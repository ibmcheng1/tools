/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2013, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/
import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.servicenow.UCDServiceNowHelper

final def airPluginTool = new AirPluginTool(args[0], args[1])
final def props = airPluginTool.getStepProperties()

def changeRequestId = props['changeRequestId']
def status = '11'
def changeOutcome = props['changeOutcome']
def shakeoutResults = props['shakeoutResults']
def shakeoutResultsUrl = props['shakeoutResultsUrl']

println "Checking request with number ${changeRequestId}"
println "Setting status to ${status}"
println "Setting outcome to ${changeOutcome}"
println "Setting shakeout results to ${shakeoutResults}"
println "Setting shakeout results URL to ${shakeoutResultsUrl}"

UCDServiceNowHelper helper = new UCDServiceNowHelper(airPluginTool)
helper.setStatusComplete(changeOutcome,status,shakeoutResults,shakeoutResultsUrl)
helper = null

println "Status set to ${status}!"
System.exit(0)
