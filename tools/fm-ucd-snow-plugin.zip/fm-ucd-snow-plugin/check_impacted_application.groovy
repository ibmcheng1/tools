/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2013, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/
import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.servicenow.UCDServiceNowHelper

final def airPluginTool = new AirPluginTool(args[0], args[1])
final def props = airPluginTool.getStepProperties()

def changeRequestId = props['changeRequestId']
def appAssetId = props['appAssetId']

println "Checking request with number ${changeRequestId}"

UCDServiceNowHelper helper = new UCDServiceNowHelper(airPluginTool)
def status = helper.checkImpactedApplication(changeRequestId,appAssetId)

if(!status) {
    println "Asset information read for ${changeRequestId}"
    System.exit(1)
}
System.exit(0)
