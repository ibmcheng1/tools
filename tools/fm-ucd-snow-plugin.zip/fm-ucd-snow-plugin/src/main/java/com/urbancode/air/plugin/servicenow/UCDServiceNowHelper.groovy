package com.urbancode.air.plugin.servicenow

import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder
import groovy.json.JsonBuilder
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import org.apache.http.Header
import org.apache.http.client.methods.*
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.DefaultHttpClient
import org.apache.http.util.EntityUtils
import org.codehaus.jettison.json.JSONException
import org.codehaus.jettison.json.JSONObject

import java.text.DateFormat
import java.text.SimpleDateFormat

class UCDServiceNowHelper {
    def airPluginTool
    def fullURL
    def idRaw
    def password
    def props = []
    def proxyHost
    def proxyPass
    def proxyPort
    def proxyUser
    def query
    def rawFields
    def rawTableLabel
    def serverUrl
    def username
    DefaultHttpClient client
    HttpClientBuilder clientBuilder
    String changeRequestId

    UCDServiceNowHelper(def airPluginToolIn) {
        airPluginTool = airPluginToolIn
        props = airPluginTool.getStepProperties()

        if (props['changeRequestId']) {
            changeRequestId = props['changeRequestId'].trim()
        }

        try {
            fullURL = new URL(props['serverUrl'].trim())
        } catch (MalformedURLException e) {
            println e.getMessage()
            System.exit(1)
        }

        serverUrl = 'https://' + fullURL.getAuthority()

        idRaw = props['id']
        password = props['password']
        proxyHost = props['proxyHost'].trim()
        query = props['query']
        rawFields = props['fields']
        rawTableLabel = props['table']
        username = props['username']

        println "[Info] Using serverUrl: '${serverUrl}'"
        println "[Info] Using username: '${username}'"

        clientBuilder = new HttpClientBuilder()
        clientBuilder.setPassword(password)
        clientBuilder.setPreemptiveAuthentication(false)
        clientBuilder.setUsername(username)

        if (proxyHost) {
            proxyPass = props['proxyPass']
            proxyPort = props['proxyPort'].trim()
            proxyUser = props['proxyUser'].trim()

            println "[Info] Using Proxy Host ${proxyHost}"
            println "[Info] Using Proxy Port ${proxyPort}"

            clientBuilder.setProxyHost(proxyHost)
            clientBuilder.setProxyPassword(proxyPass)
            clientBuilder.setProxyPort(Integer.valueOf(proxyPort))
            clientBuilder.setProxyUsername(proxyUser)
            if (proxyUser) {
                println "[Info] Using Proxy User ${proxyUser}"
            }
        }

        client = clientBuilder.buildClient()
    }

    // Unused. Issues a GET API V1 call with an encoded query (number=) and returns newline equals list
    // of fields.
    def getTableRecords() {
        def tableName = rawTableLabel.trim()

        def ids = getIDs()

        for (id in ids) {
            println "[Action] Retrieving record ${id}.\n"
            String sys_id = getSysIdForTable(id, tableName)
            def result = getRecords(tableName + '/' + sys_id.trim())
            println "[Ok] Record, ${id}, recieved.\n"

            def parsedJsonTableMap = result.result
            def sb = StringBuilder.newInstance()
            parsedJsonTableMap.each {
                if (it.value.getClass() == String) {
                    sb << "${it.key}=${it.value}"
                } else {
                    sb << "${it.key}=${it.value.value}"
                }
                sb << '\n'
            }

            airPluginTool.setOutputProperty(id, sb.toString())

            String idUrl = serverUrl + "/nav_to.do?uri=" + tableName + ".do?sys_id=" + sys_id
            airPluginTool.setOutputProperty(id + "_URL", idUrl)
        }
    }

    // Issues a GET API V1 call with an encoded query (number=) and checks fields against user input
    def checkRecordsFields() {
        def tableName = rawTableLabel.trim()

        def fieldNames = getFieldNames(rawFields)

        def ids = getIDs()

        for (id in ids) {
            println "[Action] Checking record ${id}.\n"
            String sys_id = getSysIdForTable(id, tableName)

            String idUrl = serverUrl + "/nav_to.do?uri=" + tableName + ".do?sys_id=" + sys_id
            airPluginTool.setOutputProperty(id + "_URL", idUrl)

            def parsedJson = getRecords(tableName + '/' + sys_id.trim())

            for (fieldName in fieldNames) {
                def fieldValue = parsedJson.result."${fieldName.key.toString().toLowerCase()}"
                if (fieldValue) {
                    if (!fieldName.value.toString().equalsIgnoreCase(fieldValue)) {
                        println "[Error] ${fieldName.key.toString()} does not match ${fieldName.value.toString()}; ${fieldName.key.toString()} is ${fieldValue}.\n"
                        System.exit(1)
                    }
                    println "[Ok] ${fieldName.key.toString()} equals ${fieldName.value.toString()} for Record.\n"
                } else {
                    println "[Warning] Field ${fieldName.key.toString()} was not found and is being ignored. Please enter proper fields."
                }
            }

            println "[Ok] Record, ${id}, checked.\n"
        }
    }

    // Issues a GET API V1 call with an encoded query (number=) and returns approval value
    def updateRecordsFields() {
        def fieldNames = getFieldNames(rawFields)

        def jsonfieldNames = JsonOutput.toJson(fieldNames)
        def tableName = rawTableLabel.trim()

        def ids = getIDs()
        StringEntity postEntity = new StringEntity(jsonfieldNames)

        for (id in ids) {
            println "[Action] Updating record ${id}.\n"
            String sys_id = getSysIdForTable(id, tableName)
            def method = new HttpPut(serverUrl + '/api/now/v1/table/' + tableName + '/' + sys_id.trim())
            method.addHeader("Accept", "application/json")
            method.addHeader("Content-Type", "application/json")

            method.setEntity(postEntity)

            def resp = client.execute(method)
            def statusCode = resp.getStatusLine().getStatusCode()
            if (statusCode < 200 || statusCode >= 300) {
                println "[Error] Update to record ${id} failed with status ${statusCode}. Exiting Failure."
                println('Response:\n' + resp.entity?.content?.getText("UTF-8"))
                System.exit(1)
            }

            String idUrl = serverUrl + "/nav_to.do?uri=" + tableName + ".do?sys_id=" + sys_id
            airPluginTool.setOutputProperty(id + "_URL", idUrl)

            println "[Ok] Record, ${id}, updated.\n"
        }
    }

    // Issues a GET API V1 call with an encoded query (number=) and returns approval value
    def query() {
        def tableName = rawTableLabel.trim()
        def parsedJson = getRecords(tableName + '?sysparm_query=' + query)
        return parsedJson
    }

    // Issues a GET API V1 call with an encoded query (number=) and returns approval value
    String getApproval() {
        def parsedJson = getRecords('change_request?sysparm_query=number=' + changeRequestId)
        if (parsedJson.result.size() == 0) {
            println "[Error] No Change Request found with ID ${changeRequestId}. Exiting failure."
            System.exit(1)
        }
        return parsedJson.result[0].approval
    }

    // Issues a GET API V1 call with an encoded query (number=) and returns 'state' value
    Integer getStatus() {
        def parsedJson = getRecords('change_request?sysparm_query=number=' + changeRequestId)
        if (parsedJson.result.size() == 0) {
            println "[Error] No Change Request found with ID ${changeRequestId}. Exiting failure."
            System.exit(1)
        }
        return Integer.valueOf(parsedJson.result[0].state)
    }

    // Issues a GET API V1 call with an encoded query (number=) and returns 'state' value
    String getImpactedAssetID(String sysId) {
        def parsedJson = getRecords('cmdb_ci_service?sysparm_query=sys_id=' + sysId + '&sysparm_fields=u_asset_id&sysparm_limit=1')
        println "parsedjson=${parsedJson}"

        if (parsedJson.result.size() == 0) {
            println "[Error] No CMDB AssetID found with ID ${sysId}. Exiting failure."
            System.exit(1)
        }
        if (parsedJson.result[0].u_asset_id.equals("")) {
            println "[Error] No CMDB AssetID found with ID ${sysId}. Exiting failure."
            System.exit(1)
        }
        return parsedJson.result[0].u_asset_id;
    }


    def checkImpactedApplication(String changeRequestId, String appAssetId) {
        def parsedJson = getRecords('change_request?sysparm_query=number=' + changeRequestId + '&sysparm_fields=cmdb_ci&sysparm_limit=1')
        println "parsedjson=${parsedJson}"
        def failure = false
        def assetId = ""
        if (parsedJson.result.size() == 0) {
            println "[Error] No CMDB AssetID found for change request ${changeRequestId}. Exiting failure."
            System.exit(1)
        }
        if (null == parsedJson.result[0].cmdb_ci) {
            println "[Error] No CMDB Asset found for change request ${changeRequestId}. Exiting failure."
            System.exit(1)
        }
        def sysId = parsedJson.result[0].cmdb_ci.value;
        if (null != sysId && sysId.length() > 0) {
            assetId = getImpactedAssetID(sysId)
        } else {
            println "[Error] No CMDB Asset found for change request ${changeRequestId}. Exiting failure."
            System.exit(1)
        }
        if (null != assetId && assetId.equalsIgnoreCase(appAssetId))
            failure = true
        return failure
    }

    /*
    GET https://fanniemaedev.service-now.com/api/now/table/change_request?
    sysparm_query=number%3DCHG0295541
    &
    sysparm_display_value=true
    &
    sysparm_exclude_reference_link=true
    &
    sysparm_fields=parent%2Csys_updated_on%2Cstate%2Csys_created_by%2Cimpact%2C
    active%2Cproduction_system%2Ccab_recommendation%2Cend_date%2Cu_sox_relevance%2C
    u_category%2Cu_manager%2Cu_shakeout_results_url%2Csys_created_on%2Cwork_end%2C
    cab_date%2Cassignment_group%2Curgency%2Cu_environment%2Clocation%2Ctype%2Cnumber%2C
    u_change_outcome%2Cpriority%2Cshort_description%2Cu_jira_id%2Cwork_start%2Cstart_date%2C
    assigned_to%2Cu_project_id%2Cexpected_start%2Cu_expected_end_date%2Ccategory
    &
    sysparm_limit=1
Headers
     */

    def getChangeRecord(String changeRequest, String fields) {
        def queryfields = "&sysparm_fields=parent%2Csys_updated_on%2Cstate%2Csys_created_by%2Cimpact%2Cactive%2Cproduction_system%2Ccab_recommendation%2Cend_date%2Cu_sox_relevance%2Cu_category%2Cu_manager%2Cu_shakeout_results_url%2Csys_created_on%2Cwork_end%2Ccab_date%2Cassignment_group%2Curgency%2Cu_environment%2Clocation%2Ctype%2Cnumber%2Cu_change_outcome%2Cpriority%2Cshort_description%2Cu_jira_id%2Cwork_start%2Cstart_date%2Cassigned_to%2Cu_project_id%2Cexpected_start%2Cu_expected_end_date%2Ccategory%2Capproval%2Ccmdb_ci%2Cu_impacted_application"
        if (null != fields && fields.equalsIgnoreCase("getAllFields"))
            queryfields = ""
        def parsedJson = getRecords('change_request?sysparm_query=number=' + changeRequestId + '&sysparm_display_value=true&sysparm_exclude_reference_link=true' + queryfields + '&sysparm_limit=1')
        if (parsedJson.result.size() == 0) {
            println "[Error] No Change Request found with ID ${changeRequestId}. Exiting failure."
            System.exit(1)
        }
        return parsedJson.result[0];
    }

    // Issues a GET API call and returns a size 2 array of the deployment window
    def getDeploymentWindow(String startDateField, String endDateField) {
        def parsedJson = getRecords('change_request?sysparm_query=number=' + changeRequestId)
        if (parsedJson.result.size() == 0) {
            println "[Error] No Change Request found with ID ${changeRequestId}. Exiting failure."
            System.exit(1)
        }
        def failure = false
        def pattern = "yyyy-MM-dd HH:mm:ss"

        //Read the time from ServiceNow as UTC. JVM will convert java date to system timezone for comparing
        DateFormat dateformat = new SimpleDateFormat(pattern)
        dateformat.setTimeZone(TimeZone.getTimeZone("UTC"))

        //check that specified fields exist
        if (parsedJson.result[0]."${startDateField}" == null) {
            println("[Error] No date field exists in ${changeRequestId} with name '${startDateField}'")
            failure = true
        }
        if (parsedJson.result[0]."${endDateField}" == null) {
            println("[Error] No date field exists in ${changeRequestId} with name '${endDateField}'")
            failure = true
        }

        if (failure) {
            println("[Solution] Please update the field names to valid date fields.")
            System.exit(1)
        }

        def startDate = dateformat.parse(parsedJson.result[0]."${startDateField}")
        def endDate = dateformat.parse(parsedJson.result[0]."${endDateField}")

        def window = [startDate, endDate]

        return window
    }

    // Issues a GET API V1 call with an encoded query (number=) and returns 'sys_id' value
    String getChangeRequestSysId() {
        def parsedJson = getRecords('change_request?sysparm_query=number=' + changeRequestId)
        if (parsedJson.result.size() == 0) {
            println "[Error] No Change Request found with ID ${changeRequestId}. Exiting failure."
            System.exit(1)
        }
        return parsedJson.result[0].sys_id
    }

    String getSysIdForTable(String requestId, String tableName) {
        def parsedJson = getRecords(tableName + '?sysparm_query=number=' + requestId)
        if (parsedJson.result.size() == 0) {
            println "[Error] No ${tableName} found with ID ${requestId}. Exiting failure."
            System.exit(1)
        }
        return parsedJson.result[0].sys_id
    }

    //// Issues a GET API V1 call with an encoded query (number=) and returns JSON body
    def getTaskList(String changeRequestSysId) {
        def parsedJson = getRecords('change_task?sysparm_query=change_request=' + changeRequestSysId)
        return parsedJson
    }

    // Issues a PATCH API V1 call to edit the state value of a change task
    def setTaskStatus(String taskId, String status) {
        String sysId = getSysIdForTable(taskId, "change_task")
        HttpPatch patch = new HttpPatch(serverUrl + '/api/now/v1/table/change_task/' + sysId)
        patch.addHeader("Accept", "application/json")
        patch.addHeader("Content-Type", "application/json")
        String updateInfo = "{'state':'" + status + "'}"
        StringEntity postEntity = new StringEntity(updateInfo)
        patch.setEntity(postEntity)
        println "[Action] Setting task ${taskId} with status ${status}"
        println updateInfo

        def resp = client.execute(patch)
        def statusCode = resp.getStatusLine().getStatusCode()
        if (statusCode < 200 || statusCode >= 300) {
            println "[Error] Request failed with status ${statusCode}. Exiting Failure."
            println('Response:\n' + resp.entity?.content?.getText("UTF-8"))
            System.exit(1)
        }

        def newStatus = getTaskStatus(sysId)
        if (newStatus != Integer.valueOf(status)) {
            println "[Error] Status was not updated. Exiting Failure"
            System.exit(1)
        }
    }

    // Issues a GET API V1 call to a Change Task determined by encoded query (sys_id=)
    // and returns its State value
    Integer getTaskStatus(String taskId) {
        def parsedJson = getRecords('change_task?sysparm_query=sys_id=' + taskId)
        if (parsedJson.result.size() == 0) {
            println "[Error] No Change Request found with ID ${changeRequestId}. Exiting failure."
            System.exit(1)
        }
        return Integer.valueOf(parsedJson.result[0].state)
    }


    String getCurrentDateTime() {
        def date = new Date()
        def sdf = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss")
        return sdf.format(date)
    }

    // Sets the status of a Change Request
    def setStatusWorkInProgress(String changeRequestId, String assignedTo) {
        HttpEntityEnclosingRequestBase method = null
        //def sysId = getChangeRequestSysId()
        def status = '2'
        method = new HttpPost(serverUrl + '/api/now/import/u_change_staging_update')
        method.addHeader("Accept", "application/json")
        method.addHeader("Content-Type", "application/json")
        String updateInfo = ""
        if (null == assignedTo || assignedTo.empty)
            updateInfo = "{'u_number':'" + changeRequestId + "','u_state':'" + status + "','u_actual_work_start':'" + getCurrentDateTime() + "'}"
        else
            updateInfo = "{'u_number':'" + changeRequestId + "','u_state':'" + status + "','u_actual_work_start':'" + getCurrentDateTime() + "','u_assigned_to':'" + assignedTo + "'}"

        StringEntity postEntity = new StringEntity(updateInfo)
        method.setEntity(postEntity)

        def resp = client.execute(method)
        println('Response:\n' + resp.entity?.content?.getText("UTF-8"))
        def statusCode = resp.getStatusLine().getStatusCode()
        if (statusCode < 200 || statusCode >= 300) {
            println "[Error] Request failed with status ${statusCode}. Exiting Failure."
            println('Response:\n' + resp.entity?.content?.getText("UTF-8"))
            System.exit(1)
        }
        def newStatus = getStatus()
        if (newStatus != Integer.valueOf(status)) {
            println "[Error] Status was not updated. Exiting Failure"
            //println EntityUtils.toString(resp.getEntity())
            System.exit(1)
        }
    }

    // Set status to complete
    // Sets the status of a Change Request
    /*
           -6	Draft	                    false
           -5	Open	                    false
           1	Scheduled	                false
           2	Work in Progress	        false
           11	Completed	                false
           3	Closed	                    false
           7	Cancelled	                false
           u_assigned_to

           u_change_outcome
           11	Successful	false
           12	Exceeded Scheduled Window	false
           13	Issues During Scheduled Window	false
           14	Partially Installed	false
           15	Backed Out	false
           16	Incorrect Change Deployed	false
           17	Change Not Deployed	false
           18	Status Not Updated	false
           19	Deployed without Authorization	false
    */

    def setStatusComplete(String changeOutcome, String status, String shakeoutResults, String shakeoutResultsUrl) {
        /*
        //def sysId = getChangeRequestSysId()
        println "Before executing getchange record"
        def chgRecord = getChangeRecord(changeRequestId,null)
        if (null != chgRecord.state) {
            if (chgRecord.state.toString().trim().equalsIgnoreCase("Completed")) {
                println "[Error] Change ticket is already in Completed state. Exiting Failure"
                System.exit(1)
            }
        } else {
            println "[Error] Unable to get the change request details. Exiting Failure."
            System.exit(1)
        }
        //println "After executing getchange record"
        */
        HttpEntityEnclosingRequestBase method = null
        method = new HttpPost(serverUrl + '/api/now/import/u_change_staging_update')
        method.addHeader("Accept", "application/json")
        method.addHeader("Content-Type", "application/json")
        if (shakeoutResults == null)
            shakeoutResults = ""
        if (shakeoutResultsUrl == null)
            shakeoutResultsUrl = ""
        //String updateInfo = "{'u_number':'" + changeRequestId + "','u_state':'" + status + "','u_actual_work_end':'" + getCurrentDateTime() + "'u_change_outcome':'" + changeOutcome + "','u_shakeout_results':'Executed the task through an manual/automated task using UrbanCode Release tool','u_shakeout_results_url':'https://ucrelease:8443'}"
        String updateInfo = "{'u_number':'" + changeRequestId + "','u_shakeout_results':'" + shakeoutResults + "','u_shakeout_results_url':'" + shakeoutResultsUrl + "'}"
        StringEntity postEntity = new StringEntity(updateInfo)
        method.setEntity(postEntity)
        def resp = client.execute(method)
        //println "After executing execute resp is ${resp}"

        method = new HttpPost(serverUrl + '/api/now/import/u_change_staging_update')
        method.addHeader("Accept", "application/json")
        method.addHeader("Content-Type", "application/json")
        //String updateInfo = "{'u_number':'" + changeRequestId + "','u_state':'" + status + "','u_actual_work_end':'" + getCurrentDateTime() + "'u_change_outcome':'" + changeOutcome + "','u_shakeout_results':'Executed the task through an manual/automated task using UrbanCode Release tool','u_shakeout_results_url':'https://ucrelease:8443'}"
        updateInfo = "{'u_number':'" + changeRequestId + "','u_state':'" + status + "','u_change_outcome':'" + changeOutcome + "','u_actual_work_end':'" + getCurrentDateTime() + "'}"
        postEntity = new StringEntity(updateInfo)
        method.setEntity(postEntity)
        resp = client.execute(method)
        //println "After executing execute resp is ${resp}"

//        println('Response:\n' + resp.entity?.content?.getText("UTF-8"))
//        def statusCode = resp.getStatusLine().getStatusCode()
//        println('statusCode:' + statusCode)
//        if (statusCode < 200 || statusCode >= 300) {
//            println "[Error] Request failed with status ${statusCode}. Exiting Failure."
//            //println('Response:\n' + resp.entity?.content?.getText("UTF-8"))
//            System.exit(1)
//        }
        def parsedJson
        def entity = EntityUtils.toString(resp.getEntity())

        def slurper = new JsonSlurper()
        try {
            parsedJson = slurper.parseText(entity)
        }
        catch (groovy.json.JsonException e) {
            println ""
            println "Failed to parse response body. Printing useful debugging information and exiting."
            println ""
            println "Response status code: ${statusCode}."
            println ""
            println "Header:"
            Header[] headers = resp.getAllHeaders()
            for (Header header : headers) {
                System.out.println(header.getName() + ":" + header.getValue())
            }
            println ""
            println "Body:"
            println entity
            println ""
            println "Stacktrace:"
            e.printStackTrace()
            System.exit(1)
        }
        def statusCode = resp.getStatusLine().getStatusCode()
        //println "[Error] Status code ${statusCode}"
        if (statusCode < 200 || statusCode >= 300) {
            println "[Error] Update failed with status ${statusCode}. Exiting Failure."
            //println('Response:\n' + resp.entity?.content?.getText("UTF-8"))
            System.exit(1)
        } else {
            println "[Ok] Updated successfully with status ${statusCode}."
            println "[Ok] Record: '${parsedJson.result.sys_id}' Status: ''${parsedJson.result.status}''"
        }

        def newStatus = getStatus()
        if (newStatus != Integer.valueOf(status)) {
            println "[Error] Status was not updated. Exiting Failure"
            System.exit(1)
        }
    }

    // Add notes to a Change Request
    def updateNotes(String changeRequestId, String notes) {
        HttpEntityEnclosingRequestBase method = null
        def sysId = getChangeRequestSysId()

        method = new HttpPost(serverUrl + '/api/now/import/u_change_staging_update')
        method.addHeader("Accept", "application/json")
        method.addHeader("Content-Type", "application/json")

        String updateInfo = "{'u_number':'" + changeRequestId + "','u_work_notes':'" + notes + "'}"
        StringEntity postEntity = new StringEntity(updateInfo)
        method.setEntity(postEntity)

        def resp = client.execute(method)
        println('Response:\n' + resp.entity?.content?.getText("UTF-8"))
        def statusCode = resp.getStatusLine().getStatusCode()
        if (statusCode < 200 || statusCode >= 300) {
            println "[Error] Request failed with status ${statusCode}. Exiting Failure."
            System.exit(1)
        }
    }

    def getImplPlan() {
        StringBuffer plan = new StringBuffer("")
        plan.append("1. Login to UCD/UCR")
        plan.append("\n2. Select the deployment plan for the specified release")
        plan.append("\n3. Make sure the snapshot is available and assigned to the release")
        plan.append("\n4. Verify the required properties are provided in the automated task")
        plan.append("\n5. Execute the step manually (or) allow the step to run automatically")
        plan.append("\n6. UCD will execute the verify process and will load the JIL file")
        return plan.toString()
    }

    def getShakeoutPlan() {
        StringBuffer plan = new StringBuffer("")
        plan.append("1. Login to UCD/UCR")
        plan.append("\n2. Select the deployment plan for the specified release")
        plan.append("\n3. View the automated deploy step for loading the JIL")
        plan.append("\n4. Make sure the JIL file is loaded and status is success")
        return plan.toString()
    }

    def getBackoutPlan() {
        StringBuffer plan = new StringBuffer("")
        plan.append("This change ticket is created using the Automated UCD deployment task. " +
                "Please reach out to Autosys support team.")
        return plan.toString()
    }

    def getChangeDesc() {
        StringBuffer desc = new StringBuffer();
        try {
            String jilContents = new File(props['u_jilFileName'].toString()).getText('UTF-8')
            desc.append("\nSCOPE:Autosys R11 JIL Migration");
            desc.append("\n--------------------------------");
            desc.append("\nAutosys instance : " + props['u_instance_id']);
            desc.append("\nCustomer impact  : " + props['u_customer_impact_statement']);
            desc.append("\nAffected CI      : " + props['u_affected_ci_list'])
            desc.append("\nPath to JIL file : " + props['u_jilFileName']);
            desc.append("\n--------------------------------");
            desc.append("\nJIL file contents: " + "\n")
            desc.append("\n------------ Start Content -------------");
            desc.append(jilContents)
            desc.append("\n------------ End Content-------------");
        } catch(IOException e) {
            println "[Error] Unable to read the JIL file. Exiting Failure."
            System.exit(1)
        } catch(FileNotFoundException e) {
            println "[Error] Unable to find the JIL file provided. Exiting Failure."
            System.exit(1)
        }
        return desc.toString()
    }


    String getCurrentDateTime(long grace) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss a");
        Date edt = new Date((new Date()).getTime() + grace);
        return (grace == 0) ? sdf.format(new Date()) : sdf.format(edt);
    }

    def createAutosysChangeTicket() {
        def chgTicketNumber = null
        HttpEntityEnclosingRequestBase method = null
        method = new HttpPost(serverUrl + '/api/now/import/u_create_standard_change');
        method.addHeader("Accept", "application/json")
        method.addHeader("Content-Type", "application/json")
        /*
        String crData = "{'u_template_name':'" + props['u_template_name'] + "','u_ci_name':'" + props['u_ci_name'] +
                "','u_primary_impacted_app_name':'" + props['u_primary_impacted_app_name'] +
                "','u_environment':'" + props['u_environment'] + "','u_start_date':'" + props['u_start_date'] +
                "','u_end_date':'" + props['u_end_date'] + "'}";

        String crData = "{\"u_template_name\":\"AUTOSUPP: UCD Application Autosys R11 JIL Migration\",\"u_start_date\":\"03-23-2019 19:23:31 PM\"" +
                ",\"u_end_date\":\"03-24-2019 19:30:31 PM\",\"u_ci_name\":\"Urbancode Utilities\"," +
                "\"u_primary_impacted_app_name\":\"Urbancode Utilities\",\"u_environment\":\"Development\",\"u_parent_ticket\":\"\"," +
                "\"u_change_plan\":\"test\",\"u_backout_plan\":\"test\",\"u_shakeout_plan\":\"test\",\"u_description\":\"test\"}"
        */
        JSONObject json = new JSONObject();
        try {
            json.put("u_template_name", props['u_template_name'].toString());
            json.put("u_start_date", getCurrentDateTime(5000));
            json.put("u_end_date", getCurrentDateTime(36000000));
            json.put("u_ci_name", props['u_ci_name'].toString());
            json.put("u_primary_impacted_app_name", props['u_primary_impacted_app_name'].toString());
            json.put("u_environment", props['u_environment'].toString());
            json.put("u_parent_ticket", (props['u_parent_ticket'] != null?props['u_parent_ticket'].toString():""));
            json.put("u_change_plan", getImplPlan());
            json.put("u_backout_plan", getBackoutPlan());
            json.put("u_shakeout_plan", getShakeoutPlan());
            json.put("u_description", getChangeDesc());
            //e = new StringEntity(json.toString());
            //println json.toString()
            StringEntity postEntity = new StringEntity(json.toString())
            method.setEntity(postEntity)
            def resp = client.execute(method)
            //println('Response:\n' + resp.entity?.content?.getText("UTF-8"))
            def statusCode = resp.getStatusLine().getStatusCode()
            String entity = EntityUtils.toString(resp.getEntity())
            println "[Info] Status recieved : " + statusCode
            println "[Info] Response entity : " + entity
            if (statusCode < 200 || statusCode >= 300) {
                println "[Error] Request failed with status ${statusCode}. Exiting Failure."
                System.exit(1)
            } else {
                def slurper = new JsonSlurper()
                def parsedJson
                parsedJson = slurper.parseText(entity)
                String statusMessage = parsedJson.result[0].getAt("status_message")
                println "[Info] Status message : " + statusMessage
                if (statusMessage.contains("success")) {
                    chgTicketNumber = statusMessage.substring(statusMessage.indexOf("chg:")+4,statusMessage.indexOf(",",statusMessage.indexOf("chg:")+4))
                }
            }
        } catch (JSONException e) {
            System.out.println("Error creating the request JSON");

        } catch (groovy.json.JsonException e) {
            println "[Error] Unable to parse response JSON. Exiting Failure."
            System.exit(1)
        }
        return chgTicketNumber
    }

    // Insert a table row matching TableName using the POST API V1 with a JSON
    // Reqeust Body
    def insertRow() {
        def fieldNames = getFieldNames(rawFields)

        def jsonfieldNames = JsonOutput.toJson(fieldNames)
        def tableName = rawTableLabel.trim()

        StringEntity postEntity = new StringEntity(jsonfieldNames)

        def method = new HttpPost(serverUrl + '/api/now/v1/table/' + tableName)
        method.addHeader("Accept", "application/json")
        method.addHeader("Content-Type", "application/json")

        method.setEntity(postEntity)

        def resp = client.execute(method)
        def parsedJson
        def entity = EntityUtils.toString(resp.getEntity())

        def slurper = new JsonSlurper()
        try {
            parsedJson = slurper.parseText(entity)
        }
        catch (groovy.json.JsonException e) {
            println ""
            println "Failed to parse response body. Printing useful debugging information and exiting."
            println ""
            println "Response status code: ${statusCode}."
            println ""
            println "Header:"
            Header[] headers = resp.getAllHeaders()
            for (Header header : headers) {
                System.out.println(header.getName() + ":" + header.getValue())
            }
            println ""
            println "Body:"
            println entity
            println ""
            println "Stacktrace:"
            e.printStackTrace()
            System.exit(1)
        }
        def statusCode = resp.getStatusLine().getStatusCode()
        if (statusCode < 200 || statusCode >= 300) {
            println "[Error] Update to table ${tableName} failed with status ${statusCode}. Exiting Failure."
            println('Response:\n' + resp.entity?.content?.getText("UTF-8"))
            System.exit(1)
        } else {
            println "[Ok] Table '${tableName}' updated successfully with status ${statusCode}."
            println "[Ok] Record: '${parsedJson.result.sys_id}' as '${parsedJson.result.number}' created."
        }

        String idUrl = serverUrl + "/nav_to.do?uri=" + tableName + ".do?sys_id=" + parsedJson.result.sys_id

        airPluginTool.setOutputProperty('recordSystemID', parsedJson.result.sys_id)
        airPluginTool.setOutputProperty('recordSystemNumber', parsedJson.result.number)
        airPluginTool.setOutputProperty("recordSystemURL", idUrl)
    }

    // Deletes a table row matching TableName and sys_id
    def deleteRow() {
        def tableName = rawTableLabel.trim()
        def ids = getIDs()

        for (id in ids) {
            String sys_id = getSysIdForTable(id, tableName)
            deleteRecord(tableName + '/' + sys_id.trim())
        }
    }

    // Deletes all Table rows macthing a TableName and an encoded query
    def deleteMultipleRows() {
        def condition = props['condition']
        def tableName = props['table']

        while (condition.startsWith('=')) {
            condition = condition.substring(1, condition.length())
        }

        println "[Action] Deleting row from table ${tableName}"
        println "[Action] Deleting rows with condition ${condition}"

        def queryJson = getRecords(tableName + '?sysparm_query=' + condition)
        def querySize = queryJson.result.size()

        for (int i = 0; i < querySize; i++) {
            deleteRecord(tableName + "/" + queryJson.result.sys_id[i])
            println "Deleted " + tableName + " record with sys_id=" + queryJson.result.sys_id[i]
        }
    }

//////////////////////////////// HELPER METHODS \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    // Excutes ServiceNows V1 REST API DELETE call. input form: {TableName}/{sys_id}
    def deleteRecord(String tableAndSys_id) {
        HttpDelete delete = new HttpDelete(serverUrl + "/api/now/v1/table/" + tableAndSys_id)
        delete.addHeader("Accept", "application/json")
        delete.addHeader("Content-Type", "application/json")

        def resp = client.execute(delete)
        def statusCode = resp.getStatusLine().getStatusCode()
        if (statusCode != 204) {
            println "[Error] Request failed with status ${statusCode}. Exiting Failure."
            println('Response:\n' + resp.entity?.content?.getText("UTF-8"))
            System.exit(1)
        }
    }

    // Accepts any string compatible with ServiceNow's API GET Retreive Record appended to serverUrl + '/api/now/v1/table/'
    def getRecords(String query) {
        def parsedJson

        def encodedQuery = encodeQuery(query)

        HttpGet get = new HttpGet(serverUrl + '/api/now/v1/table/' + encodedQuery)
        get.addHeader("Accept", "application/json")
        def resp = client.execute(get)

        def statusCode = resp.getStatusLine().getStatusCode()
        if (statusCode < 200 || statusCode >= 300) {
            println "[Error] Request failed with status ${statusCode}. Exiting Failure."
            println('Response:\n' + resp.entity?.content?.getText("UTF-8"))
            System.exit(1)
        }
        def entity = EntityUtils.toString(resp.getEntity())

        def slurper = new JsonSlurper()
        try {
            parsedJson = slurper.parseText(entity)
        }
        catch (groovy.json.JsonException e) {
            println ""
            println "Failed to parse response body. Printing useful debugging information and exiting."
            println ""
            println "Response status code: ${statusCode}."
            println ""
            println "Header:"
            Header[] headers = resp.getAllHeaders()
            for (Header header : headers) {
                System.out.println(header.getName() + ":" + header.getValue())
            }
            println ""
            println "Body:"
            println entity
            println ""
            println "Stacktrace:"
            e.printStackTrace()
            System.exit(1)
        }
        return parsedJson
    }

    // Custom URL encoder for Service Now API
    def encodeQuery(String query) {
        query = query.replaceAll("\\<", "%3C")
        query = query.replaceAll("\\>", "%3E")
        query = query.replaceAll("\\{", "%7B")
        query = query.replaceAll("}", "%7D")
        query = query.replaceAll("\\^", "%5E")
        query = query.replaceAll("\\ ", "%20")
        return query
    }

    /**
     * [WSP] *CHAR [WSP] '=' [WSP] *CHAR [WSP] parsed into a LinkedHashMap
     *
     * @param textArea Accepts any [WSP] *CHAR [WSP] '=' [WSP] *CHAR [WSP]
     * @return A linked hashmap of all the parsed value key. Values may be null.
     */
    private LinkedHashMap getFieldNames(
            String nlSeparatedValueEqualKey) {
        def result = [:]
        nlSeparatedValueEqualKey.eachLine { text ->
            String[] fieldValue = text.split('=', 2)*.trim()
            if (fieldValue[0] && fieldValue.size() == 2) {
                result[fieldValue[0]] = fieldValue[1]
            } else {
                println "[Error] Failed on line: " + text
                println '[Possible Solution] Use \'=\' for name value seperation. For example: approval=approved'
                System.exit(1)
            }
        }
        return result
    }

    private def getIDs() {
        return idRaw.trim().split('\n')
    }

}
