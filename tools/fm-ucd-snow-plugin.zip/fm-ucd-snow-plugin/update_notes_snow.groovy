import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.servicenow.UCDServiceNowHelper

final def airPluginTool = new AirPluginTool(args[0], args[1])
final def props = airPluginTool.getStepProperties()
def changeRequestId = props['changeRequestId']
def notes = props['notes']

UCDServiceNowHelper helper = new UCDServiceNowHelper(airPluginTool)
helper.updateNotes(changeRequestId,notes)

println "Adding notes to ${changeRequestId}"
System.exit(0)
