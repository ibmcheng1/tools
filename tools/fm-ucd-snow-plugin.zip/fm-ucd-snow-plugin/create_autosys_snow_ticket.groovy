import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.servicenow.UCDServiceNowHelper

final def airPluginTool = new AirPluginTool(args[0], args[1])
UCDServiceNowHelper helper = new UCDServiceNowHelper(airPluginTool)
def chgTicket = helper.createAutosysChangeTicket()
if(chgTicket == null) {
    println "[Error] Standard Autosys Change ticket creation failed."
    System.exit(1)
} else {
    airPluginTool.setOutputProperty("autosysChangeTicket",chgTicket)
    airPluginTool.storeOutputProperties()
    println "[Info] Created standard autosys change ticket : " + chgTicket
}
System.exit(0)