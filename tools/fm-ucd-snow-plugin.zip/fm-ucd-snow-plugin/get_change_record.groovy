/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2013, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/
import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.servicenow.UCDServiceNowHelper
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

final def airPluginTool = new AirPluginTool(args[0], args[1])
final def props = airPluginTool.getStepProperties()

def changeRequestId = props['changeRequestId']
def fields = props['fields']
println "Reading request with number ${changeRequestId}"
println "Fields requested in response ${fields}"
/*
props.each{ key, value ->
    println "Key = ${key}, value = ${value}"
}
*/
UCDServiceNowHelper helper = new UCDServiceNowHelper(airPluginTool)
def chgDetails = helper.getChangeRecord()
if (chgDetails == null || chgDetails.toString().empty) {
    helper = null
    System.exit(1)
}
airPluginTool.setOutputProperty("Number",chgDetails['number'])
airPluginTool.setOutputProperty("ChangeType",chgDetails['type'])
airPluginTool.setOutputProperty("Category",chgDetails['u_category'])
airPluginTool.setOutputProperty("Environment",chgDetails['u_environment'])
airPluginTool.setOutputProperty("State",chgDetails['state'])
airPluginTool.setOutputProperty("PlannedStartDate",chgDetails['start_date'])
airPluginTool.setOutputProperty("PlannedEndDate",chgDetails['end_date'])
airPluginTool.setOutputProperty("ActualWorkStart",chgDetails['work_start'])
airPluginTool.setOutputProperty("ActualWorkEnd",chgDetails['work_end'])
airPluginTool.setOutputProperty("Parent",chgDetails['parent'])
airPluginTool.setOutputProperty("PrimaryImpactedApplication",chgDetails['u_impacted_application'])
airPluginTool.setOutputProperty("ConfigurationItem",chgDetails['cmdb_ci'])
airPluginTool.setOutputProperty("changeDetails",groovy.json.JsonOutput.toJson(chgDetails))
airPluginTool.storeOutputProperties()
// println "Change details recieved are ${chgDetails}"
helper = null
System.exit(0)

/*
{
  "result": [
    {
      "end_date": "09-06-2018 06:30:00 AM",
      "parent": "",
      "u_shakeout_results_url": "",
      "short_description": "Create new integration server for UrbanCode Apps",
      "work_start": "09-04-2018 01:11:08 PM",
      "assignment_group": "RELEASE ORCHESTARTION SUPPORT L3",
      "u_jira_id": "",
      "sys_updated_on": "09-05-2018 12:30:34 PM",
      "type": "Normal",
      "u_sox_relevance": null,
      "number": "CHG0295541",
      "u_impacted_application": "UrbanCode Deploy",
      "urgency": "3 - Low",
      "sys_created_on": "08-17-2018 04:29:22 PM",
      "state": "Work in Progress",
      "u_expected_end_date": "",
      "sys_created_by": "s8ucrm",
      "u_change_outcome": null,
      "start_date": "08-27-2018 08:00:00 PM",
      "assigned_to": "Satish Mogasati",
      "cmdb_ci": "UrbanCode Deploy",
      "u_environment": "Production",
      "approval": "Approved",
      "impact": "3-Moderate/Limited",
      "u_project_id": "555184",
      "active": "true",
      "priority": "4 - Low",
      "production_system": "false",
      "cab_recommendation": "",
      "expected_start": "",
      "u_category": "Software > Functionality",
      "work_end": "",
      "location": "",
      "u_manager": "Christopher Mendelson",
      "cab_date": "",
      "category": "Other"
    }
  ]
}

 */
