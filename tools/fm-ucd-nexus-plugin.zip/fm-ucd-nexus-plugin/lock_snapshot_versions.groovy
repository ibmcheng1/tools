import com.urbancode.air.AirPluginTool

import com.urbancode.air.plugin.nexus.UCDNexusHelper

final def airPluginTool = new AirPluginTool(args[0], args[1])
final def props = airPluginTool.getStepProperties()

def appId = props['applicationId']
def snapshotId = props['snapshotId']
def snapshotName = props['snapshotName']
def assetId = props['assetId']
def ucdServer = props['ucdServer']
def ucdUser = props['ucdUser']
def ucdPass = props['ucdPass']

if(snapshotName == null || snapshotId == null) {
    println "[Error] Invalid Snapshot Name and/or Snapshot ID."
    System.exit(1)
}

if(assetId == null || appId == null) {
    println "[Error] Invalid Asset ID and/or Application ID."
    System.exit(1)
}

UCDNexusHelper nexusHelper = new UCDNexusHelper()
//nexusHelper.scan()
println "Asset ID      => " + assetId
println "Snapshot ID   => " + snapshotId
println "Snapshot Name => " + snapshotName
//println "Before calling lock snapshot versions"
int exitCode = nexusHelper.lockSnapshotVersions(snapshotId,ucdServer,ucdUser,ucdPass)
//println "After calling lock snapshot versions"
println "Process returned exit code : "+ exitCode
if(exitCode == 0)
    println "SUCCESS: Snapshot '" + snapshotName + "' versions are locked."
else
    println "FAILED: Error locking snapshot '" + snapshotName + "' versions."
System.exit(exitCode)
