package com.urbancode.air.plugin.nexus.repo

import groovy.io.FileType
import java.nio.file.Path

class RepoLoader {
    private String serverHost;
    private String credentials;

    RepoLoader(String serverhost, String auth){
        this.setServerHost(serverhost);
        this.setCredentials(auth);
    }

    private String getServerHost() {
        return serverHost;
    }

    private void setServerHost(String serverHost) {
        this.serverHost = serverHost;
    }

    private String getCredentials() {
        return credentials;
    }

    private void setCredentials(String credentials) {
        this.credentials = credentials;
    }

    int start(String filepath, String repository) {
        def exitCode = -1
        try {
            ArrayList<Path> files = getFiles(filepath);
            String msg = "UPLOADING FILES TO " + repository + ": " + files.toString();
            System.out.println(msg);
            exitCode = load(files, repository);
        } catch (InterruptedException e){
            Writer writer = new StringWriter();
            e.printStackTrace(new PrintWriter(writer));
            System.err.println(writer.toString());
            Thread.currentThread().interrupt();
        } catch (IOException e){
            Writer writer = new StringWriter();
            e.printStackTrace(new PrintWriter(writer));
            System.err.println(writer.toString());
            Thread.currentThread().interrupt();

        }
    }

    int start(String filepath, String repository, String groupId, String artifactId) {
        def exitCode = -1
        try {
            ArrayList<Path> files = getFiles(filepath);
            String msg = "UPLOADING FILES TO " + repository + ": " + files.toString();
            System.out.println(msg);
            exitCode = load(files, repository, groupId + "/" + artifactId);
        } catch (InterruptedException e){
            Writer writer = new StringWriter();
            e.printStackTrace(new PrintWriter(writer));
            System.err.println(writer.toString());
            Thread.currentThread().interrupt();
        } catch (IOException e){
            Writer writer = new StringWriter();
            e.printStackTrace(new PrintWriter(writer));
            System.err.println(writer.toString());
            Thread.currentThread().interrupt();

        }
        return exitCode;
    }

//    int start(String filepath, String repository, String extension) {
//        def exitCode = -1
//        try {
//            ArrayList<Path> files = getFiles(filepath);
//            Iterator<Path> i = files.iterator();
//            while (i.hasNext()) {
//                Path file = i.next();
//                String ext = FilenameUtils.getExtension(file.toString());
//                if (!ext.equals(extension)) {
//                    i.remove();
//                }
//            }
//            String msg = "UPLOADING FILES TO " + repository + ": " + files.toString();
//            System.out.println(msg);
//            exitCode = load(files, repository);
//        } catch (InterruptedException e){
//            Writer writer = new StringWriter();
//            e.printStackTrace(new PrintWriter(writer));
//            System.err.println(writer.toString());
//            Thread.currentThread().interrupt();
//        }catch (IOException e){
//            Writer writer = new StringWriter();
//            e.printStackTrace(new PrintWriter(writer));
//            System.err.println(writer.toString());
//            Thread.currentThread().interrupt();
//
//        }
//        return exitCode;
//    }

    private static ArrayList<Path> getFiles(String filepath) throws IOException {
        def list = new ArrayList();
        def dir = new File(filepath)
        dir.eachFileRecurse (FileType.FILES) { file ->
            list << file.toPath()
        }
        return list;
    }

    private int load(List<Path> artifacts, String repository) throws IOException, InterruptedException {
        def exitCode = -1
        def prErrCode
        for (Path artifact : artifacts) {
            System.out.println("UPLOADING TO NEXUS: " + artifact.toString());
            prErrCode = uploadFile("curl", "-v", "-u", this.getCredentials(),
                    "--upload-file", artifact.toString(),
                    this.getServerHost() + "/nexus/repository/" + repository + "/" + artifact.getFileName());
            if(prErrCode != 0) {
                println "Error occured uploading to Nexus repo. File name : " + artifact.getFileName();
                exitCode = -1
            } else
                exitCode = prErrCode
        }
        return exitCode
    }

    private int load(List<Path> artifacts, String repository, String artifactEndpoint) throws IOException, InterruptedException {
        def exitCode = -1
        def prErrCode
        for (Path artifact : artifacts) {
            System.out.println("UPLOADING TO NEXUS: " + artifact.toString());
            prErrCode = uploadFile("curl", "-v", "-u", this.getCredentials(),
                    "--upload-file", artifact.toString(),
                    this.getServerHost() + "/nexus/repository/" + repository + "/" + artifactEndpoint + "/"
                            + artifact.getFileName());
            if(prErrCode != 0) {
                println "Error occurred uploading to Nexus repo. File name : " + artifact.getFileName();
                exitCode = -1
            } else
                exitCode = prErrCode
        }
        return exitCode
    }

    private int uploadFile(String... args) throws IOException, InterruptedException {
        ProcessBuilder pb = new ProcessBuilder(args);
        pb.command();
        pb.redirectErrorStream(true);
        Process pr = pb.start();
        BufferedReader input = new BufferedReader(new InputStreamReader(pr.getInputStream()));
        String line;
        while ((line = input.readLine()) != null) {
            System.out.println(line);
        }
        pr.waitFor();
        input.close();
        pr.exitValue()
    }
}