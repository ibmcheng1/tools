package com.urbancode.air.plugin.nexus.common

import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder
import org.apache.http.client.methods.HttpGet
import org.apache.http.client.methods.HttpPut
import org.apache.http.entity.StringEntity

class SnapshotUtil {
    def executePut(String serverUrl,String user,String pass) {
        def exitCode = -1;
        def clientBuilder = new HttpClientBuilder()
        clientBuilder.setPassword(pass)
        clientBuilder.setPreemptiveAuthentication(false)
        clientBuilder.setUsername(user)
        def client = clientBuilder.buildClient();

        def method = new HttpPut(serverUrl)
        method.addHeader("Accept", "application/json")
        method.addHeader("Content-Type", "application/json")
        method.setEntity(new StringEntity(""))
        println "Request:" + serverUrl
        def resp = client.execute(method)

        if(null != resp) {
            println "Response:" + resp.getStatusLine().getStatusCode()
            println('\n' + resp.entity?.content?.getText("UTF-8"))
        }
        def statusCode = resp.getStatusLine().getStatusCode()
        if (statusCode < 200 || statusCode >= 300) {
            println "[Error] Failed with status ${statusCode}. Exiting Failure."
            println('Response:\n' + resp.entity?.content?.getText("UTF-8"))
            System.exit(1)
        } else {
            exitCode = 0
        }
        return exitCode
    }

    def executeGet(String serverUrl,String user,String pass) {
        def exitCode = -1;
        def clientBuilder = new HttpClientBuilder()
        clientBuilder.setPassword(pass)
        clientBuilder.setPreemptiveAuthentication(false)
        clientBuilder.setUsername(user)
        def client = clientBuilder.buildClient();

        def method = new HttpGet(serverUrl)
        method.addHeader("Accept", "application/json")
        method.addHeader("Content-Type", "application/json")
        println "Request:" + serverUrl
        def resp = client.execute(method)
        if(null != resp) {
            println "Response:" + resp.getStatusLine().getStatusCode()
            println('\n' + resp.entity?.content?.getText("UTF-8"))
        }
        def statusCode = resp.getStatusLine().getStatusCode()
        if (statusCode < 200 || statusCode >= 300) {
            println "[Error] Failed with status ${statusCode}. Exiting Failure."
            println('Response:\n' + resp.entity?.content?.getText("UTF-8"))
            System.exit(exitCode)
        } else {
            exitCode = 0
        }
        return exitCode
    }

    def executeGetFile(String serverUrl,String user,String pass,String dirPath,String fileName) {
        def exitCode = -1;
        def clientBuilder = new HttpClientBuilder()
        clientBuilder.setPassword(pass)
        clientBuilder.setPreemptiveAuthentication(false)
        clientBuilder.setUsername(user)
        def client = clientBuilder.buildClient();

        def method = new HttpGet(serverUrl)
        method.addHeader("Accept", "application/json")
        method.addHeader("Content-Type", "application/octet-stream")
        println "Request:" + serverUrl
        def resp = client.execute(method)
        if(null != resp) {
            println "Response:" + resp.getStatusLine().getStatusCode()
        }
        /*
        resp.getAllHeaders().eachWithIndex{ Header entry, int i ->
            println entry.getName() + "=" + entry.getValue()
        }*/
        byte[] buffer = new byte[4096];
        if(null != resp.getEntity().getContent()) {
            File f = new File(dirPath + File.separator +fileName)
            BufferedInputStream bis = new BufferedInputStream(resp.getEntity().getContent())
            BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(f))
            int bytesRead = -1;
            while ((bytesRead = bis.read(buffer)) != -1) {
                bos.write(buffer, 0, bytesRead);
            }

            println "File downloaded at " + f.absolutePath
            if(!f.exists()) {
                println "Unable to find the downloaded file at " + f.absolutePath
                System.exit(exitCode)
            }
            bos.flush()
            bis.close()
            bos.close()
            f = null
        }
        def statusCode = resp.getStatusLine().getStatusCode()
        if (statusCode < 200 || statusCode >= 300) {
            println "[Error] Failed with status ${statusCode}. Exiting Failure."
            println('Response:\n' + resp.entity?.content?.getText("UTF-8"))
            System.exit(exitCode)
        } else {
            exitCode = 0
        }
        return exitCode
    }

    String getResponse(String url,String user,String pass) {
        def clientBuilder = new HttpClientBuilder()
        clientBuilder.setPassword(pass)
        clientBuilder.setPreemptiveAuthentication(false)
        clientBuilder.setUsername(user)
        def client = clientBuilder.buildClient();
        println url
        def method = new HttpGet(url)
        method.addHeader("Accept", "application/json")
        method.addHeader("Content-Type", "application/json")

        def resp = client.execute(method)
        def respText = resp.entity?.content?.getText("UTF-8")
        if(null != resp) {
            println "Response:" + resp.getStatusLine().getStatusCode()
            println('\n' + respText)
        }
        return respText
    }


}
