package com.urbancode.air.plugin.nexus

import com.urbancode.air.plugin.nexus.iqserver.Scanner
import com.urbancode.air.plugin.nexus.repo.SnapshotHandler

class UCDNexusHelper {
    def airPluginTool
    def props = []
    Scanner scanner
    SnapshotHandler handler

    UCDNexusHelper(def airPluginToolIn) {
        airPluginTool = airPluginToolIn
        props = airPluginTool.getStepProperties()
        scanner = new Scanner()
        handler = new SnapshotHandler();
    }

    UCDNexusHelper() {
        scanner = new Scanner()
        handler = new SnapshotHandler();
    }

    int scan(String agentLibPath,String javaCmdPath, String iqServer, String iqUser, String iqPass, String assetId, String appId,String snapshotId,String snapshotName,String ucdServer,String ucdUser,String ucdPass,String tmpDirPath) {
        def scanStatus = -1
        def scanPassed = handler.checkSnapshotScanStatus(ucdServer,snapshotId,ucdUser,ucdPass)
        if(scanPassed) {
            println "NEXUS_SCAN_PASSED status is already applied to the Snapshot. Scan is skipped."
            return 0;
        } else {
            String componentDir = handler.downloadComponents(assetId, snapshotId, snapshotName, ucdServer, ucdUser, ucdPass, tmpDirPath);
            scanStatus = scanner.scan(agentLibPath,javaCmdPath,iqServer,iqUser,iqPass,assetId,componentDir);
        }
        return scanStatus;
    }

    int scanAndLock(String agentLibPath,String javaCmdPath, String iqServer, String iqUser, String iqPass, String assetId, String appId,String snapshotId,String snapshotName,String ucdServer,String ucdUser,String ucdPass,String tmpDirPath) {
        def scanStatus = -1
        def scanPassed = handler.checkSnapshotScanStatus(ucdServer,snapshotId,ucdUser,ucdPass)
        if(scanPassed) {
            println "NEXUS_SCAN_PASSED status is already added to the Snapshot. Scan is skipped."
            return 0;
        } else {
            ArrayList versions = handler.getSnapshotComponentVersions(snapshotId,ucdServer,ucdUser,ucdPass)
            //String componentDir = handler.downloadComponents(assetId, snapshotId, snapshotName, ucdServer, ucdUser, ucdPass, tmpDirPath);
            String componentDir = handler.downloadComponents(assetId, versions, snapshotId, ucdServer, ucdUser, ucdPass, tmpDirPath);
            scanStatus = scanner.scan(agentLibPath,javaCmdPath,iqServer,iqUser,iqPass,assetId,componentDir);
            if(scanStatus == 0) {
                //println "Locking the snapshot configuration"
                //lockSnapshotConfig(snapshotId,ucdServer,ucdUser,ucdPass)
                println "Adding component status NEXUS_SCAN_PASSED and report link"
                println "Scan report => " + scanner.scanReport
                addSnapshotComponentStatus(scanner.scanReport, versions,"NEXUS_SCAN_PASSED",ucdServer,ucdUser,ucdPass)
                println "Locking the snapshot versions"
                lockSnapshotVersions(snapshotId,ucdServer,ucdUser,ucdPass)
                println "Adding snapshot status NEXUS_SCAN_PASSED"
                addSnapshotStatus(snapshotId,"NEXUS_SCAN_PASSED",ucdServer,ucdUser,ucdPass)
            } else {
                println "Locking the snapshot versions"
                lockSnapshotVersions(snapshotId,ucdServer,ucdUser,ucdPass)
                println "Adding snapshot status NEXUS_SCAN_FAILED"
                addSnapshotStatus(snapshotId,"NEXUS_SCAN_FAILED",ucdServer,ucdUser,ucdPass)
            }
        }
        return scanStatus
    }

    int pushToNexus(String assetId,String appId,String snapshotId,String snapshotName, String ucdServer,String ucdUser,String ucdPass, String repoServer,String repoUser, String repoPass, String tmpDirPath) {
        //println "Before calling Push to Nexus"
        def exitCode = -1
        // Check if the snapshot is deployed to production or OOR
        def status = handler.checkSnapshotStatus(ucdServer,snapshotId,"DEPLOYED_TO_PROD",ucdUser,ucdPass)
        if(!status)
            status = handler.checkSnapshotStatus(ucdServer,snapshotId,"DEPLOYED_TO_OOR",ucdUser,ucdPass)
        if(status) {
            String componentDir = handler.downloadComponents(assetId, snapshotId, snapshotName, ucdServer, ucdUser, ucdPass, tmpDirPath);
            println componentDir
            if(null == componentDir) {
                println "Unable to create component directory " + tmpDirPath
                return exitCode
            }
            exitCode = handler.publishComponents(repoServer,repoUser+":"+repoPass,assetId,snapshotName)
        } else {
            println "Snapshot is not deployed to PROD or OOR. Upload to nexus repo failed."
        }
        //println "After calling Push to Nexus"
        return exitCode;
    }

    int lockSnapshotConfig(String snapshotId,String ucdServer,String ucdUser,String ucdPass) {
        //println "Before calling Lock Snapshot Config"
        int exitCode = handler.lockSnapshotConfig(snapshotId, ucdServer, ucdUser, ucdPass);
        println exitCode
        //println "After calling Lock Snapshot Config"
        return exitCode;
    }

    int lockSnapshotVersions(String snapshotId,String ucdServer,String ucdUser,String ucdPass) {
        //println "Before calling Lock Snapshot Version"
        int exitCode = handler.lockSnapshotVersion(snapshotId, ucdServer, ucdUser, ucdPass);
        println exitCode
        //println "After calling Lock Snapshot Version"
        return exitCode;
    }

    int addSnapshotStatus(String snapshotId,String status, String ucdServer,String ucdUser,String ucdPass) {
        //println "Before calling Add Snapshot Status"
        int exitCode = handler.addSnapshotStatus(snapshotId, status, ucdServer, ucdUser, ucdPass);
        println exitCode
        //println "After calling Add Snapshot Status"
        return exitCode;
    }

    int addSnapshotComponentStatus(String scanReport, ArrayList versions,String status, String ucdServer,String ucdUser,String ucdPass) {
        //println "Before calling Add Component Status"
        int exitCode = handler.addSnapshotComponentStatusLink(scanReport,versions, status, ucdServer, ucdUser, ucdPass);
        println exitCode
        //println "After calling Add Component Status"
        return exitCode;
    }

//    def int getComponentProperty(String componentId,String propName, String ucdServer,String ucdUser,String ucdPass) {
//        //println "Before calling Get Component Property"
//        int exitCode = handler.getComponentProperty(componentId, propName, ucdServer, ucdUser, ucdPass);
//        println exitCode
//        //println "After calling Get Component Property"
//        return exitCode;
//    }
}
