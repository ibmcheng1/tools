package com.urbancode.air.plugin.nexus.common

class Runner {
    public static void main(String[] args) {
        String disposition = "attachment; filename=\"Test_artifacts.zip\"; filename*=UTF-8''Test_artifacts.zip"
        String filename = null;
        if(disposition != null) {
            def matches = disposition =~ /\bfilename="(.*?)";/
            matches.each {
                filename = it[1]
            }
        }
        println filename
    }
}
