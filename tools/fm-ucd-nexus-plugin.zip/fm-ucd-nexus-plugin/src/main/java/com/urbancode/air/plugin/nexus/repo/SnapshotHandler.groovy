package com.urbancode.air.plugin.nexus.repo

import com.urbancode.air.plugin.nexus.common.SnapshotUtil
import groovy.json.JsonSlurper

import java.nio.file.Files
import java.nio.file.Path
import java.util.stream.Collectors
import java.util.zip.ZipException

public class SnapshotHandler {

    File snapshotTempDir = null;
    SnapshotUtil snapshotUtil;
    //def componentDir = null;

    public SnapshotHandler() {
        snapshotUtil = new SnapshotUtil();
    }

    def int publishComponents(String repoServer, String repoAuth, String assetId, String snapshotName) {
        def exitCode = -1
        try {
            RepoLoader loader = new RepoLoader(repoServer, repoAuth);
            exitCode = loader.start(snapshotTempDir.toString(), "prod-releases",
                    "com/fanniemae/" + assetId, snapshotName);
            //println "After uploading artifacts"
        }catch (Exception e) {
            println "Error uploading to Nexus Repo : " + e.message
            e.printStackTrace();
        }
        return exitCode
    }

    /*
    Downloads snapshot as a whole
    def String downloadComponents(String assetId, String applicationId, String snapshotId, String snapshotName,
                           String ucdServer, String ucdAuth, String tmpdirPath) throws IOException {
        println assetId
        println snapshotId
        println snapshotName
        try {
            println "Creating the tmp dir"
            // Setting up temp directory for snapshot to unpack & repack
            snapshotTempDir = setupTempFolders(tmpdirPath, assetId, snapshotId);
            println snapshotTempDir.absolutePath
            println "After creating the tmp dir"
            // Constructing the necessary export URL to grab the snapshot
            String exportURL = buildExportURL(ucdServer, applicationId, snapshotId);
            println exportURL
            // Downloading the snapshot via the export URL to the temp directory
            Path snapshot = Downloader.downloadSSL(exportURL, ucdAuth, snapshotTempDir.toString());
            // Unpacking the snapshot ZIP by its components, and repacking them into individual ZIP's
            println snapshot.toFile().absolutePath
            componentDir = Zipper.decompose(snapshot, snapshotTempDir.toString());
            println componentDir.toFile().absolutePath
            // Creating/running the RepoLoader to upload the component ZIP's & config JSON to Nexus
            return componentDir.toFile().absolutePath;
        } catch (IOException e) {
            println e.message
            e.printStackTrace();
        } catch (ZipException e) {
            println e.message
            println e.printStackTrace();
        }
        return null
    }
    */

    def getSnapshotComponentVersions(String snapshotId, String ucdServer, String user, String pass) {
        // Get the snapshot versions
        ArrayList versions = null;
        try{
            def restURL = buildListSnapshotVersionsURL(ucdServer,snapshotId)
            // Get the versions list and download each version
            def respText = snapshotUtil.getResponse(restURL,user,pass)
            def jsonSlurper = new JsonSlurper()
            def jsonObject = jsonSlurper.parseText(respText)
            versions = jsonObject.desiredVersions;
        } catch (IOException e) {
            println e.message
            e.printStackTrace();
        }
        return versions;
    }

    def String downloadComponents(String assetId, String snapshotId, String snapshotName,
                                  String ucdServer, String user, String pass, String tmpdirPath) throws IOException {
        def exitcode = -1
        def restURL
        def respText
        def jsonSlurper
        def jsonObject
        try {
            //println "Creating the tmp dir"
            // Setting up temp directory for snapshot to unpack & repack
            snapshotTempDir = setupTempFolders(tmpdirPath, assetId, snapshotId);
            println snapshotTempDir.absolutePath
            //println "After creating the tmp dir"
            ArrayList versions = getSnapshotComponentVersions(snapshotId,ucdServer,user,pass)
            if(versions != null) {
                for(int i=0;i<versions.size();i++) {
                    ArrayList version = versions.get(i)
                    if(!version.isEmpty()) {
                        println version.get(0).getAt("name") + ":" + version.get(0).getAt("id")
                        def url = buildSnapshotComponentVersionsURL(ucdServer,version.get(0).getAt("id"))
                        exitcode = snapshotUtil.executeGetFile(url,user,pass,snapshotTempDir.absolutePath,version.get(0).getAt("name") + ".zip")
                        if(exitcode == -1) {
                            println "Error downloading the component version"
                            System.exit(exitcode)
                        }
                    }
                }
            } else {
                println "No component version found. Exiting."
                System.exit(exitcode)
            }
            println snapshotTempDir.absolutePath
            // Creating/running the RepoLoader to upload the component ZIP's & config JSON to Nexus
            return snapshotTempDir.absolutePath;
        } catch (IOException e) {
            println e.message
            e.printStackTrace();
        } catch (ZipException e) {
            println e.message
            println e.printStackTrace();
        }
        return null
    }

    def String downloadComponents(String assetId, ArrayList versions,String snapshotId,
                                  String ucdServer, String user, String pass, String tmpdirPath) throws IOException {
        //println assetId
        def exitcode = -1
        def restURL
        def respText
        def jsonSlurper
        def jsonObject
        try {
            //println "Creating the tmp dir"
            // Setting up temp directory for snapshot to unpack & repack
            snapshotTempDir = setupTempFolders(tmpdirPath, assetId, snapshotId);
            println snapshotTempDir.absolutePath
            //println "After creating the tmp dir"
            if(versions != null) {
                for(int i=0;i<versions.size();i++) {
                    ArrayList version = versions.get(i)
                    if(!version.isEmpty()) {
                        println version.get(0).getAt("name") + ":" + version.get(0).getAt("id")
                        def url = buildSnapshotComponentVersionsURL(ucdServer,version.get(0).getAt("id"))
                        exitcode = snapshotUtil.executeGetFile(url,user,pass,snapshotTempDir.absolutePath,version.get(0).getAt("name") + ".zip")
                        if(exitcode == -1) {
                            println "Error downloading the component version"
                            System.exit(exitcode)
                        }
                    }
                }
            } else {
                println "No component version found. Exiting."
                System.exit(exitcode)
            }
            println snapshotTempDir.absolutePath
            // Creating/running the RepoLoader to upload the component ZIP's & config JSON to Nexus
            return snapshotTempDir.absolutePath;
        } catch (IOException e) {
            println e.message
            e.printStackTrace();
        } catch (ZipException e) {
            println e.message
            println e.printStackTrace();
        }
        return null
    }


    def checkSnapshotScanStatus(String ucdServer, String snapshotId, String user, String pass) {
        def restURL
        def respText
        def jsonSlurper
        def jsonObject
        def status
        def found = false
        // Get the snapshot status
        restURL = buildListSnapshotStatusURL(ucdServer,snapshotId)
        respText = snapshotUtil.getResponse(restURL,user,pass)
        jsonSlurper = new JsonSlurper()
        jsonObject = jsonSlurper.parseText(respText)
        jsonObject.eachWithIndex{ Map entry, int i ->
            status = entry.find { it.value == "NEXUS_SCAN_PASSED" }?.value
            if(status == "NEXUS_SCAN_PASSED")
                found = true;
        }
        return found
    }

    def checkSnapshotStatus(String ucdServer, String snapshotId, String checkStatus, String user, String pass) {
        def restURL
        def respText
        def jsonSlurper
        def jsonObject
        def found = false
        def status
        // Get the snapshot status
        restURL = buildListSnapshotStatusURL(ucdServer,snapshotId)
        respText = snapshotUtil.getResponse(restURL,user,pass)
        jsonSlurper = new JsonSlurper()
        jsonObject = jsonSlurper.parseText(respText)
        jsonObject.eachWithIndex{ Map entry, int i ->
            status = entry.find { it.value == checkStatus }?.value
            if(status == checkStatus)
                found = true;
        }
        return found
    }

    def buildExportURL(String ucdServer, String applicationId,
                                 String snapshotId){
        //println "Building the export URL"
        // Assembling the final export URL
        return (ucdServer + "/rest/deploy/application/" + applicationId + "/exportWithArtifacts?snapshotIds=" + snapshotId)
    }

    def buildLockConfigURL(String ucdServer, String snapshotId) {
        //println "Building the snapshot lock config URL"
        // Assembling the final export URL
        return (ucdServer + "/cli/snapshot/lockSnapshotConfiguration?snapshot=" + snapshotId)
    }

    def buildLockVersionURL(String ucdServer, String snapshotId) {
        //println "Building the snapshot lock version URL"
        // Assembling the final export URL
        return (ucdServer + "/cli/snapshot/lockSnapshotVersions?snapshot=" + snapshotId)
    }

    def buildAddSnapshotStatusURL(String ucdServer, String snapshotId, String status) {
        //println "Building the add snapshot status URL"
        // Assembling the final export URL
        return (ucdServer + "/cli/snapshot/addStatusToSnapshot?snapshot=" + snapshotId + "&statusName="+ status)
    }

    def buildAddComponentStatusURL(String ucdServer, String versionId, String status) {
        //println "Building the add component status URL"
        // Assembling the final export URL
        return (ucdServer + "/cli/version/addStatus?version=" + versionId + "&status="+ status)
    }

    def buildAddComponentLinkURL(String linkName,String link, String ucdServer, String versionId) {
        //println "Building the add component link URL"
        // Assembling the final export URL
        return (ucdServer + "/cli/version/addLink?version=" + versionId + "&linkName=" + linkName + "&link=" + link)
    }

    def buildSnapshotInfoURL(String ucdServer,String snapshotId) {
        //println "Building the get snapshot details URL"
        // Assembling the final export URL
        return (ucdServer + "/cli/snapshot/getSnapshot?snapshot=" + snapshotId)
    }

    def buildListSnapshotVersionsURL(String ucdServer,String snapshotId) {
        //println "Building the list snapshot versions URL"
        // Assembling the final export URL
        //println ucdServer + "/cli/snapshot/getSnapshotVersions?snapshot=" + snapshotId
        return (ucdServer + "/cli/snapshot/getSnapshotVersions?snapshot=" + snapshotId)
    }

    def buildListSnapshotStatusURL(String ucdServer,String snapshotId) {
        //println "Building the list snapshot status URL"
        // Assembling the final export URL
        //println ucdServer + "/cli/snapshot/getStatusList?snapshot=" + snapshotId
        return (ucdServer + "/cli/snapshot/getStatusList?snapshot=" + snapshotId)
    }

    def buildSnapshotComponentVersionsURL(String ucdServer,String versionId) {
        //println "Building the list snapshot component version URL"
        // Assembling the final export URL
        //println ucdServer + "/cli/version/downloadArtifacts?version=" + versionId
        return (ucdServer + "/cli/version/downloadArtifacts?version=" + versionId)
    }

    def setupTempFolders(String tmpDirPath, String assetId, String snapshotId){
        //println "Creating the asset dir"
        File tempDir = new File(tmpDirPath + File.separator + assetId);
        // Creating the overall temp directory if it doesn't exist
        if(!tempDir.exists()){
            tempDir.mkdirs();
        }
        // Creating the individual snapshot's temp directory
        //println "Creating the snapshot dir"
        File snapshotTempDir = new File(tempDir.absolutePath + File.separator + snapshotId);
        if(snapshotTempDir.exists()) {
            final List<Path> pathsToDelete = Files.walk(snapshotTempDir.toPath())
                    .sorted(Comparator.reverseOrder()).collect(Collectors.toList());
            for(Path path : pathsToDelete) {
                Files.deleteIfExists(path);
            }
        }
        snapshotTempDir.mkdirs();
        return snapshotTempDir;
    }

    def lockSnapshotVersion(String snapshotId, String ucdServer, String ucdUser, String ucdPass) {
        println "Locking the snapshot versions"
        return snapshotUtil.executePut(buildLockVersionURL(ucdServer,snapshotId),ucdUser,ucdPass);
    }

    def lockSnapshotConfig(String snapshotId, String ucdServer, String ucdUser, String ucdPass) {
        println "Locking the snapshot config"
        return snapshotUtil.executePut(buildLockVersionURL(ucdServer,snapshotId),ucdUser,ucdPass);
    }

    def addSnapshotStatus(String snapshotId, String status, String ucdServer, String ucdUser, String ucdPass) {
        println "Add snapshot status"
        return snapshotUtil.executePut(buildAddSnapshotStatusURL(ucdServer,snapshotId,status),ucdUser,ucdPass);
    }

    def addSnapshotComponentStatusLink(String scanReport,ArrayList versions, String status, String ucdServer, String ucdUser, String ucdPass) {
        println "Add component status and links"
        int exitcode = -1
        if(versions != null) {
            for(int i=0;i<versions.size();i++) {
                ArrayList version = versions.get(i)
                if(!version.isEmpty()) {
                    println version.get(0).getAt("name") + ":" + version.get(0).getAt("id")
                    def url = buildAddComponentStatusURL(ucdServer,version.get(0).getAt("id"),status)
                    exitcode = snapshotUtil.executePut(url,ucdUser,ucdPass)
                    if(exitcode == -1) {
                        println "Error adding status to the component version"
                        System.exit(exitcode)
                    }
                    if(null != scanReport && scanReport.startsWith("http")) {
                        def linkUrl = buildAddComponentLinkURL("nexusScanReport",scanReport,ucdServer,version.get(0).getAt("id"))
                        exitcode = snapshotUtil.executePut(linkUrl,ucdUser,ucdPass)
                        if(exitcode == -1) {
                            println "Error adding nexusScanReport link to the component version"
                            System.exit(exitcode)
                        }
                    }
                }
            }
        } else {
            println "No component version found in the snapshot"
            System.exit(exitcode)
        }
        return exitcode;
    }

}