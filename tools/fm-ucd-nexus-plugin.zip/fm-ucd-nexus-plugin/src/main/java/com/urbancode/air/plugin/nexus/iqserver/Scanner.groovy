package com.urbancode.air.plugin.nexus.iqserver

class Scanner {
    String scanReport

    int scan( String agentLibPath,String javaCmdPath, String iqServer, String iqUser, String iqPass, String assetId, String targetDir) {
        String msg = "Scanning Artifact [ Asset ID: " + assetId + " ; Target Dir: " + targetDir + " ]";
        println msg
        //msg = "Input properties [ Java Cmd Path : " + javaCmdPath + " ; Agent Lib Path: " + agentLibPath + " ]";
        //System.out.println(msg);
        try {
            Process p = Runtime.getRuntime().exec(javaCmdPath + "/java -jar " + agentLibPath + "/nexus-iq-cli-1.53.0-01.jar -s " + iqServer + " -a "
                    + iqUser + ":" + iqPass + " -t operate -i " + assetId + " " + targetDir);
            println p.properties.toString();
            BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));
            BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));
            while ((msg = stdInput.readLine()) != null) {
                println msg
                // assets/index.html#/reports/MSR01617/198fa05793754207b20e8dbb372c8bec
                if(msg.contains("The detailed report can be viewed online at")) {
                    def m = msg =~ /((The detailed report can be viewed online at )(.*))/;
                    if(m.find()) {
                        scanReport = m[0][3]
                    }
                }
                //System.out.println(msg);
            }
            while ((msg = stdError.readLine()) != null) {
                println msg
                //System.err.println(msg);
            }
            p.waitFor();
            // If report is available, add the report to the component version

            return p.exitValue();
        } catch (IOException e) {
            Writer writer = new StringWriter();
            e.printStackTrace(new PrintWriter(writer));
            System.out.println(writer.toString());
            return -1;
        }
        catch ( InterruptedException e){
            Writer writer = new StringWriter();
            e.printStackTrace(new PrintWriter(writer));
            System.out.println(writer.toString());
            Thread.currentThread().interrupt();
            return -1;
        }
    }

}
