package com.urbancode.air.plugin.nexus.repo

import groovy.io.FileType

import java.nio.file.Path

public class Zipper {

    private static ArrayList<Path> getFiles(String filepath, int depth) throws IOException {
        def list = new ArrayList();
        def dir = new File(filepath)
        dir.eachFileRecurse (FileType.FILES) { file ->
            list << file.toPath()
        }
        return list;

    }

    private static ArrayList<Path> getFolders(String filepath, int depth) throws IOException {
        def list = new ArrayList();
        def dir = new File(filepath)
        dir.eachFileRecurse (FileType.DIRECTORIES) { file ->
            list << file.toPath()
        }
        return list;
    }
}