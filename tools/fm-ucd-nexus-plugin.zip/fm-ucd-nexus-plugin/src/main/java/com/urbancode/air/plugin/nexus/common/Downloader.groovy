package com.urbancode.air.plugin.nexus.common

import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption

public class Downloader {

    def static Path download(String sourceURL, String targetDirectory) throws IOException {
        println sourceURL
        URL url = new URL(sourceURL);
        String fileName = sourceURL.substring(sourceURL.lastIndexOf('/') + 1, sourceURL.length());
        Path targetPath = new File(targetDirectory + File.separator + fileName).toPath();
        Files.copy(url.openStream(), targetPath, StandardCopyOption.REPLACE_EXISTING);

        return targetPath;
    }

    def static Path downloadSSL(String sourceURL, String auth, String targetDirectory) throws IOException {
        // Bypassing SSL cert checks by creating a custom trust manager
//        TrustManager[] trustAllCerts = null;
//        trustAllCerts = new TrustManager[1] {
//            new X509TrustManager() {
//                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
//                    return null;
//                }
//
//                public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
//                }
//
//                public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
//                }
//            }
//        };
        def nullTrustManager = [
                checkClientTrusted: { chain, authType ->  },
                checkServerTrusted: { chain, authType ->  },
                getAcceptedIssuers: { null }
        ]
//        def nullHostnameVerifier = [
//                verify: { hostname, session ->
//                    //true
//                    hostname.contains('fanniemae.com')
//                }
//        ]
        try {
            SSLContext sc = SSLContext.getInstance("SSL");
//            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            sc.init(null, [nullTrustManager as  javax.net.ssl.X509TrustManager] as  javax.net.ssl.X509TrustManager[], new java.security.SecureRandom())
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory())
//        javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(nullHostnameVerifier as javax.net.ssl.HostnameVerifier)
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            // Encoding auth for HTTP
            String encoding = Base64.getEncoder().encodeToString((auth).getBytes());
            println "Source URL: " + sourceURL
            URL url = new URL(sourceURL);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestProperty("Authorization", "Basic " + encoding);
            System.out.println("Request URL: " + con.getURL());
            con.connect();
            // Retrieving the Content-Disposition header from the response
            String disposition = con.getHeaderField("Content-Disposition");
            println disposition
            // Getting the filename out of the disposition attachment
            //String fileName = disposition.replaceFirst("(?i)^.*filename=\"?([^\"]+)\"?.*$", "$1");
            // attachment; filename="Test_artifacts.zip"; filename*=UTF-8''Test_artifacts.zip
            // \bfilename="(.*?)";
            //String fileName = "Runner"
            Path targetPath = new File(targetDirectory + File.separator + getFile(disposition)).toPath();
            // Copying files to the target path
            Files.copy(con.getInputStream(), targetPath, StandardCopyOption.REPLACE_EXISTING);
            return targetPath;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return null;
    }

    def static getFile(String disposition) {
        String filename = null;
        if(disposition != null) {
            def matches = disposition =~ /\bfilename="(.*?)";/
            if(matches == null)
                return null;
            matches.each {
                filename = it[1]
            }
        }
        println filename
        return filename
    }
}