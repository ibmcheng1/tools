import com.urbancode.air.AirPluginTool

import com.urbancode.air.plugin.nexus.UCDNexusHelper

final def airPluginTool = new AirPluginTool(args[0], args[1])
final def props = airPluginTool.getStepProperties()

def appId = props['applicationId']
def snapshotId = props['snapshotId']
def snapshotName = props['snapshotName']
def assetId = props['assetId']
def ucdServer = props['ucdServer']
def ucdUser = props['ucdUser']
def ucdPass = props['ucdPass']
def repoServer = props['repoServer']
def repoUser = props['repoUser']
def repoPass = props['repoPass']
def tmpDirPath = props['tmpDirPath']

if(snapshotName == null || snapshotId == null) {
    println "[Error] Invalid Snapshot Name and/or Snapshot ID."
    System.exit(1)
}

if(assetId == null || appId == null) {
    println "[Error] Invalid Asset ID and/or Application ID."
    System.exit(1)
}
UCDNexusHelper nexusHelper = new UCDNexusHelper()
//nexusHelper.scan()
println "Asset ID      => " + assetId
println "Snapshot ID   => " + snapshotId
println "Snapshot Name => " + snapshotName
//println "Before calling push to Nexus"
int exitCode = nexusHelper.pushToNexus(assetId,appId,snapshotId,snapshotName,ucdServer,ucdUser,ucdPass,repoServer,repoUser,repoPass,tmpDirPath)
//println "After returning from push to Nexus"
println "Process returned exit code : "+ exitCode
if(exitCode == 0)
    println "SUCCESS: Uploaded snapshot '" + snapshotName + "' to Nexus Repo under prod-releases."
else
    println "FAILED: Uploading snapshot '" + snapshotName + "' to Nexus Repo under prod-releases."
System.exit(exitCode)


//UCDNexusHelper helper = new UCDNexusHelper()
//helper.scan("server","user","pass","asset","targetdir");
//helper.scan("http://dlv-fff-a001:8070","admin","admin123","MSR01617","C:\\Users\\s9ussm\\IdeaProjects\\rl-jira-plan-view-integrator");
