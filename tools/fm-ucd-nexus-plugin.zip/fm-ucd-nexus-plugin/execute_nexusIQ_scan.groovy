import com.urbancode.air.AirPluginTool

import com.urbancode.air.plugin.nexus.UCDNexusHelper



final def airPluginTool = new AirPluginTool(args[0], args[1])
final def props = airPluginTool.getStepProperties()

def snapshotName = props['snapshotName']
def snapshotId = props['snapshotId']
def assetId = props['assetId']
def iqServerUrl = props['iqServer']
def username = props['username']
def password = props['password']
def javaCmdPath = props['javaCmdPath']
def agentLibPath = props['agentLibPath']
def ucdServer = props['ucdServer']
def ucdUser = props['ucdUser']
def ucdPass = props['ucdPass']
def tmpDirPath = props['tmpDirPath']
def appId = props['applicationId']

if(snapshotName == null || snapshotId == null) {
    println "[Error] Invalid Snapshot Name and/or Snapshot ID."
    System.exit(1)
}

if(assetId == null || appId == null) {
    println "[Error] Invalid Asset ID and/or Application ID."
    System.exit(1)
}

println "Asset ID      => " + assetId
println "Snapshot ID   => " + snapshotId
println "Snapshot Name => " + snapshotName

UCDNexusHelper nexusHelper = new UCDNexusHelper()
int exitCode = nexusHelper.scanAndLock(agentLibPath,javaCmdPath,iqServerUrl,username,password,assetId,appId,snapshotId,snapshotName,ucdServer,ucdUser,ucdPass,tmpDirPath);

println "Scan returned exit code : "+ exitCode
if(exitCode == 0)
    println "SUCCESS: Snapshot '" + snapshotName + "' scanned for vulnerabilities."
else
    println "FAILED: Snapshot '" + snapshotName + "' scanned for vulnerabilities."
System.exit(exitCode)
