package plugin;

import org.codehaus.groovy.runtime.StackTraceUtils

import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.RestServerConnectionBuilder

/**
 * This is the base class for classes which implement a UCR Integration Step as defined by
 * the plugin.xml.
 * @author LeonClark
 *
 */
class UCRPluginStep_Integration extends UCRPluginStep {

		
	
	@Override
	protected void performStep( String[] args, Closure theStep ) {
		// chains to the parent performStep
		
		// custom code may be placed here
		
		super.performStep(args) {
			int retval
			
			// custom code may be placed here
			 
			retval = theStep()
			
			// custom code may be placed here
			
			return retval
		}
	}
	
	@Override
	public Map getPluginXmlDefinedProperties() {
		return inProps
	}	
}
