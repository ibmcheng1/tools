package plugin

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.ucd.aws.provision.service.definition.AwsServiceDefinition
import com.fanniemae.ucd.aws.provision.service.instance.AwsServiceInstance
import com.fanniemae.ucd.aws.provision.spec.AwsSpecification
import com.fanniemae.ucd.aws.provision.ucd.UcdConfigurationDefinition
import com.fanniemae.ucd.aws.provision.ucd.UcdEnvironmentDefinition
import com.fanniemae.ucd.aws.provision.ucd.UcdResourceBranchDefinition
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.resource.ComponentResourceNode
import com.ibm.css.ucd.services.ApplicationServices
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel
import com.ibm.issr.core.plugin.AbortPluginException

import plugin.aws.UCPluginStepForAWSProvisioning

class ProvisionAWSSpecification extends UCPluginStepForAWSProvisioning  {
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new ProvisionAWSSpecification()
		stepImpl.performStep(args) { stepImpl.execute() }
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {
		
		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************

		// Display a summary of what this plugin is going to do
		Logger.info "${getPluginName()} [${getPluginVersion()}]: Provision AWS"
		String applicationName = retrieveAndDisplayInProp("applicationName")
		String requestedEnvType = retrieveAndDisplayInProp("requestedEnvType")
		boolean blueGreen = retrieveAndDisplayInProp("blueGreen").equalsIgnoreCase('true')
		boolean cleanupAwsResourcesOnFailure = retrieveAndDisplayInProp("cleanupAwsResourcesOnFailure").equalsIgnoreCase('true')
		String tokens = retrieveAndDisplayInProp("tokens")
		String requestedEnvName = retrieveAndDisplayInProp("requestedEnvName")
		String awsSpecification = retrieveInProp("awsSpecification")
		String existingAwsProductInstances = retrieveInProp("existingAwsProductInstances")
		String ucdComponentsDefFilename = retrieveInProp( "ucdComponentsDefFilename" )
		String awsRegion = retrieveInProp("awsRegion")
		String awsProductIds = retrieveInProp("awsProductIds")
		String awsProfileScript = retrieveInProp("awsProfileScript")
		String awsPassword = retrieveInProp("awsPassword")
		String awsRole = retrieveInProp("awsRole")
		String awsPool = retrieveAndDisplayInProp("awsPool")
		super.displayParameters()
		
		// Get handle to UCD Server
		UcdServerConnection ucdServer = openUcdServerConnection()
		
		ProvisionAWSSpecificationImpl impl = new ProvisionAWSSpecificationImpl( ucdServer,
			outProps, awsProductIds, awsProfileScript )
		
		// Load the component def file
		String ucComponentsDefJson = new File(ucdComponentsDefFilename).text

		impl.executeProvisioning(blueGreen, awsSpecification, awsPool, awsRegion, awsPassword, awsRole,
			requestedEnvName, requestedEnvType, applicationName, ucComponentsDefJson, cleanupAwsResourcesOnFailure, tokens, existingAwsProductInstances )
		
		Logger.info "Provisioning completed successfully"
	}

}
