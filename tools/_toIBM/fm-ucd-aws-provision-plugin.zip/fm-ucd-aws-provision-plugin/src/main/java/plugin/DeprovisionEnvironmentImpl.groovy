package plugin

import java.util.List

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.ucd.aws.api.services.servicecatalog.AwsServiceCatalog
import com.fanniemae.ucd.aws.api.services.servicecatalog.results.TerminateProvisionProductResult
import com.fanniemae.ucd.aws.api.services.servicecatalog.results.TerminateProvisionProductsResult
import com.fanniemae.ucd.aws.provision.ucd.UcdConfigurationDefinition
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.css.ucd.services.ApplicationServices
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.plugin.AbortPluginException

import groovy.json.JsonSlurper

/**
 * Implementation of the 'Provision AWS Specification' step.
 */
class DeprovisionEnvironmentImpl  {
	// plugin constructor inputs
	private UcdServerConnection ucdServer
	private UcdConnectionServices ucdConnectionServices
	private Properties outProps
	private String awsProfileScript
	
	private boolean simulateAwsCalls = false
	
	// internal data
	private UcdConfigurationDefinition ucdConfigurationDefinition
	
	private AwsConnection awsConnection
	private AwsServiceCatalog awsServiceCatalog
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to UCD Server.
	 * @param outProps Properties to set as plugin step output properties.
	 * @param awsProfileScript 
	 * @param simulateAwsCalls Should calls to AWS be simulated?  This is useful because it lets you test everything
	 * else in a debugging IDE (Eclipse or IntelliJ) session.
	 */
	public DeprovisionEnvironmentImpl( UcdServerConnection ucdServer, 
		Properties outProps, String awsProfileScript ) {
		this.ucdServer = ucdServer
		ucdConnectionServices = new UcdConnectionServices(ucdServer)
		this.outProps = outProps
		// add 'export HOME='+currentWorkingDirectory to the script
		this.awsProfileScript = awsProfileScript + "\nexport HOME=" + (new File('.')).getCanonicalPath()
	}
	
	/**
	 * Call this function to turn on the AWS Simulation mode and to set data needed for the simulation.
	 */
	public void enableAwsSimulation() {
		this.simulateAwsCalls = true
	}

	/**
	 * Given the input data, this function executes the step which performs the de-provisioning.
	 */
	public void executeDeprovisioning( String awsRegion, 
		String awsPassword, String awsRole, String environmentName, String applicationName ) {
		// List of environments getting shutdown
		List<Environment> environments = []
		
		// Verify and get the UCD application
		ApplicationServices applicationServices = ucdConnectionServices.getApplicationServices()
		if (! applicationServices.doesApplicationExist(applicationName)) {
			throw new AbortPluginException( "Unable to find application named '${applicationName}'" )
		}
		Application application = applicationServices.getApplication(applicationName)
		
		// Verify and access the environment
		if (! application.doesEnvironmentExist(environmentName)) {
			throw new AbortPluginException("The UCD Application '${applicationName}' doesn't contain an environment named '${environmentName}'")
		}
		Environment environment = application.getEnvironment(environmentName)
		environments << environment

		// Is this a paired (blue-green) environment?
		String linkedPropertyName = 'pairedBlueGreenEnvironment'
		if (environment.hasAdHocProperty( linkedPropertyName )) {
			String pairedEnvironmentName = environment.getAdHocProperty(linkedPropertyName)
			Logger.info "Also de-provisioning the paired blue-green environment named '${pairedEnvironmentName}'"
			if (! application.doesEnvironmentExist(pairedEnvironmentName)) {
				throw new AbortPluginException("The UCD Application '${applicationName}' doesn't contain an environment named '${pairedEnvironmentName}'")
			}
			Environment pairedEnvironment = application.getEnvironment(pairedEnvironmentName)
			environments << pairedEnvironment
		}
		
		// Delete the base resources, which may be shared by multiple environments
		// Get list (as a map) of base resources in the environments
		Map baseResources = [:]			// key = the base reource path, value=resource node
		environments.each { Environment env ->
			env.getBaseResources().each { ResourceNode baseResource ->
				baseResources[baseResource.getResourcePath()] = baseResource
			}
		}
		baseResources.each { String resourcePath, ResourceNode baseResource ->
			Logger.info "Deleting resource path '${resourcePath}'"
			baseResource.delete()
		}
		
		// Initiate AwsConnection, including starting AWS working session and authentication
		if (! simulateAwsCalls) {
			awsConnection = new AwsConnection(awsRegion, awsProfileScript)
			awsConnection.initiateAwsSession( awsPassword, awsRole )
			awsServiceCatalog = new AwsServiceCatalog( awsConnection )
		}


		// De-provision the AWS Resources
		/**
		 * In this map, the key is the Product Name.  The value is a Map with the following fields:
		 * <ul>
		 * <li>String recordId  - The AWS RecordId for the name.
		 * <li>boolean deleteFailed - It failed to delete the resource.</li>
		 * <li>boolean deleteCompleted - Succussfully deleted.</li>
		 * </ul>
		 */
		Map awsResources = [:]
		environments.each { Environment env ->
			if (environment.hasAdHocProperty( 'awsResources' )) {
				String awsResourcesJson = environment.getAdHocProperty('awsResources')
				List awsResourcesList = new JsonSlurper().parseText(awsResourcesJson)
				awsResourcesList.each { Map entry ->
					if (entry.provisioned) {
						awsResources[ entry.provisionedProductName ] = [ deleteFailed: false, deleteCompleted: false]
					}
				}
			}
		}
		// Get a List of the product names that need to be terminated
		List<String> provisionedProductNames = []
		awsResources.each { String awsProvisionedProductName, def mapValue ->
			println "Terminating AWS Product instance named: ${awsProvisionedProductName}"
			provisionedProductNames << awsProvisionedProductName
		}
		TerminateProvisionProductsResult terminationResults = awsServiceCatalog.terminateProvisionedProductsAndWait( provisionedProductNames )
		if (! terminationResults.successful) {
			// At least one Product Instance failed to terminate
			terminationResults.instanceResults.each { TerminateProvisionProductResult instanceResults ->
				if (! instanceResults.successful) {
					Logger.error instanceResults.errorMsg
				}
			}
			throw new AbortPluginException( "Unable to terminate the AWS Product Instance(s)" )
		}
			
		
		// Delete the environment(s)
		environments.each { Environment env ->
			env.delete()
		}
	}
}
