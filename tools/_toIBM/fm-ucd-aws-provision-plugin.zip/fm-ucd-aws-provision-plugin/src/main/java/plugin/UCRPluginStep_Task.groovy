package plugin;

import com.ibm.issr.core.log.Logger
import com.ibm.issr.rest.RestServerConnection
import com.ibm.services.ucr.api.entity.application.UcrApplication;
import com.ibm.services.ucr.api.entity.application.UcrApplicationMgr;
import com.ibm.services.ucr.api.entity.release.UcrRelease
import com.ibm.services.ucr.api.entity.scheduleddeployment.UcrScheduledDeployment
import com.ibm.services.ucr.api.entity.scheduleddeployment.UcrScheduledDeploymentMgr
import com.ibm.services.ucr.api.entity.taskexecution.UcrTaskExecution
import com.ibm.services.ucr.api.entity.taskexecution.UcrTaskExecutionMgr
import com.ibm.services.ucr.api.entity.user.UcrUser
import com.ibm.services.ucr.api.entity.user.UcrUserMgr

/**
 * Use this base class for plugin step classes which are Plugin Tasks - in other
 * words, they are tasks that can be specifically added to a Deployment Plan!!
 * @author LeonClark
 *
 */
class UCRPluginStep_Task extends UCRPluginStep {

		
	
	@Override
	protected void performStep( String[] args, Closure theStep ) {
		// chains to the parent performStep
		
		// custom code may be placed here
		
		// For UCR, logged messages are normally sent to println() and a log file.  However,
		// with a plugin step, the println is captured as execution Task comments, which isn't really
		// appropriate.  Instead, kill the println logging for plugin steps by overriding the 'outputLine'
		// closure to do nothing (instead of println()).
		Logger.outputLine = {}
		
		super.performStep(args) {
			int retval
			
			// custom code may be placed here
			 
			retval = theStep()
			
			// custom code may be placed here
			
			return retval
		}
	}
	
	@Override
	public Map getPluginXmlDefinedProperties() {
		getExtraProperties().task.properties
	}	
	
	/**
	 * Returns the hyperlink string to the deployment's execution.
	 */
	public String getDeploymentHyperlink() {
		return ucrServer.getServerRootUrl() + "/scheduledDeployment/" + getScheduledDeploymentId() + "#execution"
	}

	/**
	 * Returns the ID of the Ucr Scheduled Deployment for this plugin step task.
	 */
	public String getScheduledDeploymentId() {
		Map extraProperties = getExtraProperties()
		return extraProperties.task.scheduledDeploymentId
	}
	
	/**
	 * Returns the UcrScheduledDeployment for this Plugin Step Task execution.
	 */
	public UcrScheduledDeployment getScheduledDeployment() {
		return UcrScheduledDeploymentMgr.getInstance(ucrServer).getById(getScheduledDeploymentId())
	}
	
	/**
	 * Return the ID of the UcrTaskExecution for this plugin task step.
	 * @return
	 */
	public String getTaskExecutionId() {
		Map extraProperties = getExtraProperties()
		return extraProperties.task.id
	}
	
	/**
	 * Returns the UcrTaskExecution for this Plugin Step Task Execution.
	 */
	public UcrTaskExecution getTaskExecution() {
		return UcrTaskExecutionMgr.getInstance(ucrServer).getById(getTaskExecutionId())
	}
	
	/**
	 * Returns the UcrRelease for this Plugin Step Task Execution.
	 */
	public UcrRelease getRelease() {
		return getScheduledDeployment().getRelease()
	}
	
	/**
	 * Does the UCR Task have an associated UCR Application, as defined in the 'Application' field
	 * in the 'General' information for the task?
	 */
	public boolean hasApplication() {
		return getExtraProperties().task.containsKey('application')
	}
	
	/**
	 * Returns the UCR Application associated with this UCR Task, as defined in the 'Application' field
	 * in the 'General' information for the task?  If this Task has no associated Application, then
	 * an exception is thrown.  You can call {@link #hasApplication()} to test to see if there is a linked
	 * application.
	 */
	public UcrApplication getApplication() {
		UcrApplicationMgr.getInstance(ucrServer).getById(getExtraProperties().task.application.id)
	}
	
	
	/**
	 * Adds a comment to the executing task's comments.  Note that this actually appends a string
	 * to a shared task comment.
	 * @param comment The comment.  This supports HTML.  It is recommended to put the comment in a
	 * paragraph(s) tag.
	 */
	protected void addTaskComment( String comment ) {
		println (comment)
	}
	
	/**
	 * <p>Calls a UCD Application Process from this UCR Plugin Step!!</p>
	 * <p>Note that when UCR calls UCD App Processes via the standard process calls, UCR sends
	 * a set of fields to UCD, including a callback URL.  When UCD finishes an app process, it
	 * automatically uses the properties to notify UCR of the results (pass or fail).  BUT,
	 * that process does NOT work if the step is a Plugin Step (versus an automation step).  So,
	 * we need to write code in UCD to update UCR appropriately.</p>
	 * <p>The following properties are automatically sent to the UCD process to support the
	 * integration between UCD and UCR</p>
	 * <ul>
	 * <li>ucr.request.deployment.executor.email - The email of the user that started the release process.</li>
	 * <li>ucr.request.deployment.executor.actualName - The full display name of the user.</li>
	 * <li>ucr.request.deployment.executor.name - The short name of the user.</li>
	 * <li>ucr.request.taskId - The ID of the Execution Task in UCR</li>
	 * <li>ucr.request.scheduledDeploymentId - The ID of the Scheduled Deployment in UCR</li>
	 * <li>ucr.request.server - The server URL for UCR.</li>
	 * <li>ucr.request.link - Hyperlink to the UCR execution log.</li>
	 * </ul>
	 * @param ucdEnvironment The UCD Environment to call the process on.  The data type MUST be 'Environment' from
	 * the UCD Library, but the type is NOT declared in this function so that the other functions in
	 * the UCR Library can be used without including the UCD Library.
	 * @param processName The name of the Application Process to call.
	 * @param defineCall This is a closure which is used to define the process call.  See
	 * {@link Environment#callApplicationProcess(String, boolean, groovy.lang.Closure)} for details. Note
	 * that this function automatically adds the standard app process properties for communicating between
	 * UCR and UCD, so the closure can focus on the context specific information.
	 * @return This is the return from the function {@link Environment#callApplicationProcess(String, boolean, groovy.lang.Closure)}.
	 */
	protected List callUcdApplicationProcess( def ucdEnvironment, String processName, Closure defineCall ) {
		Map extraProperties = getExtraProperties()
		
		// Get the user that ran the Deployment
		UcrUser ucrUser = UcrUserMgr.getInstance(ucrServer).getById(extraProperties.userId)
		
//		// TODO - this is temporary test code
//		UcrTaskExecution taskExecution = UcrTaskExecutionMgr.getInstance(ucrServer).getById(extraProperties.task.id)
//		UcrTaskExecution taskExecution2 = UcrTaskExecutionMgr.getInstance(ucrServer).getById('295ddbcb-b97e-4496-9667-166b21b91353')
//		UcrSegmentExecution segmentExecution = UcrSegmentExecutionMgr.getInstance(ucrServer).getById('28c10cbd-36ce-40b0-b0b6-d5e8d53eb272')
		
		return ucdEnvironment.callApplicationProcess(processName, false) {
			// cascade the 'defineCall' calls using the same delegate as this closure
			defineCall.delegate = delegate
			defineCall()
			
			UcrRelease ucrRelease = this.getRelease()
			
			addProperty "ucr.request.deployment.executor.email", ucrUser.getEmail()
			addProperty "ucr.request.deployment.executor.actualName", ucrUser.getActualName()
			addProperty "ucr.request.deployment.executor.name", ucrUser.getName()
			addProperty "ucr.request.taskId", this.getTaskExecutionId()
			addProperty "ucr.request.scheduledDeploymentId", this.getScheduledDeploymentId()
			addProperty "ucr.request.releaseId", ucrRelease.getId()
			addProperty "ucr.request.releaseName", ucrRelease.getName()
			addProperty "ucr.request.server", ucrServer.serverRootUrl
			addProperty "ucr.request.link", this.getDeploymentHyperlink()
			
		}
	
	}
}
