package plugin.aws

import com.fanniemae.ucd.aws.provision.ucd.UcdConfigurationDefinition
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.issr.core.log.Logger

import plugin.UCPluginStepImplementation

/**
 * Implements deprovisioning.
 */
abstract class UCPluginStepForAWSProvisioning extends UCPluginStepImplementation {
	// optional UCD Authentication Token
	String ucdAuthToken = null
	
	@Override
	public void performStep( String[] args, Closure theStep ) {
		// chains to the parent performStep
		
		// custom code may be placed here
		
		super.performStep(args) {
			
			ucdAuthToken = retrieveInProp("ucdAuthToken")
						
			theStep()
			
		}
	}
	
	@Override
	protected void displayParameters() {
		if (ucdAuthToken) {
			Logger.info "   custom ucdAuthToken provided"
		}
		super.displayParameters()
	}

	
	/**
	 * Opens a Ucd Server Connection by creating an instance of UcdServerConnection and then perform
	 * an open() on it.  If a custom 'ucdAuthToken' is passed as a parameter, then that authentication
	 * information is used.  Otherwise, the current user's authentication information is used.
	 */
	protected UcdServerConnection openUcdServerConnection() {
		UcdServerConnection ucdServer = new UcdServerConnection()
		String username
		String password
		if (ucdAuthToken) {
			username = "PasswordIsAuthToken"
			password = "{\"token\" : \"" + ucdAuthToken + "\"}"
		} else {
			username = myRestServerTokenUsername
			password = myRestServerTokenPassword
		}
		ucdServer.openConnection(myRestServerUrl, myRestServerTokenUsername, myRestServerTokenPassword, myRestServerProxyHost, myRestServerProxyPort, myRestServerProxyUsername, myRestServerTokenPassword)
		return ucdServer
	}
}
