package plugin

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.ucd.aws.api.describeRecord.AwsDescribeRecordResult
import com.fanniemae.ucd.aws.api.services.servicecatalog.AwsServiceCatalog
import com.fanniemae.ucd.aws.api.services.servicecatalog.results.TerminateProvisionProductResult
import com.fanniemae.ucd.aws.api.services.servicecatalog.results.TerminateProvisionProductsResult
import com.fanniemae.ucd.aws.provision.context.BaseEnvironmentProvisionContext
import com.fanniemae.ucd.aws.provision.context.ProvisionContext
import com.fanniemae.ucd.aws.provision.context.data.AwsResourceInstanceContextData
import com.fanniemae.ucd.aws.provision.def.components.UcdComponentsDef
import com.fanniemae.ucd.aws.provision.def.components.data.UcdComponentDef
import com.fanniemae.ucd.aws.provision.def.productmap.AwsLogicalProductMap
import com.fanniemae.ucd.aws.provision.service.definition.AwsServiceDefinition
import com.fanniemae.ucd.aws.provision.service.instance.AwsServiceInstance
import com.fanniemae.ucd.aws.provision.spec.AwsSpecification
import com.fanniemae.ucd.aws.provision.ucd.UcdConfigurationDefinition
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.agent.AgentOrAgentPool
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.environmenttemplate.EnvironmentTemplate
import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.css.ucd.resource.ResourceTree
import com.ibm.css.ucd.services.ApplicationServices
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.css.ucd.team.Team
import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel
import com.ibm.issr.core.plugin.AbortPluginException

import groovy.json.JsonOutput
import groovy.json.JsonSlurper

/**
 * Implementation of the 'Provision AWS Specification' step.
 */
class ProvisionAWSSpecificationImpl  {
	// plugin constructor inputs
	private UcdServerConnection ucdServer
	private UcdConnectionServices ucdConnectionServices
	private String applicationName
	private Properties outProps
	private AwsLogicalProductMap awsLogicalProductMap
	private String awsProfileScript
	
	private String requestedEnvType
	
	private boolean simulateAwsCalls
	private Closure getSimulatedInstanceData
	
	// internal data
	private UcdConfigurationDefinition ucdConfigurationDefinition
	
	private AwsConnection awsConnection
	private AwsServiceCatalog awsServiceCatalog
	
	/**
	 * As AWS products are provisioned, their names MUST be added to this list.  If there
	 * is any failure, this list is used to automatically terminate the resource instances.
	 */
	private List<String> provisionedAwsProductNames = []
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to UCD Server.
	 * @param outProps Properties to set as plugin step output properties.
	 * @param awsProductIds JSON string that maps logical AWS Resource names (like 'RDS') to AWS Catalog product IDs.
	 * @param awsProfileScript 
	 * @param simulateAwsCalls Should calls to AWS be simulated?  This is useful because it lets you test everything
	 * else in a debugging IDE (Eclipse or IntelliJ) session.
	 */
	public ProvisionAWSSpecificationImpl( UcdServerConnection ucdServer, 
		Properties outProps, String awsProductIds, String awsProfileScript ) {
		this.ucdServer = ucdServer
		ucdConnectionServices = new UcdConnectionServices(ucdServer)
		this.outProps = outProps
		this.awsLogicalProductMap = new AwsLogicalProductMap( awsProductIds )
//		// add 'export HOME='+currentWorkingDirectory to the script
		this.awsProfileScript = awsProfileScript 
//			+ "\nexport HOME=" + (new File('.')).getCanonicalPath()
	}
	
	/**
	 * Call this function to turn on the AWS Simulation mode and to set data needed for the simulation.
	 * @param getSimulatedInstanceData This closure maps actual AWS Service Definitions to simulated
	 * AWS Service Instances.  The method signature is 'AwsServiceInstance getSimulatedInstanceData( 
	 * AwsServiceDefinition serviceDefinition )'.  It returns a simulated instance from a real definition.
	 * Note that the simulated instance should be prepopulated with the record-details.
	 */
	public void setSimulationData( Closure getSimulatedInstanceData ) {
		this.simulateAwsCalls = true
		this.getSimulatedInstanceData = getSimulatedInstanceData
	}

	/**
	 * Given the input data, this function executes the step which performs the provisioning.
	 * @param blueGreen Is blue-green deployment requested?  Actual blue-green deployment may be different.
	 * @param awsSpecification The specification JSON string.
	 * @param awsPool
	 * @param awsRegion The AWS Region
	 * @param awsPassword Password for aws
	 * @param requestedEnvName The name of the new UCD Environment to create.
	 * @param requestedEnvType The requested environment type, which must be one of the named
	 * UCD environment templates within the UCD Application Template.
	 * @param applicationName Name of the UCD Application.
	 * @param ucdComponentsDefJson The loaded 'ucdComponentDef.json' file as a string.
	 * @param tokensText Property file syntax with a list of tokens.
	 */
	public void executeProvisioning(boolean blueGreen, String awsSpecification, 
		String awsPool, String awsRegion, 
		String awsPassword, String awsRole, String requestedEnvName, String requestedEnvType, String applicationName,
		String ucdComponentsDefJson, boolean cleanupAwsResourcesOnFailure, String tokensText, String existingAwsProductInstancesText ) {
		this.requestedEnvType = requestedEnvType
		this.applicationName = applicationName
		
		Properties tokens = new Properties()
		tokens.load(new StringReader(tokensText))
		
		Properties existingAwsProductInstances = new Properties()
		existingAwsProductInstances.load(new StringReader(existingAwsProductInstancesText))
		
		// If deploying to production environment, use blue-green
		if (requestedEnvType=='PROD' || requestedEnvType=='CNTG') {
			blueGreen = true
		}

		// Load the manifest/specification
		AwsSpecification specification = new AwsSpecification( awsSpecification )
		
		// Load/process the 'ucdComponentsDef' data
		UcdComponentsDef ucdComponentsDef = new UcdComponentsDef(ucdComponentsDefJson)

		// Only allow blueGreen if at least one templatized UCD Component supports blue-gree
		if (blueGreen && (! ucdComponentsDef.doAnyComponentsSupportBlueGreen())) {
			blueGreen = false
		}
		
		Logger.info "Configuring for Blue-Green deployments? " + blueGreen
		
		BaseEnvironmentProvisionContext baseContext = new BaseEnvironmentProvisionContext(null, blueGreen)
		baseContext.setBaseEnvironmentName(requestedEnvName)
		baseContext.setTokensForAllContexts( tokens )
		
		// Verify and get the target UCD application
		ApplicationServices applicationServices = ucdConnectionServices.getApplicationServices()
		if (! applicationServices.doesApplicationExist(applicationName)) {
			Logger.error "Unable to find application named '${applicationName}'"
			throw new AbortPluginException()
		}
		baseContext.setApplication( applicationServices.getApplication(applicationName) )
		
		// abort the process if ANY of the input configurations are invalid
		verifyInputData( baseContext, specification, ucdComponentsDef )

		addAwsServiceDefinitionsToContexts( baseContext, specification )
		addDesiredEnvironmentsAndResourceBranchesToContexts( baseContext, requestedEnvName, 'pair1', 'pair2' )

		// The following check aborts the plugin if any of the target environments or resources already exist
		checkIfUCDEnvironmentAlreadyExists( baseContext )
		
		try {
			if (simulateAwsCalls) {
				// get the list of managed service instances
				List<AwsResourceInstanceContextData> serviceRequests = baseContext.getAllAwsResourceInstances()
				// simulate the service instances
				serviceRequests.each { AwsResourceInstanceContextData serviceRequest ->
					AwsServiceInstance requestedInstance = getSimulatedInstanceData( serviceRequest.getServiceDefinition() )
					serviceRequest.awsServiceInstance = requestedInstance
				}
			} else {
				// Initiate AwsConnection, including starting AWS working session and authentication
				awsConnection = new AwsConnection(awsRegion, awsProfileScript)
				awsConnection.initiateAwsSession( awsPassword, awsRole )
				awsServiceCatalog = new AwsServiceCatalog( awsConnection )
				
				// Provision the AWS Services
				provisionAwsServices( baseContext, existingAwsProductInstances )
			}
			
			// Create the target UCD Environments and Resource Tree Nodes
			createTargetUcdStructure( baseContext, requestedEnvType, awsPool, ucdComponentsDef )
		}
		catch (Exception e) {
			
			// Something failed - cleanup
			
			// terminate any provisioned AWS Product Instances if 'cleanupAwsResourcesOnFailure' is set
			if (awsServiceCatalog && cleanupAwsResourcesOnFailure) {
				TerminateProvisionProductsResult terminationResults = awsServiceCatalog.terminateProvisionedProductsAndWait( provisionedAwsProductNames )
				if (! terminationResults.successful) {
					Logger.error "Cleaning up unsuccessful provision attempt by terminating AWS Product Instances.  At least one instance failed to terminate..."
					// At least one Product Instance failed to terminate
					terminationResults.instanceResults.each { TerminateProvisionProductResult instanceResults ->
						if (! instanceResults.successful) {
							Logger.error "\t" + instanceResults.errorMsg
						}
					}
				}
			}
			
			throw e
		}

	}
	
	/**
	 * Verify the input configuration files.  If there are problems, list them and fail.
	 * @param baseContext The base context for provisioning.
	 * @param specification awsManifest.json
	 * @param ucdComponentsDef ucdComponentsDef.json
	 */
	void verifyInputData( BaseEnvironmentProvisionContext baseContext, AwsSpecification specification, UcdComponentsDef ucdComponentsDef ) {
		boolean validationFailed = false
		
		// Convert to AwsSpecification
		specification.performFullVerification()
	
		if (! specification.isValid()) {
			Logger.error "Validation of the AWS Specification/Manifest failed with the following errors..."
			specification.logValidationFailures(LoggerLevel.ERROR)
			validationFailed = true
		}
		
		// Make sure that all of the named components exist and are part of the application
		ucdComponentsDef.getAllComponentDefs().each { UcdComponentDef componentDef ->
			if (! ucdConnectionServices.getComponentServices().doesComponentExist(componentDef.componentName)) {
				ucdComponentsDef.tagValidationError("There is no component named '${componentDef.componentName}'")
			} else if (! baseContext.getApplication().hasComponent(componentDef.componentName)) {
				ucdComponentsDef.tagValidationError("The component '${componentDef.componentName}' is not part of the application '${baseContext.getApplication().getName()}'")
			}
		}
			
		if (! ucdComponentsDef.isValid()) {
			Logger.error "Validation of the UCD Components Def failed with the following errors..."
			ucdComponentsDef.logValidationFailures(LoggerLevel.ERROR)
			validationFailed = true
		}
		if (validationFailed) {
			throw new AbortPluginException("Validation failed")
		}
	}
	
	/**
	 * Adds all of the service definitions from 'specification' to the context applying blue-green as appropriate.
	 * @param baseContext
	 * @param specification
	 */
	public void addAwsServiceDefinitionsToContexts( BaseEnvironmentProvisionContext baseContext, AwsSpecification specification ) {
		specification.getServiceDefinitions().each { AwsServiceDefinition serviceDefinition ->
			if (serviceDefinition.shouldProvisionSeparateBlueGreenInstances() && baseContext.isProvisioningBlueGreen()) {
				// add to Blue and green contexts
				baseContext.getBlueChildContext().addAwsResourceInstance(serviceDefinition)
				baseContext.getGreenChildContext().addAwsResourceInstance(serviceDefinition)
			} else {
				// add to base context
				baseContext.addAwsResourceInstance(serviceDefinition)
			}
		}
	}
	
	/**
	 * Adds all the names of the environments and resource tree branches that are needed for provisioning to the
	 * context.
	 * @param baseContext The base context.
	 * @param requestedEnvName The requested environment name.
	 * @param blueSuffix The suffix to use for any blue environment/resources, such as 'BLUE' or 'pair1'.
	 * @param blueSuffix The suffix to use for any blue environment/resources, such as 'GREEN' or 'pair2'.
	 */
	public void addDesiredEnvironmentsAndResourceBranchesToContexts( BaseEnvironmentProvisionContext baseContext, String requestedEnvName,
		String blueSuffix, String greenSuffix ) {
		if (baseContext.isProvisioningBlueGreen()) {
			baseContext.getBlueChildContext().environmentName = requestedEnvName + '-' + blueSuffix
			baseContext.getGreenChildContext().environmentName = requestedEnvName + '-' + greenSuffix
			baseContext.resourceBranchName = requestedEnvName
			baseContext.getBlueChildContext().resourceBranchName = requestedEnvName + '-' + blueSuffix
			baseContext.getGreenChildContext().resourceBranchName = requestedEnvName + '-' + greenSuffix
		} else {
			baseContext.environmentName = requestedEnvName
			baseContext.resourceBranchName = requestedEnvName
		}
	}
	
	/**
	 * Check the existingAwsProductInstances properties to see if there is an existing AWS Product instance that should
	 * be used for the service definition.
	 * @param awsServiceDefinition The service that needs to be provisioned/linked next.
	 * @param baseContext The context.  In particular, this may be base, green or blue.
	 * @param existingAwsProductInstances The list of existing AWS Product instances to use.
	 * @return If existing instance should be used, returns the AWS instance ID.  Otherwise, returns false.
	 */
	private String lookupExistingAwsProductInstance( AwsServiceDefinition awsServiceDefinition, ProvisionContext context, Properties existingAwsProductInstances ) {
		String retval = ''
		String existingAwsProductName = ''
		String logicalName = awsServiceDefinition.getName()
		if (context.isBlueContext()) {
			logicalName = logicalName + '.blue'
		} else if (context.isGreenContext()) {
			logicalName = logicalName + '.green'
		}

		existingAwsProductInstances.each { String propertyName, String propertyValue ->
			if (propertyName.equalsIgnoreCase(logicalName)) {
				retval = propertyValue
			}
		}
		return retval
	}
	
	/**
	 * Provision the AWS Services.  If any of them fail, shut them all down.
	 * @param baseContext
	 * @param existingAwsProductInstances List of existing product names.  Format: logicalName[.blue/green]=awsProductName
	 */
	void provisionAwsServices( BaseEnvironmentProvisionContext baseContext, Properties existingAwsProductInstances ) {
		List<AwsServiceInstance> serviceInstances = []
		
		// start the services
		baseContext.eachContextInTree { ProvisionContext context ->
			context.getContextSpecificAwsResourceInstances().each { AwsResourceInstanceContextData serviceRequest ->
				AwsServiceInstance requestedInstance
				
				// Is there an existing product to use in 'existingAwsProductInstances'
				String existingAwsProductId = lookupExistingAwsProductInstance( serviceRequest.getServiceDefinition(), context, existingAwsProductInstances )
				 
				if (existingAwsProductId) {
					requestedInstance = serviceRequest.getServiceDefinition().provisionByLinkingToExistingAwsProductInstance( awsConnection, existingAwsProductId )
					// load the AWS output properties
					AwsDescribeRecordResult instanceDescription = requestedInstance.getAwsInstanceData()
					// Capture the AWS Product Instance name
					String awsInstanceName = instanceDescription.getProvisionedProductName()
					
				} else {
					requestedInstance = serviceRequest.getServiceDefinition().provisionInstance(context, awsConnection, awsLogicalProductMap, requestedEnvType )
					serviceInstances << requestedInstance
					// Add the provisioned product instance name to the list, which is used to terminate all instances on an error
					provisionedAwsProductNames << requestedInstance.getProvisionedName()
				}
				serviceRequest.awsServiceInstance = requestedInstance
			}
		}
		
		// wait for the services to complete
		List<String> failureMessages = waitUntilAllInstancesAreAvailable(serviceInstances, true)
		if (failureMessages.size() > 0) {
			String msg = ''
			String delim = ''
			failureMessages.each { String failureMsg ->
				msg = msg + delim + failureMsg
				delim = '\n'
			}
			throw new AbortPluginException(msg)
		}
	}

//	/**
//	 * Provisions AWS servers.
//	 * @param ucdConnectionServices
//	 * @param outProps
//	 * @param awsConnection Authenticated connection to an AWS region.
//	 * @param specification This is the manifest/specification (as an Object).  It must be verified before calling
//	 * this function.
//	 * @param awsProductIds JSON list which Maps service types to the product ID to use for the server.  Example:
//	 * <pre>
//	 *	[
//	 *		{"object":"RDS",
//	 *		"prodId":"prod-b2z72fyekkj3o"
//	 *		},
//	 *		{"object":"EB",
//	 *		"prodId":"prod-6ruu2gdnu6imc"
//	 *		}
//	 *	]
//	 * </pre>
//	 */
//	void provision( UcdConnectionServices ucdConnectionServices, Properties outProps, AwsConnection awsConnection,
//		AwsSpecification specification, String awsProductIds, UcdConfigurationDefinition ucdConfigurationDefinition ) {
//		
//		// List of ALL generated instances
//		List<AwsServiceInstance> serviceInstances = []
//
//		specification.getServiceDefinitions().each { AwsServiceDefinition serviceDefinition ->
//			// If provisioning BlueGreen and this is a Service Definition Type that supports blue green, then map to blue and green
//			if (ucdConfigurationDefinition.blueGreen && serviceDefinition.shouldProvisionSeparateBlueGreenInstances()) {
//				// provision separate blue and green instances
//				// blue
//				AwsServiceInstance blueServiceInstance = serviceDefinition.provisionInstance( awsConnection, awsProductIds )
//				serviceInstances << blueServiceInstance
//				ComponentResourceNode blueComponentResourceNode = ucdConfigurationDefinition.blueResourceBranchDefinition.addComponent(serviceDefinition.getUcdComponent(), blueServiceInstance.getProvisionedName() )
//				blueServiceInstance.addUcdEnvironment( ucdConfigurationDefinition.blueEnvironmentDefinition.getUcdEnvironment() )
//				// green
//				AwsServiceInstance greenServiceInstance = serviceDefinition.provisionInstance( awsConnection, awsProductIds )
//				serviceInstances << greenServiceInstance
//				ComponentResourceNode greenComponentResourceNode = ucdConfigurationDefinition.greenResourceBranchDefinition.addComponent(serviceDefinition.getUcdComponent(), greenServiceInstance.getProvisionedName())
//				greenServiceInstance.addUcdEnvironment( ucdConfigurationDefinition.greenEnvironmentDefinition.getUcdEnvironment() )
//			} else {
//				// provision a single instance
//				AwsServiceInstance serviceInstance = serviceDefinition.provisionInstance( awsConnection, awsProductIds )
//				serviceInstances << serviceInstance
//				ComponentResourceNode componentResourceNode = ucdConfigurationDefinition.baseResourceBranchDefinition.addComponent(serviceDefinition.getUcdComponent(), serviceInstance.getProvisionedName())
//				ucdConfigurationDefinition.getTargetEnvironments().each { UcdEnvironmentDefinition ucdEnvironmentDefinition ->
//					serviceInstance.addUcdEnvironment( ucdEnvironmentDefinition.getUcdEnvironment())
//				}
//			}
//		}
//		
//		// Some UCD properties can be defined before AWS is provisioned, and some UCD Properties
//		// have to wait for the provisioning to complete.
//		
//		// Setup UCD properties that don't have to wait for AWS Provisioning to complete
//		serviceInstances.each { AwsServiceInstance serviceInstance ->
//			serviceInstance.setUcdPropertiesBeforeProvisioningComplete(inProps)
//		}
//		
//		// Wait for all of the instances to be available
//		List<String> failureMessages = waitUntilAllInstancesAreAvailable(serviceInstances, true)
//		if (failureMessages.size() > 0) {
//			String msg = ''
//			String delim = ''
//			failureMessages.each { String failureMsg ->
//				msg = msg + delim + failureMsg
//				delim = '\n'
//			}
//			throw new AbortPluginException(msg)
//		}
//	}

	/**
	 * Waits until all AWS Services/Products are available.  If any service fails, this fails with an
	 * exception.  As the AWS Services become available, the corresponding UCD Properties are updated.
	 * @param serviceInstances The list of AWS Service/Product Instances that are being provisioned.
	 * @param waitForAll If true, wait until every service is either available or failed.  If false, it
	 * stops waiting if a single service fails.
	 * @param timeoutInMinutes How many minutes to wait until failing.
	 * @return Returns a List of String failure messages.  If the list is empty, then there were no failures.
	 */
	private List<String> waitUntilAllInstancesAreAvailable(List<AwsServiceInstance> serviceInstances, boolean waitForAll, def timeoutInMinutes = 40 ) {
		long startTime = System.currentTimeMillis()
		
		List<String> failureMessages = []
		boolean failed = false
		
		/**
		 * List of Map.  Each map entry has following fields:
		 * - boolean stillStarting
		 * - AwsServiceInstance serviceInstance
		 */
		List serviceInstancesWithStatus = []
		serviceInstances.each { AwsServiceInstance serviceInstance ->
			serviceInstancesWithStatus << [ stillStarting:true, serviceInstance:serviceInstance ]
		}

		boolean stillStarting = true
		while (stillStarting && (waitForAll || failed)) {
			// Check for timeout
			long currentTime = System.currentTimeMillis()
			if ((currentTime - startTime) > (timeoutInMinutes * 60 * 1000)) {
				throw new AbortPluginException("Timed out waiting to provision the AWS Product Instances")
			}
			// sleep one minute
			Thread.sleep( 1000*60 )
			stillStarting = false
			serviceInstancesWithStatus.each { Map entry ->
				AwsServiceInstance serviceInstance = entry.serviceInstance
				// First check if available from the cached data
				if (entry.stillStarting) {
					if (serviceInstance.isAvailable(true)) {
						entry.stillStarting = false
						// load the AWS output properties
						serviceInstance.getAwsInstanceData()
					} else if (serviceInstance.getAwsStatus() != 'UNDER_CHANGE') {
						failureMessages << "Unexpected AWS Status of ${serviceInstance.getAwsStatus()} received for newly provisioned ${serviceInstance.getServiceType()} for Product ${serviceInstance.getProvisionedName()}"
						entry.stillStarting = false
						failed = true
					} else {
						stillStarting = true
					}
				}
			}
		}
		return failureMessages
	}
	
	/**
	 * Checks to see if the environment and resource nodes already exist failing (via throwing exception) if they do.
	 * @param baseContext The base context.
	 */
	public void checkIfUCDEnvironmentAlreadyExists( BaseEnvironmentProvisionContext baseContext ) {
		Application application = baseContext.getApplication()
		
		// Check for existing environments
		baseContext.getAllEnvironmentNames().each { String environmentName ->
			if (application.doesEnvironmentExist(environmentName)) {
				throw new AbortPluginException( "Requested Environment '${environmentName}' already exists for the application '${application.name}'" )
			}
		}
		
		// Check for existing resource branches
		// get base resource tree branch for application
		ResourceTree resourceTree = ucdConnectionServices.getResourceServices().getResourceTree()
		if (resourceTree.doesChildNodeExist(application.name)) {
			ResourceNode applicationResourceNode = resourceTree.getChildNode(application.name)
			baseContext.getAllResourceBranchNames().each { String branchName ->
				if (applicationResourceNode.doesChildNodeExist(branchName)) {
					throw new AbortPluginException( "A previous instance of the environment has not been fully cleaned up.  Resource '${application.name}/${branchName}' should not exist." )
				}
			}
		}
	}
	
	/**
	 * Creates the UCD Environment and Resource Tree Structure.
	 * @param baseContext The base context.
	 * @param requestedEnvType The desired type for the new environment, which is actually the name of an environment template.
	 * @param agentName The name of the agent (or agent pool) to add to the resource tree branch
	 * @param ucdComponentsDef Describes the desired UCD Components.
	 */
	public void createTargetUcdStructure( BaseEnvironmentProvisionContext baseContext, String requestedEnvType, String agentName,
		UcdComponentsDef ucdComponentsDef ) {
		Application application = baseContext.getApplication()
		
		// Get the application teams (which are replicated)
		List<Team> applicationTeams = application.getUniqueTeams()
		
		ResourceTree resourceTree = ucdConnectionServices.getResourceServices().getResourceTree()
		
		EnvironmentTemplate environmentTemplate = application.getApplicationTemplate().getEnvironmentTemplate(requestedEnvType)
		
		// lookup the Resource Pool
		if (! ucdConnectionServices.getAgentServices().doesAgentOrAgentPoolExist(agentName)) {
			throw new AbortPluginException("Unable to find UCD Agent or Agent Pool named '${agentName}'")
		}
		AgentOrAgentPool ucdAgentOrAgentPool = ucdConnectionServices.getAgentServices().getAgentOrAgentPool(agentName)

		baseContext.iterateContextTree { ProvisionContext context ->
			if (context.environmentName) {
				
				// Create the new environment
				context.environment = application.createEnvironmentFromTemplate(context.environmentName, environmentTemplate )
				context.environment.removeLinksToAllTeams()
				applicationTeams.each { Team team ->
					context.environment.addLinkToTeam(team)
				}
				
				// Process the Environment Tree Branch which automatically created with the Environment Template
				List<ResourceNode> baseResources = context.environment.getBaseResources()
				baseResources.each { ResourceNode resourceNode ->
					context.resourceBranch = resourceNode
					setResourceNodeTeams( resourceNode, applicationTeams )
					ResourceNode agentNode = context.resourceBranch.createChildAgentOrAgentPoolNode(agentName, ucdAgentOrAgentPool)
					// Add appropriate components
					addAndConfigureComponents( context, ucdComponentsDef, agentNode, true, false )
				}
				
				// Process any additional resource nodes (not created by the template)
				if (context.parentContext && context.parentContext.resourceBranchName) {
					ResourceNode agentNode
					boolean onlyConfigureComponent
					if (! context.parentContext.resourceBranch) {
						// a shared resource branch is needed, but not created yet
						onlyConfigureComponent = false
						ResourceNode applicationResourceNode = resourceTree.getChildNode(application.name)
						context.parentContext.resourceBranch = applicationResourceNode.createChildGroupNode(context.parentContext.resourceBranchName)
						setResourceNodeTeams( context.parentContext.resourceBranch, applicationTeams )
						agentNode = context.parentContext.resourceBranch.createChildAgentOrAgentPoolNode(agentName, ucdAgentOrAgentPool)
					} else {
						onlyConfigureComponent = true
						agentNode = context.parentContext.resourceBranch.getChildNode(agentName)
					}
					addAndConfigureComponents( context, ucdComponentsDef, agentNode, false, onlyConfigureComponent )
					context.environment.addBaseResource(context.parentContext.resourceBranch)
				}
			}
		}
		
		// Set environment properties for the environment(s)
		if (baseContext.isProvisioningBlueGreen()) {
			ProvisionContext blueContext = baseContext.getBlueChildContext()
			ProvisionContext greenContext = baseContext.getGreenChildContext()
			greenContext.environment.setProperty('pairedBlueGreenEnvironment', blueContext.environmentName, false)
			blueContext.environment.setProperty('pairedBlueGreenEnvironment', greenContext.environmentName, false)
		}
		baseContext.iterateContextTree { ProvisionContext context ->
			if (context.environment) {
				List awsResourceList = []
				context.getInheritedAwsResourceInstances().each { AwsResourceInstanceContextData awsInstanceData ->
					if (awsInstanceData.awsServiceInstance) {
						String logicalName = awsInstanceData.awsServiceDefinition.name
						AwsServiceInstance serviceInstance = awsInstanceData.awsServiceInstance
						String provisionedName = serviceInstance.getProvisionedName()
						String provisionedId = serviceInstance.getProvisionedId()
						boolean isProvisioned = serviceInstance.isNewlyProvisioned()
						awsResourceList << [name: logicalName, provisionedProductName : provisionedName, provisionedProductId: provisionedId, provisioned:isProvisioned]
					}
				}
				context.environment.setProperty( 'awsResources', JsonOutput.toJson(awsResourceList), false )
			}
		}
	}
	
	/**
	 * Adds the appropriate requested UCD components to the 'agentNode' configuring the components appropriately (component and environment component
	 * properties).
	 * @param context The context for that the agent is in.
	 * @param ucdComponentsDef The definition of the requested components.
	 * @param agentNode The agent node in the resource tree to add the components to.
	 * @param isPrimaryBaseResourceBranch Is this the primary base resource tree mapped for the environment?  For blue-green,
	 * @param onlyConfigure If true, then the component already exists and just needs to be configured.  Why?
	 * When defining components shared by blue and green, the components are created and configured for the blue
	 * environment, but already exist and just need to be configured for the green environment.
	 * blue-green specific components are mapped to the primary base resource tree.
	 */
	private void addAndConfigureComponents( ProvisionContext context, UcdComponentsDef ucdComponentsDef, ResourceNode agentNode,
		boolean isPrimaryBaseResourceBranch, boolean onlyConfigure ) {
		if (context.environment) {
			
			// Get the list of component def's that need to be added to the 
			List<UcdComponentDef> componentsToAddAndConfigure
			if (context.isBaseContext()) {
				// FOr the base context, simply add and configure all of the components
				componentsToAddAndConfigure = ucdComponentsDef.getAllComponentDefs()
			} else if (isPrimaryBaseResourceBranch) {
				// The primary base resource branch for a non-base Context (aka blue-green environment) is blue-green components
				componentsToAddAndConfigure = ucdComponentsDef.getComponentDefsSupportingBlueGreen()
			} else {
				componentsToAddAndConfigure = ucdComponentsDef.getComponentDefsNotSupportingBlueGreen()
			}
			
			// add and configure the component def's
			componentsToAddAndConfigure.each { UcdComponentDef componentDef ->
				Component component = ucdConnectionServices.getComponentServices().getComponent(componentDef.componentName)
				if (! onlyConfigure) {
					agentNode.createChildComponentNode(componentDef.componentName, component)
				}
				// configure the component
				componentDef.componentEnvironmentProperties.each { String propertyName, String propertyValue ->
					propertyValue = context.processTokens(propertyValue, component.getName())
					component.setComponentEnvironmentProperty(context.environment, propertyName, propertyValue)
				}
			}
		}
	}
	
	/**
	 * Sets the teams for the resourceNode to the teams (and ONLY the teams).  This does NOT
	 * set any resource node types.
	 */
	private void setResourceNodeTeams( ResourceNode resourceNode, List<Team> teams ) {
		resourceNode.removeLinksToAllTeams()
		teams.each { Team team ->
			resourceNode.addLinkToTeam(team)
		}
	}

}
