package com.ibm.issr.core.entity


/**
 * <p>This is an indexed list of Entities.  Entities can be added, removed and looked up by name or id.
 * </p><p>
 * It is indexed by both 'uniqueName' and 'id'.  Every entity in the list must have a unique name and id.
 * The unique ID must be returned by the entity.getId() function.  The returned ID must be unique within
 * the list.
 * </p><p>
 * <b>uniqueName</b> - One goal of this class is to be able to lookup cached entities by
 * id or name.  However, let's consider the UCD-Environment entity.  Environment names are NOT
 * unique across all Applications!!  Therefore, this class uses the concept of a 'uniqueName' within
 * this cache.  For example, if this is a cache of UCD Environments for multiple UCD Applications, then
 * using "appName/envName" as the uniqueName IS unique.  However, if this is only a cache
 * of environments within one application, then using just the environment name is unique.
 * The calculateUniqueNameForEntity is a Closure parameter
 * to the constructor.  Given an entity instance, it should return the uniqueName for that entity.
 * The template is: String getUniqueNameForEntity( EntityWithId entity ).  The default version of this
 * closure simply returns the id.
 * </p> 
 * @author LeonClark
 *
 */
class IndexedListOfEntities {
	private calculateUniqueNameForEntity

	/**
	 * _nameIndex is a map whose keys are the entity's unique names and values are the Entity (EntityWithId)
	 */
	private Map _nameIndex = [:]

	/**
	 * _idIndex is a map whose keys are the entity's id's and values are the Entity (EntityWithId)
	 */
	private Map _idIndex = [:]

	/**
	 * Constructor.
	 * @param calculateUniqueNameForEntity Calculate unique name (within the cached list) for one Entity.
	 * One goal of this class is to be able to lookup cached entities by
	 * id or name.  However, let's consider the UCD-Environment entity.  Environment names are NOT
	 * unique across all Applications!!  Therefore, this class uses the concept of a 'uniqueName' within
	 * this cache.  For example, if this is a cache of UCD Environments for multiple UCD Applications, then
	 * using "appName/envName" as the uniqueName IS unique.  However, if this is only a cache
	 * of environments within one application, then using just the environment name is unique.
	 * The calculateUniqueNameForEntity is a Closure parameter
	 * to the constructor.  Given an entity instance, it should return the uniqueName for that entity.
	 * The template is: String getUniqueNameForEntity( EntityWithId entity ).  The default version of this
	 * closure simply returns the id.
	 */
	public IndexedListOfEntities( Closure calculateUniqueNameForEntity = { EntityWithId entity -> return entity.getId()} ) {
		this.calculateUniqueNameForEntity = calculateUniqueNameForEntity
	}
	
	/**
	 * Resets the entire list back to an empty list.
	 */
	public void resetList() {
		_nameIndex = [:]
		_idIndex = [:]
	}
	
	/**
	 * Is the list of entities empty?
	 */
	public boolean isEmpty() {
		return _idIndex.isEmpty()
	}
	
	/**
	 * Returns the number of elements that are in the indexed list.
	 * @return
	 */
	public int size() {
		return _idIndex.size()
	}
	
	/**
	 * This is a standard each loop which calls the closure for each element in the indexed list.
	 * @param closure Called for each element in the list.  The syntax is: void closure(EntityWithId Entity).
	 */
	public void each( Closure closure ) {
		_idIndex.each { String id, EntityWithId entity ->
			closure(entity)
		}
	}

	/**
	 * Replaces the currently cached entity (as indexed by 'id') with a newer version of the
	 * entity.
	 */
	public void updateEntity( EntityWithId entity ) {
		if (! containsEntity(entity)) {
			throw new Exception( "Internal error: Attempting to update a cached entity which does not exist")
		}
		// Get the old, cached entity
		EntityWithId cachedEntity = getEntityById( entity.id )
		// Remove old, cached entity from name index
		_nameIndex.remove(calculateUniqueNameForEntity(cachedEntity))
		// Add/update with new entity
		_nameIndex[calculateUniqueNameForEntity(entity)] = entity
		_idIndex[entity.getId()] = entity
	}	
	
	/**
	 * Adds the entity to the list.  Throws exception if the entity is already in the cache.
	 */
	public void addEntity( EntityWithId entity ) {
		if (containsEntity(entity)) {
			throw new Exception( "Attempting to add entity which is already in the index entity list.  It's id is '${entity.getId()}'" )
		} else {
			_nameIndex[calculateUniqueNameForEntity(entity)] = entity
			_idIndex[entity.getId()] = entity
		}
	}
	
	
	/**
	 * Is the entity in this indexed entity list?
	 */
	public boolean containsEntity( EntityWithId entity ) {
		return this.containsEntityById(entity.getId())
	}
	
	
	/**
	 * Removes the entity from the indexed list.  Throws exception if the entity isn't in the list.
	 */
	public void removeEntity( EntityWithId entity ) {
		if (! containsEntity(entity)) {
			throw new Exception( "Attempting to remove entity from indexed entity list, but the entity isn't in the list.  It's id is '${entity.getId()}'" )
		} else {
			_nameIndex.remove(calculateUniqueNameForEntity(entity))
			_idIndex.remove(entity.getId())
		}
	}
	
	/**
	 * Does the list contain an entity with the given id?
	 */
	public boolean containsEntityById( String id ) {
		return (_idIndex.containsKey(id))
	}
	
	/**
	 * Returns the entity with the given id.
	 * Throws exception if the entity isn't found.
	 */
	public EntityWithId getEntityById( String id ) {
		if (_idIndex.containsKey(id)) {
			return _idIndex[id]
		} else {
			throw new Exception( "The indexed list of Entities doesn't contain id '${id}'" )
		}
	}
	
	/**
	 * Does the list contain an entity with the given unique name?
	 */
	public boolean containsEntityByUniqueName( String name ) {
		return (_nameIndex.containsKey(name))
	}
	
	/**
	 * Returns the entity with the given unique name.
	 * Throws exception if the entity isn't found.
	 */
	public EntityWithId getEntityByUniqueName( String name ) {
		if (_nameIndex.containsKey(name)) {
			return _nameIndex[name]
		} else {
			throw new Exception( "The indexed list of Entities doesn't contain unique name '${name}'" )
		}
	}
}
