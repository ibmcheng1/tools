package com.fanniemae.ucd.aws.provision.ucd;

import com.ibm.css.ucd.agent.AgentOrAgentPool
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.environmenttemplate.EnvironmentTemplate
import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.css.ucd.team.Team

/**
 * Describes one UCD environment.  If and when the environment is
 * created, then the UCD environment is stored in this definition.
 * @author s9ulcc
 *
 */
public class UcdEnvironmentDefinition {
	/**
	 * Additional targetResourceNodes - these are all secondary nodes.  In particular,
	 * these are NOT created by the environment template but need to be manually created and
	 * linked to the environment. 
	 */
	private List<UcdResourceBranchDefinition> _additionalResourceBranches = []
	
	/**
	 * This is the ResourceNode which is automatically created by the environment template.
	 */
	private UcdResourceBranchDefinition _standardBaseResourceBranchDefinition
	
	private AgentOrAgentPool _ucdAgentOrAgentPool
	
	
	/**
	 * The TargetUcdConfiguration that this class is a member of.
	 */
	public UcdConfigurationDefinition targetUcdConfiguration
	/**
	 * The UCD name of this target environment
	 */
	public String name
	
	private String requestedEnvType
	
	/**
	 * The corresponding UCD Environment
	 */
	private Environment _ucdEnvironment = null
	
	/**
	 * Constructor
	 * @param targetUcdConfiguration The "parent" object of this target environment definition.
	 * @param environmentName The name of the environment.
	 * @param standardBaseResourceBranchDefinition The target node which is created by the Environment Template.
	 */
	public UcdEnvironmentDefinition( UcdConfigurationDefinition targetUcdConfiguration, String environmentName, String requestedEnvType,
		AgentOrAgentPool ucdAgentOrAgentPool, UcdResourceBranchDefinition standardBaseResourceBranchDefinition ) {
		this._standardBaseResourceBranchDefinition = standardBaseResourceBranchDefinition
		this.targetUcdConfiguration = targetUcdConfiguration
		this.name = environmentName
		this.requestedEnvType = requestedEnvType
		this._ucdAgentOrAgentPool = ucdAgentOrAgentPool
		// Add a back pointer from the resource branch to the environment
		standardBaseResourceBranchDefinition.addAssociatedEnvironmentDefinition(this)
	}
	
	/**
	 * Does this environment exist in UCD?
	 */
	public boolean doesEnvironmentExist() {
		return getApplication().doesEnvironmentExist( name )
	}
	
	/**
	 * Returns the Application for this target environment.
	 */
	public Application getApplication() {
		return targetUcdConfiguration.application
	}

	
	/**
	 * Adds additional targetResourceNode to this environment definition.  These additional
	 * nodes are NOT automatically created by the Environment Template, but have to be manually created.
	 * @return this
	 */
	public UcdEnvironmentDefinition addAdditionalResourceBranches( UcdResourceBranchDefinition resourceBranchDefinition ) {
		_additionalResourceBranches << resourceBranchDefinition
		// Add a back pointer from the resource branch to the environment
		resourceBranchDefinition.addAssociatedEnvironmentDefinition(this)
		
		return this
	}
	
	/**
	 * Create the corresponding UCD Environment and linked Resource Tree nodes.
	 * @param teams The teams to use for the environment and resource tree.
	 * @return Returns the new UCD Environment.
	 */
	public Environment createUcdEnvironment( List<Team> teams ) {
		// Create new 
		EnvironmentTemplate environmentTemplate = application.getApplicationTemplate().getEnvironmentTemplate(requestedEnvType)
		_ucdEnvironment = application.createEnvironmentFromTemplate(name, environmentTemplate)
		_ucdEnvironment.removeLinksToAllTeams()
		teams.each { Team team ->
			_ucdEnvironment.addLinkToTeam(team)
		}
		List<ResourceNode> baseResources = _ucdEnvironment.getBaseResources()
		baseResources.each { ResourceNode resourceNode ->
//			ResourceNode agentNode = resourceNode.createChildAgentOrAgentPoolNode(_ucdAgentOrAgentPool.name, _ucdAgentOrAgentPool)
			_standardBaseResourceBranchDefinition.setUcdResourceNode(resourceNode)
			_standardBaseResourceBranchDefinition.configureUcdResourceNode(teams)
		}
		// Process any additional resource nodes
		_additionalResourceBranches.each { UcdResourceBranchDefinition targetResourceNode ->
			ResourceNode ucdResourceNode = targetResourceNode.getUcdResourceNode()
			_ucdEnvironment.addBaseResource(ucdResourceNode)
			targetResourceNode.configureUcdResourceNode(teams)
		}
		return _ucdEnvironment
	}
	
	/**
	 * After calling createUcdEnvironment(), you can call this function to retrieve the UCD Environment.
	 */
	public Environment getUcdEnvironment() {
		return _ucdEnvironment
	}
}
