package com.ibm.services.ucr.api.entity.initiative

import com.ibm.issr.rest.RestDelete
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.framework.UcrEntityData
import com.ibm.services.ucr.api.framework.UcrEntityDataFormat
import com.ibm.services.ucr.api.framework.UcrEntityWithNameAndId

/**
 * One UCR Initiative record.
 * @author LeonClark
 *
 */
class UcrInitiative extends UcrEntityWithNameAndId {
	// Cached instance of 'UcrEntityData'
	private RestDataCache _cachedEntityData = new RestDataCache()
	
	/**
	 * This constructor should only be called by this entity's Mgr class.
	 */
	UcrInitiative( RestServerConnection ucrServer, String name, String id ) {
		super( ucrServer, name, id )
	}
	
	/**
	 * Constructor based on the 'restInfo'
	 * @param ucrServer
	 * @param restInfo
	 */
	UcrInitiative( RestServerConnection ucrServer, UcrEntityData restEntity ) {
		super( ucrServer, restEntity.entityObject.name, restEntity.entityObject.id )
		_cachedEntityData.setCacheData( ucrServer, restEntity )
	}
	
	/**
	 * Resets the cached data storing internal data for this class instance.
	 */
	public void resetCachedData() {
		_cachedEntityData.resetCacheData(ucrServer)
	}
	
	
	/**
	 * Returns entity data for this entity which is at LEAST the 'minDataFormat' level of information.  For example,
	 * if the minDataFormat is LIST_FORMAT, then both LIST_FORMAT and DETAIL_FORMAT are suitable.
	 * If possible, this returns cached data, otherwise it loads (and caches) the data.
	 */
	public UcrEntityData getEntityData( UcrEntityDataFormat minDataFormat, boolean resetCache=false ) {
		UcrEntityData entityData = _cachedEntityData.getCacheData(ucrServer,resetCache)
		if ((! entityData) || (! entityData.getEntityFormat().isSuperset( minDataFormat ))) {
			// Load the data and cache it
			def data = (new RestGet( ucrServer ))
				.setPath('/initiatives/' + this.id)
				.addParameter('format', minDataFormat.getFormatName())
				.setHeader('Accept', 'application/json')
				.getAsObject()
			_cachedEntityData.setCacheData(ucrServer, new UcrEntityData(data, minDataFormat))
		}
		return _cachedEntityData.getCacheData(ucrServer)
	}
	
	/**
	 * Returns detail'ed entity data.  This is data retrieved via a REST call with format of 'detail'.  If possible,
	 * this returns cached data, otherwise it loads (and caches) the data.
	 */
	public UcrEntityData getDetailedEntityData( boolean resetCache=false ) {
		return getEntityData( UcrEntityDataFormat.DETAIL_FORMAT, resetCache )
	}
	
	
	/**
	 * Returns at least a LIST level UcrEntityData for this class, which is the underlying REST/JSON based data structure.
	 */
	public UcrEntityData getEntityData( boolean resetCache = false ) {
		return getEntityData( UcrEntityDataFormat.LIST_FORMAT, resetCache )
	}
	
	
	/**
	 * If this change is from an external source, like Jira, this is the external
	 * system's ID.  Otherwise, it is an empty string.
	 */
	public String getExternalId( boolean resetCache = false ) {
		String retval = ''
		Map data = getEntityData(resetCache).entityObject
		if (data.containsKey('externalId')) {
			retval = data.externalId
		}
		return retval
	}

	/**
	 * Delete this entity from UCR!!  Appropriate cached data is reset.
	 */
	public void delete() {
		(new RestDelete(ucrServer))
			.setPath('/initiatives/' + this.id)
			.deleteWithNoReturnObject()
		// TODO - currently reseting all cached data.  In the future, just remove the entry from the Mgr's cache(s)
		RestDataCache.resetAllCacheData(ucrServer)
	}
}
