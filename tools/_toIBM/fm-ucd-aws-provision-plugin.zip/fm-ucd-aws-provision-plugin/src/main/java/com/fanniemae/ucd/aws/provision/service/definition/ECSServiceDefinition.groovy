package com.fanniemae.ucd.aws.provision.service.definition

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.ucd.aws.provision.service.instance.AwsServiceInstance
import com.fanniemae.ucd.aws.provision.service.instance.ECSServiceInstance
import com.fanniemae.ucd.aws.provision.spec.AwsSpecification

/**
 * A definition (aka Manifest definition) of one AWS Service, such as EB or RDS.
 * @author Leon Clark
 */
class ECSServiceDefinition extends AwsServiceDefinition {

	public static final String SERVICE_TYPE = 'ECS'
	
	@Override
	public String getServiceType() {
		return SERVICE_TYPE
	}
	
	@Override
	public boolean shouldProvisionSeparateBlueGreenInstances() {
		return false
	}

	@Override
	protected AwsServiceInstance buildAwsServiceInstance(AwsConnection awsConnection, String provisionedId, boolean newlyProvisioned) {
		return new ECSServiceInstance( this, awsConnection, provisionedId, newlyProvisioned )
	}

	/**
	 * Constructor.
	 * @param awsSpecification The parent AwsSpecification
	 * @param instanceData This is the parsed block of data from the specification file for one instance.
	 */
	public ECSServiceDefinition( AwsSpecification awsSpecification, Map instanceData ) {
		super( awsSpecification, instanceData )
		defineMemberField( 'name', true ) { String fieldValue -> _name = fieldValue }
		defineMemberField( 'awsName', false ) { String fieldValue -> _awsName = fieldValue }
		defineAwsProperty( 'Name', true )
		validateAndSetMemberFields()
	}
}
