package com.ibm.css.rest.ucd.applicationtemplate

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.issr.rest.RestGet

class ApplicationTemplateApi {
	UcdServerConnection ucdServer
	
	
	/**
	 * Constructor for this light weight class.
	 * @param ucdServer Handle to UCD Server
	 */
	public ApplicationTemplateApi( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
	}
	
	/**
	 * Returns the list of all ApplicationTemplates.
	 * @return List where each member of the list is a data map describing
	 * each Application Template as per /rest/deploy/applicationTemplate.
	 * At a minimum, each entry has 'name' and 'id'.
	 */
	public List getApplicationTemplates() {
		List applicationTemplates = (new RestGet( ucdServer ))
			.setPath('/rest/deploy/applicationTemplate')
			.getAsObject()
		return applicationTemplates
	}
	
	/**
	 * Returns the REST API information for the identified ApplicationId.
	 * This returns an object version of the information.
	 */
	public def getInfo( String applicationTemplateId ) {
		return (new RestGet( ucdServer ))
			.setPath('/rest/deploy/applicationTemplate/' + applicationTemplateId )
			.getAsObject()
	}

}
