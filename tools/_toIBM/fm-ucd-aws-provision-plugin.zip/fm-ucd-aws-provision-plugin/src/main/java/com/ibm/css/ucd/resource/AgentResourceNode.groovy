

package com.ibm.css.ucd.resource

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.agent.Agent

/**
 * A UCD Resource Tree node for an Agent reference.
 * @author ltclark
 *
 */
class AgentResourceNode extends AgentOrAgentPoolResourceNode {
	// Object version of the call to /cli/resource/info
	protected def info
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the UCD Server.
	 * @param parentNode The parent node to this node.
	 * @param info This is an Object version of the call to /cli/resource/info.
	 * Note that it has at least two fields - name and id.
	 */
	public AgentResourceNode( UcdServerConnection ucdServer, ResourceNode parentNode, def info ) {
		super( ucdServer, parentNode, info.name, info.id )
		this.info = info
	}

	@Override
	public String getNodeType() {
		return AGENT_NODE_TYPE
	}
	
	public Agent getAgent() {
		if (info.containsKey('agent')) {
			return new Agent(ucdServer,info.agent.name,info.agent.id)
		} else {
			throw new Exception( "Internal error: AgentResourceNode.getAgent() can't access agent information.")
		}
	}
	
	/**
	 * Is this agent node online.
	 * @return
	 */
	public boolean isOnline() {
		return info.status == "ONLINE"
	}
	
	/**
	 * Is this agent node online.
	 * @return
	 */
	public boolean isOffline() {
		return info.status == "OFFLINE"
	}

	/**
	 * Return the agent status.
	 */
	public String getStatus() {
		return info.status
	}
}
