package com.ibm.services.ucr.api.entity.change.filter

import com.ibm.services.ucr.api.entity.application.UcrApplication
import com.ibm.services.ucr.api.entity.initiative.UcrInitiative;
import com.ibm.services.ucr.api.entity.release.UcrRelease

/**
 * Defines a set of filter criteria for the function
 * UcrChangeMgr.getFilteredList().
 * @author LeonClark
 *
 */
class UcrChangeFilter {
	private UcrApplication _application = null
	private boolean _filterOnNoApplication = false
	private UcrRelease _release = null
	private boolean _filterOnNoRelease = false
	private UcrInitiative _initiative = null
	private boolean _filterOnNoInitiative = false

	/**
	 * Adds a filter criteria for a linked Application.  If
	 * the application is null, then it ONLY returns Changes that have NO application.
	 */
	public UcrChangeFilter setApplicationFilter( UcrApplication application ) {
		_application = application
		_filterOnNoApplication = (! application)
		return this
	}

	/**
	 * Adds a filter criteria for a linked Release.  If
	 * the release is null, then it ONLY returns Changes that have NO release.
	 */
	public UcrChangeFilter setReleaseFilter( UcrRelease release ) {
		_release = release
		_filterOnNoRelease = (! release)
		return this
	}

	/**
	 * Adds a filter criteria for a linked Initiative.  If
	 * the initiative is null, then it ONLY returns Changes that have NO initiative.
	 */
	public UcrChangeFilter setInitiativeFilter( UcrInitiative initiative ) {
		_initiative = initiative
		_filterOnNoInitiative = (! initiative)
		return this
	}
}
