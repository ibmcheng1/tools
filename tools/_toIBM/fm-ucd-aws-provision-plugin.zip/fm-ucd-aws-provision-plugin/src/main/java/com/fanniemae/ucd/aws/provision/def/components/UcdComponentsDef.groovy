package com.fanniemae.ucd.aws.provision.def.components

import com.fanniemae.ucd.aws.provision.def.common.ConfigFileWrapper
import com.fanniemae.ucd.aws.provision.def.components.data.UcdComponentDef
import com.ibm.issr.core.json.JsonHelper
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel

/**
 * Class wrapper for 'ucdComponentsDef.json' files.
 */
class UcdComponentsDef extends ConfigFileWrapper {
	// This is the parsed version of the json file
	private Map _config
	/**
	 * The list of defined components
	 */
	private List<UcdComponentDef> _components = []
	
	/**
	 * Constructor
	 * @param jsonContents The input json contents.
	 */
	public UcdComponentsDef( String jsonContents ) {
		String jsonStringWithoutComments = JsonHelper.removeCommentLines(jsonContents)
		try {
			_config = new groovy.json.JsonSlurper().parseText( jsonStringWithoutComments )
			if ((! _config.containsKey('ucdComponents')) || _config.ucdComponents.size()==0) {
				tagValidationError( "The ucdComponentsDef file is missing required 'ucdComponents' entry." )
			} else {
				List items = _config.ucdComponents
				int itemNumber = 0
				items.each { Map configItem ->
					++itemNumber
					_components << new UcdComponentDef( itemNumber, configItem, this )
				}
			}
		}
		catch (Exception e) {
			tagValidationError( e.message )
			
			if (Logger.displayDebug) {
				Logger.printStackTrace(LoggerLevel.ERROR, e)
			}
		}
	}
	
	/**
	 * Do any of the listed components support blue-green configuration?
	 */
	public boolean doAnyComponentsSupportBlueGreen() {
		UcdComponentDef componentSupportingBlueGreen = _components.find { UcdComponentDef ucdComponentDef ->
			return ucdComponentDef.participateInBlueGreen
		}
		return (componentSupportingBlueGreen != null)
	}
	
	/**
	 * Returns the list of all member 'UcdComponentDef's
	 */
	public List<UcdComponentDef> getAllComponentDefs() {
		return _components
	}
	
	/**
	 * Returns the list of member 'UcdComponentDef's which support blue-green environments.
	 */
	public List<UcdComponentDef> getComponentDefsSupportingBlueGreen() {
		List<UcdComponentDef> componentDefs = []
		getAllComponentDefs().each { UcdComponentDef componentDef ->
			if (componentDef.participateInBlueGreen) {
				componentDefs << componentDef
			}
		}
		return componentDefs
	}
	
	/**
	 * Returns the list of member 'UcdComponentDef's which do NOT support blue-green environments.
	 */
	public List<UcdComponentDef> getComponentDefsNotSupportingBlueGreen() {
		List<UcdComponentDef> componentDefs = []
		getAllComponentDefs().each { UcdComponentDef componentDef ->
			if (! componentDef.participateInBlueGreen) {
				componentDefs << componentDef
			}
		}
		return componentDefs
	}
}
