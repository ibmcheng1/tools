package com.fanniemae.ucd.aws.provision.context

import com.fanniemae.ucd.aws.api.describeRecord.AwsDescribeRecordResult
import com.fanniemae.ucd.aws.provision.context.data.AwsResourceInstanceContextData
import com.fanniemae.ucd.aws.provision.service.definition.AwsServiceDefinition
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.issr.core.log.Logger

/**
 * <p>Represents one provisioning context.  A context can have a parent
 * context.
 * </p><p>
 * Key data stored in the context is...
 * </p>
 * <ul>
 * <li>Application application - The UCD application being provisioned to.  Note that child contexts
 * inherit this from their parent.</li>
 * <li>AWS Resource Instance list - which includes definition and (eventually) the provisioned instances.</li>
 * <li>UCD Environment for this context (name and UCD Environment class) as appropriate.  For
 * example, if provisioning blue-green, then the base context has no environment.</li>
 * <li>UCD Resource branch for this context (name and UCD variable).  This is always defined for the
 * base, blue and green contexts</li>
 * </ul>
 * <p>For example, when provisioning to blue-green,
 * the base context corresponds to the environment, components, and
 * AWS Resource Instances that are common (not blue or green).  It has
 * two child contexts - a blue and a green context with the blue and green
 * details.
 * <p> 
 */
class ProvisionContext {
	// value that indicates that no substitution was found for a token value
	protected static final String TOKEN_NOT_FOUND = "'#!*(`"
		
	protected ProvisionContext _parentContext
	
	protected List<ProvisionContext> _childContexts = []

	protected List<AwsResourceInstanceContextData> _awsResourceInstances = []
	
	protected Application _application
	
	// The base environment name, which is the original environment name without any blue-gree suffix, etc
	protected String _baseEnvironmentName = ''
	
	// Map of tokens where key is String token name and value is String token value 
	protected Map _tokens = [:]
	
	protected boolean _blueContext = false
	protected boolean _greenContext = false
	
	/**
	 * The environment name for this context.  Empty string if not defined.
	 */
	public String environmentName = ''
	/**
	 * The environment for this context.  null if not defined.
	 */
	public Environment environment = null
	
	/**
	 * For a non-blue-green environment, this is an empty string.  
	 * Otherwise it is a unique number counter for the blue-green 
	 * environments � �1�, �2� (and so on if needed).
	 */
	public String blueGreenCounter = ''
	
	/**
	 * The name of the resource tree branch for this context.  This is the
	 * name of the child under the application node, such as 'D105' and NOT
	 * 'app/D105'.  This is an empty string if there is no resource tree branch
	 * for this context.
	 */
	public String resourceBranchName = ''
	/**
	 * The handle to the resource tree branch for this Context or
	 * null if not defined or needed.
	 */
	public ResourceNode resourceBranch

	/**
	 * Constructor
	 * @param parentContext Optional parent context
	 */
	public ProvisionContext( ProvisionContext parentContext = null, boolean blueContext=false, boolean greenContext=false ) {
		_parentContext = parentContext
		_blueContext = blueContext
		_greenContext = greenContext
	}

	/**
	 * Is this a blue context?	
	 */
	public boolean isBlueContext() {
		return _blueContext
	}
	
	/**
	 * Is this a green context?
	 */
	public boolean isGreenContext() {
		return _greenContext
	}
	
	/**
	 * Adds the list of tokens for this context.  Note that when tokens are retrieved,
	 * they use the context stack.
	 * @param tokens A set of token name/value pairs.
	 */
	public void addTokens( Map tokens ) {
		tokens.each { String name, String value ->
			_tokens[name] = value
		}
	}
	
	/**
	 * Does the named token exist in the context stack??
	 */
	public boolean containsToken( String tokenName ) {
		if (_tokens && _tokens.containsKey(tokenName)) {
			return true
		} else {
			ProvisionContext parentContext = getParentContext()
			if (parentContext) {
				return parentContext.containsToken(tokenName)
			} else {
				return false
			}
		}
	}
	
	/**
	 * Returns the value of the named token from the context stack or empty string if not found.
	 */
	public def getTokenValue( String tokenName ) {
		if (_tokens && _tokens.containsKey(tokenName)) {
			return _tokens[tokenName]
		} else {
			ProvisionContext parentContext = getParentContext()
			if (parentContext) {
				return parentContext.getTokenValue(tokenName)
			} else {
				return ''
			}
		}
	}
	
	/**
	 * Returns the parent context, which may be null.
	 */
	public ProvisionContext getParentContext() {
		return _parentContext
	}
	
	/**
	 * Adds a child context.
	 */
	public void addChildContext( ProvisionContext childContext ) {
		_childContexts << childContext
	}
	
	/**
	 * Returns a list of all of the child contexts.
	 */
	public List<ProvisionContext> getChildContexts() {
		return _childContexts
	}
	
	/**
	 * Iterate this context and every descendent context calling the callback
	 * for each context in that tree. 
	 * @param eachMethod Callback.  Syntax is 'void eachMethod( ProvisionContext provisionContext )'
	 */
	public void eachContextInTree( Closure eachMethod ) {
		// Call for this context
		eachMethod( this )
		// recurse for each child
		getChildContexts().each { ProvisionContext childContext ->
			childContext.eachContextInTree(eachMethod)
		}
	}
	
	/**
	 * Adds a brand new AWS Resource Instance to this context by adding its definition.
	 * @param awsServiceDefinition The definition of a specific desired AWS Resource Instance.
	 */
	public void addAwsResourceInstance( AwsServiceDefinition awsServiceDefinition ) {
		_awsResourceInstances << new AwsResourceInstanceContextData(awsServiceDefinition)
	}
	
	/**
	 * Return a list of AwsResourceInstanceContextData entries that are part of this context.
	 * This does NOT look at parent contextes at all.
	 */
	public List<AwsResourceInstanceContextData> getContextSpecificAwsResourceInstances() {
		return _awsResourceInstances
	}

	/**
	 * Return a list of all AwsResourceInstanceContextData entries for this context and all
	 * of its ancestor contexts. 
	 * @return
	 */
	public List<AwsResourceInstanceContextData> getInheritedAwsResourceInstances() {
		List<AwsResourceInstanceContextData> all = []
		for (ProvisionContext context = this; context; context = context.getParentContext()) {
			context.getContextSpecificAwsResourceInstances().each { AwsResourceInstanceContextData instance ->
				all << instance
			}
		}
		return all
	}
	
	/**
	 * Searches this context and parent contexts for instance context data with a matching
	 * logical definition name.
	 * @return Returns the located match or null if not found.
	 */
	public AwsResourceInstanceContextData findAwsInstanceContextData( String logicalResourceDefinitionName ) {
		List<AwsResourceInstanceContextData> contextList = getInheritedAwsResourceInstances()
		return contextList.find { AwsResourceInstanceContextData instanceContext ->
			return (instanceContext.getServiceDefinition().getName() == logicalResourceDefinitionName)
		}
	}
	
	/**
	 * Sets the application for this context.
	 */
	public void setApplication( Application application ) {
		this._application = application
	}
	
	/**
	 * Returns the application for this context.  Note that the
	 * application is inherited from the parent context.  This may return null.
	 */
	public Application getApplication() {
		if (_application) {
			return _application
		} else if (getParentContext()) {
			return getParentContext().getApplication()
		} else {
			return null
		}
	}
	
	/**
	 * Is the provisioning targeting blue-green?
	 */
	public boolean isProvisioningBlueGreen() {
		if (getParentContext()) {
			return getParentContext().isProvisioningBlueGreen()
		} else {
			return false
		}
	}

	/**
	 * Is this context the base context?  Otherwise, it is blue or green context.
	 */
	public boolean isBaseContext() {
		return (getParentContext() == null)
	}
	
	/**
	 * Process the string (s) which may contain context tokens, replaces the tokens and returns
	 * the resulting string.
	 * @param thisName Optional logical name of the entity being processed.  For example, if resolving
	 * a variable within an AwsServiceInstance, then 'thisName' is the logical name of the Service Instance. 
	 */
	public String processTokens( String s, String thisName = '' ) {
		List<String> tokenizedList = tokenize(s)
		String rslt = ''
		boolean isNextTokenPlainText = true
		tokenizedList.each { String token ->
			if (isNextTokenPlainText) {
				rslt = rslt + token
			} else {
				// Process token
				String newValue = lookupToken( token, thisName )
				if (newValue == TOKEN_NOT_FOUND) {
					Logger.info "WARNING: Unable to find a value for the token '%(${token})%'"
					rslt = rslt + '%(' + token + ')%'
				} else {
					rslt = rslt + newValue
				}
			}
			isNextTokenPlainText = ! isNextTokenPlainText
		}
		return rslt
	}
	
	/**
	 * Attempts to lookup a new value for the token.
	 * @param token The token string WITHOUT token delimiters.
	 * @param thisName Optional logical name of the entity being processed.  For example, if resolving
	 * a variable within an AwsServiceInstance, then 'thisName' is the logical name of the Service Instance. 
	 * @return Returns the new value for the token or TOKEN_NOT_FOUND if unable to find token lookup.
	 */
	protected String lookupToken( String token, String thisName = '' ) {
		List<String> segments = token.tokenize('.')
		if (token.equalsIgnoreCase('environment.name')) {
			return this.environmentName
		} else if (token.equalsIgnoreCase('environment.basename')) {
			return this.getBaseEnvironmentName()
		} else if (token.equalsIgnoreCase('environment.bluegreen.counter')) {
			return this.environmentName
		} else if (segments[0].equalsIgnoreCase('token')) {
			if (segments.size()> 1 && this.containsToken(segments[1])) {
				return this.getTokenValue(segments[1])
			} else {
				return TOKEN_NOT_FOUND
			}
		} else if (segments[0].equalsIgnoreCase('awsResource')) {
			if (segments.size() > 1) {
				String logicalResourceName = segments[1]
				if (logicalResourceName.equalsIgnoreCase('[this]')) {
					logicalResourceName = thisName
				}
				AwsResourceInstanceContextData instanceContextData = findAwsInstanceContextData(logicalResourceName)
				if (instanceContextData && segments.size() > 3) {
					if (segments[2].equalsIgnoreCase('prop')) {
						if (instanceContextData.awsServiceInstance && instanceContextData.awsServiceInstance.getAwsInstanceData()) {
							String fieldName = segments[3]
							AwsDescribeRecordResult recordResult = instanceContextData.awsServiceInstance.getAwsInstanceData()
							if (recordResult.hasNamedProperty(fieldName)) {
								return recordResult.getNamedProperty(fieldName)
							}
						}
					} else if (segments[2].equalsIgnoreCase('AwsProperty')) {
						AwsServiceDefinition awsServiceDefinition = instanceContextData.getServiceDefinition() 
						if (awsServiceDefinition) {
							String fieldName = segments[3]
							if (awsServiceDefinition.hasPropertyField(fieldName)) {
								return awsServiceDefinition.getPropertyField( fieldName, this )
							}
						}
					}
				}
			}
		} else {
			return TOKEN_NOT_FOUND
		}
	}
	
	/**
	 * Tokenize the string returning a List<String> where the first
	 * element is the string before the first token, the second element
	 * is the first token (without the delim's), the third element is plain
	 * text again and so on.
	 */
	private List<String> tokenize( String s ) {
		List<String> tokens = []
		int sIndex = 0
		while (true) {
			// Is there another '%('?
			int nextTokenStart = s.indexOf( '%(', sIndex )
			int nextTokenEnd = -1
			if (nextTokenStart >= sIndex) {
				nextTokenEnd = s.indexOf( ')%', nextTokenStart )
			}
			if (nextTokenEnd == -1) {
				// No more tokens found - return rest of string and done
				tokens << s.substring(sIndex)
				break
			} else {
				String plainText = ''
				if (nextTokenStart > sIndex) {
					plainText = s.substring( sIndex, nextTokenStart )
				}
				tokens << plainText
				
				tokens << s.substring( nextTokenStart + 2, nextTokenEnd )
				
				sIndex = nextTokenEnd + 2
			}
		}
		return tokens
	}
	
	/**
	 * Sets the Base Environment Name, which is the requested environment name without
	 * any suffix, such as for blue-green.  Note that this is inherited by the contexts -
	 * so if it isn't defined by a context, that context uses its parent context value.
	 */
	public void setBaseEnvironmentName( String name ) {
		_baseEnvironmentName = name
	}
	
	/**
	 * Returns the Base Environment Name, which is the requested environment name without
	 * any suffix, such as for blue-green.  If this context does not have a base
	 * environment name, then it searches its parent's for a value.  Returns empty
	 * string if not found at all.
	 */
	public String getBaseEnvironmentName() {
		if (_baseEnvironmentName) {
			return _baseEnvironmentName
		} else if (getParentContext()) {
			return getParentContext().getBaseEnvironmentName()
		} else {
			return ''
		}
	}
}
