package com.fanniemae.ucd.aws.provision.service.instance

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.ucd.aws.api.describeRecord.AwsDescribeRecordResult
import com.fanniemae.ucd.aws.provision.service.definition.AwsServiceDefinition
import com.ibm.css.ucd.environment.Environment

class ECSServiceInstance extends AwsServiceInstance {

	public ECSServiceInstance(AwsServiceDefinition awsServiceDefinition, AwsConnection awsConnection, String provisionedId, boolean newlyProvisioned) {
		super(awsServiceDefinition, awsConnection, provisionedId, newlyProvisioned)
	}

	@Override
	public String getServiceType() {
		return 'ECS'
	}
	
//	@Override
//	public void setUcdPropertiesAfterProvisioningComplete() {
//		super.setUcdPropertiesAfterProvisioningComplete()
//		
//		AwsDescribeRecordResult awsRecord = getAwsRecord()
//		getUcdEnvironments().each { Environment environment ->
//			setComponentEnvironmentProperty( getUcdComponent(), environment, 'awsLifeCycle', awsRecord.getRecordOutputProperty( 'Lifecycle' ) )
//			setComponentEnvironmentProperty( getUcdComponent(), environment, 'clusterName', awsRecord.getRecordOutputProperty( 'ClusterName' ) )
//		}
//
//	}

}
