package com.ibm.css.ucd.processrequest.filter

import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.processrequest.ProcessRequest;

/**
 * Filter Process Request records based on Application.
 * @author ltclark
 *
 */
class ProcessRequestApplicationFilter extends ProcessRequestFilter {
	Application application
	
	/**
	 * Constructor.
	 * @param userName The name of the user to filter on.
	 * @param caseSensitive Is the comparison of the user name case sensitive.
	 */
	public ProcessRequestApplicationFilter( Application application ) {
		this.application = application
	}
	
	@Override
	public Date getFilteringStartedAfter() {
		// There is no date filtering
		return null;
	}
	
	@Override
	public Application getFilteringApplication() {
		return application;
	}

	@Override
	public boolean includeRawRecordInFilter(Object rawRecord) {
		return rawRecord.application.id == this.application.id
	}
	
	@Override
	public boolean includeProcessRequestInFilter(ProcessRequest processRequest) {
		return true
	}

	@Override
	public String getDescription() {
		return "Application is named '${application.name}'"
	}

}
