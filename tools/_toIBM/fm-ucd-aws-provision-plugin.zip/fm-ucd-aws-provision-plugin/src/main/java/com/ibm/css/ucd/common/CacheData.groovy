package com.ibm.css.ucd.common

import com.ibm.issr.core.log.Logger


/**
 * An instance of the CacheData class is used to manage one cached variable.
 * The variable can be any data type.  The variable can be static or dynamic.
 * For example, it may be a cached list of all of the loaded Applications (which is static).  Or,
 * it may be the cached 'information' within one Application entity (which is not static).
 * <p/>
 * Managing the cache data in this class actually simplifies a lot of code, but it also
 * enables broad cache management.  For example, if you call CacheData.resetAllCacheData(),
 * all managed cached data (static and non-static) across all classes is automatically reset!!
 * <p/>
 * How does it work?  When cached data is set (via the setData() method), the time that the data was set is
 * stored.  When cached data is reset, the reset time is stored.  Then, when cached data is retrieved,
 * its time is compared to the last reset time.  If the data was stored before the reset time, then it
 * is reset and a null is returned.
 * @author LeonClark
 *
 */
class CacheData {
	
	private static long lastResetTimestamp = 0
	
	// the cache is considered to be empty if the data is null
	private def _data = null
	// The timestamp (milliseconds) when the cache data was last set
	private long timeStamp = 0
	
	// Information about the cached data
	private Class containingClass
	private boolean isStaticCacheData
	
	/**
	 * Constructor.  Information about the cache is provided so that it is possible to implement
	 * smart cache reseting.  For example, with this information, it would be possible to reset
	 * all non-static cached data in the 'Snapshot' class.
	 * @param containingClass This is the Class definition of the class containing the cached data,
	 * such as 'Snapshot.class'
	 * @param isStaticCacheData Is the cached data static data?  Normally static cached data caches
	 * the set of elements of the class type (such as the set of Snapshot entries).  Non-static cached
	 * data is generally information about one instance (such as one Snapshot entry).
	 */
	public CacheData( Class containingClass, boolean isStaticCacheData ) {
		this.containingClass = containingClass
		this.isStaticCacheData = isStaticCacheData
		
		Logger.debug "Called CacheData( containingClass='${containingClass.getName()}', isStaticCacheData=${isStaticCacheData} )"
	}
	
	
	/**
	 * Returns the handle to the cached data.  If this returns null, then
	 * the cache data has not been set or has been reset.  In either case, the
	 * cache data then needs to be set.  The general procedure is "def data = cache.getCacheData(); if (data==null) {
	 * data = cache.setCacheData( createNewData() ) }" and then use/refine the data.
	 * @param resetCache If true, force a reset of the cached data.
	 */
	public def getCacheData( boolean resetCache = false ) {
		// reset the cache if requested of if a global reset occured after the data was cached.
		if (resetCache || (timeStamp < lastResetTimestamp)) {
			clearCacheData()
		}
		return _data
	}
	
	
	/**
	 * Forces a reset of the cached data (back to empty).
	 */
	public void clearCacheData() {
		_data = null
		Logger.debug "CacheData.clearData() called for class ${containingClass.name}"
	}
	
	
	/**
	 * Sets the cached data to the value.
	 * @param data The value of the cached data.
	 * @return Returns the cached data (as a convenience).
	 */
	public def setCacheData( def data ) {
		_data = data
		timeStamp = (new Date()).getTime()
		Logger.debug "CacheData.setCacheData() called for class ${containingClass.name}"
		return _data
	}

	/**
	 * Resets all cached data.
	 */
	public static void resetAllCacheData() {
		lastResetTimestamp = (new Date()).getTime()
	}
}
