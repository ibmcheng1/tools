package com.ibm.css.ucd.resource

import java.util.List;

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.resource.ResourceApi

/**
 * This represents ANY type of non-root node in the resource tree.  Note that
 * non-root nodes have a parent.
 * @author ltclark
 *
 */
abstract class NonRootResourceNode extends ResourceNode {
	protected ResourceNode parentNode
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the UCD Server.
	 * @param parentNode The parent node to this node.
	 * @param nodeName The name of this node, such as "DEV"
	 * @param nodeId The ID of this node
	 */
	public NonRootResourceNode( UcdServerConnection ucdServer, ResourceNode parentNode, String nodeName, String nodeId ) {
		super( ucdServer, nodeName, nodeId )
		this.parentNode = parentNode
	}
	
	@Override
	public String getResourcePath() {
		if (parentNode) {
			return parentNode.getResourcePath() + "/" + getName()
		} else {
			return "/" + getName()
		}
	}
	
	@Override
	public List getTags() {
		List retval = null
		Map info = ResourceApi.getInfo(ucdServer, id)
		if (info.containsKey('tags')) {
			info.tags.each { def tagEntry ->
				if (! retval) {
					retval = []
				}
				retval << tagEntry.name
			}
		}
		return retval
	}

	@Override
	public ResourceNode getParent() {
		return parentNode;
	}
	
	@Override
	public boolean areTeamsInherited() {
		Map info = ResourceApi.getInfo(ucdServer, id)
		if (info.containsKey('inheritTeam')) {
			return info.inheritTeam
		} else {
			return false
		}
	}

	@Override
	public void addTag(String name) {
		ResourceApi.addTag(ucdServer, this.getId(), name)
	}
	
	public void setProperty( String name, String value ) {
		ResourceApi.setProperty( ucdServer, id, name, value )
	}
	
	@Override
	public List getProperties() {
		return ResourceApi.getProperties(ucdServer, this.getId() )
	}

	
}
