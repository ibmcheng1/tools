package com.fanniemae.ucd.aws.provision.def.productmap

import com.ibm.issr.core.json.JsonHelper

/**
 * Wrapper class around the input awsProductIds field.
 */
class AwsLogicalProductMap {
	private List _productMap

	/**
	 * Constructor.
	 * @param awsProductIds The product id mapping table in JSON format with comment line support.
	 * <pre>
	 *	[
	 *		{"object":"RDS",
	 *		"prodId":"prod-b2z72fyekkj3o"
	 *		},
	 *		{"object":"RDS",
	 *		"prodId":"prod-b2z72fyekkj3o",
	 *		"environmentType":"DEVL"
	 *		},
	 *		{"object":"EB",
	 *		"prodId":"prod-6ruu2gdnu6imc"
	 *		}
	 *	]
	 * </pre>
	 * <p>If an environmentType is not given, then it is the default map for
	 * all environments.  If an environmentType is given, than that map is
	 * used for the corresponding environment.</p>
	 */
	public AwsLogicalProductMap( String awsProductIds ) {
		String jsonStringWithoutComments = JsonHelper.removeCommentLines(awsProductIds)
		_productMap = new groovy.json.JsonSlurper().parseText( jsonStringWithoutComments )
	}
	
	/**
	 * Returns the AWS Product ID to use for the given logical name or null if no map found.
	 * @param logicalName The logical service name, such as 'RDS' or 'EB'.
	 * @param environmentType The target environment type, such as 'DEVL'.
	 */
	public String getAwsProductId( String logicalName, String environmentType ) {
		String genericMatch = null
		String environmentMatch = null
		_productMap.each { Map productEntry ->
			if (productEntry.object.equalsIgnoreCase(logicalName)) {
				if (productEntry.containsKey('environmentType')) {
					if (environmentType.equalsIgnoreCase(productEntry.environmentType)) {
						environmentMatch = productEntry.prodId
					}
				} else {
					genericMatch = productEntry.prodId
				}
			}
		}
		if (environmentMatch) {
			return environmentMatch
		} else {
			return genericMatch
		}
	}
}
