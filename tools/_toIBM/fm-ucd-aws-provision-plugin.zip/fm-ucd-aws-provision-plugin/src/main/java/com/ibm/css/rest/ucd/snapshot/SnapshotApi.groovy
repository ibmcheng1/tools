package com.ibm.css.rest.ucd.snapshot

import groovy.json.JsonOutput

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.component.version.ComponentVersionApi
import com.ibm.css.ucd.snapshot.Snapshot
import com.ibm.issr.core.log.Logger
import com.ibm.issr.rest.RestDelete
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPut
import com.ibm.issr.rest.RestResponse

/**
 * UCD Snapshot API calls.
 * @author ltclark
 *
 */
class SnapshotApi {
	/**
	 * Deletes the designated snapshot throwing an error if there is any problem, such as
	 * the snapshot doesn't exist.
	 * @param ucdServer The handle to the UCD server.
	 * @param applicationName The UCD Application Name containing the snapshot.
	 * @param snapshotName The name of the snapshot.
	 */
	public static void deleteSnapshot( UcdServerConnection ucdServer, String applicationName, String snapshotName ) {
		
		(new RestDelete( ucdServer )).setPath("/cli/snapshot/deleteSnapshot")
			.addParameter("snapshot", snapshotName)
			.addParameter("application", applicationName)
			.deleteWithNoReturnObject()
	}
	
	/**
	 * Deletes the designated snapshot throwing an error if there is any problem, such as
	 * the snapshot doesn't exist.
	 * @param ucdServer The handle to the UCD server.
	 * @param snapshotId The ID of the snapshot to delete.
	 */
	public static void deleteSnapshotById( UcdServerConnection ucdServer, String snapshotId ) {
		
		(new RestDelete( ucdServer )).setPath("/cli/snapshot/deleteSnapshot")
			.addParameter("snapshot", snapshotId)
			.deleteWithNoReturnObject()
	}

	
	/**
	 * Does the snapshot exist?  Returns true or false.
	 * @param ucdServer The handle to the UCD server.
	 * @param applicationName The UCD Application Name or ID containing the snapshot.
	 * @param snapshotName The name of the snapshot.
	 */
	public static boolean doesSnapshotExist( UcdServerConnection ucdServer, String applicationNameOrId, String snapshotName ) {
		return (new RestGet( ucdServer )).setPath("/cli/snapshot/getSnapshot")
			.addParameter("snapshot", snapshotName)
			.addParameter("application", applicationNameOrId)
			.get() { RestResponse response ->
			if (response.httpStatus==404 || response.httpStatus==500 || response.httpStatus==400) {
				// The requested entity doesn't exist
				Logger.debug "Snapshot not found"
				return false
			} else {
				Logger.debug "Snapshot found"
				response.throwExceptionOnBadResponse()
				return true
			}
		}
	}

	
	/**
	 * Create a new snapshot.
	 * @param ucdServer Handle to the UCD Server.
	 * @param applicationId The ID of the application to add the snapshot to.
	 * @param snapshotName The name of the new snapshot.
	 * @param snapshotDescription The description of the new snapshot.
	 * @return Returns the ID of the new snapshot.
	 */
	public static String createSnapshot( UcdServerConnection ucdServer, String applicationId, String snapshotName, String snapshotDescription ) {
		def payload = [
			application: applicationId,
			name: snapshotName,
			description: snapshotDescription
		]
		def responseObject = (new RestPut( ucdServer )).setPath("/cli/snapshot/createSnapshot")
				.setJsonPayloadToObject(payload)
				.putAsObject()
		return responseObject.id
	}
	
	
	/**
	 * Adds a component version to a snapshot.
	 * @param ucdServer Handle to UCD server
	 * @param snapshotId The ID of the existing snapshot.
	 * @param componentName The NAME of the component
	 * @param versionId The ID of the version of the component.
	 */
	public static void addVersionToSnapshot( UcdServerConnection ucdServer, String snapshotId, String componentName, String versionId ) {
		def responseObject = (new RestPut( ucdServer )).setPath("/cli/snapshot/addVersionToSnapshot")
		.addParameter('snapshot', snapshotId).addParameter('component', componentName).addParameter('version', versionId)
		.putWithNoReturnObject()
	}
	
	/**
	 * Returns information about a snapshot from the name of the snapshot.
	 * @param ucdServer Handle to the UCD Server.
	 * @param applicationId The ID of the application to add the snapshot to.
	 * @param snapshotName The name of the snapshot.
	 * @return Returns the data structure that is return from the REST /cli/snapshot/getSnapshot API call.
	 * In particular, the 'id' field is the ID of the snapshot.
	 */
	public static def getSnapshotInfoFromName( UcdServerConnection ucdServer, String applicationId, String snapshotName ) {
		return (new RestGet( ucdServer )).setPath("/cli/snapshot/getSnapshot")
		.addParameter("snapshot", snapshotName )
		.addParameter("application", applicationId )
		.getAsObject()

	}
	
	/**
	 * Returns information about a snapshot from the id of the snapshot.
	 * @param ucdServer Handle to the UCD Server.
	 * @param snapshotId The id of the snapshot.
	 * @return Returns the data structure that is return from the REST /cli/snapshot/getSnapshot API call.
	 * In particular, the 'id' field is the ID of the snapshot.
	 */
	public static def getSnapshotInfoFromId( UcdServerConnection ucdServer, String snapshotId ) {
		return (new RestGet( ucdServer )).setPath("/cli/snapshot/getSnapshot")
		.addParameter("snapshot", snapshotId )
		.getAsObject()
	}

	/**
	 * Returns an Environment Entity for the named application.
	 * @param ucdServer Handle to the UCD Server.
	 * @param applicationId The ID of the application that the environment is in.
	 * @param snapshotName The name of the snapshot.
	 */
	public static Snapshot getSnapshotEntityFromName( UcdServerConnection ucdServer, String applicationId, String snapshotName ) {
		return new Snapshot( ucdServer, getSnapshotInfoFromName(ucdServer, applicationId, snapshotName ))
	}
	
	/**
	 * Returns an Environment Entity for the named application.
	 * @param ucdServer Handle to the UCD Server.
	 * @param snapshotId The id of the snapshot.
	 */
	public static Snapshot getSnapshotEntityFromId( UcdServerConnection ucdServer, String snapshotId ) {
		return new Snapshot( ucdServer, getSnapshotInfoFromId(ucdServer, snapshotId ))
	}

	/**
	 * Returns the ID of the named snapshot.
	 * @param ucdServer Handle to the UCD Server.
	 * @param applicationId The ID of the application to add the snapshot to.
	 * @param snapshotName The name of the new snapshot.
	 */
	public static String getSnapshotId( UcdServerConnection ucdServer, String applicationId, String snapshotName ) {
		def snapshot = getSnapshotInfoFromName(ucdServer, applicationId, snapshotName)
		return snapshot.id
	}

	/**
	 * Returns a list of the components and component versions that are in the snapshot.
	 * @param ucdServer Handle to the UCD Server.
	 * @param snapshotId The ID if the snapshot.
	 * @return This returns the data structure that is returned by the 'Get the list of versions in a snapshot'
	 * CLI Rest call (cli/snapshot/getSnapshotVersions) call.  In particular, it is an array of component records.
	 * The component record includes the fields id and name (component's id and name) and 'desiredVersions'.
	 * desiredVersions is an array of the desired versions.  Each entry in desiredVersions includes name and id
	 * which is the name and id of the version.
	 */
	public static List getComponentsAndVersionsInSnapshot( UcdServerConnection ucdServer, String snapshotId ) {
		List retval = (new RestGet( ucdServer )).setPath("/cli/snapshot/getSnapshotVersions")
		.addParameter("snapshot", snapshotId)
		.getAsObject()
		return retval
	}
	
	
	/**
	 * Get the list of Component Version Flags for the snapshot.  Specifically, this
	 * returns the list of Component Versions in the snapshot and the Component Version Status flags
	 * for each.
	 * @param ucdServer Handle to the UCD Server.
	 * @param snapshotId The ID if the snapshot.
	 * @return Returns a list of ... Component Entries, where each component entry has
	 * a 'name', 'id' and 'desiredVersions'.  'desiredVersions' is a List of the desired Component
	 * Versions in the snapshot with the fields: 'name', 'id' and 'flags'.  'flags' is the
	 * List of flag names (the List contains String entries).
	 */
	public static List getComponentVersionFlagsForSnapshot(UcdServerConnection ucdServer,String snapshotId) {
		List retval = []
		Logger.debug "getComponentVersionFlagsForSnapshot( snapshotId='${snapshotId}' )"
		Logger.incrementIndentationForCodeBlock {
		
			// Get the list of components and versions that are in the snapshot
			List componentAndVersions = SnapshotApi.getComponentsAndVersionsInSnapshot(ucdServer, snapshotId)
			Logger.debug "Components and Versions: " + JsonOutput.toJson( componentAndVersions )
	
			// Iterate components and versions and get statuses building out return structure
			componentAndVersions.each { sourceComponent ->
				Map component = [ id : sourceComponent.id, name:sourceComponent.name]
				component.desiredVersions = []
				sourceComponent.desiredVersions.each { sourceComponentVersion ->
					Map componentVersion = [ id:sourceComponentVersion.id, name:sourceComponentVersion.name]
					componentVersion.flags = []
					List componentVersionFlags = ComponentVersionApi.getComponentVersionFlags(ucdServer, sourceComponentVersion.id)
					componentVersionFlags.each { flagRecord ->
						componentVersion.flags << flagRecord.name
					}
					component.desiredVersions << componentVersion
				}
				retval << component
			}
			Logger.debug "Components and Versions and flags: " + JsonOutput.toJson( retval )
		}
		return retval
	}
	
	
	/**
	 * Sets the Component Version Flag named by the flagName parameter for each Component
	 * Version member of the snapshot.
	 * @param ucdServer Handle to the UCD Server.
	 * @param snapshotId The ID if the snapshot.
	 * @param flagName The name of the flag to set.
	 */
	public static void setComponentVersionFlagForSnapshot(UcdServerConnection ucdServer,String snapshotId, String flagName ) {
		Logger.debug "setComponentVersionFlagsForSnapshot( snapshotId='${snapshotId}', flag='${flagName}' )"
		Logger.incrementIndentationForCodeBlock {
		
			// Get the list of components and versions that are in the snapshot
			List componentAndVersions = SnapshotApi.getComponentsAndVersionsInSnapshot(ucdServer, snapshotId)
			Logger.debug "Components and Versions: " + JsonOutput.toJson( componentAndVersions )
	
			// Iterate components and versions in order to set the flag
			componentAndVersions.each { component ->
				component.desiredVersions.each { componentVersion ->
					ComponentVersionApi.setComponentVersionFlag(ucdServer, componentVersion.id, flagName)
				}
			}
		}
	}

	
	/**
	 * Removes the Component Version Flag named by the flagName parameter for each Component
	 * Version member of the snapshot.
	 * @param ucdServer Handle to the UCD Server.
	 * @param snapshotId The ID if the snapshot.
	 * @param flagName The name of the flag to set.
	 */
	public static void removeComponentVersionFlagForSnapshot(UcdServerConnection ucdServer,String snapshotId, String flagName ) {
		Logger.debug "removeComponentVersionFlagsForSnapshot( snapshotId='${snapshotId}', flag='${flagName}' )"
		Logger.incrementIndentationForCodeBlock {
		
			// Get the list of components and versions that are in the snapshot
			List componentAndVersions = SnapshotApi.getComponentsAndVersionsInSnapshot(ucdServer, snapshotId)
			Logger.debug "Components and Versions: " + JsonOutput.toJson( componentAndVersions )
	
			// Iterate components and versions in order to set the flag
			componentAndVersions.each { component ->
				component.desiredVersions.each { componentVersion ->
					ComponentVersionApi.removeComponentVersionFlag(ucdServer, componentVersion.id, flagName)
				}
			}
		}
	}

	/**
	 * Returns a list of snapshots that are defined for an application.
	 * @param ucdServer Handle to the UCD Server.
	 * @param applicationId The ID of the UCD Application.
	 * @return The list returned from the API call to '/cli/application/snapshotsInApplication'.  At a minimum, each entry contains a 'name' and 'id' field.
	 */
	public static List getSnapshotsInApplication( UcdServerConnection ucdServer, String applicationId) {
		List retval = (new RestGet( ucdServer )).setPath("/cli/application/snapshotsInApplication")
		.addParameter("application", applicationId)
		.getAsObject()
		return retval
	}
	
	/**
	 * Returns the list of Snapshot Versions for a given snapshot.
	 * @param ucdServer Handle to the UCD Server.
	 * @param snapshotId The ID of the snapshot.
	 * @return The list returned from the API call to '/cli/snapshot/getStatusList'.  At a minimum, each entry contains a 'name' and 'id' field.
	 */
	public static List getSnapshotStatusList( UcdServerConnection ucdServer, String snapshotId) {
		List retval = (new RestGet( ucdServer )).setPath("/cli/snapshot/getStatusList")
		.addParameter("snapshot", snapshotId)
		.getAsObject()
		return retval
	}
	
	/**
	 * Adds the given snapshot status to the snapshot.
	 * @param ucdServer Handle to UCD Server.
	 * @param snapshotId The ID of the snapshot.
	 * @param snapshotStatusId The ID of the snapshot status to add.
	 */
	public static void addSnapshotStatus( UcdServerConnection ucdServer, String snapshotId, String snapshotStatusId ) {
		def responseObject = (new RestPut( ucdServer )).setPath("/cli/snapshot/addStatusToSnapshot")
			.addParameter('snapshot', snapshotId).addParameter('statusName', snapshotStatusId)
			.putWithNoReturnObject()

	}
}
