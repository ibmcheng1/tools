package com.ibm.css.ucd.services

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.component.ComponentApi
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.ComponentBuilderDefinition
import com.ibm.css.ucd.componenttemplate.ComponentTemplate
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPut

/**
 * Manage and access Component entities.
 * @author ltclark
 *
 */
class ComponentServices {
	private UcdServerConnection ucdServer
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the server.
	 */
	public ComponentServices( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
	}

	/**
	 * Returns the named Component.  Throws exception if not found.
	 * @param componentName The name of the component.
	 */
	public Component getComponent( String componentName ) {
		return ComponentApi.getComponentEntityFromName(ucdServer, componentName)
	}
	
	/**
	 * Is there a component with this name?
	 */
	public boolean doesComponentExist( String componentName ) {
		return (new RestGet( ucdServer )).setPath("/cli/component/info")
			.addParameter("component", componentName)
			.getAsExistenceTest()
	}
	
	/**
	 * Returns the Component given its ID.  Throws exception on error.
	 */
	public Component getComponentFromId( String componentId ) {
		return ComponentApi.getComponentEntityFromId(ucdServer, componentId)
	}

	/**
	 * Returns the List of ALL active components on the server.  The data
	 * type of each entry in the List is Component.  This is deprecated and you 
	 * should use getComponents() instead.
	 */
	@Deprecated
	public List getAllComponents() {
		return ComponentApi.getAllComponents(ucdServer)
	}
	
	/**
	 * Returns the List of ALL active components on the server.  The data
	 * type of each entry in the List is Component.
	 */
	public List getComponents() {
		return ComponentApi.getAllComponents(ucdServer)
	}

	/**
	 * Returns a List of all ComponentTemplates.  Each member of the list is of type 'ComponentTemplate'.
	 */
	public List getComponentTemplates() {
		List componentTemplates = []
		List componentTemplateList = (new RestGet( ucdServer )).setPath("/cli/componentTemplate")
			.getAsObject()
		componentTemplateList.each { Map entry ->
			componentTemplates << ComponentTemplate.getComponentTemplateWithCache( ucdServer, entry.name, entry.id )
		}
		return componentTemplates
	}

	/**
	 * Returns the named Component Template.  Throws exception if not found.
	 * @param name The name of the component template.
	 */
	public ComponentTemplate getComponentTemplate( String name ) {
		ComponentTemplate componentTemplate = getComponentTemplates().find { ComponentTemplate member ->
			return (member.name == name)
		}
		if (! componentTemplate) {
			throw new Exception( "Unable to find ComponentTemplate named '${name}'" )
		}
		return componentTemplate
	}
	
	/**
	 * Creates a new component (stand-alone or template based) using a DSL Closure.  The DSL closure is used
	 * to define the data for the new Component.  See the class
	 * {@link com.ibm.css.ucd.component.ComponentBuilderDefinition ComponentBuilderDefinition} for the syntax
	 * within te closure.
	 * <pre>
	 * 	ucdConnectionServices.getComponentServices().createComponent( "sample name" ) {
	 *		setDescription "Automatically generated"
	 *		setComponentTemplate componentTemplate
	 *		addTemplateDefinedProperty "sampleProperty", "sample property value"
	 *		addTemplateDefinedProperty "sampleCheckbox", true
	 *	}
	 * </pre>
	 * @param name The name of the new Component.
	 * @param builderDsl This is a closure used to define the input data for the new Component.  Function calls
	 * within this closure automatically call an instance (via delegate) of the class 
	 * {@link com.ibm.css.ucd.component.ComponentBuilderDefinition ComponentBuilderDefinition}.
	 * @return Returns the new Component or throws an exception if there is a problem, such as the name is already
	 * used for an existing component.
	 */
	public Component createComponent( String name, Closure builderDsl ) {
		// Create a new definition class
		ComponentBuilderDefinition definition = new ComponentBuilderDefinition( name )
		builderDsl.delegate = definition
		builderDsl()
		
		// Build the payload map/json for the new component
		Map payload = [name:definition.name]
		if (definition.cleanupCountToKeep) {
			payload.cleanupCountToKeep = definition.cleanupCountToKeep
		}
		if (definition.cleanupDaysToKeep) {
			payload.cleanupDaysToKeep = definition.cleanupDaysToKeep
		}
		payload.defaultVersionType = definition.defaultVersionType
		if (definition.description) {
			payload.description = definition.description
		}
		payload.importAutomatically = definition.importAutomatically.toString()
		if (definition.componentTemplate) {
			payload.templateId = definition.componentTemplate.id
			definition.templateDefinedProperties.each { String propertyName, def propertyValue ->
				payload.put("template/" + propertyName, propertyValue.toString())
			}
		}
		
		def componentEntity = (new RestPut( ucdServer )).setPath("/cli/component/create")
			.setJsonPayloadToObject(payload)
			.putAsObject()

		return Component.getComponentWithCache(ucdServer, componentEntity.name, componentEntity.id)
	}
}
