

package com.ibm.css.ucd.component.version.addfiles

import com.ibm.issr.core.file.filter.FilterFiles


/**
 * Defines definition/DSL options for the 
 * {@link com.ibm.css.ucd.component.version.ComponentVersion#addFiles(groovy.lang.Closure) ComponentVersion.addFiles()}
 * method.  The functions in this class can be called from the closure parameter to addFiles() using the built in 'delegate'
 * object (which behaves like 'this').
 * @author LeonClark
 *
 */
class AddFilesDefinition {
	/**
	 * This is a list.  Each entry is a mapped set of field values with the following fields.
	 * <ul>
	 * <li>String directoryName - The directory name (as passed to {@link #baseDirectory(String, Closure) baseDirectory()} function)</li>
	 * <li>{@link BaseDirectoryDefinition BaseDirectoryDefinition} baseDirectoryDefinition - The nested definition of the base directory.</li>
	 * <li>{@link com.ibm.issr.core.file.filter.FilterFiles FilterFiles} filterFiles - The class that performs the filtering, which is also
	 * used to store the filter criteria (includes and excludes).
	 * </ul>
	 */
	List _baseDirectoryDefinitions = []
	
	/**
	 * Adds a base directory to the '{@link com.ibm.css.ucd.component.version.ComponentVersion#addFiles(groovy.lang.Closure) ComponentVersion.addFiles()}'
	 * closure.  See the documentation on addFiles() for an overview.
	 * @param String directoryName This is the folder that the nested Closure uses as the base directory.  This directory name may be
	 * absolute or relative to the currently active directory.
	 * @param defineFiles This is a nested closure.  The DSL 'delegate' (which is sort of like 'this') for the Closure is
	 * {@link com.ibm.css.ucd.component.version.addfiles.BaseDirectoryDefinition BaseDirectoryDefinition}.
	 */
	public void baseDirectory( String directoryName, Closure defineFiles ) {
		FilterFiles filterFiles = new FilterFiles( directoryName )
		Map baseDirectoryDefinition = [directoryName:directoryName, baseDirectoryDefinition: new BaseDirectoryDefinition(filterFiles), filterFiles: filterFiles]
		
		// Call the closure with a delegate to support the nested DSL and collect the nested DSL information
		defineFiles.delegate = baseDirectoryDefinition.baseDirectoryDefinition
		
		defineFiles()
		
		_baseDirectoryDefinitions << baseDirectoryDefinition
	}
	
	/**
	 * Returns the list of This is a list.  Each entry is a mapped set of field values with the following fields.
	 * <ul>
	 * <li>String directoryName - The directory name (as passed to {@link #baseDirectory(String, Closure) baseDirectory()} function)</li>
	 * <li>{@link BaseDirectoryDefinition BaseDirectoryDefinition} baseDirectoryDefinition - The nested definition of the base directory.</li>
	 * <li>{@link com.ibm.issr.core.file.filter.FilterFiles FilterFiles} filterFiles - The class that performs the filtering, which is also
	 * used to store the filter criteria (includes and excludes).
	 * </ul>
	 */
	public List getBaseDirectoryDefinitions() {
		return _baseDirectoryDefinitions
	}
}
