package com.ibm.issr.rest

import org.apache.http.HttpResponse
import org.apache.http.client.methods.HttpGet

import com.ibm.issr.core.log.Logger;

/**
 * This is an abstraction of a REST GET call to be used in conjunction with the RestClient class.
 * @author ltclark
 *
 */
class RestGet extends RestOperation {
	private HttpGet method
	
	/**
	 * Constructor
	 * @param restClient The associated Rest Client connection.
	 */
	public RestGet( RestServerConnection restClient ) {
		super( restClient, "Get", new HttpGet() )
		method = super.requestMethod
	}
	
	/**
	 * Adds a set of parameters by providing one map.
	 * @param paramMap This is a map of parameter values as a groovy map, such as [a:"vala",b:"valb"].
	 * @return Return 'this'
	 */
	public RestGet addParameters( def paramMap ) {
		for (mapEntry in paramMap) {
			parameters.add( [key:mapEntry.key, value:mapEntry.value]);
		}
		return this;
	}
	
	/**
	 * Adds one parameter key/value pair.  Note
	 * @param key The key.
	 * @param value The string value.
	 * @return Returns 'this'
	 */
	public RestGet addParameter( String key, String value ) {
		parameters.add( [key:key,value:value] )
		return this
	}
	
	/**
	 * Calls a closure passing 'this' as a parameter and then returns 'this'.
	 * This allows for adding custom code to a parent.proc1().proc2().callClosure().proc3() style
	 * of sequential calls.  This was added to support a common filter capability.
	 * @param closure  The closure.  Syntax: void closure( RestGet restGet ).  It is passed 'this'
	 * as the parameter.
	 * @return 'this'
	 */
	public RestGet callClosure( Closure closure ) {
		closure(this)
		return this
	}

	/**
	 * Sets the path of the rest call, such as "/rest/sample/call".  Doe NOT
	 * pass server information.
	 * @param path The path of the call.  Do NOT include parameters.
	 * @return Return 'this'.
	 */
	public RestGet setPath( String path ) {
		this._path = path;
		return this;
	}

	/**
	 * Performs the get
	 * @param processResponse This is called with the RestResponse as the one
	 * parameter.  It should process the response, such as { response.throwExceptionOnBadResponse(); return response.getResponseAsObject() }.
	 * The response is automatically closed after this closure is called.
	 * @return Returns the value returned by the closure.
	 */
	public def get( Closure processResponse ) {
		// Build the full url
		method.setURI( new URI(this.fullUrl) );
		Logger.debug("RestGet.get('${this.fullUrl}')" + ", RestServerConnection: " + restClient)
		response = restClient.client.execute(method)
		RestResponse response = new RestResponse( this, response )
		try {
			return processResponse( response )	
		}
		finally {
			response.close()
			method.releaseConnection()
		}
	}
	
	/**
	 * Performs a get, throws exception on any HTTP return code other than OK and then
	 * returns the JSON result string as an Object tree.
	 * @return The JSON result string as an Object tree.
	 */
	public def getAsObject() {
		return get() { RestResponse response ->
			if (response) {
				response.throwExceptionOnBadResponse()
				return response.responseAsObject
			} else {
				return null
			}
		}
	}
	
	/**
	 * Performs a get, throwing exception on bad HTTP status reutrn.  Then converts
	 * the returned data into a List and returns the first element in the List.
	 * Throws exception if unable to complete (not a list, empty list, etc).
	 */
	public def getFirstElementInListAsObject() {
		return get() { RestResponse response ->
			boolean success = false
			if (response) {
				response.throwExceptionOnBadResponse()
				List entityList = response.responseAsObject
				if (entityList.size() > 0) {
					success = true
					return entityList[0]
				}
			}
			if (! success) {
				throw new Exception( "No matching record found")
			}
		}
	}
	
	/**
	 * Performs a get, returning a null if the list is empty.  
	 * If an element is found, then converts
	 * the returned data into a List and returns the first element in the List.
	 * Throws exception if there are any other errors.
	 */
	public def getFirstElementInListAsObjectOrNull() {
		return get() { RestResponse response ->
			boolean success = false
			if (response) {
				response.throwExceptionOnBadResponse()
				List entityList = response.responseAsObject
				if (entityList.size() > 0) {
					success = true
					return entityList[0]
				}
			}
			if (! success) {
				return null
			}
		}
	}

	/**
	 * Performs a get.  Returns null if the get returns 'not found'.  Throw
	 * exception on other errors.
	 * returns the JSON result string as an Object tree.
	 * @return The JSON result string as an Object tree.
	 */
	public def getAsObjectOrNull() {
		return get() { RestResponse response ->
			if (response) {
				if (response.httpStatus==404 || response.httpStatus==500) {
					return null
				} else {
					response.throwExceptionOnBadResponse()
					return response.responseAsObject
				}
			} else {
				return null
			}
		}
	}

	/**
	 * Performs a get, throws exception on any HTTP return code other than OK and then
	 * returns the response as a simple string.
	 * @return The string value of the response.
	 */
	public def getAsString() {
		return get() { RestResponse response ->
			if (response) {
				response.throwExceptionOnBadResponse()
				return response.responseAsString
			} else {
				throw new Exception ("Rest call failed")
			}
		}

	}
	
	/**
	 * Performs a get, throws exception on any HTTP return code other than OK and then
	 * writes the body/entity of the response to the outputStream.
	 */
	public void getToOutputStream( OutputStream outputStream ) {
		get() { RestResponse response ->
			if (response) {
				response.throwExceptionOnBadResponse()
				response.writeToOutputStream(outputStream)
			} else {
				throw new Exception ("Rest call failed")
			}
		}

	}


	/**
	 * Performs a get, throws exception on any HTTP return code other than OK.  This ignores
	 * any body returned by the REST call (if there is any body returned).
	 */
	public void getWithNoReturnObject() {
		get() { RestResponse response ->
			response.throwExceptionOnBadResponse()
		}
	}
	
	/**
	 * Performs a get against a specific entity, such as a user, which may or may not exist.
	 * This returns true if the entity exists (such as an SC_OK response) or false if the
	 * entity doesn't exist.
	 */
	public boolean getAsExistenceTest() {
		// Note that HTTP Get's should a code like 404 for a missing entity, but UCD seems to return 500 (undefined internal error).
		// This code checks for either
		get() { RestResponse response ->
			if (response.httpStatus==404 || response.httpStatus==500) {
				// The requested entity doesn't exist
				return false
			} else {
				response.throwExceptionOnBadResponse()
				return true
			}
		}
	}
}
