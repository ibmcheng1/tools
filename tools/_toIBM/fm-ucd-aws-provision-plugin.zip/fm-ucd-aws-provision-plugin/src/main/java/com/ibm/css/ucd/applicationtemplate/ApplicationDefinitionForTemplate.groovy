package com.ibm.css.ucd.applicationtemplate

import com.ibm.css.ucd.component.Component

class ApplicationDefinitionForTemplate {
	String name
	String description
	// List of 'Component' entries
	List components = []
	// List of Template properties.  Each entry is a structured map with 'name' and 'value'.
	List templateProperties = []

	/**
	 * Constructor
	 * @param name The name of the new Application.
	 */
	public ApplicationDefinitionForTemplate( String name ) {
		this.name = name
	}

	public ApplicationDefinitionForTemplate description( String description ) {
		this.description = description
		return this
	}

	public ApplicationDefinitionForTemplate addComponent( Component component ) {
		components << component
		return this
	}
	
	/**
	 * Defines a name for a Template property.  Note that this capability was added to
	 * UCD 7.0.3.1.  Don't call this for older versions of UCD.  Unfortunately, there
	 * is no way to determine if this version/patch of UCD is installed, so it
	 * is up to you to only call this function if the patch if available.  Note that if
	 * you call this with an older version of UCD, no error is triggered, but the property
	 * is simply not set!!
	 */
	public void addTemplateProperty( String name, def value ) {
		templateProperties << [name:name, value:value]
	}
}
