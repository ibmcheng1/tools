package com.ibm.css.ucd.agent

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.common.EntityWithNameAndId

/**
 * Base class for Agent and AgentPool classes.
 * @author s9ulcc
 *
 */
class AgentOrAgentPool extends EntityWithNameAndId {
	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 */
	public AgentOrAgentPool( UcdServerConnection ucdServer, String name, String id ) {
		super( ucdServer, name, id )
	}
}
