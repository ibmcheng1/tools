package com.ibm.css.rest.ucd.component

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.component.Component
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPut


/**
 * 'Component' APIs
 * @author ltclark
 *
 */
class ComponentApi {
	
	/**
	 * Runs the component version importer for the given component.
	 * @param ucdServer Handle to a UCD Server Session.
	 * @param componentId The ID of the component
	 */
	public static void importComponentVersions( UcdServerConnection ucdServer, String componentId ) {
		def payload = 
			[
				component: componentId
			]
		
		def jsonBuilder = new groovy.json.JsonBuilder()
		jsonBuilder payload
		String payloadString = jsonBuilder.toString()

		(new RestPut( ucdServer )).setPath("/cli/component/integrate")
			.setPayload(payloadString)
			.putWithNoReturnObject()
	}

		/**
	 * Returns the internal ID of the named UCD Component.  Throws exception if not found.
	 * @param ucdServer Handle to a UCD Server Session.
	 * @param componentName The name of the component.
	 * @return The internal ID of the component
	 */
	public static String getComponentVersionIdForName( UcdServerConnection ucdServer, String componentName ) {
		return (new RestGet( ucdServer )).setPath("/cli/component/info")
		.addParameter("component", componentName)
		.getAsObject().id
	}
	
	/**
	 * Returns the '/cli/component/info' information for a Component.  Throws exception if not found.
	 * @param ucdServer Handle to a UCD Server Session.
	 * @param nameOrId The name or id of the component.
	 * @return The info returned by /cli/component/info (mapped to objects).
	 */
	public static def getComponentInfo( UcdServerConnection ucdServer, String nameOrId ) {
		return (new RestGet( ucdServer )).setPath("/cli/component/info")
		.addParameter("component", nameOrId)
		.getAsObject()
	}

	/**
	 * Returns a Component entity for the named component.  Throws exception if not found.
	 * @param ucdServer Handle to the UCD Server.
	 * @param name The name of the component.
	 * @return
	 */
	public static Component getComponentEntityFromName( UcdServerConnection ucdServer, String name ) {
		return new Component( ucdServer, getComponentInfo(ucdServer,name))
	}
	
	/**
	 * Returns a Component entity for the named component.  Throws exception if not found.
	 * @param ucdServer Handle to the UCD Server.
	 * @param id The id of the component.
	 * @return
	 */
	public static Component getComponentEntityFromId( UcdServerConnection ucdServer, String id ) {
		return new Component( ucdServer, getComponentInfo(ucdServer,id))
	}

	
	/**
	 * Returns a List of all active Components on the server.  Each List member
	 * is typed as Component.
	 * @param ucdServer Handle to the UCD Server
	 */
	public static List getAllComponents( UcdServerConnection ucdServer ) {
		List components = []
		List componentList = (new RestGet( ucdServer )).setPath("/cli/component")
			.getAsObject()
		componentList.each { Map entry ->
			components << Component.getComponentWithCache( ucdServer, entry.name, entry.id )
		}
		return components
	}
	
	
	/**
	 * Does the component have the named property?  Note that the property may be defined by the
	 * component's template (managed) or may be defined within the property (unmanaged).
	 * @param ucdServer UCD Session handle
	 * @param componentId The ID of the component
	 * @param propertyName The name of the property.
	 */
	public static boolean hasProperty( UcdServerConnection ucdServer, String componentId, String propertyName ) {
		boolean found = false
		
		def componentInfo = (new RestGet( ucdServer )).setPath("/cli/component/info")
		.addParameter("component", componentId)
		.getAsObject()

		// Iterate properties looking for the desired property
		componentInfo.properties.each { Map property ->
			if (property.name.endsWith('/' + propertyName)) {
				found = true
			}
		}
		
		return found
	}
	
	
	/**
	 * Returns the value of the named component property.  Returns null if not found.  This can
	 * be defined by the component's template (managed) or may be defined within the property (unmanaged).
	 * @param ucdServer UCD Session handle
	 * @param componentId The ID of the component
	 * @param propertyName The name of the property.
	 */
	public static def getPropertyValue( UcdServerConnection ucdServer, String componentId, String propertyName ) {
		def result = null
		
		def componentInfo = (new RestGet( ucdServer )).setPath("/cli/component/info")
		.addParameter("component", componentId)
		.getAsObject()

		// Iterate properties looking for the desired property
		componentInfo.properties.each { Map property ->
			if (property.name.endsWith('/' + propertyName)) {
				result = property.value
			}
		}
		
		return result
	}


	/**
	 * Returns the current Property Sheet URL for a given Component ID.  Note that the property sheet URL is
	 * version dependent.  It changes every time that ANY property definition is changed for the Component.
	 * @param ucdServer Handle to a UCD Server Session.
	 * @param componentId The id of a UCD Component.
	 */
	public static String getPropertySheetDefUrlForComponentVersion( UcdServerConnection ucdServer, String componentId ) {
		def component = (new RestGet( ucdServer )).setPath("/cli/component/info")
				.addParameter("component", componentId)
				.getAsObject()

		// the url is component.versionPropSheetDef.path + component.versionPropSheetDef.version + "/propDefs"
		// -and- the '/'s in the component.versionPropSheetDef.path MUST be changed to (encoded as) '%26' (or it doesn't work)
		return "/property/propSheetDef/" + component.versionPropSheetDef.path.replaceAll('/','%26') + "." + component.versionPropSheetDef.version + "/propDefs"
	}


	/**
	 * Returns the current Property Sheet object for a given Component ID.  Note that the property sheet URL is
	 * version dependent.  It changes every time that ANY property definition is changed for the Component.
	 * @param ucdServer Handle to a UCD Server Session.
	 * @param componentId The id of a UCD Component.
	 * @return Returns a property sheet OBJECT.
	 */
	public static def getPropertySheetForComponentVersion( UcdServerConnection ucdServer, String componentId ) {
		def String propertySheetUrl = getPropertySheetDefUrlForComponentVersion( ucdServer, componentId )

		return (new RestGet( ucdServer )).setPath(propertySheetUrl)
			.addParameter("component", componentId)
			.getAsObject()
	}
}
