

package com.ibm.css.ucd.processrequest

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.common.EntityWithId

/**
 * Approval information for a ProcessRequest.
 * @author ltclark
 *
 */
class ProcessRequestApproval extends EntityWithId {
	/**
	 * Overall approval status of ... 'Passed', 'Failed', 'In Progress', 'Cancelled'
	 */
	String status
	
	/**
	 * The list of detailed approval entries.
	 */
	List<ProcessRequestApprovalDetail> detailedEntries = new ArrayList<ProcessRequestApprovalDetail>()

	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server
	 * @param rawProcessApprovalData This is raw data returned from a call to ProcessApprovalApi.getApprovals()
	 */
	public ProcessRequestApproval( UcdServerConnection ucdServer, def rawProcessApprovalData ) {
		super( ucdServer, rawProcessApprovalData.id )

//		println "RAW DATA: ${groovy.json.JsonOutput.toJson( rawProcessApprovalData )}"
		
		this.status = rawProcessApprovalData.status

		// This is a small helper function.  "def lookupMapField( Map sourceMap, String fieldName, def defaultIfMissing )".
		// If the map contains the named field, simply return its value; otherwise return the 'defaultIfMissing' value
		Closure lookupMapField = { Map sourceMap, String fieldName, def defaultIfMissing ->
			if (sourceMap.containsKey(fieldName)) {
				return sourceMap[fieldName]
			} else {
				return defaultIfMissing
			}
		}
		
		rawProcessApprovalData.detailedApprovals.each { Map sourceDetail ->
			ProcessRequestApprovalDetail newDetail = new ProcessRequestApprovalDetail(ucdServer)
			newDetail.type = sourceDetail.type
			newDetail.status = sourceDetail.status
			newDetail.componentId = lookupMapField( sourceDetail, 'componentId', null )
			newDetail.componentName = lookupMapField( sourceDetail, 'componentName', null )
//			newDetail.applicationId = lookupMapField( sourceDetail, 'applicationId', null )
//			newDetail.applicationName = lookupMapField( sourceDetail, 'applicationName', null )
//			newDetail.environmentId = lookupMapField( sourceDetail, 'environmentId', null )
//			newDetail.environmentName = lookupMapField( sourceDetail, 'environmentName', null )
			newDetail.completedBy = lookupMapField( sourceDetail, 'completedBy', null )
			newDetail.completedOn = lookupMapField( sourceDetail, 'completedOn', 0 )
			
			detailedEntries << newDetail
		}
//		println "PROCESSED DATA: ${groovy.json.JsonOutput.toJson( this )}"
	}
}
