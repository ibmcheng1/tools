package com.ibm.issr.core.csv

/**
 * Reads a CSV File.
 * @author ltclark
 *
 */
class CSVFileReader {
	private Reader reader
	
	/**
	 * Constructor.
	 * @param reader Handle to the input stream.
	 */
	public CSVFileReader( Reader reader ) {
		this.reader = reader	
	}
	
	/**
	 * This is the same as the load() function, which reads all of the rows of the CSV.
	 */
	public List<String[]> readAll() {
		return load()
	}
	
	/**
	 * Loads the CSV File/stream.
	 * @return Returns a list of rows where each row is a list of String values for the cell contents.
	 */
	public List<String[]> load() {
		List tableContents = []
		
		String cellContents = ""
		boolean inAQuote = false
		
		List rowContents = []
		
		reader.eachLine { String line ->
			boolean skipLine = false	// skip processing of totally empty lines that aren't part of a cell
			if (inAQuote) {
				// this line is part of a multi-line cell
				cellContents = cellContents + "\n"
			} else {
				// Start of a new row (if not an empty row)
				if (line.trim()) {
					// Start of a new row and cell
					cellContents = ""
					inAQuote = false
				} else {
					skipLine = true
				}
			}
			
			if (! skipLine) {
				int colPtr = 0
				while (colPtr<line.length()) {
					String nextCharacter = line.substring(colPtr,colPtr+1)
					if (inAQuote) {
						// in a quoted string
						if (nextCharacter=='"') {
							if (((colPtr+1)<line.length()) && line.substring(colPtr+1,colPtr+2)=='"') {
								// within a quoted string, translate a two double quotes in a row to a single quote and keep going
								++colPtr
								cellContents = cellContents + '"'
							} else {
								// found a single double quote, so end the quoted string without any additional characters in the string
								inAQuote = false
							}
						} else {
							// the next character isn't a quote, so simply append it
							cellContents = cellContents + nextCharacter
						}
					} else {
						// Not in a quoted string
						if (nextCharacter=='"') {
							// Start a new quoted string, without adding the quote to the cell
							inAQuote = true
						} else if (nextCharacter==',') {
							// End of the cell - add this cell to the current row and start a new cell
							rowContents.add( cellContents )
							cellContents = ''
						} else {
							// For any other character, simply at it to the current cell
							cellContents = cellContents + nextCharacter
						}
					}
					++colPtr
				}
				
				if (! inAQuote) {
					// The end of the current line is the end of a table row
					// add the cell contents to current table row and start a new cell
					rowContents.add( cellContents )
					cellContents = ''
					// add the row to the list of rows and start a new row
					tableContents.add( rowContents )
					rowContents = []
				}
			}
		}
		
		// Convert from List of List to List<String[]> (a List of String arrays)
		List<String[]> retval = []
		tableContents.each{ row ->
			retval.add( row as String[] )
			}
		
		return retval
	}
}
