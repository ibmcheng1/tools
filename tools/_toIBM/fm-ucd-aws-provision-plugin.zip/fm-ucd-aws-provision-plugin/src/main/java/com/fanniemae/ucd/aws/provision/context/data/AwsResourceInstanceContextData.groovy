package com.fanniemae.ucd.aws.provision.context.data

import com.fanniemae.ucd.aws.provision.service.definition.AwsServiceDefinition
import com.fanniemae.ucd.aws.provision.service.instance.AwsServiceInstance

/**
 * Context data for one Aws Resource instance.
 */
class AwsResourceInstanceContextData {
	// The logical name
	private String _name
	private AwsServiceDefinition _awsServiceDefinition
	public AwsServiceInstance awsServiceInstance
	
	/**
	 * Constructor
	 * @param awsServiceDefinition The AWS Resource service definition.
	 * This is a specific configuration.  For example, if there are two
	 * different EBs, then there is a specific instance for each one.
	 */
	public AwsResourceInstanceContextData( AwsServiceDefinition awsServiceDefinition ) {
		this._awsServiceDefinition = awsServiceDefinition
		this._name = awsServiceDefinition.getName()
	}
	
	/**
	 * Returns the logical name for this service request.
	 */
	public String getName() {
		return _name
	}
	
	public AwsServiceDefinition getServiceDefinition() {
		return _awsServiceDefinition
	}
	
	public AwsServiceDefinition getAwsServiceDefinition() {
		return _awsServiceDefinition
	}
}
