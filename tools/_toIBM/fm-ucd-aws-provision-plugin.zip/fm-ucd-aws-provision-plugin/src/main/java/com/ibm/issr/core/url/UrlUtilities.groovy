package com.ibm.issr.core.url

class UrlUtilities {
	/**
	 * Returns the last non-empty segment of a URL string.  For example, if the string is
	 * 'http://server/a/b/c', then this returns 'c'.  If the string is 'http://server/a/b/c/',
	 * then it still returns 'c'.
	 */
	public static String getLastSegmentOfUrl( String url ) {
		List segments = url.tokenize('/')
		return segments[segments.size()-1]
	}
}
