package com.ibm.services.ucr.api.entity.scheduleddeployment

import com.ibm.issr.core.entity.IndexedListOfEntities
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.framework.UcrEntityData
import com.ibm.services.ucr.api.framework.UcrEntityDataFormat

class UcrScheduledDeploymentMgr {
	
	// Map of the singleton instances of this class.  Key=RestServerConnection, value=instance of this class
	private static Map _singletons = [:]
	
	// The server for this instance of the Mgr
	RestServerConnection ucrServer
	
	/**
	 * Cached list of loaded entities.  The data type of the cache is IndexedListOfEntities, which is
	 * automatically initialized when the cache is created or resest.
	 */
	RestDataCache _entityCache = new RestDataCache(
		// Cache entry initialization closure - Initialize cache entries as instances of IndexedListOfEntities
		{ RestServerConnection ucrServer ->
			return new IndexedListOfEntities(
				// This closure returns the 'uniqueName' for each entry, which is simply the id because this class has no name
				{ UcrScheduledDeployment entity ->
					return entity.getId()
				}
				)
		}
		)
	
	/**
	 * Private constructor.
	 * @param ucrServer The associated Rest Server.
	 */
	private UcrScheduledDeploymentMgr( RestServerConnection ucrServer ) {
		this.ucrServer = ucrServer
	}
	
	/**
	 * Returns the singleton instance of this class for the given Rest Server.
	 */
	public static UcrScheduledDeploymentMgr getInstance( RestServerConnection ucrServer ) {
		if (! _singletons.containsKey(ucrServer)) {
			_singletons[ucrServer] = new UcrScheduledDeploymentMgr(ucrServer)
		}
		return _singletons[ucrServer]
	}
	
	/**
	 * Given entity data, this returns a UcrScheduledDeployment for that data.
	 * @param ucrServer The server.
	 * @param entityData The data returned from some REST call.
	 * @return New or existing entity.
	 */
	public UcrScheduledDeployment buildEntity( RestServerConnection ucrServer, UcrEntityData entityData ) {
		UcrScheduledDeployment entity
		String name = entityData.getEntityObject().name
		String id = entityData.getEntityObject().id
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			entity = cachedEntities.getEntityById(id)
			// Update the cached entityData
		} else {
			entity = new UcrScheduledDeployment( ucrServer, name, id, entityData )
			cachedEntities.addEntity(entity)
		}
		return entity
	}
	
	/**
	 * Returns the UcrScheduledDeployment by ID.  Throws exception if not found.
	 */
	public UcrScheduledDeployment getById( String id, boolean resetCache=false ) {
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer, resetCache)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			return cachedEntities.getEntityById(id)
		} else {
			// not found in cache - make rest call to load it
			def rawEntityData = (new RestGet( ucrServer ))
					.setPath("/scheduledDeployment/${id}")
//					.addParameter('format', 'detail')
					.setHeader('Accept', 'application/json')
					.getAsObject()
			// Convert the raw data into an entity
			return buildEntity( ucrServer, new UcrEntityData(rawEntityData, UcrEntityDataFormat.LIST_FORMAT ))
		}
	}

}

class UcrSegmentExeuctionMgr {

}
