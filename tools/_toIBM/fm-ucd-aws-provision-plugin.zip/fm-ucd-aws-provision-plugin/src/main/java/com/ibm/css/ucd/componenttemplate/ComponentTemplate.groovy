package com.ibm.css.ucd.componenttemplate

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.common.EntityWithNameAndId

class ComponentTemplate extends EntityWithNameAndId {
	// Cached set of entries for this entity.
	//	key = UcdServerConnection
	//  value = field Map
	//  	byID = Map where
	//			key = id
	//			value = entity class, such as Application or Environment
	//		byName = Map where
	//			key = name
	//			value = entity class, such as Component entity class
	static protected Map cache = [:]

	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 */
	public ComponentTemplate( UcdServerConnection ucdServer, String name, String id ) {
		super( ucdServer, name, id )
	}
	
	/**
	 * Cached creation of new entities.  If the entity is already in the cache, the existing entity
	 * is returned.  Otherwise, a new entity is created, added to the cache and returned.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 * @return The requested entity.
	 */
	public static ComponentTemplate getComponentTemplateWithCache( UcdServerConnection ucdServer, String name, String id ) {
		if (! cache.containsKey(ucdServer)) {
			cache[ucdServer] = ['byId':[:],'byName':[:]]
		}
		if (! cache[ucdServer].byId.containsKey(id)) {
			ComponentTemplate newComponentTemplate = new ComponentTemplate( ucdServer, name, id )
			cache[ucdServer].byId[id] = newComponentTemplate
			cache[ucdServer].byName[name] = newComponentTemplate
		}
		return cache[ucdServer].byId[id]
	}

}
