

package com.ibm.services.ucr.api.entity.application

import com.ibm.issr.core.entity.EntityWithId
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.entity.version.UcrVersion
import com.ibm.services.ucr.api.entity.version.UcrVersionMgr
import com.ibm.services.ucr.api.framework.UcrEntityData
import com.ibm.services.ucr.api.framework.UcrEntityDataFormat
import com.ibm.services.ucr.api.framework.UcrEntityWithNameAndId

/**
 * UCR Application Entity
 *
 * @author LeonClark
 *
 */
class UcrApplication extends UcrEntityWithNameAndId implements EntityWithId {
	// The cache of the UcrEntityData for this entity
	private RestDataCache _cachedEntityData = new RestDataCache()
	
	// Maps this application to Ucd Application indexed by UcdServerConnection.
	// The easiest way to see if this UcrApplication is mapped to a given UCD Server is to
	// simply try to open it (with the externalId) on the given UCD Server.  This map
	// uses a key value of UcdServerConnection.  IF this UcrApplication maps to a
	// UCD Application on that server, then the value is a UCD 'Application' instance.  Otherwise,
	// the value is null. 
	private Map _ucdApplicationByServer = [:]
	
	/**
	 * Private constructor - do NOT call directly from any other class.
	 * @param entityData This is optional UcrEntityData (data returned from a REST call defining this entity).  If
	 * given, then it is cached.
	 */
	private UcrApplication( RestServerConnection ucrServer, String name, String id, UcrEntityData entityData = null ) {
		super( ucrServer, name, id )
		if (entityData) {
			_cachedEntityData.setCacheData(ucrServer, entityData)
		}
	}
	
	/**
	 * Resets the cached data storing internal data for this class instance.
	 */
	public void resetCachedData() {
		_cachedEntityData.resetCacheData(ucrServer)
	}
	
	
	/**
	 * Returns entity data for this entity which is at LEAST the 'minDataFormat' level of information.  For example,
	 * if the minDataFormat is LIST_FORMAT, then both LIST_FORMAT and DETAIL_FORMAT are suitable.
	 * If possible, this returns cached data, otherwise it loads (and caches) the data.
	 */
	public UcrEntityData getEntityData( UcrEntityDataFormat minDataFormat, boolean resetCache=false ) {
		UcrEntityData entityData = _cachedEntityData.getCacheData(ucrServer,resetCache)
		if ((! entityData) || (! entityData.getEntityFormat().isSuperset( minDataFormat ))) {
			// Load the data and cache it
			def data = (new RestGet( ucrServer ))
				.setPath('/applications/' + this.id)
				.addParameter('format', minDataFormat.getFormatName())
				.setHeader('Accept', 'application/json')
				.getAsObject()
			_cachedEntityData.setCacheData(ucrServer, new UcrEntityData(data, minDataFormat))
		}
		return _cachedEntityData.getCacheData(ucrServer)
	}
	
	/**
	 * Returns detail'ed entity data.  This is data retrieved via a REST call with format of 'detail'.  If possible,
	 * this returns cached data, otherwise it loads (and caches) the data.
	 */
	public UcrEntityData getDetailedEntityData( boolean resetCache=false ) {
		return getEntityData( UcrEntityDataFormat.DETAIL_FORMAT, resetCache )
	}
	
	
	/**
	 * Returns at least a LIST level UcrEntityData for this class, which is the underlying REST/JSON based data structure.
	 */
	public UcrEntityData getEntityData( boolean resetCache = false ) {
		return getEntityData( UcrEntityDataFormat.LIST_FORMAT, resetCache )
	}

	/**
	 * Returns a List of the UcrVersion's for this Application.
	 */
	public List getVersions( boolean resetCache=false ) {
		UcrEntityData detailedData = getDetailedEntityData(resetCache)
		List versions = []
		def data = detailedData.getEntityObject()
		if (data.containsKey('versions')) {
			UcrVersionMgr UcrVersionMgr = UcrVersionMgr.getInstance(ucrServer)
			data.versions.each { Map versionData ->
				versions << UcrVersionMgr.buildEntity(ucrServer, this, versionData.name, versionData.id)
			}
		}
		return versions
	}	
	
	/**
	 * Returns the named version for this application.  Throws exception if not found.
	 */
	public UcrVersion getVersionByName( String name, boolean resetCache=false ) {
		// For now, just get all child versions and then find the desired one
		// This can be written to be smarter
		UcrVersion version = getVersions(resetCache).find { UcrVersion entity ->
			return (entity.name == name)
		}
		if (! version) {
			throw new Exception( "Unable to find version named '${name}' in application '${this.getName()}'")	
		}
		return version
	}
	
	/**
	 * Does this application have any version with the given name??
	 */
	public boolean hasVersionByName( String name, boolean resetCache=false ) {
		// For now, just get all child versions and then find the desired one
		// This can be written to be smarter
		UcrVersion version = getVersions(resetCache).find { UcrVersion entity ->
			return (entity.name == name)
		}
		return version
	}
	
	/**
	 * Attempts to find the UCD Application that corresponds to this UCR Application on the specified
	 * UCD Server.  Returns null if not found.
	 * <p/>You MUST include the 'UCD Library' in your project/plugin for this call to work.  Dependencies
	 * from the UCR to the UCD Library are enforced at runtime and NOT compile time.
	 * @param ucdServer The handle to the UCD Server.  The data type MUST BE 'UcdServerConnection'
	 * from the 'UCD Library'.  It is declared as 'def' here to make this a runtime class
	 * dependency and not a compile time dependency.
	 * @return The data type returned IS com.ibm.css.ucd.application.Application.
	 * It is declared as 'def' here to make this a runtime class
	 * dependency and not a compile time dependency.
	 */
	public def getUcdApplication_WithoutException( def ucdServer ) {
		if (! _ucdApplicationByServer.containsKey(ucdServer)) {
			// default value to the not found value (null) unless and until it is found.
			_ucdApplicationByServer[ucdServer] = null
			// The simplest test is to see if this is an application on the target UCD server
			Map data = getEntityData().entityObject
			if (data.containsKey('externalId')) {
				
				// Make the following call, but with no direct class references, so that
				// the UCR library doesn't have any compile time dependencies on the UCD Library
				// ApplicationServices applicationServices = new ApplicationServices(ucdServer)
				Class ApplicationServices_class = Class.forName( 'com.ibm.css.ucd.services.ApplicationServices' )
				def applicationServices = ApplicationServices_class.newInstance(ucdServer)
				
				if (applicationServices.doesApplicationExistById(data.externalId)) {
					_ucdApplicationByServer[ucdServer] = applicationServices.getApplicationById(data.externalId)
				}
			}
		}
		return _ucdApplicationByServer[ucdServer]
	}
	
	/**
	 * Is the given UCR application mapped to a UCD application on the ucdServer??
	 * <p/>You MUST include the 'UCD Library' in your project/plugin for this call to work.  Dependencies
	 * from the UCR to the UCD Library are enforced at runtime and NOT compile time.
	 * @param ucdServer The handle to the UCD Server.  The data type MUST BE 'UcdServerConnection'
	 * from the 'UCD Library'.  It is declared as 'def' here to make this a runtime class
	 * dependency and not a compile time dependency.
	 */
	public boolean isUcdApplication( def ucdServer ) {
		return (getUcdApplication_WithoutException(ucdServer))
	}
	
	/**
	 * Returns the UCD Application for the given UCD Server that corresponds to this UCR Application.
	 * Throws exception if there isn't a corresponding UCD Application on the UCD Server.  You can
	 * call @{link "{@link #isUcdApplication(UcdServerConnection)}"}
	 * <p/>You MUST include the 'UCD Library' in your project/plugin for this call to work.  Dependencies
	 * from the UCR to the UCD Library are enforced at runtime and NOT compile time.
	 * @param ucdServer The handle to the UCD Server.  The data type MUST BE 'UcdServerConnection'
	 * from the 'UCD Library'.  It is declared as 'def' here to make this a runtime class
	 * dependency and not a compile time dependency.
	 * @return The data type returned IS com.ibm.css.ucd.application.Application.
	 * It is declared as 'def' here to make this a runtime class
	 * dependency and not a compile time dependency.
	 */
	public def getUcdApplication( def ucdServer ) {
		def application = getUcdApplication_WithoutException(ucdServer)
		if (! application) {
			throw new Exception( "The UCR Application named '${this.name}' does not have a corresponding UCD Application")
		}
		return application
	}
}
