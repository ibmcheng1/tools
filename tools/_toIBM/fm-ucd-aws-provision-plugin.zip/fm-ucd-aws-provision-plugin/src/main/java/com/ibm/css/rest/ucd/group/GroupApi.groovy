package com.ibm.css.rest.ucd.group

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.issr.rest.RestGet

/**
 * 'Group' entity UCD functions
 * @author ltclark
 *
 */
class GroupApi {
	/**
	 * Is there a group with the given name.
	 * @param ucdServer API handle to the UCD Server.
	 * @param groupName The name of the group.
	 * @return true or false
	 */
	public static boolean doesGroupExist( UcdServerConnection ucdServer, String groupName ) {
		return (new RestGet( ucdServer )).setPath("/cli/group/export")
			.addParameter("group", groupName)
			.getAsExistenceTest()
	}

}
