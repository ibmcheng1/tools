package com.fanniemae.ucr.releasedata

import com.ibm.services.ucr.api.entity.integrationprovider.UcrPluginIntegrationProvider
import com.ibm.services.ucr.api.entity.release.UcrRelease

/**
 * This class uses the 'FNMA Release Data Plugin' to manage Release specific data!!
 * The Release Data is actually stored as Properties of the plugin with a different
 * property for each Release' data.  However, this class is designed to behave much
 * like other UCR Entity classes.  It provides an entity style interface for retrieving
 * and updating the release data.  One instance of this class represents the release
 * data for one UcrRelease. 
 * @author LeonClark
 *
 */
class ReleaseData {
	public static final String DTM_NUMBER_FIELD = "DTM Number"
	
	// The ID of the release that this data is for
	private String _releaseId
	// The plugin integration which is storing all of the Release Data (as properties)
	private UcrPluginIntegrationProvider _releaseIntegrationProvider
	
	// DURING an update() call, this field contains the release data map that is getting updated!!
	// When the update is finished, it is reset to null, so it is only non-null during an update()
	private Map _updatingReleaseData = null
	
	
	/**
	 * The constructor, which should only be called by the {@link ReleaseDataMgr} class.
	 * @param releaseId The release ID that this data is for.
	 */
	ReleaseData( String releaseId, UcrPluginIntegrationProvider releaseIntegrationProvider ) {
		_releaseId = releaseId
		_releaseIntegrationProvider = releaseIntegrationProvider
	}

	
	/**
	 * Returns the actual data for this release, which is a data Map.  Note that during an update()
	 * transaction, the returned map can be directly manipulated and the changes will persist.
	 * Note that if the data has never been defined for the associated UcrRelease, then an empty
	 * map is returned.
	 */
	public Map getReleaseData( boolean resetCache=false ) {
		// if an update() is in progress (_updatingReleaseData is not null), return the update's data
		if (_updatingReleaseData!=null) {
			return _updatingReleaseData
		} else {
			Map releaseData = [:]
			Map providerProperties = _releaseIntegrationProvider.getEntityProperties(resetCache)
			String propName = ReleaseDataMgr.calculatePropertyNameForReleaseId( _releaseId )
			if (providerProperties.containsKey(propName)) {
				releaseData = new groovy.json.JsonSlurper().parseText( providerProperties[propName] )
			}
			return releaseData
		}
	}
	
	/**
	 * Does this release data have a DTM Number field?
	 */
	public boolean hasDtmNumber() {
		return getReleaseData().containsKey(DTM_NUMBER_FIELD)
	}
	
	/**
	 * Returns the DTM Number value.  This returns an empty string if it isn't defined.
	 */
	public String getDtmNumber() {
		return getReleaseProperty(DTM_NUMBER_FIELD)
	}
	
	/**
	 * Returns the named Release Data property field or an empty string if not found.
	 * @param propertyName The name of the property.
	 */
	public String getReleaseProperty( String propertyName ) {
		Map data = getReleaseData()
		if (data.containsKey(propertyName)) {
			return data[propertyName]
		} else {
			return ''
		}
	}

	/**
	 * Sets the DTM Number field - this should ONLY be called inside of an active
	 * {@link #update(Closure)} call.  If this is called outside of update(), then
	 * the data is NOT persisted!!
	 */
	public void setDtmNumber( String value ) {
		setReleaseProperty( DTM_NUMBER_FIELD, value )
	}
	
	/**
	 * Removes the DTM Number field - this should ONLY be called inside of an active
	 * {@link #update(Closure)} call.  If this is called outside of update(), then
	 * the data is NOT persisted!!
	 */
	public void removeDtmNumber() {
		removeReleaseProperty( DTM_NUMBER_FIELD )
	}

	/**
	 * Sets a named property within the data for this release  - this should ONLY be called inside of an active
	 * {@link #update(Closure)} call.  If this is called outside of update(), then
	 * the data is NOT persisted!!
	 * @param propertyName The string name of the property, such as 'sampleProperty' or 'sample property'.
	 * @param value A string value to set.
	 */
	public void setReleaseProperty( String propertyName, String value ) {
		getReleaseData()[propertyName] = value
	}
	
	/**
	 * Removes a named property from within the data for this release  - this should ONLY be called inside of an active
	 * {@link #update(Closure)} call.  If this is called outside of update(), then
	 * the data is NOT persisted!!
	 * @param propertyName The string name of the property, such as 'sampleProperty' or 'sample property'.
	 */
	public void removeReleaseProperty( String propertyName ) {
		getReleaseData().remove(propertyName)
	}

	/**
	 * Completely resets ALL of the release's data to 'releaseData'  - this should ONLY be called inside of an active
	 * {@link #update(Closure)} call.  If this is called outside of update(), then
	 * the data is NOT persisted!!
	 * This is NOT a normal function that should be called as it resets all of the properties within the Release Data
	 * to the properties in the Map.  This was added to support the ability to Import release data.
	 * More specifically, this iterates all of the entries in 'releaseData' and adds them to the release.
	 * @param releaseData This is a Map of all of the fields within the Release Data.
	 */
	public void setReleaseData( Map releaseData ) {
		Map currentReleaseData = getReleaseData()
		releaseData.each { def key, def value ->
			currentReleaseData[key.toString()] = value
		}
	}
	
	/**
	 * Call this method to update the underlying release data!!!  Specifically, within the
	 * 'performUpdate' closure make any desired changes to the release' data.  After performUpdate()
	 * is called, the changed data is automatically saved.
	 * @param performUpdate Closure with the syntax 'void performUpdate().
	 */
	public void update( Closure performUpdate ) {
		// This actually does a nested update() call on the underlying release integration, which is
		// where the data is actually saved.
		_releaseIntegrationProvider.update { 
			// Get the current release data
			_updatingReleaseData = getReleaseData()
			
			// call the Closure callback
			performUpdate()
			
			// Update the property in the integration
			_releaseIntegrationProvider.setEntityProperty(ReleaseDataMgr.calculatePropertyNameForReleaseId(_releaseId), groovy.json.JsonOutput.toJson( _updatingReleaseData ))
		}
		_updatingReleaseData = null
	}
}
