
package com.ibm.css.ucd.services

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.request.ProcessRequestApi
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.common.CacheData
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.processrequest.ProcessRequest
import com.ibm.css.ucd.processrequest.filter.ProcessRequestFilter
import com.ibm.issr.core.log.Logger

/**
 * Manager class for interacting with ProcessRequest, which are past and future Application
 * Process Requests/executions.
 * @author ltclark
 *
 */
class ProcessRequestServices {
	private UcdServerConnection ucdServer
	private ProcessRequestApi _processRequestApi
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the server.
	 */
	public ProcessRequestServices( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
		_processRequestApi = new ProcessRequestApi(ucdServer)
	}

	/**
	 * Calls a nested application process.    Note that this call automatically resets all data that
	 * is cached by this API, because the application process can change any data.
	 * @param application The UCD Application that contains the the process.
	 * @param environment The environment to run in.
	 * @param processName The name of the process to call.
	 * @param onlyChanged Is the only changed flag set?
	 * @param snapshotName Optional name of the snapshot to use.  Otherwise, use empty string.
	 * @param componentVersions This is a List of the component versions.  Each entry in the list can be either
	 * a ComponentVersion class instance or a Map.  If it's a map, then the map must have 
	 * 'version' and 'component' entries - the component name or id and version name or id.  Note that you
	 * can use both the ComponentVersion and Map entries in the same list.
	 * @param props List of property values to send to the application process.  This can be an instance of the Properties class or
	 * it can be a Map with key/value pairs.
	 * @param scheduleFor If this is non-blank, then it is the server date and time to start the process in
	 * the format of yyyy-mm-dd hh:mm.  If blank, then start immediately.  If this is not empty, then 'waitForProcess' is automatically
	 * set to false.
	 * @param waitForProcess Wait for the nested process to complete before continuing??
	 * @return A list of return values - String requestId - the generated request ID;
	 * <ul>
	 * 	<li>String outputStatus - the status of the nested process of "Success", "Failure" or "Did Not Wait";</li>
	 *  <li>String requestStatus - the status that UCD returned for the request</li>
	 *  <li>String processStatus - the last status returned by checking the process' status.  Essentially, if 'waitForProcess' is
	 *  true and this returned 'processStatus' is anything except SUCCEEDED, then the process failed to run to completion.  Note
	 *  that it may have been cancelled or failed.</li>
	 *  <li>String webAddress - Web Address for the generated process</li>
	 *  <li>String processId - The process/request ID of the nested process.</li>
	 * </ul>
	 * Example call with return values: def (String outputStatus, String requestStatus, String processStatus, String webAddress) = callApplicationProcess(...)
	 */
	public List callApplicationProcess( Application application, Environment environment, String processName, boolean onlyChanged, String snapshotName, List componentVersions, Map props, String scheduleFor, boolean waitForProcess ) {
		// Convert 'props' to Properties
		Properties properties
		if (props instanceof Properties) {
			properties = props
		} else {
			properties = new Properties()
			props.each { String key, def value ->
				properties.put( key, value.toString() )
			}
		}
		// convert the componentVersions list in a List of Map entries.  Each map has 'version' and 'component' field.
		List componentVersionPayload = []
		componentVersions.each { def componentVersion ->
			if (componentVersion instanceof Map) {
				componentVersionPayload << componentVersion
			} else if (componentVersion instanceof ComponentVersion) {
				ComponentVersion version = componentVersion
				componentVersionPayload << [ component: version.getComponent().id, version: version.id ]
			}
		}
		
		List retval = _processRequestApi.callApplicationProcess( application.name, processName, environment.name, onlyChanged.toString(), snapshotName, componentVersionPayload, properties, scheduleFor, waitForProcess )

		// A process call may change ANY data, so reset all cached data		
		CacheData.resetAllCacheData()
		
		return retval
	}
	
	/**
	 * Loads the process request given the id.
	 * @param processRequestId The process id.
	 * @return
	 */
	public ProcessRequest getProcessRequest( String processRequestId ) {
		def processRequestInfo = _processRequestApi.getProcessRequestInfo(processRequestId)
		return new ProcessRequest(ucdServer, processRequestInfo)
	}

	/**
	 * Iterate a filtered list of the historical ProcessRequest records calling a 'callback'
	 * function for each filtered record.
	 * @param filter Filter criteria.
	 * @param callback This function/callback is called for each filtered record.  It has
	 * one parameter, which is a ProcessRequest record.
	 */
	public void iterateProcessRequestHistory( ProcessRequestFilter filter, Closure callback ) {
		// IMPLEMENTATION NOTES
		//  - There are different REST calls (documented and undocumented) which work best for different
		// 	  filters, such as 'get all Process Request History' vs 'get Process Request History for Application'.
		//  - They all use the same callback closure, so declare the closure once and then
		//    figure out the appropriate iterator to call based on the iterator.

		// This is the common iteration handler!!
		Closure iterationHandler = { def rawProcessRequest ->
			// Note that the 'rawProcessRequest' is the object tree returned by the API calls
			// This returns null if the record isn't included in the filter.  Otherwise, it returns the
			// corresponding ProcessRequest entity
			ProcessRequest processRequest = null
			
			if (filter.includeRawRecordInFilter(rawProcessRequest)) {
				// include raw record - convert to ProcessRequest and then test again
//				Logger.debug "After 'raw' test, Including: ${groovy.json.JsonOutput.toJson( rawProcessRequest )}"
			
				processRequest = new ProcessRequest(ucdServer, rawProcessRequest)
				
				if (filter.includeProcessRequestInFilter(processRequest)) {
					Logger.debug "After 'entity' test, Including: ${processRequest.toString()}"
				} else {
					// exclude the record by setting the variable to null
					processRequest = null
				}
			}

			if (processRequest) {
				callback( processRequest )
			}			
		}
				
		// Call the optimal iterator (using the common iterator handler)
//		if (filter.getFilteringApplication()) {
//			// Use Application specific Process Request history retrieval
//			_processRequestApi.iterateProcessHistoryForApplication(filter.getFilteringApplication(), iterationHandler )
//		} else {
			// Use global Process Request iteration
			_processRequestApi.iterateProcessHistory(filter.getFilteringStartedAfter(), iterationHandler )
//		} 
		
	}
	
//	/**
//	 * Returns a List of the audit history.
//	 * @return A List of audit history entries.  Each entry is a Map which includes
//	 * the following fields: 
//	 */
//	public List getProcessRequest() {
//		List history = []
//		int pageNumber=0
//		while (true) {
//			++pageNumber
////			Logger.info("${pageNumber}")
//			List rawProcessRequest = _auditHistoryApi.getPageOfProcessRequest(pageNumber, true, 100)
//			if (rawProcessRequest.size() == 0) {
//				break;
//			}
//			rawProcessRequest.each { entry ->
//				ProcessRequestEntry newEntry = new ProcessRequestEntry(entry.date, entry.eventType, entry.description, entry.objType, entry.objName, entry.objId, entry.userId, entry.userName, entry.status, entry.id, entry.ipAddress)
//				history << newEntry
//			}
//		}
//		return history
//	}
}
