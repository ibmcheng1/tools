package com.ibm.css.rest.ucd.user

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPut

/**
 * User entity UCD functions.
 * @author ltclark
 *
 */
class UserApi {
	/**
	 * Is there a user with the given name.
	 * @param ucdServer API handle to the UCD Server.
	 * @param userName The name of the user.
	 * @return true or false 
	 */
	public static boolean doesUserExist( UcdServerConnection ucdServer, String userName ) {
		return (new RestGet( ucdServer )).setPath("/cli/user/info")
			.addParameter("user", userName)
			.getAsExistenceTest()
	}
	
	/**
	 * Returns the user's API data structure (as per '/cli/user/info'.
	 * @param ucdServer API handle to the UCD Server.
	 * @param userName The name of the user.
	 * @return The user data or null if not found.
	 */
	public static def getUserData( UcdServerConnection ucdServer, String userName ) {
		return (new RestGet( ucdServer )).setPath("/cli/user/info")
			.addParameter("user", userName)
			.getAsObjectOrNull()
	}

	/**
	 * Returns the List of Active UCD Groups that the user is in.  The returned List is
	 * a list of dynamic objects (which is a map) with the following keyed fields:
	 * id - the ID of the group, name - the name of the group.
	 * @param ucdServer API handle to the UCD Server.
	 * @param userName The name of the user.
	 */
	public static List getGroups( UcdServerConnection ucdServer, String userName ) {
		List groups = []
		def userInfo = (new RestGet( ucdServer )).setPath("/cli/user/info")
		.addParameter("user", userName)
		.getAsObject()
		if (userInfo.containsKey('groups')) {
			userInfo.groups.each { existingGroupEntry ->
				if (existingGroupEntry.containsKey('enabled') && existingGroupEntry.enabled) {
					def newGroupEntry = [:]
					newGroupEntry.id = existingGroupEntry.id
					newGroupEntry.name = existingGroupEntry.name
					groups << newGroupEntry
				}
			}
		}
		return groups
	}
	
	public static void importLdapUser(UcdServerConnection ucdServer, String userId, String authenticationRealm) {
		def response = (new RestPut( ucdServer )).setPath("/cli/user/import").addParameter("user", userId).addParameter("authenticationRealm", authenticationRealm).putAsObject()
	}

}
