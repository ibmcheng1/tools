package com.fanniemae.ucd.aws.provision.service.instance

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.ucd.aws.api.describeRecord.AwsDescribeRecordResult
import com.fanniemae.ucd.aws.provision.service.definition.AwsServiceDefinition
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.environment.Environment
import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.plugin.AbortPluginException
import com.ibm.issr.rest.RestPut

import groovy.json.JsonOutput
import groovy.json.JsonSlurper

/**
 * Represents one provisioned instance of an AWS service, such as RDS or EB.
 * @author s9ulcc
 *
 */
abstract class AwsServiceInstance {
	/**
	 * The AwsServiceDefinition which created this service instance.  Note that 
	 * the service definition includes the block of data from the AWS Specification/Manifest
	 * which defines this instance.
	 */
	protected AwsServiceDefinition _awsServiceDefinition
	
	protected AwsConnection _awsConnection
	
	// The name that it is provisioned under.  This is an input to AWS 
	protected String _provisionedName
	
	// The provisioned ID, which is returned when provisioning requested.
	// This IS the same product ID that is displayed in the 'Provisioned products list' AWS GUI list!!
	// This can be used for calls to 'aws servicecatalog describe-provisioned-product'
	// Do NOT use this for calls to 'aws servicecatalog describe-record'
	protected String _provisionedId
	
	// Is this a newly provisioned AWS Product?  If this is false, then it is an existing AWS Product instance.
	protected boolean _newlyProvisioned
	
	// The aws instance record id.  This is NOT the same as _provisionedId.
	// When calling 'describe-provisioned-product', this is located in the output
	// as ProvisionedProductDetail.LastRecordId
	// Do NOT use this for calls to 'aws servicecatalog describe-provisioned-product'
	// Use this for calls to 'aws servicecatalog describe-record'
	protected String _recordId
	
	// If provided, this is the AWS Provisioned Product ID that is displayed to users in the AWS consoles.
	protected String _provisionedProductId
	
	// Current AWS Product Instance status
	protected String _awsStatus = null		// See https://docs.aws.amazon.com/cli/latest/reference/servicecatalog/describe-provisioned-product.html for list of status values
	
	// Cached AWS instance properties
	private AwsDescribeRecordResult _cached_recordResult = null

	/**
	 * Constructor	
	 * @param awsServiceDefinition The definition of the AWS Resource/Service.
	 * @param awsConnection The connection to AWS
	 * @param provisionedId The ID of the AWS Provisioning Request.
	 * @param provisionedName The instance Name.
	 * @param productInstanceId The AWS ID of the AWS Provisioned Instance.  This is primarily (if not exlusively) provided when linking to existing instances on provisioning.
	 * This is the ID that you see in the AWS Provisioned Productes List.
	 * @param newlyProvisioned Is this a newly provisioned AWS Product?  If this is false, then it is an existing AWS Product instance.
	 */
	public AwsServiceInstance( AwsServiceDefinition awsServiceDefinition, AwsConnection awsConnection, String provisionedId, boolean newlyProvisioned ) {
		this._awsServiceDefinition = awsServiceDefinition
		this._awsConnection = awsConnection
		this._provisionedId = provisionedId
		this._newlyProvisioned = newlyProvisioned
	}
	
	/**
	 * Returns the aws instance record id.  This is NOT the same as _provisionedId.
	 * When calling 'describe-provisioned-product', this is located in the output
	 * as ProvisionedProductDetail.LastRecordId
	 * Do NOT use this for calls to 'aws servicecatalog describe-provisioned-product'
	 * Use this for calls to 'aws servicecatalog describe-record'
	 */
	public String getRecordId() {
		if (! _recordId) {
			lookupProductInformationFromAws()
		}
		return _recordId
	}

	/**
	 * Makes AWS API calls to get product information (name, recordId, ..) for a 
	 * Product Instance given the product ID (_provisionedId).  Updates class variables.
	 */
	private void lookupProductInformationFromAws(AwsConnection awsConnection) {
		CommandRunner commandRunner = _awsConnection.executeAwsCliCommand("aws servicecatalog describe-provisioned-product --id ${_provisionedId}")
		if (! commandRunner.wasSuccessful()) {
			throw new AbortPluginException( "API call to get AWS Service Instance status failed")
		}
		Map productInfo = (new JsonSlurper()).parseText( commandRunner.getConsoleOutput() )
		Map ProvisionedProductDetail = productInfo.ProvisionedProductDetail
		_recordId = ProvisionedProductDetail.LastRecordId
		_provisionedName = ProvisionedProductDetail.Name
	}
	
	/**
	 * Returns the AWS Service Type, such as 'EB' or 'RDS'
	 */
	abstract public String getServiceType()
	
	/**
	 * Returns the AwsConnection for this service instance.
	 */
	public AwsConnection getAwsConnection() {
		return _awsConnection
	}
	
	/**
	 * Is this instance a newly provisioned AWS Product instance?  If false, then it is an existing, re-used instance.
	 */
	public boolean isNewlyProvisioned() {
		return _newlyProvisioned
	}
	
	/**
	 * Calls the AWS 'describe-record' command for this instance returning the resulting Object tree storing results in a cache.
	 */
	public AwsDescribeRecordResult getAwsInstanceData( boolean resetCache = false) {
		if ((! _cached_recordResult) || resetCache) {
			CommandRunner commandRunner = awsConnection.executeAwsCliCommand("aws servicecatalog describe-record --id ${getRecordId()}")
			if (! commandRunner.wasSuccessful()) {
				throw new AbortPluginException( "API call to get AWS Service Instance Record (servicecatalog describe-record) failed")
			}
			_cached_recordResult = new AwsDescribeRecordResult( commandRunner.getConsoleOutput(), true )
		}
		return _cached_recordResult
	}
	
	/**
	 * Normally, getAwsInstanceData() calls the 'aws servicecatalog describe-record' command which returns
	 * a JSON string, but this method can be called with a 'describe-record' JSON string.
	 * This is useful for loading existing records or simulating them.
	 * @param describeRecordJson The JSON string returned from an appropriate 'aws servicecatalog describe-record'
	 * call.
	 * @return The new Describe Record class wrapper for the record.
	 */
	public AwsDescribeRecordResult setDescribeRecordJson( String describeRecordJson ) {
		_cached_recordResult = new AwsDescribeRecordResult( describeRecordJson, false )
		return _cached_recordResult
	}
	
	/**
	 * Returns the
	 * @param resetCache - If true, then force reload of status from AWS, otherwise, return cached value. 
	 */
	public String getAwsStatus( boolean resetCache = false ) {
		if ((! _awsStatus) || resetCache) {
			// re-query AWS for current status
			CommandRunner commandRunner = awsConnection.executeAwsCliCommand("aws servicecatalog describe-provisioned-product --id ${_provisionedId}")
			if (! commandRunner.wasSuccessful()) {
				throw new AbortPluginException( "API call to get AWS Service Instance status failed")
			}
			Map productInfo = (new JsonSlurper()).parseText( commandRunner.getConsoleOutput() )
			Map ProvisionedProductDetail = productInfo.ProvisionedProductDetail
			_awsStatus = ProvisionedProductDetail.Status
			if (ProvisionedProductDetail.containsKey('LastRecordId')) {
				_recordId = ProvisionedProductDetail.LastRecordId
			}
		}
		return _awsStatus
	}

	/**
	 * Is this AWS Service Instance available?  If 'resetCache' is false,
	 * then this returns the last AWS Status without making an additional AWS
	 * call.  If 'resetCache' is true, then call AWS to get the current status.
	 */
	public boolean isAvailable( boolean resetCache = false ) {
		return getAwsStatus(resetCache)=='AVAILABLE'
	}
	
	/**
	 * Returns the AWS Service Instance ID.
	 * This IS the same product ID that is displayed in the 'Provisioned products list' AWS GUI list!!
	 */
	public String getProvisionedId() {
		return _provisionedId
	}
	
	/**
	 * Sets the AWS Service Instance name
	 */
	public void setProvisionedName( String name ) {
		_provisionedName = name
	}
	
	/**
	 * Returns the AWS Service Instance Name.  If there is no name defined, then an AWS api call is made to get the name. 
	 */
	public String getProvisionedName() {
		if (! _provisionedName) {
			lookupProductInformationFromAws()
		}
		return _provisionedName
	}
//	
//	/**
//	 * Adds a UCD Environment which this AWS Service Instance (and its corresponding UCD Component) are part of.
//	 * Note that one AWS Service Instance can be mapped to multiple environments.  For example,
//	 * when provisioning a Blue-Green environment, one RDS instance is mapped to both the Blue and Green
//	 * @param ucdEnvironment
//	 */
//	public void addUcdEnvironment( Environment ucdEnvironment ) {
//		_ucdEnvironments << ucdEnvironment
//	}
//	
//	/**
//	 * Returns a List of ucd Environment's which this instance is associated with.  Note that
//	 * one instance may be associated with multiple environments.
//	 */
//	public List<Environment> getUcdEnvironments() {
//		return _ucdEnvironments
//	}
//	
//	/**
//	 * Sets UCD Properties and data (tags, etc) AFTER the AWS Provisioning is complete.
//	 * In other words, set UCD data that requires the final AWS Provision
//	 * data (such as actual endpoint names in AWS).</p>
//	 */
//	public void setUcdPropertiesAfterProvisioningComplete() {
//		// There are no common data fields for all of the different aws service types 
//		// extension classes define their versions of this
//	}
	
//	/**
//	 * Sets Component Environment property 
//	 * @param name
//	 * @param value
//	 * @return
//	 */
//	protected setComponentEnvironmentProperty( Component component, Environment environment, String name, String value ) {
//		def payload = [ component: component.getId(), environment: environment.getId(), name: name, value:value ]
//		(new RestPut( component.ucdServer )).setPath("/cli/environment/componentProperties")
//			.setPayload(JsonOutput.toJson( payload ))
//			.putWithNoReturnObject()
//	}
}
