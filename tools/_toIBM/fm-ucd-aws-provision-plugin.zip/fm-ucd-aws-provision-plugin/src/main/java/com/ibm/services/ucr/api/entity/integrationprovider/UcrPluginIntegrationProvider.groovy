

package com.ibm.services.ucr.api.entity.integrationprovider

import com.ibm.issr.core.entity.EntityWithId
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPut
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.entity.plugin.UcrPlugin
import com.ibm.services.ucr.api.entity.plugin.UcrPluginMgr
import com.ibm.services.ucr.api.framework.UcrEntityData
import com.ibm.services.ucr.api.framework.UcrEntityDataFormat
import com.ibm.services.ucr.api.framework.UcrEntityWithNameAndId

/**
 * UCR Application Entity
 *
 * @author LeonClark
 *
 */
class UcrPluginIntegrationProvider extends UcrEntityWithNameAndId implements EntityWithId {
	// The cache of the UcrEntityData for this entity
	private RestDataCache _cachedEntityData = new RestDataCache()
	// The UcrPlugin that corresponds to this Integration definition.  Note that this deosn't
	// need to be cached because there is no way to ever change the plugin for an integration. (It
	// is invariant).
	private UcrPlugin _plugin = null
	// The pluginId, such as 'com.urbancode.air.plugin.deploy'.  This doesn't need to be cached as it never changes.
	private String _pluginId = null
	// This is the list of pending updated data fields.  This should ONLY be referenced within an update() call
	private Map _updatedData = null

	/**
	 * Private constructor - do NOT call directly from any other class.
	 * @param entityData This is optional UcrEntityData (data returned from a REST call defining this entity).  If
	 * given, then it is cached.
	 */
	private UcrPluginIntegrationProvider( RestServerConnection ucrServer, String name, String id, UcrEntityData entityData = null ) {
		super( ucrServer, name, id )
		if (entityData) {
			_cachedEntityData.setCacheData(ucrServer, entityData)
		}
	}
	
	/**
	 * Resets the cached data storing internal data for this class instance.
	 */
	public void resetCachedData() {
		_cachedEntityData.resetCacheData(ucrServer)
	}
	
	/**
	 * Returns entity data for this entity which is at LEAST the 'minDataFormat' level of information.  For example,
	 * if the minDataFormat is LIST_FORMAT, then both LIST_FORMAT and DETAIL_FORMAT are suitable.
	 * If possible, this returns cached data, otherwise it loads (and caches) the data.
	 */
	public UcrEntityData getEntityData( UcrEntityDataFormat minDataFormat, boolean resetCache=false ) {
		UcrEntityData entityData = _cachedEntityData.getCacheData(ucrServer,resetCache)
		if ((! entityData) || (! entityData.getEntityFormat().isSuperset( minDataFormat ))) {
			// Load the 'detail' data and cache it
			def data = (new RestGet( ucrServer ))
				.setPath("/integrationProvider/${this.id}")
				.addParameter('format', minDataFormat.getFormatName())
				.setHeader('Accept', 'application/json')
				.getAsObject()
			_cachedEntityData.setCacheData(ucrServer, new UcrEntityData(data, minDataFormat))
		}
		return _cachedEntityData.getCacheData(ucrServer)
	}

	/**
	 * Returns detail'ed entity data.  This is data retrieved via a REST call with format of 'detail'.  If possible,
	 * this returns cached data, otherwise it loads (and caches) the data. 
	 */
	public UcrEntityData getDetailedEntityData( boolean resetCache=false ) {
		return getEntityData( UcrEntityDataFormat.DETAIL_FORMAT, resetCache )
	}
	
	
	/**
	 * Returns at least a LIST level UcrEntityData for this class, which is the underlying REST/JSON based data structure.
	 */
	public UcrEntityData getEntityData( boolean resetCache = false ) {
		return getEntityData( UcrEntityDataFormat.LIST_FORMAT, resetCache )
	}

	
	/**
	 * Returns the UCR Plugin which corresponds to this Integration.
	 */
	public UcrPlugin getPlugin() {
		if (! _plugin) {
			UcrEntityData entityData = getEntityData( UcrEntityDataFormat.LIST_FORMAT )
			_plugin = UcrPluginMgr.getInstance(ucrServer).getById(entityData.entityObject.integrationPlugin.id)
		}
		return _plugin
	}

	/**
	 * Returns the pluginId for this integration provider, such as "com.urbancode.air.plugin.deploy".
	 */
	public String getPluginId( boolean resetCache=false ) {
		if (! _pluginId) {
			UcrEntityData entityData = getEntityData( UcrEntityDataFormat.LIST_FORMAT, resetCache )
			_pluginId = entityData.getEntityObject().integrationPlugin.pluginId
		}
		return _pluginId
	}
	
	/**
	 * Returns the properties of the IntegrationProvider as a Map.  The key is the property name and the value is the value of the named property.
	 */
	public Map getEntityProperties( boolean resetCache=false ) {
		return getEntityData( UcrEntityDataFormat.LIST_FORMAT, resetCache ).entityObject.properties
	}
	
	/**
	 * Sets the named property to the given value.  This uses cached data without reseting the cache.  This
	 * does NOT save the updated entity.  This can ONLY be called within an active 
	 * {@link #update(Closure)} closure/callback.
	 */
	public void setEntityProperty( String propertyName, String value ) {
		// update cached entity data
		getEntityData( UcrEntityDataFormat.LIST_FORMAT ).entityObject.properties[propertyName] = value
		// update pending _updatedData
		_updatedData.properties[propertyName] = value
	}
	
//	/**
//	 * Saves/Updates this entity with the current entity data!!
//	 */
//	public void save(UcrEntityData entityData, String propertyName ) {
//		// The payload is the currently defined entity data (which may be updated since it was read in)
////		Map payload = getEntityData( UcrEntityDataFormat.LIST_FORMAT ).entityObject
//		Map data = entityData.entityObject
//		Map payload = [
////			defaultStep: data.defaultStep,
////			description: data.description,
////			frequency: data.frequency,
////			id: data.id,
////			integrationPlugin: [ id: data.integrationPlugin.id, name: data.integrationPlugin.name ],
////			integrationPluginVersion: data.integrationPluginVersion,
////			name: data.name,
//			properties: [:] ]
//		payload.properties[propertyName] = data.properties[propertyName]
////		if (payload.properties.containsKey('foobar')) {
////			payload.properties.remove('foobar')
////		}
//		(new RestPut(ucrServer))
//			.setPath( "/integrationProvider/${this.id}" )
//			.setJsonPayloadToObject(payload)
//			.setHeader('Accept', '*/*')
//			.setHeader('Content-Type', 'application/json')
//			.putWithNoReturnObject()
//	}
	
	
	/**
	 * Call this method to update data in this entity!!!  This calls the performUpdate() closure
	 * to actually update the appropriate entity data.  After calling performUpdate(), the entity 
	 * is automatically saved.  Note that this loads a fresh copy of the entity before calling
	 * performUpdate().
	 * @param updater Closure with the syntax 'void performUpdate()'.
	 */
	public void update( Closure performUpdate ) {
		// Implementation Notes:
		//	- You can do a Put on a UCR entity with a JSON payload that ONLY contains the changed
		//	  fields!!  To that end, when any data is updated in the entity, the both the entityData
		//	  and the _updatedData is changed.  Therefore, when it is time to save, the _updatedData
		//	  can simply be saved and it only has the changes.
		//  - Note that a field can be deleted/reset by assigning it a value of null.
		//	- For fields that have properties, properties can also be selectively set. 
		
		// Refresh the entity's data
		getEntityData(true)
		_updatedData = [properties:[:]]
		
		// perform the update
		performUpdate()
		
		// update the record with ONLY the changes (_updatedData)
		(new RestPut(ucrServer))
			.setPath( "/integrationProvider/${this.id}" )
			.setJsonPayloadToObject(_updatedData)
			.setHeader('Accept', '*/*')
			.setHeader('Content-Type', 'application/json')
			.putWithNoReturnObject()

		
		// reset cached data so that the next data access reloads the data
		resetCachedData()
		_updatedData = null
	}
}
