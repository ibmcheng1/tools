package com.ibm.services.ucr.api.entity.taskexecution

import com.ibm.issr.core.entity.EntityWithId
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPost
import com.ibm.issr.rest.RestPut
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.framework.UcrEntityData;
import com.ibm.services.ucr.api.framework.UcrEntityDataFormat;
import com.ibm.services.ucr.api.framework.UcrEntityWithNameAndId

/**
 * UCR Task Execution Entity
 *
 * @author LeonClark
 *
 */
class UcrTaskExecution extends UcrEntityWithNameAndId implements EntityWithId {
	// The cache of the UcrEntityData for this entity
	private RestDataCache _cachedEntityData = new RestDataCache()
	
	/**
	 * Private constructor - do NOT call directly from any other class except the corresponding Mgr class.
	 * @param entityData This is optional UcrEntityData (data returned from a REST call defining this entity).  If
	 * given, then it is cached.
	 */
	private UcrTaskExecution( RestServerConnection ucrServer, String name, String id, UcrEntityData entityData = null ) {
		super( ucrServer, name, id )
		if (entityData) {
			_cachedEntityData.setCacheData(ucrServer, entityData)
		}
	}
	
	/**
	 * Resets the cached data storing internal data for this class instance.
	 */
	public void resetCachedData() {
		_cachedEntityData.resetCacheData(ucrServer)
	}

		
	/**
	 * Returns entity data for this entity which is at LEAST the 'minDataFormat' level of information.  For example,
	 * if the minDataFormat is LIST_FORMAT, then both LIST_FORMAT and DETAIL_FORMAT are suitable.
	 * If possible, this returns cached data, otherwise it loads (and caches) the data.
	 */
	public UcrEntityData getEntityData( UcrEntityDataFormat minDataFormat, boolean resetCache=false ) {
		UcrEntityData entityData = _cachedEntityData.getCacheData(ucrServer,resetCache)
		if ((! entityData) || (! entityData.getEntityFormat().isSuperset( minDataFormat ))) {
			// Load the 'detail' data and cache it
			def data = (new RestGet( ucrServer ))
				.setPath('/taskExecutions/' + this.id)
				.addParameter('format', minDataFormat.getFormatName())
				.setHeader('Accept', 'application/json')
				.getAsObject()
			_cachedEntityData.setCacheData(ucrServer, new UcrEntityData(data, minDataFormat))
		}
		return _cachedEntityData.getCacheData(ucrServer)
	}

	/**
	 * Returns detail'ed entity data.  This is data retrieved via a REST call with format of 'detail'.  If possible,
	 * this returns cached data, otherwise it loads (and caches) the data.
	 */
	public UcrEntityData getDetailedEntityData( boolean resetCache=false ) {
		return getEntityData( UcrEntityDataFormat.DETAIL_FORMAT, resetCache )
	}

	
	/**
	 * Returns at least a LIST level UcrEntityData for this class, which is the underlying REST/JSON based data structure.
	 */
	public UcrEntityData getEntityData( boolean resetCache = false ) {
		return getEntityData( UcrEntityDataFormat.LIST_FORMAT, resetCache )
	}

	/**
	 * Adds a new Task Comment to this task.
	 */
	public void addTaskComment( String comment ) {
		Map entityData = getEntityData().entityObject
		def payload = [comment: comment, task: [id:entityData.id, name:entityData.name]]
		String redirectUrl = (new RestPost( ucrServer ))
			.setPath('/comments/')
			.setJsonPayloadToObject(payload)
//			.setHeader('Accept', 'application/json')
			.setHeader('Accept', '*/*')
//			.setHeader('Accept-Encoding', 'gzip,deflate')
			.setHeader('Content-Type', 'application/json')
			.postAndReturnRedirect()
		this.resetCachedData()
		// TODO - return the instance of UcrTaskComment class.
	}
	
	/**
	 * Flag that this Task Execution has completed successfully (aka passed).
	 */
	public void setAsCompleted() {
		(new RestPut(ucrServer))
			.setPath( '/taskExecutions/' + this.getId() + "/complete" )
			.putWithNoReturnObject()
	}
	
	/**
	 * Flag that this Task Execution has Failed.
	 */
	public void setAsFailed() {
		(new RestPut(ucrServer))
			.setPath( '/taskExecutions/' + this.getId() + "/fail" )
			.putWithNoReturnObject()
	}
}
