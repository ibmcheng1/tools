package com.ibm.css.ucd.resource

import com.ibm.css.rest.ucd.UcdServerConnection

abstract class AgentOrAgentPoolResourceNode extends NonRootResourceNode {
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the UCD Server.
	 * @param parentNode The parent node to this node.
	 * @param nodeName The name of this node, such as "DEV"
	 * @param nodeId The ID of this node
	 */
	public AgentOrAgentPoolResourceNode( UcdServerConnection ucdServer, ResourceNode parentNode, String nodeName, String nodeId ) {
		super( ucdServer, parentNode, nodeName, nodeId )
	}

	/**
	 * Is this agent/pool node online.
	 * @return
	 */
	abstract public boolean isOnline()
	
	/**
	 * Is this agent/pool node online.
	 * @return
	 */
	abstract public boolean isOffline()
	
	/**
	 * Return the agent/pool status.
	 */
	abstract public String getStatus()
}
