package com.fanniemae.ucd.aws.provision.service.definition

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.ucd.aws.provision.context.ProvisionContext
import com.fanniemae.ucd.aws.provision.def.productmap.AwsLogicalProductMap
import com.fanniemae.ucd.aws.provision.helpers.AwsProvisionedNameHelper
import com.fanniemae.ucd.aws.provision.service.instance.AwsServiceInstance
import com.fanniemae.ucd.aws.provision.spec.AwsSpecification
import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.plugin.AbortPluginException

import groovy.json.JsonSlurper

/**
 * Common base class for AWS Service Definitions.  Note that an instance of this Definition class includes
 * the associated block of data from the AWS Specification/Manifest (_instanceData).
 */
abstract class AwsServiceDefinition {
	
	/**
	 * The name of this service definition.
	 */
	protected String _name
	
	/**
	 * Optional AWS Name.  If not provided, then the logical 'name' is used.
	 */
	protected String _awsName

	/**
	 * The AwsSpecification which this instance Specification is part of
	 */
	protected AwsSpecification awsSpecification
	
	/**
	 * The list of fields defined in the AWS Manifest Item.  It is as structured map
	 * with the following fields: String fieldName, boolean isRequired, Closure setValue.
	 * The syntax for the closure is
	 * 'void setValue( def value )' where
	 * instanceSpec is the instance and value is the Spec value of the field. 
	 */
	private List<Map> _memberFieldDefinitions = []
	
	/**
	 * The list of expected AWS Properties.  Each entry is a structured map with the following fields:
	 * String propertyName, boolean isRequired
	 */
	private List<Map> _awsPropertyFieldDefinitions = []
	
	/**
	 * These are manifest property values that are mapped to AWS. 
	 * Key is the property name and the value is the value.  Note that the value may contain tokens!!
	 */
	protected Map _awsPropertyFields = [:]
	
	/**
	 * The AWS Specification/Manifest data block associated with this Service Definition.
	 */
	protected Map _instanceData
	
	/**
	 * Constructor.
	 * @param awsSpecification The parent AwsSpecification
	 * @param instanceData The AWS Specification/Manifest data block associated with this Service Definition.
	 */
	public AwsServiceDefinition( AwsSpecification awsSpecification, Map instanceData ) {
		this.awsSpecification = awsSpecification
		this._instanceData = instanceData
	}
	
	/**
	 * Returns the AWS Service Type, such as 'EB' or 'RDS' 
	 */
	abstract public String getServiceType()
	
	/**
	 * Returns the name of this defined AWS resource service.
	 */
	public String getName() {
		return _name
	}
	
	/**
	 * Returns the aws base name, which may be context specific.
	 */
	public String getAwsName( ProvisionContext context ) {
		if (_awsName) {
			return context.processTokens( _awsName, _name )
		} else {
			return _name
		}
	}
	
	/**
	 * Should this type of AWS Service provision separate instances for blue-green deployments?
	 * If false, then only deploy a single instance even during a blue-green deployment. 
	 */
	public boolean shouldProvisionSeparateBlueGreenInstances() {
		return false
	}

	/**
	 * Defines a member field of the instance in the specification.  Note that
	 * this function doesn't care what the fields data type is - String, integer, Map, etc
	 * @param fieldName The name of the field in the specification.
	 * @param isRequired Is this a required field?
	 * @param setValue This closure is called to set the field value.  The syntax is
	 * 'void setValue( def value )' where
	 * instanceSpec is the instance and value is the Spec value of the field. 
	 */
	protected void defineMemberField( String fieldName, boolean isRequired, Closure setValue ) {
		_memberFieldDefinitions << [fieldName:fieldName, isRequired:isRequired, setValue:setValue]
	}
	
	/**
	 * Defines a member field that is mapped to the AWS propertyFields.
	 * @param propertyName The name of the AWS Property.
	 * @param isRequired Is the field required?
	 */
	protected void defineAwsProperty( String propertyName, boolean isRequired ) {
		_awsPropertyFieldDefinitions << [propertyName:propertyName, isRequired:isRequired]
	}
	
	/**
	 * Sets the field values for this InstanceSpec while validation, such as making sure that all required fields
	 * are defined.  If there are any validation problems, then the spec's tagValidationError() function is called.
	 */
	protected void validateAndSetMemberFields() {
		_memberFieldDefinitions.each { Map memberFieldDefinition ->
			if (_instanceData.containsKey(memberFieldDefinition.fieldName)) {
				memberFieldDefinition.setValue( _instanceData[memberFieldDefinition.fieldName] )
			} else if (memberFieldDefinition.isRequired) {
				awsSpecification.tagValidationError( "An instance of ${this.getServiceType()} is missing the required '${memberFieldDefinition.fieldName}' field" )
			}
		}
		if (_instanceData.containsKey('AwsProperties')) {
			_awsPropertyFieldDefinitions.each { Map propertyFieldDefinition ->
				if (_instanceData.AwsProperties.containsKey(propertyFieldDefinition.propertyName)) {
					_awsPropertyFields[propertyFieldDefinition.propertyName] = _instanceData.AwsProperties[propertyFieldDefinition.propertyName]
				} else if (propertyFieldDefinition.isRequired) {
					awsSpecification.tagValidationError( "An instance of ${this.getServiceType()} is missing the required AWS Property '${propertyFieldDefinition.propertyName}'" )
				}
			}
		} else {
			awsSpecification.tagValidationError( "An instance of ${this.getServiceType()} is missing the required 'AwsProperties' data" )
		}
	}

	/**
	 * Performs a full/deep verification of the manifest instance.
	 */
	public void performFullVerification() {
		// validation is performed on parsing the data, so no additional verification is needed
	}
	
	/**
	 * Is there a property key with the given name?
	 */
	public boolean hasPropertyField( String propertyName ) {
		return _awsPropertyFields.containsKey(propertyName)
	}
	
	/**
	 * Returns the value of the named 'propertyName' after resolving tokens or empty string if not found.
	 * @param propertyName The name of the input property (from awsManifest.json).
	 * @param context The context for resolving tokens.
	 */
	public String getPropertyField( String propertyName, ProvisionContext context ) {
		if (_awsPropertyFields.containsKey(propertyName)) {
			return context.processTokens( _awsPropertyFields[propertyName], this._name )
		} else {
			return ''
		}
	}
	
	/**
	 * Instead of provisioning a brand new AWS Product Instance, this function 'provisions' the definition to an
	 * existing AWS Product instance returning the resuling AwsServiceInstance.
	 * @param awsConnection
	 * @param awsExistingProductId This is the AWS ID that shows up in the AWS console when you list provisioned products.
	 */
	public AwsServiceInstance provisionByLinkingToExistingAwsProductInstance( AwsConnection awsConnection, String awsExistingProductInstanceId ) {
		return buildAwsServiceInstance( awsConnection, awsExistingProductInstanceId, false )
	}
	
	/**
	 * Provisions one instance of the defined AWS service.
	 * @param context The Provision Context that this instance is part of.
	 * @param awsConnection Authenticated connection to an AWS region.
	 * @param awsLogicalProductMap Maps logical names (like 'RDS') to formal AWS product IDs.
	 * @param requestedEnvType The requested environment type, such as "DEVL". This is needed because the
	 * map from logical AWS product codes to AWS Product IDs can be environment specific.
	 * @return Returns the provisioned instance wrapper.
	 */
	public AwsServiceInstance provisionInstance( ProvisionContext context, AwsConnection awsConnection, AwsLogicalProductMap awsLogicalProductMap, String requestedEnvType ) {
		Logger.debug( "called AwsServiceDefinition.provisionInstance()")
		
		// Create the awsPropertiesPayload - which is a List of the AWS Properties, including token processing
		List awsPropertiesPayload = []
		_awsPropertyFields.each { String propertyName, String value ->
			value = context.processTokens(value, this._name )
			awsPropertiesPayload << [Key:propertyName, Value:value]
		}
		Logger.debug "AWS Property Payload: " + awsPropertiesPayload
		
		// Lookup the awsProductId
		String productId = awsLogicalProductMap.getAwsProductId(this.getServiceType(), requestedEnvType)
		if (! productId) {
			throw new AbortPluginException( "Unable to find AWS product ID for '${this.getServiceType()}' in the awsProductIds")
		}
		Logger.debug "AWS Product ID: " + productId
		
		// Get the AWS provisionedName
		String provisionedName = AwsProvisionedNameHelper.getInstance().getProvisionedName( context.getApplication().getName() + '_' +
			context.environmentName + '_' + getAwsName(context) )
		Logger.debug "AWS Provisioned Name: " + provisionedName
		
		// Write the awsPropertiesPayload to file
		File awsPropertiesPayloadFile = new File( 'awsCreate.json' )
		awsPropertiesPayloadFile.text = groovy.json.JsonOutput.toJson(awsPropertiesPayload)
		
		Logger.debug "**************************************************"
		Logger.debug " Provision parameters file"
		Logger.debug "**************************************************"
		Logger.debug awsPropertiesPayloadFile.text

		// Lookup the artifactId
		String artifactId = getArtifactId( awsConnection, productId )
		
		CommandRunner commandRunner = awsConnection.executeAwsCliCommand("""aws servicecatalog provision-product --product-id "$productId" --provisioning-artifact-id "$artifactId"  --provisioned-product-name "$provisionedName" --provisioning-parameters file://${awsPropertiesPayloadFile.getCanonicalPath()} --region ${awsConnection.getRegion()}""")
		if (! commandRunner.wasSuccessful()) {
			throw new AbortPluginException( "Unable retrieve AWS Artifact ID for Product ID: ${productId}" )
		}
		String consoleOutput = commandRunner.getConsoleOutput()
		
		Map provisionedData = (new JsonSlurper()).parseText(consoleOutput)
		String provisioningId = provisionedData.RecordDetail.ProvisionedProductId
		provisionedName = provisionedData.RecordDetail.ProvisionedProductName
		
		Logger.debug "Provisioned a ${getServiceType()} instance of the productId ${productId} as instance: ID=$provisioningId, Name=$provisionedName"
		
		AwsServiceInstance serviceInstance = buildAwsServiceInstance( awsConnection, provisioningId, true )
		serviceInstance.setProvisionedName(provisionedName)
		return serviceInstance
	}
	
	/**
	 * Constructs an instance of AwsServiceInstance and returns it.  This builder method may be extended in subclasses to define custom
	 * construction including building a sub-class of AwsServiceInstance.
	 * @param awsConnection Authenticated connection to an AWS region.
	 * @param provisioningId The ID of the AWS Provisioning Request.  This is the ID that you see in the AWS Provisioned Productes List.
	 * @param newlyProvisioned Is this a newly provisioned AWS product (vs re-using existing product)
	 * @return The new instance of AwsServiceInstance or a subclass of that class.
	 */
	abstract protected AwsServiceInstance buildAwsServiceInstance( AwsConnection awsConnection, String provisioningId, boolean newlyProvisioned )
	
	/**
	 * Return the latest artifactId from the AWS catalog for the given catalog productId. 
	 * @param awsConnection Authenticated connection to an AWS region.
	 */
	private String getArtifactId( AwsConnection awsConnection, String productId ) {
		
		CommandRunner commandRunner = awsConnection.executeAwsCliCommand("""aws servicecatalog describe-product --id  $productId --region ${awsConnection.getRegion()}""")
		if (! commandRunner.wasSuccessful()) {
			throw new AbortPluginException( "Unable retrieve AWS Artifact ID for Product ID: ${productId}" )
		}
		String consoleOutput = commandRunner.getConsoleOutput()
		
		def createdTime = 0
		String artifactId = null
		String artifactName
		Map productInfo = (new JsonSlurper()).parseText(consoleOutput)
		if (productInfo.containsKey('ProvisioningArtifacts')) {
			productInfo.ProvisioningArtifacts.each { Map artifactInfo ->
				if (artifactInfo.CreatedTime > createdTime) {
					createdTime = artifactInfo.CreatedTime
					artifactId = artifactInfo.Id
					artifactName = artifactInfo.Name
				}
			} 
		}
		
		if (! artifactId) {
			throw new AbortPluginException( "Unable retrieve AWS Artifact ID for Product ID: ${productId} - no IDs found" )
		}

		Logger.debug "getArtifactId('${productId}') found ID='${artifactId}', Name='${artifactName}'"

		return artifactId
	}
}
