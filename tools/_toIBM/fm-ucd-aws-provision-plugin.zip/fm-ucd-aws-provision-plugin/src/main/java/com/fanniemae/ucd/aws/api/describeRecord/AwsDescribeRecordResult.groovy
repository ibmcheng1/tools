package com.fanniemae.ucd.aws.api.describeRecord

import com.ibm.issr.core.log.Logger

import groovy.json.JsonSlurper

/**
 * This is a class wrapper around the 'servicecatalog describe-record' result data.
 * @author s9ulcc
 *
 */
class AwsDescribeRecordResult {
	private Map _result
	
	/**
	 * Constructor.
	 * @param displayRecord If true, then display the record contents via Logger.info
	 * @param jsonResults The json string returned by calling aws 'servicecatalog describe-record'.
	 */
	public AwsDescribeRecordResult( String jsonResults, boolean displayRecord = false ) {
		if (displayRecord) {
			Logger.info 'aws catalog describe-record returned the following data, which can referenced in the component properties...\n' + jsonResults
		}
		_result = (new JsonSlurper()).parseText( jsonResults )
	}
	
	/**
	 * Returns the 'RecordDetail.Status', such as 'IN_PROGRESS'
	 */
	public String getStatus() {
		return _result.RecordDetail.Status
	}
	
	/**
	 * Is there a RecordOutputs property with the given name?
	 */
	public boolean hasRecordOutputProperty( String name ) {
		Map matchingEntry = _result.RecordOutputs.find { Map entry ->
			String keyname = entry.OutputKey
			return (keyname == name)
		}
		if (matchingEntry) {
			return true
		} else {
			return false
		}
	}

	/**
	 * Retrieve the named RecordOutputs property returning the defaultValue if not found.
	 */
	public def getRecordOutputProperty( String name, String defaultValue='' ) {
		Map matchingEntry = _result.RecordOutputs.find { Map entry ->
			String keyname = entry.OutputKey
			return (keyname == name)
		}  
		if (matchingEntry) {
			return matchingEntry.OutputValue
		} else {
			return defaultValue
		}
	}
	
	/**
	 * Is there an entry in 'RecordDetail.RecordTags' for the name??
	 * Note that the tags are name/value pairs.
	 */
	public boolean hasRecordTag( String name ) {
		Map matchingEntry = _result.RecordDetail.RecordTags.find { Map entry ->
			String keyname = entry.Key
			return (keyname == name)
		}
		if (matchingEntry) {
			return true
		} else {
			return false
		}
	}
	
	/**
	 * Returns the named 'RecordDetail.RecordTags' entry or empty string if not found.
	 * Note that the tags are name/value pairs.
	 */
	public def getRecordTag( String name ) {
		Map matchingEntry = _result.RecordDetail.RecordTags.find { Map entry ->
			String keyname = entry.Key
			return (keyname == name)
		}
		if (matchingEntry) {
			return matchingEntry.Value
		} else {
			return ''
		}
	}
	
	/**
	 * Is there a matching entry in the 'RecordDetail' fields?
	 */
	public boolean hasRecordDetail( String name ) {
		Map recordDetail = _result.RecordDetail
		return recordDetail.containsKey(name)
	}
	
	/**
	 * Returns the matching named 'RecordDetail' fields or empty string if not found.
	 */
	public def getRecordDetail( String name ) {
		Map recordDetail = _result.RecordDetail
		if (recordDetail.containsKey(name)) {
			return recordDetail[name]
		} else {
			return ''
		}
	}
	
	/**
	 * Is there a matching named property.
	 * This checkes (in order) RecordOutputs, RecordDetail.RecordTags, RecordDetail
	 */
	public boolean hasNamedProperty( String name ) {
		return hasRecordOutputProperty(name) || hasRecordTag(name) || hasRecordDetail(name)
	}
	
	/**
	 * Returns the matching named property or empty string if not found.
	 * This checkes (in order) RecordOutputs, RecordDetail.RecordTags, RecordDetail
	 */
	public String getNamedProperty( String name ) {
		if (hasRecordOutputProperty(name)) {
			return getRecordOutputProperty(name)
		} else if (hasRecordTag(name)) {
			return getRecordTag(name)
		} else if (hasRecordDetail(name)) {
			return getRecordDetail(name)
		} else {
			return ''
		}
	}
	
	/**
	 * Returns the 'ProvisionedProductName' which is the instance name that shows up in AWS console
	 * screens.
	 */
	public String getProvisionedProductName() {
		return _result.RecordDetail.ProvisionedProductName
	}
}
