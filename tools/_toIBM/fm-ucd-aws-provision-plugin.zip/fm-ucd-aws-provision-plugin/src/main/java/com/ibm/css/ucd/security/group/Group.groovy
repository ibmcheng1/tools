package com.ibm.css.ucd.security.group;

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.security.UserOrGroup
import com.ibm.css.ucd.security.user.User
import com.ibm.css.ucd.security.user.UserMgr
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.cache.RestDataCacheWithFields

public class Group extends UserOrGroup {
	// The cache of the entity data for this entity
	private RestDataCacheWithFields _cachedEntityData = new RestDataCacheWithFields()
	private final String INFO_FIELD = 'info'
	private final String MEMBERS_FIELD = 'members'

	/**
	 * Constructor.
	 * @param ucdServer The handle to the UCD Server.
	 * @param info This is an Object version of the info returned with a REST call.
	 * Note that it has at least two fields - name and id.
	 */
	public Group( UcdServerConnection ucdServer, def info ) {
		super( ucdServer, info.name, info.id )
		_cachedEntityData.setField(ucdServer, INFO_FIELD, info)
	}
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 */
	public Group( UcdServerConnection ucdServer, String name, String id ) {
		super( ucdServer, name, id )
	}
	
	/**
	 * Returns the entity data (aka data from REST call) optionaly forcing a cache
	 * refresh.  Note that the cache may reset even if 'resetCache' is false.
	 * @return the Structured data map for the entity data.
	 */
	public Map getEntityData( boolean resetCache=false ) {
		def entityData = _cachedEntityData.getField(ucdServer,INFO_FIELD,resetCache)
		if (! entityData) {
			// reload the entity
			def rawEntityData = (new RestGet( ucdServer ))
					.setPath('/security/group/' + id)
					.getAsObject()
			// Convert the raw data into an entity
			_cachedEntityData.setField(ucdServer, INFO_FIELD, rawEntityData)
		}
		return _cachedEntityData.getField(ucdServer,INFO_FIELD)
	}
	
	/**
	 * Returns the members of the group.
	 * @param resetCache If true, then the entire entity cache is reset.
	 */
	public List<User> getMembers( boolean resetCache=false ) {
		List<User> members = null
		UserMgr userMgr = UserMgr.getInstance(ucdServer)
		
		// Check the current cache
		members = _cachedEntityData.getField( ucdServer, MEMBERS_FIELD, resetCache )
		
		if (! members) {
			// NOT cached, load the list
			members = []
			def rawEntityData = (new RestGet( ucdServer ))
				.setPath('/security/group/' + id + '/members')
				.getAsObject()
			rawEntityData.each { def rawEntry ->
				members << userMgr.getByNameAndId(rawEntry.name, rawEntry.id)
			}
			_cachedEntityData.setField(ucdServer, MEMBERS_FIELD, members)
		}
		return members
	}
}
