
package com.ibm.css.ucd.component.version

import java.nio.charset.Charset

import org.apache.http.entity.mime.HttpMultipartMode
import org.apache.http.entity.mime.MultipartEntity
import org.apache.http.entity.mime.content.FileBody
import org.apache.http.entity.mime.content.StringBody

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.component.version.ComponentVersionApi
import com.ibm.css.ucd.common.CacheData
import com.ibm.css.ucd.common.EntityWithNameAndId
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.addfiles.AddFilesDefinition
import com.ibm.css.ucd.component.version.addfiles.BaseDirectoryDefinition
import com.ibm.css.ucd.component.version.download.DownloadFilesDefinition
import com.ibm.css.ucd.status.*
import com.ibm.issr.core.file.AntFilesetWildcard
import com.ibm.issr.core.file.ChecksumHelper
import com.ibm.issr.core.file.FileHelper
import com.ibm.issr.core.file.filter.FilterFiles
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPost


class ComponentVersion extends EntityWithNameAndId {
	/**
	 * Cached set of entries for this entity
	 * <pre>
	 * key = UcdServerConnection
	 * value = Map where
	 *     key = id
	 *     value = entity class, such as Application or Environment
	 * </pre>
	 */
	static protected Map cache = [:]
	
	// Cached List of component version statuses.  Each entry of type ComponentVersionSnapshotInstance.
	CacheData _cached_componentVersionStatusInstances = new CacheData(ComponentVersion.class, false)

	// The component that this is a version of
	Component component
	
	// ** Additional Properties **
	// Component Versions have a different API (as of 7.0.2).  There is NO 'get Info' API call
	// for component versions.  The only way to get additional information is to
	// get all of the ComponentVersions for a Component!!  So, it's best to get all of the
	// component version data in the constructor.  But, some of the other functions create
	// a component version from just a name and id and don't have access to the additional data.
	// So, there is a simple constructor (with just name and id) and a constructor with more data.
	// If the additional data isn't loaded, then this throws an exception on attempts to
	// get the data.
	boolean additionalDataLoaded = false
	// '_created' is the date that the ComponentVersion was created and is cached
	long _created

	// ** Cached internal data **
	// _managedProperties is the list of associated Managed Properties.  If any property changes, reset this cached data back to null
	List _managedProperties = null
	
	/**
	 * Constructor.
	 * @param component The component that this is a version of
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 */
	public ComponentVersion( UcdServerConnection ucdServer, Component component, String name, String id ) {
		super( ucdServer, name, id )
		this.component = component
	}

	
	/**
	 * Constructor.
	 * @param component The component that this is a version of
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param versionData This is the data retrieved for each Component Version by the /cli/component/versions
	 * API call.
	 */
	public ComponentVersion( UcdServerConnection ucdServer, Component component, def versionData ) {
		super( ucdServer, versionData.name, versionData.id )
		this.component = component
		this.additionalDataLoaded = true
		this._created = versionData.created
	}

	/**
	 * Cached creation of new entities.  If the entity is already in the cache, the existing entity
	 * is returned.  Otherwise, a new entity is created, added to the cache and returned.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param component The component that this is a version of
	 * @param name The name.
	 * @param id The id.
	 * @return The requested entity.
	 */
	public static ComponentVersion getComponentVersionWithCache( UcdServerConnection ucdServer, Component component, String name, String id ) {
		if (! cache.containsKey(ucdServer)) {
			cache[ucdServer] = [:]
		}
		if (! cache[ucdServer].containsKey(id)) {
			cache[ucdServer][id] = new ComponentVersion( ucdServer, component, name, id )
		}
		return cache[ucdServer][id]
	}
	
	/**
	 * When a ComponentVersion is loaded into memory, the 'created' field may be known without the rest
	 * of the additional entity data.  In that case, this function can be called.
	 * @param created Date that this componentVersion was created in milliseconds.
	 */
	public void setCreated( long created ) {
		_created = created
	}

	/**
	 * Gets the date/timestamp (as long milliseconds) for the component Version.
	 */
	public long getCreated() {
		if (_created) {
			return _created
		} else if (! additionalDataLoaded) {
			throw new Exception( "INTERNAL ERROR - you can only retrieve this data the full ComponentVersion constructor is called")
		} else {
			return _created
		}
	}
	
	/**
	 * Returns the List of Managed Properties for this Component Version.
	 * @return This returns the return value from the /cli/version/versionPropDefs
	 * API call, which is a List of Mapped data.  At a minimum, each mapped entry
	 * has a name and value property.
	 */
	public List getManagedProperties() {
		if (! _managedProperties) {
			_managedProperties = ComponentVersionApi.getComponentVersionProperties( ucdServer, component.id, this.id )
		}
		return _managedProperties
	}
	
	
	/**
	 * Returns the value of the named managed property.  If not found, this throws an exception.
	 */
	public String getManagedProperty( String name ) {
		List managedProperties = getManagedProperties()
		String value = null
		managedProperties.each { def entry ->
			if (entry.name == name) {
				value = entry.value
			}
		}
		if (value == null) {
			throw new Exception( "Unable to find a property named '${name}' for version '${this.name}' of component '${component.name}'")
		}
		return value
	}
	
	/**
	 * Is there a named Managed Property for this component version with the given name?
	 */
	public boolean doesManagedPropertyExist( String name ) {
		List managedProperties = getManagedProperties()
		boolean found = false
		managedProperties.each { def entry ->
			if (entry.name == name) {
				found = true
			}
		}
		return found
	}
	
	/**
	 * Us there a named Managed Property with the given name?  This is the same as the
	 * function doesManagedPropertyExist()
	 */
	public boolean hasManagedProperty( String name ) {
		return doesManagedPropertyExist( name )
	}
	
	
	/**
	 * Sets the value of the given managed property.  If the property doesn't exist in the
	 * Component's list of defined component version properties, then it is not created/assigned.
	 */
	public void setManagedProperty( String name, String value ) {
		ComponentVersionApi.setComponentVersionProperty( ucdServer, component.getId(), this.getId(), name, value, false )
	}
	
	/**
	 * Returns a List of the ComponentVersionStatusInstance elements associated with this component version.
	 * Each element of the list is of the type 'ComponentVersionStatusInstance'.  The list may be empty.
	 * @param resetCache If true, then resets the cache of status information
	 * for this objects and reloads from UCD Server.
	 */
	public List getStatuses(boolean resetCache=false) {
		List statusInstances = _cached_componentVersionStatusInstances.getCacheData(resetCache)
		if (statusInstances == null) {
			statusInstances = []
			List rawList = ComponentVersionApi.getComponentVersionFlags( ucdServer, this.id )
			rawList.each { def statusDef ->
				statusInstances << new ComponentVersionStatusInstance(ucdServer, this, statusDef.name, statusDef.id)
			}
			_cached_componentVersionStatusInstances.setCacheData(statusInstances)
		}
		return statusInstances
	}

	/**
	 * Returns a List of the ComponentVersionStatusInstance elements associated with this component version.
	 * Each element of the list is of the type 'ComponentVersionStatusInstance'.  The list may be empty.
	 * Use getStatuses() instead.
	 * @param resetCache If true, then resets the cache of status information
	 * for this objects and reloads from UCD Server.
	 */
	@Deprecated
	public List getComponentVersionStatuses(boolean resetCache=false) {
		return getStatuses(resetCache)
	}
	
	/**
	 * Does this component version have the given status?
	 * @param componentVersionStatus Component version status to test for
	 * @param resetCache If true, then resets the cache of status information
	 * for this object and reloads from UCD Server.
	 */
	public boolean hasStatus( ComponentVersionStatus componentVersionStatus, boolean resetCache=false ) {
		return getComponentVersionStatuses(resetCache).find { ComponentVersionStatusInstance componentVersionStatusInstance ->
			return componentVersionStatusInstance.getComponentVersionStatus().equals(componentVersionStatus)
		}
	}

	/**
	 * Does this component version have the given status?  Use hasStatus() instead.
	 * @param componentVersionStatus Component version status to test for
	 * @param resetCache If true, then resets the cache of status information
	 * for this object and reloads from UCD Server.
	 */
	@Deprecated
	public boolean hasComponentVersionStatus( ComponentVersionStatus componentVersionStatus, boolean resetCache=false ) {
		return hasStatus( componentVersionStatus, resetCache )
	}
	
	/**
	 * Adds the given component version status flag.  This throws an exception if the status is already set.
	 */
	public void addStatus( ComponentVersionStatus componentVersionStatus ) {
		ComponentVersionApi.setComponentVersionFlag(ucdServer, this.id, componentVersionStatus.name)
		// reset the cache
		_cached_componentVersionStatusInstances .clearCacheData()
	}
	
	/**
	 * Adds the given status to this component version.  This is deprecated to addStatus()
	 */
	@Deprecated
	public void addComponentVersionStatus( ComponentVersionStatus componentVersionStatus ) {
		addStatus(componentVersionStatus)
	}
	
	/**
	 * Removes the given ComponentVersionStatus from this ComponentVersion.  Throws an exception
	 * if the status is not associated with this ComponentVersion.
	 *
	 */
	public void removeStatus( ComponentVersionStatus status ) {
		ComponentVersionApi.removeComponentVersionFlag(ucdServer, this.id, status.name)
	}
	
	/**
	 * <p>Downloads files from the ComponentVersion to the named 'targetDirectory'.</p>
	 * <p>The closure can call the methods defined in
	 * {@link com.ibm.css.ucd.component.version.download.DownloadFilesDefinition DownloadFilesDefinition}
	 * without a variable referencee.  Specifically, the 'delegate' for the
	 * function is of type DownloadFilesDefinition.  If you aren't familiar with Groovy delegates, it is
	 * similar to 'this'.</p>
	 * <p>This is an example call.</p>
	 * <pre>
	 * componentVersion.downloadFiles {
	 *    // FUTURE - include + exclude
	 *    // include "**&#47;*"
	 *    // exclude "*.class"
	 *    // exclude "abc.txt"
	 *    setExecutionBits true
	 * }
	 * </pre>
	 *
	 * @param targetDirectory The name of the target directory which may be absolute or relative to the
	 * current active directory.
	 */
	public void downloadFiles( String targetDirectory, Closure defineFiles = {} ) {
		File targetDir = new File( targetDirectory )
		DownloadFilesDefinition definition = new DownloadFilesDefinition()
		defineFiles.delegate = definition
		defineFiles()

		_downloadFilesRecursively( targetDir, definition, '' )
	}
	
	/**
	 * <p>Recursively downloads the files from the repository.</p>
	 * @param definition Definition of the download criteria, such as 'include's and 'exclude's.
	 * @param repositoryFolder The parent folder.  This is '' for the root folder.  Otherwise,
	 * it looks like 'folder/nestedFolder'
	 */
	private void _downloadFilesRecursively( File targetDirectory, DownloadFilesDefinition definition, String repositoryFolder ) {
		// Get the list of files and folders in this folder
		RestGet restGet = (new RestGet( ucdServer )).setPath("/cli/version/listVersionArtifacts")
			.addParameter("version", this.id)
		if (repositoryFolder) {
			restGet.addParameter("singleFilePath", repositoryFolder)
		}
		List versionFiles = restGet.getAsObject()
		
		/**
		 * Should the given filePath (which may be a file or directory) be included in the download
		 * as per the 'definition'? Return boolean
		 */
		Closure includePath = { String filePath, DownloadFilesDefinition filesDefinition ->
			boolean matches = false
			// Search for at least one matching 'include' clause
			boolean includeMatch = filesDefinition.getIncludes().find { String expression ->
				AntFilesetWildcard filesetWildcard = new AntFilesetWildcard()
				return filesetWildcard.doesMatch( filePath, expression )
			}
			if (includeMatch) {
				// Search for at least one matching 'exclude' clause
				boolean excludeMatch = filesDefinition.getExcludes().find { String expression ->
					AntFilesetWildcard filesetWildcard = new AntFilesetWildcard()
					return filesetWildcard.doesMatch( filePath, expression )
				}
				if (! excludeMatch) {
					matches = true
				}
			}
			return matches
		}
		
		versionFiles.each { Map versionFile ->
			if (versionFile.type == "file") {
				// Process file
				if (includePath( versionFile.path, definition )) {
					
					File file = new File( targetDirectory, versionFile.path )
					
					// Make sure that the parent directory exists
					file.getParentFile().mkdirs()
					
					// Download the file
					file.withOutputStream() { OutputStream outputStream ->
						(new RestGet( ucdServer )).setPath("/cli/version/downloadArtifacts")
							.addParameter("version", this.id)
							.addParameter("singleFilePath", versionFile.path )
							.getToOutputStream(outputStream)
					}
				}
			} else if (versionFile.type == "folder") {
				// Process folder
				File folder = new File( targetDirectory, versionFile.path )
				if (includePath( versionFile.path, definition )) {
					folder.mkdirs()
				}
				// Recurse
				_downloadFilesRecursively( targetDirectory, definition, versionFile.path )
			} else {
				throw new Exception( "Error downloading files - file '"+ versionFile.path + "' has unexpected file type of " + versionFile.type )
			}
		}
		
	}

	/**
	 * <p>Add/upload files to this component version.  This uses a DSL closure to define the upload
	 * files!!</p>
	 * <p>The methods in
	 * {@link com.ibm.css.ucd.component.version.addfiles.AddFilesDefinition AddFilesDefinition}
	 * can be called within the Closure without a variable reference.  Specifically, the 'delegate' for the
	 * function is of type BaseDirectoryDefinition.  If you aren't familiar with Groovy delegates, it is
	 * similar to 'this'.</p>
	 * <p>This is an example call.</P
	 * <pre>
	 * componentVersion.addFiles {
	 *    baseDirectory( "." ) {
	 *       include "**&#47;*"
	 *       exclude "*.class"
	 *       exclude "abc.txt"
	 *       saveExecutionBits true
	 *    }
	 *    baseDirectory( "c:/tempp" ) {
	 *       include "sample.txt"
	 *    }
	 * }
	 * </pre>
	 * @param defineFiles
	 */
	public void addFiles( Closure defineFiles ) {
		/**
		 * <p>This is the list of files and folders that need to be sent to the server.
		 * The map key is the File() (for the file or directory).  The value is a field Map.
		 * Currently, the value map is empty for directories.  For files it has the following
		 * mapped fields.</p>
		 * <ul>
		 * <li>boolean saveExecutionBits - The execution bits option for the file.  This is optional
		 * and defaults to false.</li>
		 * <li>String relativePath - The path to the file/folder relative to the associated base directory.</li>
		 * </ul>
		 */
		Map files = [:]
		
		FileHelper fileHelper = new FileHelper()
		ChecksumHelper checksumHelper = new ChecksumHelper()

		/**
		 * Adds/updates the given file in the 'files' list.
		 */
		Closure addFileToFiles = { File baseDirectory, File file, boolean saveExecutionBits ->
			if (files.containsKey(file)) {
				// update the entry if saveExecutionBits is true
				if (saveExecutionBits) {
					files[file].saveExecutionBits = saveExecutionBits
				}
			} else {
				files[file] = [saveExecutionBits:saveExecutionBits, relativePath:fileHelper.calculateRelativePath(baseDirectory, file)]
			}
		}
		
		AddFilesDefinition addFilesDefinition = new AddFilesDefinition()
		
		// Call the closure with a delegate to collect all of the needed nested DSL information
		defineFiles.delegate = addFilesDefinition
		defineFiles()
		
		// Process the defined DSL information
		addFilesDefinition.getBaseDirectoryDefinitions().each { Map filesDefinition ->
			// Each loop through this iterator is another defined base directory with its own includes and excludes
			// Add/update the files to the list
			
			File baseDirectory = new File( filesDefinition.directoryName )
			BaseDirectoryDefinition baseDirectoryDefinition = filesDefinition.baseDirectoryDefinition
			FilterFiles filterFiles = filesDefinition.filterFiles
			boolean saveExecutionBits = baseDirectoryDefinition.isSaveExecutionBits()
			
			// Get the list of files in this filter
			List filteredFiles = filterFiles.applyFilter()
			// loop through the files adding the file AND its path nodes to the list that needs to be processed
			filteredFiles.each { File filteredFile ->
				addFileToFiles( baseDirectory, filteredFile, saveExecutionBits )
				
				List directories = fileHelper.getIntermediateDirectories( baseDirectory, filteredFile )
				directories.each { File directory ->
					addFileToFiles( baseDirectory, directory, saveExecutionBits )
				}
			}
			
		}
		
		// Build the multipart entity
		MultipartEntity entity = new MultipartEntity( HttpMultipartMode.BROWSER_COMPATIBLE )
		
		// add the version id
		entity.addPart("version", new StringBody(this.id,"text/plain",Charset.forName("UTF-8")) )
		
		// If two physical files have the same name and checksum, then only upload the file one time
		// to that end, this map uses a file checksum as the key.  The value is a Set of filenames (just the name
		// of the file and not the path
		Map checksumIndexedFiles = [:]
		
		// 'files' contains the list of files and folders to upload
		// Iterate the files and add to mulitpart form
		files.each { File file, Map fileInfo ->
			if (file.isDirectory()) {
				// Process Directory
				Map payload = [
					path:fileInfo.relativePath,
					version:1,
					type:'DIRECTORY',
					length:0,
					modified:file.lastModified()
					]
				String payloadString = groovy.json.JsonOutput.toJson( payload )
				entity.addPart("entryMetadata", new StringBody(payloadString,"text/plain",Charset.forName("UTF-8")) )
			} else {
				// Process File
				// calculate SHA-256 hash key
				String checksum = checksumHelper.calculateChecksum(file, 'SHA-256').encodeHex().toString()
				String filename = file.getName()
				boolean fileAlreadyUploaded = false
				if (checksumIndexedFiles.containsKey(checksum)) {
					if (checksumIndexedFiles[checksum].contains(filename)) {
						fileAlreadyUploaded = true
					} else {
						checksumIndexedFiles[checksum] << filename
					}
				} else {
					checksumIndexedFiles[checksum] = [filename] as Set
				}
				if (! fileAlreadyUploaded) {
					// Add the file to the multipart form
					FileBody filebody = new FileBody( file )
					entity.addPart("entryContent-"+checksum, filebody)
				}
				// Add the file description to the multiplart form.
				Map payload = [
					path:fileInfo.relativePath,
					contentHash:"SHA-256{" + checksum + "}",
					version:1,
					type:'REGULAR',
					length:file.length(),
					modified:file.lastModified()
					]
				String payloadString = groovy.json.JsonOutput.toJson( payload )
				entity.addPart("entryMetadata", new StringBody(payloadString,"text/plain",Charset.forName("UTF-8")) )
			}
		}
		
		(new RestPost(ucdServer))
			.setPath("/cli-internal/version/addVersionFilesFull")
			.setMultiPartEntity(entity)
			.setHeader('Accept', '*/*')
			.postWithNoReturnObject()
	}
}
