package com.ibm.services.ucr.api.framework

import com.ibm.issr.rest.RestServerConnection

/**
 * Base class for all UCR Entity classes.
 * @author LeonClark
 *
 */
class UcrEntity {
	RestServerConnection ucrServer
	
	protected UcrEntity( RestServerConnection ucrServer ) {
		this.ucrServer = ucrServer
	}
}
