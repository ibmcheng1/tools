package com.ibm.css.rest.ucd.application

import groovy.json.JsonOutput

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPut

/**
 * Interface to the UCD Application API REST calls.  This is a lightweight class and it is ok to create lots of instances of it.
 * @author ltclark
 */
class ApplicationApi {
	UcdServerConnection ucdServer
	
	/**
	 * Constructor for this light weight class.
	 * @param ucdServer Handle to UCD Server
	 */
	public ApplicationApi( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
	}

	/**
	 * Creates a new UCD Application which is NOT based on a template.  Throws exception on failure.
	 * @param applicationName The name of the new UCD Application.
	 * @param description Optional description of the new Application.  This can be null or an empty string.
	 * @param enforceCompleteSnapshots Should complete snapshots be enforced.
	 * @param notificationScheme Optional notification scheme name.  This can be null or an empty string.
	 * @return Returns the ID of the new application.
	 */
	public String createApplication( String applicationName, String description="", boolean enforceCompleteSnapshots=false, String notificationScheme="" ) {
		def payload = [ name: applicationName, enforceCompleteSnapshots: enforceCompleteSnapshots ]
		if (description) {
			payload.description = description
		}
		if (notificationScheme) {
			payload.notificationScheme = notificationScheme
		}
		def restResults = (new RestPut( ucdServer )).setPath("/cli/application/create")
			.setPayload(JsonOutput.toJson( payload ))
			.putAsObject()
		return restResults.id
	}

		
	/**
	 * Creates a new Application based on a template.
	 * @param applicationTemplateID The ID of the Application Template.  Required
	 * @param applicationName The name of the new application.  Required
	 * @param description The description of the new application.  Optional (may be empty string or null)
	 * @param notificationScheme The name of the notification scheme to use.  Optional
	 * @param componentIds This is a List of 'String componentId's to include.  Optional.
	 * @return The new Application's ID.
	 * @deprecated
	 */
	@Deprecated
	public String createApplicationFromTemplate( String applicationTemplateID, String applicationName, String description, String notificationScheme,
		List componentIds ) {
		def payload = [ name: applicationName, templateId: applicationTemplateID ]
		if (description) {
			payload.description = description
		}
		if (notificationScheme) {
			payload.notificationScheme = notificationScheme
		}
		if (componentIds && componentIds.size() > 0) {
			payload.existingComponentIds = componentIds 
		}
		def restResults = (new RestPut( ucdServer )).setPath("/cli/application/createApplicationFromTemplate")
			.setPayload(JsonOutput.toJson( payload ))
			.putAsObject()
		return restResults.id
	}

	/**
	 * Returns the list of all UCD Applications.
	 * @param ucdServer Handle to a UCD Server
	 * @return Returns the list that comes from the REST call to '/cli/application'.
	 */
	@Deprecated
	public static List getApplications( UcdServerConnection ucdServer ) {
		return (new ApplicationApi(ucdServer)).getApplications()
	}
	
	/**
	 * Returns the list of all UCD Applications.
	 * @return Returns the list that comes from the REST call to '/cli/application'.
	 */
	public List getApplications(  ) {
		List applications = (new RestGet( ucdServer ))
			.setPath("/cli/application")
			.getAsObject()
		return applications
	}
	
	/**
	 * Returns the list of all environments for the Application.
	 * @return Returns the list that comes from the REST call to '/cli/application/environmentsInApplication'.
	 * At a minimum, each entry in the list includes the environment's 'name' and 'id'.
	 */
	public List getEnvironmentsInApplication( String applicationId ) {
		return (new RestGet( ucdServer )).setPath("/cli/application/environmentsInApplication")
			.addParameter("application", applicationId)
			.getAsObject()
	}

	
	/**
	 * Returns the list of teams (and corresponding team Resource Roles) for the given application.
	 * The return value is a List of Map entries.  The Map entries are the dynamic properties
	 * of teamId, teamLabel, resourceRoleId and resourceRoleLabel.  Note that the resourceRoleId
	 * and resourceRoleLabel are NOT defined if it is a Standard team.
	 * @param ucdServer
	 * @param applicationId
	 * @return
	 */
	public static def getTeams( UcdServerConnection ucdServer, String applicationId ) {
		def teamList = []
		def appInfo = (new RestGet( ucdServer )).setPath("/cli/application/info").addParameter("application", applicationId).getAsObject()
		appInfo.extendedSecurity.teams.each { def team ->
			def newTeamEntry = [:]
			newTeamEntry.teamId = team.teamId
			newTeamEntry.teamLabel = team.teamLabel
			if (team.containsKey('resourceRoleId')) {
				newTeamEntry.resourceRoleId = team.resourceRoleId
			}
			if (team.containsKey('resourceRoleLabel')) {
				newTeamEntry.resourceRoleLabel = team.resourceRoleLabel
			}
			teamList << newTeamEntry
		}
		return teamList
	}
	
	
	/**
	 * Returns the information for the application by application name.  The information is the
	 * object returned by the REST call to /cli/application/info
	 * @param ucdServer Handle to the UCD server.
	 * @param applicationNameOrId The name OR id of the application.
	 * @return The object map.
	 */
	@Deprecated
	public static def getApplicationInfo( UcdServerConnection ucdServer, String applicationNameOrId ) {
		return (new ApplicationApi(ucdServer)).getApplicationInfo( applicationNameOrId )
	}
	
	
	/**
	 * Returns the information for the application by application name.  The information is the
	 * object returned by the REST call to /cli/application/info
	 * @param applicationNameOrId The name OR id of the application.
	 * @return The object map.
	 */
	public def getApplicationInfo( String applicationNameOrId ) {
		return (new RestGet( ucdServer ))
			.setPath("/cli/application/info")
			.addParameter("application", applicationNameOrId)
			.getAsObject()
	}
	
	/**
	 * Does the named application exist?
	 * @param applicationName The name of the application
	 * @return true or false
	 */
	public boolean doesApplicationExist( String applicationNameOrId ) {
		return (new RestGet( ucdServer ))
			.setPath("/cli/application/info")
			.addParameter("application", applicationNameOrId)
			.getAsExistenceTest()
	}

	
	/**
	 * Returns the Application ID for the named application.
	 * @param ucdServer Handle to the UCD Server.
	 * @param applicationName The name of the application.
	 * @return Returns the ID.
	 */
	@Deprecated
	public static String getApplicationId( UcdServerConnection ucdServer, String applicationName ) {
		return (new ApplicationApi(ucdServer)).getApplicationId( applicationName )
	}
	
	
	/**
	 * Returns the Application ID for the named application.
	 * @param applicationName The name of the application.
	 * @return Returns the ID.
	 */
	public String getApplicationId( String applicationName ) {
		def appInfo = getApplicationInfo(applicationName)
		return appInfo.id
	}
	
	/**
	 * Adds the component to the application.
	 * @param applicationName Name of the application
	 * @param componentName Name of the component
	 */
	@Deprecated
	public static void addComponentToApplication( UcdServerConnection ucdServer, String applicationName, String componentName ) {
		(new ApplicationApi(ucdServer)).addComponentToApplication( applicationName, componentName )
	}
	
	/**
	 * Adds the component to the application.
	 * @param applicationName Name of the application
	 * @param componentName Name of the component
	 */
	public void addComponentToApplication( String applicationName, String componentName ) {
		def restResults = (new RestPut( ucdServer )).setPath("/cli/application/addComponentToApp")
			.addParameter('application', applicationName)
			.addParameter('component', componentName )
			.putWithNoReturnObject()
	}
	
	/**
	 * Returns a List of the Components that are in the application.  This actually returns the
	 * value from the API call /cli/application/componentsInApplication.  At a minimum, each entry
	 * has a field called 'id' which is the ID of the component and a field called 'name' which is the component name.
	 * @param applicationId The application ID.
	 */
	public List getComponentsInApplication( String applicationId ) {
		return (new RestGet( ucdServer )).setPath("/cli/application/componentsInApplication")
			.addParameter("application", applicationId)
			.getAsObject()
	}
}
