package com.ibm.issr.core.prettyprint

/**
 * Utility class to display objects in nice formats.
 * @author LeonClark
 *
 */
class PrettyPrintObject {
	private String _tabString
	
	/**
	 * Constructor
	 * @param tabString The string that represents one tab indent.  It may be a tab or a set of spaces or html or ...
	 */
	public PrettyPrintObject( String tabString='   ' ) {
		_tabString = tabString
	}
	
	/**
	 * Returns a multiple line string which contains the contents of the
	 * object.  It is similar to, but intentionally a little simpler and more
	 * human readable than JSON.
	 * @param obj The object to pretty print.  This may be a POJO (Plain old java object),
	 * map, list, etc.  In particular, this is designed to handle objects that have been
	 * instantiated from parsing JSON.
	 * @param prefixTabs The number of tab positions to prefix all of the output lines with.
	 */
	public String prettyPrint( def obj, int prefixTabs=0 ) {
		return (_tabString*prefixTabs) + recursivelyPrettyPrint( obj, prefixTabs )
	}
	
	/**
	 * Performs a recursive pretty print.  Note that the first line is NOT tabbed in
	 * at all because it may be appended to another line.
	 * @param obj
	 * @param prefixTabs
	 * @return
	 */
	private String recursivelyPrettyPrint( def obj, int prefixTabs ) {
		String prettyString = ""
		if (obj instanceof List) {
			prettyString = "[\n"
			obj.each { def listEntry ->
				prettyString = prettyString + 
					(_tabString*(prefixTabs+1)) + 
					recursivelyPrettyPrint(listEntry, prefixTabs+1) +
					"\n"
			}
			prettyString = prettyString + (_tabString*prefixTabs) + "]"
		} else if (obj instanceof Map) {
			prettyString = "{\n"
			obj.each { def key, def value ->
				prettyString = prettyString + 
					(_tabString*(prefixTabs+1)) +
					key.toString() + ': ' + 
					recursivelyPrettyPrint(value, prefixTabs+1) +
					"\n"
			}
			prettyString = prettyString + (_tabString*prefixTabs) + "}"
		} else {
			prettyString = obj.toString()
		}
		return prettyString
	}
}
