package com.fanniemae.ucr.releasedata

import com.ibm.issr.rest.RestServerConnection
import com.ibm.services.ucr.api.entity.integrationprovider.UcrPluginIntegrationProvider
import com.ibm.services.ucr.api.entity.plugin.UcrPlugin
import com.ibm.services.ucr.api.entity.plugin.UcrPluginMgr
import com.ibm.services.ucr.api.entity.release.UcrRelease

/**
 * This class is used to manage 'Release Data' as defined in the FNMA ReleaseData plugin/integration.
 * This is loosely modeled after the UCR entity 'Mgr' classes providing entity style
 * management of the release data.
 * @author LeonClark
 *
 */
class ReleaseDataMgr {
	
	// Map of the singleton instances of this class.  Key=RestServerConnection, value=instance of this class
	private static Map _singletons = [:]
	
	private static final String RELEASE_PROP_PREFIX = 'release-'
	
	// The server for this instance of the Mgr
	RestServerConnection ucrServer
	
	/**
	 * This is the UCR Integration Provider for the ReleaseData plugin.
	 * This is cached.  There is no need to reset the cache as it very rarely changes.
	 */
	private UcrPluginIntegrationProvider _integrationProvider = null

	/**
	 * Private constructor.
	 * @param ucrServer The associated Rest Server.
	 */
	private ReleaseDataMgr( RestServerConnection ucrServer ) {
		this.ucrServer = ucrServer
	}
	
	/**
	 * Returns the singleton instance of this class for the given Rest Server.
	 */
	public static ReleaseDataMgr getInstance( RestServerConnection ucrServer ) {
		if (! _singletons.containsKey(ucrServer)) {
			_singletons[ucrServer] = new ReleaseDataMgr(ucrServer)
		}
		return _singletons[ucrServer]
	}
	
	/**
	 * Resets any cached release property data.
	 */
	public void resetCachedData() {
		getReleaseDataIntegrationProvider().resetCachedData()
	}

	/**
	 * Returns (and caches) the Integration Provider for the UCR DataRelease plugin integration.
	 * Throws exception if not found.
	 */
	private UcrPluginIntegrationProvider getReleaseDataIntegrationProvider() {
		if (! _integrationProvider) {
			UcrPlugin plugin
			try {
				plugin = UcrPluginMgr.getInstance(ucrServer).getByPluginId('com.fanniemae.urbancode.plugin.ucr.releasedata')
			}
			catch (Exception e) {
				throw new Exception( "In order to manage Release Data, the plugin 'FannieMae Release Data Mgr' MUST be installed with one (and only one) integration defined", e )
			}
			List integrationProviders = plugin.getIntegrationProviders()
			if (integrationProviders.size() != 1) {
				throw new Exception( "In order to manage Release Data, the plugin 'FannieMae Release Data Mgr' MUST be installed with one (and only one) integration defined")
			} else {
				_integrationProvider = integrationProviders[0]
			}
		}
		return _integrationProvider
	}
	
	
	/**
	 * Returns a {@link ReleaseData} entity for the given release.  Use that
	 * entity to access or update the release specific data.  Note that even if the
	 * given release has absolutely no data, this still returns a ReleaseData object.
	 */
	public ReleaseData getForRelease( UcrRelease release ) {
		return new ReleaseData( release.getId(), getReleaseDataIntegrationProvider() )
	}
	
	
	/**
	 * Returns a {@link ReleaseData} entity for the given release ID.  Use that
	 * entity to access or update the release specific data.  Note that even if the
	 * given release has absolutely no data, this still returns a ReleaseData object.
	 */
	public ReleaseData getForReleaseId( String releaseId ) {
		return new ReleaseData( releaseId, getReleaseDataIntegrationProvider() )
	}

	/**
	 * This function iterates ALL of the releases that have release data.
	 * For each release, it calls the 'processEntry' closure.
	 * @param processEntry The syntax of this closure is 'void processEntry( String releaseId,
	 * Map processData ) where...
	 * <ul>
	 * <li>releaseId - The ID of the release.</li>
	 * <li>processData - The processData JSON converted to an object Map</li>
	 * </ul> 
	 */
	public void eachReleaseData( Closure processEntry ) {
		Map providerProperties = getReleaseDataIntegrationProvider().getEntityProperties()
		providerProperties.each { String propertyName, String propertyValue ->
			String releaseId = calculateReleaseIdForPropertyName(propertyName)
			if (releaseId) {
				processEntry( releaseId, new groovy.json.JsonSlurper().parseText(propertyValue) )
			}
		}
	}
	
	/**
	 * This function iterates ALL of the releases that have release data.
	 * For each release, it calls the 'processEntry' closure.
	 * @param processEntry The syntax of this closure is 'void processEntry( String releaseId,
	 * String processData ) where...
	 * <ul>
	 * <li>releaseId - The ID of the release.</li>
	 * <li>processData - The processData in the stored JSON format (and NOT converted to objects)</li>
	 * </ul>
	 */
	public void eachReleaseDataAsJson( Closure processEntry ) {
		Map providerProperties = getReleaseDataIntegrationProvider().getEntityProperties()
		providerProperties.each { String propertyName, String propertyValue ->
			String releaseId = calculateReleaseIdForPropertyName(propertyName)
			if (releaseId) {
				processEntry( releaseId, propertyValue )
			}
		}
	}

	
	/**
	 * Calculates and returns the property name for the given release' release data.
	 * @param releaseId The ID of the release.
	 */
	public static String calculatePropertyNameForReleaseId( String releaseId ) {
		return RELEASE_PROP_PREFIX + releaseId
	}
	
	/**
	 * Given a property name in the integration provider, if it is a Release Property, then
	 * this returns the releaseId; otherwise, this returns null. 
	 */
	public static String calculateReleaseIdForPropertyName( String propertyName ) {
		if (propertyName.startsWith(RELEASE_PROP_PREFIX)) {
			return propertyName.substring(RELEASE_PROP_PREFIX.length())
		} else {
			return null
		}		
	}
}
