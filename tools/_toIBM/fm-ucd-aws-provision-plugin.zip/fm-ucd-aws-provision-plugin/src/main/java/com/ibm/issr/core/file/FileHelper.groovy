package com.ibm.issr.core.file

import java.io.File;

import com.ibm.issr.core.log.LogTracingClass;

/**
 * File helper functions.  This is a singleton
 * @author ltclark
 *
 */
class FileHelper extends LogTracingClass {
	private static instance = new FileHelper()
	
	// constructor is private
	private FileHelper() {
		
	}
	
	/**
	 * Returns the singleton instance.
	 */
	public static FileHelper getInstance() {
		return instance
	}

	/**
	 * Returns the relative path for the file relative to the 'directoryFile'.  For
	 * example if the directory is 'c:/test' and the file is 'c:/test/foo/bar.txt', this
	 * returns 'foo/bar.txt'.
	 * @param directoryFile Handle to a directory.
	 * @param file Handle to a specific file
	 * @return The relative path.
	 */
	public String calculateRelativePath( File directoryFile, File file ) {
		return directoryFile.toURI().relativize( file.toURI() ).getPath()
	}

	/**
	 * Given a base directory and a File that is somewhere nested within the base directory,
	 * this returns a List of type File with all of the directories between the base directory
	 * and the file.  For example, if the base directory is c:/work and the file is 
	 * c:/work/a/b/c/test.txt, then this returns a List with Files for c:/work/a, c:/work/a/b
	 * and c:/work/a/b/c.
	 * @param baseDirectory The base directory.
	 * @param file A file nested somewhere under the base directory.
	 */
	public List getIntermediateDirectories( File baseDirectory, File file ) {
		List directories = []
		String relativePath = calculateRelativePath( baseDirectory, file )
		File parentFolder = baseDirectory
		relativePath.tokenize('/\\').each { String segment ->
			File nextFolder = new File( parentFolder, segment )
			if (! baseDirectory.equals(parentFolder)) {
				directories << parentFolder
			}
			parentFolder = nextFolder
		}
		return directories
	}
}
