package com.ibm.css.ucd.component

import com.ibm.css.ucd.componenttemplate.ComponentTemplate

/**
 * This class is used to build/create new Components by defining the desired input
 * data for the new Component.  This is used with the closure for the
 * {@link com.ibm.css.ucd.services.ComponentServices#createComponent(String, groovy.lang.Closure) ComponentServices.createComponent()}
 * method.
 * @author LeonClark
 *
 */
class ComponentBuilderDefinition {
	/**
	 * Map which stores the Template defined Component Properties.  The key is
	 * the property name and the value is the defined value.
	 */
	private Map templateDefinedProperties = [:]
	
	/**
	 * If a componentTemplate is provided, then the Component is based on this template.
	 */
	ComponentTemplate componentTemplate
	
	/**
	 * Name of the new Component
	 */
	String name
	
	/**
	 * Optional description
	 */
	String description
	
	/**
	 * Number of most recent versions to 
	 * keep; omit this parameter to inherit the system settings 
	 * (Optional).  If set, it should be set to an integer value.
	 */
	String cleanupCountToKeep
	
	/**
	 * Number of days to keep versions;
	 * omit this parameter to inherit the system settings
	 * (Optional).  If set, it should be set to an integer value.
	 */
	String cleanupDaysToKeep
	
	/**
	 * 
	 * The component's default version type, which can be either
	 * FULL or INCREMENTAL.  This defaults to FULL.
	 */
	String defaultVersionType = "FULL"
	
	/**
	 * Should component versions automatically import.  Defaults to false.
	 */
	boolean importAutomatically = false

	
	/**
	 * Constructor
	 * @param name The name is the only required field, so it is passed to the constructor.
	 */
	public ComponentBuilderDefinition( String name ) {
		this.name = name
	}
	
	/**
	 * If the Component Template defines Component Properties ("Component Property Definitions" in the web GUI), then
	 * you can add a property/value pair for the new component.
	 * @param name The name of the Template defined Component Property, such as "sampleProperty".  Note that the actual
	 * API call that is made prefixes 'template/' in front of this name.  DO NOT put 'template/' in the front yourself in
	 * calling this function.
	 * @param value The value to set.
	 */
	public void addTemplateDefinedProperty( String name, def value ) {
		templateDefinedProperties[name] = value
	}
}
