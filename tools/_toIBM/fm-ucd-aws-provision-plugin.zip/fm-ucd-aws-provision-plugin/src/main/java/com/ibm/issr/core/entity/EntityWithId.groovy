package com.ibm.issr.core.entity

/**
 * Represents an Entity class (aka data storage object) which has an id.  For example,
 * a UCD Application class is an Entity class.  This is designed to work with or without REST based
 * entities.
 * @author LeonClark
 *
 */
interface EntityWithId {
	/**
	 * Returns the entity's id.
	 */
	public String getId()
}
