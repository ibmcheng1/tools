package com.ibm.css.ucd.team

import com.ibm.css.ucd.common.Entity

/**
 * Represents a team which is linked to an entity via an optional role.
 * @author s9ulcc
 *
 */
class LinkedTeam {
	/**
	 * The team
	 */
	public Team team
	
	/**
	 * The associated entity
	 */
	public Entity entity
	
	/**
	 * IF there is an assigned role, this is the role's ID; otherwise, this is an empty string.
	 */
	public String resourceRoleId = ''
	
	/**
	 * IF there is an assigned role, this is the role's name; otherwise, this is an empty string.
	 */
	public String resourceRoleName = ''
	
	
	/**
	 * Constructor
	 * @param teamInfo This is the raw team data (parsed json) which is
	 * an instance of 'entityInfo.security.teams[]' from an entity's 'info'. 
	 * @param entity The linked entity (application, environment, resource, etc)
	 */
	public LinkedTeam( Map teamInfo, Entity entity ) {
		this.entity = entity
		this.team = new Team(entity.ucdServer, teamInfo.teamLabel, teamInfo.teamId)
		if (teamInfo.containsKey('resourceRoleId')) {
			this.resourceRoleId = teamInfo.resourceRoleId
		}
		if (teamInfo.containsKey('resourceRoleName')) {
			this.resourceRoleId = teamInfo.resourceRoleName
		}
	}
	
	
	/**
	 * Given an instance of an entity's info and an entity, returns the list of LinkedTeams.
	 * @param teamsInfo This is the data returned by '/cli/[entityType]/info' after parsing it.
	 * @param entity The associated entity
	 */
	public static List<LinkedTeam> getLinkedTeams( Map entityInfo, Entity entity ) {
		List<LinkedTeam> linkedTeams = []
		if (entityInfo.containsKey('extendedSecurity')) {
			Map securityInfo = entityInfo.extendedSecurity
			if (securityInfo.containsKey('teams')) {
				List teamsInfo = securityInfo.teams
				teamsInfo.each { Map teamInfo ->
					linkedTeams << new LinkedTeam( teamInfo, entity )
				}
			}
		}

		return linkedTeams
	}
}
