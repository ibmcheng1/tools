package com.fanniemae.ucd.aws.provision.def.components.data

import com.fanniemae.ucd.aws.provision.def.common.ValidationErrorReporter

/**
 * Used to represent one entry from the 'ucdComponents' list
 * in the 'ucdComponentsDef.json' file.
 *
 */
class UcdComponentDef {
	public String componentName
	public boolean participateInBlueGreen = false
	/**
	 * In this map, the key is the name of a Component Environment Property and the value is
	 * a String value (which can contain '%...%' tokens) or a boolean value.
	 */
	public Map componentEnvironmentProperties = [:]
	
	/**
	 * Constructor.
	 * @param entryNumber Which entry number is this from the list of components in the list.
	 * @param rawData The parsed JSON data for the entry.
	 * @param errorReporter Used to report any problems.
	 */
	public UcdComponentDef( int entryNumber, Map rawData, ValidationErrorReporter errorReporter ) {
		if (! rawData.containsKey('componentName')) {
			errorReporter.tagValidationError("The ucdComponentsDef file is missing the 'componentName' field for items entry #" + entryNumber)
		} else {
			componentName = rawData.componentName
			if (rawData.containsKey('participateInBlueGreen')) {
				def blueGreen = rawData.participateInBlueGreen
				if (blueGreen instanceof String) {
					participateInBlueGreen = blueGreen.toBoolean()
				} else {
					participateInBlueGreen = blueGreen
				}
			}
			if (rawData.containsKey('componentEnvironmentProperties')) {
				if (! (rawData.componentEnvironmentProperties instanceof Map)) {
					errorReporter.tagValidationError("Within the ucdComponentsDef file, the componentEnvironmentProperties field for component '${componentName}' should be, but is not, a Map")
				} else {
					componentEnvironmentProperties = rawData.componentEnvironmentProperties
				}
			}
		}
	}
}
