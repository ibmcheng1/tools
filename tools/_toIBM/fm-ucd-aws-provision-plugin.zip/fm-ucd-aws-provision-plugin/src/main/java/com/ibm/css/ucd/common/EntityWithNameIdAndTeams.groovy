package com.ibm.css.ucd.common

import java.util.List;

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.common.InfoHelper
import com.ibm.css.rest.ucd.common.TeamMembershipApi
import com.ibm.css.ucd.team.Team;

/**
 * This is an Entity which has a Name, an ID and may also have associated Teams.
 * @author ltclark
 *
 */
class EntityWithNameIdAndTeams extends EntityWithNameAndId {
	// handle to the team membership API interface
	private TeamMembershipApi _teamMembershipApi
	
	 
	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 */
	public EntityWithNameIdAndTeams( UcdServerConnection ucdServer, TeamMembershipApi teamMembershipApi, String name, String id ) {
		super( ucdServer, name, id )
		this._teamMembershipApi = teamMembershipApi
	}
	
	/**
	 * Is this entity associated with the given team and resource type?
	 * @param Team The team.
	 * @param resourceType The optional resource type. If this is null or an empty string, then this looks for a team without a type.
	 * If this is a non-empty string, then it looks for a matching resourceType entry for the team.
	 */
	public boolean isLinkedToTeam( Team team, String resourceType="" ) {
		return _teamMembershipApi.isLinkedToTeam(this.getId(), team.getId(), resourceType)
	}
	
	/**
	 * Removes a link to the given team and optionally to the resourceType (if provided)
	 * @param Team The team.
	 * @param resourceType The optional resource type.
	 */
	public void removeLinkToTeam( Team team , String resourceType="" ) {
		_teamMembershipApi.removeLinkToTeam(this.getId(), team.getId(), resourceType )
	}
	
	/**
	 * Removes links to ALL teams that this entity is linked to.
	 */
	public void removeLinksToAllTeams() {
		_teamMembershipApi.removeLinksToAllTeams(this.getId())
	}
	
	/**
	 * Adds a link to the given team and optionally to the resourceType (if provided)
	 * @param Team The team.
	 * @param resourceType The optional resource type. If this is null or an empty string, then the team is added without a resource type.
	 * If this is a non-empty string, then the team is added with this resource type.
	 */
	public void addLinkToTeam( Team team, String resourceType='' ) {
		_teamMembershipApi.addLinkToTeam(this.getId(), team.getId(), resourceType)
	}
	
	/**
	 * Returns a list of Teams (and corresponding resource types) linked to this entity.
	 * @param entityId The ID of the entity.
	 * @return A List of the linked teams.  Each entry is a map with the fields: 'team' (of type Team) and 'resourceType' (of type String).  resourceType is empty
	 * for the 'default' resource type.
	 */
	public List getLinkedTeams() {
		// The raw list contains ...
		List rawTeamList = _teamMembershipApi.getLinkedTeams(this.getId())
		// The 'teamList' contains member fields: Team team, String resourceType
		List teamList = new ArrayList()
		rawTeamList.each { rawTeamEntry ->
			def teamEntry = [ team: new Team(ucdServer, rawTeamEntry.teamName, rawTeamEntry.teamId), resourceType: rawTeamEntry.resourceType ]
			teamList.add(teamEntry)
		}
		return teamList
	}


}
