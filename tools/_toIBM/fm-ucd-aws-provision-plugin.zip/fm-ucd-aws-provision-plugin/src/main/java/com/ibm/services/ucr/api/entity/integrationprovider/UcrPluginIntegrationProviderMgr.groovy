package com.ibm.services.ucr.api.entity.integrationprovider

import com.ibm.issr.core.entity.IndexedListOfEntities
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.framework.UcrEntityData
import com.ibm.services.ucr.api.framework.UcrEntityDataFormat


/**
 * <p>Manager class for the entity, which includes entity creation and lookup functions.
 * This is a 'RestServerConnection linked Singleton' class - there is one and only one
 * instance of this class for each associated RestServerConnections.</p>
 * <p>Technical notes:</p>
 * <ul>
 * <li>The 'integrationProvider' API calls IGNORE filtering!!!</li>
 * </ul>
 * @author LeonClark
 *
 */
class UcrPluginIntegrationProviderMgr {
	
	// Map of the singleton instances of this class.  Key=RestServerConnection, value=instance of this class
	private static Map _singletons = [:]
	
	// The server for this instance of the Mgr
	RestServerConnection ucrServer
	
	/**
	 * Cached 'List' of ALL Of the UCR Integration Providers.  Each entry is of type UcrPluginIntegrationProvider.
	 */
	private RestDataCache _cachedCompleteList = new RestDataCache()
	 
	/**
	 * Cached list of loaded entities.  The data type of the cache is IndexedListOfEntities, which is
	 * automatically initialized when the cache is created or resest.
	 */
	RestDataCache _entityCache = new RestDataCache(
		// Cache entry initialization closure - Initialize cache entries as instances of IndexedListOfEntities
		{ RestServerConnection ucrServer ->
			return new IndexedListOfEntities(
				// This closure returns the 'uniqueName' for each entry, which is simply the name
				{ UcrPluginIntegrationProvider entity ->
					return entity.getName()
				} 
				)
		}
		) 
	
	/**
	 * Private constructor.
	 * @param ucrServer The associated Rest Server.
	 */
	private UcrPluginIntegrationProviderMgr( RestServerConnection ucrServer ) {
		this.ucrServer = ucrServer
	}
	
	/**
	 * Returns the singleton instance of this class for the given Rest Server.
	 */
	public static UcrPluginIntegrationProviderMgr getInstance( RestServerConnection ucrServer ) {
		if (! _singletons.containsKey(ucrServer)) {
			_singletons[ucrServer] = new UcrPluginIntegrationProviderMgr(ucrServer)
		}
		return _singletons[ucrServer]
	}
	
	/**
	 * Returns the list of UCRPluginIntegrationProviders's.
	 */
	public List getAll( boolean resetCache = false ) {
		if (resetCache) {
			_entityCache.resetCacheData(ucrServer)
		}
		List entityList = _cachedCompleteList.getCacheData( ucrServer, resetCache )
		if (! entityList) {
			// Load the list via REST calls
			entityList = []
			List rawEntityList = (new RestGet( ucrServer ))
					.setPath('/integrationProvider/')
					.setHeader('Accept', 'application/json')
					.getAsObject()
			// convert to entities
			rawEntityList.each { def rawEntity ->
				entityList << buildEntity( ucrServer, new UcrEntityData( rawEntity, UcrEntityDataFormat.LIST_FORMAT ) )
			}
			_cachedCompleteList.setCacheData(ucrServer, entityList)
		}
		return entityList
	}
	
	/**
	 * Returns the IntegrationProvider by ID.  Throws exception if not found.
	 */
	public UcrPluginIntegrationProvider getById( String id, boolean resetCache=false ) {
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer, resetCache)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			return cachedEntities.getEntityById(id)
		} else {
			// not found in cache - make rest call to load it
			def rawEntityData = (new RestGet( ucrServer ))
					.setPath("/integrationProvider/${id}")
//					.addParameter('format', 'detail')
					.setHeader('Accept', 'application/json')
					.getAsObject()
			// Convert the raw data into an entity
			return buildEntity( ucrServer, new UcrEntityData(rawEntityData, UcrEntityDataFormat.LIST_FORMAT ))
		}
	}

	/**
	 * Returns the named IntegrationProvider.  Throws exception if not found.
	 */
	public UcrPluginIntegrationProvider getByName( String name, boolean resetCache=false ) {
		// REST calls to '/integrationProvider/' ignore filters, so load all and manually filter.
		List providers = this.getAll()
		UcrPluginIntegrationProvider provider = providers.find { UcrPluginIntegrationProvider candidate ->
			return (candidate.name == name)
		}
		if (! provider) {
			throw new Exception( "Unable to find integration provider named '${name}'")
		}
		return provider
	}
	
	/**
	 * Given entity data, this returns a UcrPluginIntegrationProvider for that data.
	 * @param ucrServer The server.
	 * @param entityData The data returned from some REST call.
	 * @return New or existing entity.
	 */
	public UcrPluginIntegrationProvider buildEntity( RestServerConnection ucrServer, UcrEntityData entityData ) {
		UcrPluginIntegrationProvider integrationProvider
		String name = entityData.getEntityObject().name
		String id = entityData.getEntityObject().id
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			integrationProvider = cachedEntities.getEntityById(id)
			// Update the cached entityData
		} else {
			integrationProvider = new UcrPluginIntegrationProvider( ucrServer, name, id, entityData )
			cachedEntities.addEntity(integrationProvider)
		}
		return integrationProvider
	}

}
