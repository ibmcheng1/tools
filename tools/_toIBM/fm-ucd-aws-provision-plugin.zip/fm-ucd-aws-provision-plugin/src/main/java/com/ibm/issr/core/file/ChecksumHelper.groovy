package com.ibm.issr.core.file

import com.ibm.issr.core.log.LogTracingClass
import com.ibm.issr.core.log.Logger

/**
 * Checksum utility class - singleton
 * @author ltclark
 *
 */
class ChecksumHelper extends LogTracingClass {
	private static instance = new ChecksumHelper()
	
	// constructor is private
	private ChecksumHelper() {
		
	}
	
	/**
	 * Returns the singleton instance.
	 */
	public static ChecksumHelper getInstance() {
		return instance	
	}

	/**
	 * Calculates the MD5 checksum for a file.
	 * @param file The handle to the file.
	 * @return Returns the checksum string as a 32 character integer string with leading 0s.
	 */
	public String calculateChecksum(File file) {

		if (! (file.exists() && file.isFile())) {
			Logger.abortApplicationWithMessage( "Unable to find a file named ${file.getAbsolutePath()}" )
		}
		java.security.MessageDigest digest = java.security.MessageDigest.getInstance("MD5");
		def checksum = ""
		file.withInputStream() { is ->
			byte[] buffer = new byte[8192]
			int read = 0
			while ( (read=is.read(buffer)) > 0) {
				digest.update(buffer, 0, read)
			}
			checksum = new BigInteger(1, digest.digest()).toString(16).padLeft(32,'0')
		}
		return checksum
	}

	/**
	 * Calculates the checksum of a file using the selected algorithm.
	 * @param file The handle to the file.
	 * @param algorithm This is the name of the algorithm which is used when calling MessageDigest.getIntance(),
	 * such as 'MD5' or 'SHA-256'
	 * @return Returns the checksum as a byte array (byte[]) or null.  The easiest way to convert this
	 * to a hex string is ... calculateChecksum(...).encodeHex().toString().
	 */
	public def calculateChecksum(File file, String algorithm ) {

		if (! (file.exists() && file.isFile())) {
			Logger.abortApplicationWithMessage( "Unable to find a file named ${file.getAbsolutePath()}" )
		}
		java.security.MessageDigest digest = java.security.MessageDigest.getInstance(algorithm);
		def checksum = null
		file.withInputStream() { is ->
			byte[] buffer = new byte[8192]
			int read = 0
			while ( (read=is.read(buffer)) > 0) {
				digest.update(buffer, 0, read)
			}
			checksum = digest.digest()
		}
		return checksum
	}
	
	static void main( String[] args ) {
		println "hello"
		def checksum = ChecksumHelper.getInstance().calculateChecksum(new File("C:/urban/SourceForSampleComponents/apic acme-bank/1.0.3/acme-bank.yaml"), "SHA-256")
		println checksum
		println checksum.encodeHex().toString()
	}
}
