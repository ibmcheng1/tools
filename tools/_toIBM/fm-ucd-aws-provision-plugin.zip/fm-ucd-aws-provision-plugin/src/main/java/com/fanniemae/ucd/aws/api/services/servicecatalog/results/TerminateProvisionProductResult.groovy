package com.fanniemae.ucd.aws.api.services.servicecatalog.results


/**
 * Information about one AWS Product Instance being terminated.
 */
public class TerminateProvisionProductResult {
	private TerminateProvisionProductsResult _parentResults
	
	// The provisioned product name
	String provisionedProductName
	// The RecordId of the product instance
	String recordId
	boolean successful = true			// Was this instance successflly terminated
	String errorMsg				// IF the termination failed, this is a brief description of the failure
	// This is used internally to flag when all processing to terminate the instance is done (pass or fail)
	boolean processingCompleted = false
	
	/**
	 * Constructor.
	 * @param parentResults The parent result object, which has the list of instance reslults
	 */
	public TerminateProvisionProductResult( String provisionedProductName, TerminateProvisionProductsResult parentResults ) {
		this.provisionedProductName = provisionedProductName
		this._parentResults = parentResults
	}
	
	/**
	 * Flag this instance as failed and update all appropriate data fields in this record and the parent.
	 * @param errorMsg
	 */
	public void flagFailure( String errorMsg ) {
		this.processingCompleted = true
		this.successful = false
		this.errorMsg = errorMsg
		_parentResults.successful = false
	}
	
	/**
	 * Set flags and data indicating that this Product Instance was successfully terminated!!
	 */
	public void flagSuccess() {
		this.processingCompleted = true
		this.successful = true
	}
}
