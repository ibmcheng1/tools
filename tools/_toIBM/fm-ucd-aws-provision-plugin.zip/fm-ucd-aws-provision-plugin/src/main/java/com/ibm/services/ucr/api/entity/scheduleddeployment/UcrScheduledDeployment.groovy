package com.ibm.services.ucr.api.entity.scheduleddeployment

import com.ibm.issr.core.entity.EntityWithId
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPost
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.entity.release.UcrRelease
import com.ibm.services.ucr.api.entity.release.UcrReleaseMgr
import com.ibm.services.ucr.api.framework.UcrEntityData
import com.ibm.services.ucr.api.framework.UcrEntityDataFormat
import com.ibm.services.ucr.api.framework.UcrEntityWithNameAndId

/**
 * @author LeonClark
 *
 */
class UcrScheduledDeployment extends UcrEntityWithNameAndId implements EntityWithId {
	// The cache of the UcrEntityData for this entity
	private RestDataCache _cachedEntityData = new RestDataCache()
	
	// The associated UcrRelease.  This does NOT need cache management because the associated Release never changes.
	private UcrRelease _ucrRelease = null

	/**
	 * Private constructor - do NOT call directly from any other class except the corresponding Mgr class.
	 * @param entityData This is optional UcrEntityData (data returned from a REST call defining this entity).  If
	 * given, then it is cached.
	 */
	private UcrScheduledDeployment( RestServerConnection ucrServer, String name, String id, UcrEntityData entityData = null ) {
		super( ucrServer, name, id )
		if (entityData) {
			_cachedEntityData.setCacheData(ucrServer, entityData)
		}
	}
	
	/**
	 * Resets the cached data storing internal data for this class instance.
	 */
	public void resetCachedData() {
		_cachedEntityData.resetCacheData(ucrServer)
	}

		
	/**
	 * Returns entity data for this entity which is at LEAST the 'minDataFormat' level of information.  For example,
	 * if the minDataFormat is LIST_FORMAT, then both LIST_FORMAT and DETAIL_FORMAT are suitable.
	 * If possible, this returns cached data, otherwise it loads (and caches) the data.
	 */
	public UcrEntityData getEntityData( UcrEntityDataFormat minDataFormat, boolean resetCache=false ) {
		UcrEntityData entityData = _cachedEntityData.getCacheData(ucrServer,resetCache)
		if ((! entityData) || (! entityData.getEntityFormat().isSuperset( minDataFormat ))) {
			// Load the 'detail' data and cache it
			def data = (new RestGet( ucrServer ))
				.setPath('/scheduledDeployment/' + this.id)
				.addParameter('format', minDataFormat.getFormatName())
				.setHeader('Accept', 'application/json')
				.getAsObject()
			_cachedEntityData.setCacheData(ucrServer, new UcrEntityData(data, minDataFormat))
		}
		return _cachedEntityData.getCacheData(ucrServer)
	}

	/**
	 * Returns detail'ed entity data.  This is data retrieved via a REST call with format of 'detail'.  If possible,
	 * this returns cached data, otherwise it loads (and caches) the data.
	 */
	public UcrEntityData getDetailedEntityData( boolean resetCache=false ) {
		return getEntityData( UcrEntityDataFormat.DETAIL_FORMAT, resetCache )
	}

	
	/**
	 * Returns at least a LIST level UcrEntityData for this class, which is the underlying REST/JSON based data structure.
	 */
	public UcrEntityData getEntityData( boolean resetCache = false ) {
		return getEntityData( UcrEntityDataFormat.LIST_FORMAT, resetCache )
	}

	/**
	 * Returns the UcrRelease that this SegmentExecution is part of.
	 */
	public UcrRelease getRelease() {
		if (! _ucrRelease) {
			_ucrRelease = UcrReleaseMgr.getInstance(ucrServer).getById(getEntityData().entityObject.release.id)
		}
		return _ucrRelease
	}

	/**
	 * Adds a new External Hyperlink to this Scheduled Deployment, which show up in the 'External Links' section of the 'Overview' tab of
	 * the scheduled deployment.	
	 * @param link This is the hyperlink, such as 'http://server/link'.
	 * @param name This is the name which is displayed.  It can be set to the hyperlink or any string value that you want.
	 * @param description This is a description of the link, which is displayed as a flyover tooltip in the UI.  Note that this is NOT
	 * HTML, but is just plain text.
	 */
	public void addExternalLink( String link, String name, String description ) {
		Map payload = [link:link, name:name, description:description]
		(new RestPost(ucrServer))
			.setPath( '/scheduledDeployments/' + this.getId() + "/externalLink" )
			.setJsonPayloadToObject(payload)
			.setHeader('Accept', '*/*')
			.setHeader('Content-Type', 'application/json')
			.postWithNoReturnObject()
		// Note that the post actually returns the new entity, including it's ID
	}
}
