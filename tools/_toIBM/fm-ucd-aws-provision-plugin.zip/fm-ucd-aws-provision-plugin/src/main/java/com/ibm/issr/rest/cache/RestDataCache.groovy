package com.ibm.issr.rest.cache

import com.ibm.issr.core.log.Logger
import com.ibm.issr.rest.RestServerConnection;


/**
 * <p>An instance of RestDataCache can be used to cache REST server data on the client side
 * for any REST server, include UCD and UCR.
 * </p>
 * <p>Two types of data are supported - static and non-static data
 * </p>
 * <h1>'static' data</h1>
 * <p>'Static' data is meant to be used to manage sets of entities coming back from the server,
 * such as a List of Status entities.
 * </p>
 * <h1>non-static data</h1>
 * <p>'non-static' data meant to be used to manage cached data within one entity instance, such
 * as the information about one Status entry.
 * </p>
 * <p>This cache is designed to work with multiple REST server's at the same time.  As such,
 * every time that the cache is called, the server associated with that cache must be identified.
 * That is provided in the form of a RestServerConnection
 * </p> 
 * <p>Managing the cache data in this class actually simplifies a lot of code, and it also
 * enables broad cache management.  For example, if you call UcrCacheData.resetAllCacheData( RestServerConnection ),
 * all managed cached data (static and non-static) across all classes is automatically reset for the
 * given REST server!!
 * </p>
 * <p>How does it work?  When cached data is set (via the setData() method), the time that the data was set is
 * stored.  When cached data is reset, the reset time is stored.  Then, when cached data is retrieved,
 * its time is compared to the last reset time.  If the data was stored before the reset time, then it
 * is reset and a null is returned.
 * </p>
 * @author LeonClark
 *
 */
class RestDataCache {
	
	/**
	 * Map of the last time each RestConnectionServer was reset.
	 * Key = RestConnectionServer.  Value = timestamp (in milliseconds) last set.
	 */
	private static Map lastResetTimestampMap = [:] 
	
	/**
	 * This is a Map of the cache data which is managed by Rest Servers.
	 * <br/>
	 * The Key is RestServerConnection - so each server has it's own set of cached data.
	 * <br/>
	 * The value is a structured property map. In this 'data' is the cached data for the server with
	 * data type of 'def'.  'timeStamp' is a long value, which is the timestamp (milliseconds) when
	 * the cache for this server was last set.  'locked' is defined and set to true of the data is locked (so
	 * that it won't flush from the cache).
	 */
	private Map cacheByRestServerMap = [:]
	
//	 the cache is considered to be empty if the data is null
//	private def _data = null
//	// The timestamp (milliseconds) when the cache data was last set
//	private long timeStamp = 0
	
	/**
	 * This optional closure is called (if not null) to initialize the value for any newly accessed (or reset)
	 * cache for a given RestServer.  This is very useful for cached lists of Entities.  Basically, when this
	 * is defined, the call to getCacheData() ALWAYS returns a value, even if it is just an empty 'list' (when
	 * reset).  The template for the closure is: def initializeDataForRestServer( RestServer restServer ).  The
	 * closure returns a new, 'empty' data element, such as an empty List or Map.
	 */
	protected Closure initializeDataForRestServer = null
	
	/**
	 * Constructor for a cache.
	 * @param initializeDataForRestServer 
	 * This optional closure is called (if not null) to initialize the value for any newly accessed (or reset)
	 * cache for a given RestServer.  This is very useful for cached lists of Entities.  Basically, when this
	 * is defined, the call to getCacheData() ALWAYS returns a value, even if it is just an empty 'list' (when
	 * reset).  The template for the closure is: def initializeDataForRestServer( RestServer restServer ).  The
	 * closure returns a new, 'empty' data element, such as an empty List or Map.
	 */
	public RestDataCache( initializeDataForRestServer = null ) {
		this.initializeDataForRestServer = initializeDataForRestServer
		
		Logger.debug "Called UcrCacheData()"
	}
	
	/**
	 * Returns the last time (in milliseconds) that the cache was reset for the given REST server.  Returns
	 * 0 if it has never been reset for the given server.
	 * @param restServer Handle to the rest server.
	 */
	private static getLastResetTimestamp( RestServerConnection restServer ) {
		if (lastResetTimestampMap.containsKey(restServer)) {
			return lastResetTimestampMap[restServer]
		} else {
			return 0
		}
	}
	
	
	/**
	 * Returns the handle to the cached data.  If this returns null, then
	 * the cache data has not been set or has been reset.  In either case, the
	 * cache data then needs to be set.  The general procedure is "def data = cache.getCacheData(); if (data==null) {
	 * data = cache.setCacheData( createNewData() ) }" and then use/refine the data.
	 * @param resetCache If true, force a reset of the cached data.
	 */
	public def getCacheData( RestServerConnection restServer, boolean resetCache = false ) {
		def cachedData = null
		if (cacheByRestServerMap.containsKey(restServer)) {
			def serverCache = cacheByRestServerMap[restServer]
			// reset the cache if requested or if a global reset occurred after the data was cached.
			boolean cacheCleared = false
			if (resetCache || (serverCache.timeStamp <= getLastResetTimestamp(restServer))) {
				cacheCleared = clearCacheData(restServer)
			}
			if (! cacheCleared) {
				cachedData = serverCache.data
			}
		}
		if ((! cachedData) && initializeDataForRestServer) {
			cachedData = this.setCacheData( restServer, initializeDataForRestServer(restServer) )
		}
		return cachedData
	}
	
	
	/**
	 * Forces a reset of the cached data in this cache for the given server back to the 
	 * empty or initialized state.  Note that the cache is NOT cleared if it is locked.
	 * @return True if the cache is cleared and false if the cache is NOT cleared because it is locked.
	 */
	public boolean clearCacheData(RestServerConnection restServer) {
		boolean cleared = false
		if (cacheByRestServerMap.containsKey(restServer)) {
			if (! isCacheDataLocked(restServer)) {
				cacheByRestServerMap.remove(restServer)
				Logger.debug "UcrCacheData.clearData() cleared the cache"
				cleared = true
			} else {
				Logger.debug "UcrCacheData.clearData() was NOT cleared because it is locked!!"
			}
		}
		return cleared
	}
	
	/**
	 * Forces of reset of the data in this cache for the given server.  This is the
	 * same as clearCacheData().  In fact, this simply calls that function.
	 * @param restServer
	 * @return True if the cache is cleared and false if the cache is NOT cleared because it is locked.
	 */
	public boolean resetCacheData(RestServerConnection restServer) {
		return clearCacheData(restServer)
	}
	
	
	/**
	 * Sets the cached data to the value.
	 * @param data The value of the cached data.
	 * @return Returns the cached data (as a convenience).
	 */
	public def setCacheData( RestServerConnection restServer, def data ) {
		cacheByRestServerMap[restServer] = [data:data, timeStamp:(new Date()).getTime()]
		return data
	}
	
	/**
	 * Locks the cached data for the given restServer, which means that ANY attempt to reset a locked
	 * cache is ignored.  Note that this is meant to be used when data is updated, but
	 * hasn't been saved yet.
	 */
	public void lockCacheData( RestServerConnection restServer ) {
		if (cacheByRestServerMap.containsKey(restServer)) {
			cacheByRestServerMap[restServer].locked = true
		}
	}
	
	/**
	 * Unlocks any outstanding lock on the cached data for the given restServer allowing for
	 * normal cache resets.
	 */
	public void unlockCacheData( RestServerConnection restServer ) {
		if (cacheByRestServerMap.containsKey(restServer)) {
			if (cacheByRestServerMap[restServer].containsKey('locked')) {
				cacheByRestServerMap[restServer].remove('locked')
			}
		}
	}
	
	/**
	 * Is the cacheData for the given restServer Locked??
	 */
	public boolean isCacheDataLocked( RestServerConnection restServer ) {
		return (cacheByRestServerMap.containsKey(restServer) && 
			cacheByRestServerMap[restServer].containsKey('locked') && 
			cacheByRestServerMap[restServer].locked)
	}

	/**
	 * Resets all cached data for the given REST Server.
	 */
	public static void resetAllCacheData( RestServerConnection restServer ) {
		lastResetTimestampMap[restServer] = (new Date()).getTime()
	}
}
