package com.ibm.services.ucr.api.entity.changetype

import com.ibm.issr.core.entity.IndexedListOfEntities
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.framework.UcrEntityData
import com.ibm.services.ucr.api.framework.UcrEntityDataFormat

/**
 * Manager class for the entity, which includes entity creation and lookup functions.
 * This is a 'RestServerConnection linked Singleton' class - there is one and only one
 * instance of this class for each associated RestServerConnections.
 * @author LeonClark
 *
 */
class UcrChangeTypeMgr {
	// Map of the singleton instances of this class.  Key=RestServerConnection, value=instance of this class
	private static Map _singletons = [:]

	// Contains the List of all entries for the UCR Server.  Each entry is of type UcrChangeType.
	private RestDataCache _cachedCompleteList = new RestDataCache()

	/**
	 * Cached list of loaded entities.  The data type of the cache is IndexedListOfEntities, which is
	 * automatically initialized when the cache is created or reset.
	 */
	RestDataCache _entityCache = new RestDataCache(
		// Cache entry initialization closure - Initialize cache entries as instances of IndexedListOfEntities
		{ RestServerConnection ucrServer ->
			return new IndexedListOfEntities(
				// This closure returns the 'uniqueName' for each entry, which is simply the name
				{ UcrChangeType entity ->
					return entity.getName()
				}
				)
		}
		)

	// The server for this instance of the Mgr
	RestServerConnection ucrServer
	
	/**
	 * Private constructor.
	 * @param ucrServer The associated Rest Server.
	 */
	private UcrChangeTypeMgr( RestServerConnection ucrServer ) {
		this.ucrServer = ucrServer
	}
	
	/**
	 * Returns the singleton instance of this class for the given Rest Server.
	 */
	public static UcrChangeTypeMgr getInstance( RestServerConnection ucrServer ) {
		if (! _singletons.containsKey(ucrServer)) {
			_singletons[ucrServer] = new UcrChangeTypeMgr(ucrServer)
		}
		return _singletons[ucrServer]
	}
	 
	/**
	 * Returns the list of all entries for the given UCR Server.  Each element
	 * in the list is of type UcrChangeType.
	 * @param resetCache If set to true, bypasses any client side cached data and gets a fresh list from the server.
	 */
	public List getAll( boolean resetCache=false ) {
		if (resetCache) {
			_entityCache.resetCacheData(ucrServer)
		}
		List entityList = _cachedCompleteList.getCacheData( ucrServer, resetCache )
		if (! entityList) {
			
			// Load the list via REST calls
			entityList = []
			List rawDataList = (new RestGet( ucrServer ))
				.setPath('/changeTypes/')
				.setHeader('Accept', 'application/json')
				.getAsObject()
			rawDataList.each { def rawEntry ->
				entityList << this.buildEntity(ucrServer, new UcrEntityData(rawEntry, UcrEntityDataFormat.LIST_FORMAT))
			}
			
			_cachedCompleteList.setCacheData(ucrServer, entityList)
		}
		return entityList
	}
	
	/**
	 * Looks up and returns a UcrChangeType by name.  Throws an exception if not found.
	 * @param name The name to find.
	 * @param resetCache If set to true, bypasses any client side cached data and gets a fresh list from the server.
	 */
	public UcrChangeType getByName( String name, boolean resetCache=false ) {
		List entityList = getAll( resetCache )
		UcrChangeType status = entityList.find { UcrChangeType status ->
			return (status.name == name)
		}
		if (! status) {
			throw new Exception( "Unable to find a UCR Status named '${name}'")
		}
		return status
	}
	
	/**
	 * Is there a UCR Status with the given name?
	 * @param name The name to find.
	 * @param resetCache If set to true, bypasses any client side cached data and gets a fresh list from the server.
	 */
	public boolean hasByName( String name, boolean resetCache=false ) {
		List entityList = getAll( resetCache )
		UcrChangeType status = entityList.find { UcrChangeType status ->
			return (status.name == name)
		}
		return status
	}
	
	/**
	 * Looks up and returns a UcrChangeType by id.  Throws an exception if not found.
	 * @param id The id to find.
	 * @param resetCache If set to true, bypasses any client side cached data and gets a fresh list from the server.
	 */
	public UcrChangeType getById( String id, boolean resetCache=false ) {
		List entityList = getAll( resetCache )
		UcrChangeType status = entityList.find { UcrChangeType status ->
			return (status.id == id)
		}
		if (! status) {
			throw new Exception( "Unable to find a UCR Status named '${name}'")
		}
		return status
	}
	
	/**
	 * Is there a UCR Status with the given id?
	 * @param id The id to find.
	 * @param resetCache If set to true, bypasses any client side cached data and gets a fresh list from the server.
	 */
	public boolean hasById( String id, boolean resetCache=false ) {
		List entityList = getAll( resetCache )
		UcrChangeType status = entityList.find { UcrChangeType status ->
			return (status.id == id)
		}
		return status
	}

	/**
	 * Given entity data, this returns a UcrChangeType for that data.
	 * @param ucrServer The server.
	 * @param entityData The data returned from some REST call.
	 * @return New or existing entity.
	 */
	public UcrChangeType buildEntity( RestServerConnection ucrServer, UcrEntityData entityData ) {
		UcrChangeType ucrEntity
		String name = entityData.getEntityObject().name
		String id = entityData.getEntityObject().id
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			ucrEntity = cachedEntities.getEntityById(id)
			// Update the cached entityData
		} else {
			ucrEntity = new UcrChangeType( ucrServer, entityData )
			cachedEntities.addEntity(ucrEntity)
		}
		return ucrEntity
	}
	
	/**
	 * Given a name and id, this returns a UcrChangeType for that data.
	 * @param ucrServer The server.
	 * @return New or existing entity.
	 */
	public UcrChangeType buildEntity( RestServerConnection ucrServer, String name, String id ) {
		UcrChangeType ucrEntity
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			ucrEntity = cachedEntities.getEntityById(id)
			// Update the cached entityData
		} else {
			ucrEntity = new UcrChangeType( ucrServer, name, id )
			cachedEntities.addEntity(ucrEntity)
		}
		return ucrEntity
	}

}
