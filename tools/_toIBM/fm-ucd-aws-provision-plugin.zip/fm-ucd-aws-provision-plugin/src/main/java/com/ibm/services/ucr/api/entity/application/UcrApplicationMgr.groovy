package com.ibm.services.ucr.api.entity.application

import com.ibm.issr.core.entity.IndexedListOfEntities
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.framework.DataQueryFilter
import com.ibm.services.ucr.api.framework.UcrEntityData
import com.ibm.services.ucr.api.framework.UcrEntityDataFormat


/**
 * Manager class for the entity, which includes entity creation and lookup functions.
 * This is a 'RestServerConnection linked Singleton' class - there is one and only one
 * instance of this class for each associated RestServerConnections.
 * @author LeonClark
 *
 */
class UcrApplicationMgr {
	
	// Map of the singleton instances of this class.  Key=RestServerConnection, value=instance of this class
	private static Map _singletons = [:]
	
	// The server for this instance of the Mgr
	RestServerConnection ucrServer
	
	/**
	 * Cached 'List' of ALL Of the UCR Applications.  Each entry is of type UcrApplication.
	 */
	private RestDataCache _cachedCompleteList = new RestDataCache()
	 
	/**
	 * Cached list of loaded entities.  The data type of the cache is IndexedListOfEntities, which is
	 * automatically initialized when the cache is created or resest.
	 */
	RestDataCache _entityCache = new RestDataCache(
		// Cache entry initialization closure - Initialize cache entries as instances of IndexedListOfEntities
		{ RestServerConnection ucrServer ->
			return new IndexedListOfEntities(
				// This closure returns the 'uniqueName' for each entry, which is simply the name
				{ UcrApplication entity ->
					return entity.getName()
				} 
				)
		}
		) 
	
	/**
	 * Private constructor.
	 * @param ucrServer The associated Rest Server.
	 */
	private UcrApplicationMgr( RestServerConnection ucrServer ) {
		this.ucrServer = ucrServer
	}
	
	/**
	 * Returns the singleton instance of this class for the given Rest Server.
	 */
	public static UcrApplicationMgr getInstance( RestServerConnection ucrServer ) {
		if (! _singletons.containsKey(ucrServer)) {
			_singletons[ucrServer] = new UcrApplicationMgr(ucrServer)
		}
		return _singletons[ucrServer]
	}
	
	/**
	 * Returns list of all entities in the list.
	 */
	public List<UcrApplication> getAll( boolean resetCache=false ) {
		if (resetCache) {
			_entityCache.resetCacheData(ucrServer)
		}
		List<UcrApplication> entityList = _cachedCompleteList.getCacheData( ucrServer, resetCache )
		if (! entityList) {
			// Load the list via REST calls
			entityList = []
			List rawEntityList = (new RestGet( ucrServer ))
					.setPath('/applications/')
					.setHeader('Accept', 'application/json')
					.getAsObject()
			// convert to entities
			rawEntityList.each { def rawEntity ->
				entityList << buildEntity( ucrServer, new UcrEntityData( rawEntity, UcrEntityDataFormat.LIST_FORMAT ) )
			}
			_cachedCompleteList.setCacheData(ucrServer, entityList)
		}
		return entityList
	}
	
	/**
	 * Returns the list of UCRApplication's.  Use getAll() instead.
	 */
	@Deprecated
	public List<UcrApplication> getApplications( boolean resetCache = false ) {
		return getAll(resetCache)
	}
	
	
	/**
	 * Returns the entity by ID.  Throws exception if not found.
	 */
	public UcrApplication getById( String id, boolean resetCache=false ) {
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer, resetCache)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			return cachedEntities.getEntityById(id)
		} else {
			// not found in cache - make rest call to load it
			def rawEntityData = (new RestGet( ucrServer ))
					.setPath("/applications/${id}")
//					.addParameter('format', 'detail')
 					.setHeader('Accept', 'application/json')
					.getAsObject()
			// Convert the raw data into an entity
			return buildEntity( ucrServer, new UcrEntityData(rawEntityData, UcrEntityDataFormat.LIST_FORMAT ))
		}
	}

	
	/**
	 * Returns the named entity.  Throws exception if not found.
	 */
	public UcrApplication getByName( String name, boolean resetCache = false ) {
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer, resetCache)
		// Check the cache first
		if (cachedEntities.containsEntityByUniqueName(name)) {
			return cachedEntities.getEntityByUniqueName(name)
		} else {
			// not found in cache - make rest call to load it
			def rawEntityData = (new RestGet( ucrServer ))
					.setPath('/applications/')
//					.addParameter('format', 'detail')
					.callClosure { RestGet restGet ->
						DataQueryFilter.defineFilter(restGet, 'name', DataQueryFilter.FilterClass.STRING, 
							DataQueryFilter.FilterType.EQUALS, name )
					}
					.setHeader('Accept', 'application/json')
					.getFirstElementInListAsObject()
			// Convert the raw data into an entity
			return buildEntity( ucrServer, new UcrEntityData(rawEntityData, UcrEntityDataFormat.LIST_FORMAT ))
		}
	}
	
	
	/**
	 * Is there an entity instance with the given name?
	 */
	public boolean hasByName( String name, boolean resetCache = false ) {
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer, resetCache)
		// Check the cache first
		if (cachedEntities.containsEntityByUniqueName(name)) {
			return true
		} else {
			// not found in cache - make rest call to load it
			def rawEntityData = (new RestGet( ucrServer ))
					.setPath('/applications/')
//					.addParameter('format', 'detail')
					.callClosure { RestGet restGet ->
						DataQueryFilter.defineFilter(restGet, 'name', DataQueryFilter.FilterClass.STRING,
							DataQueryFilter.FilterType.EQUALS, name )
					}
					.setHeader('Accept', 'application/json')
					.getFirstElementInListAsObjectOrNull()
			if (rawEntityData) {
				// Found an element, so return true, but go ahead and cache it as well (by
				// building the entity
				buildEntity( ucrServer, new UcrEntityData(rawEntityData, UcrEntityDataFormat.LIST_FORMAT ))
				return true
			} else {
				return false
			}
			return buildEntity( ucrServer, new UcrEntityData(rawEntityData, UcrEntityDataFormat.LIST_FORMAT ))
		}
	}

	/**
	 * Returns the named Application.  Throws exception if not found.
	 */
	@Deprecated
	public UcrApplication getApplicationByName( String name, boolean resetCache=false ) {
		return getByName( name, resetCache )
	}
	
	/**
	 * Given entity data, this returns a UcrApplication for that data.
	 * @param ucrServer The server.
	 * @param entityData The data returned from some REST call.
	 * @return New or existing entity.
	 */
	public UcrApplication buildEntity( RestServerConnection ucrServer, UcrEntityData entityData ) {
		UcrApplication application
		String name = entityData.getEntityObject().name
		String id = entityData.getEntityObject().id
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			application = cachedEntities.getEntityById(id)
			// Update the cached entityData
		} else {
			application = new UcrApplication( ucrServer, name, id, entityData )
			cachedEntities.addEntity(application)
		}
		return application
	}

}
