package com.ibm.issr.rest.cache

import com.ibm.issr.rest.RestServerConnection;

/**
 * <p>This adds named fields to the RestDataCache.  For example, suppose
 * that you want to cache data for a Security Group.  One set of data
 * is the general 'info' field for the security group.  Another set of
 * data is the list of group members.  This cache class lets you use
 * one cache to manage both sets of entity data.  One set of entity
 * data would be named 'info' (structured map) and the other would be
 * 'List<User> members'.  ALL of the fields for the cache can be reset
 * as a set or the individual fields can be reset.</p>
 * <p>What if you use the underlying getCacheData() instead of
 * getField()?  The actual data is a Map where the key is the name
 * of the fields and the values are the values of the fields.</p> 
 * @author LeonClark
 *
 */
class RestDataCacheWithFields extends RestDataCache {
	
	public RestDataCacheWithFields() {
		super()
		// define a data initializer for the cache which creates an empty map.
		super.initializeDataForRestServer = { RestServerConnection restServer ->
			return [:]
		}
	}
	
	/**
	 * Retrieves the value of the named field from this cache, which is null if not defined.
	 * @param restServer The Rest Server
	 * @param fieldName The name of the field, such as 'members' or 'info'
	 * @param resetEntityCache Should the entire cache entry be reset?
	 * @param resetFieldCache Should the cache be reset just for this name?
	 */
	public def getField( RestServerConnection restServer, String fieldName, boolean resetEntityCache = false, boolean resetFieldCache = false ) {
		def retval = null
		Map cachedFields = getCacheData(restServer,resetEntityCache)
		if (cachedFields.containsKey(fieldName)) {
			if (resetFieldCache) {
				cachedFields.remove(fieldName)
			} else {
				retval = cachedFields[fieldName]
			}
		}
		return retval
	}
	
	/**
	 * Sets the value of the named field for tihs cache to the given value.
	 * @param restServer The Rest Server
	 * @param fieldName The name of the field, such as 'members' or 'info'
	 * @param fieldValue The value to set
	 */
	public void setField( RestServerConnection restServer, String fieldName, def fieldValue ) {
		getCacheData(restServer)[fieldName] = fieldValue
	}
	
	/**
	 * Resets the named field in this cache to null.
	 * @param restServer The Rest Server
	 * @param fieldName The name of the field, such as 'members' or 'info'
	 */
	public void resetField( RestServerConnection restServer, String fieldName ) {
		Map cachedFields = getCacheData(restServer,resetEntityCache)
		if (cachedFields.containsKey(fieldName)) {
			cachedFields.remove(fieldName)
		}
	}
		
}
