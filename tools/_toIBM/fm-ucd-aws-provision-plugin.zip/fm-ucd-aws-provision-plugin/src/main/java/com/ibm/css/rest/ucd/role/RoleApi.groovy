package com.ibm.css.rest.ucd.role

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.issr.rest.RestGet

/**
 * User security roles.
 * @author LeonClark
 *
 */
class RoleApi {
	
	/**
	 * Returns the role's API data structure (as per '/security/role'.
	 * @param ucdServer API handle to the UCD Server.
	 * @param roleName The name of the role.
	 * @return The user data or null if not found.
	 */
	public static def getRoleData( UcdServerConnection ucdServer, String roleName ) {
		def retval = null
		
		// Roles
		def existingRoles = (new RestGet( ucdServer )).setPath("/security/role").getAsObject()
		existingRoles.each { roleEntry ->
			if (roleEntry.name == roleName) {
				retval = roleEntry
			}
		}
		
		return retval
	}

}
