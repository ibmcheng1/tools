package com.ibm.services.ucr.api.entity.versionstatus

import com.ibm.issr.core.entity.EntityWithId
import com.ibm.issr.rest.RestServerConnection;
import com.ibm.services.ucr.api.framework.UcrEntityWithId


/**
 * Represents one file attachment for a UCR VersionStatus.  The Attachments are NOT
 * a stand-alone entity but is only data contained with UCR's VersionStatus entity.
 * Since this is not an independent UCR entity, the decision was made that this class
 * is not responsible for data caching, but its parent class (UcrVersionStatus) is.
 * @author LeonClark
 *
 */
class UcrVersionStatusAttachment implements EntityWithId {
	private String _id
	public UcrVersionStatus versionStatus
	public String description
	public String fileName
	public int version
	public long dateCreated
	public String username
	public String userId
	
	/**
	 * Constructor, which should only be called by the UcrVersionStatus class.
	 * @param id The ID of the attachment.
	 * @param versionStatus The parent VersionStatus that this is an attachment for.
	 * @param description Optional description of the file, which may be an empty string.
	 * @param fileName The name of the file, such as 'data.json'.
	 * @param version The revision number of the file.
	 * @param dateCreated When created in milliseconds.
	 * @param username User name that created the attachment.
	 * @param userId User ID for the user that created the attachment.
	 */
	UcrVersionStatusAttachment( String id, UcrVersionStatus versionStatus, 
		String description, String fileName, int version, long dateCreated, String username, String userId ) {
		this._id = id
		this.versionStatus = versionStatus
		this.description = description
		this.fileName = fileName
		this.version = version
		this.dateCreated = dateCreated
		this.username = username
		this.userId = userId
	}

	public String getId() {
		return _id
	}
}
