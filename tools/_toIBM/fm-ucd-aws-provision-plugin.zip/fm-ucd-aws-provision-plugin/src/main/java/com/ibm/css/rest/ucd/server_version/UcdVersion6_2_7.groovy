package com.ibm.css.rest.ucd.server_version

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestResponse

class UcdVersion6_2_7 extends VersionBaseClass {
	/**
	 * This is a cache of the 'isVersion' answers by ucdServer
	 * Key = ucdServer, value = 'boolean isVersion'.
	 */
	private static Map cachedIsVersion = [:]

	@Override
	public boolean isVersionAtOrAbove( UcdServerConnection ucdServer ) {

		// Is version 6.2.7 (or above) running?  Caches the answer.
		// '/cli/version/versionPropDefs?component=comp' was added to 6.2.7
		// So, call it with a bogus component name

		if (! cachedIsVersion.containsKey(ucdServer)) {

			(new RestGet( ucdServer ))
					.setPath("/cli/version/versionPropDefs")
					.addParameter("component", "Invalid_Component_124")
					.get() { RestResponse response ->
						if (response.httpStatus==400) {
							// Unrecognized URL, so this is an older version of UCD
							cachedIsVersion[ucdServer] = false
						} else {
							cachedIsVersion[ucdServer] = true
						}
						return true
					}
		}

		return cachedIsVersion[ucdServer]
	}

}
