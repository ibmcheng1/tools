package com.fanniemae.ucd.aws.provision.context

import com.fanniemae.ucd.aws.provision.context.data.AwsResourceInstanceContextData

/**
 * This is a provision context for the base class.  It automatically
 * has a blue and green child IF (and only if) provisioning blue green.
 */
class BaseEnvironmentProvisionContext extends ProvisionContext {
	ProvisionContext _blueChildContext = null
	ProvisionContext _greenChildContext = null
	boolean _isProvisioningBlueGreen = false
	
	/**
	 * Constructor
	 * @param parentContext Optional parent context
	 * @param isProvisioningBlueGreen Is a blue-green environment configuration being provisioned?
	 */
	public BaseEnvironmentProvisionContext( ProvisionContext parentContext, boolean isProvisioningBlueGreen ) {
		super(parentContext)
		_isProvisioningBlueGreen = isProvisioningBlueGreen
		if (isProvisioningBlueGreen) {
			_blueChildContext = new ProvisionContext(this,true,false)
			this.addChildContext(_blueChildContext)
			_blueChildContext.blueGreenCounter = '1'
			_greenChildContext = new ProvisionContext(this,false,true)
			this.addChildContext(_greenChildContext)
			_greenChildContext.blueGreenCounter = '2'
		}
	}
	
	/**
	 * Is the provisioning targeting blue-green?
	 */
	public boolean isProvisioningBlueGreen() {
		return _isProvisioningBlueGreen
	}
	
	/**
	 * Returns the BLUE child context or null if there is no BLUE context.
	 */
	public ProvisionContext getBlueChildContext() {
		return _blueChildContext
	}
	
	/**
	 * Returns the GREEN child context or null if there is no GREEN context.
	 */
	public ProvisionContext getGreenChildContext() {
		return _greenChildContext
	}
	
	/**
	 * Returns a list of all of the AWS Resource Instances from all of the contexts (base, blue, green)
	 */
	public List<AwsResourceInstanceContextData> getAllAwsResourceInstances() {
		List<AwsResourceInstanceContextData> resourceInstances = []
		this.getContextSpecificAwsResourceInstances().each { AwsResourceInstanceContextData resourceInstance ->
			resourceInstances << resourceInstance
		}
		if (isProvisioningBlueGreen()) {
			getBlueChildContext().getContextSpecificAwsResourceInstances().each { AwsResourceInstanceContextData resourceInstance ->
				resourceInstances << resourceInstance
			}
			getGreenChildContext().getContextSpecificAwsResourceInstances().each { AwsResourceInstanceContextData resourceInstance ->
				resourceInstances << resourceInstance
			}
		}
		return resourceInstances
	}
	
	/**
	 * Returns a list of all of the environment names from all of the contexts (base, blue, green).
	 */
	public List<String> getAllEnvironmentNames() {
		List<String> environmentNames = []
		if (environmentName) {
			environmentNames << environmentName
		}
		if (isProvisioningBlueGreen()) {
			String blueEnvironmentName = getBlueChildContext().environmentName
			if (blueEnvironmentName) {
				environmentNames << blueEnvironmentName
			}
			String greenEnvironmentName = getGreenChildContext().environmentName
			if (greenEnvironmentName) {
				environmentNames << greenEnvironmentName
			}
		}
		return environmentNames
	}
	
	/**
	 * Returns a list of all of the resource branch names from all of the contexts (base, blue, green).
	 */
	public List<String> getAllResourceBranchNames() {
		List<String> resourceBranchNames = []
		if (resourceBranchName) {
			resourceBranchNames << resourceBranchName
		}
		if (isProvisioningBlueGreen()) {
			String blueBranchName = getBlueChildContext().resourceBranchName
			if (blueBranchName) {
				resourceBranchNames << blueBranchName
			}
			String greenBranchName = getGreenChildContext().resourceBranchName
			if (greenBranchName) {
				resourceBranchNames << greenBranchName
			}
		}
		return resourceBranchNames
	}
	
	/**
	 * Iterates the context tree and all child contexts calling the 'iterator' for each context in
	 * the tree (including the base).
	 * @param iterator Closure which is call for each context in the tree, including the base
	 * context.  Syntax: void iterator( ProvisionContext context )
	 */
	public void iterateContextTree( Closure iterator ) {
		iterator(this)
		if (is_isProvisioningBlueGreen()) {
			iterator(getBlueChildContext())
			iterator(getGreenChildContext())
		}
	}
	
	
	/**
	 * Sets tokens for base, blue and green contexts.
	 * @param tokens This is a list of tokens for all contexts.  Tokens for
	 * blue context have suffix of '.blue' and tokens for green context have suffix of
	 * '.green'.  IF this is NOT a blue-green deployment, then the .blue values are used
	 * for the base context IF there isn't a base token with the same name.
	 */
	public void setTokensForAllContexts( Map tokens ) {
		// separate into base, blue and green tokens
		Map baseTokens = [:]
		Map blueTokens = [:]
		Map greenTokens = [:]
		String blueSuffix = ".blue".toUpperCase()
		String greenSuffix = ".green".toUpperCase()
		tokens.each { String name, String value ->
			if (name.toUpperCase().endsWith(blueSuffix)) {
				blueTokens[ name.substring(0, name.length() - blueSuffix.length()) ] = value
			} else if (name.toUpperCase().endsWith(greenSuffix)) {
				greenTokens[ name.substring(0, name.length() - greenSuffix.length()) ] = value
			} else {
				baseTokens[ name ] = value
			}
		}

		if (_isProvisioningBlueGreen) {
			_blueChildContext.addTokens(blueTokens)
			_greenChildContext.addTokens(greenTokens)
		} else {
			// This is NOT blue-green
			// add the blue tokens before base, so any base tokens can replace matching blue
			this.addTokens(blueTokens)
		}
		this.addTokens(baseTokens)
	}
}
