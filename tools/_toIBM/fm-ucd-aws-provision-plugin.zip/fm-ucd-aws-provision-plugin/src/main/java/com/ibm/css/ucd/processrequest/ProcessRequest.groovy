
package com.ibm.css.ucd.processrequest;

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.request.ProcessRequestApi
import com.ibm.css.rest.ucd.request.approval.ProcessRequestApprovalApi
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.application.process.ApplicationProcess
import com.ibm.css.ucd.common.EntityWithId
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.snapshot.Snapshot
import com.ibm.issr.rest.RestGet

/**
 * This is an Application Process Request.
 * @author LeonClark
 *
 */
class ProcessRequest extends EntityWithId {
	ProcessRequestApi _processRequestApi
	
	// fields
	Application application
	ApplicationProcess applicationProcess
	String description
	long duration
	Date endTime		
	Environment environment
	Boolean onlyChanged
	Boolean paused
	String result
	Date scheduledTime
	Snapshot snapshot
	Date startTime
	String state
	String status
	String _statusOverview			// Overall status, which is actually a calculated field
	Date submittedTime
	String traceId
	String url		// Web UI URL
	String userName
	
	// *** Conditionally loaded fields ***
	/**
	 * List of ComponentVersions associated with this ProcessRequest.
	 * If this is null, then the list hasn't been loaded.  If this is
	 * not null then the list is loaded, though it may be an empty list.
	 */
	List _componentVersions = null
	/**
	 * Process Approval information.  This is null if it isn't loaded or if there is no
	 * associated process approval process.  The flag 'approvalLoaded' determines if this
	 * has been loaded. 
	 */
	ProcessRequestApproval _approval = null
	boolean _approvalLoaded = false
	
	
	/**
	 * Constructor
	 * @param ucdServer Handle to the UCD Server
	 * @param entity This is an Object version of the REST call returned data.  Specifically, this is
	 * based on the rest call /cli/applicationProcessRequest, though it may get information from
	 * a different call, such as /rest/deploy/applicationProcessRequest/table.
	 */
	public ProcessRequest( UcdServerConnection ucdServer, def entity ) {
		super( ucdServer, entity.id )
		
		_processRequestApi = new ProcessRequestApi(ucdServer)
		
		url = "${ucdServer.serverRootUrl}/#applicationProcessRequest/${entity.id}"
		if (entity.containsKey('submittedTime')) {
			submittedTime = new Date(entity.submittedTime)
		}
		if (entity.containsKey('startTime')) {
			startTime = new Date(entity.startTime)
		}
		if (entity.containsKey('endTime')) {
			endTime = new Date(entity.endTime)
		}
		if (entity.containsKey('duration')) {
			duration = entity.duration
		}
		if (entity.containsKey('traceId')) {
			traceId = entity.traceId
		}
		if (entity.containsKey('application')) {
			application = Application.getApplicationWithCache(ucdServer, entity.application.name, entity.application.id)
		}
		if (entity.containsKey('result')) {
			result = entity.result
		}
		if (entity.containsKey('state')) {
			state = entity.state
		}
		if (entity.containsKey('status')) {
			state = entity.status
		}
		if (entity.containsKey('environment')) {
			environment = Environment.getEnvironmentWithCache(ucdServer, application, entity.environment.name, entity.environment.id)
		}
		if (entity.containsKey('applicationProcess')) {
			applicationProcess = ApplicationProcess.getApplicationProcessWithCache(ucdServer, entity.applicationProcess.name, entity.applicationProcess.id)
		}
		if (entity.containsKey('userName')) {
			userName = entity.userName
		}
		if (entity.containsKey('onlyChanged')) {
			onlyChanged = entity.onlyChanged
		}
		if (entity.containsKey('description')) {
			description = entity.description
		}
		if (entity.containsKey('paused')) {
			paused = entity.paused
		}
		if (entity.containsKey('snapshot')) {
			snapshot = Snapshot.getSnapshotWithCache(ucdServer, entity.snapshot.name, entity.snapshot.id)
		}
		
		// calculate the _statusOverview
		if (state=='CLOSED' && result=='SUCCEEDED') {
			_statusOverview = 'SUCCESS'
		} else if (state=='CLOSED' && result=='CANCELED') {
			_statusOverview = 'CANCELLED'
		} else if (state=='RUNNING' && result=='FAULTED') {
			// I am using a sample from 'Build Demo'.  In report it says 'FAILURE'.  In app history, it says 'Could Not Start'
			_statusOverview = 'FAILURE'
		} else if (state=='RUNNING' && (! result)) {
			_statusOverview = 'RUNNING'
		} else if (result=='FAULTED') {
			_statusOverview = 'FAILURE'
		} else if (state=='EXECUTING') {
			_statusOverview = 'EXECUTING'
		} else if (state=='SCHEDULED') {
			_statusOverview = 'SCHEDULED'
		} else {
			// TODO - This is currently an unknown state - map it
			_statusOverview = "TBD, status=" + status +", state=" + state + ", result=" + result
		}
		if (_statusOverview=='SCHEDULED') {
			// depending on the API call used to get 'entity', schedule info may or may not be included
			// If it isn't included, get it
			if (entity.containsKey('entry') && entity.entry.containsKey('scheduledDate')) { 
				scheduledTime = new Date( entity.entry.scheduledDate )
			} else {
				def info = ProcessRequestApi.getInformationForApplicationRequestId(ucdServer, entity.id)
				if (info.containsKey('entry') && info.entry.containsKey('scheduledDate')) { 
					scheduledTime = new Date( info.entry.scheduledDate )
				}
			}
		}
	} 
	
	/**
	 * Resets the cache for this entity, which forces a reload of 'volatile' information, such as the current
	 * status.  Non-volatile information is left unchanged, such as the associated Application (which NEVER changes).
	 */
	public void resetCache() {
		// reload the processRequests data (as 'entity' variable)
		def entity = _processRequestApi.getProcessRequestInfo(this.id)
		
		// reset volatile data
		if (entity.containsKey('startTime')) {
			startTime = new Date(entity.startTime)
		}
		if (entity.containsKey('endTime')) {
			endTime = new Date(entity.endTime)
		}
		if (entity.containsKey('duration')) {
			duration = entity.duration
		}
		if (entity.containsKey('traceId')) {
			traceId = entity.traceId
		}
		if (entity.containsKey('result')) {
			result = entity.result
		}
		if (entity.containsKey('state')) {
			state = entity.state
		}
		if (entity.containsKey('status')) {
			state = entity.status
		}
		if (entity.containsKey('paused')) {
			paused = entity.paused
		}
		
		// calculate the _statusOverview
		if (state=='CLOSED' && result=='SUCCEEDED') {
			_statusOverview = 'SUCCESS'
		} else if (state=='CLOSED' && result=='CANCELED') {
			_statusOverview = 'CANCELLED'
		} else if (state=='RUNNING' && result=='FAULTED') {
			// I am using a sample from 'Build Demo'.  In report it says 'FAILURE'.  In app history, it says 'Could Not Start'
			_statusOverview = 'FAILURE'
		} else if (state=='RUNNING' && (! result)) {
			_statusOverview = 'RUNNING'
		} else if (result=='FAULTED') {
			_statusOverview = 'FAILURE'
		} else if (state=='EXECUTING') {
			_statusOverview = 'EXECUTING'
		} else if (state=='SCHEDULED') {
			_statusOverview = 'SCHEDULED'
		} else {
			// TODO - This is currently an unknown state - map it
			_statusOverview = "TBD, status=" + status +", state=" + state + ", result=" + result
		}
		if (_statusOverview=='SCHEDULED') {
			// depending on the API call used to get 'entity', schedule info may or may not be included
			// If it isn't included, get it
			if (entity.containsKey('entry') && entity.entry.containsKey('scheduledDate')) { 
				scheduledTime = new Date( entity.entry.scheduledDate )
			} else {
				def info = ProcessRequestApi.getInformationForApplicationRequestId(ucdServer, entity.id)
				if (info.containsKey('entry') && info.entry.containsKey('scheduledDate')) { 
					scheduledTime = new Date( info.entry.scheduledDate )
				}
			}
		}
	}
	
	/**
	 * Returns a List of the current context properties.
	 * @return Each List member contains: id, name, value and secure.
	 */
	public List getContextProperties() {
		return _processRequestApi.getContextProperties( getId() )
	}
	
	/**
	 * Returns displayable string formatted startTime
	 * @param formatString How to format the string based on Java's SimpleDateFormat (https://docs.oracle.com/javase/7/docs/api/java/text/SimpleDateFormat.html).
	 */
	public String getDisplayableStartTime( String formatString = 'MM/dd/yy hh:mm:ss a') {
		if (startTime) {
			return startTime.format( formatString )
		} else {
			return ''
		}
	}
	
	/**
	 * Returns displayable string formatted submittedTime.  Note that UCD generally displays and uses this
	 * field as either the Start or Submitted time.
	 * @param formatString How to format the string based on Java's SimpleDateFormat (https://docs.oracle.com/javase/7/docs/api/java/text/SimpleDateFormat.html).
	 */
	public String getDisplayableSubmittedTime( String formatString = 'MM/dd/yy hh:mm:ss a') {
		if (submittedTime) {
			return submittedTime.format( formatString )
		} else {
			return ''
		}
	}
	
	/**
	 * Returns displayable string formatted endTime
	 * @param formatString How to format the string based on Java's SimpleDateFormat (https://docs.oracle.com/javase/7/docs/api/java/text/SimpleDateFormat.html).
	 */
	public String getDisplayableEndTime( String formatString = 'MM/dd/yy hh:mm:ss a') {
		if (endTime) {
			return endTime.format( formatString )
		} else {
			return ''
		}
	}
	
	/**
	 * Returns a displayable version of the 'scheduled time', which is the past start or future scheduled time.
	 * @param formatString How to format the string based on Java's SimpleDateFormat (https://docs.oracle.com/javase/7/docs/api/java/text/SimpleDateFormat.html).
	 */
	public String getDisplayableScheduledTime( String formatString = 'MM/dd/yy hh:mm:ss a') {
		if (scheduledTime) {
			return scheduledTime.format( formatString )
		} else if (startTime) {
			return startTime.format( formatString )
		} else if (submittedTime) {
			return submittedTime.format( formatString )
		} else {
			return ''
		}
	}
	
	/**
	 * Returns a brief overview of the status, such as 'SUCCESS' or 'FAILURE'.  Oddly enough, the REST
	 * API doesn't have such a field.  The status is spread out over multiple fields including (but
	 * not limited to) status, state and result.  This function consolidates that information into one
	 * brief description.
	 */
	public String getStatusOverview() {
		return _statusOverview
	}
	
	/**
	 * Returns the duration (which is elapsed milliseconds) as hh:mm:ss format.  Returns empty string
	 * if there is no duraction.
	 */
	public String getDisplayableDuration() {
		if (duration) {
			long seconds, minutes, hours
			seconds = duration / 1000
			minutes = seconds / 60
			seconds = seconds % 60
			hours = minutes / 60
			minutes = minutes % 60
			return hours + ':' + (new Formatter()).format('%02d',minutes) + ':' + (new Formatter()).format('%02d',seconds) 
		} else {
			return ''
		}
	}
	
	/**
	 * Returns the display name of the associated snapshot or empty string if no snapshot
	 * @return
	 */
	public String getSnapshotName() {
		if (snapshot) {
			return snapshot.name
		} else {
			return ''
		}
	}
	
	/**
	 * Returns a List of the 'ComponentVersions' that were selected for this ProcessRequest.
	 * Note that the first call to this function uses a REST call(s) to get the data,
	 * but subsequent calls used cached data.
	 * @return List of type ComponentVersions
	 */
	public List getComponentVersions() {
		// if _componentVersions is null, then perform the initial load
		if (_componentVersions == null) {
			def rawComponentVersions = ProcessRequestApi.getComponentVersions(ucdServer, this.id)
			_componentVersions = []
			rawComponentVersions.each { def rawEntry ->
				Component component = Component.getComponentWithCache( ucdServer, rawEntry.component.name, rawEntry.component.id )
				ComponentVersion componentVersion = ComponentVersion.getComponentVersionWithCache(ucdServer, component, rawEntry.name, rawEntry.id)
				_componentVersions << componentVersion
			}
		}
		return _componentVersions
	}
	
	/**
	 * Returns the process approval information for this ProcessRequest.  Note that this uses
	 * cached data, but the first call will make appropriate REST call(s).
	 * @return The process approval data or null if this Process Request has no approval information.
	 */
	public ProcessRequestApproval getApproval() {
		if (! _approvalLoaded) {
			def rawApprovalData = ProcessRequestApprovalApi.getApprovals(ucdServer, this.id)
			if (rawApprovalData) {
				_approval = new ProcessRequestApproval(ucdServer, rawApprovalData) 
			}
			_approvalLoaded = true
		}
		
		return _approval
	}
	
	/**
	 * Returns the Activity Trace for this process request as an object tree.  Specifically,
	 * this calls the REST API /cli/applicationProcessRequest/{requestId} as an object tree.
	 */
	public def getActivityTrace() {
		return _processRequestApi.getActivityTrace(this.id)
	}
	
	/**
	 * Saves the Full Trace Log (which is a zip file) to the provided file.  Do NOT call this for
	 * an Application Process Request which is still active or the underlying API call will fail.
	 */
	public void saveFullTraceLogToFile( File file ) {
		FileOutputStream fileOutputStream = new FileOutputStream(file)
		
		(new RestGet( ucdServer )).setPath("/rest/workflow/${traceId}/fullTraceWithLogs")
			.getToOutputStream( fileOutputStream )
		
		fileOutputStream.close()
	}
	
	/**
	 * This function waits until this Application Process Request is Closed (which happens on Cancel or Completion) or
	 * the timeout occurs.
	 * @param timeoutSeconds How many seconds to wait before giving up.  If this is 0, then there is no timeout.
	 * @return Returns true if this process is Closed or false if the function timed out before the Process was closed.
	 */
	public boolean waitUntilClosed( int timeoutSeconds=0 ) {
		boolean retval = false
		
		int elapsedTime = 0
		while (true) {
			
			// Is the process done??
			this.resetCache()
			if (this.state == 'CLOSED') {
				retval = true
				break
			}
			
			// timed out??
			if (timeoutSeconds > 0) {
				++elapsedTime
				if (elapsedTime > timeoutSeconds) {
					break
				}
			}
			
			// sleep for one second
			sleep(1000)
		}
		
		return retval
	}
}
