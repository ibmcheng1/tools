package com.ibm.css.ucd.services

import com.ibm.css.rest.ucd.UcdServerConnection;
import com.ibm.css.rest.ucd.agent.AgentApi;
import com.ibm.css.rest.ucd.agent.AgentPoolApi
import com.ibm.css.ucd.agent.Agent;
import com.ibm.css.ucd.agent.AgentOrAgentPool
import com.ibm.css.ucd.agent.AgentPool

/**
 * Manager class for interacting with Agents.
 * @author ltclark
 *
 */
class AgentServices {
	private UcdServerConnection ucdServer
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the server.
	 */
	public AgentServices( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
	}
	
	/**
	 * Does the named Agent exist?
	 */
	public boolean doesAgentExist( String agentName ) {
		return AgentApi.doesAgentExist(ucdServer, agentName)
	}

	/**
	 * Returns the named agent.  Throws exception if unable to find the agent.
	 * @param agentName The name of the agent.
	 * @return The 'Agent' instance.
	 */
	public Agent getAgent( String agentName ) {
		return AgentApi.getAgentEntityFromName(ucdServer, agentName)
	}

	/**
	 * Does the named Agent Pool exist?
	 */
	public boolean doesAgentPoolExist( String agentPoolName ) {
		return AgentPoolApi.doesAgentPoolExist(ucdServer, agentPoolName)
	}

	/**
	 * Returns the named Agent Pool throwing exception if not found.
	 * @param agentPoolName The name of the pool.
	 * @return The 'AgentPool' instance.
	 */
	public AgentPool getAgentPool( String agentPoolName ) {
		return AgentPoolApi.getAgentPoolEntityFromName(ucdServer, agentPoolName)
	}
	
	/**
	 * Is there an agent or agent pool with the given name.
	 */
	public boolean doesAgentOrAgentPoolExist( String name ) {
		return doesAgentExist(name) || doesAgentPoolExist( name)
	}

	/**
	 * Attempts to return an Agent or AgentPool with the given name throwing an exception if not found.
	 */
	public AgentOrAgentPool getAgentOrAgentPool( String name ) {
		if (doesAgentPoolExist(name)) {
			return getAgentPool(name)
		} else if (doesAgentExist(name)) {
			return getAgent(name)
		} else {
			throw new Exception( "No Agent or AgentPool found with the name '${name}'")
		}
	}
}
