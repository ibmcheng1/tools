package com.fanniemae.ucd.aws.provision.ucd;

import com.ibm.css.ucd.agent.AgentOrAgentPool
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.resource.ComponentResourceNode
import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.css.ucd.resource.ResourceTree
import com.ibm.css.ucd.team.Team
import com.ibm.issr.core.plugin.AbortPluginException

/**
 * Defines a 'base' branch of the Resource Tree for an Environment Branch.  Note that
 * there is a many-to-many relationship between UCD Environments and UCD base branches.
 * If and when the resource branch node is actually created/accessed, that ResourceNode
 * is saved in this class.
 * 
 * @author s9ulcc
 *
 */
public class UcdResourceBranchDefinition {
	/**
	 * The associated environments.
	 */
	private List<UcdEnvironmentDefinition> _environmentDefinitions = []
	
	public boolean includeCommon
	public boolean includeBlue
	public boolean includeGreen
	
	// The corresponding UCD ResourceNode
	private ResourceNode _ucdResourceNode
	// The Agent/AgentPool node within the branch
	private ResourceNode _ucdAgentOrAgentPoolNode
	
	// The UCD Agent Pool that needs to be added to the resource nodes
	private AgentOrAgentPool _ucdAgentOrAgentPool
	
	/**
	 * The TargetUcdConfiguration that this class is a member of.
	 */
	public UcdConfigurationDefinition targetUcdConfiguration
	/**
	 * The resource tree node name fot this node.
	 */
	public String name

	/**
	 * Constructor
	 * @param targetUcdConfiguration The configuration that this element is part of.
	 * @param nodeName The name of the node (and NOT the path) of the resource tree node.
	 * @param ucdAgentOrAgentPoo lThe UCD Agent or Agent Pool that should be added to resource node.
	 * @param includeCommon Include common components, which are ones that aren't blue or green. 
	 * @param includeBlue Include blue components?
	 * @param includeGreen Include green components?
	 */
	public UcdResourceBranchDefinition( UcdConfigurationDefinition targetUcdConfiguration, String nodeName, 
		AgentOrAgentPool ucdAgentOrAgentPool,
		boolean includeCommon, boolean includeBlue,
		boolean includeGreen ) {
		this.targetUcdConfiguration = targetUcdConfiguration
		this.name = nodeName
		this._ucdAgentOrAgentPool = ucdAgentOrAgentPool
	}
	
	/**
	 * Adds an associated environment definition.  This is an environment which includes this Resource Branch
	 * as a 'base' resource.
	 * @param environmentDefinition Associated environment.
	 */
	public void addAssociatedEnvironmentDefinition( UcdEnvironmentDefinition environmentDefinition ) {
		_environmentDefinitions << environmentDefinition
	}
	
	/**
	 * Returns the Application for this target environment.
	 */
	public Application getApplication() {
		return targetUcdConfiguration.application
	}
	
	/**
	 * Does this resource tree node exist??
	 */
	public boolean doesResourceNodeExist() {
		boolean retval = false
		ResourceTree resourceTree = targetUcdConfiguration.ucdConnectionServices.getResourceServices().getResourceTree()
		if (resourceTree.doesChildNodeExist(application.name)) {
			ResourceNode appResourceNode = resourceTree.getChildNode(application.name)
			retval = appResourceNode.doesChildNodeExist(name)
		}
		return retval
	}
	
	/**
	 * Assign the UCD ResourceNode that corresponds to this builder.  This is useful
	 * in the case where an Environment Template is automatically creating and linking the resource nodes.
	 * @param resourceNode The corresponding UCD ResourceNode
	 * @return this
	 */
	public UcdResourceBranchDefinition setUcdResourceNode( ResourceNode resourceNode ) {
		_ucdResourceNode = resourceNode
		return this
	}
	
	
	/**
	 * Configures the corresponding UCD ResourceNode with teams, child agents/pools, etc.
	 * @param teams The resource tree node is set to these teams.
	 * @return this
	 */
	public UcdResourceBranchDefinition configureUcdResourceNode( List<Team> teams ) {
		// Setup teams
		_ucdResourceNode.removeLinksToAllTeams()
		teams.each { Team team ->
			_ucdResourceNode.addLinkToTeam(team)
		}
		// Setup child AgentOrAgentPool
		if (! _ucdResourceNode.doesChildNodeExist(_ucdAgentOrAgentPool.name)) {
			_ucdAgentOrAgentPoolNode = _ucdResourceNode.createChildAgentOrAgentPoolNode(_ucdAgentOrAgentPool.name, _ucdAgentOrAgentPool)
		}
		return this
	}
	
	/**
	 * Returns the corresponding UCD Resource Node creating it if it doesn't already exist.
	 */
	public ResourceNode getUcdResourceNode() {
		if (! _ucdResourceNode) {
			ResourceTree resourceTree = targetUcdConfiguration.ucdConnectionServices.getResourceServices().getResourceTree()
			if (! resourceTree.doesChildNodeExist(application.name)) {
				throw new AbortPluginException("Unable to find root Resource Tree node named '${application.name}'")
			}
			ResourceNode appResourceNode = resourceTree.getChildNode(application.name)
			if (appResourceNode.doesChildNodeExist(name)) {
				_ucdResourceNode = appResourceNode.getChildNode(name)
			} else {
				_ucdResourceNode = appResourceNode.createChildGroupNode(name)
			}
		}
		return _ucdResourceNode
	}
	
	/**
	 * Adds the named component to this resource node.  Actually, it adds the component resource to the node's
	 * child agent/agentPool.
	 * @param component The UCD Component
	 * @param componentResourceName The name to use for the new Resource Node.
	 * @return Returns the new resource node.
	 */
	public ComponentResourceNode addComponent( Component component, String componentResourceName ) {
		// Lookup the component
		return _ucdAgentOrAgentPoolNode.createChildComponentNode(componentResourceName, component)
	}
}
