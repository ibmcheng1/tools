package com.fanniemae.ucd.aws.provision.ucd

import com.ibm.css.ucd.agent.AgentOrAgentPool
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.css.ucd.team.Team
import com.ibm.issr.core.plugin.AbortPluginException

/**
 * Defines the target UCD configuration, such as application, environments and resources.
 * @author s9ulcc
 *
 */
class UcdConfigurationDefinition {
	
	/**
	 * Is this a blue-green target system?
	 */
	public boolean blueGreen
	public String baseEnvironmentName
	
	public UcdConnectionServices ucdConnectionServices
	public Application application
	// This is a list of all TargetEnvironmentBuilders
	private List<UcdEnvironmentDefinition> _targetEnvironmentDefinitions = []
	private List<UcdResourceBranchDefinition> _targetResourceNodeBuilders = []
	// Type specific Environments
	public UcdEnvironmentDefinition blueEnvironmentDefinition
	public UcdEnvironmentDefinition greenEnvironmentDefinition
	public UcdEnvironmentDefinition standardEnvironmentDefinition
	// Type specific Resource Branches
	public UcdResourceBranchDefinition blueResourceBranchDefinition
	public UcdResourceBranchDefinition greenResourceBranchDefinition
	public UcdResourceBranchDefinition baseResourceBranchDefinition
	
	/** 
	 * The agent/agentPool to use
	 */
	private AgentOrAgentPool ucdAgentOrAgentPool
	
	/**
	 * Constructor.	You must also call setUcdConnectionServices() and setApplication() before using the other functions in this class.
	 * @param blueGreen Is this a blue-green configuration?
	 * @param baseEnvironmentName The name of the base environment
	 * @param ucdAgentPoolName The name of the UCD Resource or Resource Pool to use within UCD for the environment definitions.
	 */
	public UcdConfigurationDefinition( UcdConnectionServices ucdConnectionServices, Application application, boolean blueGreen, 
		String baseEnvironmentName, String requestedEnvType, String ucdAgentPoolName ) {
		
		// lookup the Resource Pool
		if (! ucdConnectionServices.getAgentServices().doesAgentOrAgentPoolExist(ucdAgentPoolName)) {
			throw new AbortPluginException("Unable to find UCD Agent or Agent Pool named '${ucdAgentPoolName}'")
		}
		ucdAgentOrAgentPool = ucdConnectionServices.getAgentServices().getAgentOrAgentPool(ucdAgentPoolName)
		
		this.blueGreen = blueGreen
		this.baseEnvironmentName = baseEnvironmentName
		this.ucdConnectionServices = ucdConnectionServices
		this.application = application
		if (blueGreen) {
			baseResourceBranchDefinition = new UcdResourceBranchDefinition(this, baseEnvironmentName+"-shared", ucdAgentOrAgentPool, true, false, false )
			_targetResourceNodeBuilders << baseResourceBranchDefinition
			String blueEnvironmentName = baseEnvironmentName + "-BLUE"
			String greenEnvironmentName = baseEnvironmentName + "-GREEN"
			blueResourceBranchDefinition = new UcdResourceBranchDefinition(this, blueEnvironmentName, ucdAgentOrAgentPool, false, true, false )
			_targetResourceNodeBuilders << blueResourceBranchDefinition
			blueEnvironmentDefinition = (new UcdEnvironmentDefinition(this,blueEnvironmentName,requestedEnvType,ucdAgentOrAgentPool,blueResourceBranchDefinition))
				.addAdditionalResourceBranches(baseResourceBranchDefinition)
			_targetEnvironmentDefinitions << blueEnvironmentDefinition
			greenResourceBranchDefinition = new UcdResourceBranchDefinition(this, greenEnvironmentName, ucdAgentOrAgentPool, false, false, true )
			_targetResourceNodeBuilders << greenResourceBranchDefinition
			greenEnvironmentDefinition = (new UcdEnvironmentDefinition(this,greenEnvironmentName,requestedEnvType,ucdAgentOrAgentPool,greenResourceBranchDefinition))
				.addAdditionalResourceBranches(baseResourceBranchDefinition)
			_targetEnvironmentDefinitions << greenEnvironmentDefinition
		} else {
			baseResourceBranchDefinition = new UcdResourceBranchDefinition(this, baseEnvironmentName, ucdAgentOrAgentPool, true, false, false )
			_targetResourceNodeBuilders << baseResourceBranchDefinition
			standardEnvironmentDefinition = (new UcdEnvironmentDefinition(this,baseEnvironmentName,requestedEnvType,ucdAgentOrAgentPool,baseResourceBranchDefinition))
			_targetEnvironmentDefinitions << standardEnvironmentDefinition
		}
	}
	
	/**
	 * Returns a List of the 'TargetEnvironment's
	 */
	public List<UcdEnvironmentDefinition> getTargetEnvironments() {
		return _targetEnvironmentDefinitions
	}
	
	/**
	 * Returns a List of the 'TargetResourceNode's
	 */
	public List<UcdResourceBranchDefinition> getTargetResourceNodes() {
		return _targetResourceNodeBuilders
	}
	
	/**
	 * Creates and wires the target UCD Structure - environments, resource tree branches and connects the two.
	 */
	public void createTargetUcdStructure() {
		
		// Get the application teams (which are replicated)
		List<Team> applicationTeams = application.getUniqueTeams()

		// Create environment(s)
		_targetEnvironmentDefinitions.each { UcdEnvironmentDefinition targetEnvironmentBuilder ->
			targetEnvironmentBuilder.createUcdEnvironment(applicationTeams)
		}
	}
}
