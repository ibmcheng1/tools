package com.fanniemae.ucd.aws.provision.service.instance

import java.util.Properties

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.ucd.aws.api.describeRecord.AwsDescribeRecordResult
import com.fanniemae.ucd.aws.provision.service.definition.AwsServiceDefinition
import com.ibm.css.ucd.environment.Environment

class EBServiceInstance extends AwsServiceInstance {

	public EBServiceInstance(AwsServiceDefinition awsServiceDefinition, AwsConnection awsConnection, String provisionedId, boolean newlyProvisioned) {
		super(awsServiceDefinition, awsConnection, provisionedId, newlyProvisioned)
	}

	@Override
	public String getServiceType() {
		return 'EB'
	}

}
