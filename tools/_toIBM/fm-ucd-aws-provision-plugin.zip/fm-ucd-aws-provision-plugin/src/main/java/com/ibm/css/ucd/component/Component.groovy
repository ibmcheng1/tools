package com.ibm.css.ucd.component

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.component.ComponentApi
import com.ibm.css.rest.ucd.component.version.ComponentVersionApi
import com.ibm.css.ucd.common.CacheData;
import com.ibm.css.ucd.common.EntityWithNameAndId
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.property.Property
import com.ibm.issr.core.string.SimpleWildcard
import com.ibm.issr.rest.RestPut

import groovy.json.JsonOutput


/**
 * Entity class for UCD Component.
 * @author ltclark
 *
 */
class Component extends EntityWithNameAndId {
	// Cached set of entries for this entity.
	//	key = UcdServerConnection
	//  value = field Map
	//  	byID = Map where
	//			key = id
	//			value = entity class, such as Application or Environment
	//		byName = Map where
	//			key = name
	//			value = entity class, such as Component entity class
	static protected Map cache = [:]
	
	// cached 'info' for this snapshot
	CacheData _cached_info = new CacheData(Component.class, false)

		
	/**
	 * Constructor.
	 * @param ucdServer The handle to the UCD Server.
	 * @param info This is an Object version of the call to /cli/component/info.
	 * Note that it has at least two fields - name and id.
	 */
	public Component( UcdServerConnection ucdServer, def info ) {
		super( ucdServer, info.name, info.id )
		_cached_info.setCacheData(info)
	}
	
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 */
	public Component( UcdServerConnection ucdServer, String name, String id ) {
		super( ucdServer, name, id )
	}
	
	/**
	 * Cached creation of new entities.  If the entity is already in the cache, the existing entity
	 * is returned.  Otherwise, a new entity is created, added to the cache and returned.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 * @return The requested entity.
	 */
	public static Component getComponentWithCache( UcdServerConnection ucdServer, String name, String id ) {
		if (! cache.containsKey(ucdServer)) {
			cache[ucdServer] = ['byId':[:],'byName':[:]]
		}
		if (! cache[ucdServer].byId.containsKey(id)) {
			Component newComponent = new Component( ucdServer, name, id )
			cache[ucdServer].byId[id] = newComponent
			cache[ucdServer].byName[name] = newComponent
		}
		return cache[ucdServer].byId[id]
	}
	
	/**
	 * Cached creation of new entities.  If the entity is already in the cache, the existing entity
	 * is returned.  Otherwise, a new entity is created, added to the cache and returned.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 * @return The requested entity.
	 */
	public static Component getComponentWithCacheByName( UcdServerConnection ucdServer, String name ) {
		if (! cache.containsKey(ucdServer)) {
			cache[ucdServer] = ["byId":[:], "byName":[:]]
		}
		if (! cache[ucdServer].byName.containsKey(name)) {
			String id = ComponentApi.getComponentVersionIdForName(ucdServer,name)
			Component newComponent = new Component( ucdServer, name, id )
			cache[ucdServer].byId[id] = newComponent
			cache[ucdServer].byName[name] = newComponent
		}
		return cache[ucdServer].byName[name]
	}

	/**
	 * Resets internally cached data.  This should be called whenever the data
	 * for the component may change.  In particular, any call that specifically
	 * changes data should clear the internal cache.
	 */
	public void resetCachedData() {
		_cached_info.clearCacheData()
	}
	
	/**
	 * Returns the 'info' structure that is returned by the  /cli/component/info API call.
	 * This information is cached locally.
	 */
	public def getInfo( boolean resetCache = false ) {
		def info = _cached_info.getCacheData(resetCache)
		if (info == null) {
			info = _cached_info.setCacheData(ComponentApi.getComponentInfo( ucdServer, id ))
		}
		return info
	}
	
	/**
	 * Returns the name of the template associated with this component.
	 * @return
	 */
	public String getTemplateName() {
		def info = getInfo()
		String templateName = ''
		if (info.containsKey('template')) {
			templateName = info.template.name
		}
		return templateName
	}
	
	/**
	 * INTERNAL function to getComponentProperties() and getBasicProperties() -- Returns the List of properties for this Component.  Each
	 * entry is a Map with the following keys: id, name, value, description, secure.
	 * 'secure' is the only boolean field.  The rest are strings.
	 * The list contains the 'basic' (template defined) properties AND custom
	 * 'Component Properties'.  The 'basic' properties are prefixed with 'template/'
	 * and the 'component properties' are prefixed with 'custom/'.  The list does NOT
	 * include the various other types of properties, such as 'component version properties'.
	 */
	private List getPropertyList() {
		def info = getInfo()
		if (info.containsKey('properties')) {
			return info.properties
		} else {
			return []
		} 
	}
	
	/**
	 * Returns List of the Basic Properties for this Component.
	 * The Basic Properties are properties that are defined in the corresponding Component Templates 
	 * 'Component Property Definitions' Configuration page.  Within the Component, these properties appear
	 * on the 'Basic Settings' Configuration page.
	 * @return List of type
	 * {@link com.ibm.css.ucd.property.Property Property}.
	 * Returns the 'basic' properties, which are the properties defined by the component's template, as a
	 * List of 'Property' values.
	 */
	public List getBasicProperties() {
		List properties = []
		String namePrefix = 'template/'
		getPropertyList().each { Map propertyEntry ->
			String name = propertyEntry.name
			if (name.startsWith(namePrefix)) {
				properties << new Property(propertyEntry.name.substring(namePrefix.length()), propertyEntry.description, propertyEntry.secure, propertyEntry.value)
			}
		}
		return properties
	}
	
	/**
	 * Does this component have the given 'basic property'.
	 * The Basic Properties are properties that are defined in the corresponding Component Templates 
	 * 'Component Property Definitions' Configuration page.  Within the Component, these properties appear
	 * on the 'Basic Settings' Configuration page.
	 */
	public boolean hasBasicProperty( String name ) {
		return getBasicProperties().find { Property property ->
			return property.name == name
		}
	}
	
	/**
	 * Returns the named basic property throwing an exception if not found
	 * The Basic Properties are properties that are defined in the corresponding Component Templates 
	 * 'Component Property Definitions' Configuration page.  Within the Component, these properties appear
	 * on the 'Basic Settings' Configuration page.
	 */
	public Property getBasicProperty( String name ) {
		Property property = getBasicProperties().find { Property property ->
			return property.name == name
		}
		if (property) {
			return property
		} else {
			throw new Exception( "Unable to find the basic property named '${name}' in component '${this.name}'" )
		}
	}

	/**
	 * Returns List of the ComponentProperties for this Component.
	 * ComponentProperties are the properties defined in the 'Component Properties' section of the
	 * Component's Configuration page (in the Web UI).  They ALSO include any properties defined in the
	 * corresponding Component Template's "Properties" Configuration page.
	 * @return List of type
	 * {@link com.ibm.css.ucd.property.Property Property}.
	 * Returns the 'basic' properties, which are the properties defined by the component's template, as a
	 * List of 'Property' values.
	 */
	public List getComponentProperties() {
		List properties = []
		String namePrefix = 'custom/'
		getPropertyList().each { Map propertyEntry ->
			String name = propertyEntry.name
			if (name.startsWith(namePrefix)) {
				properties << new Property(propertyEntry.name.substring(namePrefix.length()), propertyEntry.description, propertyEntry.secure, propertyEntry.value)
			}
		}
		return properties
	}
	
	/**
	 * Does this component have the given 'component property'.
	 * ComponentProperties are the properties defined in the 'Component Properties' section of the
	 * Component's Configuration page (in the Web UI).  They ALSO include any properties defined in the
	 * corresponding Component Template's "Properties" Configuration page.
	 */
	public boolean hasComponentProperty( String name ) {
		return getComponentProperties().find { Property property -> 
			return property.name == name
		}
	}
	
	/**
	 * Returns the named component property throwing an exception
	 * ComponentProperties are the properties defined in the 'Component Properties' section of the
	 * Component's Configuration page (in the Web UI).  They ALSO include any properties defined in the
	 * corresponding Component Template's "Properties" Configuration page.
	 */
	public Property getComponentProperty( String name ) {
		Property property = getComponentProperties().find { Property property ->
			return property.name == name
		}
		if (property) {
			return property
		} else {
			throw new Exception( "Unable to find the component property named '${name}' in component '${this.name}'" )
		}
	}

	/**
	 * Returns a List of the ComponentVersion's of this component with an optional filter.
	 * @param filter Optional filter.  If provided, then the closure is used to
	 * filter the versions.  Basically, the declaration for the filter is
	 * 'boolean filter( ComponentVersion componentVersion )' where filter returns
	 * true if the ComponentVersion should be included in the list.
	 */
	public List getComponentVersions( Closure filter=null ) {
		List componentVersions = []
		List rawEntries = ComponentVersionApi.getComponentVersions( ucdServer, id, false )
		rawEntries.each { Map entry ->
			ComponentVersion componentVersion = new ComponentVersion(ucdServer, this, entry)
			boolean includeEntry = true
			if (filter) {
				includeEntry = filter(componentVersion)
			}
			if (includeEntry) {
				componentVersions << componentVersion
			}
		}
		return componentVersions
	}
	
	/**
	 * Returns all of the ComponentVersions for this Component whose name
	 * matches the 'simpleWildcard'.
	 * @param simpleWildcard This is a 'simpleWildcard'.  The only wildcard symbol is
	 * '*' which matches any number of characters.
	 */
	public List getComponentVersionsMatchingWildcard( String simpleWildcard ) {
		return this.getComponentVersions() { ComponentVersion componentVersion ->
			return SimpleWildcard.doesMatch( componentVersion.name, simpleWildcard )
		}
	}

	/**
	 * Returns the latest active component version of this component.  This returns null if there
	 * are no component versions.
	 */
	public ComponentVersion getLatestComponentVersion() {
		ComponentVersion componentVersion = null
		List componentVersions = ComponentVersionApi.getComponentVersions( ucdServer, id, false )
		
		// Figure out the newest component version
		String newestVersionName = ""
		String newestVersionId = ""
		long newestVersionCreated = 0
		componentVersions.each { def version ->
			if (newestVersionCreated==0 || newestVersionCreated < version.created) {
				newestVersionName = version.name
				newestVersionId = version.id
				newestVersionCreated = version.created
			}
		}
		
		if (newestVersionCreated > 0 ) {
			componentVersion = ComponentVersion.getComponentVersionWithCache( ucdServer, this, newestVersionName, newestVersionId)
			componentVersion.setCreated(newestVersionCreated)
		}
		
		return componentVersion
	}
	
	/**
	 * Does this Component have a version with the given version name?
	 * @param versionName The name of the desired version
	 * @return True or false.
	 */
	public boolean doesComponentVersionExist( String versionName ) {
		return (new ComponentVersionApi(ucdServer)).doesComponentVersionExist(this.id, versionName)
	}
	
	/**
	 * Does this Component have a version with the given version name?
	 * @param versionName The name of the desired version
	 * @return True or false.
	 */
	public boolean hasComponentVersion( String versionName ) {
		return doesComponentVersionExist( versionName )
	}

	/**
	 * Returns the ComponentVersion Entity for the named version.  Throws exception if the version
	 * isn't found.
	 * @param versionName The name of the Component Version within this Component.
	 */
	public ComponentVersion getComponentVersion( String versionName ) {
		String versionId = (new ComponentVersionApi(ucdServer)).getComponentVersionIdForName(this.id, versionName)
		return new ComponentVersion(ucdServer, this, versionName, versionId)
	}
	
	/**
	 * Creates and returns a new component version.  Throws exception on failure.
	 * @param versionName The name of the new component version.
	 * @param description Optional description of the new component version.  This may be null or an empty string.
	 * @return The new component version.
	 */
	public ComponentVersion createComponentVersion( String versionName, String description ) {
		if (! description) {
			description = ""
		}
		(new ComponentVersionApi(ucdServer)).createNewComponentVersion(ucdServer, this.id, versionName, description)
		return getComponentVersion(versionName)
	}
	
	/**
	 * Sets a Component Environment property.
	 */
	public void setComponentEnvironmentProperty( Environment environment, String name, String value ) {
		def payload = [ component: this.getId(), environment: environment.getId(), name: name, value:value ]
		(new RestPut( ucdServer )).setPath("/cli/environment/componentProperties")
			.setPayload(JsonOutput.toJson( payload ))
			.putWithNoReturnObject()
	}
}
