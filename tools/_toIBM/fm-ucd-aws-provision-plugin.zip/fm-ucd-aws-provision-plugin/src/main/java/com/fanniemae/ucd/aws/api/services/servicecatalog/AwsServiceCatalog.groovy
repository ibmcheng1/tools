package com.fanniemae.ucd.aws.api.services.servicecatalog;

import com.fanniemae.aws.api.connection.AwsConnection;
import com.fanniemae.ucd.aws.api.describeRecord.AwsDescribeRecordResult
import com.fanniemae.ucd.aws.api.services.servicecatalog.results.TerminateProvisionProductResult
import com.fanniemae.ucd.aws.api.services.servicecatalog.results.TerminateProvisionProductsResult
import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.plugin.AbortPluginException

import groovy.json.JsonSlurper

public class AwsServiceCatalog {
	/**
	 * The connection handle to AWS.
	 */
	public AwsConnection awsConnection
	
	/**
	 * Constructor.
	 * @param awsConnection Connection to AWS.
	 */
	public AwsServiceCatalog( AwsConnection awsConnection ) {
		this.awsConnection = awsConnection
	}
	
	/**
	 * Termainates a list of AWS Product Instances waiting for final pass/fail results on all of them.
	 * @param provisionedProductNames The list of provisioned Product instance names.
	 * @return A list with results for each one.
	 */
	public TerminateProvisionProductsResult terminateProvisionedProductsAndWait( List<String> provisionedProductNames, int timeoutInMinutes = 90 ) {
		TerminateProvisionProductsResult results = new TerminateProvisionProductsResult()
		
		// Start terminating each one
		provisionedProductNames.each { String provisionedProductName ->
			TerminateProvisionProductResult instanceResult = new TerminateProvisionProductResult( provisionedProductName, results )
			results.instanceResults << instanceResult
			try {
				instanceResult.recordId = terminateProvisionedProduct( provisionedProductName )
			}
			catch (Exception e) {
				instanceResult.flagFailure(e.getMessage())
			}
		}
		
		// Loop waiting for all of the instances to complete (success or failure)
		long startTime = System.currentTimeMillis()
		boolean stillWaiting = true
		boolean firstTime = true
		while (stillWaiting) {
			// check for timeout
			long currentTime = System.currentTimeMillis()
			if ((currentTime - startTime) > (timeoutInMinutes * 60 * 1000)) {
				// Timed out
				results.successful = false
				results.instanceResults.each { TerminateProvisionProductResult instanceResult ->
					if (! instanceResult.processingCompleted) {
						instanceResult.flagFailure("Termination of product '${instanceResult.provisionedProductName}' did not complete before UCD Process timed out" )
					}
				}
//				throw new AbortPluginException("Timed out waiting to provision the AWS Product Instances")
				break
			}
			if (firstTime) {
				firstTime = false
			} else {
				// sleep one minute
				Thread.sleep( 1000*60 )
			}
			
			// check statuses for remaining product instances
			stillWaiting = false
			results.instanceResults.each { TerminateProvisionProductResult instanceResult ->
				if (! instanceResult.processingCompleted) {
					AwsDescribeRecordResult recordResult = describeRecord( instanceResult.recordId)
					if (recordResult.getStatus() == 'IN_PROGRESS') {
						stillWaiting = true
					} else if (recordResult.getStatus() == 'SUCCEEDED') {
						instanceResult.flagSuccess()
					} else {
						instanceResult.flagFailure("AWS returned unexpected status code of '${recordResult.getStatus()}' while terminating AWS Product Instance '${instanceResult.provisionedProductName}'")
					}
				}
			}

		}
		return results
	}
	
	/**
	 * Starts the termination of a provision AWS Product via an
	 * 'aws servicecatalog terminate-provisioned-product'.  This function
	 * returns before the termination is complete (pass or fail).
	 * @param provisionedProductName The provisioned Product/resource to terminate.
	 * @return REturns the RecordId which can be used to track the termination progress.
	 */
	public String terminateProvisionedProduct( String provisionedProductName ) {
		CommandRunner commandRunner = awsConnection.executeAwsCliCommand("""aws servicecatalog terminate-provisioned-product --provisioned-product-name '${p:provisionedProductName}' --region ${p:awsConnection.getRegion()}""")
		if (! commandRunner.wasSuccessful()) {
			throw new AbortPluginException( "Unable retrieve AWS Artifact ID for Product ID: ${provisionedProductName}" )
		}
		Map results = (new JsonSlurper()).parseText( commandRunner.getConsoleOutput() )
		return results.RecordDetail.RecordId
	}
	
	/**
	 * Returns the 'describe-record' data for an AWS Product/Resource instance.
	 * @param recordId The ID of the record.
	 * @param displayRecord If true, then display the record contents via Logger.info
	 * @return A class wrapper for the results.
	 */
	public AwsDescribeRecordResult describeRecord( String recordId, boolean displayRecord = false ) {
		CommandRunner commandRunner = awsConnection.executeAwsCliCommand("aws servicecatalog describe-record --id ${recordId} --region ${awsConnection.getRegion()}")
		if (! commandRunner.wasSuccessful()) {
			throw new AbortPluginException( "API call to get AWS Service Instance Record (servicecatalog describe-record) for record id ${recordId} failed")
		}
		return new AwsDescribeRecordResult( commandRunner.getConsoleOutput(), displayRecord )
	}

}
