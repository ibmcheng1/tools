package com.ibm.css.ucd.common

import com.ibm.css.rest.ucd.UcdServerConnection

/**
 * Base class for entity classes that has an ID.  Note that if you call
 * entityWithId.equals(entity2WithId), it will return true if it is the same type of object and
 * the same id.
 * @author ltclark
 *
 */
class EntityWithId extends Entity implements com.ibm.issr.core.entity.EntityWithId {
	// the id
	private String _id
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param id The id.
	 */
	public EntityWithId( UcdServerConnection ucdServer, String id ) {
		super(ucdServer)
		_id = id
	}
	
	/**
	 * Returns the entity's ID.
	 */
	public String getId() {
		return _id
	}
	
	/**
	 * Overwrite of equals that returns true if two 'EntityWithId' are (a) the same class,
	 * (b) the same ucdServer, and (c) the same id.
	 */
	boolean equals( Object o ) {
		return ((o instanceof EntityWithId) && this.ucdServer.equals(o.ucdServer) && this.getClass().equals(o.getClass()) && this.id.equals(o.id))
	}
}
