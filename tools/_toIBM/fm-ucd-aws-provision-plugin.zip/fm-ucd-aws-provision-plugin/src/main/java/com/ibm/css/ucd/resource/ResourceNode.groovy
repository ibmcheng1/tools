package com.ibm.css.ucd.resource

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.resource.ResourceApi
import com.ibm.css.ucd.agent.Agent
import com.ibm.css.ucd.agent.AgentOrAgentPool
import com.ibm.css.ucd.agent.AgentPool
import com.ibm.css.ucd.common.EntityWithNameIdAndTeams
import com.ibm.css.ucd.component.Component
import com.ibm.issr.rest.RestDelete

/**
 * This is a node in the resource tree.  This is the base class for specific
 * types of nodes.  Note that this class 'extends' EntityWithNameAndId.  However
 * the 'ResourceTree' node doesn't have a name or id, so it is assigned a null name
 * and id.
 * @author ltclark
 *
 */
abstract class ResourceNode extends EntityWithNameIdAndTeams {
	// TYPES of RESOURCE NODES
	public static final String ROOT_NODE_TYPE = "RootNode"
	public static final String GROUP_NODE_TYPE = "GroupNode"
	public static final String AGENT_NODE_TYPE = "AgentNode"
	public static final String AGENT_POOL_NODE_TYPE = "AgentPoolNode"
	public static final String COMPONENT_NODE_TYPE = "ComponentNode"
	
	// CACHE THE CHILD NODES
	//	- Note that the cache may be a subset of the children or all of the children
	private boolean allChildrenCached = false
	// The cache is a map
	//		key =
	//		node = ResourceNode of the child
	private Map cachedChildren = [:]
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the UCD Server.
	 */
	public ResourceNode( UcdServerConnection ucdServer, String name, String id ) {
		super( ucdServer, new ResourceApi(ucdServer), name, id )
	}
	
	/**
	 * Returns the node's data type as a string, such as 'RootNode' or 'AgentNode'
	 */
	public abstract String getNodeType();
	
	/**
	 * Is this node a RootNode??
	 */
	public boolean isRootNode() {
		return false
	}

	/**
	 * Returns the resource path for this node.  For the root of the tree,
	 * this is an empty string.  An example would be '/appName/envName/agentNodeName'.
	 */
	public abstract String getResourcePath()
	
	/**
	 * Returns the parent node, which is null for the root node.
	 */
	public abstract ResourceNode getParent();
	
	/**
	 * Returns the full resource path for a named child of this node. 
	 * @param childNodeName The name of the child (which may or may not exist).
	 * @return The path, such as '/appname/environment/agentname/componentname'
	 */
	public String getChildNodePath( String childNodeName ) {
		return getResourcePath() + "/" + childNodeName
	}
	
	/**
	 * Does a named child node exist?
	 * @param nodeName The name of the child node.
	 */
	public boolean doesChildNodeExist( String nodeName ) {
		if (cachedChildren.containsKey(nodeName)) {
			return true
		} else {
			return ResourceApi.doesResourceNodeExist(ucdServer, getChildNodePath(nodeName) )
		}
	}
	
	/**
	 * Converts an information block returned by an api call into a ResourceNode.
	 * @param info This is a block of data returned about a node which describes a node.
	 * @return A ResourceNode.
	 */
	public ResourceNode _convertInfoToNode( def info ) {
		
		// This part is a class factory - create concrete class based on the data (group node vs agent node, etc)
		if (info.containsKey('agent')) {
			// THIS IS AN AGENT NODE
			return new AgentResourceNode( ucdServer, this, info )
		} else if (info.containsKey('agentPool')) {
			// AGENT POOL node
			return new AgentPoolResourceNode( ucdServer, this, info )
		} else if (info.containsKey('role') && info.role.specialType=="COMPONENT") {
			// COMPONENT node
			return new ComponentResourceNode( ucdServer, this, info )
		} else {
			// GROUP node
			return new GroupResourceNode( ucdServer, this, info )
		}

	}
	
	/**
	 * Returns the named child node.  Note that the actual class type depends on the node's type.
	 * This throws an exception if the node doesn't exist.
	 * @param nodeName The name of the child node.
	 */
	public ResourceNode getChildNode( String nodeName ) {
		if (cachedChildren.containsKey(nodeName)) {
			return cachedChildren[nodeName]
		} else {
			def info = ResourceApi.getInfo(ucdServer, getChildNodePath(nodeName) )
		
			ResourceNode newNode = _convertInfoToNode(info)
			
			cachedChildren[nodeName] = newNode
			
			return newNode
		}
	}
	
	/**
	 * If this resource node has an ResourceRole, this returns it name or it returns an empty string if not.
	 */
	public String getResourceRole() {
		return ""
	}
	
	/**
	 * If there are one or more Tags for the Resource Node, then this
	 * returns a List of String names.  If there are no Tags, then this returns
	 * null.
	 */
	public List getTags() {
		return null
	}
	
	/**
	 * Returns a List of the properties in the resource node.  Note that this does NOT return
	 * environment properties which are defined by components.
	 * @return This returns the structure returned by the '/cli/resource/getProperties' call which is
	 * a list.  Each member of the list has the following fields: id, name, value, description, secure (which is boolean).
	 */
	public List getProperties() {
		// The general 'ResourceNodes' includes the root, which does NOT have properties
		return []
	}

	/**
	 * Returns a List of all of the child nodes.  The data type of each entry is ResourceNode.
	 */
	public List getChildren() {
		if (allChildrenCached) {
			List children = []
			cachedChildren.each { name, resourceNode ->
				children << resourceNode
			}
			return children
		} else {
			def childEntries = ResourceApi.getChildren(ucdServer, getResourcePath())
			List children = new ArrayList()
			childEntries.each { def entryInfo ->
				// Unfortunately, 'entryInfo' does NOT have enough information, so call getChildNode() to get the full node
				children.add( getChildNode(entryInfo.name) )
			}
			allChildrenCached = true
			return children
		}
	}

	/**
	 * Creates a child Group Node and returns a handle to it.  Throws an exception
	 * if there is already a child with the same name.
	 * @param nodeName The name of the new child Group Node
	 * @param resourceRoleName This is an optional name for a Resource Role to attach to the new Group node.
	 * @param resourceRoleProperties IF a resourceRoleName is provided, this is an optional list of the properties.
	 * This is a Map field.  Each entry is a propertyName=value pair where the map key is the property name and the
	 * map value is the property value.
	 */
	public ResourceNode createChildGroupNode( String nodeName, String resourceRoleName=null, Map resourceRoleProperties=null ) {
		ResourceApi.createGroupResourceNode( ucdServer, getResourcePath(), nodeName, resourceRoleName, resourceRoleProperties )
		return getChildNode(nodeName)
	}
	
	/**
	 * Attempts to find or create (if it doesn't exist) a named 'Group Node' child.  Note that
	 * an exception is thrown if there is already a child, but it is a different type.  Optionally, ResourceRole
	 * information can be provided (name and property list).  The ResourceRole information is ONLY used if the node
	 * is created.  If the node already exists, no attempt is made to change it.
	 * @param nodeName The name of the new child Group Node
	 * @param resourceRoleName This is an optional name for a Resource Role to attach to the new Group node.
	 * @param resourceRoleProperties IF a resourceRoleName is provided, this is an optional list of the properties.
	 * This is a Map field.  Each entry is a propertyName=value pair where the map key is the property name and the
	 * map value is the property value.
	 */
	public ResourceNode getOrCreateChildGroupNode( String nodeName, String resourceRoleName=null, Map resourceRoleProperties=null ) {
		if (! doesChildNodeExist(nodeName)) {
			return createChildGroupNode( nodeName, resourceRoleName, resourceRoleProperties )
		} else {
			ResourceNode childNode = getChildNode(nodeName)
			if (childNode.getNodeType() != GROUP_NODE_TYPE) {
				throw new Exception( "Attempting to find a Group Node child named '${nodeName}' of '${getResourcePath()}', but a node already exists with a different type (${childNode.getNodeType()})")
			} else {
				return childNode
			}
		}
	}
	
	/**
	 * Creates a child Agent Node and returns a handle to it.  Throws an exception
	 * if there is already a child with the same name.
	 * @param nodeName The name of the new child Agent Node
	 * @param agent The agent to tie to the node.
	 */
	public ResourceNode createChildAgentNode( String nodeName, Agent agent ) {
		ResourceApi.createAgentResourceNode( ucdServer, getResourcePath(), nodeName, agent )
		return getChildNode(nodeName)
	}
	
	/**
	 * Creates a child Agent Pool Node and returns a handle to it.  Throws an exception
	 * if there is already a child with the same name.
	 * @param nodeName The name of the new child Agent Pool Node
	 * @param agentPool The agent pool to tie to the node.
	 */
	public ResourceNode createChildAgentPoolNode( String nodeName, AgentPool agentPool ) {
		ResourceApi.createAgentPoolResourceNode( ucdServer, getResourcePath(), nodeName, agentPool )
		return getChildNode(nodeName)
	}
	
	/**
	 * Creates a child Agent or Agent Pool Node and returns a handle to it.  Throws an exception
	 * if there is already a child with the same name.
	 * @param nodeName The name of the new child node.
	 * @param agentOrAgentPool This is an Agent or Agent Pool.
	 */
	public ResourceNode createChildAgentOrAgentPoolNode( String nodeName, AgentOrAgentPool agentOrAgentPool ) {
		if (agentOrAgentPool instanceof Agent) {
			return createChildAgentNode( nodeName, agentOrAgentPool )
		} else {
			return createChildAgentPoolNode( nodeName, agentOrAgentPool )
		}
	}

	/**
	 * Attempts to find or create (if it doesn't exist) a named 'Agent Node' child.  Note that
	 * an exception is thrown if there is already a child, but it is a different type.
	 * @param nodeName The name of the new child Agent Node
	 * @param agent The agent to tie to the node.
	 */
	public ResourceNode getOrCreateChildAgentNode( String nodeName, Agent agent ) {
		if (! doesChildNodeExist(nodeName)) {
			ResourceApi.createAgentResourceNode( ucdServer, getResourcePath(), nodeName, agent )
		}
		ResourceNode childNode = getChildNode(nodeName)
		if (childNode.getNodeType() != AGENT_NODE_TYPE) {
			throw new Exception( "Attempting to find a Agent Node child named '${nodeName}' of '${getResourcePath()}', but a node already exists with a different type (${childNode.getNodeType()})")
		} else {
			return childNode
		}
	}
	
	/**
	 * Creates a child Component Node and returns a handle to it.  Throws an exception
	 * if there is already a child with the same name.
	 * @param nodeName The name of the new child Component Node
	 * @param component The component to tie to the node.
	 */
	public ResourceNode createChildComponentNode( String nodeName, Component component ) {
		ResourceApi.createComponentResourceNode( ucdServer, getResourcePath(), nodeName, component )
		return getChildNode(nodeName)
	}
	
	/**
	 * Attempts to find or create (if it doesn't exist) a named 'Component Node' child.  Note that
	 * an exception is thrown if there is already a child, but it is a different type.
	 * @param nodeName The name of the new child Component Node
	 * @param component The component to tie to the node.
	 */
	public ResourceNode getOrCreateChildComponentNode( String nodeName, Component component ) {
		if (! doesChildNodeExist(nodeName)) {
			ResourceApi.createComponentResourceNode( ucdServer, getResourcePath(), nodeName, component )
		}
		ResourceNode childNode = getChildNode(nodeName)
		if (childNode.getNodeType() != COMPONENT_NODE_TYPE) {
			throw new Exception( "Attempting to find a Component Node child named '${nodeName}' of '${getResourcePath()}', but a node already exists with a different type (${childNode.getNodeType()})")
		} else {
			return childNode
		}
	}
	
	/**
	 * Are the teams inherited from the parent??
	 */
	abstract boolean areTeamsInherited()

	/**
	 * Adds a tag label to a resource tree node. 
	 * @param name The name of the tag.
	 */
	public abstract void addTag( String name );
	
	/**
	 * Recursively resets all cached child nodes.  Essentially, reset descendant cache data.
	 * Use this if the children have changed from a different source.  Adding and deleting
	 * children through this api updates the cache appropriately.
	 */
	public void resetCachedChildren() {
		// Recursively reset child node caches
		cachedChildren.each { String name, ResourceNode childNode ->
			childNode.resetCachedChildren()
		}
		// Reset this cache
		cachedChildren = [:]
		allChildrenCached = false
	}
	
	/**
	 * Delete this resource tree node (and all descendants).  Note that the
	 * parent's cache of child nodes is reset.
	 */
	public void delete() {
		if (! (ResourceNode instanceof ResourceTree)) {
			(new RestDelete( ucdServer )).setPath("/cli/resource/deleteResource")
				.addParameter("resource", this.getResourcePath())
				.deleteWithNoReturnObject()
			getParent().resetCachedChildren()
		}
	}
}
