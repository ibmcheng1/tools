package com.ibm.services.ucr.api.framework

import com.ibm.issr.rest.RestServerConnection;

/**
 * Base class for UCR Entities which have a name and an ID.
 * @author LeonClark
 *
 */
class UcrEntityWithNameAndId extends UcrEntityWithId {
	private String _name
	
	/**
	 * Constructor
	 */
	protected UcrEntityWithNameAndId( RestServerConnection ucrServer, String name, String id ) {
		super( ucrServer, id )
		_name = name
	}
	
	/**
	 * Returns the name.
	 */
	public String getName() {
		return _name
	}

	/**
	 * Override to toString() to return the class name, instance name and instance id.
	 */
	String toString() {
		return this.getClass().getName() + "( name: '" + this.name +"', id: " + this.id + " )"
	}
}
