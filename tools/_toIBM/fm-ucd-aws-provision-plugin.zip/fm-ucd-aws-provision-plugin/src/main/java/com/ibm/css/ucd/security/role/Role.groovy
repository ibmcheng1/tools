package com.ibm.css.ucd.security.role;

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.common.EntityWithNameAndId
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.cache.RestDataCache

public class Role extends EntityWithNameAndId {
	// The cache of the entity data for this entity
	private RestDataCache _cachedEntityData = new RestDataCache()

	/**
	 * Constructor.
	 * @param ucdServer The handle to the UCD Server.
	 * @param info This is an Object version of the info returned with a REST call.
	 * Note that it has at least two fields - name and id.
	 */
	public Role( UcdServerConnection ucdServer, def info ) {
		super( ucdServer, info.name, info.id )
		_cachedEntityData.setCacheData(ucdServer, info)
	}
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 */
	public Role( UcdServerConnection ucdServer, String name, String id ) {
		super( ucdServer, name, id )
	}
	
	/**
	 * Returns the entity data (aka data from REST call) optionaly forcing a cache
	 * refresh.  Note that the cache may reset even if 'resetCache' is false.
	 * @return the Structured data map for the entity data.
	 */
	public Map getEntityData( boolean resetCache=false ) {
		def entityData = _cachedEntityData.getCacheData(ucdServer,resetCache)
		if (! entityData) {
			// reload the entity
			def rawEntityData = (new RestGet( ucdServer ))
					.setPath('/security/role/' + id)
					.getAsObject()
			// Convert the raw data into an entity
			_cachedEntityData.setCacheData(ucdServer, rawEntityData)
		}
		return _cachedEntityData.getCacheData(ucdServer)
	}
}
