package com.ibm.services.ucr.api.entity.versionstatus

import com.ibm.issr.core.entity.IndexedListOfEntities
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.entity.status.UcrStatus
import com.ibm.services.ucr.api.entity.version.UcrVersion
import com.ibm.services.ucr.api.framework.UcrEntityData

class UcrVersionStatusMgr {
	
	// Map of the singleton instances of this class.  Key=RestServerConnection, value=instance of this class
	private static Map _singletons = [:]
	
	// The server for this instance of the Mgr
	RestServerConnection ucrServer
	
	/**
	 * Cached list of loaded entities.  The data type of the cache is IndexedListOfEntities, which is
	 * automatically initialized when the cache is created or resest.
	 */
	RestDataCache _entityCache = new RestDataCache(
		// Cache entry initialization closure - Initialize cache entries as instances of IndexedListOfEntities
		{ RestServerConnection ucrServer ->
			return new IndexedListOfEntities(
				// This closure returns the 'uniqueName' for each entry, which is simply the id because this class has no name
				{ UcrVersionStatus entity ->
					return entity.getId()
				}
				)
		}
		)
	
	/**
	 * Private constructor.
	 * @param ucrServer The associated Rest Server.
	 */
	private UcrVersionStatusMgr( RestServerConnection ucrServer ) {
		this.ucrServer = ucrServer
	}
	
	/**
	 * Returns the singleton instance of this class for the given Rest Server.
	 */
	public static UcrVersionStatusMgr getInstance( RestServerConnection ucrServer ) {
		if (! _singletons.containsKey(ucrServer)) {
			_singletons[ucrServer] = new UcrVersionStatusMgr(ucrServer)
		}
		return _singletons[ucrServer]
	}
	
	/**
	 * Given entity data, this returns a UcrVersionStatus for that data.
	 * @param ucrServer The server.
	 * @param entityData The data returned from some REST call.
	 * @return New or existing entity.
	 */
	public UcrVersionStatus buildEntity( RestServerConnection ucrServer, UcrVersion version, UcrStatus status, UcrEntityData entityData ) {
		UcrVersionStatus entity
		String id = entityData.getEntityObject().id
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			entity = cachedEntities.getEntityById(id)
			// Update the cached entityData
		} else {
			entity = new UcrVersionStatus( ucrServer, version, status, id, entityData )
		}
		return entity
	}
	
	/**
	 * Given an id, this returns a UcrVersionStatus for that data.
	 * @param ucrServer The server.
	 * @return New or existing entity.
	 */
	public UcrVersionStatus buildEntity( RestServerConnection ucrServer, UcrVersion version, UcrStatus status, String id ) {
		UcrVersionStatus entity
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			entity = cachedEntities.getEntityById(id)
			// Update the cached entityData
		} else {
			entity = new UcrVersionStatus( ucrServer, version, status, id )
		}
		return entity
	}

}
