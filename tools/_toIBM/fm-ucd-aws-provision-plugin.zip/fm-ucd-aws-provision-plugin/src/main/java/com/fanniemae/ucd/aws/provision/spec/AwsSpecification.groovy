package com.fanniemae.ucd.aws.provision.spec

import com.fanniemae.ucd.aws.provision.def.common.ConfigFileWrapper
import com.fanniemae.ucd.aws.provision.service.definition.AwsServiceDefinition
import com.fanniemae.ucd.aws.provision.service.definition.EBServiceDefinition
import com.fanniemae.ucd.aws.provision.service.definition.ECSServiceDefinition
import com.fanniemae.ucd.aws.provision.service.definition.RDSServiceDefinition
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.json.JsonHelper
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel

/**
 * This class wraps an AWS Specification/Manifest JSON into classes.
 * This class represents the entire specification.
 * @author s9ulcc
 *
 */
class AwsSpecification extends ConfigFileWrapper {
	
	/**
	 * Maps AWS Service/Reesource types to instances of AwsServiceDefinition.  Each entry is a Map
	 * with the following fields:
	 * <ul>
	 * <li>String serviceType - The name of the service type, such as RDS or EB.</li>
	 * <li>Closure buildInstance - Syntax: AwsServiceDefinition buildInstance( AwsSpecification
	 * awsSpecification, Map instanceData ) - Return a new class instance of AwsServiceDefinition for
	 * the corresponding serviceType.</li>
	 * </ul>
	 */
	private static List instanceBuilders = [
		[ serviceType: ECSServiceDefinition.SERVICE_TYPE, 
			buildInstance: { AwsSpecification awsSpecification, Map instanceData -> return new ECSServiceDefinition(awsSpecification, instanceData) } ],
		[ serviceType: EBServiceDefinition.SERVICE_TYPE, 
			buildInstance: { AwsSpecification awsSpecification, Map instanceData -> return new EBServiceDefinition(awsSpecification, instanceData) } ],
		[ serviceType: RDSServiceDefinition.SERVICE_TYPE, 
			buildInstance: { AwsSpecification awsSpecification, Map instanceData -> return new RDSServiceDefinition(awsSpecification, instanceData) } ]
		]
	
	/**
	 * Entire specification as parsed and Objectified from JSON string.
	 * This is public, but should not generally be accessed directly outside
	 * of this class.
	 */
	public Map spec = null
	
	// Member data
	private String _description = ''
	// The list of service definitions
	private List<AwsServiceDefinition> _serviceDefinitions = []
	
	/**
	 * Constructor.  Note that more complex/expensive verification, such as looking up UCD Components,
	 * are performed as needed.  Call the function performFullVerification() to force full verification. 
	 * @param specification The specification as a JSON string.
	 */
	public AwsSpecification( String specification ) {
		
		// parse the json
		String specificationWithoutComments = JsonHelper.removeCommentLines(specification)
		try {
			spec = new groovy.json.JsonSlurper().parseText( specificationWithoutComments )
			if (spec.containsKey('description')) {
				_description = spec.description
			}
			if ((! spec.containsKey('items')) || spec.items.size()==0) {
				tagValidationError( "An 'items' entry must be in the Manifest, which contains the AWS service definitions" )
			} else {
				List items = spec.items
				int itemNumber = 0
				items.each { Map configItem ->
					++itemNumber
					if (! configItem.containsKey('serviceType')) {
						tagValidationError( "The Manifest Spec is missing the 'serviceType' field for items entry #" + itemNumber )
					} else {
						boolean foundBuilder = false
						instanceBuilders.each { Map instanceBuilder ->
							if (instanceBuilder.serviceType == configItem.serviceType) {
								// Found a matching builder
								foundBuilder = true
								_serviceDefinitions << instanceBuilder.buildInstance(this, configItem)
							}
						}
						if (! foundBuilder) {
							tagValidationError( "Unknown serviceType of '${configItem.serviceType}' found")
						}
					}
				}
			}
		}
		catch (Exception e) {
			tagValidationError( e.message )
			
			if (Logger.displayDebug) {
				Logger.printStackTrace(LoggerLevel.ERROR, e)
			}
		}
	}
	
	/**
	 * Do any of the requested AWS Resource types support separate blue-green instances?
	 * @return
	 */
	public boolean doAnyRequestedAwsResourcesSupportBlueGreen() {
		AwsServiceDefinition serviceWithBlueGreen = _serviceDefinitions.find { AwsServiceDefinition serviceDefinition ->
			return serviceDefinition.shouldProvisionSeparateBlueGreenInstances()
		}
		return (serviceWithBlueGreen != null)
	}
	
	/**
	 * Performs a full/deep verification of the manifest specification and set any failures.
	 * For example, this forces calls to UCD to find the components which is normally
	 * deferred.
	 */
	public void performFullVerification() {
		// Iterate the instances and cascade
		_serviceDefinitions.each { AwsServiceDefinition instanceSpecification ->
			instanceSpecification.performFullVerification()
		}
	}
	
	/**
	 * Returns the list of AWS Service Definitions 
	 * @return
	 */
	public List<AwsServiceDefinition> getServiceDefinitions() {
		return _serviceDefinitions
	}
	
	/**
	 * Returns the description from the spec.  If not defined, this returns an empty string.
	 */
	public String getDescription() {
		return _description
	}
}
