package com.ibm.services.ucr.api.entity.versionstatuscomment

import com.ibm.issr.core.entity.IndexedListOfEntities
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.entity.status.UcrStatus
import com.ibm.services.ucr.api.entity.version.UcrVersion
import com.ibm.services.ucr.api.entity.versionstatus.UcrVersionStatus
import com.ibm.services.ucr.api.entity.versionstatus.UcrVersionStatusMgr
import com.ibm.services.ucr.api.framework.UcrEntityData

class UcrVersionStatusCommentMgr {
	
	// Map of the singleton instances of this class.  Key=RestServerConnection, value=instance of this class
	private static Map _singletons = [:]
	
	// The server for this instance of the Mgr
	RestServerConnection ucrServer
	
	/**
	 * Cached list of loaded entities.  The data type of the cache is IndexedListOfEntities, which is
	 * automatically initialized when the cache is created or resest.
	 */
	RestDataCache _entityCache = new RestDataCache(
		// Cache entry initialization closure - Initialize cache entries as instances of IndexedListOfEntities
		{ RestServerConnection ucrServer ->
			return new IndexedListOfEntities(
				// This closure returns the 'uniqueName' for each entry, which is simply the id because this class has no name
				{ UcrVersionStatusComment entity ->
					return entity.getId()
				}
				)
		}
		)
	
	/**
	 * Private constructor.
	 * @param ucrServer The associated Rest Server.
	 */
	private UcrVersionStatusCommentMgr( RestServerConnection ucrServer ) {
		this.ucrServer = ucrServer
	}
	
	/**
	 * Returns the singleton instance of this class for the given Rest Server.
	 */
	public static UcrVersionStatusCommentMgr getInstance( RestServerConnection ucrServer ) {
		if (! _singletons.containsKey(ucrServer)) {
			_singletons[ucrServer] = new UcrVersionStatusCommentMgr(ucrServer)
		}
		return _singletons[ucrServer]
	}
	
	/**
	 * Builds by returning a new or existing data entity class.
	 * @param ucrServer The server.
	 * @param versionStatus The UcrVersionStatus that this comment belongs to.
	 * @param id The ID of the comment.
	 * @param comment The body of the comment.
	 * @param entityData Optional entity data, which is the REST data within the comment REST calls.
	 * @return New or existing entity.
	 */
	public UcrVersionStatusComment buildEntity( RestServerConnection ucrServer, UcrVersionStatus versionStatus, String id, String comment, UcrEntityData entityData = null ) {
		UcrVersionStatusComment entity
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			entity = cachedEntities.getEntityById(id)
			// Update the cached entityData
		} else {
			entity = new UcrVersionStatusComment( ucrServer, versionStatus, id, comment, entityData )
			cachedEntities.addEntity(entity)
		}
		return entity
	}

}
