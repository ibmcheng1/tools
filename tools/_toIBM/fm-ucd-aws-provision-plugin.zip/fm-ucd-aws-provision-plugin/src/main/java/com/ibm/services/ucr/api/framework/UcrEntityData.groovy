package com.ibm.services.ucr.api.framework

/**
 * A UcrEntityData is the parsed/slurped value of a REST data retrieval call.
 * The UCR Rest API needs to retrieve and save the REST Entity information.
 * @author LeonClark
 *
 */
class UcrEntityData {
	def entityObject
	UcrEntityDataFormat entityFormat
	
	/**
	 * Constructor
	 * @param entityObject The object version (via parse/slurp) of the entity data
	 * returned from a UCR REST api call.
	 * @param entityFormat The format of the data, such as UcrEntityDataFormat.LIST_FORMAT.
	 */
	public UcrEntityData( def entityObject, UcrEntityDataFormat entityFormat ) {
		this.entityObject = entityObject
		this.entityFormat = entityFormat
	}
	
	/**
	 * Returns the JSON entity object as a JSON string.
	 */
	public String getEntityObjectAsJsonString() {
		return groovy.json.JsonOutput.toJson( entityObject )
	}
}
