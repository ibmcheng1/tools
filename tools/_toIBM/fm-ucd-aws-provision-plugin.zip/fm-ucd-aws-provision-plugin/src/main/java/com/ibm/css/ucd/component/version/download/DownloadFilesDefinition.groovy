package com.ibm.css.ucd.component.version.download

/**
 * Defines definition/DSL options for the
 * {@link com.ibm.css.ucd.component.version.ComponentVersion#downloadFiles(String, groovy.lang.Closure) ComponentVersion.downloadFiles()}
 * method.  The functions in this class define the DSL commands.
 * @author LeonClark
 *
 */
class DownloadFilesDefinition {
	// The List of include clauses.  Each one is a string.
	private List _includes = []
	// The List of exclude clauses.  Each one is a string.
	private List _excludes = []
	// The 'setExectionBits' flag
	private boolean _setExecutionBits = false
	
	/**
	 * Adds an 'include' clause.
	 * @param clause The clause with wildcards, such as '**.txt'
	 */
	public void include( String clause ) {
		_includes << clause
	}
	
	/**
	 * Adds an 'exclude' clause.
	 * @param clause The clause with wildcards, such as '**.txt'
	 */
	public void exclude( String clause ) {
		_excludes << clause
	}
	
	/**
	 * Sets the 'setExecutionBits' flag.  If this is NEVER called,
	 * the default value is false.
	 */
	public void setExecutionBits( boolean value=true ) {
		_setExecutionBits = value
	}
	
	/**
	 * Returns the List of 'include' clauses, where each member of the List
	 * is a String. 
	 */
	public List getIncludes() {
		return _includes
	}
	
	/**
	 * Returns the List of 'exclude' clauses, where each member of the List
	 * is a String. 
	 */
	public List getExcludes() {
		return _excludes
	}
}
