package com.ibm.css.ucd.snapshot

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.snapshot.SnapshotApi
import com.ibm.css.ucd.common.CacheData
import com.ibm.css.ucd.common.EntityWithNameAndId
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.status.SnapshotStatus
import com.ibm.css.ucd.status.SnapshotStatusInstance
import com.ibm.issr.rest.RestDelete
import com.ibm.issr.rest.RestPut

/**
 * An entity representing on UCD Snapshot.
 * @author ltclark
 *
 */
class Snapshot extends EntityWithNameAndId {
	// Cached set of entries for this entity.
	//	key = UcdServerConnection
	//	value = Map where
	//		key = id
	//		value = entity class, such as Application or Environment
	static protected Map cache = [:]
	
	// Cached List of snapshot statuses.  Each entry of type SnapshotStatusInstance.
	CacheData _cached_snapshotStatusInstances = new CacheData(Snapshot.class, false)
	// cached 'info' for this snapshot
	CacheData _cached_info = new CacheData(Snapshot.class, false)

	/**
	 * Constructor.
	 * @param ucdServer The handle to the UCD Server.
	 * @param info This is an Object version of the call to /cli/snapshot/getSanpshot.
	 * Note that it has at least two fields - name and id.
	 */
	public Snapshot( UcdServerConnection ucdServer, def info ) {
		super( ucdServer, info.name, info.id )
	}
	
	/**
	 * Constructor given a snapshot name and ID.  This does NOT validate the
	 * existence of the snapshot, but it's existence should be validated before calling
	 * this function.
	 * @param ucdServer The handle to the UCD Server.
	 * @param name The name of the snapshot.
	 * @param id The ID of the snapshot.
	 */
	public Snapshot( UcdServerConnection ucdServer, String name, String id ) {
		super( ucdServer, name, id )
	}

	/**
	 * Cached creation of new entities.  If the entity is already in the cache, the existing entity
	 * is returned.  Otherwise, a new entity is created, added to the cache and returned.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 * @return The requested entity.
	 */
	public static Snapshot getSnapshotWithCache( UcdServerConnection ucdServer, String name, String id ) {
		if (! cache.containsKey(ucdServer)) {
			cache[ucdServer] = [:]
		}
		if (! cache[ucdServer].containsKey(id)) {
			cache[ucdServer][id] = new Snapshot( ucdServer, name, id )
		}
		return cache[ucdServer][id]
	}
	
	/**
	 * Returns the REST information
	 * @param resetCache If true, then skips cached data and reloads via a REST call.
	 * @return
	 */
	private def getInfo( boolean resetCache = false ) {
		def info = _cached_info.getCacheData(resetCache)
		if (info == null) {
			info = _cached_info.setCacheData(SnapshotApi.getSnapshotInfoFromId(ucdServer, this.id))
		}
		return info
	}

	/**
	 * Deletes this snapshot from UCD
	 */
	public void delete() {
		SnapshotApi.deleteSnapshotById(ucdServer, this.getId())
	}
	

	/**
	 * Are the component versions in this snapshot locked?? 	
	 * @param resetCache If true, then skips cached data and reloads via a REST call.
	 */
	public boolean isVersionsLocked( boolean resetCache = false ) {
		def info = this.getInfo(resetCache)
		return (info.containsKey('versionsLocked') && info.versionsLocked)
	}
	
	/**
	 * Are the configuration for this snapshot locked??
	 * @param resetCache If true, then skips cached data and reloads via a REST call.
	 */
	public boolean isConfigLocked( boolean resetCache = false ) {
		def info = this.getInfo(resetCache)
		return (info.containsKey('configLocked') && info.configLocked)
	}
	
	/**
	 * Locks the snapshot's component versions.  Once locked, there is no way to unlock.
	 */
	public void lockSnapshotVersions() {
		def responseObject = (new RestPut( ucdServer )).setPath("/cli/snapshot/lockSnapshotVersions")
			.addParameter('snapshot', this.id)
			.putWithNoReturnObject()
			// Reset the info cache
			_cached_info.clearCacheData()
	}
	
	/**
	 * Locks the snapshot's configuration.  Once locked, there is no way to unlock.
	 */
	public void lockSnapshotConfiguration() {
		def responseObject = (new RestPut( ucdServer )).setPath("/cli/snapshot/lockSnapshotConfiguration")
			.addParameter('snapshot', this.id)
			.putWithNoReturnObject()
		// Reset the info cache
		_cached_info.clearCacheData()
	}

	
	/**
	 * Returns the list of component versions that are in this snapshot.
	 * @return A List, each member of the list is a Map with the fields
	 * name (of the component), id (of the component) and 'versions'.  versions is a nested List
	 * with the ordered list of versions for the component.  Each entry in 'versions'
	 * contains the following fields: name and id (of the component version). 
	 */
	public List getComponentVersions() {
		List retval = []
		def components = SnapshotApi.getComponentsAndVersionsInSnapshot( ucdServer, this.getId() )
		components.each { def component ->
			def componentRetval = [:]
			componentRetval.name = component.name
			componentRetval.id = component.id
			def componentVersionsRetval = []
			component.desiredVersions.each { def desiredVersion ->
				def versionRetval = [:]
				versionRetval.name = desiredVersion.name
				versionRetval.id = desiredVersion.id
				componentVersionsRetval << versionRetval
			}
			componentRetval.versions = componentVersionsRetval
			retval << componentRetval
		}
		return retval
	}
	
	/**
	 * Returns the List of member ComponentVersions.  Each entry in the list is of type
	 * ComponentVersion.
	 */
	public List getComponentVersionObjects() {
		List rawList = getComponentVersions()
		List retval = []
		rawList.each { def componentEntry ->
			Component component = Component.getComponentWithCache(ucdServer, componentEntry.name, componentEntry.id)
			componentEntry.versions.each { def versionEntry -> 
				retval << new ComponentVersion(ucdServer, component, versionEntry.name, versionEntry.id)
			}
		}
		return retval
	}

		
	/**
	 * Adds the given Component Version to this snapshot.  This will fail
	 * if the snapshot is locked.
	 */
	public void addComponentVersion( ComponentVersion componentVersion ) {
		def responseObject = (new RestPut( ucdServer )).setPath("/cli/snapshot/addVersionToSnapshot")
		.addParameter('snapshot', this.id)
		.addParameter('version', componentVersion.id )
		.putWithNoReturnObject()
		// Reset the info cache
		_cached_info.clearCacheData()

	}

	/**
	 * Does this Snapshot contain ANY component versions?? 
	 */
	public boolean hasAnyVersions() {
		boolean retval = false
		def components = SnapshotApi.getComponentsAndVersionsInSnapshot( ucdServer, this.getId() )
		components.each { def component ->
			if (component.desiredVersions.size() > 0) {
				retval = true
			}
		}
		return retval
	}
	
	/**
	 * Returns the List of 'SnapshotStatusInstance' entries for this snapshot.
	 * @param resetCache If true, then resets the cache of snapshot status information
	 * for this snapshot and reloads from UCD Server.
	 */
	public List getSnapshotStatuses( boolean resetCache=false ) {
		List statusInstances = _cached_snapshotStatusInstances.getCacheData(resetCache)
		if (statusInstances == null) {
			statusInstances = []
			List statusEntries = SnapshotApi.getSnapshotStatusList(ucdServer, this.id)
			statusEntries.each { def statusEntry ->
				statusInstances << new SnapshotStatusInstance(ucdServer, this, statusEntry.name, statusEntry.id)
			}
			_cached_snapshotStatusInstances.setCacheData(statusInstances)
		}
		return statusInstances
	}
	
	/**
	 * Does this snapshot have the given status?
	 * @param snapshotStatus Desired snapshot status
	 * @param resetCache If true, then resets the cache of snapshot status information
	 * for this snapshot and reloads from UCD Server.
	 */
	public boolean hasSnapshotStatus( SnapshotStatus snapshotStatus, boolean resetCache=false ) {
		return getSnapshotStatuses(resetCache).find { SnapshotStatusInstance snapshotStatusInstance ->
			return snapshotStatusInstance.getSnapshotStatus().equals(snapshotStatus)
		}
	}
	
	/**
	 * Adds the given snapshot status to this snapshot.
	 */
	public void addSnapshotStatus( SnapshotStatus snapshotStatus ) {
		SnapshotApi.addSnapshotStatus(ucdServer, this.id, snapshotStatus.id)
		// reset the cache
		_cached_snapshotStatusInstances.clearCacheData()
	}
	
	/**
	 * Removes the given snapshot status from the snapshot throwing an exception if there is any
	 * problem.  If the snapshot doesn't have the status that you are removing, no exception is
	 * thrown, because the underlying UCD REST API reports successful completion (even though status was not
	 * there to remove).
	 */
	public void removeSnapshotStatus( SnapshotStatus snapshotStatus ) {
		(new RestDelete( ucdServer )).setPath("/rest/deploy/snapshot/${this.getId()}/status/" + snapshotStatus.getName() )
			.deleteWithNoReturnObject()

	}
}
