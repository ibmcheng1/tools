package com.ibm.css.rest.ucd.process

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.issr.rest.RestPut
import com.ibm.issr.rest.RestResponse

/**
 * Process APIs - application, component and generic
 * @author ltclark
 *
 */
class ProcessApi {
	/**
	 * Sets a runtime Process property (aka dynamic property).  The process may be an application,
	 * component or generic process.
	 * @param ucdServer Handle to a UCD Server Session.
	 * @param processRequestId The ID of the runtime process, which may be application, component or generic.
	 * @param propertyName The name of the property to set.
	 * @param propertyValue The value to set
	 * @param secure Should this be set as a secure/encrypted property?
	 */
	public static void setProcessRequestProperty( UcdServerConnection ucdServer, String processRequestId, String propertyName, String propertyValue, boolean secure=false) {
		def payload = [
			[
				name: propertyName,
				value: propertyValue,
				secure: "${secure}"			// Note that this has to be a string and not a boolean value 
			]
		]
		def jsonBuilder = new groovy.json.JsonBuilder()
		jsonBuilder payload
		String payloadString = jsonBuilder.toString()

		// Try the application process first
		def isResponseOk = (new RestPut( ucdServer )).setPath("/rest/deploy/applicationProcessRequest/${processRequestId}/saveProperties")
			.setPayload(payloadString)
			.put() { RestResponse response ->
				// Return true if the HTTP Response is OK, otherwise return false
				return (response.isOk())
			}

		if (! isResponseOk) {
			// the application process failed, so try the component process
			isResponseOk = (new RestPut( ucdServer )).setPath("/rest/deploy/componentProcessRequest/${processRequestId}/saveProperties")
				.setPayload(payloadString)
				.put() { RestResponse response ->
					// Return true if the HTTP Response is OK, otherwise return false
					return (response.isOk())
				}

			if (! isResponseOk) {
				// Both the Application and Component Process Requests failed, try a generic Process Request.
				isResponseOk = (new RestPut( ucdServer )).setPath("/rest/process/request/${processRequestId}/saveProperties")
					.setPayload(payloadString)
					.put() { RestResponse response ->
						// Return true if the HTTP Response is OK, otherwise return false
						return (response.isOk())
					}

				if (! isResponseOk) {
					throw new Exception( "Unable to define the Process Property named ${propertyName}")
				}
			}
		}

	}

}
