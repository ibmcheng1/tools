package com.ibm.issr.core.properties

/**
 * The normal Java/Groovy Property files use escape characters. But, frequently
 * developers use property files that are straight text with no escapes.  That
 * is what this class is.
 * <br/>
 * This class supports a very limited number of special characters.
 * <ul>
 * <li>Comments are lines that contain '#' or '!' in the first character of te line</li>
 * <li>Optionally, property values can span multiple lines. By default, they don't.  Call
 * the function addSupportMultipleLineProperties() to turn on multiple line properties.  The
 * parameter is the line continuation character.</li>
 * </ul>
 *  * @author LeonClark
 *
 */
class SimpleProperties {
	// This is the list of entries in the properties 'file', which includes
	// properties, comments and blank lines.
	// 'propertyEntries' is a List of structured map entries.  Each map contains:
	//		entryType of 'property' or 'literal'.  Note that 'literal' is a comment and/or blank line.
	//		lines is an List of the line contents of the line (one or more) for the entry.  This includes the full text include property name and comment markers.
	//		propertyName is ONLY defined for 'property' entries and is the name of the property for the entry.
	private List propertyEntries = []
	private boolean multipleLinePropertiesSupported = false
	private String continuationCharacter = ''
	
	/**
	 * By default, property values don't span lines.  Call this function to turn on multiple line support.
	 * @param continuationCharacter If a property line value ends with this character, the property value continues.
	 */
	public void addSupportMultipleLineProperties( String continuationCharacter = "\\") {
		multipleLinePropertiesSupported = true
		this.continuationCharacter = continuationCharacter
	}
	
	/**
	 * If these properties contain an entry for 'key', completely remove it.
	 * @param key The property key to remove.
	 */
	public void removeProperty( String key ) {
		boolean found = false
		def foundIndex
		propertyEntries.eachWithIndex { Map propertyEntry, def index ->
			if (propertyEntry.entryType == 'property') {
				if (propertyEntry.propertyName == key) {
					found = true
					foundIndex = index
				}
			}
		}
		if (found) {
			propertyEntries.remove( foundIndex )
		}
	}
	
	/**
	 * Sets the value of the named property.  This replaces existing property if one
	 * with same name already exists.
	 * @param key The name of the property.
	 * @param value The value of the property, which can be a multiple line value.
	 * @return The previous value of the property or null if the property had no previous value.
	 */
	public Object setPropertyValue( String key, String value ) {
		Object retval = getPropertyValue(key)
		
		// Calculate the new 'lines' for this entry.
		List lines = []
		int lineNumber = 0
		value.eachLine { String line ->
			if (lineNumber == 0) {
				lines << key + "=" + line
			} else {
				if (multipleLinePropertiesSupported) {
					lines[lineNumber-1] = lines[lineNumber-1] + continuationCharacter
					lines << line
				} else {
					lines[0] = lines[0] + "\\n" + line
				}
			}
			++lineNumber
		}
		
		// Iterate existing properties to replace if it exists
		boolean updatedExistingEntry = false
		propertyEntries.each { Map propertyEntry ->
			if (propertyEntry.entryType == 'property') {
				if (propertyEntry.propertyName == key) {
					propertyEntry.lines = lines
					updatedExistingEntry = true
				}
			}
		}
		
		// Append new entry if not found
		if (! updatedExistingEntry) {
			propertyEntries << [entryType:'property', lines:lines, propertyName:key]
		}
		
		return retval
	}

	/**
	 * Searches for the named key in the properties.  If found, then this returns
	 * the value.  If not found, then this returns the 'defaultValue'.  Note that this
	 * is called getPropertyValue instead of getProperty otherwise the name conflicts with
	 * the built in Groovy function called getProperty.
	 * @param key The property name/key to look for.
	 * @param defaultValue Value to return if the property key isn't found.
	 * @return The value if found or 'defaultValue' if not found.
	 */
	public String getPropertyValue( String key, String defaultValue = null ) {
		String retval = defaultValue
		
		// Iterate existing properties
		propertyEntries.each { Map propertyEntry ->
			if (propertyEntry.entryType == 'property') {
				if (propertyEntry.propertyName == key) {
					// Matching entry found!!
					int lineNumber = 1
					String lineDelim = ""
					retval = ""
					
					propertyEntry.lines.each { line ->
						String lineContents
						if (lineNumber==1) {
							int equalIndex = line.indexOf("=")
							lineContents = line.substring(equalIndex+1)
						} else {
							lineContents = line
						}
						if ((lineNumber < propertyEntry.lines.size()) && lineContents.endsWith(continuationCharacter)) {
							lineContents = lineContents.substring( 0, lineContents.length()-continuationCharacter.length() )
						}
						retval = retval + lineDelim + lineContents
						++lineNumber
						lineDelim = "\n"
					}
				}
			}
		}
		return retval
	}

	/**
	 * Write the property file to a File.
	 */
	public void store( File file ) {
		file.withOutputStream { OutputStream stream ->
			store( stream )
		}
	}

	/**
	 * Write the property file to an output stream.
	 */
	public void store( OutputStream outStream ) {
		String body = ""
		String delim = ""
		propertyEntries.each { propertyEntry ->
			propertyEntry.lines.each { line ->
				body = body + delim + line
				delim = "\n"
			}
		}
		outStream.write( body.getBytes() )
	}
	
	/**
	 * Load the simple properties from a File.
	 */
	public void load( File file ) {
		file.withInputStream { InputStream stream ->
			load( stream )
		}
	}

	/**
	 * Load the simple properties from an input stream.
	 */
	public void load( InputStream inStream ) {
		// Load the lines of the stream/file
		List lines = inStream.readLines()
		
		// If a property continues to the next line, then 'continuingPropertyLines' is set to
		// the 'lines' array value of the
		def continuingPropertyLines = null
		
		// track the line number
		int lineNumber = 0

		lines.each { String line ->
			++lineNumber
			// Is this a line continuation of a property value??
			if (continuingPropertyLines) {
				continuingPropertyLines.add( line )
				if (! line.endsWith(continuationCharacter)) {
					// no more lines for this property
					continuingPropertyLines = null
				}
			} else {
				String trimmedLine = line.trim()
				if (trimmedLine.startsWith("#") || trimmedLine.startsWith("!") || (! trimmedLine)) {
					// this is a commment or empty row
					def newEntry = [entryType:"literal", lines:[line]]
					propertyEntries.add(newEntry)
				} else {
					// This SHOULD be a property definition row.  If not, throw an error
					int equalIndex = line.indexOf("=")
					if (equalIndex < 0) {
						throw new Exception("Line ${lineNumber} of property file has no '=' - '${line}'")
					}
					String propertyName = line.substring(0,equalIndex).trim()
					if (! propertyName) {
						throw new Exception("Line ${lineNumber} of property file is missing the property name - '${line}'")
					}
					def newEntry = [entryType:"property", lines:[line], propertyName:propertyName]
					if (multipleLinePropertiesSupported && line.endsWith(continuationCharacter)) {
						continuingPropertyLines = newEntry.lines
					}
					propertyEntries.add(newEntry)
				}
				
			}

		}
	}
}
