package com.ibm.css.rest.ucd.request

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.request.entity.ProcessRequestStatus
import com.ibm.css.rest.util.PagedDataIterator;
import com.ibm.css.ucd.application.Application
import com.ibm.issr.core.log.Logger
import com.ibm.issr.rest.RestDelete
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPut

/**
 * Helper functions for Process Requests.
 * @author ltclark
 *
 */
class ProcessRequestApi {
	UcdServerConnection ucdServer
	
	/**
	 * Constructor for this light weight class.
	 * @param ucdServer Handle to UCD Server
	 */
	public ProcessRequestApi( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
	}
	
	
	/**
	 * Loads the information data structure for a process request.
	 * @param processRequestId The Process Request ID.
	 * @return The object tree.
	 */
	public def getProcessRequestInfo( String processRequestId ) {
		return (new RestGet( ucdServer )).setPath("/cli/applicationProcessRequest/info/${processRequestId}").getAsObject()
	}
	
	/**
	 * Returns the activity trace for the request as an object tree as per
	 * the cli rest call /cli/applicationProcessRequest/{request}.
	 * @param processRequestId The ID of the process request.
	 * @return The object tree.
	 */
	public def getActivityTrace( String processRequestId ) {
		return (new RestGet( ucdServer )).setPath("/cli/applicationProcessRequest/${processRequestId}").getAsObject()
	}
	
	/**
	 * Returns a List of the current context properties.
	 * @param processRequestId The ID of the process request.
	 * @return Each List member contains: id, name, value and secure.
	 */
	public List getContextProperties( String processRequestId ) {
		return (new RestGet( ucdServer )).setPath("/rest/deploy/applicationProcessRequest/${processRequestId}").getAsObject().contextProperties
	}
	
	/**
	 * Returns a list of historical Application Process Requests.  This may be a huge list, so several filtering options are
	 * included.
	 * @param ucdServer Handle to the server.
	 * @param startedAfter If not null, then only requests that started after this date/time are included.  Note
	 * that this filter is passed to the REST API call, so it filters records server side.
	 * @param filterAndTransformRecord This is a closure which takes one parameter - a data record.  If it returns null, then the
	 * record is not included in the result set.  If it returns a non-null value, than that value is included in the result set.
	 * @return Returns the filtered list of matching records.  The body of the records is defined by the REST API call
	 * cli/applicationProcessRequest.
	 */
	@Deprecated
	public static List getProcessHistory( UcdServerConnection ucdServer, Date startedAfter, Closure filterAndTransformRecord ) {
		return (new ProcessRequestApi(ucdServer)).getProcessHistory(startedAfter,filterAndTransformRecord)
	}
	
	/**
	 * Returns a list of historical Application Process Requests.  This may be a huge list, so several filtering options are
	 * included.  This is deprecated and iterateProcessHistory() is the preferred function.  Why?  This function builds a result list,
	 * which can be huge.  The iterate function processes records as it goes, thus inherently using less memory.
	 * @param ucdServer Handle to the server.
	 * @param startedAfter If not null, then only requests that started after this date/time are included.  Note
	 * that this filter is passed to the REST API call, so it filters records server side.
	 * @param filterAndTransformRecord This is a closure which takes one parameter - a data record.  If it returns null, then the
	 * record is not included in the result set.  If it returns a non-null value, than that value is included in the result set.
	 * @return Returns the filtered list of matching records.  The body of the records is defined by the REST API call
	 * cli/applicationProcessRequest.
	 */
	@Deprecated
	public List getProcessHistory( Date startedAfter, Closure filterAndTransformRecord ) {
		// Implementation notes - The matching records are returned in pages of up to 100 records
		
		List retval = []
		
		// Get the number of matches
		RestGet restGet = (new RestGet( ucdServer )).setPath("/cli/applicationProcessRequest/count")
		if (startedAfter) {
			restGet.addParameter("startedAfter", startedAfter.getTime().toString() )
		}
		def countValueStructure = restGet.getAsObject()
		int numberOfRecords = countValueStructure.appProcReqCount
		
		for (int startIndex=0; startIndex<numberOfRecords; startIndex += 100) {
			// By default /cli/applicationProcessRequest returns the next 100 records starting at
			// the zero-based 'startIndex'.  For example, if 'startIndex' is 1, it returns #1 to #101.
			restGet = (new RestGet( ucdServer )).setPath("/cli/applicationProcessRequest")
			.addParameter( "startIndex", startIndex.toString() )
			if (startedAfter) {
				restGet.addParameter("startedAfter", startedAfter.getTime().toString() )
			}
			List nextRecords = restGet.getAsObject()
			int recordIndex = startIndex		// which record # is getting processed (zero based from start of list)
			nextRecords.each { def processRecord ->
				// If new records have shown up since this started, ignore them
				if (recordIndex < numberOfRecords) {
					def transformedRecord = filterAndTransformRecord(processRecord)
					if (transformedRecord) {
						retval << transformedRecord
					}
				}
				++recordIndex
			}
		}
		
		return retval
	}
	
	
	/**
	 * Iterate the Process Request history reports for a specific Application.  For each record, it calls the 'closure' function.  It's
	 * up to the closure function to perform additional processing, such as filtering the records, building a list, etc
	 * @param application The Application to retrieve Process Request history.
	 * @param callback This function is called for each member record.  It takes one parameter, which is the Object version of the json
	 * entry for each record returned by the rest call.
	 */
	public void iterateProcessHistoryForApplication( Application application, Closure callback ) {
		
		PagedDataIterator.iteratePagedData(150, callback) { int pageSize, long pageNumber ->
			// Retrieve the records on 'pageNumber' with a 'pageSize'
			List nextRecords = (new RestGet( ucdServer )).setPath("/rest/deploy/applicationProcessRequest/table")
				.addParameter( "rowsPerPage", pageSize.toString() )
				.addParameter( "pageNumber", pageNumber.toString() )
				.addParameter( "orderField", "calendarEntry.scheduledDate")
				.addParameter( "sortType", "asc")
				.addParameter( "filterFields", "application.id")
				.addParameter( "filterValue_application.id", application.id)
				.addParameter( "filterType_application.id", "eq")
				.addParameter( "filterClass_application.id", "UUID")
				.addParameter( "outputType", "BASIC")
				.addParameter( "outputType", "LINKED")
				.getAsObject()
			return nextRecords
		}
	}

	
	/**
	 * Iterate the Process Request history reports.  For each record, it calls the 'closure' function.  It's
	 * up to the closure function to perform additional processing, such as filtering the records, building a list, etc
	 * @param startedAfter If not null, then only requests that started after this date/time are included.  Note
	 * that this filter is passed to the REST API call, so it filters records server side.
	 * @param callback This function is called for each member record.  It takes one parameter, which is the Object version of the json
	 * entry for each record returned by /cli/applicationProcessRequest.
	 */
	public void iterateProcessHistory( Date startedAfter, Closure callback ) {
		// Implementation notes 
		//   - The REST API returns 100 records at a time
		//   - Instead of providing a page number for the REST call, you provide a 0 based starting record number,
		//	   so, page 1 (1 based pages) has an index of 0, page 2 is index of 100, ...
		//   - Specifically, 'startIndex' = (pageNumber -1) * 100 
		
		PagedDataIterator.iteratePagedData(100, callback) { int pageSize, long pageNumber ->
			// Retrieve the records on 'pageNumber' with a 'pageSize'
			// Convert page number into 0 based record index
			long startIndex = (pageNumber - 1) * pageSize
			RestGet restGet = (new RestGet( ucdServer )).setPath("/cli/applicationProcessRequest")
			.addParameter( "startIndex", startIndex.toString() )
			if (startedAfter) {
				restGet.addParameter("startedAfter", startedAfter.getTime().toString() )
			}
			List nextRecords = restGet.getAsObject()
			if (nextRecords.size() > pageSize) {
				// don't return to many records
				nextRecords = nextRecords.take(pageSize)
			}
			return nextRecords
		}
	}

	/**
	 * When working with Application Processes, there are two distinct entities involved.
	 * The application request (and corresponding app request id) is all of the information about EXCEPT
	 * for the schedule (past, present or future).  There is a corresponding Calendar entry that manages
	 * the schedule of the request.  This function returns the calendar id for a given application request id.
	 */
	@Deprecated
	public static String getCalendarIdForApplicationRequestId( UcdServerConnection ucdServer, String applicationRequestId ) {
		return (new ProcessRequestApi(ucdServer)).getCalendarIdForApplicationRequestId(applicationRequestId)
	}
	
	/**
	 * When working with Application Processes, there are two distinct entities involved.
	 * The application request (and corresponding app request id) is all of the information about EXCEPT
	 * for the schedule (past, present or future).  There is a corresponding Calendar entry that manages
	 * the schedule of the request.  This function returns the calendar id for a given application request id. 
	 */
	public String getCalendarIdForApplicationRequestId( String applicationRequestId ) {
		def restResponse = (new RestGet( ucdServer )).setPath("/rest/deploy/applicationProcessRequest/${applicationRequestId}")
			.getAsObject()
		Logger.debug "getCalendarIdForApplicationRequestId().rest response is ${restResponse}"
		String deploymentRequestId = restResponse.entry.id
		Logger.debug "getCalendarIdForApplicationRequestId() -> ${deploymentRequestId}"
		return deploymentRequestId
	}

	/**
	 * Returns information (as object structure) for the given application request id.
	 */
	@Deprecated
	public static def getInformationForApplicationRequestId( UcdServerConnection ucdServer, String applicationRequestId ) {
		return (new ProcessRequestApi(ucdServer)).getInformationForApplicationRequestId(applicationRequestId)
	}
	
	/**
	 * Returns information (as object structure) for the given application request id.
	 */
	public def getInformationForApplicationRequestId( String applicationRequestId ) {
		def information = (new RestGet( ucdServer )).setPath("/rest/deploy/applicationProcessRequest/${applicationRequestId}")
			.getAsObject()
		Logger.debug "getInformationForApplicationRequestId response is ${information}"
		return information
	}
	
	/**
	 * If (and only if) the process has approvals (past or pending), then process has an associated Approval process ID.
	 * This function returns that Approval Process ID or null if this process request has no associated approvals (past or pending)
	 * @param applicationRequestId The application process request.
	 */
	public String getApprovalId( String applicationRequestId ) {
		String approvalId = null
		
		def info = this.getInformationForApplicationRequestId(applicationRequestId)
		if (info.containsKey('approval')) {
			approvalId = info.approval.id
		}
		
		return approvalId
	}

	/**
	 * Calls a nested application process.
	 * @param applicationName The name of the UCD Application that contains the the process.
	 * @param processName The name of the process to call.
	 * @param environmentName The environment to run in.
	 * @param onlyChanged Is the only changed flag set?
	 * @param snapshotName Optional name of the snapshot to use.  Otherwise, use empty string.
	 * @param componentVersionPayload This is a List where each entry is one component and version.  Each entry is a map with
	 * 'version' and 'component' entries - the component name and version label.
	 * @param props List of property values to send to the application process.
	 * @param scheduleFor If this is non-blank, then it is the server date and time to start the process in
	 * the format of yyyy-mm-dd hh:mm.  If blank, then start immediately.  If this is not empty, then 'waitForProcess' is automatically
	 * set to false.
	 * @param waitForProcess Wait for the nested process to complete before continuing??
	 * @return A list of return values - String requestId - the generated request ID;
	 * 	String outputStatus - the status of the nested process of "Success", "Failure" or "Did Not Wait";
	 *  String requestStatus - the status that UCD returns for the request
	 *  String processStatus - the last status returned by checking the process' status
	 *  String webAddress = Web Address for the generated process
	 */
	@Deprecated
	public static List callApplicationProcess( UcdServerConnection ucdServer, String applicationName, String processName, String environmentName, String onlyChanged, String snapshotName, List componentVersionPayload, Properties props, String scheduleFor, boolean waitForProcess ) {
		return (new ProcessRequestApi(ucdServer)).callApplicationProcess(applicationName, processName, environmentName, onlyChanged, snapshotName, componentVersionPayload, props, scheduleFor, waitForProcess)
	}

	/**
	 * Calls a nested application process.
	 * @param applicationName The name of the UCD Application that contains the the process.
	 * @param processName The name of the process to call.
	 * @param environmentName The environment to run in.
	 * @param onlyChanged Is the only changed flag set?
	 * @param snapshotName Optional name of the snapshot to use.  Otherwise, use empty string.
	 * @param componentVersionPayload This is a List where each entry is one component and version.  Each entry is a map with
	 * 'version' and 'component' entries - the component name or id and version label or id.
	 * @param props List of property values to send to the application process.
	 * @param scheduleFor If this is non-blank, then it is the server date and time to start the process in
	 * the format of yyyy-mm-dd hh:mm.  If blank, then start immediately.  If this is not empty, then 'waitForProcess' is automatically
	 * set to false.
	 * @param waitForProcess Wait for the nested process to complete before continuing??
	 * @return A list of return values - String requestId - the generated request ID;
	 * <ul>
	 * 	<li>String outputStatus - the status of the nested process of "Success", "Failure" or "Did Not Wait";</li>
	 *  <li>String requestStatus - the status that UCD returned for the request</li>
	 *  <li>String processStatus - the last status returned by checking the process' status.  Essentially, if 'waitForProcess' is
	 *  true and this returned 'processStatus' is anything except SUCCEEDED, then the process failed to run to completion.  Note
	 *  that it may have been cancelled or failed.</li>
	 *  <li>String webAddress - Web Address for the generated process</li>
	 *  <li>String processId - The process/request ID of the nested process.</li>
	 * </ul>
	 * Example call with return values: def (String outputStatus, String requestStatus, String processStatus, String webAddress) = callApplicationProcess(...)
	 */
	public List callApplicationProcess( String applicationName, String processName, String environmentName, String onlyChanged, String snapshotName, List componentVersionPayload, Properties props, String scheduleFor, boolean waitForProcess ) {
		if (scheduleFor) {
			waitForProcess = false
		}
		def payload =  [
			application: applicationName,
			applicationProcess: processName,
			environment: environmentName,
			onlyChanged: onlyChanged
		]
		if (scheduleFor) {
			payload.date = scheduleFor
		}
		if (componentVersionPayload && componentVersionPayload.size() > 0) {
			payload.versions = componentVersionPayload
		}
		if (props && props.size() > 0) {
			payload.properties = props
		}
		if (snapshotName) {
			payload.snapshot = snapshotName
		}
		
		def jsonBuilder = new groovy.json.JsonBuilder();
		jsonBuilder payload

		String payloadString = jsonBuilder.toString();
		
		Logger.debug "Payload string for requesting app process is: ${payloadString}"

		def restResponse = (new RestPut( ucdServer )).setPath("/cli/applicationProcessRequest/request")
			.setPayload(payloadString)
			.putAsObject()

		String requestId = restResponse.requestId
		
		Logger.info "Started new Application Process with Request ID of ${requestId}"
		
		String outputStatus = ""
		
		String processStatus = getApplicationProcessStatus(ucdServer, requestId)
		if (waitForProcess) {
			while (!(processStatus.equalsIgnoreCase("CANCELED") || processStatus.equalsIgnoreCase("succeeded") || 
				processStatus.equalsIgnoreCase("faulted") || processStatus.equalsIgnoreCase("FAILED TO START"))) {
				Thread.sleep(3000);
				processStatus = getApplicationProcessStatus( ucdServer, requestId)
			}
			if (processStatus.equalsIgnoreCase("succeeded")) {
				Logger.debug "The application process succeeded"
				outputStatus = "Success"
			} else {
				Logger.debug "The application process failed with message '${p:processStatus}'.  See the application process log for details."
				outputStatus = "Failure"
			}
		} else {
			outputStatus = "Did Not Wait"
		}

		String webAddress = ucdServer.getServerRootUrl() + "/#applicationProcessRequest/${requestId}"
		return [requestId, outputStatus, processStatus, webAddress, requestId]
	}
	
	/**
	 * Call this function for a running application process in order to retrieve the current execution status.
	 * @param requestId The request id of the process
	 * @return Returns a ProcessRequestStatus.
	 */
	@Deprecated
	public static ProcessRequestStatus getApplicationProcessStatusObject( UcdServerConnection ucdServer, String requestId ) {
		return (new ProcessRequestApi(ucdServer)).getApplicationProcessStatusObject(requestId)
	}
	
	/**
	 * Call this function for a running application process in order to retrieve the current execution status.
	 * @param requestId The request id of the process
	 * @return Returns a ProcessRequestStatus.
	 */
	public ProcessRequestStatus getApplicationProcessStatusObject( String requestId ) {
		def responseAsObject = (new RestGet( ucdServer )).setPath("/cli/applicationProcessRequest/requestStatus")
			.addParameter( "request", requestId )
			.getAsObject()
		Logger.debug "getApplicationProcess() object is ${responseAsObject.toString()}"
		
		ProcessRequestStatus processRequestStatus = new ProcessRequestStatus(responseAsObject.status, responseAsObject.result)
		
		// If the result is 'SCHEDULED FOR FUTURE' you have to access the definition of the
		// calendar entry to determine if it is canceled or scheduled
		if (processRequestStatus.isScheduledForFuture()) {
		
			String calendarId = getCalendarIdForApplicationRequestId(ucdServer, requestId)
			def calendarEntity = (new RestGet( ucdServer )).setPath("/rest/calendar/entry/${calendarId}")
				.getAsObject()
				
			// It is canceled if the field 'fired' is true and the nested array 'calendarIds' is empty
			if (calendarEntity.fired && calendarEntity.calendarIds.empty) {
				Logger.debug "This is a scheduled request which has been canceled"
				processRequestStatus.canceledForFuture = true
			} 
		}
		
		return processRequestStatus
	}
	
	/**
	 * Call this function for a running application process in order to retrieve the current execution status.
	 * @param requestId The request id of the process
	 * @return Returns the current status (which is a string value).
	 */
	@Deprecated
	public static String getApplicationProcessStatus( UcdServerConnection ucdServer, String requestId ) {
		return (new ProcessRequestApi(ucdServer)).getApplicationProcessStatus(requestId)
	}
	
	/**
	 * Call this function for a running application process in order to retrieve the current execution status.
	 * @param requestId The request id of the process
	 * @return Returns the current status (which is a string value).
	 */
	public String getApplicationProcessStatus( String requestId ) {
		def statusObject = getApplicationProcessStatusObject(ucdServer, requestId)
		return statusObject.result
	}
	
	/**
	 * Reschedules the scheduled Application Process.  Note that this function does NOT check to see if the
	 * process is still scheduled to run in the future.  You can check the status before calling this if you want.
	 * @param ucdServer Handle to the ucd server
	 * @param requestId The Request ID of the application.
	 * @param scheduleFor The new time to schedule for in the format of 'yyyy-mm-dd hh:mm' based on the UCD Server's timezone.
	 * @param timezone The java Timezone string for the UCD server.
	 * @return Returns the object from the REST call.
	 */
	@Deprecated
	public static def rescheduleApplicationProcess( UcdServerConnection ucdServer, String requestId, String scheduleFor, String timezone ) {
		return (new ProcessRequestApi(ucdServer)).rescheduleApplicationProcess(requestId, scheduleFor, timezone)
	}
	
	/**
	 * Reschedules the scheduled Application Process.  Note that this function does NOT check to see if the
	 * process is still scheduled to run in the future.  You can check the status before calling this if you want.
	 * @param ucdServer Handle to the ucd server
	 * @param requestId The Request ID of the application.
	 * @param scheduleFor The new time to schedule for in the format of 'yyyy-mm-dd hh:mm' based on the UCD Server's timezone.
	 * @param timezone The java Timezone string for the UCD server.
	 * @return Returns the object from the REST call.
	 */
	public def rescheduleApplicationProcess( String requestId, String scheduleFor, String timezone ) {
		
		// Convert the 'scheduleFor' into milliseconds based on the server's timezone
		def timeInMillis = convertDateStringToMillis(scheduleFor, timezone)
		
		// Convert the Application Request ID into a Deployment Request ID
		def calendarId = ProcessRequestApi.getCalendarIdForApplicationRequestId(ucdServer, requestId)
		Logger.debug "Calendar ID = ${calendarId}"
		
		return (new RestGet( ucdServer )).setPath("/rest/deploy/schedule/entry/${calendarId}/moveTo/${timeInMillis}")
			.getAsObject()
	}
	
	/**
	 * Cancels the scheduled Application Process.  Note that this function does NOT check to see if the
	 * process is still scheduled to run in the future.  You can check the status before calling this if you want.
	 * @param ucdServer Handle to the ucd server
	 * @param requestId The Request ID of the application.
	 */
	@Deprecated
	public static void cancelApplicationProcess( UcdServerConnection ucdServer, String requestId ) {
		(new ProcessRequestApi(ucdServer)).cancelApplicationProcess(requestId)
	}
	
	/**
	 * Cancels the scheduled Application Process.  Note that this function does NOT check to see if the
	 * process is still scheduled to run in the future.  You can check the status before calling this if you want.
	 * @param ucdServer Handle to the ucd server
	 * @param requestId The Request ID of the application.
	 */
	public void cancelApplicationProcess( String requestId ) {
		
		// Convert the Application Request ID into a Deployment Request ID
		def calendarId = ProcessRequestApi.getCalendarIdForApplicationRequestId(ucdServer, requestId)
		Logger.debug "Calendar ID = ${calendarId}"
		
		(new RestDelete( ucdServer )).setPath("/rest/calendar/entry/${calendarId}")
			.deleteWithNoReturnObject()
	}

	/**
	 * Convert a date string in the format of 'yyyy-mm-dd HH:mm' into the number of milliseconds based
	 * on the specified timezone.
	 * @param sDate Date string in the format of 'yyyy-mm-dd HH:mm'
	 * @param tz timezone qualifier as per the Java timezone class, such as MST for Mountain Standard Time.
	 * @return The time in milliseconds.
	 */
	public static def convertDateStringToMillis( String sDate, String tz ) {
		// tz is the timezone label, such as CDT or MST
		java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm")
		TimeZone timezone = TimeZone.getTimeZone(tz)
		dateFormat.setTimeZone(timezone)
		Date date = dateFormat.parse(sDate)
		def millis = date.getTime()
		Logger.debug "convertDateStringToMillis( '${sDate}' ) -> ${millis}"
		return millis
	}
	
	/**
	 * Convert a Date into a timezone specific string in the format of 'yyy-mm-dd HH:mm'.
	 * @param date The Date.
	 * @param tz timezone qualifier as per the Java timezone class, such as MST for Mountain Standard Time.
	 */
	public static String convertDateToString( Date date, String tz ) {
		java.text.SimpleDateFormat outputDateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm")
		TimeZone outputTimezone = TimeZone.getTimeZone(tz)
		outputDateFormat.setTimeZone(outputTimezone)
		return outputDateFormat.format(date)
	}
	
	/**
	 * Returns a list of the component versions in the application process request.
	 * @param ucdServer Handle to the server.
	 * @param applicationRequestId The ID of the application process request.
	 * @return List of component versions.  The minimum structure returned for each member in the list
	 * is { id, name, description, type, component: { id, name, description }}
	 */
	@Deprecated
	public static List getComponentVersions( UcdServerConnection ucdServer, String applicationRequestId ) {
		return (new ProcessRequestApi(ucdServer)).getComponentVersions(applicationRequestId)
	}
	
	/**
	 * Returns a list of the component versions in the application process request.
	 * @param applicationRequestId The ID of the application process request.
	 * @return List of component versions.  The minimum structure returned for each member in the list  
	 * is { id, name, description, type, component: { id, name, description }}
	 */
	public List getComponentVersions( String applicationRequestId ) {
		def versionInfo = (new RestGet( ucdServer )).setPath("/rest/deploy/applicationProcessRequest/${applicationRequestId}/versions")
			.getAsObject()
		return versionInfo.versions
	}
}
