package com.ibm.css.rest.ucd.agent

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.agent.Agent
import com.ibm.css.ucd.agent.AgentPool
import com.ibm.issr.rest.RestGet

class AgentPoolApi {
	/**
	 * Returns info about an Agent as per the /cli/agentCLI/info REST API call.
	 * @param ucdServer Handle to the UCD server.
	 * @param agentPoolName The name of the agent pool.
	 * @return The object map.
	 */
	public static def getAgentPoolInfo( UcdServerConnection ucdServer, String agentPoolName ) {
		// The documented '/cli/agentPool/info' step doesn't seem to work.  Get entire list instead
//		return (new RestGet( ucdServer )).setPath("/cli/agentPool/info")
//			.addParameter("pool", agentPoolName)
//			.getAsObject()
		List agentPools = (new RestGet( ucdServer )).setPath("/cli/agentPool")
			.getAsObject()
		Map agentPool = agentPools.find { Map candidateAgentPool ->
			return (candidateAgentPool.name == agentPoolName)
		}
		if (! agentPool) {
			// Not found
			throw new Exception( "Unable to find an Agent Pool named '${agentPoolName}'")
		}
		return agentPool
	}
	
	/**
	 * Does the named agent exist?
	 * @param ucdServer Handle to the UCD server.
	 * @param agentPoolName The name of the agent pool.
	 */
	public static def doesAgentPoolExist( UcdServerConnection ucdServer, String agentPoolName ) {
		// The documented '/cli/agentPool/info' step doesn't seem to work.  Get entire list instead
//		return (new RestGet( ucdServer )).setPath("/cli/agentPool/info")
//			.addParameter("pool", agentPoolName)
//			.getAsExistenceTest()
		List agentPools = (new RestGet( ucdServer )).setPath("/cli/agentPool")
			.getAsObject()
		Map agentPool = agentPools.find { Map candidateAgentPool ->
			return (candidateAgentPool.name == agentPoolName)
		}
		return (agentPool != null)
	}
	
	/**
	 * Returns 'AgentPool' entity class instance for named agent pool.  Throws exception on failure.
	 * @param ucdServer Handle to the UCD server.
	 * @param agentPoolName The name of the agent pool.
	 * @return The entity class.
	 */
	public static AgentPool getAgentPoolEntityFromName( UcdServerConnection ucdServer, String agentPoolName ) {
		return new AgentPool( ucdServer, getAgentPoolInfo( ucdServer, agentPoolName ))
	}

}
