
package com.ibm.css.ucd.applicationtemplate

import groovy.json.JsonOutput

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.application.ApplicationApi
import com.ibm.css.rest.ucd.applicationtemplate.ApplicationTemplateApi
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.common.EntityWithNameAndId
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.environmenttemplate.EnvironmentTemplate
import com.ibm.issr.rest.RestPut

class ApplicationTemplate extends EntityWithNameAndId {
	
	// Handle to ApplicationApi Instance
	ApplicationTemplateApi applicationTemplateApi
	ApplicationApi applicationApi
	
	// Cached application info for this application
	private def _cachedInfo = null

	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 * @param info Optional 'info' for this application returned from the ApplicationTemplateApi.getInfo() function.
	 * If provided, this is used to populate the cached info field.
	 */
	public ApplicationTemplate( UcdServerConnection ucdServer, String name, String id, def info = null ) {
		super( ucdServer, name, id )
		applicationTemplateApi = new ApplicationTemplateApi(ucdServer)
		applicationApi = new ApplicationApi(ucdServer)
		if (info) {
			_cachedInfo = info
		}
	}
	

	/**
	 * Create a new Application for this template based on the 'applicationDefinition'	
	 * @param applicationDefinition Defines information about the new application.
	 * @return The new Application object.
	 */
	public Application createApplication( ApplicationDefinitionForTemplate applicationDefinition ) {
		def payload = [ name: applicationDefinition.name, templateId: this.id ]
		if (applicationDefinition.description) {
			payload.description = applicationDefinition.description
		}
		// TODO - include notification scheme name
//		if (notificationScheme) {
//			payload.notificationScheme = notificationScheme
//		}
		if (applicationDefinition.templateProperties.size() > 0) {
			payload.templateProperties = []
			applicationDefinition.templateProperties.each { Map templateProperty ->
				payload.templateProperties << [ name:templateProperty.name, value:templateProperty.value ]
			}
		}
		List componentIdList = []
		applicationDefinition.components.each { Component component ->
			componentIdList << component.id
		}
		if (componentIdList && componentIdList.size() > 0) {
			payload.existingComponentIds = componentIdList
		}
		def restResults = (new RestPut( ucdServer )).setPath("/cli/application/createApplicationFromTemplate")
			.setPayload(JsonOutput.toJson( payload ))
			.putAsObject()
		String applicationId = restResults.id
		return new Application( ucdServer, applicationDefinition.name, applicationId )
	}
	
	/**
	 * Returns the raw information associated with this entity from the REST
	 * calls.  This information is cached.  Pass with 'resetCache' of true to reset the cache.
	 */
	private def getInfo( boolean resetCache=false ) {
		if (resetCache || (! _cachedInfo)) {
			_cachedInfo = applicationTemplateApi.getInfo( this.id )
		}
		return _cachedInfo
	}

	/**
	 * Returns the List of 'EnvironmentTemplate's for this ApplicationTemplate.
	 * @return A List whose members are of type 'EnvironmentTemplate'.
	 */
	public List getEnvironmentTemplates() {
		List environmentTemplates = []
		def info = this.getInfo()
		info.environmentTemplates.each { templateInfo ->
			environmentTemplates << new EnvironmentTemplate(ucdServer, templateInfo.name, templateInfo.id)
		}
		return environmentTemplates
	}
	
	/**
	 * Does this ApplicationTemplate have an EnvironmentTemplate with the given name.
	 */
	public boolean doesEnvironmentTemplateExist( String name ) {
		List environmentTemplates = getEnvironmentTemplates()
		EnvironmentTemplate environmentTemplate = environmentTemplates.find { EnvironmentTemplate environmentTemplate ->
			return (environmentTemplate.name == name)
		}
		return environmentTemplate
	}
		
	/**
	 * Returns the named Environment template or throws exception. 
	 */
	public EnvironmentTemplate getEnvironmentTemplate( String name ) {
		List environmentTemplates = getEnvironmentTemplates()
		EnvironmentTemplate environmentTemplate = environmentTemplates.find { EnvironmentTemplate environmentTemplate ->
			return (environmentTemplate.name == name)
		}
		if (! environmentTemplate) {
			throw new Exception( "Unable to find an environment template named '" + name + "' in application template '" + this.name + "'" )
		}
		return environmentTemplate
	}
}
