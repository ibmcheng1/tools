package com.fanniemae.ucd.aws.provision.service.definition

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.ucd.aws.provision.service.instance.AwsServiceInstance
import com.fanniemae.ucd.aws.provision.service.instance.RDSServiceInstance
import com.fanniemae.ucd.aws.provision.spec.AwsSpecification
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.services.UcdConnectionServices

/**
 * A specification for an instance of AWS RDS
 * @author Leon Clark
 */
class RDSServiceDefinition extends AwsServiceDefinition {
	public static final String SERVICE_TYPE = 'RDS'
	
	@Override
	public String getServiceType() {
		return SERVICE_TYPE;
	}
	
	@Override
	public boolean shouldProvisionSeparateBlueGreenInstances() {
		return false
	}

	@Override
	protected AwsServiceInstance buildAwsServiceInstance(AwsConnection awsConnection, String provisionedId, boolean newlyProvisioned ) {
		return new RDSServiceInstance( this, awsConnection, provisionedId, newlyProvisioned )
	}

	/**
	 * Constructor.
	 * @param awsSpecification The parent AwsSpecification
	 * @param instanceData This is the parsed block of data from the specification file for one instance.
	 */
	public RDSServiceDefinition( AwsSpecification awsSpecification, Map instanceData ) {
		super( awsSpecification, instanceData )
		defineMemberField( 'name', true ) { String fieldValue -> _name = fieldValue }
		defineMemberField( 'awsName', false ) { String fieldValue -> _awsName = fieldValue }
		defineAwsProperty( 'DatabaseName', true )
		defineAwsProperty( 'DatabaseEngine', true )
		defineAwsProperty( 'DatabaseUser', true )
		validateAndSetMemberFields()
	}
	
	
}
