package com.ibm.services.ucr.api.entity.initiative

import java.util.List;

import com.ibm.issr.core.entity.IndexedListOfEntities
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.framework.UcrEntityData
import com.ibm.services.ucr.api.framework.UcrEntityDataFormat

class UcrInitiativeMgr {
	
	// Map of the singleton instances of this class.  Key=RestServerConnection, value=instance of this class
	private static Map _singletons = [:]
	
	// The server for this instance of the Mgr
	RestServerConnection ucrServer
	
	/**
	 * Cached list of loaded entities.  The data type of the cache is IndexedListOfEntities, which is
	 * automatically initialized when the cache is created or resest.
	 */
	RestDataCache _entityCache = new RestDataCache(
		// Cache entry initialization closure - Initialize cache entries as instances of IndexedListOfEntities
		{ RestServerConnection ucrServer ->
			return new IndexedListOfEntities(
				// This closure returns the 'uniqueName' for each entry, which is simply the id because this class has no name
				{ UcrInitiative entity ->
					return entity.getId()
				}
				)
		}
		)
	
	/**
	 * Private constructor.
	 * @param ucrServer The associated Rest Server.
	 */
	private UcrInitiativeMgr( RestServerConnection ucrServer ) {
		this.ucrServer = ucrServer
	}
	
	/**
	 * Returns the singleton instance of this class for the given Rest Server.
	 */
	public static UcrInitiativeMgr getInstance( RestServerConnection ucrServer ) {
		if (! _singletons.containsKey(ucrServer)) {
			_singletons[ucrServer] = new UcrInitiativeMgr(ucrServer)
		}
		return _singletons[ucrServer]
	}
	
	/**
	 * Given entity data, this returns a UcrInitiative for that data.
	 * @param ucrServer The server.
	 * @param entityData The data returned from some REST call.
	 * @return New or existing entity.
	 */
	public UcrInitiative buildEntity( RestServerConnection ucrServer, UcrEntityData entityData ) {
		UcrInitiative entity
		String name = entityData.getEntityObject().name
		String id = entityData.getEntityObject().id
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			entity = cachedEntities.getEntityById(id)
			// Update the cached entityData
		} else {
			entity = new UcrInitiative( ucrServer, entityData )
			cachedEntities.addEntity(entity)
		}
		return entity
	}
	
	/**
	 * Returns the entity by ID.  Throws exception if not found.
	 */
	public UcrInitiative getById( String id, boolean resetCache=false ) {
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer, resetCache)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			return cachedEntities.getEntityById(id)
		} else {
			// not found in cache - make rest call to load it
			def rawEntityData = (new RestGet( ucrServer ))
					.setPath("/initiatives/${id}")
//					.addParameter('format', 'detail')
					.setHeader('Accept', 'application/json')
					.getAsObject()
			// Convert the raw data into an entity
			return buildEntity( ucrServer, new UcrEntityData(rawEntityData, UcrEntityDataFormat.LIST_FORMAT ))
		}
	}
	
	/**
	 * Returns the list of of type UcrInitiative with all of the initiatives.
	 */
	public List getAll( boolean resetCache = false ) {
		// This list is not cached
		List entityList = []
		List rawEntityList = (new RestGet( ucrServer ))
				.setPath('/initiatives/')
				.setHeader('Accept', 'application/json')
				.getAsObject()
		// convert to entities
		rawEntityList.each { def rawEntity ->
			entityList << buildEntity( ucrServer, new UcrEntityData( rawEntity, UcrEntityDataFormat.LIST_FORMAT ) )
		}
		return entityList
	}
}
