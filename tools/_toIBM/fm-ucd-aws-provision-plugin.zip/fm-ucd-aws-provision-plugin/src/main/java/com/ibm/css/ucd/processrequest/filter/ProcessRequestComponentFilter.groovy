package com.ibm.css.ucd.processrequest.filter

import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.processrequest.ProcessRequest
import com.ibm.css.ucd.processrequest.ProcessRequestApproval
import com.ibm.css.ucd.processrequest.ProcessRequestApprovalDetail

/**
 * Filter Process Request records based on deploying a component (any version).
 * @author ltclark
 *
 */
class ProcessRequestComponentFilter extends ProcessRequestFilter {
	Component component
	
	/**
	 * Constructor.
	 * @param component The component to filter on.
	 */
	public ProcessRequestComponentFilter( Component component ) {
		this.component = component
	}

	@Override
	public Date getFilteringStartedAfter() {
		// There is no date filtering
		return null;
	}
	
	@Override
	public Application getFilteringApplication() {
		// no application to filter on
		return null;
	}

	@Override
	public boolean includeProcessRequestInFilter(ProcessRequest processRequest) {
		boolean retval = false
		processRequest.getComponentVersions().each { ComponentVersion componentVersion ->
			if (componentVersion.component.id == component.id){
				// Found the match!!
				retval = true
			} 
		}
		return retval
	}

	@Override
	public boolean includeRawRecordInFilter(Object rawRecord) {
		// This filter only applies to the processed (object oriented) data and not to the raw data
		return true
	}

	@Override
	public String getDescription() {
		return "Deployed Component named '${component.name}'"
	}

}
