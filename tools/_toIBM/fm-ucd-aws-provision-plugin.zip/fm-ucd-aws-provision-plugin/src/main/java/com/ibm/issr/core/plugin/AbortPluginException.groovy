package com.ibm.issr.core.plugin

/**
 * This exception is thrown by see {@link PluginHelper}.abortPlugin().  The root plugin
 * class should catch this exception type and display the corresponding message.
 * @author ltclark
 *
 */
class AbortPluginException extends Exception {
	/**
	 * Aborts the current plugin via an exception by displaying the exception's message, but NOT displaying the call stack.
	 */
	public AbortPluginException(String msg) {
		super(msg);
	}
}
