package com.fanniemae.aws.api.connection

import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.plugin.AbortPluginException

/**
 * Represents an authenticated connection (with needed data) to an AWS instance.
 * @author s9ulcc
 *
 */
class AwsConnection {
	private String _awsRegion
	private String _awsProfileScript
	
	/**
	 * Constructor.
	 * @param awsRegion The AWS Region, such as 'us-east-1'
	 * @param awsProfileScript A shell script fragment to setup calls to AWS CLI
	 */
	public AwsConnection( String awsRegion, String awsProfileScript ) {
		this._awsRegion = awsRegion
		this._awsProfileScript = awsProfileScript
	}
	
	/**
	 * Initiate an AWS Working Session and authentication.
	 * @param awsPassword AWS Password for the role
	 */
	public void initiateAwsSession( String awsPassword, String awsRole ) {
		CommandRunner commandRunner = executeAwsCliCommand("""pwd
python3 /export/apps/citools/python/Python-3.5.3/usr/local/bin/federate-UCD.py ftxdply ${awsRole} ${awsPassword}
aws sts get-caller-identity""")
		if (! commandRunner.wasSuccessful()) {
			throw new AbortPluginException( "Unable to authenticate against AWS" )
		}
	}
	
	/**
	 * Executes the given AWS CLI script.  The script may be one or multiple lines.  This function
	 * adds all of the appropriate setup commands before the call.
	 * @param cmd The script line(s) to run.
	 * @return The CommandRunner that ran.  Call CommandRunner.wasSuccessful() to determine if the script ran OK.
	 * Call CommandRunner.getConsoleOutput() to get the console output.
	 */
	public CommandRunner executeAwsCliCommand( String cmd ) {
		// Create and execute the script file that calls AWS
		File shellScript = new File('awsScript.ksh')
		shellScript.text = """${getProfileScript()}
""" + cmd 
		shellScript.setExecutable(true)
		
		Logger.debug "**************************************************"
		Logger.debug " Calling AWS CLI script"
		Logger.debug "**************************************************"
		Logger.debug shellScript.text

		CommandRunner commandRunner = new CommandRunner()
		boolean success = commandRunner
			.setVerbose( Logger.displayDebug )
			.setCommand([ "./${shellScript.name}" ])
			.execute()
			.wasSuccessful()
		Logger.debug "Shell successful? " + success
		return commandRunner
	}

	/**
	 * Returns the AWS Region, such as 'us-east-1'
	 */
	public String getRegion() {
		return _awsRegion
	}
	
	/**
	 * Returns the AWS Profile Script, which is a shell script fragment to put at the beginning
	 * of all scripts that call the AWS CLI.
	 */
	public String getProfileScript() {
		return _awsProfileScript
	}
}
