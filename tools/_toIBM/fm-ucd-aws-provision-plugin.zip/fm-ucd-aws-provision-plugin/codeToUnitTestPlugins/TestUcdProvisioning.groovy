import com.fanniemae.ucd.aws.provision.ucd.UcdConfigurationDefinition
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel
import com.ibm.issr.core.plugin.AbortPluginException

class TestUcdProvisioning {
	
	static main(String[] args) {
			
//		Logger.setLoggingLevel "debug"
		
		String ucdServerUrl = "https://ucdeploytest:8443/"
		String token = '52d4e409-415b-431c-9df5-278272a5f4cf'
		String applicationName = 'AWS-FZM'
		String requestedEnvType = 'DEVL'
		String requestedEnvName = 'D5'
		String awsPool = 'AWS-Integration-Servers'
		boolean blueGreen = true
		
		runTest(ucdServerUrl, token, applicationName, blueGreen, requestedEnvName, requestedEnvType, awsPool )

		runTest(ucdServerUrl, token, applicationName, false, requestedEnvName, requestedEnvType, awsPool )

		runTest(ucdServerUrl, token, applicationName, false, 'D99', requestedEnvType, awsPool )
		
		runTest(ucdServerUrl, token, applicationName, true, 'D98', requestedEnvType, awsPool )
		
		}

	private static runTest( String ucdServerUrl, String token, String applicationName, boolean blueGreen, String requestedEnvName, String requestedEnvType,
		String awsPool ) {
		
		try {
			Logger.info " "
			Logger.info "===================================================="
			Logger.info "runTest( application='${applicationName}', blueGreen='${blueGreen}', requestedEnvName='${requestedEnvName}', requestedEnvType='${requestedEnvType}' )"
			
			UcdServerConnection ucdServer = new UcdServerConnection()
			ucdServer.openConnection(ucdServerUrl, token )
			UcdConnectionServices ucdConnectionServices = new UcdConnectionServices(ucdServer)
	
			Application application = ucdConnectionServices.getApplicationServices().getApplication(applicationName)
	
			UcdConfigurationDefinition targetUcdConfigurationBuilder = new UcdConfigurationDefinition( ucdConnectionServices, 
				application, blueGreen, requestedEnvName, requestedEnvType, awsPool )
//			
//			ProvisionImpl provisionImpl = new ProvisionImpl()
//			provisionImpl.checkIfUCDEnvironmentAlreadyExists( targetUcdConfigurationBuilder )
			
			targetUcdConfigurationBuilder.createTargetUcdStructure()
			
		}
		catch (AbortPluginException e) {
			Logger.error "runTest() aborted with message: " + e.getMessage()
			Logger.printStackTrace( LoggerLevel.ERROR, e )
		}
		catch (Exception e) {
			Logger.error "runTest() failed with exception... " + e.getMessage()
			Logger.printStackTrace( LoggerLevel.ERROR, e )
		}

	}

}
