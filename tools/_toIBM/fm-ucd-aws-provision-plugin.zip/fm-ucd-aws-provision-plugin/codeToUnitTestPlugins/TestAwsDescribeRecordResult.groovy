import static org.junit.Assert.*;

import org.junit.Test;

import com.fanniemae.ucd.aws.api.describeRecord.AwsDescribeRecordResult;

public class TestAwsDescribeRecordResult {

	@Test
	public void test() {
		
		AwsDescribeRecordResult result = new AwsDescribeRecordResult(
'''
{
    "RecordDetail": {
        "ProvisionedProductName": "AWS-RDS.2019.11.18.04.50-1",
        "RecordTags": [
            {
                "Key": "ApplicationName",
                "Value": "UrbanCode Deploy on Cloud SANDBOX ONLY"
            },
            {
                "Key": "ProvisioningVersion",
                "Value": "v2"
            },
            {
                "Key": "Lifecycle",
                "Value": "sdbx-sf"
            },
            {
                "Key": "aws:servicecatalog:portfolioArn",
                "Value": "arn:aws:catalog:us-east-1:175626457831:portfolio/port-p3ogxn2dhokcs"
            },
            {
                "Key": "ApplicationShortName",
                "Value": "fvq"
            },
            {
                "Key": "AppCode",
                "Value": "FVQ"
            },
            {
                "Key": "aws:servicecatalog:productArn",
                "Value": "arn:aws:catalog:us-east-1:175626457831:product/prod-b2z72fyekkj3o"
            },
            {
                "Key": "aws:servicecatalog:provisioningPrincipalArn",
                "Value": "arn:aws:sts::175626457831:assumed-role/SDBX-SF-FVQ-SUPPORT/urbancodedeploy_deploymentid@fanniemae.com"
            },
            {
                "Key": "CostCenter",
                "Value": "046"
            },
            {
                "Key": "Environment",
                "Value": "Sandbox-SingleFamily"
            },
            {
                "Key": "AssetID",
                "Value": "MSR01265"
            },
            {
                "Key": "aws:servicecatalog:provisioningArtifactIdentifier",
                "Value": "pa-3u5njcwfw2uj4"
            },
            {
                "Key": "aws:servicecatalog:provisionedProductArn",
                "Value": "arn:aws:servicecatalog:us-east-1:175626457831:stack/AWS-RDS.2019.11.18.04.50-1/pp-dankftroaihpm"
            }
        ],
        "Status": "SUCCEEDED",
        "RecordErrors": [],
        "ProvisionedProductId": "pp-dankftroaihpm",
        "ProductId": "prod-b2z72fyekkj3o",
        "PathId": "lpv2-iujpcr3bioviq",
        "ProvisioningArtifactId": "pa-3u5njcwfw2uj4",
        "RecordId": "rec-e7dyom65abgmq",
        "RecordType": "PROVISION_PRODUCT",
        "UpdatedTime": 1574114891.078,
        "ProvisionedProductType": "CFN_STACK",
        "CreatedTime": 1574113851.604
    },
    "RecordOutputs": [
        {
            "OutputValue": "arn:aws:cloudformation:us-east-1:175626457831:stack/SC-175626457831-pp-dankftroaihpm/7d997530-0a4d-11ea-afb6-0a90b7832da7",
            "Description": "The ARN of the launched Cloudformation Stack",
            "OutputKey": "CloudformationStackARN"
        },
        {
            "OutputValue": "5432",
            "Description": "RDS instance port",
            "OutputKey": "DBInstancePort"
        },
        {
            "OutputValue": "fvq-sdbx-sf-rds-74",
            "Description": "RDS instance identifier",
            "OutputKey": "DBInstanceId"
        },
        {
            "OutputValue": "PostgreSQL10",
            "Description": "RDS engine",
            "OutputKey": "DBEngine"
        },
        {
            "OutputValue": "fvq-sdbx-sf-rds-74.cuzuy40jmh0h.us-east-1.rds.amazonaws.com",
            "Description": "RDS instance endpoint",
            "OutputKey": "DBInstanceEndpoint"
        },
        {
            "OutputValue": "10",
            "Description": "RDS engine version",
            "OutputKey": "DBVersion"
        },
        {
            "OutputValue": "db01",
            "Description": "Database name",
            "OutputKey": "DBName"
        },
        {
            "OutputValue": "edbadm",
            "Description": "Database application user",
            "OutputKey": "DBUser"
        }
    ]
}
''')
		
		assert result.getRecordOutputProperty( 'DBName' ) == 'db01'
		assert result.getRecordOutputProperty( 'unknown' ) == ''
		assert result.getRecordOutputProperty( 'unknown', null ) == null
		//fail("Not yet implemented");
	}

}
