import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.issr.core.log.Logger

import plugin.DeprovisionEnvironmentImpl

class TestDeprovisioningEnvironment {
	
	static main(String[] args) {
			
//		Logger.setLoggingLevel "debug"
		
		String environmentName = 'D99-Test-pair2'
		String applicationName = 'AWS-FZM'

		String ucdServerUrl = "https://ucdeploytest:8443/"
		String token = '52d4e409-415b-431c-9df5-278272a5f4cf'
		String awsProfileScript = '''
#!/bin/ksh
export HOME=${p:resource/work.dir}${p:component.name}/${p:environment/envType}
export PATH=/export/apps/citools/python/Python-3.5.3/usr/local/bin:/usr/bin:\$PATH
export http_proxy=http://zsproxy.fanniemae.com:9480
export https_proxy=http://zsproxy.fanniemae.com:9480
export no_proxy=sts.fanniemae.com
export MALLOC_CHECK_=1
'''
		String awsRegion = 'us-east-1'
		String awsPassword = 'ucAGNT-2'
		String awsRole = 'SDBX-SF-FVQ-SUPPORT'
		
		UcdServerConnection ucdServer = new UcdServerConnection()
		ucdServer.openConnection(ucdServerUrl, token )

		Properties outProps = new Properties()
			
		DeprovisionEnvironmentImpl step = new DeprovisionEnvironmentImpl(ucdServer, outProps, awsProfileScript)
		
		step.enableAwsSimulation()

		step.executeDeprovisioning(awsRegion, awsPassword, awsRole, environmentName, applicationName)
				
		println "*** SUCCESS ***"

	}

}
