import com.fanniemae.ucd.aws.provision.service.definition.AwsServiceDefinition
import com.fanniemae.ucd.aws.provision.service.definition.EBServiceDefinition
import com.fanniemae.ucd.aws.provision.service.definition.RDSServiceDefinition
import com.fanniemae.ucd.aws.provision.service.instance.AwsServiceInstance
import com.ibm.css.rest.ucd.UcdServerConnection

import plugin.ProvisionAWSSpecificationImpl

class TestProvisionAWSSpecificationImpl {
	
	static main(String[] args) {
			
//		Logger.setLoggingLevel "debug"
		
		boolean blueGreen = true
		String requestedEnvName = 'D99-Test'
		String requestedEnvType = 'DEVL'
		String applicationName = 'AWS-FZM'

		String ucdServerUrl = "https://ucdeploytest:8443/"
		String token = '52d4e409-415b-431c-9df5-278272a5f4cf'
		String awsProduductIds = '''
[
	{
		"object": "RDS",
		"prodId": "prod-b2z72fyekkj3o-x"
	}, 
	{
		"object": "RDS",
		"prodId": "prod-b2z72fyekkj3o",
		"environmentType": "DEVL"
	}, 
	{
		"object": "ECS",
		"prodId": "prod-npd4hvnntogme"
	}, {
		"object": "EB",
		"prodId": "prod-6ruu2gdnu6imc"
	}
]
'''
		String tokens = '''
sample=one
second=another
'''
		String existingAwsProductInstances = '''
logicalName=awsProductName
logicalName2.blue=awsProductName2
logicalName3.blue=awsProductName3
'''
		String awsProfileScript = '''
#!/bin/ksh
export HOME=${p:resource/work.dir}${p:component.name}/${p:environment/envType}
export PATH=/export/apps/citools/python/Python-3.5.3/usr/local/bin:/usr/bin:\$PATH
export http_proxy=http://zsproxy.fanniemae.com:9480
export https_proxy=http://zsproxy.fanniemae.com:9480
export no_proxy=sts.fanniemae.com
export MALLOC_CHECK_=1
'''
		String awsSpecification = '''
# awsManifest.json file
{
	"items":
	[
		{
			"name":"rds-resource",
			"serviceType": "RDS",
			"AwsProperties": {
				"DatabaseName": "db09",
				"DatabaseEngine": "PostgreSQL",
				"DatabaseUser": "edbadm"
			}
		}, 
		{
			"name": "sampleEB",
			"serviceType": "EB",
			"AwsProperties": {
				"ApplicationOwnerEMail": "leon_t_clark@fanniemae.com",
				"EnvironmentType": "WebServer",
				"EnvironmentName": "webapp",
				"EnvironmentPlatform": "Java8",
				"AutoScalingMin": "1",
				"AutoScalingMax": "1",
				"InstanceSize": "Small"
			}
		}, 
		{
			"name": "ecsResource",
			"serviceType": "ECS",
			"AwsProperties": {
				"Name": "%(environment.basename)%"
			}
		}
	]
}
'''
		String awsPool = 'tlv-ftx-a003.fanniemae.com'
		String awsRegion = 'us-east-1'
		String awsPassword = 'ucAGNT-2'
		String awsRole = 'SDBX-SF-FVQ-SUPPORT'
		String ucdComponentsDefJson = '''
{
	"ucdComponents":
	[
		{
			"componentName": "AWS-EB",
			"participateInBlueGreen": true,
			"componentEnvironmentProperties":
			{
#				"applicationName": "%(awsResource.sampleEB.prop.ApplicationName)%",
#				"environmentName": "%(awsResource.sampleEB.prop.EnvironmentName)%",
				"fileNames": "%(awsResource.sampleEB.prop.LoadBalancerDnsName)%",
				"provisionedProductName": "ENV: %(environment.name)%, ProvProdName: %(awsResource.sampleEB.prop.ProvisionedProductName)%, ProvVersion: %(awsResource.sampleEB.prop.ProvisioningVersion)%"
			}
		}, 
		{
			"componentName": "AWS-RDS",
			"participateInBlueGreen": false,
			"componentEnvironmentProperties":
			{
				"awsEndpoint": "%(awsResource.rds-resource.DBInstanceEndpoint)%",
				"awsPort": "%(awsResource.rds-resource.DBInstancePort)%",
				"awsInstanceId": "%(awsResource.rds-resource.DBInstanceId)%"
			}
		}, 
		{
			"componentName": "AWS-FZM-ECS",
			"componentEnvironmentProperties":
			{
				"awsLifeCycle": "%(awsResource.ecsResource.Lifecycle)%",
				"clusterName": "%(awsResource.ecsResource.ClusterName)%"
			}
		}
	]
}
'''

		String sampleEbDescribeRecord = '''
{
    "RecordOutputs": [
        {
            "OutputValue": "arn:aws:cloudformation:us-east-1:175626457831:stack/SC-175626457831-pp-e5ac37wyrwue2/c4e7b450-1b7e-11ea-8c19-0e24761bd22a",
            "OutputKey": "CloudformationStackARN",
            "Description": "The ARN of the launched Cloudformation Stack"
        },
        {
            "OutputValue": "internal-fvq-alb-ecs-name03-981441355.us-east-1.elb.amazonaws.com",
            "OutputKey": "LoadBalancerDnsName",
            "Description": "AWS DNS name of LoadBalancer"
        },
        {
            "OutputValue": "arn:aws:elasticloadbalancing:us-east-1:175626457831:listener/app/fvq-alb-ecs-name03/14fe9275a09e1a0d/95f3ded7d1e941ee",
            "OutputKey": "LoadBalancerListener",
            "Description": "Arn of the Listener attached to the Load Balancer"
        },
        {
            "OutputValue": "sdbx-sf",
            "OutputKey": "Lifecycle"
        },
        {
            "OutputValue": "fvq",
            "OutputKey": "ApplicationShortName"
        },
        {
            "OutputValue": "arn:aws:elasticloadbalancing:us-east-1:175626457831:loadbalancer/app/fvq-alb-ecs-name03/14fe9275a09e1a0d",
            "OutputKey": "LoadBalancerArn",
            "Description": "LoadBalancer ARN"
        },
        {
            "OutputValue": "arn:aws:iam::175626457831:role/sdbx-sf-fvq-instance",
            "OutputKey": "FargateInstanceRole",
            "Description": "Instance Role to use for Fargate Instances"
        },
        {
            "OutputValue": "fvq-sdbx-sf-ecs-name03.e003.fanniemae.com",
            "OutputKey": "LoadBalancerCname",
            "Description": "Canonical(Friendly) Name for LoadBalancer"
        },
        {
            "OutputValue": "fvq-sdbx-sf-ecs-name03",
            "OutputKey": "ClusterName",
            "Description": "Name of the provisioned ecs cluster"
        },
        {
            "OutputValue": "sg-0e7778c8eed8b4587",
            "OutputKey": "ServiceSecurityGroupName",
            "Description": "ServiceSecurityGroup to use in Service Definitions"
        },
        {
            "OutputValue": "arn:aws:elasticloadbalancing:us-east-1:175626457831:targetgroup/fvq-ecs-name03/0ef0b21c33264e95",
            "OutputKey": "TargetGroupArn",
            "Description": "TargetGroup ARN required for the ECS Service Definition"
        },
        {
            "OutputValue": "subnet-6996a70d,subnet-e8c785c7",
            "OutputKey": "EcsServiceSubnets",
            "Description": "Subnets Allocated for Service to Define for Fargate"
        }
    ],
    "RecordDetail": {
        "ProvisioningArtifactId": "pa-ohaxc3jpo3djm",
        "ProvisionedProductType": "CFN_STACK",
        "RecordId": "rec-efxcsjzo6yzuo",
        "CreatedTime": 1576004186.197,
        "RecordErrors": [],
        "RecordType": "PROVISION_PRODUCT",
        "ProvisionedProductName": "ecsResource-2019.12.10.01.56-1",
        "UpdatedTime": 1576004588.348,
        "PathId": "lpv2-zmx2s6hqwerny",
        "RecordTags": [
            {
                "Key": "ApplicationName",
                "Value": "UrbanCode Deploy on Cloud SANDBOX ONLY"
            },
            {
                "Key": "ProvisioningVersion",
                "Value": "v2"
            },
            {
                "Key": "Lifecycle",
                "Value": "sdbx-sf"
            },
            {
                "Key": "aws:servicecatalog:portfolioArn",
                "Value": "arn:aws:catalog:us-east-1:175626457831:portfolio/port-p3ogxn2dhokcs"
            },
            {
                "Key": "ApplicationShortName",
                "Value": "fvq"
            },
            {
                "Key": "AppCode",
                "Value": "FVQ"
            },
            {
                "Key": "aws:servicecatalog:productArn",
                "Value": "arn:aws:catalog:us-east-1:175626457831:product/prod-npd4hvnntogme"
            },
            {
                "Key": "aws:servicecatalog:provisioningPrincipalArn",
                "Value": "arn:aws:sts::175626457831:assumed-role/SDBX-SF-FVQ-SUPPORT/urbancodedeploy_deploymentid@fanniemae.com"
            },
            {
                "Key": "CostCenter",
                "Value": "046"
            },
            {
                "Key": "Environment",
                "Value": "Sandbox-SingleFamily"
            },
            {
                "Key": "AssetID",
                "Value": "MSR01265"
            },
            {
                "Key": "aws:servicecatalog:provisioningArtifactIdentifier",
                "Value": "pa-ohaxc3jpo3djm"
            },
            {
                "Key": "aws:servicecatalog:provisionedProductArn",
                "Value": "arn:aws:servicecatalog:us-east-1:175626457831:stack/ecsResource-2019.12.10.01.56-1/pp-e5ac37wyrwue2"
            }
        ],
        "ProvisionedProductId": "pp-e5ac37wyrwue2",
        "ProductId": "prod-npd4hvnntogme",
        "Status": "SUCCEEDED"
    }
}
'''
		String sampleRdsDescribeRecord = '''
{
    "RecordDetail": {
        "RecordTags": [
            {
                "Value": "UrbanCode Deploy on Cloud SANDBOX ONLY",
                "Key": "ApplicationName"
            },
            {
                "Value": "v2",
                "Key": "ProvisioningVersion"
            },
            {
                "Value": "sdbx-sf",
                "Key": "Lifecycle"
            },
            {
                "Value": "arn:aws:catalog:us-east-1:175626457831:portfolio/port-p3ogxn2dhokcs",
                "Key": "aws:servicecatalog:portfolioArn"
            },
            {
                "Value": "fvq",
                "Key": "ApplicationShortName"
            },
            {
                "Value": "FVQ",
                "Key": "AppCode"
            },
            {
                "Value": "arn:aws:catalog:us-east-1:175626457831:product/prod-b2z72fyekkj3o",
                "Key": "aws:servicecatalog:productArn"
            },
            {
                "Value": "arn:aws:sts::175626457831:assumed-role/SDBX-SF-FVQ-SUPPORT/urbancodedeploy_deploymentid@fanniemae.com",
                "Key": "aws:servicecatalog:provisioningPrincipalArn"
            },
            {
                "Value": "046",
                "Key": "CostCenter"
            },
            {
                "Value": "Sandbox-SingleFamily",
                "Key": "Environment"
            },
            {
                "Value": "MSR01265",
                "Key": "AssetID"
            },
            {
                "Value": "pa-3u5njcwfw2uj4",
                "Key": "aws:servicecatalog:provisioningArtifactIdentifier"
            },
            {
                "Value": "arn:aws:servicecatalog:us-east-1:175626457831:stack/rds-resource-2019.12.10.08.21-1/pp-lkyfgpgkm5cj4",
                "Key": "aws:servicecatalog:provisionedProductArn"
            }
        ],
        "ProvisionedProductId": "pp-lkyfgpgkm5cj4",
        "PathId": "lpv2-iujpcr3bioviq",
        "ProductId": "prod-b2z72fyekkj3o",
        "UpdatedTime": 1576028332.825,
        "RecordType": "PROVISION_PRODUCT",
        "CreatedTime": 1576027288.484,
        "RecordId": "rec-ons3h7gq6qxhm",
        "ProvisionedProductName": "rds-resource-2019.12.10.08.21-1",
        "Status": "SUCCEEDED",
        "RecordErrors": [],
        "ProvisionedProductType": "CFN_STACK",
        "ProvisioningArtifactId": "pa-3u5njcwfw2uj4"
    },
    "RecordOutputs": [
        {
            "OutputKey": "CloudformationStackARN",
            "Description": "The ARN of the launched Cloudformation Stack",
            "OutputValue": "arn:aws:cloudformation:us-east-1:175626457831:stack/SC-175626457831-pp-lkyfgpgkm5cj4/8eed21b0-1bb4-11ea-8184-1253d15d20e2"
        },
        {
            "OutputKey": "DBName",
            "Description": "Database name",
            "OutputValue": "db09"
        },
        {
            "OutputKey": "DBInstancePort",
            "Description": "RDS instance port",
            "OutputValue": "5432"
        },
        {
            "OutputKey": "DBInstanceId",
            "Description": "RDS instance identifier",
            "OutputValue": "fvq-sdbx-sf-rds-100"
        },
        {
            "OutputKey": "DBUser",
            "Description": "Database application user",
            "OutputValue": "edbadm"
        },
        {
            "OutputKey": "DBVersion",
            "Description": "RDS engine version",
            "OutputValue": "10"
        },
        {
            "OutputKey": "DBEngine",
            "Description": "RDS engine",
            "OutputValue": "PostgreSQL10"
        },
        {
            "OutputKey": "DBInstanceEndpoint",
            "Description": "RDS instance endpoint",
            "OutputValue": "fvq-sdbx-sf-rds-100.cuzuy40jmh0h.us-east-1.rds.amazonaws.com"
        }
    ]
}
'''		
		String sampleEcsDescribeRecord = '''
'''		
		
		UcdServerConnection ucdServer = new UcdServerConnection()
		ucdServer.openConnection(ucdServerUrl, token )

		Properties outProps = new Properties()
			
		ProvisionAWSSpecificationImpl step = new ProvisionAWSSpecificationImpl( ucdServer, outProps, awsProduductIds, awsProfileScript )
			
		step.setSimulationData { AwsServiceDefinition serviceDefinition ->
			if (serviceDefinition instanceof EBServiceDefinition) {
				AwsServiceInstance serviceInstance = serviceDefinition.provisionByLinkingToExistingAwsProductInstance( null, 'rec-efxcsjzo6yzuo' )
				serviceInstance.setProvisionedName('sampleProvisionedName')
				serviceInstance.setDescribeRecordJson( sampleEbDescribeRecord )
				return serviceInstance
			} else if (serviceDefinition instanceof RDSServiceDefinition) {
				AwsServiceInstance serviceInstance = serviceDefinition.provisionByLinkingToExistingAwsProductInstance( null, 'rec-efxcsjzo6yzuo' )
				serviceInstance.setProvisionedName('sampleProvisionedName2')
				serviceInstance.setDescribeRecordJson( sampleRdsDescribeRecord )
				return serviceInstance
			}
		}
		
		step.executeProvisioning(blueGreen, awsSpecification, awsPool, awsRegion, awsPassword, awsRole, 
			requestedEnvName, requestedEnvType, applicationName, ucdComponentsDefJson, true, tokens, existingAwsProductInstances )
		println "*** SUCCESS ***"

	}

}
