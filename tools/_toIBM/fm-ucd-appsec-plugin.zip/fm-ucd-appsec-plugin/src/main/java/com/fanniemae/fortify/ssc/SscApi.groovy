package com.fanniemae.fortify.ssc

import com.ibm.issr.core.plugin.AbortPluginException
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPost
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.RestServerConnectionBuilder

/**
 * Wrapper functions around the Fortify SSC REST API.
 * @author s9ulcc
 *
 */


class SscApi {
    private RestServerConnection sscServer
    private String authToken

    // Cached data
    // The projectListCache is a simple cache of all of the projects
    private Map projectListCache = null
    // The dashboardVersionsListCache is indexed by application/version ID.  The value is the version list
    // for that app/project/version
    private Map dashboardVersionsListCache = [:]
    // The versionsByProjectCache is indexed by application/project ID.  The value is the version list
    // for that app/project
    private Map versionsByProjectCache = [:]
    // The artifactsByProjectCache is indexed by application/project ID/version ID.  The value is the artifact list
    // for that app/project/version
    private Map artifactsByProjectCache = [:]
    // The issuesByProjectCache is indexed by application/project ID/version ID.  The value is the issue list
    // for that app/project/version
    private Map issuesByProjectCache = [:]

    /**
     * Constructor.
     * @param serverUrl The ssc server URL, such as 'https://pwv-e4t-a01:8443/ssc'
     * @param authToken An SSC Authentication token.
     */
    public SscApi(String serverUrl, String authToken) {
        this.authToken = authToken
        sscServer = (new RestServerConnectionBuilder())
                .setServerUrl(serverUrl)
                .setTrustAllCerts()
                .openConnection()
    }

    /**
     * Constructor.
     * @param serverUrl The ssc server URL, such as 'https://pwv-e4t-a01:8443/ssc'
     */
    public SscApi(String serverUrl, String username, String password) {

        // Use Username/password to generate a 24 hour API Token

        RestServerConnection server = (new RestServerConnectionBuilder())
                .setServerUrl(serverUrl)
                .setAuthentication(username, password)
                .setTrustAllCerts()
                .openConnection()
        Map restPayload = ['description': 'DevOps', 'type': "UnifiedLoginToken"]
        Map results = (new RestPost(server))
                .setPath('/api/v1/tokens')
                .setJsonPayloadToObject(restPayload)
                .setHeader('Accept', 'application/json')
                .setHeader('Content-Type', 'application/json')
                .postAsObject()

        // Use the 24 hour API token for everything else
        this.authToken = results.data.token
        sscServer = (new RestServerConnectionBuilder())
                .setServerUrl(serverUrl)
                .setTrustAllCerts()
                .openConnection()
    }

    /**
     * <p>Gets the list of SSC Projects/Applications.  Specifically, this returns an Object version
     * of the JSON returned by the SSC 'application/json' call.  This is an example return
     * value (as JSON):</p>
     * <pre>
     *{* 		"data": [{* 				"_href": "https://pwv-e4t-a01:8443/ssc/api/v1/projects/702",
     * 				"createdBy": "s6uahn",
     * 				"name": "EDL_EDW",
     * 				"description": "",
     * 				"id": 702,
     * 				"creationDate": "2019-02-08T17:57:20.533+0000",
     * 				"issueTemplateId": "8da4cca1-6812-43e5-ac00-5c9a0b016ed2"
     *}, {* 				"_href": "https://pwv-e4t-a01:8443/ssc/api/v1/projects/710",
     * 				"createdBy": "s6uahn",
     * 				"name": "FZM",
     * 				"description": "",
     * 				"id": 710,
     * 				"creationDate": "2019-02-28T16:12:24.147+0000",
     * 				"issueTemplateId": "8da4cca1-6812-43e5-ac00-5c9a0b016ed2"
     *}* 		],
     * 		"count": 2,
     * 		"responseCode": 200,
     * 		"links": {* 			"last": {* 				"href": "https://pwv-e4t-a01:8443/ssc/api/v1/projects?start=0"
     *},
     * 			"first": {* 				"href": "https://pwv-e4t-a01:8443/ssc/api/v1/projects?start=0"
     *}*}*}* </pre>
     * @param resetCache If true, then forces a reload of the list, otherwise, the list may be cached.
     * @return Map version of the SSC Json string (as illustrated above)
     */
    public Map getProjects(boolean resetCache = false) {
        if ((!projectListCache) || resetCache) {
            projectListCache = (new RestGet(sscServer))
                    .setPath('/api/v1/projects')
                    .addParameter("start", "0")
                    .addParameter("limit", "0")
                    .setHeader('Accept', 'application/json')
                    .setHeader('Authorization', "FortifyToken ${authToken}")
                    .getAsObject()
        }
        return projectListCache
    }

    public int getProjectId(String sscApplicationName, boolean resetCache = false) {
        Map projects = getProjects(resetCache)
        int projectId = -1
        projects.data.each { Map projectData ->
            if (projectData.name == sscApplicationName) {
                projectId = projectData.id
            }
        }
        if (projectId == -1) {
            throw new AbortPluginException("Unable to find an SSC Server Application/Project named '${sscApplicationName}'")
        }

        return projectId
    }

/*
    * < p >
    Gets the
    list of
    SSC Versions
    for a Project.Specifically, this returns an
    Object version
    * of the
    JSON returned
    by the SSC 'application/json'
    call.This is
    an example return
    * value ( as JSON ): < / p>
	 * <pre>
	 * {
	 *	"data": [{
	 *			"latestScanId": null,
	 *			"serverVersion": 17.1,
	 *			"tracesOutOfDate": false,
	 *			"attachmentsOutOfDate": false,
	 *			"description": "",
	 *			"project": {
	 *				"id": 710,
	 *				"name": "FZM",
	 *				"description": "",
	 *				"creationDate": "2019-02-28T16:12:24.147+0000",
	 *				"createdBy": "s6uahn",
	 *				"issueTemplateId": "8da4cca1-6812-43e5-ac00-5c9a0b016ed2"
	 *			},
	 *			"sourceBasePath": null,
	 *			"mode": "BASIC",
	 *			"masterAttrGuid": "87f2364f-dcd4-49e6-861d-f8d3f351686b",
	 *			"obfuscatedId": null,
	 *			"id": 10822,
	 *			"customTagValuesAutoApply": null,
	 *			"issueTemplateId": "8da4cca1-6812-43e5-ac00-5c9a0b016ed2",
	 *			"loadProperties": null,
	 *			"predictionPolicy": null,
	 *			"bugTrackerPluginId": null,
	 *			"owner": "s6uahn",
	 *			"_href": "https: / / pwv - e4t - a01: 8443 / ssc / api / v1 / projectVersions / 10822 " ,
    * "committed": true,
    * "bugTrackerEnabled": false,
    * "active": true,
    * "snapshotOutOfDate": false,
    * "issueTemplateModifiedTime": 1559064033685,
    * "securityGroup": null,
    * "creationDate": "2019-02-28T16:12:24.160+0000",
    * "refreshRequired": false,
    * "issueTemplateName": "Fannie Mae Template v2",
    * "migrationVersion": null,
    * "createdBy": "s6uahn",
    * "name": "MSR01617",
    * "siteId": null,
    * "staleIssueTemplate": false,
    * "autoPredict": null,
    * "currentState": {
        * "id": 10822,
        * "committed": true,
        * "attentionRequired": false,
        * "analysisResultsExist": true,
        * "auditEnabled": true,
        * "lastFprUploadDate": "2019-10-18T19:19:32.430+0000",
        * "extraMessage": null,
        * "analysisUploadEnabled": true,
        * "batchBugSubmissionExists": false,
        * "hasCustomIssues": false,
        * "metricEvaluationDate": "2019-10-18T19:19:35.330+0000",
        * "deltaPeriod": 7,
        * "issueCountDelta": -2,
        * "percentAuditedDelta": 0.0,
        * "criticalPriorityIssueCountDelta": -2,
        * "percentCriticalPriorityIssuesAuditedDelta": 0.0
        *
    },
    * "assignedIssuesCount": 0,
    * "status": null
    *
}

, {
    * "latestScanId": null,
    * "serverVersion": 17.1,
    * "tracesOutOfDate": false,
    * "attachmentsOutOfDate": false,
    * "description": "",
    * "project": {
        * "id": 710,
        * "name": "FZM",
        * "description": "",
        * "creationDate": "2019-02-28T16:12:24.147+0000",
        * "createdBy": "s6uahn",
        * "issueTemplateId": "8da4cca1-6812-43e5-ac00-5c9a0b016ed2"
        *
    },
    * "sourceBasePath": null,
    * "mode": "BASIC",
    * "masterAttrGuid": "87f2364f-dcd4-49e6-861d-f8d3f351686b",
    * "obfuscatedId": null,
    * "id": 10824,
    * "customTagValuesAutoApply": null,
    * "issueTemplateId": "8da4cca1-6812-43e5-ac00-5c9a0b016ed2",
    * "loadProperties": null,
    * "predictionPolicy": null,
    * "bugTrackerPluginId": null,
    * "owner": "s6uahn",
    * "_href": "https://pwv-e4t-a01:8443/ssc/api/v1/projectVersions/10824",
    * "committed": true,
    * "bugTrackerEnabled": false,
    * "active": true,
    * "snapshotOutOfDate": false,
    * "issueTemplateModifiedTime": 1559064033685,
    * "securityGroup": null,
    * "creationDate": "2019-03-04T20:13:49.047+0000",
    * "refreshRequired": false,
    * "issueTemplateName": "Fannie Mae Template v2",
    * "migrationVersion": null,
    * "createdBy": "s6uahn",
    * "name": "MSR01617_Client",
    * "siteId": null,
    * "staleIssueTemplate": false,
    * "autoPredict": null,
    * "currentState": {
        * "id": 10824,
        * "committed": true,
        * "attentionRequired": false,
        * "analysisResultsExist": true,
        * "auditEnabled": true,
        * "lastFprUploadDate": "2019-10-22T21:42:39.693+0000",
        * "extraMessage": null,
        * "analysisUploadEnabled": true,
        * "batchBugSubmissionExists": false,
        * "hasCustomIssues": false,
        * "metricEvaluationDate": "2019-10-22T21:42:42.860+0000",
        * "deltaPeriod": 7,
        * "issueCountDelta": 0,
        * "percentAuditedDelta": 0.0,
        * "criticalPriorityIssueCountDelta": 0,
        * "percentCriticalPriorityIssuesAuditedDelta": 0.0
        *
    },
    * "assignedIssuesCount": 0,
    * "status": null
    *
}
* ] ,
* "count" : 2 ,
* "responseCode" : 200 ,
* "links" : {
    * "last": {
        * "href": "https://pwv-e4t-a01:8443/ssc/api/v1/projects/710/versions?start=0"
        *
    },
    * "first": {
        * "href": "https://pwv-e4t-a01:8443/ssc/api/v1/projects/710/versions?start=0"
        *
    }
    *
}
* }
* < /pre>
	 * @param resetCache If true, then forces a reload of the list, otherwise, the list may be cached.
	 * @return Map version of the SSC Json string (as illustrated above)
	 */

    public Map getVersions(int projectId, boolean resetCache = false) {
        if ((!versionsByProjectCache.containsKey(projectId)) || resetCache) {
            versionsByProjectCache[projectId] = (new RestGet(sscServer))
                    .setPath("/api/v1/projects/${projectId}/versions")
                    .addParameter("start", "0")
                    .addParameter("limit", "0")
                    .setHeader('Accept', 'application/json')
                    .setHeader('Authorization', "FortifyToken ${authToken}")
                    .getAsObject()
        }
        return versionsByProjectCache[projectId]
    }

    public int getVersionId(int projectId, String versionName, boolean resetCache = false) {
        Map versions = getVersions(projectId, resetCache)
        int versionId = -1
        versions.data.each { Map versionData ->
            if (versionData.name == versionName) {
                versionId = versionData.id
            }
        }
        if (versionId == -1) {
            throw new AbortPluginException("Unable to find version named '${versionName}'")
        }

        return versionId
    }

    public Map getDashboardVersions(boolean resetCache = false) {
        if ((!dashboardVersionsListCache) || resetCache) {
            dashboardVersionsListCache = (new RestGet(sscServer))
                    .setPath('/api/v1/dashboardVersions')
                    .addParameter("start", "0")
                    .addParameter("limit", "0")
                    .setHeader('Accept', 'application/json')
                    .setHeader('Authorization', "FortifyToken ${authToken}")
                    .getAsObject()
        }
        return dashboardVersionsListCache
    }

    public int getVersionIdFromDashboardVersions(String projectName, String versionName, boolean resetCache = false) {
        Map versions = getDashboardVersions(resetCache)
        int versionId = -1
        versions.data.each { Map versionData ->
            if ((versionData.projectName == projectName) && (versionData.versionName == versionName)) {
                versionId = versionData.id
            }
        }
        if (versionId == -1) {
            throw new AbortPluginException("Unable to find version for SSC Server Application/Project named '${projectName}'")
        }

        return versionId
    }
/*
	{
		"data": [{
				"artifactType": "FPR",
				"fileName": "503665e6786c41dcb4629da825a89322.tmp",
				"approvalDate": null,
				"messageCount": 0,
				"scanErrorsCount": 0,
				"uploadIP": "10.215.45.245",
				"allowApprove": false,
				"allowPurge": false,
				"lastScanDate": "2019-10-22T17:32:00.000+0000",
				"fileURL": null,
				"id": 6918,
				"purged": false,
				"webInspectStatus": "NONE",
				"inModifyingStatus": false,
				"originalFileName": "MSR01617.fpr",
				"allowDelete": true,
				"_href": "https://awv-e4t-a007:8443/ssc/api/v1/artifacts/6918",
				"scaStatus": "IGNORED",
				"indexed": true,
				"runtimeStatus": "NONE",
				"userName": "s6uahn",
				"versionNumber": null,
				"otherStatus": "NOT_EXIST",
				"uploadDate": "2019-10-22T17:32:45.833+0000",
				"approvalComment": null,
				"approvalUsername": null,
				"fileSize": 879758,
				"messages": "",
				"auditUpdated": false,
				"status": "PROCESS_COMPLETE"
			}
		],
		"count": 24,
		"responseCode": 200,
		"links": {
			"next": {
				"href": "https://awv-e4t-a007:8443/ssc/api/v1/projectVersions/10546/artifacts?limit=1&start=1"
			},
			"last": {
				"href": "https://awv-e4t-a007:8443/ssc/api/v1/projectVersions/10546/artifacts?limit=1&start=23"
			},
			"first": {
				"href": "https://awv-e4t-a007:8443/ssc/api/v1/projectVersions/10546/artifacts?limit=1&start=0"
			}
		}
	}
*/

    public Map getArtifacts(int versionId, boolean resetCache = false) {
        if ((!artifactsByProjectCache.containsKey(versionId)) || resetCache) {
            artifactsByProjectCache[versionId] = (new RestGet(sscServer))
                    .setPath("/api/v1/projectVersions/${versionId}/artifacts")
                    .addParameter("start", "0")
                    .addParameter("limit", "1")
                    .setHeader('Accept', 'application/json')
                    .setHeader('Authorization', "FortifyToken ${authToken}")
                    .getAsObject()
        }
        return artifactsByProjectCache[versionId]
    }
/*	{
		"data": [{
				"bugURL": null,
				"hidden": false,
				"issueName": "Cross-Site Scripting: Reflected",
				"folderGuid": "54362046-6cd7-4d09-84db-50958b560180",
				"lastScanId": 1857,
				"engineType": "SCA",
				"issueStatus": "Unreviewed",
				"friority": "Critical",
				"analyzer": "Data Flow",
				"primaryLocation": "AQEServlet.java",
				"reviewed": null,
				"id": 2982818,
				"suppressed": false,
				"hasAttachments": false,
				"engineCategory": "STATIC",
				"projectVersionName": null,
				"removedDate": null,
				"severity": 4.0,
				"_href": "https://awv-e4t-a007:8443/ssc/api/v1/projectVersions/10542/issues/2982818",
				"displayEngineType": "SCA",
				"foundDate": "2018-08-24T19:41:46.000+0000",
				"confidence": 5.0,
				"impact": 5.0,
				"primaryRuleGuid": "798E4513-03B3-4252-A644-FBA596AEFB2B",
				"projectVersionId": 10542,
				"scanStatus": "NEW",
				"audited": false,
				"kingdom": "Input Validation and Representation",
				"folderId": 3211,
				"revision": 0,
				"likelihood": 5.0,
				"removed": false,
				"issueInstanceId": "07947DCA280749CE718B56FB5D973AB8",
				"hasCorrelatedIssues": false,
				"primaryTag": null,
				"lineNumber": 188,
				"projectName": null,
				"fullFileName": "fmll_build/src/main/java/com/fanniemae/aqe/service/AQEServlet.java",
				"primaryTagValueAutoApplied": false
			}
		],
		"count": 3,
		"responseCode": 200,
		"links": {
			"last": {
				"href": "https://awv-e4t-a007:8443/ssc/api/v1/projectVersions/10542/issues?start=0"
			},
			"first": {
				"href": "https://awv-e4t-a007:8443/ssc/api/v1/projectVersions/10542/issues?start=0"
			}
		}
	}
*/

    public Map getIssues(int versionId, boolean resetCache = false) {
        if ((!issuesByProjectCache.containsKey(versionId)) || resetCache) {
            issuesByProjectCache[versionId] = (new RestGet(sscServer))
                    .setPath("/api/v1/projectVersions/${versionId}/issues")
            //				.addParameter("start", "0")
            //				.addParameter("limit", "1")
                    .setHeader('Accept', 'application/json')
                    .setHeader('Authorization', "FortifyToken ${authToken}")
                    .getAsObject()
        }
        return issuesByProjectCache[versionId]
    }

}
