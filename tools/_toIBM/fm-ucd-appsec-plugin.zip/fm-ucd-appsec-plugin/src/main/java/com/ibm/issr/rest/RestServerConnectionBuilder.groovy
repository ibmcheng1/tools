package com.ibm.issr.rest

import org.apache.http.client.HttpClient
import org.apache.http.client.params.HttpClientParams

import com.ibm.issr.core.log.Logger
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder

/**
 * Class which builds/opens a generic REST server connection.
 * @author LeonClark
 *
 */
class RestServerConnectionBuilder {
	private String serverUrl
	String proxyHost
	String proxyPort
	String proxyUsername
	String proxyPassword
	String username
	String password
	boolean trustAllCerts = false
	
	/**
	 * Sets the URL to the server context, such as "https://server:2134/" or
	 * "http://server.domain/appContext".  It should be context root of the server.
	 * @return The handle to this builder.  This allows for cascading calls, such as builder.setAuthentication(...).setServerUrl(...)...
	 */
	public RestServerConnectionBuilder setServerUrl( String serverUrl ) {
		this.serverUrl = serverUrl
		return this
	}
	
	/**
	 * Sets server proxy information.
	 * @param proxyHost Proxy host.  Pass null or an empty string if there is no proxy host.  If a proxy host
	 * is provided, then a proxy port must also be supplied.
	 * @param proxyPort Proxy port.  Pass null or an empty string if no proxy port.  This is actually an integer value.
	 * @param proxyUsername Optional username to use for the proxy port.
	 * @param proxyPassword Optional password to use for the proxy port.
	 * @return The handle to this builder.  This allows for cascading calls, such as builder.setAuthentication(...).setServerUrl(...)...
	 */
	public RestServerConnectionBuilder setProxyInformation( String proxyHost, String proxyPort, String proxyUsername=null, String proxyPassword=null ) {
		this.proxyHost = proxyHost
		this.proxyPort = proxyPort
		this.proxyUsername = proxyUsername
		this.proxyPassword = proxyPassword
		return this
	}
	
	/**
	 * Sets the authentication user name and password to use for the connection.
	 * @param username User name to use for authentication
	 * @param password Password to use for authentication
	 * @return The handle to this builder.  This allows for cascading calls, such as builder.setAuthentication(...).setServerUrl(...)...
	 */
	public RestServerConnectionBuilder setAuthentication( String username, String password ) {
		this.username = username
		this.password = password
		return this
	}
	
	/**
	 * Sets authentication for an Urbancode server token.  This should only be used if the target
	 * server is an Urbancode Release or Deploy server.
	 * @param token The token
	 * @return The handle to this builder.  This allows for cascading calls, such as builder.setAuthentication(...).setServerUrl(...)...
	 */
	public RestServerConnectionBuilder setUrbancodeTokenAuthentication( String token ) {
		setAuthentication( "PasswordIsAuthToken", "{\"token\": \""+token+"\"}")
		return this
	}
	
	/**
	 * Should all certificates (including invalid ones) be trusted?
	 * @return The handle to this builder.  This allows for cascading calls, such as builder.setAuthentication(...).setServerUrl(...)...
	 */
	public RestServerConnectionBuilder setTrustAllCerts( boolean trustAllCerts = true ) {
		this.trustAllCerts = trustAllCerts
		return this
	}
	
	/**
	 * Protected function that should only be called from the various open...Connection() methods.
	 * This standardizes the server url and opens an HTTP connection
	 * @return Returns a List - first element is String serverRootUrl.  Second element is HttpClient.  Sample code:
	 * <pre>
	 * String serverRootUrl
	 * HttpClient httpClient
	 * (serverRootUrl, httpClient) = _openHttpConnection()
	 * return new RestServerConnection( httpClient, serverRootUrl )
	 * </pre>
	 */
	protected List _openHttpConnection() {
		Logger.debug "RestServerConnectionBuilder.openConnection( '${serverUrl}', '${username}', '*****' )"
		
		// clean up parameters
		String serverRootUrl = serverUrl

		// Create HttpBuilder
		HttpClientBuilder builder = new HttpClientBuilder();
		builder.setTrustAllCerts(trustAllCerts)
		
		// Set proxy information
		if (proxyHost && proxyPort) {
			Logger.debug "Setting proxy to REST host"
			builder.setProxyHost(proxyHost)
			builder.setProxyPort(proxyPort.toInteger())
			if (proxyUsername) {
				Logger.debug "Setting proxy username to " + proxyUsername
				builder.setProxyUsername(proxyUsername)
				if (proxyPassword) {
					builder.setProxyPassword(proxyPassword)
				}
			}
		}
		
		if (username) {
			builder.setUsername(username)
			if (password) {
				builder.setPassword(password)
			}
			builder.setPreemptiveAuthentication(true)
		}
		
		HttpClient httpClient = builder.buildClient()
		
		return [ serverRootUrl, httpClient ]
	}
	
	/**
	 * Opens a connection to a REST server based on the various builder function calls (such as builder.setAuthentication()) that
	 * have already been made.  For example: RestServerConnection serverConnection = 
	 * (new ResetServerConnectionBuilder).setServerUrl(serverUrl).setAuthentication(username,password).setTrustAllCerts(true).openConnection()
	 * @return Returns the RestServerConnection or throws exception on error.
	 */
	public RestServerConnection openConnection() {
		String serverRootUrl
		HttpClient httpClient
		(serverRootUrl,httpClient) = _openHttpConnection()
//		HttpClientParams.setRedirecting(httpClient.getParams(), false)
		return new RestServerConnection( httpClient, serverRootUrl )
	} 
}
