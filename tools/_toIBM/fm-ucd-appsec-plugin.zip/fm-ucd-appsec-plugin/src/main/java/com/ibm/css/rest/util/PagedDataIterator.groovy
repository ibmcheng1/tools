package com.ibm.css.rest.util

/**
 * Helper class for iterating through REST calls that return paged data.
 * @author ltclark
 *
 */
class PagedDataIterator {
	/**
	 * Iterates through the pages of data calling a callback function for each record.
	 * @param pageSize The number of records in a page.
	 * @param recordCallback This closure is called for each iterated record.  The closure
	 * has no return value.  It takes one parameter, which is an Object version of the record (converted
	 * from json).
	 * @param getPage Retrieve a page of the data.  The syntax is "List getPage( int pageSize, long pageNumber )".
	 * It returns a List of the returned records for the page.  The 'pageNumber' is 1-based (first page is 1).
	 * If this returns less than a full page worth of records, then the iteration terminates.  The 'pageSize' will
	 * either be the original 'pageSize' given to this function or 1.  1 is used for searching for records.
	 */
	public static void iteratePagedData( int pageSize, Closure recordCallback, Closure getPage ) {
		long pageNumber = 0
		while (true) {
			++pageNumber
			List nextRecords = getPage( pageSize, pageNumber )
			nextRecords.each { def nextRecord ->
				recordCallback( nextRecord )
			}
			if (nextRecords.size() < pageSize) {
				break
			}
		}
	}
}
