package com.ibm.issr.rest

import org.apache.http.HttpResponse
import org.apache.http.client.methods.HttpRequestBase
import org.codehaus.groovy.runtime.ProcessGroovyMethods.ProcessRunner;

import com.ibm.issr.core.log.LogTracingClass

/**
 * This is the base class for the various REST operations, such as RestPut and RestGet.
 * This is not usable in and of itself.
 * 
 * @author ltclark
 *
 */
class RestOperation extends LogTracingClass {
	protected RestServerConnection restClient;
	protected String _path;		// the path of the rest call
	protected HttpRequestBase requestMethod
	HttpResponse response = null;
	// The name of the operation, such as "Put"
	String operationName
	// parameters
	protected def parameters = []			// this is a list.  Each entry is a map with 'key' of key and 'value' of value.

	/**
	 * Constructor
	 * @param restClient The associated Rest Client connection.
	 * @param operationName The name of the operation: Put, Post, Get, etc.  This is used
	 * for generic messages.
	 * @param requestMethod This is the request method (such as HttpDelete) that the REST
	 * operation is using.  All of the classes derived from this class have the same basic
	 * pattern - in there constructor, they create a new request method (such as HttpDelete or
	 * HttpGet).  The various functions in the class manipulate the request method.  The execution
	 * call (such as put(), get(), post(), delete()) executes the request method.  In order to
	 * implement common behavior, the request method object is passed to the base class (which
	 * is this class).
	 */
	public RestOperation( RestServerConnection restClient, String operationName, HttpRequestBase requestMethod ) {
		this.restClient = restClient
		this.operationName = operationName
		this.requestMethod = requestMethod
	}

	/**
	 * Calculates and returns the full URL, which includes the server, path and parameters
	 * @return The full URL
	 */
	public String getFullUrl() {
		return restClient.buildFullUrl( _path, parameters )
	}

	/**
	 * For debugging purposes, the standard 'toString' method has been expanded to include
	 * the full url for the Rest Operation.
	 */
	public String toString() {
		return super.toString() + "[URL = '${getFullUrl()}']"
	}
	
	/**
	 * Sets request header field, such as .setHeader( 'Accept', 'application/json' )
	 * @param name The name of the request header.
	 * @param value The value of the request header.
	 * @return Returns 'this'.
	 */
	public RestOperation setHeader( String name, String value ) {
		requestMethod.setHeader(name, value)
		return this
	}
}
