package com.ibm.css.rest.ucd.security

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.application.ApplicationApi
import com.ibm.css.rest.ucd.team.TeamApi
import com.ibm.css.rest.ucd.user.UserApi
import com.ibm.issr.core.log.Logger
import com.ibm.issr.rest.RestPut

class SecurityApi {
	
	/**
	 * Does the given user have the named Security Role for the application??
	 * @param ucdServer API handle to the UCD Server.
	 * @param applicationId The Application ID
	 * @param userId The (login) name for the user.
	 * @param rolename The name of the security role.
	 */
	public static boolean doesUserHaveSecurityRoleForApplication(UcdServerConnection ucdServer, String applicationId, String userId, String roleName) {
		boolean isRoleMember = false

		// Get the list of Teams and Resource Roles for the Application
		def teams = ApplicationApi.getTeams(ucdServer, applicationId)
		Logger.debug "Teams for the application: ${teams}"

		// Get list of groups that the user is a member of
		def groups = UserApi.getGroups(ucdServer, userId)
		Logger.debug "Groups: ${groups}"

		// Is the user (or the user's group) a member of the role for any of the teams
		teams.each { team ->
			String teamName = team.teamLabel
			// check to see if the user is a role member of the team
			if ((! isRoleMember) && TeamApi.isUserAMemberAsRole( ucdServer, teamName, userId, roleName )) {
				isRoleMember = true
			}
			// check to see if any of the user's groups are role members of the team
			groups.each { group ->
				if ((! isRoleMember) && TeamApi.isGroupAMemberAsRole( ucdServer, teamName, group.name, roleName )) {
					isRoleMember = true
				}
			}
		}
		return isRoleMember
	}
}
