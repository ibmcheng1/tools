package com.ibm.css.ucd.services

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.css.ucd.resource.ResourceTree

/**
 * Manage and access Resource entities.
 * @author ltclark
 *
 */
class ResourceServices {
	private UcdServerConnection ucdServer
	private ResourceTree theResourceTree
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the server.
	 */
	public ResourceServices( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
		theResourceTree = new ResourceTree( ucdServer )
	}

	/**
	 * Returns the Resource Tree
	 */
	public ResourceTree getResourceTree() {
		return theResourceTree
	}
}
