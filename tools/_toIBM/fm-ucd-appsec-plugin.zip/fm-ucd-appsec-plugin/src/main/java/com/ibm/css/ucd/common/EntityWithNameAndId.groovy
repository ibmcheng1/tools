package com.ibm.css.ucd.common

import com.ibm.css.rest.ucd.UcdServerConnection

/**
 * Base class for entity classes that have a name and an ID.
 * @author ltclark
 *
 */
class EntityWithNameAndId extends EntityWithId {
	// the name and id
	private String _name
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 */
	public EntityWithNameAndId( UcdServerConnection ucdServer, String name, String id ) {
		super( ucdServer, id )
		_name = name
	}
	
	/**
	 * Returns the entity's name.
	 */
	public String getName() {
		return _name
	}

	/**
	 * Override to toString() to return the class name, instance name and instance id.
	 */
	String toString() {
		return this.getClass().getName() + "( name: '" + this.name +"', id: " + this.id + " )"
	}
}
