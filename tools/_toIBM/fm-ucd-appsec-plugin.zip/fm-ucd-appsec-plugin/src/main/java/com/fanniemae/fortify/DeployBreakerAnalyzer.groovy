package com.fanniemae.fortify

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.status.ComponentVersionStatus
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel
import com.ibm.issr.core.plugin.AbortPluginException
import com.ibm.issr.core.plugin.PluginHelper
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPost

import java.util.Map

import com.fanniemae.fortify.ssc.SscApi

class DeployBreakerAnalyzer {

//	String PRIMARY_TAGS_FILENAME = "PrimaryTags.txt"
	String PRIMARY_TAGS_FILENAME = "PrimaryTagsUsedToContinueDeployment.txt"
	
	UcdServerConnection ucdServer

	/**
	 * Constructor.
	 * @param ucdServer The associated UCD Server.
	 */
	public DeployBreakerAnalyzer(UcdServerConnection ucdServer) {
		Logger.debug "*****Started Analyzing SSC data...."
		this.ucdServer = ucdServer
	}

	/**
	 * Finds issues.
	 * @param ucdServer2 UCD server connection using StatusOwnewr username and password.
	 * @param componentVersion Component version object scanned earlier.
	 * @param sscServerUrl URL of the Fortify SSC server where the fortify scan information resides.
	 * @param sscUsername Username to be used to login Fortify SSC server.
	 * @param sscPassword Password to be used to login Fortify SSC server.
	 * @param sscApplicationName The SSC/Fortify Application Name.
	 * @param sscVersionName The name of the version with the project to find issues for.
	 * @param appScanPassedComponentStatus Component status as APPSEC_SCAN_PASSED
	 * @param appScanFailedComponentStatus Component status as APPSEC_SCAN_FAILED
	 * @return List - first element is a 'boolean success' flag.  Second element is a detailed error message.
	 */
	public List findIssuesAndSetComponentVersionStatus( UcdServerConnection ucdServer2, ComponentVersion componentVersion, String sscServerUrl, String sscUsername, String sscPassword, String sscApplicationName, String sscVersionName, ComponentVersionStatus appScanPassedComponentStatus, ComponentVersionStatus appScanFailedComponentStatus ) {
		boolean success = false
		String errorMsg = ''
//		try {
			SscApi sscApi = new SscApi(sscServerUrl, sscUsername, sscPassword)			
			
			Logger.debug "*****Loading dashboard versions"
			Object dashboardVersions = sscApi.getDashboardVersions()

			Logger.debug "*****Getting version ID from dashboard versions"

			Logger.debug "*****sscApplicationName: '${sscApplicationName}'"
			Logger.debug "*****sscVersionName: '${sscVersionName}'"

//			int versionId = sscApi.getVersionIdFromDashboardVersions("FZM", "MSR01617")
			int versionId = sscApi.getVersionIdFromDashboardVersions(sscApplicationName, sscVersionName)
			Logger.debug "***** version IDs: " + versionId

			Logger.debug "*****Loading artifacts"
			Object artifacts = sscApi.getArtifacts(versionId)
	
			Logger.debug "*****Loading issues"
			Object issues = sscApi.getIssues(versionId)
			
			int totalIssues = 0
			Logger.debug "*****Total issues: ${issues.count}"
			
			// read all the lines from Primary Tags file into a list,
			// each line is an element in the list except comment and blank lines
			File primaryTagsFile = new File( getClass().getResource(PRIMARY_TAGS_FILENAME).toURI() )
			List primaryTagsFileContents = primaryTagsFile.readLines()
			List primaryTagsList = []
		
//			Logger.debug "*****PrimarytTags used to stop deployment:"
			Logger.debug "*****PrimarytTags used NOT to stop deployment:"
			if ( primaryTagsFileContents != null ) {
				primaryTagsFileContents.each { String listItem ->
					if (!(listItem.contains("#")) && (listItem.size() != 0)) {
						Logger.debug "***** : ${listItem}"
						primaryTagsList.add(listItem)
					}
				}
			} else {
                throw new AbortPluginException("Something wrong with primary tags file: ${PRIMARY_TAGS_FILENAME}. No primary tags found in the file.")
            }
	
			issues.data.each { Map issueData ->

//				if ((!(issueData.primaryTag)) || (primaryTagsList.contains(issueData.primaryTag))) {
//					totalIssues++
//				}
				if (!(primaryTagsList.contains(issueData.primaryTag))) {
					Logger.debug "*****issueName: '${issueData.issueName}', issueStatus: '${issueData.issueStatus}', Analysis (Primary Tag): '${issueData.primaryTag}', '<==DEPLOY BREAKER'"
					totalIssues++
				} else {
					Logger.debug "*****issueName: '${issueData.issueName}', issueStatus: '${issueData.issueStatus}', Analysis (Primary Tag): '${issueData.primaryTag}'"
				}
				
			}
			Logger.info "*****Total issues with concerns: ${totalIssues}"
			
			Logger.debug "*****Started working on component version status..."
			if (totalIssues == 0) {
//				success = false
				// flag as success
				if (componentVersion.hasStatus(appScanFailedComponentStatus)) {
					componentVersion.removeStatus(ucdServer2, appScanFailedComponentStatus)
				}
				if (! componentVersion.hasStatus(appScanPassedComponentStatus)) {
					componentVersion.addStatus(ucdServer2, appScanPassedComponentStatus)
				}
			} else {
//				success = true
				// flag as failed
				if (componentVersion.hasStatus(appScanPassedComponentStatus)) {
					componentVersion.removeStatus(ucdServer2, appScanPassedComponentStatus)
				}
				if (! componentVersion.hasStatus(appScanFailedComponentStatus)) {
					componentVersion.addStatus(ucdServer2, appScanFailedComponentStatus)
				}
	
			}			
			
//		}
//		catch (Exception e) {
//			Logger.printStackTrace(LoggerLevel.ERROR, e)
//		}
		return [success,errorMsg]
	}


}
