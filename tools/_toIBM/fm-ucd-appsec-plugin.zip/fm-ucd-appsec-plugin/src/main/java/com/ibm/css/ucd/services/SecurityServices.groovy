package com.ibm.css.ucd.services

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.security.group.GroupMgr
import com.ibm.css.ucd.security.role.RoleMgr
import com.ibm.css.ucd.team.TeamMgr
import com.ibm.css.ucd.security.user.User
import com.ibm.css.ucd.security.user.UserMgr

/**
 * Services for working with security, authentication and authorization information.
 * @author LeonClark
 *
 */
class SecurityServices {
	private UcdServerConnection ucdServer
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the server.
	 */
	public SecurityServices( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
	}
	
	/**
	 * This is a convenience method that is a shortcut for calling 'UserMgr.getInstance(ucdServer)'
	 */
	public UserMgr getUserMgr() {
		return UserMgr.getInstance(ucdServer)
	}
	
	/**
	 * This is a convenience method that is a shortcut for calling 'TeamMgr.getInstance(ucdServer)'
	 */
	public TeamMgr getTeamMgr() {
		return TeamMgr.getInstance(ucdServer)
	}
	
	/**
	 * This is a convenience method that is a shortcut for calling 'RoleMgr.getInstance(ucdServer)'
	 */
	public RoleMgr getRoleMgr() {
		return RoleMgr.getInstance(ucdServer)
	}

	/**
	 * This is a convenience method that is a shortcut for calling 'GroupMgr.getInstance(ucdServer)'
	 */
	public GroupMgr getGroupMgr() {
		return GroupMgr.getInstance(ucdServer)
	}

	/**
	 * Returns a user by name.
	 * @deprecated Use UserMgr.getByName() instead.
	 * @param name
	 * @return
	 */
	@Deprecated
	public User getUserByName( String name ) {
		
	}
}
