package com.ibm.css.rest.ucd.request

/**
 * Helper functions for making Process Request functions.
 * @author ltclark
 *
 */
class ProcessRequestHelper {
	/**
	 * Parse a string list of component versions (which are passed into the plugin
	 * as a string) into a List of the component versions.
	 * @param componentVersions Multiline string.  Each line is one component version map
	 * in the format of "componentName:versionName".
	 * @return A List of dynamic objects (which are maps) with the fields 'version' and
	 * 'component'.
	 */
	public static List parseComponentVersions( String componentVersions ) {
		List componentList = []
		String[] componentVersionLines = componentVersions.split("\n")
		for (String componentVersionLine : componentVersionLines) {
			if (componentVersionLine.trim().length() > 0) {
				int delimLoc = componentVersionLine.indexOf(':')
				if (delimLoc <= 0) {
					throw new IllegalArgumentException("Component/version pairs must contain one component per line with format component:version")
				}
				String componentName = componentVersionLine.substring(0,delimLoc).trim()
				String componentVersion = componentVersionLine.substring(delimLoc+1).trim()
				componentList.add( [version:componentVersion, component:componentName] )
			}
		}
		return componentList
	}
	
	public static Properties parseProperties( String propertyParameters ) {
		// TODO - there is a problem - using the Java Properties for a multiline property actually merges the lines (discards the new lines)
		Properties props = new Properties()
		props.load( new StringReader(propertyParameters) )
		return props
	}
}
