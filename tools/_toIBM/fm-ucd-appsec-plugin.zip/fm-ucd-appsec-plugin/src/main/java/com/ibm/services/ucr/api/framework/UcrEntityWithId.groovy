package com.ibm.services.ucr.api.framework

import com.ibm.issr.core.entity.EntityWithId;
import com.ibm.issr.rest.RestServerConnection

/**
 * Base class for UCR Entities which have an ID. 
 * @author LeonClark
 *
 */
class UcrEntityWithId extends UcrEntity implements EntityWithId {
	private String _id
	
	/**
	 * Constructor.
	 * @param ucrServer Handle to the UCR Server
	 * @param id The entity's id
	 */
	protected UcrEntityWithId( RestServerConnection ucrServer, String id ) {
		super(ucrServer)
		_id = id
	}
	
	/**
	 * Returns the entity's id.
	 */
	public String getId() {
		return _id
	}
	
	/**
	 * Overwrite of equals that returns true if two 'UcrEntityWithId' are (a) the same class,
	 * (b) the same ucdServer, and (c) the same id.
	 */
	boolean equals( Object o ) {
		return ((o instanceof UcrEntityWithId) && this.ucrServer.equals(o.ucrServer) && this.getClass().equals(o.getClass()) && this.id.equals(o.id))
	}

	/**
	 * Override to toString() to return the class name, instance name and instance id.
	 */
	String toString() {
		return this.getClass().getName() + "( id: " + this.id + " )"
	}
}
