package com.ibm.css.ucd.processrequest.filter

import java.util.Date

import com.ibm.css.ucd.application.Application;
import com.ibm.css.ucd.processrequest.ProcessRequest;

/**
 * This is used to apply a set (zero, one or more) different filters at one time.
 * The logic is basically 'AND' logic, where a record is only included if all of the member
 * filters pass. 
 * @author ltclark
 *
 */
class ProcessRequestSetOfFilters extends ProcessRequestFilter {
	// The list of contained filters.  Each entry is a ProcessRequestFilter.
	List _filters = []

	/**
	 * Add another filter to the list.  This returns 'this' object, which allows for syntax
	 * like ProcessRequestFilter filter = (new ProcessRequestSetOfFilters()).addFilter(filter1).addFilter(filter2)
	 * @param processRequestFilter
	 */
	public ProcessRequestSetOfFilters addFilter( ProcessRequestFilter processRequestFilter ) {
		_filters << processRequestFilter
		return this
	}
		
	@Override
	public Date getFilteringStartedAfter() {
		// Iterate the filters and return the most current 'startedAfter' value
		Date startedAfter = null
		_filters.each { ProcessRequestFilter childFilter ->
			Date childStartedAfter = childFilter.getFilteringStartedAfter()
			if (childStartedAfter) {
				if ((! startedAfter) || (startedAfter < childStartedAfter)) {
					startedAfter = childStartedAfter
				}
			}
		}
		return startedAfter
	}
	
	@Override
	public Application getFilteringApplication() {
		// Iterate the filters searching for any that have an application filter
		Application appFilter = null
		_filters.each { ProcessRequestFilter childFilter ->
			if (childFilter.getFilteringApplication()) {
				appFilter = childFilter.getFilteringApplication()
			}
		}
		return appFilter
	}

	@Override
	public boolean includeRawRecordInFilter(Object rawRecord) {
		boolean retval = true
		
		// If ANY of the member filters returns false, then this function returns false
		_filters.each { ProcessRequestFilter childFilter ->
			if (! childFilter.includeRawRecordInFilter(rawRecord)) {
				retval = false
			}
		}
		
		return retval
	}
	
	@Override
	public boolean includeProcessRequestInFilter(ProcessRequest processRequest) {
		boolean retval = true
		
		// If ANY of the member filters returns false, then this function returns false
		_filters.each { ProcessRequestFilter childFilter ->
			if (! childFilter.includeProcessRequestInFilter(processRequest)) {
				retval = false
			}
		}
		
		return retval
	}

	@Override
	public String getDescription() {
		String retval = ''
		String delim = ''
		_filters.each { ProcessRequestFilter childFilter ->
			retval = retval + delim + '(' + childFilter.getDescription() + ')'
			delim = ' and '
		}
		return retval;
	}

}
