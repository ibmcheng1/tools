package com.ibm.services.ucr.api.entity.change

import com.ibm.issr.rest.RestDelete
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.entity.application.UcrApplication
import com.ibm.services.ucr.api.entity.application.UcrApplicationMgr
import com.ibm.services.ucr.api.entity.changetype.UcrChangeType
import com.ibm.services.ucr.api.entity.changetype.UcrChangeTypeMgr
import com.ibm.services.ucr.api.entity.initiative.UcrInitiative
import com.ibm.services.ucr.api.entity.initiative.UcrInitiativeMgr
import com.ibm.services.ucr.api.entity.release.UcrRelease
import com.ibm.services.ucr.api.entity.release.UcrReleaseMgr
import com.ibm.services.ucr.api.framework.UcrEntityData
import com.ibm.services.ucr.api.framework.UcrEntityDataFormat
import com.ibm.services.ucr.api.framework.UcrEntityWithNameAndId

/**
 * One UCR Change record.
 * @author LeonClark
 *
 */
class UcrChange extends UcrEntityWithNameAndId {
	// Cached instance of 'UcrEntityData'
	private RestDataCache _cachedEntityData = new RestDataCache()
	
	/**
	 * This constructor should only be called by this entity's Mgr class.
	 */
	UcrChange( RestServerConnection ucrServer, String name, String id ) {
		super( ucrServer, name, id )
	}
	
	/**
	 * Constructor based on the 'restInfo'
	 * @param ucrServer
	 * @param restInfo
	 */
	UcrChange( RestServerConnection ucrServer, UcrEntityData restEntity ) {
		super( ucrServer, restEntity.entityObject.name, restEntity.entityObject.id )
		_cachedEntityData.setCacheData( ucrServer, restEntity )
	}
	
	/**
	 * Resets the cached data storing internal data for this class instance.
	 */
	public void resetCachedData() {
		_cachedEntityData.resetCacheData(ucrServer)
	}
	
	
	/**
	 * Returns entity data for this entity which is at LEAST the 'minDataFormat' level of information.  For example,
	 * if the minDataFormat is LIST_FORMAT, then both LIST_FORMAT and DETAIL_FORMAT are suitable.
	 * If possible, this returns cached data, otherwise it loads (and caches) the data.
	 */
	public UcrEntityData getEntityData( UcrEntityDataFormat minDataFormat, boolean resetCache=false ) {
		UcrEntityData entityData = _cachedEntityData.getCacheData(ucrServer,resetCache)
		if ((! entityData) || (! entityData.getEntityFormat().isSuperset( minDataFormat ))) {
			// Load the data and cache it
			def data = (new RestGet( ucrServer ))
				.setPath('/changes/' + this.id)
				.addParameter('format', minDataFormat.getFormatName())
				.setHeader('Accept', 'application/json')
				.getAsObject()
			_cachedEntityData.setCacheData(ucrServer, new UcrEntityData(data, minDataFormat))
		}
		return _cachedEntityData.getCacheData(ucrServer)
	}
	
	/**
	 * Returns detail'ed entity data.  This is data retrieved via a REST call with format of 'detail'.  If possible,
	 * this returns cached data, otherwise it loads (and caches) the data.
	 */
	public UcrEntityData getDetailedEntityData( boolean resetCache=false ) {
		return getEntityData( UcrEntityDataFormat.DETAIL_FORMAT, resetCache )
	}
	
	
	/**
	 * Returns at least a LIST level UcrEntityData for this class, which is the underlying REST/JSON based data structure.
	 */
	public UcrEntityData getEntityData( boolean resetCache = false ) {
		return getEntityData( UcrEntityDataFormat.LIST_FORMAT, resetCache )
	}
	
	
	/**
	 * If this change is from an external source, like Jira, this is the external
	 * system's ID.  Otherwise, it is an empty string.
	 */
	public String getExternalId( boolean resetCache = false ) {
		String retval = ''
		Map data = getEntityData(resetCache).entityObject
		if (data.containsKey('externalId')) {
			retval = data.externalId
		}
		return retval
	}
	
	
	/**
	 * If possible, this is the URL hyperlink to the issue within the linked external
	 * system, such as Jira.  Otherwise, this is an empty string.
	 */
	public String getExternalUrl( boolean resetCache = false ) {
		String retval = ''
		Map data = getEntityData(resetCache).entityObject
		if (data.containsKey('externalUrl')) {
			retval = data.externalUrl
		}
		return retval
	}

	
	/**
	 * Returns the UcrChangeType of this Change record.
	 */
	public UcrChangeType getChangeType( boolean resetCache = false ) {
		UcrChangeType changeType = null
		Map data = getEntityData(resetCache).entityObject
		if (data.containsKey('type')) {
			String changeTypeId = data['type'].id
			changeType = UcrChangeTypeMgr.getInstance(ucrServer).getById(changeTypeId, resetCache)
		}
		return changeType
	}

	/**
	 * Returns the UcrRelease linked to this change or null if there is no linked release.
	 */
	public UcrRelease getRelease( boolean resetCache = false ) {
		UcrRelease release = null
		Map data = getEntityData(resetCache).entityObject
		if (data.containsKey('release')) {
			String releaseId = data.release.id
			release = UcrReleaseMgr.getInstance(ucrServer).getById(releaseId)
		}
		return release
	}	

	/**
	 * Returns the UcrInitiative linked to this change or null if there is no linked initiative.
	 */
	public UcrInitiative getInitiative( boolean resetCache = false ) {
		UcrInitiative initiative = null
		Map data = getEntityData(resetCache).entityObject
		if (data.containsKey('initiative')) {
			String initiativeId = data.initiative.id
			initiative = UcrInitiativeMgr.getInstance(ucrServer).getById(initiativeId)
		}
		return initiative
	}	

	/**
	 * Returns the UcrApplication linked to this change or null if there is no linked application.
	 */
	public UcrApplication getApplication( boolean resetCache = false ) {
		UcrApplication application = null
		Map data = getEntityData(resetCache).entityObject
		if (data.containsKey('application')) {
			String initiativeId = data.application.id
			application = UcrApplicationMgr.getInstance(ucrServer).getById(initiativeId)
		}
		return application
	}

	/**
	 * Returns the 'severity' of this change or an empty String if not found.
	 */
	public String getSeverity( boolean resetCache = false ) {
		Map data = getEntityData(resetCache).entityObject
		if (data.containsKey('severity') && data.severity) {
			return data.severity
		} else {
			return ''
		}
	}	

	/**
	 * Returns the 'status' of this change or an empty String if not found.
	 */
	public String getStatus( boolean resetCache = false ) {
		Map data = getEntityData(resetCache).entityObject
		if (data.containsKey('status') && data.status) {
			return data.status
		} else {
			return ''
		}
	}	

	/**
	 * Delete this entity from UCR!!  Appropriate cached data is reset.
	 */
	public void delete() {
		(new RestDelete(ucrServer))
			.setPath('/changes/' + this.id)
			.deleteWithNoReturnObject()
		// TODO - currently reseting all cached data.  In the future, just remove the entry from the Mgr's cache(s)
		RestDataCache.resetAllCacheData(ucrServer)
	}
}
