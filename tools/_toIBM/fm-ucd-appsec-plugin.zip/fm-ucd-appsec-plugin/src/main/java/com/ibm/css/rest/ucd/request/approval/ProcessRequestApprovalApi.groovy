package com.ibm.css.rest.ucd.request.approval

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.request.ProcessRequestApi
import com.ibm.issr.core.log.Logger
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestResponse

/**
 * API wrapper for accessing approval status information for Process Requests.
 * @author ltclark
 *
 */
class ProcessRequestApprovalApi {
	
	/**
	 * Returns a list of the Approvals (pending and complete) for a Process Request.  Note that unlike most
	 * of the other API classes and data retrieval functions, this does NOT just forward the raw data
	 * from the REST call.  Instead this maps the data into following format:
	 * <pre>
	 * Map (approval information for one Process Request)
	 *     String id - The ID of the approval request 'task'
	 *     String status - Overall status: 'Approved', 'Rejected', 'In Progress', 'Canceled'
	 *     List detailedApprovals - List of past and future approvals.  Each entry is one detailed approval.
	 *         Map - One detailed approval entry (pending or completed)
	 * 	           String type	- The type of approval entry: 'environment', 'application', 'component'
	 *             String status - Calculate status.  One of: 'Pending', 'Approved', 'Rejected', 'Canceled'
	 *             
	 *             // for type of 'component', the following fields defined (else undefined)
	 *             String componentId
	 *             String componentName
	 *             
	 *             // for type of 'application', the following fields defined (else undefined)
	 *             String applicationId
	 *             String applicationName
	 *             
	 *             // for type of 'environment', the following fields defined (else undefined)
	 *             String environmentId
	 *             String environmentName
	 *             
	 *             // The following fields are only defined if the detailedApproval is complete 
	 *             String completedBy - IF completed by person, name of completing person.
	 *             long completedOn - IF completed, when (milliseconds).
	 * </pre>
	 * @param ucdServer Handle to the server.
	 * @param processRequestId The ID of the ProcessRequest.
	 * @return A map as described in the description if this process has approval information.  Returns
	 * null if no process approval is associated with the Process Request.
	 */
	public static Map getApprovals( UcdServerConnection ucdServer, String processRequestId ) {
		
		// Figure out the ApprovalRequestID for the given processRequestId!!
		String approvalId = (new ProcessRequestApi(ucdServer)).getApprovalId(processRequestId)
		
		if (approvalId) {
			Map approvalData = [id:approvalId, detailedApprovals:[]]

			// Note that I have seen valid rest calls (with a valid approvalId), return a 500 error code from this
			// So, set special error handling in that code.
			def information = (new RestGet( ucdServer )).setPath("/rest/approval/approval/${approvalId}/withTrace")
					.get() { RestResponse response ->
						if (response) {
							if (response.httpStatus == 500) {
								// This shouldn't be returned, but I have seen it return it - eat the problem and
								Logger.info "IGNORING: ${response.restOperation.operationName} call to REST (" + response.restOperation.fullUrl + ") failed with code ${response.httpStatus} - ${response.responseAsString}"
								return null
							} else {
								response.throwExceptionOnBadResponse()
								return response.responseAsObject
							}
						} else {
							return null
						}
					}
			Logger.debug "getApprovals() - get approval data response is ${information}"
	
			if (information) {
				// Figure out the Approval Status
				if (information.finished) {
					if (information.failed) {
						approvalData.status = 'Rejected'
					} else if (information.cancelled) {
						approvalData.status = 'Canceled'
					} else {
						approvalData.status = 'Approved'
					}
				} else {
					approvalData.status = 'In Progress'
				}
				
				// This closure calculates the summary 'status' (such as "Approved") for one detailed entry in the approval data
				// The 'approvalTaskEntry' is a record in the approval information which has a 'type' of 'environmentApprovalTask',
				// 'applicationApprovalTask' or 'componentApprovalTask'.  It returns the summary 'String status'. 
				Closure calculateDetailedStatus = { def approvalTaskEntry ->
					String status
					if (approvalTaskEntry.state.equalsIgnoreCase('CLOSED')) {
						if (approvalTaskEntry.result.equalsIgnoreCase('FAULTED')) {
							if (approvalTaskEntry.containsKey('task')) {
								status = 'Rejected'
							} else {
								status = 'Canceled'
							}
						} else if (approvalTaskEntry.result.equalsIgnoreCase('SUCCEEDED')) {
							if (approvalTaskEntry.containsKey('task') && approvalTaskEntry.task.status.equalsIgnoreCase('CANCELLED')) {
								status = 'Canceled'
							} else {
								status = 'Approved'
							}
						} else if (approvalTaskEntry.result.equalsIgnoreCase('CANCELED')) {
							status = 'Canceled'
						}
					} else if (approvalTaskEntry.state.equalsIgnoreCase('EXECUTING')) {
						status = 'Pending'
					} else if (approvalTaskEntry.state.equalsIgnoreCase('INITIALIZED')) {
						// technically, this is an approval process that hasn't even started yet - in the flow waiting for prior approvals first
						status = 'Pending'
					}
					if (! status) {
						status = "Unknown (approvalTaskEntry.state='${approvalTaskEntry.state}',approvalTaskEntry.result='${approvalTaskEntry.result}')"
					}
//					status = status + "(state='${approvalTaskEntry.state}',result='${approvalTaskEntry.result}')"
					return status
				}
				
				// Iterate and process the approval details
				if (information.containsKey('activity') && information.activity.containsKey('children')) {
					information.activity.children.each { Map childEntry ->

						// Maps common fields from one of the '...Task' typed entries from the raw data into
						// a 'newDetailedApproval' record. 						
						Closure mapCommonTaskFields = { def newDetailedApproval, def taskEntry ->
							newDetailedApproval.status = calculateDetailedStatus( taskEntry )
							if (taskEntry.containsKey('task')) {
								if (taskEntry.task.containsKey('completedBy')) {
									newDetailedApproval.completedBy = taskEntry.task.completedBy
								}
								if (taskEntry.task.containsKey('completedOn')) {
									newDetailedApproval.completedOn = taskEntry.task.completedOn
								}
							}
							
						}

						if (childEntry.type=='environmentApprovalTask') {
							Map newDetailedApproval = [:]
							newDetailedApproval.type = 'environment'
							mapCommonTaskFields( newDetailedApproval, childEntry )
							if (childEntry.containsKey('task') && childEntry.task.containsKey('environment')) {
								newDetailedApproval.environmentId = childEntry.task.environment.id
								newDetailedApproval.environmentName = childEntry.task.environment.name
							}
							approvalData.detailedApprovals << newDetailedApproval
						} else if (childEntry.type=='applicationApprovalTask') {
							Map newDetailedApproval = [:]
							newDetailedApproval.type = 'application'
							mapCommonTaskFields( newDetailedApproval, childEntry )
							if (childEntry.containsKey('task') && childEntry.task.containsKey('application')) {
								newDetailedApproval.applicationId = childEntry.task.application.id
								newDetailedApproval.applicationName = childEntry.task.application.name
							}
							approvalData.detailedApprovals << newDetailedApproval
						} else if (childEntry.type=='componentApprovalIterator') {
							// Iterate the children
							childEntry.children.each { def rawComponentApprovalTask ->
								Map newDetailedApproval = [:]
								newDetailedApproval.type = 'component'
								mapCommonTaskFields( newDetailedApproval, rawComponentApprovalTask )
								if (childEntry.containsKey('task') && childEntry.task.containsKey('component')) {
									newDetailedApproval.componentId = rawComponentApprovalTask.task.component.id
									newDetailedApproval.componentName = rawComponentApprovalTask.task.component.name
								}
								approvalData.detailedApprovals << newDetailedApproval
							}
						} else {
							throw new Exception( "Internal UCD Wrapper error - unknown approval detailed type of '${childEntry.type}'" )
						}
					}
				}
				
				return approvalData
			} else {
				return null
			}
		} else {
			return null
		}
		
	}
	
}
