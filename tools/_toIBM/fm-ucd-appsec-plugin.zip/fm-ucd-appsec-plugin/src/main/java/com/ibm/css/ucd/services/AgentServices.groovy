package com.ibm.css.ucd.services

import com.ibm.css.rest.ucd.UcdServerConnection;
import com.ibm.css.rest.ucd.agent.AgentApi;
import com.ibm.css.ucd.agent.Agent;

/**
 * Manager class for interacting with Agents.
 * @author ltclark
 *
 */
class AgentServices {
	private UcdServerConnection ucdServer
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the server.
	 */
	public AgentServices( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
	}

	/**
	 * Returns the named agent.  Throws exception if unable to find the agent.
	 * @param agentName The name of the agent.
	 * @return The 'Agent' instance.
	 */
	public Agent getAgent( String agentName ) {
		return AgentApi.getAgentEntityFromName(ucdServer, agentName)
	}
}
