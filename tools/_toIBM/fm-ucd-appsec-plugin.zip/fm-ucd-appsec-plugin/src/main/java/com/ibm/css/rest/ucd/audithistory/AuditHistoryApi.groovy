package com.ibm.css.rest.ucd.audithistory

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.issr.core.log.Logger
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPut;
import com.ibm.issr.rest.RestResponse;

class AuditHistoryApi {
	UcdServerConnection ucdServer
	
	/**
	 * Constructor for this light weight class.
	 * @param ucdServer Handle to UCD Server
	 */
	public AuditHistoryApi( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
	}

	
	/**
	 * Iterates the entries in the Audit History table with optional start and end date range.
	 * It calls the callback function for each record.
	 * @param startDate Optional start date.  If provided, it looks for records on or after this date.
	 * @param endDate Optional end date for the filter.  If provided, it looks for records LESS THAN
	 * (but not equal to) this date.
	 * @param callback This function is called for each member record.  It takes one parameter, which is the Object version of the json
	 * entry for each record returned by the rest call.
	 */
	public void iterateAuditHistory( Date startDate, Date endDate, Closure callback ) {
		// Page size for data retrieval
		int pageSize = 128
		
		// What 0-based record number to start with?  If there is no start date, then this is 0
		long firstPageIndex = 0
		if (startDate) {
			// Figure out the first record number based on startDate
			
			// First - roughly how many records are under consideration?
			// Start with record number 'searchStart' and multiply by 'searchExponent'
			// until finding a record after the startDate or finding the end of the list
			long searchStart = 1024
			long searchExponent = 8 
			long searchIndex = searchStart
			while (true) {
				searchIndex = searchIndex * searchExponent
				Logger.debug "AuditHistoryApi.iterateAuditHistory() -  FINDING SIZE: searchIndex = ${searchIndex}"				
				List records = getPageOfAuditHistory( searchIndex+1, true, 1, 'date' )
				if (records.size() == 0) {
					// found the end of the list
					break
				}
				Date date = new Date( records[0].date)
				if (date > startDate) {
					// found a record after the start date
					break
				}
			}
			Logger.debug "AuditHistoryApi.iterateAuditHistory() -  FOUND MAX SIZE: searchIndex = ${searchIndex}"
			
			// The starting date is somewhere between 0 and searchIndex.
			// But, we just need to know which page number (zero based) has
			// the starting record
			// Use binary search to find the date
			long lowPageIndex = 0
			long highPageIndex = searchIndex / pageSize
			long searchPageIndex = lowPageIndex
			while (true) {
				// desired record is >= lowIndex and < highIndex
				searchPageIndex = lowPageIndex + ((highPageIndex - lowPageIndex) / 2)
				Logger.debug "AuditHistoryApi.iterateAuditHistory() -  LOOKING FOR STARTING PAGE: lowPageIndex=${lowPageIndex}, highPageIndex=${highPageIndex}, searchPageIndex=${searchPageIndex}"				
				if (searchPageIndex == highPageIndex) {
					searchPageIndex = highPageIndex - 1
				}
				if (searchPageIndex <= lowPageIndex) {
					searchPageIndex = lowPageIndex
					break
				}
				List records = getPageOfAuditHistory( (searchPageIndex*pageSize)+1, true, 1, 'date' )
				if (records.size() == 0) {
					// searchPageIndex is still to high (after end of table), so use it as highIndex
					highPageIndex = searchPageIndex
				} else {
					Date date = new Date( records[0].date)
					if (date < startDate) {
						lowPageIndex = searchPageIndex
					} else {
						highPageIndex = searchPageIndex
					}
				}
			}
			
			// Use the searchIndex as the lowest record number to retrieve
			firstPageIndex = searchPageIndex
		}
		
		// get the records
		// Implementation notes:
		//		start loading the recods on 'firstPageIndex' until reaching the end date or the end of the list
		//		This still validates that each retrieved record is in range
		int pageNumber = firstPageIndex		// this is zero based page number.  API call is 1 based page number
		Logger.debug "AuditHistoryApi.iterateAuditHistory() -  FIRST PAGE: pageNumber=${pageNumber}"				
		boolean reachedEndOfList = false
		while (! reachedEndOfList) {
			Logger.debug "AuditHistoryApi.iterateAuditHistory() -  READING PAGE: pageNumber=${pageNumber}"				
			++pageNumber
			List auditRecords = getPageOfAuditHistory(pageNumber, true, pageSize, 'date')
			if (auditRecords.size() == 0) {
				// reached the end of the list
				break
			}
			auditRecords.each { entry ->
				// if we have found the end of the list, skip processing of remaining records from the page
				if (! reachedEndOfList) {
					Date date = new Date(entry.date)
					if (startDate && startDate > date) {
						// this record is before the start date - ignore it
					} else if (endDate && endDate <= date) {
						// this record is after the end date - ignore it and flag as done
						reachedEndOfList = true
					} else {
						// Good record - process it
						callback( entry )
					}
				}
			}
		}
		
	}
	
	
	/**
	 * Returns one page of the the audit history list.
	 * @param pageSize The number of rows to return in a page.
	 * @param pageNumber Which page number to return.  The first page is 1
	 * @param ascending Ascending order or false for descending.
	 * @param orderField Which field to sort on.
	 * @return Returns an empty list if no entries found for the page.
	 * The List of entries as returned by the REST call (to /rest/auditentry).  This is a sample
	 * entry: 	{
	 *	"date": 1525813381401,
	 *	"eventType": "Login",
	 *	"description": "Login Attempt",
	 *	"objType": "SecurityUser",
	 *	"objName": "admin",
	 *	"objId": "20000000000000000000000001000000",
	 *	"userId": "20000000000000000000000001000000",
	 *	"userName": "admin",
	 *	"status": "Success",
	 *	"id": "660af851-a95a-4e22-8e02-dfdfb0e9952c",
	 *	"ipAddress": "127.0.0.1"
	 *  },
	 */
	public List getPageOfAuditHistory( long pageNumber, boolean ascending=true, int pageSize=500, String orderField='date' ) {
		String sortType = 'desc'
		if (ascending) {
			sortType = 'asc'
		}
		// sortType may be asc or desc
			
		return (new RestGet( ucdServer )).setPath("/rest/auditentry").addParameter("rowsPerPage", "${pageSize}").addParameter("pageNumber", "${pageNumber}").
			addParameter("orderField", orderField).addParameter("sortType", sortType).
			getAsObject()
	}
	
	
	/**
	 * Deletes old audit history records from UCD that are older than the given date.
	 * If this fails, then an exception is thrown
	 * @param priorToDate Cutoff date.  It deletes records older than this.  It does NOT
	 * delete audit records with this date.
	 */
	public void deleteOldAuditHistoryEntries( Date priorToDate ) {
		def payload = 
			[
				date: priorToDate.getTime(),
				time: ''
			]
		(new RestPut(ucdServer)).setPath("/rest/auditentry/")
//			.setPayload('{date: 1525183200000, time: "1970-01-01T15:00:00.000Z"}')
			.setJsonPayloadToObject(payload)
			.putWithNoReturnObject()
	}

}
