package com.ibm.issr.core.plugin

/**
 * Class containing Plugin Helper functions.
 * @author ltclark
 *
 */
class PluginHelper {
	// If defined, this overrides the PLUGIN_HOME environment variable
	private static defaultPluginHome = null
	
	/**
	 * This class finds plugin files (like plugin.xml and info.xml) using the PLUGIN_HOME system property.
	 * When this function is called with a non-null pluginHome, that directory is used as the plugin's
	 * home directory instead of the PLUGIN_HOME system property
	 */
	static public void setDefaultPluginHome( String pluginHome ) {
		this.defaultPluginHome = pluginHome
	}
	
	
	/**
	 * Immediately abort the plugin because of a failure condition described by the message.
	 * This actually throws a message.  The message is displayed to the output as an 'error'
	 * message, but no stack trace is thrown.
	 * @param msg
	 */
	static public void abortPlugin( String msg ) {
		throw new AbortPluginException(msg)
	}
	
	/**
	 * <p>Looks up and returns information about the current plugin by reading its XML files (info.xml and plugin.xml).
	 * Specifically, this returns a Map with the following fields.  Note that every field is ALWAYS returned even
	 * if there is a problem reading the xml files.</p>}
	 * <ul>
	 * <li>pluginFolder - The folder where the plugin files are located.</li>
	 * <li>version - The plugin version string (from info.xml></li>
	 * <li>apiVersion - The numeric API version of the plugin (from plugin.xml)</li>
	 * <li>name - The name of the plugin</li>
	 * <li>id - The id of the plugin</li>
	 * <li>description - The description of the plugin</li>
	 * </ul>
	 * @param pluginHome This function automatically locates the plugin's XML files via the system property 'PLUGIN_HOME', but
	 * you can specify an alternative path in this property which overrides the system property.
	 */
	static public Map getPluginInformation() {
		Map info = [
			pluginFolder: '[unknown]',
			version: '[unknown version]',
			apiVersion: "-1",
			name: '[unknown name]',
			id: '[unknown id]',
			description: ''
			]
		String pluginHome = defaultPluginHome
		if ((! pluginHome) && System.getenv('PLUGIN_HOME')) {
			pluginHome = System.getenv('PLUGIN_HOME')
		}
		if (pluginHome) {
			info.pluginFolder = pluginHome
			File infoXmlFile = new File( pluginHome, 'info.xml' )
			def infoXml = new XmlSlurper().parse(infoXmlFile)
			info.version = infoXml."release-version".text()
			
			File pluginXmlFile = new File( pluginHome, 'plugin.xml' )
			def pluginXml = new XmlSlurper().parse(pluginXmlFile)
			info.apiVersion = pluginXml.header.identifier.@version
			info.name =  pluginXml.header.identifier.@name
			info.id = pluginXml.header.identifier.@id
			info.description = pluginXml.header.description
		}
		return info
	}
	
	/**
	 * Returns the folder where the UCD Plugin is located.  If NOT running in UCD, this
	 * will return null.
	 */
	static public String getPluginFolder() {
		String folder = getPluginInformation().pluginFolder
		if (folder == '[unknown]') {
			return null
		} else {
			return folder
		}
	}
}
