package com.ibm.css.ucd.services

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.process.ProcessApi

/**
 * UCD Connection Manager.  Currently, this returns specific managers.
 * Note that it is ok to create multiple instances of this class.  The implementation uses
 * a ucdService specific singleton that is wrapped in this class.
 * @author ltclark
 *
 */
class UcdConnectionServices {
	// List of service instances.  key = UcdServerConnection, value=ConnectionServiceInstance
	static def serviceInstances = [:]
	
	// The nested singleton for this instance.
	public ConnectionServiceInstance serviceInstance; 
	
	/**
	 * The implementation of this class is a ucdServer based singleton.  Each ucdServer instance
	 * has its own inner class.
	 * @author ltclark
	 *
	 */
	class ConnectionServiceInstance {
		private UcdServerConnection ucdServer
		private AgentServices _agentManager
		private ComponentServices _componentManager
		private TeamServices _teamManager
		private ResourceServices _resourceManager
		private ApplicationServices _applicationManager
		private AuditHistoryServices _auditHistoryServices
		private ProcessRequestServices _processRequestServices
		private StatusServices _statusServices
		private SecurityServices _securityServices
	}
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the server.
	 */
	public UcdConnectionServices( UcdServerConnection ucdServer ) {
		if (serviceInstances.containsKey(ucdServer)) {
			serviceInstance = serviceInstances[ucdServer]
		} else {
			serviceInstance = new ConnectionServiceInstance()
			serviceInstance.ucdServer = ucdServer
			serviceInstance._agentManager = new AgentServices(ucdServer)
			serviceInstance._componentManager = new ComponentServices(ucdServer)
			serviceInstance._teamManager = new TeamServices(ucdServer)
			serviceInstance._resourceManager = new ResourceServices(ucdServer)
			serviceInstance._applicationManager = new ApplicationServices(ucdServer)
			serviceInstance._auditHistoryServices = new AuditHistoryServices(ucdServer)
			serviceInstance._processRequestServices = new ProcessRequestServices(ucdServer)
			serviceInstance._statusServices = new StatusServices(ucdServer)
			serviceInstance._securityServices = new SecurityServices(ucdServer)
			serviceInstances[ucdServer] = serviceInstance
		}
	}

	/**
	 * Sets a Process Request property.  The process can be an Application or Component process.
	 * @param processRequestId The ID of a currently running Application or Component process in which
	 * to set the property.
	 * @param propertyName The name of the property.
	 * @param propertyValue The value to set.
	 * @param secure Is this a secure property?
	 */
	public void setProcessRequestProperty( String processRequestId, String propertyName, String propertyValue, boolean secure=false) {
		ProcessApi.setProcessRequestProperty( ucdServer, processRequestId, propertyName, propertyValue, secure )
	}
	/**
	 * Returns the UcdServer connection
	 */
	public UcdServerConnection getUcdServer() {
		return serviceInstance.ucdServer
	}
	
	/**
	 * Returns the ProcessRequest Servce
	 */
	public ProcessRequestServices getProcessRequestServices() {
		return serviceInstance._processRequestServices
	}
	
	/**
	 * Returns the Agent Manager.
	 */
	public AgentServices getAgentServices() {
		return serviceInstance._agentManager
	}
	
	/**
	 * Returns the Component Manager.
	 */
	public ComponentServices getComponentServices() {
		return serviceInstance._componentManager
	}

	/**
	 * Returns the Component Manager.
	 */
	public AuditHistoryServices getAuditHistoryServices() {
		return serviceInstance._auditHistoryServices
	}
	
	/**
	 * Returns the Team Manager.
	 */
	public TeamServices getTeamServices() {
		return serviceInstance._teamManager
	}
	
	/**
	 * Returns the Resource service manager.
	 */
	public ResourceServices getResourceServices() {
		return serviceInstance._resourceManager
	}
	
	/**
	 * Returns the application services.
	 */
	public ApplicationServices getApplicationServices() {
		return serviceInstance._applicationManager
	}
	
	/**
	 * Returns the status services.
	 */
	public StatusServices getStatusServices() {
		return serviceInstance._statusServices
	}
	
	/**
	 * Returns the Security Services.
	 */
	public SecurityServices getSecurityServices() {
		return serviceInstance._securityServices
	}
}
