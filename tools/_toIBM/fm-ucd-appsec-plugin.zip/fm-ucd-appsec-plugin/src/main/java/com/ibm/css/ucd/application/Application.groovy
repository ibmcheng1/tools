package com.ibm.css.ucd.application

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.application.ApplicationApi
import com.ibm.css.rest.ucd.environment.EnvironmentApi
import com.ibm.css.rest.ucd.snapshot.SnapshotApi
import com.ibm.css.ucd.applicationtemplate.ApplicationTemplate
import com.ibm.css.ucd.common.EntityWithNameAndId
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.environmenttemplate.EnvironmentTemplate
import com.ibm.css.ucd.property.Property
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.css.ucd.snapshot.Snapshot
import com.ibm.issr.core.log.Logger
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPut

/**
 * UCD Application Entity.  Represents one existing UCD Application.
 * @author ltclark
 *
 */
class Application extends EntityWithNameAndId {
	// Cached set of entries for this entity.
	//	key = UcdServerConnection
	//	value = Map where
	//		key = id
	//		value = entity class, such as Application or Environment
	static protected Map cache = [:]
	
	// Cached internal data
	private def _cached_Info = null
	private List _cached_components = null
	
	// Handle to ApplicationApi Instance
	ApplicationApi applicationApiInstance
	EnvironmentApi environmentApiInstance
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 */
	public Application( UcdServerConnection ucdServer, String name, String id ) {
		super( ucdServer, name, id )
		applicationApiInstance = new ApplicationApi(ucdServer)
		environmentApiInstance = new EnvironmentApi(ucdServer)
	}
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param info Info returned with a REST call to load Application data.  At a 
	 * minimum, this has a name and id field.
	 */
	public Application( UcdServerConnection ucdServer, def info ) {
		super( ucdServer, info.name, info.id )
		_cached_Info = info
		applicationApiInstance = new ApplicationApi(ucdServer)
		environmentApiInstance = new EnvironmentApi(ucdServer)
	}

	/**
	 * Returns the raw REST information for the Application.  Generally, you should call
	 * specific functions, such as getDateCreated().  Note that the information is cached.
	 */
	public def getInfo( boolean resetCache = false ) {
		if ((! _cached_Info) || resetCache) {
			_cached_Info = applicationApiInstance.getApplicationInfo( getId() )
		}
		return _cached_Info
	}
	
	/**
	 * Cached creation of new entities.  If the entity is already in the cache, the existing entity
	 * is returned.  Otherwise, a new entity is created, added to the cache and returned.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 * @return The requested entity.
	 */
	public static Application getApplicationWithCache( UcdServerConnection ucdServer, String name, String id ) {
		if (! cache.containsKey(ucdServer)) {
			cache[ucdServer] = [:]
		}
		if (! cache[ucdServer].containsKey(id)) {
			cache[ucdServer][id] = new Application( ucdServer, name, id )
		}
		return cache[ucdServer][id]
	}
	
	/**
	 * Standard equality test, which returns true if the other object is the same application.
	 */
	public boolean equals( Object o ) {
		return (o instanceof Application && o.name==this.name && o.id==this.id)
	}
	
	/**
	 * Does the named child environment exist? 
	 * @param environmentName
	 * @return The name of the environment.
	 */
	public boolean doesEnvironmentExist( String environmentName ) {
		return EnvironmentApi.doesEnvironmentExist( ucdServer, this.id, environmentName )
	}
	
	/**
	 * Returns the named child environment throwing an exception if it doesn't exist.
	 * @param environmentName The name of the child environment.
	 * @return A UCD Environment entity.
	 */
	public Environment getEnvironment( String environmentName ) {
		return new Environment( ucdServer, this, EnvironmentApi.getEnvironmentInfo(ucdServer, this.id, environmentName ))
	}
	
	/**
	 * Returns a List of all of the environments.  Each entry in the list is an 'Environment' type.
	 */
	public List getEnvironments() {
		List rawList = applicationApiInstance.getEnvironmentsInApplication( this.id )
		List environmentList = []
		rawList.each { def entry ->
			environmentList << Environment.getEnvironmentWithCache( ucdServer, this, entry.name, entry.id )
		}
		return environmentList
	}
	
	/**
	 * Creates a new environment based on an Environment Template.  Throws exception if creation fails.
	 * @param environmentName
	 * @param environmentTemplate
	 * @return The new environment.
	 */
	public Environment createEnvironmentFromTemplate( String environmentName, EnvironmentTemplate environmentTemplate, String description='' ) {
		environmentApiInstance.createEnvironmentFromTemplate( this.id, environmentTemplate.id, environmentName, description )
		// clear the cache
		_cached_Info = null
		// load the newly created environment
		return getEnvironment(environmentName)
	}
	
	/**
	 * Creates and returns a new child environment with the given name.  If the environment already exists, an exception will be thrown.
	 * Note that sometimes UCD automatically assigns teams to new environments.  This function makes sure that the new team has no environments.
	 * This supports named parameters, such as
	 * app.createEnvironment( environmentName, color: '%23ff0000', requireApprovals: true )
	 * @param namedParams For passing named parameters.  Supported are String description,
	 * String color (which is an RGB value), boolean requireApprovals and boolean
	 * noSelfApprovals.
	 * @param environmentName The name of the new child environment.
	 * @return The new UCD Environment instance.
	 */
	public Environment createEnvironment( String environmentName, Map namedParams=null ) {
		EnvironmentApi.createEnvironment( ucdServer, this.id, environmentName, namedParams )
		
		// clear the cache
		_cached_Info = null
		
		Environment environment = this.getEnvironment(environmentName)
		
		// Make sure that there are no teams.  UCD likes to automatically assign teams to new environments
		EnvironmentApi.removeLinksToAllTeams(ucdServer, environment.id)
		
		return environment
	}
	
	/**
	 * If the environment doesn't exist yet, create it.  In either case, return the new or existing Environment.
	 * @param environmentName The name of the new child environment.
	 * @return The UCD Environment instance.
	 */
	public Environment getOrCreateEnvironment( String environmentName ) {
		if (doesEnvironmentExist(environmentName)) {
			return this.getEnvironment(environmentName)
		} else {
			return createEnvironment( environmentName )
		}
	}
	
	/**
	 * Creates a new, empty Snapshot for this Application.
	 * @param name The name of the snapshot.  Note that snapshot names MUST be unique within
	 * an Application.
	 * @param description A description of the snapshot.
	 * @return The new Snapshot instance.
	 */
	public Snapshot createSnapshot( String name, String description='' ) {
		def payload = [
			application: this.id,
			name: name,
			description: description
		]
		def responseObject = (new RestPut( ucdServer )).setPath("/cli/snapshot/createSnapshot")
				.setJsonPayloadToObject(payload)
				.putAsObject()
		String snapshotId = responseObject.id
		return new Snapshot( ucdServer, name, snapshotId )
	}

	/**
	 * Does this application have a snapshot with the given name?
	 * @param snapshotName The name of the snapshot.
	 */
	public Snapshot doesSnapshotExist( String snapshotName ) {
		return SnapshotApi.doesSnapshotExist(ucdServer, this.getId(), snapshotName)
	}

	/**
	 * Returns the named snapshot.  Throws exception if it doesn't exist.
	 * @param snapshotName The name of the snapshot.
	 */
	public Snapshot getSnapshot( String snapshotName ) {
		String snapshotId = SnapshotApi.getSnapshotId(ucdServer, this.getId(), snapshotName)
		return new Snapshot( ucdServer, snapshotName, snapshotId )
	}
	
	/**
	 * Returns the newest snapshot that has the given Snapshot Status flag.  If no matches are found,
	 * then this returns null.
	 * @param statusName The Snapshot Status to match.
	 */
	public Snapshot getNewestSnapshotWithStatus( String statusName ) {
		Snapshot retval = null
		 
		Logger.debug "getNewestSnapshotWithStatus( statusName='${statusName}' ) called"
		
		// These fields are set to a non-empty value when a matching version is found.
		String matchingSnapshotId = ""
		String matchingSnapshotName = ""
		int matchingSnapshotCreated = 0
		
		// Get the list of Snapshots in the Application
		List snapshots = SnapshotApi.getSnapshotsInApplication( ucdServer, this.getId() )
		snapshots.each { def snapshot ->
			Logger.debug " - Snapshot found named '${snapshot.name}'"
			
			// Get the list of Snapshot Statuses for this Snapshot
			List snapshotStatuses = SnapshotApi.getSnapshotStatusList( ucdServer, snapshot.id )
			snapshotStatuses.each { def snapshotStatus ->
				Logger.debug "     - Snapshot Status: ${snapshotStatus.name}"
				if (snapshotStatus.name == statusName) {
					// FOUND A MATCH
					boolean useNewMatch = false
					if (matchingSnapshotId) {
						// There is already a match.  If the new match is newer, use it
						if (matchingSnapshotCreated < snapshot.create) {
							useNewMatch = true
						}
					} else {
						useNewMatch = true
					}
					if (useNewMatch) {
						matchingSnapshotId = snapshot.id
						matchingSnapshotName = snapshot.name
						matchingSnapshotCreated = snapshot.created
					}
				}
			}
		}
		
		if (matchingSnapshotId) {
			retval = new Snapshot(ucdServer, matchingSnapshotName, matchingSnapshotId)
		}
		
		return retval

	}
	
	/**
	 * Adds the component to this application.
	 * @param component Component.
	 */
	public void addComponent( Component component ) {
		ApplicationApi.addComponentToApplication(ucdServer, this.name, component.name)
	}
	
	/**
	 * Returns the date that this application was created.
	 */
	public Date getDateCreated( boolean resetCache = false ) {
		return getCreated(resetCache)
	}
	
	/**
	 * Returns the name of the person that created the application.
	 */
	public String getCreatingUsername( boolean resetCache = false ) {
		return this.getUser( resetCache )
	}
	
	/**
	 * Returns the List of Component's that are in this application.  Specifically, returns a List
	 * of type Component.
	 * @param resetCache If true, then this bypasses any cached information and makes REST calls
	 * to get the current list of components.
	 */
	public List getComponents( boolean resetCache = false ) {
		if (! _cached_components) {
			List rawList = applicationApiInstance.getComponentsInApplication( this.id )
			_cached_components = []
			rawList.each { def entry ->
				_cached_components << new Component( ucdServer, entry.name, entry.id )
			}
		}
		return _cached_components
	}
	
	/**
	 * Does this application have a component with the given name??
	 */
	public boolean hasComponent( String componentName, boolean resetCache = false ) {
		List components = this.getComponents(resetCache)
		Component component = components.find { Component component ->
			return component.name == componentName
		}
		return component
	}

	/**
	 * Returns the member component by name throwing exception if not found.
	 */
	public Component getComponent( String componentName, boolean resetCache = false ) {
		List components = this.getComponents(resetCache)
		Component component = components.find { Component component ->
			return component.name == componentName
		}
		if (! component) {
			throw new Exception( "Unable to find a component named '" + componentName + "' in application " + this.name)
		}
		return component
	}
	
	/**
	 * Does this application have a component with the given id??
	 */
	public boolean hasComponentById( String componentId, boolean resetCache = false ) {
		List components = this.getComponents(resetCache)
		Component component = components.find { Component component ->
			return component.id == componentId
		}
		return component
	}

	/**
	 * Returns the member component by ID throwing exception if not found.
	 */
	public Component getComponentById( String componentId, boolean resetCache = false ) {
		List components = this.getComponents(resetCache)
		Component component = components.find { Component component ->
			return component.id == componentId
		}
		if (! component) {
			throw new Exception( "Unable to find a component with ID " + componentId + " in application " + this.name)
		}
		return component
	}
	
	/**
	 * Is this application based on an application template?
	 */
	public boolean hasApplicationTemplate() {
		def info = this.getInfo()
		return (info.containsKey('templateId') && info.templateId)
	}
	
	/**
	 * Returns the ApplicationTemplate for this application.  Throws exception if this
	 * Application is doesn't have an applicaiton template.
	 */
	public ApplicationTemplate getApplicationTemplate() {
		def info = this.getInfo()
		if (info.containsKey('templateId') && info.templateId) {
			return (new UcdConnectionServices(ucdServer)).getApplicationServices().getApplicationTemplateById( info.templateId )
		} else {
			throw new Exception( "The application named '" + this.name + "' does not have an application template")
		}
	}
	
	/**
	 * Returns ALL application properties include template and non-template properties.
	 * @return
	 */
	public List getAllApplicationProperties() {
		List props = getApplicationProperties()
		props.addAll( getBasicProperties() )
		return props
	}
	
	/**
	 * Does this application have the given 'application property' as an applicaiton or app template property.
	 * ApplicationProperties are the properties defined in the 'Application Properties' section of the
	 * Application's Configuration page (in the Web UI).  They do NOT include any template defined properties
	 * (at least as of version 7.0).
	 */
	public boolean hasAllApplicationProperty( String name ) {
		return getAllApplicationProperties().find { Property property ->
			return property.name == name
		}
	}
	
	/**
	 * Returns the named application property throwing an exception if not found - as an applicaiton or app template property
	 * ApplicationProperties are the properties defined in the 'Application Properties' section of the
	 * Application's Configuration page (in the Web UI).  They do NOT include any template defined properties
	 * (at least as of version 7.0).
	 */
	public Property getAllApplicationProperty( String name ) {
		Property property = getAllApplicationProperties().find { Property property ->
			return property.name == name
		}
		if (property) {
			return property
		} else {
			throw new Exception( "Unable to find the application property named '${name}' in Application '${this.name}'" )
		}
	}

	/**
	 * Returns List of the ApplicationProperties for this Application.
	 * ApplicationProperties are the properties defined in the 'Application Properties' section of the
	 * Application's Configuration page (in the Web UI).  They do NOT include any template defined properties
	 * (at least as of version 7.0).
	 * @return List of type
	 * {@link com.ibm.css.ucd.property.Property Property}.
	 * Returns the 'basic' properties, which are the properties defined by the application's template, as a
	 * List of 'Property' values.
	 */
	public List getApplicationProperties() {
		List properties = []
		
		List propList = (new RestGet( ucdServer ))
			.setPath("/cli/application/getProperties")
			.addParameter("application", this.id)
			.getAsObject()
		propList.each { Map entry ->
			properties << new Property(entry.name, entry.description, entry.secure, entry.value)
		}
		
		return properties
	}
	
	/**
	 * Does this application have the given 'application property'.
	 * ApplicationProperties are the properties defined in the 'Application Properties' section of the
	 * Application's Configuration page (in the Web UI).  They do NOT include any template defined properties
	 * (at least as of version 7.0).
	 */
	public boolean hasApplicationProperty( String name ) {
		return getApplicationProperties().find { Property property ->
			return property.name == name
		}
	}
	
	/**
	 * Returns the named application property throwing an exception if not found
	 * ApplicationProperties are the properties defined in the 'Application Properties' section of the
	 * Application's Configuration page (in the Web UI).  They do NOT include any template defined properties
	 * (at least as of version 7.0).
	 */
	public Property getApplicationProperty( String name ) {
		Property property = getApplicationProperties().find { Property property ->
			return property.name == name
		}
		if (property) {
			return property
		} else {
			throw new Exception( "Unable to find the application property named '${name}' in Application '${this.name}'" )
		}
	}

	/**
	 * Returns List of the Basic Properties for this Application.
	 * The Basic Properties are properties that are defined in the corresponding Application Templates 
	 * 'Application Property Definitions' Configuration page.  Within the Application, these properties appear
	 * on the 'Basic Settings' Configuration page.
	 * @return List of type
	 * {@link com.ibm.css.ucd.property.Property Property}.
	 * Returns the 'basic' properties, which are the properties defined by the application's template, as a
	 * List of 'Property' values.
	 */
	public List getBasicProperties() {
		List properties = []
		Map info = this.getInfo()
		String namePrefix = 'template/'
		if (info.containsKey('properties')) {
			info.properties.each { Map propertyEntry ->
				String name = propertyEntry.name
				if (name.startsWith(namePrefix)) {
					properties << new Property(propertyEntry.name.substring(namePrefix.length()), propertyEntry.description, propertyEntry.secure, propertyEntry.value)
				}
			}
		}
		return properties
	}
	
	/**
	 * Does this application have the given 'basic property'.
	 * The Basic Properties are properties that are defined in the corresponding Application Templates 
	 * 'Application Property Definitions' Configuration page.  Within the Application, these properties appear
	 * on the 'Basic Settings' Configuration page.
	 */
	public boolean hasBasicProperty( String name ) {
		return getBasicProperties().find { Property property ->
			return property.name == name
		}
	}
	
	/**
	 * Returns the named basic property throwing an exception if not found
	 * The Basic Properties are properties that are defined in the corresponding Application Templates 
	 * 'Application Property Definitions' Configuration page.  Within the Application, these properties appear
	 * on the 'Basic Settings' Configuration page.
	 */
	public Property getBasicProperty( String name ) {
		Property property = getBasicProperties().find { Property property ->
			return property.name == name
		}
		if (property) {
			return property
		} else {
			throw new Exception( "Unable to find the basic property named '${name}' in Application '${this.name}'" )
		}
	}
	
	/**
	 * Does this entity have the given named property?  It may be ad-hoc, managed, etc.  Note that 'NamedProperty' is used
	 * because Groovy has built in functions like 'getProperty', so choosing a different name avoids a collision.
	 */
	public boolean hasNamedProperty( String name ) {
		return hasBasicProperty(name) || hasApplicationProperty(name)	
	}
	
	
	/**
	 * Returns the value of the named property.  It may be ad-hoc, managed, etc.
	 * If the property doesn't exist, then an exception is thrown.  
	 * Note that 'NamedProperty' is used
	 * because Groovy has built in functions like 'getProperty', so choosing a different name avoids a collision.
	 */
	public Property getNamedProperty( String name ) {
		if (hasBasicProperty(name)) {
			return getBasicProperty(name)
		} else if (hasApplicationProperty(name)) {
			return getApplicationProperty(name)
		} else {
			throw new Exception( "Unable to find the property named '${name}' in Application '${this.name}'" )
		}
	}

	public boolean isActive( boolean resetCache=false ) {
		boolean fieldValue
		
		Map entityData = getInfo( resetCache ) 
		if (entityData.containsKey('active')) {
			fieldValue = entityData['active']
		}
		
		return fieldValue
	}


	public int getComponentCount( boolean resetCache=false ) {
		int fieldValue
		
		Map entityData = getInfo( resetCache ) 
		if (entityData.containsKey('componentCount')) {
			fieldValue = entityData['componentCount']
		}
		
		return fieldValue
	}


	public long getCreated( boolean resetCache=false ) {
		long fieldValue
		
		Map entityData = getInfo( resetCache ) 
		if (entityData.containsKey('created')) {
			fieldValue = entityData['created']
		}
		
		return fieldValue
	}


	public boolean isDeleted( boolean resetCache=false ) {
		boolean fieldValue
		
		Map entityData = getInfo( resetCache ) 
		if (entityData.containsKey('deleted')) {
			fieldValue = entityData['deleted']
		}
		
		return fieldValue
	}


	public String getDescription( boolean resetCache=false ) {
		String fieldValue
		
		Map entityData = getInfo( resetCache ) 
		if (entityData.containsKey('description')) {
			fieldValue = entityData['description']
		}
		
		return fieldValue
	}


	public boolean isEnforceCompleteSnapshots( boolean resetCache=false ) {
		boolean fieldValue
		
		Map entityData = getInfo( resetCache ) 
		if (entityData.containsKey('enforceCompleteSnapshots')) {
			fieldValue = entityData['enforceCompleteSnapshots']
		}
		
		return fieldValue
	}


	public String getSecurityResourceId( boolean resetCache=false ) {
		String fieldValue
		
		Map entityData = getInfo( resetCache ) 
		if (entityData.containsKey('securityResourceId')) {
			fieldValue = entityData['securityResourceId']
		}
		
		return fieldValue
	}


	public String getTemplateId( boolean resetCache=false ) {
		String fieldValue
		
		Map entityData = getInfo( resetCache ) 
		if (entityData.containsKey('templateId')) {
			fieldValue = entityData['templateId']
		}
		
		return fieldValue
	}


	public int getTemplateVersion( boolean resetCache=false ) {
		int fieldValue
		
		Map entityData = getInfo( resetCache ) 
		if (entityData.containsKey('templateVersion')) {
			fieldValue = entityData['templateVersion']
		}
		
		return fieldValue
	}


	public String getUser( boolean resetCache=false ) {
		String fieldValue
		
		Map entityData = getInfo( resetCache ) 
		if (entityData.containsKey('user')) {
			fieldValue = entityData['user']
		}
		
		return fieldValue
	}

}
