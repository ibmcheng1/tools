package com.ibm.css.rest.ucd.application.process

/**
 * API Wrapper for ApplicationProcess calls.
 * @author ltclark
 *
 */
class ApplicationProcessApi {

}
