package com.ibm.services.ucr.api.entity.changetype

import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.framework.UcrEntityData
import com.ibm.services.ucr.api.framework.UcrEntityDataFormat
import com.ibm.services.ucr.api.framework.UcrEntityWithNameAndId

/**
 * One UCR ChangeType record.
 * @author LeonClark
 *
 */
class UcrChangeType extends UcrEntityWithNameAndId {
	// Cached instance of 'UcrEntityData'
	private RestDataCache _cachedEntityData = new RestDataCache()
	
	/**
	 * This constructor should only be called by this entity's Mgr class.
	 */
	UcrChangeType( RestServerConnection ucrServer, String name, String id ) {
		super( ucrServer, name, id )
	}
	
	/**
	 * Constructor based on the 'restInfo'
	 * @param ucrServer
	 * @param restInfo
	 */
	UcrChangeType( RestServerConnection ucrServer, UcrEntityData restEntity ) {
		super( ucrServer, restEntity.entityObject.name, restEntity.entityObject.id )
		_cachedEntityData.setCacheData( ucrServer, restEntity )
	}
	
	/**
	 * Resets the cached data storing internal data for this class instance.
	 */
	public void resetCachedData() {
		_cachedEntityData.resetCacheData(ucrServer)
	}

	/**
	 * Returns the UcrEntityData for this class, which is the underlying REST/JSON based data structure.
	 */
	public UcrEntityData getEntityData( boolean resetCache = false ) {
		UcrEntityData restEntity = (UcrEntityData) _cachedEntityData.getCacheData(ucrServer,resetCache)
		if (! restEntity) {
			def entityData = (new RestGet(ucrServer))
				.setPath('/changeTypes/' + this.id)
				.setHeader('Accept', 'application/json, application/javascript, text/javascript')
				.getAsObject()
			restEntity = new UcrEntityData( entityData, UcrEntityDataFormat.LIST_FORMAT )
			_cachedEntityData.setCacheData( ucrServer, restEntity )

		}
		return restEntity
	}
}
