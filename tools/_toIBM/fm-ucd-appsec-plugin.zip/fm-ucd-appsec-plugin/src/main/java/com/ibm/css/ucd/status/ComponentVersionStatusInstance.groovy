package com.ibm.css.ucd.status;

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.common.EntityWithNameAndId
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.services.UcdConnectionServices

/**
 * Represents a specific instance (tied to a specific ComponentVersion) of a ComponentVersionStatus.
 *
 * @author LeonClark
 *
 */
public class ComponentVersionStatusInstance extends EntityWithNameAndId {
	private ComponentVersion componentVersion
	
	/**
	 * The component version status is loaded on demand.
	 */
	private ComponentVersionStatus componentVersionStatus

	public ComponentVersionStatusInstance(UcdServerConnection ucdServer, ComponentVersion componentVersion, String name,
			String id) {
		super(ucdServer, name, id);
		this.componentVersion = componentVersion
	}
		
	/**
	 * Returns the associated ComponentVersion.
	 */
	public ComponentVersion getComponentVersion() {
		return componentVersion
	}
	
	/**
	 * Returns the instance independent ComponentVersionStatus.
	 */
	public ComponentVersionStatus getComponentVersionStatus() {
		if (! componentVersionStatus) {
			componentVersionStatus = (new UcdConnectionServices(ucdServer)).getStatusServices().getComponentVersionStatus(this.name)
		}
		return componentVersionStatus
	}

}
