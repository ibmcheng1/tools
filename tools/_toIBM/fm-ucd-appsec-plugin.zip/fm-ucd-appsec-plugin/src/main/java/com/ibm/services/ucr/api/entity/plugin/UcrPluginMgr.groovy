package com.ibm.services.ucr.api.entity.plugin

import com.ibm.issr.core.entity.IndexedListOfEntities
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.framework.DataQueryFilter
import com.ibm.services.ucr.api.framework.UcrEntityData
import com.ibm.services.ucr.api.framework.UcrEntityDataFormat


/**
 * Manager class for the entity, which includes entity creation and lookup functions.
 * This is a 'RestServerConnection linked Singleton' class - there is one and only one
 * instance of this class for each associated RestServerConnections.
 * @author LeonClark
 *
 */
class UcrPluginMgr {
	
	// Map of the singleton instances of this class.  Key=RestServerConnection, value=instance of this class
	private static Map _singletons = [:]
	
	// The server for this instance of the Mgr
	RestServerConnection ucrServer
	
	/**
	 * Cached 'List' of ALL Of the entities.  Each entry is of type UcrPlugin.
	 */
	private RestDataCache _cachedCompleteList = new RestDataCache()
	 
	/**
	 * Cached list of loaded entities.  The data type of the cache is IndexedListOfEntities, which is
	 * automatically initialized when the cache is created or resest.
	 */
	RestDataCache _entityCache = new RestDataCache(
		// Cache entry initialization closure - Initialize cache entries as instances of IndexedListOfEntities
		{ RestServerConnection ucrServer ->
			return new IndexedListOfEntities(
				// This closure returns the 'uniqueName' for each entry, which is simply the name
				{ UcrPlugin entity ->
					return entity.getName()
				} 
				)
		}
		) 
	
	/**
	 * Private constructor.
	 * @param ucrServer The associated Rest Server.
	 */
	private UcrPluginMgr( RestServerConnection ucrServer ) {
		this.ucrServer = ucrServer
	}
	
	/**
	 * Returns the singleton instance of this class for the given Rest Server.
	 */
	public static UcrPluginMgr getInstance( RestServerConnection ucrServer ) {
		if (! _singletons.containsKey(ucrServer)) {
			_singletons[ucrServer] = new UcrPluginMgr(ucrServer)
		}
		return _singletons[ucrServer]
	}
	
	/**
	 * Returns the list of UcrPlugins's.
	 */
	public List getAll( boolean resetCache = false ) {
		if (resetCache) {
			_entityCache.resetCacheData(ucrServer)
		}
		List entityList = _cachedCompleteList.getCacheData( ucrServer, resetCache )
		if (! entityList) {
			// Load the list via REST calls
			entityList = []
			List rawEntityList = (new RestGet( ucrServer ))
					.setPath('/plugins/')
					.setHeader('Accept', 'application/json')
					.getAsObject()
			// convert to entities
			rawEntityList.each { def rawEntity ->
				entityList << buildEntity( ucrServer, new UcrEntityData( rawEntity, UcrEntityDataFormat.LIST_FORMAT ) )
			}
			_cachedCompleteList.setCacheData(ucrServer, entityList)
		}
		return entityList
	}
	
	/**
	 * Returns the UcrPlugin by ID.  Throws exception if not found.
	 */
	public UcrPlugin getById( String id, boolean resetCache=false ) {
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer, resetCache)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			return cachedEntities.getEntityById(id)
		} else {
			// not found in cache - make rest call to load it
			def rawEntityData = (new RestGet( ucrServer ))
					.setPath("/plugins/${id}")
//					.addParameter('format', 'detail')
					.setHeader('Accept', 'application/json')
					.getAsObject()
			// Convert the raw data into an entity
			return buildEntity( ucrServer, new UcrEntityData(rawEntityData, UcrEntityDataFormat.LIST_FORMAT ))
		}
	}

	/**
	 * Returns the named UcrPlugin.  Throws exception if not found.
	 */
	public UcrPlugin getByName( String name, boolean resetCache=false ) {
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer, resetCache)
		// Check the cache first
		if (cachedEntities.containsEntityByUniqueName(name)) {
			return cachedEntities.getEntityByUniqueName(name)
		} else {
			// not found in cache - make rest call to load it
			def rawEntityData = (new RestGet( ucrServer ))
					.setPath('/plugins/')
//					.addParameter('format', 'detail')
					.callClosure { RestGet restGet ->
						DataQueryFilter.defineFilter(restGet, 'name', DataQueryFilter.FilterClass.STRING, 
							DataQueryFilter.FilterType.EQUALS, name )
					}
					.setHeader('Accept', 'application/json')
					.getFirstElementInListAsObject()
			// Convert the raw data into an entity
			return buildEntity( ucrServer, new UcrEntityData(rawEntityData, UcrEntityDataFormat.LIST_FORMAT ))
		}
	}
	
	/**
	 * Returns the UcrPlugin by 'plugin ID'.  Note that the plugin ID is the
	 * internal package style plugin id, such as 'com.sample.ucr.myplugin'.  This is different than the
	 * 'name' or the 'id'.  Throws exception if not found.
	 */
	public UcrPlugin getByPluginId( String pluginId, boolean resetCache=false ) {
		// I attempted to do a filtered get, but it failed.  Instead, get all and iterate to find the match
		UcrPlugin matchingPlugin = getAll(resetCache).find { UcrPlugin candidatePlugin ->
			return (candidatePlugin.getEntityData().entityObject.pluginId == pluginId)
		}
		if (! matchingPlugin) {
			throw new Exception( "Unable to find a UCR Plugin with a plugin ID of " + pluginId )
		}
		return matchingPlugin
	}

	/**
	 * Given entity data, this returns a UcrPlugin for that data.
	 * @param ucrServer The server.
	 * @param entityData The data returned from some REST call.
	 * @return New or existing entity.
	 */
	public UcrPlugin buildEntity( RestServerConnection ucrServer, UcrEntityData entityData ) {
		UcrPlugin entity
		String name = entityData.getEntityObject().name
		String id = entityData.getEntityObject().id
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			entity = cachedEntities.getEntityById(id)
			// Update the cached entityData
		} else {
			entity = new UcrPlugin( ucrServer, name, id, entityData )
			cachedEntities.addEntity(entity)
		}
		return entity
	}

}
