package com.ibm.css.ucd.component.version.addfiles

import com.ibm.issr.core.file.filter.FilterFiles

/**
 * Defines one Base Directory for the Closure parameter to
 * {@link com.ibm.css.ucd.component.version.ComponentVersion#addFiles(groovy.lang.Closure) ComponentVersion.addFiles()}
 * @author LeonClark
 *
 */
class BaseDirectoryDefinition {
	private FilterFiles _filterFiles
	private boolean _saveExecutionBits = false

	/**
	 * Constructor.
	 * @param filterFiles This is the class that performs the actual filter.  It also stores the 
	 */
	public BaseDirectoryDefinition( FilterFiles filterFiles ) {
		this._filterFiles = filterFiles
	}
	
	/**
	 * Defines a set of file(s) to include.
	 * This is part of the Closure DSL called by 
	 * {@link com.ibm.css.ucd.component.version.ComponentVersion#addFiles(groovy.lang.Closure) ComponentVersion.addFiles()}
	 * @param pattern Supports Apache Ant style wildcards.
	 */
	void include( String pattern ) {
		_filterFiles.addInclude( pattern )
	}

	/**
	 * Defines a set of file(s) to exclude.  Note that exclusion has higher precedence than includes.
	 * This is part of the Closure DSL called by 
	 * {@link com.ibm.css.ucd.component.version.ComponentVersion#addFiles(groovy.lang.Closure) ComponentVersion.addFiles()}
	 * @param pattern Supports Apache Ant style wildcards.
	 */
	void exclude( String pattern ) {
		_filterFiles.addExclude(pattern)
	}

	/**
	 * Indicates if execution file flags should be preserved.
	 * This is part of the Closure DSL called by 
	 * {@link com.ibm.css.ucd.component.version.ComponentVersion#addFiles(groovy.lang.Closure) ComponentVersion.addFiles()}
	 * @param pattern Supports Apache Ant style wildcards.
	 */
	void saveExecutionBits( boolean save=true ) {
		_saveExecutionBits = save
	}
	
	/**
	 * Returns the value of the 'saveExecutionBits' flag. 
	 */
	public boolean isSaveExecutionBits() {
		return _saveExecutionBits
	}
}
