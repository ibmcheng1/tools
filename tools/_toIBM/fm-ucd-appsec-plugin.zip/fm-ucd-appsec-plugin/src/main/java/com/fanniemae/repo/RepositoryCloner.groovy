package com.fanniemae.repo

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPost

class RepositoryCloner {
	UcdServerConnection ucdServer
	
	/**
	 * Constructor.
	 * @param ucdServer The associated UCD Server.
	 */
	public RepositoryCloner(UcdServerConnection ucdServer) {
		this.ucdServer = ucdServer
	}

	/**
	 * Clones repository.
	 * @param workingPath The path to retrieve the files to.
	 * @param assetId
	 * @param repoURL
	 * @param codeCommitHash
	 * @return List - first element is a 'boolean success' flag.  Second element is a detailed error message.
	 */
	public List cloneRepository( String genericProcessName, String resourcePath, String workingPath, String assetId, String repoURL, String branch, String codeCommitHash, String envType,
		String awsAccountId, String awsRole, String awsRegion ) {
		boolean success = false
		String errorMsg = ''
		try {
			String processId = getGenericProcessId(genericProcessName)
			
			String requestId
			String hyperlink
			(requestId, hyperlink) = callGenericProcess( processId, resourcePath, workingPath, repoURL, branch, codeCommitHash, envType, awsAccountId, awsRole, assetId, awsRegion )

			Logger.info "Started generic process to clone repository - " + hyperlink
			
			if (! waitForGenericProcessToEnd( requestId )) {
				// nested generic process failed
				success = false
				errorMsg = "unable to retrieve source code from repository.  Call to nested process '${hyperlink}' failed"
			} else {
				success = true
			}
		}
		catch (Exception e) {
			Logger.printStackTrace(LoggerLevel.ERROR, e)
		}
		return [success,errorMsg]
	}
	
	
	/**
	 * Finds and returns the ID of the named generic process.  Throws exception if not found.
	 */
	public String getGenericProcessId( String genericProcessName ) {
		String processId = ''
		// get list of all generic processes
		List genericProcesses = (new RestGet(ucdServer))
			.setPath( '/cli/process')
			.getAsObject()
		// search the list for this one
		genericProcesses.each { Map genericProcess ->
			if (genericProcess.name == genericProcessName) {
				processId = genericProcess.id
			}
		}
		if (! processId) {
			throw new Exception( "Unable to find a Generic Process named '${genericProcessName}'")
		}
		return processId
	}

	/**
	 * Calls generic process.  Throws exception on failure.
	 * @param ucdServer
	 * @param processId The generic proceess' id
	 * @return List with the following ordered values 'requestId' and 'requestHyperlink'
	 */
	private List callGenericProcess(String processId, String resourcePath, String workingPath, String repoURL, String branch, String codeCommitHash,
		String envType, String awsAccountId, String awsRole, String assetId, String awsRegion ) {
		Map payload = [
			processId: processId,
			resources: [ resourcePath ],
			properties: [ 
				targetDirectory:workingPath, 
				repoUrl:repoURL, 
				commitHash:codeCommitHash,
				branch:branch,
				envType:envType,
				assetId:assetId,
				awsRegion:awsRegion
				]
		]
		if (awsAccountId) {
			payload.properties.accountId = awsAccountId
		}
		if (awsRole) {
			payload.properties.role = awsRole
		}

		List resultObject = (new RestPost( ucdServer ))
				.setPath('/cli/processRequest')
				.setJsonPayloadToObject(payload)
				.postAsObject()
		String requestId = resultObject[0].id

		String requestHyperlink = ucdServer.buildFullUrl( '/#processRequest/' + requestId, [] )
		return [ requestId, requestHyperlink ]
	}
	
	/**
	 * Wait for the Generic Process completion - success or fail.
	 * @param requestId
	 * @return Did it work successfully?
	 */
	private boolean waitForGenericProcessToEnd( String requestId ) {
		// loop until done (pass or fail)
		String processStatus = getProcessStatus(requestId)
		while ((processStatus==null) || !(processStatus.equalsIgnoreCase("CANCELED") || processStatus.equalsIgnoreCase("succeeded") ||
			processStatus.equalsIgnoreCase("faulted") || processStatus.equalsIgnoreCase("FAILED TO START"))) {
			Thread.sleep(3000);
			processStatus = getProcessStatus(requestId)
		}
		if (processStatus.equalsIgnoreCase("succeeded")) {
			Logger.debug "The application process succeeded"
			return true
		} else {
			Logger.debug "The application process failed with message '${p:processStatus}'.  See the application process log for details."
			return false
		}
	}
	
	/**
	 * Returns the status of a called Generic Process.
	 * @param requestId The Generic Process request ID.
	 * @return String result, which is the 'result' value returned by UCD, which may be null.  It looks like null
	 * means that it hasn't started yet.
	 */
	private String getProcessStatus( String requestId ) {
		def statusObj = (new RestGet(ucdServer))
			.setPath( '/cli/processRequest/' + requestId)
			.getAsObject()
		return statusObj.result
	}

}
