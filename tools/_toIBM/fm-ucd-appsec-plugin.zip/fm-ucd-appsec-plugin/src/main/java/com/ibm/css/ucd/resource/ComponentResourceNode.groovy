

package com.ibm.css.ucd.resource

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.cache.RestDataCache;

/**
 * A UCD Resource Tree node for a Component reference.
 * @author ltclark
 *
 */
class ComponentResourceNode extends NonRootResourceNode {
	// Object version of the call to /cli/resource/info
	protected def info
	
	protected String _componentName
	// The cached Component
	protected Component _component = null

	
	/**
	 * Cached list of component version information.  When retrieving version information for a Component node,
	 * you actually make a REST call against the node's PARENT, which returns all version information for all
	 * of the siblings as well, which is horribly inefficient.  So, the case stores the REST call against the
	 * parent.  The cache (for a UCD Server), stores a Map.  The key is the parent's ID.  The value is the
	 * object returned from REST call.
	 */
	static RestDataCache _componentVersionDataCache = new RestDataCache(
		// Cache entry initialization closure - Simply return an empty map
		{ UcdServerConnection ucdServer ->
			return [:]
		}
		)

	/**
	 * Constructor.
	 * @param ucdServer The handle to the UCD Server.
	 * @param parentNode The parent node to this node.
	 * @param info This is an Object version of the call to /cli/resource/info.
	 * Note that it has at least two fields - name and id.
	 */
	public ComponentResourceNode( UcdServerConnection ucdServer, ResourceNode parentNode, def info ) {
		super( ucdServer, parentNode, info.name, info.id )
		this.info = info
		this._componentName = info.role.name
	}

	@Override
	public String getNodeType() {
		return COMPONENT_NODE_TYPE
	}
	
	public Component getComponent() {
		if (! _component) {
			_component = Component.getComponentWithCacheByName(ucdServer, _componentName)
		}
		return _component
	}
	
	/**
	 * Returns the List of 'ComponentVersion's currently deployed to this Component Resource Node.
	 */
	public List getComponentVersions( boolean resetCache = false ) {
		List componentVersions = []
		
		Component component = this.getComponent()
		
		// The ONLY way that I have found to get the component versions is to make a REST call
		// against the component node's parent!!  To make this more efficient, the parent call is cached and indexed
		// with the parent's ID.
		String parentId = this.getParent().id
		
		// The nodes are returned from either (a) the cache or (b) the REST call against the parent
		List nodes
		Map cache = _componentVersionDataCache.getCacheData(ucdServer, resetCache)
		if (cache.containsKey(parentId)) {
			nodes = cache[parentId]
		}
		if (! nodes) {
			nodes = (new RestGet( ucdServer ))
				.setPath("/rest/resource/resource/"+ this.getParent().id +"/resources")
				.getAsObject()
			cache[parentId] = nodes
		}
		
		// This returns siblings as well as this node, so iterate looking for this node
		nodes.each { Map node ->
			if (node.id == this.id) {
				node.versions.each { Map versionData ->
					componentVersions << ComponentVersion.getComponentVersionWithCache(ucdServer, component, versionData.name, versionData.id)
				}
			}
		}
		
		
		return componentVersions
	}

}
