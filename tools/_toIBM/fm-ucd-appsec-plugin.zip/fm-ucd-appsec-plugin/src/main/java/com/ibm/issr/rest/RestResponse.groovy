package com.ibm.issr.rest

import org.apache.http.Header
import org.apache.http.HttpEntity
import org.apache.http.HttpResponse
import org.apache.http.HttpStatus
import org.apache.http.util.EntityUtils

import com.ibm.issr.core.log.LogTracingClass
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.plugin.PluginHelper

/**
 * This is a common Response (which wraps an HttpResponse) which is returned by the
 * various Rest Calls. YOU MUST MAKE SURE TO CALL THE close() FUNCTION WHEN YOU ARE DONE
 * WITH THE RESPONSE in order to free up the HTTP resources.  Otherwise, HTTP calls will
 * start to fail after a few calls.
 * 
 * @author ltclark
 *
 */
class RestResponse extends LogTracingClass {
	RestOperation restOperation
	HttpResponse response							// Response will NOT be null
	private boolean entityProcessed = false;		// has the entity been processed
	private String stringValueOfResponse = ""

	/**
	 * Constructor.
	 * @param restOperation The operation that generated the response.
	 * @param response The actual HttpResponse
	 */
	public RestResponse( RestOperation restOperation, HttpResponse response ) {
		if (! response) {
			PluginHelper.abortPlugin( "Internal error - RestResponse called with a null HttpResponse" )
		}
		this.restOperation = restOperation
		this.response = response
	}

	/**
	 * Convenience method throws an exception if any
	 * value other than OK was returned in this response.
	 * @param isStatusAcceptable This is a closure with the following syntax: boolean isStatusAcceptable( int status ).
	 * It should return true if the given http status code is acceptable for the function call or false if the status
	 * is not acceptable.  See the default value for an example.
	 * @return Return this.
	 */
	public RestResponse throwExceptionOnBadResponse( 
		Closure isStatusAcceptable = { int status -> return (status == HttpStatus.SC_OK || status == HttpStatus.SC_NO_CONTENT) }) {
		assert response
		int status = httpStatus
		Logger.debug "REST call returned status of ${status}"
		if (! isStatusAcceptable(status)) {
			def msg = this.responseAsString
			PluginHelper.abortPlugin( "${this.restOperation.operationName} call to REST (" + this.restOperation.fullUrl + ") failed with code ${status} - ${msg}" )
		}
		return this
	}

	/**
	 * Did the response return an OK response??
	 */
	public boolean isOk() {
		assert response
		int status = response.getStatusLine().getStatusCode();
		return (status == HttpStatus.SC_OK)
	}

	/**
	 * Returns the underlying HTTP Response Status.
	 */
	public int getHttpStatus() {
		assert response
		return response.getStatusLine().getStatusCode()
	}

	/**
	 * Returns the underlying HTTP Response Message.
	 */
	public String getHttpMsg() {
		return this.responseAsString
	}

	/**
	 * Returns the contents of the response as a string.
	 * @return The contents of the response.
	 */
	public String getResponseAsString() {
		assert response
		if (! entityProcessed) {
			entityProcessed = true
			HttpEntity entity = response.getEntity()
			if (entity) {
				stringValueOfResponse = EntityUtils.toString( response.getEntity(), "UTF-8" )
			} else {
				stringValueOfResponse = ""
			}
		}
		Logger.debug("RestResponse of '${stringValueOfResponse}'")
		return stringValueOfResponse;
	}
	
	/**
	 * Writes the contents/entity of the response to an outputStream.
	 */
	public void writeToOutputStream( OutputStream outputStream ) {
		assert response
		response.getEntity().writeTo(outputStream)
	}


	/**
	 * If possible, this will convert the response body into a Java/Groovy object.  Currently,
	 * this only support JSON content, but could be expanded to handle XML content.  Throws
	 * exception if unsupported content found.
	 * When does this return null?  I have run into one UCD rest call (/cli/environment/${environmentId}/snapshot)
	 * which returns ABSOLUTELY nothing if there is no matching snapshot - it doesn't return an error, or a body,
	 * or a response.  So, if this function sees no response, it returns null.  That should be an rare occurence.
	 * @return An object based on the results.  This may return null.
	 */
	public getResponseAsObject() {
		assert response
		if (response && response.getEntity()) {
			Header header = response.getEntity().getContentType();
			if (header.value.indexOf("application/json") >= 0) {
				return (new groovy.json.JsonSlurper()).parseText( this.responseAsString );
			} else {
				throw new Exception( "Internal error: RestResponse.getResponseAsObject() can only process json content.  Actual content is ${header.value}" )
			}
		} else {
			return null
		}
	}
	
	
	/**
	 * For debugging purposes, the standard 'toString' method has been expanded to include
	 * the response code.
	 */
	public String toString() {
		return super.toString() + "[Status = '${httpStatus}']"
	}
	
	/**
	 * Close out the response stream which frees up the HTTP handle.  You MUST call this when done or HTTP
	 * calls will start to fail!!
	 */
	public void close() {
		// response.close();
		// This clears the response as per http://stackoverflow.com/questions/4775618/httpclient-4-0-1-how-to-release-connection
		if (response.getEntity()) {
			response.getEntity().consumeContent();
		}
	}

}
