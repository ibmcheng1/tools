package com.ibm.issr.core.file.filter

import com.ibm.issr.core.log.Logger

/**
 * This class performs an Ant style file filter on a directory.  In fact, it uses
 * Ant to perform the filter.  Note that you must specify a Base Directory and all of
 * the files are relative to that base directory.
 * @author LeonClark
 *
 */
class FilterFiles {
	private String _baseDirectory
	
	/**
	 * List of the 'String include' statements.
	 */
	private List _includes = []
	
	/**
	 * List of the 'String include' statements.
	 */
	private List _excludes = []

	
	/**
	 * Constructor for filtering file names. This class lets you apply a set of includes and
	 * excludes (with wildcard support) to a base directory to return a list of matching
	 * files.  This uses Ant
	 * wildcard syntax.   Note that the wildcard of **&#47;* means all files recursively.
	 * Win
	 * @param baseDirectory This is the base directory for all of the includes and excludes.
	 * This can be an absolute directory or relative to the currently active directory.
	 */
	public FilterFiles( String baseDirectory ) {
		Logger.debug "FilterFiles( baseDir = '${baseDirectory}' )"		
		this._baseDirectory = baseDirectory
	}
	
	/**
	 * <p>Adds an 'include' clause.  This is an Ant style list of files to include, such as **&#47;*</p>
	 * <p>The files are relative to the base directory.</p>
	 * <p>The wildcard syntax is ...</p>
	 * <ul>
	 * <li>? - Match any single character except a path separator (such as '/')</li>
	 * <li>* - Match any number of characters, except a path separator.</li>
	 * <li>** - Match any number of characters, including path separators.
	 * </ul>
	 */
	public void addInclude( String include ) {
		Logger.debug "FilterFiles.addInclude( '${include}' )"		
		_includes << include
	}
	
	/**
	 * <p>Adds an 'exclude' clause.  This is an Ant style list of files to exclude, such as **&#47;*
	 * Note that exclude have higher precedence than include.</p>
	 * <p>The wildcard syntax is ...</p>
	 * <ul>
	 * <li>? - Match any single character except a path separator (such as '/'</li>
	 * <li>* - Match any number of characters, except a path separator.</li>
	 * <li>** - Match any number of characters, including path separators.
	 * </ul>
	 */
	public void addExclude( String exclude ) {
		Logger.debug "FilterFiles.addExclude( '${exclude}' )"		
		_excludes << exclude
	}
	
	/**
	 * <p>Applies the defined filter returning a List of the matching files (of type 'File').
	 * This returns both files and directories.  However, it may not return intermediate
	 * directories.  For example, if you have a base directory relative file
	 * 'dir1/dir2/sample.txt' any you search for '**&#47;*.txt', this returns sample.txt, but
	 * not the directories.  However, if you search for '**', then it returns 'dir1', 'dir1/dir2'
	 * and 'dir1/dir2/sample.txt'.</p>
	 * <p>Note that the base directory can be returned in the list!!</p>
	 */
	public List applyFilter() {
		List files = []
		
		AntBuilder ant = new AntBuilder()
		def scanner = ant.fileScanner {
			fileset(dir: _baseDirectory) {
				_includes.each { String includeRule ->
					if (includeRule != null && includeRule.trim().length() > 0) {
						include(name: includeRule.trim())
					}
				}
				_excludes?.each { String excludeRule ->
					if (excludeRule != null && excludeRule.trim().length() > 0) {
						exclude(name: excludeRule.trim())
					}
				}
			}

		}
		// Iterate the member files
		scanner.each { File file ->
			files << file
		}
		scanner.directories().each { File directory ->
			files << directory
		}

		return files
	}
}
