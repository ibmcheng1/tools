package com.ibm.issr.core.log;

public interface LoggerInterface {

	/**
	 * Logs a 'trace' level message.
	 */
	public abstract void trace(def message);

	/**
	 * Logs a 'debug' level message.
	 */
	public abstract void debug(def message);

	/**
	 * Logs an 'info' level message.
	 */
	public abstract void info(def message);

	/**
	 * Logs a 'warn' level message.
	 */
	public abstract void warn(def message);

	/**
	 * Logs an 'error' level message.
	 */
	public abstract void error(def message);

	/**
	 * Logs a 'fatal' level message.
	 */
	public abstract void fatal(def message);

	/**
	 * The intent of this logging statement is to display a message as part
	 * of a temporary debugging session and that the debugSession() call
	 * will be deleted when the debugging session is done!!  This force
	 * output the message regardless of the logging level.
	 */
	public abstract void debugSession(def message);

	/**
	 * Prints a message to the designated log level.
	 * @param loggerLevel Log level enumeration, such as LoggerLevel.INFO
	 * @param message The message to print.
	 */
	public abstract void println(LoggerLevel loggerLevel, def message);

	/**
	 * This prints an {@link Exception}/Throwable stack trace by printing the 
	 * stack to the log level associated with loggerLevel.
	 * @param loggerLevel An enumerated value for the appropriate log level, such as LoggerLevel.DEBUG
	 * @param e The exception.
	 */
	public abstract void printStackTrace(LoggerLevel loggerLevel, Throwable e);

}