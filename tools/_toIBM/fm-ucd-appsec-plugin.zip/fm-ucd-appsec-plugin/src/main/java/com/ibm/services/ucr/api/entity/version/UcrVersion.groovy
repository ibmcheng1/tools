

package com.ibm.services.ucr.api.entity.version

import com.ibm.issr.core.entity.EntityWithId
import com.ibm.issr.core.url.UrlUtilities;
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPost;
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.entity.application.UcrApplication
import com.ibm.services.ucr.api.entity.status.UcrStatus
import com.ibm.services.ucr.api.entity.status.UcrStatusMgr;
import com.ibm.services.ucr.api.entity.versionstatus.UcrVersionStatus
import com.ibm.services.ucr.api.entity.versionstatus.UcrVersionStatusMgr
import com.ibm.services.ucr.api.framework.UcrEntityData
import com.ibm.services.ucr.api.framework.UcrEntityDataFormat
import com.ibm.services.ucr.api.framework.UcrEntityWithNameAndId

/**
 * UCR Version Entity
 *
 * @author LeonClark
 *
 */
class UcrVersion extends UcrEntityWithNameAndId implements EntityWithId {
	// The cache of the UcrEntityData for this entity
	private RestDataCache _cachedEntityData = new RestDataCache()
	
	private UcrApplication _application
	
	/**
	 * Private constructor - do NOT call directly from any other class.
	 * @param application The application which this version belongs to.
	 * @param entityData This is optional UcrEntityData (data returned from a REST call defining this entity).  If
	 * given, then it is cached.
	 */
	private UcrVersion( RestServerConnection ucrServer, UcrApplication application, String name, String id, UcrEntityData entityData = null ) {
		super( ucrServer, name, id )
		if (entityData) {
			_cachedEntityData.setCacheData(ucrServer, entityData)
		}
		this._application = application
	}
	
	/**
	 * Resets the cached data storing internal data for this class instance.
	 */
	public void resetCachedData() {
		_cachedEntityData.resetCacheData(ucrServer)
	}
	
	
	/**
	 * Returns the application that this version belongs to.
	 */
	public UcrApplication getApplication() {
		return _application
	}
	
	
	/**
	 * Returns detail'ed entity data.  This is data retrieved via a REST call with format of 'detail'.  If possible,
	 * this returns cached data, otherwise it loads (and caches) the data. 
	 */
	public UcrEntityData getDetailedEntityData( boolean resetCache = false ) {
		UcrEntityData entityData = _cachedEntityData.getCacheData(ucrServer,resetCache)
		if ((! entityData) || (! entityData.getEntityFormat().isDetailed)) {
			// Load the 'detail' data and cache it
			def data = (new RestGet(ucrServer))
				.setPath('/versions/' + this.id)
				.addParameter('format', 'detail')
				.setHeader('Accept', 'application/json, application/javascript, text/javascript')
				.getAsObject()
			_cachedEntityData.setCacheData(ucrServer, new UcrEntityData(data, UcrEntityDataFormat.DETAIL_FORMAT))
		}
		return _cachedEntityData.getCacheData(ucrServer)
	}
	
	
	/**
	 * Returns the UcrEntityData for this class, which is the underlying REST/JSON based data structure.
	 */
	public UcrEntityData getEntityData( boolean resetCache = false ) {
		UcrEntityData restEntity = (UcrEntityData) _cachedEntityData.getCacheData(ucrServer,resetCache)
		if (! restEntity) {
			def entityData = (new RestGet(ucrServer))
				.setPath('/versions/' + this.id)
				.setHeader('Accept', 'application/json, application/javascript, text/javascript')
				.getAsObject()
			restEntity = new UcrEntityData( entityData, UcrEntityDataFormat.LIST_FORMAT )
			_cachedEntityData.setCacheData( ucrServer, restEntity )

		}
		return restEntity
	}

	/**
	 * Returns the list of VersionStatuses for this Version.
	 * @return List of type UcrVersionStatus
	 */
	public List getVersionStatuses( boolean resetCache=false ) {
		def data = getEntityData(resetCache).getEntityObject()
		List versionStatuses = []
		if (data.containsKey('versionStatuses')) {
			UcrVersionStatusMgr mgr = UcrVersionStatusMgr.getInstance(ucrServer)
			data.versionStatuses.each { Map versionStatusData -> 
				versionStatuses << mgr.buildEntity( ucrServer, this,
					UcrStatusMgr.getInstance(ucrServer).getStatusById(versionStatusData.status.id),
					new UcrEntityData(versionStatusData, UcrEntityDataFormat.LIST_FORMAT) )
			}
		}
		return versionStatuses
	}
	
	/**
	 * Does this version have the given status?
	 */
	public boolean hasVersionStatus( UcrStatus status, boolean resetCache=false ) {
		// At least for now, get all of the Version Statuses and see if there is a match
		return getVersionStatuses().find { UcrVersionStatus versionStatus ->
			return versionStatus.getStatus().equals(status)
		}
	}
	
	/**
	 * Get the VersionStatus for the given status for this version.  Throws exception if not found.
	 */
	public UcrVersionStatus getVersionStatus( UcrStatus status, boolean resetCache=false ) {
		// At least for now, get all of the Version Statuses and see if there is a match
		UcrVersionStatus versionStatus = getVersionStatuses().find { UcrVersionStatus versionStatus ->
			versionStatus.getStatus().equals(status)
		}
		if (! versionStatus) {
			throw new Exception( "Unable to find the status '${status.name}' for version '${this.name}' of application '${this.getApplication().name}'")
		}
		return versionStatus
	}
	
	/**
	 * Associated the UCR Status to this UCR Version.
	 * @param status The Status to associate.
	 * @return Returns the new UcrVersionStatus or throws exception on failure.
	 */
	public UcrVersionStatus addVersionStatus( UcrStatus status ) {
		def statusEntityData = status.getEntityData().getEntityObject()
		def environmentEntityData = this.getEntityData().getEntityObject()
		def environmentStatusDefinition = [ appVersion: environmentEntityData, status: statusEntityData ]
		String redirectUrl = (new RestPost( ucrServer ))
			.setPath('/versionStatus/')
			.setJsonPayloadToObject(environmentStatusDefinition)
//			.setHeader('Accept', 'application/json')
			.setHeader('Accept', '*/*')
//			.setHeader('Accept-Encoding', 'gzip,deflate')
			.setHeader('Content-Type', 'application/json')
			.postAndReturnRedirect()
			
		this.resetCachedData()
		
		return UcrVersionStatusMgr.getInstance(ucrServer).buildEntity(ucrServer, this, status, 
			UrlUtilities.getLastSegmentOfUrl(redirectUrl) )
	}

}
