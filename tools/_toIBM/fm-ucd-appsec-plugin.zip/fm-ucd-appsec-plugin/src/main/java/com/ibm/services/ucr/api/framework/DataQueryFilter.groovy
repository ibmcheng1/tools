package com.ibm.services.ucr.api.framework

import com.ibm.issr.rest.RestGet

/**
 * Use this class to help create UCR REST query filters.
 * @author LeonClark
 *
 */
class DataQueryFilter {

	/**
	 * Defines the list of valid Query Types.
	 */
	public static final class FilterType {
		String name
		String value
		/**
		 * Does this filter type require a field value?
		 */
		boolean requiresValue
		
		private FilterType( String name, String value, boolean requiresValue ) {
			this.name = name
			this.value = value
			this.requiresValue = requiresValue
		}

		public static final FilterType EQUALS = new FilterType("EQUALS", "eq", true)
		public static final FilterType LIKE = new FilterType("LIKE", "like", true)
		public static final FilterType GREATER_THAN = new FilterType("GREATER_THAN", "gt", true)
		public static final FilterType GREATER_OR_EQUAL = new FilterType("GREATER_OR_EQUAL", "ge", true)
		public static final FilterType LESS_THAN = new FilterType("LESS_THAN", "lt", true)
		public static final FilterType LESS_OR_EQUAL = new FilterType("LESS_OR_EQUAL", "le", true)
		public static final FilterType IN = new FilterType("IN", "in", true)
		public static final FilterType NOT_EQUALS = new FilterType("NOT_EQUALS", "ne", true)
		public static final FilterType NULL = new FilterType("NULL", "null", false)
		public static final FilterType NOT_NULL = new FilterType("NOT_NULL", "notnull", false)
		public static final FilterType RANGE = new FilterType("RANGE", "range", true)
		
	}
	
	/**
	 * Defines filterClass constants.
	 */
	public static final class FilterClass {
		String name
		String value
		
		private FilterClass( String name, String value ) {
			this.name = name
			this.value = value
		}
		
		public static final FilterClass BOOLEAN = new FilterClass('BOOLEAN','Boolean')
		public static final FilterClass LONG = new FilterClass('LONG','Long')
		public static final FilterClass STRING = new FilterClass('STRING','String')
		public static final FilterClass UUID = new FilterClass('UUID','UUID')
		public static final FilterClass ENUM = new FilterClass('ENUM','Enum')
	}
	
	/**
	 * <p>Adds parameters to a RestGet definition which define a UCR data filter.</p>
	 * <p>An example call is...</p>
	 * <pre>
	 * def rawList = (new RestGet( ucrServer ))
	 *     .setPath('/changes/')
	 *     .callClosure { RestGet restGet ->
	 *         DataQueryFilter.defineFilter(restGet, 'release.id', DataQueryFilter.FilterClass.UUID, 
	 *             DataQueryFilter.FilterType.EQUALS, this.id )
	 *     }
	 *     .setHeader('Accept', 'application/json')
	 *     .getAsObject()
	 * </pre>
	 * <p><b>Test for Child Node:</b></p>
	 * <p>Suppose that you want to filter out records that don't have a specific child entry.  For
	 * example, a UcrChange may or may not have a linked Release.  If it has a linked Release, then
	 * it has a child entry of 'release.id' which is the release's ID.  But, if the change doesn't
	 * have a linked release, then the child 'release' branch doesn't even exist.  To test for that,
	 * use the DataQueryFilter.FilterType.NULL filter type.  There is no class that represents a tree
	 * node, but STRING works.  An example that filters out Change records that don't have a linked
	 * release is ...</p>
	 * <pre>
	 * def rawList = (new RestGet( ucrServer ))
	 *     .setPath('/changes/')
	 *     .callClosure { RestGet restGet ->
	 *         DataQueryFilter.defineFilter(restGet, 'release', DataQueryFilter.FilterClass.STRING, 
	 *             DataQueryFilter.FilterType.NULL, null )
	 *     }
	 *     .setHeader('Accept', 'application/json')
	 *     .getAsObject()
	 * </pre>
	 * <p><b>Filtering on Dates:</b></p>
	 * <p>Dates are filtered on the 'long' representation of the Date(), which is date.getTime().
	 * As a convenience, you can pass a Date field as the 'filterValue' and this function automatically
	 * converts it into the long value.  This is an example...</p>
	 * <pre>
	 * Date filterDate = ...
	 * def rawList = (new RestGet( ucrServer ))
	 *     .setPath('/changes/')
	 *     .callClosure { RestGet restGet ->
	 *         DataQueryFilter.defineFilter(restGet, 'dateCreated', DataQueryFilter.FilterClass.LONG, 
	 *             DataQueryFilter.FilterType.GREATER_THAN, filterDate )
	 *     }
	 *     .setHeader('Accept', 'application/json')
	 *     .getAsObject()
	 * </pre>
	 * @param restGet This is a restGet which has been created but not executed yet.
	 * The filter parameters are added to this restGet.
	 * @param fieldName The name of the field.  This can be a compound name.  Some examples:
	 * 'id', 'name', 'release.id'
	 * @param filterClass This is one of the constant values defined in the 
	 * DataQueryFilter.FilterClass, such as DataQueryFilter.FilterClass.STRING
	 * @param filterType This is the evaluation type of the filter, such as DataQueryFilter.FilterType.EQUALS
	 * @param filterValue The comparison value.  Note that some of the comparison types, such as NOT_NULL, ignore
	 * the value.  If the filterType is RANGE or IN, then this filterValue should be a LIST.  This code automatically
	 * processes the List values appropriately.
	 */
	public static void defineFilter( RestGet restGet, String fieldName, FilterClass filterClass, FilterType filterType, def filterValue ) {
		restGet.addParameter('filterFields', fieldName)
		restGet.addParameter('filterClass_' + fieldName, filterClass.value)
		restGet.addParameter('filterType_' + fieldName, filterType.value)
		if (filterType.requiresValue) {
			if (filterType.name=='RANGE' || filterType.name=='IN') {
				List filterValueList = (List) filterValue
				filterValueList.each { def entry ->
					restGet.addParameter('filterValue_' + fieldName, translateFilterValue(entry,filterClass,filterType).toString())
				}
			} else {
				restGet.addParameter('filterValue_' + fieldName, translateFilterValue(filterValue,filterClass,filterType).toString())
			}
		}
	}
	
	/**
	 * <p>Translates the filter value according to the following rules...  Note that this should only be called by
	 * defineFilter() with the same filterClass and filterType given to that function.</p>
	 * <ul>
	 * <li>If the filterValue is a Date class, then returns the date's getTime() value, which is the long value.</li>
	 * <li>If none of the conditions listed above are true, then the original filterValue is returned.
	 * </ul>
	 * @param filterValue
	 * @return The translated value.
	 */
	private static def translateFilterValue( def filterValue, FilterClass filterClass, FilterType filterType ) {
		if (filterValue instanceof Date) {
			return ((Date) filterValue).getTime()
		} else {
			return filterValue
		}
	}
}
