package com.ibm.css.ucd.security.user;

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.security.UserOrGroup
import com.ibm.css.ucd.security.role.Role
import com.ibm.css.ucd.security.role.RoleMgr
import com.ibm.css.ucd.team.Team
import com.ibm.css.ucd.team.TeamMgr
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.cache.RestDataCacheWithFields

public class User extends UserOrGroup {
	private RestDataCacheWithFields _cachedEntityData = new RestDataCacheWithFields()
	private final String INFO_FIELD = 'info'
	private final String TEAMROLES_FIELD = 'members'

	/**
	 * Constructor.
	 * @param ucdServer The handle to the UCD Server.
	 * @param info This is an Object version of the info returned with a REST call.
	 * Note that it has at least two fields - name and id.
	 */
	public User( UcdServerConnection ucdServer, def info ) {
		super( ucdServer, info.name, info.id )
		_cachedEntityData.setField(ucdServer, INFO_FIELD, info)
	}
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 */
	public User( UcdServerConnection ucdServer, String name, String id ) {
		super( ucdServer, name, id )
	}
	
	/**
	 * Returns the entity data (aka data from REST call) optionaly forcing a cache
	 * refresh.  Note that the cache may reset even if 'resetCache' is false.
	 * @return the Structured data map for the entity data.
	 */
	public Map getEntityData( boolean resetCache=false ) {
		def entityData = _cachedEntityData.getField(ucdServer,INFO_FIELD,resetCache)
		if (! entityData) {
			// reload the entity
			def rawEntityData = (new RestGet( ucdServer ))
					.setPath('/security/user/' + id)
					.getAsObject()
			// Convert the raw data into an entity
			_cachedEntityData.setField(ucdServer, INFO_FIELD, rawEntityData)
		}
		return _cachedEntityData.getField(ucdServer,INFO_FIELD)
	}

	
	/**
	 * Returns the email address for the user. 
	 */
	public String getEmail( boolean resetCache=false ) {
		// Note that if the user doesn't have an email, then it may NOT be in the entity data
		
		String email = ''
		
		Map entityData = getEntityData( resetCache ) 
		if (entityData.containsKey('email')) {
			email = entityData['email']
		}
		
		return email
	}

		
	/**
	 * <p>Returns a List of all of the Team/Roles that this user is a member of.  This includes
	 * ALL Team/Roles - even if the membership is direct (teaam/role contains specific user) or
	 * through a Group.  The Group information is NOT included in this list.  Each List
	 * member is a Map withthe following member fields:</p>
	 * <ul>
	 * <li>Team team</li>
	 * <li>Role role</li>
	 * </ul> 
	 */
	public List<Map> getTeamRoles( boolean resetCache=false ) {
		List<Map> teamRoles = null
		
		TeamMgr teamMgr = TeamMgr.getInstance(ucdServer)
		RoleMgr roleMgr = RoleMgr.getInstance(ucdServer)
		
		// Check the current cache
		teamRoles = _cachedEntityData.getField( ucdServer, TEAMROLES_FIELD, resetCache )
		
		if (! teamRoles) {
			teamRoles = []
			def rawEntityData = (new RestGet( ucdServer ))
				.setPath('/security/user/roleMappings/' + id )
				.getAsObject()
			rawEntityData.each { def rawEntry ->
				Team team = teamMgr.getByNameAndId(rawEntry.name, rawEntry.id)
				Role role = roleMgr.getByNameAndId(rawEntry.roleMapping.role.name, rawEntry.roleMapping.role.id)
				teamRoles << [team:team, role:role]
			}
			_cachedEntityData.setField( ucdServer, TEAMROLES_FIELD, teamRoles )
		}
		
		return teamRoles
	}
	
	/**
	 * Returns the List of Teams that the user is a member of.  It can be any role (or multiple roles).
	 * It may be that the user is a direct member of the team or the membership may be through a Group(s).
	 * @return The return list is a List of type Team.
	 */
	public List<Team> getTeams( boolean resetCache=false ) {
		// The data isn't cached as it is a transformation of the getTeamRoles() data with no additional REST calls.
		
		List teamRoles = getTeamRoles(resetCache)
		List teams = []
		// Iterate te teamRoles and add any teams that are already in the variable 'teams'
		teamRoles.each { Map teamRole ->
			if (! teams.contains(teamRole.team)) {
				teams << teamRole.team
			}
		}
		
		return teams
	}
	
	
	/**
	 * Is this user a member of the given Team?  The user may be any role.  The user
	 * may be a member through a group.
	 */
	public boolean isMemberOfTeam( Team team, boolean resetCache=false ) {
		List<Team> teams = getTeams(resetCache)
		
		def itemIndex = teams.find { Team teamEntry ->
			return (teamEntry.id == team.id)
		}
		
		return (itemIndex != null)
	}
	
	/**
	 * Is this user a member of the given 'team' with the Role of 'role'?
	 */
	public boolean isRoleMemberOfTeam( Team team, Role role, boolean resetCache=false ) {
		List<Map> teamRoles = this.getTeamRoles()
		
		def itemIndex = teamRoles.find { Map entry ->
			return ((entry.team.id == team.id) && (entry.role.id == role.id))
		}
		
		return (itemIndex != null)
	}

	public String getActualName( boolean resetCache=false ) {
		String fieldValue
		
		Map entityData = getEntityData( resetCache ) 
		if (entityData.containsKey('actualName')) {
			fieldValue = entityData['actualName']
		}
		
		return fieldValue
	}


	public boolean isDeleted( boolean resetCache=false ) {
		boolean fieldValue
		
		Map entityData = getEntityData( resetCache ) 
		if (entityData.containsKey('deleted')) {
			fieldValue = entityData['deleted']
		}
		
		return fieldValue
	}


	public Date getDeletedDate( boolean resetCache=false ) {
		Date fieldValue = null
		
		Map entityData = getEntityData( resetCache ) 
		if (entityData.containsKey('deletedDate')) {
			fieldValue = new Date( entityData['deletedDate'] )
		}
		
		return fieldValue
	}


	public String getDisplayName( boolean resetCache=false ) {
		String fieldValue
		
		Map entityData = getEntityData( resetCache ) 
		if (entityData.containsKey('displayName')) {
			fieldValue = entityData['displayName']
		}
		
		return fieldValue
	}


	public boolean isDeletable( boolean resetCache=false ) {
		boolean fieldValue
		
		Map entityData = getEntityData( resetCache ) 
		if (entityData.containsKey('isDeletable')) {
			fieldValue = entityData['isDeletable']
		}
		
		return fieldValue
	}


	public boolean isLockedOut( boolean resetCache=false ) {
		boolean fieldValue
		
		Map entityData = getEntityData( resetCache ) 
		if (entityData.containsKey('isLockedOut')) {
			fieldValue = entityData['isLockedOut']
		}
		
		return fieldValue
	}


	public Date getLastLoginDate( boolean resetCache=false ) {
		Date fieldValue = null
		
		Map entityData = getEntityData( resetCache ) 
		if (entityData.containsKey('lastLoginDate')) {
			fieldValue = new Date( entityData['lastLoginDate'] )
		}
		
		return fieldValue
	}

}
