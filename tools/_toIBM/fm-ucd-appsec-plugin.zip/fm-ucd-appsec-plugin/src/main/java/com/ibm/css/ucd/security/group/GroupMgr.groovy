package com.ibm.css.ucd.security.group

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.security.user.User;
import com.ibm.issr.core.entity.IndexedListOfEntities
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.cache.RestDataCache

class GroupMgr {
	
	// Map of the server specific singleton instances of this class.  Key=UcdServerConnection, value=instance of this class
	private static Map<UcdServerConnection,GroupMgr> _singletons = [:]
	
	// The UCD Server connection for this instance of the Mgr class
	UcdServerConnection ucdServer
	
	/**
	 * Cached 'List' of ALL Of the entiteis.  Each entry is of type Group.
	 */
	private RestDataCache _cachedCompleteList = new RestDataCache()
	
	/**
	 * Cached list of loaded entities.  The data type of the cache is IndexedListOfEntities, which is
	 * automatically initialized when the cache is created or reset.
	 */
	RestDataCache _entityCache = new RestDataCache(
		// Cache entry initialization closure - Initialize cache entries as instances of IndexedListOfEntities
		{ UcdServerConnection ucdServer ->
			return new IndexedListOfEntities(
				// This closure returns the 'uniqueName' for each entry, which is simply the name
				{ Group entity ->
					return entity.getName()
				}
				)
		}
		)

	
	/**
	 * Private constructor.
	 * @param ucrServer The associated Rest Server.
	 */
	private GroupMgr( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
	}
	
	/**
	 * Returns the singleton instance of this class for the given Rest Server.
	 */
	public static GroupMgr getInstance( UcdServerConnection ucdServer ) {
		if (! _singletons.containsKey(ucdServer)) {
			_singletons[ucdServer] = new GroupMgr(ucdServer)
		}
		return _singletons[ucdServer]
	}
	
	/**
	 * Given entity data, this returns an Entity class instance with Cache management.  Call
	 * this instead of calling the constructor directly!!
	 * @param ucdServer The server.
	 * @param entityData The data returned from some REST call.
	 * @return New or existing entity.
	 */
	public Group buildEntity( UcdServerConnection ucdServer, def entityData ) {
		Group entityInstance
		String id = entityData.id
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucdServer)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			entityInstance = cachedEntities.getEntityById(id)
			// Update the cached entityData
		} else {
			entityInstance = new Group( ucdServer, entityData )
			cachedEntities.addEntity(entityInstance)
		}
		return entityInstance
	}
	
	/**
	 * Given an entity name and id (that are known to be valid), this returns an Entity class.
	 * This is useful for API calls that only return an entity's name and id and not the entity
	 * data.  It may return a brand new entity instance or an existing cached entity instance.
	 * @param ucdServer The server.
	 * @return New or existing entity.
	 */
	public Group buildEntity( UcdServerConnection ucdServer, String name, String id ) {
		Group entityInstance
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucdServer)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			entityInstance = cachedEntities.getEntityById(id)
			// Update the cached entityData
		} else {
			entityInstance = new Group( ucdServer, name, id )
			cachedEntities.addEntity(entityInstance)
		}
		return entityInstance
	}

	
	/**
	 * Returns list of all entities in the list.
	 */
	public List<Group> getAll( boolean resetCache=false ) {
		if (resetCache) {
			_entityCache.resetCacheData(ucdServer)
		}
		List<Group> entityList = _cachedCompleteList.getCacheData( ucdServer, resetCache )
		if (! entityList) {
			// Load the list via REST calls
			entityList = []
			List rawEntityList = (new RestGet( ucdServer ))
					.setPath('/security/group')
//					.setHeader('Accept', 'application/json')
					.getAsObject()
			// convert to entities
			rawEntityList.each { def rawEntity ->
				entityList << buildEntity( ucdServer, rawEntity )
			}
			_cachedCompleteList.setCacheData(ucdServer, entityList)
		}
		return entityList
	}
	
	
	/**
	 * Finds/loads the given entity by name and id.  This should ONLY be called if you know
	 * that the entity exists.  If the entity is not in the cache, then the name
	 * and id is used to create the entity WITHOUT making any REST calls for additional
	 * confirmation or inforamtion.
	 * @return The new or existing entity entry.
	 */
	public Group getByNameAndId( String name, String id, boolean resetCache = false ) {
		return buildEntity(ucdServer, name, id)
	}

	
	/**
	 * Returns the named entity.  Throws exception if not found.
	 */
	public Group getByName( String name, boolean resetCache = false ) {
		// There is no reliable API call to load a group by name, so load them all and check the cache
		getAll(resetCache)
		
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucdServer, false)
		// Check the cache first
		if (cachedEntities.containsEntityByUniqueName(name)) {
			return cachedEntities.getEntityByUniqueName(name)
		} else {
			throw new Exception( "No group was found with the name '${name}'")
		}
	}
	
	
	/**
	 * Does the named entity instance exist?
	 */
	public boolean hasByName( String name, boolean resetCache = false ) {
		// There is no reliable API call to load a group by name, so load them all and check the cache
		getAll(resetCache)
		
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucdServer, false)
		// Check the cache first
		if (cachedEntities.containsEntityByUniqueName(name)) {
			return true
		} else {
			return false
		}
	}
	
	
	/**
	 * Returns the entity by Id.  Throws exception if not found.
	 */
	public Group getById( String id, boolean resetCache = false ) {
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucdServer, resetCache)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			return cachedEntities.getEntityById(id)
		} else {
			// not found in cache - make rest call to load it
			def rawEntityData = (new RestGet( ucdServer ))
					.setPath('/security/group/' + id)
//					.addParameter('name', name)
//					.setHeader('Accept', 'application/json')
					.getAsObject()
			// Convert the raw data into an entity
			return buildEntity( ucdServer, rawEntityData )
		}
	}
	
	
	/**
	 * Does an entity with the given ID exist?
	 */
	public boolean hasById( String id, boolean resetCache = false ) {
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucdServer, resetCache)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			return cachedEntities.getEntityById(id)
		} else {
			// not found in cache - make rest call to load it
			def rawEntityData = (new RestGet( ucdServer ))
					.setPath('/security/group/' + id)
//					.addParameter('name', name)
//					.setHeader('Accept', 'application/json')
					.getAsObjectOrNull()
			if (rawEntityData) {
				// The entity exists.  Go ahead and cache it since the needed data is already loaded
				// Convert the raw data into an entity
				buildEntity( ucdServer, rawEntityData )
				return true
			} else {
				return false
			}
		}
	}
}
