package com.ibm.css.ucd.processrequest.filter

import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.processrequest.ProcessRequest
import com.ibm.css.ucd.processrequest.ProcessRequestApproval
import com.ibm.css.ucd.processrequest.ProcessRequestApprovalDetail;

/**
 * Filter Process Request records based on a user that has an associated approval record.
 * @author ltclark
 *
 */
class ProcessRequestApprovalUserFilter extends ProcessRequestFilter {
	String userValue	// As per 'compareToName' field, this may be userId or userName for filtering
	boolean compareToName //If true, compare to the user's display name.
	boolean compareToId		// If true, compare to the user's id
	boolean caseSensitive
	
	/**
	 * Constructor.
	 * @param userFilter In this version of the constructor, the filter looks for any matching name OR id (case insensitive)
	 */
	public ProcessRequestApprovalUserFilter( String userFilter ) {
		this.userValue = userFilter
		this.compareToName = true
		this.compareToId = true
		this.caseSensitive = false
	}
	
	/**
	 * Constructor.
	 * @param userValue The name of the user to filter on.
	 * @param compareToName If true, compare to the user's display name.  This does NOT determine if the ID is also compared.
	 * @param compareToId If true, compare to the user's ID.  This does NOT determine if the the display name is also compared.
	 * @param caseSensitive Is the comparison of the user name case sensitive.
	 */
	public ProcessRequestApprovalUserFilter( String userValue, boolean compareToName, boolean compareToId, caseSensitive ) {
		this.userValue = userValue
		this.compareToName = compareToName
		this.compareToId = compareToId
		this.caseSensitive = caseSensitive
	}

	@Override
	public Date getFilteringStartedAfter() {
		// There is no date filtering
		return null;
	}
	
	@Override
	public Application getFilteringApplication() {
		// no application to filter on
		return null;
	}

	@Override
	public boolean includeProcessRequestInFilter(ProcessRequest processRequest) {
		boolean retval = false
		// Check to see if the given user has any associated approval records
		ProcessRequestApproval approvalData = processRequest.getApproval()
		if (approvalData) {
			approvalData.detailedEntries.each {  ProcessRequestApprovalDetail detailedEntry ->
				if ((! retval) && detailedEntry.completedBy) {
					
					// Parse the 'rawRecord.userName' into userName and userId fields
					// rawRecord.userName may be 'userName (userId)' or just 'userId', such as 'Leon Clark (leon)' or 'leon'
					String userName = ''
					String userId = ''
					String originalField = detailedEntry.completedBy
					if (originalField.endsWith(')') && originalField.lastIndexOf(' (')>=0) {
						// format is 'userName (userId)'
						int openParenAt = originalField.lastIndexOf(' (')
						userName = originalField.substring( 0, openParenAt )
						userId = originalField.substring( openParenAt + 2, originalField.length() - 1 )
					} else {
						// format is 'userId'
						userId = originalField
					}
			
					if ((! retval) && compareToName) {
						if (caseSensitive) {
							retval = (userName == this.userValue)
						} else {
							retval = userName.equalsIgnoreCase(this.userValue)
						}
					}
					if ((! retval) && compareToId) {
						if (caseSensitive) {
							retval = (userId == this.userValue)
						} else {
							retval = userId.equalsIgnoreCase(this.userValue)
						}
					}
			
				} 
			}
		}
		return retval
	}

	@Override
	public boolean includeRawRecordInFilter(Object rawRecord) {
		// This filter only applies to the processed (object oriented) data and not to the raw data
		return true
	}

	@Override
	public String getDescription() {
		String filterField = ''
		String filterFieldDelim = ''
		if (compareToName) {
			filterField = 'user display name'
			filterFieldDelim = ' or '
		}
		if (compareToId) {
			filterField = filterField + filterFieldDelim + 'user ID'
		}
		return "Approval entry found where ${filterField} is ${userValue} (caseSensitive=${caseSensitive})"
	}

}
