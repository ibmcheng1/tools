package com.ibm.issr.rest

import org.apache.http.NameValuePair
import org.apache.http.client.*
import org.apache.http.client.utils.URLEncodedUtils
import org.apache.http.message.BasicNameValuePair

import com.ibm.issr.core.log.LogTracingClass
import com.ibm.issr.core.log.Logger
import com.urbancode.air.*
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder
import com.urbancode.commons.util.ssl.XTrustProvider
import com.urbancode.ubuild.codestation.client.*

/**
 * This is a thin wrapper around the Apache HTTP client library to provide a REST client
 * interface to UrbanCode uBuild and/or Deploy.
 * 
 * @author ltclark
 *
 */
public class RestServerConnection extends LogTracingClass {
	String serverRootUrl;	// root server url, such as "https://server:1234"
	HttpClient client;				// handle to the HTTP(s) client.
	
	/**
	 * Constructor.
	 * @param client The Apache HTTP Client handle.
	 * @param serverRootUrl The server's root url, such as "https://server:1234/" or "http://serv/contextRoot"
	 */
	public RestServerConnection( HttpClient client, String serverRootUrl ) {
		this.client = client
		this.serverRootUrl = serverRootUrl
	}
	
	
	/**
	 * Constructor with no parameter, which is deprecated.  The preferred approach
	 * to building (constructing) RestServerConnection's is to use a Builder class
	 * that establishes the connection and then calls the constructor that takes
	 * a connection and root url as parameters.  That shifts the focus of this class
	 * into maintaining and using a REST connection instead of also establishing the
	 * connection.
	 */
	@Deprecated
	public RestServerConnection() {
		// do nothing	
	}
	
	
	/**
	 * Appends a path, such as '/rest/operation' to the base URL.  If the base url ends with
	 * '/' and the path starts with '/', then it only uses one of the '/'s
	 * @param path The path to append to the base url.
	 * @return The combined path
	 */
	protected String appendPathToRootUrl( String path ) {
		if (serverRootUrl.endsWith('/') && path.startsWith('/')) {
			return serverRootUrl + path.substring(1)
		} else {
			return serverRootUrl + path
		}
	}

	/**
	 * Builds a complete URL including encoded URL parameters
	 * @param urlPath the url path without parameters or the server name.  
	 * For example, it could be "/rest/deploy/applications"
	 * @param paramMaps a set of zero or more maps, each of which looks something like [val1:"a", val2:"b"]
	 * @deprecated This function is replaced with RestPut and RestGet classes.  Do NOT use any more.
	 * @return A full encoded URL, including the server, path and parameters.
	 */
	public String buildUrlWithParameters( String urlPath, Object... paramMaps ) {
		if (! urlPath) {
			urlPath = ""
		}
		def url = encodeUrl(appendPathToRootUrl(urlPath))
		def List<NameValuePair> parameters = new ArrayList<NameValuePair>();
		if (paramMaps) {
			paramMaps.each { paramMap ->
				paramMap.each{ k, v ->
					parameters.add( new BasicNameValuePair( k, v.toString() ) );
				}
			}
		}
		if (parameters.size() > 0) {
			url = url + "?" + URLEncodedUtils.format( parameters, "UTF-8" );
		}
		return url;
	}
	
	/**
	 * Builds the complete URL including the server information, path and encoded parameters.
	 * @param path The path, such as "/rest/deploy/application".  This does NOT include the server or parameters.
	 * @param params  The parameters (which may be null).  The format of this is an array.  Each element in the array
	 * is a map with an entry named 'key' with the key and 'value' with the value.
	 * @return The full URL.
	 */
	public String buildFullUrl( String path, def params ) {
		if (! path) {
			path = ""
		}
		def url = encodeUrl(appendPathToRootUrl(path));
		List<NameValuePair> parameters = new ArrayList<NameValuePair>();
		if (params) {
			params.each { paramEntry ->
				parameters.add( new BasicNameValuePair( paramEntry.key.toString(), paramEntry.value.toString() ))
			}
		}
		if (parameters.size() > 0) {
			url = url + "?" + URLEncodedUtils.format( parameters, "UTF-8" );
		}
		return url;
	}
	
	/**
	 * Encodes a basic HTTP URL escaping any special characters (such as spaces).
	 * @param url The url, such as "http://server:1234/path".  This must NOT include any parameters,
	 * but should be the full url except for parameters.
	 * @return The encoded url.
	 */
	protected String encodeUrl( String urlValue ) {
		
		Logger.debug "RestClient.encodeUrl( urlValue is '${urlValue}' )"

				// First make sure that the url isn't already encoded by decoding it
		String decodedUrl = URLDecoder.decode( urlValue, "UTF-8" )
		// now encode it
		URL urlPath = new URL(decodedUrl)
		URI uri = new URI(urlPath.getProtocol(), urlPath.getUserInfo(), urlPath.getHost(), urlPath.getPort(), urlPath.getPath(), urlPath.getQuery(), urlPath.getRef())
		return uri.toURL().toExternalForm()
//		return urlValue
	}
}
