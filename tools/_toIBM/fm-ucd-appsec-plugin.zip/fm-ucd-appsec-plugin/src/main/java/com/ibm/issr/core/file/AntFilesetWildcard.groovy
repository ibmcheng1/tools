package com.ibm.issr.core.file

/**
 * <p>This class implements the Apache Ant fileset wildcard expressions.  These wildcards
 * are used to match path/filename expressions, such as 'dir/subdir/file.txt'.  The
 * special characters are ...</p>
 * <ul>
 * <li>? - Match any single character except a path separator.</li>
 * <li>* - Matches any number of characters except path separators.</li>
 * <li>** - Matches any number of characters including file separators.</li>
 * <li>**&#47; - Matches any number of characters including file separators.binding  If there are any file
 * separators in the match, then it must end with a file separator.  If there are no file separators, then
 * this can match no strings.</li>
 * <li>/ - Matches a file separator - which may be a forward or backward slash</li>
 * </ul> 
 * @author LeonClark
 *
 */
class AntFilesetWildcard {
	// Converts from Ant wildcards to Java RegEx as follows...
	// **/ -> ((.*[/\\])|())
	// ** -> .*
	// * -> [^/\\]*
	// / -> [/\\]
	// 	. -> \.
	// \ -> \\
	// ? -> [^/\\]
	
	/**
	 * Does the 'Ant Fileset' wildcard (see
	 * {@link AntFilesetWildcard AntFilesetWildcard}) match the given
	 * path string.
	 * @param filesetWildcard The 'Ant Fileset' wildcard expression, such as '**.txt'.
	 * @param path The path expression, which is generally a relative path, such as
	 * 'aDir/bDir/cFile.txt'.
	 * @param caseSensitive Is the comparison case sensitive?
	 * @return Do they match??
	 */
	public boolean doesMatch( String path, String filesetWildcard, boolean caseSensitive = false ) {
		boolean retval
		String regex = convertFilesetWildcardToRegex( filesetWildcard  )
		if (caseSensitive) {
			retval = path.matches(regex)
		} else {
			retval = path.toLowerCase().matches(regex.toLowerCase())
		}
		return retval
	}

	/**
	 * Converts an Ant Fileset wildcard expression into a Java regex (regular expression).
	 * See {@link AntFilesetWildcard AntFilesetWildcard} for more information.
	 * @param filesetWildcard The fileset wildcard.
	 * @return The corresponding regular expression.
	 */
	public String convertFilesetWildcardToRegex( String filesetWildcard ) {
		String regex = ""
		int nextLetterOffset = 0
		String nextLetter
		
		while (nextLetterOffset < filesetWildcard.length()) {
			nextLetter = filesetWildcard.substring(nextLetterOffset, nextLetterOffset+1)
			++ nextLetterOffset
			if (nextLetter == '/') {
				regex = regex + '[/\\\\]'
			} else if (nextLetter == '.') {
				regex = regex + '\\.'
			} else if (nextLetter=='\\') {
				regex = regex + '\\\\'
			} else if (nextLetter=='?') {
				regex = regex + '[^/\\\\]'
			} else if (nextLetter=='*') {
				if ((nextLetterOffset<filesetWildcard.length()) && (filesetWildcard.substring(nextLetterOffset, nextLetterOffset+1)=='*')) {
					// Found '**' - test if '**/'
					++nextLetterOffset
					if ((nextLetterOffset<filesetWildcard.length()) && (filesetWildcard.substring(nextLetterOffset, nextLetterOffset+1)=='/')) {
						// Found '**/'
						++nextLetterOffset
						regex = regex + '((.*[/\\\\])|())'
					} else {
						// Found '**'
						regex = regex + '.*'
					}	
				} else {
					// Found '*'
					regex = regex + '[^/\\\\]*'
				}
			} else {
				regex = regex + nextLetter
			}
		}
		
		return regex
	}
}
