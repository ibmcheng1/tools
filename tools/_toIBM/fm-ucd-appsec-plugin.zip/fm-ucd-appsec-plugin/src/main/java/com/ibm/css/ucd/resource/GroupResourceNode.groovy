

package com.ibm.css.ucd.resource

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.resource.ResourceApi

/**
 * A UCD Resource Tree node for a Group (aka resource folder).
 * @author ltclark
 *
 */
class GroupResourceNode extends NonRootResourceNode {
	// Object version of the call to /cli/resource/info
	protected def info
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the UCD Server.
	 * @param parentNode The parent node to this node.
	 * @param info This is an Object version of the call to /cli/resource/info.
	 * Note that it has at least two fields - name and id.
	 */
	public GroupResourceNode( UcdServerConnection ucdServer, ResourceNode parentNode, def info ) {
		super( ucdServer, parentNode, info.name, info.id )
		this.info = info
	}

	@Override
	public String getNodeType() {
		return GROUP_NODE_TYPE
	}
	
	@Override
	public String getResourceRole() {
		Map info = ResourceApi.getInfo(ucdServer, id)
		if (info.containsKey('role')) {
			return info.role.name
		} else {
			return ''
		}
	}

}
