package com.ibm.css.ucd.property

/**
 * Represents one property value instance.
 * @author LeonClark
 *
 */
class Property {
	String name
	String description
	boolean secure
	def value
	
	public Property( String name, String description, boolean secure, def value ) {
		this.name = name
		this.description = description
		this.secure = secure
		this.value = value
	}
	
	/**
	 * Returns a 'displayable' copy of the value.  For example, if the value is a String,
	 * it returns the string within single quotes.
	 * @return
	 */
	public String getDisplayableValue() {
		if (value instanceof String) {
			return "'" + value + "'"
		} else {
			return value.toString()
		}
	}
}
