package com.ibm.issr.core.log

import com.ibm.issr.core.plugin.PluginHelper;

/**
 * Implementation class for the Logger class.
 * @author ltclark
 *
 */
class LoggerImpl implements LoggerInterface {
	
	/**
	 * This is the internal function used to output the message.  This should ONLY be called internally
	 * to this class and ONLY after confirming that the given logging level needs output.
	 * @param label The Logging level label, such as "TRACE"
	 * @param message The logging message.
	 */
	private void emit( String label, def message ) {
		String prefix = "${label}"
		Closure out = Logger.outputLine
		message.eachLine { line ->
			out( "${Logger.tabOutput}${Logger.indentation}${prefix}: ${line}".toString() )
			prefix = "..."
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.issr.core.log.LoggerInterface#trace(java.lang.Object)
	 */
	@Override
	public void trace( def message ) {
		if (Logger.displayTrace) {
			emit("TRACE", message)
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.issr.core.log.LoggerInterface#debug(java.lang.Object)
	 */
	@Override
	public void debug( def message ) {
		if (Logger.displayDebug) {
			emit("DEBUG", message)
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.issr.core.log.LoggerInterface#info(java.lang.Object)
	 */
	@Override
	public void info( def message ) {
		if (Logger.displayInfo) {
			emit("INFO", message)
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.issr.core.log.LoggerInterface#warn(java.lang.Object)
	 */
	@Override
	public void warn( def message ) {
		if (Logger.displayWarn) {
			emit("WARNING", message)
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.issr.core.log.LoggerInterface#error(java.lang.Object)
	 */
	@Override
	public void error( def message ) {
		if (Logger.displayError) {
			emit("ERROR", message)
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.issr.core.log.LoggerInterface#fatal(java.lang.Object)
	 */
	@Override
	public void fatal( def message ) {
		if (Logger.displayFatal) {
			emit("FATAL", message)
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.issr.core.log.LoggerInterface#debugSession(java.lang.Object)
	 */
	@Override
	public void debugSession( def message ) {
		emit("DEBUGGING SESSION", message)
	}
	
	
	/* (non-Javadoc)
	 * @see com.ibm.issr.core.log.LoggerInterface#println(com.ibm.issr.core.log.LoggerLevel, java.lang.Object)
	 */
	@Override
	public void println( LoggerLevel loggerLevel, def message ) {
		if (! message) {
			message = ''.toString()
		}
		loggerLevel.println message
	}
	
	
	/* (non-Javadoc)
	 * @see com.ibm.issr.core.log.LoggerInterface#printStackTrace(com.ibm.issr.core.log.LoggerLevel, java.lang.Throwable)
	 */
	@Override
	public void printStackTrace( LoggerLevel loggerLevel, Throwable e ) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		pw.flush()
		sw.flush()
		String stringTrace = sw.toString()
		stringTrace.eachLine { line ->
			loggerLevel.println line
		}
	}
}
