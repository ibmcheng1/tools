package com.ibm.css.ucd.processrequest

import com.ibm.css.rest.ucd.UcdServerConnection;
import com.ibm.css.ucd.common.Entity

/**
 * Entity class which contains detailed information about one 
 * @author ltclark
 *
 */
class ProcessRequestApprovalDetail extends Entity {

	/**
	 * The type of approval entry from: 'environment', 'application', 'component'
	 */
	String type
	/**
	 * The status.  One of: 'Pending', 'Approved', 'Rejected', 'Canceled'
	 */
	String status
	/**
	 * If a component is associated, then the id, otherwise null
	 */
	String componentId
	/**
	 * If a component is associated, then the name, otherwise null
	 */
	String componentName
	/**
	 * If an application is associated, then the id, otherwise null
	 */
	//String applicationId
	/**
	 * If an application is associated, then the name, otherwise null
	 */
	//String applicationName
	/**
	 * If an environment is associated, then the id, otherwise null
	 */
	//String environmentId
	/**
	 * If an environment is associated, then the name, otherwise null
	 */
	//String environmentName
	/**
	 * If this is completed, then the ID of the completer, otherwise null
	 */
	String completedBy
	/**
	 * If this is completed, then the time (in millisenconds) of completion, otherwise 0
	 */
	long completedOn = 0
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to the ucd server
	 */
	public ProcessRequestApprovalDetail( UcdServerConnection ucdServer ) {
		super( ucdServer )
	}
}
