package com.ibm.css.rest.ucd.common

/**
 * Various REST calls, such as '/cli/environment/info' return info
 * about an entity class, such as an Application, Component, ResourceTreeNode, etc.
 * The various info objects have common structure, such as 'extendedSecurity'.
 * This helper class works with that common structure.
 * @author ltclark
 *
 */
class InfoHelper {
	/**
	 * Does the information object tree contain a team entry for the team and resourceType?
	 * @param info Is an object tree version of some returned 'info' REST call.
	 * @param teamId The ID of the team.
	 * @param resourceType The optional resource type. If this is null or an empty string, then this looks for a team without a type.
	 * If this is a non-empty string, then it looks for a matching resourceType entry for the team.
	 */
	public static boolean isLinkedToTeam( def info, String teamId, String resourceType ) {
		boolean retval = false
		if (info.containsKey('extendedSecurity') && info.extendedSecurity.containsKey('teams')) {
			info.extendedSecurity.teams.each { def team ->
				if (teamId == team.teamId) {
					if (team.containsKey('resourceRoleLabel')) {
						// The team entry has a resource type/role
						if (resourceType && resourceType == team.resourceRoleLabel) {
							retval = true;
						}
					} else {
						// The team entry does NOT have a resource type/role
						if (! resourceType) {
							retval = true;
						}
					}
				}
			}
		}
		return retval
	}
	
	/**
	 * Returns a list of Teams (and corresponding resource types) linked to this 'info' entity.
	 * @param info Is an object tree version of some returned 'info' REST call.
	 * @return A List of the linked teams.  Each entry is a map with the fields: 'teamId', 'teamName' and 'resourceType'.  resourceType is empty
	 * for the 'default' resource type.
	 */
	public static List getLinkedTeams( def info ) {
		List retval = []
		if (info.containsKey('extendedSecurity') && info.extendedSecurity.containsKey('teams')) {
			info.extendedSecurity.teams.each { def team ->
				def resourceType = ""
				if (team.containsKey('resourceRoleLabel')) {
					resourceType = team.resourceRoleLabel
				}
				retval << [teamId: team.teamId, teamName: team.teamLabel, resourceType: resourceType]
			}
		}
		return retval
	}
}
