

package com.ibm.css.ucd.security

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.common.EntityWithNameAndId
/** * Base class for User and Group classes.  Quite often, we * want to treat the two classes interchangeably, such as Team * membership. * @author LeonClark * */
class UserOrGroup extends EntityWithNameAndId {
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 */
	public UserOrGroup( UcdServerConnection ucdServer, String name, String id ) {
		super( ucdServer, name, id )
	}

}
