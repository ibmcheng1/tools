package com.ibm.css.ucd.status;

import com.ibm.css.rest.ucd.UcdServerConnection;
import com.ibm.css.ucd.common.EntityWithNameAndId;

/**
 * Represents on Component Version Status flag.  This represents the existence
 * of the flag and does NOT reflect a specific instance of the flag for a
 * ComponentVersion.
 *
 * @author LeonClark
 *
 */
public class ComponentVersionStatus extends EntityWithNameAndId {

	public ComponentVersionStatus(UcdServerConnection ucdServer, String name,
			String id) {
		super(ucdServer, name, id);
	}

}
