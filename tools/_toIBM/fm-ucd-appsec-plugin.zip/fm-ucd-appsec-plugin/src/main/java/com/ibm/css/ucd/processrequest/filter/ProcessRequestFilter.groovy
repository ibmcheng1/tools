package com.ibm.css.ucd.processrequest.filter

import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.processrequest.ProcessRequest

/**
 * This is an abstract base class for filtering ProcessRequest records.  There are three
 * key opportunities for filtering the records.  (1) Define a filter which is passed to
 * the underlying REST calls.  Unfortunately, the only filter supported by the underlying
 * REST calls is 'startedAfter'.  (2) Filter on the 'raw' data objects... 
 * The underlying rest calls retrieves 'raw' data objects (which
 * are not mapped to the ProcessRequest class.  The 'raw' objects contain a lot of potential data
 * to apply a filter to. (3) Filter on ProcessRequest entities...
 * Once an entry is converted into a ProcessRequest entity, additional information is available
 * for filtering.
 * @author ltclark
 *
 */
abstract class ProcessRequestFilter {
	
	/**
	 * Returns a textual descripton of the filter such as "date between a and b"
	 * @return
	 */
	abstract String getDescription()
	
	/**
	 * The built in REST call that gets all Process Requests for all applications supports a 'startedAfter'
	 * filter on the API call.  It returns Process Requests starting after that date.  This function
	 * should return a started after date if appropriate.  Note that the filter must still compare
	 * the startedAfter date.
	 * @return The 'startedAfter' date (only return ProcessRequests starting after this date) or null
	 * if there is no 'startedAfter' date.
	 */
	abstract public Date getFilteringStartedAfter()
	
	/**
	 * Does this filter apply to only a single UCD Application??  If so, then return that application.
	 * This allows for optimization of the overall filtering effort.  Note that the matching application should
	 * still be verified in the filtering function.
	 * @return The application to filter on if the filter is for a single application or return null.
	 */
	abstract public Application getFilteringApplication()

	/**
	 * Is the 'rawRecord' in the filter??  This filter test is called before the raw record
	 * is converted into a ProcessRequest entity.
	 * @param rawRecord The 'raw' record, which is the object returned by the underlying api call
	 * to ProcessRequestApi.getProcessHistory().
	 * @return true if the record is 'in' according to the filter.
	 */
	abstract boolean includeRawRecordInFilter( def rawRecord )

	/**
	 * Should the given ProcessRequest entity be included in the filter??  This test is
	 * in addition to the 'includeRawRecordInFilter' test.  In fact, this test is performed after
	 * the 'raw record' filter.  This test uses a ProcessRequest entity instead of the raw data.
	 * The ProcessRequest entity has access to data not available to the raw record.
	 * @param processRequest The ProcessRequest entity.
	 * @return true if the record is 'included' according to the concrete filter.
	 */
	abstract boolean includeProcessRequestInFilter( ProcessRequest processRequest )
}
