package com.ibm.services.ucr.api.entity.status

import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.framework.UcrEntityWithNameAndId
import com.ibm.services.ucr.api.framework.UcrEntityData
import com.ibm.services.ucr.api.framework.UcrEntityDataFormat

/**
 * One UCR Status.  Note that this is the underlying definition of a Status which 
 * is NOT directly linked to any other UCR Entity, such as a version.
 * @author LeonClark
 *
 */
class UcrStatus extends UcrEntityWithNameAndId {
	// Cached instance of 'UcrEntityData'
	private RestDataCache _cachedEntityData = new RestDataCache()
	
	/**
	 * This constructor should only be called by this entity's Mgr class.
	 */
	UcrStatus( RestServerConnection ucrServer, String name, String id ) {
		super( ucrServer, name, id )
	}
	
	/**
	 * Constructor based on the 'restInfo' 
	 * @param ucrServer
	 * @param restInfo
	 */
	UcrStatus( RestServerConnection ucrServer, UcrEntityData restEntity ) {
		super( ucrServer, restEntity.entityObject.name, restEntity.entityObject.id )
		_cachedEntityData.setCacheData( ucrServer, restEntity )
	}
	
	/**
	 * Resets the cached data storing internal data for this class instance.
	 */
	public void resetCachedData() {
		_cachedEntityData.resetCacheData(ucrServer)
	}

	/**
	 * Returns the UcrEntityData for this class, which is the underlying REST/JSON based data structure.
	 */
	public UcrEntityData getEntityData( boolean resetCache = false ) {
		UcrEntityData restEntity = (UcrEntityData) _cachedEntityData.getCacheData(ucrServer,resetCache)
		if (! restEntity) {
			def entityData = (new RestGet(ucrServer))
				.setPath('/statuses/' + this.id)
				.setHeader('Accept', 'application/json, application/javascript, text/javascript')
				.getAsObject()
			restEntity = new UcrEntityData( entityData, UcrEntityDataFormat.LIST_FORMAT )
			_cachedEntityData.setCacheData( ucrServer, restEntity )

		}
		return restEntity
	}
}
