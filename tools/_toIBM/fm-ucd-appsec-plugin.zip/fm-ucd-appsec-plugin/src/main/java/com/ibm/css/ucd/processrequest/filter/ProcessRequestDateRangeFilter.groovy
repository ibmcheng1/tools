package com.ibm.css.ucd.processrequest.filter

import com.ibm.css.ucd.application.Application;
import com.ibm.css.ucd.processrequest.ProcessRequest;
import com.ibm.issr.core.log.Logger


/**
 * Filter Process Request records based on a date range filter.  Specifically, this
 * compares the date range filter to the 'submittedTime' field in the process request.  It
 * also checks for > startDate and < endDate ( and NOT >= and <=)
 * @author ltclark
 *
 */
class ProcessRequestDateRangeFilter extends ProcessRequestFilter {
	Date startDate
	Date endDate
	
	/**
	 * Constructor for date range Process Request filter.
	 * @param startDate Optional start date.
	 * @param endDate Optional end date.
	 */
	public ProcessRequestDateRangeFilter( Date startDate, Date endDate) {
		this.startDate = startDate
		this.endDate = endDate
	}
	
	@Override
	public Application getFilteringApplication() {
		// no application to filter on
		return null;
	}

	@Override
	public Date getFilteringStartedAfter() {
		return startDate;
	}

	@Override
	public boolean includeRawRecordInFilter(Object rawRecord) {
		boolean includedInFilter = true

		// If 'startTime' is given use that, otherwise, use schedule time in second pass of filter

		if (rawRecord.containsKey('startTime')) {
			Date startTime = new Date( rawRecord.startTime )

			if (startDate && (startTime < startDate)) {
				includedInFilter = false
			} else if (endDate && (startTime > endDate)) {
				includedInFilter = false
			}
		}
		return includedInFilter
	}
	
	@Override
	public boolean includeProcessRequestInFilter(ProcessRequest processRequest) {
		boolean includedInFilter = true

		if (processRequest.getStatusOverview()=="SCHEDULED") {
			// Filter on the scheduled time
			Date startTime = processRequest.scheduledTime

			if (startDate && (startTime < startDate)) {
				includedInFilter = false
			} else if (endDate && (startTime > endDate)) {
				includedInFilter = false
			}

		}
		
		return includedInFilter
	}
	

	@Override
	public String getDescription() {
		String startDateString = ''
		String endDateString = ''
		if (startDate) {
			startDateString = startDate.format('MM/dd/yy HH:mm')
		}
		if (endDate) {
			endDateString = endDate.format('MM/dd/yy HH:mm')
		}
		if (startDate && endDate) {
			return "Date Started between ${startDateString} and ${endDateString}"
		} else if (startDate) {
			return "Date Started after ${startDateString}"
		} else if (endDate) {
			return "Date Started before ${endDateString}"
		} else {
			return ""
		}
	}

}
