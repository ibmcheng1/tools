package com.ibm.css.ucd.security.user

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.team.Team;
import com.ibm.issr.core.entity.IndexedListOfEntities
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.cache.RestDataCache

class UserMgr {
	
	// Map of the server specific singleton instances of this class.  Key=UcdServerConnection, value=instance of this class
	private static Map<UcdServerConnection,UserMgr> _singletons = [:]
	
	// The UCD Server connection for this instance of the Mgr class
	UcdServerConnection ucdServer
	
	/**
	 * Cached 'List' of ALL Of the entiteis.  Each entry is of type User.
	 */
	private RestDataCache _cachedCompleteList = new RestDataCache()
	
	/**
	 * Cached list of loaded entities.  The data type of the cache is IndexedListOfEntities, which is
	 * automatically initialized when the cache is created or reset.
	 */
	RestDataCache _entityCache = new RestDataCache(
		// Cache entry initialization closure - Initialize cache entries as instances of IndexedListOfEntities
		{ UcdServerConnection ucdServer ->
			return new IndexedListOfEntities(
				// This closure returns the 'uniqueName' for each entry, which is simply the name
				{ User entity ->
					return entity.getName()
				}
				)
		}
		)

	
	/**
	 * Private constructor.
	 * @param ucrServer The associated Rest Server.
	 */
	private UserMgr( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
	}
	
	/**
	 * Returns the singleton instance of this class for the given Rest Server.
	 */
	public static UserMgr getInstance( UcdServerConnection ucdServer ) {
		if (! _singletons.containsKey(ucdServer)) {
			_singletons[ucdServer] = new UserMgr(ucdServer)
		}
		return _singletons[ucdServer]
	}
	
	/**
	 * Given entity data, this returns an Entity class instance with Cache management.  Call
	 * this instead of calling the constructor directly!!
	 * @param ucdServer The server.
	 * @param entityData The data returned from some REST call.
	 * @return New or existing entity.
	 */
	public User buildEntity( UcdServerConnection ucdServer, def entityData ) {
		User entityInstance
		String id = entityData.id
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucdServer)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			entityInstance = cachedEntities.getEntityById(id)
			// Update the cached entityData
		} else {
			entityInstance = new User( ucdServer, entityData )
			cachedEntities.addEntity(entityInstance)
		}
		return entityInstance
	}
	
	/**
	 * Given an entity name and id (that are known to be valid), this returns an Entity class.
	 * This is useful for API calls that only return an entity's name and id and not the entity
	 * data.  It may return a brand new entity instance or an existing cached entity instance.
	 * @param ucdServer The server.
	 * @return New or existing entity.
	 */
	public User buildEntity( UcdServerConnection ucdServer, String name, String id ) {
		User entityInstance
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucdServer)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			entityInstance = cachedEntities.getEntityById(id)
			// Update the cached entityData
		} else {
			entityInstance = new User( ucdServer, name, id )
			cachedEntities.addEntity(entityInstance)
		}
		return entityInstance
	}

	
	/**
	 * Returns list of all entities in the list.
	 */
	public List<User> getAll( boolean resetCache=false ) {
		if (resetCache) {
			_entityCache.resetCacheData(ucdServer)
		}
		List<User> entityList = _cachedCompleteList.getCacheData( ucdServer, resetCache )
		if (! entityList) {
			// Load the list via REST calls
			entityList = []
			List rawEntityList = (new RestGet( ucdServer ))
					.setPath('/security/user')
//					.setHeader('Accept', 'application/json')
					.getAsObject()
			// convert to entities
			rawEntityList.each { def rawEntity ->
				entityList << buildEntity( ucdServer, rawEntity )
			}
			_cachedCompleteList.setCacheData(ucdServer, entityList)
		}
		return entityList
	}
	
	
	/**
	 * Finds/loads the given entity by name and id.  This should ONLY be called if you know
	 * that the entity exists.  If the entity is not in the cache, then the name
	 * and id is used to create the entity WITHOUT making any REST calls for additional
	 * confirmation or inforamtion.
	 * @return The new or existing entity entry.
	 */
	public User getByNameAndId( String name, String id, boolean resetCache = false ) {
		return buildEntity(ucdServer, name, id)
	}
	
	
	/**
	 * Returns the named entity.  Throws exception if not found.
	 */
	public User getByName( String name, boolean resetCache = false ) {
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucdServer, resetCache)
		// Check the cache first
		if (cachedEntities.containsEntityByUniqueName(name)) {
			return cachedEntities.getEntityByUniqueName(name)
		} else {
			// not found in cache - make rest call to load it
			def rawEntityData = (new RestGet( ucdServer ))
					.setPath('/security/user')
					.addParameter('name', name)
//					.setHeader('Accept', 'application/json')
					.getFirstElementInListAsObject()
			// Convert the raw data into an entity
			return buildEntity( ucdServer, rawEntityData )
		}
	}
	
	
	/**
	 * Does the named entity instance exist?
	 */
	public boolean hasByName( String name, boolean resetCache = false ) {
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucdServer, resetCache)
		// Check the cache first
		if (cachedEntities.containsEntityByUniqueName(name)) {
			return true
		} else {
			// not found in cache - make rest call to load it
			def rawEntityData = (new RestGet( ucdServer ))
					.setPath('/security/user')
					.addParameter('name', name)
//					.setHeader('Accept', 'application/json')
					.getFirstElementInListAsObjectOrNull()
			if (rawEntityData) {
				// It exists.  Go ahead and cache the entity since we have the data
				// Convert the raw data into an entity
				buildEntity( ucdServer, rawEntityData )
				return true
			} else {
				return false
			}
		}
	}
	
	
	/**
	 * Returns the entity by Id.  Throws exception if not found.
	 */
	public User getById( String id, boolean resetCache = false ) {
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucdServer, resetCache)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			return cachedEntities.getEntityById(id)
		} else {
			// not found in cache - make rest call to load it
			def rawEntityData = (new RestGet( ucdServer ))
					.setPath('/security/user/' + id)
//					.addParameter('name', name)
//					.setHeader('Accept', 'application/json')
					.getAsObject()
			// Convert the raw data into an entity
			return buildEntity( ucdServer, rawEntityData )
		}
	}
	
	
	/**
	 * Does an entity with the given ID exist?
	 */
	public boolean hasById( String id, boolean resetCache = false ) {
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucdServer, resetCache)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			return cachedEntities.getEntityById(id)
		} else {
			// not found in cache - make rest call to load it
			def rawEntityData = (new RestGet( ucdServer ))
					.setPath('/security/user/' + id)
//					.addParameter('name', name)
//					.setHeader('Accept', 'application/json')
					.getAsObjectOrNull()
			if (rawEntityData) {
				// The entity exists.  Go ahead and cache it since the needed data is already loaded
				// Convert the raw data into an entity
				buildEntity( ucdServer, rawEntityData )
				return true
			} else {
				return false
			}
		}
	}


	
	

}
