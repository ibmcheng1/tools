package com.ibm.css.ucd.team
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.common.EntityWithNameAndId
import com.ibm.css.ucd.security.UserOrGroup
import com.ibm.css.ucd.security.group.GroupMgr;
import com.ibm.css.ucd.security.role.Role
import com.ibm.css.ucd.security.role.RoleMgr
import com.ibm.css.ucd.security.user.UserMgr
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.cache.RestDataCacheWithFields

public class Team extends EntityWithNameAndId {
	// The cache of the entity data for this entity
	private RestDataCacheWithFields _cachedEntityData = new RestDataCacheWithFields()
	private final String INFO_FIELD = 'info'
	private final String MEMBERS_FIELD = 'members'		// data is a List<Map> of the members

	/**
	 * Constructor.
	 * @param ucdServer The handle to the UCD Server.
	 * @param info This is the object version of data returned from a reset call.
	 * Note that it has at least two fields - name and id.
	 */
	public Team( UcdServerConnection ucdServer, def info ) {
		super( ucdServer, info.name, info.id )
		_cachedEntityData.setField(ucdServer, INFO_FIELD, info)
	}
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 */
	public Team( UcdServerConnection ucdServer, String name, String id ) {
		super( ucdServer, name, id )
	}
	
	/**
	 * Returns the entity data (aka data from REST call) optionaly forcing a cache
	 * refresh.  Note that the cache may reset even if 'resetCache' is false.
	 * @return the Structured data map for the entity data.
	 */
	public Map getEntityData( boolean resetCache=false ) {
		def entityData = _cachedEntityData.getField(ucdServer,INFO_FIELD,resetCache)
		if (! entityData) {
			// reload the entity
			def rawEntityData = (new RestGet( ucdServer ))
					.setPath('/security/team/' + id)
					.getAsObject()
			// Convert the raw data into an entity
			_cachedEntityData.setField(ucdServer, INFO_FIELD, rawEntityData)
		}
		return _cachedEntityData.getField(ucdServer,INFO_FIELD)
	}

	/**
	 * <p>Returns a list of the team members and roles.  This does NOT expand
	 * groups, so the list will be a mix of users and groups.  Each record
	 * in the list has the following fields:</p>
	 * <ul>
	 * <li>UserOrGroup member - this may be a User or a Group</li>
	 * <li>Role role - the UCD permission Role</li>
	 * </ul>
	 * <p>It returns all of the combinations.  For example, if the user
	 * has two roles on a team, they are in this list twice.</p> 
	 */
	public List<Map> getMembersWithRoles( boolean resetCache=false ) {
		List<Map> membersWithRoles
		
		RoleMgr roleMgr = RoleMgr.getInstance(ucdServer)
		UserMgr userMgr = UserMgr.getInstance(ucdServer)
		GroupMgr groupMgr = GroupMgr.getInstance(ucdServer)
		
		// Is there a cached member list?
		membersWithRoles = _cachedEntityData.getField(ucdServer, MEMBERS_FIELD, resetCache )
		if (! membersWithRoles) {
			// There isn't a cached instance, so load/calculate the list
			membersWithRoles = []
			
			// Get the information.
			Map entityData = getEntityData()
			
			// If the 'roleMappings' are missing, force reload the entity data.  
			// Some API calls don't include the mappings, but the reload call does
			if (! entityData.containsKey('roleMappings')) {
				entityData = getEntityData(true)
			}
			
			entityData.roleMappings.each { Map roleMapping ->
				Role role = roleMgr.getByNameAndId(roleMapping.role.name, roleMapping.role.id)
				UserOrGroup userOrGroup
				if (roleMapping.containsKey('user')) {
					userOrGroup = userMgr.getByNameAndId( roleMapping.user.name, roleMapping.user.id)
				} else {
					userOrGroup = groupMgr.getByNameAndId( roleMapping.group.name, roleMapping.group.id)
				}
				
				membersWithRoles << [role:role,member:userOrGroup]
			}
			
			// Update the cached data
			_cachedEntityData.setField(ucdServer, MEMBERS_FIELD, membersWithRoles )
		}
		
		return membersWithRoles
	}
}
