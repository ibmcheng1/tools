package com.ibm.services.ucr.api.entity.versionstatuscomment

import com.ibm.issr.core.entity.EntityWithId
import com.ibm.issr.rest.RestDelete
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.entity.versionstatus.UcrVersionStatus
import com.ibm.services.ucr.api.framework.UcrEntityData
import com.ibm.services.ucr.api.framework.UcrEntityDataFormat
import com.ibm.services.ucr.api.framework.UcrEntityWithId

class UcrVersionStatusComment extends UcrEntityWithId implements EntityWithId {
	// The cache of the UcrEntityData for this entity
	private RestDataCache _cachedEntityData = new RestDataCache()
	
	// The UcrVersionStatus that this is a comment for
	private UcrVersionStatus _versionStatus
	// The comment
	private String _comment
	
	/**
	 * Private constructor that should ONLY be called by the ...Mgr.build... functionsn.
	 * @param ucrServer The server.
	 * @param versionStatus The UcrVersionStatus that this comment belongs to.
	 * @param id The ID of the comment.
	 * @param comment The body of the comment.
	 * @param entityData Optional entity data, which is the REST data within the comment REST calls.
	 */
	private UcrVersionStatusComment( RestServerConnection ucrServer, UcrVersionStatus versionStatus, String id, String comment, UcrEntityData entityData = null ) {
		super( ucrServer, id )
		if (entityData) {
			_cachedEntityData.setCacheData(ucrServer, entityData)
		}
		this._versionStatus = versionStatus
		this._comment = comment
	}
	
	/**
	 * Resets the cached data storing internal data for this class instance.
	 */
	public void resetCachedData() {
		_cachedEntityData.resetCacheData(ucrServer)
	}

	/**
	 * Returns the UcrVersionStatus that this comment is associated with.
	 */
	public UcrVersionStatus getVersionStatus() {
		return _versionStatus
	}
	
	/**
	 * Returns the body of the comment
	 */
	public String getComment() {
		return _comment
	}
	
	/**
	 * Returns entity data for this entity which is at LEAST the 'minDataFormat' level of information.  For example,
	 * if the minDataFormat is LIST_FORMAT, then both LIST_FORMAT and DETAIL_FORMAT are suitable.
	 * If possible, this returns cached data, otherwise it loads (and caches) the data.
	 */
	public UcrEntityData getEntityData( UcrEntityDataFormat minDataFormat, boolean resetCache=false ) {
		UcrEntityData entityData = _cachedEntityData.getCacheData(ucrServer,resetCache)
		if ((! entityData) || (! entityData.getEntityFormat().isSuperset( minDataFormat ))) {
			// Load the 'detail' data and cache it
			def data = (new RestGet( ucrServer ))
				.setPath('/versionStatusComment/' + this.id)
				.addParameter('format', minDataFormat.getFormatName())
				.setHeader('Accept', 'application/json')
				.getAsObject()
			_cachedEntityData.setCacheData(ucrServer, new UcrEntityData(data, minDataFormat))
		}
		return _cachedEntityData.getCacheData(ucrServer)
	}

	/**
	 * Returns detail'ed entity data.  This is data retrieved via a REST call with format of 'detail'.  If possible,
	 * this returns cached data, otherwise it loads (and caches) the data.
	 */
	public UcrEntityData getDetailedEntityData( boolean resetCache=false ) {
		return getEntityData( UcrEntityDataFormat.DETAIL_FORMAT, resetCache )
	}
	
	/**
	 * Returns the date that this entity was created.
	 */
	public Date getDateCreated( boolean resetCache=false ) {
		new Date( getEntityData( UcrEntityDataFormat.LIST_FORMAT, resetCache ).entityObject.dateCreated )
	}

	/**
	 * Delete this entity from UCR!!  Appropriate cached data is reset.
	 */
	public void delete() {
		(new RestDelete(ucrServer))
			.setPath('/versionStatusComment/' + this.id)
			.deleteWithNoReturnObject()
		// TODO - currently reseting all cached data.  In the future, just remove the entry from the Mgr's cache(s)
		RestDataCache.resetAllCacheData(ucrServer)
	}

}
