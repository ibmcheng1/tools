package com.ibm.issr.core.string

class SimpleWildcard {
	public static void main(String[] args) {
		println "hello"
		println doesMatch( "axyz,abc,!", "*xyz**abc*!")
	}
	
	/**
	 * Does the given string match the wildcard expression?  This is case insensitive.
	 * @param s The string to match.
	 * @param wildcard The wildcard expression.  The ONLY special symbol is '*' which
	 * matches zero, one or more characters.
	 * @return True if match or false if not.
	 */
	public static boolean doesMatchCaseInsensitive( String s, String wildcard ) {
		return doesMatch( s, wildcard, false )
	}
	
	/**
	 * Does the given string match the wildcard expression?  This is case sensitive.
	 * @param s The string to match.
	 * @param wildcard The wildcard expression.  The ONLY special symbol is '*' which
	 * matches zero, one or more characters.
	 * @return True if match or false if not.
	 */
	public static boolean doesMatch( String s, String wildcard, boolean caseSensitive=true ) {
		if (! caseSensitive) {
			s = s.toLowerCase()
			wildcard = wildcard.toLowerCase()
		}
		def tokens = wildcard.split('\\*')
		boolean endsWithWildcard = false
		if (wildcard.endsWith('*')) {
			endsWithWildcard = true
		}
		
		// Iterate tokens attempting to match the string
		boolean firstToken = true
		boolean failed = false
		String remainingString = s
		tokens.each{ def token ->
			if (! failed) {
				// If the match has failed, stop trying
				if (! token) {
					// the next token is '', which can be skipped - do nothing
				} else {
					if (firstToken) {
						// Look for the string to start with the token
						if (remainingString.startsWith(token)) {
							remainingString = remainingString.substring(token.length())
						} else {
							failed = true
						}
					} else {
						// Look for the next instance of the token
						int index = remainingString.indexOf(token)
						if (index >= 0) {
							remainingString = remainingString.substring(index + token.length())
						} else {
							failed = true
						}
					}
				}
				firstToken = false
			}
		}
		
		if ((! failed) && remainingString) {
			// after processing the tokens, there is stil a string left, which is ok
			// if the search ends with a token
			if (! endsWithWildcard) {
				failed = true
			}
		}
		return (! failed)
	}
}
