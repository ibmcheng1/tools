package com.ibm.css.rest.ucd.server_version

import com.ibm.css.rest.ucd.UcdServerConnection;

/**
 * I have been unable to find any simple API call that returns the server's version.
 * So, the idea of these classes is that each version has an implementation which is
 * responsible for figuring out if the server is on or above that version.
 * @author ltclark
 *
 */
abstract class VersionBaseClass {
	/**
	 * Is the currently running version of the UCD server on or above
	 * the version identified by this concrete class (such as UcdVersion6_2_7)?
	 * I have been unable to find any simple API call that returns the server's version.
	 * So, the idea of these classes is that each version has an implementation which is
	 * responsible for figuring out if the server is on or above that version.
	 * For example, 6.2.7 has a new REST call '/cli/version/copyVersion'.  So, testing
	 * to see if that is a callable REST end point, which tells us if the UCD version is at
	 * least 6.2.7.
	 * @return Boolean result.
	 */
	abstract boolean isVersionAtOrAbove(UcdServerConnection ucdServe)
}
