package com.ibm.services.ucr.api.entity.change

import com.ibm.issr.core.entity.IndexedListOfEntities
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.entity.change.filter.UcrChangeFilter;
import com.ibm.services.ucr.api.entity.changetype.UcrChangeTypeMgr;
import com.ibm.services.ucr.api.framework.DataQueryFilter;
import com.ibm.services.ucr.api.framework.UcrEntityData
import com.ibm.services.ucr.api.framework.UcrEntityDataFormat

class UcrChangeMgr {
	
	// Map of the singleton instances of this class.  Key=RestServerConnection, value=instance of this class
	private static Map _singletons = [:]
	
	// The server for this instance of the Mgr
	RestServerConnection ucrServer
	
	/**
	 * Cached list of loaded entities.  The data type of the cache is IndexedListOfEntities, which is
	 * automatically initialized when the cache is created or resest.
	 */
	RestDataCache _entityCache = new RestDataCache(
		// Cache entry initialization closure - Initialize cache entries as instances of IndexedListOfEntities
		{ RestServerConnection ucrServer ->
			return new IndexedListOfEntities(
				// This closure returns the 'uniqueName' for each entry, which is simply the id because this class has no name
				{ UcrChange entity ->
					return entity.getId()
				}
				)
		}
		)
	
	/**
	 * Private constructor.
	 * @param ucrServer The associated Rest Server.
	 */
	private UcrChangeMgr( RestServerConnection ucrServer ) {
		this.ucrServer = ucrServer
	}
	
	/**
	 * Returns the singleton instance of this class for the given Rest Server.
	 */
	public static UcrChangeMgr getInstance( RestServerConnection ucrServer ) {
		if (! _singletons.containsKey(ucrServer)) {
			_singletons[ucrServer] = new UcrChangeMgr(ucrServer)
		}
		return _singletons[ucrServer]
	}
	
	/**
	 * Given entity data, this returns a UcrChange for that data.
	 * @param ucrServer The server.
	 * @param entityData The data returned from some REST call.
	 * @return New or existing entity.
	 */
	public UcrChange buildEntity( RestServerConnection ucrServer, UcrEntityData entityData ) {
		UcrChange entity
		String name = entityData.getEntityObject().name
		String id = entityData.getEntityObject().id
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			entity = cachedEntities.getEntityById(id)
			// Update the cached entityData
		} else {
			entity = new UcrChange( ucrServer, entityData )
			cachedEntities.addEntity(entity)
		}
		return entity
	}
	
	/**
	 * Returns the entity by ID.  Throws exception if not found.
	 */
	public UcrChange getById( String id, boolean resetCache=false ) {
		IndexedListOfEntities cachedEntities = _entityCache.getCacheData(ucrServer, resetCache)
		// Check the cache first
		if (cachedEntities.containsEntityById(id)) {
			return cachedEntities.getEntityById(id)
		} else {
			// not found in cache - make rest call to load it
			def rawEntityData = (new RestGet( ucrServer ))
					.setPath("/changes/${id}")
//					.addParameter('format', 'detail')
					.setHeader('Accept', 'application/json')
					.getAsObject()
			// Convert the raw data into an entity
			return buildEntity( ucrServer, new UcrEntityData(rawEntityData, UcrEntityDataFormat.LIST_FORMAT ))
		}
	}
	
	/**
	 * Returns a List of type UcrChange of the change records that match the provided
	 * 'filter'.  In general, the filter is defined within the server side of the REST call
	 * and not the client side, which makes this an efficient call.
	 * @param filter This defines the filter criteria.
	 */
	public List getFilteredList( UcrChangeFilter filter, boolean resetCache=false ) {
		List resultList = []
		UcrChangeMgr changeMgr = UcrChangeMgr.getInstance(ucrServer)
		RestGet restGet = (new RestGet( ucrServer ))
			.setPath('/changes/')
			
		if (filter._application) {
			DataQueryFilter.defineFilter(restGet, "application.id", 
				DataQueryFilter.FilterClass.UUID, DataQueryFilter.FilterType.EQUALS, 
				filter._application.id)
		} else if (filter._filterOnNoApplication) {
			DataQueryFilter.defineFilter(restGet, "application", 
				DataQueryFilter.FilterClass.STRING, DataQueryFilter.FilterType.NULL, 
				null)
		}
		
		if (filter._release) {
			DataQueryFilter.defineFilter(restGet, "release.id",
				DataQueryFilter.FilterClass.UUID, DataQueryFilter.FilterType.EQUALS,
				filter._release.id)
		} else if (filter._filterOnNoRelease) {
			DataQueryFilter.defineFilter(restGet, "release",
				DataQueryFilter.FilterClass.STRING, DataQueryFilter.FilterType.NULL,
				null)
		}
		
		if (filter._initiative) {
			DataQueryFilter.defineFilter(restGet, "initiative.id",
				DataQueryFilter.FilterClass.UUID, DataQueryFilter.FilterType.EQUALS,
				filter._initiative.id)
		} else if (filter._filterOnNoInitiative) {
			DataQueryFilter.defineFilter(restGet, "initiative",
				DataQueryFilter.FilterClass.STRING, DataQueryFilter.FilterType.NULL,
				null)
		}

		def rawList = restGet.setHeader('Accept', 'application/json')
			.getAsObject()
		rawList.each { Map rawEntry ->
			resultList << changeMgr.buildEntity(ucrServer, new UcrEntityData(rawEntry,UcrEntityDataFormat.LIST_FORMAT))
		}
		return resultList

	}
}
