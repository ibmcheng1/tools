package com.ibm.issr.core

import com.ibm.issr.core.log.LogTracingClass
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.plugin.PluginHelper;

import groovy.lang.Closure

/**
 * This is a class that is capable of running operating system commands with various options.
 * Note that the various setter functions return 'this' allowing syntax like
 * new CommandRunner().setCommand(["a"]).setTitle("foobar").setDirectory(directory)
 * @author ltclark
 *
 */
class CommandRunner extends LogTracingClass {
	private String[] command=null		// The array version of the command
	private String cmdString		// String version of the command
	private String title=null			// The command title
	private String activeDirectory=null
	private boolean displayOutput=true
	private Closure printHandler=null
	private boolean runViaCommandShell = false
	// If timeoutInSeconds > 0, then there is a timeout
	private int timeoutInSeconds = 0
	private int exitValue	// the exit value of the command
	private boolean verboseMode = true
	private Closure postProcesser
	private boolean success = false
	// optional override of the environment variables.  Each list member is one string in the format of 'name=value'.
	private List environmentVariables = null
	
	/**
	 * Constructor.
	 */
	public CommandRunner() {
		setPostProcessor { CommandRunner cmdRunner, String outputLog ->
			return ( cmdRunner.getExitValue() == 0)
		}
	}
	
	/**
	 * Sets the 'verbose' flag, which defaults to true if this function isn't called.
	 * If verbose is true, then all normal output is displayed. If verbose is false, then
	 * output is only displayed if the command fails.
	 * @return this
	 */
	public CommandRunner setVerbose( boolean flag=true ) {
		verboseMode = flag
		return this
	}
	
	/**
	 * Sets the environment variables to use with the nested execution.  If this is not called,
	 * then the parent process environment variables are used.  This replaces those variables.
	 * @param environment The List of environment variables.  Each entry is a string in the
	 * format of 'name=value'.
	 * @return this
	 */
	public CommandRunner setEnvironment( List environment ) {
		environmentVariables = environment
		return this
	}

	/**
	 * The post process is called just after the command is executed.  Note that the default
	 * postProcesser looks at the exitValue and return true if (and only if) the exitValue is 0.
	 * @param postProcessor Syntax: 'boolean postProcessor( CommandRunner cmdRunner, String outputLog )'
	 * The commandRunner exitValue is defined before this is called.  The 'outputLog' is the captured output of the
	 * command.  The postProcessor should return true if the command is considered to be successful or false if failed.
	 * @return
	 */
	public CommandRunner setPostProcessor( Closure postProcessor ) {
		this.postProcesser = postProcessor
		return this
	}

	/**
	 * Sets the actual command, which is a String array of the command and its parameters.
	 * The CommandRunner can be given a string array or a string.  This is the string array version.
	 * @param command A string array where the first element is the actual command and every other
	 * element is a parameter (in order), such as ["command","param1","param 2"]
	 * @return Returns 'this'.
	 */
	public CommandRunner setCommand( String[] command ) {
		this.command = command;
		return this;
	}
	

	/**
	 * Sets the actual command, which is a String array of the command and its parameters.
	 * The CommandRunner can be given a string array or a string.  This is the string array version.
	 * @param command A List containing only String members where the first element is the actual command and every other
	 * element is a parameter (in order), such as ["command","param1","param 2"]
	 * @return Returns 'this'.
	 * **/
	public CommandRunner setCommand( List command ) {
		setCommand( command as String[] )
	}
	
	/**
	 * Sets the actual command.
	 * The CommandRunner can be given a string array or a string.  This is the string version.
	 * @param command This is the command line string passed onto the operating system.  You are
	 * responsible for putting quotes around appropriate parameters.
	 * @return Returns 'this'.
	 */
	public CommandRunner setCommand( String command ) {
		this.cmdString = command
		return this
	}

	/**
	 * Sets the title of the command.
	 * @param title The title.
	 * @return Returns 'this'.
	 */
	public CommandRunner setTitle( String title ) {
		this.title = title
		return this
	}
	
	/**
	 * Sets an optional timeout (in seconds).  If the timeout is set to a non-zero value, then an error is thrown if it runs out of time
	 * @param timeoutInSeconds The timeout in seconds, or 0 to have no timeout.
	 * @return Returns 'this'.
	 */
	public CommandRunner setTimeout( int timeoutInSeconds ) {
		this.timeoutInSeconds = timeoutInSeconds
		return this
	}

	/**
	 * Set the 'runViaCommandShell' property. If this is true, then the command is prefixed with a command shell call, which
	 * is "sh -c" for Linux/Unix or "cmd /c" for Windows.
	 * @return Return 'this'
	 */
	public CommandRunner setRunViaCommandShell( boolean runViaCommandShell=true ) {
		this.runViaCommandShell = runViaCommandShell
		return this
	}

	/**
	 * Call this function to set an output handler which is called to emit the
	 * output of the nested application.
	 * @param printHandler The command handler.  It is called once per line from
	 * the nested application.  It has one parameter - that line.  It should print,
	 * save, log, ... as appropriate.
	 * @return Returns 'this'
	 */
	public CommandRunner setPrintln( Closure printHandler ) {
		this.printHandler = printHandler;
		return this
	}
	
	/**
	 * Sets the output to 'Logger.trace' output every line
	 * @return returns 'this'
	 */
	public CommandRunner setPrintToTrace() {
		setPrintln { line -> Logger.info line }
	}

	/**
	 * Sets the active directory to use when calling the command.
	 * @param activeDirectory The active directory.  Set to null for current working directory.
	 * @return 'this'
	 */
	public CommandRunner setActiveDirectory( String activeDirectory ) {
		this.activeDirectory = activeDirectory;
		return this
	}

	/**
	 * Should the output of the nested command be sent to the standard output??
	 * @param displayOut
	 * @return
	 */
	public CommandRunner setDisplayOut( boolean displayOut ) {
		this.displayOutput = displayOut
		return this
	}
	
	/**
	 * Returns a string version of the command.  This is quite useable for logging output.
	 */
	public String getCommandAsString() {
		if (command) {
			String[] actualCommand = command
			if (runViaCommandShell) {
				String osName = System.getProperty("os.name")
				boolean isWindows = (osName.toLowerCase().contains("windows"))
				actualCommand = new String[command.size()+2]
				if (isWindows) {
					actualCommand[0] = "cmd"
					actualCommand[1] = "/c"
				} else {
					actualCommand[0] = "sh"
					actualCommand[1] = "-c"
				}
				for (int i=0; i<command.size(); ++i) {
					actualCommand[i+2] = command[i];
				}
	
			}
			return CommandLineHelper.getCommandString(actualCommand)
		} else {
			return cmdString
		}
	}

	/**
	 * Perform the command!!  Throws exception on error.
	 * @param printer The print handler to use, which ignores the member variable.  This allows for a 
	 * more dynamic replacement of the print handler.
	 * @return Returns the exit code returned by the command.  By convention,
	 * an exit code of 0 means success.
	 */
	private int runCommandImplementation( Closure printer ) {
		if (! printer) {
			printer = { line -> println line }
		}
		def actualCommand		// may be String or String[]
		boolean isCmdArray		// Is the command an array
		if (command) {
			isCmdArray = true
			actualCommand = command
		} else if (cmdString) {
			isCmdArray = false
			actualCommand = cmdString
		} else {
			PluginHelper.abortPlugin( "CommandRunner failed - no command was provided")
		}
		if (runViaCommandShell) {
			String osName = System.getProperty("os.name")
			boolean isWindows = (osName.toLowerCase().contains("windows"))
			if (isCmdArray) {
				actualCommand = new String[command.size()+2]
				if (isWindows) {
					actualCommand[0] = "cmd"
					actualCommand[1] = "/c"
				} else {
					actualCommand[0] = "sh"
					actualCommand[1] = "-c"
				}
				for (int i=0; i<command.size(); ++i) {
					actualCommand[i+2] = command[i];
				}
			} else {
				if (isWindows) {
					actualCommand = "cmd /c " + actualCommand
				} else {
					actualCommand = "sh -c " + actualCommand
				}
			}
		}
		
		printer "Calling command: ${this.getCommandAsString()}"
		
		StringBuffer cmdOut = new StringBuffer()
		Process proc
		if (this.activeDirectory) {
			// Verify the existence of the 'activeDirectory'.  If it doesn't exist, an odd exception is thrown.
			if (! (new File(activeDirectory)).isDirectory()) {
				PluginHelper.abortPlugin("Attempting to run a command script in the directory '${activeDirectory}', but the directory does not exist")
			}
			proc = actualCommand.execute( environmentVariables, (new File( activeDirectory )))
		} else {
			proc = actualCommand.execute( environmentVariables, null )
		}
		if (timeoutInSeconds > 0) {
			long startTime = System.currentTimeMillis()
			long endTime = startTime + ((long) timeoutInSeconds) * 1000L
			boolean procIsRunning = true
			while (procIsRunning) {
				if (System.currentTimeMillis() > endTime) {
					Logger.abortApplicationWithMessage("The command line call timed out (timeout set to ${timeoutInSeconds} seconds)")
				}
				// sleep for a second
				try {
					Thread.sleep(1000)
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt()
				}
				// Display any new output lines
				if (this.displayOutput) {
					cmdOut.eachLine() { line -> printer line }
				}
				// test to see if done - by seeing if there is an exit value
				try {
					proc.exitValue()
					// If the exitValue() call worked, then the proc is done!!
					procIsRunning = false
				} catch (IllegalThreadStateException e) {
					// the process isn't done yet
				}
			}
		} else {
			// The following line waits until the process is done
			proc.waitForProcessOutput(cmdOut, cmdOut)
			if (this.displayOutput) {
				cmdOut.eachLine() { line -> printer line }
			}
		}
		this.exitValue = proc.exitValue() 
		return this.exitValue

	}
	
	
	/**
	 * Perform the command!!  Throws exception on error.
	 * @return Returns the exit code returned by the command.  By convention,
	 * an exit code of 0 means success.
	 */
	public int runCommand() {
		int retval
		boolean ran = false
		String bufferedOutput = ''
		Closure nestedPrintHandler = printHandler
		// default to a false success
		success = false
		// This runs the command within the context of the verbose flag.
		if (! nestedPrintHandler) {
			nestedPrintHandler = { line -> println line }
		}
		Closure verbosePrintHandler = { line ->
			bufferedOutput += line +  "\n"
			if (verboseMode) {
				nestedPrintHandler line
			}
		}
		
		try {
			retval = runCommandImplementation(verbosePrintHandler)
			if (postProcesser( this, bufferedOutput )) {
				// command was success
				success = true
			} else {
				success = false
				// command failed - output if not verbose
				if (! verboseMode) {
					bufferedOutput.eachLine() { line -> nestedPrintHandler line }
				}
			}
			ran = true
		}
		finally {
			// In the event of an exception, display bufferedOutput
			if ((! ran) && (! verboseMode)) {
				bufferedOutput.eachLine() { line -> nestedPrintHandler line }
			}
		}
		return retval
	}
	
	/**
	 * Perform the command!!  Throws exception on error.
	 * @return Returns 'this'.
	 */
	public CommandRunner execute() {
		runCommand()
		return this
	}

	/**
	 * This should ONLY be called after runCommand() and it returns the
	 * exitValue from the command line.  0 generally means success and non-zero
	 * generally means failure.
	 */
	public int getExitValue() {
		return exitValue
	}
	
	/**
	 * Did the call work successfully - which means that it ran to completion and the posProcesser() command returned true.
	 */
	public boolean wasSuccessful() {
		return success
	}
}