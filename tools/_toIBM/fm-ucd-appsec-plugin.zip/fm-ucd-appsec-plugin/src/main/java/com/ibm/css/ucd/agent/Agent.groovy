package com.ibm.css.ucd.agent

import com.ibm.css.rest.ucd.UcdServerConnection;
import com.ibm.css.ucd.common.EntityWithNameAndId;

/**
 * Represents one UCD Agent.
 * @author ltclark
 *
 */
class Agent extends EntityWithNameAndId {
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the UCD Server.
	 * @param info This is an Object version of the call to /cli/agentCLI/info.
	 * Note that it has at least two fields - name and id.
	 */
	public Agent( UcdServerConnection ucdServer, def info ) {
		super( ucdServer, info.name, info.id )
	}
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 */
	public Agent( UcdServerConnection ucdServer, String name, String id ) {
		super( ucdServer, name, id )
	}

}
