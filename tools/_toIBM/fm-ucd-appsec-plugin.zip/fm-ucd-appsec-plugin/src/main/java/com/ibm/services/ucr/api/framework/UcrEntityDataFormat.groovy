package com.ibm.services.ucr.api.framework

/**
 * This class is used to identify what "format" was used when retrieving data
 * from UCR via REST calls.
 * When retrieving data from UCR using REST calls, you use a String format
 * label to specify how detailed the return information is.  The standard
 * formats are 'list', 'detail' and 'name'.  However, any given type of entity
 * can define additional retrieval formats.
 * @author LeonClark
 *
 */
class UcrEntityDataFormat {
	
	/**
	 * The instances.  The key is a formatName and the value is the UcrEntityDataFormat instance.
	 */
	private static Map _instances = [:]
	
	public static UcrEntityDataFormat NAME_FORMAT = UcrEntityDataFormat.getInstance('name',[])
	public static UcrEntityDataFormat LIST_FORMAT = UcrEntityDataFormat.getInstance('list',[NAME_FORMAT])
	public static UcrEntityDataFormat DETAIL_FORMAT = UcrEntityDataFormat.getInstance('detail',[NAME_FORMAT,LIST_FORMAT])
	
	private final String formatName
	private final Set subsetFormats
	
	/**
	 * Does this format type contain 'detailed' information?
	 */
	public boolean isDetailed() {
		return this == DETAIL_FORMAT
	}
	
	/**
	 * Private constructor.
	 * @param formatName The name of the format, such as list, detail or name.
	 * @param subsetFormats This is a List of 'UcrEntityDataFormat's which are a subset
	 * of this format.  For example, NAME_FORMAT is a subset of DETAIL_FORMAT and LIST_FORMAT.
	 */
	private UcrEntityDataFormat( String formatName, List subsetFormats ) {
		this.formatName = formatName
		this.subsetFormats = subsetFormats as Set
	}
	
	/**
	 * Returns a UcrEntityDataFormat for the given format name
	 * @param formatName The name of the format, such as list, detail or name.
	 * @param subsetFormats This is a List of 'UcrEntityDataFormat's which are a subset
	 * of this format.  For example, NAME_FORMAT is a subset of DETAIL_FORMAT and LIST_FORMAT.
	 */
	public static UcrEntityDataFormat getInstance( String formatName, List subsetFormats ) {
		if (! _instances.containsKey(formatName)) {
			_instances[formatName] = new UcrEntityDataFormat(formatName,subsetFormats)
		}
		return _instances[formatName]
	}
	
	/**
	 * Returns the string name of the format, such as 'list' or 'detail'.
	 * @return
	 */
	public getFormatName() {
		return formatName
	}
	
	public String toString() {
		return super.toString() + "( format='${formatName}' )"
	}
	
	/**
	 * Is 'this' format a superset of 'format'.  It is a superset if it contains at least
	 * as much data.  For example, the Detail format is a superset of the List format.
	 */
	public boolean isSuperset( UcrEntityDataFormat format ) {
		return subsetFormats.contains(format) || this.equals(format)
	}
}
