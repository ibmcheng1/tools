package com.ibm.issr.core.csv

/**
 * Use this class to access a CSV table (of type 'List<String[]>') as a set of rows
 * where the designated (default first) row contains column header names.
 * @author ltclark
 *
 */
class TableWithColumnHeadings {
	private List<String[]> rows
	private int headingRow = 0
	private boolean caseSensitive = false
	
	private boolean processed = false
	// columnNames is a map where the key is a String column name and the value is the integer column
	// If 'caseSensitive' is false, then the column name is lower case
	private def columnNames = [:]
	
	/**
	 * Constructor, which takes the full list of rows
	 */
	public TableWithColumnHeadings( List<String[]> rows ) {
		this.rows = rows
	}

	/**
	 * Call this function to set the heading row to anything other than 0.
	 * @param headingRow The heading row number.  0 based (first row is 0, etc)
	 */
	public void setHeadingRow( int headingRow ) {
		this.headingRow = headingRow
	}	
	
	/**
	 * By default, the column headings are case insensitive (specifically, all lower case).
	 * Call this function to make the column headings case sensitive
	 */
	public void setCaseSensitive() {
		caseSensitive = true
	}
	
	/**
	 * This is an internal function that processes the headings one and only one time.
	 */
	private void processHeadings() {
		if (! processed) {
			processed = true
			
			// get the column headings
			rows[headingRow].eachWithIndex{ columnName, columnIndex ->
				columnName = columnName.trim()
				if (! caseSensitive) {
					columnName = columnName.toLowerCase()
				}
				if (columnName) {
					columnNames[columnName] = columnIndex
				}
			}
			
			// strip out the column headings from the rows
			for (int i=0; i<=headingRow; ++i) {
				rows.remove(i)
			}
		}
	}
	
	/**
	 * Returns a map ([:]) of the column headings where the key is the column name
	 * and the value is the column number.  Call this AFTER setting any options.  If
	 * not caseSensitive, then the column names are all lower case.
	 * @return the map of column names
	 */
	public def getColumnNames() {
		processHeadings()
		return columnNames
	}
	
	/**
	 * Returns the list of rows with the column heading rows removed.
	 * @return The rows
	 */
	public List<String[]> getRows() {
		processHeadings()
		return rows
	}
}
