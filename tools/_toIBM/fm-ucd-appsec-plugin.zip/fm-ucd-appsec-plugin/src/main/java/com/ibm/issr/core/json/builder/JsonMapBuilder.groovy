package com.ibm.issr.core.json.builder

/**
 * Helper function to build a json map entry.
 * Call 'addEntry' for each additional entry in the map.  Then call
 * 'toJsonString()' to get the final string.
 * @author ltclark
 *
 */
class JsonMapBuilder implements JsonBuilderInterface {
	// map of entries.  Key is the name.  Value is the value
	Map entries = [:]

	/**
	 * Adds another entry to the map.  Note that if you want to use
	 * nested json strings, use an instance of JsonBuilderInterface.
	 * @param name The map name of the entry
	 * @param value The value.  
	 * If this is a JsonBuilderInterface, then the toJsonString() value of the builder
	 * is used (without quotes).
	 * For any other values, groovy.json.JsonOutput.toJson() is called on the
	 * value to properly encode it, quote it, etc
	 * @return As a convenience, returns 'this'.
	 */
	public JsonMapBuilder addEntry( String name, def value ) {
		entries[name] = value
		return this
	}

	/**
	 * Returns the composite list as a json string.
	 */
	public String toJsonString() {
		StringBuffer retval = new StringBuffer( '{' )
		String delim = ''
		entries.each { String name, def value ->
			if (value == null) {
				// completely skip null value
			} else {
				if (delim) {
					retval.append(delim)
				} else {
					delim = ','
				}
				retval.append( '"' )
				retval.append( name )
				retval.append( '":' )
				if (value instanceof JsonBuilderInterface) {
					// for a json string, simply append the value with no quotes
					retval.append( ((JsonBuilderInterface) value).toJsonString() )
				} else {
					retval.append( groovy.json.JsonOutput.toJson(value) )
				}
			}
		}
		retval.append('}')
		return retval.toString()
		return retval
	}
}
