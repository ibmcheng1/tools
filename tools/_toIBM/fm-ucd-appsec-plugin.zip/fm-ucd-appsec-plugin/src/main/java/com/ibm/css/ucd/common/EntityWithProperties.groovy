package com.ibm.css.ucd.common

import com.ibm.css.ucd.property.Property


interface EntityWithProperties {
	
	/**
	 * Does this component have any property (basic or entity) with the given name?
	 */
	public boolean hasPropertyEntry( String name, boolean resetCache )
	
	/**
	 * Does this component have any property (basic or entity) with the given name?
	 */
	public boolean hasPropertyEntry( String name )

	/**
	 * If this entity has a Basic or Entity property with the given name, then the property entry/value
	 * is returned.  Otherwise, an exception is thrown.
	 */
	public Property getPropertyEntry( String name, boolean resetCache )
	
	/**
	 * If this entity has a Basic or Entity property with the given name, then the property entry/value
	 * is returned.  Otherwise, an exception is thrown.
	 */
	public Property getPropertyEntry( String name )

}
