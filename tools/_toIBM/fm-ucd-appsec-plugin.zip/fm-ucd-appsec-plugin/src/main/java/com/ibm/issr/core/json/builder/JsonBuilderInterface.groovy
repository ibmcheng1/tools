package com.ibm.issr.core.json.builder

/**
 * Interface for classes that output json strings when calling toJsonString().
 * @author ltclark
 *
 */
interface JsonBuilderInterface {
	
	/**
	 * Returns the json string value of the Json Builder object
	 */
	public String toJsonString()

}
