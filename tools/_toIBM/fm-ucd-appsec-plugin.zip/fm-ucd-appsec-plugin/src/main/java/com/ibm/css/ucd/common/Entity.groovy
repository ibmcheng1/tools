package com.ibm.css.ucd.common

import com.ibm.css.rest.ucd.UcdServerConnection

/**
 * Base class for all entity classes.
 * @author ltclark
 *
 */
class Entity {
	// handle to the UCD Server
	protected UcdServerConnection ucdServer
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 */
	public Entity( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
	}
	
	/**
	 * Returns the Type name of the entity, such as 'Component' or 'Application'.
	 * The default implementation returns the name of the entity's class.
	 */
	public String getEntityTypeName() {
		return this.getClass().getName()
	}
}
