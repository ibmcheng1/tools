package com.ibm.css.rest.ucd.component.version

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.component.ComponentApi
import com.ibm.issr.core.log.Logger
import com.ibm.issr.rest.RestDelete
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPost
import com.ibm.issr.rest.RestPut
import com.ibm.issr.rest.RestResponse

/**
 * API Calls for Component Versions
 * @author ltclark
 *
 */
class ComponentVersionApi {
	UcdServerConnection ucdServer
	
	/**
	 * Constructor for this light weight class.
	 * @param ucdServer Handle to UCD Server
	 */
	public ComponentVersionApi( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
	}

	/**
	 * Does the named application exist?
	 * @param componentId The ID of the component for the version
	 * @param versionName The name of the desired version.
	 * @return true or false
	 */
	public boolean doesComponentVersionExist( String componentId, String versionName ) {
		// Implementation notes - the /cli/version/getVersionId behaves differently than other UCD REST calls
		//   - It simply returns the string value of the ID.  Specifically, it does NOT return JSON!!
		//   - If the version name isn't found, it returns HTTP code 400 (malformed request) instead of
		//     HTTP code 404 (record not found)
		// So this uses special handling!!  Specifically, it uses the core get() function with a custom closure.
		return (new RestGet( ucdServer ))
			.setPath("/cli/version/getVersionId")
			.addParameter("component", componentId)
			.addParameter("version", versionName)
			.get() { RestResponse response ->
				// Returns true if component version exists or false if it doesn't
				if (response.httpStatus==400 || response.httpStatus==404 || response.httpStatus==500) {
					// The requested entity doesn't exist
					return false
				} else {
					response.throwExceptionOnBadResponse()
					return true
				}
	
			}
	}

	/**
	 * Returns the internal UCD id for a Component Version Name or throws exception if not found.
	 * @param ucdServer Handle to a UCD Server Session.
	 * @param componentId The ID (and NOT the name) of the component.
	 * @param versionName The name of the version.
	 * @return The internal UCD id.
	 */
	@Deprecated
	public static String getComponentVersionIdForName( UcdServerConnection ucdServer, String componentId, String versionName ) {
		return (new ComponentVersionApi(ucdServer)).getComponentVersionIdForName(componentId, versionName)
	}
	
	/**
	 * Returns the internal UCD id for a Component Version Name or throws exception if not found.
	 * @param componentId The ID (and NOT the name) of the component.
	 * @param versionName The name of the version.
	 * @return The internal UCD id.
	 */
	public String getComponentVersionIdForName( String componentId, String versionName ) {
		// Implementation notes - the /cli/version/getVersionId behaves differently than other UCD REST calls
		//   - It simply returns the string value of the ID.  Specifically, it does NOT return JSON!!
		//   - If the version name isn't found, it returns HTTP code 400 (malformed request) instead of
		//     HTTP code 404 (record not found)
		// So this uses special handling!!  Specifically, it uses the core get() function with a custom closure.
		return (new RestGet( ucdServer ))
			.setPath("/cli/version/getVersionId")
			.addParameter("component", componentId)
			.addParameter("version", versionName)
			.get() { RestResponse response ->
				// Returns true if component version exists or false if it doesn't
				if (response.httpStatus==400 || response.httpStatus==404 || response.httpStatus==500) {
					// The requested entity doesn't exist
					throw new Exception( "No version named ${versionName} was found" )
				} else {
					response.throwExceptionOnBadResponse()
					return response.responseAsString
				}
	
			}
	}

	/**
	 * Sets the value of the named version property for the given component + version.
	 * @param ucdServer Handle to a UCD Server Session.
	 * @param componentId The ID (and NOT the name) of the component.
	 * @param versionId The ID of the component version.
	 * @param propertyName The name of the property
	 * @param propertyValue The new value
	 * @param createIfMissing Should it create the property if it doesn't already exist
	 * @param propertyType The type of the property
	 * @return Returns true if the property was set or false if it wasn't set.
	 */
	public static boolean setComponentVersionProperty( UcdServerConnection ucdServer, String componentId, String versionId, String propertyName, String propertyValue, boolean createIfMissing=true, String propertyType="TEXT" ) {
		boolean propertyExists = true
		if (! ComponentVersionApi.doesComponentVersionPropertyExist( ucdServer, componentId, propertyName )) {
			if (createIfMissing) {
				// Define the property
				(new RestPut( ucdServer )).setPath("/cli/component/versionPropDefs")
						.addParameter( "component", componentId )
						.addParameter( "name", propertyName )
						.addParameter( "type", propertyType )
						.putWithNoReturnObject()
			} else {
				propertyExists = false
			}
		}
		if (propertyExists) {
			// Set the property value
			if (ucdServer.isServerVersionAtLeast6_2_7()) {
				Map payload = [ component: componentId, version: versionId,
					name: propertyName, value: propertyValue ]
				(new RestPut( ucdServer )).setPath("/cli/version/versionProperties")
					.setJsonPayloadToObject(payload)
					.putWithNoReturnObject()
			} else {
				(new RestPut( ucdServer )).setPath("/cli/version/versionProperties")
						.addParameter("component", componentId)
						.addParameter("version", versionId)
						.addParameter("name", propertyName)
						.addParameter("value",propertyValue)
						.addParameter("isSecure", "false")
						.putWithNoReturnObject()
			}
			return true
		} else {
			return false
		}
	}

	/**
	 * Retrieves ALL of the component version properties.
	 * @param ucdServer Handle to the UCD Server session.
	 * @param componentId THe ID (not the name) of the component.
	 * @param versionId The ID (not the name) of the Version.
	 * @return A List of of the property value entries.  For each entry, the '.name' field is the property name
	 * and the '.value' is the value.
	 */
	public static List getComponentVersionProperties( UcdServerConnection ucdServer, String componentId, String versionId ) {
		
		return (new RestGet( ucdServer )).setPath("/cli/version/versionProperties")
				.addParameter("component", componentId)
				.addParameter("version", versionId)
				.getAsObject()
	}

	/**
	 * Gets the value of the named version property for the given component + version.
	 * @param ucdServer Handle to a UCD Server Session.
	 * @param componentId The ID (and NOT the name) of the component.
	 * @param versionId The ID of the component version.
	 * @param propertyName The name of the property
	 * @return Returns the value of the property or an empty string if not found.
	 */
	public static String getComponentVersionProperty( UcdServerConnection ucdServer, String componentId, String versionId, String propertyName ) {

		def propertyValues = (new RestGet( ucdServer )).setPath("/cli/version/versionProperties")
				.addParameter("component", componentId)
				.addParameter("version", versionId)
				.getAsObject()

		// search for a name value pair in the 'propertyValues'
		boolean propertyFound = false;
		String propertyValue = "";
		propertyValues.each() { propertyValueEntry ->
			if (propertyValueEntry.name.equals(propertyName)) {
				propertyFound = true;
				propertyValue = propertyValueEntry.value;
			}
		}

		if (! propertyFound) {
			// The property was NOT found for the Component Version.  Check to see if a default value is defined by the Component's Version Property definitions
			def propertyDefinitions = (new RestGet( ucdServer )).setPath("/cli/version/versionPropDefs")
					.addParameter("component", componentId)
					.getAsObject()
			propertyDefinitions.each() { propertyDefinition ->
				if (propertyDefinition.name.equals(propertyName)) {
					propertyValue = propertyDefinition.value;
				}
			}
		}
		return propertyValue;
	}


	/**
	 * Is there a version of the component with the given name (label)?
	 * @param ucdServer Handle to a UCD Server Session.
	 * @param componentId The internal UCD ID for a specific Component
	 * @param versionName The name of the version to test for.
	 * @return true if it exists or false if not.
	 */
	public static boolean doesComponentVersionExist( UcdServerConnection ucdServer, String componentId, String versionName ) {
		boolean retval = false

		def componentVersionEntityList = (new RestGet( ucdServer )).setPath("/rest/deploy/component/${componentId}/versions/false")
				.addParameter("name", versionName)
				.getAsObject()

		componentVersionEntityList.each { componentVersion ->
			if (componentVersion.name.equals(versionName)) {
				retval = true
			}
		}

		return retval
	}
	
	
	/**
	 * Returns the list of versions of this component.
	 * @param ucdServer Handle to the UCD Server.
	 * @param componentId The Component ID
	 * @param includeInactive Should inactive versions be included.
	 * @return The List returned by the '/cli/component/versions' call, which may be empty. Each entry includes
	 * id, name, type (FULL or ...), created (#), active (boolean), archived (boolean)
	 */
	public static List getComponentVersions( UcdServerConnection ucdServer, String componentId, boolean includeInactive=false ) {
		return (new RestGet( ucdServer )).setPath("/cli/component/versions")
			.addParameter("component", componentId)
			.addParameter("inactive", includeInactive.toString())
			.getAsObject()
	}
	
	
	/**
	 * Creates a new Component Version.  This does NOT check if the version exists yet.  This throws an exception on failure.
	 * @param ucdServer Handle to a UCD Server Session.
	 * @param componentId The internal UCD ID for a specific Component
	 * @param versionName The name of the new version.
	 * @param description Optional description of the new version.
	 */
	public static void createNewComponentVersion(UcdServerConnection ucdServer, String componentId, String versionName, String description ) {
		def componentVersionEntityList = (new RestPost( ucdServer )).setPath("/cli/version/createVersion")
			.addParameter( 'component', componentId )
			.addParameter("name", versionName)
			.addParameter('description',description)
		.postAsObject()

	}


	/**
	 * Is there a property with the given name for the given Component?
	 * @param ucdServer Handle to a UCD Server Session.
	 * @param componentId The internal UCD ID for a specific Component
	 * @param propertyName The name of the property.
	 * @return true if it exists or false if not.
	 */
	public static boolean doesComponentVersionPropertyExist( UcdServerConnection ucdServer, String componentId, String propertyName ) {
		def propertySheet = ComponentApi.getPropertySheetForComponentVersion(ucdServer, componentId);

		Logger.debug("{setVersionProp}.doesComponentVersionPropertyExist() - property sheet is ${propertySheet}")

		def propertyExists = false
		propertySheet.each() { propertySheetEntry ->
			if (propertySheetEntry.name.equals(propertyName)) {
				propertyExists = true;
			}
		}
		return propertyExists;

	}
	
	/**
	 * Returns the list of approval flags that are set for the given component version ID.
	 * @param ucdServer Handle to a UCD Server Session.
	 * @param componentVersionId The ID of the Component Version.
	 * @return a List of status flag structures.  Each status flag structure includes 'name' which is
	 * the name of the status flag and 'id' which is the ID of the status flag.
	 */
	public static List getComponentVersionFlags( UcdServerConnection ucdServer, String componentVersionId ) {
		def componentVersion = (new RestGet( ucdServer )).setPath("/rest/deploy/version/${componentVersionId}")
			.getAsObject()

		return componentVersion.statuses
	}
	
	/**
	 * Sets/adds the named Component Version Status Flag to the Component Version.
	 * @param ucdServer Handle to a UCD Server Session.
	 * @param componentVersionId The ID of the Component Version.
	 * @param flagName The name of the flag to set.
	 */
	public static void setComponentVersionFlag(UcdServerConnection ucdServer, String componentVersionId, String flagName) {
		(new RestPut( ucdServer )).setPath("/cli/version/addStatus")
			.addParameter("version", componentVersionId)
			.addParameter("status", flagName)
			.putWithNoReturnObject()
	}
	
	/**
	 * Removes the named Component Version Status Flag from the Component Version.
	 * @param ucdServer Handle to a UCD Server Session.
	 * @param componentVersionId The ID of the Component Version.
	 * @param flagName The name of the flag to remove.
	 */
	public static void removeComponentVersionFlag(UcdServerConnection ucdServer, String componentVersionId, String flagName) {
		(new RestDelete( ucdServer )).setPath("/cli/version/status")
			.addParameter("version", componentVersionId)
			.addParameter("status", flagName)
			.deleteWithNoReturnObject()
	}
}
