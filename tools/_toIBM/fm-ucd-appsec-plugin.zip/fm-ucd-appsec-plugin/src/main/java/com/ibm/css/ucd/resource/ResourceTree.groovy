package com.ibm.css.ucd.resource

import com.ibm.css.rest.ucd.UcdServerConnection

/**
 * This entity class represents the root of the UCD Resource Tree
 * @author ltclark
 *
 */
class ResourceTree extends ResourceNode {
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the UCD Server.
	 */
	public ResourceTree( UcdServerConnection ucdServer ) {
		super( ucdServer, null, null )
	}

	@Override
	public String getResourcePath() {
		return "";
	}

	@Override
	public ResourceNode getParent() {
		return null;
	}

	@Override
	public String getNodeType() {
		return ROOT_NODE_TYPE
	}
	
	@Override
	public boolean isRootNode() {
		return true
	}

	@Override
	public void addTag(String name) {
		throw new Exception("You can't add tags to the Resource Tree")
	}

	@Override
	public boolean areTeamsInherited() {
		// For the root node, this makes no sense, so it is false
		return false;
	}
	
	/**
	 * Return the resource node for the given resource path.
	 * @param resourcePath The path, such as '/root/env/sampleAgent/sampleComponent'
	 */
	public ResourceNode getResourceNode( String resourcePath ) {
		ResourceNode currentNode = this
		// break path into elements
		List pathElements = resourcePath.tokenize('/')
		pathElements.each { String pathElement ->
			if (pathElement) {
				currentNode = currentNode.getChildNode(pathElement)
			}
		}
		return currentNode
	}

}
