
package com.ibm.services.ucr.api.entity.versionstatus

import java.nio.charset.Charset

import org.apache.http.entity.mime.HttpMultipartMode
import org.apache.http.entity.mime.MultipartEntity
import org.apache.http.entity.mime.content.FileBody
import org.apache.http.entity.mime.content.StringBody

import com.ibm.issr.core.entity.EntityWithId
import com.ibm.issr.core.url.UrlUtilities
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPost
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.cache.RestDataCache
import com.ibm.services.ucr.api.entity.status.UcrStatus
import com.ibm.services.ucr.api.entity.version.UcrVersion
import com.ibm.services.ucr.api.entity.versionstatuscomment.UcrVersionStatusComment
import com.ibm.services.ucr.api.entity.versionstatuscomment.UcrVersionStatusCommentMgr
import com.ibm.services.ucr.api.framework.UcrEntityData
import com.ibm.services.ucr.api.framework.UcrEntityDataFormat
import com.ibm.services.ucr.api.framework.UcrEntityWithId

class UcrVersionStatus extends UcrEntityWithId implements EntityWithId {
	// The cache of the UcrEntityData for this entity
	private RestDataCache _cachedEntityData = new RestDataCache()
	
	// The version and status for this VersionStatus
	private UcrVersion _version
	private UcrStatus _status

	/**
	 * Private constructor - do NOT call directly from any other class.
	 * @param entityData This is optional UcrEntityData (data returned from a REST call defining this entity).  If
	 * given, then it is cached.
	 */
	private UcrVersionStatus( RestServerConnection ucrServer, UcrVersion version, UcrStatus status, String id, UcrEntityData entityData = null ) {
		super( ucrServer, id )
		if (entityData) {
			_cachedEntityData.setCacheData(ucrServer, entityData)
		}
		this._version = version
		this._status = status
	}
	
	/**
	 * Resets the cached data storing internal data for this class instance.
	 */
	public void resetCachedData() {
		_cachedEntityData.resetCacheData(ucrServer)
	}
	
	/**
	 * Returns entity data for this entity which is at LEAST the 'minDataFormat' level of information.  For example,
	 * if the minDataFormat is LIST_FORMAT, then both LIST_FORMAT and DETAIL_FORMAT are suitable.
	 * If possible, this returns cached data, otherwise it loads (and caches) the data.
	 */
	public UcrEntityData getEntityData( UcrEntityDataFormat minDataFormat, boolean resetCache=false ) {
		UcrEntityData entityData = _cachedEntityData.getCacheData(ucrServer,resetCache)
		if ((! entityData) || (! entityData.getEntityFormat().isSuperset( minDataFormat ))) {
			// Load the 'detail' data and cache it
			def data = (new RestGet( ucrServer ))
				.setPath("/versionStatus/" + this.id)
				.addParameter('format', minDataFormat.getFormatName())
				.setHeader('Accept', 'application/json')
				.getAsObject()
			_cachedEntityData.setCacheData(ucrServer, new UcrEntityData(data, minDataFormat))
		}
		return _cachedEntityData.getCacheData(ucrServer)
	}

	/**
	 * Returns detail'ed entity data.  This is data retrieved via a REST call with format of 'detail'.  If possible,
	 * this returns cached data, otherwise it loads (and caches) the data.
	 */
	public UcrEntityData getDetailedEntityData( boolean resetCache=false ) {
		return getEntityData( UcrEntityDataFormat.DETAIL_FORMAT, resetCache )
	}

	
	/**
	 * Returns at least a LIST level UcrEntityData for this class, which is the underlying REST/JSON based data structure.
	 */
	public UcrEntityData getEntityData( boolean resetCache = false ) {
		return getEntityData( UcrEntityDataFormat.LIST_FORMAT, resetCache )
	}

	/**
	 * Returns the UCRStatus for this UcrVersionStatus.
	 */
	public UcrStatus getStatus() {
		return _status
	}
	
	/**
	 * Returns the UcrVersion for this UcrVersionStatus.
	 * @return
	 */
	public UcrVersion getVersion() {
		return _version
	}
	
	/**
	 * Returns the comments for this VersionStatus as a List of type UcrVesionStatusComment
	 */
	public List getComments( boolean resetCache = false ) {
		UcrEntityData entityData = getEntityData(resetCache)
		def data = entityData.getEntityObject()
		List comments = []
		if (data.containsKey('comments')) {
			UcrVersionStatusCommentMgr mgr = UcrVersionStatusCommentMgr.getInstance(ucrServer)
			data.comments.each { def commentData ->
				comments << mgr.buildEntity(ucrServer, this, commentData.id, commentData.comment)
			}
		}
		return comments
	}
	
	/**
	 * Adds a new comment to this VersionStatus returning the comments new UcrVersionStatusComment record.
	 * Throws exception on failure.  The new comment is immediately saved!!  No other save() needs to be called.
	 * @param comment The comment.  This can be multiple lines.  In code, simply use '\n' for a new line.
	 * I haven't seen any need to escape any characters.
	 */
	public UcrVersionStatusComment addComment( String comment ) {
		def payload = [ comment: comment, versionStatus: this.getId() ]
		String redirectUrl = (new RestPost( ucrServer ))
			.setPath('/versionStatusComment/')
			.setJsonPayloadToObject(payload)
//			.setHeader('Accept', 'application/json')
			.setHeader('Accept', '*/*')
//			.setHeader('Accept-Encoding', 'gzip,deflate')
			.setHeader('Content-Type', 'application/json')
			.postAndReturnRedirect()
		this.resetCachedData()	
		return UcrVersionStatusCommentMgr.getInstance(ucrServer).buildEntity( ucrServer, this, UrlUtilities.getLastSegmentOfUrl(redirectUrl), comment )
	}
	
	/**
	 * Adds a new file attachment to this VersionStatus.  Throws exception on failure.
	 * The new file is immediately saved!!  No other save() needs to be called.
	 * @param filePath The name of the file.  It can be an absolute or relative path.
	 * @param fileDescription The description for the file.
	 */
	public void addAttachment( String filePath, String fileDescription ) {
		if (! fileDescription) {
			fileDescription = ''
		}
		MultipartEntity entity = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE)
		File file = new File(filePath)
		if (! file.exists()) {
			throw new Exception( "Unable to upload attachment named '${filePath}', because the file doesn't exist.")
		}
		entity.addPart("description", new StringBody(fileDescription,"text/plain",Charset.forName("UTF-8")))
		FileBody filebody = new FileBody( file, "text/plain" )
		entity.addPart("file", filebody)
		entity.addPart("modelID", new StringBody(this.getId(),"text/plain",Charset.forName("UTF-8")))
		entity.addPart("fileName", new StringBody(file.name,"text/plain",Charset.forName("UTF-8")))
		
		String redirectUrl = (new RestPost( ucrServer ))
			.setPath('/versionStatusAttachment/importAttachment')
			.setMultiPartEntity(entity)
			.setHeader('Accept', '*/*')
			.postWithNoReturnObject()
	}
	
	/**
	 * Returns the List of attachment files, where each element in the list is of type UcrVersionStatusAttachment.
	 */
	public List getAttachments( boolean resetCache = false ) {
		List attachments = []
		UcrEntityData entityData = getEntityData(resetCache)
		def data = entityData.getEntityObject()
		if (data.containsKey('attachments')) {
			data.attachments.each { Map attachmentData -> 
				UcrVersionStatusAttachment attachment = new UcrVersionStatusAttachment(attachmentData.id, this, 
					attachmentData.description, attachmentData.fileName, attachmentData.version, 
					attachmentData.dateCreated, attachmentData.username, attachmentData.userId)
				attachments << attachment
			}
		}
		return attachments
	}
}
