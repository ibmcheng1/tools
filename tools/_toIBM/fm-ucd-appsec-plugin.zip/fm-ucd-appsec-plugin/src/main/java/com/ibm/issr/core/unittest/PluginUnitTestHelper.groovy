package com.ibm.issr.core.unittest

import com.ibm.issr.core.log.Logger

/**
 * This class is designed to make it easy to call the main executable for plugin steps for
 * unit testing.  This includes the following capabilities: Ability to set inbound properties,
 * ability to retrieve output properties, ability to capture the output log.
 * <p/>
 * Note that the current directory is used as the Plugin step's current working directory.  Java/Groovy
 * doesn't have a mechanism to change the current directory within a running application.
 * <p/>
 * Create an instance of this class to perform a plugin unit test.
 * <p/>
 * To call your plugin ...
 * <br/>- Define and set your 'Properties inProps'
 * <br/>- PluginUnitTestHelper unitTestHelper = new PluginUnitTestHelper()
 * <br/>- Call 'unitTestHelper.preparePluginClass( PluginClass.class )'
 * <br/>- Call PluginClass.main(unitTestHelper.getPluginParameters(inProps))
 * <br/>- Call 'Properties outProps = unitTestHelper.getOutputProperties()' to get the output properties.
 * <br/>- Call 'unitTestHelper.getCapturedLog()' to get the Logger output
 * <br/>- Optionally call unitTestHelper.cleanup() to delete the input and output property files.
 * @author ltclark
 *
 */
class PluginUnitTestHelper {
	final String pluginInputFile = "inprops.txt"
	final String pluginOutputFile = "outprops.txt"
	// All Logger output is captured in this string
	String capturedLog = ''
	String logDelim = ''
	
	/**
	 * Constructor which automatically starts to capture the Logger output.
	 */
	public PluginUnitTestHelper() {
		Logger.outputLine = { String msg ->
			println msg
			capturedLog = capturedLog + logDelim + msg
			logDelim = "\n"
		}
	}
	
	/**
	 * Call this function to prepare a Plugin Class to be called from a Test framework.
	 * This does the following. (1) Any exit calls in the plugin normally call system.exit().  Instead,
	 * they throw an exception.
	 * @param pluginClass This is the plugin class, such as UcdApplication.class.
	 */
	public void preparePluginClass( def pluginClass ) {
		pluginClass.exitSystem = { int exitCode ->
			throw new Exception( "Exiting application with exitCode of ${exitCode}" )
		}
	}
	
	/**
	 * Returns all of the Logger logged output as a string.
	 */
	public String getLoggerOutput() {
		return capturedLog
	}

	/**
	 * Creates the 'String[] args' parameter to pass to the plugin with 'inProps' defining
	 * the input properties.
	 * @param inProps The properties to pass to the plugin.
	 * @return The 
	 */
	public java.lang.String[] getPluginParameters( Properties inProps ) {
		def inPropsFile = new File(pluginInputFile)
		def inPropsStream = new FileOutputStream(inPropsFile)
		inProps.store(inPropsStream, "Input props")
	
		java.lang.String[] args = [pluginInputFile,pluginOutputFile]
		return args
	}
	
	/**
	 * Returns an empty argument list that can be used in calling the plugin step.
	 * Use this when directly setting the inProps and outProps without going through files.
	 */
	public java.lang.String[] getEmptyArgumentList() {
		java.lang.String[] args = []
		return args
	}
	
	/**
	 * Call this function after calling to plugin in order to retrieve its output properties.
	 * @return The plugin's output properties.
	 */
	public Properties getOutputProperties() {
		Properties outProps = new Properties()
		def outPropsFile = new File(pluginOutputFile)
		def outPropsStream = new FileInputStream(outPropsFile)
		outProps.load(outPropsStream)
		return outProps
	}

	/**
	 * Cleanup after running by deleting the input and output files
	 */
	public void cleanup() {
		deleteFile( pluginInputFile )
		deleteFile( pluginOutputFile )
	}
	
	/**
	 * Attempts to delete the named file if it exists.  This intentionally eats
	 * exceptions.  This is called by the cleanup code, which doesn't care if there
	 * is an exception.
	 * @param filename The name of the file to delete.
	 */
	private void deleteFile( String filename ) {
		File file = new File(filename)
		try {
			if (file.exists()) {
				file.delete()
			}
		}
		catch (Exception e) {
			// eat the exception
		}
	}
}
