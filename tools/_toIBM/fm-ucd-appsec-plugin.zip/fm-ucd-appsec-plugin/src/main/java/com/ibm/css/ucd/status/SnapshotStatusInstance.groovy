package com.ibm.css.ucd.status;

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.common.EntityWithNameAndId
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.css.ucd.snapshot.Snapshot

/**
 * Represents one instance specific (aka specific to Snapshot) instance of a snapshot status
 *
 * @author LeonClark
 *
 */
public class SnapshotStatusInstance extends EntityWithNameAndId {
	private Snapshot snapshot
	
	/**
	 * The snapshotStatus is loaded on demand (if it is null).
	 */
	private SnapshotStatus snapshotStatus = null

	public SnapshotStatusInstance(UcdServerConnection ucdServer, Snapshot snapshot, String name,
			String id) {
		super(ucdServer, name, id);
		this.snapshot = snapshot
	}
			
	/**
	 * Returns the Snapshot associated with this instance.
	 */
	public Snapshot getSnapshot() {
		return snapshot
	}
	
	/**
	 * Returns the instance independent SnapshotStatus.
	 */
	public SnapshotStatus getSnapshotStatus() {
		if (! snapshotStatus) {
			snapshotStatus = (new UcdConnectionServices(ucdServer)).getStatusServices().getSnapshotStatus(this.name)
		}
		return snapshotStatus
	}

}
