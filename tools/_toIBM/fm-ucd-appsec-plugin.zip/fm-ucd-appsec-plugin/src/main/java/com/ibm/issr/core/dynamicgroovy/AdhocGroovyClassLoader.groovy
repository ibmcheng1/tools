package com.ibm.issr.core.dynamicgroovy

/**
 * This singleton class is used to dynamically load 'ad-hoc' groovy classes.
 * An ad-hoc groovy class is one whose source code is saved to disk just before
 * the class is loaded, which allows for a dynamic or 'ad-hoc' definition of the
 * class.
 * @author ltclark
 *
 */
class AdhocGroovyClassLoader {
	private static AdhocGroovyClassLoader _instance = null
	
	private boolean classLoaderHasBeenModified = false
	
	/**
	 * This singleton has a private class constructor.
	 */
	private AdhocGroovyClassLoader() {
		
	}
	
	/**
	 * Returns the singleton instance.
	 */
	public static AdhocGroovyClassLoader getInstance() {
		if (! _instance) {
			_instance = new AdhocGroovyClassLoader()
		}
		return _instance
	}
	
	/**
	 * Loads an ad-hoc/dynamic Groovy class.  If a source groovy file already
	 * exists for the named classname (name of [classname].groovy) AND the sourceCode
	 * is empty, then this loads
	 * the existing file.  Otherwise, this function saves the body of the 'sourceCode'
	 * to the groovy source file and then loads it.
	 * @param sourceCode This is the body of the source code to be loaded.  Note that
	 * it MUST declare the 'class' given by the classname parameter.
	 * @param classname The name of the class defined in 'sourceCode'.
	 * @return Returns the Class definition (aka metadata) of the class.  To get an instance of the
	 * class call 'retval.newInstance()'.
	 */
	public Class loadAdhocGroovyClass( String sourceCode, String classname ) {
		if (! classLoaderHasBeenModified) {
			// modify the class loader to include '.' in the classpath
			AdhocGroovyClassLoader.class.classLoader.rootLoader.addURL((new File('.')).toURI().toURL())
			classLoaderHasBeenModified = true
		}
		
		File sourceFile = new File("${classname}.groovy")
		
		// update the source file if it doesn't exist or the sourceCode is defined
		if ((! sourceFile.isFile()) || sourceCode) {
			// Save the source code to [classname].groovy
			sourceFile.text = sourceCode
		}
		
		// load and return the Class definition
		return AdhocGroovyClassLoader.class.classLoader.loadClass(classname,true)
	}
}
