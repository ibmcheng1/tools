package com.ibm.services.ucr.api.util

class UcrHelper {
	/**
	 * Various UCR calls are given a URL to UCR, but NOT the Deployment or Release IDs - this
	 * function parses that URL to return the Deployment ID.  In particular, when UCR calls
	 * plugins, it often sends this URL.  Also, when the built in UCR to UCD Application Process
	 * capability is used, this is the URL sent to UCD.  The format of the url is
	 * [server]/scheduledDeployment/[deploymentId]/...,
	 * such as https://ucrServer:9443/scheduledDeployment/04ee62a9-19a4-4b79-853c-df3e2791a496#execution/Segment/f5f02123-f900-47f9-b003-0b8ea01c2822/TaskExecution/3f265905-825f-4300-9ddc-63657fe318f4
	 * or just scheduledDeployment/04ee62a9-19a4-4b79-853c-df3e2791a496#execution/Segment/f5f02123-f900-47f9-b003-0b8ea01c2822/TaskExecution/3f265905-825f-4300-9ddc-63657fe318f4
	 * @return the Deployment ID from the url.
	 */
	public static String parseScheduleDeploymentIdFromUrl( String url ) {
		String[] elements = url.split('#')[0].split('/')
		return elements[ elements.size()-1 ]
	}
	
	/**
	 * Various UCR calls are given a URL to UCR, but NOT the Deployment or Release IDs - this
	 * function parses that URL to return the server string.  In particular, when UCR calls
	 * plugins, it often sends this URL.  Also, when the built in UCR to UCD Application Process
	 * capability is used, this is the URL sent to UCD.  The format of the url is
	 * [server]/scheduledDeployment/[deploymentId]#...,
	 * such as https://ucrServer:9443/scheduledDeployment/04ee62a9-19a4-4b79-853c-df3e2791a496#execution/Segment/f5f02123-f900-47f9-b003-0b8ea01c2822/TaskExecution/3f265905-825f-4300-9ddc-63657fe318f4
	 * @return The server string, such as https://ucrServer:9443
	 */
	public static String parseServerFromUrl( String url ) {
		URL theUrl = new URL(url)
		String retval = theUrl.getAuthority() + "://" + theUrl.getHost()
		int port = theUrl.getPort().toInteger().value
		if (port > 0) {
			retval = retval + ":" + theUrl.getPort()
		}
		return retval
	}
	
//	public static void main( def args ) {
//		println parseScheduleDeploymentIdFromUrl("https://ucrServer:9443/scheduledDeployment/04ee62a9-19a4-4b79-853c-df3e2791a496#execution/Segment/f5f02123-f900-47f9-b003-0b8ea01c2822/TaskExecution/3f265905-825f-4300-9ddc-63657fe318f4")
//		println parseScheduleDeploymentIdFromUrl("scheduledDeployment/04ee62a9-19a4-4b79-853c-df3e2791a496#execution/Segment/f5f02123-f900-47f9-b003-0b8ea01c2822/TaskExecution/3f265905-825f-4300-9ddc-63657fe318f4")
//		println parseServerFromUrl("https://ucrServer:9443/scheduledDeployment/04ee62a9-19a4-4b79-853c-df3e2791a496#execution/Segment/f5f02123-f900-47f9-b003-0b8ea01c2822/TaskExecution/3f265905-825f-4300-9ddc-63657fe318f4")
//		println parseServerFromUrl("https://ucrServer/scheduledDeployment/04ee62a9-19a4-4b79-853c-df3e2791a496#execution/Segment/f5f02123-f900-47f9-b003-0b8ea01c2822/TaskExecution/3f265905-825f-4300-9ddc-63657fe318f4")
//	}

}
