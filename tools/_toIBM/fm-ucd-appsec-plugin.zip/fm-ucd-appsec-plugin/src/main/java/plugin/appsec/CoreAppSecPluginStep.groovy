package plugin.appsec

import com.fanniemae.fortify.DeployBreakerAnalyzer
import com.fanniemae.fortify.ssc.SscApi
import com.fanniemae.repo.RepositoryCloner
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.processrequest.ProcessRequest
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.css.ucd.snapshot.Snapshot
import com.ibm.css.ucd.status.ComponentVersionStatus
import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.file.FileHelper
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.plugin.AbortPluginException

import plugin.UCPluginStepImplementation
import plugin.helper.PluginUtils


/**
 * The AppSec Scan Plugin is designed to have modular steps.  There are four high level
 * tasks: Decide which Component Versions need to be scanned, download source code,
 * scan and 'deploy breaker'.  This plugin is designed to let you have one plugin step for each
 * of the tasks or to have plugin steps that perform more than one task.
 * For example, it is possible to have one plugin step that performs all four tasks.
 * To support this modularity, the plugin step code are all extended from this common base class.
 * This shared base class implements the task (with supporting infrastructure).  Then a plugin
 * step can easily call the desired tasks.
 * @author s9ulcc
 *
 */
class CoreAppSecPluginStep extends UCPluginStepImplementation {
	
	String APPSCAN_REQUIRED_COMPONENT_PROPERTY = 'appsecScanRequired'
	String APPSCAN_PASSED_COMPONENT_STATUS = 'APPSEC_SCAN_PASSED'
	String APPSCAN_FAILED_COMPONENT_STATUS = 'APPSEC_SCAN_FAILED'

	/**
	 * <p>This is the structure that stores information about the component
	 * versions that need to be scanned.  This can be passed between plugin
	 * step calls as a json string.</p>
	 * <p>It is a Map with the following structure</p>
	 * <pre>
	 * Map application - The application
	 *		String name
	 *		String id
	 *		Map environment
	 *			String name
	 *			String id
	 *	Map snapshot - ONLY defined if there is a snapshot
	 *		String name
	 *		String id
	 *	List componentVersionsToBeScanned - List of the component versions that need to be scanned
	 *		Map - Each entry is a structured map with the following fields
	 *			String name - name of the component version
	 *			String id - id of the component version
	 *			String relativeFolder - Relative folder (to current working directory) for processing this component
	 *				Note that the directory is NOT created.
	 *			String fprFilename - The relative name (to current working directory) of the FPR file name.
	 *			boolean processingFailed - set to true if any processing step failed
	 *			String processingErrorMsg - If a processing step has failed, put a description of the failure in this field
	 *			String sscApplicationName - When it is time to upload to SSC, this field is populated
	 *			String sscVersionName - When it is time to upload to SSC, this field is populated
	 *			Map component - the related component
	 *				String name - name of the component
	 *				String id - id of the component
	 * </pre>
	 */
	protected Map appscanData

	// data needed to decide which Component Versions eed to be loaded and perform basic initialization.	
	protected String applicationRequestId
	protected boolean cleanupVersionDirectories

	// SSC Data	
	protected String sscServerUrl
	protected String sscAuthToken
	protected String sscUsername
	protected String sscPassword

	// Status Owner Data	
	protected String statusOwnerUsername
	protected String statusOwnerPassword

	// Status user details
	protected String statusUser
	protected String statusPass
	// sonar data
	protected String sonarServerUrl
	protected String sonarInstallationPath
	protected String scanScope
	
	// sca data
	protected String scaInstallationPath
	
	// The plugin's resource path is needed when calling nested UCD Generic Processes
	protected String resourcePath

	// UCD Server connection
	protected UcdServerConnection ucdServer
	protected UcdConnectionServices ucdConnectionServices

	// UCD Server connection for Status Owner
	protected UcdServerConnection ucdServer2
	protected UcdConnectionServices ucdConnectionServices2
	protected boolean verbose = false		// verbose mode?

	@Override
	public void performStep( String[] args, Closure theStep ) {
		// chains to the parent performStep
		
		// custom code may be placed here
		
		super.performStep(args) {
					
			theStep()
			
		}
	}
	
	/**
	 * Retrieve, display and parse the 'appscanData' input field.  This should be called
	 * when the other properties are loaded/retrieved.  This is an optional retrieval
	 * because not all steps need this.
	 */
	protected void retrieveAndDisplayAppScanData() {
		String appscanDataString = retrieveAndDisplayInProp('appscanData')
		appscanData = new groovy.json.JsonSlurper().parseText(appscanDataString)
		scanScope = retrieveAndDisplayInProp('scanScope')
		//statusUser =
	}
	
	/**
	 * This retrieves and displays all of the data needed to decide which Component Versions
	 * need to be loaded and perform basic initialization.
	 */
	protected void retrieveAndDisplayDataForGeneratingVersionList() {
		applicationRequestId = retrieveAndDisplayInProp('applicationRequestId')
		String cleanupVersionDirectoriesString = retrieveAndDisplayInProp('cleanupVersionDirectories')
		cleanupVersionDirectories = cleanupVersionDirectoriesString.trim().equalsIgnoreCase('true')
	}

	/**
	 * Retrieve and display Sonar data
	 * @return
	 */
	protected void retrieveAndDisplaySonarData() {
		sonarServerUrl = retrieveAndDisplayInProp('sonarServerUrl')
		sonarInstallationPath = retrieveAndDisplayInProp('sonarInstallationPath')
	}
	
	/**
	 * Resource Path is needed if a nested UCD Generic Process is called.
	 */
	protected void retrieveAndDisplayResourcePath() {
		resourcePath = retrieveAndDisplayInProp('resourcePath')
	}
	protected void retrieveAndDisplayScaData() {
		scaInstallationPath = retrieveAndDisplayInProp('scaInstallationPath')
	}

	/**
	 * Retrieve and display Fortify SSC server information. 
	 */
	protected void retrieveAndDisplaySscServerData() {
		sscServerUrl = retrieveAndDisplayInProp('sscServerUrl')
		sscAuthToken = retrieveInProp('sscAuthToken')
		sscUsername = retrieveAndDisplayInProp('sscUsername')
		sscPassword = retrieveInProp('sscPassword')
	}
	
	/**
	 * Retrieve and display Status Owner Data for UCD server.
	 */
	protected void retrieveAndDisplayStatusOwnerDataforUCDServer() {
		statusOwnerUsername = retrieveAndDisplayInProp('statusOwner')
//		println "statusOwnerUsername: " + statusOwnerUsername
		statusOwnerPassword = retrieveInProp('statusPass')
//		println "statusOwnerPassword: " + statusOwnerPassword
	}

	@Override
	protected void displayParameters() {
		if (inProps.containsKey('verbose')) { 
			String verboseString = retrieveAndDisplayInProp('verbose')
			verbose = (verboseString.trim().equalsIgnoreCase('true'))
		}
		super.displayParameters();
	}
	
	/**
	 * Opens connection to UCD Server as both 'UcdServerConnection ucdServer' and 
	 * 'UcdConnectionServices ucdConnectionServices'
	 */
	protected void connectToUcdServer() {
		ucdServer = new UcdServerConnection()
		ucdServer.openConnection(myRestServerUrl, myRestServerTokenUsername, myRestServerTokenPassword, myRestServerProxyHost, myRestServerProxyPort, myRestServerProxyUsername, myRestServerTokenPassword)
		ucdConnectionServices = new UcdConnectionServices(ucdServer)
	}

	
	/**
	 * Opens connection to UCD Server as both 'UcdServerConnection ucdServer' and
	 * 'UcdConnectionServices ucdConnectionServices'
	 */
	protected void connectToUcdServer2() {
		ucdServer2 = new UcdServerConnection()
		ucdServer2.openConnection(myRestServerUrl, statusOwnerUsername, statusOwnerPassword, myRestServerProxyHost, myRestServerProxyPort, myRestServerProxyUsername, myRestServerTokenPassword)
		ucdConnectionServices2 = new UcdConnectionServices(ucdServer2)
	}

	/**
	 * Flags/registers an error with processing a Component Version.  Note that if an error has
	 * already been registered, then this does nothing - only the first registered error for the
	 * component version is captured.
	 * @param componentVersionData This is a reference to one Component Version entry in the 'appscanData'.
	 * @param msg The error message, such as 'unable to retrieve souce code from repository'
	 */
	protected void registerError(Map componentVersionData, String msg) {
		if (! componentVersionData.processingFailed) {
			componentVersionData.processingFailed = true
			componentVersionData.processingErrorMsg = msg
		}
	}

	/**
	 * Call this function to display a summary of the step's results to the logged output.
	 * ALSO, if there are any flagged failures, then this aborts the plugin.
	 * @param actionLabel A very brief description of what the plugin step was doing, such as
	 * 'Scan' or 'Download Source Code'.
	 */
	protected void summarizeResults(String actionLabel) {
		Logger.info ""
		Logger.info "************************************************************"
		Logger.info " "
		Logger.info "                       " + actionLabel + " Summary"
		Logger.info " "
		Logger.info "************************************************************"
		Logger.info ""
		// Display successful scans
		appscanData.componentVersionsToBeScanned.each() { Map componentVersionData ->
			if (! componentVersionData.processingFailed) {
				String componentVersionName = componentVersionData.name
				String componentName = componentVersionData.component.name
				Logger.info actionLabel + " completed for version '${componentVersionName}' of component '${componentName}'"
				displayAdditionalComponentVersionInfoForResultSummary(componentVersionData)
			}
		}
		// Display failed scans
		boolean anyFailures = false
		appscanData.componentVersionsToBeScanned.each() { Map componentVersionData ->
			if (componentVersionData.processingFailed) {
				anyFailures = true
				String componentVersionName = componentVersionData.name
				String componentName = componentVersionData.component.name
				String msg = componentVersionData.processingErrorMsg
				Logger.error actionLabel + " FAILED for version '${componentVersionName}' of component '${componentName}' - ${msg}"
			}
		}
		if (anyFailures) {
			throw new AbortPluginException( actionLabel + " failed")
		}
	}

	/**
	 * When the plugin step summary is displayed, the summary lists the successful component versions.  However,
	 * based on the type of step (such as 'scan' or 'download source files'), some additional information may
	 * be relevant.  This function logs any additional Component Version information for successful component versions,
	 * as part of the summary.  See 'PerformScan' class for sample.
	 * @param componentVersionData This is a reference to one Component Version entry in the 'appscanData'.
	 */
	protected void displayAdditionalComponentVersionInfoForResultSummary(Map componentVersionData) {
	}
	
	/**
	 * Given a relative path (to a file or folder) return the absolute path from the current working directory.
	 */
	protected String convertRelativeToAbsolutePath(String relativePath) {
		return new File('.', relativePath ).getCanonicalPath()
	}
	
	/**
	 * Generates the 'appscanData' class member which includes the list of
	 * UCD Component Versions which need to be scanned.
	 */
	public void generateListOfComponentVersionsNeedingScanning( ) {

		this.appscanData = [applicationRequestId:applicationRequestId, componentVersionsToBeScanned:[]]
		
		// Lookup status flags
		ComponentVersionStatus appScanPassedComponentStatus = ucdConnectionServices.getStatusServices().getComponentVersionStatus(APPSCAN_PASSED_COMPONENT_STATUS)
		ComponentVersionStatus appScanFailedComponentStatus = ucdConnectionServices.getStatusServices().getComponentVersionStatus(APPSCAN_FAILED_COMPONENT_STATUS)
		
		ProcessRequest processRequest = ucdConnectionServices.getProcessRequestServices().getProcessRequest( applicationRequestId )
		
		Environment environment = processRequest.getEnvironment()
		Application application = processRequest.getApplication()
		appscanData.application = [name:application.name, id:application.id, environment:[name:environment.name,id:environment.id]]
		String appCode = PluginUtils.getAppCode( application )
		String assetId = PluginUtils.getAssetId( application )
		
		Snapshot snapshot = processRequest.getSnapshot()
		if (snapshot) {
			appscanData.snapshot = [name:snapshot.name, id:snapshot.id]
			Logger.info "Processing Snapshot '${snapshot.name}'"
		}
		
		List componentVersions = processRequest.getComponentVersions()
		componentVersions.each{ ComponentVersion componentVersion ->
			Component component = componentVersion.component
			String versionDescription = "component version '${componentVersion.getName()}' of component '${component.getName()}'"
			String exclusionMsg = ''
			
			// Should this component version be scanned?
			boolean scanNeeded
			
			// Does this component flagged for scanning
			if (PluginUtils.getAppsecScanRequired(component, false).equalsIgnoreCase('true')) {
				scanNeeded = true
			} else {
				scanNeeded = false
				exclusionMsg = "The Component doesn't need to be scanned"
			}
			
			// Skip scanning if the Component Version has already been scanned (pass or fail)
			if (scanNeeded) {
				if (componentVersion.hasStatus(appScanPassedComponentStatus)) {
					scanNeeded = false
					exclusionMsg = "The Component Version has already passed AppScan"
				} else if (componentVersion.hasStatus(appScanFailedComponentStatus)) {
					scanNeeded = false
					exclusionMsg = "The Component Version has already failed AppScan"
				}
			}
			
			if (scanNeeded) {
				Logger.info "Needs to be scanned: " + versionDescription

				// Get the new repo names
				String repoName = PluginUtils.getRepoName(componentVersion)
                String repoUrl = PluginUtils.getRepoURL(componentVersion)
				String fortifyApplicationName = PluginUtils.getFortifyApplicationName(application, componentVersion)
				String fortifyVersionName = PluginUtils.getFortifyVersionName(application, componentVersion)
                String branchName = PluginUtils.getBranch(componentVersion)
                String commitID = PluginUtils.getCodeCommitHash(componentVersion)
                String javaVersion = PluginUtils.getJavaVersion(component)

                Logger.info "AppSec Scan required properties........"
                Logger.info "fortifyApplicationName : " + fortifyApplicationName
                Logger.info "fortifyVersionName     : " + fortifyVersionName
                Logger.info "repoURL                : " + repoUrl
                Logger.info "branch                 : " + branchName
                Logger.info "commitHash             : " + commitID
                Logger.info "javaVersion            : " + javaVersion

                if(!fortifyApplicationName || !fortifyVersionName || !repoName || !branchName || !commitID)
                    throw new AbortPluginException("Missing one/more required properties for scan. Aborting.")

				Map newEntry = [
					name: componentVersion.name,
					id: componentVersion.id,
                    repoUrl: repoUrl,
                    commit: commitID,
                    branch: branchName,
                    javaVersion: javaVersion,
					component: [
						name: component.name,
						id: component.id,
                        fortifyApplication: fortifyApplicationName,
                        fortifyVersion: fortifyVersionName
						]
					]
				newEntry.relativeFolder = (fortifyApplicationName + '/' + environment.name + '/' + fortifyVersionName).replaceAll(" ", "_")
				newEntry.fprFilename = (newEntry.relativeFolder + "/${fortifyVersionName}.fpr").replaceAll(" ", "_")
				newEntry.processingFailed = false
				newEntry.processingErrorMsg = ''
				appscanData.componentVersionsToBeScanned << newEntry
				if (cleanupVersionDirectories) {
					File versionDirectory = new File( '.', newEntry.relativeFolder )
					if (! versionDirectory.exists()) {
						versionDirectory.mkdirs()
					}
					new FileHelper().wipeDirectory( versionDirectory )
				}
			} else {
				Logger.info "Not scanning: " + versionDescription + " - " + exclusionMsg
			}
			
		}

	}

	/**
	 * Checkout code with a pass/fail return.
	 * @param componentVersionData This is one componentVersion entry in the appscanData field.
	 * If this function fails, it can registerError() to register a failure with a detailed, context specific error message.
	 */
	public boolean checkoutCode( Map componentVersionData, String resourcePath, String workingPath, String assetId, String repoURL,
		String branch, String codeCommitHash, String envType, String awsAccountId, String awsRole, String awsRegion ) {
		
		RepositoryCloner repositoryCloner = new RepositoryCloner(ucdServer)
		boolean success
		String errorMsg
		(success,errorMsg) = repositoryCloner.cloneRepository('cloneRepo-GenProc', resourcePath, workingPath, assetId, componentVersionData.repoUrl, componentVersionData.branch, componentVersionData.commit, envType, awsAccountId, awsRole, awsRegion )
		if (! success) {
			registerError(componentVersionData, errorMsg)
		}
		Logger.info "Code checkout complete : " + componentVersionData
		return success
		
	}
	
	/**
	 * Clean source analyzer with a pass/fail return code.
	 */
	public boolean cleanAnalyzer( String workingPath, String appCode) {
		boolean success = true
		// clone repository
		success = new CommandRunner().setVerbose(verbose)
			.setActiveDirectory(workingPath)
			.setCommand(["sourceanalyzer", "-b", appCode, "-clean"])
			.execute()
			.wasSuccessful()
		Logger.info "Source analyzer clean complete for appCode : " + appCode
		return success
	}
	
	/**
	 * Compile the maven build with a pass/fail return code.
	 */
	public boolean compileMavenProject( String workingPath, String appCode, String assetId, String javaVersion, String pomFilename ) {
		boolean success = true

		// Use the parent environment with 'JAVA_HOME' stripped out
		Map<String,String> parentEnv = System.getenv()
		List childEnv = []
		parentEnv.each { String key, String value ->
			if (! key.trim().equalsIgnoreCase('JAVA_HOME')) {
				childEnv << "${key}=${value}"
			}
		}
		
		// clone repository
		success = new CommandRunner().setVerbose(verbose)
			.setActiveDirectory(workingPath)
			.setCommand(["mvn", "-f", pomFilename, "-s", "${getPluginFolder()}/files/settings.xml", "clean", "compile", "-Dfortify.sca.buildId=${appCode}",
				"-Dfortify.sca.source.version=${javaVersion}", "-DskipTests=true", "-Dcustom.applicationId=${assetId}",
				"com.fortify.ps.maven.plugin:sca-maven-plugin:translate"])
			.setEnvironment(childEnv)
			.execute()
			.wasSuccessful()
		Logger.info "Maven compile with scan complete for appCode : " + appCode
		return success
	}

	/**
	 * Analyze the scanned code for finding issues with a pass/fail return.
	 * @param componentVersionData This is one componentVersion entry in the appscanData field.
	 * @param componentVersion Component version object scanned earlier.
	 * @param sscServerUrl URL of the Fortify SSC server where the fortify scan information resides.
	 * @param sscUsername Username to be used to login Fortify SSC server.
	 * @param sscPassword Password to be used to login Fortify SSC server.
	 * @param sscApplicationName The SSC/Fortify Application Name.
	 * @param sscVersionName The name of the version with the project to find issues for.
 	 * @param appScanPassedComponentStatus Component status as APPSEC_SCAN_PASSED
	 * @param appScanFailedComponentStatus Component status as APPSEC_SCAN_FAILED
	 * @return
	 */
//	public boolean findDeployBreakerIssuesAndSetComponentVersionStatus( Map componentVersionData, ComponentVersion componentVersion, String sscServerUrl, String sscUsername, String sscPassword, String sscApplicationName, String sscVersionName, ComponentVersionStatus appScanPassedComponentStatus, ComponentVersionStatus appScanFailedComponentStatus ) {
	public boolean findDeployBreakerIssuesAndSetComponentVersionStatus( Map componentVersionData, ComponentVersion componentVersion, String sscServerUrl, String sscUsername, String sscPassword, ComponentVersionStatus appScanPassedComponentStatus, ComponentVersionStatus appScanFailedComponentStatus ) {
			
//		DeployBreakerAnalyzer deployBreakerAnalyzer = new DeployBreakerAnalyzer(ucdServer)
		DeployBreakerAnalyzer deployBreakerAnalyzer = new DeployBreakerAnalyzer(ucdServer2)
		boolean success
		String errorMsg
		
        String sscApplicationName = componentVersionData.component.fortifyApplication
        String sscVersionName = componentVersionData.component.fortifyVersion

		(success,errorMsg) = deployBreakerAnalyzer.findIssuesAndSetComponentVersionStatus(ucdServer2, componentVersion, sscServerUrl, sscUsername, sscPassword, sscApplicationName, sscVersionName, appScanPassedComponentStatus, appScanFailedComponentStatus )
		if (! success) {
			registerError(componentVersionData, errorMsg)
		}
		return success
	}

	/**
	 * Compile the maven build with a pass/fail return code.
	 */
	public boolean compileMavenProjectForSonar( String workingPath, String appCode, String assetId, String javaVersion, String pomFilename ) {
		boolean success = true

		// Use the parent environment with 'JAVA_HOME' stripped out
		Map<String,String> parentEnv = System.getenv()
		List childEnv = []
		parentEnv.each { String key, String value ->
			if (! key.trim().equalsIgnoreCase('JAVA_HOME')) {
				childEnv << "${key}=${value}"
			}
		}

		// clone repository
		success = new CommandRunner().setVerbose(verbose)
				.setActiveDirectory(workingPath)
				.setCommand(["mvn", "-f", pomFilename, "-s", "${getPluginFolder()}/files/settings.xml", "clean", "compile", "-DskipTests=true"])
				.setEnvironment(childEnv)
				.execute()
				.wasSuccessful()
		Logger.info "Maven compile complete for appCode : " + appCode
		return success
	}

	/**
	 * Run the code analyzer with a pass/fail return code.
	 */
	public boolean runCodeAnalyzer( String workingPath, String appCode, String fprFilename ) {
		boolean success = true
		success = new CommandRunner().setVerbose(verbose)
			.setActiveDirectory(workingPath)
			.setCommand(["sourceanalyzer", "-b", appCode, "-scan", "-mt", "-Xmx4G", "-f", fprFilename, "-project-template", "fm_projecttemplate_v2.0.xml"])
			.execute()
			.wasSuccessful()
		Logger.info "Source analyzer scan complete for file : " + fprFilename
		return success
	}

	/**
	 * Upload the FPR Results file to the HP Fortify SSC Server.
	 * @param workingPath The full path to the active working directory to use.
	 * @param fprFilename The full pathname of the FPR file.
	 * @param sscProjectName The SSC/Fortify Project/Application Name.
	 * @param sscVersionName The name of the version with the project (appCode) to upload the FPR to.
	 * @param sscServerUrl The URL of the SSC Server.
	 * @param sscAuthToken An SSC Server authentication token with the SSC AnalysisUploadToken permission type.
	 * @return
	 */
	public boolean uploadResults( String workingPath, String fprFilename, String sscProjectName, String sscVersionName,
		String sscServerUrl, String sscAuthToken ) {
		boolean success = true
		
		success = new CommandRunner().setVerbose(verbose)
			.setActiveDirectory(workingPath)
			.setCommand([ "fortifyclient", "uploadFPR", "-file", fprFilename, "-project", sscProjectName, "-version", sscVersionName, "-url", sscServerUrl, "-authtoken", sscAuthToken ])
			.execute()
			.wasSuccessful()
		Logger.info "Upload results to SSC server complete for project:" + sscProjectName + ", version:" + sscVersionName
		return success
	}
	
	/**
	 * Generates Sonatype Report returning success flag.
	 */
	public boolean generateSonatypeReport( String workingPath, String fprFilename, String appCode, String assetId ) {
		boolean success = true
		
		String sonatypeOutputFile = new File( workingPath, "${appCode}-${assetId}-sast.xml" )
		
		success = new CommandRunner().setVerbose(verbose)
			.setActiveDirectory(workingPath)
			.setCommand([ "ReportGenerator", "-Xmx3G", "-template", "${getPluginFolder()}/files/Custom-Audit.xml", "-format",
				"xml", "-f", sonatypeOutputFile, "-source", fprFilename ])
			.execute()
			.wasSuccessful()
		Logger.info "ReportGenerator complete for file : " + fprFilename
		return success
	}
	
	/**
	 * Runs the Sonar Runner.  Note that this downloads information from Fortify SSC server before running the Sonar Runner.
	 * @param workingPath The full path to the active working directory to use.
	 * @param fprFilename The full pathname of the FPR file.
	 * @param sscApplicationName The SSC/Fortify Application Name for this component version.
	 * @param sscVersionName The name of the version with the project (appCode) to upload the FPR to.
	 * @param sscServerUrl The URL of the SSC Server.
	 * @param sscAuthToken An SSC Server authentication token with the SSC AnalysisUploadToken permission type.
	 * @param scaInstallationPath The full path to where SCA is installed.
	 * @param sonarServerUrl The URL of the sonar server
	 * @param sonarInstallationPath The full path to where SonarScanner is installed.
	 * @param appScanScope Scope of the sonar scanner
	 * @return Did it work?
	 */
	public boolean runSonarRunner( String workingPath, String fprFilename, String sscApplicationName, String sscVersionName, String sscServerUrl, String sscAuthToken,
		String scaInstallationPath, String sonarServerUrl, String sonarInstallationPath, String appScanScope ) {
		boolean success = true
		
		// Create 'sonar-project.properties' for the call to the sonarJarFilepath
		File sonarProjectPropertiesFile = new File( workingPath, 'sonar-project.properties' )
		String sonarProjectPropertiesFilepath = sonarProjectPropertiesFile.getCanonicalPath()
		Properties sonarProjectProperties = new Properties()
		sonarProjectProperties['sonar.sourceEncoding'] = "UTF-8".toString()
		sonarProjectProperties['sonar.server.url'] = sonarServerUrl
		sonarProjectProperties['sonar.java.binaries'] = workingPath
		sonarProjectProperties['sonar.exclusions'] = "**/Custom-FNM-SQReport.xml,**/Custom-FNM-SQ.xml,${sscApplicationName}-${sscVersionName}-sast.xml,${sscApplicationName}-${sscVersionName}-dast.xml".toString()
		sonarProjectProperties['sonar.projectVersion'] = sscVersionName
		sonarProjectProperties['sonar.projectKey'] = "${sscApplicationName}:${sscVersionName}".toString()
		sonarProjectProperties['sonarqube.dast.enable'] = 'true'
		sonarProjectProperties['sonar.projectName'] = sscApplicationName
		sonarProjectProperties['sonar.sources'] = workingPath
		sonarProjectProperties['sonar.java.binaries'] = workingPath
		
		// Properties for new version of sonar scanner (v2.5)
		if(appScanScope.equalsIgnoreCase("CODE_REVIEW_APP_SCAN")) {
			sonarProjectProperties['ssc.url'] = sscServerUrl
			sonarProjectProperties['ssc.token'] = sscAuthToken
			sonarProjectProperties['sca.installation.path'] = scaInstallationPath
			sonarProjectProperties['sonarqube.fortify.enable'] = 'true'
			sonarProjectProperties['sonar.fortify.ssc.appversion'] = "${sscApplicationName}:${sscVersionName}".toString()
			sonarProjectProperties['sonar.fortify.ssc.uploadFPR'] = fprFilename
			sonarProjectProperties['sonar.fortify.ssc.failOnArtifactState'] = 'SCHED_PROCESSING,PROCESSING,REQUIRE_AUTH,ERROR_PROCESSING'
			sonarProjectProperties['sonar.fortify.ssc.processing.timeout'] = '120'
		}

		sonarProjectPropertiesFile.withWriter('utf-8') { BufferedWriter writer ->
			sonarProjectProperties.store(writer, null)
		}
		
		// RUN SONAR RUNNER
		success = new CommandRunner().setVerbose(verbose)
			.setActiveDirectory(workingPath)
			.setCommand([ "${sonarInstallationPath}/bin/sonar-scanner", "-X" ])
			.execute()
			.wasSuccessful()
		Logger.info "SonarRunner complete for application:" + sscApplicationName + ", version:" + sscVersionName
		return success
	}
	
	/**
	 * Returns the end-user hyperlink to the given SSC Applicaiton + Version.
	 * @param sscServerUrl The server URL for SSC, which includes the root context, such as 'https://pwv-e4t-a01:8443/ssc'
	 * @param sscApplicationName The name of the SSC Application/Project
	 * @param sscVersionName The name of the SSC Version.
	 * @return
	 */
	protected String getSscHyperlink( String sscServerUrl, String sscUsername, String sscPassword,
		String sscApplicationName, String sscVersionName ) {
		SscApi sscApi = new SscApi( sscServerUrl, sscUsername, sscPassword )
		Map projects = sscApi.getProjects()
		int projectId = -1
		projects.data.each { Map projectData ->
			if (projectData.name == sscApplicationName) {
				projectId = projectData.id
			}
		}
		if (projectId == -1) {
			throw new AbortPluginException("Unable to find an SSC Server Application/Project named '${sscApplicationName}'")
		}
		Map versions = sscApi.getVersions(projectId)
		int versionId = -1
		versions.data.each { Map versionData ->
			if (versionData.name == sscVersionName) {
				versionId = versionData.id
			}
		}
		if (versionId == -1) {
			throw new AbortPluginException("Unable to find an SSC version named '${sscVersionName}'")
		}
		return "${sscServerUrl}/html/ssc/version/${versionId}/fix/null/"
	}
	
	/**
	 * Lookup the AWS Authentication information (account and role) for the given
	 * UCD environment and UCD component.
	 * @return Returns List where the first element is the awsAccountId and the second
	 * element is the awsRole.
	 */
	protected List lookupAwsAuthenticationInfo(Environment environment, Component component) {
		String awsAccountId = ''
		String awsRole = ''
		if (environment.hasComponentProperty('awsLifeCycle',component)) {
			awsAccountId = environment.getComponentProperty('awsLifeCycle',component).value
		}
		if (environment.hasComponentProperty('accountId',component)) {
			awsAccountId = environment.getComponentProperty('accountId',component).value
		}
		if (environment.hasComponentProperty('role',component)) {
			awsRole = environment.getComponentProperty('role',component).value
		}
		if (environment.hasComponentProperty('awsRole',component)) {
			awsRole = environment.getComponentProperty('awsRole',component).value
		}
		return [awsAccountId,awsRole]
	}

}
