#!/usr/bin/env groovy

package plugin

import org.codehaus.groovy.runtime.StackTraceUtils

import com.ibm.issr.core.log.LogTracingClass
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel
import com.ibm.issr.core.plugin.AbortPluginException
import com.ibm.issr.core.plugin.PluginHelper

/**
 * <p>This is a re-usable base class for UrbanCode Plugins implemented in Groovy.  This
 * class has standard setup and teardown code for the plugin step along with helper
 * functions.</p>
 * <p>The concrete class implementation MUST implement the program's main() function, pretty
 * much as follows.</p>
 * <pre>
 * {@code
 *  public class ConcreteExample extends UCDPluginStepImplementation {
 *  
 *  ...
 *  
 * 	public static void main( java.lang.String[] args ) {
 * 		def stepImpl = new ConcreteExample();
 * 		stepImpl.performStep(args) { implementation_of_the_step  }
 * 	}
 * </pre>
 * <p>Some of the features implemented by this base Step class are...</p>
 * <ul>
 * <li>On startup, it automatically loads the inbound properties into 'inProps'</li>
 * <li>On startup, it automatically loads the Agent's properties into the variable 'agentProps'</li>
 * <li>On ending, it automatically puts any properties in 'outProps' to the output property file</li>
 * <li>On startup, if there is a property named 'loggingLevel', this automatically sets the logging
 * level to the designated property value (trace, debug, info, etc)</li>
 * <p>How to process known failure conditions... Throw a new Exception for unexpected problems.
 * Throw instances of ExpectedPluginException when a known, expected error occurs.
 * <p>Semi-automatic 'result' handling.  The idea is that result is that the output property
 * 'result' provides a high level description of the results of the plugin.  'result' will be set
 * to 'success' if successful, 'unknown error' if an unhandled error occurred or a specific
 * error message in the event of a handled error.</p>
 * <p>When a plugin starts, 'result' is automatically set to 'unknown error'.  If the
 * plugin finishes successfully (and result is still set to 'unknown error'), then 'result' is
 * set to 'success'.  'result' can be set at any time by calling 'setResult()'.  If the plugin is
 * aborted by calling abortPluginWithMessage() then 'result' is automatically set to the message.</p>
 * </ul>
 */
class UCPluginStepImplementation extends LogTracingClass {
	private final String RESULT_NAME = UCPluginStepImplementation.getDefaultOutputPropertyPrefix() + 'result'
	private final String RESULT_DEFAULT_FAIL = 'unknown error'
	private final String RESULT_SUCCESS = 'success'
	
	// Information from the plugin's XML files, which is loaded on demand
	private Map pluginInfo = null
	
	public static Closure exitSystem = { int exitCode ->
		System.exit( exitCode )
	}
	
	/**
	 * Loads the input properties.  The argument is the programs command line arguments.
	 * Returns an instance of Properties class with the properties.
	 * The default implementation reads the property file which is named as the second to last
	 * string argument.
	 */
	public static Closure inputPropsLoader = { java.lang.String[] args ->
		// load the inbound properties
		Properties inProps = new Properties();
		final def inputPropsFile = new File(args[args.length-2]);
		def inputPropsStream = new FileInputStream(inputPropsFile);
		inProps.load(inputPropsStream);
		return inProps
	}
	
	/**
	 * Saves the output properties.  The arguments are .. 'outProps' are the properties to save.
	 * 'args' are the commend line properties.  The default implementation saves the properties
	 * to the file that is named as the last parameter in the arguments.
	 */
	public static Closure outputPropsSaver = { Properties outProps, java.lang.String[] args ->
		final def outputPropsFile = new File(args[args.length-1]);
		def outputPropsStream = new FileOutputStream(outputPropsFile);
		outProps.store(outputPropsStream, "Output props");
	}
	
	/**
	 * The current working directory.
	 */
	File workDir;
	/**
	 * A 'Properties' map of the properties passed from UrbanCode server to the plugin.
	 * For example, call 'def propName = inProps.propName' to access the value of the "propName" property.
	 */
	Properties inProps;
	/**
	 * A 'Properties' map of the properties sent from the plugin to the UrbanCode server. You can set
	 * property values by calling 'outProps.put( "propName", propValue )'.
	 * When the step ends, this base class automatically sends the properties back to UrbanCode Deploy.
	 */
	Properties outProps;
	/**
	 * Read only access the current Agent's installed properties, which are in the file 'conf/agent/installed.properties' as
	 * a Properties map.
	 */
	Properties agentProps;
	/**
	 * The step's command line arguments
	 */
	java.lang.String[] stepArgs

	/**
	 * The "home" (installation) directory of the UrbanCode agent.  This is not calculated until it is needed
	 */
	private File private_AGENT_HOME = null
	
	/**
	 * Retrieve the 'AGENT_HOME' value which is looked up the first time.
	 * @return
	 */
	protected getAGENT_HOME() {
		if (! private_AGENT_HOME) {
			private_AGENT_HOME = new File(System.getenv().get("AGENT_HOME"))
		}
		return private_AGENT_HOME
	}
	
	private static boolean runningAsUCD
	private static boolean runningAsUCB
	private static String private_defaultOutputPropertyPrefix
	private static boolean private_defaultPrefixModified = false
	private static boolean testedToSeeIfBuildOrDeployPlugin = false
	private static final String DEFAULT_UCD_PREFIX = ''
	private static final String DEFAULT_UCB_PREFIX = 'buildlife/'
	
	/**
	 * Tests to see if this is running as a Build or Deploy plugin.
	 */
	private static void testToSeeIfBuildOrDeployPlugin() {
		if (! testedToSeeIfBuildOrDeployPlugin) {
			runningAsUCD = false
			runningAsUCB = false
			private_defaultOutputPropertyPrefix = ''
			if (System.getenv().containsKey('AH_WEB_URL')) {
				runningAsUCD = true
				private_defaultOutputPropertyPrefix = DEFAULT_UCD_PREFIX
			} else if (System.getenv().containsKey('WEB_URL')) {
				runningAsUCB = true
				private_defaultOutputPropertyPrefix = DEFAULT_UCB_PREFIX
			}
			testedToSeeIfBuildOrDeployPlugin = true
		}
	}
	
	/**
	 * Is this plugin running under UCD?  Normally, this checks for the environment
	 * variable named 'AH_WEB_URL' to determine that, but you can call setAsRunningAsUCDPlugin()
	 * to force it to true.
	 */
	protected static boolean isRunningAsUCDPlugin() {
		testToSeeIfBuildOrDeployPlugin()
		return runningAsUCD
	}
	
	/**
	 * Is this plugin running under UCB?  Normally, this checks for the environment
	 * variable named 'WEB_URL' to determine that, but you can call setAsRunningAsUCDPlugin()
	 * to force it to true.
	 */
	protected static boolean isRunningAsUCBPlugin() {
		testToSeeIfBuildOrDeployPlugin()
		return runningAsUCB
	}
	
	/**
	 * Sets a flag that indicates that this plugin instance is running within UCD (vs
	 * UCB, UCR or ..?).  The flag is automatically set based on environment properties.
	 * Generally, this function should only be called for unit test code, in which case
	 * the environment properties aren't set.
	 * @return
	 */
	public static void setAsRunningAsUCDPlugin() {
		testedToSeeIfBuildOrDeployPlugin = true
		runningAsUCD = true
		runningAsUCB = false
		if (! private_defaultPrefixModified) {
			private_defaultOutputPropertyPrefix = DEFAULT_UCD_PREFIX
		}
	}
	
	/**
	 * Sets a flag that indicates that this plugin instance is running within UCB (vs
	 * UCD, UCR or ..?).  The flag is automatically set based on environment properties.
	 * Generally, this function should only be called for unit test code, in which case
	 * the environment properties aren't set.
	 * @return
	 */
	public static void setAsRunningAsUCBPlugin() {
		testedToSeeIfBuildOrDeployPlugin = true
		runningAsUCD = false
		runningAsUCB = true
		if (! private_defaultPrefixModified) {
			private_defaultOutputPropertyPrefix = DEFAULT_UCB_PREFIX
		}
	}
	
	/**
	 * Returns the default output property prefix.  For UCD, this is ''.  For UCB,
	 * this is 'buildlife/'.  The default output property can be changed by calling
	 * the setter function.
	 */
	public static String getDefaultOutputPropertyPrefix() {
		testToSeeIfBuildOrDeployPlugin()
		return private_defaultOutputPropertyPrefix
	}
	
	/**
	 * Sets the defaultOutputPropertyPrefix to value.
	 */
	public static void setDefaultOutputPropertyPrefix( String value ) {
		testToSeeIfBuildOrDeployPlugin()
		private_defaultOutputPropertyPrefix = value
		private_defaultPrefixModified = true
	}

	/**
	 * <p>Call this function to perform the step!!  Specifically, this function
	 * does initialization, then it calls 'theStep' (which is implementation of the step), and
	 * then it does post-step processing.  For example, in pre-step initialization, it reads
	 * the inbound properties and in post-step processing, it outputs outbound properties.</p>
	 * <p>This function may be extended in inheritence classes.</p>
	 * <p>Note that you can call abortPluginWithMessage() to fail the plugin with an exception
	 * AND set the message as an output property.
	 * @param args <p>The command line arguments to the step.</p>
	 * <p>The parameters are</p>
	 * <ul>
	 * <li>args[args.length-2] - Name of the inbound property file</li>
	 * <li>args[args.length-1] - Name of the outbound property file</li>
	 * </ul>
	 * @param theStep This closure actually performs the step.
	 */
	void performStep( java.lang.String[] args, Closure theStep ) {
		try {
			workDir = new File('.').canonicalFile
			stepArgs = args

			// load the inbound properties
			inProps = inputPropsLoader(args)

			// initialize the outbound properties (to an empty set)
			outProps = new Properties()
			
			
			// Set default result
			outProps.put( RESULT_NAME, RESULT_DEFAULT_FAIL )

			// If there is a property named "loggingLevel", set the logging level.
			// It should be blank, 'trace', 'debug', 'info', 'warn' or 'error'
			if (inProps.containsKey("loggingLevel")) {
				try {
					Logger.setLoggingLevel(inProps.loggingLevel)
				} catch (Exception e) {
					throw new AbortPluginException("Invalid logging level of '${inProps.loggingLevel}' sent to the plugin via the 'loggingLevel' property")
				}
			}
			
			// Shutdown hook is called on System.exit()
			addShutdownHook({
				writeOutputProperties()
			});

			// call the implementation of the step!!
			theStep();
			
			// Success - update the results
			if (outProps[RESULT_NAME].equals(RESULT_DEFAULT_FAIL)) {
				outProps[RESULT_NAME] = RESULT_SUCCESS
			}
				
		} catch (AbortPluginException e) {
			// if it is an 'AbortPluginException', display the error message, but no stack trace unless 'debug' level 
			Logger.println(LoggerLevel.ERROR, e.message )
			// sanitize the groovy information
//			StackTraceUtils.deepSanitize(e)
//			Logger.printStackTrace(LoggerLevel.DEBUG, e)
			setResultIfDefault( e.message )
			writeOutputProperties()
			exitSystem(1)
		} catch (Exception e) {
			Logger.println(LoggerLevel.ERROR, e.message )
			// sanitize the groovy information
			StackTraceUtils.deepSanitize(e)
			Logger.printStackTrace(LoggerLevel.INFO, e)
			setResultIfDefault( e.message )
			writeOutputProperties()
			exitSystem(1)
		}
		
		writeOutputProperties()
	}
	
	/**
	 * Write the output properties to the output properties file.
	 */
	protected void writeOutputProperties() {
		// If there are any outbound properties save them to the property file
		try {
			if (outProps.size() > 0) {
				Logger.debug "These are the output properties"
				outProps.each() { k, v ->
					Logger.debug "   - ${k}=${v}"
				}
				outputPropsSaver( outProps, stepArgs)
			}
		}
		catch (Exception e) {
			// eat any exceptions generated by writing the output property file
			Logger.println(LoggerLevel.ERROR, e.message )
		}
	}
	
	/**
	 * If the 'result' value is still the default value, then set the 'result' to 'msg'.
	 */
	protected void setResultIfDefault( String msg ) {
		if (! msg) {
			msg = ''.toString()
		}
		if (outProps.containsKey(RESULT_NAME) && outProps[RESULT_NAME].equals(RESULT_DEFAULT_FAIL)) {
			outProps[RESULT_NAME] = msg
		}
	}
	
	/**
	 * Aborts the plugin displaying a message, but NOT a stack trace.  This returns a non-zero exit
	 * code from the plugin to indicate that the plugin failed.  This can be called from external
	 * classes (and not just from derived classes).  Note that you can also simply throw an AbortPluginException().
	 * @param msg The message to display.
	 */
	public void abortPluginWithMessage( String msg ) {
		// Note that the plugin handler catches the 'AbortPluginException' messages by displaying the message with no stack trace and then exits the plugin.
		throw new AbortPluginException(msg)
	}
	
	public void setResult( String resultMsg ) {
		outProps[RESULT_NAME] = resultMsg
	}
	
	/**
	 * Retrieves the value of an input property without display the value.
	 * @param propertyName The name of the property.
	 */
	protected String retrieveInProp( String propertyName ) {
		String retval = ''
		if (inProps.containsKey(propertyName)) {
			retval = inProps[propertyName]
		}
		return retval
	}

	/**
	 * Retrieves the value of an input property and display the value.
	 * @param propertyName The name of the property.
	 */
	protected String retrieveAndDisplayInProp( String propertyName ) {
		String retval = ''
		if (inProps.containsKey(propertyName)) {
			retval = inProps[propertyName]
		}
		Logger.info "   ${propertyName}='${retval}'"
		return retval
	}
	
	/**
	 * Display list of plugin parameters - this can and should be extended by classes that extend this one.
	 */
	protected void displayParameters() {
		Logger.info "   loggingLevel='${Logger.getLoggingLevel()}'"
	}

	/**
	 * Helper function that returns the server URL for the UrbanCode server that launched this plugin step, such as "https://server:1234".
	 */
	String getMyRestServerUrl() {
		return System.getenv("AH_WEB_URL");
	}
	
	/**
	 * Helper function that returns the PROXY_HOST system environment.  IF the call is through a relay
	 * server, this field will be defined and should be used as an HTTP Relay Server.
	 * @return Empty string if no Proxy Host or non-empty if there is a proxy host.
	 */
	String getMyRestServerProxyHost() {
		return System.getenv("PROXY_HOST")
	}
	
	/**
	 * Helper function that returns the PROXY_PORT system environment.  IF the call is through a relay
	 * server, this field will be defined and should be used as an HTTP Relay Server.
	 * @return Empty string if no Proxy Port or non-empty if there is a proxy Port.
	 */
	String getMyRestServerProxyPort() {
		return System.getenv("PROXY_PORT")
	}

	/**
	 * Helper function that returns the username to use for automatic Token based authentication with the
	 * UrbanCode server that launched this plugin.  When an UrbanCode server launches a plugin, it make the server url,
	 * and a token based authentication username and password available.  Note that the tokens are session specific and only
	 * good for the lifetime instance of this plugin step.  
	 */
	String getMyRestServerTokenUsername() {
		return "PasswordIsAuthToken";
	}
	
	/**
	 * Helper function that returns the PROXY_USERNAME system environment.  
	 * @return Empty string the property is not defined.
	 */
	String getMyRestServerProxyUsername() {
		return System.getenv("PROXY_USERNAME")
	}
	
	/**
	 * Helper function that returns the PROXY_PASSWORD system environment.  IF the call is through a relay
	 * server, this field will be defined and should be used as an HTTP Relay Server.
	 * @return Empty string the property is not defined.
	 */
	String getMyRestServerProxyPassword() {
		return System.getenv("PROXY_PASSWORD")
	}

	/**
	 * Helper function that ret
	 * @return
	 */
	String getMyProxyUsername() {
		
	}

	/**
	 * Helper function that returns the username to use for automatic Token based authentication with the
	 * UrbanCode server that launched this plugin.  When an UrbanCode server launches a plugin, it make the server url,
	 * and a token based authentication username and password available.  Note that the tokens are session specific and only
	 * good for the lifetime instance of this plugin step.  
	 */
	String getMyRestServerTokenPassword() {
		String authToken = System.getenv("AUTH_TOKEN");
		return "{\"token\" : \"" + authToken + "\"}";
	}

	/**
	 * Returns the current Agent's installed properties, which are in the file 'conf/agent/installed.properties' as
	 * a Properties map.  Throws exception if there is an error.
	 */
	Properties getAgentProps() {
		if (this.agentProps == null) {
			this.agentProps = new Properties();
			final def agentInstalledProps = new File(AGENT_HOME, "conf/agent/installed.properties")
			final def agentInputStream = new FileInputStream(agentInstalledProps);
			agentProps.load(agentInputStream);
		}
		return this.agentProps;
	}

	/**
	 * Declaring this private function makes inProps a read-only field.
	 * @param properties
	 */
	private void setInProps( Properties properties ) {
		this.inProps = properties;
	}

	/**
	 * Declaring this private function makes outProps a read-only field.
	 * @param properties
	 */
	protected void setOutProps( Properties properties ) {
		this.outProps = properties;
	}

	/**
	 * Declaring this private function makes agentProps a read-only field.
	 * @param properties
	 */
	private void setAgentProps( Properties properties ) {
		this.agentProps = properties;
	}
	
	/**
	 * Exits the plugin with an error message.
	 */
	protected void exitWithErrorMessage( String msg ) {
		throw new RuntimeException(msg)
	}
	
	/**
	 * Sets the named Step output property to the given value.
	 */
	public void setOutputProperty( String propertyName, String propertyValue ) {
		outProps.put(propertyName, propertyValue)
	}
	
	/**
	 * Returns the plugin's XML defined information as per the function PluginHelper.getPluginInformation() as 
	 * a Map.
	 */
	public Map getPluginInformation() {
		if (! pluginInfo) {
			pluginInfo = PluginHelper.getPluginInformation()
		}
		return pluginInfo
	}
	
	/**
	 * Returns the folder where the plugin's files are located.
	 */
	public String getPluginFolder() {
		return getPluginInformation().pluginFolder
	}
	
	/**
	 * Returns the plugin's name as defined in plugin.xml.
	 */
	public String getPluginName() {
		return getPluginInformation().name
	}
	
	/**
	 * Returns the plugin's id as defined in info.xml.
	 */
	public String getPluginId() {
		return getPluginInformation().id
	}
	
	/**
	 * Returns the plugin's description as defined in plugin.xml.
	 */
	public String getPluginDescription() {
		return getPluginInformation().description
	}
	
	/**
	 * Returns the plugin's API Version as defined in plugin.xml.
	 */
	public String getPluginApiVersion() {
		return getPluginInformation().apiVersion
	}
	
	/**
	 * Returns the plugin's version as defined in plugin.xml.
	 */
	public String getPluginVersion() {
		return getPluginInformation().version
	}
}
