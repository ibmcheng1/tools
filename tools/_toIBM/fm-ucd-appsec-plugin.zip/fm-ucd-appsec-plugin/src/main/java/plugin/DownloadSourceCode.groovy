package plugin

import java.util.Map

import com.fanniemae.fortify.ssc.SscApi
import com.fanniemae.repo.RepositoryCloner
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.property.Property
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.CommandRunner	
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.plugin.AbortPluginException

import plugin.appsec.CoreAppSecPluginStep
import plugin.helper.PluginUtils

class DownloadSourceCode extends CoreAppSecPluginStep {
	
	/**
	 * This function implements the step!!
	 */
	void execute() {	
		//**********************************************
		//  UCD Process PARAMETERS (Process properties)
		//**********************************************
		Logger.info "${getPluginName()} [${getPluginVersion()}]: Download Source Code"
		// load the JSON appscanData from previous step(s)
		retrieveAndDisplayAppScanData()
		// Data for downloading source code
		retrieveAndDisplayResourcePath()
		
		// Get handle to UCD Server
		connectToUcdServer()

		performDownload( )
	}
	
	/**
	 * Perform the scan.
	 */
	public void performDownload( ) {
		
		Application application = ucdConnectionServices.getApplicationServices().getApplicationById(appscanData.application.id)
		String appCode = PluginUtils.getAppCode( application )
		String assetId = PluginUtils.getAssetId( application )
		Environment environment = application.getEnvironment(appscanData.application.environment.name)
		
		String envType = environment.getBasicProperty('envType').value
		
		appscanData.componentVersionsToBeScanned.each{ Map componentVersionData ->
			// Calculate absolute path to working directory and make sure that it exists
			String workingPath = convertRelativeToAbsolutePath(componentVersionData.relativeFolder)
			File workingPathFile = new File(workingPath)
			if (! workingPathFile.exists()) {
				workingPathFile.mkdirs()
			}
			
			ComponentVersion componentVersion = ucdConnectionServices.getComponentServices().getComponentFromId(componentVersionData.component.id).getComponentVersion(componentVersionData.name)
			Component component = componentVersion.getComponent()
			String awsRegion = PluginUtils.getComponentEnvironmentAwsRegion( environment, component )
			// Get AWS Authentication Information, which is optionally defined
			String awsAccountId
			String awsRole
			(awsAccountId,awsRole) = lookupAwsAuthenticationInfo(environment, component)

			// Lookup all of the additional Component Version Specific data
			String repoURL = componentVersionData.repoUrl
			String codeCommitHash = componentVersionData.commit
			String branch = componentVersionData.branch
			
			if (! checkoutCode( componentVersionData, resourcePath, workingPath, assetId, repoURL, branch, codeCommitHash, envType, awsAccountId, awsRole, awsRegion )) {
				registerError(componentVersionData, "unable to retrieve source code from repository" )
			} 
		}
		
		summarizeResults("Download source code")
	}
	
	/* (non-Javadoc)
	 * @see plugin.appsec.CoreAppSecPluginStep#displayAdditionalComponentVersionInfoForResultSummary(java.util.Map)
	 */
	@Override
	protected void displayAdditionalComponentVersionInfoForResultSummary(Map componentVersionData) {
		super.displayAdditionalComponentVersionInfoForResultSummary(componentVersionData);
	}
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new DownloadSourceCode()
		stepImpl.performStep(args) { stepImpl.execute() }
	}
}

