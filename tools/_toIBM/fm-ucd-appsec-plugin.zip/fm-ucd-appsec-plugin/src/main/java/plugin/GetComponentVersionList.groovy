package plugin

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.processrequest.ProcessRequest
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.css.ucd.snapshot.Snapshot
import com.ibm.css.ucd.status.ComponentVersionStatus
import com.ibm.issr.core.file.FileHelper
import com.ibm.issr.core.log.Logger

import plugin.appsec.CoreAppSecPluginStep
import plugin.helper.PluginUtils

class GetComponentVersionList extends CoreAppSecPluginStep {
	
	/**
	 * This function implements the step!!
	 */
	void execute() {	
		//**********************************************
		//  UCD Process PARAMETERS (Process properties)
		//**********************************************
		Logger.info "${getPluginName()} [${getPluginVersion()}]: Get List of Component Versions to Scan"
		// load data needed to create 'appscanData' with list of component versions needing scanning
		retrieveAndDisplayDataForGeneratingVersionList()
		super.displayParameters()
		
		// Get handle to UCD Server
		this.connectToUcdServer()

		generateListOfComponentVersionsNeedingScanning( )
		
		outProps.put( 'appscanData', groovy.json.JsonOutput.toJson(appscanData))
	}
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new GetComponentVersionList()
		stepImpl.performStep(args) { stepImpl.execute() }
	}


}

