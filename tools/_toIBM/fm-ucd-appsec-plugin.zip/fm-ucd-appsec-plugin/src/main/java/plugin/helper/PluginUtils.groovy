package plugin.helper

import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.environment.Environment
import com.ibm.issr.core.plugin.AbortPluginException

class PluginUtils {
	
	/**
	 * Looks up and returns an app template or app defined property for the application.  Throws an exception if the property isn't found.
	 */
	public static def getAnyApplicationProperty( Application application, String propertyName, boolean mandatoryField = true ) {
		application
		if (application.hasAllApplicationProperty(propertyName)) {
			return application.getAllApplicationProperty(propertyName).getValue()
		} else if (mandatoryField) {
			throw new AbortPluginException("The application '${application.name}' is not correctly configured for running AppScans.  It is missing the mandatory property '${propertyName}'")
		} else {
			return ''
		}
	}

	/**
	 * Returns the 'appCode' for the application or aborts if not found.
	 */
	public static String getAppCode( Application application, boolean mandatoryField = true ) {
		return getAnyApplicationProperty( application, 'appCode', mandatoryField )
	}
	
	/**
	 * Returns the 'assetId' for the application or aborts if not found.
	 */
	public static String getAssetId( Application application, boolean mandatoryField = true ) {
		return getAnyApplicationProperty( application, 'assetId', mandatoryField )
	}

	/**
	 * Looks up and returns a Component property, which might be a basic or entity property.  If 'mandatroyField' is true
	 * then abort if property is missing, otherwise, return empty string if not found.
	 */
	public static def getComponentPropertyValue( Component component, String propertyName, boolean mandatoryField = true ) {
		if (component.hasPropertyEntry(propertyName)) {
			return component.getPropertyEntry(propertyName).getValue()
		} else if (mandatoryField) {
			throw new AbortPluginException( "The component '${component.name}' is not correctly configured for running AppScans.  It is missing the mandatory property '${propertyName}'" )
		} else {
			return ''
		}
	}
	
	/**
	 * Returns the optional 'aws.region' UCD Component Environment property or empty string if not found.
	 */
	public static String getComponentEnvironmentAwsRegion( Environment environment, Component component ) {
		if (component.hasComponentEnvironmentProperty( environment, 'aws.region' )) {
			return component.getComponentEnvironmentProperty( environment, 'aws.region' ).value
		} else {
			return ''
		}
	}

	/**
	 * Returns the 'repoURL' property for the component.
	 */
	public static String getRepoURL( Component component, boolean mandatoryField = true ) {
		return getComponentPropertyValue( component, 'repoURL', mandatoryField )
	}

	/**
	 * Returns the name (leaf name of url) for the component.
	 */
	public static String getRepoName( ComponentVersion componentVersion, boolean mandatoryField = true ) {
		String repoUrl = getRepoURL( componentVersion, mandatoryField )
		String[] tokens = repoUrl.split('/')
		return tokens[ tokens.size()-1 ]
	}

	/**
	 * Returns the 'javaVersion' property for the component.
	 */
	public static String getJavaVersion( Component component, boolean mandatoryField = true ) {
		return getComponentPropertyValue( component, 'javaVersion', mandatoryField )
	}
	
//	/**
//	 * Returns the 'hpFortifySseName' property for the component.
//	 */
//	public static String getHpFortifySseName( Component component, boolean mandatoryField = true ) {
//		return getComponentPropertyValue( component, 'appsecVersionName', mandatoryField )
//	}

//	/**
//	 * Returns the HP Fortify Project Name for the given UCD application and component.
//	 */
//	public static String getFortifyProjectName( Component component, boolean mandatoryField = true ) {
//		return getComponentPropertyValue(component,'appsecProjectName',mandatoryField)
//	}

	/**
	 * Returns the 'appsecScanRequired' property for the component.
	 */
	public static String getAppsecScanRequired( Component component, boolean mandatoryField = true ) {
		return getComponentPropertyValue( component, 'appsecScanRequired', mandatoryField )
	}

	/**
	 * Looks up and returns a Component property, which might be a basic or entity property.  If 'mandatroyField' is true
	 * then abort if property is missing, otherwise, return empty string if not found.
	 */
	public static def getComponentVersionManagedPropertyValue( ComponentVersion componentVersion, String propertyName, boolean mandatoryField = true ) {
		if (componentVersion.hasManagedProperty(propertyName)) {
			return componentVersion.getManagedProperty(propertyName)
		} else if (mandatoryField) {
			throw new AbortPluginException( "The component version '${componentVersion.name}' of component '${componentVersion.component.name}' is not correctly configured for running AppScans.  It is missing the mandatory property '${propertyName}'" )
		} else {
			return ''
		}
	}
	
	/**
	 * Returns the 'codeCommitHash' property for the component version.
	 */
	public static String getCodeCommitHash( ComponentVersion componentVersion, boolean mandatoryField = true ) {
		return getComponentVersionManagedPropertyValue( componentVersion, 'commitHash', mandatoryField )
	}

	/**
	 * Returns the 'branch' property for the component version.
	 */
	public static String getBranch( ComponentVersion componentVersion, boolean mandatoryField = true ) {
		String branchStr = getComponentVersionManagedPropertyValue( componentVersion, 'repoBranch', mandatoryField )
		if(branchStr.contains("origin/")) {
			branchStr = branchStr.substring(branchStr.indexOf("/")+1,branchStr.length())
		}
		return branchStr
	}

	/**
	 * Returns the 'repoURL' property for the component version.
	 */
	public static String getRepoURL( ComponentVersion componentVersion, boolean mandatoryField = true ) {
		return getComponentVersionManagedPropertyValue( componentVersion, 'repoUrl', mandatoryField )
	}

	/**
	 * Returns the 'buildTimestamp' property for the component version.
	 */
	public static String getBuildTimestamp( ComponentVersion componentVersion, boolean mandatoryField = true ) {
		return getComponentVersionManagedPropertyValue( componentVersion, 'buildTimestamp', mandatoryField )
	}

	/**
	 * Returns the HP Fortify Application Name for the given UCD application and component version.
	 */
	public static String getFortifyApplicationName( Application application, ComponentVersion componentVersion ) {
		return getComponentPropertyValue(componentVersion.component,'appsecProjectName')
	}

	/**
	 * Returns the HP Fortify Version Name for the given UCD application and component version.
	 */
	public static String getFortifyVersionName( Application application, ComponentVersion componentVersion ) {
		String versionName = componentVersion.component.name
		String sseName = getComponentPropertyValue(componentVersion.component,'appsecVersionName')
		if (sseName) {
			versionName = sseName
		}
		return versionName
	}

}
