package plugin;

import org.codehaus.groovy.runtime.StackTraceUtils

import plugin.logger.UcrPluginLogger

import com.ibm.issr.core.log.Logger
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.RestServerConnectionBuilder
import com.ibm.services.ucr.api.entity.integrationprovider.UcrPluginIntegrationProvider
import com.ibm.services.ucr.api.entity.integrationprovider.UcrPluginIntegrationProviderMgr

/**
 * This is the base class for all types of UCR plugin steps, including
 * Integration definitions, Plugin Task steps and event driven Plugin steps.
 * Inherited classes extend this with step type specific capabilities.
 * @author LeonClark
 *
 */
abstract class UCRPluginStep {
	/**
	 * This Closure is responsible for loading the input properties.  The
	 * closure syntax is: 'Properties loadInputProperties( String[] args ).  It is
	 * passed the programs command line arguments.  It must return the loaded Properties.
	 */
	public static Closure loadInputProperties = { String[] args ->
		// load the inbound properties
		Properties inProps = new Properties();
		final def inputPropsFile = new File(args[args.length-2]);
		def inputPropsStream = new FileInputStream(inputPropsFile);
		inProps.load(inputPropsStream);
		return inProps
	}
	
	/**
	 * Closure which saves the output properties.  The arguments are .. 'outProps' are the properties to save.
	 * 'args' are the commend line properties.  The default implementation saves the properties
	 * to the file that is named as the last parameter in the arguments.
	 */
	public static Closure saveOutputProperties = { Properties outProps, java.lang.String[] args ->
		final def outputPropsFile = new File(args[args.length-1]);
		def outputPropsStream = new FileOutputStream(outputPropsFile);
		outProps.store(outputPropsStream, "Output props");
	}

	/**
	 * The input properties for the plugin.
	 */
	public Properties inProps
	
	/**
	 * The output properties for the plugin
	 */
	public Properties outProps = new Properties()

	/**
	 * The handle to this UCR server, which is cached.	
	 */
	private RestServerConnection _ucrServer = null
	
		
	
	/**
	 * <p>The main() function should call this to perform this plugin step!!  In turn,
	 * the Closure named 'theStep' is called to perform the actual step.  The syntax
	 * for 'theStep' is 'int theStep()' where it returns the program's exit code with a 0
	 * meaning success and non-zero value indicating a failure.
	 * </p>
	 * <p>By defaults, the input property file is named in args[arg.length-2] and the
	 * output property file is named in args[arg.length-1].  However, more specifically, the
	 * input properties are loaded via the loadInputProperties Closure and the output properties
	 * are saved via the saveOuputProperties Closure.  Since they are closures, they can be overridden.
	 * </p>
	 * @param args The command line arguments.
	 * @param theStep The closure which implements the step.
	 */
	protected void performStep( String[] args, Closure theStep ) {
		int retval = 0
		try {
			
			
			// Set the logger to a UCR specific logger
			// To find a directory to log to, find the current class' directory.  Then walk
			// parents until 'repo' directory found and then go one more up.
			File logDirectory = new File(getClass().protectionDomain.codeSource.location.path)
			while (logDirectory && logDirectory.getName()!="repo") {
				logDirectory = logDirectory.getParentFile()
			}
			if (logDirectory) {
				logDirectory = logDirectory.getParentFile()
			} else {
				logDirectory = new File( '/' )
			}
			// Get the name of the plugin from the plugin.xml file
			//	- Why? The name is available via REST calls, by we want to start the logger before making any REST calls.
			File pluginDirectory = new File(getClass().protectionDomain.codeSource.location.path)
			String pluginName = ""
			while (pluginDirectory && (! pluginName)) {
				// Walk up the directory tree looking for plugin.xml
				File pluginFile = new File(pluginDirectory,"plugin.xml")
				if (pluginFile.exists()) {
					def plugin = new XmlParser().parse(pluginFile)
					pluginName = plugin.header.identifier.@name[0]
					break
				}
				pluginDirectory = pluginDirectory.getParentFile()
			}
			if (! pluginName) {
				pluginName = "plugin"
			}
			// Set the logger
			//   get a unique id for logging - for now - first 2 + last 4 digits of a UUID
			String logId = UUID.randomUUID().toString()
			logId = logId.substring(0,2) + logId.substring(logId.length()-4)
			Logger.loggerImpl = new UcrPluginLogger(this.getClass().getSimpleName(), pluginName, logId, logDirectory )
			
			inProps = loadInputProperties(args)
			
			// Set logging level
			Map integrationProperties = getIntegrationDefinedProperties()
			if (integrationProperties.containsKey('loggingLevel')) {
				Logger.setLoggingLevel(integrationProperties.loggingLevel)
			} else {
				Logger.setLoggingLevel("info")
			}
			
			retval = theStep()
			
		} 
		catch (Exception e) {
			println e.getMessage()
			StackTraceUtils.deepSanitize(e)
			e.printStackTrace()
			System.exit(1)
		} 
		finally {
			// Write the output properties
			saveOutputProperties( outProps, args )
		}
		if (retval) {
			System.exit(retval)
		}
	}
	
	
	/**
	 * Returns the 'extraProperties' input file property as an json slurped Object set.
	 * UCR stores lot's of information in the extraProperties input field.  Generally,
	 * the custom UCR Plugin Step classes (such as UCRPluginTaskStep) have functions
	 * that pull step type (such as 'Task Step' or 'Event Step') specific information
	 * from this field as the contents of this field are type specific.
	 */
	public def getExtraProperties() {
		return new groovy.json.JsonSlurper().parseText( inProps.extraProperties )
	}
	
	
	/**
	 * Returns a handle to the UCR server using the default plugin implementation.
	 * Specifically, this uses the 'releaseServerUrl', 'releaseToken' and 'releaseUser'
	 * data from the input property file.  Note that the server connection is cached,
	 * so the first call actually establishes the connection, but subsequent calls use
	 * the existing connection.
	 */
	public RestServerConnection getUcrServer() {
		if (! _ucrServer) {
			_ucrServer = (new RestServerConnectionBuilder())
				.setServerUrl(inProps.releaseServerUrl)
				.setAuthentication(inProps.releaseUser, inProps.releaseToken)
				.setTrustAllCerts()
//				.setProxyInformation(ucrProxyHost, ucrProxyPort, ucrProxyUsername, ucrProxyPassword)
				.openConnection()
		}
		return _ucrServer
	}
	
	/**
	 * <p>Returns the plugin.xml define properties of the Step as a Map where the key is the String
	 * name of the property and the value is the value.  These are the 'properties' defined for this specific
	 * plugin step. For example, for an Integration plugin step, it is the Integration's properties and for
	 * the Custom Plugin step it is the custom plugin's properties.</p>  
	 * <p>Note that the map contains MORE THAN
	 * just the plugin.xml defined properties.  For example, one of the standard fields is 'lastPropertyEdit',
	 * which is the date/time when the properties were last edited.</p>
	 */
	abstract public Map getPluginXmlDefinedProperties()
	
	
	/**
	 * Returns a Map which includes the plugin.xml defined Integration properties. Note
	 * that the properties are mixed in with other standard properties, so the actual
	 * returned map is a superset of the Integration defined properties.
	 */
	public Map getIntegrationDefinedProperties() {
		return inProps
	}
	
	
	/**
	 * Displays an input property name and value.
	 */
	protected void displayProperty( String propertyName, def propertyValue ) {
		Logger.info "   ${propertyName}='${propertyValue.toString()}'"
	}

	
	/**
	 * Retrieves the value of a Plugin.xml defined input property and display the value.
	 * If the property isn't found, then an empty string is returned.
	 * @param propertyName The name of the property.
	 * @param propertySet This is an optional propertySet map, such as via a call to
	 * getIntegrationDefinedProperties() or getPluginXmlDefinedProperties().  If not
	 * provided, this defaults to the pluginXml define properties.
	 */
	protected String retrieveAndDisplayInProp( String propertyName, Map propertySet=null ) {
		String retval = retrieveInProp(propertyName, propertySet)
		displayProperty( propertyName, retval )
		return retval
	}
	
	
	/**
	 * Retrieves the value of a Plugin.xml defined input property and display the value.
	 * If the property isn't found, then an empty string is returned.
	 * @param propertyName The name of the property.
	 * @param defaultValue If the retrieved value is empty, then the default value is used instead. 
	 * @param propertySet This is an optional propertySet map, such as via a call to
	 * getIntegrationDefinedProperties() or getPluginXmlDefinedProperties().  If not
	 * provided, this defaults to the pluginXml define properties.
	 */
	protected String retrieveAndDisplayInProp( String propertyName, String defaultValue, Map propertySet=null ) {
		String retval = retrieveInProp(propertyName, propertySet)
		if (! retval) {
			retval = defaultValue
		}
		displayProperty( propertyName, retval )
		return retval
	}

	
	/**
	 * Retrieves the value of a Plugin.xml defined input property without displaying the value.
	 * If the property isn't found, then an empty string is returned.
	 * @param propertyName The name of the property.
	 * @param propertySet This is an optional propertySet map, such as via a call to
	 * getIntegrationDefinedProperties() or getPluginXmlDefinedProperties().  If not
	 * provided, this defaults to the pluginXml define properties.
	 */
	protected String retrieveInProp( String propertyName, Map propertySet=null ) {
		String retval = ''
		if (! propertySet) {
			propertySet = getPluginXmlDefinedProperties()
		}
		if (propertySet.containsKey(propertyName)) {
			retval = propertySet[propertyName]
		}
		else {
			// property not found, use default return value, which is already set.
//	Logger.info "Unable to find the property named '${propertyName}' in ..."
//	propertySet.each { String key, String value ->
//		Logger.info "   " + key + ": " + value
//	} 
		}		
		return retval
	}
	
	
	/**
	 * Returns the UCRPluginIntegrationProvider for this plugin step.
	 */
	UcrPluginIntegrationProvider getIntegrationProvider() {
		return UcrPluginIntegrationProviderMgr.getInstance(ucrServer).getById(inProps.releaseIntegrationProvider)
	}
}
