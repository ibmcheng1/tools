package plugin;

import org.codehaus.groovy.runtime.StackTraceUtils

import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.RestServerConnectionBuilder

/**
 * Use this base class for plugin step classes which implement the action for a property
 * button.
 * @author LeonClark
 *
 */
class UCRPluginStep_ButtonField extends UCRPluginStep {

		
	
	@Override
	protected void performStep( String[] args, Closure theStep ) {
		// chains to the parent performStep
		
		// custom code may be placed here
		
		super.performStep(args) {
			int retval
			
			// custom code may be placed here
			 
			retval = theStep()
			
			// custom code may be placed here
			
			return retval
		}
	}
	
	/**
	 * Field Definitions have no step specific properties, so this just
	 * returns an empty map.
	 */
	@Override
	public Map getPluginXmlDefinedProperties() {
		return [:]
	}	
	
	/**
	 * Sets the Output of the FieldDefinition step, which is generally a JSON string
	 * containing the output data, such as a list of values for the select list.
	 * Specifically, this writes a String named 'Output' to the output property file.
	 * @param value The output string.
	 */
	public void setOutput( String value ) {
		outProps.put( "Output", value )
	}
}
