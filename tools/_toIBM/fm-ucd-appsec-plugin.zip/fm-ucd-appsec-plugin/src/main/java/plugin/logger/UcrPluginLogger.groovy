package plugin.logger

import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerInterface
import com.ibm.issr.core.log.LoggerLevel

/**
 * This is a Logger specific to UCR plugins.  The UCD logger simply logs
 * to the standard output, but generally, for UCR plugins, the standard output
 * doesn't go anywhere useful. 
 * @author LeonClark
 *
 */
class UcrPluginLogger implements LoggerInterface {
	private String _stepName
	private File _logFile
	private String _processId
	
	/**
	 * Constructor.
	 * @param stepName The name of the running step, such as "Integration" or "GetApplications".
	 * An easy way to do this is to use the step's implementation class name.
	 * @param logFileName The base name (without extension) of the log file name
	 * to create, such as 'service-now-plugin'.
	 * @param processId Some string that uniquely identifies one running plugin instance.  It is
	 * common for multiple instances of the same plugin to run at the same time, so this differntiates them.
	 * The actual value doesn't matter.
	 * @param logDirectory The directory to put the log into.
	 */
	public UcrPluginLogger( String stepName, String logFileName, String processId, File logDirectory ) {
		_stepName = stepName
		_processId = processId
//		println "LOG DIRECTORY: " + logDirectory
//		println "LOG FILENAME: " + logFileName
		_logFile = new File( logDirectory, logFileName + ".log" )
//		println "LOG FILE: " + _logFile
		if (! _logFile.exists()) {
			_logFile.text = ''
		}
	}
	
	/**
	 * This is the internal function used to output the message.  This should ONLY be called internally
	 * to this class and ONLY after confirming that the given logging level needs output.
	 * @param label The Logging level label, such as "TRACE"
	 * @param message The logging message.
	 */
	private void emit( String label, def message ) {
		String prefix = "${label}"
		Closure out = Logger.outputLine
		message.eachLine { line ->
			String msg = "${prefix} ${_stepName} - ${Logger.tabOutput}${Logger.indentation}${line}".toString() 
			out( msg )
			_logFile.append((new Date()).format("yyyy-MM-dd HH:mm:ss") + " " + _processId + " " + msg +"\n")
			prefix = "..."
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.issr.core.log.LoggerInterface#trace(java.lang.Object)
	 */
	@Override
	public void trace( def message ) {
		if (Logger.displayTrace) {
			emit("TRACE", message)
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.issr.core.log.LoggerInterface#debug(java.lang.Object)
	 */
	@Override
	public void debug( def message ) {
		if (Logger.displayDebug) {
			emit("DEBUG", message)
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.issr.core.log.LoggerInterface#info(java.lang.Object)
	 */
	@Override
	public void info( def message ) {
		if (Logger.displayInfo) {
			emit("INFO", message)
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.issr.core.log.LoggerInterface#warn(java.lang.Object)
	 */
	@Override
	public void warn( def message ) {
		if (Logger.displayWarn) {
			emit("WARNING", message)
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.issr.core.log.LoggerInterface#error(java.lang.Object)
	 */
	@Override
	public void error( def message ) {
		if (Logger.displayError) {
			emit("ERROR", message)
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.issr.core.log.LoggerInterface#fatal(java.lang.Object)
	 */
	@Override
	public void fatal( def message ) {
		if (Logger.displayFatal) {
			emit("FATAL", message)
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.issr.core.log.LoggerInterface#debugSession(java.lang.Object)
	 */
	@Override
	public void debugSession( def message ) {
		emit("DEBUGGING SESSION", message)
	}
	
	
	/* (non-Javadoc)
	 * @see com.ibm.issr.core.log.LoggerInterface#println(com.ibm.issr.core.log.LoggerLevel, java.lang.Object)
	 */
	@Override
	public void println( LoggerLevel loggerLevel, def message ) {
		if (! message) {
			message = ''.toString()
		}
		loggerLevel.println message
	}
	
	
	/* (non-Javadoc)
	 * @see com.ibm.issr.core.log.LoggerInterface#printStackTrace(com.ibm.issr.core.log.LoggerLevel, java.lang.Throwable)
	 */
	@Override
	public void printStackTrace( LoggerLevel loggerLevel, Throwable e ) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		pw.flush()
		sw.flush()
		String stringTrace = sw.toString()
		stringTrace.eachLine { line ->
			loggerLevel.println line
		}
	}
}
