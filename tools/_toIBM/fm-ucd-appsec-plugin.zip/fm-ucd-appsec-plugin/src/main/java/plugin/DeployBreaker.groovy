package plugin

import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.snapshot.Snapshot
import com.ibm.css.ucd.status.ComponentVersionStatus
import com.ibm.css.ucd.status.SnapshotStatus
import com.ibm.issr.core.log.Logger

import plugin.appsec.CoreAppSecPluginStep
import plugin.helper.PluginUtils

class DeployBreaker extends CoreAppSecPluginStep {
	
	/**
	 * This function implements the step!!
	 */
	void execute() {	
		//**********************************************
		//  UCD Process PARAMETERS (Process properties)
		//**********************************************
		Logger.info "${getPluginName()} [${getPluginVersion()}]: Perform Deploy Breaker"
		// load the JSON appscanData from previous step(s)
		retrieveAndDisplayAppScanData()
		// Data for the scan
//		retrieveAndDisplayScaData()
//		retrieveAndDisplaySonarData()
		retrieveAndDisplaySscServerData()
		retrieveAndDisplayStatusOwnerDataforUCDServer()
		super.displayParameters()
		
		// Get handle to UCD Server
		connectToUcdServer()

		// Get handle to UCD Server for Status Owner
		connectToUcdServer2()

		
		performDeployBreaker( )
	}
	
	/**
	 * Perform the deploy breaker.
	 */
	public void performDeployBreaker( ) {
		
		Application application = ucdConnectionServices.getApplicationServices().getApplicationById(appscanData.application.id)
		ComponentVersionStatus appScanPassedComponentStatus = ucdConnectionServices.getStatusServices().getComponentVersionStatus(APPSCAN_PASSED_COMPONENT_STATUS)
		ComponentVersionStatus appScanFailedComponentStatus = ucdConnectionServices.getStatusServices().getComponentVersionStatus(APPSCAN_FAILED_COMPONENT_STATUS)
		SnapshotStatus appScanPassedSnapshotStatus = ucdConnectionServices.getStatusServices().getSnapshotStatus(APPSCAN_PASSED_COMPONENT_STATUS)
		SnapshotStatus appScanFailedSnapshotStatus = ucdConnectionServices.getStatusServices().getSnapshotStatus(APPSCAN_FAILED_COMPONENT_STATUS)

		appscanData.componentVersionsToBeScanned.each{ Map componentVersionData ->

			Logger.debug "*****Started working on....componentVersionData.name: '${componentVersionData.name}'"
			
			ComponentVersion componentVersion = ucdConnectionServices.getComponentServices().getComponentFromId(componentVersionData.component.id).getComponentVersion(componentVersionData.name)

//			Component component = componentVersion.getComponent()

//			componentVersionData.sscApplicationName = PluginUtils.getFortifyProjectName(componentVersion.component)
//			componentVersionData.sscVersionName = PluginUtils.getFortifyVersionName(application, componentVersion)

			Logger.debug "*****componentVersionData.component.fortifyApplication: '${componentVersionData.component.fortifyApplication}'"
			Logger.debug "*****componentVersionData.component.fortifyVersion: '${componentVersionData.component.fortifyVersion}'"
			
			if (! findDeployBreakerIssuesAndSetComponentVersionStatus( componentVersionData, componentVersion, sscServerUrl, sscUsername, sscPassword, appScanPassedComponentStatus, appScanFailedComponentStatus )) {
				registerError(componentVersionData, "Unable to find deploy breaker issues on SSC - NO ISSUES FOUND" )
			} 
		}
		
		// if snapshot defined - set its status
		if (appscanData.containsKey('snapshot')) {
		Logger.debug "*****Started working on snapshot status..."
			Map snapshotData = appscanData.snapshot
			Snapshot snapshot = application.getSnapshot(snapshotData.name)
			List componentVersions = snapshot.getComponentVersionObjects()
			// search for a failed component version
			ComponentVersion failedComponentVersion = componentVersions.find { ComponentVersion componentVersion ->
				return componentVersion.hasStatus(appScanFailedComponentStatus)
			}
			if (failedComponentVersion) {
				// at least one component version failed - flag snapshot as failed
				if (snapshot.hasSnapshotStatus(appScanPassedSnapshotStatus)) {
					snapshot.removeSnapshotStatus(ucdServer2, appScanPassedSnapshotStatus)
				}
				if (! snapshot.hasSnapshotStatus(appScanFailedSnapshotStatus)) {
					snapshot.addSnapshotStatus(ucdServer2, appScanFailedSnapshotStatus)
				}
			} else {
				// no component versions failed - make sure snapshot flagged as passed
				if (snapshot.hasSnapshotStatus(appScanFailedSnapshotStatus)) {
					snapshot.removeSnapshotStatus(ucdServer2, appScanFailedSnapshotStatus)
				}
				if (! snapshot.hasSnapshotStatus(appScanPassedSnapshotStatus)) {
					snapshot.addSnapshotStatus(ucdServer2, appScanPassedSnapshotStatus)
				}
			}
		} else {
			Logger.debug "*****No need to update snapshot status as snapshot is NOT used during request."
		}
	}

	/* (non-Javadoc)
	 * @see plugin.appsec.CoreAppSecPluginStep#displayAdditionalComponentVersionInfoForResultSummary(java.util.Map)
	 */
	@Override
	protected void displayAdditionalComponentVersionInfoForResultSummary(Map componentVersionData) {
		Logger.info "\tUploaded to SSC as Application='${componentVersionData.sscApplicationName}', Version='${componentVersionData.sscVersionName}' at " +
				getSscHyperlink( sscServerUrl, sscUsername, sscPassword, componentVersionData.component.fortifyApplication, componentVersionData.component.fortifyVersion )
		super.displayAdditionalComponentVersionInfoForResultSummary(componentVersionData);
	}
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new DeployBreaker()
		stepImpl.performStep(args) { stepImpl.execute() }
	}
}

