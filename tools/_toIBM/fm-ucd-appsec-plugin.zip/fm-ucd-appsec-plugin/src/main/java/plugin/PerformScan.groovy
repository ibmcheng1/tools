package plugin

import java.util.Map

import com.fanniemae.fortify.ssc.SscApi
import com.fanniemae.repo.RepositoryCloner
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.property.Property
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.plugin.AbortPluginException

import plugin.appsec.CoreAppSecPluginStep
import plugin.helper.PluginUtils

class PerformScan extends CoreAppSecPluginStep {

    /**
     * This function implements the step!!
     */
    void execute() {
        //**********************************************
        //  UCD Process PARAMETERS (Process properties)
        //**********************************************
        Logger.info "${getPluginName()} [${getPluginVersion()}]: Perform Scan"
        // load the JSON appscanData from previous step(s)
        retrieveAndDisplayAppScanData()
        // Data for the scan
        retrieveAndDisplayScaData()
        retrieveAndDisplaySonarData()
        retrieveAndDisplaySscServerData()
        super.displayParameters()

        // Get handle to UCD Server
        connectToUcdServer()

        performScan()
    }

    /**
     * Perform the scan.
     */
    public void performScan() {

        Application application = ucdConnectionServices.getApplicationServices().getApplicationById(appscanData.application.id)
        String appCode = PluginUtils.getAppCode(application)
        String assetId = PluginUtils.getAssetId(application)
        Environment environment = application.getEnvironment(appscanData.application.environment.name)

        String envType = environment.getBasicProperty('envType').value

        appscanData.componentVersionsToBeScanned.each { Map componentVersionData ->
            // Calculate absolute path to working directory and make sure that it exists
            String workingPath = convertRelativeToAbsolutePath(componentVersionData.relativeFolder)
            String fprFilename = convertRelativeToAbsolutePath(componentVersionData.fprFilename)
            File workingPathFile = new File(workingPath)
            if (!workingPathFile.exists()) {
                workingPathFile.mkdirs()
            }

            ComponentVersion componentVersion = ucdConnectionServices.getComponentServices().getComponentFromId(componentVersionData.component.id).getComponentVersion(componentVersionData.name)
            Component component = componentVersion.getComponent()

            // Lookup all of the additional Component Version Specific data
            String javaVersion = componentVersionData.javaVersion
            String sscApplicationName = componentVersionData.component.fortifyApplication
            String sscVersionName = componentVersionData.component.fortifyVersion
            if (scanScope.equalsIgnoreCase("CODE_REVIEW_APP_SCAN")) {
                // Perform Scan and Code review
                if (!cleanAnalyzer(workingPath, appCode)) {
                    registerError(componentVersionData, "unable clean the source analyzer")
                } else if (!compileMavenProject(workingPath, appCode, assetId, javaVersion, 'pom.xml')) {
                    registerError(componentVersionData, "maven build failed")
                } else if (!runCodeAnalyzer(workingPath, appCode, fprFilename)) {
                    registerError(componentVersionData, "codeanalyzer failed")
                } else if (!uploadResults(workingPath, fprFilename, sscApplicationName, sscVersionName, sscServerUrl, sscAuthToken)) {
                    registerError(componentVersionData, "Unable to upload results to SSC")
                } else if (!generateSonatypeReport(workingPath, fprFilename, appCode, assetId)) {
                    registerError(componentVersionData, "Sonatype Report Generation failed")
                } else if (!runSonarRunner(workingPath, fprFilename, sscApplicationName, sscVersionName, sscServerUrl, sscAuthToken, scaInstallationPath, sonarServerUrl, sonarInstallationPath, scanScope)) {
                    registerError(componentVersionData, "Sonar Runner failed")
                }
            } else if (scanScope.equalsIgnoreCase("CODE_REVIEW")) {
                if (!compileMavenProjectForSonar(workingPath, appCode, assetId, javaVersion, 'pom.xml')) {
                    registerError(componentVersionData, "maven build failed")
                } else if (!runSonarRunner(workingPath, fprFilename, sscApplicationName, sscVersionName, sscServerUrl, sscAuthToken, scaInstallationPath, sonarServerUrl, sonarInstallationPath, scanScope)) {
                    registerError(componentVersionData, "Sonar Runner failed")
                }
            } else if (scanScope.equalsIgnoreCase("APP_SCAN")) {
                if (!cleanAnalyzer(workingPath, appCode)) {
                    registerError(componentVersionData, "unable clean the source analyzer")
                } else if (!compileMavenProject(workingPath, appCode, assetId, javaVersion, 'pom.xml')) {
                    registerError(componentVersionData, "maven build failed")
                } else if (!runCodeAnalyzer(workingPath, appCode, fprFilename)) {
                    registerError(componentVersionData, "codeanalyzer failed")
                } else if (!uploadResults(workingPath, fprFilename, sscApplicationName, sscVersionName, sscServerUrl, sscAuthToken)) {
                    registerError(componentVersionData, "Unable to upload results to SSC")
                } else if (!generateSonatypeReport(workingPath, fprFilename, appCode, assetId)) {
                    registerError(componentVersionData, "Sonatype Report Generation failed")
                }
            } else {
                throw new AbortPluginException("scanScope undefined. Allowed values are CODE_REVIEW_APP_SCAN, CODE_REVIEW, APP_SCAN.")
            }
        }

        summarizeResults("Scan")
    }

    /* (non-Javadoc)
     * @see plugin.appsec.CoreAppSecPluginStep#displayAdditionalComponentVersionInfoForResultSummary(java.util.Map)
     */

    @Override
    protected void displayAdditionalComponentVersionInfoForResultSummary(Map componentVersionData) {
        Logger.info "Getting SSC Hyperlink for Application='${componentVersionData.component.fortifyApplication}', Version='${componentVersionData.component.fortifyVersion}'"
        Logger.info "\tUploaded to SSC as Application='${componentVersionData.component.fortifyApplication}', Version='${componentVersionData.component.fortifyVersion}' at " +
                getSscHyperlink(sscServerUrl, sscUsername, sscPassword, componentVersionData.component.fortifyApplication, componentVersionData.component.fortifyVersion)
        super.displayAdditionalComponentVersionInfoForResultSummary(componentVersionData);
    }

    public static void main(java.lang.String[] args) {
        def stepImpl = new PerformScan()
        stepImpl.performStep(args) { stepImpl.execute() }
    }
}

