import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger

import plugin.GetComponentVersionList
import plugin.PerformScan

class CallPluginSteps {

	static main(String[] args) {
		if (args.size() < 3) {
			displayHelp()
		} else {
			String ucdServerUrl = args[0]
			String token = args[1]
			String applicationProcessRequestId = args[2]
			
			UcdServerConnection ucdServer = new UcdServerConnection()
			ucdServer.openConnection(ucdServerUrl, token )
			UcdConnectionServices ucdConnectionServices = new UcdConnectionServices(ucdServer)
			
			Properties outProps = new Properties()
			
//			Logger.setLoggingLevel "debug"

			(new GetComponentVersionList()).generateList(ucdConnectionServices, outProps, applicationProcessRequestId)
				
			println "** OUTPUT PROPERTIES FROM generateList **"
			outProps.each { String name, def value ->
				println "${name}: ${value}"
			}
			
			(new PerformScan()).performScan(ucdConnectionServices, outProps, outProps.appscanData, 'https://pwv-e4t-a01:8443/ssc', '8e6568f0-4c7f-41b1-ab23-ffe02a467471', false)
		}
	}
	
	public static void displayHelp() {
		println "Syntax: CallPluginStep_GetComponentVersionList ucdServedUrl ucdToken applicationProcessRequestId"
	}

}
