import java.util.Map

import com.fanniemae.fortify.ssc.SscApi
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.plugin.AbortPluginException

class TestSscApi {

	// The issuesWithSeverityCache is indexed by application/project ID/version ID.  The value is the issue list
	// with severity higher than 4.0 for that app/project/version
	private Map issuesWithSeverityCache = [:]

	static main(args) {

//		String PRE_EXISTING_ISSUE_PRIMARY_TAG = "Pre-Existing Issue"
		Logger.setLoggingLevel('debug')
		
//		String PRIMARY_TAGS_FILENAME = "C:\\git\\fnma\\fm-ucd-appsec-plugin\\src\\main\\java\\com\\fanniemae\\fortify\\PrimaryTags.txt"
//		String PRIMARY_TAGS_FILENAME = "src\\main\\java\\com\\fanniemae\\fortify\\PrimaryTags.txt"
//		String PRIMARY_TAGS_FILENAME = "src\\main\\java\\com\\fanniemae\\fortify\\PrimaryTagsUsedToContinueDeployment.txt"
		String PRIMARY_TAGS_FILENAME = "\\com\\fanniemae\\fortify\\PrimaryTagsUsedToContinueDeployment.txt"
		
		// TODO - this is test code
		SscApi sscApi = new SscApi('https://pwv-e4t-a01:8443/ssc', args[0], args[1])
//		SscApi sscApi = new SscApi('https://awv-e4t-a007:8443/ssc', args[0], args[1])
/*
		Logger.debug "Loading projects - first time"
		Map results = sscApi.getProjects()
		Logger.debug "Loading projects - second time"
		results = sscApi.getProjects()
		Logger.debug "Loading projects - with reset"
		results = sscApi.getProjects(true)
*/
/*
		Logger.debug "Getting project ID - first time"
		int projId = sscApi.getProjectId("FZM")
		Logger.debug " project ID - first time: " + projId
		Logger.debug "Getting project ID - second time"
		projId = sscApi.getProjectId("FZM")
		Logger.debug " project ID - second time: " + projId
		Logger.debug "Getting project ID - with reset"
		projId = sscApi.getProjectId("FZM", true)
		Logger.debug " project ID - with reset: " + projId
*/
/*
		 Logger.debug "Loading versions - first time"
		Map versions = sscApi.getVersions(projId)
		Logger.debug "Loading versions - second time"
		versions = sscApi.getVersions(702)
		Logger.debug "Loading versions - with reset"
		versions = sscApi.getVersions(702,true)
*/
/*
		Logger.debug "Getting version ID - first time"
		int versionId = sscApi.getVersionId(projId, "MSR01617")
		Logger.debug " version ID - first time: " + versionId
		Logger.debug "Getting version ID - second time"
		versionId = sscApi.getVersionId(projId, "MSR01617")
		Logger.debug " version ID - second time: " + versionId
		Logger.debug "Getting version ID - with reset"
		versionId = sscApi.getVersionId(projId, "MSR01617", true)
		Logger.debug " version ID - with reset: " + versionId
*/
		
		
		Logger.debug "*****Loading dashboard versions - first time"
		Map dashboardVersions = sscApi.getDashboardVersions()
/*		Logger.debug "Loading dashboard versions - second time"
		results = sscApi.getDashboardVersions()
		Logger.debug "Loading dashboard versions - with reset"
		results = sscApi.getDashboardVersions(true)
*/		
		
		String sscApplicationName = "EDL_EDW"
		String sscVersionName = "MSR00365"
//		String sscApplicationName = "FZM"
//		String sscVersionName = "MSR01617"
//		String sscApplicationName = "Test"
//		String sscVersionName = "AppSec12345"
//		String sscApplicationName = "ACheck-appsec"
//		String sscVersionName = "AST000000000050019"

		Logger.debug "*****Getting version ID from dashboard versions - first time"
		int versionId = sscApi.getVersionIdFromDashboardVersions(sscApplicationName, sscVersionName)
		Logger.debug "*****version ID - first time: " + versionId
/*		Logger.debug "Getting version ID from dashboard versions - second time"
		versionId = sscApi.getVersionId("FZM", "MSR01617")
		Logger.debug " version ID - second time: " + versionId
		Logger.debug "Getting version ID from dashboard versions - with reset"
		versionId = sscApi.getVersionId("FZM", "MSR01617", true)
		Logger.debug " version ID - with reset: " + versionId
*/
		Logger.debug "*****Loading artifacts - first time"
		Map artifacts = sscApi.getArtifacts(versionId)
/*		Logger.debug "Loading artifacts - second time"
		artifacts = sscApi.getArtifacts(versionId)
		Logger.debug "Loading artifacts - with reset"
		artifacts = sscApi.getArtifacts(versionId,true)
*/
		Logger.debug "*****Loading issues - first time"
		Map issues = sscApi.getIssues(versionId)
/*		Logger.debug "Loading issues - second time"
		issues = sscApi.getIssues(versionId)
		Logger.debug "Loading issues - with reset"
		issues = sscApi.getIssues(versionId,true)
*/
		// read all the lines from PrimaryTags.txt file into a list, each line is an element in the list
//		def path = System.getProperty("user.dir")
//		Logger.debug "*****Primary Tags File path: ${path}"
		
		Logger.debug "*****Primary Tags Filename: ${PRIMARY_TAGS_FILENAME}"
//		File primaryTagsFile = new File(PRIMARY_TAGS_FILENAME)
		File primaryTagsFile = new File( this.getClassLoader().getResource(PRIMARY_TAGS_FILENAME).toURI() )
		List primaryTagsFileContents = primaryTagsFile.readLines()
		List primaryTagsList = []
		
//		Logger.debug "*****PrimarytTags used to stop deployment:"
		Logger.debug "*****PrimarytTags used NOT to stop deployment:"
		if ( primaryTagsFileContents != null ) {
			primaryTagsFileContents.each { String listItem ->
				if (!(listItem.contains("#")) && (listItem.size() != 0)) {
					Logger.debug "***** : ${listItem}"
					primaryTagsList.add(listItem)
				}
			}
			
			int totalIssues = 0
			Logger.debug "*****Total issues: ${issues.count}"
			
			issues.data.each { Map issueData ->
//				if ((!(issueData.primaryTag)) || (issueData.primaryTag == PRE_EXISTING_ISSUE_PRIMARY_TAG)) {
//				if ((!(issueData.primaryTag)) || (primaryTagsList.contains(issueData.primaryTag))) {
//					totalIssues++
//				}
				if (!(primaryTagsList.contains(issueData.primaryTag))) {
					Logger.debug "*****issueName: '${issueData.issueName}', issueStatus: '${issueData.issueStatus}', Analysis (Primary Tag): '${issueData.primaryTag}', '<==DEPLOY BREAKER'"
					totalIssues++
				} else {
					Logger.debug "issueName: '${issueData.issueName}', issueStatus: '${issueData.issueStatus}', Analysis (Primary Tag): '${issueData.primaryTag}'"
				}
			}
			Logger.debug "*****Total issues with concerns: ${totalIssues}"
			
			if (totalIssues == 0) {
				Logger.debug "*****No issues found for SSC Server Application/Project named '${sscApplicationName}' and version '${sscVersionName}'"
			
	//			throw new AbortPluginException("Unable to find version for SSC Server Application/Project named '${projectName}'")
	//				throw new AbortPluginException("No issues found for SSC Server Application/Project named '${sscApplicationName}' and version '${sscVersionName}'")
			} else {
				
			}
	
        } else {
            Logger.debug "*****Something wrong with primary tags file: ${PRIMARY_TAGS_FILENAME}. No primary tags found in the file."
        }

	}

}
