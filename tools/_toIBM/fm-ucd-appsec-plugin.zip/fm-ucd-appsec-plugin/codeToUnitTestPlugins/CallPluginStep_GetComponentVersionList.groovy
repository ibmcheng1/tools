import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger

import plugin.GetComponentVersionList

class CallPluginStep_GetComponentVersionList {

	static main(String[] args) {
		if (args.size() < 3) {
			displayHelp()
		} else {
			String ucdServerUrl = args[0]
			String token = args[1]
			String applicationProcessRequestId = args[2]
			
			UcdServerConnection ucdServer = new UcdServerConnection()
			ucdServer.openConnection(ucdServerUrl, token )
			UcdConnectionServices ucdConnectionServices = new UcdConnectionServices(ucdServer)
			
			Properties outProps = new Properties()
			
//			Logger.setLoggingLevel "debug"

			(new GetComponentVersionList()).generateList(ucdConnectionServices, outProps, applicationProcessRequestId)
				
			println "** OUTPUT PROPERTIES **"
			outProps.each { String name, def value ->
				println "${name}: ${value}"
			}
		}
	}
	
	public static void displayHelp() {
		println "Syntax: CallPluginStep_GetComponentVersionList ucdServedUrl ucdToken applicationProcessRequestId"
	}

}
