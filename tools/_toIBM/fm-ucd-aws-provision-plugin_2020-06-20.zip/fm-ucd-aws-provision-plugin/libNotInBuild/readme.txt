This folder (libNotInBuild) contains library JARs that are needed to edit this project in
an IDE (IntelliJ/Eclipse).  But they do NOT need to be included in the plugin jar because
they are part of the Groovy runtime libraries.