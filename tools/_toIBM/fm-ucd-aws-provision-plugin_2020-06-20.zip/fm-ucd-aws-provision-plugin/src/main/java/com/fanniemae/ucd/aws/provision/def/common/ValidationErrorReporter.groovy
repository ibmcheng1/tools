package com.fanniemae.ucd.aws.provision.def.common

interface ValidationErrorReporter {
	/**
	 * Adds a new validation error to the list of errors.  This is public, but
	 * should only be called by the specification definition classes.
	 */
	public void tagValidationError( String errorMsg )
}
