package com.fanniemae.ucd.aws.api

import com.fanniemae.aws.api.connection.AwsConnection

/**
 * Common base class for AWS API wrapper classes.
 * @author s9ulcc
 *
 */
class AwsBaseApiWrapper {
	/**
	 * The connection handle to AWS.
	 */
	public AwsConnection awsConnection
	
	/**
	 * Constructor.
	 * @param awsConnection Connection to AWS.
	 */
	public AwsBaseApiWrapper( AwsConnection awsConnection ) {
		this.awsConnection = awsConnection
	}

}
