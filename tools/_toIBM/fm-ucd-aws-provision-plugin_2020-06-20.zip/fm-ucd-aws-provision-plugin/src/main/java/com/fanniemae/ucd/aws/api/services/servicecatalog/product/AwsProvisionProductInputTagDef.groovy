package com.fanniemae.ucd.aws.api.services.servicecatalog.product;

import java.util.List

/**
 * Defines one defined TagOptions for provisioning products.
 * @author s9ulcc
 *
 */
public class AwsProvisionProductInputTagDef {
	// The product version
	protected AwsProductVersion _awsProductVersion
	
	protected String _name
	
	protected List<String> _valueList
	
	/**
	 * Constructor.
	 * @param awsProductVersion The Product Version that this is a Tag Def for.
	 * @param name The name of the tag
	 * @param valueList The list of potential values.
	 */
	public AwsProvisionProductInputTagDef( AwsProductVersion awsProductVersion, String name, List<String> valueList ) {
		_awsProductVersion = awsProductVersion
		_name = name
		_valueList = valueList
	}
	
	/**
	 * Returns the name of this Tag
	 */
	public String getName() {
		return _name
	}
	
	/**
	 * Returns the List (of type String) of allowed values.  If there are less than two values, then
	 * it is a fixed value and doesn't need to be set when provisioning.
	 */
	public List<String> getValueList() {
		return _valueList
	}
}
