package com.fanniemae.ucd.aws.api.services.servicecatalog;

import com.fanniemae.aws.api.connection.AwsConnection;
import com.fanniemae.ucd.aws.api.AwsBaseApiWrapper
import com.fanniemae.ucd.aws.api.describeRecord.AwsDescribeRecordResult
import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProduct
import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel

import groovy.json.JsonSlurper

public class AwsServiceCatalog extends AwsBaseApiWrapper {
	
	/**
	 * Cached list of AwsProducts.
	 */
	protected List<AwsProduct> _awsProducts = null

	/**
	 * Constructor.
	 * @param awsConnection Connection to AWS.
	 */
	public AwsServiceCatalog( AwsConnection awsConnection ) {
		super( awsConnection )
	}
	
	/**
	 * Is there a Provisioned Product with the given name that this
	 * account role can see?
	 * This function doesn't throw an exception.
	 * @param name The name to search for.
	 */
	public boolean doesNamedProvisionedProductExist( String name ) {
		boolean retval = false
		try {
			List productInstances = getProvisionedProducts()
			Map matchingEntry = productInstances.find { Map entry ->
				return (entry.Name == name)
			}
			if (matchingEntry) {
				retval = true
			}
		}
		catch (Exception e) {
			// only display exception if debug logging
			Logger.debug "Unable to load AWS Product Instances - " + e.getMessage()
			Logger.printStackTrace(LoggerLevel.DEBUG, e)
		}
		return retval
	}
	
	/**
	 * Returns the list of AWS Provisioned Products for the account role.
	 * Throws exception on failure.
	 * @return Returns a List of Map entries as per the underlying call to
	 * 'aws servicecatalog scan-provisioned-products'.  At a minimum,
	 * each list entry contains a 'Name' and 'Id' field for the provisioned
	 * product.
	 */
	public List getProvisionedProducts() {
		CommandRunner commandRunner = awsConnection.executeAwsCliCommand("""aws servicecatalog scan-provisioned-products --access-level-filter Key=Role,Value=self --no-paginate --region ${p:awsConnection.getRegion()}""")
		if (! commandRunner.wasSuccessful()) {
			throw new Exception( "AWS API call to get list of Provisioned Products via 'scan-provisioned-products' failed" )
		}
		Map results = (new JsonSlurper()).parseText( commandRunner.getConsoleOutput() )
		return results.ProvisionedProducts
	}
	
	/**
	 * Starts the termination of a provision AWS Product via an
	 * 'aws servicecatalog terminate-provisioned-product'.  This function
	 * returns before the termination is complete (pass or fail).  Throws exception on failure.
	 * @param provisionedProductName The provisioned Product/resource to terminate.
	 * @return REturns the RecordId which can be used to track the termination progress.
	 */
	public String terminateProvisionedProduct( String provisionedProductName ) {
		CommandRunner commandRunner = awsConnection.executeAwsCliCommand("""aws servicecatalog terminate-provisioned-product --provisioned-product-name '${p:provisionedProductName}' --region ${p:awsConnection.getRegion()}""")
		if (! commandRunner.wasSuccessful()) {
			throw new Exception( "Unable retrieve AWS Artifact ID for Product ID: ${provisionedProductName}" )
		}
		Map results = (new JsonSlurper()).parseText( commandRunner.getConsoleOutput() )
		return results.RecordDetail.RecordId
	}
	
	/**
	 * Returns the 'describe-record' data for an AWS Product/Resource instance. Throws exception on failure.
	 * @param recordId The ID of the record.
	 * @param displayRecord If true, then display the record contents via Logger.info
	 * @return A class wrapper for the results.
	 */
	public AwsDescribeRecordResult describeRecord( String recordId, boolean displayRecord = false ) {
		CommandRunner commandRunner = awsConnection.executeAwsCliCommand("aws servicecatalog describe-record --id ${recordId} --region ${awsConnection.getRegion()}")
		if (! commandRunner.wasSuccessful()) {
			throw new Exception( "API call to get AWS Service Instance Record (servicecatalog describe-record) for record id ${recordId} failed")
		}
		return new AwsDescribeRecordResult( commandRunner.getConsoleOutput(), displayRecord )
	}
	
	/**
	 * An AWS catalog Product can have multiple version.  Basically, this function
	 * finds the newest (based on creation date) version of the Product and returns the
	 * corresponding Provisioning Artifact ID.  Throws exception on failure.
	 * @param productId AWS Product id from the catalog
	 * @return The Provisioning Artifact ID for the newest version of the Product.
	 */
	public String getNewestProductProvisioningArtifactId( String productId ) {
		CommandRunner commandRunner = awsConnection.executeAwsCliCommand("aws servicecatalog describe-product --id ${productId} --region ${awsConnection.getRegion()}")
		if (! commandRunner.wasSuccessful()) {
			throw new Exception( "AWS servicecatalog call failed")
		}
		Map productInfo = (new JsonSlurper()).parseText( commandRunner.getConsoleOutput() )
		def createdTime = 0
		String artifactId = null
		String artifactName
		productInfo.ProvisioningArtifacts.each { Map artifactInfo ->
			if (artifactInfo.CreatedTime > createdTime) {
				createdTime = artifactInfo.CreatedTime
				artifactId = artifactInfo.Id
				artifactName = artifactInfo.Name
			}
		}
		return artifactId
	}
	
	/**
	 * Returns the list of AwsProduct's.  The first time that this is called, then list is loaded.
	 * Throws exception on failure.
	 */
	public List<AwsProduct> getAwsProducts() {
		if (_awsProducts == null) {
			_awsProducts = []
			CommandRunner commandRunner = awsConnection.executeAwsCliCommand("aws servicecatalog search-products --no-paginate")
			if (! commandRunner.wasSuccessful()) {
				throw new Exception( "AWS servicecatalog call failed")
			}
			Map searchResults = (new JsonSlurper()).parseText( commandRunner.getConsoleOutput() )
			searchResults.ProductViewSummaries.each { Map entry ->
				if (! entry.Name.toLowerCase().contains('lambda')) {
					_awsProducts << new AwsProduct(this, entry)
				}
			}
		}
		return _awsProducts
	}

	
	/**
	 * Is there a product with the given name in this Service Catalog?
	 * @param name The name (case sensitive)
	 */
	public boolean hasProductByName( String name ) {
		// get products by calling function and not accessing variable.  The function does cache management. 
		List<AwsProduct> products = getAwsProducts()
		AwsProduct locatedProduct = products.find { AwsProduct entry ->
			return (entry.getName() == name)
		}
		return (locatedProduct != null)
	}
	
	/**
	 * Returns the AwsProduct with the given name.  Throws exception if not found.
	 * @param name The named product to look for.
	 */
	public AwsProduct getProductByName( String name ) {
		// get products by calling function and not accessing variable.  The function does cache management. 
		List<AwsProduct> products = getAwsProducts()
		AwsProduct locatedProduct = products.find { AwsProduct entry ->
			return (entry.getName() == name)
		}
		if (locatedProduct) {
			return locatedProduct
		} else {
			throw new Exception( "Unable to find a product in the current AWS Service Catalog with the name '${name}'")
		}
	}
}
