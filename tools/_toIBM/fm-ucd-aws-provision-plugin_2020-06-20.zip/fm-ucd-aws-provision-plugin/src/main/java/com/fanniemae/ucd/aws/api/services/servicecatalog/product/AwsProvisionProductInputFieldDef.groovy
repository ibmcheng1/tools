package com.fanniemae.ucd.aws.api.services.servicecatalog.product

/**
 * Defines one input field definition for provisioning a product version instance.
 * @author s9ulcc
 *
 */
class AwsProvisionProductInputFieldDef {
	// The product version
	protected AwsProductVersion _awsProductVersion
	
	/**
	 * The field's name, which AWS calls the 'ParameterKey'
	 */
	protected String _name
	
	/**
	 * Default value.  Set to null or empty string if there is no default value.
	 */
	protected String _defaultValue
	
	/**
	 * The description of the field.  
	 */
	protected String _description
	
	/**
	 * An optional custom label.  We load this from the fields label.
	 */
	protected String _customLabel
	
	/**
	 * If not null or empty list, then this is the list of acceptable values.
	 */
	protected List<String> _valueList
	
	/**
	 * Constructor.
	 * @param awsProductVersion The AwsProductVersion that this is an input field for.
	 * @param name The name of the field.  This must be provided.  AWS calls this the ParameterKey
	 * @param defaultValue Optional default value.  May be null or empty string.
	 * @param description Optional description.  May be null or empty string.
	 * @param valueList An optional list of acceptable content values.  Use null or empty list if there is not list.
	 */
	public AwsProvisionProductInputFieldDef( AwsProductVersion awsProductVersion, String name, String defaultValue, String description, String customLabel, List<String> valueList ) {
		_awsProductVersion = awsProductVersion
		_name = name
		if (defaultValue) {
			_defaultValue = defaultValue
		} else {
			_defaultValue = ""
		}
		if (description) {
			_description = description
		} else {
			_description = ""
		}
		if (customLabel) {
			_customLabel = customLabel
		} else {
			_customLabel = ""
		}
		_valueList = valueList
	}
	
	/**
	 * Returns the AwsProductVersion that this field is for.
	 */
	public AwsProductVersion getAwsProductVersion() {
		return _awsProductVersion
	}

	/**
	 * Returns the name, which AWS calls the 'ParameterKey'
	 */
	public String getName() {
		return _name
	}
	
	/**
	 * Returns the default value or an empty string.
	 */
	public String getDefaultValue() {
		return _defaultValue
	}
	
	/**
	 * Returns the description or an empty string.
	 */
	public String getDescription() {
		return _description
	}	
	
	/**
	 * Returns the custom label or an empty string.
	 */
	public String getCustomLabel() {
		return _customLabel
	}

	/**
	 * If there is a list of allowed values, this returns that list; otherwise, this returns null.
	 */
	public List<String> getValueList() {
		if (_valueList && _valueList.size()>0) {
			return _valueList
		} else {
			return null
		}
	}
}
