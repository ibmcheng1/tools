package com.fanniemae.provision.ucd

import com.fanniemae.common.string.SimpleEncryption
import com.fanniemae.provision.ucd.persistence.PersistentAwsProductInstanceData
import com.fanniemae.provision.ucd.persistence.PersistentProvisionData
import com.fanniemae.ucd.aws.api.services.servicecatalog.AwsServiceCatalog
import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProductInstance
import com.fanniemae.ucd.aws.provision.context.BaseEnvironmentProvisionContext
import com.fanniemae.ucd.aws.provision.context.ProvisionContext
import com.fanniemae.ucd.aws.provision.context.data.AwsProductInstancePlaceholder
import com.fanniemae.ucd.aws.provision.def.components.UcdTemplateDefinition
import com.fanniemae.ucd.aws.provision.def.components.data.UcdComponentDef
import com.fanniemae.ucd.aws.provision.service.instance.AwsServiceInstance
import com.ibm.css.ucd.agent.AgentOrAgentPool
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.environmenttemplate.EnvironmentTemplate
import com.ibm.css.ucd.resource.AgentOrAgentPoolResourceNode
import com.ibm.css.ucd.resource.ComponentResourceNode
import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.css.ucd.resource.ResourceTree
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.css.ucd.team.Team
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.plugin.AbortPluginException

import groovy.json.JsonOutput

/**
 * This class manages the provisioning and deprovisioning of a UCD Environment(s).  It has the following general capabilities.
 * <ul>
 * <li>Supports blue-green or non-blue-green environments.  In the first case, two
 * environments are provisioned.  In the latter case, only a single environment is
 * provisioned.</li>
 * <li>UCD Components can be flagged as supporting blue-green or not.  If a component
 * doesn't support blue-green, but blue-green is on, then it is put into a shared
 * Base Resource.</li>
 * <li>Parts of the environment(s) may already exist.</li>
 * <li>If a Component exists in an environment, its properties are updated.  For new
 * Components, its properties are created.</li> 
 * <li>Incompletely provisioned environments have a suffix of ' (??)'.  The text
 * inside of the parens may evolve.</li>
 * <li>Provisioning is based on the UCD Provisioning template information.</li>
 * </ul>
 * @author s9ulcc
 *
 */
class UcdEnvironmentProvisionMgr {
	
	private static final String AWSPROVISIONDATA_FIELDNAME = 'awsProvisionData'
	private static final String BLUEGREEN_FIELDNAME = 'pairedBlueGreenEnvironment'
	
	protected UcdConnectionServices _ucdConnectionServices
	protected Application _application
	protected String _specifiedEnvName
	
	//
	// DATA FOR SCANNING FOR EXISTING ENVIRONMENTS
	//
	
	// Has there been a scan for existing environment(s).  Only needs to happen once.
	// Call doesEnvironmentAlreadyExist() to force initial scan.
	private boolean _hasScannedForExistingEnvironment = false
	
	protected PersistentProvisionData _existingProvisionData = null
	
	//
	// METHODS
	//

	/**
	 * Constructor
	 * @param ucdConnectionServices Connection to UCD Server
	 * @param application The UCD Application
	 * @param specifiedEnvName The user specified environment name, which is used as the basis for findingin/determining
	 * actual environment name(s).
	 */
	public UcdEnvironmentProvisionMgr( UcdConnectionServices ucdConnectionServices, Application application, String specifiedEnvName ) {
		_ucdConnectionServices = ucdConnectionServices
		_application = application
		_specifiedEnvName = specifiedEnvName
	}
	
	/**
	 * Returns persistent provisioning data for existing environment(s).  This
	 * should only be called if doesEnvironmentAlreadyExist() returns true; otherwise
	 * this function will return null.
	 */
	public PersistentProvisionData getExistingProvisionData() {
		if (doesEnvironmentAlreadyExist()) {
			return _existingProvisionData
		} else {
			return null
		}
	}
	
	/**
	 * Did an environment(s) exist when this plugin step started.  It may be a single (non-blue/green) environment
	 * or a paired (blue/green) environment - even if only blue or green exist.
	 */
	public boolean doesEnvironmentAlreadyExist() {
		if (! _hasScannedForExistingEnvironment) {
			// CHECK NOW
			PersistentProvisionData persistentMetadata
			
			// First, check to see if there is an environment with the requested name
			if (_application.doesEnvironmentExist(_specifiedEnvName)) {
				_existingProvisionData = new PersistentProvisionData(_application.getEnvironment(_specifiedEnvName))
			} else {
				// scan environments looking for matches
				List<Environment> environments = _application.getEnvironments()
				// Look for '{name} (...'
				Environment matchingEnv = environments.find { Environment environment ->
					return environment.name.startsWith(_specifiedEnvName + " (")
				}
				if (! matchingEnv) {
					// Look for blue/green, which is '{name}-...'.  Side effect - if found 'persistentMetadata' variable is set
					matchingEnv = environments.find { Environment environment ->
						return (environment.name.startsWith(_specifiedEnvName + '-'))
					}
				}
				if (matchingEnv) {
					_existingProvisionData = new PersistentProvisionData(matchingEnv)
				}
			}
			
			_hasScannedForExistingEnvironment = true
		}
		
		return (_existingProvisionData != null)
	}
	
	/**
	 * If this provisioning execution is using an existing environment(s), then the
	 * context's are updated to refer to the existing environments.
	 */
	public void addExistingEnvironmentToContext( BaseEnvironmentProvisionContext baseContext ) {
		if (doesEnvironmentAlreadyExist()) {
			SummaryReport summaryReport = SummaryReport.getInstance()
			if (baseContext.isProvisioningBlueGreen()) {
				// blue green
				baseContext.getBlueChildContext().environment = _existingProvisionData.getBlueEnvironment()
				summaryReport.addExistingUcdEnvironment(_existingProvisionData.getBlueEnvironment())
				baseContext.getGreenChildContext().environment = _existingProvisionData.getGreenEnvironment()
				summaryReport.addExistingUcdEnvironment(_existingProvisionData.getGreenEnvironment())
			} else {
				// stand alone
				baseContext.environment = _existingProvisionData.getStandAloneEnvironment()
				summaryReport.addExistingUcdEnvironment(_existingProvisionData.getStandAloneEnvironment())
				
			}
		}
	}
	
	/**
	 * If their are existing AWS Product Instances defined by the existing Environment(s)'s persistent
	 * data, then add the product instance information to the appropriate base/blue/green context.
	 * @param baseContext The base context.
	 * @param awsServiceCatalog Handle to the user authenticated AWS Service Catalog.
	 */
	public void addExistingAwsProductInstancesToContext( BaseEnvironmentProvisionContext baseContext, AwsServiceCatalog awsServiceCatalog ) {
		if (doesEnvironmentAlreadyExist()) {
			if (baseContext.isProvisioningBlueGreen()) {
				getExistingProvisionData().getSharedAwsProductInstances().each { PersistentAwsProductInstanceData instance ->
					baseContext.addExistingAwsProductInstanceToContext( instance.name, new AwsProductInstance(awsServiceCatalog, instance.provisionedProductId), instance.provisioned, false )
				}
				getExistingProvisionData().getBlueAwsProductInstances().each { PersistentAwsProductInstanceData instance ->
					baseContext.getBlueChildContext().addExistingAwsProductInstanceToContext( instance.name, new AwsProductInstance(awsServiceCatalog, instance.provisionedProductId), instance.provisioned, false )
				}
				getExistingProvisionData().getGreenAwsProductInstances().each { PersistentAwsProductInstanceData instance ->
					baseContext.getGreenChildContext().addExistingAwsProductInstanceToContext( instance.name, new AwsProductInstance(awsServiceCatalog, instance.provisionedProductId), instance.provisioned, false )
				}
			} else {
				// Stand-alone environment
				getExistingProvisionData().getStandAloneAwsProductInstances().each { PersistentAwsProductInstanceData instance ->
					baseContext.addExistingAwsProductInstanceToContext( instance.name, new AwsProductInstance(awsServiceCatalog, instance.provisionedProductId), instance.provisioned, false )
				}
			}
		}

	}

	/**
	 * Creates/updates the UCD Environment infrastructure according to the template and context.
	 * @param baseContext The base context
	 * @param ucdTemplateDefinition The loaded UCD Template.
	 * @param requestedEnvType The requested environment type which is used to create new UCD Environment(s).
	 */
	public void createTargetUcdStructure( BaseEnvironmentProvisionContext baseContext, UcdTemplateDefinition ucdTemplateDefinition, String requestedEnvType ) {
		
		// Get the application teams (which are replicated)
		List<Team> applicationTeams = _application.getUniqueTeams()
		
		ResourceTree resourceTree = _ucdConnectionServices.getResourceServices().getResourceTree()
		
		
		// -------------------------------------------------------
		// Create/find Environments and Base Resource(s)
		// -------------------------------------------------------
		
		EnvironmentTemplate environmentTemplate = _application.getApplicationTemplate().getEnvironmentTemplate(requestedEnvType)

		if (baseContext.isProvisioningBlueGreen()) {
			// Setup/Update Blue/Green Environments
			ProvisionContext blueContext = baseContext.getBlueChildContext()
			ProvisionContext greenContext = baseContext.getGreenChildContext()
			
			// create the environments if they are defined in the context(s) yet
			if (! blueContext.environment) {
				// create the blue environment
				createEnvironment( blueContext, environmentTemplate, applicationTeams )
			}			
			if (! greenContext.environment) {
				// create the blue environment
				createEnvironment( greenContext, environmentTemplate, applicationTeams )
			}
			findExistingOrCreateNewBlueGreenBaseResources( resourceTree, blueContext, greenContext )
		} else {
			// Setup/Update stand-alone Environment
			// create the environment if it isn't are defined in the context(s) yet
			if (! baseContext.environment) {
				// The stand-alone environment doesn't exist yet, so create it.  This sets 'environment' and 'resourceBranch'
				createEnvironment( baseContext, environmentTemplate, applicationTeams )
			} else {
				// The stand-alone environment already exists.  Get the baseResource 'resourceBranch'
				findExistingOrCreateNewStandAloneBaseResource( resourceTree, baseContext )
			}
		}
		
		
		// -------------------------------------------------------
		// Create/find/set Template Defined Components
		// -------------------------------------------------------

		ucdTemplateDefinition.getAllComponentDefs().each { UcdComponentDef componentDef ->
			if (baseContext.isProvisioningBlueGreen()){
				// Provisioning Blue/Green
				if (componentDef.participateInBlueGreen) {
					configureEnvironmentComponent( componentDef, baseContext.getBlueChildContext().resourceBranch, [baseContext.getBlueChildContext()] )
					configureEnvironmentComponent( componentDef, baseContext.getGreenChildContext().resourceBranch, [baseContext.getGreenChildContext()] )
				} else {
					configureEnvironmentComponent( componentDef, baseContext.resourceBranch, [baseContext.getGreenChildContext(),baseContext.getBlueChildContext()] )
				}
			} else {
				// Provisioning standAlone
				configureEnvironmentComponent( componentDef, baseContext.resourceBranch, [baseContext] )
			}
		}
	}

	
	/**
	 * Saves data back to the environments, components, etc.
	 * @param baseContext The base context
	 */
	public void saveDataToEnvironments( BaseEnvironmentProvisionContext baseContext ) {
		// save persistent data
		baseContext.iterateContextsWithEnvironments { ProvisionContext context ->
			// write the describe-record data
			context.getInheritedAwsProductInstancePlaceholder().each { AwsProductInstancePlaceholder awsInstanceData ->
				if (awsInstanceData.awsServiceInstance) {
					AwsServiceInstance serviceInstance = awsInstanceData.awsServiceInstance
					if (serviceInstance && serviceInstance.isAvailable()) {
						context.environment.setProperty( 'aws.describe-record.'+serviceInstance.getProvisionedName(), JsonOutput.toJson(serviceInstance.getAwsInstanceData().getRawResults()), false )
					}
				}
			}
			
			// Several data fields are saved to Environment Properties
			//	awsResources
			// 		As a convenience to the user a fairly simple AWS Product Instance inventory is written to the 'awsResources' field.  This is never
			// 		read or used by the plugin.
			// 		It is a list of AWS Product Instances for the environment.  Each member is a map with the following fields: name = logical template name,
			// 		provisionedProductName, provisionedProductId, boolean provisioned - set to true if provisioned by this plugin versus predefined.
			// 		Builds as string 'awsResourceList'
			//	awsProvisionData
			//		This persistent data IS used by the plugin when working with existing "provisioned" environment(s)
			//		This structure is documented with the PersistentProvisionData class constructor.
			
			// write 'awsProvisionData' structure to environment property
			Map awsProvisionData = [awsResources:[]]
			List awsResourceList = []
			String awsAccountId = baseContext.getAwsAccountId()
			String awsRole = baseContext.getAwsRole()
			if (awsAccountId && awsRole) {
				awsProvisionData.awsAuthentication = [ accountId: awsAccountId, role: awsRole ]
			}
			awsProvisionData.baseEnvironmentName = baseContext.baseEnvironmentName
			awsProvisionData.isBlueGreen = baseContext.isProvisioningBlueGreen()
			Closure addEntryToAwsResources = { AwsProductInstancePlaceholder awsInstanceData, boolean shared ->
				if (awsInstanceData.awsServiceInstance) {
					AwsServiceInstance serviceInstance = awsInstanceData.awsServiceInstance
					if (serviceInstance && serviceInstance.isAvailable()) {
						awsProvisionData.awsResources << [name: awsInstanceData.getName(),
							provisionedProductName: serviceInstance.getProvisionedName(),
							provisionedProductId: serviceInstance.getProvisionedId(),
							provisioned:serviceInstance.isProvisionedByPlugin(),
							shared:shared
							]
						awsResourceList << [name: awsInstanceData.getName(),
							provisionedProductName: serviceInstance.getProvisionedName(),
							provisionedProductId: serviceInstance.getProvisionedId(),
							provisioned:serviceInstance.isProvisionedByPlugin()
							]
					}
				}
			}
			context.getContextSpecificAwsProductInstancePlaceholders().each { AwsProductInstancePlaceholder awsInstanceData ->
				addEntryToAwsResources( awsInstanceData, false )
			}
			if (context.hasParentContext()) {
				context.getParentContext().getContextSpecificAwsProductInstancePlaceholders().each { AwsProductInstancePlaceholder awsInstanceData ->
					addEntryToAwsResources( awsInstanceData, true )
				}
			}
			Closure convertEnvironmentToMap = { Environment environment ->
				// Convert the Environment class to a Map with 'name' and 'id' and return that
				return [ name: environment.name, id: environment.id ]
			}
			if (baseContext.isProvisioningBlueGreen()) {
				awsProvisionData.blueEnvironment = convertEnvironmentToMap( baseContext.getBlueChildContext().environment )
				awsProvisionData.greenEnvironment = convertEnvironmentToMap( baseContext.getGreenChildContext().environment )
			} else {
				awsProvisionData.standAloneEnvironment = convertEnvironmentToMap( baseContext.environment )
			}
			context.environment.setProperty( 'awsProvisionData', SimpleEncryption.obfuscateString( JsonOutput.toJson(awsProvisionData) ), false )
			context.environment.setProperty( 'awsResources', JsonOutput.prettyPrint(JsonOutput.toJson(awsResourceList)), false )
			
			// Append exeuction summary information
			String summaryInformation = ''
			String summaryPropName = 'AWS Provision Summary'
			if (context.environment.hasAdHocProperty(summaryPropName)) {
				summaryInformation = context.environment.getAdHocProperty(summaryPropName) + '\n'
			}
			summaryInformation = summaryInformation + SummaryReport.getInstance().getSummary() 
			context.environment.setAdHocProperty(summaryPropName, summaryInformation, false )
		}
//		// TODO - For now, save 'paired...' context variable until Deprovisioning updated to use new persistent data
//		if (baseContext.isProvisioningBlueGreen()) {
//			ProvisionContext blueContext = baseContext.getBlueChildContext()
//			ProvisionContext greenContext = baseContext.getGreenChildContext()
//			greenContext.environment.setProperty('pairedBlueGreenEnvironment', blueContext.environmentName, false)
//			blueContext.environment.setProperty('pairedBlueGreenEnvironment', greenContext.environmentName, false)
//		}
	}
	
	
	/**
	 * <p>Configures a template defined component in a Base Resource Node for one or more environments.  For example,
	 * configure a component in a Shared base Resource Node for both a blue and green environment.  Specifically, this ...</p>
	 * <ul>
	 * <li>Finds appropriate Agent Resource Node within the Base Resource Node, creating it if not found.</li>
	 * <li>Find or creates the Component Resource Node within the Agent Resource Node.</li>
	 * <li>If the Component Resource Node was created - apply all of the template defined component environment properties</li>
	 * <li>If the Component Resource Node already existed, iterate existing component environment properties.  Apply token resolver
	 * to the property value.  IF (and only if) the value is different, update the property with the new value.</li>
	 * </ul>
	 * @param componentDef The template define component.
	 * @param environmentBaseResourceNode The UCD Base Resource Node.
	 * @param environmentContexts A list of one or more Provision Contexts.  Each one must have a UCD environment.  This is the context
	 * for resolving tokens AND the component environment properties are set for the corresponding environment.
	 */
	private void configureEnvironmentComponent( UcdComponentDef componentDef, ResourceNode environmentBaseResourceNode, List<ProvisionContext> environmentContexts ) {
		AgentOrAgentPool agentOrPool = componentDef.ucdAgent
		AgentOrAgentPoolResourceNode agentResourceNode = environmentBaseResourceNode.getOrCreateChildAgentPoolNode(agentOrPool.name, agentOrPool)
		// find or create child component node
		boolean componentResourceNodeExisted = agentResourceNode.doesChildNodeExist(componentDef.resourceName)
		Component component = _ucdConnectionServices.getComponentServices().getComponent(componentDef.componentName)
		ComponentResourceNode componentResourceNode = agentResourceNode.getOrCreateChildComponentNode(componentDef.resourceName, component)
		
		// Set or update the Component Environment Properties
		environmentContexts.each { ProvisionContext context ->
			if (componentResourceNodeExisted) {
				// Update the properties
				
				component.getComponentEnvironmentProperties(context.environment).each { Map property ->
					String oldValue = property.value
					String newValue = context.processTokens(property.value, component.getName())
					if (newValue != oldValue) {
						setComponentEnvironmentProperty( component, context.environment, property.name, newValue )
					}
				}
				
			} else {
				// Create the properties
			
				componentDef.componentEnvironmentProperties.each { String propertyName, String propertyValue ->
					propertyValue = context.processTokens(propertyValue, component.getName())
					setComponentEnvironmentProperty( component, context.environment, propertyName, propertyValue )
				}
				
			}
		}
	}
	
	/**
	 * Sets one Component Environment property.  Displays error if there is a problem, but does NOT throw an exception.
	 * @param component The component.
	 * @param context The environment.
	 * @param propertyName The name of the property.
	 * @param propertyValue The value of the property.
	 */
	private void setComponentEnvironmentProperty( Component component, Environment environment, String propertyName, String propertyValue) {
		// If there is ANY problem setting a component environment property, log a message, but ignore the
		// problem.  We don't want to fail provisioning because of this.
		try {
			component.setComponentEnvironmentProperty(environment, propertyName, propertyValue)
		}
		catch (Exception e) {
			String errormsg = ''
			if (e instanceof AbortPluginException) {
				errormsg = ((AbortPluginException) e).getNestedMsg()
			} else {
				errormsg = e.message
			}
			Logger.error "Unable to set '${environment.getName()}' environment component property named '${propertyName}' for component '${component.name}' to '${propertyValue}' - " + errormsg
		}
	}
	
	
	/**
	 * Find existing or create new base resources for the blue and green contexts - including the shared base resource.
	 * This updates the appopriate 'resourceBranch' fields in the contexts.
	 * @param resourceTree
	 * @param blueContext
	 * @param greenContext
	 */
	private void findExistingOrCreateNewBlueGreenBaseResources( ResourceTree resourceTree, ProvisionContext blueContext,
		ProvisionContext greenContext ) {
		List<ResourceNode> blueResources = blueContext.environment.getBaseResources()
		List<ResourceNode> greenResources = greenContext.environment.getBaseResources()
		// Iterate blue resources and decide if each one is blue specific or shared
		blueResources.each { ResourceNode resourceNode ->
			ResourceNode findNode = greenResources.find { ResourceNode candidateNode ->
				return (resourceNode.getResourcePath() == candidateNode.getResourcePath())
			}
			if (findNode) {
				// This node is in blue and green, so it is shared
				blueContext.parentContext.resourceBranch = resourceNode
				blueContext.parentContext.resourceBranchName = resourceNode.name
			} else {
				// This is a blue/green specific base resource
				blueContext.resourceBranch = resourceNode
				blueContext.resourceBranchName = resourceNode.name
			}
		}
		// Iterate green resources to find green specific ones
		greenResources.each { ResourceNode resourceNode ->
			ResourceNode findNode = blueResources.find { ResourceNode candidateNode ->
				return (resourceNode.getResourcePath() == candidateNode.getResourcePath())
			}
			if (findNode) {
				// This node is in blue and green, so it is shared
				// already processed, so do nothing
			} else {
				// This is a blue/green specific base resource
				greenContext.resourceBranch = resourceNode
				greenContext.resourceBranchName = resourceNode.name
			}
		}
		// Create any missing base resources
		ResourceNode applicationResourceNode = resourceTree.getChildNode(_application.name)
		if (! blueContext.resourceBranch) {
			blueContext.resourceBranch = applicationResourceNode.getOrCreateChildGroupNode(blueContext.resourceBranchName)
			blueContext.environment.addBaseResource(blueContext.resourceBranch)
		} 
		if (! greenContext.resourceBranch) {
			greenContext.resourceBranch = applicationResourceNode.getOrCreateChildGroupNode(greenContext.resourceBranchName)
			greenContext.environment.addBaseResource(greenContext.resourceBranch)
		}
		if (! blueContext.parentContext.resourceBranch) {
			blueContext.parentContext.resourceBranch = applicationResourceNode.getOrCreateChildGroupNode(blueContext.parentContext.resourceBranchName)
			blueContext.environment.addBaseResource(blueContext.parentContext.resourceBranch )
			greenContext.environment.addBaseResource(blueContext.parentContext.resourceBranch )
		}
	}
	
	
	/**
	 * Finds existing or create a new Base Resource for the stand-alone environment and sets 'baseContext.resourceBranch'
	 * to the value.
	 * @param baseContext The base context, which, for stand-alone environments, corresponds to the environment.
	 */
	private void findExistingOrCreateNewStandAloneBaseResource( ResourceTree resourceTree, BaseEnvironmentProvisionContext baseContext ) {
		List<ResourceNode> baseResources = baseContext.environment.getBaseResources()
		baseResources.each { ResourceNode resourceNode ->
			baseContext.resourceBranch = resourceNode
		}
		if (baseContext.resourceBranch == null) {
			ResourceNode applicationResourceNode = resourceTree.getChildNode(_application.name)
			baseContext.resourceBranch = applicationResourceNode.getOrCreateChildGroupNode(baseContext.getEnvironmentName())
			baseContext.resourceBranchName = baseContext.resourceBranch.name
			baseContext.environment.addBaseResource(baseContext.resourceBranch)
		}
	}

		
	/**
	 * Create a new environment for the context.  The new environment and base resource branch are saved back to the
	 * context as the fields context.environment and context.resourceBranch.
	 * @param context An environment context.  The name of the environment is retrieved from this.  The newly
	 * create Environment and Base Resource node are saved to this.
	 * @param environmentTemplate The environment template to use.
	 * @param applicationTeams The teams to link to the new environment.
	 */
	private void createEnvironment( ProvisionContext context, EnvironmentTemplate environmentTemplate, List<Team> applicationTeams ) {
		context.environment = _application.createEnvironmentFromTemplate(context.environmentName, environmentTemplate )
		SummaryReport.getInstance().addSuccessfulUcdEnvironmentCreation(context.environment)
		context.environment.removeLinksToAllTeams()
		applicationTeams.each { Team team ->
			context.environment.addLinkToTeam(team)
		}
		
		// Find and save the Environment's Resource tree node which was automatically created by the template
		List<ResourceNode> baseResources = context.environment.getBaseResources()
		baseResources.each { ResourceNode resourceNode ->
			context.resourceBranch = resourceNode
			setResourceNodeTeams( resourceNode, applicationTeams )
		}
	}
	
	/**
	 * Sets the teams for the resourceNode to the teams (and ONLY the teams).  This does NOT
	 * set any resource node types.
	 */
	private void setResourceNodeTeams( ResourceNode resourceNode, List<Team> teams ) {
		resourceNode.removeLinksToAllTeams()
		teams.each { Team team ->
			resourceNode.addLinkToTeam(team)
		}
	}
}
