package com.fanniemae.ucd.aws.api.services.servicecatalog.product

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.ucd.aws.api.services.servicecatalog.AwsServiceCatalog
import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.plugin.AbortPluginException

import groovy.json.JsonSlurper

/**
 * Represents one AWS Service Catalog Product
 * @author s9ulcc
 *
 */
class AwsProduct {
	/**
	 * The AWS Service Catalog
	 */
	protected AwsServiceCatalog _awsServiceCatalog
	
	protected List<AwsProductVersion> _awsProductVersions
	
	protected List<AwsProductLaunchPath> _awsLaunchPaths
	
	/**
	 * <p>The AWS definition of the product.  This is the parsed definition from
	 * calling 'aws servicecatalog search-products'  This is a sample entry...<p>
	 * <pre>
	    {
            "Type": "CLOUD_FORMATION_TEMPLATE",
            "ShortDescription": "ecr-repo",
            "Id": "prodview-xtce5gd2mr4tk",
            "Owner": "EA",
            "Name": "ecr-repo",
            "ProductId": "prod-224u4iysbc4ky",
            "HasDefaultPath": false
        },

	 * </pre>
	 */
	public Map _awsDefinition
	
	/**
	 * Constructor.
	 * @param awsDefinition The AWS definition of the product.  See the description of the
	 * awsDefinition field in this class for more details.
	 */
	public AwsProduct( AwsServiceCatalog awsServiceCatalog, Map awsDefinition ) {
		this._awsServiceCatalog = awsServiceCatalog
		this._awsDefinition = awsDefinition
	}
	
	/**
	 * Returns the associated AwsServiceCatalog.
	 */
	public AwsServiceCatalog getAwsServiceCatalog() {
		return _awsServiceCatalog
	}
	
	/**
	 * <p>Returns the AWS definition of the product.  This is the parsed definition from
	 * calling 'aws servicecatalog search-products'  This is a sample entry...<p>
	 * <pre>
	    {
            "Type": "CLOUD_FORMATION_TEMPLATE",
            "ShortDescription": "ecr-repo",
            "Id": "prodview-xtce5gd2mr4tk",
            "Owner": "EA",
            "Name": "ecr-repo",
            "ProductId": "prod-224u4iysbc4ky",
            "HasDefaultPath": false
        },

	 * </pre>
	 */
	public Map getAwsDefinition() {
		return _awsDefinition
	}
	
	/**
	 * Returns the AWS Product ID for this product.
	 */
	public String getProductId() {
		return awsDefinition.ProductId
	}
	
	/**
	 * This is the same as getProductId() and returns the ID.
	 */
	public String getId() {
		return awsDefinition.ProductId
	}

	/**
	 * Returns the name of this Aws Product	
	 */
	public String getName() {
		return awsDefinition.Name
	}
	
	/**
	 * Returns the short description.  Returns empty string if there isn't a short description.
	 */
	public String getShortDescription() {
		if (awsDefinition.containsKey('ShortDescription')) {
			return awsDefinition.ShortDescription
		} else {
			return ''
		}
	}
	
	/**
	 * Returns a List<AwsProductLaunchPath> of launch paths for this product.
	 */
	public List<AwsProductLaunchPath> getAwsProductLaunchPaths() {
		if (_awsLaunchPaths == null) {
			AwsConnection awsConnection = _awsServiceCatalog.awsConnection
			_awsLaunchPaths = []
			CommandRunner commandRunner = awsConnection.executeAwsCliCommand("aws servicecatalog list-launch-paths --product-id ${productId} --region ${awsConnection.getRegion()}")
			if (! commandRunner.wasSuccessful()) {
				throw new AbortPluginException( "AWS servicecatalog call failed")
			}
			Map info = (new JsonSlurper()).parseText( commandRunner.getConsoleOutput() )
			info.LaunchPathSummaries.each { Map entry ->
				_awsLaunchPaths << new AwsProductLaunchPath(this, entry)
			}
		}
		return _awsLaunchPaths
	}
	
	/**
	 * Returns the 'default' launch path for this Product.  Note that AWS doesn't define a default
	 * launch path.  This simply returns the first launch path in the list.
	 */
	public AwsProductLaunchPath getDefaultAwsProductLaunchPath() {
		List<AwsProductLaunchPath> launchPaths = getAwsProductLaunchPaths()
		return launchPaths[0]
	}
	
	/**
	 * Returns a List of the versions of this product.  This function does cache management.
	 */
	public List<AwsProductVersion> getAwsProductVersions() {
		if (_awsProductVersions == null) {
			AwsConnection awsConnection = _awsServiceCatalog.awsConnection
			_awsProductVersions = []
			CommandRunner commandRunner = awsConnection.executeAwsCliCommand("aws servicecatalog describe-product --id ${productId} --region ${awsConnection.getRegion()}")
			if (! commandRunner.wasSuccessful()) {
				throw new AbortPluginException( "AWS servicecatalog call failed")
			}
			Map info = (new JsonSlurper()).parseText( commandRunner.getConsoleOutput() )
			info.ProvisioningArtifacts.each { Map entry ->
				_awsProductVersions << new AwsProductVersion(this, entry.Name, entry.Id, entry.CreatedTime )
			}
		}
		return _awsProductVersions
	}
	
	/**
	 * Does this Product have a version with the given name?
	 */
	public boolean hasVersionByName( String name ) {
		// get versions by calling function and not accessing variable.  The function does cache management.
		List<AwsProductVersion> versions = getAwsProductVersions()
		AwsProductVersion locatedEntity = versions.find { AwsProductVersion entry ->
			return (entry.getName() == name)
		}
		return (locatedEntity != null)

	}
	
	/**
	 * Return the AwsProductVersion with the given name.  Throws exception if not found.
	 */
	public AwsProductVersion getVersionByName( String name ) {
		// get versions by calling function and not accessing variable.  The function does cache management.
		List<AwsProductVersion> versions = getAwsProductVersions()
		AwsProductVersion locatedEntity = versions.find { AwsProductVersion entry ->
			return (entry.getName() == name)
		}
		if (locatedEntity) {
			return locatedEntity
		} else {
			throw new Exception( "Unable to find a version named '${name}' for the AWS Product '${this.getName()}'")
		}
	}
	
	/**
	 * Returns the newest version of this product.
	 */
	public AwsProductVersion getNewestVersion() {
		AwsProductVersion newest = null
		getAwsProductVersions().each { AwsProductVersion entry ->
			if ((! newest) || (entry.getCreated() > newest.getCreated())) {
				newest = entry
			}
		}
		return newest
	}
}
