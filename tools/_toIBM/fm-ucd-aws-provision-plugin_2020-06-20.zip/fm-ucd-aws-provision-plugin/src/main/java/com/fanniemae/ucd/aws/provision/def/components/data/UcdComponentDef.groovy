package com.fanniemae.ucd.aws.provision.def.components.data

import java.util.List

import com.fanniemae.ucd.aws.provision.def.common.ValidationErrorReporter
import com.ibm.css.ucd.agent.AgentOrAgentPool
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.services.ApplicationServices

/**
 * Used to represent one entry from the 'ucdComponents' list
 * in the UCD Template.
 *
 */
class UcdComponentDef {
	public String componentName
	public boolean participateInBlueGreen = false
	/**
	 * The resource name of Component Resource.  If not defined in the JSON, then this
	 * class automatically sets this to the componentName.
	 */
	private String _resourceName
	/**
	 * The name of the selected agent, such as 'agent1' or 'agent2'.
	 * The default is 'agent1', which is automatically set.
	 */
	public String agent
	/**
	 * The UCD Agent or Pool
	 */
	public AgentOrAgentPool ucdAgent
	/**
	 * In this map, the key is the name of a Component Environment Property and the value is
	 * a String value (which can contain '%...%' tokens) or a boolean value.
	 */
	public Map componentEnvironmentProperties = [:]

	/**
	 * Constructor.
	 * @param entryNumber Which entry number is this from the list of components in the list.
	 * @param rawData The parsed JSON data for the entry.
	 * @param errorReporter Used to report any problems.
	 * @param applicationServices UCD Application Services
	 * @param ucdApplication The application being processed.
	 * @param indexedUcdAgents Indexed list of UCD Agents for provisioning.  Key = name of agent, such as 'agent1'.
	 * Value = the agent or pool.
	 */
	public UcdComponentDef( int entryNumber, Map rawData, ValidationErrorReporter errorReporter, ApplicationServices applicationServices, Application ucdApplication,
		Map<String,AgentOrAgentPool> indexedUcdAgents ) {
		if (! rawData.containsKey('componentName')) {
			errorReporter.tagValidationError("The ucdComponentsDef file is missing the 'componentName' field for items entry #" + entryNumber)
		} else {
			componentName = rawData.componentName
			if (rawData.containsKey('resourceName')) {
				_resourceName = rawData.resourceName
			} else {
				_resourceName = componentName
			}
			if (rawData.containsKey('agent')) {
				agent = rawData.agent
			} else {
				agent = 'agent1'
			}
			if (indexedUcdAgents.containsKey(agent)) {
				ucdAgent = indexedUcdAgents[agent]
			} else {
				errorReporter.tagValidationError("Within the provision template file, the 'agent' value for component '${componentName}' is '${agent}', but only ${indexedUcdAgents.size()} agents are defined, and they are referenced as agent1, agent2, and so on.")
			}
			if (! ucdApplication.hasComponent(componentName)) {
				errorReporter.tagValidationError("The template contains a UCD Component named '${componentName}', which is NOT in the UCD Application '${ucdApplication.getName()}'")
			} else {
				Component ucdComponent = ucdApplication.getComponent(componentName)
				if (rawData.containsKey('participateInBlueGreen')) {
					def blueGreen = rawData.participateInBlueGreen
					if (blueGreen instanceof String) {
						participateInBlueGreen = blueGreen.toBoolean()
					} else {
						participateInBlueGreen = blueGreen
					}
				}
				if (rawData.containsKey('componentEnvironmentProperties')) {
					if (! (rawData.componentEnvironmentProperties instanceof Map)) {
						errorReporter.tagValidationError("Within the provision template file, the componentEnvironmentProperties field for component '${componentName}' should be, but is not, a Map")
					} else {
						componentEnvironmentProperties = rawData.componentEnvironmentProperties
						// validate the component env properties
						List ucdEnvironmentProperties = ucdComponent.getEnvironmentPropertyDefinitions()
						// Create a name indexed map of the ucd environment properties
						Map<String,Map> indexedUcdEnvironmentProperties = [:]
						ucdEnvironmentProperties.each { Map entry ->
							indexedUcdEnvironmentProperties[entry.name] = entry
						}
						componentEnvironmentProperties.each { String propName, String propValue ->
							if (! indexedUcdEnvironmentProperties.containsKey(propName)) {
								// The template has a property that isn't part of UCD
								errorReporter.tagValidationError("Within the provision template file, the template has a property named '${propName}' for the UCD component '${ucdComponent.name}', but no such property exists in the UCD Component.")
							}
						}
					}
				}
			}
		}
	}
	
	/**
	 * Returns the resourceName, which is the name of the corresponding resource(s) for this component.  This
	 * defaults to the component name.  This is deprecated.  Use getResourceName() instead.
	 */
	@Deprecated
	public String getName() {
		return _resourceName
	}
	
	/**
	 * Returns the resourceName, which is the name of the corresponding resource(s) for this component.  This
	 * defaults to the component name.  
	 */
	public String getResourceName() {
		return _resourceName
	}
}
