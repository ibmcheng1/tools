package com.fanniemae.ucd.aws.api.cloudformation

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.ucd.aws.api.AwsBaseApiWrapper
import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel

import groovy.json.JsonSlurper

/**
 * An interface to the AWS Cloudformation services.
 * @author s9ulcc
 *
 */
class AwsCloudformation extends AwsBaseApiWrapper {
	
	/**
	 * Constructor.
	 * @param awsConnection Connection to AWS.
	 */
	public AwsCloudformation( AwsConnection awsConnection ) {
		super( awsConnection )
	}
	
//	/**
//	 * Given a Cloudformation Stack ARN, return the embedded stack name.
//	 * @param stackArn The ARN, such as 
//	 * arn:aws:cloudformation:us-east-1:243769994261:stack/SC-243769994261-pp-2a3refmxhqghi-EB-1H65D8X91J62L/c8b2c8f0-9486-11ea-b8b7-0a1540e225b5
//	 * which returns the name SC-243769994261-pp-2a3refmxhqghi-EB-1H65D8X91J62L
//	 * @return The stack name or an empty string if unable to extract the name.
//	 */
//	public static String extractNameFromStackARN( String stackArn ) {
//		String stackName = ''
//		def match = (stackArn =~ /.+\:stack\/(.+)\/.*/)
//		if (match.find()) {
//			stackName = match.group(1)
//		}
//		return stackName
//	}

}
