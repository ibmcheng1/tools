package com.fanniemae.aws.api.connection

import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel
import com.ibm.issr.core.plugin.AbortPluginException

/**
 * Represents an authenticated connection (with needed data) to an AWS instance.
 * @author s9ulcc
 *
 */
class AwsConnection {
	private String _awsRegion
	
	/**
	 * Constructor.
	 * @param awsRegion The AWS Region, such as 'us-east-1'
	 */
	public AwsConnection( String awsRegion ) {
		this._awsRegion = awsRegion
	}
	
	/**
	 * Initiate an AWS Working Session and authentication.
	 * @param awsRole The AWS Role
	 */
	public void initiateAwsSession( String awsRole ) {
		CommandRunner commandRunner = executeAwsCliCommand("ROLE=${awsRole}" + '''
CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
if [[ $CURRENT_ROLE != $ROLE ]] ; then
    echo "ERROR: Failed to assume the role: ${ROLE}"
    exit 1
fi
echo "Assumed role: ${CURRENT_ROLE}"
''')
		if (! commandRunner.wasSuccessful()) {
			throw new AbortPluginException( "Unable to authenticate against AWS" )
		}
	}
	
	/**
	 * Executes the given AWS CLI script.  The script may be one or multiple lines.  This function
	 * adds all of the appropriate setup commands before the call.
	 * @param cmd The script line(s) to run.
	 * @return The CommandRunner that ran.  Call CommandRunner.wasSuccessful() to determine if the script ran OK.
	 * Call CommandRunner.getConsoleOutput() to get the console output.
	 */
	public CommandRunner executeAwsCliCommand( String cmd ) {
		// Create and execute the script file that calls AWS
		File shellScript = new File('awsScript.sh')
//		shellScript.text = """${getProfileScript()}
//""" + cmd 
		shellScript.text = """#!/bin/bash
source .awsprofile
""" + cmd 
		shellScript.setExecutable(true)
		
		
		// Most of the following code is setup to force logging if the command fails.  In that
		// event, it outputs the script body as well.  Note that if the log level is set
		// to info and the command works, nothing is displayed.
		
		boolean success
		String logMessages
		CommandRunner commandRunner
		// do a delayed capture of the Logger messages at DEBUG level if current level is below DEBUG
		logMessages = Logger.captureLogMessages( ! Logger.willDisplay(LoggerLevel.DEBUG) ) {
			Logger.setLocalLoggingLevel( LoggerLevel.DEBUG ) {
				Logger.debug "**************************************************"
				Logger.debug " Calling AWS CLI script"
				Logger.debug "**************************************************"
				Logger.debug shellScript.text
		
				commandRunner = new CommandRunner()
				success = commandRunner
					.setVerbose( Logger.displayDebug )
					.setPrintToDebug()
					.setCommand([ "./${shellScript.name}" ])
					.execute()
					.wasSuccessful()
			}
		}
		if ((! success) && logMessages) {
			Logger.displayRawText(logMessages)
		}
		Logger.debug "Shell successful? " + success
		return commandRunner
	}

	/**
	 * Returns the AWS Region, such as 'us-east-1'
	 */
	public String getRegion() {
		return _awsRegion
	}
}
