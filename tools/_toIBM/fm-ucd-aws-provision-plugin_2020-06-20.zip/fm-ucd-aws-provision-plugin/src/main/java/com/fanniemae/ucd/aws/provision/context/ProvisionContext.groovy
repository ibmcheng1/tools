package com.fanniemae.ucd.aws.provision.context

import com.fanniemae.provision.ucd.SummaryReport
import com.fanniemae.ucd.aws.api.describeRecord.AwsDescribeRecordResult
import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProductInstance
import com.fanniemae.ucd.aws.provision.context.data.AwsProductInstancePlaceholder
import com.fanniemae.ucd.aws.provision.service.definition.AwsServiceDefinition
import com.fanniemae.ucd.aws.provision.service.instance.AwsServiceInstance
import com.ibm.css.ucd.agent.AgentOrAgentPool
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.issr.core.log.Logger

/**
 * <p>Represents one provisioning context.  A context can have a parent
 * context.
 * </p><p>
 * Key data stored in the context is...
 * </p>
 * <ul>
 * <li>Application application - The UCD application being provisioned to.  Note that child contexts
 * inherit this from their parent.</li>
 * <li>AWS Resource Instance list - which includes definition and (eventually) the provisioned instances.</li>
 * <li>UCD Environment for this context (name and UCD Environment class) as appropriate.  For
 * example, if provisioning blue-green, then the base context has no environment.</li>
 * <li>UCD Resource branch for this context (name and UCD variable).  This is always defined for the
 * base, blue and green contexts</li>
 * </ul>
 * <p>For example, when provisioning to blue-green,
 * the base context corresponds to the environment, components, and
 * AWS Resource Instances that are common (not blue or green).  It has
 * two child contexts - a blue and a green context with the blue and green
 * details.
 * <p>
 */
class ProvisionContext {
	// value that indicates that no substitution was found for a token value
	protected static final String TOKEN_NOT_FOUND = "'#!*(`"
	
	// The context name which can be used in user messages, such as 'shared resources', 'blue environment', 'stand-alone environment'
	protected String _contextName = ''
		
	protected ProvisionContext _parentContext
	
	protected List<ProvisionContext> _childContexts = []

	protected List<AwsProductInstancePlaceholder> _awsProductInstancePlaceholders = []
	
	protected Application _application
	
	// UCD Application 'appCode' field
	protected String _appCode
	
	// The AWS Region and authentication information
	protected String _region = ''
	protected String _awsAccountId = ''
	protected String _awsRole = ''
	
	// The base environment name, which is the original environment name without any blue-gree suffix, etc
	protected String _baseEnvironmentName = ''
	
	// Map of tokens where key is String token name and value is String token value
	protected Map _tokens = [:]
	
	protected boolean _blueContext = false
	protected boolean _greenContext = false
	
	/**
	 * The environment name for this context.  Empty string if not defined.
	 */
	protected String _environmentName = ''
	protected String _environmentType = ''
	protected boolean _environmentContext = false	// Set to true if this is a UCD Environment context.
	
	/**
	 * The environment for this context.  null if not defined.
	 */
	protected Environment _environment = null
	
	/**
	 * The ordered list of Agents for provisioning.  User refers to first
	 * entry as 'agent1', second as 'agent2' and so on.
	 */
	protected List<AgentOrAgentPool> _ucdAgents = null
	
	/**
	 * If a context has a specific UCD Agent, it is tracked with this field.
	 * For example, the Context for a agent within a Resource branch will have
	 * this value, which is the agent.
	 */
	protected AgentOrAgentPool _ucdAgent = null
	
	/**
	 * IF (and only if) the _ucdAgents are defined, then the list
	 * of possible token values, such as 'agent1.name' are precalculated
	 * and stored in this map.  They key is the token name and the value
	 * is the token value.  This is an empty map if the Agents aren't defined.
	 */
	protected Map<String,String> _ucdAgentTokens = [:]
	
	/**
	 * For a non-blue-green environment, this is an empty string.
	 * Otherwise it is a unique number counter for the blue-green
	 * environments � �1�, �2� (and so on if needed).
	 */
	protected String _blueGreenCounter = ''
	
	/**
	 * The name of the resource tree branch for this context.  This is the
	 * name of the child under the application node, such as 'D105' and NOT
	 * 'app/D105'.  This is an empty string if there is no resource tree branch
	 * for this context.
	 */
	protected String _resourceBranchName = ''
	/**
	 * The handle to the resource tree branch for this Context or
	 * null if not defined or needed.
	 */
	protected ResourceNode _resourceBranch

	/**
	 * Constructor
	 * @param parentContext Optional parent context.  Use null if there is no parent context.
	 * @param blueContext Is this is a blue context?
	 * @param greenContext Is this ia a green context?
	 */
	public ProvisionContext( ProvisionContext parentContext, boolean blueContext, boolean greenContext ) {
		_parentContext = parentContext
		_blueContext = blueContext
		_greenContext = greenContext
	}
	
	/**
	 * Constructor which does not specific blue/green context information.  The blue/green context information
	 * is inherited from the parentContext or false if there is no parent context.
	 * @param parentContext Optional parent context
	 */
	public ProvisionContext( ProvisionContext parentContext = null ) {
		_parentContext = parentContext
		if (parentContext) {
			_blueContext = parentContext.isBlueContext()
			_greenContext = parentContext.isGreenContext()
		}
	}

	/**
	 * Is this a blue context?
	 */
	public boolean isBlueContext() {
		return _blueContext
	}
	
	/**
	 * Is this a green context?
	 */
	public boolean isGreenContext() {
		return _greenContext
	}
	
	/**
	 * Sets the AWS Region, such as us-east-1
	 */
	public void setAwsRegion( String region ) {
		_region = region
	}
	
	/**
	 * Use setAwsRegion() instead.
	 */
	@Deprecated
	public void setRegion( String value ) {
		setAwsRegion(value)
	}
	
	/**
	 * Returns the AWS region name or empty string if not defined.  The region is
	 * inherited from the parent context.
	 * @return
	 */
	public String getAwsRegion() {
		if (_region) {
			return _region
		} else if (hasParentContext()) {
			return getParentContext().getAwsRegion()
		} else {
			return ''
		}
	}
	
	/**
	 * Sets the context name, such as 'shared resources', 'blue environment', 'stand-alone environment'
	 */
	public void setContextName( String contextName ) {
		_contextName = contextName
	}
	
	/**
	 * Returns the context name, which is inherited. 
	 * @return
	 */
	public String getContextName() {
		if (_contextName) {
			return _contextName
		} else if (hasParentContext()) {
			return getParentContext().getContextName()
		} else {
			return ''
		}
	}
	
	/**
	 * Use getAwsRegion() instead.
	 */
	@Deprecated
	public String getRegion() {
		return getAwsRegion()
	}
	
	/**
	 * Sets the AWS Account ID
	 */
	public void setAwsAccountId( String value ) {
		_awsAccountId = value
	}
	
	/**
	 * Returns the AWS Account ID or empty string if not defined.  The value is
	 * inherited from the parent context.
	 */
	public String getAwsAccountId() {
		if (_awsAccountId) {
			return _awsAccountId
		} else if (hasParentContext()) {
			return getParentContext().getAwsAccountId()
		} else {
			return ''
		}
	}
	
	/**
	 * Sets the AWS Role
	 */
	public void setAwsRole( String value ) {
		_awsRole = value
	}
	
	/**
	 * Returns the AWS Role or empty string if not defined.  The value is
	 * inherited from the parent context.
	 */
	public String getAwsRole() {
		if (_awsRole) {
			return _awsRole
		} else if (hasParentContext()) {
			return getParentContext().getAwsRole()
		} else {
			return ''
		}
	}

	/**
	 * Sets the environment name for this context.
	 */
	public void setEnvironmentName( String name ) {
		this._environmentName = name
	}
	
	/**
	 * If there is an actual environment associated with this context, then that name is returned.  Otherwise,
	 * the setEnvironmentName() value is set.
	 * Returns the environmentName for this context or empty string if not defined.  The environmentName is
	 * inherited from the parent context.
	 */
	public String getEnvironmentName() {
		Environment environment = this.getEnvironment()
		if (environment) {
			return environment.getName()
		} else if (_environmentName) {
			return _environmentName
		} else if (hasParentContext()) {
			return getParentContext().getEnvironmentName()
		} else {
			return ''
		}
	}
	
	/**
	 * Sets the environment Context flag to true for this context.
	 */
	public void flagAsEnvironmentContext() {
		this._environmentContext = true
	}
	
	/**
	 * Is this an environment context?  Unlike most properties, this is NOT inherited.
	 */
	public boolean isEnvironmentContext() {
		return _environmentContext
	}

	/**
	 * Sets the UCD agents for this context.
	 */
	public void setUcdAgents( List<AgentOrAgentPool> ucdAgents ) {
		this._ucdAgents = ucdAgents
		// pre-build the UCD Agent Tokens
		int agentIndex = 0
		_ucdAgents.each { AgentOrAgentPool agent ->
			++agentIndex
			_ucdAgentTokens['agent' + agentIndex + '.name'] = agent.name
		}
	}
	
	/**
	 * Returns the UCD Agents for this context or null if not defined.  This is
	 * inherited from the parent context.
	 */
	public List<AgentOrAgentPool> getUcdAgents() {
		if (_ucdAgents) {
			return _ucdAgents
		} else if (hasParentContext()) {
			return getParentContext().getUcdAgents()
		} else {
			return null
		}
	}
	
	/**
	 * Sets the ucd agent for this context.
	 */
	public void setUcdAgent( AgentOrAgentPool ucdAgent ) {
		this._ucdAgent = ucdAgent
	}
	
	/**
	 * Returns the ucd agent for this context or null if not defined.  This is
	 * inherited from the parent context.
	 */
	public String getUcdAgent() {
		if (_ucdAgent) {
			return _ucdAgent
		} else if (hasParentContext()) {
			return getParentContext().getUcdAgent()
		} else {
			return null
		}
	}

	/**
	 * Internal function which returns all of the token values for the
	 * ucd agents.  There are a variable number of Agents.  It is easier (and faster)
	 * to pre-build the list of tokens for the agent list than to try to parse the
	 * tokens and try to match them up.
	 * @return Map where the keys are token strings and the values are the token values.
	 * This may return an empty map, but doesn't return null.
	 */
	protected Map<String,String> getUcdAgentTokens() {
		if (_ucdAgentTokens.size()> 0) {
			return _ucdAgentTokens
		} else if (hasParentContext()) {
			return getParentContext().getUcdAgentTokens()
		} else {
			return [:]
		}
	}

	/**
	 * Sets the environment type for this context.
	 */
	public void setEnvironmentType( String envType ) {
		this._environmentType = envType
	}
	
	/**
	 * Returns the environmentType for this context or empty string if not defined.  The environmentType is
	 * inherited from the parent context.
	 */
	public String getEnvironmentType() {
		if (_environmentType) {
			return _environmentType
		} else if (hasParentContext()) {
			return getParentContext().getEnvironmentType()
		} else {
			return ''
		}
	}

	/**
	 * Sets the environment for this context.
	 */
	public void setEnvironment( Environment environment ) {
		this._environment = environment
	}
	
	/**
	 * Returns the environment for this context or null if not defined.  The environment is
	 * inherited from the parent context.
	 */
	public Environment getEnvironment() {
		if (_environment) {
			return _environment
		} else if (hasParentContext()) {
			return getParentContext().getEnvironment()
		} else {
			return null
		}
	}
	
	/**
	 * For a non-blue-green environment, this is an empty string.
	 * Otherwise it is a unique number counter for the blue-green
	 * environments � �1�, �2� (and so on if needed).
	 */
	public void setBlueGreenCounter( String value ) {
		_blueGreenCounter = value
	}
	
	/**
	 * For a non-blue-green environment, this is an empty string.
	 * Otherwise it is a unique number counter for the blue-green
	 * environments � �1�, �2� (and so on if needed).  This is inherited from
	 * the parent context.
	 */
	public String getBlueGreenCounter() {
		if (_blueGreenCounter) {
			return _blueGreenCounter
		} else if (hasParentContext()) {
			return getParentContext().getBlueGreenCounter()
		} else {
			return null
		}
	}
	
	/**
	 * The name of the resource tree branch for this context.  This is the
	 * name of the child under the application node, such as 'D105' and NOT
	 * 'app/D105'.  This is an empty string if there is no resource tree branch
	 * for this context.
	 */
	public void setResourceBranchName( String value ) {
		_resourceBranchName = value
	}
	
	/**
	 * The name of the resource tree branch for this context.  This is the
	 * name of the child under the application node, such as 'D105' and NOT
	 * 'app/D105'.  This is an empty string if there is no resource tree branch
	 * for this context.  This is inherited from the parent context.
	 */
	public String getResourceBranchName() {
		if (_resourceBranchName) {
			return _resourceBranchName
		} else if (hasParentContext()) {
			return getParentContext().getResourceBranchName()
		} else {
			return ''
		}
	}
	
	/**
	 * The handle to the resource tree branch for this Context or
	 * null if not defined or needed.
	 */
	public void setResourceBranch( ResourceNode resourceBranch ) {
		_resourceBranch = resourceBranch
	}
	
	/**
	 * The handle to the resource tree branch for this Context or
	 * null if not defined or needed.  This is inherited from the parent
	 * context.
	 */
	public ResourceNode getResourceBranch() {
		if (_resourceBranch) {
			return _resourceBranch
		} else if (hasParentContext()) {
			return getParentContext().getResourceBranch()
		} else {
			return null
		}
	}

	/**
	 * Adds the list of tokens for this context.  Note that when tokens are retrieved,
	 * they use the context stack.
	 * @param tokens A set of token name/value pairs.
	 */
	public void addTokens( Map tokens ) {
		tokens.each { String name, String value ->
			_tokens[name] = value
		}
	}
	
	/**
	 * Does the named token exist in the context stack??
	 */
	public boolean containsToken( String tokenName ) {
		if (_tokens && _tokens.containsKey(tokenName)) {
			return true
		} else {
			ProvisionContext parentContext = getParentContext()
			if (parentContext) {
				return parentContext.containsToken(tokenName)
			} else {
				return false
			}
		}
	}
	
	/**
	 * Returns the value of the named token from the context stack or empty string if not found.
	 */
	public def getTokenValue( String tokenName ) {
		if (_tokens && _tokens.containsKey(tokenName)) {
			return _tokens[tokenName]
		} else {
			ProvisionContext parentContext = getParentContext()
			if (parentContext) {
				return parentContext.getTokenValue(tokenName)
			} else {
				return ''
			}
		}
	}
	
	/**
	 * Returns the parent context, which may be null.
	 */
	public ProvisionContext getParentContext() {
		return _parentContext
	}
	
	/**
	 * Does this context have a parent context??
	 */
	public boolean hasParentContext() {
		if (_parentContext) {
			return true
		} else {
			return false
		}
	}
	
	/**
	 * Returns the root context which is the parent's parent's .. etc .. context which
	 * has no parent.
	 */
	public ProvisionContext getRootContext() {
		if (hasParentContext()) {
			return getParentContext().getRootContext()
		} else {
			return this
		}
	}
	
	/**
	 * Adds a child context.
	 */
	public void addChildContext( ProvisionContext childContext ) {
		_childContexts << childContext
	}
	
	/**
	 * Returns a list of all of the child contexts.
	 */
	public List<ProvisionContext> getChildContexts() {
		return _childContexts
	}
	
	/**
	 * Iterate this context and every descendent context calling the callback
	 * for each context in that tree.
	 * @param eachMethod Callback.  Syntax is 'void eachMethod( ProvisionContext provisionContext )'
	 */
	public void eachContextInTree( Closure eachMethod ) {
		// Call for this context
		eachMethod( this )
		// recurse for each child
		getChildContexts().each { ProvisionContext childContext ->
			childContext.eachContextInTree(eachMethod)
		}
	}
	
	/**
	 * Adds a brand new AWS Product Instance Placeholder to this context.
	 */
	public void addAwsProductInstancePlaceholder( AwsProductInstancePlaceholder awsProductInstancePlaceholder ) {
		_awsProductInstancePlaceholders << awsProductInstancePlaceholder
	}
	
	/**
	 * Return a list ofAwsProductInstancePlaceholder entries that are part of this context.
	 * This does NOT look at parent contexts at all.
	 */
	public List<AwsProductInstancePlaceholder> getContextSpecificAwsProductInstancePlaceholders() {
		return _awsProductInstancePlaceholders
	}

	/**
	 * Return a list of all AwsProductInstancePlaceholder entries for this context and all
	 * of its ancestor contexts.
	 * @return
	 */
	public List<AwsProductInstancePlaceholder> getInheritedAwsProductInstancePlaceholder() {
		List<AwsProductInstancePlaceholder> all = []
		for (ProvisionContext context = this; context; context = context.getParentContext()) {
			context.getContextSpecificAwsProductInstancePlaceholders().each { AwsProductInstancePlaceholder instance ->
				all << instance
			}
		}
		return all
	}
	
	/**
	 * Iterates through the list of all AwsProductInstancePlaceholder entries for this context or
	 * any ancestor context.  Calls iterator Closure for each located entry.
	 * @param iterator Syntax is 'void iterator( AwsProductInstancePlaceholder placeholder, ProvisionContext context )'
	 * where placeholder is the iterated placeholder and 'context' is the context that the placeholder is in.
	 */
	public void iterateInheritedAwsProductInstancePlaceholders( Closure iterator ) {
		for (ProvisionContext context = this; context; context = context.getParentContext()) {
			context.getContextSpecificAwsProductInstancePlaceholders().each { AwsProductInstancePlaceholder instance ->
				iterator( instance, context )
			}
		}
	}
	
	/**
	 * Searches this context and parent contexts for instance context data with a matching
	 * logical definition name.
	 * @return Returns the located match or null if not found.
	 */
	public AwsProductInstancePlaceholder findAwsProductInstancePlaceholder( String logicalResourceDefinitionName ) {
		List<AwsProductInstancePlaceholder> contextList = getInheritedAwsProductInstancePlaceholder()
		return contextList.find { AwsProductInstancePlaceholder instanceContext ->
			return (instanceContext.getName() == logicalResourceDefinitionName)
		}
	}
	
	/**
	 * Searches this context and NOT parent contexts for instance context data with a matching
	 * logical definition name.
	 * @return Returns the located match or null if not found.
	 */
	public AwsProductInstancePlaceholder findContextSpecificAwsProductInstancePlaceholder( String logicalResourceDefinitionName ) {
		List<AwsProductInstancePlaceholder> contextList = getContextSpecificAwsProductInstancePlaceholders()
		return contextList.find { AwsProductInstancePlaceholder instanceContext ->
			return (instanceContext.getName() == logicalResourceDefinitionName)
		}
	}

	/**
	 * Sets the application for this context.
	 */
	public void setApplication( Application application ) {
		this._application = application
	}
	
	/**
	 * Returns the application for this context.  Note that the
	 * application is inherited from the parent context.  This may return null.
	 */
	public Application getApplication() {
		if (_application) {
			return _application
		} else if (getParentContext()) {
			return getParentContext().getApplication()
		} else {
			return null
		}
	}
	
	/**
	 * Sets UCD Application's 'appCode'
	 */
	public void setAppCode( String appCode ) {
		_appCode = appCode
	}
	
	/**
	 * Returns the 'appCode' which is inherited from parent context.  Returns emptry string if not found.
	 */
	public String getAppCode() {
		if (_appCode) {
			return _appCode
		} else if (hasParentContext()) {
			return getParentContext().getAppCode()
		} else {
			return ''
		}
	}

	/**
	 * Is the provisioning targeting blue-green?
	 */
	public boolean isProvisioningBlueGreen() {
		if (getParentContext()) {
			return getParentContext().isProvisioningBlueGreen()
		} else {
			return false
		}
	}

	/**
	 * Is this context the base context?  Otherwise, it is blue or green context.
	 */
	public boolean isBaseContext() {
		return (getParentContext() == null)
	}
	
	/**
	 * Process the string (s) which may contain context tokens, replaces the tokens and returns
	 * the resulting string.
	 * @param thisName Optional logical name of the entity being processed.  For example, if resolving
	 * a variable within an AwsServiceInstance, then 'thisName' is the logical name of the Service Instance.
	 */
	public String processTokens( String s, String thisName = '' ) {
		List<String> tokenizedList = tokenize(s)
		String rslt = ''
		boolean isNextTokenPlainText = true
		tokenizedList.each { String token ->
			if (isNextTokenPlainText) {
				rslt = rslt + token
			} else {
				// Process token
				String newValue = lookupToken( token, thisName )
				if (newValue == TOKEN_NOT_FOUND) {
					Logger.info "WARNING: Unable to find a value for the token '%(${token})%'"
					rslt = rslt + '%(' + token + ')%'
				} else {
					rslt = rslt + newValue
				}
			}
			isNextTokenPlainText = ! isNextTokenPlainText
		}
		return rslt
	}
	
	/**
	 * Attempts to lookup a new value for the token.
	 * @param token The token string WITHOUT token delimiters.
	 * @param thisName Optional logical name of the entity being processed.  For example, if resolving
	 * a variable within an AwsServiceInstance, then 'thisName' is the logical name of the Service Instance.
	 * @return Returns the new value for the token or TOKEN_NOT_FOUND if unable to find token lookup.
	 */
	protected String lookupToken( String token, String thisName = '' ) {
		String retval = TOKEN_NOT_FOUND
		boolean shiftToLowerCase = false
		
		// Get predefined tokens
		Map<String,String> agentTokens = this.getUcdAgentTokens()
		
		String lowerCaseToken = token.toLowerCase()
		String lowerCaseSuffix = '.tolowercase'
		if (lowerCaseToken.endsWith(lowerCaseSuffix)) {
			shiftToLowerCase = true
			token = token.substring(0, token.length()-lowerCaseSuffix.length())
			lowerCaseToken = token.toLowerCase()
		}
		
		List<String> segments = token.tokenize('.')
		if (token.equalsIgnoreCase('environment.name')) {
			// if the environment name is empty, then return the environment base name
			retval = this.getEnvironmentName()
			if (! retval) {
				retval = this.getBaseEnvironmentName()
			}
		} else if (agentTokens.containsKey(lowerCaseToken)) {
			retval = agentTokens[lowerCaseToken]
		} else if (token.equalsIgnoreCase('environment.basename')) {
			retval = this.getBaseEnvironmentName()
		} else if (token.equalsIgnoreCase('application.name')) {
			retval = this.getApplication().name
		} else if (token.equalsIgnoreCase('appcode')) {
			retval = this.getAppCode()
		} else if (token.equalsIgnoreCase('environment.type')) {
			retval = this.getEnvironmentType()
		} else if (token.equalsIgnoreCase('isBlueGreen')) {
			retval = this.isProvisioningBlueGreen()
		} else if (token.equalsIgnoreCase('environment.bluegreen.counter')) {
			retval = this.getBlueGreenCounter()
		} else if (token.equalsIgnoreCase('region') || token.equalsIgnoreCase('aws.region')) {
			retval = this.getAwsRegion()
		} else if (token.equalsIgnoreCase('aws.accountId')) {
			retval = this.getAwsAccountId()
		} else if (token.equalsIgnoreCase('aws.role')) {
			retval = this.getAwsRole()
		} else if (segments[0].equalsIgnoreCase('token')) {
			if (segments.size()> 1 && this.containsToken(segments[1])) {
				retval = this.getTokenValue(segments[1])
			} else {
				retval = TOKEN_NOT_FOUND
			}
		} else {
			// Try to match a Service and property name.
			// General pattern is ['awsResource'.]serviceName.[context.]propertyName
			//	- 'awsResource.' can be skipped.  If skipped, then the first segment contains the serviceName
			//	- serviceName is '[this]' or the logical name of a service.
			//  - context
			//		- can be 'prop', 'outprop', 'AwsProperty', 'inprop' or skipped
			//		- If skipped, the output properties are search before input for a matching property name
			retval = TOKEN_NOT_FOUND 
			int segmentPointer = 0
			if ((segments.size()> segmentPointer) && (segments[segmentPointer].equalsIgnoreCase('awsResource'))) {
				++segmentPointer
			}
			if (segments.size()> segmentPointer) {
				String logicalResourceName = segments[segmentPointer]
				++segmentPointer
				if (logicalResourceName.equalsIgnoreCase('[this]')) {
					logicalResourceName = thisName
				}
				AwsProductInstancePlaceholder awsProductInstancePlaceholder = findAwsProductInstancePlaceholder(logicalResourceName)
				if (awsProductInstancePlaceholder && segments.size() > segmentPointer) {
					boolean check_OutProps = true
					boolean check_InProps = true
					if (segments.size()> segmentPointer) {
						if (segments[segmentPointer].equalsIgnoreCase('prop') || segments[segmentPointer].equalsIgnoreCase('outprop')) {
							check_InProps = false
							++segmentPointer
						} else if (segments[segmentPointer].equalsIgnoreCase('AwsProperty') || segments[segmentPointer].equalsIgnoreCase('inprop')) {
							check_OutProps = false
							++segmentPointer
						}
					}
					if (segments.size()> segmentPointer) {
						boolean resolved = false
						String fieldName = segments[segmentPointer]
						if (check_OutProps) {
							AwsServiceInstance awsServiceInstance = awsProductInstancePlaceholder.awsServiceInstance
							if (awsServiceInstance) {
								AwsDescribeRecordResult recordResult = awsServiceInstance.getAwsInstanceData()
								if (recordResult && recordResult.hasNamedProperty(fieldName)) {
									retval = recordResult.getNamedProperty(fieldName)
									resolved = true
								}
							}
						}
						if (check_InProps && (! resolved)) {
							AwsServiceDefinition awsServiceDefinition = awsProductInstancePlaceholder.getServiceDefinition()
							if (awsServiceDefinition && awsServiceDefinition.hasPropertyField(fieldName)) {
								retval = awsServiceDefinition.getPropertyField( fieldName, this )
								resolved = true
							}
						}
					}
				}
			}
		}
		if (shiftToLowerCase && retval!=TOKEN_NOT_FOUND) {
			retval = retval.toLowerCase()
		}
		return retval
	}
	
	/**
	 * Tokenize the string returning a List<String> where the first
	 * element is the string before the first token, the second element
	 * is the first token (without the delim's), the third element is plain
	 * text again and so on.
	 */
	private List<String> tokenize( String s ) {
		List<String> tokens = []
		int sIndex = 0
		while (true) {
			// Is there another '%('?
			int nextTokenStart = s.indexOf( '%(', sIndex )
			int nextTokenEnd = -1
			if (nextTokenStart >= sIndex) {
				nextTokenEnd = s.indexOf( ')%', nextTokenStart )
			}
			if (nextTokenEnd == -1) {
				// No more tokens found - return rest of string and done
				tokens << s.substring(sIndex)
				break
			} else {
				String plainText = ''
				if (nextTokenStart > sIndex) {
					plainText = s.substring( sIndex, nextTokenStart )
				}
				tokens << plainText
				
				tokens << s.substring( nextTokenStart + 2, nextTokenEnd )
				
				sIndex = nextTokenEnd + 2
			}
		}
		return tokens
	}
	
	/**
	 * Sets the Base Environment Name, which is the requested environment name without
	 * any suffix, such as for blue-green.  Note that this is inherited by the contexts -
	 * so if it isn't defined by a context, that context uses its parent context value.
	 */
	public void setBaseEnvironmentName( String name ) {
		_baseEnvironmentName = name
	}
	
	/**
	 * Returns the Base Environment Name, which is the requested environment name without
	 * any suffix, such as for blue-green.  If this context does not have a base
	 * environment name, then it searches its parent's for a value.  Returns empty
	 * string if not found at all.
	 */
	public String getBaseEnvironmentName() {
		if (_baseEnvironmentName) {
			return _baseEnvironmentName
		} else if (getParentContext()) {
			return getParentContext().getBaseEnvironmentName()
		} else {
			return ''
		}
	}
	
	/**
	 * Returns a multiple line string describing this context and its child context's for
	 * debugging.
	 */
	public String getContextInfoForDebugging( String indent = '', String tab='  ' ) {
		String retval = ''
		retval = retval + indent + "Context Contents:" + "\n"
		if (_application) {
			retval = retval + indent + tab + "Application: " + _application.getName() + "\n"
		} else {
			retval = retval + indent + tab + "no application" + "\n"
		}
		// List<AwsProductInstancePlaceholdera> _awsResourceInstances
		_awsProductInstancePlaceholders.each { AwsProductInstancePlaceholder resourceInstance ->
			retval = retval + indent + tab + "AwsProductInstancePlaceholder: " + resourceInstance.getName() + "\n"
		}
		// 	protected List<ProvisionContext> _childContexts = []
		_childContexts.each { ProvisionContext child ->
			retval = retval + indent + tab + "Child Context..." + "\n"
			retval = retval + child.getContextInfoForDebugging(indent+tab+tab, tab) + "\n"
		}
		
		return retval
	}

	/**
	 * Adds an existing AWS Product Instance to this Context.  Note that this verifies that the Product Instance exists.  This also displays
	 * appropriate log messages.
	 * @param productInstance An AwsProductInstance for the existing Product.
	 * @param provisioned Was these instance provisioned by the Provisioning module?  If false, then it was provisioned outside of UCD and passed
	 * in as an available Instance.
	 * @param onlyAddIfExistingPlaceholder Only add if there is an existing placeholder for this logicalName.  Otherwise, simply ignore
	 */
	public void addExistingAwsProductInstanceToContext( String logicalName, AwsProductInstance productInstance, boolean provisioned, boolean onlyAddIfExistingPlaceholder ) {
		// Verify that the Product Instance exists
		if (! productInstance.doesExist()) {
			String msg = "Ignoring existing AWS Product Instance with the ID of ${productInstance.getProvisionedProductId()} mapped to logical provisioning name of ${logicalName} because it can't be found in AWS"
			Logger.info(msg)
			SummaryReport.getInstance().addLine(msg,SummaryReport.EXISTING_AWS_INSTANCES_SECTION)
		} else {
			AwsProductInstancePlaceholder existingPlaceholder = this.findContextSpecificAwsProductInstancePlaceholder(logicalName)
			if (existingPlaceholder) {
				// There is a placeholder, but only update it if it doesn't have a Product Instance yet.
				if (! existingPlaceholder.awsServiceInstance) {
					Logger.info "Setting template defined '${logicalName}' for the ${this.getContextName()} to the existing AWS Product Instance named ${productInstance.getName()}"
					existingPlaceholder.awsServiceInstance = new AwsServiceInstance(existingPlaceholder.getAwsServiceDefinition(), productInstance, provisioned)
					SummaryReport.getInstance().addExistingProductInstance(existingPlaceholder, this)
				}
			} else if (! onlyAddIfExistingPlaceholder) {
				Logger.info "Setting '${logicalName}' (which is not in the template) for the ${this.getContextName()} to the existing AWS Product Instance named ${productInstance.getName()}"
				AwsProductInstancePlaceholder placeholder = new AwsProductInstancePlaceholder(logicalName, new AwsServiceInstance(null,productInstance,provisioned))
				this.addAwsProductInstancePlaceholder(placeholder)
				SummaryReport.getInstance().addExistingProductInstance(placeholder, this)
			}
		}
	}
}
