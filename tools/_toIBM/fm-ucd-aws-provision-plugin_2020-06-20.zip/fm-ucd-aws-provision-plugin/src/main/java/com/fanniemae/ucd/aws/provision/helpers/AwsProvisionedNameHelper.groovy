package com.fanniemae.ucd.aws.provision.helpers

/**
 * <p>When creating the AWS Service Instances in AWS, we defined the
 * 'Provisioned Name' for each instance.  The pattern that we use is
 * '[ucdComponentName]-[dateTimeStamp]-[counter]', where ...</p>
 * <ul>
 * <li>ALL of the instances created as a set have the same 'dateTimeStamp'.</li>
 * <li>The counter starts at 1 for each componentName is is incremented.  Each
 * [ucdComponentName] has its own counter.</li>
 * </ul>
 * <p>This is a singleton class</p>
 * @author s9ulcc
 *
 */
class AwsProvisionedNameHelper {
	private static AwsProvisionedNameHelper _instance = new AwsProvisionedNameHelper()
	
	/**
	 * The current timestamp or null if there is no current timestamp.
	 */
	private String _timestamp = null
	
	/**
	 * Counter value for each component name.  The map key is the
	 * name of a UCD Component.  The value is 'int counter' - the last used value of the counter
	 * for the component.
	 */
	private Map _componentCounter = [:] 
	
	/**
	 * Private constructor.
	 */
	private AwsProvisionedNameHelper() {
		
	}
	
	public static AwsProvisionedNameHelper getInstance() {
		return _instance
	}
	
	/**
	 * Assigns a new timestamp used for all subsequent calls.  This
	 * also resets all of the counters (since they are timestamp specific).
	 * This does NOT need to be called unless you want to start a new
	 * timestamp.
	 */
	public void setNewTimestamp() {
		String newStamp = (new Date()).format("yyyy.MM.dd.hh.mm")
		// Only reset the counters if the timestamp has changed
		if (_timestamp && (_timestamp!=newStamp)) {
			_componentCounter = [:]
		}
		_timestamp = newStamp
	} 
	
	/**
	 * Returns the next Provisioned Name to use for the given ucdComponentName.
	 * If there is no current timestamp, then this automatically starts a
	 * new timestamp.
	 */
	public String getProvisionedName( String awsProposedProvisionName ) {
		return awsProposedProvisionName
//		if (! _timestamp) {
//			setNewTimestamp()
//		}
//		if (! (_componentCounter.containsKey(awsProposedProvisionName))) {
//			_componentCounter[awsProposedProvisionName] = 0
//		}
//		++_componentCounter[awsProposedProvisionName]
//		return awsProposedProvisionName + "-" + _timestamp + "-" + _componentCounter[awsProposedProvisionName]
	}
}
