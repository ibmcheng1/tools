package com.fanniemae.provision.ucd.persistence

import com.fanniemae.common.string.SimpleEncryption
import com.ibm.css.ucd.environment.Environment

import groovy.json.JsonSlurper

/**
 * <p>Retrieve persistent Provisioning Data including...</p>
 * <ul>
 * <li>Provisioning blue/green or stand-alone environment</li>
 * <li>The stand-alone environment or blue/green environment(s)</li>
 * <li>The associated AWS Product Instances including predefined and provisioned</li> 
 * </ul>
 * @author s9ulcc
 *
 */
class PersistentProvisionData {
	
	private static final String AWSPROVISIONDATA_FIELDNAME = 'awsProvisionData'
	private static final String BLUEGREEN_FIELDNAME = 'pairedBlueGreenEnvironment'
	
	protected boolean _isBlueGreen = false		// Is this a blue/green configuration
	protected Environment _standAloneEnvironment		// The environment if stand-alone (non-blue/green)
	protected Environment _blueEnvironment = null		// blue environment, which may be null
	protected Environment _greenEnvironment = null		// green environment, which may be null
	
	protected String _awsAccountId = ''
	protected String _awsRole = ''
	
	protected List<PersistentAwsProductInstanceData> _standAloneAwsProductInstances = []
	protected List<PersistentAwsProductInstanceData> _sharedAwsProductInstances = []
	protected List<PersistentAwsProductInstanceData> _blueAwsProductInstances = []
	protected List<PersistentAwsProductInstanceData> _greenAwsProductInstances = []
	
	/**
	 * Return list (of type PersistentAwsProductInstanceData) of the stand alone AWS Product
	 * Instances - from previous runs of provisioning this environment.
	 * @return
	 */
	public List<PersistentAwsProductInstanceData> getStandAloneAwsProductInstances() {
		return _standAloneAwsProductInstances
	}
	
	/**
	 * Return list (of type PersistentAwsProductInstanceData) of the shared AWS Product
	 * Instances - from previous runs of provisioning this environment.
	 * @return
	 */
	public List<PersistentAwsProductInstanceData> getSharedAwsProductInstances() {
		return _sharedAwsProductInstances
	}
	
	/**
	 * Return list (of type PersistentAwsProductInstanceData) of the blue AWS Product
	 * Instances - from previous runs of provisioning this environment.
	 * @return
	 */
	public List<PersistentAwsProductInstanceData> getBlueAwsProductInstances() {
		return _blueAwsProductInstances
	}
	
	/**
	 * Return list (of type PersistentAwsProductInstanceData) of the green AWS Product
	 * Instances - from previous runs of provisioning this environment.
	 * @return
	 */
	public List<PersistentAwsProductInstanceData> getGreenAwsProductInstances() {
		return _greenAwsProductInstances
	}

//	/**
//	 * List of AWS Products provisioned for this environment including
//	 * environment specific AND shared Product Instances.  But, if this
//	 * is a Blue or Green environment, this list does NOT contain the
//	 * Product Instances that are specific to the sibling blue/green
//	 * environment.
//	 */
//	protected List _awsResourceList = []	
	
//	/**
//	 * 
//	 * 
//	 * Populates this class' data from an existing Environment Context.  Note that this constructor basically takes
//	 * a snapshot of the current context data.  If the context data changes, such as provisioning additional
//	 * AWS Products, then you must call this constructor again.
//	 * @param environmentContext A ProvisionContext that corresponds to a specific environment.  Specifically,
//	 * the base environment or blue or green.
//	 */
//	public PersistentProvisionData( ProvisionContext environmentContext ) {
//		_environment = environmentContext.getEnvironment()
//		_blueGreen = environmentContext.isProvisioningBlueGreen()
//		if (_blueGreen) {
//			BaseEnvironmentProvisionContext baseContext = environmentContext.getRootContext()
//			ProvisionContext blueContext = baseContext.get_blueChildContext()
//			_blueEnvironment = blueContext.getEnvironment()
//			ProvisionContext greenContext = baseContext.get_blueChildContext()
//			_greenEnvironment = greenContext.getEnvironment()
//		}
//		environmentContext.getInheritedAwsResourceInstances().each { AwsResourceInstanceContextData awsInstanceData ->
//			if (awsInstanceData.awsServiceInstance) {
//				String logicalName = awsInstanceData.awsServiceDefinition.name
//				AwsServiceInstance serviceInstance = awsInstanceData.awsServiceInstance
//				if (serviceInstance) {
//					String provisionedName = serviceInstance.getProvisionedName()
//					String provisionedId = serviceInstance.getProvisionedId()
//					boolean isProvisioned = serviceInstance.isNewlyProvisioned()
//					_awsResourceList << [name: logicalName, provisionedProductName : provisionedName, provisionedProductId: provisionedId, provisioned:isProvisioned]
//				}
//			}
//		}
//	}
	
	/**
	 * <p>Constructor, which, given an existing provisioned environment, load all of the provision data.  Note that the
	 * existing environment may be stand-alone, blue or green.  If the environment is blue or green, then
	 * all of the blue AND green environment information is loaded.<pp>
	 * <p>The data may be in an obsolete format which has two Environment Property fields</p>
	 * <ul>
	 * <li>'awsResources' - JSON List. Each member of the list is a Map with the following fields:</li>
	 * 		<ul>
	 * 		<li>name - The logical name of the AWS Product Instance from the Template.</li>
	 *		<li>provisionedProductName - The AWS instance name.</li>
	 *		<li>provisionedProductId - The AWS instance ID.</li>
	 *		<li>boolean provisioned - Was this AWS Product Instance provisioned or was it pre-existing.</li>
	 * 		</ul>
	 * <li>pairedBlueGreenEnvironment - This is ONLY defined if a blue-green pair of UCD Environments was
	 * provisioned.  This environment is one half of the blue/green pair.  This field contains the UCD Environment
	 * name of the other half of the blue/green pair of environments.</li> 
	 * </ul>
	 * <p>The current format is a JSON Map field named '<b>awsProvisionData</b>'.  If the field starts with the
	 * letters 'en', then the rest of the field contains an encoded version of the JSON string, otherwise
	 * the field is a non-encoded JSON string.  The JSON Map currently contains the following fields:</p> 
	 * <ul>
	 * <li>baseEnvironmentName - The base environment name - without any blue/green or () suffixes.</li>
	 * <li>'awsResources' - JSON List. Each member of the list is a Map with the following fields:</li>
	 * 		<ul>
	 * 		<li>name - The logical name of the AWS Product Instance from the Template.</li>
	 *		<li>provisionedProductName - The AWS instance name.</li>
	 *		<li>provisionedProductId - The AWS instance ID.</li>
	 *		<li>boolean provisioned - Was this AWS Product Instance provisioned or was it pre-existing.</li>
	 *		<li>boolean shared - Is this AWS Product Instance shared by multiple (aka blue/green) environments.</li>
	 * 		</ul>
	 * <li>boolean isBlueGreen - Is this part of a blue/green environment?</li>
	 * <li>standAloneEnvironment is a JSON Map describing the stand-alone environment with the following fields:</li>
	 * 		<ul>
	 * 		<li>id - The ID of the environment</li>
	 * 		<li>name - The name of the environment without any '()' suffix, such as 'DEV-A'</li>
	 * 		</ul>
	 * <li>blueEnvironment is a JSON Map describing the 'blue' environment with the following fields:</li>
	 * 		<ul>
	 * 		<li>id - The ID of the environment</li>
	 * 		<li>name - The name of the environment without any '()' suffix, such as 'DEV-A'</li>
	 * 		</ul>
	 * <li>greenEnvironment is a JSON Map describing the 'green' environment with the following fields:</li>
	 * 		<ul>
	 * 		<li>id - The ID of the environment</li>
	 * 		<li>name - The name of the environment without any '()' suffix, such as 'DEV-A'</li>
	 * 		</ul>
	 * <li>awsAuthentication is an optional field describing the last AWS authentication data used.  It
	 * is a JSON Map with the following fields.</li>
	 * 		<ul>
	 * 		<li>accountId - The AWS account ID used last</li>
	 * 		<li>role - The AWS Role used last</li>
	 * 		</ul>
	 * </ul>
	 * @param environment Existing environment
	 */
	public PersistentProvisionData( Environment environment ) {
		// Try to load the newer 'awsProvisionData' field
		if (environment.hasAdHocProperty(AWSPROVISIONDATA_FIELDNAME)) {
			String awsProvisionDataString = SimpleEncryption.decodeString( environment.getAdHocProperty(AWSPROVISIONDATA_FIELDNAME) )
			Map awsProvisionData = new JsonSlurper().parseText(awsProvisionDataString)
			if (awsProvisionData.containsKey('awsAuthentication')) {
				_awsAccountId = awsProvisionData.awsAuthentication.accountId
				_awsRole = awsProvisionData.awsAuthentication.role
			}
			_isBlueGreen = awsProvisionData.isBlueGreen
			if (_isBlueGreen) {
				_blueEnvironment = environment.getApplication().getEnvironmentById(awsProvisionData.blueEnvironment.id)
				_greenEnvironment = environment.getApplication().getEnvironmentById(awsProvisionData.greenEnvironment.id)
				
				// Load the existing blue, green and shared AWS Products
				Map blueAwsProvisionData
				Map greenAwsProvisionData
				if (_blueEnvironment.id == environment.id) {
					blueAwsProvisionData = awsProvisionData
					greenAwsProvisionData = new JsonSlurper().parseText( SimpleEncryption.decodeString(_greenEnvironment.getAdHocProperty(AWSPROVISIONDATA_FIELDNAME)) )
				} else {
					greenAwsProvisionData = awsProvisionData
					blueAwsProvisionData = new JsonSlurper().parseText( SimpleEncryption.decodeString(_blueEnvironment.getAdHocProperty(AWSPROVISIONDATA_FIELDNAME)) )
				}
				blueAwsProvisionData.awsResources.each { Map entry ->
					if (entry.shared) {
						_sharedAwsProductInstances << new PersistentAwsProductInstanceData(name:entry.name, provisionedProductName:entry.provisionedProductName,
							provisionedProductId:entry.provisionedProductId, provisioned:entry.provisioned)
					} else {
						_blueAwsProductInstances << new PersistentAwsProductInstanceData(name:entry.name, provisionedProductName:entry.provisionedProductName,
							provisionedProductId:entry.provisionedProductId, provisioned:entry.provisioned)
					}
				}
				greenAwsProvisionData.awsResources.each { Map entry ->
					if (! entry.shared) {
						_greenAwsProductInstances << new PersistentAwsProductInstanceData(name:entry.name, provisionedProductName:entry.provisionedProductName,
							provisionedProductId:entry.provisionedProductId, provisioned:entry.provisioned)
					}
				}
				
			} else {
				_standAloneEnvironment = environment
				awsProvisionData.awsResources.each { Map entry ->
					_standAloneAwsProductInstances << new PersistentAwsProductInstanceData(name:entry.name, provisionedProductName:entry.provisionedProductName,
						provisionedProductId:entry.provisionedProductId, provisioned:entry.provisioned)
				}
			}
			// TODO
		} else {
			// Try to load older 'pairedBlueGreenEnvironment' and 'awsResources' fields
			if (environment.hasAdHocProperty(BLUEGREEN_FIELDNAME)) {
				String pairedEnvironmentName = environment.getAdHocProperty(BLUEGREEN_FIELDNAME)
				_isBlueGreen = true
				if (environment.name.contains('-b')) {
					_greenEnvironment = environment
				} else {
					_blueEnvironment = environment
				}
				if (environment.getApplication().doesEnvironmentExist(pairedEnvironmentName)) {
					if (_blueEnvironment) {
						_greenEnvironment = environment.getApplication().getEnvironment(pairedEnvironmentName)
					} else {
						_blueEnvironment = environment.getApplication().getEnvironment(pairedEnvironmentName)
					}
				}
			} else {
				_standAloneEnvironment = environment
			}
			loadOldStyleAwsProductInstanceData()
		}
	}
	
	/**
	 * <p>Load 'old style' persistent AWS Product Instance data from the environment(s).
	 * In the old style, an adhoc environment property named awsResource contains the list of
	 * Product Instance data for each type of environment (stand-alone, blue, green).  The List elements
	 * are maps with the following fields:</p>
	 * 		<ul>
	 * 		<li>name - The logical name of the AWS Product Instance from the Template.</li>
	 *		<li>provisionedProductName - The AWS instance name.</li>
	 *		<li>provisionedProductId - The AWS instance ID.</li>
	 *		<li>boolean provisioned - Was this AWS Product Instance provisioned or was it pre-existing.</li>
	 * 		</ul>
	 * <p>Note that within a blue/green set of environments, the shared Product Instances are NOT
	 * flagged with data.  Instead, the two lists have to be compared.  If the same Product Instance is
	 * in both Blue and Green, then it is shared</P 
	 */
	private void loadOldStyleAwsProductInstanceData() {
		if (_standAloneEnvironment) {
			_standAloneAwsProductInstances = loadOldStyleAdHocAwsResourcesForEnvironment(_standAloneEnvironment)
		} else {
			List<PersistentAwsProductInstanceData> blueAwsProductInstances = []
			List<PersistentAwsProductInstanceData> greenAwsProductInstances = []
			if (_blueEnvironment) {
				blueAwsProductInstances = loadOldStyleAdHocAwsResourcesForEnvironment(_blueEnvironment)
			}
			if (_greenEnvironment) {
				greenAwsProductInstances = loadOldStyleAdHocAwsResourcesForEnvironment(_greenEnvironment)
			}
			// Separate the common product instances by looking for ones in both blue and green lists
			blueAwsProductInstances.each { PersistentAwsProductInstanceData blueEntry ->
				PersistentAwsProductInstanceData matchingEntry = greenAwsProductInstances.find { PersistentAwsProductInstanceData greenEntry ->
					return (blueEntry.provisionedProductId == greenEntry.provisionedProductId)
				}
				if (matchingEntry) {
					_sharedAwsProductInstances << blueEntry
				} else {
					_blueAwsProductInstances << blueEntry
				}
			}
			greenAwsProductInstances.each { PersistentAwsProductInstanceData greenEntry ->
				PersistentAwsProductInstanceData matchingEntry = _sharedAwsProductInstances.find { PersistentAwsProductInstanceData sharedEntry ->
					return (sharedEntry.provisionedProductId == greenEntry.provisionedProductId)
				}
				if (! (matchingEntry)) {
					_greenAwsProductInstances << greenEntry
				}
			}
		}
	}
	
	/**
	 * Loads the old style ad-hoc 'awsResources' field list for one UCD environment and returns
	 * it as a List of type PersistentAwsProductInstanceData.
	 */
	private List<PersistentAwsProductInstanceData> loadOldStyleAdHocAwsResourcesForEnvironment( Environment environment ) {
		List<PersistentAwsProductInstanceData> awsProductInstances = []
		if (environment.hasAdHocProperty('awsResources')) {
			String awsResourcesJson = environment.getAdHocProperty('awsResources')
			List awsResourcesList = new JsonSlurper().parseText(awsResourcesJson)
			awsResourcesList.each { Map entry ->
				awsProductInstances << new PersistentAwsProductInstanceData(name:entry.name, provisionedProductName:entry.provisionedProductName, 
					provisionedProductId:entry.provisionedProductId, provisioned:entry.provisioned)
			}
		}
		return awsProductInstances
	}
	
	
	/**
	 * Is this persistent data for a blue-green set of environments?
	 */
	public boolean isBlueGreen() {
		return _isBlueGreen
	}
	
	/**
	 * Returns the persisted AWS account ID or an empty string.
	 */
	public String getAwsAccountId() {
		return _awsAccountId
	}
	
	/**
	 * Returns the persisted AWS Role or an empty string.
	 */
	public String getAwsRole() {
		return _awsRole
	}

	/**
	 * Returns the stand-alone (non blue/green) environment or null if it doesn't exist.
	 */
	public Environment getStandAloneEnvironment() {
		return _standAloneEnvironment
	}
	
	/**
	 * Returns existing blue environment or null.
	 * @return
	 */
	public Environment getBlueEnvironment() {
		return _blueEnvironment
	}
	
	/**
	 * Returns existing greeb environment or null.
	 * @return
	 */
	public Environment getGreenEnvironment() {
		return _greenEnvironment
	}
}
