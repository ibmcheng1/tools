package com.fanniemae.ucd.aws.api.cloudformation.model

import com.fanniemae.ucd.aws.api.cloudformation.AwsCloudformation
import com.ibm.issr.core.CommandRunner

import groovy.json.JsonSlurper

/**
 * Represents one Cloudformation Stack.
 * @author s9ulcc
 *
 */
class CloudformationStack {
	/**
	 * The AWS Cloudformation
	 */
	protected AwsCloudformation _awsCloudformation

	/**
	 * The id (which is the ARN) of the stack.
	 */
	protected String _id
	
	/**
	 * Cached call to 'aws cloudformation describe-stacks' for this stack.
	 */
	protected Map _cachedDescribeStack = null
	
	/**
	 * Constructor.
	 * @param awsCloudformation The AWS Cloudformation API handle.
	 * @param id The ID (or ARN) of the stack.
	 */
	public CloudformationStack( AwsCloudformation awsCloudformation, String id ) {
		this._awsCloudformation = awsCloudformation
		this._id = id
	}
	
	
	/**
	 * Returns a Map of the stack specific data returned by calling 'run aws cloudformation describe-stack-events ...'.
	 * For example, the Map includes the fields StackId, StackName and Description.
	 * @return
	 */
	public Map describeStack( boolean resetCache = false ) {
		if (resetCache || _cachedDescribeStack == null) {
			CommandRunner commandRunner = _awsCloudformation.awsConnection.executeAwsCliCommand("""aws cloudformation describe-stacks --stack-name ${this._id}""")
			if (! commandRunner.wasSuccessful()) {
				throw new Exception( "AWS API call to 'aws cloudformation describe-stack-events' failed" )
			}
			_cachedDescribeStack = (new JsonSlurper()).parseText( commandRunner.getConsoleOutput() ).Stacks[0]
		}
		return _cachedDescribeStack
	}
	
	
	/**
	 * Returns the description of this stack.
	 */
	public String getDescription( boolean resetCache = false ) {
		Map stackData = describeStack(resetCache)
		if (stackData && stackData.containsKey('Description')) {
			return stackData.Description
		} else {
			return ''
		}
	}
	
	
	
	/**
	 * Iterates cloudformation stack events from newest to oldest.
	 * @param processEvent The closure that is called.  Signature is
	 * 'void processEvent( Map event )' where the event is one
	 * event returned from the AWS cloudformation describe-stack-events call.
	 * See https://docs.aws.amazon.com/cli/latest/reference/cloudformation/describe-stack-events.html for
	 * details and example output.
	 */
	public void describeEachStackEvent( Closure processEvent ) {
		boolean anotherPage = true
		String startingTokenParam = ''
		while (anotherPage) {
			anotherPage = false
			CommandRunner commandRunner = _awsCloudformation.awsConnection.executeAwsCliCommand("""aws cloudformation describe-stack-events --stack-name ${this._id} ${startingTokenParam}""")
			if (! commandRunner.wasSuccessful()) {
				throw new Exception( "AWS API call to 'aws cloudformation describe-stack-events' failed" )
			}
			Map results = (new JsonSlurper()).parseText( commandRunner.getConsoleOutput() )
			results.StackEvents.each { Map stackEvent ->
				processEvent( stackEvent )
			}
			if (results.containsKey('NextToken')) {
				anotherPage = true
				startingTokenParam = "--starting-token " + results.NextToken
			}
		}
	}
}
