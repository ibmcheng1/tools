package com.fanniemae.ucd.aws.provision.spec

import com.fanniemae.ucd.aws.api.services.servicecatalog.AwsServiceCatalog
import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProduct
import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProductVersion
import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProvisionProductInputFieldDef
import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProvisionProductInputTagDef
import com.fanniemae.ucd.aws.provision.def.common.ConfigFileWrapper
import com.fanniemae.ucd.aws.provision.def.common.ErrorAccumulator
import com.fanniemae.ucd.aws.provision.service.definition.AwsServiceDefinition

/**
 * This class wraps an AWS Specification/Manifest JSON into classes.
 * This class represents the entire specification.
 * @author s9ulcc
 *
 */
class AwsSpecification extends ConfigFileWrapper {
	AwsServiceCatalog _awsServiceCatalog
	
	// Member data
	private String _description = ''
	// The list of service definitions
	private List<AwsServiceDefinition> _serviceDefinitions = []
	
	// This is an indexed list of the entries.  It is used to check for duplicate names
	// the Key is an entry's Name and the value is list entry
	private Map<String,Map> _indexedEntries = [:]

	
	/**
	 * Constructor.  Note that more complex/expensive verification, such as looking up UCD Components,
	 * are performed as needed.  Call the function performFullVerification() to force full verification. 
	 * @param specification The specification as a JSON string.
	 */
	public AwsSpecification( AwsServiceCatalog awsServiceCatalog, ErrorAccumulator errors ) {
		super(errors)
		_awsServiceCatalog = awsServiceCatalog
	}
	
	/**
	 * Loads the template from the parsed JSON.
	 * @param templateRoot The root node of the 'awsTemplate' branch of the template.
	 */
	public void loadTemplate( Map templateRoot ) {
		if (templateRoot.containsKey('description')) {
			_description = templateRoot.description
		}
		if ((! templateRoot.containsKey('provisionProducts')) || templateRoot.provisionProducts.size()==0) {
			// tagValidationError( "The template is missing the required 'provisionProducts' entry within 'awsTemplate' section." )
		} else {
			List items = templateRoot.provisionProducts
			int itemNumber = 0
			items.each { Map configItem ->
				++itemNumber
				processProvisionProductEntry(itemNumber, configItem)
			}
		}
	}

	/**
	 * Process one entry from the 'provisionProducts' list.
	 * @param itemNumber The one-based entry number. This is useful for error messages. 
	 * @param configItem The entry from the 'provisionProducts' list.
	 */
	private void processProvisionProductEntry(int itemNumber, Map configItem) {
		if (! configItem.containsKey('name')) {
			tagValidationError( "Entry number ${itemNumber} within the template's '/awsTemplate/provisionProducts' section is missing required 'name' field")
		} else {
			String configName = configItem.name
			// check for duplicate name
			if (_indexedEntries.containsKey(configName)) {
				tagValidationError( "Multiple entries in the awsTemplate have the same name of '${configName}'")
			} else {
				// Add this name to the indexed entries
				_indexedEntries[configName] = configItem
			}
			if (! configItem.containsKey('awsProductName')) {
				tagValidationError( "The entry named '${configName}' within the template's '/awsTemplate/provisionProducts' section is missing required 'awsProductName' field")
			} else {

				// Get and validate the aws product name
				String awsProductName = configItem.awsProductName
				if (! _awsServiceCatalog.hasProductByName(awsProductName)) {
					tagValidationError( "No AWS Catalog Product named '${awsProductName}' can be found." )
				} else {
					AwsProduct awsProduct = _awsServiceCatalog.getProductByName(awsProductName)

					// Get the current or desired version
					AwsProductVersion awsProductVersion = null
					if (configItem.containsKey('awsVersionName')) {
						String versionName = configItem.awsVersionName
						if (! awsProduct.hasVersionByName(versionName)) {
							tagValidationError( "The AWS Catalog Product named '${awsProductName}' does not have the request version of '${versionName}'")
						} else {
							awsProductVersion = awsProduct.getVersionByName(versionName)
						}
					} else {
						awsProductVersion = awsProduct.getNewestVersion()
					}
					
					if (awsProductVersion) {
						boolean participateInBlueGreen = false
						if (configItem.containsKey('participateInBlueGreen')) {
							participateInBlueGreen = configItem.participateInBlueGreen
						}
						
						//-----------------------------
						// Finally - define the provision definition
						//-----------------------------
						AwsServiceDefinition serviceDefinition = new AwsServiceDefinition(configName, awsProductVersion, participateInBlueGreen)
						if (configItem.containsKey('awsName')) {
							serviceDefinition.setAwsName(configItem.awsName)
						}
						
						processProperties( configItem, awsProductVersion, serviceDefinition )
						processTags( configItem, awsProductVersion, serviceDefinition )
						
						_serviceDefinitions << serviceDefinition
					}

				}
			}
		}
	}
	
	/**
	 * Processes the input property definitions for one catalog product provision definition
	 * @param configItem The entry from the 'provisionProducts' list in the JSON template.
	 * @param awsProductVersion The AWS Product Version that will be provisioned.
	 * @param serviceDefinition The configuration of the provisioning of the product version.
	 */
	protected void processProperties( Map configItem, AwsProductVersion awsProductVersion, AwsServiceDefinition serviceDefinition ) {
		String configItemName = configItem.name
		if (! configItem.containsKey('awsProperties')) {
			tagValidationError( "In the configuration template, the AWS product named '${configItemName}' is missing the mandatory 'awsProperties' list.")
		} else {
			Map configProperties = configItem.awsProperties
			
			List<AwsProvisionProductInputFieldDef> awsInputs = awsProductVersion.getInputFields()
			
			// Make sure that every AWS input has a corresponding template input
			// Also build an index map of the AWS inputs - key = input name, value = the input field def
			Map<String,AwsProvisionProductInputFieldDef> indexedMapOfAwsInputs = [:]
			awsInputs.each { AwsProvisionProductInputFieldDef awsInput ->
				// Add this entry to the indexed map
				indexedMapOfAwsInputs[awsInput.getName()] = awsInput
				// verify that an input is defined
				if (! configProperties.containsKey(awsInput.getName())) {
					tagValidationError( "The template configuration for an AWS Product named '${configItemName}' is missing the AWS Property '${awsInput.getName()}'")
				}
			}
			
			// Now iterate the template inputs.  Test to make sure that each one is valid.  If so, add it to the serviceDefinition
			configProperties.each { String propertyName, String propertyValue ->
				if (! indexedMapOfAwsInputs.containsKey(propertyName)) {
					tagValidationError( "The template configuration for an AWS Product named '${configItemName}' contains an awsProperty named '${propertyName}', which is NOT an input for the Catalog Product")
				} else {
					serviceDefinition.addPropertyField(propertyName, propertyValue)
				}
			}
		}
	}
	
	/**
	 * Processes the input tag definitions for one catalog product provision definition
	 * @param configItem The entry from the 'provisionProducts' list in the JSON template.
	 * @param awsProductVersion The AWS Product Version that will be provisioned.
	 * @param serviceDefinition The configuration of the provisioning of the product version.
	 */
	protected void processTags( Map configItem, AwsProductVersion awsProductVersion, AwsServiceDefinition serviceDefinition ) {
		String configItemName = configItem.name
		if (configItem.containsKey('awsTags')) {
			Map configTags = configItem.awsTags
			
			List<AwsProvisionProductInputTagDef> awsTags = awsProductVersion.getInputTags()
			
			// Make sure that every required AWS tag has a corresponding template tag.
			// A tag is required if it has more than one value option.
			// Also build an index map of the AWS tags - key = tag name, value = the input field def
			Map<String,AwsProvisionProductInputTagDef> indexedMapOfAwsTags = [:]
			awsTags.each { AwsProvisionProductInputTagDef awsTag ->
				// Add this entry to the indexed map
				indexedMapOfAwsTags[awsTag.getName()] = awsTag
				// Is this a required tag?
				boolean requiredTag = false
				if (awsTag.getValueList() && awsTag.getValueList().size()>1) {
					requiredTag = true
				}
				// verify that a tag is defined in the Template
				if (requiredTag && (! configTags.containsKey(awsTag.getName()))) {
					tagValidationError( "The template configuration for an AWS Product named '${configItemName}' is missing the required AWS Tag '${awsTag.getName()}'")
				}
			}
			
			// Now iterate the template inputs.  Test to make sure that each one is valid.  If so, add it to the serviceDefinition
			configTags.each { String propertyName, String propertyValue ->
//				if (! indexedMapOfAwsTags.containsKey(propertyName)) {
//					tagValidationError( "The template configuration for an AWS Product named '${configItemName}' contains an awsTag named '${propertyName}', which is NOT an input tag for the Catalog Product")
//				} else {
					serviceDefinition.addTag(propertyName, propertyValue)
//				}
			}
		}
	}

	/**
	 * Do any of the requested AWS Resource types support separate blue-green instances?
	 * @return
	 */
	public boolean doAnyRequestedAwsResourcesSupportBlueGreen() {
		AwsServiceDefinition serviceWithBlueGreen = _serviceDefinitions.find { AwsServiceDefinition serviceDefinition ->
			return serviceDefinition.shouldProvisionSeparateBlueGreenInstances()
		}
		return (serviceWithBlueGreen != null)
	}
	
	/**
	 * Returns the list of AWS Service Definitions.  Each list member is of type AwsServiceDefinition.
	 * @return
	 */
	public List<AwsServiceDefinition> getServiceDefinitions() {
		return _serviceDefinitions
	}
	
	/**
	 * Returns the description from the spec.  If not defined, this returns an empty string.
	 */
	public String getDescription() {
		return _description
	}
}
