package com.fanniemae.ucd.aws.api.services.servicecatalog.product

import com.fanniemae.ucd.aws.api.describeRecord.AwsDescribeRecordResult
import com.fanniemae.ucd.aws.api.services.servicecatalog.AwsServiceCatalog

import groovy.json.JsonOutput

/**
 * The API call to terminate a Catalog Product Instance returns a 'termination request tracking
 * record' which is used to track the termination request.  This is a class wrapper
 * for the 'termination request tracking record'. Note that if the termination request
 * is succesful, then the Product Instance 'record' in AWS is deleted, so an external record
 * is used to track the request.  That external record is NOT deleted when the
 * termination is successful.
 * @author s9ulcc
 *
 */
class AwsProductInstanceTerminationRequestRecord {

	private AwsServiceCatalog _awsServiceCatalog
	private Map _terminationRequestData
	
	/**
	 * Constructor
	 * @param awsServiceCatalog The AWS Service Catalog
	 * @param terminationRequestData The parsed data returned by the termination request.
	 */
	public AwsProductInstanceTerminationRequestRecord( AwsServiceCatalog awsServiceCatalog,
		Map terminationRequestData ) {
		this._awsServiceCatalog = awsServiceCatalog
		this._terminationRequestData = terminationRequestData
	}
	
	/**
	 * The toString() call returns the JSON contents (as a string).
	 */
	public String toString() {
		return "AwsProductInstanceTerminationRequestRecord: data=" + JsonOutput.toJson(_terminationRequestData)
	}
	
	/**
	 * Returns the RecordId of the termination request action object tracked by this class.
	 * @return
	 */
	public String getRecordId() {
		return _terminationRequestData.RecordDetail.RecordId
	}
	
	/**
	 * Returns the 'awscatalog describe-record' value for this termination request record.
	 * Note that the getStatus() of the Describe Record in the termination request progress status.
	 * Throws error on exception. 
	 * @return A class version of the described record.
	 */
	public AwsDescribeRecordResult describeRecord() {
		return _awsServiceCatalog.describeRecord( this.getRecordId(), false )
	}
}
