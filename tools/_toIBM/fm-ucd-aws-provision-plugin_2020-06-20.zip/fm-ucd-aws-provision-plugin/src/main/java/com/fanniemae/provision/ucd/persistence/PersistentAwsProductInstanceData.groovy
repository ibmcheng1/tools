package com.fanniemae.provision.ucd.persistence

/**
 * Persistent information about one AWS Product Instance as part of the
 * overall PersistenProvisionData class.
 * @author s9ulcc
 *
 */
class PersistentAwsProductInstanceData {
	/**
	 * The logical name of the AWS Product Instance as defined in the provision Template.
	 */
	public String name
	/**
	 * The AWS Product Instance name
	 */
	public String provisionedProductName
	/**
	 * The AWS Product Instance ID
	 */
	public String provisionedProductId
	/**
	 * Was this AWS Product Instance provisioned or was it pre-existing.
	 */
	public boolean provisioned
}
