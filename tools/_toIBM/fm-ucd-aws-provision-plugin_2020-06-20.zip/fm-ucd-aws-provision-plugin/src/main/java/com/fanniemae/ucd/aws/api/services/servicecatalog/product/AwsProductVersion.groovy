package com.fanniemae.ucd.aws.api.services.servicecatalog.product

import java.util.List

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.ucd.aws.api.services.servicecatalog.AwsServiceCatalog
import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.plugin.AbortPluginException

import groovy.json.JsonOutput
import groovy.json.JsonSlurper

/**
 * Represents one version of one product.
 * @author s9ulcc
 *
 */
class AwsProductVersion {
	/**
	 * The AWS Service Catalog
	 */
	protected AwsServiceCatalog _awsServiceCatalog
	
	protected AwsProduct _awsProduct
	protected String _name
	protected String _id
	protected BigDecimal _created		// when was the version created
	
	/**
	 * Cached list of AWS input fields for this version. 
	 */
	protected List<AwsProvisionProductInputFieldDef> _inputFields = null
	
	/**
	 * Cached list of AWS input tags for this version.
	 */
	protected List<AwsProvisionProductInputTagDef> _inputTags = null
	
	/**
	 * Cache the data from calling the AWS Catalog describe-provisioning-parameters call
	 */
	protected Map _cachedDescribeProvisioningParameters = null
	
	/**
	 * Constructor
	 * @param awsProduct The product that this is a version of.
	 * @param name The name of the version.
	 * @param id The AWS ID of the version.
	 * @param created When was the version created?
	 */
	public AwsProductVersion( AwsProduct awsProduct, String name, String id, BigDecimal created ) {
		_awsServiceCatalog = awsProduct.getAwsServiceCatalog()
		_awsProduct = awsProduct
		_name = name
		_id = id
		_created = created
	}
	
	/**
	 * Provisions a new instance of this Service Catalog Product Version.
	 * @param name The name of the new instance.
	 * @param inputs The input values.  This is a map where the keys are the AWS input fields and the values are the values.
	 * @param tags Tag values to set.  This is a map where the keys are the tag names and the values are the tag values.  This
	 * may be null or an empty map if there are no tags.
	 * @return Returns an AwsProductInstance.  Returns null if this fails.  If this fails, appropriate error messages are displayed to the console.
	 */
	public AwsProductInstance provisionProductInstance( String name, Map<String,String> inputs, Map<String,String> tags ) {
		Logger.debug( "called AwsProductVersion.provisionProductInstance()")

		// Create payload for 'inputs' parameters
		String parametersParam = ""
		if (inputs && inputs.size()> 0) {
			List parametersPayload = []
			inputs.each { String propertyName, String value ->
				parametersPayload << [Key:propertyName, Value:value]
			}
			Logger.debug "AWS Property Payload: " + parametersPayload
			File parametersPayloadFile = new File('awsCreateProps.json')
			parametersPayloadFile.text = JsonOutput.toJson(parametersPayload)
			parametersParam = "--provisioning-parameters file://${parametersPayloadFile.getCanonicalPath()}"
		}
		
		String tagsParam = ""
		if (tags && tags.size()>0) {
			List tagsPayload = []
			tags.each { String tagName, String tagValue ->
				tagsPayload << [Key:tagName, Value:tagValue]
			}
			Logger.debug "AWS Tags Payload: " + tagsPayload
			File tagsPayloadFile = new File('awsCreateTags.json')
			tagsPayloadFile.text = JsonOutput.toJson(tagsPayload)
			tagsParam = "--tags file://${tagsPayloadFile.getCanonicalPath()}"
		}
		
		AwsConnection awsConnection = _awsServiceCatalog.awsConnection
		CommandRunner commandRunner = awsConnection.executeAwsCliCommand("""aws servicecatalog provision-product --product-id "${awsProduct.id}" --provisioning-artifact-id "${this.id}"  --provisioned-product-name "${name}" ${parametersParam} ${tagsParam} --region ${awsConnection.getRegion()}""")
		if (! commandRunner.wasSuccessful()) {
			Logger.error "Failed to provision instance of AWS Catalog Product '${this.getAwsProduct().getName()}'"
			return null
		} else {
			String consoleOutput = commandRunner.getConsoleOutput()
			
			Map provisionedData = (new JsonSlurper()).parseText(consoleOutput)
			
			return new AwsProductInstance(getAwsServiceCatalog(), provisionedData.RecordDetail.ProvisionedProductId)
		}
	}
	
	/**
	 * Returns the list of input fields for this Product Version where each list entry is of type
	 * AwsProvisionProductInputFieldDef.  The data is cached on the first call.
	 */
	public List<AwsProvisionProductInputFieldDef> getInputFields() {
		if (_inputFields == null) {
			_inputFields = []
			if (_cachedDescribeProvisioningParameters == null) {
				AwsConnection awsConnection = _awsServiceCatalog.awsConnection
				CommandRunner commandRunner = awsConnection.executeAwsCliCommand("aws servicecatalog describe-provisioning-parameters --provisioning-artifact-id ${this.id} --product-id ${awsProduct.id} --path-id ${awsProduct.getDefaultAwsProductLaunchPath().id} --region ${awsConnection.getRegion()}")
				if (! commandRunner.wasSuccessful()) {
					throw new AbortPluginException( "AWS servicecatalog call failed")
				}
				_cachedDescribeProvisioningParameters = (new JsonSlurper()).parseText( commandRunner.getConsoleOutput() )
			}
			_cachedDescribeProvisioningParameters.ProvisioningArtifactParameters.each { Map entry ->
				String defaultValue = ''
				if (entry.containsKey('DefaultValue')) {
					defaultValue = entry.DefaultValue
				}
				String description = ""
				if (entry.containsKey('Description')) {
					description = entry.Description
				}
				List<String> valueList = null
				if (entry.containsKey('ParameterConstraints') && entry.ParameterConstraints.containsKey('AllowedValues') && entry.ParameterConstraints.AllowedValues.size()>0) {
					valueList = []
					entry.ParameterConstraints.AllowedValues.each { def constraint ->
						valueList << constraint.toString()
					}
				}
				String customLabel = ''
				if (_cachedDescribeProvisioningParameters.containsKey('UsageInstructions')) {
					Map metadataEntry = _cachedDescribeProvisioningParameters.UsageInstructions.find { Map usageEntry ->
						return usageEntry.Type == 'metadata'
					}
					if (metadataEntry) {
						String metadataString = metadataEntry.Value
						metadataString = metadataString.replaceAll( '\\\\"', '"' )
						Map metadata = (new JsonSlurper()).parseText( metadataString )
						if (metadata.containsKey('AWS::CloudFormation::Interface')) {
							Map interfaceMap = metadata['AWS::CloudFormation::Interface']
							if (interfaceMap.containsKey('ParameterLabels')) {
								Map parameterLabels = interfaceMap.ParameterLabels
								if (parameterLabels.containsKey(entry.ParameterKey)) {
									Map labelEntry = parameterLabels[entry.ParameterKey]
									if (labelEntry.containsKey('default')) {
										customLabel = labelEntry.default
									}
								}
							}
						}
					}
				}
				_inputFields << new AwsProvisionProductInputFieldDef(this, entry.ParameterKey, defaultValue, description, customLabel, valueList)
			}
			
		}
		return _inputFields
	}
	
	/**
	 * Returns the list of input tags for this Product Version where each list entry is of type
	 * AwsProvisionProductInputTagDef.  The data is cached on the first call.
	 */
	public List<AwsProvisionProductInputTagDef> getInputTags() {
		if (_inputTags == null) {
			_inputTags = []
			if (_cachedDescribeProvisioningParameters == null) {
				AwsConnection awsConnection = _awsServiceCatalog.awsConnection
				CommandRunner commandRunner = awsConnection.executeAwsCliCommand("aws servicecatalog describe-provisioning-parameters --provisioning-artifact-id ${this.id} --product-id ${awsProduct.id} --path-id ${awsProduct.getDefaultAwsProductLaunchPath().id} --region ${awsConnection.getRegion()}")
				if (! commandRunner.wasSuccessful()) {
					throw new AbortPluginException( "AWS servicecatalog call failed")
				}
				_cachedDescribeProvisioningParameters = (new JsonSlurper()).parseText( commandRunner.getConsoleOutput() )
			}
			_cachedDescribeProvisioningParameters.TagOptions.each { Map entry ->
				List<String> valueList = null
				if (entry.containsKey('Values')) {
					valueList = entry.Values
				}
				_inputTags << new AwsProvisionProductInputTagDef( this, entry.Key, valueList )
			}
			
		}
		return _inputTags
	}

	/**
	 * Returns the associated AwsServiceCatalog.
	 */
	public AwsServiceCatalog getAwsServiceCatalog() {
		return _awsServiceCatalog
	}
	
	/**
	 * Returns the AwsProduct that this is a version of.
	 */
	public AwsProduct getAwsProduct() {
		return _awsProduct
	}
	
	/**
	 * Returns this version's name
	 */
	public String getName() {
		return _name
	}
	
	/**
	 * Returns this version's id
	 */
	public String getId() {
		return _id
	}

	/**
	 * Returns the creation date/time of this version.
	 */
	public BigDecimal getCreated() {
		return _created
	}
}
