package com.fanniemae.ucd.aws.provision.def.components

import com.fanniemae.ucd.aws.provision.def.common.ConfigFileWrapper
import com.fanniemae.ucd.aws.provision.def.common.ErrorAccumulator
import com.fanniemae.ucd.aws.provision.def.components.data.UcdComponentDef
import com.ibm.css.ucd.agent.AgentOrAgentPool
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.services.ApplicationServices
import com.ibm.issr.core.log.Logger

/**
 * Stores UCD Template Definition information.
 */
class UcdTemplateDefinition extends ConfigFileWrapper {
	private ApplicationServices _applicationServices
	private Application _ucdApplication
	
	/**
	 * The list of defined components
	 */
	private List<UcdComponentDef> _components = []
	
	/**
	 * Constructor
	 * @param errors Used for reporting errors.
	 */
	public UcdTemplateDefinition( ErrorAccumulator errors, ApplicationServices applicationServices, Application ucdApplication ) {
		super(errors)
		_applicationServices = applicationServices
		_ucdApplication = ucdApplication
	}
	
	/**
	 * Load the UCD Template.
	 * @param ucdTemplate The parsed JSON for the ucdTemplate.
	 * @param ucdAgents The list of UCD Agents where the first is 'agent1', the second is 'agent2' and so on.
	 */
	public loadTemplate( Map ucdTemplate, List<AgentOrAgentPool> ucdAgents ) {
		if ((! ucdTemplate.containsKey('ucdComponents')) || ucdTemplate.ucdComponents.size()==0) {
			Logger.info "WARNING: The ucdComponentsDef file is missing 'ucdComponents' entries, so no UCD Components will be configured."
		} else {
			// As a convenience, convert ucdAgents from a List to an indexed Map
			Map<String,AgentOrAgentPool> indexedUcdAgents = [:]		// key = agent name, such as 'agent1'. value is the AgentOrAgentPool agent
			int agentIndex = 0
			ucdAgents.each { AgentOrAgentPool agent ->
				++agentIndex
				indexedUcdAgents['agent' + agentIndex] = agent
			}
			
			// Iterate the components in the template
			List items = ucdTemplate.ucdComponents
			int itemNumber = 0
			items.each { Map configItem ->
				++itemNumber
				_components << new UcdComponentDef( itemNumber, configItem, this, _applicationServices, _ucdApplication, indexedUcdAgents )
			}
		}
	}
	
	/**
	 * Do any of the listed components support blue-green configuration?
	 */
	public boolean doAnyComponentsSupportBlueGreen() {
		UcdComponentDef componentSupportingBlueGreen = _components.find { UcdComponentDef ucdComponentDef ->
			return ucdComponentDef.participateInBlueGreen
		}
		return (componentSupportingBlueGreen != null)
	}
	
	/**
	 * Returns the list of all member 'UcdComponentDef's
	 */
	public List<UcdComponentDef> getAllComponentDefs() {
		return _components
	}
	
	/**
	 * Returns the list of member 'UcdComponentDef's which support blue-green environments.
	 */
	public List<UcdComponentDef> getComponentDefsSupportingBlueGreen() {
		List<UcdComponentDef> componentDefs = []
		getAllComponentDefs().each { UcdComponentDef componentDef ->
			if (componentDef.participateInBlueGreen) {
				componentDefs << componentDef
			}
		}
		return componentDefs
	}
	
	/**
	 * Returns the list of member 'UcdComponentDef's which do NOT support blue-green environments.
	 */
	public List<UcdComponentDef> getComponentDefsNotSupportingBlueGreen() {
		List<UcdComponentDef> componentDefs = []
		getAllComponentDefs().each { UcdComponentDef componentDef ->
			if (! componentDef.participateInBlueGreen) {
				componentDefs << componentDef
			}
		}
		return componentDefs
	}
}
