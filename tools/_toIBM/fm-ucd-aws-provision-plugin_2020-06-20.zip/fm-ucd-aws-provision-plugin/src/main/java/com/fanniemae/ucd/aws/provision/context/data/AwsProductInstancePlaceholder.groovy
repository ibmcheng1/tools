package com.fanniemae.ucd.aws.provision.context.data

import com.fanniemae.ucd.aws.provision.service.definition.AwsServiceDefinition
import com.fanniemae.ucd.aws.provision.service.instance.AwsServiceInstance

/**
 * <p>Placeholder for one AWS Product Instance and/or Product Instance request definition.</p>
 * 
 * <p>If the Service Definition exists (isn't null), then this is a Product Instance
 * requested by the current Provisioning Template.  If the Service Instance is also defined,
 * then an instance of requested product exists (has been provisione).  That instance may
 * have already existed or it may have been provisioned in this plugin run.  If the
 * Service Instance doesn't exist, then it hasn't been provisioned yet OR it failed to
 * provision.<p>
 * <p>If the Service Instance exists but the Definition doesn't, then this is a Product
 * Instance created from a different template which is not in the current template.</p>
 * <p>The Service Definition and/or the Service Instance must be defined.
 */
class AwsProductInstancePlaceholder {
	// The logical name, which is required 
	private String _name
	/**
	 * If this placeholder was defined by a provisioning template, then
	 * this is the handle to the template's definition of the Product Instance request.
	 * Otherwise, this is an existing Product Instance and this field is null.
	 */
	private AwsServiceDefinition _awsServiceDefinition = null
	/**
	 * The AWS Product Instance reference.  This is null if there
	 * is no AWS Product Instance.
	 */
	private AwsServiceInstance _awsServiceInstance = null

	/**
	 * Constructor which is based on an AWS Product Instance request/definition.
	 * @param awsServiceDefinition The AWS Resource service definition.
	 * This is a specific configuration.  For example, if there are two
	 * different EBs, then there is a specific instance for each one.
	 */
	public AwsProductInstancePlaceholder( AwsServiceDefinition awsServiceDefinition ) {
		this._awsServiceDefinition = awsServiceDefinition
		this._name = awsServiceDefinition.getName()
	}
	
	
	/**
	 * Constructor which is based on an existing AWS Product Instance.
	 * @param name The logical name of the instance.
	 * @param awsServiceInstance Data about the existing AWS Product Instance.
	 */
	public AwsProductInstancePlaceholder( String name, AwsServiceInstance awsServiceInstance ) {
		this._awsServiceInstance = awsServiceInstance
		this._name = name
	}
	
	/**
	 * Sets the AWS Service Instance, which represents a an instance which is being or has been provisioned.
	 */
	public void setAwsServiceInstance( AwsServiceInstance awsServiceInstance ) {
		_awsServiceInstance = awsServiceInstance
	}
	
	/**
	 * Returns the AWS Service Instance, which represents a an instance which is being or has been provisioned.
	 */
	public AwsServiceInstance getAwsServiceInstance() {
		return _awsServiceInstance
	}

	/**
	 * Returns the logical name for this service request.
	 */
	public String getName() {
		return _name
	}
	
	/**
	 * Returns the service definition, which may be null if an existing Product Instance is referenced.
	 */
	public AwsServiceDefinition getServiceDefinition() {
		return _awsServiceDefinition
	}
	
	/**
	 * Returns the service definition, which may be null if an existing Product Instance is referenced.
	 */
	public AwsServiceDefinition getAwsServiceDefinition() {
		return _awsServiceDefinition
	}
	
	/**
	 * Returns a string displayable version of this placeholder.
	 */
	public String toString() {
		AwsServiceDefinition serviceDefinition = getAwsServiceDefinition()
		AwsServiceInstance serviceInstance = getAwsServiceInstance()
		
		String retval = "AWS Service Catalog Product Instance ( Template Name='${this.getName()}'"
		String delim = ', '
		
		if (serviceDefinition) {
			retval = retval + delim + "Product=${serviceDefinition.getName()}"
		}
		
		if (serviceInstance) {
			retval = retval + delim + "Instance Name=${serviceInstance.getProvisionedName()}" + 
				delim + "Instance ID=${serviceInstance.getProvisionedId()}"
		}
		
		retval = retval + " )"
		return retval
	}
}
