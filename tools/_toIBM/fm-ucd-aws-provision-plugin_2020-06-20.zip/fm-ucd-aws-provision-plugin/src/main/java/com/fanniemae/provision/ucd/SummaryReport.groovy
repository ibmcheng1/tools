package com.fanniemae.provision.ucd

import java.util.List

import com.fanniemae.ucd.aws.provision.context.ProvisionContext
import com.fanniemae.ucd.aws.provision.context.data.AwsProductInstancePlaceholder
import com.ibm.css.ucd.environment.Environment
import com.ibm.issr.core.log.Logger

/**
 * <p>Captures and summarizes key successes and failures of the provisioning process.  In
 * particular, steps can fail, but the plugin will create/update as much as possible.  This
 * class can be called at the very end of the plugin to summarize what worked and what didn't.
 * Track the information at a high level from the users perspective with entries like 'Created
 * UCD Environment named xyz', 'Updated existing UCD environment named 'xyz', 'Provisioned AWS Product
 * Instance ...', 'Referenced existing AWS Product Instance ...', 'Provisioning ... FAILED'.</p>
 * <p>This class is generally given the data and calculates the actual text of the message itself.</p>
 * <p>This is a singleton.  Call SummaryReport.getInstance() to get the one instance.
 * @author s9ulcc
 *
 */
class SummaryReport {
	// Report sections
	public final static int INTRO_SECTION = 1
	public final static int ENVIRONMENT_SUMMARY_SECTION = 2
	public final static int EXISTING_AWS_INSTANCES_SECTION = 3
	public final static int END_SECTION = 4
	
	// Singleton instance
	private static SummaryReport _instance = null
	
	private Date _reportDate = new Date()
	
	// The report title
	private String _title = ''
	
	// This is an ordered List of sections indexed by # (0 based)
	// Each section is a list of lines
	List<List> _summarySections = []

	/**
	 * Returns the singleton instance.
	 */
	public static SummaryReport getInstance() {
		if (! _instance) {
			_instance = new SummaryReport()
		}
		return _instance
	}
	
	/**
	 * Private constructor because this is a singleton.
	 */
	private SummaryReport() {
		
	}
	
	/**
	 * Sets the summary report title - such as 'Provision' or 'Deprovision'
	 * @param title
	 */
	public void setTitle( String title ) {
		_title = title
	}
	
	/**
	 * Call this when a UCD environment is successfully created.
	 */
	public void addSuccessfulUcdEnvironmentCreation( Environment environment ) {
		addLine( "Created new UCD Environment named ${environment.getName()}", ENVIRONMENT_SUMMARY_SECTION )
	}
	
	/**
	 * Call this when an existing UCD environment is found for the current provisioning.
	 */
	public void addExistingUcdEnvironment( Environment environment ) {
		addLine( "Updated existing UCD Environment named ${environment.getName()}", ENVIRONMENT_SUMMARY_SECTION )
	}
	
	/**
	 * Call this when a Product Instance Placeholder is successfully provisioned.
	 * @param placeholder The Product Instance definition and instance.
	 * @param context The context (such as 'Blue Environment') that the placeholder is in.
	 */
	public void addSuccessfulProvisionRequest( AwsProductInstancePlaceholder placeholder, ProvisionContext context ) {
		addLine( "Successfully provisioned ${placeholder.toString()} for ${context.getContextName()}", END_SECTION )
	}
	
	/**
	 * Call this when a Product Instance Placeholder is successfully provisioned.
	 * @param placeholder The Product Instance definition.
	 * @param context The context (such as 'Blue Environment') that the placeholder is in.
	 */
	public void addFailedProvisionRequest( AwsProductInstancePlaceholder placeholder, ProvisionContext context ) {
		String productName = placeholder.getAwsServiceDefinition().getAwsProduct().getName()
		addLine( "FAILED TO PROVISION AWS Product '${productName}' for ${context.getContextName()}", END_SECTION )
	}
	
	/**
	 * Call this when using an existing Product Instance.
	 * @param placeholder The Product Instance definition.
	 * @param context The context (such as 'Blue Environment') that the placeholder is in.
	 */
	public void addExistingProductInstance( AwsProductInstancePlaceholder placeholder, ProvisionContext context ) {
		addLine( "Using existing ${placeholder.toString()} for ${context.getContextName()}", EXISTING_AWS_INSTANCES_SECTION )
	}
	
	/**
	 * Simply add a line of information to the end of the summary report.
	 * @param line
	 */
	public void addLine( String line, int section = SummaryReport.END_SECTION ) {
		while (_summarySections.size() < (section+1)) { 
			_summarySections << []	
		}
		_summarySections[section] << line
	}
	
	/**
	 * Returns the summary report as a multiple line string.
	 * @return
	 */
	public String getSummary() {
		String title = (_title + " Execution Summary").trim()
		int titleIndent = 12
		String summaryValue = ('*' * (titleIndent*2 + title.length())) + "\n"
		summaryValue = summaryValue + (' ' * titleIndent) + title + "\n"
		summaryValue = summaryValue + "\n"
		summaryValue = summaryValue + "Executed: " + _reportDate.toString() + "\n"
		_summarySections.each { List lines ->
			lines.each { String line ->
				summaryValue = summaryValue + line + "\n"
			}
		}
		
		return summaryValue
	}

	/**
	 * Display the summary to the output log.
	 */
	public void displaySummary() {
		Logger.disablePrefix {
			Logger.info "\n" + getSummary() + "\n"
		}
	}
}
