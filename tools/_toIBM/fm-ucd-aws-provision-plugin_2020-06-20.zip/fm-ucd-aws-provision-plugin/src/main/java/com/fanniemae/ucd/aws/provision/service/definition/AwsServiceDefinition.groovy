package com.fanniemae.ucd.aws.provision.service.definition

import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProduct
import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProductVersion
import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProductInstance
import com.fanniemae.ucd.aws.provision.context.ProvisionContext
import com.fanniemae.ucd.aws.provision.service.instance.AwsServiceInstance
import com.ibm.issr.core.log.Logger

/**
 * Defines the information needed to provision one AWS Catalog Service instance.
 * @author s9ulcc
 *
 */
class AwsServiceDefinition {
	protected String _name
	// If _awsName isn't defined, then the _name is used for AWS instead
	protected String _awsName = null
	protected AwsProductVersion _awsProductVersion
	protected boolean _participateInBlueGreen
	
	/**
	 * These are manifest property values that are mapped to AWS.
	 * Key is the String property name and the value is the value.  Note that the value may contain tokens!!
	 */
	protected Map<String,String> _awsPropertyFields = [:]
	
	/**
	 * These are manifest Tags that are mapped to AWS.
	 * Key is the String tag name and the value is the value.  Note that the value may contain tokens!!
	 */
	protected Map<String,String> _awsTags = [:]

	/**
	 * Constructor.
	 * @param name The logical name of this entry.  This is the 'name' field value.
	 * @param awsProductVersion The AWS Product version to provision.  Note that the product version has a reference to the
	 * product.
	 * @param participateInBlueGreen Should this catalog product participate in blue/green deployments by spinning up a blue
	 * and green instance?
	 */
	public AwsServiceDefinition( String name, AwsProductVersion awsProductVersion, boolean participateInBlueGreen ) {
		_name = name
		_awsProductVersion = awsProductVersion 
		_participateInBlueGreen = participateInBlueGreen
	}
	
	/**
	 * Returns the AWS Product Version for this service definition.
	 */
	public AwsProductVersion getAwsProductVersion() {
		return _awsProductVersion
	}
	
	/**
	 * Returns the AWS Product for this service definition.
	 */
	public AwsProduct getAwsProduct() {
		return _awsProductVersion.getAwsProduct()
	}
	
	/**
	 * Does this service product definition participate in blue/green deployments with separate instances.
	 */
	public boolean participateInBlueGreen() {
		return _participateInBlueGreen
	}
	
	/**
	 * This is the same as participateInBlueGreen() - 
	 * Does this service product definition participate in blue/green deployments with separate instances.
	 */
	public boolean shouldProvisionSeparateBlueGreenInstances() {
		return participateInBlueGreen()
	}
	
	/**
	 * Set the AWS Name, which is used as part of the Provisioned AWS Service name.
	 */
	public void setAwsName( String awsName ) {
		_awsName = awsName
	}
	
	/**
	 * Returns the AWS Name, which is used as part of the Provisioned AWS Service name.
	 * Note that if the awsName field isn't defined, then this returns the logical 'name' field instead.
	 */
	public String getAwsName( ProvisionContext context ) {
		if (_awsName) {
			return context.processTokens( _awsName, _name )
		} else {
			return _name
		}
	}
	
	/**
	 * Returns the logical name for this service definition.
	 */
	public String getName() {
		return _name
	}
	
	/**
	 * Add a new property field to pass to AWS.
	 * @param name The name of the property field.
	 * @param value The value.  Note that the value may contain tokens.  The tokens are resolved later.
	 */
	public void addPropertyField( String name, String value ) {
		_awsPropertyFields[name] = value
	}
	
	/**
	 * Is there a property field entry for 'name' field?
	 */
	public boolean hasPropertyField( String name ) {
		return (_awsPropertyFields.containsKey(name))
	}
	
	/**
	 * Returns the value of the named 'propertyName' after resolving tokens or empty string if not found.
	 * @param propertyName The name of the input property (from awsManifest.json).
	 * @param context The context for resolving tokens.
	 */
	public String getPropertyField( String propertyName, ProvisionContext context ) {
		if (_awsPropertyFields.containsKey(propertyName)) {
			return context.processTokens( _awsPropertyFields[propertyName], this._name )
		} else {
			return ''
		}
	}
	
	/**
	 * Add a new tag to pass to AWS.
	 * @param name The name of the tag.
	 * @param value The value.  Note that the value may contain tokens.  The tokens are resolved later.
	 */
	public void addTag( String name, String value ) {
		_awsTags[name] = value
	}
	
	/**
	 * Is there a Tag entry for 'name' field?
	 */
	public boolean hasTag( String name ) {
		return (_awsTags.containsKey(name))
	}
	
	/**
	 * Returns the value of the named 'tagName' after resolving tokens or empty string if not found.
	 * @param tagName The name of the input Tag).
	 * @param context The context for resolving tokens.
	 */
	public String getTag( String tagName, ProvisionContext context ) {
		if (_awsTags.containsKey(tagName)) {
			return context.processTokens( _awsTags[tagName], this._name )
		} else {
			return ''
		}
	}
	
	/**
	 * Calculates and returns the AWS Product Instance name that will be used when provisioning.
	 * @param context The provision Context, which is used to resolve any tokens in the name.
	 */
	public String calculateProvisionedName( ProvisionContext context ) {
		
		// Get the AWS provisionedName
		String envName = context.getEnvironmentName()
		if (! envName) {
			envName = context.getBaseEnvironmentName()
		}
		return context.getAppCode() + '_' + envName + '_' + getAwsName(context)
	}

	/**
	 * Provisions one instance of the defined AWS service.
	 * @param context The Provision Context that this instance is part of.
	 * @return Returns the provisioned instance wrapper.  Returns null if unable to provision.  If unable to provision,
	 * appropriate messages are logged.
	 */
	public AwsServiceInstance provisionInstance( ProvisionContext context ) {
		Logger.debug( "called AwsServiceDefinition.provisionInstance()")
		
		// Get the AWS provisionedName
		String provisionedName = calculateProvisionedName( context )
		
		Logger.info "Provisioning version '${_awsProductVersion.getName()}' of AWS Catalog Product '${_awsProductVersion.getAwsProduct().getName()}'"
		Logger.info "\tProvisioned Name: " + provisionedName

		// Create a copy of the input properties where the tokens are replaced with values
		Map<String,String> inputs = [:]
		_awsPropertyFields.each { String propertyName, String propertyValue ->
			propertyValue = context.processTokens( propertyValue, this.getName() )
			inputs[propertyName] = propertyValue
			Logger.info "\tSetting property: ${propertyName} = " + propertyValue
		}
		
		// Create a copy of the input Tags with token substitution
		Map<String,String> tags = [:]
		_awsTags.each { String tagName, String tagValue ->
			tagValue = context.processTokens( tagValue, this.getName() )
			tags[tagName] = tagValue
			Logger.info "\tSetting tag: ${tagName} = " + tagValue
		}
		
		AwsProductInstance awsProvisionedProduct = _awsProductVersion.provisionProductInstance(provisionedName, inputs, tags )
		if (awsProvisionedProduct) {
			return new AwsServiceInstance(this, awsProvisionedProduct, true)
		} else {
			return null
		}
	}
	
	/**
	 * Returns an AwsServiceInstance for an existing provisioned product.
	 * @param existingAwsProductId The ID of the existing product.  This throws exception if the product can't be found.
	 * @param provisionedByPlugin Was this AWS Product Instance provisioned by this plugin?
	 */
	public AwsServiceInstance provisionByLinkingToExistingAwsProductInstance( String existingAwsProductId, boolean provisionedByPlugin = false ) {
		AwsProductInstance awsProvisionedProduct = new AwsProductInstance(_awsProductVersion.getAwsServiceCatalog(), existingAwsProductId)
		
		// verify that the provisioned product exists
		if (! awsProvisionedProduct) {
			throw new Exception( "Unable to find an existing provisioned product with the id of ${existingAwsProductId}")
		}
		
		return new AwsServiceInstance(this, awsProvisionedProduct, provisionedByPlugin)
	}
}
