package com.fanniemae.ucd.aws.provision.info

/**
 * Represents predefined (known when the plugin was built) information about AWS Products.
 * Call static lookupByName() to find an entry.
 * @author s9ulcc
 *
 */
class PredefinedProductInfo {
	protected static List<PredefinedProductInfo> products = [
		new PredefinedProductInfo( 'ECR Repository', true, 'ecr' ),
		new PredefinedProductInfo( 'CodeCommit', false, null ),
		new PredefinedProductInfo( 'ECS CICD Pipeline', false, null ),
		new PredefinedProductInfo( 'Code CICD Pipeline', false, null ),
		new PredefinedProductInfo( 'SNS Topic', true, 'sns' ),
		new PredefinedProductInfo( 'Application Load Balancer', true, 'loadBalancer' ),
		new PredefinedProductInfo( 'ElasticBeanstalk Environment', true, 'ebEnv' ),
		new PredefinedProductInfo( 'ElasticBeanstalk Application and Environment', true, 'eb' ),
		new PredefinedProductInfo( 'EC2', true, 'ec2' ),
		new PredefinedProductInfo( 'ElastiCache', true, 'cache' ),
		new PredefinedProductInfo( 'SQS Queue', true, 'sqs' ),
		new PredefinedProductInfo( 'DynamoDB table', true, 'table' ),
		new PredefinedProductInfo( 'API Gateway', true, 'api' ),
		new PredefinedProductInfo( 'ECS Cluster', true, 'ecs' ),
		new PredefinedProductInfo( 'RDS', true, 'rds' ),
		new PredefinedProductInfo( 'Kinesis Data Stream Service', true, 'kData' ),
		new PredefinedProductInfo( 'Kinesis Analytics Service', true, 'kAnalysis' ),
		new PredefinedProductInfo( 'Kinesis Data Firehose Service', true, 'kFirehose' )
		]
	
	protected String _productName
	protected boolean _includeInGenerator
	protected String _defaultName
	
	/**
	 * Looks up PredefinedProductInfo for the named AWS Catalog Product return null if not
	 * found.
	 */
	public static PredefinedProductInfo lookupByName( String productName ) {
		return products.find { PredefinedProductInfo product ->
			return (product.productName == productName)
		}
	}
			
	/**
	 * Private/protected constructor
	 * @param productName The AWS Catalog Product Name.  This is the lookup key.
	 * @param includeInGenerator Should this entry be included in the generator.
	 * @param defaultName The default logical and aws name.  Set to null if there is no default.
	 */
	protected PredefinedProductInfo( String productName, boolean includeInGenerator, String defaultName ) {
		_productName = productName
		_includeInGenerator = includeInGenerator
		_defaultName = defaultName
	}
	
	/**
	 * Returns the AWS Catalog Product Name.
	 */
	public String getProductName() {
		return _productName
	}
	
	/**
	 * Should this product be included in the generated template?
	 */
	public boolean shouldIncludeInGenerator() {
		return _includeInGenerator
	}
	
	/**
	 * Returns the default logical/aws instance name.  Returns null of empty string if there
	 * is no default name.
	 */
	public String getDefaultName() {
		return _defaultName
	}
}
