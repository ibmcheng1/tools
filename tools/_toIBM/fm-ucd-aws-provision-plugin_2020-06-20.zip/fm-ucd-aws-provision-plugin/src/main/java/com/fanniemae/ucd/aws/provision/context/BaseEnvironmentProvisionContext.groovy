package com.fanniemae.ucd.aws.provision.context

import com.fanniemae.ucd.aws.provision.context.data.AwsProductInstancePlaceholder
import com.fanniemae.ucd.aws.provision.service.definition.AwsServiceDefinition
import com.fanniemae.ucd.aws.provision.service.instance.AwsServiceInstance
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel

/**
 * This is a provision context for the base class.  It automatically
 * has a blue and green child IF (and only if) provisioning blue green.
 */
class BaseEnvironmentProvisionContext extends ProvisionContext {
	ProvisionContext _blueChildContext = null
	ProvisionContext _greenChildContext = null
	boolean _isProvisioningBlueGreen = false
	
	/**
	 * Constructor
	 * @param isProvisioningBlueGreen Is a blue-green environment configuration being provisioned?
	 */
	public BaseEnvironmentProvisionContext( boolean isProvisioningBlueGreen ) {
		super(null)
		_isProvisioningBlueGreen = isProvisioningBlueGreen
		// 'shared resources', 'blue environment', 'stand-alone environment'
		if (isProvisioningBlueGreen) {
			this.setContextName('shared resources')
			_blueChildContext = new ProvisionContext(this,true,false)
			_blueChildContext.setContextName('blue environment')
			this.addChildContext(_blueChildContext)
			_blueChildContext.blueGreenCounter = '1'
			_blueChildContext.flagAsEnvironmentContext()
			_greenChildContext = new ProvisionContext(this,false,true)
			_greenChildContext.setContextName('green environment')
			this.addChildContext(_greenChildContext)
			_greenChildContext.blueGreenCounter = '2'
			_greenChildContext.flagAsEnvironmentContext()
		} else {
			flagAsEnvironmentContext()
			this.setContextName('stand-alone environment')
		}
	}
	
	/**
	 * Is the provisioning targeting blue-green?
	 */
	public boolean isProvisioningBlueGreen() {
		return _isProvisioningBlueGreen
	}
	
	/**
	 * Returns the BLUE child context or null if there is no BLUE context.
	 */
	public ProvisionContext getBlueChildContext() {
		return _blueChildContext
	}
	
	/**
	 * Returns the GREEN child context or null if there is no GREEN context.
	 */
	public ProvisionContext getGreenChildContext() {
		return _greenChildContext
	}
	
	/**
	 * Returns a list of all of the AWS Resource Instances from all of the contexts (base, blue, green)
	 */
	public List<AwsProductInstancePlaceholder> getAllAwsResourceInstances() {
		List<AwsProductInstancePlaceholder> resourceInstances = []
		this.getContextSpecificAwsProductInstancePlaceholders().each { AwsProductInstancePlaceholder resourceInstance ->
			resourceInstances << resourceInstance
		}
		if (isProvisioningBlueGreen()) {
			getBlueChildContext().getContextSpecificAwsProductInstancePlaceholders().each { AwsProductInstancePlaceholder resourceInstance ->
				resourceInstances << resourceInstance
			}
			getGreenChildContext().getContextSpecificAwsProductInstancePlaceholders().each { AwsProductInstancePlaceholder resourceInstance ->
				resourceInstances << resourceInstance
			}
		}
		return resourceInstances
	}
	
	/**
	 * Returns a list of all of the environment names from all of the contexts (base, blue, green).
	 */
	public List<String> getAllEnvironmentNames() {
		List<String> environmentNames = []
		if (environmentName) {
			environmentNames << environmentName
		}
		if (isProvisioningBlueGreen()) {
			String blueEnvironmentName = getBlueChildContext().environmentName
			if (blueEnvironmentName) {
				environmentNames << blueEnvironmentName
			}
			String greenEnvironmentName = getGreenChildContext().environmentName
			if (greenEnvironmentName) {
				environmentNames << greenEnvironmentName
			}
		}
		return environmentNames
	}
	
	/**
	 * Returns a list of all of the resource branch names from all of the contexts (base, blue, green).
	 */
	public List<String> getAllResourceBranchNames() {
		List<String> resourceBranchNames = []
		if (resourceBranchName) {
			resourceBranchNames << resourceBranchName
		}
		if (isProvisioningBlueGreen()) {
			String blueBranchName = getBlueChildContext().resourceBranchName
			if (blueBranchName) {
				resourceBranchNames << blueBranchName
			}
			String greenBranchName = getGreenChildContext().resourceBranchName
			if (greenBranchName) {
				resourceBranchNames << greenBranchName
			}
		}
		return resourceBranchNames
	}
	
	/**
	 * Iterates the context tree and all child contexts calling the 'iterator' for each context in
	 * the tree (including the base).
	 * @param iterator Closure which is call for each context in the tree, including the base
	 * context.  Syntax: void iterator( ProvisionContext context )
	 */
	public void iterateContextTree( Closure iterator ) {
		iterator(this)
		if (is_isProvisioningBlueGreen()) {
			iterator(getBlueChildContext())
			iterator(getGreenChildContext())
		}
	}
	
	/**
	 * Iterates the context tree and all child contexts, but ONLY call the 'iterator' for
	 * a context that has an 'environment'
	 * @param iterator Closure which is call for each context in the tree that has an environment, including the base
	 * context.  Syntax: void iterator( ProvisionContext context )
	 */
	public void iterateContextsWithEnvironments( Closure iterator ) {
		iterateContextTree { ProvisionContext context ->
			if (context.environment) {
				iterator(context)
			}
		}
	}
	
	/**
	 * Iterates the context tree and all child contexts, but ONLY call the 'iterator' for
	 * a context that are flagged as environment context.  Note that the context may be flagged as
	 * an environment and not have a UCD Environment.
	 * @param iterator Closure which is call for each context in the tree that is flagged as environment, including the base
	 * context.  Syntax: void iterator( ProvisionContext context )
	 */
	public void iterateContextsFlaggedAsEnvironments( Closure iterator ) {
		iterateContextTree { ProvisionContext context ->
			if (context.isEnvironmentContext()) {
				iterator(context)
			}
		}
	}

	
	/**
	 * Sets tokens for base, blue and green contexts.
	 * @param tokens This is a list of tokens for all contexts.  Tokens for
	 * blue context have suffix of '.blue' and tokens for green context have suffix of
	 * '.green'.  IF this is NOT a blue-green deployment, then the .blue values are used
	 * for the base context IF there isn't a base token with the same name.
	 */
	public void setTokensForAllContexts( Map tokens ) {
		// separate into base, blue and green tokens
		Map baseTokens = [:]
		Map blueTokens = [:]
		Map greenTokens = [:]
		String blueSuffix = ".blue".toUpperCase()
		String greenSuffix = ".green".toUpperCase()
		tokens.each { String name, String value ->
			if (name.toUpperCase().endsWith(blueSuffix)) {
				blueTokens[ name.substring(0, name.length() - blueSuffix.length()) ] = value
			} else if (name.toUpperCase().endsWith(greenSuffix)) {
				greenTokens[ name.substring(0, name.length() - greenSuffix.length()) ] = value
			} else {
				baseTokens[ name ] = value
			}
		}

		if (_isProvisioningBlueGreen) {
			_blueChildContext.addTokens(blueTokens)
			_greenChildContext.addTokens(greenTokens)
		} else {
			// This is NOT blue-green
			// add the blue tokens before base, so any base tokens can replace matching blue
			this.addTokens(blueTokens)
		}
		this.addTokens(baseTokens)
	}

	/**
	 * This is for debugging purposes.  It displays the 'msg' and then displays all of the placeholders in all
	 * of the contexts and environments.
	 * @param loggerLevel Log level enumeration, such as LoggerLevel.INFO
	 */
	public void debug_displayPlaceholders( LoggerLevel loggerLevel, String msg ) {
		// If the requested logger level is higher than the current logger level, just skip the whole block of code since it won't log anything
		if (Logger.willDisplay(loggerLevel)) {
			Logger.println( loggerLevel, "*** DISPLAYING PLACEHOLDERS - ${msg} ***" )
			
			Logger.incrementIndentationForCodeBlock {
				this.iterateContextsFlaggedAsEnvironments { ProvisionContext context ->
					String hasEnvironment
					if (context.environment) {
						hasEnvironment = "has UCD environment named ${context.environment.getName()}"
					} else {
						hasEnvironment = "does NOT have a UCD environment"
					}
					Logger.println( loggerLevel, "Environment: ${context.getContextName()}, ${hasEnvironment}" )
					Logger.incrementIndentationForCodeBlock {
						context.iterateInheritedAwsProductInstancePlaceholders { AwsProductInstancePlaceholder placeholder, ProvisionContext placeholderContext ->
							String logicalName = placeholder.getName()
							AwsServiceDefinition serviceDefinition = placeholder.getAwsServiceDefinition()
							AwsServiceInstance serviceInstance = placeholder.getAwsServiceInstance()
							String definitionDesc = ''
							String instanceDesc = ''
							if (serviceDefinition) {
								definitionDesc = "definition=(name=${serviceDefinition.getName()}, product name='${serviceDefinition.getAwsProduct().getName()}')"
							} else {
								definitionDesc = '(no service definition)'
							}
							if (serviceInstance) {
								instanceDesc = "instance=(instance name='${serviceInstance.getProvisionedName()}', i='${serviceInstance.getProvisionedId()}', provisioned by plugin=${serviceInstance.isProvisionedByPlugin()}, status=${serviceInstance.getAwsStatus()})"
							} else {
								instanceDesc = '(no service instance)'
							}
							Logger.println( loggerLevel, "AWS Instance Placeholder: location='${placeholderContext.getContextName()}', name=${logicalName}, ${definitionDesc}, ${instanceDesc}" )
						}
					}
				}
			}
		}
	}
}
