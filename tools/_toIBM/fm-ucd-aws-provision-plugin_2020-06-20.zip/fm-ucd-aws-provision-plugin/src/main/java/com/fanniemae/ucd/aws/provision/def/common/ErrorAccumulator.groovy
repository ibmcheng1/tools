package com.fanniemae.ucd.aws.provision.def.common

import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel

/**
 * Accumulates a set of separate error messages.
 * @author s9ulcc
 *
 */
class ErrorAccumulator {
	private List<String> _errors = []
	
	/**
	 * Add an error messaget to the list.
	 * @param errorMsg The error message.
	 */
	public void addError( String errorMsg ) {
		_errors << errorMsg
	}
	
	/**
	 * Are there any logged errors?
	 */
	public boolean hasErrors() {
		return (_errors.size() > 0)
	}
	
	/**
	 * Returns the ordered list of error messages as List<String>.
	 */
	public List<String> getErrors() {
		return _errors
	}
	
	/**
	 * Sends the list of error messages to the logger.  It displays
	 * lines between the messages.
	 * @param loggerLevel Which logging level to use, such as LoggerLevel.ERROR
	 */
	public void logErrors( LoggerLevel loggerLevel ) {
		boolean anyFailures = false
		_errors.each { String msg ->
			anyFailures = true
			Logger.println(loggerLevel, "----------------------------------------------------")
			Logger.println(loggerLevel, msg )
		}
		if (anyFailures) {
			Logger.println(loggerLevel, "----------------------------------------------------")
		}
	}

}
