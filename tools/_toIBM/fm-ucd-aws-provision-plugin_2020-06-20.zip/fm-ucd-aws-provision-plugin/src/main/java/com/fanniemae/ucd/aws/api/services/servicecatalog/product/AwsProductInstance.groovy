package com.fanniemae.ucd.aws.api.services.servicecatalog.product

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.ucd.aws.api.cloudformation.AwsCloudformation
import com.fanniemae.ucd.aws.api.describeRecord.AwsDescribeRecordResult
import com.fanniemae.ucd.aws.api.services.servicecatalog.AwsServiceCatalog
import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger

import groovy.json.JsonSlurper

/**
 * Represents a Provisioned AWS Product.
 * @author s9ulcc
 *
 */
class AwsProductInstance {
	/**
	 * The AWS Service Catalog
	 */
	protected AwsServiceCatalog _awsServiceCatalog
	
	/**
	 * This is the ID of the provisioned product.
	 */
	protected String _provisionedProductId
	
	// Cache managed Map returned by 'aws servicecatalog describe-provisioned-product' call for
	// this id.
	protected Map __cachedDescribeProvisionedProduct = null

	/**
	 * Cached describe-record data for the last record associated with this provisioned product	
	 */
	protected AwsDescribeRecordResult __cachedAwsDescribeRecordResult = null

	/**
	 * Constructor.
	 * @param awsServiceCatalog The service catalog.
	 * @param provisionedProductId The ID of the provisioned product.
	 */
	public AwsProductInstance( AwsServiceCatalog awsServiceCatalog, String provisionedProductId ) {
		_awsServiceCatalog = awsServiceCatalog
		_provisionedProductId = provisionedProductId
	}
	
	/**
	 * Returns the cache managed Map returned by 'aws servicecatalog describe-provisioned-product' call for
	 * this id.
	 */
	protected Map getDescribeProvisionedProduct( boolean resetCache = false ) {
		if (resetCache || (__cachedDescribeProvisionedProduct==null)) {
			CommandRunner commandRunner = _awsServiceCatalog.awsConnection.executeAwsCliCommand("aws servicecatalog describe-provisioned-product --id ${_provisionedProductId}")
			if (! commandRunner.wasSuccessful()) {
				throw new Exception( "API call to get AWS Service Instance status failed")
			}
			__cachedDescribeProvisionedProduct = (new JsonSlurper()).parseText( commandRunner.getConsoleOutput() )
		}
		return __cachedDescribeProvisionedProduct
	}
	
	
	/**
	 * Calls the AWS 'describe-record' command for this instance returning the resulting Object tree storing results in a cache.
	 * Throws exception on failure.
	 */
	public AwsDescribeRecordResult getDescribeRecordResult( boolean resetCache = false) {
		if ((! __cachedAwsDescribeRecordResult) || resetCache) {
			CommandRunner commandRunner = _awsServiceCatalog.awsConnection.executeAwsCliCommand("aws servicecatalog describe-record --id ${getLastRecordId(resetCache)}")
			if (! commandRunner.wasSuccessful()) {
				throw new Exception( "API call to get AWS Service Instance Record (servicecatalog describe-record) failed")
			}
			__cachedAwsDescribeRecordResult = new AwsDescribeRecordResult( commandRunner.getConsoleOutput(), true )
		}
		return __cachedAwsDescribeRecordResult
	}

	/**
	 * Returns the corresponding CloudFormation stack id (which is the ARN).  Returns empty string if unable to determine it.
	 */
	public String getCloudFormationStackId( boolean resetCache = false ) {
		AwsDescribeRecordResult recordResult = getDescribeRecordResult(resetCache)
		String cloudformationStackARN = ''
		if (recordResult.hasRecordOutputProperty('CloudformationStackARN')) {
			cloudformationStackARN = recordResult.getRecordOutputProperty('CloudformationStackARN')
		}
		return cloudformationStackARN
	}

	/**
	 * Does the Provisioned Product described by 'this' instance actually exist?
	 */
	public boolean doesExist() {
		boolean exists
		// Force a reload of the object data.  If the reload fails, then assume that it doesn't exist.
		try {
			getDescribeProvisionedProduct(true)
			exists = true
		}
		catch (Exception e) {
			exists = false
		}
		return exists
	}
	
	/**
	 * Returns the ID of the 'LastRecord' (aka last operation) for this Provisioned Product.
	 */
	public String getLastRecordId( boolean resetCache = false ) {
		return getDescribeProvisionedProduct(resetCache).ProvisionedProductDetail.LastRecordId
	}
	
	
	/**
	 * Returns the name of this Provisioned Product.
	 */
	public String getName( boolean resetCache = false ) {
		return getDescribeProvisionedProduct(resetCache).ProvisionedProductDetail.Name
	}
	
	/**
	 * Returns the current Status.  This defaults to reseting the cache.
	 */
	public String getStatus( boolean resetCache = true ) {
		return getDescribeProvisionedProduct(resetCache).ProvisionedProductDetail.Status
	}
	
	/**
	 * Returns the current Status Message or empty string if not defined.  This defaults to reseting the cache.
	 */
	public String getStatusMessage( boolean resetCache = true ) {
		Map provisionedProductDescription
		provisionedProductDescription = getDescribeProvisionedProduct(resetCache)
		if (provisionedProductDescription.ProvisionedProductDetail.containsKey('StatusMessage')) {
			return provisionedProductDescription.ProvisionedProductDetail.StatusMessage
		} else {
			return ''
		}
	}

	/**
	 * Returns this Provisioned Product's ID.
	 */
	public String getProvisionedProductId() {
		return _provisionedProductId
	}
	
	
	/**
	 * Initiates an AWS Termination (aka deprovision) request for this Product Instance.  Returns
	 * an AwsProductInstanceTerminationRequestRecord which is used to track the async termination
	 * process.  Use the returned object to monitor the actual termination progress.  Throws
	 * exception on error.
	 */
	public AwsProductInstanceTerminationRequestRecord terminate() {
		AwsConnection awsConnection = _awsServiceCatalog.awsConnection
		CommandRunner commandRunner = awsConnection.executeAwsCliCommand("""aws servicecatalog terminate-provisioned-product --provisioned-product-name '${p:this.getName()}' --region ${p:awsConnection.getRegion()}""")
		if (! commandRunner.wasSuccessful()) {
			throw new Exception( "AWS Call to terminate Product Instance named ${this.getName()} failed" )
		}
		Map terminationRequestData = (new JsonSlurper()).parseText( commandRunner.getConsoleOutput() )
		return new AwsProductInstanceTerminationRequestRecord( _awsServiceCatalog, terminationRequestData )
	}


}
