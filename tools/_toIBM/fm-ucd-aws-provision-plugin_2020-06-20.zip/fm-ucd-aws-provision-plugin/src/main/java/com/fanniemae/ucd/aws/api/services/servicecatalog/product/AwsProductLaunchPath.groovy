package com.fanniemae.ucd.aws.api.services.servicecatalog.product;

/**
 * One AwsProduct launch path.  A launch path is a 'path' for provisioning
 * a service isntance.  The data in this entity does NOT include any path
 * field, but has an ID field.
 * @author s9ulcc
 *
 */
public class AwsProductLaunchPath {
	/**
	 * This is the definition of a Launch path. Specifically,
	 * its one entry from the 'aws list-launch-paths' call.
	 */
	protected Map _awsDefinition
	
	// The corresponding product
	protected AwsProduct _awsProduct
	
	/**
	 * Constructor
	 * @param awsProduct The Product that this is a launch path for.
	 * @param awsDefinition The definition of the launch path as returned
	 * from a call to 'aws list-launch-paths'.
	 */
	public AwsProductLaunchPath( AwsProduct awsProduct, Map awsDefinition ) {
		_awsProduct = awsProduct
		_awsDefinition = awsDefinition
	}
	
	/**
	 * Returns the name of this launch path.
	 */
	public getName() {
		return _awsDefinition.Name
	}
	
	/**
	 * Returns the AWS Id of this launch path.
	 */
	public getId() {
		return _awsDefinition.Id
	}
}
