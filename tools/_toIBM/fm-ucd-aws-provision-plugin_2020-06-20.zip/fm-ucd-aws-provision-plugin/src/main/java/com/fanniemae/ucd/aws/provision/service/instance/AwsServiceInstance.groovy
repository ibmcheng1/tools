package com.fanniemae.ucd.aws.provision.service.instance

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.ucd.aws.api.describeRecord.AwsDescribeRecordResult
import com.fanniemae.ucd.aws.api.services.servicecatalog.AwsServiceCatalog
import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProductInstance
import com.fanniemae.ucd.aws.provision.service.definition.AwsServiceDefinition
import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.plugin.AbortPluginException

import groovy.json.JsonSlurper

/**
 * Represents one provisioned instance of an AWS service, such as RDS or EB.
 * @author s9ulcc
 *
 */
class AwsServiceInstance {
	protected AwsProductInstance _awsProductInstance
	
	/**
	 * The AwsServiceDefinition which created this service instance.  Note that
	 * the service definition includes the block of data from the AWS Specification/Manifest
	 * which defines this instance.  This is null if an existing instance is used.
	 */
	protected AwsServiceDefinition _awsServiceDefinition = null
	
	// Was this Product Instance provisioned by this plugin??  It may be a previous incremental execution of the plugin.
	protected boolean _provisionedByPlugin

	
	/**
	 * Constructor.
	 * @param awsServiceDefinition The corresponding service definition, which contains corresponding template data.  This may be null.
	 * @param awsProductInstance The provisioned product instance.  This MUST be provided.
	 * @param provisionedByPlugin Was this AWS Product Instance provisioned by this plugin?
	 */
	public AwsServiceInstance( AwsServiceDefinition awsServiceDefinition, AwsProductInstance awsProductInstance, boolean provisionedByPlugin ) {
		_awsServiceDefinition = awsServiceDefinition
		_awsProductInstance = awsProductInstance
		_provisionedByPlugin = provisionedByPlugin
	}
	
	/**
	 * Returns the service definition linked to this service instance.
	 * @return
	 */
	public AwsServiceDefinition getAwsServiceDefinition() {
		return _awsServiceDefinition
	}
	
	/**
	 * Is this AWS Service Instance available?  If 'resetCache' is false,
	 * then this returns the last AWS Status without making an additional AWS
	 * call.  If 'resetCache' is true, then call AWS to get the current status.
	 */
	public boolean isAvailable( boolean resetCache = false ) {
		return getAwsStatus(resetCache)=='AVAILABLE'
	}
	
	/**
	 * Is this AWS Product Instance 'under change'.  Generally it is under change
	 * if it is currently being provisioned, deprovisioned or changed in some other
	 * significant way.
	 */
	public boolean isUnderChange( boolean resetCache = false ) {
		return getAwsStatus(resetCache)=='UNDER_CHANGE'
	}
	
	/**
	 * Returns the Status from AWS.
	 * @param resetCache - If true, then force reload of status from AWS, otherwise, return cached value.
	 */
	public String getAwsStatus( boolean resetCache = false ) {
		return _awsProductInstance.getStatus(resetCache)
	}
	
	/**
	 * Returns the StatusMessage from AWS.
	 * @param resetCache - If true, then force reload of status from AWS, otherwise, return cached value.
	 */
	public String getAwsStatusMessage( boolean resetCache = false ) {
		return _awsProductInstance.getStatusMessage(resetCache)
	}

	/**
	 * Returns the AWS Service Instance Name.  If there is no name defined, then an AWS api call is made to get the name.
	 */
	public String getProvisionedName() {
		return _awsProductInstance.getName()
	}
	
	/**
	 * Is this instance a newly provisioned AWS Product instance?  If false, then it is an existing, re-used instance.
	 */
	@Deprecated
	public boolean isNewlyProvisioned() {
		return _provisionedByPlugin
	}
	
	/**
	 * 	Was this Product Instance provisioned by this plugin??  It may be a previous incremental execution of the plugin.
	 */
	public boolean  isProvisionedByPlugin() {
		return _provisionedByPlugin
	}
	
	/**
	 * Calls the AWS 'describe-record' command for this instance returning the resulting Object tree storing results in a cache.
	 */
	public AwsDescribeRecordResult getAwsInstanceData( boolean resetCache = false) {
		return _awsProductInstance.getDescribeRecordResult(resetCache)
	}
	
	/**
	 * Returns the corresponding CloudFormation stack id (which is the ARN).
	 */
	public String getCloudFormationStackId( boolean resetCache = false ) {
		return _awsProductInstance.getCloudFormationStackId(resetCache)
	}
	
	/**
	 * Returns the AWS Service Instance ID.
	 * This IS the same product ID that is displayed in the 'Provisioned products list' AWS GUI list!!
	 */
	public String getProvisionedId() {
		return _awsProductInstance.getProvisionedProductId()
	}
	
	/**
	 * Returns the corresponding AwsProductInstance which is the Object Oriented wrapper for a Product Instance.
	 */
	public AwsProductInstance getProductInstance() {
		return _awsProductInstance
	}

	
	
	
	
	
	
	
	
//	// The provisioned ID, which is returned when provisioning requested.
//	// This IS the same product ID that is displayed in the 'Provisioned products list' AWS GUI list!!
//	// This can be used for calls to 'aws servicecatalog describe-provisioned-product'
//	// Do NOT use this for calls to 'aws servicecatalog describe-record'
//	protected String _provisionedId
//	
//	// The aws instance record id.  This is NOT the same as _provisionedId.
//	// When calling 'describe-provisioned-product', this is located in the output
//	// as ProvisionedProductDetail.LastRecordId
//	// Do NOT use this for calls to 'aws servicecatalog describe-provisioned-product'
//	// Use this for calls to 'aws servicecatalog describe-record'
//	protected String _recordId
//	
//	// If provided, this is the AWS Provisioned Product ID that is displayed to users in the AWS consoles.
//	protected String _provisionedProductId
//	
//	// Current AWS Product Instance status
//	protected String _awsStatus = null		// See https://docs.aws.amazon.com/cli/latest/reference/servicecatalog/describe-provisioned-product.html for list of status values
//	
//	// Cached AWS instance properties
//	private AwsDescribeRecordResult _cached_recordResult = null
//	
//	/**
//	 * Sets the AWS Service Instance name
//	 */
//	public void setProvisionedName( String name ) {
//		_provisionedName = name
//	}
}
