package com.fanniemae.ucd.aws.api.services.servicecatalog.results

/**
 * Information about one AWS Product Instance being terminated.
 */
public class TerminateProvisionProductsResult {
	boolean successful = true		// true if and only if all of the product instances were succesfully deleted.
	List<TerminateProvisionProductResult> instanceResults = []
}
