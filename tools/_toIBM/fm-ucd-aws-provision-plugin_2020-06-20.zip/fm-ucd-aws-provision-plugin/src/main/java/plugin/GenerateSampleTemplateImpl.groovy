package plugin

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.ucd.aws.api.services.servicecatalog.AwsServiceCatalog
import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProduct
import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProductVersion
import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProvisionProductInputFieldDef
import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProvisionProductInputTagDef
import com.fanniemae.ucd.aws.provision.info.PredefinedProductInfo
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.services.ApplicationServices
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.json.dsl.CommentedJsonDslBuilder
import com.ibm.issr.core.json.dsl.impl.JsonBuilder_ListElement
import com.ibm.issr.core.json.dsl.impl.JsonBuilder_MapElement
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.plugin.AbortPluginException

import groovy.json.JsonOutput

/**
 * Implementation of the 'Generate Sample Template' step.
 */
class GenerateSampleTemplateImpl  {
	// plugin constructor inputs
	private UcdServerConnection ucdServer
	private UcdConnectionServices ucdConnectionServices
	private Properties outProps
	private String applicationName
	
	// internal data
	
	private AwsConnection awsConnection
	private AwsServiceCatalog awsServiceCatalog
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to UCD Server.
	 * @param outProps Properties to set as plugin step output properties.
	 * @param awsProductIds JSON string that maps logical AWS Resource names (like 'RDS') to AWS Catalog product IDs.
	 * @param simulateAwsCalls Should calls to AWS be simulated?  This is useful because it lets you test everything
	 * else in a debugging IDE (Eclipse or IntelliJ) session.
	 */
	public GenerateSampleTemplateImpl( UcdServerConnection ucdServer, 
		Properties outProps, String applicationName ) {
		this.ucdServer = ucdServer
		ucdConnectionServices = new UcdConnectionServices(ucdServer)
		this.outProps = outProps
		this.applicationName = applicationName
	}

	/**
	 * Given the input data, this function executes the step which performs the provisioning.
	 * @param blueGreen Is blue-green deployment requested?  Actual blue-green deployment may be different.
	 * @param awsSpecification The specification JSON string.
	 * @param awsPool
	 * @param awsRegion The AWS Region
	 * @param requestedEnvName The name of the new UCD Environment to create.
	 * @param requestedEnvType The requested environment type, which must be one of the named
	 * UCD environment templates within the UCD Application Template.
	 * @param applicationName Name of the UCD Application.
	 * @param ucdComponentsDefJson The loaded 'ucdComponentDef.json' file as a string.
	 * @param tokensText Property file syntax with a list of tokens.
	 */
	public void generateSampleTemplate( String awsRegion, String awsAccountId, String awsRole ) {
		
		
		// Verify and get the target UCD application
		ApplicationServices applicationServices = ucdConnectionServices.getApplicationServices()
		if (! applicationServices.doesApplicationExist(applicationName)) {
			Logger.error "Unable to find application named '${applicationName}'"
			throw new AbortPluginException()
		}
		Application ucdApplication = applicationServices.getApplication(applicationName)
		
		
		// Initiate AwsConnection, including starting AWS working session and authentication
		awsConnection = new AwsConnection(awsRegion)
		awsConnection.initiateAwsSession( awsRole )
		awsServiceCatalog = new AwsServiceCatalog( awsConnection )
		

		// Build the JSON template
		CommentedJsonDslBuilder builder = new CommentedJsonDslBuilder()
		builder.define { JsonBuilder_ListElement jsonRootBody ->
			jsonRootBody.addComment( 'AWS Provisioning Template for UCD')
			jsonRootBody.addMap { JsonBuilder_MapElement jsonRootMap ->
				jsonRootMap.addComment( "'awsTemplate' section defines the AWS Services to provision" )
				jsonRootMap.addNamedMap('awsTemplate') { JsonBuilder_MapElement jsonAwsTemplate ->
					jsonAwsTemplate.addComment('''Within the AWS Product Service specification, you can use dynamic tokens.
In the following example...
   - The awsName is dynamically referring to the EnvironmentPlatform property.
     In this example, awsName will be 'EB-Nodejs'
   - The EnvironmentName refers to the name of the environment being provisioned.
     For example, if you provision to 'DEVL-5', the environment name is 'webapp-DEVL-5'

{
	"name" : "eb",
	"awsProductName" : "ElasticBeanstalk Application and Environment",
	"awsName": "EB-%([this].EnvironmentPlatform)%",
	"participateInBlueGreen" : false,
	"awsProperties" : {
		"EnvironmentType" : "WebServer",
		"EMMAlertGroup" : "",
		"AutoScalingMax" : "1",
		"InstanceSize" : "Small",
		"EnvironmentName" : "webapp-%(environment.name)%",
		"AutoScalingMin" : "1",
		"EnvironmentPlatform" : "Nodejs",
		"ApplicationIdentifier" : "",
		"ApplicationOwnerEMail" : ""
	}
},''')
					jsonAwsTemplate.addNamedList('provisionProducts') { JsonBuilder_ListElement jsonProductList ->
						int nameCounter = 0
						awsServiceCatalog.getAwsProducts().each { AwsProduct awsProduct ->
							PredefinedProductInfo predefinedProductInfo = PredefinedProductInfo.lookupByName( awsProduct.getName() )
							if ((! predefinedProductInfo) || predefinedProductInfo.shouldIncludeInGenerator()) {
								jsonProductList.addMap { JsonBuilder_MapElement jsonProductEntry ->
									String logicalName = null
									if (predefinedProductInfo) {
										logicalName = predefinedProductInfo.getDefaultName()
									}
									if (! logicalName) {
										++nameCounter
										logicalName = 'name'+nameCounter
									}
									AwsProductVersion awsProductVersion = awsProduct.getNewestVersion()
									jsonProductEntry.addComment( "'name' is the logical name for this AWS Product Instance." )
									jsonProductEntry.addComment( "It is used to reference this Product Instance throughout this template." )
									jsonProductEntry.addComment( "In particular, reference it in tokens as %([name].[field])%, such as %(${logicalName}.fieldName)%" )
									jsonProductEntry.addComment( "Note that tokens may NOT be used within the name field." )
									jsonProductEntry.addNamedSimpleField( 'name', logicalName )
									jsonProductEntry.addComment( "'awsName' is used as part of the provisioned Product Instance in AWS." )
									jsonProductEntry.addComment( "The full AWS Product Instance Name is calculated as: {AppCode}_{UCD Environment Name}_{awsName}" )
									jsonProductEntry.addNamedSimpleField( 'awsName', logicalName )
									String shortDescription = awsProduct.getShortDescription()
									if (shortDescription) {
										jsonProductEntry.addComment( "AWS Description: " + shortDescription )
									}
									jsonProductEntry.addNamedSimpleField( 'awsProductName', awsProduct.getName() )
									jsonProductEntry.addComment( "Optionally specify the Catalog Product Version to use, otherwise newest version is used." )
									jsonProductEntry.addComment( '"awsVersionName": ' + JsonOutput.toJson(awsProductVersion.getName()) + ',' )
									jsonProductEntry.addComment( "Set 'participateInBlueGreen' if this AWS Product should be provisioned separately for blue-green deployments.  Otherwise, it is provisioned once and shared between bluee and green." )
									if (awsProduct.getName().toLowerCase().startsWith('eb ') || awsProduct.getName().toLowerCase().contains('elasticbeanstalk')) {
										jsonProductEntry.addNamedSimpleField( 'participateInBlueGreen', true )
									} else {
										jsonProductEntry.addNamedSimpleField( 'participateInBlueGreen', false )
									}
									jsonProductEntry.addComment("'awsProperties' are the input properties (inprop) sent to AWS when provisioning a Service Catalog Product")
									jsonProductEntry.addNamedMap( 'awsProperties' ) { JsonBuilder_MapElement jsonProductProperties ->
										List<AwsProvisionProductInputFieldDef> inputFields = awsProductVersion.getInputFields()
										inputFields.each { AwsProvisionProductInputFieldDef inputField ->
											if (inputField.customLabel) {
												jsonProductProperties.addComment( "Label: " + inputField.customLabel )
											}
											if (inputField.description) {
												jsonProductProperties.addComment( "Description: " + inputField.description )
											}
											if (inputField.valueList) {
												String values = ''
												String delim = ''
												inputField.valueList.each { String allowedValue ->
													values = values + delim + allowedValue
													delim = ', '
												}
												jsonProductProperties.addComment( 'Allowed values: ' + values )
											}
											if (inputField.defaultValue) {
												jsonProductProperties.addComment( 'Default: ' + inputField.defaultValue )
											}
											jsonProductProperties.addNamedSimpleField( inputField.name, inputField.defaultValue )
										}
									}
									jsonProductEntry.addComment("'awsTags' are the input tags sent to AWS when provisioning a Service Catalog Product.")
									jsonProductEntry.addComment("Products define multiple Tags.  If a tag has a single value, then it doesn't need to be set.")
									jsonProductEntry.addComment("If a tag has multiple possible values, then you must select a value when provisioning the Product.")
									jsonProductEntry.addNamedMap( 'awsTags' ) { JsonBuilder_MapElement jsonProductTags ->
										List<AwsProvisionProductInputTagDef> inputTags = awsProductVersion.getInputTags()
										inputTags.each { AwsProvisionProductInputTagDef inputTag ->
											List<String> valueList = inputTag.getValueList()
											if (valueList && valueList.size()> 1) {
												// This tag has multiple values, so a selection must be made in the template
												String values = ''
												String delim = ''
												valueList.each { String allowedValue ->
													values = values + delim + allowedValue
													delim = ', '
												}
												jsonProductTags.addComment("Allowed values for '${inputTag.getName()}' tag: " + values )
												// default to the last entry in the allowed values list
												jsonProductTags.addNamedSimpleField(inputTag.getName(), valueList[valueList.size()-1])
											}
										}
									}
								}
							}
						}
					}
				}
				jsonRootMap.addComment( "'ucdTemplate' section describes how to configure UCD from provisioned AWS services" )
				jsonRootMap.addNamedMap('ucdTemplate') { JsonBuilder_MapElement jsonUcdTemplate ->
					jsonUcdTemplate.addNamedList('ucdComponents') { JsonBuilder_ListElement jsonComponentsList ->
						List<Component> ucdComponents = ucdApplication.getComponents()
						ucdComponents.each { Component ucdComponent ->
							jsonComponentsList.addMap { JsonBuilder_MapElement jsonComponentEntry ->
								jsonComponentEntry.addNamedSimpleField('componentName', ucdComponent.name)
								jsonComponentEntry.addComment( "The name to use for this component within the UCD Resource Tree.  This is generally the same as the componentName, but can be different." )
								jsonComponentEntry.addNamedSimpleField('resourceName', ucdComponent.name)
								jsonComponentEntry.addComment( "Which UCD Agent is this Component assigned to?  The first agent is agent1, then agent2 and so on." )
								jsonComponentEntry.addNamedSimpleField('agent', 'agent1')
								jsonComponentEntry.addComment( "Set 'participateInBlueGreen' if this UCD Component should be separately configured for blue and green environments" )
								jsonComponentEntry.addNamedSimpleField( 'participateInBlueGreen', false )
								jsonComponentEntry.addNamedMap("componentEnvironmentProperties") { JsonBuilder_MapElement jsonPropertyMap ->
									List ucdPropDefinitions = ucdComponent.getEnvironmentPropertyDefinitions()
									ucdPropDefinitions.each { Map ucdPropDefinition ->
										if (ucdPropDefinition.containsKey('description') && ucdPropDefinition.description) {
											jsonPropertyMap.addComment(ucdPropDefinition.description)
										}
										if (ucdPropDefinition.containsKey('required') && ucdPropDefinition.required) {
											jsonPropertyMap.addComment("Required field")
										}
										jsonPropertyMap.addNamedSimpleField( ucdPropDefinition.name, ucdPropDefinition.value )
									}
								}
							} 
						}
					}
				}
			}
		}

		String body = builder.toJsonString()
		String bodyWithoutComments = builder.toJsonStringIgnoringComments()
				
		println "*** BODY ***"
		println body
		
		outProps.put('ProvisionAws-withComments.template', body )
		outProps.put('ProvisionAws-noComments.template', bodyWithoutComments )
		
		(new File('ProvisionAws-withComments.template')).text = body
		(new File('ProvisionAws-noComments.template')).text = bodyWithoutComments
		
	}
}
