package plugin

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.ucd.aws.provision.service.definition.AwsServiceDefinition
import com.fanniemae.ucd.aws.provision.service.instance.AwsServiceInstance
import com.fanniemae.ucd.aws.provision.spec.AwsSpecification
import com.fanniemae.ucd.aws.provision.ucd.UcdConfigurationDefinition
import com.fanniemae.ucd.aws.provision.ucd.UcdEnvironmentDefinition
import com.fanniemae.ucd.aws.provision.ucd.UcdResourceBranchDefinition
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.resource.ComponentResourceNode
import com.ibm.css.ucd.services.ApplicationServices
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel
import com.ibm.issr.core.plugin.AbortPluginException

import plugin.aws.UCPluginStepForAWSProvisioning

class ValidateRequestedEnvironmentType extends UCPluginStepForAWSProvisioning  {
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new ValidateRequestedEnvironmentType()
		stepImpl.performStep(args) { stepImpl.execute() }
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {
		
		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************

		// Display a summary of what this plugin is going to do
		Logger.info "${getPluginName()} [${getPluginVersion()}]: Validate Requested Environment Type"
		String applicationName = retrieveAndDisplayInProp("applicationName")
		String requestedEnvType = retrieveAndDisplayInProp("requestedEnvType")
		String requestedEnvName = retrieveAndDisplayInProp("requestedEnvName")
		super.displayParameters()
		
		// Get handle to UCD Server
		UcdServerConnection ucdServer = openUcdServerConnection()
		
		ValidateRequestedEnvironmentTypeImpl impl = new ValidateRequestedEnvironmentTypeImpl( ucdServer,
			outProps )
		
		impl.validateRequestedEnvironmentType(requestedEnvName, requestedEnvType, applicationName)
	}

}
