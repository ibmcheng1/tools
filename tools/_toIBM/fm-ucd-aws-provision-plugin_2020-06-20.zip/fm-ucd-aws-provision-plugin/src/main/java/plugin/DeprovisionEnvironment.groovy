package plugin

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.ucd.aws.provision.service.definition.AwsServiceDefinition
import com.fanniemae.ucd.aws.provision.service.instance.AwsServiceInstance
import com.fanniemae.ucd.aws.provision.spec.AwsSpecification
import com.fanniemae.ucd.aws.provision.ucd.UcdConfigurationDefinition
import com.fanniemae.ucd.aws.provision.ucd.UcdEnvironmentDefinition
import com.fanniemae.ucd.aws.provision.ucd.UcdResourceBranchDefinition
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.resource.ComponentResourceNode
import com.ibm.css.ucd.services.ApplicationServices
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel
import com.ibm.issr.core.plugin.AbortPluginException

import plugin.aws.UCPluginStepForAWSProvisioning

class DeprovisionEnvironment extends UCPluginStepForAWSProvisioning  {
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new DeprovisionEnvironment()
		stepImpl.performStep(args) { stepImpl.execute() }
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {
		
		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************

		// Display a summary of what this plugin is going to do
		Logger.info "${getPluginName()} [${getPluginVersion()}]: Provision AWS"
		String applicationName = retrieveAndDisplayInProp("applicationName")
		String environmentName = retrieveAndDisplayInProp("environmentName")
		String awsRegion = retrieveInProp("awsRegion")
		String awsAccountId = retrieveInProp("awsAccountId")
		String awsRole = retrieveInProp("awsRole")
		boolean completelyDeprovision = retrieveAndDisplayInProp("completelyDeprovision").equalsIgnoreCase('true')
		String awsInstancesToDeprovision = retrieveAndDisplayInProp("awsInstancesToDeprovision")
		super.displayParameters()
		
		// Get handle to UCD Server
		UcdServerConnection ucdServer = openUcdServerConnection()
		
		DeprovisionEnvironmentImpl impl = new DeprovisionEnvironmentImpl(ucdServer, outProps, _applicationProcessId )
		
		impl.executeDeprovisioning(awsRegion, awsAccountId, awsRole, environmentName, applicationName, completelyDeprovision, awsInstancesToDeprovision)
		
		Logger.info "De-provisioning completed successfully"
	}

}
