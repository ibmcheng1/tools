package plugin

import com.fanniemae.provision.ucd.UcdEnvironmentProvisionMgr
import com.fanniemae.provision.ucd.persistence.PersistentAwsProductInstanceData
import com.fanniemae.provision.ucd.persistence.PersistentProvisionData
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.environmenttemplate.EnvironmentTemplate
import com.ibm.css.ucd.services.ApplicationServices
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.plugin.AbortPluginException

/**
 * Implementation of the 'Generate AWS Provision Report' step.
 */
class GenerateAwsProvisionReportImpl  {
	// plugin constructor inputs
	private UcdServerConnection ucdServer
	private UcdConnectionServices ucdConnectionServices
	private Properties outProps
	
	private Map _reportData
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to UCD Server.
	 * @param outProps Properties to set as plugin step output properties.
	 */
	public GenerateAwsProvisionReportImpl( UcdServerConnection ucdServer, 
		Properties outProps ) {
		this.ucdServer = ucdServer
		ucdConnectionServices = new UcdConnectionServices(ucdServer)
		this.outProps = outProps
	}

	/**
	 * Generates a UCD Inventory Report which is focues on the AWS Provisioned Products.
	 * More specifically, this generates a JSON Data structure and a recommended HTML Template
	 * to use with that data.
	 * @param applicationName The required application name.
	 * @param environmentName An optional environment name.  If provided, an environment specific
	 * report is generated.  If not provided (blank), then the report is for all environments in
	 * the application.
	 * @return Returns a Map containing the following data fields:
	 * <ul>
	 * <li>Map data - The generated data which can be saved as a JSON file.</li>
	 * <li>String templateBody - The body of the recommended template.</li>
	 * </ul>
	 */
	public Map generate( String applicationName, String environmentName ) {
		_reportData = [ environments:[], stagingEnvironments:[] ]

		
		//------------------------------------------------------------
		// Initialize common UCD data
		//------------------------------------------------------------
		
		
		// Verify and get the target UCD application
		Application ucdApplication
		ApplicationServices applicationServices = ucdConnectionServices.getApplicationServices()
		if (! applicationServices.doesApplicationExist(applicationName)) {
			throw new AbortPluginException( "Unable to find UCD application named '${applicationName}'" )
		} else {
			ucdApplication = applicationServices.getApplication(applicationName)
		}
		
		// Get the appCode
		String appCode
		if (ucdApplication.hasNamedProperty('appCode')) {
			appCode = ucdApplication.getNamedProperty('appCode').value
		} else {
			throw new AbortPluginException( "The UCD Application is missing the required 'appCode' property")
		}
		
		_reportData.application = [ name: ucdApplication.getName(), appCode: appCode, id: ucdApplication.getId() ]
		
		//------------------------------------------------------------
		// Process environment(s)
		//------------------------------------------------------------
		
		environmentName = environmentName.trim()

		if (environmentName) {
			
			//------------------------------------------------------------
			// Process one selected environment
			//------------------------------------------------------------
			
			_reportData.singleEnvironment = true
			_reportData.environmentName = environmentName
			
			if (ucdApplication.doesEnvironmentExist(environmentName)) {
				UcdEnvironmentProvisionMgr ucdEnvironmentProvisionMgr = new UcdEnvironmentProvisionMgr(ucdConnectionServices, ucdApplication, environmentName )
				if (ucdEnvironmentProvisionMgr.doesEnvironmentAlreadyExist()) {
					PersistentProvisionData persistentData = ucdEnvironmentProvisionMgr.getExistingProvisionData()
					mapPersistentProvisionDataToEnvironments( persistentData )
				} else {
					if (ucdApplication.doesEnvironmentExist(environmentName)) {
						throw new AbortPluginException( "The environment named '${environmentName}' exists but is NOT a provisioned environment.")
					} else {
						throw new AbortPluginException( "There is no environment named '${environmentName}'.")
					}
				}
			} else {
				throw new AbortPluginException( "There is no environment named '${environmentName}'.")
			}
			
		} else {
			
			//------------------------------------------------------------
			// Process all environments in Application
			//------------------------------------------------------------
			
			_reportData.singleEnvironment = false

			// Get list of environments
			List<Environment> environments = ucdApplication.getEnvironments()
			// This is a set of the environments (by name) that have been considered/processed
			Set<String> processedEnvironments = new HashSet()
			
			// Loop through the environments
			environments.each { Environment environment ->
				if (! processedEnvironments.contains(environment.getName())) {
					
					EnvironmentTemplate environmentTemplate = environment.getEnvironmentTemplate()
					if (environmentTemplate && environmentTemplate.getName()=='STAGING') {
						// ignore staging environments
						_reportData.stagingEnvironments << [ name: environment.getName(), id: environment.getId() ]
					} else {
										
					// Process this environment
					UcdEnvironmentProvisionMgr ucdEnvironmentProvisionMgr = new UcdEnvironmentProvisionMgr(ucdConnectionServices, ucdApplication, environment.getName() )
					if (ucdEnvironmentProvisionMgr.doesEnvironmentAlreadyExist()) {
						// Add environment (stand-alone or blue-green) to set of processed environments
						PersistentProvisionData persistentData = ucdEnvironmentProvisionMgr.getExistingProvisionData()
						mapPersistentProvisionDataToEnvironments( persistentData )
						if (persistentData.isBlueGreen()) {
							processedEnvironments.add( persistentData.getBlueEnvironment().getName() )
							processedEnvironments.add( persistentData.getGreenEnvironment().getName() )
						} else {
							processedEnvironments.add( persistentData.getStandAloneEnvironment().getName() )
						}
			
					} else {
						// this is an environment that isn't provisioned
					}
					
					
					}	
				}
			}
		}
		
		// alpha sort the environments in _reportData.environments
		_reportData.environments.sort { it.name.toLowerCase() }

		String templateBody = getHtmlTemplateBody()
		return [ data: _reportData, templateBody: templateBody ]	
	}
	
	
	/**
	 * Processes the environments within the provision mgr data - which is a stand-alone environment or a blue-green environment.
	 * This updates the _reportData appropriately.
	 * @param ucdEnvironmentProvisionMgr
	 */
	protected void mapPersistentProvisionDataToEnvironments( PersistentProvisionData persistentData ) {
		if (persistentData.isBlueGreen()) {
			// BLUE-GREEN ENVIRONMENTS
			
			// get UCD Environments
			Environment blueEnvironment = persistentData.getBlueEnvironment()
			Environment greenEnvironment = persistentData.getGreenEnvironment()
			
			// map to _reportData environment entries
			Map blueEnvironmentEntry = mapEnvironmentsToEnvironmentsEntries( blueEnvironment, greenEnvironment )
			Map greenEnvironmentEntry = mapEnvironmentsToEnvironmentsEntries( greenEnvironment, blueEnvironment )

			// add mapped AWS Product Instances
			persistentData.getBlueAwsProductInstances().each { PersistentAwsProductInstanceData instance ->
				blueEnvironmentEntry.unsharedAwsProductInstances << mapPersistentAwsProductInstanceDataToProductInstancesEntry( instance )
			}
			persistentData.getGreenAwsProductInstances().each { PersistentAwsProductInstanceData instance ->
				greenEnvironmentEntry.unsharedAwsProductInstances << mapPersistentAwsProductInstanceDataToProductInstancesEntry( instance )
			}
			persistentData.getSharedAwsProductInstances().each { PersistentAwsProductInstanceData instance ->
				Map mappedEntry = mapPersistentAwsProductInstanceDataToProductInstancesEntry( instance )
				blueEnvironmentEntry.sharedAwsProductInstances << mappedEntry
				greenEnvironmentEntry.sharedAwsProductInstances << mappedEntry
			}

			// add data to _reportData
			_reportData.environments << blueEnvironmentEntry
			_reportData.environments << greenEnvironmentEntry
		} else {
			// STAND ALONE ENVIRONMENT
			
			// get UCD Environment
			Environment environment = persistentData.getStandAloneEnvironment()
			
			// map to _reportData environment entry
			Map environmentEntry = mapEnvironmentsToEnvironmentsEntries( environment )

			// add mapped AWS Product Instances			
			persistentData.getStandAloneAwsProductInstances().each { PersistentAwsProductInstanceData instance ->
				environmentEntry.unsharedAwsProductInstances << mapPersistentAwsProductInstanceDataToProductInstancesEntry( instance )
			}
			
			// add data to _reportData
			_reportData.environments << environmentEntry
		}
	}
	
	/**
	 * Creates and returns a Map entry member of the 'environments' list in the _reportData structure.  This
	 * works with both blue/green pairs and stand-alone environments.
	 * @param environment The environment.
	 * @param pairedEnvironment The optional paired environment.
	 * @return Returns the Map entry.
	 */
	protected Map mapEnvironmentsToEnvironmentsEntries( Environment environment, Environment pairedEnvironment = null ) {
		Map entry = [ name: environment.getName(), id: environment.getId(), unsharedAwsProductInstances: [], sharedAwsProductInstances: [] ]
		if (pairedEnvironment) {
			entry.isBlueGreen = true
			entry.pairedEnvironment = [ name: pairedEnvironment.getName(), id: pairedEnvironment.getId() ]
		} else {
			entry.isBlueGreen = false
		}
		return entry
	}
	
	/**
	 * Maps a PersistentAwsProductInstanceData instance into a Map entry in one of the 'AwsProductInstances' lists
	 * in the generated _reportData structure.
	 */
	protected Map mapPersistentAwsProductInstanceDataToProductInstancesEntry( PersistentAwsProductInstanceData instance ) {
		return [ name: instance.name, provisionedProductName: instance.provisionedProductName, 
			provisionedProductId: instance.provisionedProductId, provisioned: instance.provisioned ]
	}
	
	/**
	 * Returns the body of the Apache Velocity HTML Template for the report
	 */
	protected String getHtmlTemplateBody() {
		return '''<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>AWS Inventory for UCD Application ${json.application.name}</title>
</head>
<body>
<style>
	.inventory {
		width:100%;
		border:1px solid #C0C0C0;
		border-collapse:collapse;
		padding:5px;
	}
	.inventory th {
		border:1px solid #C0C0C0;
		padding:5px;
		background:#F0F0F0;
	}
	.inventory td {
		border:1px solid #C0C0C0;
		padding:5px;
	}
</style>

<h1>AWS Inventory for UCD 
#if (${json.singleEnvironment})
	Environment '${json.environmentName}' of
#end
Application ${json.application.name}</h1>
	

#foreach( $ucdEnv in ${json.environments} )
	<h2>Environment ${ucdEnv.name}</h2>
	
	
	
#if (${ucdEnv.isBlueGreen})
	<p>Blue-Green Environment paired with ${ucdEnv.pairedEnvironment.name}<p>
#else
	<p>Stand Alone Environment<p>
#end



#if (${helper.isMemberArrayWithData($ucdEnv, "unsharedAwsProductInstances")})
<table class="inventory">
	<caption>AWS Provisioned Product Instances private to Environment ${ucdEnv.name}</caption>
	<thead>
	<tr>
		<th>Template Name</th>
		<th>AWS Name</th>
		<th>AWS ID</th>
	</tr>
	</thead>
	<tbody>
#foreach( $unsharedInstance in ${ucdEnv.unsharedAwsProductInstances} )	
	<tr>
		<td>&nbsp;${unsharedInstance.name}</td>
		<td>&nbsp;${unsharedInstance.provisionedProductName}</td>
		<td>&nbsp;${unsharedInstance.provisionedProductId}</td>
	</tr>
#end	
	</tbody>
</table>
<br/>
#end



#if (${helper.isMemberArrayWithData($ucdEnv, "sharedAwsProductInstances")})
<table class="inventory">
	<caption>AWS Provisioned Product Instances shared with Environment ${ucdEnv.pairedEnvironment.name}</caption>
	<thead>
	<tr>
		<th>Template Name</th>
		<th>AWS Name</th>
		<th>AWS ID</th>
	</tr>
	</thead>
	<tbody>
#foreach( $sharedInstance in ${ucdEnv.sharedAwsProductInstances} )	
	<tr>
		<td>&nbsp;${sharedInstance.name}</td>
		<td>&nbsp;${sharedInstance.provisionedProductName}</td>
		<td>&nbsp;${sharedInstance.provisionedProductId}</td>
	</tr>
#end	
	</tbody>
</table>
#end


## end of looping environments
#end

</html>'''		
	}
}
