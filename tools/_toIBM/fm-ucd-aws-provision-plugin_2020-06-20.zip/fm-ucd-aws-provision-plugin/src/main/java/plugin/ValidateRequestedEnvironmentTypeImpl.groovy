package plugin

import org.codehaus.groovy.runtime.StackTraceUtils

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.provision.ucd.SummaryReport
import com.fanniemae.provision.ucd.UcdEnvironmentProvisionMgr
import com.fanniemae.provision.ucd.persistence.PersistentAwsProductInstanceData
import com.fanniemae.provision.ucd.persistence.PersistentProvisionData
import com.fanniemae.ucd.aws.api.describeRecord.AwsDescribeRecordResult
import com.fanniemae.ucd.aws.api.services.servicecatalog.AwsServiceCatalog
import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProductInstance
import com.fanniemae.ucd.aws.api.services.servicecatalog.results.TerminateProvisionProductResult
import com.fanniemae.ucd.aws.api.services.servicecatalog.results.TerminateProvisionProductsResult
import com.fanniemae.ucd.aws.provision.context.BaseEnvironmentProvisionContext
import com.fanniemae.ucd.aws.provision.context.ProvisionContext
import com.fanniemae.ucd.aws.provision.context.data.AwsProductInstancePlaceholder
import com.fanniemae.ucd.aws.provision.def.common.ErrorAccumulator
import com.fanniemae.ucd.aws.provision.def.components.UcdTemplateDefinition
import com.fanniemae.ucd.aws.provision.def.components.data.UcdComponentDef
import com.fanniemae.ucd.aws.provision.service.definition.AwsServiceDefinition
import com.fanniemae.ucd.aws.provision.service.instance.AwsServiceInstance
import com.fanniemae.ucd.aws.provision.spec.AwsSpecification
import com.fanniemae.ucd.aws.provision.ucd.UcdConfigurationDefinition
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.agent.AgentOrAgentPool
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.css.ucd.services.ApplicationServices
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.css.ucd.team.Team
import com.ibm.issr.core.json.JsonHelper
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel
import com.ibm.issr.core.plugin.AbortPluginException
import com.ibm.issr.core.string.SimulateMultipleLines

/**
 * Implementation of the 'Provision AWS Specification' step.
 */
class ValidateRequestedEnvironmentTypeImpl  {
	// plugin constructor inputs
	private UcdServerConnection ucdServer
	private UcdConnectionServices ucdConnectionServices
	private Properties outProps
	
//	
//	/**
//	 * As AWS products are provisioned, their names MUST be added to this list.  If there
//	 * is any failure, this list is used to automatically terminate the resource instances.
//	 */
//	private List<String> provisionedAwsProductNames = []
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to UCD Server.
	 * @param outProps Properties to set as plugin step output properties.
	 */
	public ValidateRequestedEnvironmentTypeImpl( UcdServerConnection ucdServer, 
		Properties outProps ) {
		this.ucdServer = ucdServer
		ucdConnectionServices = new UcdConnectionServices(ucdServer)
		this.outProps = outProps
	}

	/**
	 * Given the input data, this function executes the step which performs the provisioning.
	 * @param blueGreen Is blue-green deployment requested?  Actual blue-green deployment may be different.
	 * @param ucdAgentsString Multiple line string with one UCD Agent or Agent Pool name per line.  These
	 * are the Agents to use in the UCD Environments.  The first line is referenced by the user
	 * as 'agent1', the second is 'agent2' and so on.
	 * @param awsRegion The AWS Region
	 * @param requestedEnvName The name of the new UCD Environment to create.
	 * @param requestedEnvType The requested environment type, which must be one of the named
	 * UCD environment templates within the UCD Application Template.
	 * @param applicationName Name of the UCD Application.
	 * @param templateText The text contents of the AWS Provision Template file.
	 * @param tokensText Property file syntax with a list of tokens.
	 */
	public void validateRequestedEnvironmentType( String envName, String requestedEnvType, String applicationName ) {
		boolean provisioningFailed = false

		
		//------------------------------------------------------------
		// Initialize common UCD data
		//------------------------------------------------------------
		
		
		// Verify and get the target UCD application
		Application ucdApplication
		ApplicationServices applicationServices = ucdConnectionServices.getApplicationServices()
		if (! applicationServices.doesApplicationExist(applicationName)) {
			throw new AbortPluginException( "Unable to find UCD application named '${applicationName}'" )
		} else {
			ucdApplication = applicationServices.getApplication(applicationName)
		}
		
		// Get the appCode
		String appCode
		if (ucdApplication.hasNamedProperty('appCode')) {
			appCode = ucdApplication.getNamedProperty('appCode').value
		} else {
			throw new AbortPluginException( "The UCD Application is missing the required 'appCode' property")
		}
		Logger.info "appCode: " + appCode
		
		UcdEnvironmentProvisionMgr ucdEnvironmentProvisionMgr = new UcdEnvironmentProvisionMgr(ucdConnectionServices, ucdApplication, envName )
		
		
		//------------------------------------------------------------
		// Does the environment already exist - if so, get it's environment type
		//------------------------------------------------------------

		
		// if the environment(s) already exist, use current environment's settings
		if (ucdEnvironmentProvisionMgr.doesEnvironmentAlreadyExist()) {
			Environment environment = null
			PersistentProvisionData persistentData = ucdEnvironmentProvisionMgr.getExistingProvisionData()
			if (persistentData.isBlueGreen()) {
				environment = persistentData.getBlueEnvironment()
			} else {
				environment = persistentData.getStandAloneEnvironment()
			}
			if (environment && environment.hasBasicProperty('envType')) {
				String newEnvironmentType = environment.getBasicProperty('envType').getValue()
				Logger.info "Existing environment has been found.  Changing Environment Type from ${requestedEnvType} to ${newEnvironmentType}"
				requestedEnvType = newEnvironmentType
			}
			outProps.put('awsAccountId', persistentData.getAwsAccountId())
			outProps.put('awsRole', persistentData.getAwsRole())
		}		

		outProps.put('envType', requestedEnvType)
	}
}
