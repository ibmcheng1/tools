package plugin

import org.codehaus.groovy.runtime.StackTraceUtils

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.provision.ucd.SummaryReport
import com.fanniemae.provision.ucd.UcdEnvironmentProvisionMgr
import com.fanniemae.ucd.aws.api.cloudformation.AwsCloudformation
import com.fanniemae.ucd.aws.api.cloudformation.model.CloudformationStack
import com.fanniemae.ucd.aws.api.describeRecord.AwsDescribeRecordResult
import com.fanniemae.ucd.aws.api.services.servicecatalog.AwsServiceCatalog
import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProductInstance
import com.fanniemae.ucd.aws.provision.context.BaseEnvironmentProvisionContext
import com.fanniemae.ucd.aws.provision.context.ProvisionContext
import com.fanniemae.ucd.aws.provision.context.data.AwsProductInstancePlaceholder
import com.fanniemae.ucd.aws.provision.def.common.ErrorAccumulator
import com.fanniemae.ucd.aws.provision.def.components.UcdTemplateDefinition
import com.fanniemae.ucd.aws.provision.def.components.data.UcdComponentDef
import com.fanniemae.ucd.aws.provision.service.definition.AwsServiceDefinition
import com.fanniemae.ucd.aws.provision.service.instance.AwsServiceInstance
import com.fanniemae.ucd.aws.provision.spec.AwsSpecification
import com.fanniemae.ucd.aws.provision.ucd.UcdConfigurationDefinition
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.agent.AgentOrAgentPool
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.processrequest.ProcessRequest
import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.css.ucd.services.ApplicationServices
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.css.ucd.team.Team
import com.ibm.issr.core.json.JsonHelper
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel
import com.ibm.issr.core.plugin.AbortPluginException
import com.ibm.issr.core.string.PropertyLinesHelper
import com.ibm.issr.core.string.SimulateMultipleLines

/**
 * Implementation of the 'Provision AWS Specification' step.
 */
class ProvisionAWSSpecificationImpl  {
	// plugin constructor inputs
	private UcdServerConnection ucdServer
	private UcdConnectionServices ucdConnectionServices
	private Properties outProps
	private boolean _skipAwsProcessing = false
	
	private String _applicationProcessId
	
	private String requestedEnvType
	
	private SummaryReport summaryReport = SummaryReport.getInstance()
	
	// internal data
	private UcdConfigurationDefinition ucdConfigurationDefinition
	
	private AwsConnection awsConnection
	private AwsServiceCatalog awsServiceCatalog
	private AwsCloudformation awsCloudformation
//	
//	/**
//	 * As AWS products are provisioned, their names MUST be added to this list.  If there
//	 * is any failure, this list is used to automatically terminate the resource instances.
//	 */
//	private List<String> provisionedAwsProductNames = []
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to UCD Server.
	 * @param outProps Properties to set as plugin step output properties.
	 * @param skipAwsProcessing If true, then skip any AWS processing that involves making AWS process calls.
	 * This is used to unit test the other functionality from an IDE/Debugger.
	 */
	public ProvisionAWSSpecificationImpl( UcdServerConnection ucdServer, 
		Properties outProps, String applicationProcessId, boolean skipAwsProcessing = false ) {
		this.ucdServer = ucdServer
		ucdConnectionServices = new UcdConnectionServices(ucdServer)
		this.outProps = outProps
		_applicationProcessId = applicationProcessId
		this._skipAwsProcessing = skipAwsProcessing
	}

	/**
	 * Given the input data, this function executes the step which performs the provisioning.
	 * @param blueGreen Is blue-green deployment requested?  Actual blue-green deployment may be different.
	 * @param ucdAgentsString Multiple line string with one UCD Agent or Agent Pool name per line.  These
	 * are the Agents to use in the UCD Environments.  The first line is referenced by the user
	 * as 'agent1', the second is 'agent2' and so on.
	 * @param awsRegion The AWS Region
	 * @param requestedEnvName The name of the new UCD Environment to create.
	 * @param requestedEnvType The requested environment type, which must be one of the named
	 * UCD environment templates within the UCD Application Template.
	 * @param applicationName Name of the UCD Application.
	 * @param templateText The text contents of the AWS Provision Template file.
	 * @param tokensText Property file syntax with a list of tokens.
	 */
	public void executeProvisioning(boolean blueGreen, 
		String ucdAgentsString, String awsRegion, String awsAccountId, 
		String awsRole, String requestedEnvName, String requestedEnvType, String applicationName,
		String templateText, boolean cleanupAwsResourcesOnFailure, String tokensText, String existingAwsProductInstancesText ) {
		boolean provisioningFailed = false
		
		this.requestedEnvType = requestedEnvType
		
		Properties tokens = new Properties()
		tokens.load(new StringReader(PropertyLinesHelper.convert_ColonsOrEquals_To_Equals(SimulateMultipleLines.convertPipesToNewLines(tokensText))))
		if (tokens.size() > 0) {
			Logger.info "User defined tokens:"
			tokens.each { key, value ->
				Logger.info "   ${key}=${value}"
			}
		}
		
		Properties existingAwsProductInstancesProperties = new Properties()
		existingAwsProductInstancesProperties.load(new StringReader(SimulateMultipleLines.convertPipesToNewLines(existingAwsProductInstancesText)))
		
		// If deploying to production environment, use blue-green
		if (requestedEnvType=='PROD' || requestedEnvType=='CNTG') {
			blueGreen = true
		}
		
		ucdAgentsString = SimulateMultipleLines.convertPipesToNewLines(ucdAgentsString)
		
		summaryReport.setTitle("Provision")
		
		
		
		//------------------------------------------------------------
		// Open AWS Connection
		//------------------------------------------------------------

		
		// Initiate AwsConnection, including starting AWS working session and authentication
		if (! _skipAwsProcessing) {
			awsConnection = new AwsConnection(awsRegion)
			awsConnection.initiateAwsSession( awsRole )
			awsServiceCatalog = new AwsServiceCatalog( awsConnection )
			awsCloudformation = new AwsCloudformation( awsConnection )
		}
		
		
		//------------------------------------------------------------
		// Perform general validation
		//------------------------------------------------------------

		
		//------------------------------------------------------------
		// Initialize common UCD data
		//------------------------------------------------------------
		
		ProcessRequest appProcessRequest = ucdConnectionServices.getProcessRequestServices().getProcessRequest( _applicationProcessId )
		summaryReport.addLine("Application Process: " + appProcessRequest.url, SummaryReport.INTRO_SECTION)
		
		// Verify and get the target UCD application
		Application ucdApplication
		ApplicationServices applicationServices = ucdConnectionServices.getApplicationServices()
		if (! applicationServices.doesApplicationExist(applicationName)) {
			throw new AbortPluginException( "Unable to find UCD application named '${applicationName}'" )
		} else {
			ucdApplication = applicationServices.getApplication(applicationName)
		}
		
		// Get the appCode
		String appCode
		if (ucdApplication.hasNamedProperty('appCode')) {
			appCode = ucdApplication.getNamedProperty('appCode').value
		} else {
			throw new AbortPluginException( "The UCD Application is missing the required 'appCode' property")
		}
		Logger.info "appCode: " + appCode
		
		// Process and validate the 'ucdAgents'.  Builds a list of the agent entities.
		List<AgentOrAgentPool> ucdAgents = []
		ucdAgentsString.eachLine { String ucdAgentName ->
			ucdAgentName = ucdAgentName.trim()
			if (ucdAgentName) {
				if (ucdConnectionServices.getAgentServices().doesAgentOrAgentPoolExist(ucdAgentName)) {
					ucdAgents << ucdConnectionServices.getAgentServices().getAgentOrAgentPool(ucdAgentName)
				} else {
					throw new AbortPluginException( "Unable to continue.  No UCD Agent or Agent Pool found with the name '${ucdAgentName}'")
				}
			}
			
		}
		if (ucdAgents.size() == 0) {
			throw new AbortPluginException( "Unable to continue.  No UCD Agent or Agent Pool is defined")
		}
		
		UcdEnvironmentProvisionMgr ucdEnvironmentProvisionMgr = new UcdEnvironmentProvisionMgr(ucdConnectionServices, ucdApplication, requestedEnvName)
		
		
		//------------------------------------------------------------
		// Load the Template
		//------------------------------------------------------------
		
		
		Logger.info "Provisioning Template: "
		Logger.disablePrefix {
			Logger.info templateText
		}
		
		ErrorAccumulator errors = new ErrorAccumulator() 
		Map awsProvisionTemplate = parseProvisionTemplate(templateText)
		
		AwsSpecification specification
		if (! _skipAwsProcessing) {
			specification = processAwsSectionOfTemplate(awsProvisionTemplate, errors)
		}
		
		// Process ucdTemplate section
		UcdTemplateDefinition ucdTemplateDefinition = new UcdTemplateDefinition(errors,applicationServices,ucdApplication)
		if (! awsProvisionTemplate.containsKey('ucdTemplate')) {
			Logger.info "WARNING: The 'ucdTemplate' section is missing from the provisioning template, so no UCD Components will be configured."
		} else {
			ucdTemplateDefinition.loadTemplate(awsProvisionTemplate.ucdTemplate, ucdAgents)
		}

		if (errors.hasErrors()) {
			errors.logErrors(LoggerLevel.ERROR)
			throw new AbortPluginException('Failing with errors')
		}
		
		
		//------------------------------------------------------------
		// Set the actual blue-green option
		//------------------------------------------------------------

		
		// if the environment(s) already exist, use current environment's settings
		if (ucdEnvironmentProvisionMgr.doesEnvironmentAlreadyExist()) {
			blueGreen = ucdEnvironmentProvisionMgr.getExistingProvisionData().isBlueGreen()
		} else {
			// Does blueGreen even make sense?  It only makes sense if the template has something that supports blue/green.
			if (blueGreen) {
				if (ucdTemplateDefinition.doAnyComponentsSupportBlueGreen() || specification.doAnyRequestedAwsResourcesSupportBlueGreen()) {
					// blue green is ok because supported by AWS Product requests and/or UCD Components
				} else {
					// There is no point to provisioning blueGreen because the template has no blueGreen support
					blueGreen = false
				}
			}
		}
		
		Logger.info "Configuring for Blue-Green deployments? " + blueGreen
		
		
		//------------------------------------------------------------
		// Setup the base context
		//------------------------------------------------------------

		
		BaseEnvironmentProvisionContext baseContext = new BaseEnvironmentProvisionContext(blueGreen)
		ProvisionContext blueContext = baseContext.getBlueChildContext()
		ProvisionContext greenContext = baseContext.getGreenChildContext()
		baseContext.setBaseEnvironmentName(requestedEnvName)
		baseContext.setEnvironmentType(requestedEnvType)
		baseContext.setTokensForAllContexts( tokens )
		baseContext.setApplication( ucdApplication )
		baseContext.setAppCode(appCode)
		baseContext.setAwsRegion(awsRegion)
		baseContext.setAwsAccountId(awsAccountId)
		baseContext.setAwsRole(awsRole)
		baseContext.setUcdAgents(ucdAgents)
		ucdEnvironmentProvisionMgr.addExistingEnvironmentToContext(baseContext)
		
		if (! _skipAwsProcessing) {
			addAwsServiceDefinitionsToContexts( baseContext, specification )
		}
		addDesiredEnvironmentsAndResourceBranchesToContexts( baseContext, requestedEnvName, 'a', 'b' )
		
		
		
		//------------------------------------------------------------
		// Define all existing AWS Product Instances
		//------------------------------------------------------------


		if (! _skipAwsProcessing) {
			
			// *** PROCESS PRODUCT INSTANCES ALREADY IN THE ENVIRONMENT ***
			ucdEnvironmentProvisionMgr.addExistingAwsProductInstancesToContext( baseContext, awsServiceCatalog )
	
			// *** PROCESS PRODUCT INSTANCES PASSED AS PARAMETERS INTO THE PLUGIN ***
			existingAwsProductInstancesProperties.each { String name, String provisionedProductId ->
				String blueSuffix = '.blue'
				String greenSuffix = '.green'
				if (name.toLowerCase().endsWith(blueSuffix)) {
					if (blueGreen) {
						String baseName = name.substring(0,name.length()-blueSuffix.length())
						blueContext.addExistingAwsProductInstanceToContext( baseName, new AwsProductInstance(awsServiceCatalog, provisionedProductId), false, true )
					}
				} else if (name.toLowerCase().endsWith(greenSuffix)) {
					if (blueGreen) {
						String baseName = name.substring(0,name.length()-greenSuffix.length())
						greenContext.addExistingAwsProductInstanceToContext( baseName, new AwsProductInstance(awsServiceCatalog, provisionedProductId), false, true )
					}
				} else {
					baseContext.addExistingAwsProductInstanceToContext( name, new AwsProductInstance(awsServiceCatalog, provisionedProductId), false, true )
				}
			}
			
		}
		
		
		//------------------------------------------------------------
		// Provision AWS Products and Map to UCD
		//------------------------------------------------------------

		
		baseContext.debug_displayPlaceholders( LoggerLevel.DEBUG, 'Product Instance Placeholders just before provisioning' )

		// Provision the AWS Services
		if (! _skipAwsProcessing) {
			try {
				if (! provisionAwsProductInstances( baseContext )) {
					provisioningFailed = true
				}
			}
			catch (Exception e) {
				// An exception occured while provisioning AWS.  Display the exception and finish
				Logger.printStackTrace( LoggerLevel.ERROR, e)
			}
		}
		
		// Create the target UCD Environments and Resource Tree Nodes
		ucdEnvironmentProvisionMgr.createTargetUcdStructure(baseContext, ucdTemplateDefinition,requestedEnvType)

		// Display the AWS Product Instance Placeholders
		baseContext.debug_displayPlaceholders( LoggerLevel.DEBUG, 'placeholders just before saving data to environments' )
		
		
		
		//------------------------------------------------------------
		// Save/update persistent data
		//------------------------------------------------------------
		
		
		ucdEnvironmentProvisionMgr.saveDataToEnvironments(baseContext)
		
		
		
		//------------------------------------------------------------
		// Report and results and finish
		//------------------------------------------------------------

		
		summaryReport.displaySummary()
		
		if (provisioningFailed) {
			throw new AbortPluginException('Provisioning failed, but environment(s) still created/updated.') 
		} else {
//			Logger.info "Provisioning completed successfully."
		}

	}
	
	/**
	 * Processes the AWS information from the parsed template file.
	 * @param provisionTemplate The Json parsed (but not processed) JSON template.
	 * @param errors Accumulated list of errors.
	 * @return The AWS Template definition in the form of the class AwsSpecification.
	 */
	public AwsSpecification processAwsSectionOfTemplate(Map provisionTemplate, ErrorAccumulator errors) {
		AwsSpecification specification
		specification = new AwsSpecification( awsServiceCatalog, errors )
		if (! provisionTemplate.containsKey('awsTemplate')) {
			//errors.addError( "The required 'awsTemplate' section is missing from the provisioning template." )
		} else {
			specification.loadTemplate(provisionTemplate.awsTemplate)
		}
		return specification
	}
	
	/**
	 * Parses the template text using JsonSlurper.
	 * @param templateText The template
	 * @return The Map root of the template.
	 */
	public Map parseProvisionTemplate( String templateText ) {
		Map awsProvisionTemplate
		try {
			awsProvisionTemplate = new groovy.json.JsonSlurper().parseText( JsonHelper.removeCommentLines(templateText) )
		}
		catch (Exception e) {
			Logger.println(LoggerLevel.INFO, e.message )
			// sanitize the groovy information
			StackTraceUtils.deepSanitize(e)
			Logger.printStackTrace(LoggerLevel.INFO, e)
			throw new AbortPluginException("Unable to parse the AWS Template File")
		}
		return awsProvisionTemplate
	}
	
	/**
	 * Verify the input configuration files.  If there are problems, list them and fail.
	 * @param baseContext The base context for provisioning.
	 * @param specification awsManifest.json
	 * @param ucdTemplateDefinition ucdTemplateDefinition.json
	 */
	void verifyInputData( BaseEnvironmentProvisionContext baseContext, AwsSpecification specification, UcdTemplateDefinition ucdTemplateDefinition ) {
		boolean validationFailed = false
		
		// Convert to AwsSpecification
//		specification.performFullVerification()
	
		if (! specification.isValid()) {
			Logger.error "Validation of the AWS Specification/Manifest failed with the following errors..."
			specification.logValidationFailures(LoggerLevel.ERROR)
			validationFailed = true
		}
		
		// Make sure that all of the named components exist and are part of the application
		ucdTemplateDefinition.getAllComponentDefs().each { UcdComponentDef componentDef ->
			if (! ucdConnectionServices.getComponentServices().doesComponentExist(componentDef.componentName)) {
				ucdTemplateDefinition.tagValidationError("There is no component named '${componentDef.componentName}'")
			} else if (! baseContext.getApplication().hasComponent(componentDef.componentName)) {
				ucdTemplateDefinition.tagValidationError("The component '${componentDef.componentName}' is not part of the application '${baseContext.getApplication().getName()}'")
			}
		}
			
		if (! ucdTemplateDefinition.isValid()) {
			Logger.error "Validation of the UCD Components Def failed with the following errors..."
			ucdTemplateDefinition.logValidationFailures(LoggerLevel.ERROR)
			validationFailed = true
		}
		if (validationFailed) {
			throw new AbortPluginException("Validation failed")
		}
	}
	
	/**
	 * Adds all of the service definitions from 'specification' to the context applying blue-green as appropriate.
	 * @param baseContext
	 * @param specification
	 */
	public void addAwsServiceDefinitionsToContexts( BaseEnvironmentProvisionContext baseContext, AwsSpecification specification ) {
		specification.getServiceDefinitions().each { AwsServiceDefinition serviceDefinition ->
			if (serviceDefinition.shouldProvisionSeparateBlueGreenInstances() && baseContext.isProvisioningBlueGreen()) {
				// add to Blue and green contexts
				baseContext.getBlueChildContext().addAwsProductInstancePlaceholder(new AwsProductInstancePlaceholder(serviceDefinition))
				baseContext.getGreenChildContext().addAwsProductInstancePlaceholder(new AwsProductInstancePlaceholder(serviceDefinition))
			} else {
				// add to base context
				baseContext.addAwsProductInstancePlaceholder(new AwsProductInstancePlaceholder(serviceDefinition))
			}
		}
	}
	
	/**
	 * Adds all the names of the environments and resource tree branches that are needed for provisioning to the
	 * context.
	 * @param baseContext The base context.
	 * @param requestedEnvName The requested environment name.
	 * @param blueSuffix The suffix to use for any blue environment/resources, such as 'BLUE' or 'pair1'.
	 * @param blueSuffix The suffix to use for any blue environment/resources, such as 'GREEN' or 'pair2'.
	 */
	public void addDesiredEnvironmentsAndResourceBranchesToContexts( BaseEnvironmentProvisionContext baseContext, String requestedEnvName,
		String blueSuffix, String greenSuffix ) {
		if (baseContext.isProvisioningBlueGreen()) {
			baseContext.getBlueChildContext().environmentName = requestedEnvName + '-' + blueSuffix
			baseContext.getGreenChildContext().environmentName = requestedEnvName + '-' + greenSuffix
			baseContext.resourceBranchName = requestedEnvName
			baseContext.getBlueChildContext().resourceBranchName = requestedEnvName + '-' + blueSuffix
			baseContext.getGreenChildContext().resourceBranchName = requestedEnvName + '-' + greenSuffix
		} else {
			baseContext.environmentName = requestedEnvName
			baseContext.resourceBranchName = requestedEnvName
		}
	}
	
	/**
	 * Check the existingAwsProductInstances properties to see if there is an existing AWS Product instance that should
	 * be used for the service definition.
	 * @param logicalName - the logical name of the Product Instance definition.
	 * @param baseContext The context.  In particular, this may be base, green or blue.
	 * @param existingAwsProductInstances Map of existing AWS Product Instances
	 * <ul>
	 *		<li>String key - logical name of the Product Instance as per Template logical
	 *			names.  Optionally suffixed with '.blue' or '.green'</li>
	 *		<li>Map value - structured map with following fields</li>
	 *			<ul>
	 * 			<li>provisionedProductId - The AWS Provisioned ID</li>
	 *			<li>boolean provisioned - Was this Product Instance provisioned by this plugin.  Or, was it pre-defined.</li>
	 *			</ul>
	 * </ul>
	 * @return If existing instance should be used, returns Map entry from the instances.  Returns null if no existing instance found.
	 */
	private Map lookupExistingAwsProductInstance( String logicalName, ProvisionContext context, Map existingAwsProductInstances ) {
		Map retval = null
		String existingAwsProductName = ''
		if (context.isBlueContext()) {
			logicalName = logicalName + '.blue'
		} else if (context.isGreenContext()) {
			logicalName = logicalName + '.green'
		}

		existingAwsProductInstances.each { String propertyName, Map propertyValue ->
			if (propertyName.equalsIgnoreCase(logicalName)) {
				retval = propertyValue
			}
		}
		return retval
	}
	
	/**
	 * <p>Provisions all outstanding AWS Product requests from the context which don't have
	 * an instance yet.  Specifically, it looks for instance Placeholders in the contexts which have
	 * a definition but no instance.</p>
	 * <p>This function displays the ongoing progress with messages like "provisioning ...", "succesfully provisioned..."
	 * and "failed to provision..." along with supporting inforamtion.  For example, when provisioning, it displays
	 * all of the parameters and tags.</p>
	 * <p>As instances are successful OR fail, appropriate calls are made to the SummaryReport singleton.</p>
	 * <p>When an instance is successfully provisioned, the Placeholder contains both the original definition and the
	 * new instance</p>
	 * <p>When an instance fails to provision, it is de-provisioned from AWS.  The Placeholder is left with the
	 * original definition and no (a null) instance.</p>
	 * @param baseContext The base context.
	 * @param timoutInMinutes How long to wait for completion, including waiting for instances to provision and failed instances to deprovision.
	 * Set to zero to never time out.
	 * @return Was all of the provisioning successful?  If even a single Product failed to provision,
	 * then this returns false.
	 */
	public boolean provisionAwsProductInstances(BaseEnvironmentProvisionContext baseContext, int timeoutInMinutes = 60 ) {
		boolean methodReturnCode = true
		
		final int PROVISIONING = 1		// provisioning started and still progressing
		final int PROVISIONED = 2		// successfully provisioned
		final int DEPROVISIONING = 3	// it failed to provision and is now being deprovisioned
		final int DEPROVISIONED = 4		// Successfully deprovisioned

		long startTime = System.currentTimeMillis()
		
		/**
		 * List of the pending provisioned Product Instances.  Each entry is a map with...
		 * <ul>
		 * <li>int status - One of the constants: PROVISIONING, PROVISIONED, DEPROVISIONING, DEPROVISIONED.</li>
		 * <li>AwsProductInstancePlaceholder placeholder - For PROVISIONING and PROVISIONED, this is the placeholder which has the instance.
		 * If it fails, the instance must be removed from the placeholder.</li>
		 * <li>AwsServiceInstance instance - The instance being provisioned/deprovisioned.  This is valid for any state.</li>
		 * <li>ProvisionContext context - The context that the placeholder is in (such as 'Blue Environment').
		 * <li>String deprovisionRecordId - ONLY used when deprovisioning.  It is the recordId used to track the status of the deprovisioning.
		 * </ul>
		 */
		List<Map> pendingInstances = []
		
		// Loop through contexts and Product Instance Placeholders to find the products that need to be provisioned.
		baseContext.eachContextInTree { ProvisionContext context ->
			context.getContextSpecificAwsProductInstancePlaceholders().each { AwsProductInstancePlaceholder awsProductInstancePlaceholder ->
				// If there is an Instance Request, aka definition but no instance, then provision it!!
				AwsServiceDefinition serviceDefinition = awsProductInstancePlaceholder.getAwsServiceDefinition()
				AwsServiceInstance serviceInstance = awsProductInstancePlaceholder.getAwsServiceInstance()
				if (serviceDefinition && (! serviceInstance)) {
					// **** PROVISION ****
					// Make sure that the Product Instance name isn't already in use
					if (awsServiceCatalog.doesNamedProvisionedProductExist(serviceDefinition.calculateProvisionedName( context ))) {
						// A product instance with he given name already exists!!
						methodReturnCode = false
						Logger.info "Failed to provision '${serviceDefinition.calculateProvisionedName( context )}' because a provisioned Product Instance already exists with that name."
						summaryReport.addFailedProvisionRequest( awsProductInstancePlaceholder, context )
					} else {
						// provision
						AwsServiceInstance requestedInstance = serviceDefinition.provisionInstance(context)
						if (requestedInstance) {
							
							awsProductInstancePlaceholder.setAwsServiceInstance( requestedInstance )
						
							// Add this to the pendingInstances list
							pendingInstances << [ status: PROVISIONING, placeholder: awsProductInstancePlaceholder, instance: requestedInstance, context: context ]
							
						} else {
							// failed to even start the provisioning process
							methodReturnCode = false
							summaryReport.addFailedProvisionRequest( awsProductInstancePlaceholder, context )
						}
					}
				}
			}
		}

		// wait as long as any instances are provisioning or deprovisioning
		boolean stillProvisioningOrDeprovisioning = true
		boolean timedOut = false
		// if nothing was provisioned, then stillProvisioning is false
		if (pendingInstances.size() == 0) {
			stillProvisioningOrDeprovisioning = false
		}
		while (stillProvisioningOrDeprovisioning && (! timedOut)) {
			
			// sleep one minute
			Thread.sleep( 1000*60 )
			
			// set 'stillProvisioning' to false, but if any instance is still provisioning it is reset to true
			stillProvisioningOrDeprovisioning = false
			
			// Check all of the pendingInstances, but only if their status is PROVISIONING or DEPROVISIONING
			pendingInstances.each { Map pendingInstance ->
				
				if (pendingInstance.status == PROVISIONING) {
					
					AwsServiceInstance serviceInstance = pendingInstance.instance
					AwsProductInstancePlaceholder placeholder = pendingInstance.placeholder
					if (serviceInstance.isAvailable(true)) {
						//
						// SUCCESSFULLY PROVISIONED
						//
						// Update list entry status
						pendingInstance.status = PROVISIONED
						// Update summary report
						summaryReport.addSuccessfulProvisionRequest( pendingInstance.placeholder, pendingInstance.context )
						// load and display the AWS output properties
						AwsDescribeRecordResult resultDescription = serviceInstance.getAwsInstanceData()
						Logger.info "The Provisioned Product instance '${serviceInstance.getProvisionedName()}' of '${serviceInstance.getAwsServiceDefinition().getAwsProduct().getName()}' returned the following data, which can referenced in the component properties...\n"
						Logger. disablePrefix {
							Logger.info resultDescription.getRawJsonResults()
						}
						Logger.info ""

					} else if (serviceInstance.isUnderChange(false)) {
						//
						// STILL STARTING
						//
						stillProvisioningOrDeprovisioning = true
					} else {
						//
						// FAILED (status is NOT Under Change or Available)
						//
						stillProvisioningOrDeprovisioning = true			// need to wait for this instance to deprovision
						// At least one provisioning failed, so set function return value to false (aka failure)
						methodReturnCode = false
						// Update list entry status
						pendingInstance.status = DEPROVISIONING
						// Display error message
						String statusMessage = serviceInstance.getAwsStatusMessage()
						if (statusMessage) {
							statusMessage = " - " + statusMessage
						}
						Logger.error "Unexpected AWS Status of ${serviceInstance.getAwsStatus()} received for newly provisioned Product ${serviceInstance.getProvisionedName()}" + 
							statusMessage + "\n" + recursivelyLogCFStackErrors(serviceInstance.getCloudFormationStackId(),"    ")

						// Update summary report
						summaryReport.addFailedProvisionRequest( pendingInstance.placeholder, pendingInstance.context )
						// TODO - display the CF Stack events
						// Remove the instance from the Placeholder
						placeholder.setAwsServiceInstance(null)
						// De-provision the instance
						try {
							pendingInstance.deprovisionRecordId = awsServiceCatalog.terminateProvisionedProduct( serviceInstance.getProvisionedName() )
							pendingInstance.status = DEPROVISIONING
						}
						catch (Exception e) {
							pendingInstance.status = DEPROVISIONED
							Logger.error "Unable to de-provision ${serviceInstance.getProvisionedName()} - " + e.getMessage()
						}
					}
					
				} else if (pendingInstance.status == DEPROVISIONING) {
					
					AwsServiceInstance serviceInstance = pendingInstance.instance
					AwsDescribeRecordResult recordResult = awsServiceCatalog.describeRecord( pendingInstance.deprovisionRecordId )
					if (recordResult.getStatus() == 'IN_PROGRESS') {
						//
						// STILL DE-PROVISIONING
						//
						stillProvisioningOrDeprovisioning = true
					} else if (recordResult.getStatus() == 'SUCCEEDED') {
						//
						// SUCCESSFULLY DEPROVISIONED
						//
						pendingInstance.status = DEPROVISIONED
					} else {
						//
						// FAILED TO DEPROVISION
						//
						// flag as de-provisioned, but display error message
						pendingInstance.status = DEPROVISIONED
						Logger.error "Attempt to de-provision ${serviceInstance.getProvisionedName()} FAILED with an AWS Status of ${recordResult.getStatus()}"
					}
				}
			}
			
			// Check for timeout
			long currentTime = System.currentTimeMillis()
			if ((timeoutInMinutes>0) && ((currentTime - startTime) > (timeoutInMinutes * 60 * 1000))) {
				timedOut = true
			}

		}
		
		// TODO - if timedOut, figure out and handle timed out provisioning and/or deprovisioning requests
		
		return methodReturnCode
	}
	
	/**
	 * <p>Recursively assemble errors in the named Cloudformation Stack into one string.  The recursion processes errors in nested stacks.
	 * For example, if you Provision a ServiceCatalog product that is an EB App + Environment, it has a nested stack to
	 * create the EB App and a nested stack to create the EB Environment.  This is called when a call to provision a
	 * product fails in order to see the detailed messages that caused the failure.</p>
	 * @param cloudformationStackId The ID of the stack to list errors for.
	 * @param indentation  The indentation spacing to put in front of each line.
	 * @return Returns a multiple line string with the nested errors.
	 */
	private String recursivelyLogCFStackErrors( String cloudformationStackId, String indentation ) {
		CloudformationStack cfStack = new CloudformationStack(awsCloudformation, cloudformationStackId)
		String retval = ''
		if (cloudformationStackId) {
			// This function is used to display more detailed error information.  If this fails with an exception,
			// catch the exception (DO NOT simply pass it on), and return a canned message instead
			try {
				retval = indentation + "Displaying errors for Cloudformation Stack: " + cfStack.getDescription() + " (Stack ID: ${cloudformationStackId})"
				cfStack.describeEachStackEvent { Map stackEvent ->
					String resourceStatus = stackEvent.ResourceStatus
					if (resourceStatus.contains("FAILED")) {
						String reason = ''
						String nestedStackId = ''
						if (stackEvent.containsKey('ResourceStatusReason')) {
							reason = stackEvent.ResourceStatusReason
						}
						String entityLabel = ''
						if (stackEvent.ResourceType=="AWS::CloudFormation::Stack") {
							if (stackEvent.PhysicalResourceId == cloudformationStackId) {
								entityLabel = stackEvent.LogicalResourceId
							} else {
								entityLabel = 'nested stack'
								nestedStackId = stackEvent.PhysicalResourceId
							}
						} else {
							entityLabel = stackEvent.LogicalResourceId
						}
						retval = retval + "\n" + indentation + "${resourceStatus} for ${entityLabel} - ${reason}"
						if (nestedStackId) {
							retval = retval + "\n" + recursivelyLogCFStackErrors(nestedStackId,indentation + "   ")
						}
					}
				}
			} catch (Exception e) {
				Logger.error "Unable to retrieve detailed error stack information - " + e.message
			}
		} else {
			// There is NO associated cloudformation stack
			retval = indentation + 'No Cloudformation Stack found'
		}
		return retval
	}

	/**
	 * Sets the teams for the resourceNode to the teams (and ONLY the teams).  This does NOT
	 * set any resource node types.
	 */
	private void setResourceNodeTeams( ResourceNode resourceNode, List<Team> teams ) {
		resourceNode.removeLinksToAllTeams()
		teams.each { Team team ->
			resourceNode.addLinkToTeam(team)
		}
	}
}
