package plugin

import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.provision.ucd.SummaryReport
import com.fanniemae.provision.ucd.UcdEnvironmentProvisionMgr
import com.fanniemae.provision.ucd.persistence.PersistentProvisionData
import com.fanniemae.ucd.aws.api.describeRecord.AwsDescribeRecordResult
import com.fanniemae.ucd.aws.api.services.servicecatalog.AwsServiceCatalog
import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProductInstance
import com.fanniemae.ucd.aws.api.services.servicecatalog.product.AwsProductInstanceTerminationRequestRecord
import com.fanniemae.ucd.aws.provision.context.BaseEnvironmentProvisionContext
import com.fanniemae.ucd.aws.provision.context.ProvisionContext
import com.fanniemae.ucd.aws.provision.context.data.AwsProductInstancePlaceholder
import com.fanniemae.ucd.aws.provision.service.instance.AwsServiceInstance
import com.fanniemae.ucd.aws.provision.ucd.UcdConfigurationDefinition
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.processrequest.ProcessRequest
import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.css.ucd.services.ApplicationServices
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel
import com.ibm.issr.core.plugin.AbortPluginException
import com.ibm.issr.core.string.SimulateMultipleLines

import groovy.json.JsonOutput

/**
 * Implementation of the 'Provision AWS Specification' step.
 */
class DeprovisionEnvironmentImpl  {
	// plugin constructor inputs
	private UcdServerConnection ucdServer
	private UcdConnectionServices ucdConnectionServices
	private Properties outProps
	private String _applicationProcessId
	
	private boolean simulateAwsCalls = false
	
	// internal data
	private UcdConfigurationDefinition ucdConfigurationDefinition
	
	private AwsConnection awsConnection
	private AwsServiceCatalog awsServiceCatalog
	
	private SummaryReport summaryReport = SummaryReport.getInstance()

	
	/**
	 * Constructor.
	 * @param ucdServer Handle to UCD Server.
	 * @param outProps Properties to set as plugin step output properties.
	 * @param simulateAwsCalls Should calls to AWS be simulated?  This is useful because it lets you test everything
	 * else in a debugging IDE (Eclipse or IntelliJ) session.
	 */
	public DeprovisionEnvironmentImpl( UcdServerConnection ucdServer, 
		Properties outProps, String applicationProcessId ) {
		this.ucdServer = ucdServer
		ucdConnectionServices = new UcdConnectionServices(ucdServer)
		this.outProps = outProps
		_applicationProcessId = applicationProcessId
	}
	
	/**
	 * Call this function to turn on the AWS Simulation mode and to set data needed for the simulation.
	 */
	public void enableAwsSimulation() {
		this.simulateAwsCalls = true
	}

	/**
	 * Given the input data, this function executes the step which performs the de-provisioning.
	 * @param awsRegion The AWS Region
	 * @param awsAccountId The AWS AccountId for authentication
	 * @param awsRole THe AWS Role for authentication
	 * @param environmentName The environment name.  Note that this may be the name of an environment or the 'base name'.  For
	 * example, if you provide an environmentName of 'DEV01', but the actual environments are 'DEV01-a' and 'DEV01-b', this
	 * will find the actual environment names.
	 * @param applicationName The name of the application.
	 * @param completelyDeprovision If this is true, then the environments are completely deprovisioned including
	 * all AWS Product Instances and all associated UCD Resource branches.  If this is true, then the 'awsInstancesToDeprovision' is
	 * ignored.
	 * @param awsInstancesToDeprovision The list (multiple line with '|' support) of AWS Instances to deprovision.  This
	 * parameter is ignored if completelyDeprovision is true.  Each line has an AWS Instance to deprovision.  In addition,
	 * multiple AWS Instances can be listed on one line with '|' between each line.  Each listed AWS Product Instance can be one of ...
	 * <ul>
	 * <li>Template logical name, such as 'eb'.  If the logical name has different Blue and Green versions, then BOTH the blue
	 * and green are deprovisioned!!</li>
	 * <li>AWS Product Instance Name</li>
	 * <li>AWS Product Instance ID</li>
	 * </ul>
	 */
	public void executeDeprovisioning( String awsRegion, String awsAccountId, 
		String awsRole, String environmentName, String applicationName, boolean completelyDeprovision, String awsInstancesToDeprovision ) {
		
		// Set this to true if anything fails (to the point where the plugin step should fail)
		boolean deprovisioningFailed = false
		
		summaryReport.setTitle("Deprovision")
		
		
		//------------------------------------------------------------
		// Validate and load existing environment(s) data
		//------------------------------------------------------------

		
		ProcessRequest appProcessRequest = ucdConnectionServices.getProcessRequestServices().getProcessRequest( _applicationProcessId )
		summaryReport.addLine("Application Process: " + appProcessRequest.url, SummaryReport.INTRO_SECTION)
		
		// Verify and get the UCD application
		ApplicationServices applicationServices = ucdConnectionServices.getApplicationServices()
		if (! applicationServices.doesApplicationExist(applicationName)) {
			throw new AbortPluginException( "Unable to find application named '${applicationName}'" )
		}
		Application application = applicationServices.getApplication(applicationName)
		
		
		UcdEnvironmentProvisionMgr ucdEnvironmentProvisionMgr = new UcdEnvironmentProvisionMgr(ucdConnectionServices, application, environmentName)
		boolean environmentExists = ucdEnvironmentProvisionMgr.doesEnvironmentAlreadyExist()
		if (! environmentExists) {
			throw new AbortPluginException("The UCD Application '${applicationName}' doesn't contain an environment named '${environmentName}'")
		}
		PersistentProvisionData persistentProvisionData = ucdEnvironmentProvisionMgr.getExistingProvisionData()
		boolean blueGreen = persistentProvisionData.isBlueGreen()
		
		
		
		//------------------------------------------------------------
		// Has this de-provision request (as defined by App Process ID) already run?
		//------------------------------------------------------------

				
		if (hasDeprovisionAlreadyRunForAppProcessId( _applicationProcessId, persistentProvisionData )) {
			Logger.info "De-provisioning has already run for Application Process ID ${_applicationProcessId}"
			System.exit(0)
		} else {
			flagDeprovisionRunningForAppProcessId( _applicationProcessId, persistentProvisionData )
		}

		
		
		//------------------------------------------------------------
		// Open AWS Connection
		//------------------------------------------------------------

		
		// Initiate AwsConnection, including starting AWS working session and authentication
		if (! simulateAwsCalls) {
			awsConnection = new AwsConnection(awsRegion)
			awsConnection.initiateAwsSession( awsRole )
			awsServiceCatalog = new AwsServiceCatalog( awsConnection )
		}
		
		
		
		//------------------------------------------------------------
		// Setup the base context
		//------------------------------------------------------------

		
		BaseEnvironmentProvisionContext baseContext = new BaseEnvironmentProvisionContext(blueGreen)
		ProvisionContext blueContext = baseContext.getBlueChildContext()
		ProvisionContext greenContext = baseContext.getGreenChildContext()
		// baseContext.setBaseEnvironmentName(requestedEnvName)
		// baseContext.setEnvironmentType(requestedEnvType)
		// baseContext.setTokensForAllContexts( tokens )
		// baseContext.setAppCode(appCode)
		// baseContext.setUcdAgents(ucdAgents)
		baseContext.setApplication( application )
		baseContext.setAwsRegion(awsRegion)
		baseContext.setAwsAccountId(awsAccountId)
		baseContext.setAwsRole(awsRole)
		ucdEnvironmentProvisionMgr.addExistingEnvironmentToContext(baseContext)
		
		// if (! _skipAwsProcessing) {
		// 	addAwsServiceDefinitionsToContexts( baseContext, specification )
		// }
		// addDesiredEnvironmentsAndResourceBranchesToContexts( baseContext, requestedEnvName, 'a', 'b' )
		
		// *** PROCESS PRODUCT INSTANCES ALREADY IN THE ENVIRONMENT ***
		ucdEnvironmentProvisionMgr.addExistingAwsProductInstancesToContext( baseContext, awsServiceCatalog )
		
		// TODO - change next line to .DEBUG
		baseContext.debug_displayPlaceholders( LoggerLevel.INFO, 'Product Instance Placeholders after loading environment(s)' )
		
		
		
		//------------------------------------------------------------
		// Build list of AWS Product Instances that need to be deprovisioned
		//------------------------------------------------------------
		
		
		
		// The list of AWS instance placeholders that need to be deprovisioned.
		// Each entry is a Map structure.  The initial values are:
		//	- AwsProductInstancePlaceholder placeholder
		//		The placeholder to deprovision
		//	- ProvisionContext context
		//		The context of the placeholder
		// Additional fields may be added to manage the deprovisioning process.  Any such additional fields
		// aren't relevant to this function.
		List<Map> listOfPlaceholdersToDeprovision = []
		
		// This is of the instances to deprovision.  Each entry is a Map structure with the following fields
		//	- String instanceLabel
		//		The Template Name, AWS Instance Name or AWS Instance ID to deprovision
		//	- boolean found
		//		Has this entry been found in the context?  If found multiple times, no special flag is set.
		// This list is ONLY filled in if 'completelyDeprovision' isn't true.
		List<Map> listOfRequestedInstancesToDeprovision = []
		
		if (completelyDeprovision) {
			Logger.info "Requesting to completely deprovision the AWS Product Instances and UCD Environment(s)"
		} else {
			awsInstancesToDeprovision = SimulateMultipleLines.convertPipesToNewLines(awsInstancesToDeprovision)
			awsInstancesToDeprovision.eachLine { String instanceLabel ->
				if (instanceLabel) {
					instanceLabel = instanceLabel.trim()
				}
				if (instanceLabel) {
					Logger.info "Requesting to deprovision AWS Instance: " + instanceLabel
					listOfRequestedInstancesToDeprovision << [ instanceLabel: instanceLabel, found: false ]
				}
			}
		}
		
		// Iterate the placeholders in the context tree
		baseContext.iterateContextTree { ProvisionContext context ->
			context.getContextSpecificAwsProductInstancePlaceholders().each { AwsProductInstancePlaceholder placeholder ->
				// Note that only Product Instances provisioned by this environment can be de-provisioned
				if (placeholder.getAwsServiceInstance() && placeholder.getAwsServiceInstance().isProvisionedByPlugin()) {
					boolean isMatch = false
					if (completelyDeprovision) {
						isMatch = true
					} else {
						// Search list of requested deprovisionings for a match
						Map matchingEntry = listOfRequestedInstancesToDeprovision.find { Map candidateEntry ->
							AwsServiceInstance awsServiceInstance = placeholder.getAwsServiceInstance()
							String instanceLabel = candidateEntry.instanceLabel
							if (awsServiceInstance) {
								if (placeholder.getName()==instanceLabel) {
									return true
								} else if (awsServiceInstance.getProvisionedName()==instanceLabel) {
									return true
								} else if (awsServiceInstance.getProvisionedId()==instanceLabel) {
									return true
								} else {
									return false
								}
							} else {
								return false
							}
						}
						if (matchingEntry) {
							isMatch = true
							matchingEntry.found = true
						}
					}
					if (isMatch) {
						// this placeholder instance should be de-provisioned!!
						listOfPlaceholdersToDeprovision << [ placeholder: placeholder, context: context ]
						Logger.debug "Added the following to the instances to be deprovisioned: ${placeholder.toString()} for ${context.getContextName()}"
					}
				}
			}
		}
		
		// Check to see if any requested instances weren't found
		listOfRequestedInstancesToDeprovision.each { Map requestedEntry ->
			if (! requestedEntry.found) {
				// This entry wasn't found - log it and register it with summary report
				String instanceLabel = requestedEntry.instanceLabel
				String msg = "Requested to deprovision AWS Product Instance '${instanceLabel}', but the instance wasn't found in the environment(s)"
				Logger.error msg
//				summaryReport.addLine( "Failure - " + msg )
				deprovisioningFailed = true
			}
		}
		
		
		
		//------------------------------------------------------------
		// Deprovision AWS Product Instances
		//------------------------------------------------------------
		
		
		if (! deprovisionAwsInstancesViaPlaceHolders( listOfPlaceholdersToDeprovision )) {
			deprovisioningFailed = true
		}


		
		

//		// Verify and access the environment
//		if (! application.doesEnvironmentExist(environmentName)) {
//		}
//		
//		Environment environment = application.getEnvironment(environmentName)
//		environments << environment
//
//		// Is this a paired (blue-green) environment?
//		String linkedPropertyName = 'pairedBlueGreenEnvironment'
//		if (environment.hasAdHocProperty( linkedPropertyName )) {
//			String pairedEnvironmentName = environment.getAdHocProperty(linkedPropertyName)
//			Logger.info "Also de-provisioning the paired blue-green environment named '${pairedEnvironmentName}'"
//			if (! application.doesEnvironmentExist(pairedEnvironmentName)) {
//				throw new AbortPluginException("The UCD Application '${applicationName}' doesn't contain an environment named '${pairedEnvironmentName}'")
//			}
//			Environment pairedEnvironment = application.getEnvironment(pairedEnvironmentName)
//			environments << pairedEnvironment
//		}
//
//
//		// De-provision the AWS Resources
//		/**
//		 * In this map, the key is the provisioned Product Name.  The value is a Map with the following fields:
//		 * <ul>
//		 * <li>String recordId  - The AWS RecordId for the name.
//		 * <li>boolean deleteFailed - It failed to delete the resource.</li>
//		 * <li>boolean deleteCompleted - Succussfully deleted.</li>
//		 * </ul>
//		 */
//		Map awsResources = [:]
//		environments.each { Environment env ->
//			if (env.hasAdHocProperty( 'awsResources' )) {
//				String awsResourcesJson = env.getAdHocProperty('awsResources')
//				List awsResourcesList = new JsonSlurper().parseText(awsResourcesJson)
//				awsResourcesList.each { Map entry ->
//					if (entry.provisioned) {
//						awsResources[ entry.provisionedProductName ] = [ deleteFailed: false, deleteCompleted: false]
//					}
//				}
//			}
//		}
//		// Get a List of the product names that need to be terminated
//		List<String> provisionedProductNames = []
//		awsResources.each { String awsProvisionedProductName, def mapValue ->
//			Logger.info "De-provisioning AWS Product instance named: ${awsProvisionedProductName}"
//			provisionedProductNames << awsProvisionedProductName
//		}
//		TerminateProvisionProductsResult terminationResults = awsServiceCatalog.terminateProvisionedProductsAndWait( provisionedProductNames )
//		if (! terminationResults.successful) {
//			// At least one Product Instance failed to terminate
//			terminationResults.instanceResults.each { TerminateProvisionProductResult instanceResults ->
//				if (! instanceResults.successful) {
//					Logger.error instanceResults.errorMsg
//				}
//			}
//			throw new AbortPluginException( "Unable to terminate the AWS Product Instance(s)" )
//		}



		//------------------------------------------------------------
		// Deprovision UCD Resources and Environment OR update persistent data
		//------------------------------------------------------------


		if (completelyDeprovision) {
			// The list of environments to de-provision (along with their Base Resources)
			List<Environment> environments = []
			
			// Convert environments from the Context tree into a List of environments
			baseContext.iterateContextsWithEnvironments { ProvisionContext context ->
				Environment environment = context.getEnvironment()
				if (environment) {
					environments << environment
				}
			}
//			
//			// TODO - delete this test block
//			environments.each { Environment environment ->
//				Logger.info "De-provision UCD Environment '${environment.getName()}'"
//			}
			
			
			// Delete the base resources, which may be shared by multiple environments
			// Get list (as a map) of base resources in the environments
			Map baseResources = [:]			// key = the base reource path, value=resource node
			environments.each { Environment env ->
				env.getBaseResources().each { ResourceNode baseResource ->
					baseResources[baseResource.getResourcePath()] = baseResource
				}
			}
			baseResources.each { String resourcePath, ResourceNode baseResource ->
				Logger.info "Deleting UCD Resource with path of '${resourcePath}'"
				baseResource.delete()
			}
	
			// Delete the environment(s)
			environments.each { Environment env ->
				String envName = env.getName()
				Logger.info "Deleting UCD Environment named '${envName}'"
				env.delete()
				summaryReport.addLine("Deleted UCD Environment '${envName}'")
			}
		}
		
		
		
		//------------------------------------------------------------
		// Save/update persistent data
		//------------------------------------------------------------

		
		if (! completelyDeprovision) {
			ucdEnvironmentProvisionMgr.saveDataToEnvironments(baseContext)
		}
		
		
		//------------------------------------------------------------
		// Report and results and finish
		//------------------------------------------------------------
		
		
		summaryReport.displaySummary()
		
		if (deprovisioningFailed) {
			throw new AbortPluginException( 'Parts of deprovisioning failed, but still completed')
		}		
	}
	
	/**
	 * Deprovision the AWS Instances given a list of Placeholders
	 * @param listOfPlaceholdersToDeprovision
	 * <p>The list of AWS instance placeholders that need to be deprovisioned.
	 * Each entry is a Map structure.  The initial values are:</p>
	 * <ul>
	 * <li>AwsProductInstancePlaceholder placeholder - The placeholder to deprovision</li>
	 * <li>ProvisionContext context - The context of the placeholder</li>
	 * </ul>
	 * <p>Additional fields are added within this function manage the deprovisioning process.</p>
	 * @param timeoutInMinutes How long to wait on deprovisioning before timing out.
	 * @return Returns true if everything works and false if anything failed.  Note that even if anything
	 * fails, this function still accomplishes as much of the work as possible.  The placeholders are
	 * updated to their final status.
	 */
	public boolean deprovisionAwsInstancesViaPlaceHolders(List<Map> listOfPlaceholdersToDeprovision, int timeoutInMinutes = 45 ) {
		boolean functionSuccessful = true
		
		long startTime = System.currentTimeMillis()
		
		/**
		 * flagFailure( String msg ) - logs failure to Logger, SummaryReport AND sets 'functionSuccessful' to false
		 */
		Closure flagTerminationFailure = { String msg ->
			Logger.error msg
			summaryReport.addLine(msg)
			functionSuccessful = false
		}

		// Additional fields added to the entries in the listOfPlaceholdersToDeprovision
		//	- String placeholderString
		//		The original string value of the placeholder before making de-provisioning changes to the placeholder
		//	- AwsServiceInstance awsServiceInstance
		//		The Service Instance (which is removed from the placeholder) 
		//	- boolean stillTerminating
		//		Is the product instance still terminating?
		//	- AwsProductInstanceTerminationRequestRecord terminationRequest
		//		The termination tracking information.
			
		// Iterate list and initiate deprovisioning
		listOfPlaceholdersToDeprovision.each { Map entry ->
			AwsProductInstancePlaceholder placeholder = entry.placeholder
			ProvisionContext context 
			AwsServiceInstance awsServiceInstance = placeholder.getAwsServiceInstance()
			
			// Add additional data to the list entry
			entry.placeholderString = entry.placeholder.toString()
			entry.awsServiceInstance = awsServiceInstance
			entry.stillTerminating = true
			
			// Display update
			Logger.info "Deprovisioning " + entry.placeholderString
			
			// Start to de-provision the instance
			AwsProductInstance productInstance = awsServiceInstance.getProductInstance()
			try {
				AwsProductInstanceTerminationRequestRecord terminationRequest = productInstance.terminate()
//// TODO - debugging line
//Logger.info "DEBUG TERM - " + terminationRequest.toString()						
				entry.terminationRequest = terminationRequest
				// Remove the instance from the placeholder - which removes it from the environment(s)
				placeholder.setAwsServiceInstance(null) 
			}
			catch (Exception e) {
				flagTerminationFailure( "Unable to terminate " + entry.placeholderString + " - " + e.getMessage() )
				entry.stillTerminating = false
			}
			
		}
		
		// *** WAIT FOR TIMEOUT OF SUCCESSFUL TERMINATIONS
		
		boolean stillWaiting = true
		int sleepInSeconds = 5
		while (stillWaiting) {
			stillWaiting = false
			
			// Loop through and check status of instances that aren't done yet
			listOfPlaceholdersToDeprovision.each { Map entry ->
				if (entry.stillTerminating) {
					try {
						AwsProductInstanceTerminationRequestRecord terminationRequest = entry.terminationRequest
						AwsDescribeRecordResult recordResult = terminationRequest.describeRecord()
						String terminationStatus = recordResult.getStatus()
						if (terminationStatus== 'IN_PROGRESS') {
							stillWaiting = true
						} else if (terminationStatus== 'SUCCEEDED') {
							entry.stillTerminating = false
							String msg = "Successfully terminated " + entry.placeholderString
							Logger.info msg
							summaryReport.addLine(msg)
						} else {
							flagTerminationFailure( "Error terminating " + entry.placeholderString + " - but still removed from UCD Environment" + " - " + "Unknown AWS status of " + terminationStatus )
							entry.stillTerminating = false
						}
					}
					catch (Exception e) {
						flagTerminationFailure( "Error terminating " + entry.placeholderString + " - but still removed from UCD Environment" + " - " + e.getMessage() )
						entry.stillTerminating = false
					}
				}
			}
			
			// check for timeout
			if (stillWaiting) {
				long currentTime = System.currentTimeMillis()
				if ((timeoutInMinutes > 0) && ((currentTime - startTime) > (timeoutInMinutes * 60 * 1000))) {
					stillWaiting = false
					// TIMEOUT OCCURRED
					listOfPlaceholdersToDeprovision.each { Map entry ->
						if (entry.stillTerminating) {
							// Entry that timed out
							flagTerminationFailure( "Timed out terminating " + entry.placeholderString + " - but still removed from UCD Environment" )
						}
					}
				}
			}
			
			// Sleep
			if (stillWaiting) {
				Thread.sleep( sleepInSeconds * 1000 )
				// Double the sleep time each time up to 60
				sleepInSeconds = sleepInSeconds * 2
				if (sleepInSeconds > 60) {
					sleepInSeconds = 60
				}
			}
		}
		
		return functionSuccessful
	}
	
	private static final String DEPROVISION_HISTORY_PROPNAME = 'aws.deprovision.history'
	
	/**
	 * <p>Has de-provisioning already executed for the given Application Process ID.  De-provisioning MUST
	 * only run once per App Process ID even if there are multiple AWS Provisioning Components in an
	 * application.</p>
	 * <p>Implementation notes: Reads environment property named 'aws.deprovision.history' which is a JSON
	 * hashmap.  Key is AppProcessIds.  Value is currently empty map.  If this id is in the map, then it has already run.</p>
	 * @param applicationProcessId The Application Process ID.
	 * @param persistentProvisionData Use this data to determine if the target environment is stand-alone
	 */
	private boolean hasDeprovisionAlreadyRunForAppProcessId( String applicationProcessId, PersistentProvisionData persistentProvisionData ) {
		// Get the environment to read from - either the stand-alone or one of the blue/green environments
		Environment env
		if (persistentProvisionData.isBlueGreen()) {
			env = persistentProvisionData.getBlueEnvironment()
		} else {
			env = persistentProvisionData.getStandAloneEnvironment()
		}
		// Map of App Process IDs that have run de-provisioning
		Map deprovisionHistory = [:]
		if (env.hasAdHocProperty(DEPROVISION_HISTORY_PROPNAME)) {
			deprovisionHistory = new groovy.json.JsonSlurper().parseText(env.getAdHocProperty(DEPROVISION_HISTORY_PROPNAME))
		}
		return deprovisionHistory.containsKey(applicationProcessId)
	}
	
	/**
	 * <p>Updates the environment property(s) (one stand-alone or both blue and green) adding the Application
	 * Process ID to the list of the deprovision processes that have run.</p>
	 * <p>Implementation notes: Updates environment property named 'aws.deprovision.history' which is a JSON
	 * map.  They keys are AppProcessIds which have run and values are currently an empty map</p>
	 * @param applicationProcessId The Application Process ID.
	 * @param persistentProvisionData Use this data to determine if the target environment is stand-alone
	 */
	private void flagDeprovisionRunningForAppProcessId( String applicationProcessId, PersistentProvisionData persistentProvisionData ) {
		List<Environment> environments = []		// The environments (stand-alone or blue+green) to update
		if (persistentProvisionData.isBlueGreen()) {
			environments << persistentProvisionData.getBlueEnvironment()
			environments << persistentProvisionData.getGreenEnvironment()
		} else {
			environments << persistentProvisionData.getStandAloneEnvironment()
		}
		environments.each { Environment env ->
			Map deprovisionHistory = [:]
			if (env.hasAdHocProperty(DEPROVISION_HISTORY_PROPNAME)) {
				deprovisionHistory = new groovy.json.JsonSlurper().parseText(env.getAdHocProperty(DEPROVISION_HISTORY_PROPNAME))
			}
			deprovisionHistory[applicationProcessId] = [:]
			env.setAdHocProperty(DEPROVISION_HISTORY_PROPNAME, JsonOutput.toJson(deprovisionHistory), false )
		}
	}	

}
