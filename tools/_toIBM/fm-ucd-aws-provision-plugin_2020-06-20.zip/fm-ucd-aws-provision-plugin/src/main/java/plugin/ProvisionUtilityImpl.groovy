package plugin


import com.fanniemae.aws.api.connection.AwsConnection
import com.fanniemae.common.string.SimpleEncryption
import com.fanniemae.ucd.aws.api.services.servicecatalog.AwsServiceCatalog
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel

/**
 * Implementation of the 'Provision AWS Specification' step.
 */
class ProvisionUtilityImpl  {
	// plugin constructor inputs
	private UcdServerConnection ucdServer
	private UcdConnectionServices ucdConnectionServices
	private Properties outProps
	
	private AwsConnection awsConnection
	private AwsServiceCatalog awsServiceCatalog
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to UCD Server.
	 * @param outProps Properties to set as plugin step output properties.
	 */
	public ProvisionUtilityImpl( UcdServerConnection ucdServer, 
		Properties outProps ) {
		this.ucdServer = ucdServer
		ucdConnectionServices = new UcdConnectionServices(ucdServer)
		this.outProps = outProps
	}

	/**
	 * Execute the utility action(s).
	 */
	public void executeUility( String awsRegion, String awsAccountId, String awsRole, String executionData ) {
		
		
		//------------------------------------------------------------
		// Open AWS Connection
		//------------------------------------------------------------

		
		// Initiate AwsConnection, including starting AWS working session and authentication
		awsConnection = new AwsConnection(awsRegion)
		awsConnection.initiateAwsSession( awsRole )
		awsServiceCatalog = new AwsServiceCatalog( awsConnection )
		
		
		//------------------------------------------------------------
		// process the execution data
		//------------------------------------------------------------

		List commands = []
		Closure addCommand = { String commandName, Closure executeCommand ->
			// executeCommand takes one parameter - the execution line
			commands << [ name: commandName.trim().toLowerCase(), cmd: executeCommand ]
		}
		
		addCommand( 'delete', { String line -> deleteCommand(line)} )
		addCommand( 'run', { String line -> runCommand(line)} )
		addCommand( 'decrypt', { String line -> decryptCommand(line)} )
		
		executionData.eachLine { String executionLine ->
			executionLine = executionLine.trim()
			if (executionLine) {
				boolean executed = false
				commands.each { Map command ->
					String cmdName = command.name
					if (executionLine.toLowerCase().startsWith( cmdName+' ' )) {
						Logger.info "Executing ${command} command"
						String line = executionLine.substring( cmdName.length() + 1 )
						command.cmd(line.trim())
						executed = true
					}
				}
				if (! executed) {
					Logger.error "Unknown command - $executionLine"
				}
			}
		}
	}
	
	/**
	 * Deletes an AWS Provisioned Product by name.
	 * @param productInstanceName
	 */
	public void deleteCommand( String productInstanceName ) {
		Logger.info "d - ${productInstanceName}"
		awsServiceCatalog.terminateProvisionedProduct(productInstanceName)
	}
	
	/**
	 * Executes an AWS command.
	 * @param line The AWS command line
	 */
	public void runCommand( String line ) {
		Logger.setLocalLoggingLevel(LoggerLevel.DEBUG) {
			awsConnection.executeAwsCliCommand( line )
		}
	}
	
	/**
	 * Decrypts the given string using the FNMA SimpleEncryption class. For example,
	 * the 'awsProvisionData' class for provisioned UCD Environments contain an encrypted string.
	 * @param s The encrypted string.
	 */
	public void decryptCommand( String s ) {
		Logger.info "Decrypted String: " + SimpleEncryption.decodeString(s)
	}
}