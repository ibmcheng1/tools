package plugin

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.issr.core.log.Logger

import groovy.json.JsonOutput
import plugin.aws.UCPluginStepForAWSProvisioning

class GenerateAwsProvisionReport extends UCPluginStepForAWSProvisioning  {
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new GenerateAwsProvisionReport()
		stepImpl.performStep(args) { stepImpl.execute() }
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {
		
		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************

		// Display a summary of what this plugin is going to do
		Logger.info "${getPluginName()} [${getPluginVersion()}]: Generate AWS Provision Report"
		String applicationName = retrieveAndDisplayInProp("applicationName")
		String environmentName = retrieveAndDisplayInProp("environmentName")
		super.displayParameters()
		
		// Get handle to UCD Server
		UcdServerConnection ucdServer = openUcdServerConnection()
		
		GenerateAwsProvisionReportImpl impl = new GenerateAwsProvisionReportImpl( ucdServer,
			outProps )
		
		Map reportData = impl.generate(applicationName, environmentName)
		
		(new File("awsInventoryReport.txt")).text = JsonOutput.toJson( reportData.data )
		(new File("awsInventoryReport.html.template")).text = reportData.templateBody
	}

}
