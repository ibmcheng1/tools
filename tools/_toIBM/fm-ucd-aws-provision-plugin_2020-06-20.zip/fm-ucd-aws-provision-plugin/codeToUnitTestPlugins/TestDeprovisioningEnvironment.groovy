import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.issr.core.log.Logger

import plugin.DeprovisionEnvironmentImpl

class TestDeprovisioningEnvironment {
	
	static main(String[] args) {
		
		Logger.setLoggingLevel "debug"
		
		String ucdServerUrl = "https://ucdeploytest:8443/"
		String token = '52d4e409-415b-431c-9df5-278272a5f4cf'
		
		UcdServerConnection ucdServer = new UcdServerConnection()
		ucdServer.openConnection(ucdServerUrl, token )
		
		Properties outProps = new Properties()
		
		DeprovisionEnvironmentImpl deprovisionImpl = new DeprovisionEnvironmentImpl(ucdServer, outProps)
		deprovisionImpl.executeDeprovisioning('us-east-1', 'someAwsAcccount', 'someAwsRole', 'LTC03', 'FVQ-AWS')
		
				
		println "*** SUCCESS ***"

	}

}
