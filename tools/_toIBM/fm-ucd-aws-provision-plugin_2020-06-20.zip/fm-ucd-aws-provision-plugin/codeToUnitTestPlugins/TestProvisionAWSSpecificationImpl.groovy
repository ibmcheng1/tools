import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.issr.core.log.Logger

import plugin.ProvisionAWSSpecificationImpl

class TestProvisionAWSSpecificationImpl {
	
	static main(String[] args) {
			
		Logger.setLoggingLevel "debug"
		
		String ucdServerUrl = "https://ucdeploytest:8443/"
		String token = '52d4e409-415b-431c-9df5-278272a5f4cf'
		
		UcdServerConnection ucdServer = new UcdServerConnection()
		ucdServer.openConnection(ucdServerUrl, token )
		
		Properties outProps = new Properties()

		
		
		
		// Test Scenarios - getTemplateText_Exemplar_0416
		
		boolean blueGreen = false
//		String requestedEnvName = 'LEON01'
		String requestedEnvName = 'LEON10'
		String templateText = getTemplateText_Exemplar_0416()

//		boolean blueGreen = false
//		String requestedEnvName = 'DEM1'
//		String templateText = getTemplateText_Exemplar()

//		boolean blueGreen = true
//		String requestedEnvName = 'UT01'
//		String templateText = getTemplateText()
		
//		boolean blueGreen = false
//		String requestedEnvName = 'UT02'
//		String templateText = getTemplateText()
		
//		boolean blueGreen = true
//		String requestedEnvName = 'UT03bg'
//		String templateText = getTemplateText()
		
//		boolean blueGreen = true
//		String requestedEnvName = 'DEM'
//		String templateText = getTemplateText()
		
//		boolean blueGreen = true
//		String requestedEnvName = 'ECR1'
//		String templateText = getTemplateText()
		
		
				
		String requestedEnvType = 'DEVL'
		String applicationName = 'FVQ-AWS'
		String ucdAgents='''tlv-ftx-a008
AWS-Integration'''
			
		ProvisionAWSSpecificationImpl step = new ProvisionAWSSpecificationImpl( ucdServer, outProps, true )
		
		step.executeProvisioning(blueGreen, ucdAgents, 'us-east-1', 'sampleAccount', 'sampleRole', requestedEnvName, requestedEnvType,
			applicationName, templateText, false, '', '' )
		println "*** SUCCESS ***"

	}

	static getTemplateText_Exemplar_0416() {
		return '''// AWS Provisioning Template for UCD
{
	// 'awsTemplate' section defines the AWS Services to provision
	"awsTemplate" : {
		"provisionProducts" : [
			{
				// 'name' is the logical name for this AWS Product Instance.
				// It is used to reference this Product Instance throughout this template.
				// In particular, reference it in tokens as %([name].[field])%, such as %(eb.fieldName)%
				// Note that tokens may NOT be used within the name field.
				"name" : "eb",
				// 'awsName' is used as part of the provisioned Product Instance in AWS.
				// The full AWS Product Instance Name is calculated as: {AppCode}_{UCD Environment Name}_{awsName}
				"awsName" : "EB-%([this].EnvironmentPlatform)%",
				// AWS Description: Provisions an ElasticBeanstalk Application and Environment
				"awsProductName" : "ElasticBeanstalk Application and Environment",
				// Optionally specify the Catalog Product Version to use, otherwise newest version is used.
				// "awsVersionName": "4",
				// Set 'participateInBlueGreen' if this AWS Product should be provisioned separately for blue-green deployments.  Otherwise, it is provisioned once and shared between bluee and green.
				"participateInBlueGreen" : true,
				// 'awsProperties' are the input properties (inprop) sent to AWS when provisioning a Service Catalog Product
				"awsProperties" : {
					// Label: Environment Type
					// Description: Environment Type. Pleaser refer to ElasticBeanstalk documentation for details
					// Allowed values: WebServer, Worker
					// Default: WebServer
					"EnvironmentType" : "WebServer",
					// Description: EMM Alert Group to send alarms. Can be empty in lower environments
					"EMMAlertGroup" : "",
					// Label: Maximum Instances
					// Description: Maximum number of instances desired for auto scaling
					// Default: 1
					"AutoScalingMax" : "1",
					// Label: EC2 Instance Size
					// Description: Size of the EC2 instances for the Environment
					// Allowed values: Small, Medium, Large, ExtraLarge
					// Default: Small
					"InstanceSize" : "Small",
					// Label: Environment Name
					// Description: Unique Identifier for the Environment. Min:3, Max:10
					"EnvironmentName" : "env-%(environment.name)%",
					// Label: Minimum Instances
					// Description: Minimum number of instances desired for auto scaling
					// Default: 1
					"AutoScalingMin" : "1",
					// Label: Environment Platform
					// Description: Environment Platform. Pleaser refer to ElasticBeanstalk documentation for details
					// Allowed values: Nodejs, Tomcat8.5, Java8, DockerSingle
					// Default: Tomcat8.5
					"EnvironmentPlatform" : "Nodejs",
					// Label: Application Identifier
					// Description: Unique Identifier for the Application. Min:3, Max:10
					"ApplicationIdentifier" : "%(appCode.toLowerCase)%%(environment.name.toLowerCase)%",
					// Label: Application Email
					// Description: Contact information for the Application/Environment
					"ApplicationOwnerEMail" : ""
				},
				// 'awsTags' are the input tags sent to AWS when provisioning a Service Catalog Product.
				// Products define multiple Tags.  If a tag has a single value, then it doesn't need to be set.
				// If a tag has multiple possible values, then you must select a value when provisioning the Product.
				"awsTags" : {
				}
			},
			{
				// 'name' is the logical name for this AWS Product Instance.
				// It is used to reference this Product Instance throughout this template.
				// In particular, reference it in tokens as %([name].[field])%, such as %(rds.fieldName)%
				// Note that tokens may NOT be used within the name field.
				"name" : "rds",
				// 'awsName' is used as part of the provisioned Product Instance in AWS.
				// The full AWS Product Instance Name is calculated as: {AppCode}_{UCD Environment Name}_{awsName}
				"awsName" : "rds",
				// AWS Description: Provisions an RDS Instance
				"awsProductName" : "RDS",
				// Optionally specify the Catalog Product Version to use, otherwise newest version is used.
				// "awsVersionName": "9",
				// Set 'participateInBlueGreen' if this AWS Product should be provisioned separately for blue-green deployments.  Otherwise, it is provisioned once and shared between bluee and green.
				"participateInBlueGreen" : false,
				// 'awsProperties' are the input properties (inprop) sent to AWS when provisioning a Service Catalog Product
				"awsProperties" : {
					// Label: RDS Engine
					// Description: The RDS engine for the Database
					// Allowed values: PostgreSQL, AuroraPostgres
					// Default: PostgreSQL
					"DatabaseEngine" : "PostgreSQL",
					// Label: Database User
					// Description: The RDS Application User ID. This parameter should satisfy vendors' requirements for usernames
					"DatabaseUser" : "ebdadm",
					// Label: Database Name
					// Description: Not to be confused with the RDS instance name. This parameter should satisfy vendors' requirements on DB names, otherwise the product will fail
					"DatabaseName" : "db%(environment.name.toLowerCase)%",
					// Label: Unique Identifier for the RDS Instance
					// Description: Instance will be named ${ApplicationShortName}-rds-${Identifier}. Min:3, Max:10
					"Name" : "%(environment.name.toLowerCase)%"
				},
				// 'awsTags' are the input tags sent to AWS when provisioning a Service Catalog Product.
				// Products define multiple Tags.  If a tag has a single value, then it doesn't need to be set.
				// If a tag has multiple possible values, then you must select a value when provisioning the Product.
				"awsTags" : {
					"CustomTag1" : "sample custom tag",
					"CustTag2" : "this is custom tag"
				}
			}
		]
	},
	// 'ucdTemplate' section describes how to configure UCD from provisioned AWS services
	"ucdTemplate" : {
		"ucdComponents" : [
			{
				"componentName" : "FVQ-eb",
				// The name to use for this component within the UCD Resource Tree.  This is generally the same as the componentName, but can be different.
				"resourceName" : "eb-component",
				// Which UCD Agent is this Component assigned to?  The first agent is agent1, then agent2 and so on.
				"agent" : "agent1",
				// Set 'participateInBlueGreen' if this UCD Component should be separately configured for blue and green environments
				"participateInBlueGreen" : false,
				"componentEnvironmentProperties" : {
					// Elastic Beanstalk application name
					"eb.application" : "%(eb.ApplicationName)%",
					// Elastic Beanstalk environment name
					"eb.environment" : "%(eb.EnvironmentName)%"
				}
			},
			{
				"componentName" : "FVQ-ecs",
				// The name to use for this component within the UCD Resource Tree.  This is generally the same as the componentName, but can be different.
				//"resourceName" : "FVQ-ecs",
				// Which UCD Agent is this Component assigned to?  The first agent is agent1, then agent2 and so on.
				"agent" : "agent2",
				// Set 'participateInBlueGreen' if this UCD Component should be separately configured for blue and green environments
				"participateInBlueGreen" : false,
				"componentEnvironmentProperties" : {
				}
			}
		]
	}
}'''
	}
	
	
	static getTemplateText() {
		return '''// AWS Provisioning Template for UCD
{
	// 'awsTemplate' section defines the AWS Services to provision
	"awsTemplate" : {
		"provisionProducts" : [
			{
				"name" : "sampleEB",
				"awsProductName" : "ElasticBeanstalk Application and Environment",
				"awsName" : "EB-%([this].EnvironmentPlatform)%",
				// "awsVersionName": "4",
				"participateInBlueGreen" : false,
				"awsProperties" : {
					"EnvironmentType" : "WebServer",
					"EMMAlertGroup" : "",
					"AutoScalingMax" : "1",
					"InstanceSize" : "Small",
					"EnvironmentName" : "env-%(environment.name)%",
					"AutoScalingMin" : "1",
					// Allowed values: Nodejs, Tomcat8.5, Java8, DockerSingle
					"EnvironmentPlatform" : "Nodejs",
					"ApplicationIdentifier" : "fzm%(environment.name)%",
					"ApplicationOwnerEMail" : ""
				},
				"awsTags" : {
					// Allowed values for 'ProvisioningVersion' tag: v2, v3
					"ProvisioningVersion" : "v3"
				}
			},
			{
				"name" : "rds",
				"awsProductName" : "RDS",
				"participateInBlueGreen" : false,
				"awsProperties" : {
					"DatabaseEngine" : "PostgreSQL",
					"DatabaseUser" : "ebdadm",
					"DatabaseName" : "db%(environment.name)%",
					"Name" : "%(environment.name)%"
				},
				"awsTags" : {
					// Allowed values for 'ProvisioningVersion' tag: v2, v3
					"ProvisioningVersion" : "v3"
				}
			}
		]
	},
	// 'ucdTemplate' section describes how to configure UCD from provisioned AWS services
	"ucdTemplate" : {
		"ucdComponents" : [
			{
				"componentName" : "AWS-EB",
				"name" : "eb",
				"agent" : "agent2",
				// Set 'participateInBlueGreen' if this UCD Component should be separately configured for blue and green environments
				"participateInBlueGreen" : true,
				"componentEnvironmentProperties" : {
					// AWS IAM Role used for Deployments
					// Required field
					"awsRole" : "%(aws.role)%",
					// aws region
					// Required field
					"awsRegion" : "%(aws.region)%"
				}
			},
			{
				"componentName" : "AWS-RDS",
				"name" : "rds",
				"agent" : "agent2",
				// Set 'participateInBlueGreen' if this UCD Component should be separately configured for blue and green environments
				"participateInBlueGreen" : false,
				"componentEnvironmentProperties" : {
					// AWS IAM Role used for Deployments
					// Required field
					"iam.awsRole" : "ENV: %(environment.name)%",
					// aws region
					// Required field
					"aws.region" : "%(aws.region)%"
					
				}
			},
			{
				"componentName" : "FZM-config",
				// Set 'participateInBlueGreen' if this UCD Component should be separately configured for blue and green environments
				"participateInBlueGreen" : true,
				"componentEnvironmentProperties" : {
					"eb.application" : "%(sampleEB.ApplicationName)%",
					"eb.environment" : "%(sampleEB.EnvironmentName)%"
				}
			}
		]
	}
}
'''
	}

	static getTemplateText_Exemplar() {
		return '''// AWS Provisioning Template for UCD
{
	// 'awsTemplate' section defines the AWS Services to provision
	"awsTemplate" : {
		"provisionProducts" : [
			{
				"name" : "sampleEB",
				"awsProductName" : "ElasticBeanstalk Application and Environment",
				"awsName" : "EB-%([this].EnvironmentPlatform)%",
				// "awsVersionName": "4",
				"participateInBlueGreen" : true,
				"awsProperties" : {
					"EnvironmentType" : "WebServer",
					"EMMAlertGroup" : "",
					"AutoScalingMax" : "1",
					"InstanceSize" : "Small",
					"EnvironmentName" : "env-%(environment.name)%",
					"AutoScalingMin" : "1",
					// Allowed values: Nodejs, Tomcat8.5, Java8, DockerSingle
					"EnvironmentPlatform" : "Nodejs",
					"ApplicationIdentifier" : "fzm%(environment.name)%",
					"ApplicationOwnerEMail" : ""
				},
				"awsTags" : {
					// Allowed values for 'ProvisioningVersion' tag: v2, v3
					"ProvisioningVersion" : "v3"
				}
			},
			{
				"name" : "rds",
				"awsProductName" : "RDS",
				"participateInBlueGreen" : false,
				"awsProperties" : {
					"DatabaseEngine" : "PostgreSQL",
					"DatabaseUser" : "ebdadm",
					"DatabaseName" : "db%(environment.name)%",
					"Name" : "%(environment.name)%"
				},
				"awsTags" : {
					// Allowed values for 'ProvisioningVersion' tag: v2, v3
					"ProvisioningVersion" : "v3"
				}
			}
		]
	},
	// 'ucdTemplate' section describes how to configure UCD from provisioned AWS services
	"ucdTemplate" : {
		"ucdComponents" : [
			{
				"componentName" : "FZM-config",
				// Set 'participateInBlueGreen' if this UCD Component should be separately configured for blue and green environments
				"participateInBlueGreen" : true,
				"componentEnvironmentProperties" : {
					"eb.application" : "%(sampleEB.ApplicationName)%",
					"eb.environment" : "%(sampleEB.EnvironmentName)%"
				}
			}
		]
	}
}'''
	}
}
