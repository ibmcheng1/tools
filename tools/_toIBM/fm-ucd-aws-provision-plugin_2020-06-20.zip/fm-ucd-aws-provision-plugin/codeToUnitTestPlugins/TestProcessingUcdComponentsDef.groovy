import static org.junit.Assert.*

import org.junit.Test

import com.fanniemae.ucd.aws.provision.def.components.UcdTemplateDefinition
import com.ibm.issr.core.log.Logger

class TestProcessingUcdComponentsDef {

	@Test
	public void test() {
		Logger.setLoggingLevel('debug')
		
		processJson('''
{
	"ucdComponents":
	[
		{
			"componentName": "AWS-EB",
			"participateInBlueGreen": true,
			"componentEnvironmentProperties":
			{
				"applicationName": "%awsResource.sampleEB.ApplicationName%",
				"environmentName": "%awsResource.sampleEB.EnvironmentName%"
			}
		}, 
		{
			"componentName": "AWS-RDS",
			"participateInBlueGreen": false,
			"componentEnvironmentProperties":
			{
				"awsEndpoint": "%awsResource.rds-resource.DBInstanceEndpoint%",
				"awsPort": "%awsResource.rds-resource.DBInstancePort%",
				"awsInstanceId": "%awsResource.rds-resource.DBInstanceId%"
			}
		}, 
		{
			"componentName": "AWS-FZM-ECS",
			"componentEnvironmentProperties":
			{
				"awsLifeCycle": "%awsResource.ecsResource.Lifecycle%",
				"clusterName": "%awsResource.ecsResource.ClusterName%"
			}
		}
	]
}
''')
	}
	
	public void processJson( String ucdComponentsDefJson ) {
		UcdTemplateDefinition componentsDef = new UcdTemplateDefinition(ucdComponentsDefJson)
		assert componentsDef.isValid() 
		assert componentsDef.doAnyComponentsSupportBlueGreen()
	}

}
