import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel
import com.ibm.issr.core.plugin.AbortPluginException

import groovy.json.JsonOutput
import plugin.GenerateAwsProvisionReportImpl

class TestGenerateAwsProvisionReportImpl {
	
	static main(String[] args) {
			
//		Logger.setLoggingLevel "debug"
		
		String ucdServerUrl = "https://ucdeploytest:8443/"
		String token = '52d4e409-415b-431c-9df5-278272a5f4cf'
		
		UcdServerConnection ucdServer = new UcdServerConnection()
		ucdServer.openConnection(ucdServerUrl, token )
		
		Properties outProps = new Properties()

		test( ucdServer, 'FVQ-AWS', 'FOOBAR' )
		test( ucdServer, 'FVQ-AWS' )
	}
	
	public static void test( UcdServerConnection ucdServer, String applicationName, String optionalEnvironmentName='' ) {
		Logger.info "\ntest( application='${applicationName}', environment='${optionalEnvironmentName}' )"
		
		Properties outProps = new Properties()

		try {
			GenerateAwsProvisionReportImpl impl = new GenerateAwsProvisionReportImpl( ucdServer, outProps )
			Map retval = impl.generate(applicationName, optionalEnvironmentName)
			Logger.info "Return data: " + JsonOutput.toJson( retval.data )
			Logger.info "Template body: " + retval.templateBody
		}
		catch (AbortPluginException e) {
			Logger.error e.getMessage()
		}
		catch (Exception e) {
			Logger.error("test() failed - " + e.getMessage())
			Logger.printStackTrace(LoggerLevel.ERROR, e)
		}
		
		Logger.info "\toutProps = ${outProps}"
	}
}
