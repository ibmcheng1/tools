import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.issr.core.log.Logger

import plugin.ValidateRequestedEnvironmentTypeImpl

class TestValidateRequestedEnvironmentTypeImpl {
	
	static main(String[] args) {
			
//		Logger.setLoggingLevel "debug"
		
		String ucdServerUrl = "https://ucdeploytest:8443/"
		String token = '52d4e409-415b-431c-9df5-278272a5f4cf'
		
		UcdServerConnection ucdServer = new UcdServerConnection()
		ucdServer.openConnection(ucdServerUrl, token )
		
		Properties outProps = new Properties()

		test( ucdServer, 'UNKNOWN_ENV', 'ACPT', 'FVQ-AWS' )
		test( ucdServer, 'LEON10', 'ACPT', 'FVQ-AWS' )
		test( ucdServer, 'LEON11', 'ACPT', 'FVQ-AWS' )
	}
	
	public static void test( UcdServerConnection ucdServer, String envName, String requestedEnvType, String applicationName ) {
		Logger.info "\ntest( envName='${envName}', envType=${requestedEnvType} )"
		
		Properties outProps = new Properties()

		ValidateRequestedEnvironmentTypeImpl validateClass = new ValidateRequestedEnvironmentTypeImpl( ucdServer, outProps )
		validateClass.validateRequestedEnvironmentType(envName, requestedEnvType, applicationName)
		
		Logger.info "\toutProps = ${outProps}"
	}
}
