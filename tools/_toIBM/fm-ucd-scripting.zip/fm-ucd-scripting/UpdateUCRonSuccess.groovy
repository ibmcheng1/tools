import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger;
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.RestServerConnectionBuilder
import com.ibm.services.ucr.api.entity.scheduleddeployment.UcrScheduledDeployment
import com.ibm.services.ucr.api.entity.scheduleddeployment.UcrScheduledDeploymentMgr
import com.ibm.services.ucr.api.entity.taskexecution.UcrTaskExecution
import com.ibm.services.ucr.api.entity.taskexecution.UcrTaskExecutionMgr

/**
 * Groovy script class which has access to UCD API Services.
 */
class GroovyScript extends ScriptWithUcdServicesHook {

	/**
	 * This is the script function that is executed.
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
		String ucrServerUrl = '${p?:ucr.request.server}'
		String ucrLink = '${p?:ucr.request.link}'
		String ucrTaskId = '${p?:ucr.request.taskId}'
		String ucrSheduledDeploymentId = '${p?:ucr.request.scheduledDeploymentId}'
		String dtmId = '${p?:Create DTM Record/DTMRecordNumber}'
		//example -> http://dlv-e9v-a002:8181/dtmtest/browse/ENTDTMDEV-4561
		String dtmLink = "${p:DTM_URL}" + '/browse/' + dtmId
		
		// Skip processing if the UCR data is not defined
		if (ucrServerUrl && ucrLink) {
			Logger.info "Updating UCR Task and Deployment: dtmLink = " + dtmLink
			RestServerConnection ucrServer = (new RestServerConnectionBuilder())
				.setServerUrl(ucrServerUrl)
				.setUrbancodeTokenAuthentication('${p:ucrToken}')
				.setTrustAllCerts()
				.openConnection()

			UcrScheduledDeployment ucrScheduledDeployment = UcrScheduledDeploymentMgr.getInstance(ucrServer).getById(ucrSheduledDeploymentId)	
			ucrScheduledDeployment.addExternalLink(dtmLink, dtmLink, "Hyperlink to the newly created DTM record.")
					
			UcrTaskExecution ucrTaskExecution = UcrTaskExecutionMgr.getInstance(ucrServer).getById(ucrTaskId)
//			ucrTaskExecution.addTaskComment("Successfully created new DTM #" + dtmId + " which can be opened at <a href='" + dtmLink + "'>" + dtmLink + "</a>" )
			ucrTaskExecution.setAsCompleted()
			
		} else {
			Logger.info "There is no need to update UCR"
		}
	}
}