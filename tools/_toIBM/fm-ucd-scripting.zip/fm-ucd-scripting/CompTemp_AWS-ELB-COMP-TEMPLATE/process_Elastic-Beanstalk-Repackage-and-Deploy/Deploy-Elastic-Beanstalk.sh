#!/bin/bash

################################
#Read in UCD Properties
################################
AWS_VER=${p:awsVersionLabel} #get this one from the app process
REGION=${p:component/awsRegion}
AWS_APP_NAME=${p:environment/applicationName}
AWS_ENV_NAME=${p:environment/environmentName}
S3_LOCATION=${p:environment/s3Location}
SOURCE_FILE=${p:environment/fileNames}
ROLE=${p:environment/awsRole}

################################
#Validate that we assumed the role
################################
source .awsprofile
CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
if [[ $CURRENT_ROLE != $ROLE ]] ; then
    echo "ERROR: Failed to assume the role: ${ROLE}"
    exit 1
fi

################################
#Validate UCD input
################################
#check that aws application exists
echo "Verifying elastic beanstalk application"
APP_CHECK=$(aws elasticbeanstalk describe-applications \
                --application-names ${AWS_APP_NAME} \
                --output text)

if [[ -z $APP_CHECK ]] ; then
        echo "ERROR: Can't find application: ${AWS_APP_NAME}"
        exit 1
fi

#check that the aws environment exists
echo "Verifying elastic beanstalk environment"
ENV_CHECK=$(aws elasticbeanstalk describe-environments \
                --application-name ${AWS_APP_NAME} \
                --environment-names ${AWS_ENV_NAME} \
                --output text)

if [[ -z $ENV_CHECK ]] ; then
        echo "ERROR: Can't find environment: ${AWS_ENV_NAME}"
        exit 1
fi

#if source file is undefined then get file name by listing current location
if [[ -z $SOURCE_FILE ]] ; then
    echo "The file name is not given in the environment properties, so checking to see if there is a single file at the current location to use."
    if [[ $(ls | wc -l) -eq 1 ]] ;  then
        SOURCE_FILE=$(ls)
        echo "found file: ${SOURCE_FILE}"
    else
        echo "Invalid number of files in component version. Please specify the source file in the environment property"
        ls -l
        exit 1
    fi
fi

#get s3 path to use for creating version
#S3_PATH var will be used to create app version so will need to include filename
#S3_LOCATION var will just be used to verify path exists so can be parent directory
FILE_EXTENSION="\.(war|zip)$"
if  [[ $S3_LOCATION =~ $FILE_EXTENSION ]] ; then
    #if s3 location points to file then should be good to go
    S3_PATH=$S3_LOCATION
    S3_LOCATION=$(dirname $S3_LOCATION) 
else
    #if s3 location is a directory then need to add file and not have extra slash
    FILE_NAME=$(basename $SOURCE_FILE)
    TRAILING_SLASH="/$"
    if [[ $S3_LOCATION =~ $TRAILING_SLASH ]] ; then
        S3_PATH=$S3_LOCATION$FILE_NAME
    else 
        S3_PATH=$S3_LOCATION/$FILE_NAME
    fi
fi

#check that the S3 location exists
echo "Verifying S3 location: ${S3_LOCATION}"
aws s3 ls $S3_LOCATION
if [[ $? -ne 0 ]]; then
  echo "ERROR: Can't find the S3 Location: ${S3_LOCATION}"
  exit 1
fi

#check that the S3 Bucket is associated with the elastic beanstalk application
S3_BUCKET=$(echo $S3_PATH | cut -d '/' -f 3)
S3_KEY=$(echo $S3_PATH | cut -d ':' -f 2 | sed -e "s/\/\/${S3_BUCKET}\///")
echo "${S3_BUCKET}"
echo "${S3_KEY}"

S3_BUCKET_CHECK=$(aws elasticbeanstalk describe-configuration-settings \
                    --environment-name ${AWS_ENV_NAME} \
                	--application-name ${AWS_APP_NAME} \
                    --region ${REGION} \
                    --query "ConfigurationSettings[].OptionSettings[?OptionName=='PRIVATE_BUCKET'].Value" \
                    --output text)
            
if [[ $S3_BUCKET != $S3_BUCKET_CHECK ]] ; then
    echo "ERROR: Looks like the S3 bucket in the given s3 location, ${S3_BUCKET}, does not match the private bucket associated with the elastic beanstalk app and env: ${S3_BUCKET_CHECK}"
    exit 1
fi

#check that user provided a version label to use, otherwise use component version name
if [ -z $AWS_VER ] ; then 
    echo "No version label provided so use component version name: ${p:version.name}"
    AWS_VER=${p:version.name}
fi

#check that version label is unique
VER_CHECK=$(aws elasticbeanstalk describe-application-versions \
	            --application-name ${AWS_APP_NAME}  \
            	--version-label ${AWS_VER} \
            	--output text)
	
if [[ ! -z $VER_CHECK ]] ; then 
    echo "ERROR: ${AWS_VER} already exists as a version label for ${AWS_APP_NAME}"
    exit 1
fi

################################
#copy to s3 location
################################
if [[ -d $SOURCE_FILE ]]; then
    echo "${SOURCE_FILE} is a directory - copying recursively"
    aws s3 cp $SOURCE_FILE $S3_PATH --recursive --sse 
   
else
    echo "copying ${SOURCE_FILE} to ${S3_LOCATION}"
    aws s3 cp $SOURCE_FILE $S3_PATH --sse 
fi

if [[ $? -ne 0 ]]; then
  echo "ERROR: Failed to copy to ${S3_LOCATION}"
  exit 1
fi

################################
#Create application version
################################
echo "Creating new application version"
aws elasticbeanstalk create-application-version \
    --application-name ${AWS_APP_NAME} \
    --version-label ${AWS_VER} \
    --source-bundle "S3Bucket=${S3_BUCKET},S3Key=${S3_KEY}" \
    --process \
    --region ${REGION}
    
if [[ $? -ne 0 ]]; then
  echo "ERROR: there was a failure while creating the application version"
  exit 1
fi

while true; do
	VER_STATUS=$(aws elasticbeanstalk describe-application-versions \
                    --application-name ${AWS_APP_NAME} \
                    --version-label ${AWS_VER} \
                    --region ${REGION} \
                    --query 'ApplicationVersions[0].Status' \
                    --output text)
    if [ "${VER_STATUS}" = "PROCESSING" ]; then
    	sleep 2
        continue
    fi
    if [ "${VER_STATUS}" = "FAILED" ]; then
    	echo "ERROR: Application version creation failed"
    	exit 1
    fi
    echo "Application version has been created"
  break
done

################################
#Update environment
################################
#get the env id
AWS_ENV_ID=$(aws elasticbeanstalk describe-environments \
    			--application-name ${AWS_APP_NAME} \
    			--environment-name ${AWS_ENV_NAME} \
    			--query "Environments[].EnvironmentId" \
    			--output text)
			
#Update the environment with the application version
echo "Checking if environment is ready"
while true; do
	ENV_STATUS=$(aws elasticbeanstalk describe-environment-health \
        			--environment-name ${AWS_ENV_NAME} \
        			--environment-id ${AWS_ENV_ID} \
                    --region ${REGION} \
                    --attribute-names Status \
                    --query Status \
                    --output text)
    
	if [ "${ENV_STATUS}" = "Launching" ] || [ "${ENV_STATUS}" = "Updating" ]; then
      sleep 2
      continue
    fi
  	if [ "$ENV_STATUS" = "Terminating" ] || [ "${ENV_STATUS}" = "Terminated" ]; then
    	echo "Environment is in the process of shutting down/is shut down"
   		exit 1
  	fi
    echo "Environment is ${ENV_STATUS}"
  	break
done

echo "Updating environment with new application version"
aws elasticbeanstalk update-environment \
    --application-name ${AWS_APP_NAME} \
    --environment-name ${AWS_ENV_NAME} \
    --environment-id ${AWS_ENV_ID} \
    --region ${REGION} \
    --version-label ${AWS_VER}

if [[ $? -ne 0 ]]; then
  echo "ERROR: there was a failure while trying to update the environment"
  exit 1
fi
    
while true; do
	ENV_STATUS=$(aws elasticbeanstalk describe-environment-health \
        			--environment-name ${AWS_ENV_NAME} \
        			--environment-id ${AWS_ENV_ID} \
                    --region ${REGION} \
                    --attribute-names Status \
                    --query Status \
                    --output text)
    
	if [ "${ENV_STATUS}" = "Launching" ] || [ "${ENV_STATUS}" = "Updating" ] ; then
      sleep 2 
      continue 
    fi
  	if [ "$ENV_STATUS" = "Terminating" ] || [ "${ENV_STATUS}" = "Terminated" ] ; then
    	echo "Environment is in the process of shutting down/is shut down"
   		exit 1
  	fi
  	echo "Environment status: ${ENV_STATUS}"
    echo "Done updating environment"
  	break
done

################################
#Validate environment
################################
#Check env status 
ENV_HEALTH=$(aws elasticbeanstalk describe-environment-health \
    			--environment-name ${AWS_ENV_NAME} \
				--environment-id ${AWS_ENV_ID} \
                --region ${REGION} \
                --attribute-names HealthStatus \
                --query HealthStatus \
                --output text)
                
echo "Environment Health: ${ENV_HEALTH}"

#Check if environment reflects the new version label
CURRENT_VERSION=$(aws elasticbeanstalk describe-environments \
	                --application-name ${AWS_APP_NAME} \
                	--environment-name ${AWS_ENV_NAME} \
                	--query "Environments[].VersionLabel" \
                	--output text)
                	
if [[ $AWS_VER != $CURRENT_VERSION ]] ; then
 echo "ERROR: There was an issue updating ${AWS_ENV_NAME} with ${AWS_VER}. The current version is: ${CURRENT_VERSION}"
 exit 1
fi

echo "${AWS_ENV_NAME} has been updated with the new version ${AWS_VER}"