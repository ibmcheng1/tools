import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.property.Property
import com.ibm.css.ucd.services.StatusServices
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.css.ucd.snapshot.Snapshot
import com.ibm.css.ucd.status.ComponentVersionStatus
import com.ibm.issr.core.log.Logger
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook
import com.ibm.css.ucd.status.ComponentVersionStatusInstance
import com.ibm.css.ucd.status.SnapshotStatus
import com.ibm.css.ucd.status.SnapshotStatusInstance

import java.io.File


/**
 * Groovy script class which has access to UCD API Services.
 *
 */
class CreateUCDContextPropertiesFile extends ScriptWithUcdServicesHook {
	    String myVersion = '05-06-2019 v1.1'
		//**********************************************
		//  UCD Process PARAMETERS (Process properties)
		//**********************************************
		String applicationId = "${p:applicationId}"
		String snapshotName = "${p:snapshotName}"
		
		String appCode = "${p:appCode}"
		String assetId = "${p:assetId}"
						
		String componentBasicPropertyKey_appsecScanRequired = "${p:componentBasicPropertyKey_appsecScanRequired}"
		String componentBasicPropertyKey_javaVersion = "${p:componentBasicPropertyKey_javaVersion}"
		String componentBasicPropertyKey_repoURL = "${p:componentBasicPropertyKey_repoURL}"
		
		String componentPropertyKey_hpFortifySseName = "${p:componentPropertyKey_hpFortifySseName}"		
		String componentVersionPropertyKey_codeCommitHash = "${p:componentVersionPropertyKey_codeCommitHash}"
		
		String STATUS_passedStatusName = "${p:STATUS_passedStatusName}"
		
		String FORTIFY_SCAN_SCRIPT_PATH = "${p:fortifyScanScriptPath}"
		String CONTEXT_PROPERTIES_FILE_NAME = "context.properties"
		String SCRIPT_RESULT_FILE_NAME = "scriptResult.output"
		String STRING_SCAN_RESULT_PASSED = "APPSEC_SCAN_PASSED"
		
		/**
		 * This is the script function that is executed.
		 * @param ucdConnectionServices UCD API Services
		 */
		public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
			    Logger.info "myVersion: " + myVersion
				Logger.info "Application ID: " + applicationId
				Logger.info "Snapshot name: " + snapshotName
				Logger.info "appCode: " + appCode
				Logger.info "assetId: " + assetId
				
				Logger.info "componentBasicPropertyKey_appsecScanRequired: " + componentBasicPropertyKey_appsecScanRequired
				Logger.info "componentBasicPropertyKey_javaVersion: " + componentBasicPropertyKey_javaVersion
				Logger.info "componentBasicPropertyKey_repoURL: " + componentBasicPropertyKey_repoURL
				Logger.info "componentPropertyKey_hpFortifySseName: " + componentPropertyKey_hpFortifySseName
				Logger.info "componentVersionPropertyKey_codeCommitHash: " + componentVersionPropertyKey_codeCommitHash
												
				// Get the application
				Application application = ucdConnectionServices.getApplicationServices().getApplicationById(applicationId)
				Logger.info "Found application ID " + application.id
				
				String applicationName = application.getName();
				String applicationAppCode = appCode
				String applicationAssetId = assetId

				// Get the snapshot
				Snapshot snapshot = application.getSnapshot(snapshotName)
				
				def contextFile = new File(CONTEXT_PROPERTIES_FILE_NAME)
				if(contextFile.exists()){
					Logger.info "Deleting existing contextFile. Path = " + contextFile.absolutePath
					contextFile.delete();
				}
				Logger.info "Creating new contextFile ..."
				contextFile.createNewFile();
				Logger.info "New contextFile path = " + contextFile.absolutePath
				
				def currentDir = new File('')
				String currentDirectory = currentDir.getAbsolutePath()
				Logger.info "currentDirectory = " + currentDirectory
	
				contextFile << "currentDirectory='" + currentDirectory + "'\n"
				contextFile << "CONTEXT_PROPERTIES_FILE_NAME='" + CONTEXT_PROPERTIES_FILE_NAME + "'\n"
				contextFile << "FORTIFY_SCAN_SCRIPT_PATH='" + FORTIFY_SCAN_SCRIPT_PATH + "'\n"
				contextFile << "SCRIPT_RESULT_FILE_NAME=" + SCRIPT_RESULT_FILE_NAME + "\n"
				contextFile << "STRING_SCAN_RESULT_PASSED=" + STRING_SCAN_RESULT_PASSED + "\n"
								
				StatusServices statusServices = ucdConnectionServices.getStatusServices()
				
				String messageSnapshot = "application["+applicationName+"].snapshot["+snapshotName+"]"
															
				Logger.info "applicationAppCode = " + applicationAppCode
				Logger.info "applicationAssetId = " + applicationAssetId
				Logger.info "snapshot.id        = " + snapshot.id
				Logger.info "snapshotName       = " + snapshotName
				
				outProps.put("applicationName", applicationName);
				outProps.put("applicationAppCode", applicationAppCode);
				outProps.put("applicationAssetId", applicationAssetId);
												
				contextFile << "applicationName=" + applicationName + "\n"
				contextFile << "snapshotName=" + snapshotName + "\n"
				contextFile << "applicationAppCode=" + applicationAppCode + "\n"
				contextFile << "applicationAssetId=" + applicationAssetId + "\n"
			
				// Get the list of Component Versions in the snapshot
				List componentVersions = snapshot.getComponentVersionObjects()
				
				Logger.info "For each componentVersion ... "
				int counter = 0
				componentVersions.each { ComponentVersion componentVersion ->
					String componentVersionName = ComponentVersion.getName();
					Map componentVersionPropertiesMap = componentVersion.getProperties();
					List componentVersionManagedPropertiesList = componentVersion.get_managedProperties();
					List componentVersionStatuses = componentVersion.getComponentVersionStatuses();
										
					Component component = componentVersion.getComponent()
					String componentId = component.getId()
					String componentName = component.getName()
					
					// to avoid duplicate scan on ComponentVersion level, skip scan if the ComponentVersion has the desired STATUS_passedStatusName
					String messageComponent = messageSnapshot + ".component["+componentName+"].version["+componentVersionName+"]"
					ComponentVersionStatusInstance componentVersionStatusInstancePASSED = getComponentVersionStatusByName(componentVersion, STATUS_passedStatusName)
					Logger.info messageComponent + ": componentVersionStatusInstancePASSED = " + componentVersionStatusInstancePASSED
					boolean toSkip = false
					if(componentVersionStatusInstancePASSED != null) {
						toSkip = true;
						Logger.info messageComponent + ": The componentVersionStatusInstancePASSED exists, skip this componentVersion"
					} else {
						Logger.info messageComponent + ": The componentVersionStatusInstancePASSED is null. continue ... "
					}

					Logger.info messageComponent + ": toSkip = " + toSkip
										
					List componentBasicPropertiesList = component.getBasicProperties();
					Logger.info componentName + ": componentBasicPropertiesList = " + componentBasicPropertiesList
					
					String componentRepoURL = ""
					String componentJavaVersion = ""
					String componentAppsecScanRequired = ""
					
					componentBasicPropertiesList.each { Property p ->
						String pName = p.getName();
						if(pName == componentBasicPropertyKey_repoURL) {
							componentRepoURL = p.getValue()
						}
						if(pName == componentBasicPropertyKey_javaVersion) {
							componentJavaVersion = p.getValue()
						}
						if(pName == componentBasicPropertyKey_appsecScanRequired) {
							componentAppsecScanRequired = p.getValue()
						}
					}
					Logger.info componentName + ": componentRepoURL = " + componentRepoURL
					Logger.info componentName + ": componentJavaVersion = " + componentJavaVersion
					Logger.info componentName + ": componentAppsecScanRequired = " + componentAppsecScanRequired
										
					if(componentAppsecScanRequired != null && toSkip == false) {
						if(componentAppsecScanRequired.equalsIgnoreCase("true")) {
							Logger.info componentName +": " + componentName + " - appsecScanRequired is TRUE."
														
							if (componentRepoURL=="") {
								String componentRepoURLNotFoundString = "The component ["+ componentName +"] has appsecScanRequired set to TRUE, but does not have repoURL property for the HP Fortify Scan."
								throw new Exception (componentRepoURLNotFoundString)
							}
							
							// continue for this component.
							
							Property componentPropertyHpFortifySseName = null
							String componentHpFortifySseName = null
							try {
								componentPropertyHpFortifySseName = component.getComponentProperty(componentPropertyKey_hpFortifySseName);
								componentHpFortifySseName = componentPropertyHpFortifySseName.getValue();
							} catch (Exception e) {
								// Assuming this is optional component property
							}
		
							
							String componentVersionCodeCommitHash = ""
							componentVersionManagedPropertiesList.each { Map map ->
								String propertyName = map.get("name")
								if(propertyName == componentVersionPropertyKey_codeCommitHash) {
									componentVersionCodeCommitHash = map.get("value")
								}
							}
													
							String outputComponentNameKey = "component_" + counter + "_name"
							String outputComponentIdKey = "component_" + counter + "_id"
							String outputComponentRepoURLKey = "component_" + counter + "_repoURL"
							String outputComponentJavaVersionKey = "component_" + counter + "_javaVersion"
							String outputComponentAppsecScanRequiredKey = "component_" + counter + "_appsecScanRequired"
							String outputComponentVersionCodeCommitHashKey = "component_" + counter + "_codeCommitHash"
							String outputComponentHpFortifySseNameKey = "component_" + counter + "_hpFortifySseName"

							
							Logger.info "-----------------------------------------------"
							Logger.info outputComponentNameKey +"=" + componentName
							Logger.info outputComponentIdKey + "=" + componentId
							Logger.info outputComponentRepoURLKey + "=" + componentRepoURL
							Logger.info outputComponentJavaVersionKey + "=" + componentJavaVersion
							Logger.info outputComponentAppsecScanRequiredKey + "=" + componentAppsecScanRequired
							Logger.info outputComponentVersionCodeCommitHashKey + "=" + componentVersionCodeCommitHash
							Logger.info outputComponentHpFortifySseNameKey + "=" + componentHpFortifySseName
							Logger.info "-----------------------------------------------------"
		
							outProps.put(outputComponentNameKey, componentName);
							outProps.put(outputComponentIdKey, componentId);
							outProps.put(outputComponentRepoURLKey, componentRepoURL);
							outProps.put(outputComponentJavaVersionKey, componentJavaVersion);
							outProps.put(outputComponentAppsecScanRequiredKey, componentAppsecScanRequired);
							outProps.put(outputComponentVersionCodeCommitHashKey, componentVersionCodeCommitHash);
							outProps.put(outputComponentHpFortifySseNameKey, componentHpFortifySseName);
							
							contextFile << outputComponentNameKey +"=" + componentName + "\n"
							contextFile << outputComponentIdKey + "=" + componentId + "\n"
							contextFile << outputComponentRepoURLKey + "=" + componentRepoURL + "\n"
							contextFile << outputComponentJavaVersionKey + "=" + componentJavaVersion + "\n"
							contextFile << outputComponentAppsecScanRequiredKey + "=" + componentAppsecScanRequired + "\n"
							contextFile << outputComponentVersionCodeCommitHashKey + "=" + componentVersionCodeCommitHash + "\n"
							contextFile << outputComponentHpFortifySseNameKey + "=" + componentHpFortifySseName + "\n"
							
							counter++
						} else {
							Logger.info componentName +": " + componentName + " - appsecScanRequired is FALSE. Skip this componet."
							// skip current component
						}
					} else {
						Logger.info componentName +": " + componentName + " - appsecScanRequired is not set or toSkip="+toSkip+". Skip this componet."
						// skip current component
					}
																						
				}
				
				contextFile << "numberOfComponents=" + counter + "\n"
				outProps.put("numberOfComponents", "" + counter);

		}
		
		public static SnapshotStatusInstance getSnapshotStatusByName(Snapshot snapshot, String statusName) {
			SnapshotStatusInstance toReturn = null;
			List statusFlags = snapshot.getSnapshotStatuses();
			statusFlags.each { SnapshotStatusInstance status ->
				if (status.name == statusName) {
					Logger.info "getSnapshotStatusByName() -> snapshot status " + statusName + " FOUND for snapshot name: " + snapshot.getName()
					toReturn = status
				}
			}

			return toReturn;
		}
		
		public static ComponentVersionStatusInstance getComponentVersionStatusByName(ComponentVersion componentVersion, String statusName) {
			ComponentVersionStatusInstance toReturn = null;
			List statusFlags = componentVersion.getComponentVersionStatuses()
			statusFlags.each { ComponentVersionStatusInstance status ->
				if (status.name == statusName) {
					Logger.info "getComponentVersionStatusByName() -> Version status " + statusName + " FOUND for component version name: " + componentVersion.name + ", component version ID: " + componentVersion.id + ", from component named: " + componentVersion.component.name
					toReturn = status
				}
			}
				
			return toReturn;
		}

}
