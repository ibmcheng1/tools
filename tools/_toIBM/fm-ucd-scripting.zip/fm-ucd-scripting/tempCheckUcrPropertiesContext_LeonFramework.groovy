import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger;
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.RestServerConnectionBuilder
import com.ibm.services.ucr.api.entity.scheduleddeployment.UcrScheduledDeployment
import com.ibm.services.ucr.api.entity.scheduleddeployment.UcrScheduledDeploymentMgr
import com.ibm.services.ucr.api.entity.taskexecution.UcrTaskExecution
import com.ibm.services.ucr.api.entity.taskexecution.UcrTaskExecutionMgr

import com.fanniemae.ucr.releasedata.ReleaseData
import com.fanniemae.ucr.releasedata.ReleaseDataMgr
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.processrequest.ProcessRequest
import com.ibm.css.ucd.services.ProcessRequestServices
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.RestServerConnectionBuilder
import com.ibm.services.ucr.api.entity.release.UcrRelease
import com.ibm.services.ucr.api.entity.scheduleddeployment.UcrScheduledDeployment
import com.ibm.services.ucr.api.entity.scheduleddeployment.UcrScheduledDeploymentMgr
import com.ibm.services.ucr.api.util.UcrHelper
//import com.urbancode.air.plugin.dtm.UCDDTMHelper
import groovy.json.JsonSlurper
//import org.apache.http.impl.client.DefaultHttpClient

/**
 * Groovy script class which has access to UCD API Services.
 */
class CheckUcrPropertiesContext extends ScriptWithUcdServicesHook {
	
	Properties outProps = null
	UcdConnectionServices ucdConnectionServices = null

	/**
	 * This is the script function that is executed.
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
		this.outProps = outProps	
		this.ucdConnectionServices = ucdConnectionServices	
		
		String ucrServerUrl = ''
		String ucrSheduledDeploymentId = ''
		String taskId = ''
		
		String ucrToken = '${p?:ucrToken}'
		String processRequestId = '${p?:ucr.request.processRequestId}'
		String postDeployPutUrl = '${p?:ucr.request.postDeployPutUrl}'
		String postDeployMessage = '${p?:ucr.request.postDeployMessage}'
		
		println "processRequestId = " + processRequestId
		println "postDeployPutUrl = " + postDeployPutUrl
		println "postDeployMessage = " + postDeployMessage

		// option 1:
		String taskExecutionUrl = getTaskExecutionUrlFromUcdProcessRequest(processRequestId)
					
			
		if(postDeployPutUrl) {
			ucrServerUrl = parseServerFromUrlWithProtocol(postDeployPutUrl)
			println 'ucrServerUrl = ' + ucrServerUrl
						
			if(postDeployMessage) {
				def slurper = new JsonSlurper()
				def postDeployMessageJson = slurper.parseText(postDeployMessage)
				println 'postDeployMessageJson = ' + postDeployMessageJson
				taskId = postDeployMessageJson.taskId;
				println 'taskId = ' + taskId
				
				// from taskId to get Release, TBD
		
			} else {
				//throw new Exception ("Error: postDeployMessage is null")
				Logger.info "The postDeployMessage is null or empty. Skip this process.  No output from this step."
			}
		} else {
			//throw new Exception ("Error: postDeployPutUrl is null")
			Logger.info "The postDeployPutUrl is null or empty. Skip this process.  No output from this step."
		}
		
		String serverRootUrl = ucdConnectionServices.getUcdServer().getServerRootUrl()
		println 'serverRootUrl = ' + serverRootUrl
		//String ucdServerUrl = 'https://ucdeploy-dev:8443'
		//println 'ucdServerUrl = ' + ucdServerUrl
		String myRestServerUrl = serverRootUrl
		
		// https://ucdeploy-dev:8443/rest/deploy/applicationProcessRequest/16c43baa-1777-bc3b-a535-cc60f24593e4
		String applicationProcessRequestPath = 'rest/deploy/applicationProcessRequest/' + processRequestId		
		String restUrlFullPath = myRestServerUrl + '/' + applicationProcessRequestPath
		println 'restUrlFullPath = ' + restUrlFullPath
		
		//ucdServer.openConnection(myRestServerUrl, myRestServerTokenUsername, myRestServerTokenPassword, myRestServerProxyHost, myRestServerProxyPort, myRestServerProxyUsername, myRestServerTokenPassword)
		//def url = 'curl -k -u g9ucdc:Roxie_4m https://ucdeploy-dev:8443/rest/deploy/applicationProcessRequest/16c43baa-1777-bc3b-a535-cc60f24593e4';
		
		String authString = 'g9ucdc:Roxie_4m'
		String curlCommandString = 'curl -k -u ' + authString + ' ' + restUrlFullPath
		println "curlCommandString = " + curlCommandString
		
		outProps.put("restUrlFullPath", restUrlFullPath);
		outProps.put("curlCommandString", curlCommandString);
		
		// option 2:
		//taskExecutionUrl =  getTaskExecutionUrlFromUCDDTMHelper(restUrlFullPath)
		
		// option 3:
		taskExecutionUrl = getTaskExecutionUrlFromCurlCommand(curlCommandString)

		// option 4:
		taskExecutionUrl =  getTaskExecutionUrlFromGroovyBuiltinRest(restUrlFullPath)
		
		println "final taskExecutionUrl = " + taskExecutionUrl
		if(taskExecutionUrl) {
			ucrServerUrl = parseServerFromUrlWithProtocol(taskExecutionUrl)
			ucrSheduledDeploymentId = parseScheduleDeploymentIdFromUrl(taskExecutionUrl)
			
			println "ucrServerUrl = " + ucrServerUrl
			println "ucrSheduledDeploymentId = " + ucrSheduledDeploymentId
			
			if (ucrServerUrl) {
				RestServerConnection ucrServer = (new RestServerConnectionBuilder())
					.setServerUrl(ucrServerUrl)
					.setUrbancodeTokenAuthentication(ucrToken)
					.setTrustAllCerts()
					.openConnection()
	
				UcrScheduledDeployment ucrScheduledDeployment = UcrScheduledDeploymentMgr.getInstance(ucrServer).getById(ucrSheduledDeploymentId)
				
				// get the DTM Number in the release's data
				UcrRelease ucrRelease = ucrScheduledDeployment.getRelease()
				ReleaseData releaseData = ReleaseDataMgr.getInstance(ucrServer).getForRelease(ucrRelease)
				def dtmNumber = releaseData.getDtmNumber()
				
				outProps.put("dtmNumber", "" + dtmNumber);
						
				Logger.info "dtmNumber = " + dtmNumber
				
			} else {
				throw new Exception ("Error: ucrServerUrl is null")
			}
		} else {
			// This step is optional.  If taskExecutionUrl is null or empty,  simply do nothing.
			Logger.info "The taskExecutionUrl is null or empty. Skip this process.  No output from this step."
			//throw new Exception ("Error: taskExecutionUrl is null")
		}
		
	}
	
	def getTaskExecutionUrlFromUcdProcessRequest (String processRequestId)
	{
		println "+++ getTaskExecutionUrlFromUcdProcessRequest"
		//UcdServerConnection ucdServer= new UcdServerConnection()
		//ucdServer.openConnection(myRestServerUrl, myRestServerTokenUsername, myRestServerTokenPassword, myRestServerProxyHost, myRestServerProxyPort, myRestServerProxyUsername, myRestServerTokenPassword)
		//UcdConnectionServices ucdConnectionServices = new UcdConnectionServices(ucdServer)
		ProcessRequestServices processRequestServices = ucdConnectionServices.getProcessRequestServices()
		ProcessRequest processRequest = processRequestServices.getProcessRequest(processRequestId)
		//Logger.setLoggingLevel('debug')
		List contextPropertiesList = processRequest.getContextProperties()
		
		String taskExecutionUrl = extractTaskExecutionUrlFromContextProperties(contextPropertiesList)
		if (taskExecutionUrl) {
			outProps.put("getTaskExecutionUrlFromUcdProcessRequest", taskExecutionUrl);
		} else {
			outProps.put("getTaskExecutionUrlFromUcdProcessRequest", "null");
		}
		
		println "--- getTaskExecutionUrlFromUcdProcessRequest(): taskExecutionUrl = " + taskExecutionUrl
		return taskExecutionUrl

	}
	
	/*
	def getTaskExecutionUrlFromUCDDTMHelper(String url) {
		// 		ucdServer.openConnection(myRestServerUrl, myRestServerTokenUsername, myRestServerTokenPassword, myRestServerProxyHost, myRestServerProxyPort, myRestServerProxyUsername, myRestServerTokenPassword)
		println "+++ getTaskExecutionUrlFromUCDDTMHelper(): url = " + url
		UCDDTMHelper dtm = new UCDDTMHelper()
		// Construct the HTTP client to allow user authentication
		
		String myRestServerTokenUsername = getMyRestServerTokenUsername()
		String myRestServerTokenPassword = getMyRestServerTokenPassword()
		
		DefaultHttpClient client = dtm.createClient(myRestServerTokenUsername, myRestServerTokenPassword, null, null, true)
		def jsonData = dtm.getData(client, url)
		
		String taskExecutionUrl = extractTaskExecutionUrlFromJsonData(jsonData)
		if (taskExecutionUrl) {
			outProps.put("getTaskExecutionUrlFromUCDDTMHelper", taskExecutionUrl);
		} else {
			outProps.put("getTaskExecutionUrlFromUCDDTMHelper", "null");
		}
		
		println "--- getTaskExecutionUrlFromUCDDTMHelper(): taskExecutionUrl = " + taskExecutionUrl
		return taskExecutionUrl
	}
	*/
	
	def getTaskExecutionUrlFromGroovyBuiltinRest(String url) {
		println "+++ getTaskExecutionUrlFromGroovyBuiltinRest(): url = " + url
		String name = 'g9ucdc'
		String password = 'Roxie_4m'
		String authString = name + ":" + password;
		System.out.println("auth string: " + authString);
		
		String encoded = authString.bytes.encodeBase64().toString()
				
		String authStringEnc = encoded
		System.out.println("Base64 encoded auth string: " + authStringEnc);
		
		def connection = new URL( url )
			.openConnection() as HttpURLConnection
	
		connection.setRequestProperty("Authorization", "Basic " + authStringEnc);
		// set some headers
		connection.setRequestProperty( 'User-Agent', 'groovy-2.4.4' )
		connection.setRequestProperty( 'Accept', 'application/json' )
				
		
		String json = connection.inputStream.text
		String taskExecutionUrl = extractTaskExecutionUrlFromJson(json)
		if (taskExecutionUrl) {
			outProps.put("getTaskExecutionUrlFromGroovyBuiltinRest", taskExecutionUrl);
		} else {
			outProps.put("getTaskExecutionUrlFromGroovyBuiltinRest", "null");
		}
		
		println "--- getTaskExecutionUrlFromGroovyBuiltinRest(): taskExecutionUrl = " + taskExecutionUrl
		return taskExecutionUrl

	}
	
	def getTaskExecutionUrlFromCurlCommand(String curlCommandString){
	   //def url = 'curl -u g9ucdc:Roxie_4m https://ucdeploy-dev:8443/rest/deploy/applicationProcessRequest/16c43baa-1777-bc3b-a535-cc60f24593e4';
		println "+++ getTaskExecutionUrlFromCurlCommand(): curlCommandString = " + curlCommandString
		def proc = curlCommandString.execute();
		def outputStream = new StringBuffer();
		proc.waitForProcessOutput(outputStream, System.err)
		
		String json = outputStream.toString()
		String taskExecutionUrl = extractTaskExecutionUrlFromJson(json)
		if (taskExecutionUrl) {
			outProps.put("getTaskExecutionUrlFromCurlCommand", taskExecutionUrl);
		} else {
			outProps.put("getTaskExecutionUrlFromCurlCommand", "null");
		}
		
		println "--- getTaskExecutionUrlFromCurlCommand(): taskExecutionUrl = " + taskExecutionUrl
		return taskExecutionUrl
   }
   
   def extractTaskExecutionUrlFromJson(String json){
	   println "+++ extractTaskExecutionUrlFromJson()"
	   def slurper = new groovy.json.JsonSlurper()
	   def processRequestJsonData = slurper.parseText(json)
	   println 'processRequestJsonData = ' + processRequestJsonData
	   List contextPropertiesList = processRequestJsonData.contextProperties
	   println "ProcessRequest contextPropertiesList = " + contextPropertiesList
	   println "ProcessRequest contextPropertiesList.size() = " + contextPropertiesList.size()
	   
	   String taskExecutionUrl = ''
	   contextPropertiesList.each { Map property ->
		   if(property.name == 'link:View in IBM UrbanCode Release') {
			   println "FOUND target property -> " + property
			   taskExecutionUrl = property.value
		   }
	   }
	   println "--- extractTaskExecutionUrlFromJson(): taskExecutionUrl = " + taskExecutionUrl
	   return taskExecutionUrl
   }

   def extractTaskExecutionUrlFromJsonData(Object jsonData){
	   println "+++ extractTaskExecutionUrlFromJsonData()"
	   List contextPropertiesList = jsonData.contextProperties
	   println "ProcessRequest contextPropertiesList = " + contextPropertiesList
	   println "ProcessRequest contextPropertiesList.size() = " + contextPropertiesList.size()
	   
	   String taskExecutionUrl = ''
	   contextPropertiesList.each { Map property ->
		   if(property.name == 'link:View in IBM UrbanCode Release') {
			   println "FOUND target property -> " + property
			   taskExecutionUrl = property.value
		   }
	   }
	   println "--- extractTaskExecutionUrlFromJsonData(): taskExecutionUrl = " + taskExecutionUrl
	   return taskExecutionUrl
   }
   
   def extractTaskExecutionUrlFromContextProperties(List contextPropertiesList){
	   println "+++ extractTaskExecutionUrlFromContextProperties()"
	   println "ProcessRequest contextPropertiesList = " + contextPropertiesList
	   println "ProcessRequest contextPropertiesList.size() = " + contextPropertiesList.size()
	   
	   String taskExecutionUrl = ''
	   contextPropertiesList.each { Map property ->
		   if(property.name == 'link:View in IBM UrbanCode Release') {
			   println "FOUND target property -> " + property
			   taskExecutionUrl = property.value
		   }
	   }
	   println "--- extractTaskExecutionUrlFromContextProperties(): taskExecutionUrl = " + taskExecutionUrl
	   return taskExecutionUrl
   }
   
   String getMyRestServerTokenPassword() {
	   String authToken = System.getenv("AUTH_TOKEN");
	   return "{\"token\" : \"" + authToken + "\"}";
   }
   
   String getMyRestServerTokenUsername() {
	   return "PasswordIsAuthToken";
   }
   
   /**
	* Various UCR calls are given a URL to UCR, but NOT the Deployment or Release IDs - this
	* function parses that URL to return the Deployment ID.  In particular, when UCR calls
	* plugins, it often sends this URL.  Also, when the built in UCR to UCD Application Process
	* capability is used, this is the URL sent to UCD.  The format of the url is
	* [server]/scheduledDeployment/[deploymentId]/...,
	* such as https://ucrServer:9443/scheduledDeployment/04ee62a9-19a4-4b79-853c-df3e2791a496#execution/Segment/f5f02123-f900-47f9-b003-0b8ea01c2822/TaskExecution/3f265905-825f-4300-9ddc-63657fe318f4
	* or just scheduledDeployment/04ee62a9-19a4-4b79-853c-df3e2791a496#execution/Segment/f5f02123-f900-47f9-b003-0b8ea01c2822/TaskExecution/3f265905-825f-4300-9ddc-63657fe318f4
	* @return the Deployment ID from the url.
	*/
   public static String parseScheduleDeploymentIdFromUrl( String url ) {
	   String[] elements = url.split('#')[0].split('/')
	   return elements[ elements.size()-1 ]
   }
   
   /**
	* Various UCR calls are given a URL to UCR, but NOT the Deployment or Release IDs - this
	* function parses that URL to return the server string.  In particular, when UCR calls
	* plugins, it often sends this URL.  Also, when the built in UCR to UCD Application Process
	* capability is used, this is the URL sent to UCD.  The format of the url is
	* [server]/scheduledDeployment/[deploymentId]#...,
	* such as https://ucrServer:9443/scheduledDeployment/04ee62a9-19a4-4b79-853c-df3e2791a496#execution/Segment/f5f02123-f900-47f9-b003-0b8ea01c2822/TaskExecution/3f265905-825f-4300-9ddc-63657fe318f4
	* @return The server string, such as https://ucrServer:9443
	*/
   public static String parseServerFromUrl( String url ) {
	   URL theUrl = new URL(url)
	   String retval = theUrl.getAuthority() + "://" + theUrl.getHost()
	   int port = theUrl.getPort().toInteger().value
	   if (port > 0) {
		   retval = retval + ":" + theUrl.getPort()
	   }
	   return retval
   }
   
   /**
	* Various UCR calls are given a URL to UCR, but NOT the Deployment or Release IDs - this
	* function parses that URL to return the server string.  In particular, when UCR calls
	* plugins, it often sends this URL.  Also, when the built in UCR to UCD Application Process
	* capability is used, this is the URL sent to UCD.  The format of the url is
	* [server]/scheduledDeployment/[deploymentId]#...,
	* such as https://ucrServer:9443/scheduledDeployment/04ee62a9-19a4-4b79-853c-df3e2791a496#execution/Segment/f5f02123-f900-47f9-b003-0b8ea01c2822/TaskExecution/3f265905-825f-4300-9ddc-63657fe318f4
	* @return The server string, such as https://ucrServer:9443
	*/
   public static String parseServerFromUrlWithProtocol( String url ) {
	   URL theUrl = new URL(url)
	   String retval = theUrl.getProtocol() + "://" + theUrl.getHost()
	   int port = theUrl.getPort().toInteger().value
	   if (port > 0) {
		   retval = retval + ":" + theUrl.getPort()
	   }
	   return retval
   }

}