#!/bin/bash

################################
#helper functions
################################
log () {
    MESSAGE=$1
    TS=$(TZ=":US/Eastern" date +%H:%M:%S)
    echo "${TS} - $MESSAGE"
}

#checks that a given role is assumed
CHECK_ROLE_ASSUMED () {
    ROLE=$1
    CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
    if [[ $CURRENT_ROLE != $ROLE ]] ; then
        echo "ERROR: Failed to assume the role: ${ROLE}"
        exit 1
    fi
    
    log "Assumed role: ${ROLE}"
}

#checks that given image exists in ECR
CHECK_IMAGE_EXISTS () {
    log "Checking that the image exists in ECR"
    IMAGE=$1
    IMAGE_TAG=$(echo $IMAGE | cut -d ':' -f 2)
    ECR_URL=$(echo $IMAGE | cut -d '/' -f 1)
    ECR_REPO=$(echo ${IMAGE/$ECR_URL\//} | cut -d : -f 1)
    
    log "IMAGE: ${IMAGE}"
    log "aws ecr describe-images --repository-name $ECR_REPO --query \"imageDetails[].imageTags\" --output text | grep $IMAGE_TAG"
    ECR_CHECK=$(aws ecr describe-images --repository-name $ECR_REPO --query "imageDetails[].imageTags" --output text | grep $IMAGE_TAG 2>/dev/null)
    
    if [[ -z $ECR_CHECK ]] ; then
            echo "Can't find image ${IMAGE_TAG} in ${ECR_URL}/${ECR_REPO}"
            
            if [[ -z $2 ]] ; then
                exit 1
            else
                IMAGE_CHECK=MISSING
            fi
    else 
        log "Found image ${IMAGE_TAG} in ${ECR_URL}/${ECR_REPO}"
    fi
}

#run a command with logging and error checking
RUN_CMD () {
    CMD=$1
    log "Running: ${CMD}"
    $CMD
    
    if [[ $? -ne 0 ]]; then
        echo "Failed while running: ${CMD}"
        exit 1
    fi
}

############MAIN###################

if [[ "${p:environment/ecr.deploy}" == "false" ]] ; then
    log "Skipping ECR step"
    exit 0
fi

################################
#Read in UCD properties
################################
#get properties for ECR source location (to promote from)
SOURCE_ROLE=${p?:getParameters/priorEnvRole}
SOURCE_IMAGE=${p?:getParameters/imageLocation}

#get properties for ECR target location (to promote to)
TARGET_ROLE=${p:environment/iam.awsRole}
TARGET_IMAGE=${p?:getParameters/ContainerImage}

################################
#First check if this image is already promoted
################################
source .awsprofile
CHECK_ROLE_ASSUMED $TARGET_ROLE
log "Make sure image doesn't already exist in current ECR"
CHECK_IMAGE_EXISTS $TARGET_IMAGE dont_fail

if [[ $IMAGE_CHECK != "MISSING" ]] ; then
    echo "${TARGET_IMAGE} already exists. No need to promote to ECR"
    exit 0
fi

################################
#Validate source ECR info
################################
#see if we can assume the prior environment role
log "Switching to ${SOURCE_ROLE}"
$switchprofile_1 #this can switch to any role which are ordered by index: switchprofile_<index>. In this case two roles: [0, 1]
CHECK_ROLE_ASSUMED $SOURCE_ROLE

#validate that the image exists in that ECR location
log "Going to make sure the image exists in the lower env ECR"
CHECK_IMAGE_EXISTS $SOURCE_IMAGE

################################
#Pull image
################################
log "Going to pull image from ${SOURCE_IMAGE}"

#get login for docker
log "Authenticate docker client to ${ECR_URL}"
export PATH=/usr/lib/fnma_docker:$PATH
$(aws ecr get-login --region us-east-1 --no-include-email) 
if [[ $? -ne 0 ]]; then
    echo "Failed to authenticate with docker"
    exit 1
fi

#pull the image
RUN_CMD "docker pull ${SOURCE_IMAGE}"
log "Finished running docker pull"

#tag the image
log "Going to tag the image"
REPO_PATH=$(echo $TARGET_IMAGE | cut -d ':' -f 1)
RUN_CMD "docker tag ${SOURCE_IMAGE} ${REPO_PATH}:latest"
RUN_CMD "docker tag ${REPO_PATH}:latest ${TARGET_IMAGE}"

################################
#Push image to ECR in current environment
################################
log "Going to push image to ${TARGET_IMAGE}"

#switch back to current env role and authenticate docker again
$switchprofile_0
CHECK_ROLE_ASSUMED $TARGET_ROLE

log "Authenticate docker client to ${ECR_URL}"
$(aws ecr get-login --region us-east-1 --no-include-email) 
if [[ $? -ne 0 ]]; then
    echo "Failed to authenticate with docker"
    exit 1
fi

#push the image
RUN_CMD "docker push ${REPO_PATH}:latest"
RUN_CMD "docker push ${TARGET_IMAGE}"
log "Finished running docker push"

log "Checking that image has been pushed to ECR"
CHECK_IMAGE_EXISTS $TARGET_IMAGE
log "Succesfully promoted image to current ECR repo"
