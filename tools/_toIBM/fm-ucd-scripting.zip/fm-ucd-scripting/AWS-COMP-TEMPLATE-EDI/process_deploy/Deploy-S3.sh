#!/bin/bash

################################
#Helper functions
################################
log () {
    MESSAGE=$1
    TS=$(TZ=":US/Eastern" date +%H:%M:%S)
    echo "${TS} - $MESSAGE"
}

#run a command with logging and error checking
RUN_CMD () {
    CMD=$1
    log "Running: ${CMD}"
    $CMD
    
    if [[ $? -ne 0 ]]; then
        echo "Failed while running: ${CMD}"
        exit 1
    fi
}

VALIDATE_ROLE () {
    ROLE=$1
    
    source .awsprofile
    CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
    if [[ $CURRENT_ROLE != $ROLE ]] ; then
        echo "ERROR: Failed to assume the role: ${ROLE}"
        exit 1
    fi    
    log "Assumed role: ${ROLE}"
}

VALIDATE_S3_PATHS () {
    S3_FILES=$1
    
    #check that s3 paths in file pairs are valid
    log "Validating s3 paths"
    for FILE_PAIR in $S3_FILES ; do
        S3_PATH=$(echo $FILE_PAIR | cut -d ':' -f 2)
        S3_KEY=$(echo $FILE_PAIR | cut -d ':' -f 3)
        S3_PATH="${S3_PATH}:${S3_KEY}"
        
        if [[ -z $S3_PATH ]] ; then
            echo "${FILE_PAIR} line is invalid in fileNames property. Needs to be in this format: <sourceFile>:<s3Location>"
            exit 1
        fi
    done
}

CLEANUP_S3_PATH () {
    S3_PATH_CLEANED=$1
    FILE_EXTENSION="\.(war|zip|jar|ear|txt|yaml|json)$"
    if  [[ $S3_PATH_CLEANED =~ $FILE_EXTENSION ]] ; then
        S3_PATH_CLEANED=$(dirname $S3_PATH_CLEANED) 
    fi
    
    TRAILING_SLASH="/$"
    if [[ ! $S3_PATH_CLEANED =~ $TRAILING_SLASH ]] ; then
        S3_PATH_CLEANED=${S3_PATH_CLEANED}/
    fi
}

COPY_S3 () {
    S3_PATHS=$1
    KMS_KEY=$2
    
    #validate property
    VALIDATE_S3_PATHS $S3_FILES
    
    #check the type of encryption
    if [[ ! -z $KMS_KEY ]] ; then
        KMS_FLAG="aws:kms --sse-kms-key-id ${KMS_KEY}"
    fi
    
    #copy files
    for FILE_PAIR in $S3_FILES ; do 
        SOURCE_FILE=$(echo $FILE_PAIR | cut -d ':' -f 1)
        S3_PATH=$(echo $FILE_PAIR | cut -d ':' -f 2)
        S3_KEY=$(echo $FILE_PAIR | cut -d ':' -f 3)
        S3_PATH="${S3_PATH}:${S3_KEY}"
        CLEANDEPLOY=$(echo $FILE_PAIR | cut -d ':' -f 4)
        
        CLEANUP_S3_PATH $S3_PATH && S3_PATH=$S3_PATH_CLEANED
        
        if [[ -d $SOURCE_FILE ]] ; then
            RECURSIVE="--recursive"
        fi
        
        if [[ ! -z $CLEANDEPLOY ]] ; then
            log "Performing clean deploy"
            RUN_CMD "aws s3 rm ${S3_PATH} --recursive"
        fi
        
        RUN_CMD "aws s3 cp ${SOURCE_FILE} ${S3_PATH} ${RECURSIVE} --sse ${KMS_FLAG}"
    done

    log "Finished copying to s3 location"
}

############MAIN###################

if [[ "${p:environment/s3.deploy}" == "false" ]] ; then
    log "Skipping s3 copy"
    exit 0
fi

################################
#UCD Properties
################################
S3_FILES="${p:environment/s3.s3Files}" #source file and corresponding s3 location: <sourceFile>:<s3Target>
ROLE=${p:environment/iam.awsRole}
KMS_KEY=${p:environment/s3.kmsKey}

################################
#copy to s3 location
################################
VALIDATE_ROLE $ROLE
COPY_S3 "${S3_FILES}" $KMS_KEY

log "Exiting successful"