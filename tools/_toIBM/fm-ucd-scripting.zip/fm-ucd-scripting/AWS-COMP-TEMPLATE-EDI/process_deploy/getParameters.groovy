import groovy.json.*

def deployECR = "${p:environment/ecr.deploy}"
def deployECS = "${p:environment/ecs.deploy}"
if ((deployECR != null && deployECR == "true") || (deployECS != null && deployECS == "true")  ){
	println "Perform getParamaters. deployECR=" + deployECR + ", deployECS=" + deployECS
} else {
	println "Skip getParamaters. deployECR=" + deployECR + ", deployECS=" + deployECS
	System.exit(0)
}

//Make sure parameters file exists
def parametersFileName = "${p:environment/cf.parametersJson}"
def parametersFile = new File(parametersFileName)

if (!parametersFile.exists()) {
    println "Failed to locate ${parametersFileName}"
    System.exit(1)
}

//Extract all the parameters from parameters file into ucd properties
//Also update container image version to component version if it does not match
def parameters = new JsonSlurper().parseText(parametersFile.getText())
def parameterList = ["ApplicationShortName", "ContainerName", "ContainerImage", "ClusterName", "ServiceName"]
def updatedJson = false
def componentVersion = "${p:version.name}"

parameters.each { parameter ->
    key = parameter.ParameterKey
    value = parameter.ParameterValue
    
    if (parameterList.contains(key)) {
        println "Getting parameter: ${key}"
        
        //ensure image version is the same as ucd component version
        if (key == "ContainerImage") {
            def (ecrPath, imageVersion) = value.split(":")
            println "current image version: ${imageVersion}"
            if (imageVersion != componentVersion) {
                println "Changing ${imageVersion} to ${componentVersion} in json file"
                value = ecrPath + ":" + componentVersion
                parameter["ParameterValue"] = value
                updatedJson = true
            }
        }
        
        println "${key} : ${value}"
        outProps.put(key, value)
    }
}

if (updatedJson) {
    def updateParametersJson = new JsonBuilder(parameters).toPrettyString()
    println updateParametersJson
    parametersFile.write(updateParametersJson)
}

//check if we need to get the role from previous environment
if ("${p:environment/envType}" != "DEVL" ) {
    println "We'll need to promote the image to this env's ECR repo so need info on prior env"
    def (priorEnvRole, priorEnvAccountId, priorEnvType, priorEnvJson) = getPriorEnvInfo()
    def imageLocation = getECRLocation(priorEnvJson, componentVersion)
    
    println "Getting priorEnvRole: " + priorEnvRole
    println "Getting priorEnvAccountId: " + priorEnvAccountId
    println "Getting priorEnvType: " + priorEnvType
    println "Getting image location in lower env ECR: " + imageLocation
    
    outProps.put("priorEnvRole", priorEnvRole)
    outProps.put("priorEnvAccountId", priorEnvAccountId)
    outProps.put("priorEnvType", priorEnvType)
    outProps.put("imageLocation", imageLocation)
}

def getPriorEnvInfo() {
    def errors = []
    def priorEnvInfoString = '''${p:environment/ecr.previousEnvInfo}'''
    def priorEnvInfo = [:]
    
    println "Validating previousEnvInfo"
    priorEnvInfoString.split("\n").each { line ->
        def values = line.split("=")
        if (values.size() != 2) {
            errors << "${line} is invalid. Needs to be in this format: <property>=<value>"
        }
        
        priorEnvInfo.put(values[0], values[1])
    }
    
    if (errors) {
        println "Failed while validating previousEnvInfo:\n" + errors.join("\n")
        System.exit(1)
    }
    
    def requiredFields = ["awsRole", "awsLifeCycle", "parametersJson", "envType"]
    
    requiredFields.each { field ->
        if (!priorEnvInfo.containsKey(field)) {
            errors << "Missing ${field} in previousEnvInfo"
        }
    }
    
    if (errors) {
        println "Failed while validating previousEnvInfo:\n" + errors.join("\n")
        println "Should have the following:\n------------------------------------------"
        println "awsRole=<role>\nawsLifeCycle=<accountId>\nenvType=<envType>\nparametersJson=<relativePathToJson>"
        System.exit(1)
    }

    return [priorEnvInfo["awsRole"], priorEnvInfo["awsLifeCycle"], priorEnvInfo["envType"], priorEnvInfo["parametersJson"]]
}

def getECRLocation(def envJson, def componentVersion) {
    //Make sure parameters file exists
    println "Going to check parameters json file from previousEnvInfo: ${envJson}"
    def parametersFile = new File(envJson)
    def imageLocation
    
    if (!parametersFile.exists()) {
        println "Failed to locate ${envJson}"
        System.exit(1)
    }
    
    def parameters = new JsonSlurper().parseText(parametersFile.getText())
    parameters.each { parameter ->
        if (parameter.ParameterKey == "ContainerImage") {
            imageLocation = parameter.ParameterValue
        }
    }
    
    if (!imageLocation) {
        println "Couldn't find ContianerImage parameter in ${envJson}"
        System.exit(1)
    }
    
    //make sure it has the component version
    def (ecrPath, currentTag) = imageLocation.split(":")
    imageLocation = ecrPath + ":" + componentVersion
    
    return imageLocation
}
