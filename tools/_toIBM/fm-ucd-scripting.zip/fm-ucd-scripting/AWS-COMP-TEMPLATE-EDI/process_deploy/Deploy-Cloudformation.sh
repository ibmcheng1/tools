#!/bin/bash

################################
#Helper functions
################################
log () {
    MESSAGE=$1
    TS=$(TZ=":US/Eastern" date +%H:%M:%S)
    echo "${TS} - $MESSAGE"
}

#run a command with logging and error checking
RUN_CMD () {
    CMD=$1
    log "Running: ${CMD}"
    $CMD
    
    if [[ $? -ne 0 ]]; then
        echo "Failed while running: ${CMD}"
        exit 1
    fi
}

VALIDATE_ROLE () {
    ROLE=$1
    
    source .awsprofile
    CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
    if [[ $CURRENT_ROLE != $ROLE ]] ; then
        echo "ERROR: Failed to assume the role: ${ROLE}"
        exit 1
    fi    
    log "Assumed role: ${ROLE}"
}

CLEANUP_S3_PATH () {
    S3_PATH_CLEANED=$1
    FILE_EXTENSION="\.(war|zip|jar|ear|txt|yaml|json)$"
    if  [[ $S3_PATH_CLEANED =~ $FILE_EXTENSION ]] ; then
        S3_PATH_CLEANED=$(dirname $S3_PATH_CLEANED) 
    fi
    
    TRAILING_SLASH="/$"
    if [[ ! $S3_PATH_CLEANED =~ $TRAILING_SLASH ]] ; then
        S3_PATH_CLEANED=${S3_PATH_CLEANED}/
    fi
}

CLOUDFORMATION_PACKAGE () {
    CFT_S3_LOCATION=$1
    TEMPLATE_FILE=$2
    PARAMETERS_FILE=$3
    KMS_KEY=$4
    
    log "Running package step with ${CFT_S3_LOCATION}"
    
    CLEANUP_S3_PATH $CFT_S3_LOCATION && CFT_S3_LOCATION=$S3_PATH_CLEANED
    
    TEMPLATE=${p:componentProcess.defaultWorkDir}/${TEMPLATE_FILE}
    PARAMETERS=${p:componentProcess.defaultWorkDir}/${PARAMETERS_FILE}
    S3_BUCKET=$(echo $CFT_S3_LOCATION | cut -d '/' -f 3)
    S3_PREFIX=$(echo $CFT_S3_LOCATION | cut -d ':' -f 2 | sed -e "s/\/\/${S3_BUCKET}\///")
    NEW_TEMPLATE_FILE=new${TEMPLATE_FILE}
    
    if [[ ! -z $KMS_KEY ]] ; then
        KMS_FLAG="--kms-key-id ${KMS_KEY}"
    fi
    
    if [[ ! -z $S3_PREFIX ]] ; then
        S3_PREFIX_FLAG="--s3-prefix ${S3_PREFIX}"
    fi
    
    #run cloudformation package 
    RUN_CMD "aws cloudformation package --template-file ${TEMPLATE} --s3-bucket ${S3_BUCKET} $S3_PREFIX_FLAG --output-template-file ${NEW_TEMPLATE_FILE} $KMS_FLAG"
    
    if [[ ! -e $NEW_TEMPLATE_FILE ]] ; then
        echo "Error creating new sam template during package step"
        exit 1
    fi
    log "Created new template during package step: ${NEW_TEMPLATE_FILE}"
    
    RUN_CMD "aws s3 cp ${NEW_TEMPLATE_FILE} ${CFT_S3_LOCATION} --sse aws:kms --sse-kms-key-id ${KMS_KEY}"
    TEMPLATE_S3_URL=$(aws s3 presign ${CFT_S3_LOCATION}${NEW_TEMPLATE_FILE})
    TEMPLATE_S3_URL=$(echo $TEMPLATE_S3_URL | cut -d '?' -f 1)
    
    echo "template s3 url: ${TEMPLATE_S3_URL}"
    if [[ -z $TEMPLATE_S3_URL ]] ; then
        echo "Failed to get url for new cft template in s3"
        exit 1
    fi
}

DELETE_STACK () {
    STACK_NAME=$1
    aws cloudformation delete-stack --stack-name $STACK_NAME
            
    if [[ $? -ne 0 ]]; then
        echo "Failed to delete the stack"
        exit 1
    fi
    
    #wait on it to be deleted
    aws cloudformation wait stack-delete-complete --stack-name $STACK_NAME
    log "${STACK_NAME} has been deleted"
}

CHECK_STACK () {
    log "Checking if stack already exists: ${STACK_NAME}"
    aws cloudformation describe-stacks --stack-name $STACK_NAME > /dev/null 2>&1
    
    if [[ $? -ne 0 ]]; then
        log "Stack doesn't exist so create new stack"
        CMD=create-stack
    else
        log "Stack already exists so update existing stack"
        CMD=update-stack
        
        #make sure stack isn't already being updated
        log "Wait on stack to be ready first"
        IN_PROGRESS="PROGRESS$"
        FAILED="FAILED$"
        TIME_OUT=0
        
        while true ; do
            STACK_STATUS=$(aws cloudformation describe-stacks --stack-name $STACK_NAME --query "Stacks[].StackStatus" --output text 2>/dev/null)
            log "Status: $STACK_STATUS"
            
            if [[ $STACK_STATUS =~ $FAILED ]] ; then
                #if it's in a failed state then we can't update it sometimes (deleting/creating fixes that issue)
                log "Stack is in a failed state, so try deleting and recreating it"
                DELETE_STACK $STACK_NAME
                CMD="create-stack"
                break
            elif [[ ! $STACK_STATUS =~ $IN_PROGRESS && ! -z $STACK_STATUS ]] ; then
                log "Stack is ready to update"
                break
            elif [[ -z $STACK_STATUS ]] ; then
                log "Stack must have been deleted, so we'll try to create it"
                CMD="create-stack"
                break
            fi
            
            TIME_OUT=$((TIME_OUT+1))
            if [[ $TIME_OUT -eq 360 ]] ; then
                echo "Timed out waiting on stack to be ready"
                exit 1
            fi
            
            sleep 5
        done
    fi
}

PRINT_CF_EVENTS () {
    STACK_NAME=$1
    
    log "Events for the last 10 minutes:"
    PAST_TIME=$(date '+%Y-%m-%dT%H:%M:%S' -d '10 minutes ago + 5 hours')
    aws cloudformation describe-stack-events --stack-name  ${STACK_NAME} --query "StackEvents[?Timestamp>='$PAST_TIME']"
}

DEPLOY_STACK () {
    STACK_NAME=$1
    TEMPLATE=$2
    PARAMETERS_FILE=$3
    PARAMETERS=${p:componentProcess.defaultWorkDir}/${PARAMETERS_FILE}
    
    #check if we need to create or update stack
    CHECK_STACK $STACK_NAME
    
    log "Going to perform action ${CMD} for cloudformation stack ${STACK_NAME}"
    log "aws cloudformation ${CMD} --stack-name ${STACK_NAME} ${TEMPLATE} --parameters file://${PARAMETERS} --capabilities CAPABILITY_NAMED_IAM CAPABILITY_AUTO_EXPAND 2>&1"
    STAT=$(aws cloudformation $CMD --stack-name ${STACK_NAME} $TEMPLATE --parameters file://${PARAMETERS} --capabilities CAPABILITY_NAMED_IAM CAPABILITY_AUTO_EXPAND 2>&1)
    
    if [[ $? -ne 0 ]]; then
        NO_UPDATES="No updates are to be performed."
        if [[ $STAT =~ $NO_UPDATES ]] ; then
            echo "No updates to deploy"
            exit 0
        fi
        
        echo "Stack creation/update failed: ${STAT}"
        exit 1
    fi
    
    echo "*****************************************************************"
    echo "Cloudformation stack creation/update cannot be stopped from UCD"
    echo "*****************************************************************"
    
    ################################
    #Wait on stack update to complete
    ################################
    COMPLETED="COMPLETE$"
    FAILED="FAILED$"
    ROLLBACK="ROLLBACK"
    TIME_OUT=0
    
    while true ; do 
        STACK_STATUS=$(aws cloudformation describe-stacks --stack-name $STACK_NAME --query "Stacks[].StackStatus" --output text)
        log "Status: ${STACK_STATUS}"
        
        if [[ $STACK_STATUS =~ $FAILED || $STACK_STATUS =~ $COMPLETED ]] ; then
            break
        fi
     
        TIME_OUT=$((TIME_OUT+1))
        if [[ $TIME_OUT -eq 360 ]] ; then
            echo "STACK update/creation is not completing or failing within an hour"
            exit 1
        fi
        
        sleep 10
    done
    
    if [[ $STACK_STATUS =~ $FAILED || $STACK_STATUS =~ $ROLLBACK ]] ; then
        echo "Failed while deploying ${STACK_NAME}"
        PRINT_CF_EVENTS $STACK_NAME
        exit 1
    fi
    
    log "Stack creation/update completed succesfully"
    PRINT_CF_EVENTS $STACK_NAME
}

############MAIN###################

if [[ "${p:environment/cf.deploy}" == "false" ]] ; then
    log "Skipping cloudformation step"
    exit 0
fi

################################
#UCD Properties
################################
CFT_S3_LOCATION=${p:environment/cf.cftS3Location} #to use for cft package. leave blank if you don't want to package
ROLE=${p:environment/iam.awsRole}
PARAMETERS_FILE=${p:environment/cf.parametersJson}
TEMPLATE_FILE=${p:environment/cf.cloudformationTemplate}
KMS_KEY=${p:environment/s3.kmsKey}
STACK_NAME=${p:environment/cf.stackName}

# override STACK_NAME in ecs.deploy=true case
if [[ ("${p:environment/ecs.deploy}" == "true") && (-z ${STACK_NAME}) ]] ; then
    log "ecs.deploy=true and current STACK_NAME is empty, get STACK_NAME from getParameters step."
    CLUSTER_NAME=${p?:getParameters/ClusterName}
    SERVICE_NAME=${p?:getParameters/ServiceName}
    STACK_NAME=${CLUSTER_NAME}-${SERVICE_NAME}
    log "calculated STACK_NAME = ${STACK_NAME}"   
fi

log "CFT_S3_LOCATION = ${CFT_S3_LOCATION}"
log "PARAMETERS_FILE = ${PARAMETERS_FILE}"
log "TEMPLATE_FILE = ${TEMPLATE_FILE}"
log "STACK_NAME = ${STACK_NAME}"

################################
#Validate that we assumed the role
################################
VALIDATE_ROLE $ROLE

################################
#Validate UCD input
################################
#Check given parameters json file exists 
log "Checking that parameters json file exists"
if [[ ! -e $PARAMETERS_FILE ]] ; then
    echo "Can't find parameters json file"
    exit 1
fi
log "Found file: ${PARAMETERS_FILE}"

#check that cloudformation template file exists
log "Checking that the cloudformation template file exists"
if [[ ! -e $TEMPLATE_FILE ]] ; then
    echo "Can't find cloudformation template yaml file"
    exit 1
fi
log "Found file: ${TEMPLATE_FILE}" 

################################
#Run cloudformation package step
################################
if [[ ! -z $CFT_S3_LOCATION ]] ; then
    CLOUDFORMATION_PACKAGE $CFT_S3_LOCATION $TEMPLATE_FILE $PARAMETERS_FILE $KMS_KEY
    TEMPLATE="--template-url ${TEMPLATE_S3_URL}"
else
    log "Skipping package step since CFT_S3_LOCATION is not defined"
    TEMPLATE="--template-body file://${p:componentProcess.defaultWorkDir}/${TEMPLATE_FILE}"
fi

log "TEMPLATE = ${TEMPLATE}"

################################
#Deploy stack 
################################
DEPLOY_STACK "${STACK_NAME}" "${TEMPLATE}" "${PARAMETERS_FILE}"

log "Exiting successfully"