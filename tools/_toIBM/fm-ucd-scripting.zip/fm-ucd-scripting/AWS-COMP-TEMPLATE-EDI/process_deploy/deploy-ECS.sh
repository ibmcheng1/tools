#!/bin/bash

################################
#Helper functions
################################
log () {
    MESSAGE=$1
    TS=$(TZ=":US/Eastern" date +%H:%M:%S)
    echo "${TS} - $MESSAGE"
}

DELETE_STACK () {
    STACK_NAME=$1
    aws cloudformation delete-stack --stack-name $STACK_NAME
            
    if [[ $? -ne 0 ]]; then
        echo "Failed to delete the stack"
        exit 1
    fi
    
    #wait on it to be deleted
    aws cloudformation wait stack-delete-complete --stack-name $STACK_NAME
    log "${STACK_NAME} has been deleted"
}

############MAIN###################

if [[ "${p:environment/ecs.deploy}" == "false" ]] ; then
    echo "Skipping ECS step"
    exit 0
fi

################################
#Read in UCD properties
################################
PARAMETERS_JSON=${p:environment/cf.parametersJson}
TEMPLATE_YAML=${p:environment/cf.cloudformationTemplate}
VERSION=${p:version.name}
ROLE=${p:environment/iam.awsRole}

CLUSTER_NAME=${p?:getParameters/ClusterName}
SERVICE_NAME=${p?:getParameters/ServiceName}
CONTAINER_IMAGE=${p?:getParameters/ContainerImage}

################################
#Validate that we assumed the role
################################
source .awsprofile
CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
if [[ $CURRENT_ROLE != $ROLE ]] ; then
    echo "ERROR: Failed to assume the role: ${ROLE}"
    exit 1
fi
log "Assumed role: ${CURRENT_ROLE}"

################################
#Validate user input
################################
#Check given parameters json file exists and contains the correct image version
log "Checking that parameters json file exists"
if [[ ! -e $PARAMETERS_JSON ]] ; then
    echo "Can't find parameters json file"
    exit 1
fi
log "Found file: ${PARAMETERS_JSON}"

#Check that cluster exists
log "Checking that cluster name is valid"
CLUSTER_CHECK=$(aws ecs describe-clusters --clusters $CLUSTER_NAME --query "clusters[].clusterName" --output text 2>/dev/null)

if [[ $CLUSTER_CHECK != $CLUSTER_NAME ]] ; then
    echo "Can't access ECS Cluster ${CLUSTER_NAME}"
    exit 1
fi
log "Validated ECS Cluster ${CLUSTER_NAME}"

#Check that image tag matches component version
log "Checking that the current image tag is the same as the UCD component version"
IMAGE_TAG=$(echo $CONTAINER_IMAGE | cut -d ':' -f 2)
if [[ $(grep $VERSION $PARAMETERS_JSON | wc -l) -eq 0 || $IMAGE_TAG != $VERSION ]] ; then
    echo "Failed to add ucd component version to ${PARAMETERS_JSON} (check getParameters step of the component process for troubleshooting)"
    exit 1
fi
log "Validated container image in parameters file" 

#Check that the image exists in ECR repo
log "Checking that the image exists in ECR"
ECR_URL=$(echo $CONTAINER_IMAGE | cut -d '/' -f 1)
ECR_REPO=$(echo ${CONTAINER_IMAGE/$ECR_URL\//} | cut -d : -f 1)
ECR_CHECK=$(aws ecr describe-images --repository-name $ECR_REPO --query "imageDetails[].imageTags" --output text | grep $IMAGE_TAG)

if [[ -z $ECR_CHECK ]] ; then
        echo "Can't find image ${IMAGE_TAG} in ${ECR_URL}/${ECR_REPO}"
        exit 1
fi
log "Found image ${IMAGE_TAG} in ${ECR_URL}/${ECR_REPO}"

log "Paremeters Json validated successfully:"
cat $PARAMETERS_JSON
echo ""

#check that cloudformation template file exists
log "Checking that the cloudformation template file exists"
if [[ ! -e $TEMPLATE_YAML ]] ; then
    echo "Can't find cloudformation template yaml file"
    exit 1
fi
log "Found file: $TEMPLATE_YAML"

################################
#create or update stack in ecs cluster
################################
STACK_NAME=${CLUSTER_NAME}-${SERVICE_NAME}
TEMPLATE=${p:componentProcess.defaultWorkDir}/${TEMPLATE_YAML}
PARAMETERS=${p:componentProcess.defaultWorkDir}/${PARAMETERS_JSON}

# CF step should have completed ECS deployment

#############################
#Make sure ECS service exists
#############################
log "Checking ECS resources were created/updated"
SERVICE_CHECK=$(aws ecs describe-services --cluster $CLUSTER_NAME --services $SERVICE_NAME --query "services[].status" --output text)

if [[ $SERVICE_CHECK != "ACTIVE" ]] ; then
    echo "Can't find service: ${SERVICE_NAME}"
    exit 1
fi
log "Found ECS service ${SERVICE_NAME}"

#Get the new task definition
TASK_DEFINITION=$(aws ecs describe-services --cluster $CLUSTER_NAME --services $SERVICE_NAME --query "services[].taskDefinition" --output text)

if [[ -z $TASK_DEFINITION ]] ; then
    echo "Can't find any task definition for service ${SERVICE_NAME}"
    exit 1
fi
log "Found task definition: ${TASK_DEFINITION}"

CURRENT_IMAGE=$(aws ecs describe-task-definition --task-definition $TASK_DEFINITION --query "taskDefinition.containerDefinitions[].image" --output text)
log "Current image: ${CURRENT_IMAGE}"

if [[ $CURRENT_IMAGE != $CONTAINER_IMAGE ]] ; then
    echo "${CONTAINER_IMAGE} did not get updated in the task definition"
    exit 1
fi
log "Verified that the ECS service has been created/updated with new task definition for container: ${CONTAINER_IMAGE}"