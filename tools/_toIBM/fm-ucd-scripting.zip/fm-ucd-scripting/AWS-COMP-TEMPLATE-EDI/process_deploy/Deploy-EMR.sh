#!/bin/bash

################################
#Helper functions
################################
log () {
    MESSAGE=$1
    TS=$(TZ=":US/Eastern" date +%H:%M:%S)
    echo "${TS} - $MESSAGE"
}

#run a command with logging and error checking
RUN_CMD () {
    CMD=$1
    log "Running: ${CMD}"
    $CMD
    
    if [[ $? -ne 0 ]]; then
        echo "Failed while running: ${CMD}"
        exit 1
    fi
}

CLEANUP_S3_PATH () {
    S3_PATH_CLEANED=$1
    FILE_EXTENSION="\.(war|zip|jar|ear)$"
    if  [[ $S3_PATH_CLEANED =~ $FILE_EXTENSION ]] ; then
        S3_PATH_CLEANED=$(dirname $S3_PATH_CLEANED) 
    fi
    
    TRAILING_SLASH="/$"
    if [[ ! $S3_PATH_CLEANED =~ $TRAILING_SLASH ]] ; then
        S3_PATH_CLEANED=${S3_PATH_CLEANED}/
    fi
}

############MAIN###################

if [[ "${p:environment/emr.deploy}" == "false" ]] ; then
    echo "Skipping EMR step"
    exit 0
fi

################################
#UCD Properties
################################
EMR_FILES="${p:environment/emr.emrFiles}" #needs to include source path and target path for each file separated by new line: <file location>:<target location on emr node>
ROLE=${p:environment/iam.awsRole}
CLUSTER_NAME=${p:environment/emr.emrClusterName}
S3_LOCATION=${p:environment/emr.emrS3Location}
EMR_SCRIPT=${p:Prepare EMR Deploy Script/emrScript}
KMS_KEY=${p:environment/s3.kmsKey}

################################
#Validate that we assumed the role
################################
source .awsprofile
CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
if [[ $CURRENT_ROLE != $ROLE ]] ; then
    echo "ERROR: Failed to assume the role: ${ROLE}"
    exit 1
fi    
log "Assumed role: ${ROLE}"

################################
#EMR Step
################################
#copy EMR script to s3
CLEANUP_S3_PATH $S3_LOCATION && S3_LOCATION=$S3_PATH_CLEANED

if [[ ! -z $KMS_KEY ]] ; then
    KMS_FLAG="aws:kms --sse-kms-key-id ${KMS_KEY}"
fi

if [[ ! -e $EMR_SCRIPT ]] ; then
    echo "Failed to prepare the emr deploy script"
    exit 1
fi

echo "Staging emr deploy script in s3 bucket"
chmod u+rx $EMR_SCRIPT
RUN_CMD "aws s3 cp ${EMR_SCRIPT} ${S3_LOCATION} --sse ${KMS_FLAG}"

#Check cluster id 
CLUSTER_ID=$(aws emr list-clusters --active --output text | grep ${CLUSTER_NAME} | awk '{print $2}' | uniq)

if [[ -z $CLUSTER_ID ]] ; then
    echo "Can't find cluster id"
    exit 1
fi
log "Using cluster id: ${CLUSTER_ID}"

#now prepare the step definition (will execute script on emr master node which will download files into respective directories)
#EMR_FILES variable should have source file and target location separated by ':' e.g <sourcefile>:<targetfolder>
for FILE in $EMR_FILES ; do 
    ARGS="${ARGS},\"${FILE}\""
done

ARGS=$(echo $ARGS | tr -d '\r' | tr -d '\n')

JAR="${p:customJar}" #this jar just executes a shell script
STEP_NAME=${p:request.id} #just need some unique name
STEPS="Type=CUSTOM_JAR,Name=\"${STEP_NAME}\",Jar=\"${JAR}\",ActionOnFailure=CONTINUE,Args=[\"${S3_LOCATION}${EMR_SCRIPT}\",\"${S3_LOCATION}\"${ARGS}] "

#Now execute steps on cluster
echo "aws emr add-steps --cluster-id ${CLUSTER_ID} --steps ${STEPS}"
STEP_IDS=$(aws emr add-steps --cluster-id $CLUSTER_ID --steps $STEPS)
    
if [[ $? -ne 0 ]]; then
  echo "ERROR: Failed to add emr steps"
  exit 1
fi

echo $STEP_IDS

################################
#validate all the steps went fine
################################
#parse json output
STEP_IDS=$(echo ${STEP_IDS/*[/} | cut -d ']' -f 1 | sed -e 's/"//g' -e 's/,//g')

#wait on all steps to be completed or failed
COUNT=$(echo $STEP_IDS | wc -w)
while true ; do
    COMPLETED=0
    FAILED=0

    log "-----------------------------------------------------"
    for STEP_ID in $STEP_IDS ; do
            STEP_STATUS=$(aws emr list-steps --cluster-id $CLUSTER_ID --step-ids $STEP_ID --query "Steps[].Status.State" --output text)
                
            log "${STEP_ID} : ${STEP_STATUS}"
                
            if [[ $STEP_STATUS == "COMPLETED" ]] ; then
                        COMPLETED=$((COMPLETED+1))
            elif [[ $STEP_STATUS == "FAILED" ]] ; then
                        FAILED=$((FAILED+1))
            fi
    done
    log "------------------------------------------------------"
    echo ""

    if [[ $((COMPLETED+FAILED)) -eq $COUNT ]] ; then
            echo "All steps are done processing"
            break
    fi

    sleep 5
done

#check if any failed
if [[ $FAILED -gt 0 ]] ; then
        echo "${FAILED} steps have failed"
        exit 1
fi

echo "Exiting successfully"