#!/bin/bash

################################
#Helper functions
################################
log () {
    MESSAGE=$1
    TS=$(TZ=":US/Eastern" date +%H:%M:%S)
    echo "${TS} - $MESSAGE"
}

#run a command with logging and error checking
RUN_CMD () {
    CMD=$1
    log "Running: ${CMD}"
    $CMD
    
    if [[ $? -ne 0 ]]; then
        echo "Failed while running: ${CMD}"
        exit 1
    fi
}

################################
#UCD Properties
################################
FUNCTIONS="${p:environment/lambdaFunctions}"
ROLE=${p:environment/awsRole}

################################
#Validate that we assumed the role
################################
source .awsprofile
CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
if [[ $CURRENT_ROLE != $ROLE ]] ; then
    echo "ERROR: Failed to assume the role: ${ROLE}"
    exit 1
fi    
log "Assumed role: ${ROLE}"

################################
#Invoke Functions
################################

log "Going to invoke functions"
for FUNCTION in FUNCTIONS ; do
    RUN_CMD "aws lambda invoke --function-name ${FUNCTION}"
done

log "Done invoking functions"
