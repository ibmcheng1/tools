#!/bin/bash
S3_LOCATION=$1

for ARG in $@ ; do 
if [[ $ARG == $S3_LOCATION ]] ; then
continue
fi

FILE=$(echo $ARG | cut -d ':' -f 1)
TARGET_PATH=$(echo $ARG | CUT -d ':' -f 2)

aws s3 cp ${S3_LOCATION}/${FILE} $TARGET_PATH

if [[ $? -ne 0 ]]; then
echo "ERROR: Failed download ${FILE} to ${TARGET_PATH}"
exit 1
fi

done

echo "All files staged succesfully"