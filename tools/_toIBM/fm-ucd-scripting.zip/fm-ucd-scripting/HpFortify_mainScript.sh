#!/bin/sh

if [ -f ../scriptResult.output ]; then
  echo "removing existing ../scriptResult.output file."
  rm ../scriptResult.output
else
  echo "../scriptResult.output file does not exist."
fi

touch ../scriptResult.output

if [ -f ../context.properties ]; then
  . ../context.properties
else
  echo "../context.properties file does not exist."
fi


WORKING_DIR=`pwd`
chmod a+x "${WORKING_DIR}"/*.sh

echo ======================================
echo mainScript.sh - version - 2019-06-27
echo mainScript.sh - $WORKING_DIR - numberOfComponents=$numberOfComponents
echo ======================================
echo WORKING_DIR="$WORKING_DIR"
ls -l ../context.properties

if [ -z ${applicationAppCode+x} ]
then 
    echo "applicationAppCode is unset indictaes no need to scan. exit 0"
    exit 0
else 
    echo "continue after verifying applicationAppCode ..." 
fi

if [ -z ${numberOfComponents+x} ]
then 
    echo "numberOfComponentsis unset indictaes no need to scan. exit 0"
    exit 0
else 
    echo "continue after verifying is numberOfComponents unset..." 
fi

if (( $numberOfComponents == 0 ))
then 
    echo "numberOfComponents = $numberOfComponents indictaes no need to scan. exit 0"
    exit 0
else 
    echo "continue after verifying if numberOfComponents == 0..." 
fi


echo "------------------"
echo "Parameters from execution context:"
echo "------------------"
echo applicationName=$applicationName
echo applicationAppCode=$applicationAppCode
echo applicationAssetId=$applicationAssetId
echo numberOfComponents=$numberOfComponents
echo STRING_SCAN_RESULT_PASSED=$STRING_SCAN_RESULT_PASSED
echo STRING_SCAN_RESULT_FAILED=$STRING_SCAN_RESULT_FAILED
echo "------------------"

declare -a commandArgsArray
declare -a componentNamesArray

for (( i=0; i<numberOfComponents; i++ )) do
   echo "---------------------"
   componentName="component_${i}_name"
   componentId="component_${i}_id"
   componentRepoURL="component_${i}_repoURL"
   componentJavaVersion="component_${i}_javaVersion"
   componentAppsecScanRequired="component_${i}_appsecScanRequired"
   componentCodeCommitHash="component_${i}_codeCommitHash"
   componentHpFortifySseName="component_${i}_hpFortifySseName"

   echo componentName=${!componentName}
   echo componentId=${!componentId}
   echo componentRepoURL=${!componentRepoURL}
   echo componentJavaVersion=${!componentJavaVersion}
   echo componentAppsecScanRequired=${!componentAppsecScanRequired}
   echo componentCodeCommitHash=${!componentCodeCommitHash}
   echo componentHpFortifySseName=${!componentHpFortifySseName}

   commandArgs="$applicationAppCode $applicationAssetId ${!componentRepoURL} ${!componentCodeCommitHash} ${!componentJavaVersion} ${!componentHpFortifySseName}"
   commandArgsArray[$i]=$commandArgs
   componentNamesArray[$i]=${!componentName}
   echo "---------------------"
done

echo "###############################"
echo "Running commands of ${FORTIFY_SCAN_SCRIPT_PATH}" 
echo "###############################"


declare -a commandResultsArray
overallExitStatus=0
COUNTER=0
for i in "${commandArgsArray[@]}"
do
    componentName=${componentNamesArray[$COUNTER]}
    echo  "Component: " $componentName " -> commandArgsArray[$COUNTER]: $i"
    #commandResultsArray[$COUNTER]=$($FORTIFY_SCAN_SCRIPT_PATH $i)
    
    echo Running command $FORTIFY_SCAN_SCRIPT_PATH $i
    $FORTIFY_SCAN_SCRIPT_PATH $i 2>&1
    retVal=$?
    echo retVal=$retVal       
    echo =================================
    echo "Verify command exit status code:"
    echo =================================
    if [ $retVal -eq 100 ]; then
        commandResultsArray[$COUNTER]="$STRING_SCAN_RESULT_FAILED - component[${componentName}] - $FORTIFY_SCAN_SCRIPT_PATH command failed.  exit code = $retVal"
        overallExitStatus=0
    elif [ $retVal -eq 0 ]; then
        commandResultsArray[$COUNTER]="$STRING_SCAN_RESULT_PASSED - component[${componentName}] - $FORTIFY_SCAN_SCRIPT_PATH command passed. exit code = $retVal"
        overallExitStatus=0
    else
        commandResultsArray[$COUNTER]="$STRING_SCAN_RESULT_FAILED - component[${componentName}] - $FORTIFY_SCAN_SCRIPT_PATH process failed.  exit code = $retVal"
        overallExitStatus=1
    fi
    
    echo "====================="
    let COUNTER=COUNTER+1
done

echo ======================================
echo Print out command results ...
echo ======================================

COUNTER=0
for i in "${commandResultsArray[@]}"
do
    componentName=${componentNamesArray[$COUNTER]}
    commandArg=${commandArgsArray[$COUNTER]}
    commandResult=$i

    echo "$componentName -> $commandArg"
    echo $commandResult

    SOURCE=$STRING_SCAN_RESULT_PASSED
    echo '--------------------------------------'    
    echo SOURCE = ${SOURCE}   
    
    if echo "$commandResult" | grep -q "$SOURCE"; then
      echo "matched  - ${componentName}=${SOURCE}"
      echo "${componentName}=${SOURCE}" >> ../scriptResult.output
    else
      echo "no match for ${SOURCE}";
    fi
      
    SOURCE=$STRING_SCAN_RESULT_FAILED
    echo '--------------------------------------'    
    echo SOURCE = ${SOURCE}  
    if echo "$commandResult" | grep -q "$SOURCE"; then
      echo "matched  - ${componentName}=${SOURCE}"
      echo "${componentName}=${SOURCE}" >> ../scriptResult.output
    else
      echo "no match for ${SOURCE}";
    fi
    
    echo "---------------------------"
    let COUNTER=COUNTER+1
done

echo ======================================
echo Done - overallExitStatus = $overallExitStatus 
echo ======================================

exit $overallExitStatus