pwd
ls -ltra
export HOME=${p:resource/work.dir}/${p:component.name}
export PATH=/usr/bin/pip:$PATH
export PYTHONPATH=/export/appl/ftxdply/tableau/landing/python/lib64/:/export/apps/citools/python/python-2.7.6/lib/python2.7/:/export/appl/ftxdply/tableau/landing/python/libs/

reports="${p:environment/includedReports}"

if [[ $reprots == "*" ]]; then
    echo "Publishing the datasource..."
    for file in *; do
        if [[ $file =~ ".tdsx" ]]
        then
            echo $file
            python /export/appl/ftxdply/tableau/landing/PUB-TABLEAU_2.py "$file" "${p:component/userName}" ""${p:component/password}"" "${p:environment/awsTableauUrl}" "${p:environment/tableauSiteName}" "${p:environment/tableauProjectName}" "${p:environment/tableauEnvName}" "${p:environment/dbName}" "${p:environment/schemas}" "${p:environment/dbUserId}" "${p:environment/dbServer}" "${p:environment/dbPassword}"
             if [[ $? -ne 0 ]]; then
                echo "Failed while running: Publishing the datasource"
                exit 1
    fi
        else 
            echo "skipping this file:$file as it's not .tdsx..."
        fi
    done
    echo "Publishing the workbook..."
    for file in *; do
        if [[ $file =~ ".twbx" ]]
        then
            echo $file
            python /export/appl/ftxdply/tableau/landing/PUB-TABLEAU_2.py "$file" "${p:component/userName}" ""${p:component/password}"" "${p:environment/awsTableauUrl}" "${p:environment/tableauSiteName}" "${p:environment/tableauProjectName}" "${p:environment/tableauEnvName}" "${p:environment/dbName}" "${p:environment/schemas}" "${p:environment/dbUserId}" "${p:environment/dbServer}" "${p:environment/dbPassword}"
             if [[ $? -ne 0 ]]; then
                echo "Failed while running: Publishing the workbook"
                exit 1
    fi
        else 
            echo "skipping this file:$file as it's not .twbx..."
        fi
    done
else 
    IFS=","
    for file in $reports
    do
        if [[ $file =~ ".tdsx" ]]
        then
            echo $file
            python /export/appl/ftxdply/tableau/landing/PUB-TABLEAU_2.py "$file" "${p:component/userName}" ""${p:component/password}"" "${p:environment/awsTableauUrl}" "${p:environment/tableauSiteName}" "${p:environment/tableauProjectName}" "${p:environment/tableauEnvName}" "${p:environment/dbName}" "${p:environment/schemas}" "${p:environment/dbUserId}" "${p:environment/dbServer}" "${p:environment/dbPassword}"
             if [[ $? -ne 0 ]]; then
                echo "Failed while running: Publishing the datasource"
                exit 1
    fi
        else 
            echo "skipping this file:$file as it's not .tdsx..."
        fi
    done
    echo "Publishing the workbook..."
    for file in *; do
        if [[ $file =~ ".twbx" ]]
        then
            echo $file
            python /export/appl/ftxdply/tableau/landing/PUB-TABLEAU_2.py "$file" "${p:component/userName}" ""${p:component/password}"" "${p:environment/awsTableauUrl}" "${p:environment/tableauSiteName}" "${p:environment/tableauProjectName}" "${p:environment/tableauEnvName}" "${p:environment/dbName}" "${p:environment/schemas}" "${p:environment/dbUserId}" "${p:environment/dbServer}" "${p:environment/dbPassword}"
             if [[ $? -ne 0 ]]; then
                echo "Failed while running: Publishing the workbook"
                exit 1
    fi
        else 
            echo "skipping this file:$file as it's not .twbx..."
        fi
    done
 fi