// Validate the CHANGE TICKET Details
// Get the dtmDetails as string and then convert to object tree
String dtmDetailsString = '''${p:Get DTM Details/dtmDetails}'''
Map dtmDetailsMap = new groovy.json.JsonSlurper().parseText(dtmDetailsString)

outProps.put("Change_Ticket_Number", dtmDetailsMap.dtmDetails.changeTicket)

println '------------------------------------------'
println 'Found changeTicket : ' +dtmDetailsMap.dtmDetails.changeTicket
println '------------------------------------------'

println '------------------------------------------'
println 'Found AssetId : ' + ${p:application/assetId}
println '------------------------------------------'