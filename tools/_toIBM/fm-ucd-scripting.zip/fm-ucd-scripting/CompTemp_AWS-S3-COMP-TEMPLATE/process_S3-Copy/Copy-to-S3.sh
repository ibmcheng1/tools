#!/bin/bash

################################
#UCD Properties
################################
SOURCE_FILE=${p:environment/fileNames}
S3_LOCATION=${p:environment/s3Location}
ROLE=${p:environment/awsRole}

################################
#Validate that we assumed the role
################################
source .awsprofile
CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
if [[ $CURRENT_ROLE != $ROLE ]] ; then
    echo "ERROR: Failed to assume the role: ${ROLE}"
    exit 1
fi    
echo "Assumed role: ${ROLE}"

################################
#Validate UCD input
################################
#check that the S3 location exists and is a directory
FILE_EXTENSION="\.(war|zip|jar|ear)$"
if  [[ $S3_LOCATION =~ $FILE_EXTENSION ]] ; then
    S3_LOCATION=$(dirname $S3_LOCATION) 
fi

TRAILING_SLASH="/$"
if [[ ! $S3_LOCATION =~ $TRAILING_SLASH ]] ; then
    S3_LOCATION=${S3_LOCATION}/
fi

echo "Verifying S3 location: ${S3_LOCATION}"
aws s3 ls $S3_LOCATION

if [[ $? -ne 0 ]]; then
  echo "ERROR: Can't find the S3 Location: ${S3_LOCATION}"
  exit 1
fi

################################
#copy to s3 location
################################
#first check the type of encryption
if [[ ! -z $KMS ]] ; then
    KMS_FLAG="aws:kms --sse-kms-key-id ${KMS}"
fi

#if specific files are specified then just copy those
if [[ -z $SOURCE_FILE ]] ; then
    for file in $SOURCE_FILE ; do 
        if [[ -d $SOURCE_FILE ]] ; then
            RECURSIVE="--recursive"
        fi
        
        echo "aws s3 cp ${SOURCE_FILE} ${S3_LOCATION} ${RECURSIVE} --sse ${KMS}"
        aws s3 cp $SOURCE_FILE $S3_LOCATION $RECURSIVE --sse $KMS
        
        if [[ $? -ne 0 ]]; then
            echo "ERROR: Failed to copy to ${S3_LOCATION}"
            exit 1
        fi
    done
#otherwise sync everthing in their component version
else
    echo "aws s3 sync --exclude=\".aws*\" . ${S3_LOCATION} --sse ${KMS_FLAG}"
    aws s3 sync --exclude=".aws*" . $S3_LOCATION --sse $KMS_FLAG
    
    if [[ $? -ne 0 ]]; then
        echo "ERROR: Failed to copy to ${S3_LOCATION}"
        exit 1
    fi
fi

echo "Finished copying to s3 location"