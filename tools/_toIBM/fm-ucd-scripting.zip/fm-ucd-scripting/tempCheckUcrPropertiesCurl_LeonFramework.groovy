import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger;
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.RestServerConnectionBuilder
import com.ibm.services.ucr.api.entity.scheduleddeployment.UcrScheduledDeployment
import com.ibm.services.ucr.api.entity.scheduleddeployment.UcrScheduledDeploymentMgr
import com.ibm.services.ucr.api.entity.taskexecution.UcrTaskExecution
import com.ibm.services.ucr.api.entity.taskexecution.UcrTaskExecutionMgr

/**
 * Groovy script class which has access to UCD API Services.
 */
class CheckUcrProperties extends ScriptWithUcdServicesHook {

	/**
	 * This is the script function that is executed.
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
		String restUrlFullPath="${p?:Get UCR Release Data/restUrlFullPath}"
		String curlCommandString="${p?:Get UCR Release Data/curlCommandString}"
		
		def proc = curlCommandString.execute();
		def outputStream = new StringBuffer();
		proc.waitForProcessOutput(outputStream, System.err)
		String curlResultJsonText = outputStream.toString()
				
		def slurper = new groovy.json.JsonSlurper()
		def processRequestJsonData = slurper.parseText(curlResultJsonText)
		List contextPropertiesList = processRequestJsonData.contextProperties
		println "ProcessRequest contextPropertiesList.size() = " + contextPropertiesList.size()
		
		String taskExecutionUrl = null
		contextPropertiesList.each { Map property ->
			if(property.name == 'link:View in IBM UrbanCode Release') {
				println "FOUND target property -> " + property
				taskExecutionUrl = property.value
			}
		}
		
		outProps.put("taskExecutionUrl", taskExecutionUrl)
		
		println '------------------------------------------'
		println "taskExecutionUrl = " + taskExecutionUrl
		println '------------------------------------------'			
	}
}