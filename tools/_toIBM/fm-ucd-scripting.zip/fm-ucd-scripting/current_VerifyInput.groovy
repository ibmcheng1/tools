import groovy.json.*

println 'Verify Input ...'

def DTMCreateJsonData = '''${p?:DTMCreateJsonData}'''

println 'DTMCreateJsonData = ' + DTMCreateJsonData

if(DTMCreateJsonData == null || DTMCreateJsonData == '') {
	throw new Exception ("Error: DTMCreateJsonData can not be null or empty.")
}


def slurper = new JsonSlurper()
def dtmJsonData = slurper.parseText(DTMCreateJsonData)
def customFields = dtmJsonData.dtmData
println 'dtmJsonData:    ' + dtmJsonData
println 'customFields:    ' + customFields

def changeTicket = null
if(customFields["Change Management Ticket #"] != null && customFields["Change Management Ticket #"] != '') {
	changeTicket = customFields["Change Management Ticket #"]
	println 'changeTicket from json:    ' + changeTicket
}

println '---------------------'
println 'changeTicket: ' +changeTicket
println '---------------------'

if(changeTicket == null || changeTicket == '') {
	throw new Exception ("Error: changeTicket can not be null or empty.")
}

outProps.put("changeTicket", changeTicket)
