String restUrlFullPath="${p?:Get UCR Release Data/restUrlFullPath}"
String curlCommandString="${p?:Get UCR Release Data/curlCommandString}"

//def url = 'curl -u g9ucdc:Roxie_4m https://ucdeploy-dev:8443/rest/deploy/applicationProcessRequest/16c43baa-1777-bc3b-a535-cc60f24593e4';
def proc = curlCommandString.execute();
def outputStream = new StringBuffer();
proc.waitForProcessOutput(outputStream, System.err)
String curlResultJsonText = outputStream.toString()

//outProps.put("curlResultJsonText", curlResultJsonText)
//println '------------------------------------------'
//println 'curlResultJsonText= ' + curlResultJsonText
//println '------------------------------------------'

def slurper = new groovy.json.JsonSlurper()
def processRequestJsonData = slurper.parseText(curlResultJsonText)
//println 'processRequestJsonData = ' + processRequestJsonData
List contextPropertiesList = processRequestJsonData.contextProperties
//println "ProcessRequest contextPropertiesList = " + contextPropertiesList
println "ProcessRequest contextPropertiesList.size() = " + contextPropertiesList.size()

String taskExecutionUrl = null
contextPropertiesList.each { Map property ->
	if(property.name == 'link:View in IBM UrbanCode Release') {
		println "FOUND target property -> " + property
		taskExecutionUrl = property.value
	}
}

outProps.put("taskExecutionUrl", taskExecutionUrl)

println '------------------------------------------'
println "taskExecutionUrl = " + taskExecutionUrl
println '------------------------------------------'