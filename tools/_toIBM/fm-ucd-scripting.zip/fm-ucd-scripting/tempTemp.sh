
which java
echo path is $PATH
echo "Step: Run mainScript.sh"
agentHost=$(hostname)
echo "UCD agent host is ${agentHost}"

numberOfComponents=${p:Create UCD Context File/numberOfComponents}
echo -----------------
echo numberOfComponents = $numberOfComponents
echo -----------------

if (( $numberOfComponents == 0 ))
then 
    echo "UCD Step: numberOfComponents = $numberOfComponents indictaes no need to scan. exit 0"
    exit 0
else 
    echo "UCD Step: continue after verifying if numberOfComponents == 0..." 
fi


pwd
whoami

if [ ! -d "scriptPackage" ]; then
  echo "creating scriptPackage directory."
  mkdir scriptPackage
fi

if [ -f ./scriptPackage/mainScript.sh ]; then
  echo "removing existing mainScript.sh file."
  rm -f ./scriptPackage/mainScript.sh
else
  echo "./scriptPackage/mainScript.sh file does not exist."
fi

cp -r ${p:HP_FORTIFY_SCRIPT_PATH}/* ./scriptPackage

chmod a+x ./scriptPackage/*.sh

ls -l ./scriptPackage

ls -l context.properties
echo "-------------------"
cat context.properties
echo "-------------------"
cd scriptPackage
chmod a+x *.sh
pwd
which java 
echo path: $PATH
./mainScript.sh