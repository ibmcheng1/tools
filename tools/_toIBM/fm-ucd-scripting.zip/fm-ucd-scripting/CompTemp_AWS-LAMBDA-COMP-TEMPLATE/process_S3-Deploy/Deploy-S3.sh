#UCD Properties
SOURCE_FILE=${p:environment/fileNames}
S3_LOCATION=${p:environment/s3Location}
ROLE=${p:environment/awsRole}

################################
#Validate that we assumed the role
################################
source .awsprofile
CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
if [[ $CURRENT_ROLE != $ROLE ]] ; then
    echo "ERROR: Failed to assume the role: ${ROLE}"
    exit 1
fi    

################################
#Validate UCD input
################################
#if source file is undefined then get file name by listing current location
if [[ -z $SOURCE_FILE ]] ; then
    echo "The file name is not given in the environment properties, so checking to see if there is a single file at the current location to use."
    if [[ $(ls | wc -l) -eq 1 ]] ;  then
        SOURCE_FILE=$(ls)
        echo "found file: ${SOURCE_FILE}"
    else
        echo "Invalid number of files in component version. Please specify the source file in the environment property"
        ls -l
        exit 1
    fi
fi

#check that the S3 location exists
FILE_EXTENSION="\.(war|zip|jar)$"
if  [[ $S3_LOCATION =~ $FILE_EXTENSION ]] ; then
    #if s3 location points to file then only check parent directory exists since file may not be copied yet
    S3_PATH=$(dirname $S3_LOCATION) 
else
    S3_PATH=$S3_LOCATION
fi

echo "Verifying S3 location: ${S3_PATH}"
aws s3 ls $S3_PATH
if [[ $? -ne 0 ]]; then
  echo "ERROR: Can't find the S3 Location: ${S3_PATH}"
  exit 1
fi

################################
#copy to s3 location
################################
if [[ -d $SOURCE_FILE ]]; then
    echo "${SOURCE_FILE} is a directory - copying recursively"
    aws s3 cp $SOURCE_FILE $S3_LOCATION --recursive --sse 
   
else
    echo "copying ${SOURCE_FILE} to ${S3_LOCATION}"
    aws s3 cp $SOURCE_FILE $S3_LOCATION --sse 
fi

if [[ $? -ne 0 ]]; then
  echo "ERROR: Failed to copy to ${S3_LOCATION}"
  exit 1
fi

echo "Finished copying to s3 location"