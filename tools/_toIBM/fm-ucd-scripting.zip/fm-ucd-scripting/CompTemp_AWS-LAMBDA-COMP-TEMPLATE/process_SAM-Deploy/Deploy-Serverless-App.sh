#!/bin/bash

################################
#Helper functions
################################
log () {
    MESSAGE=$1
    TS=$(TZ=":US/Eastern" date +%H:%M:%S)
    echo "${TS} - $MESSAGE"
}

#run a command with logging and error checking
RUN_CMD () {
    CMD=$1
    log "Running: ${CMD}"
    $CMD
    
    if [[ $? -ne 0 ]]; then
        echo "Failed while running: ${CMD}"
        exit 1
    fi
}

############MAIN###################

################################
#Read in UCD properties
################################
PARAMETERS_FILE=${p:environment/parametersJson}
TEMPLATE_FILE=${p:environment/cloudformationTemplate}
ROLE=${p:environment/awsRole}
S3_LOCATION=${p:environment/s3Location}
KMS_KEY=${p:environment/kmsKey}
STACK_NAME=${p:environment/stackName}

################################
#Validate that we assumed the role
################################
source .awsprofile
CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
if [[ $CURRENT_ROLE != $ROLE ]] ; then
    echo "ERROR: Failed to assume the role: ${ROLE}"
    exit 1
fi
log "Assumed role: ${CURRENT_ROLE}"

################################
#Validate user input
################################
#Check given parameters json file exists and contains the correct image version
log "Checking that parameters json file exists"
if [[ ! -e $PARAMETERS_FILE ]] ; then
    echo "Can't find parameters json file"
    exit 1
fi
log "Found file: ${PARAMETERS_FILE}"

#check that cloudformation template file exists
log "Checking that the cloudformation template file exists"
if [[ ! -e $TEMPLATE_FILE ]] ; then
    echo "Can't find cloudformation template yaml file"
    exit 1
fi
log "Found file: ${TEMPLATE_FILE}"

#check that the S3 location exists
echo "Verifying S3 location: ${S3_LOCATION}"
aws s3 ls $S3_LOCATION
if [[ $? -ne 0 ]]; then
  echo "ERROR: Can't find the S3 Location: ${S3_LOCATION}"
  exit 1
fi

################################
#Run package step
################################
TEMPLATE=${p:componentProcess.defaultWorkDir}/${TEMPLATE_FILE}
PARAMETERS=${p:componentProcess.defaultWorkDir}/${PARAMETERS_FILE}
S3_BUCKET=$(echo $S3_LOCATION | cut -d '/' -f 3)
S3_PREFIX=$(echo $S3_LOCATION | cut -d ':' -f 2 | sed -e "s/\/\/${S3_BUCKET}\///")
NEW_TEMPLATE_FILE=new${TEMPLATE_FILE}

if [[ ! -z $KMS_KEY ]] ; then
    KMS_FLAG="--kms-key-id ${KMS_KEY}"
fi

#run cloudformation package 
RUN_CMD "aws cloudformation package --template-file ${TEMPLATE} --s3-bucket ${S3_BUCKET} --s3-prefix ${S3_PREFIX} --output-template-file ${NEW_TEMPLATE_FILE} $KMS_FLAG"

if [[ ! -e $NEW_TEMPLATE_FILE ]] ; then
    echo "Error creating new sam template during package step"
    exit 1
fi
log "Created new template during package step: ${NEW_TEMPLATE_FILE}"

################################
#Deploy stack 
################################
#make sure stack is ready to update
IN_PROGRESS="PROGRESS$"
while true ; do
    STACK_STATUS=$(aws cloudformation describe-stacks --stack-name $STACK_NAME --query "Stacks[].StackStatus" --output text 2>/dev/null)
    log "Status: $STACK_STATUS"
    
    if [[ ! $STACK_STATUS =~ $IN_PROGRESS ]] ; then
        log "Stack is ready to update"
        break
    fi
    
    TIME_OUT=$((TIME_OUT+1))
    if [[ $TIME_OUT -eq 360 ]] ; then
        echo "Timed out waiting on stack to be ready"
        exit 1
    fi
    
    sleep 5
done

#deploy the stack
NEW_TEMPLATE=${p:componentProcess.defaultWorkDir}/${NEW_TEMPLATE_FILE}
RUN_CMD "aws cloudformation deploy --template-file ${NEW_TEMPLATE} --stack-name ${STACK_NAME} --capabilities CAPABILITY_NAMED_IAM"

################################
#Wait on stack update to complete
################################
COMPLETED="COMPLETE$"
FAILED="FAILED$"
TIME_OUT=0

while true ; do 
    STACK_STATUS=$(aws cloudformation describe-stacks --stack-name $STACK_NAME --query "Stacks[].StackStatus" --output text)
    log "Status: ${STACK_STATUS}"
    
    if [[ $STACK_STATUS =~ $FAILED || $STACK_STATUS =~ $COMPLETED ]] ; then
        break
    fi
 
    TIME_OUT=$((TIME_OUT+1))
    if [[ $TIME_OUT -eq 360 ]] ; then
        echo "STACK update/creation is not completing or failing within an hour"
        exit 1
    fi
    
    sleep 10
done

if [[ $STACK_STATUS =~ $FAILED ]] ; then
    echo "Failed while deploying ${STACK_NAME}"
    exit 1
fi
log "Stack creation/update completed succesfully"

echo "Exiting successfully"