import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.application.Application;
import com.ibm.css.ucd.environment.Environment;
import com.ibm.css.ucd.resource.AgentOrAgentPoolResourceNode
import com.ibm.css.ucd.resource.AgentPoolResourceNode
import com.ibm.css.ucd.resource.AgentResourceNode;
import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook

/**
 * This script tests out resource tree code.
 * @author LeonClark
 *
 */
class DisplayAgentStatusForAppEnvironment extends ScriptWithUcdServicesHook {
	String statusMsg = ""	
	String[] envArray = ["PROD", "CNTG"]
	boolean[] envAgentCheckPassedArray = null
	String[] envStatusMsgArray = null	
	List envSkippedList = []
	
	boolean currentIsAgentCheckPassed = true;
	String currentStatusMsg = ""
	
	boolean overallFlag = true;
	
	/**
	 * This is the script function that is executed.
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
		// TODO: determine whether to allow users to override environments to check
		envAgentCheckPassedArray = new boolean[envArray.length]
		envStatusMsgArray = new String[envArray.length]
		
		for (int i=0; i<envArray.length; i++) {
			println ''
			println "checking environment[" +envArray[i]+ "] ..."
			findOfflineAgents( ucdConnectionServices, outProps, '${p:applicationName}', envArray[i], i)
		}
		
		postProcess(outProps)
	}
	
	public postProcess(Properties outProps) {
		for (int i=0; i<envAgentCheckPassedArray.length; i++) {
			if(envAgentCheckPassedArray[i] == false && !envSkippedList.contains(envArray[i])) {
				overallFlag = false
				
				statusMsg = statusMsg + "\nEnvironment name: " + envArray[i] + "\n"
				statusMsg = statusMsg + envStatusMsgArray[i]
			}
		}
		
		println ''
		println "overallFlag = " + overallFlag
		println ''
		
		if (overallFlag ==  false) {
			outProps.put("failureStatus", statusMsg )
			outProps.put("flag", "1")
		} else {
			outProps.put("flag", "0")
		}
	}
	
	
	public boolean findOfflineAgents(UcdConnectionServices ucdConnectionServices, Properties outProps, String applicationName, String environmentName, int envIndex) {
		boolean flag = true;
		
		// must reset the current tracking variable values
		currentIsAgentCheckPassed = true
		currentStatusMsg = ""

	    println ''
	    println '+++ findOfflineAgents applicationName=' + applicationName + ', environmentName='+environmentName
		Application ucdApplication = ucdConnectionServices.getApplicationServices().getApplication(applicationName)		
		Environment ucdEnvironment = null
		try {
			ucdEnvironment = ucdApplication.getEnvironment(environmentName)
		} catch (Exception e) {
			Logger.info "Exception message: " + e.getMessage()
			if(e.getMessage().indexOf("code 404 - Could not find an environment with name") > -1) {
				Logger.info "UCD environment[" +environmentName+ "] does not exist. "
				Logger.info "Skipping environment check on environment with name " + environmentName
				envSkippedList.add(environmentName)
				return
			} else {
				Logger.info "Unexpected error" 
				e.printStackTrace()
			}
		}
		
		// get the base resource(s) for the environment
		List baseResources = ucdEnvironment.getBaseResources()
		
		// Iterate each base resource
		int count = 0
		baseResources.each { ResourceNode baseResource ->
			println "baseResource[" +(count++)+ "] name: " + baseResource.getName()
			iterateTree(baseResource,outProps)
		}
		
		println "UCD environment[" +environmentName+ "]: currentIsAgentCheckPassed = " + currentIsAgentCheckPassed
		
		envAgentCheckPassedArray[envIndex] = currentIsAgentCheckPassed
		envStatusMsgArray[envIndex] = currentStatusMsg
		
		println '--- findOfflineAgents applicationName=' + applicationName + ', environmentName='+environmentName		
		return currentIsAgentCheckPassed
	}
	
	public boolean iterateTree( ResourceNode node, Properties outProps) {
		String msg;
		String indent = "    "
		if (node instanceof AgentOrAgentPoolResourceNode) {
			String nodeType = node.getNodeType()
			if(nodeType == "AgentNode") {
				nodeType = "Agent"
			} else if(nodeType == "AgentPoolNode") {
				nodeType = "Agent Pool"
			}
			
			if (node.isOnline()) {
				msg = nodeType + "["+node.name+"] - status: Online ,  resourcePath: " + node.resourcePath
			}  else if (node.isOffline()) {
				msg = nodeType + "["+node.name+"] - status: Offline ,  resourcePath: " + node.resourcePath
				currentStatusMsg = currentStatusMsg + msg + "\n"
				currentIsAgentCheckPassed = false
			} else {
				msg = nodeType + "["+node.name+"] - status: " + node.getStatus() + " ,  resourcePath: " + node.resourcePath + ".\n    Please email DevOps_Customer_Response for support."
				currentStatusMsg = currentStatusMsg + msg + "\n"
				currentIsAgentCheckPassed = false
			}			
			println indent + msg
		} 
				
		List children = node.getChildren()
		if (children.size() > 0) {
			children.each { ResourceNode child ->
				iterateTree(child,outProps)
			}
		}
	}
	
}
