import com.ibm.css.ucd.agent.Agent
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.css.ucd.resource.ResourceTree
import com.ibm.css.ucd.services.UcdConnectionServices;
import com.ibm.css.ucd.team.Team
import com.ibm.issr.core.log.Logger
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook
import com.ibm.issr.rest.RestServerConnection

/**
 * Groovy script class which has access to UCD API Services.
 */
class TestUser extends ScriptWithUcdServicesHook {

	/**
	 * This is the script function that is executed.
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
	
		// *** UCD EXAMPLE ***
		// This sample implementation defines a new Application Environment and links it to a new Resource Tree branch
		// for a newly provisioned UCD Agent.
		
		// Configuration options
		String userName = "${p:userName}"
		String userPassword = "${p:userPassword}"
		String id = "${p:ID}"
		String data = "${p:Data}"

		
		Logger.info "userName        = " + userName
		Logger.info "userPassword       = " + userPassword
		Logger.info "id         = " + id
		Logger.info "data       = " + data

		
		// Illustrate output properties by setting the ID of the new Environment
		outProps.put( "userName", userName)
		outProps.put( "userPassword", userPassword)
		outProps.put( "id", id)
		outProps.put( "data", data)

	}
}