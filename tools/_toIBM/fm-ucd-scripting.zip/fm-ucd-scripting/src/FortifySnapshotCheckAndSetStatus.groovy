import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.property.Property
import com.ibm.css.ucd.services.StatusServices
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.css.ucd.snapshot.Snapshot
import com.ibm.css.ucd.status.ComponentVersionStatus
import com.ibm.issr.core.log.Logger
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook
import com.ibm.css.ucd.status.ComponentVersionStatusInstance
import com.ibm.css.ucd.status.SnapshotStatus
import com.ibm.css.ucd.status.SnapshotStatusInstance
import java.io.File


/**
 * Groovy script class which has access to UCD API Services.
 *
 */
class FortifySnapshotCheckAndSetStatus extends ScriptWithUcdServicesHook {
		//**********************************************
		//  UCD Process PARAMETERS (Process properties)
		//**********************************************
		// Note: this will be used in generic process.
		String applicationId = "${p:applicationId}"
		String snapshotName = "${p:snapshotName}"
		String componentBasicPropertyKey_appsecScanRequired = "${p:componentBasicPropertyKey_appsecScanRequired}"
		String STATUS_passedStatusName = "${p:STATUS_passedStatusName}"
		
		/**
		 * This is the script function that is executed.
		 * @param ucdConnectionServices UCD API Services
		 */
		public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
				Logger.info "Application ID: " + applicationId
				Logger.info "Snapshot name: " + snapshotName
												
				// Get the application
				Application application = ucdConnectionServices.getApplicationServices().getApplicationById(applicationId)
				Logger.info "Found application ID " + application.id
				
				String applicationName = application.getName();

				// Get the snapshot
				Snapshot snapshot = application.getSnapshot(snapshotName)
				
				Logger.info "snapshot.id        = " + snapshot.id
				Logger.info "snapshotName       = " + snapshotName
								
				String messageSnapshot = "application["+applicationName+"].snapshot["+snapshotName+"]"
				
				StatusServices statusServices = ucdConnectionServices.getStatusServices()
								
				List componentVersions = snapshot.getComponentVersionObjects()
				
				  // if the expected snapshotStatus does not exist, exception will occur.
				ComponentVersionStatus componentVersionStatusPASSED = statusServices.getComponentVersionStatus(STATUS_passedStatusName);
				
				boolean isAllComponentRequiredSecScanPassed = true;
				int counter = 0
				componentVersions.each { ComponentVersion componentVersion ->
					String componentVersionName = ComponentVersion.getName();
					Component component = componentVersion.getComponent()
					String componentName = component.getName()
																									
					List componentBasicPropertiesList = component.getBasicProperties();
					Logger.info componentName + ": componentBasicPropertiesList = " + componentBasicPropertiesList
					
					String componentAppsecScanRequired = ""
					componentBasicPropertiesList.each { Property p ->
						String pName = p.getName();
						if(pName == componentBasicPropertyKey_appsecScanRequired) {
							componentAppsecScanRequired = p.getValue()
						}
					}
					Logger.info componentName + ": componentAppsecScanRequired = " + componentAppsecScanRequired
	
					
					//String componentAppsecScanRequired = ""
					if(componentAppsecScanRequired != null) {
						//componentAppsecScanRequired = componentPropertyAppsecScanRequired.getValue();
						if(componentAppsecScanRequired.equalsIgnoreCase("true")) {
							Logger.info componentName +": appsecScanRequired is TRUE."
							
							String messageComponent = messageSnapshot + ".component["+componentName+"].version["+componentVersionName+"]"
							ComponentVersionStatusInstance componentVersionStatusInstancePASSED = getComponentVersionStatusByName(componentVersion, STATUS_passedStatusName)
							Logger.info messageComponent + ": componentVersionStatusInstancePASSED = " + componentVersionStatusInstancePASSED
							if(componentVersionStatusInstancePASSED == null) {
								isAllComponentRequiredSecScanPassed = false
							}
							counter++
						} else {
							Logger.info componentName +": " + componentName + " - appsecScanRequired is FALSE. Skip this componet."
							// skip current component
						}
					} else {
						Logger.info componentName +": " + componentName + " - appsecScanRequired is not set. Skip this componet."
						// skip current component
					}
																						
				}
				
				Logger.info "isAllComponentRequiredSecScanPassed = " + isAllComponentRequiredSecScanPassed
				outProps.put("isAllComponentRequiredSecScanPassed", ""+isAllComponentRequiredSecScanPassed);
				
				if(isAllComponentRequiredSecScanPassed) {
					SnapshotStatusInstance snapshotStatusInstancePASSED = getSnapshotStatusByName(snapshot, STATUS_passedStatusName)
					Logger.info messageSnapshot + ": snapshotStatusInstancePASSED = " + snapshotStatusInstancePASSED
					if(snapshotStatusInstancePASSED != null) {
						Logger.info messageSnapshot + ": The snapshotStatusInstancePASSED exists, skip setting " + STATUS_passedStatusName
					} else {
						Logger.info messageSnapshot + ": The snapshotStatusInstancePASSED is null. proceed to Set " + STATUS_passedStatusName
												
						// if the expected snapshotStatus does not exist, exception will occur.
						SnapshotStatus snapshotStatusPASSED = statusServices.getSnapshotStatus(STATUS_passedStatusName);
						snapshot.addSnapshotStatus(snapshotStatusPASSED);
					}
				}
				
				verifySnapshotStatus(snapshot, isAllComponentRequiredSecScanPassed)
				
				outProps.put("fortifySnapshotCheckAndSetStatusResult", isAllComponentRequiredSecScanPassed.toString());
				
		}
		
		public static SnapshotStatusInstance getSnapshotStatusByName(Snapshot snapshot, String statusName) {
			SnapshotStatusInstance toReturn = null;
			List statusFlags = snapshot.getSnapshotStatuses();
			statusFlags.each { SnapshotStatusInstance status ->
				if (status.name == statusName) {
					Logger.info "getSnapshotStatusByName() -> snapshot status " + statusName + " FOUND for snapshot name: " + snapshot.getName()
					toReturn = status
				}
			}

			return toReturn;
		}
		
		
		public static ComponentVersionStatusInstance getComponentVersionStatusByName(ComponentVersion componentVersion, String statusName) {
			ComponentVersionStatusInstance toReturn = null;
			List statusFlags = componentVersion.getComponentVersionStatuses()
			statusFlags.each { ComponentVersionStatusInstance status ->
				if (status.name == statusName) {
					Logger.info "getComponentVersionStatusByName() -> Version status " + statusName + " FOUND for component version name: " + componentVersion.name + ", component version ID: " + componentVersion.id + ", from component named: " + componentVersion.component.name
					toReturn = status
				}
			}
				
			return toReturn;
		}
		
		public void verifySnapshotStatus(Snapshot snapshot, boolean isAllComponentRequiredSecScanPassed) {
			Logger.info "+++ verifySnapshotStatus(): snapshot = " + snapshot.getName() + ", isAllComponentRequiredSecScanPassed = " + isAllComponentRequiredSecScanPassed
			// verify all status
			Logger.info "verify the snapshot status ..."
			SnapshotStatusInstance snapshotStatusInstancePASSED = getSnapshotStatusByName(snapshot, STATUS_passedStatusName)
			String messageSnapshot = "snapshot["+snapshot.getName()+"]"
			Logger.info messageSnapshot + ": snapshotStatusInstancePASSED = " + snapshotStatusInstancePASSED

			List componentVersions = snapshot.getComponentVersionObjects()
			
			componentVersions.each { ComponentVersion componentVersion ->
				String componentVersionName = ComponentVersion.getName();
				Component component = componentVersion.getComponent()
				String componentName = component.getName()
																						
				List componentBasicPropertiesList = component.getBasicProperties();
				Logger.info componentName + ": componentBasicPropertiesList = " + componentBasicPropertiesList
				
				String componentAppsecScanRequired = ""
				componentBasicPropertiesList.each { Property p ->
					String pName = p.getName();
					if(pName == componentBasicPropertyKey_appsecScanRequired) {
						componentAppsecScanRequired = p.getValue()
					}
				}
				Logger.info componentName + ": componentAppsecScanRequired = " + componentAppsecScanRequired
				
				String componentAppsecScanRequiredString = componentBasicPropertyKey_appsecScanRequired + "=" + componentAppsecScanRequired
				String messageComponent = messageSnapshot + ".component["+componentName+"].version["+componentVersionName+"]: " + componentAppsecScanRequiredString
				
				ComponentVersionStatusInstance componentVersionStatusInstancePASSED = getComponentVersionStatusByName(componentVersion, STATUS_passedStatusName)
				Logger.info messageComponent + ", componentVersionStatusInstancePASSED = " + componentVersionStatusInstancePASSED
				
			}
			
			if(isAllComponentRequiredSecScanPassed && snapshotStatusInstancePASSED != null) {
				Logger.info "Overall SnapshotStatus Verification PASSED."
			} else {
				//if(snapshotStatusInstancePASSED != null) {
					//remove PASSED status from snapshot;
					//TBD: the following line does not actually remove snapshot status.
				
					//boolean hasRemoved = snapshot.getSnapshotStatuses().remove(snapshotStatusInstancePASSED)
					//Logger.info "hasRemoved = " + hasRemoved
				//}
				Logger.info "Overall SnapshotStatus Verification FAILED."
				throw new Exception ("Snapshot Status Verification Failed.")
			}
			
			
			Logger.info "--- verifySnapshotStatus()"
		}
				
}

