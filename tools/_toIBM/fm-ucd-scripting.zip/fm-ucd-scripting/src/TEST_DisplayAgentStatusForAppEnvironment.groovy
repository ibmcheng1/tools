import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.application.Application;
import com.ibm.css.ucd.environment.Environment;
import com.ibm.css.ucd.resource.AgentOrAgentPoolResourceNode
import com.ibm.css.ucd.resource.AgentPoolResourceNode
import com.ibm.css.ucd.resource.AgentResourceNode;
import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.css.ucd.services.UcdConnectionServices

class TEST_DisplayAgentStatusForAppEnvironment {
	
	public static void main( String[] args ) {
		// Get handle to UCD Server
		UcdServerConnection ucdServer = new UcdServerConnection()
		ucdServer.openConnection ("https://ucdeploy-dev:8443", "g9ucdc", "Roxie_4m")

		UcdConnectionServices services = new UcdConnectionServices(ucdServer)
		
		Properties outProps = new Properties()
		
		DisplayAgentStatusForAppEnvironment displayAgentStatusForAppEnvironment = new DisplayAgentStatusForAppEnvironment()
		//String[] envArray = displayAgentStatusForAppEnvironment.envArray
		//String[] envArray = ["PROD", "CNTG", "TBD-AGENT-FAILED-01", "TBD-AGENT-FAILED-02", "TBD-AGENTPOOL-PASSED-01", "TBD-AGENTPOOL-FAILED-02"]
		String[] envArray = ["PROD", "CNTG"]
		displayAgentStatusForAppEnvironment.envArray = envArray
		boolean[] envAgentCheckPassedArray = new boolean[envArray.length]
		String[] envStatusMsgArray = new String[envArray.length]
		
		displayAgentStatusForAppEnvironment.envAgentCheckPassedArray = envAgentCheckPassedArray
		displayAgentStatusForAppEnvironment.envStatusMsgArray = envStatusMsgArray
		
		for (int i=0; i<envArray.length; i++) {
			println ''
			println "checking environment[" +envArray[i]+ "] ..."
			displayAgentStatusForAppEnvironment.findOfflineAgents( services, outProps, "FZM", envArray[i], i )
		}
		
		displayAgentStatusForAppEnvironment.postProcess(outProps)
	
		println "------------------------------"
		println "envSkippedList: "
		println "------------------------------"
		List list = displayAgentStatusForAppEnvironment.envSkippedList
		list.each { String s ->
			println s
		}
		
		println "------------------------------"
		println "envAgentCheckPassedArray[]: "
		println "------------------------------"
		boolean[] array = displayAgentStatusForAppEnvironment.envAgentCheckPassedArray
		for (int i=0; i<array.length; i++) {
			if(!displayAgentStatusForAppEnvironment.envSkippedList.contains(envArray[i]))
			println envArray[i] + ": array[" +i+ "] = " + array[i]
		}

		println "------------------------------"
		println "outProps"
		println "------------------------------"
		outProps.each {
			println it
		}
		
	}
}