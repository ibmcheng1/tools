#!/bin/bash

################################
#Read in UCD Properties
################################
ROLE=${p:environment/awsRole}
S3_LOCATION=${p:environment/s3Location}
KMS=${p:environment/kms}

################################
#Validate that we assumed the role
################################
source .awsprofile
CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
if [[ $CURRENT_ROLE != $ROLE ]] ; then
    echo "ERROR: Failed to assume the role: ${ROLE}"
    exit 1
fi    
echo "Assumed role: ${CURRENT_ROLE}"

################################
#Validate UCD input
################################
#check that the S3 location exists and is a directory

echo "Verifying S3 location: ${S3_LOCATION}"
aws s3 ls $S3_LOCATION

if [[ $? -ne 0 ]]; then
  echo "ERROR: Can't find the S3 Location: ${S3_PATH}"
  exit 1
fi

aws cloudformation package --template-file $ --s3-bucket fnma-fn2cr6-devl-edl-us-east-1-742458541136-artifacts --output-template-file NewSamTemplate.yaml



#aws cloudformation package --template-file samTemplate.yaml --s3-bucket fnma-fn2cr6-devl-edl-us-east-1-742458541136-artifacts --output-template-file NewSamTemplate.yaml

aws cloudformation create-change-set --stack-name fn2cr6-devl-edl-cspiredshift-SAM-Stack  --change-set-name fn2cr6-devl-edl-cspiredshift-SAM-Change-Set --template-body file://NewSamTemplate.yaml --parameters file:///var/tmp/test.json --capabilities CAPABILITY_NAMED_IAM --role-arn arn:aws:iam::742458541136:role/fn2cr6-devl-edl-cp-deploy


