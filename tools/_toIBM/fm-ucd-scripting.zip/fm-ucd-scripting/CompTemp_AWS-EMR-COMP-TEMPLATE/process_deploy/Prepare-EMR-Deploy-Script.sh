def script = '''${p:talendScript}'''
def scriptname = "emr_deploy.sh"
println "Preparing emr deploy script script:"
println "-------------------------------------------------------"
println script
println "-------------------------------------------------------"
def file = new File(scriptname)
file.write(script)
outProps.put("emrScript", scriptname)