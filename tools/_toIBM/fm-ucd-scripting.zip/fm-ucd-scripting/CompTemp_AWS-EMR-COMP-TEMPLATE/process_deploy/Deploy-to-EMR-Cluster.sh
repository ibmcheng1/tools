#!/bin/bash

################################
#Read in UCD Properties
################################
ROLE=${p:environment/awsRole}
S3_LOCATION=${p:environment/s3Location}
CLUSTER_NAME=${p:environment/clusterName}
KMS=${p:environment/kms}

################################
#Validate that we assumed the role
################################
source .awsprofile
CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
if [[ $CURRENT_ROLE != $ROLE ]] ; then
    echo "ERROR: Failed to assume the role: ${ROLE}"
    exit 1
fi    
echo "Assumed role: ${CURRENT_ROLE}"

################################
#Validate UCD input
################################
#check that the S3 location exists and is a directory
FILE_EXTENSION="\.(war|zip|jar)$"
if  [[ $S3_LOCATION =~ $FILE_EXTENSION ]] ; then
    S3_LOCATION=$(dirname $S3_LOCATION) 
fi

TRAILING_SLASH="/$"
if [[ ! $S3_LOCATION =~ $TRAILING_SLASH ]] ; then
    S3_LOCATION=${S3_LOCATION}/
fi

echo "Verifying S3 location: ${S3_LOCATION}"
aws s3 ls $S3_LOCATION

if [[ $? -ne 0 ]]; then
  echo "ERROR: Can't find the S3 Location: ${S3_LOCATION}"
  exit 1
fi

#Check cluster id 
CLUSTER_ID=$(aws emr list-clusters --active --output text | grep ${CLUSTER_NAME} | awk '{print $2}' | uniq)

if [[ -z $CLUSTER_ID ]] ; then
    echo "Can't find cluster id"
    exit 1
fi
echo "Using cluster id: ${CLUSTER_ID}"

################################
#stage files to copy to s3
################################
#go through all zip files and stage files
mkdir staging
STAGING_PATH=$(cd staging; pwd) #get full path
echo "STAGING PATH: ${STAGING_PATH}"

for zipfile in $(find process_mr -name "*.zip") ; do
    echo "found file: ${zipfile}"
    cp $zipfile $STAGING_PATH
done

if [[ $(ls $STAGING_PATH | wc -l) -eq 0 ]] ; then
    echo "No zip files found in artifact"
    exit 1
fi

################################
#copy zip files to s3 location
################################
#first check the type of encryption
if [[ ! -z $KMS ]] ; then
    KMS_FLAG="aws:kms --sse-kms-key-id ${KMS}"
fi

ls -ltr $STAGING_PATH
echo "Copying zip files to s3 location: ${S3_LOCATION}"
echo "aws s3 sync --exclude="*" --include=\"*.zip\" staging/ $S3_LOCATION --sse $KMS_FLAG"
aws s3 sync --exclude="*" --include="*.zip" staging/ $S3_LOCATION --sse $KMS_FLAG

if [[ $? -ne 0 ]]; then
  echo "ERROR: Failed to copy to ${S3_LOCATION}"
  exit 1
fi

################################
#stage emr script in s3 bucket
################################
SCRIPT=${p:Prepare EMR Deploy Script/emrScript}

if [[ ! -e $SCRIPT ]] ; then
    echo "Failed to prepare the emr deploy script"
    exit 1
fi

echo "Staging emr deploy script in s3 bucket"
chmod u+rx $SCRIPT
aws s3 cp $SCRIPT $S3_LOCATION --sse $KMS_FLAG

if [[ $? -ne 0 ]]; then
  echo "ERROR: Failed to copy the emr deploy script to ${S3_LOCATION}"
  exit 1
fi

################################
#run emr step to deploy to cluster
################################
#First create list of steps to add (each step will execute the script on the master node in unique working folder with the zip file passed in as argument)
echo "Adding steps to deploy to emr cluster"
JAR="${p:customJar}" #this jar just executes a shell script

for FILE in $(ls ${STAGING_PATH}) ; do
    STEP_NAME=${p:request.id}_${FILE}
    STEPS="${STEPS}Type=CUSTOM_JAR,Name=\"${STEP_NAME}\",Jar=\"${JAR}\",ActionOnFailure=CONTINUE,Args=[\"${S3_LOCATION}${SCRIPT}\",\"${S3_LOCATION}${FILE}\"] "
    echo "Going to deploy ${FILE}"
done

#Now execute steps on cluster
STEP_IDS=$(aws emr add-steps --cluster-id $CLUSTER_ID --steps $STEPS)
    
if [[ $? -ne 0 ]]; then
  echo "ERROR: Failed to add emr steps"
  exit 1
fi

echo $STEP_IDS

################################
#validate all the steps went
################################
#parse json output
STEP_IDS=$(echo ${STEP_IDS/*[/} | cut -d ']' -f 1 | sed -e 's/"//g' -e 's/,//g')

#wait on all steps to be completed or failed
COUNT=$(echo $STEP_IDS | wc -w)
while true ; do
    COMPLETED=0
    FAILED=0

    echo "-----------------------------------------------------"
    for STEP_ID in $STEP_IDS ; do
            STEP_STATUS=$(aws emr list-steps --cluster-id $CLUSTER_ID --step-ids $STEP_ID --query "Steps[].Status.State" --output text)
            ZIP_FILE=$(basename $(aws emr list-steps --cluster-id $CLUSTER_ID --step-ids $STEP_ID --query "Steps[].Config.Args[1]" --output text))
                
            echo "${STEP_ID} / ${ZIP_FILE} : ${STEP_STATUS}"
                
            if [[ $STEP_STATUS == "COMPLETED" ]] ; then
                        COMPLETED=$((COMPLETED+1))
            elif [[ $STEP_STATUS == "FAILED" ]] ; then
                        FAILED=$((FAILED+1))
            fi
    done
    echo "------------------------------------------------------"
    echo ""

    if [[ $((COMPLETED+FAILED)) -eq $COUNT ]] ; then
            echo "All steps are done processing"
            break
    fi

    sleep 5
done

#check if any failed
if [[ $FAILED -gt 0 ]] ; then
        echo "${FAILED} steps have failed"
        exit 1
fi

echo "All steps have gone successfully"