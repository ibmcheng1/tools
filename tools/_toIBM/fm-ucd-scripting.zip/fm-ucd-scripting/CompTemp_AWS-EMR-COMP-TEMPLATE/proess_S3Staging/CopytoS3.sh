#!/bin/bash

################################
#Read in UCD Properties
################################
ROLE=${p:environment/awsRole}
S3_LOCATION=${p:environment/s3Location}
CLUSTER_NAME=${p:environment/clusterName}
KMS=${p:environment/kms}
INCLUDED=${p:environment/S3include}
EXCLUDED=${p:environment/S3exclude}
################################
#Validate that we assumed the role
################################

source .awsprofile
CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
if [[ $CURRENT_ROLE != $ROLE ]] ; then
    echo "ERROR: Failed to assume the role: ${ROLE}"
    exit 1
fi    
echo "Assumed role: ${CURRENT_ROLE}"

################################
#Validate UCD input
################################
#check that the S3 location exists and is a directory

FILE_EXTENSION="\.(war|zip|jar)$"
if  [[ $S3_LOCATION =~ $FILE_EXTENSION ]] ; then
    S3_LOCATION=$(dirname $S3_LOCATION) 
fi

#add slash at end if needed
TRAILING_SLASH="/$"
if [[ ! $S3_LOCATION =~ $TRAILING_SLASH ]] ; then
    S3_LOCATION=${S3_LOCATION}/
fi

echo "Verifying S3 location: ${S3_PATH}"
aws s3 ls $S3_PATH

if [[ $? -ne 0 ]]; then
  echo "ERROR: Can't find the S3 Location: ${S3_PATH}"
  exit 1
fi

################################
#stage files to copy to s3
################################
#go through all zip files and stage files

cd unzipped

mkdir staging

STAGING_PATH=$(cd staging; pwd) #get full path
echo "STAGING PATH: ${STAGING_PATH}"

#copying all included files/directories
if [[ $INCLUDED ]]
then
    IFS=', ' read -a array <<< "$INCLUDED"; echo "${array[@]}"

    for element in "${array[@]}"
    do
        for i in $(find . -name "$element") ; do
            echo "copying: ${i}"
            cp -rf $i $STAGING_PATH
        done
    done
else
    echo "Nothing to copy to s3 exiting"
    exit 0
fi

#removing all excluded files/directories
if [[ $EXCLUDED ]]
then
    IFS=', ' read -a array <<< "$EXCLUDED"; echo "${array[@]}"
    for element in "${array[@]}"
    do
        for i in $(find $STAGING_PATH -name "$element") ; do
            echo "removing: ${i}"
            rm -rf $i
        done
    done
fi


if [[ $(ls $STAGING_PATH | wc -l) -eq 0 ]] ; then
    echo "staging empty nothing to copy"
    exit 1
fi


if [[ $KMS ]] ; then
    $KMS = "--sse aws:kms --sse-kms-key-id ${KMS}"
fi


aws s3 sync $KMS $STAGING_PATH $S3_LOCATION

