#!/bin/bash
echo "Working Directory: $(pwd)"

#download zip from s3 bucket onto EMR master node
echo "Downloading from s3"
aws s3 cp $1 .

if [[ $? -ne 0 ]] ; then
echo "Failed to copy from s3 location: ${1}"
exit 1
fi

ls -l

#unzip zip file
echo "Looking for zip file"
ZIPFILE=$(ls *.zip)

if [[ -z $ZIPFILE ]] ; then
echo "Can't find zip file"
exit 1
fi
echo "Found zip file: ${ZIPFILE}"

unzip -o $ZIPFILE
rm -f $ZIPFILE

#locate folder and script to execute
echo "Looking for script to execute"
jobname=$(ls | grep -i $(echo ${ZIPFILE/_*.zip/}) | grep -v $ZIPFILE)
script=$(find . -name ${jobname}_run.sh)

if [[ -z $script ]] ; then
echo "Can't find script to execute: ${script}"
exit 1
fi
echo "Found script: ${script}"

#chmod and execute the script
chmod u+rx $script
echo "Executing script: ${script}"
$script

if [[ $? -ne 0 ]] ; then
echo "Failed while executing script"
exit 1
fi