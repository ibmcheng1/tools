import groovy.json.*

def parentId       = "${p:requestId}"
def preProcess     = "preDeployValidation-GenProc"
//def preProcess     = "G01-preDeployValidation"
def postProcess    = "postDeployUpdates-GenProc" 

//get json for application proess
def resturl  = "\"${p:system/UCD_SERVER_URL}/rest/deploy/applicationProcessRequest/${parentId}\""
def curlOut = callCurl(resturl)
def json = new JsonSlurper().parseText(curlOut)

Boolean preProcessRan     = false  // this needs to flip to true
Boolean postProcessRan    = false  // this needs to stay false 
// println "DEBUG: App process:"
// println JsonOutput.prettyPrint(curlOut)

json.rootTrace.children.each { step ->
     //println "DEBUG: step: [$step]"
     def id      = step.childRequestId  // id is the object not the process
     def type    = step.type
     def display = step.displayName 
     println "checking ${display}"
     
      // inspect each of the application processes' child generic process that has already run 
     if (type.equals("runProcess") && id != null) {  
         //get generic process name and status
         def childResturl  =  "\"${p:system/UCD_SERVER_URL}/rest/process/request/${id}\""
         def childCurlOut = callCurl(childResturl)
         def childJson     = new JsonSlurper().parseText(childCurlOut)
         def processName   = childJson?.process?.name
         def processStatus = childJson?.result
         println "**************************************************************************"
         println "Found Generic Process [$processName] with status [$processStatus]"
         
         //if it is pre deploy then fail if it is not sucessful already
         if ( processName.equals(preProcess)) { 
               preProcessRan = true
            if (!processStatus.equals("SUCCEEDED") ) {
                println "Expecting [SUCCEEDED] but found [$processStatus]"
				println "ERROR: Pre-Deploy must be run successfully before any deployment processes"
                println "Please update your application process and try again"
				System.exit(1)
               }
	        }
	   
	   //if it is post deploy then fail if it has already run (since that means it is not at the end after components steps)
        if ( processName.equals(postProcess) ) {
            postProcessRan = true
            println "ERROR: Post-Deploy Step has run before the deployment" 
            println "Post-Deploy Update must be the last step in the application process"
            println "Please update your application process and try again"
			System.exit(1)
         }
         println "**************************************************************************"
       }//if runProcess
} //each step

// Pre-Process Validation never ran
if (!preProcessRan) {
        println "**************************************************************************"
        println "ERROR: Pre-Deploy Validation Step must be run before the deployment" 
        println "Please update your application process and try again"
		println "**************************************************************************"

		System.exit(1)
}
		
println "exiting succesfully"
System.exit(0)

//~~~~~~~~~~~~~~~~~~~~~~~~~~ DEBUG ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
//uncomment to print the app process tree
println "Parent Process Info:"
println JsonOutput.prettyPrint(curlOut)

//===========================================================================================
def callCurl(def url) {
    println "Running curl -s -k -u <adminUser> " + url
    
	def outputFileName = "output-${p:request.id}.txt"
    def cmd = "source ${p:system/tokenFile}; curl -s -k -u \$TOKEN " + url + " >> ${outputFileName}"
    def scriptFile = new File("script-${p:request.id}.sh")
    scriptFile.text = cmd;
    def proc = ["/bin/bash",scriptFile.absolutePath].execute()
    proc.waitForProcessOutput()
	def outputFile = new File(outputFileName)
	def output = outputFile.getText()
	outputFile.delete()
    scriptFile.delete()
    println output
    return output
}

//******************************************************************************

