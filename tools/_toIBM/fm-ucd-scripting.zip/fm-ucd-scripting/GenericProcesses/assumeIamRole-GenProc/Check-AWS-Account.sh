import groovy.json.*

//get cicd roles
def cicdRolesJson = '''${p:system/CICDRoles}'''
def cicdRoles = new JsonSlurper().parseText(cicdRolesJson)
def envTypesList = "${p:envType}"
def accountIdsList = "${p:accountId}"
def rolesList = "${p:role}"

def envTypes = envTypesList.split(" ")
def accountIds = accountIdsList.split(" ")
def roles = rolesList.split(" ")

if ((envTypes.size() != accountIds.size()) || (envTypes.size() != roles.size())) {
        println "account ids, env types, and roles all need to have the same amount"
        System.exit(1)
}

//validate account id and get cicd roles to use
def cicdRoleList
for (def i = 0; i < accountIds.size(); i++) {
    def accountId = accountIds[i]
    def envRoles = cicdRoles[envTypes[i]]
    
    println "Validating aws lifecycle: " + accountId
    if (envRoles.containsKey(accountId)) {
        def cicdRole = envRoles[accountId]
        println "role: ${cicdRole}"
        cicdRoleList = (cicdRoleList) ? cicdRoleList.concat(" ${cicdRole}") : cicdRole
    } else {
        println "The aws lifecycle ${accountId} is invalid for this environment"
        System.exit(1)
    }
}

println "adding roles: ${cicdRoleList}"
outProps.put("cicdRoles", cicdRoleList)