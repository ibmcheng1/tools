#Properties
CICD_ROLES="${p:Check AWS Account/cicdRoles}"
ROLES="${p:role}"
ACCOUNT_IDS="${p:accountId}"

export HOME=${p:home}
export PATH=/export/apps/citools/python/Python-3.5.3/usr/local/bin:$PATH
export http_proxy=http://zsproxy.fanniemae.com:9480
export https_proxy=http://zsproxy.fanniemae.com:9480
export no_proxy=sts.fanniemae.com
export MALLOC_CHECK_=1

IFS=' ' read -r -a ACCOUNT_IDS <<< "$ACCOUNT_IDS"
IFS=' ' read -r -a ROLES <<< "$ROLES"

################################
#Loop through all roles that we need to assume
################################
COUNT=0
for CICD_ROLE in $CICD_ROLES ; do
	ROLE=${ROLES[${COUNT}]}
	ACCOUNT_ID=${ACCOUNT_IDS[${COUNT}]}
	PROFILE=${p:request.id}_${COUNT}
	
	################################
	#have ucd user assume the cicd deploy role
	################################
	echo "using cicd role: ${CICD_ROLE}"
	python3 /export/apps/citools/python/Python-3.5.3/usr/local/bin/federate-UCD.py ftxdply $CICD_ROLE ${p:system/AWS_PASSWORD}
	export AWS_PROFILE=default
	
	################################
	#then create a profile for cp deploy role
	################################
	python3 /export/apps/citools/python/Python-3.5.3/usr/local/bin/switchRole.py arn:aws:iam::$ACCOUNT_ID:role/$ROLE $PROFILE $PROFILE

	if [[ -z $(grep $PROFILE $HOME/.aws/credentials) ]]; then
		echo "failed to create new profile for cp deploy role, so remain with default profile"
		echo $AWS_PROFILE
		PROFILE=default
		DEFAULT_PROFILE=default
	else
		export AWS_PROFILE=$PROFILE
	fi
	aws sts get-caller-identity
	
	CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
	if [[ $CURRENT_ROLE != $ROLE ]] ; then
		echo "ERROR: Failed to assume the role: ${ROLE}"
		exit 1
	fi

	echo "Assumed role: ${ROLE}"
	
	################################
	#Add this new profile to the list
	################################
	PROFILES="${PROFILES}switchprofile_${COUNT}=\"export AWS_PROFILE=${PROFILE}\"\n"
	
	COUNT=$((COUNT+1))
done

if [[ -z $DEFAULT_PROFILE ]] ; then
	DEFAULT_PROFILE=${p:request.id}_0
fi

################################
#create file for component process to source for the profile
################################
FILE=$HOME/.awsprofile
cat <<EOM >$FILE
export HOME=${p:home}
export PATH=/export/apps/citools/python/Python-3.5.3/usr/local/bin:$PATH
export http_proxy=http://zsproxy.fanniemae.com:9480
export https_proxy=http://zsproxy.fanniemae.com:9480
export no_proxy=sts.fanniemae.com
export MALLOC_CHECK_=1
export AWS_PROFILE=$DEFAULT_PROFILE
EOM

#append aliases for switching profiles
echo -ne $PROFILES >> $FILE