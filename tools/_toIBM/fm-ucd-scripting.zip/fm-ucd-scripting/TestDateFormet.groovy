import java.text.SimpleDateFormat
import java.util.Date

def releaseDeploymentDate = '02-18-2019 01:00:00 AM'

println 'releaseDeploymentDate: ' + releaseDeploymentDate

	if(releaseDeploymentDate == null) {
		println 'Error: The releaseDeploymentDate can not be null.'
		System.exit(1)
	} else if (releaseDeploymentDate == ''){
		println 'Error: The releaseDeploymentDate can not be empty.'
		System.exit(1)
	} else {		
		try {
			def oldDate = new Date().parse("MM-dd-yyyy", releaseDeploymentDate)
			println 'oldDate: ' + oldDate
			newDate = new SimpleDateFormat("yyyy-MM-dd").format(oldDate)
			println 'newDate: ' + newDate
			releaseDeploymentDate = newDate.toString()			
		} catch (Exception e) {
			println 'Error: The releaseDeploymentDate format is incorrect.'
			throw e
		}
	}

	println 're-formatted releaseDeploymentDate: ' + releaseDeploymentDate
	println '---------------------------------'

	