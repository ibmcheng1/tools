#!/bin/sh

restUrlFullPath="${p?:Get UCR Release Data/restUrlFullPath}"
curlCommandString="${p?:Get UCR Release Data/curlCommandString}"

echo $restUrlFullPath
echo $curlCommandString

output=`$curlCommandString`
echo $output