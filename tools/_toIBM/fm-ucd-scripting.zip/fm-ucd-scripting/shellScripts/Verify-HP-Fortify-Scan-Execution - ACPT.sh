#!/bin/bash
# Configure UCD Client
export DS_WEB_URL=${p:DS_WEB_URL}
export JAVA_HOME=${p:JAVA_HOME}
export DS_AUTH_TOKEN=${p:system/DS_AUTH_TOKEN}
export UDCLIENT=${p:AGENT_HOME}/opt/udclient/udclient 
mandatedEnvStatus="APPSEC_SCAN_PASSED"

echo $UDCLIENT getStatusList -application ${p:applicationName} -snapshot "${p:snapshotName}" 
statusOutput=`$UDCLIENT getStatusList -application ${p:applicationName} -snapshot "${p:snapshotName}"` 
rc=$?
if [[ $rc -ne 0 ]] ; then
  echo "ERROR: Not able to get Snapshot status information"
  echo $@
 exit 1
fi

# verify if 
if [[ "$statusOutput" =~ $mandatedEnvStatus ]] ; then
  echo "Success: HP Fortify Scan has already been performed on the snapshot"
else 
  echo "Failure: HP Fortify Scan must be completed for production deployment to continuea"
  exit 1
fi