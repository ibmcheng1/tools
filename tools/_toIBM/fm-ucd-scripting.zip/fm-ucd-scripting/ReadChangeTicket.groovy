import groovy.json.*

def json = '''${p:Get MyServices Change Record/changeDetails}'''

def slurper = new JsonSlurper()
def ticket = slurper.parseText(json)

println '---------------------'
println 'ticket: ' + ticket.number
println 'Desc:   ' + ticket.short_description
println 'State:  ' + ticket.state
println 'Approval:'+ ticket.approval

def changeTicket_start_date = null;
try {
	changeTicket_start_date = ticket.start_date
} catch (groovy.lang.MissingPropertyException e) {
	println 'Error: failed to get start_date from change ticket.'
	e.printStackTrace()
}

println "start_date:      " + changeTicket_start_date
println '---------------------'
outProps.put("changeTicket_start_date", changeTicket_start_date)