import groovy.json.*

println 'Verify Input ...'

def DTMCreateJsonData = '''${p?:DTMCreateJsonData}'''

println 'DTMCreateJsonData = ' + DTMCreateJsonData

if(DTMCreateJsonData == null || DTMCreateJsonData == '') {
	throw new Exception ("Error: DTMCreateJsonData can not be null or empty.")
}

def slurper = new JsonSlurper()
def customFields = slurper.parseText(DTMCreateJsonData)
println 'customFields:    ' + customFields

def changeTicket = null
if(customFields.customfield_10049 != null && customFields.customfield_10049 != '') {
	changeTicket = customFields.customfield_10049
	println 'changeTicket from json:    ' + changeTicket
}

println '---------------------'
println 'changeTicket: ' +changeTicket
println '---------------------'

if(changeTicket == null || changeTicket == '') {
	throw new Exception ("Error: changeTicket can not be null or empty.")
}

outProps.put("changeTicket", changeTicket)