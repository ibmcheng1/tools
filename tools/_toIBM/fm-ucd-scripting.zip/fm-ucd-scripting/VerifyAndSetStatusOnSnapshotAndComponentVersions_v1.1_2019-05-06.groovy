import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.property.Property
import com.ibm.css.ucd.services.StatusServices
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.css.ucd.snapshot.Snapshot
import com.ibm.css.ucd.status.ComponentVersionStatus
import com.ibm.issr.core.log.Logger
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook
import com.ibm.css.ucd.status.ComponentVersionStatusInstance
import com.ibm.css.ucd.status.SnapshotStatus
import com.ibm.css.ucd.status.SnapshotStatusInstance
import java.io.File


/**
 * Groovy script class which has access to UCD API Services.
 *
 */
class VerifyAndSetStatusOnSnapshotAndComponentVersions extends ScriptWithUcdServicesHook {
		String myVersion = '05-06-2019 v1.1'
		//**********************************************
		//  UCD Process PARAMETERS (Process properties)
		//**********************************************
		String applicationId = "${p:applicationId}"
		String snapshotName = "${p:snapshotName}"
		
		String appCode = "${p:appCode}"
		String assetId = "${p:assetId}"
				
		String componentBasicPropertyKey_appsecScanRequired = "${p:componentBasicPropertyKey_appsecScanRequired}"
				
		String STATUS_passedStatusName = "${p:STATUS_passedStatusName}"
		
		String SCRIPT_RESULT_FILE_NAME = "scriptResult.output"
		String STRING_SCAN_RESULT_PASSED = "APPSEC_SCAN_PASSED"
		def componetsPassedList = [];
		
		/**
		 * This is the script function that is executed.
		 * @param ucdConnectionServices UCD API Services
		 */
		public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
				Logger.info "myVersion: " + myVersion
				Logger.info "Application ID: " + applicationId
				Logger.info "Snapshot name: " + snapshotName
				Logger.info "appCode: " + appCode
				Logger.info "assetId: " + assetId
				
				Logger.info "componentBasicPropertyKey_appsecScanRequired: " + componentBasicPropertyKey_appsecScanRequired
												
				// Get the application
				Application application = ucdConnectionServices.getApplicationServices().getApplicationById(applicationId)
				Logger.info "Found application ID " + application.id
				
				String applicationName = application.getName();
				String applicationAppCode = appCode
				String applicationAssetId = assetId

				// Get the snapshot
				Snapshot snapshot = application.getSnapshot(snapshotName)
				
				Logger.info "applicationAppCode = " + applicationAppCode
				Logger.info "applicationAssetId = " + applicationAssetId
				Logger.info "snapshot.id        = " + snapshot.id
				Logger.info "snapshotName       = " + snapshotName
				
				outProps.put("applicationName", applicationName);
				outProps.put("applicationAppCode", applicationAppCode);
				outProps.put("applicationAssetId", applicationAssetId);
				outProps.put("snapshotName", snapshotName);
				
				processScriptResultFile();

				// Snapshot's component versions may be added or removed, means it is mutable, unless version is locked.
				// if the component versions changed, the PASSED status must be removed, so it can be re-scanned.
				// Assuming versons are locked.
				
				String messageSnapshot = "application["+applicationName+"].snapshot["+snapshotName+"]"
				
				StatusServices statusServices = ucdConnectionServices.getStatusServices()
								
				List componentVersions = snapshot.getComponentVersionObjects()
				
				  // if the expected snapshotStatus does not exist, exception will occur.
				ComponentVersionStatus componentVersionStatusPASSED = statusServices.getComponentVersionStatus(STATUS_passedStatusName);
				
				Logger.info "For each componentVersion ... "
				boolean isAllComponentRequiredSecScanPassed = true;
				int counter = 0
				componentVersions.each { ComponentVersion componentVersion ->
					String componentVersionName = ComponentVersion.getName();
					Component component = componentVersion.getComponent()
					String componentName = component.getName()
					
					List componentBasicPropertiesList = component.getBasicProperties();
					Logger.info componentName + ": componentBasicPropertiesList = " + componentBasicPropertiesList
					
					String componentAppsecScanRequired = ""
					componentBasicPropertiesList.each { Property p ->
						String pName = p.getName()
						if(pName == componentBasicPropertyKey_appsecScanRequired) {
							componentAppsecScanRequired = p.getValue()
						}
					}
					Logger.info componentName + ": componentAppsecScanRequired = " + componentAppsecScanRequired
				
					if(componentAppsecScanRequired != null) {
						if(componentAppsecScanRequired.equalsIgnoreCase("true")) {
							Logger.info componentName +": appsecScanRequired is TRUE."
							
							String messageComponent = messageSnapshot + ".component["+componentName+"].version["+componentVersionName+"]"
							ComponentVersionStatusInstance componentVersionStatusInstancePASSED = getComponentVersionStatusByName(componentVersion, STATUS_passedStatusName)
							Logger.info messageComponent + ": componentVersionStatusInstancePASSED = " + componentVersionStatusInstancePASSED
							if(componentVersionStatusInstancePASSED != null) {
								Logger.info messageComponent + ": The componentVersionStatusInstancePASSED exists, skip setting " + STATUS_passedStatusName
							} else {
								Logger.info messageComponent + ": The componentVersionStatusInstancePASSED is null. proceed to Set " + STATUS_passedStatusName
								
								// verify if this component version really passed scan.
								if(componetsPassedList.contains(componentName)) {
									Logger.info messageComponent + ": The component is in the SCANNED and PASSED list. Adding status[" + STATUS_passedStatusName + "]"
									componentVersion.addComponentVersionStatus(componentVersionStatusPASSED);
								} else {
									// this component appsecScanRequired=true, but it does not pass scan, the containing snapshot can not add PASSED status.
									Logger.info messageComponent + ": The component is NOT in the SCANNED and PASSED list. Do nothing."
									isAllComponentRequiredSecScanPassed = false
								}
							}
							
							counter++
						} else {
							Logger.info componentName +": " + componentName + " - appsecScanRequired is FALSE. Skip this componet."
							// skip current component
						}
					} else {
						Logger.info componentName +": " + componentName + " - appsecScanRequired is not set. Skip this componet."
						// skip current component
					}
																						
				}
				
				Logger.info "isAllComponentRequiredSecScanPassed = " + isAllComponentRequiredSecScanPassed
				outProps.put("isAllComponentRequiredSecScanPassed", ""+isAllComponentRequiredSecScanPassed);
				
				if(isAllComponentRequiredSecScanPassed) {
					SnapshotStatusInstance snapshotStatusInstancePASSED = getSnapshotStatusByName(snapshot, STATUS_passedStatusName)
					Logger.info messageSnapshot + ": snapshotStatusInstancePASSED = " + snapshotStatusInstancePASSED
					if(snapshotStatusInstancePASSED != null) {
						Logger.info messageSnapshot + ": The snapshotStatusInstancePASSED exists, skip setting " + STATUS_passedStatusName
					} else {
						Logger.info messageSnapshot + ": The snapshotStatusInstancePASSED is null. proceed to Set " + STATUS_passedStatusName
						
						// if the expected snapshotStatus does not exist, exception will occur.
						SnapshotStatus snapshotStatusPASSED = statusServices.getSnapshotStatus(STATUS_passedStatusName);
						snapshot.addSnapshotStatus(snapshotStatusPASSED);
					}
				}
				
				verifySnapshotStatus(snapshot, isAllComponentRequiredSecScanPassed)
		}
		
		public static SnapshotStatusInstance getSnapshotStatusByName(Snapshot snapshot, String statusName) {
			SnapshotStatusInstance toReturn = null;
			List statusFlags = snapshot.getSnapshotStatuses();
			statusFlags.each { SnapshotStatusInstance status ->
				if (status.name == statusName) {
					Logger.info "getSnapshotStatusByName() -> snapshot status " + statusName + " FOUND for snapshot name: " + snapshot.getName()
					toReturn = status
				}
			}

			return toReturn;
		}
		
		
		public static ComponentVersionStatusInstance getComponentVersionStatusByName(ComponentVersion componentVersion, String statusName) {
			ComponentVersionStatusInstance toReturn = null;
			List statusFlags = componentVersion.getComponentVersionStatuses()
			statusFlags.each { ComponentVersionStatusInstance status ->
				if (status.name == statusName) {
					Logger.info "getComponentVersionStatusByName() -> Version status " + statusName + " FOUND for component version name: " + componentVersion.name + ", component version ID: " + componentVersion.id + ", from component named: " + componentVersion.component.name
					toReturn = status
				}
			}
				
			return toReturn;
		}
		
		public void verifySnapshotStatus(Snapshot snapshot, boolean isAllComponentRequiredSecScanPassed) {
			Logger.info "+++ verifySnapshotStatus(): snapshot = " + snapshot.getName() + ", isAllComponentRequiredSecScanPassed = " + isAllComponentRequiredSecScanPassed
			// verify all status
			Logger.info "verify the snapshot status ..."
			SnapshotStatusInstance snapshotStatusInstancePASSED = getSnapshotStatusByName(snapshot, STATUS_passedStatusName)
			String messageSnapshot = "snapshot["+snapshot.getName()+"]"
			Logger.info messageSnapshot + ": snapshotStatusInstancePASSED = " + snapshotStatusInstancePASSED

			List componentVersions = snapshot.getComponentVersionObjects()
			
			componentVersions.each { ComponentVersion componentVersion ->
				String componentVersionName = ComponentVersion.getName();
				Component component = componentVersion.getComponent()
				String componentName = component.getName()
																			
				//Property componentPropertyAppsecScanRequired = null
				//try {
				//	componentPropertyAppsecScanRequired = component.getComponentProperty(componentPropertyKey_appsecScanRequired);
				//} catch (Exception e) {
				//}
				
				List componentBasicPropertiesList = component.getBasicProperties();
				Logger.info componentName + ": componentBasicPropertiesList = " + componentBasicPropertiesList
				
				String componentAppsecScanRequired = ""
				componentBasicPropertiesList.each { Property p ->
					String pName = p.getName()
					if(pName == componentBasicPropertyKey_appsecScanRequired) {
						componentAppsecScanRequired = p.getValue()
					}
				}
				Logger.info componentName + ": componentAppsecScanRequired = " + componentAppsecScanRequired

				
				
				//String componentAppsecScanRequiredValue = componentAppsecScanRequired
				//if(componentPropertyAppsecScanRequired != null) {
				//	componentAppsecScanRequiredValue = componentPropertyAppsecScanRequired.getValue();
				//}
				
				String componentAppsecScanRequiredString = componentBasicPropertyKey_appsecScanRequired + "=" + componentAppsecScanRequired
				String messageComponent = messageSnapshot + ".component["+componentName+"].version["+componentVersionName+"]: " + componentAppsecScanRequiredString
				
				ComponentVersionStatusInstance componentVersionStatusInstancePASSED = getComponentVersionStatusByName(componentVersion, STATUS_passedStatusName)
				Logger.info messageComponent + ", componentVersionStatusInstancePASSED = " + componentVersionStatusInstancePASSED
			}
			
			if(isAllComponentRequiredSecScanPassed && snapshotStatusInstancePASSED != null) {
				Logger.info "Overall SnapshotStatus Verification PASSED."
			} else {
				if(snapshotStatusInstancePASSED != null) {
					//remove PASSED status from snapshot
					boolean hasRemoved = snapshot.getSnapshotStatuses().remove(snapshotStatusInstancePASSED)
					Logger.info "hasRemoved = " + hasRemoved
				}
				Logger.info "Overall SnapshotStatus Verification FAILED."
				throw new Exception ("Snapshot Status Verification Failed.")
			}
			
			
			Logger.info "--- verifySnapshotStatus()"
		}
		
		public void processScriptResultFile() {
			Logger.info "+++ processScriptResultFile()"
			def file = new File(SCRIPT_RESULT_FILE_NAME)
			int counter = 0
			if(file.exists()){
				Logger.info "Script result file["+SCRIPT_RESULT_FILE_NAME+"] found. Path = " + file.absolutePath
				def lines = file.readLines()
				lines.each { String line ->
					Logger.info "line [" + counter + "]: " + line
					// e.g. JenkinsTest=SCAN_RESULT_PASSED
					// two string tokens in a line
					List stringsList = line.tokenize("=")
					String component = null
					String resultString = null
					stringsList.each { String s ->
						//Logger.info "    " + s
						if(component == null) {
							component = s
						} else {
							resultString = s
							if(STRING_SCAN_RESULT_PASSED.equalsIgnoreCase(resultString)) {
								componetsPassedList.add(component)
								component = null
								resultString = null;
							}
						}
					}
					counter++;
				}
			} else {
				Logger.info "file not found: " + file.getAbsolutePath()
			}
			
			Logger.info "componetsPassedList.size() = " + componetsPassedList.size()
			componetsPassedList.each { String s ->
				Logger.info "    " + s
				//  e.g. JenkinsTest
				//       LocalJenkinsTest
			}

			if(false) {
				String componetNameForTesting = "JenkinsTest"
				boolean isComponentPassed = componetsPassedList.contains(componetNameForTesting)
				Logger.info componetNameForTesting + " -> isComponentPassed = " + isComponentPassed
				
				componetNameForTesting = "LocalJenkinsTest"
				isComponentPassed = componetsPassedList.contains(componetNameForTesting)
				Logger.info componetNameForTesting + " -> isComponentPassed = " + isComponentPassed
				
				componetNameForTesting = "HelloWorld_FALSE"
				isComponentPassed = componetsPassedList.contains(componetNameForTesting)
				Logger.info componetNameForTesting + " -> isComponentPassed = " + isComponentPassed
			}

			Logger.info "--- processScriptResultFile()"
		}
		

		public static main( args ){
			def currentDir = new File('.')
			Logger.info currentDir.getAbsolutePath()
			VerifyAndSetStatusOnSnapshotAndComponentVersions instance = new VerifyAndSetStatusOnSnapshotAndComponentVersions();
			instance.processScriptResultFile()
		}
		
}

