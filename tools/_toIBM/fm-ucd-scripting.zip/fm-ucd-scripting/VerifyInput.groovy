import groovy.json.*

println 'Verify Input ...'

// temporary input
//def DTMCreateJsonData = '''
//	{"project":{"key":"ENTDTMDEV"},"customfield_10098":"iCart","customfield_10099":"Git (Bitbucket)","customfield_10088":"Yes","summary":"984e45bd-b7fd-4159-9a1c-ffd1501b86eb","customfield_10057":"Fzm demo","customfield_10049":"CHG12345","issuetype":{"name":"Build"},"customfield_10050":"12/9/2019","customfield_10076":"Scrum"}
//    '''
//def DTMCreateJsonData = '''
//    {"dtmData":{"project":{"key":"ENTDTMDEV"},"summary":"bf745c6a-e825-4191-b436-2ce1d36ce4cf","issuetype":{"name":"Agile Release"},"5. What DevOps Build and Deploy Tool will be used for this software release?":{"value":"UrbanCode"},"5.a What Version Control Tool (Code Repository) will be used for this software release?":{"value":"Git (Bitbucket)"},"1. Does this application contain source code created by or for Fannie Mae?":{"value":"Yes"},"Release Name":"cheng1 Release","Change Management Ticket #":"CHG0350332","Asset ID#":["MSR01617"]},"changeType":"Build"}
//    '''
//def DTMCreateJsonData = '''
//	{"project":{"key":"ENTDTMDEV"},"summary":"bf745c6a-e825-4191-b436-2ce1d36ce4cf","issuetype":{"name":"Agile Release"},"5. What DevOps Build and Deploy Tool will be used for this software release?":{"value":"UrbanCode"},"5.a What Version Control Tool (Code Repository) will be used for this software release?":{"value":"Git (Bitbucket)"},"1. Does this application contain source code created by or for Fannie Mae?":{"value":"Yes"},"Release Name":"cheng1 Release","Change Management Ticket #":"CHG0350332","Asset ID#":["MSR01617"],"Change Type":{"value":"Build"}}
//    '''
def DTMCreateJsonData = '''
	{"dtmData":{"project":{"key":"ENTDTMDEV"},"summary":"bf745c6a-e825-4191-b436-2ce1d36ce4cf","issuetype":{"name":"Agile Release"},"5. What DevOps Build and Deploy Tool will be used for this software release?":{"value":"UrbanCode"},"5.a What Version Control Tool (Code Repository) will be used for this software release?":{"value":"Git (Bitbucket)"},"1. Does this application contain source code created by or for Fannie Mae?":{"value":"Yes"},"Release Name":"cheng1 Release","Change Management Ticket #":"CHG0350332","Asset ID#":["MSR01617"],"Change Type":{"value":"Build"}}}
	'''

//def DTMCreateJsonData = '''${p?:DTMCreateJsonData}'''
println 'DTMCreateJsonData = ' + DTMCreateJsonData

///////////////////////////////////////////////////////////////////////////////

if(DTMCreateJsonData == null || DTMCreateJsonData == '') {
	throw new Exception ("Error: DTMCreateJsonData can not be null or empty.")
}


def slurper = new JsonSlurper()
def dtmJsonData = slurper.parseText(DTMCreateJsonData)
def customFields = dtmJsonData.dtmData
println 'dtmJsonData:    ' + dtmJsonData
println 'customFields:    ' + customFields

def changeTicket = null
if(customFields["Change Management Ticket #"] != null && customFields["Change Management Ticket #"] != '') {
	changeTicket = customFields["Change Management Ticket #"]
	println 'changeTicket from json:    ' + changeTicket
}

println '---------------------'
println 'changeTicket: ' +changeTicket
println '---------------------'

if(changeTicket == null || changeTicket == '') {
	throw new Exception ("Error: changeTicket can not be null or empty.")
}

outProps.put("changeTicket", changeTicket)