

// Get the dtmDetails as string and then convert to object tree
def errorStatusMsg =""

String dtmDetailsString = '''${p:Get DTM Details/dtmDetails}'''
Map dtmDetailsMap = new groovy.json.JsonSlurper().parseText(dtmDetailsString)

String UCDassetID = "${p:assetId}"
String UCDDTMId = "${p:dtmRecordId}"
String UCDChangeTkt =  "${p:changeTicket}"
String DTMChangeTkt  = dtmDetailsMap.dtmDetails.changeTicket 
String DTMChangeType = dtmDetailsMap.dtmDetails.changeType
String DTMType = dtmDetailsMap.dtmDetails.dtmType
String DTMStatus = dtmDetailsMap.dtmDetails.status
// def DTMPrimaryassetID
String CHGPrimaryassetID = ""
ArrayList validDTMChangeTypes = ["Enhance","Build","Retire"]
ArrayList DTMOtherassetIDs =  dtmDetailsMap.dtmDetails.otherAssets
ArrayList DTMPrimaryassetIDs = []
ArrayList CHGOtherassetIDs = [""]

if ( DTMType.equals("Agile Release")  || DTMType.equals("Waterfall Release") ) {

	DTMPrimaryassetIDs =  dtmDetailsMap.dtmDetails.AssetID
	println "DTM primary asset IDs : " + DTMPrimaryassetIDs
	//DTMPrimaryassetIDs.add(DTMPrimaryassetID)
}
else if ( DTMType.equals("Agile-PI Release")) {
	DTMPrimaryassetIDs.add(dtmDetailsMap.dtmDetails.AssetID)
}



String changeDetailsString = '''${p:Get Change Record/changeDetails}'''
Map changeDetailsMap = new groovy.json.JsonSlurper().parseText(changeDetailsString)
String CHGDTMId  = changeDetailsMap.u_jira_id
String CHGParent  = changeDetailsMap.parent

println "[INFO] User provided input.............."
println "[INFO] UCD assetID       : " + UCDassetID
println "[INFO] UCD Change ticket : " + UCDChangeTkt
println "[INFO] UCD DTM Id        : " + UCDDTMId
 
println "[INFO] Details from DTM Record..........."
println "[INFO] DTM Change ticket : " + DTMChangeTkt
println "[INFO] DTM Change Type   : " + DTMChangeType
println "[INFO] DTM Type          : " + DTMType
println "[INFO] DTM Status        : " + DTMStatus
DTMPrimaryassetIDs.each {
println "[INFO] DTM Primary AssetID : ${it}"
}
DTMOtherassetIDs.each {
println "[INFO] DTM Other AssetID   : ${it}"
}

println "[INFO] Details from SNOW................"
println "[INFO] DTM Id provided in the Change ticket : " + CHGDTMId
println "[INFO] Parent provided in the Change ticket : " + CHGParent

println "[INFO] Information inferred from DTM Record..........."
//(1) Check DTM change type is valid. Information purpose only.
if(validDTMChangeTypes.contains(DTMChangeType)){
	println "[INFO] DTM change type is : "+ DTMChangeType
} else {
	println "[INFO] DTM change type is "+ DTMChangeType + ". Ignoring DTM validations."
	System.exit(0)
}
//(2) Check DTM Id in Change ticket. Information purpose only.
if( (CHGDTMId == null) || (CHGDTMId.equals("")) ){
	println "[INFO] " + UCDChangeTkt + " does not have the  DTM Record ID"
}
else{
	if(UCDDTMId.equals(CHGDTMId)){
		println "[INFO] " + UCDDTMId + " provided by the user matches with " + CHGDTMId + " provided in the change ticket"
	} else {
		println "[INFO] " + UCDDTMId + " provided by the user DONT match with " + CHGDTMId + " provided in the change ticket"
	}
}

println "[INFO] Starting DTM validations..........."
//(3) Check if DTM change ticket matches with user provided change ticket
if( (DTMChangeTkt==null)  ||  (DTMChangeTkt.equals("")) ){
	def errorMsg = "[FAIL] Missing change ticket " + DTMChangeTkt + " in DTM Record ID " + UCDDTMId + "\n"
	println errorMsg
	errorStatusMsg = errorStatusMsg + errorMsg
	
	
}
if(DTMChangeTkt.equals(UCDChangeTkt)) {
	println "[PASS] Change ticket in DTM " + DTMChangeTkt+ " is matching with user provided Change Ticket " + UCDChangeTkt
} else if(DTMChangeTkt.equals(CHGParent)) {
	println "[INFO] User provided change ticket is " + UCDChangeTkt +" and the parent change ticket is "+ CHGParent
	println "[PASS] Change ticket in DTM " + DTMChangeTkt+ " is matching with parent Change Ticket " + CHGParent
} else {
	println "[INFO] User provided change ticket : " + UCDChangeTkt
	println "[INFO] Parent change ticket        : " + CHGParent
	println "[INFO] Change ticket in DTM        : " + DTMChangeTkt
	def errorMsg = "[FAIL] Change ticket or its parent are not associated with DTM Record." +"\n"
	println errorMsg
	errorStatusMsg = errorStatusMsg + errorMsg
	
}




//(4) Check if impacted applicaiton/asset is part of DTM
if ( DTMPrimaryassetIDs.contains(UCDassetID) || DTMOtherassetIDs.contains(UCDassetID) )
{
	println "[PASS] Application Asset matches with the Application Asset provided in the DTM"
}
else{
	def errorMsg =  "[FAIL] Application Asset " + UCDassetID + " DOES NOT MATCH with the Assets [" + DTMPrimaryassetIDs + "," + DTMOtherassetIDs + "] provided in the DTM" +"\n"
	println errorMsg
	errorStatusMsg = errorStatusMsg + errorMsg
}

//(5) Check DTM status
if ( DTMType.equalsIgnoreCase("Agile Release")  || DTMType.equalsIgnoreCase("Waterfall Release") ) {
	 if(DTMStatus.equalsIgnoreCase("Deliverable Update") || DTMStatus.equalsIgnoreCase("On Hold") ) {
		println "[PASS] DTM status is valid"
	}
	else{
		def errorMsg =  "[FAIL] DTM status is NOT valid. Valid states are Deliverable Update and On Hold." +"\n"
		println errorMsg
		errorStatusMsg = errorStatusMsg + errorMsg
	}
}else if ( DTMType.equalsIgnoreCase("Agile-PI Release")) {
	String parentStatus  = dtmDetailsMap.dtmDetails.parentStatus
	String parentDTMType = dtmDetailsMap.dtmDetails.parentDtmType
	println "[INFO] Agile-PI DTM Record status : " + parentStatus
	println "[INFO] Agile-PI DTM Record type   : " + parentDTMType
	if(   ( DTMStatus.equalsIgnoreCase("RELEASE INPROGRESS") || DTMStatus.equalsIgnoreCase("RELEASE ONHOLD") )
	   &&  ( parentDTMType.equalsIgnoreCase("Agile Program Increment(PI)") )
	   && ( parentStatus.equalsIgnoreCase("DELIVERABLE UPDATE") || parentStatus.equalsIgnoreCase("ON HOLD") )
	  ){
		 println "[PASS] DTM status is valid"
	  }else{
		def errorMsg1 =  "[FAIL] DTM status is NOT valid."
		def errorMsg2 = " Valid states for DTM are RELEASE INPROGRESS and RELEASE ONHOLD."
		def errorMsg3 = " Valid states for Agile Program Increment(PI) are DELIVERABLE UPDATE and ON HOLD."
		def errorMsg4 = " For more details, refer to the DTM at ${p:system/DTM_URL}/browse/${p:dtmRecordId}"
		
		println errorMsg1
		println errorMsg2
		println errorMsg3
		println errorMsg4

		def errorMsg = errorMsg1 + errorMsg2 + errorMsg3 + errorMsg4

		println errorMsg
		errorStatusMsg = errorStatusMsg + errorMsg

		

	}
}
outProps.put("failureStatus", errorStatusMsg )
if(errorStatusMsg)
	System.exit(1)
