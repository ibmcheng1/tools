import com.fanniemae.ucr.releasedata.ReleaseData
import com.fanniemae.ucr.releasedata.ReleaseDataMgr
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger;
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook
import com.ibm.issr.rest.RestServerConnection
import com.ibm.issr.rest.RestServerConnectionBuilder
import com.ibm.services.ucr.api.entity.application.UcrApplication
import com.ibm.services.ucr.api.entity.change.UcrChange
import com.ibm.services.ucr.api.entity.changetype.UcrChangeType
import com.ibm.services.ucr.api.entity.initiative.UcrInitiative
import com.ibm.services.ucr.api.entity.integrationprovider.UcrPluginIntegrationProvider
import com.ibm.services.ucr.api.entity.integrationprovider.UcrPluginIntegrationProviderMgr
import com.ibm.services.ucr.api.entity.release.UcrRelease
import com.ibm.services.ucr.api.entity.release.UcrReleaseMgr

/**
 * Groovy script class which has access to UCD API Services.
 */
class GenerateUcrReleaseDatafile extends ScriptWithUcdServicesHook {

	/**
	 * This is the script function that is executed.
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
		// Parameters
		String ucrServerUrl = "${p:ucrServerUrl}"
		String ucrToken = "${p:ucrToken}"
		String ucrReleaseName = "${p:ucrReleaseName}"
		String jsonDataFilename = "${p:jsonDataFilename}"
		
		Map reportData = generateData(ucrServerUrl, ucrToken, ucrReleaseName)
		
		// Write JSON output
		new File(jsonDataFilename).text = groovy.json.JsonOutput.toJson( reportData )
		
		outProps.put( "dtm", reportData.release.dtm )
		outProps.put( "hasDtm", reportData.release.dtm?"true":"false" )
		outProps.put( "results", groovy.json.JsonOutput.toJson( reportData ) )
		
	}

	private Map generateData(String ucrServerUrl, String ucrToken, String ucrReleaseName) {
		Map reportData = [dateGenerated:new Date().toString()]

		RestServerConnection ucrServer = (new RestServerConnectionBuilder())
				.setServerUrl(ucrServerUrl)
				.setUrbancodeTokenAuthentication(ucrToken)
				.setTrustAllCerts()
				//				.setProxyInformation(ucrProxyHost, ucrProxyPort, ucrProxyUsername, ucrProxyPassword)
				.openConnection()

		UcrRelease release = UcrReleaseMgr.getInstance(ucrServer).getByName(ucrReleaseName)
		reportData.release = [:]
		reportData.release.name = ucrReleaseName
		reportData.release.id = release.id
		
		// Process related DTM (if there  is one)
		ReleaseData releaseData = ReleaseDataMgr.getInstance(ucrServer).getForRelease(release)
		reportData.release.dtm = releaseData.getDtmNumber()

		// Process UCR Applications in the Release
		reportData.release.applications = []
		release.getApplications().each { UcrApplication application ->
			Map applicationData = [ name:application.name, id:application.name ]
			reportData.release.applications << applicationData
		}

		// Process UCR Changes in the Release
		reportData.release.changes = []
		release.getChanges().each { UcrChange change ->
			Map changeData = [name:change.name, id:change.id]
			UcrApplication application = change.getApplication()
			if (application) {
				changeData.application = [name:application.name,id:application.id]
			}
			UcrChangeType changeType = change.getChangeType()
			if (changeType) {
				changeData.changeTypeName = changeType.name
				changeData.changeType = [name:changeType.name, id:changeType.id]
			} else {
				changeData.changeTypeName = ''
			}
			UcrInitiative initiative = change.getInitiative()
			if (initiative) {
				changeData.initiative =[ name:initiative.name, id:initiative.id ]
			}
			changeData.severity = change.getSeverity()
			changeData.status = change.getStatus()
			changeData.externalId = change.getExternalId()
			changeData.externalUrl = change.getExternalUrl()
			reportData.release.changes << changeData
		}
		return reportData
	}
	
	static void main( String[] args ) {
		Logger.setLoggingLevel("debug")
		Map results = new GenerateUcrReleaseDatafile().generateData("https://ucrelease-dev:8443", "6400cb10-e357-496e-acc0-f3da2ebcb33b", "Fzm demo")
		println groovy.json.JsonOutput.toJson( results )
		println results.toString()
	}
}