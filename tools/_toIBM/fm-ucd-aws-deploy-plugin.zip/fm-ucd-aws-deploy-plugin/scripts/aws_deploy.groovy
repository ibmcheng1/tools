import com.urbancode.air.AirPluginTool

import com.fanniemae.aws.api.connection.*
import com.fanniemae.ucd.aws.deploy.AwsDeployer

import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.plugin.AbortPluginException

final def airPluginTool = new AirPluginTool(args[0], args[1])
final def props = airPluginTool.getStepProperties()

println "#######################"
println "+++ aws.deploy.groovy"
println "#######################"

//def targetEnvironmentName = props['targetEnvironmentName']
//println "targetEnvironmentName = ${targetEnvironmentName}"
//println "===================================="
//def ucdComponentConfigProperties = props['ucdComponentConfigProperties']
//println "ucdComponentConfigProperties = "
//println "-------------------------------"
//println "${ucdComponentConfigProperties}"
//println "===================================="
//def ucdDeploymentTemplateJson = props['ucdDeploymentTemplateJson']
//println "ucdDeploymentTemplateJson = ${ucdDeploymentTemplateJson}"
//println "===================================="

try {
	String failFastModeString = System.getProperty("failFastMode")
	
	if(failFastModeString != null) {
		println "SystemProperty: failFastMode = " + failFastModeString
		if(failFastModeString == "false") {
			AwsDeployer.failFastMode = false
			println "SystemProperty - AwsDeployer.failFastMode = " + AwsDeployer.failFastMode
		}
	} else if(props['failFastMode'] != null && props['failFastMode'] == "false") {
		AwsDeployer.failFastMode = false
		println "User configured - AwsDeployer.failFastMode = " + AwsDeployer.failFastMode
	}
	
	AwsDeployer awsDeployer = new AwsDeployer()
	awsDeployer.deploy(props['targetEnvironmentName'], props['ucdComponentConfigProperties'], props['ucdDeploymentTemplateJson'])
}
catch (Throwable e) {
	e.printStackTrace()
	println ""
	println e.getMessage()
	println ""
	System.exit(1)
}

