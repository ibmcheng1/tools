import com.fanniemae.ucd.aws.deploy.test.TestRunner

//run the tests
TestRunner testRunner = new TestRunner()
def status = testRunner.runTests()

if (status == "failed") {
	System.exit(1)
}

