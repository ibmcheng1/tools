#!/bin/bash

echo "---------------------"
echo "Info: testScript02.sh - run ls -l ."
echo "---------------------"
arguments=$*
echo "arguments = ${arguments}"

ls -l .

exit 0