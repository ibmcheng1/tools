#!/bin/bash

echo "---------------------"
echo "Info: testScript01.sh - date"
echo "---------------------"

arguments=$*
echo "arguments = ${arguments}"

date

exit 0