#!/bin/bash

export HOME=/tmp/g9ucdc
export PATH=/export/appl/ftxdply/installs/aws-cli-tools:/export/apps/citools/python/Python-3.7.4/bin:/export/apps/citools/python/Python-3.7.4/bin:/usr/bin:/bin:/usr/sbin:/export/appl/uxprod/bin:/usr/SYSADM/bin:/export/appl/ftxdply/ucd-test/agent/opt/udclient

python3.7 /export/apps/citools/python/Python-3.7.4/bin/federate.py