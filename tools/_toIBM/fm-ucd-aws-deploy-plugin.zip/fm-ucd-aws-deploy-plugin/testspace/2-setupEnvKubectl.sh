#!/bin/bash

source .awsprofile
aws sts get-caller-identity
aws eks update-kubeconfig --name fvq-sdbx-sf-devops-ekscluster01

####################
# edit .kube/config
# Note, it appears it does not need to edit .kube/config file.  this is new.
###################
# apiVersion: v1
# clusters:
# - cluster:
#    server: https://fvq-sdbx-sf-devops-ekscluster01.sdbx-sf.e003.fanniemae.com
#    insecure-skip-tls-verify: true
####################

export PATH=/appl/ftxdply/installs/aws-cli-tools:$PATH

unset http_proxy
unset https_proxy
unset no_proxy

kubectl get svc
