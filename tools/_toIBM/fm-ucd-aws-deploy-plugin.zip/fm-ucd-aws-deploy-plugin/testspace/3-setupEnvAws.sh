#!/bin/bash

source .awsprofile
aws sts get-caller-identity

export PATH=/appl/ftxdply/installs/aws-cli-tools:$PATH