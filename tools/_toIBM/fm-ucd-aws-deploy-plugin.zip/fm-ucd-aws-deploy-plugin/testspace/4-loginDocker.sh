#!/bin/bash

echo "Authenticate docker client to ECR"

$(aws ecr get-login --no-include-email) 
