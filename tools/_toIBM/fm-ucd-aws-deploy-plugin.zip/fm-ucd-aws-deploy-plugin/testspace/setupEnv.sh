#!/bin/bash

if [[ ! -e .awsprofile ]] ; then
        echo "Missing .awsprofile"
        exit 1
fi
source .awsprofile
aws sts get-caller-identity

if [[ $? -ne 0 ]] ; then
        echo "Missing working aws token"
        exit 1
fi

export http_proxy=; export https_proxy=; export no_proxy=
export PATH=${PATH}:/appl/ftxdply/ucd-test/java/ibm-java-x86_64-80/jre/bin:/appl/ftxdply/ucd-test/agent/opt/groovy-2.4.15/bin
export JAVA_HOME=/appl/ftxdply/ucd-test/java/ibm-java-x86_64-80/jre
export GROOVY_HOME=/appl/ftxdply/ucd-test/agent/opt/groovy-2.4.15
export CLASS_PATH=${GROOVY_HOME}/lib/*:./target/test-classes:./target/classes:./lib/*
