#!/bin/bash

source .awsprofile

log () {
    MESSAGE=$1
    TS=$(TZ=":US/Eastern" date +%H:%M:%S)
    echo "${TS} - $MESSAGE"
}

PRINT_CF_EVENTS () {
    STACK_NAME=$1
    
    log "Events for the last 10 minutes:"
    PAST_TIME=$(TZ=":UTC" date '+%Y-%m-%dT%H:%M:%S' -d '10 minutes ago')
    aws cloudformation describe-stack-events --stack-name  ${STACK_NAME} --query "StackEvents[?Timestamp>='$PAST_TIME']"
}

MONITOR_STACK () {
	STACK_NAME=$1
echo "*****************************************************************"
    echo "Cloudformation stack creation/update cannot be stopped from UCD"
    echo "*****************************************************************"
    
    ################################
    #Wait on stack update to complete
    ################################
    COMPLETED="COMPLETE$"
    FAILED="FAILED$"
    ROLLBACK="ROLLBACK"
    TIME_OUT=0
    
    while true ; do 
        STACK_STATUS=$(aws cloudformation describe-stacks --stack-name $STACK_NAME --query "Stacks[].StackStatus" --output text)
        log "Status: ${STACK_STATUS}"
        
        if [[ $STACK_STATUS =~ $FAILED || $STACK_STATUS =~ $COMPLETED ]] ; then
            break
        fi
     
        TIME_OUT=$((TIME_OUT+1))
        if [[ $TIME_OUT -eq 360 ]] ; then
            echo "STACK update/creation is not completing or failing within an hour"
            exit 1
        fi
        
        sleep 10
    done
    
    if [[ $STACK_STATUS =~ $FAILED || $STACK_STATUS =~ $ROLLBACK ]] ; then
        echo "Failed while deploying ${STACK_NAME}"
        PRINT_CF_EVENTS $STACK_NAME
        exit 1
    fi
    
    log "Stack creation/update completed succesfully"
    PRINT_CF_EVENTS $STACK_NAME
}

MONITOR_STACK aabg2-ecs-fzm-ecs-fzm-certification-01
