Run the following command in the root directory of the plugin directory to build this plugin:

	mvn package -DskipTests
	
	
The generated plugin zip file is in target directory with the plugin root directory.
For example, fm-ucd-aws-deploy-plugin/target/fm-ucd-aws-deployment-plugin-0.0.1-SNAPSHOT.zip

If you want to test the plugin in UCD system during development, the good practice is to create your own plugin and test it.
You must temporarily build the plugin with your own identifiers in 3 attributes within plugin.xml:
	id   : "com.fanniemae.urbancode.air.plugin.awsdeploy.<YOUR_ID>"
	name : "FannieMae AWS Deployment-<YOUR_ID>"
	tag  :  FannieMae/AWS <YOUR_ID>

The following is an example (header section of plugin.xml) with YOUR_ID=g9ucdc
  <header>
    <identifier version="1" id="com.fanniemae.urbancode.air.plugin.awsdeploy.g9ucdc" name="FannieMae AWS Deployment-g9ucdc"/>
    <description>
      This plugin allows for the automation of AWS deployment with release pipeline.
    </description>
    <tag>FannieMae/AWS g9ucdc</tag>
  </header>
  
Important, DO NOT commit and push your temporary plugin.xml with <YOUR_ID> to repo.
 

