#!/bin/sh

mvn package -DskipTests
