#!/bin/bash

################################
#Helper functions
################################
log () {
    MESSAGE=$1
    TS=$(TZ=":US/Eastern" date +%H:%M:%S)
    echo "${TS} - $MESSAGE"
}

VALIDATE_ROLE () {
    ROLE=$1
    
    source .awsprofile
    CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
    if [[ $CURRENT_ROLE != $ROLE ]] ; then
        echo "ERROR: Failed to assume the role: ${ROLE}"
        exit 1
    fi    
    log "Assumed role: ${ROLE}"
}

############MAIN###################

if [[ "${p:CF-Validate-Parameters/ecs.deploy}" == "false" ]] ; then
    echo "Skipping ECS step"
    exit 0
fi

################################
#Read in UCD properties
################################
#ROLE=${p:environment/iam.awsRole}
#CLUSTER_NAME=${p?:getParameters/ClusterName}
#SERVICE_NAME=${p?:getParameters/ServiceName}
#CONTAINER_IMAGE=${p?:getParameters/ContainerImage}
#IMAGES_FILE=${p:getParameters/containerImagesFile}

log "-----------------------"
log "ECS Verify ..."
log "-----------------------"

#cat ucd-comp-env-profile.properties

#log "-----------------------"

source ucd-comp-env-profile.properties
CLUSTER_NAME=$CF_CLUSTER_NAME

log "-----------------------"
log "currentDirectory: ${currentDirectory}"
log "ROLE: ${ROLE}"
log "CLUSTER_NAME: ${CLUSTER_NAME}" 
log "SERVICE_NAME: ${SERVICE_NAME}"
log "IMAGES_FILE: ${IMAGES_FILE}"
log "-----------------------"

################################
#Validate that we assumed the role
################################
VALIDATE_ROLE $ROLE

#############################
#Make sure ECS service exists
#############################
log "Checking ECS resources were created/updated"
SERVICE_CHECK=$(aws ecs describe-services --cluster $CLUSTER_NAME --services $SERVICE_NAME --query "services[].status" --output text)

if [[ $SERVICE_CHECK != "ACTIVE" ]] ; then
    echo "Can't find service: ${SERVICE_NAME}"
    exit 1
fi
log "Found ECS service ${SERVICE_NAME}"

#Get the new task definition
TASK_DEFINITION=$(aws ecs describe-services --cluster $CLUSTER_NAME --services $SERVICE_NAME --query "services[].taskDefinition" --output text)

if [[ -z $TASK_DEFINITION ]] ; then
    echo "Can't find any task definition for service ${SERVICE_NAME}"
    exit 1
fi
log "Found task definition: ${TASK_DEFINITION}"

log "Checking that container images are in the task definition"
while read line; do
    CONTAINER_IMAGE=$(echo $line | cut -d ',' -f 2)
    log "Verifying container image: ${CONTAINER_IMAGE}"
    
    CURRENT_IMAGE=$(aws ecs describe-task-definition --task-definition $TASK_DEFINITION \
                    --query "taskDefinition.containerDefinitions[].image" \
                    --output text | grep $CONTAINER_IMAGE)

    if [[ -z $CURRENT_IMAGE ]] ; then
        echo "Failed to verify the container image in the task definition"
        ERRORS="${ERRORS}Failed to verify ${CONTAINER_IMAGE}\n"
    fi
done < $IMAGES_FILE

if [[ ! -z $ERRORS ]] ; then
    echo "Container image verification failed with the following errors:"
    echo -ne "${ERRORS}"
    exit 1
fi

log "Verified that the ECS service has been created/updated successfully"