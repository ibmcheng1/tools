#!/bin/bash

################################
#helper functions
################################
log () {
    MESSAGE=$1
    TS=$(TZ=":US/Eastern" date +%H:%M:%S)
    echo "${TS} - $MESSAGE"
}

#checks that a given role is assumed
CHECK_ROLE_ASSUMED () {
    ROLE=$1
    CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
    if [[ $CURRENT_ROLE != $ROLE ]] ; then
        echo "ERROR: Failed to assume the role: ${ROLE}"
        exit 1
    fi
    
    log "Assumed role: ${ROLE}"
}

#checks that given image exists in ECR
CHECK_IMAGE_EXISTS () {
    log "Checking that the image exists in ECR"
    IMAGE=$1
    IMAGE_TAG=$(echo $IMAGE | cut -d ':' -f 2)
    ECR_URL=$(echo $IMAGE | cut -d '/' -f 1)
    ECR_REPO=$(echo ${IMAGE/$ECR_URL\//} | cut -d : -f 1)
    
    log "IMAGE: ${IMAGE}"
    log "aws ecr describe-images --repository-name $ECR_REPO --query \"imageDetails[].imageTags\" --output text | grep $IMAGE_TAG"
    ECR_CHECK=$(aws ecr describe-images --repository-name $ECR_REPO --query "imageDetails[].imageTags" --output text | grep $IMAGE_TAG 2>/dev/null)
    
    if [[ -z $ECR_CHECK ]] ; then
            echo "Can't find image ${IMAGE_TAG} in ${ECR_URL}/${ECR_REPO}"
            
            if [[ -z $2 ]] ; then
                exit 1
            else
                IMAGE_CHECK=MISSING
            fi
    else 
        log "Found image ${IMAGE_TAG} in ${ECR_URL}/${ECR_REPO}"
        IMAGE_CHECK=EXISTS
    fi
}

#run a command with logging and error checking
RUN_CMD () {
    CMD=$1
    log "Running: ${CMD}"
    $CMD
    
    if [[ $? -ne 0 ]]; then
        echo "Failed while running: ${CMD}"
        exit 1
    fi
}

#Get the right Twistlock url based on enviornment 
GET_TWISTLOCK_URL () {
        CMD="echo '${TWISTLOCK_URLS}' | /export/apps/citools/jq-linux64  -r '.${ENV_TYPE}[0]'"
        echo $CMD > tmpScript.sh
        chmod 755 tmpScript.sh
        URL=$(./tmpScript.sh)
        echo $URL
}

#Get the version of twistlock defender for environment
GET_TWISTLOCK_DEFENDER () {
    CMD="echo '${TWISTLOCK_URLS}' | /export/apps/citools/jq-linux64  -r '.${ENV_TYPE}[2]'"
	echo $CMD > tmpScript.sh
	chmod 755 tmpScript.sh
	DEFENDER=$(./tmpScript.sh)
	rm -f tmpScript.sh
    
    if [[ $DEFENDER == "null" ]] ; then
        DEFENDER=${TW_DEFENDER_VERSION}
    fi
    
    echo $DEFENDER
}

#run twistlock build scan for checking the vulnerabilities
RUN_TWISTLOCK () {
    image=$1
    DEFENDER=$2
    log "Unsetting the proxy because we don't need proxy to connect to the twistlock console"
    export https_proxy=""
    export http_proxy=""
    export no_proxy=""
    FAIL_STATUS="Vulnerability threshold check results: FAIL"
    PASS_STATUS="Vulnerability threshold check results: PASS"
    log "Finding the right Twistlock console depending on environment"
    URL=$(GET_TWISTLOCK_URL)
    echo "Twistlock url: ${URL}"
    
    if [[ ${DEFENDER} == ${TW_DEFENDER_VERSION} ]]; then     
        #running scan using pre-existing twistcli in citools"
    	CMD="/export/apps/citools/twistcli images scan -u ${TWISTLOCK_DEV_USER} -p ${TWISTLOCK_DEV_PASS} --containerized --address $URL --vulnerability-threshold critical $image"
   	SCAN_STATUS=$($CMD)
    	if [[ $? -ne 0 ]]; then
        	echo "Failed while running: ${CMD}"
        	#exit 1
    	fi
    else
    	#version is different then default//download new twistcli from console
	CMD="curl -k -u ${TWISTLOCK_DEV_USER}:${TWISTLOCK_DEV_PASS} --output ./twistcli ${URL}/api/v1/util/twistcli" 
	INSTALL_TWIST=$($CMD)
	if [[ $? -ne 0 ]]; then 
	        echo "Failed while running: ${CMD}"
		#exit 1
	fi
	chmod 755 twistcli
    	CMD="./twistcli images scan -u ${TWISTLOCK_DEV_USER} -p ${TWISTLOCK_DEV_PASS} --containerized --address $URL --ci $image"
        SCAN_STATUS=$($CMD)
	        if [[ $? -ne 0 ]]; then
		        echo "Failed while running: ${CMD}"
			#exit 1
		fi
    fi
    
    echo "Scan Status: ${SCAN_STATUS}"
    if [[ $SCAN_STATUS =~ $FAIL_STATUS ]]; then
        echo "Scan FAILED. Critical vulnerabilities found."
        echo $SCAN_STATUS
    fi

    if [[ $SCAN_STATUS =~ $PASS_STATUS ]]; then
        echo "Scan Passed. No Critical vulnerabilities found."
        echo $SCAN_STATUS
    fi
    export https_proxy=http://zsproxy.fanniemae.com:9480
    export http_proxy=http://zsproxy.fanniemae.com:9480
    export no_proxy=sts.fanniemae.com
}

PULL_IMAGE () {
    SOURCE_ROLE=$1
    SOURCE_IMAGE=$2
    
    ################################
    #Validate source ECR info
    ################################
    #see if we can assume the prior environment role
    log "Switching to ${SOURCE_ROLE}"
    $switchprofile_1 #this can switch to any role which are ordered by index: switchprofile_<index>. In this case two roles: [0, 1]
    CHECK_ROLE_ASSUMED $SOURCE_ROLE
    
    #validate that the image exists in that ECR location
    log "Going to make sure the image exists in the lower env ECR"
    CHECK_IMAGE_EXISTS $SOURCE_IMAGE
    
    ################################
    #Pull image
    ################################
    log "Going to pull image from ${SOURCE_IMAGE}"
    
    #get login for docker
    log "Authenticate docker client to ${ECR_URL}"
    export PATH=/usr/lib/fnma_docker:$PATH
    $(aws ecr get-login --no-include-email|sed 's/docker/sudo \/bin\/docker/g') 
    if [[ $? -ne 0 ]]; then
        echo "Failed to authenticate with docker"
        exit 1
    fi
    
    #pull the image
    RUN_CMD "${DOCKER_COMMAND} pull ${SOURCE_IMAGE}"
    log "Finished running docker pull"
}

PULL_IMAGE_ARTIFACTORY () {
    SOURCE_IMAGE=$1
    
    ################################
    #validate artifactory path
    ################################
    #get full path: <artifactory system property> + / + <SOURCE_IMAGE>
    #check it exists (or else just check exit code of docker pull and run docker images)
    
    ################################
    #Pull image
    ################################
    log "Going to pull image from ${SOURCE_IMAGE}"
    
    #pull the image
    RUN_CMD "${DOCKER_COMMAND} pull ${SOURCE_IMAGE}"
    log "Finished running docker pull"
}

PUSH_IMAGE () {
    TARGET_ROLE=$1
    SOURCE_IMAGE=$2
    TARGET_IMAGE=$3
    LATEST=$4
    
    ################################
    #First check if this image is already promoted
    ################################
    #switch back to current env role and authenticate docker again
    $switchprofile_0
    CHECK_ROLE_ASSUMED $TARGET_ROLE
    
    log "Make sure image doesn't already exist in current ECR"
    CHECK_IMAGE_EXISTS $TARGET_IMAGE dont_fail
    
    if [[ $IMAGE_CHECK == "EXISTS" ]] ; then
        echo "${TARGET_IMAGE} already exists. No need to promote to ECR"
        return 0
    fi
    IMAGE_CHECK=""
    
    #tag the image
    log "Going to tag the image"
    REPO_PATH=$(echo $TARGET_IMAGE | cut -d ':' -f 1)
    
    if [[ $LATEST == "latest" ]] ; then
        RUN_CMD "${DOCKER_COMMAND} tag ${SOURCE_IMAGE} ${REPO_PATH}:latest"
    fi
    
    RUN_CMD "${DOCKER_COMMAND} tag ${SOURCE_IMAGE} ${TARGET_IMAGE}"
    
    ################################
    #Push image to ECR in current environment
    ################################
    log "Going to push image to ${TARGET_IMAGE}"
    log "Authenticate docker client to ${ECR_URL}"
    $(aws ecr get-login --no-include-email|sed 's/docker/sudo \/bin\/docker/g') 
    if [[ $? -ne 0 ]]; then
        echo "Failed to authenticate with docker"
        exit 1
    fi
    
    #push the image
    if [[ $LATEST == "latest" ]] ; then
        RUN_CMD "${DOCKER_COMMAND} push ${REPO_PATH}:latest"
    fi
    RUN_CMD "${DOCKER_COMMAND} push ${TARGET_IMAGE}"
    log "Finished running docker push"
    
    log "Checking that image has been pushed to ECR"
    CHECK_IMAGE_EXISTS $TARGET_IMAGE
    log "Succesfully promoted image to current ECR repo"
}

CHECK_DEFENDER_IMAGE () {
    ECR=$1
    DEFENDER_TAG=$2
    DEFENDER_IMAGE="${ECR}:${DEFENDER_TAG}"
    
    CHECK_IMAGE_EXISTS $DEFENDER_IMAGE dont_fail
    
    if [[ $IMAGE_CHECK != "MISSING" ]] ; then
        ECR_DEFENDER=$DEFENDER_IMAGE
        log "Found defender image: ${DEFENDER_IMAGE}"
    fi
}

LOAD_DEFENDER_IMAGE () {
    DEFENDER_TAG=$1
    TWISTLOCK_REPO=$2
    DEFENDER_IMAGE_FILE="/export/appl/ftxdply/defender/twistlock_${DEFENDER_TAG}.tar.gz"
    
    if [[ ! -e $DEFENDER_IMAGE_FILE ]] ; then
        HOST=$(hostname)
        echo "ERROR: Can't locate ${DEFENDER_IMAGE_FILE} on ${HOST}"
        exit 1
    fi
    
    log "load the defender image"
    RUN_CMD "${DOCKER_COMMAND} load -i ${DEFENDER_IMAGE_FILE}"
    
    IMAGE_CHECK=$(${DOCKER_COMMAND} images $TWISTLOCK_REPO | grep $DEFENDER_TAG)
    if [[ -z $IMAGE_CHECK ]] ; then
        echo "ERROR: Failed to load defender image with version ${DEFENDER_TAG} from ${DEFENDER_IMAGE_FILE}" 
        exit 1
    fi
}

PUSH_DEFENDER () {
    ECR=$1
    DEFENDER_TAG=$2
    TARGET_ROLE=$3
    TWISTLOCK_REPO="twistlock/private"
    TARGET_DEFENDER_IMAGE="${ECR}:${DEFENDER_TAG}"
    SOURCE_DEFENDER_IMAGE="${TWISTLOCK_REPO}:${DEFENDER_TAG}"
    
    IMAGE_CHECK=$(${DOCKER_COMMAND} images $TWISTLOCK_REPO | grep $DEFENDER_TAG)
    
    if [[ -z $IMAGE_CHECK ]] ; then
        #if we don't have the image, try loading it from tar file
        LOAD_DEFENDER_IMAGE $DEFENDER_TAG $TWISTLOCK_REPO
    fi
    log "Found ${SOURCE_DEFENDER_IMAGE}"
    
    log "Going to push ${TARGET_DEFENDER_IMAGE}"
    PUSH_IMAGE $TARGET_ROLE $SOURCE_DEFENDER_IMAGE $TARGET_DEFENDER_IMAGE
    ECR_DEFENDER=$TARGET_DEFENDER_IMAGE
}

############MAIN###################

#if [[ "${p:CF-Validate-Parameters/ecs.deploy}" == "false" ]] ; then
#    log "Skipping ECR step"
#    exit 0
#fi

################################
#Read in UCD Properties
################################
#IMAGES_FILE=${p:getParameters/containerImagesFile}
#SOURCE_ROLE=${p?:getParameters/priorEnvRole}
#TARGET_ROLE=${p:environment/iam.awsRole}
#ENV_TYPE=${p:environment/envType}
#APP_SHORT_NAME=${p:getParameters/ApplicationShortName}
#ARTIFACTORY=${p?:environment/app.artifactory}
#SHARED_ECR_REPOS="${p?:sharedEcrRepos}"

log "-----------------------"
log "Ecr Deploy ..."
log "-----------------------"

#cat ucd-comp-env-profile.properties

#log "-----------------------"

source ucd-comp-env-profile.properties
TARGET_ROLE=$ROLE

echo "------------------------"
export DOCKER_COMMAND="docker"
echo "default DOCKER_COMMAND = $DOCKER_COMMAND"
$DOCKER_COMMAND images &>/dev/null
rc=$?
echo rc=$rc
if [[ $rc -ne 0 ]] ; then
  echo "ERROR: (${DOCKER_COMMAND}): $rc"
  echo $@
  echo "change default DOCKER_COMMAND" 
  export DOCKER_COMMAND="sudo /bin/docker"
else
  echo "Continue to use default DOCKER_COMMAND (${DOCKER_COMMAND})"
fi

echo "Active DOCKER_COMMAND = $DOCKER_COMMAND"

log "-----------------------"
log "currentDirectory: ${currentDirectory}"
log "UCD_ENV_PROPERTIES_FILE_NAME: ${UCD_ENV_PROPERTIES_FILE_NAME}"
log "IMAGES_FILE = ${IMAGES_FILE}"
log "SOURCE_ROLE = ${SOURCE_ROLE}"
log "TARGET_ROLE = ${TARGET_ROLE}"
log "ENV_TYPE = ${ENV_TYPE}"
log "APP_SHORT_NAME = ${APP_SHORT_NAME}"
log "ARTIFACTORY = ${ARTIFACTORY}"
log "SHARED_ECR_REPOS = ${SHARED_ECR_REPOS}"
log "DOCKER_COMMAND = ${DOCKER_COMMAND}"
log "-----------------------"

################################
#Validate the images file
################################
if [[ ! -e $IMAGES_FILE ]] ; then
    echo "${IMAGES_FILE} wasn't created properly in getParameters step"
    exit 1
fi

if [[ $(wc -l < $IMAGES_FILE) -eq 0 ]] ; then
    echo "${IMAGES_FILE} is empty"
    exit 1
fi

################################
#push app container images
################################
DEFENDER_TAG=$(GET_TWISTLOCK_DEFENDER)

source .awsprofile
while read line; do
    SOURCE_IMAGE=$(echo $line | cut -d ',' -f 1)
    TARGET_IMAGE=$(echo $line | cut -d ',' -f 2)
    
    #skip for base images since they have their own pipeline where twistlock is run
    IS_SHARED_REPO="false"
    
    for SHARED_REPO in $SHARED_ECR_REPOS ; do
        if [[ $TARGET_IMAGE =~ $SHARED_REPO ]] ; then
            IS_SHARED_REPO="true"
        fi
    done
    
    if [[ $IS_SHARED_REPO == "true" ]] ; then
        continue #skip ecr push for shared services repos
    fi
    
    #always pull the image so we can run the twistlock scan
    if [[ $ARTIFACTORY == "true" ]] ; then
        PULL_IMAGE_ARTIFACTORY $SOURCE_IMAGE
    else
    
        if [[ $ENV_TYPE == "DEVL" ]] ; then
            SOURCE_ROLE=$TARGET_ROLE
        fi
        
        PULL_IMAGE $SOURCE_ROLE $SOURCE_IMAGE
    fi
    
    #run twistlock scan
    RUN_TWISTLOCK $SOURCE_IMAGE $DEFENDER_TAG
    
    #push image if we need to
    PUSH_IMAGE $TARGET_ROLE $SOURCE_IMAGE $TARGET_IMAGE latest
    
    #make sure the defender image exists in ecr
    CHECK_DEFENDER_IMAGE $(echo $TARGET_IMAGE | cut -d ':' -f 1) $DEFENDER_TAG
done < $IMAGES_FILE

################################
#check if we need to push the defender image
################################
if [[ -z $ECR_DEFENDER ]] ; then
    #if there isn't a defender in any of ecr repos then push to one repo that contains app short name
    ECR=$(grep $APP_SHORT_NAME $IMAGES_FILE | head -n 1 | cut -d ',' -f 2 | cut -d ':' -f 1)
    
    if [[ ! -z $ECR ]] ; then
        PUSH_DEFENDER $ECR $DEFENDER_TAG $TARGET_ROLE
    else 
        echo "couldn't find an ecr repo that contains application short name, so pick just pick one to push defender image to"
        ECR=$(head -n 1 $IMAGES_FILE | cut -d ',' -f 2 | cut -d ':' -f 1)
        PUSH_DEFENDER $ECR $DEFENDER_TAG $TARGET_ROLE
    fi
fi

#make sure defender image is listed in image file so we can use it in next steps
echo ",${ECR_DEFENDER}" >> $IMAGES_FILE
echo "Finished pushing all container images to ECR"
