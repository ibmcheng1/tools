#!/bin/bash

echo "---------------------"
echo "Glue deployment script is not completed in the plugin"
echo "---------------------"

exit 0