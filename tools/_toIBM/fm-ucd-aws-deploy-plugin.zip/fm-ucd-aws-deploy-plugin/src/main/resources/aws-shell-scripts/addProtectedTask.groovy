import groovy.json.*
import groovy.yaml.*

/**
 * extract fargate task from cf template
 * call twistlock api to get protected task
 * modify cf template to replace unprotected task with protected task
 */

println "======================"
println "addProtectedTask.groovy"
println "======================"

//UCD Properties
def propertiesStringFile = "ucd-comp-config-properties-string.txt"
def environmentProperties = loadProperties(propertiesStringFile)

def cfTemplateYamlFileName = environmentProperties["cf.cloudformationTemplate"]
def parametersJsonFileName = environmentProperties["cf.parametersJson"]
def imagesFile = environmentProperties["getParameters.containerImagesFile"]
def envType = environmentProperties["environment.envType"]
def twJsonString = environmentProperties["system.TWISTLOCK_URLS"]
def defaultDefender = environmentProperties["system.TW_DEFENDER_VERSION"]
def twUser = environmentProperties["system.TWISTLOCK_DEV_USER"]
def twPass = environmentProperties["system.TWISTLOCK_DEV_PASS"]
def requestId = environmentProperties["process.requestId"]

def defenderImageVersion = getDefenderVersion(twJsonString, envType, defaultDefender)

println "Validating input"

//Validate yaml file
def cfTemplateYamlFile = new File(cfTemplateYamlFileName)
if (!cfTemplateYamlFile.exists()) {
	println "Can't find cloudformation template file"
	System.exit(1)
}
println "Found file for cloudformation template"

println "Parsing yaml file"
def cfTemplate
try {
	cfTemplate = new YamlSlurper().parseText(cfTemplateYamlFile.getText().replaceAll("!", "-!"))
} catch (Throwable e) {
	println "Failed to parse yaml file"
	System.exit(1)
}
println "Parsed cloudformation yaml"

//validate json file
def parametersFile = new File(parametersJsonFileName)
if (!parametersFile.exists()) {
	println "Failed to locate ${parametersJsonFileName}"
	System.exit(1)
}
println "Found file for parameters json"

println "Parsing json file"
def parametersJson
try {
	parametersJson = new JsonSlurper().parseText(parametersFile.getText())
} catch(Throwable e) {
	println "Failed to parse parameters json file: " + parametersFile.name
	System.exit(1)
}
println "Parsed json parameters file"

def parameters = reformatParametersJson(parametersJson)

//make sure defender image exists in ecr
def defenderImage = checkDefenderImage(imagesFile, defenderImageVersion)

//extract unprotected task from cf template
def task = getNode(cfTemplate, "Resources").TaskDefinition.Properties

//generate protected task from that task
def protectedTask = getProtectedTask(task, defenderImage, parameters, twJsonString, twUser, twPass, envType, requestId)

//replace unprotected task with protected task in cf template
def updatedCfTemplate = updateCfTemplate(cfTemplate, protectedTask)

//write back to yaml file
def yamlBuilder = new YamlBuilder()
writeBackToFile(updatedCfTemplate, cfTemplateYamlFile, yamlBuilder)

//helper methods
//--------------------------------
def loadProperties(def fileName) {
	def propFile = new File(fileName)
	if (!propFile.exists()) {
		println "Failed to locate ucd environment properties file: " + fileName
		System.exit(1)
	}
	def propText = propFile.text
	propFile.delete()
	
	def props = parsePropertiesString(propText)
	return props
}

def parsePropertiesString(String s) {
	println "+++ parsePropertiesString():"
	
	s = cleanUpProps(s)
	
	final Properties p = new Properties()
	p.load(new StringReader(s))
	
	
	println "parsePropertiesString()"
	return p
}

def cleanUpProps(String props) {
	def lines = props.split("\n")
	String newString = ""
	Boolean insideMultiLineProp = false
	lines.each { line ->
		if (line.contains("<beginProp>")) {
			insideMultiLineProp=true
			line = line.replaceAll("<beginProp>", "")
		}
		
		if (line.contains("<endProp>")) {
			insideMultiLineProp = false
			line = line.replaceAll("<endProp>", "")
			//line = line + "\\n\\"
		}
		
		if (insideMultiLineProp) {
			line = line + "\\n\\"
		}
		
		newString = newString.concat(line + "\n")
	}
	
	return newString
}

def getDefenderVersion(def twJsonString, def envType, def defaultDefender) {
	//def twJsonString = '''${p:system/TWISTLOCK_URLS}'''
	//def envType = "${p:environment/envType}"
	def defender
	
	def twJson
	try {
		twJson = new JsonSlurper().parseText(twJsonString)   
	} catch(Throwable e) {
		println "Failed to parse parameters json: " + twJsonString
		System.exit(1)
	}
	
	def values = twJson[envType]
	if (values.size() == 3) {
		defender = values[2]
	}
	
	if (!defender) {
		defender = defaultDefender
	}
	
	println "Using defender tag: " + defender
	return defender
}

def reformatParametersJson(def parametersJson) {
	def updatedJson = [:]
	
	parametersJson.each { parameter ->
		def key = parameter.ParameterKey
		def value = parameter.ParameterValue
		updatedJson.put(key, value)
	}
	
	return updatedJson
}

def checkDefenderImage(def imagesFileName, def defenderImageVersion) {
	//get defender image from images file
	def defenderImage
	def imagesFile = new File(imagesFileName)
	if (!imagesFile.exists()) {
		println "Can't find " + imagesFileName
		System.exit(1)
	}
	
	imagesFile.readLines().each { line ->
		def image = line.split(",")[1]
		if (image.contains(defenderImageVersion)) {
			println "found defender image in ecr"
			defenderImage = image
			return
		}
	}
	
	if (!defenderImage) {
		println "ERROR: Failed to determine the defender image location in ecr"
		System.exit(1)
	}
	
	println "Using defender image: " + defenderImage
	return defenderImage
}

def getProtectedTask(def task, def defenderImage, def parameters, def twJsonString, def twUser, def twPass, def envType, def requestId) {
	//convert keys to camel case: true for converting to camel case, false for vice versa (first character capitalized or uncapitalized)
	task = convertFormat(task, true)
	
	//replace Ref functions for container name and image (twistlock will use these values in some encrypted strings)
	task = updateContainerDefinition(task, "replaceRefFunctions", "", parameters)
	
	//then make sure there is an entrypoint in any container definitions
	task = updateContainerDefinition(task, "addEntryPoint", "", "")
	
	//now we can call twistlock api to generate protected task
	def protectedTask = callTwistlockApi(task, twJsonString, twUser, twPass, envType, requestId)
	
	//update location for defender image to ecr repo in the sidecar containerDefinition
	protectedTask = updateContainerDefinition(protectedTask, "updateDefenderImage", defenderImage, "")
	
	//convert format back for use in cloudformation template
	protectedTask = convertFormat(protectedTask, false)
	
	return protectedTask
}

def convertFormat(def object, def toCamelCase) {
	//goes recursively through maps and lists and updates keys to be either camelCase or not in all maps
	//base case is when some object is not a map or list: e.g. string or int
	 
	if (object instanceof Map) {
		def updatedObject = [:]
		
		object.each { keyPair ->
			def key = keyPair.key
			def value = keyPair.value
		
			//skip options since they aren't camel case
			if (key == "Options") {
				updatedObject.put(key, value)
				return
			}
			
			//update key 
			def newKey
			if (toCamelCase) {
				newKey = key.substring(0, 1).toLowerCase() + key.substring(1)
			} else {
				newKey = key.substring(0, 1).toUpperCase() + key.substring(1)
			}
			
			value = convertFormat(object[key], toCamelCase)
			updatedObject.put(newKey, value)
		}
		return updatedObject
		
	} else if (object instanceof List) {
		def updatedObject = []
		
		object.each { element ->
			element = convertFormat(element, toCamelCase)
			updatedObject << element
		}
		
		return updatedObject
	} else {
		//reached base case
		return object
	}
}

def updateContainerDefinition(def task, def action, def defenderImage, def parameters) {
	def containerDefinitions = task.containerDefinitions
	def updatedContainerDefinitions = []
	def entryPoint = "entryPoint"
	
	containerDefinitions.each { containerDefinition ->
		switch(action) {
			case "addEntryPoint":
				//should be only one container definition at this point, but just add entrypoints for any in the loop
				containerDefinition = addEntryPoint(containerDefinition, entryPoint)
				updatedContainerDefinitions << containerDefinition
				break
			case "replaceRefFunctions":
				//should be only one container definition at this point
				containerDefinition = replaceRefFunctions(containerDefinition, parameters)
				updatedContainerDefinitions << containerDefinition
				break
			case "addScriptsToEntryPoint":
				//this should be on the applications's container definition
				if (!isSideCarDefinition(containerDefinition)) {
					containerDefinition = addScriptsToEntryPoint(containerDefinition, entryPoint)
				}
				updatedContainerDefinitions << containerDefinition
				break
			case "updateDefenderImage":
				//this should only be in the sidecar container definition
				if (isSideCarDefinition(containerDefinition)) {
					containerDefinition = updateDefenderImage(containerDefinition, defenderImage)
				}
				updatedContainerDefinitions << containerDefinition
				break
			default:
				println "Error: need to specificy one of three actions while making updates to container definition within a task"
				System.exit(1)
		}
		
	}
	
	task.remove("containerDefinitions")
	task.put("containerDefinitions", updatedContainerDefinitions)
	return task
}

def isSideCarDefinition(def containerDefinition) {
	def isSideCarDefinition = false
	
	containerDefinition.entryPoint.each { value ->
		if (value == "sidecar") {
			isSideCarDefinition = true
		}
	}
	
	return isSideCarDefinition
}

def addEntryPoint(def containerDefinition, def entryPoint) {
	if (!containerDefinition.containsKey(entryPoint)) {
		containerDefinition.put(entryPoint, [])
	}
	
	return containerDefinition
}

def replaceRefFunctions(def containerDefinition, def parameters) {
	//check name for container
	containerDefinition = replaceRef(containerDefinition, "name", parameters)
	
	//check image for container
	containerDefinition = replaceRef(containerDefinition, "image", parameters)
	
	return containerDefinition
}

def replaceRef(def containerDefinition, def property, def parameters) {
	if (containerDefinition.containsKey(property)) {
		def value = containerDefinition[property]
		if (value.contains("!Ref ")) {
			def parameter = value.split(" ")[1]
			if (!parameters.containsKey(parameter)) {
				println "Failed to replace Ref funtion for container definition ${property} while looking for parameter ${parameter}"
				System.exit(1)
			}
			
			def newValue = parameters[parameter]
			println "Going to replace ${parameter} with ${newValue} before getting protected task"
			
			containerDefinition.remove(property)
			containerDefinition.put(property, newValue)
		}
	} else {
		println "missing ${property} in containerDefinition"
		System.exit(1)
	}
	
	return containerDefinition
}

def addScriptsToEntryPoint(def containerDefinition, def entryPoint) {
	def script = "/scripts/start.sh"
	def containsScript = false
	
	containerDefinition.entryPoint.each { value ->
		if (value == script) {
			containsScript = true
		}
	}
	
	if (!containsScript) {
		def updatedEntryPoint = []
		updatedEntryPoint = containerDefinition.remove(entryPoint)
		updatedEntryPoint << script
		containerDefinition.put(entryPoint, updatedEntryPoint)
	}
	
	
	return containerDefinition
}

def updateDefenderImage(def containerDefinition, def defenderImage) {
	containerDefinition.remove("image")
	containerDefinition.put("image", defenderImage)
	return containerDefinition
}

def callTwistlockApi(def task, def twJsonString, def twUser, def twPass, def envType, def requestId) {
	//write task as json to file
	def unprotectedFileName = "fargate.task"
	def unprotectedJsonFile = new File(unprotectedFileName)
	def unprotectedJson = new JsonBuilder(task).toPrettyString()
	unprotectedJsonFile.write(unprotectedJson)
	
	def protectedFileName = "protected.task"
	
	//first get temporary token
	def twAppUrl = getTwistlockUrl("APPLICATION_LOAD_BALANCER", twJsonString, envType)
	def twClassicUrl = getTwistlockUrl("CLASSIC_LOAD_BALANCER", twJsonString, envType)
	def token = getTwistlockToken(twAppUrl, twUser, twPass, requestId)
	
	//now call twistlock api
	def getProtectedTaskCmd = "curl -k -H \"Authorization: Bearer ${token}\" \"${twAppUrl}/api/v1/defenders/fargate.json?consoleaddr=${twClassicUrl}\" --data-binary \"@${unprotectedFileName}\" -o ${protectedFileName}"
	
	println "Going to call twistlock api to get protected task"
	runCMD(getProtectedTaskCmd, requestId) 
	
	//retrieve new task from output file
	def protectedJsonFile = new File(protectedFileName)
	if (!protectedJsonFile.exists()) {
		println "Failed to get protected task from twistlock. No output file"
		System.exit(1)
	}
	
	def protectedTask
	try {
		protectedTask = new JsonSlurper().parseText(protectedJsonFile.getText())
	} catch(Throwable e) {
		println "Failed to get protected task from twistlock. No valid Json"
		System.exit(1)
	} 
	
	if (protectedTask.containsKey("err")) {
		println "There was an error getting the protected task from twistlock console:\n" + protectedTask.err 
		System.exit(1)
	}
	
	return protectedTask
}

def getTwistlockUrl(def urlType, def urls, def envType) {
	//def urls = '''${p:system/TWISTLOCK_URLS}'''
	//def envType = "${p:environment/envType}"
	def urlsJson = new JsonSlurper().parseText(urls)
	def url
	
	if (urlType == "APPLICATION_LOAD_BALANCER") {
		url = urlsJson[envType][0]
		
	} else if (urlType == "CLASSIC_LOAD_BALANCER") {
		url = urlsJson[envType][1]
		
		//this url can't have https since twistlock will use different ws protocol in the protected task
		if (url.contains("https://") || url.contains("http://")) {
			url = url.split("//")[1]
		}
		
	} else {
		println "something went wrong"
		System.exit(1)
	}
	
	if ((!url) || (url == "")) {
		println "Failed to get the twistlock URL from json in system property for env type: " + envType
		System.exit(1)
	}
	
	println "Getting tw url: " + url
	return url
}

def getTwistlockToken(def twConsole, def twUser, def twPass, def requestId) {
	def auth = [:]
	auth.put("username", twUser)
	auth.put("password", twPass)
	def authJson = new JsonBuilder(auth).toString()
	def getTokenCommand = "curl -k -H \"Content-Type: application/json\" -d '${authJson}' ${twConsole}/api/v1/authenticate"
	def tokenOutput = runCMD(getTokenCommand, requestId)
	def tokenJson
	try {
	   tokenJson = new JsonSlurper().parseText(tokenOutput)
	} catch (Throwable e) {
		println "Failed to connect to twistlock console: " + twConsole
		System.exit(1)
	}
	
	if (!tokenJson.containsKey("token")) {
		println "Failed to connect to twistlock console: " + twConsole
		System.exit(1)
	}
	
	return tokenJson.token
}

def updateCfTemplate(def cfTemplate, def protectedTask) {
	def updatedCfTemplate = [:]
	
	cfTemplate.each { node ->
		if (node.key == "Resources") {
			def nodeValue = updateResources(node.value, protectedTask)
			updatedCfTemplate.put(node.key, nodeValue)
			return
		}
		updatedCfTemplate.put(node.key, node.value)
	}
	
	return updatedCfTemplate
}

def updateResources(def resources, def protectedTask) {
	def updatedResources = [:]
	resources.each { resource ->
		if (resource.key == "TaskDefinition") {
			newTaskDefinition = updateTaskDefinition(resource.value, protectedTask)
			updatedResources.put(resource.key, newTaskDefinition)
			return
		}
		updatedResources.put(resource.key, resource.value)
	}
	
	return updatedResources
}

def updateTaskDefinition(def taskDefinition, def protectedTask) {
	def properties = "Properties"
	taskDefinition.remove(properties)
	taskDefinition.put(properties, protectedTask)
	
	return taskDefinition
}

def getNode(def tree, def name) {
	def requestedElement
	tree.each { node ->
		if (node.key == name) {
			requestedElement = node.value
		}
	}
	
	return requestedElement
}

def writeBackToFile(def updatedCfTemplate, def cfTemplateYamlFile, def yamlBuilder) {
	yamlBuilder updatedCfTemplate
	def newYaml = yamlBuilder.toString().replaceAll("-!", "!")
	
	cfTemplateYamlFile.withWriter { out ->
		newYaml.split("\n").each { line ->
			if (line.contains("!")) {
				out.println line.replaceAll("\"", "")
			} else {
				out.println line
			}
		}
	}
	println cfTemplateYamlFile.text
}

def runCMD(def cmd, def requestId) {
	def outputFileName = "output-${requestId}.txt"
	def scriptFile = new File("script-${requestId}.sh")
	scriptFile.text = cmd + " >> ${outputFileName}"
	
	try {
		def proc = ["/bin/bash",scriptFile.absolutePath].execute()
		proc.waitForOrKill(30 * 1000) //kill after 30 seconds which throws an exception
	} catch (Throwable e) {
		println "Failed to run command"
		System.exit(1)
	}
	
	def outputFile = new File(outputFileName)
	def output = outputFile.getText()
	outputFile.delete()
	scriptFile.delete()
	return output
}