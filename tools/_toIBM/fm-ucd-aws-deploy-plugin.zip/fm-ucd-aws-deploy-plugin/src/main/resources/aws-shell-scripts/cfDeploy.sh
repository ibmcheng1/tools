#!/bin/bash

################################
#Helper functions
################################
log () {
    MESSAGE=$1
    TS=$(TZ=":US/Eastern" date +%H:%M:%S)
    echo "${TS} - $MESSAGE"
}

#run a command with logging and error checking
RUN_CMD () {
    CMD=$1
    log "Running: ${CMD}"
    $CMD
    
    if [[ $? -ne 0 ]]; then
        echo "Failed while running: ${CMD}"
        exit 1
    fi
}

ADD_PROTECTED_TASK() {
	AGENT_ROOT=$(dirname $AGENT_HOME)
	
	log "Unsetting the proxy because we don't need proxy to connect to the twistlock console"
	export http_proxy=; export https_proxy=; export no_proxy=
	
	# JAVA_HOME should be passed in from UCD agent process context via generated environment properties file
	# Agent container's jre is install on different location (/opt/ibm/java/jre)
	# export JAVA_HOME=${AGENT_ROOT}/java/ibm-java-x86_64-80/jre
	
	export GROOVY_HOME=${AGENT_ROOT}/agent/opt/groovy-3.0.0-rc-1
	export PATH=${PATH}:${JAVA_HOME}/bin:${GROOVY_HOME}/bin
	
	#make sure groovy 3 exists on this agent
	if [[ ! -d $GROOVY_HOME ]] ; then
		echo "ERROR: can't find groovy version needed on this agent: ${GROOVY_HOME}"
		exit 1
	fi
	
	#now run groovy script to update cf template with protected task
	log "Using GROOVY_HOME: ${GROOVY_HOME}"
	${GROOVY_HOME}/bin/groovy ${SCRIPTS_PATH}/addProtectedTask.groovy

	if [[ $? != 0 ]] ; then
		echo "Failed to add protected task"
		exit 1
	fi
	
	log "CF template yaml file is updated with twistlock defender in fargate task"
	
	export https_proxy=http://zsproxy.fanniemae.com:9480
    export http_proxy=http://zsproxy.fanniemae.com:9480
    export no_proxy=sts.fanniemae.com
}

VALIDATE_ROLE () {
    ROLE=$1
    
    source .awsprofile
    CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
    if [[ $CURRENT_ROLE != $ROLE ]] ; then
        echo "ERROR: Failed to assume the role: ${ROLE}"
        exit 1
    fi    
    log "Assumed role: ${ROLE}"
}

CLEANUP_S3_PATH () {
    S3_PATH_CLEANED=$1
    FILE_EXTENSION="\.(war|zip|jar|ear|txt|yaml|json)$"
    if  [[ $S3_PATH_CLEANED =~ $FILE_EXTENSION ]] ; then
        S3_PATH_CLEANED=$(dirname $S3_PATH_CLEANED) 
    fi
    
    TRAILING_SLASH="/$"
    if [[ ! $S3_PATH_CLEANED =~ $TRAILING_SLASH ]] ; then
        S3_PATH_CLEANED=${S3_PATH_CLEANED}/
    fi
}

CLOUDFORMATION_PACKAGE () {
    CFT_S3_LOCATION=$1
    TEMPLATE_FILE=$2
    PARAMETERS_FILE=$3
    KMS_KEY=$4
    NOTIFICATION_FILE=$5
    
    log "Running package step with ${CFT_S3_LOCATION}"
    
    CLEANUP_S3_PATH $CFT_S3_LOCATION && CFT_S3_LOCATION=$S3_PATH_CLEANED
    
    #PARAMETERS=${PARAMETERS_FILE}
    S3_BUCKET=$(echo $CFT_S3_LOCATION | cut -d '/' -f 3)
    S3_PREFIX=$(echo $CFT_S3_LOCATION | cut -d ':' -f 2 | sed -e "s/\/\/${S3_BUCKET}\///")
    NEW_TEMPLATE_FILE=new$(basename $TEMPLATE_FILE)
    
    if [[ ! -z $KMS_KEY ]] ; then
        PKG_KMS_FLAG="--kms-key-id ${KMS_KEY}"
        S3_KMS_FLAG="aws:kms --sse-kms-key-id ${KMS_KEY}"
    fi
    
    if [[ ! -z $S3_PREFIX ]] ; then
        S3_PREFIX_FLAG="--s3-prefix ${S3_PREFIX}"
    fi
    
    #run cloudformation package 
    RUN_CMD "aws cloudformation package --template-file ${TEMPLATE_FILE} --s3-bucket ${S3_BUCKET} $S3_PREFIX_FLAG --output-template-file ${NEW_TEMPLATE_FILE} ${PKG_KMS_FLAG}"
    
    if [[ ! -e $NEW_TEMPLATE_FILE ]] ; then
        echo "Error creating new sam template during package step"
        exit 1
    fi
    log "Created new template during package step: ${NEW_TEMPLATE_FILE}"
    
    RUN_CMD "aws s3 cp ${NEW_TEMPLATE_FILE} ${CFT_S3_LOCATION} --sse ${S3_KMS_FLAG}"
    TEMPLATE_S3_URL=$(aws s3 presign ${CFT_S3_LOCATION}${NEW_TEMPLATE_FILE})
    TEMPLATE_S3_URL=$(echo $TEMPLATE_S3_URL | cut -d '?' -f 1)
    
    log "template s3 url: ${TEMPLATE_S3_URL}"
    if [[ -z $TEMPLATE_S3_URL ]] ; then
        echo "Failed to get url for new cft template in s3"
        exit 1
    fi
    
    if [[ ! -z $NOTIFICATION_FILE ]] ; then
    	
    	if [[ ! -e $NOTIFICATION_FILE ]] ; then
    		echo "Failed to locate file: ${NOTIFICATION_FILE}"
    		exit 1
    	fi
    	
        echo "Notification JSON provided in environment: ${NOTIFICATION_FILE}"
        
        echo "${S3_BUCKET} buckets notification configuration prior to running new notification json:"
        RUN_CMD "aws s3api get-bucket-notification-configuration --bucket ${S3_BUCKET}"
        
        echo "running s3api notification configuration"
        RUN_CMD "aws s3api put-bucket-notification-configuration --bucket ${S3_BUCKET} --notification-configuration file://${NOTIFICATION_FILE}"
        
        echo "${S3_BUCKET} buckets notification configuration after to running new notification json:"
        RUN_CMD "aws s3api get-bucket-notification-configuration --bucket ${S3_BUCKET}"
    fi
}

DELETE_STACK () {
    STACK_NAME=$1
    aws cloudformation delete-stack --stack-name $STACK_NAME
            
    if [[ $? -ne 0 ]]; then
        echo "Failed to delete the stack"
        exit 1
    fi
    
    #wait on it to be deleted
    aws cloudformation wait stack-delete-complete --stack-name $STACK_NAME
    
    if [[ $? -ne 0 ]]; then
        echo "Failed to delete stack"
        exit 1
    fi
    
    log "${STACK_NAME} has been deleted"
}

CHECK_STACK () {
    log "Checking if stack already exists: ${STACK_NAME}"
    aws cloudformation describe-stacks --stack-name $STACK_NAME > /dev/null 2>&1
    
    if [[ $? -ne 0 ]]; then
        log "Stack doesn't exist so create new stack"
        changeSetType="CREATE"
        CMD=create-stack
    else
        log "Stack already exists so update existing stack"
        CMD=update-stack
        
        #make sure stack isn't already being updated
        log "Wait on stack to be ready first"
        IN_PROGRESS="PROGRESS$"
        FAILED="FAILED$"
        ROLLBACK_COMPLETE="ROLLBACK_COMPLETE" # when the stack is at this status, only DELETE operation is allowed.
        TIME_OUT=0
        REVIEW_IN_PROGRESS="REVIEW_IN_PROGRESS$" ############### NEED TO REVIEW THIS, ONCE THE CHANGESET IS CREATED, THE STACK IS IN REVIEW_IN_PROGRESS STATSUS.
        
        while true ; do
            STACK_STATUS=$(aws cloudformation describe-stacks --stack-name $STACK_NAME --query "Stacks[].StackStatus" --output text 2>/dev/null)
            log "Stack Status: $STACK_STATUS"
            
            if [[ $STACK_STATUS =~ $FAILED || $STACK_STATUS =~ $ROLLBACK_COMPLETE ]] ; then
                #if it's in a failed state then we can't update it sometimes (deleting/creating fixes that issue)
                log "Stack is in a failed state, current status: [$STACK_STATUS], so try deleting and recreating it"
                DELETE_STACK $STACK_NAME
                CMD="create-stack"
                changeSetType="CREATE"
                break
            elif [[ ! $STACK_STATUS =~ $IN_PROGRESS && ! -z $STACK_STATUS ]] ; then
                log "Stack is ready to update, current status: [$STACK_STATUS]"
                changeSetType="UPDATE"
                break
            elif [[ $STACK_STATUS =~ $REVIEW_IN_PROGRESS ]] ; then
                log "Stack status is : [$STACK_STATUS], breaking out for now to continue next step...."
                changeSetType="CREATE"
                break
            elif [[ -z $STACK_STATUS ]] ; then
                log "Stack must have been deleted, so we'll try to create it, current status: [$STACK_STATUS]"
                CMD="create-stack"
                changeSetType="CREATE"
                break
            fi
            
            TIME_OUT=$((TIME_OUT+1))
            if [[ $TIME_OUT -eq 360 ]] ; then
                echo "Timed out waiting on stack to be ready"
                exit 1
            fi
            
            sleep 5
        done
    fi
}

processMonitor () {
    cmd_=$1
    seconds_=$2
    iter_=$3

    TIME_OUT=0

    IN_PROGRESS="PROGRESS$"
    COMPLETE="COMPLETE$"
    FAILED="FAILED$"
    REVIEW_IN_PROGRESS="REVIEW_IN_PROGRESS$" ############### NEED TO REVIEW THIS, ONCE THE CHANGESET IS CREATED, THE STACK IS IN REVIEW_IN_PROGRESS STATSUS.

    log "Executing the command [$cmd_], and waiting for $seconds_ * $iter_ second(s) or less..."
    while true ; do
       STATUS=$($cmd_ 2>/dev/null)
       log "Command Status: $STATUS"

       if [[ $STATUS =~ $COMPLETE || $STATUS =~ $FAILED ]] ; then
          log "Command is either complete or failed status: [$STATUS]"
          break
       elif [[ $STATUS =~ $REVIEW_IN_PROGRESS ]] ; then
          log "Command status is : [$STATUS], breaking out for now to continue next step...."
          break
       elif [[ -z $STATUS ]] ; then
          log "Command did not return any status: [$STATUS]"
          break
       fi

       TIME_OUT=$((TIME_OUT+1))
       if [[ $TIME_OUT -gt $iter_ ]] ; then
          ((tmp_=$seconds_*$iter_))
          echo "Timed out after waiting [${tmp_}] seconds on command execution..."
          exit 1
       fi

       sleep $seconds_
    done
}

#Create Cloudformation change set
createChangeSet () {
    STACK_NAME=$1
    TEMPLATE=$2
    PARAMETERS_FILE=$3
    TAGS=$4
    PARAMETERS=${PARAMETERS_FILE}

    FAILED="FAILED$"
    ROLLBACK="ROLLBACK"

    #changeSetType="UPDATE"

    log "Create the changeset [${CHANGESET_NAME}] of stack [$STACK_NAME]"

    # Check the status of the stack, if it is in *_FAILED or ROLLBACK_COMPLETE status, and delete the stack
    CHECK_STACK $STACK_NAME

    cmd_="aws cloudformation create-change-set --stack-name ${STACK_NAME} --change-set-name $CHANGESET_NAME --change-set-type $changeSetType $TEMPLATE --parameters file://${PARAMETERS} --capabilities CAPABILITY_NAMED_IAM CAPABILITY_AUTO_EXPAND $TAGS 2>&1"
    log "Creating changeset using create-change-set command :[$cmd_]"
    ## Had to execute this command thru another tempory script, 
    ## getting error of unclosed quote for the tags value which has more than one word
    ## basically, it is trying to pass the multi-word value as separate key/value pair.
    echo $cmd_ > /tmp/.crChgSet.$$
    chmod 700 /tmp/.crChgSet.$$
    /tmp/.crChgSet.$$
    RC=$?
    rm /tmp/.crChgSet.$$
    if [[ $RC -ne 0 ]]; then
       echo "Failed to execute the changeset.[$RC]"
       exit 1
    else
       # Wait for the changeset creation
       log "Executed the create-change-set command on [$CHANGESET_NAME] successfully, now monitor the progress..."
       processMonitor "aws cloudformation describe-change-set --change-set-name $CHANGESET_NAME --stack-name $STACK_NAME --query Status --output text" 10 30
       STACK_STATUS=$(aws cloudformation describe-change-set --change-set-name $CHANGESET_NAME --stack-name $STACK_NAME --query Status --output text 2>/dev/null)
       log "Stack status after create-change-set and wait is ... [$STACK_STATUS]"
       if [[ $STACK_STATUS =~ $FAILED || $STACK_STATUS =~ $ROLLBACK ]] ; then
          REASON=$(aws cloudformation describe-change-set --change-set-name $CHANGESET_NAME --stack-name $STACK_NAME --query StatusReason --output text 2>/dev/null)         
          echo "Failed creating the changeset ${CHANGESET_NAME} for the reason: [$REASON]"
          if [[ $REASON == "The submitted information didn't contain changes. Submit different information to create a change set." ]] ; then
             STACK_CHANGES="FALSE"
             log "There are NO changes to apply to the stack"
          else
             PRINT_CF_EVENTS $STACK_NAME
             exit 1
          fi
       fi

       PRINT_CF_EVENTS $STACK_NAME
       log "Create changeset [$CHANGESET_NAME] for stack [$STACK_NAME] completed succesfully"
   fi
}

#Check the status of the ChangeSet
executeChangeSet () {
    STACK_NAME=$1
    CHANGESET_NAME=$2

    FAILED="FAILED$"
    ROLLBACK="ROLLBACK"

    log "Execute the changeset [${CHANGESET_NAME}] of stack [$STACK_NAME] if it is at AVAILABLE status "
    cmd_="aws cloudformation describe-change-set --change-set-name $CHANGESET_NAME --stack-name $STACK_NAME --query ExecutionStatus --output text "
    log "Executing the describe-change-set command :[$cmd_]"
    STATUS=$($cmd_ 2>/dev/null)
    log "Executed the describe-change-set [${CHANGESET_NAME}] of stack [$STACK_NAME], status is: [$STATUS]"
    AVAILABLE="AVAILABLE$"
    if [[ $STATUS =~ $AVAILABLE ]]
    then
       log "Executing the changeset [${CHANGESET_NAME}] of stack [$STACK_NAME] "

       aws cloudformation execute-change-set --change-set-name $CHANGESET_NAME --stack-name $STACK_NAME 
       if [[ $? -ne 0 ]]; then
           echo "Failed to execute the changeset."
           exit 1
       else
           # Wait for the stack creation
           log "Executed the execute-change-set command on [$CHANGESET_NAME] successfully, now monitor the progress..."
           processMonitor "aws cloudformation describe-stacks --stack-name $STACK_NAME --query "Stacks[].StackStatus" --output text" 5 360
           STACK_STATUS=$(aws cloudformation describe-stacks --stack-name $STACK_NAME --query "Stacks[].StackStatus" --output text 2>/dev/null)
           log "Stack status after execute-change-set and wait is ... [$STACK_STATUS]"
           if [[ $STACK_STATUS =~ $FAILED || $STACK_STATUS =~ $ROLLBACK ]] ; then
               echo "Failed while executing the changeset ${CHANGESET_NAME}"
               PRINT_CF_EVENTS $STACK_NAME
               exit 1
           fi
    
           log "Stack [$STACK_NAME] creation/update completed succesfully"
           PRINT_CF_EVENTS $STACK_NAME
       fi
    fi
}
    
#Get the changeset details
viewChangeSet () {
    STACK_NAME=$1
    CHANGESET_NAME=$2

    log "List of changes happening to the stack [$STACK_NAME] with changeset [${CHANGESET_NAME}]"
    aws cloudformation describe-change-set --change-set-name $CHANGESET_NAME --stack-name $STACK_NAME 
    if [[ $? -ne 0 ]]; then
        echo "Failed to describe the changeset."
        exit 1
    fi
}
    
#Delete the changeset 
deleteChangeSet () {
    STACK_NAME=$1
    CHANGESET_NAME=$2

    log "Deleting the changeset [${CHANGESET_NAME}] of stack [$STACK_NAME]"
    aws cloudformation delete-change-set --change-set-name $CHANGESET_NAME --stack-name $STACK_NAME 
    if [[ $? -ne 0 ]]; then
        echo "Failed to delete the changeset."
        exit 1
    fi
}

setCommonTags () {
    prefix=$1

    log "Preparing Tags (Key,Value) with pre-defined set and custom tags json file if exists"

    for tag  in $(echo "$COMMON_TAGS" | sed "s/ //g" | tr ',' '\n')
    do
      tagKey="$prefix/$tag"
      tagValue=$(aws ssm get-parameter --name "$tagKey" --query "Parameter.Value")
      if [[ "x$tagValue" != "x" ]]
      then
         TAGS="Key=$tag,Value=$tagValue $TAGS"
      else
         echo "Error: Null value returned for the tag [$tagKey] from ssm."
      fi
    done
    
    log "Checking if custom tags json file parameter set and file [$CUSTOM_TAGS_JSON_FILE] exists"
    if [[ "x${CUSTOM_TAGS_JSON_FILE}" != "x" ]]
    then
       if [[ -s $CUSTOM_TAGS_JSON_FILE ]]
       then
          log "Reading custom tags json file [$CUSTOM_TAGS_JSON_FILE]."
          #dont change the identation in below lines, it is required for python
          CUSTOM_TAGS=`cat $CUSTOM_TAGS_JSON_FILE | python -c "
import sys, json;
data=json.load(sys.stdin);
for k in data:
  sys.stdout.write('Key={},Value=\"{}\" '.format(k,data[k]))
  " `
          log "Custom tags are :[$CUSTOM_TAGS]"
          TAGS=" $TAGS $CUSTOM_TAGS"
       else
          log "Error: Custom Tags Json file [$CUSTOM_TAGS_JSON_FILE] passed is not available or zero bytes."
       fi
    fi
    
    if [[ "x${TAGS}" != "x" ]]
    then
       TAGS=" --tags $TAGS "
    fi

    log "List of tags adding are:[$TAGS]"
}

PRINT_CF_EVENTS () {
    STACK_NAME=$1
    
    log "Events for the last 10 minutes:"
    PAST_TIME=$(TZ=":UTC" date '+%Y-%m-%dT%H:%M:%S' -d '10 minutes ago')
    aws cloudformation describe-stack-events --stack-name  ${STACK_NAME} --query "StackEvents[?Timestamp>='$PAST_TIME']"
}

#############################
#Make sure ECS service exists
#############################
verfiyECSresources () {
   log "Checking ECS resources were created/updated"
   SERVICE_CHECK=$(aws ecs describe-services --cluster $CLUSTER_NAME --services $SERVICE_NAME --query "services[].status" --output text)

   if [[ $SERVICE_CHECK != "ACTIVE" ]] ; then
       echo "Can't find service: ${SERVICE_NAME}"
       exit 1
   fi
   log "Found ECS service ${SERVICE_NAME}"

   #Get the new task definition
   TASK_DEFINITION=$(aws ecs describe-services --cluster $CLUSTER_NAME --services $SERVICE_NAME --query "services[].taskDefinition" --output text)

   if [[ -z $TASK_DEFINITION ]] ; then
       echo "Can't find any task definition for service ${SERVICE_NAME}"
       exit 1
   fi
   log "Found task definition: ${TASK_DEFINITION}"

   log "Checking that container images are in the task definition"
   while read line; do
       CONTAINER_IMAGE=$(echo $line | cut -d ',' -f 2)
       log "Verifying container image: ${CONTAINER_IMAGE}"
    
       CURRENT_IMAGE=$(aws ecs describe-task-definition --task-definition $TASK_DEFINITION \
                    --query "taskDefinition.containerDefinitions[].image" \
                    --output text | grep $CONTAINER_IMAGE)

       if [[ -z $CURRENT_IMAGE ]] ; then
           echo "Failed to verify the container image in the task definition"
           ERRORS="${ERRORS}Failed to verify ${CONTAINER_IMAGE}\n"
       fi
   done < $IMAGES_FILE

   if [[ ! -z $ERRORS ]] ; then
       echo "Container image verification failed with the following errors:"
       echo -ne "${ERRORS}"
       exit 1
   fi

   log "Verified that the ECS service has been created/updated successfully"
}

############MAIN###################

#if [[ "${p:environment/cf.deploy}" == "false" ]] ; then
#    log "Skipping cloudformation step"
#    exit 0
#fi

################################
#UCD Properties
################################
#CFT_S3_LOCATION=${p:environment/cf.cftS3Location} #to use for cft package. leave blank if you don't want to package
#ROLE=${p:environment/iam.awsRole}
#PARAMETERS_FILE=${p:environment/cf.parametersJson}
#TEMPLATE_FILE=${p:environment/cf.cloudformationTemplate}
#KMS_KEY=${p:environment/s3.kmsKey}
#STACK_NAME=${p:environment/cf.stackName}
#SERVICE_NAME=${p?:getParameters/ServiceName}
#CONTAINER_IMAGE=${p?:getParameters/ContainerImage}
#IMAGES_FILE=${p:getParameters/containerImagesFile}
#CF_CHANGE_SET=${p?:aws.cf.changeSet}
#CUSTOM_TAGS_JSON_FILE=${p?:aws.cf.customTagsJsonFile}

log "-----------------------"
log "CF Deploy ..."
log "-----------------------"

#cat ucd-comp-env-profile.properties

#log "-----------------------"

source ucd-comp-env-profile.properties
CLUSTER_NAME=$CF_CLUSTER_NAME

# override STACK_NAME in ecs.deploy=true case
if [[ -z ${STACK_NAME} ]] ; then
    if [[ $ECS_ENFORCE_TWISTLOCK == "true" ]] ; then
		log "ecs.deploy=true and current STACK_NAME is empty, get STACK_NAME from getParameters step."
    	STACK_NAME=${CLUSTER_NAME}-${SERVICE_NAME}
    elif [[ $APPMESH_DEPLOY == "true" ]] ; then
        log "appmesh.deploy=true and current STACK_NAME is empty, get STACK_NAME from getParameters step."
        STACK_NAME=${MESH_NAME}-${SERVICE_NAME}
    fi
    
    log "calculated STACK_NAME = ${STACK_NAME}"   
fi

CHANGESET_NAME=${STACK_NAME}-cs-$(TZ=":US/Eastern" date +"%Y-%m-%d-%H%M%S")

APP_SHORT_NAME=$(echo $ROLE | cut -d '-' -f 1)
COMMON_TAGS=${COMMON_TAGS:-"AssetID,AppCode,ApplicationName,ApplicationShortName,CostCenter,ProjectCode"}
COMMON_TAGS_PREFIX=${COMMON_TAGS_PREFIX:-"/$APP_SHORT_NAME/common"}

log "-----------------------"
#log "currentDirectory: ${currentDirectory}"
log "currentDirectory: "`pwd`
log "CFT_S3_LOCATION: ${CFT_S3_LOCATION}"
log "ROLE: ${ROLE}"
log "PARAMETERS_FILE: ${PARAMETERS_FILE}"
log "TEMPLATE_FILE: ${TEMPLATE_FILE}"
log "KMS_KEY: ${KMS_KEY}"
log "STACK_NAME: ${STACK_NAME}"
log "ECS_ENFORCE_TWISTLOCK: ${ECS_ENFORCE_TWISTLOCK}"
log "NOTIFICATION_FILE: ${NOTIFICATION_FILE}"
log "CHANGESET_NAME: ${CHANGESET_NAME}"
log "CF_CHANGE_SET: [${CF_CHANGE_SET}]"
log "ECS Related parameters:"
log "CLUSTER_NAME: ${CLUSTER_NAME}" 
log "SERVICE_NAME: ${SERVICE_NAME}"
log "IMAGES_FILE: ${IMAGES_FILE}"
log "COMMON_TAGS: ${COMMON_TAGS}"
log "COMMON_TAGS_PREFIX: ${COMMON_TAGS_PREFIX}"
log "CUSTOM_TAGS_JSON_FILE: ${CUSTOM_TAGS_JSON_FILE}"
log "-----------------------"


################################
#Validate that we assumed the role
################################
VALIDATE_ROLE $ROLE

################################
#Validate UCD input
################################
#Check given parameters json file exists 
log "Checking that parameters json file exists"
if [[ ! -e $PARAMETERS_FILE ]] ; then
    echo "Can't find parameters json file"
    exit 1
fi
log "Found file: ${PARAMETERS_FILE}"

#check that cloudformation template file exists
log "Checking that the cloudformation template file exists"
if [[ ! -e $TEMPLATE_FILE ]] ; then
    echo "Can't find cloudformation template yaml file"
    exit 1
fi
log "Found file: ${TEMPLATE_FILE}" 


#make sure fargate task in cf template is protected
if [[ $ECS_ENFORCE_TWISTLOCK == "true" ]] ; then
	log "ecs.enforceTwistlock is true so going to modify cloudformation template to add the protected task"
	ADD_PROTECTED_TASK
fi

################################
#Run cloudformation package step
################################
if [[ ! -z $CFT_S3_LOCATION ]] ; then
    CLOUDFORMATION_PACKAGE $CFT_S3_LOCATION $TEMPLATE_FILE $PARAMETERS_FILE $KMS_KEY
    TEMPLATE="--template-url ${TEMPLATE_S3_URL}"
else
    log "Skipping package step since CFT_S3_LOCATION is not defined"
    #TEMPLATE="--template-body file://${p:componentProcess.defaultWorkDir}/${TEMPLATE_FILE}"
    TEMPLATE="--template-body file://${TEMPLATE_FILE}"
fi

log "TEMPLATE = ${TEMPLATE}"

################################
#Create Tags
################################
setCommonTags "$COMMON_TAGS_PREFIX"

#Create the stack ChageSet 
createChangeSet "${STACK_NAME}" "${TEMPLATE}" "${PARAMETERS_FILE}" "${TAGS}"

#View a ChageSet 
viewChangeSet "${STACK_NAME}" "${CHANGESET_NAME}"

#Preview or Execute the ChageSet after creating it.
if [[ "${CF_CHANGE_SET}" == "Preview" ]]
then
   log "Just a Preview request for the stack updates with ChangeSet."
elif [[ ( "X${STACK_CHANGES}" == "X" ) && ( "X${CF_CHANGE_SET}" == "X" || "${CF_CHANGE_SET}" == "Execute" ) ]]
then
   log "Executing the stack update with ChangeSet."

   #Execute the stack using ChageSet 
   executeChangeSet "${STACK_NAME}" "${CHANGESET_NAME}"
   
   #Verify ECS resources
   if [[ $ECS_ENFORCE_TWISTLOCK == "true" ]] ; then
	   log "ecs.enforceTwistlock is true so going to verify ECS resources"
       verfiyECSresources
   fi
fi

log "$0 Exiting successfully"

exit 0