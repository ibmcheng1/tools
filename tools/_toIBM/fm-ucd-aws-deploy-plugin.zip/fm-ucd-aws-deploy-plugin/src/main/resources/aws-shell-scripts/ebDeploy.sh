#!/bin/bash

################################
#Helper functions
################################
log () {
    MESSAGE=$1
    TS=$(TZ=":US/Eastern" date +%H:%M:%S)
    echo "${TS} - $MESSAGE"
}

#run a command with logging and error checking
RUN_CMD () {
    CMD=$1
    log "Running: ${CMD}"
    $CMD
    
    if [[ $? -ne 0 ]]; then
        echo "Failed while running: ${CMD}"
        exit 1
    fi
}

VALIDATE_ROLE () {
    ROLE=$1
    
    source .awsprofile
    CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
    if [[ $CURRENT_ROLE != $ROLE ]] ; then
        echo "ERROR: Failed to assume the role: ${ROLE}"
        exit 1
    fi    
    log "Assumed role: ${ROLE}"
}

PRINT_EVENT_STREAM() {
	AWS_ENV_ID=$1
    
    log "Events for the last 10 minutes:"
    PAST_TIME=$(TZ=":UTC" date '+%Y-%m-%dT%H:%M:%S' -d '10 minutes ago')
    aws elasticbeanstalk describe-events --environment-id ${AWS_ENV_ID} --query "Events[?EventDate>='$PAST_TIME']"

}

CREATE_APP_VERSION() {
    AWS_APP_NAME=$1
    AWS_VER=$2
    S3_LOCATION=$3
	AWS_ENV_NAME$4

    #get the env id
    AWS_ENV_ID=$(aws elasticbeanstalk describe-environments \
        			--application-name ${AWS_APP_NAME} \
        			--environment-name ${AWS_ENV_NAME} \
        			--query "Environments[].EnvironmentId" \
        			--output text)
							
	
    S3_BUCKET=$(echo $S3_LOCATION | cut -d '/' -f 3)
    S3_KEY=$(echo $S3_LOCATION | cut -d ':' -f 2 | sed -e "s/\/\/${S3_BUCKET}\///")
    echo "Bucket: ${S3_BUCKET}"
    echo "Key: ${S3_KEY}"
    
    log "Creating new application version"
    #this command failed when running through RUN_CMD() so need to troubleshoot, for now just run on its own
    #RUN_CMD "aws elasticbeanstalk create-application-version --application-name ${AWS_APP_NAME} --version-label ${AWS_VER} --source-bundle \"S3Bucket=${S3_BUCKET},S3Key=${S3_KEY}\" --process" 
    
    log "aws elasticbeanstalk create-application-version --application-name ${AWS_APP_NAME} --version-label ${AWS_VER} --source-bundle \"S3Bucket=${S3_BUCKET},S3Key=${S3_KEY}\" --process"
    aws elasticbeanstalk create-application-version --application-name ${AWS_APP_NAME} --version-label ${AWS_VER} --source-bundle "S3Bucket=${S3_BUCKET},S3Key=${S3_KEY}" --process
    
    if [[ $? -ne 0 ]]; then
        echo "Failed while running creating application version"
        exit 1
    fi
	
    
    while true; do
    	VER_STATUS=$(aws elasticbeanstalk describe-application-versions \
                        --application-name ${AWS_APP_NAME} \
                        --version-label ${AWS_VER} \
                        --query 'ApplicationVersions[0].Status' \
                        --output text)
        if [ "${VER_STATUS}" = "PROCESSING" ]; then
        	sleep 2
            continue
        fi
        if [ "${VER_STATUS}" = "FAILED" ]; then
			PRINT_EVENT_STREAM $AWS_ENV_ID
        	echo "ERROR: Application version creation failed"
        	exit 1
        fi
        echo "Application version has been created"
      break
    done
}

UPDATE_ENVIRONMENT() {
    AWS_APP_NAME=$1
    AWS_ENV_NAME=$2
    AWS_VER=$3
    
    #get the env id
    AWS_ENV_ID=$(aws elasticbeanstalk describe-environments \
        			--application-name ${AWS_APP_NAME} \
        			--environment-name ${AWS_ENV_NAME} \
        			--query "Environments[].EnvironmentId" \
        			--output text)
    			
    #Update the environment with the application version
    log "Checking if environment is ready"
    while true; do
    	ENV_STATUS=$(aws elasticbeanstalk describe-environment-health \
            			--environment-name ${AWS_ENV_NAME} \
            			--environment-id ${AWS_ENV_ID} \
                        --attribute-names Status \
                        --query Status \
                        --output text)
						
        
    	if [ "${ENV_STATUS}" = "Launching" ] || [ "${ENV_STATUS}" = "Updating" ]; then
          sleep 2
          continue
        fi
      	if [ "$ENV_STATUS" = "Terminating" ] || [ "${ENV_STATUS}" = "Terminated" ]; then
        	PRINT_EVENT_STREAM $AWS_ENV_ID
			echo "Environment is in the process of shutting down/is shut down"
       		exit 1
      	fi
        echo "Environment is ${ENV_STATUS}"
      	break
    done
    
    log "Updating environment with new application version"
    RUN_CMD "aws elasticbeanstalk update-environment --application-name ${AWS_APP_NAME} --environment-name ${AWS_ENV_NAME} --environment-id ${AWS_ENV_ID} --version-label ${AWS_VER}"

    while true; do
    	ENV_STATUS=$(aws elasticbeanstalk describe-environment-health \
            			--environment-name ${AWS_ENV_NAME} \
            			--environment-id ${AWS_ENV_ID} \
                        --attribute-names Status \
                        --query Status \
                        --output text)
						
        
    	if [ "${ENV_STATUS}" = "Launching" ] || [ "${ENV_STATUS}" = "Updating" ] ; then
          sleep 2 
          continue 
        fi
      	if [ "$ENV_STATUS" = "Terminating" ] || [ "${ENV_STATUS}" = "Terminated" ] ; then
        	PRINT_EVENT_STREAM $AWS_ENV_ID
			echo "Environment is in the process of shutting down/is shut down"
       		exit 1
      	fi
      	log "Environment status: ${ENV_STATUS}"
        log "Done updating environment"
      	break
    done
}

############MAIN###################

################################
#Read in UCD Properties
################################
# REGION=${p:environment/aws.region}
# AWS_APP_NAME=${p:environment/eb.application}
# AWS_ENV_NAME=${p:environment/eb.environment}
# S3_LOCATION=${p:environment/eb.s3Location} #right now this needs to be a path to a zip file or war file
# ROLE=${p:environment/iam.awsRole}
# AWS_VER=${p:version.name}

log "-----------------------"
log "EB Deploy ..."
log "-----------------------"

#cat ucd-comp-env-profile.properties

#log "-----------------------"

source ucd-comp-env-profile.properties
S3_LOCATION=$EB_S3_LOCATION

log "-----------------------"
log "currentDirectory: ${currentDirectory}"
log "UCD_ENV_PROPERTIES_FILE_NAME: ${UCD_ENV_PROPERTIES_FILE_NAME}"
log "REGION: ${REGION}" 
log "ROLE: ${ROLE}"
log "AWS_VER: ${AWS_VER}"
log "AWS_APP_NAME: ${AWS_APP_NAME}"
log "AWS_ENV_NAME: ${AWS_ENV_NAME}"
log "S3_LOCATION: ${S3_LOCATION}"
log "-----------------------"

################################
#Validate that we assumed the role
################################
VALIDATE_ROLE $ROLE

################################
#Validate UCD input
################################
#check that aws application exists
log "Verifying elastic beanstalk application"
APP_CHECK=$(aws elasticbeanstalk describe-applications \
                --application-names ${AWS_APP_NAME} \
                --output text)

if [[ -z $APP_CHECK ]] ; then
        echo "ERROR: Can't find application: ${AWS_APP_NAME}"
        exit 1
fi

#check that the aws environment exists
log "Verifying elastic beanstalk environment"
ENV_CHECK=$(aws elasticbeanstalk describe-environments \
                --application-name ${AWS_APP_NAME} \
                --environment-names ${AWS_ENV_NAME} \
                --output text)

if [[ -z $ENV_CHECK ]] ; then
        echo "ERROR: Can't find environment: ${AWS_ENV_NAME}"
        exit 1
fi

#check that the S3 location exists
log "Verifying S3 location: ${S3_LOCATION}"
aws s3 ls $S3_LOCATION
if [[ $? -ne 0 ]]; then
  echo "ERROR: Can't find the S3 Location: ${S3_LOCATION}"
  exit 1
fi

################################
#Create application version
################################
#check version already exists
VER_CHECK=$(aws elasticbeanstalk describe-application-versions \
	            --application-name ${AWS_APP_NAME}  \
            	--version-label ${AWS_VER} \
            	--output text)
            	
if [[ -z $VER_CHECK ]] ; then 
    log "${AWS_VER} doesn't exist so create application version"
    CREATE_APP_VERSION $AWS_APP_NAME $AWS_VER $S3_LOCATION $AWS_ENV_NAME
else 
    log "${AWS_VER} already exists, skipping application version creation"
fi

################################
#Update environment
################################
#check if we need to update the environment with a new version
CURRENT_VERSION=$(aws elasticbeanstalk describe-environments \
	                --application-name ${AWS_APP_NAME} \
                	--environment-name ${AWS_ENV_NAME} \
                	--query "Environments[].VersionLabel" \
                	--output text)
if [[ $AWS_VER != $CURRENT_VERSION ]] ; then
    log "Updating environment with the new version: ${AWS_VER}"
    UPDATE_ENVIRONMENT $AWS_APP_NAME $AWS_ENV_NAME $AWS_VER
else 
    log "${AWS_ENV_NAME} is already updated with the application version ${AWS_VER}. Skipping deployment"
    exit 0
fi

################################
#Validate environment
################################
#Check env status 
ENV_HEALTH=$(aws elasticbeanstalk describe-environment-health \
    			--environment-name ${AWS_ENV_NAME} \
				--environment-id ${AWS_ENV_ID} \
                --attribute-names HealthStatus \
                --query HealthStatus \
                --output text)
                
log "Environment Health: ${ENV_HEALTH}"

#Check if environment reflects the new version label
CURRENT_VERSION=$(aws elasticbeanstalk describe-environments \
	                --application-name ${AWS_APP_NAME} \
                	--environment-name ${AWS_ENV_NAME} \
                	--query "Environments[].VersionLabel" \
                	--output text)
									

if [[ $AWS_VER != $CURRENT_VERSION ]] ; then
 PRINT_EVENT_STREAM $AWS_ENV_ID
 echo "ERROR: There was an issue updating ${AWS_ENV_NAME} with ${AWS_VER}. The current version is: ${CURRENT_VERSION}"
 exit 1
fi

log "${AWS_ENV_NAME} has been updated with the new version ${AWS_VER}"

log "Exiting successful - EB Deploy"