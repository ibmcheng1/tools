#!/bin/bash

################################
#Helper functions
################################
log () {
    MESSAGE=$1
    TS=$(TZ=":US/Eastern" date +%H:%M:%S)
    echo "${TS} - $MESSAGE"
}

#run a command with logging and error checking
RUN_CMD () {
    CMD=$1
    log "Running: ${CMD}"
    $CMD
    
    if [[ $? -ne 0 ]]; then
        echo "Failed while running: ${CMD}"
        exit 1
    fi
}

VALIDATE_ROLE () {
    ROLE=$1
    
    source .awsprofile    
    CURRENT_ROLE=$(aws sts get-caller-identity --query Arn | cut -d '/' -f 2)
    if [[ $CURRENT_ROLE != $ROLE ]] ; then
        echo "ERROR: Failed to assume the role: ${ROLE}"
        exit 1
    fi    
    log "Assumed role: ${ROLE}"
}

VALIDATE_S3_PATHS () {
    S3_FILES="${1}"

    #check that s3 paths in file pairs are valid
    log "Validating s3 paths"
    for FILE_PAIR in $S3_FILES ; do
        log "Validating: ${FILE_PAIR}"
        SOURCE_PATH=$(echo $FILE_PAIR | cut -d ':' -f 1)
        S3_PREFIX=$(echo $FILE_PAIR | cut -d ':' -f 2)
        S3_PATH=$(echo $FILE_PAIR | cut -d ':' -f 3)
        S3="s3"
        SLASHES="^//"

        if [[ $SOURCE_PATH == "" || $S3_PREFIX != "s3" || ! $S3_PATH =~ $SLASHES ]] ; then
            ERROR="${FILE_PAIR} line is invalid in fileNames property. Needs to be in this format: <sourceFile>:s3://<bucket>/<path>\n"
            ERRORS="${ERRORS}$ERROR"
        fi

    done

    if [[ ! -z $ERRORS ]] ; then
        echo -ne "${ERRORS}"
        exit 1
    fi

    log "Successfully validated s3 paths"
}

CLEANUP_S3_PATH () {
    S3_PATH_CLEANED=$1
    FILE_EXTENSION="\.(war|zip|jar|ear|txt|yaml|json)$"
    if  [[ $S3_PATH_CLEANED =~ $FILE_EXTENSION ]] ; then
        S3_PATH_CLEANED=$(dirname $S3_PATH_CLEANED) 
    fi
    
    TRAILING_SLASH="/$"
    if [[ ! $S3_PATH_CLEANED =~ $TRAILING_SLASH ]] ; then
        S3_PATH_CLEANED=${S3_PATH_CLEANED}/
    fi
}

COPY_S3 () {
    S3_FILES="${1}"
    KMS_KEY=$2
    
    #validate property
    VALIDATE_S3_PATHS "${S3_FILES}"
    
    #check the type of encryption
    if [[ ! -z $KMS_KEY ]] ; then
        KMS_FLAG="aws:kms --sse-kms-key-id ${KMS_KEY}"
    fi
    
    #copy files
    for FILE_PAIR in $S3_FILES ; do 
        SOURCE_FILE=$(echo $FILE_PAIR | cut -d ':' -f 1)
        S3_PATH=$(echo $FILE_PAIR | cut -d ':' -f 2)
        S3_KEY=$(echo $FILE_PAIR | cut -d ':' -f 3)
        S3_PATH="${S3_PATH}:${S3_KEY}"
        CLEANDEPLOY=$(echo $FILE_PAIR | cut -d ':' -f 4)
        
        CLEANUP_S3_PATH $S3_PATH && S3_PATH=$S3_PATH_CLEANED
        
        log "Source: ${SOURCE_FILE}"
        log "S3 Target: ${S3_PATH}"
        
        if [[ ! -z $CLEANDEPLOY ]] ; then
            log "Performing clean deploy on ${S3_PATH}"
            RUN_CMD "aws s3 rm ${S3_PATH} --recursive"
        fi
        
        for FILE in $SOURCE_FILE ; do
        
            if [[ -d $FILE ]] ; then
                RECURSIVE="--recursive"
            fi
            
            log "Running: aws s3 cp ${FILE} ${S3_PATH} ${RECURSIVE} --sse ${KMS_FLAG} --exclude \".aws/*\"  --exclude \".awsprofile\""
            aws s3 cp ${FILE} ${S3_PATH} ${RECURSIVE} --sse ${KMS_FLAG} --exclude ".aws/*"  --exclude ".awsprofile"
            
            if [[ $? -ne 0 ]]; then
                ERROR="Failed while copying ${FILE} to ${S3_PATH}\n"
                ERRORS="${ERRORS}$ERROR"
            fi
            
            RECURSIVE=""
        done
    done
    
    if [[ ! -z $ERRORS ]] ; then
        echo -ne "${ERRORS}"
        exit 1
    fi

    log "Finished copying to s3 location"
}

############MAIN###################

#if [[ "${p:environment/s3.deploy}" == "false" ]] ; then
#    log "Skipping s3 copy"
#    exit 0
#fi

################################
#UCD Properties
################################
#S3_FILES="${p:environment/s3.s3Files}" #source file and corresponding s3 location: <sourceFile>:<s3Target>
#ROLE=${p:environment/iam.awsRole}
#KMS_KEY=${p:environment/s3.kmsKey}

log "-----------------------"
log "S3 Deploy ..."
log "-----------------------"

#cat ucd-comp-env-profile.properties

#log "-----------------------"

source ucd-comp-env-profile.properties


log "-----------------------"
log "currentDirectory: ${currentDirectory}"
log "UCD_ENV_PROPERTIES_FILE_NAME: ${UCD_ENV_PROPERTIES_FILE_NAME}"
log "S3_FILES: ${S3_FILES}" 
log "ROLE: ${ROLE}"
log "KMS_KEY: ${KMS_KEY}"
log "-----------------------"

################################
#copy to s3 location
################################
VALIDATE_ROLE $ROLE
COPY_S3 "${S3_FILES}" $KMS_KEY

log "Exiting successful - S3 Deploy"