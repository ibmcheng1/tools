package com.fanniemae.ucd.aws.deploy.controller

/**
 * Abstract class to allow for polymorphism for aws controller objects
 */
abstract class AwsController {

}