package com.fanniemae.ucd.aws.deploy.controller

import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel
import com.ibm.issr.core.plugin.AbortPluginException
import com.fanniemae.ucd.aws.deploy.AwsDeploymentHelper

/**
 * The EcrController manages deployment steps involving pushing container images to ecr and running static twistlock scans
 * @author sxuwed
 *
 */
class EcrController extends AwsController {
	def script
	
	/**
	 * Constructor
	 *
	 */
	public EcrController(def script) {
		this.script = script
	}
	
	/**
	 * deploy: executes shell
	 * @return commandRunner
	 */
	public def deploy() {
		Logger.info "======================"
		Logger.info "EcrController.deploy()"
		Logger.info "======================"
		
		Logger.info "running: " + script
		
		CommandRunner commandRunner = AwsDeploymentHelper.executeShellScript(script)
		return commandRunner
	}
}