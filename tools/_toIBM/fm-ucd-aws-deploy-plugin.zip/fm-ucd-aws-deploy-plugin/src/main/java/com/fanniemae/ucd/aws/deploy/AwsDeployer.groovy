package com.fanniemae.ucd.aws.deploy

import com.fanniemae.ucd.aws.deploy.plan.DeploymentPlan
import com.fanniemae.ucd.config.model.*
import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel
import com.ibm.issr.core.plugin.AbortPluginException

class AwsDeployer  {
	static boolean failFastMode = true
	static def osType = "Linux"

	static String pathToOriginalAwsScriptsDirectory = null
	static def awsServicesScriptsMaps = [:]
	
	AwsDeploymentConfig awsDeploymentConfig = null

	static {
		String osName = System.properties['os.name']
		if (osName!=null && osName.toLowerCase().contains('windows')) {
			osType = "Windows"
		} else {
			osType = "Linux"
		}

		println "AwsDeployer.osType = " + osType
	}
	
	public void preDeploy () {
		// TBD
	}
	
	public void postDeploy () {
	// TBD
}


	/**
	 * Public API to deploy AWS services
	 * precedence:
	 * 		1. ucd-deployment-template.json file on the current directory (stored in component repo.)
	 * 		2. ucdComponentConfigPropertiesString (passed in from UCD process)
	 * 		3. jsonString (support unit test)
	 */
	public void deploy (String targetEnvironment, String ucdComponentConfigPropertiesString, String jsonString) {
		Logger.info "======================"
		Logger.info "AwsDeployer.deploy()"
		Logger.info "======================"
		Logger.info "targetEnvironment = " + targetEnvironment
		Logger.info "ucdComponentConfigPropertiesString = \n" + ucdComponentConfigPropertiesString
		Logger.info "jsonString = " + jsonString
		println ""

		def defaultJsonFilePath = Constants.DEFAULT_UCD_DEPLOYMENT_TEMPLATE_FILE_PATH
		Logger.info "Default UCD Deployment Template file = " + defaultJsonFilePath

		Environment environment = null;

		String ucdDeploymentTemplateJson = null
		def defaultJsonFile = new File(defaultJsonFilePath)
		if (defaultJsonFile.exists()) {
			Logger.info "Default UCD Deployment Template file [" + defaultJsonFilePath + "] file exists."
			Logger.info "Use default UCD Deployment Template file [" + defaultJsonFilePath + "]"

			ucdDeploymentTemplateJson = defaultJsonFile.text
		} else {
			Logger.info "Default UCD Deployment Template file [" + defaultJsonFilePath + "] file does not exist."
			Logger.info "Use passed in ucdComponentConfigPropertiesString or jsonString"

			if(ucdComponentConfigPropertiesString != null && ucdComponentConfigPropertiesString != "") {
				environment = new Environment(ucdComponentConfigPropertiesString)
			} else {
				if(jsonString != null && jsonString != "") {
					Logger.info "Use jsonString to environment profile, becasue it is a valid string. "
					ucdDeploymentTemplateJson = jsonString
				} else {
					// error
					throw new Exception( "Error: no valid default UCD deployment template json file, ucdComponentConfigProperties, or jsonString available." )
				}
			}
		}
		
		Logger.info "Environment: " + environment	
		
		processJsonStringForAwsDeploymentConfig(jsonString)
		
		if (environment != null) {
			if(targetEnvironment != environment.getName()) {
				throw new Exception ("The name of created Environment config object is '" + environment.getName() + ", but the targetEnvironment name is '" + targetEnvironment + "'")
			}
		} else {
			throw new Exception ("Environment [" + targetEnvironment + "] config object is not created.")
		}
		
		pathToOriginalAwsScriptsDirectory = environment.pathToOriginalAwsScriptsDirectory
		awsServicesScriptsMaps = environment.awsServicesScriptsMaps
				
		DeploymentPlan AwsDeploymentPlan = null
		if(awsDeploymentConfig != null) {
			// user defined AWS deployment plan
			AwsDeploymentPlan = new DeploymentPlan(targetEnvironment, environment, awsDeploymentConfig.steps, awsServicesScriptsMaps)
		} else {
			// default plan
			List<String> awsServices = null
			List<Step> steps = []					
			awsServices = environment.getEnabledAwsServices()
			awsServices.each { String awsService ->
				String name = "Deploy " + awsService
				String type = Constants.STEP_TYPE_STRING_AWS
				List command = [awsService]
				steps << new Step(name, type, command)
			}

			AwsDeploymentPlan = new DeploymentPlan(targetEnvironment, environment, steps, awsServicesScriptsMaps)			
		}
		
		if(AwsDeploymentPlan == null) {
			throw new Exception ("AWS DeploymentPlan is not created.")
		} 
		
		try {
			AwsDeploymentPlan.deploy()
		} catch(Throwable t) {
			t.printStackTrace()
			throw t
		}
		
		if (AwsDeploymentPlan.status == "FAILED") {
			//if failed, return error message
			List<String> errorMessages = []
			String errorMessage
			
			AwsDeploymentPlan.deploymentStepsList.each { step ->
				if ((step.status == Constants.COMMAND_STATUS_STRING_FAILED) && (step.type == Constants.STEP_TYPE_STRING_AWS)) {
					if (step.stepResultJsonMap.containsKey("awsTasks")) {
						step.stepResultJsonMap.awsTasks.each { taskJson ->
							taskJson.messages.each { message ->
								errorMessages << message
							}
						}
					}
				}
			}
			
			if (errorMessages.size() > 0) {
				errorMessage = errorMessages.join("\n")
			} else {
				errorMessage = "Deployment Failed"
			}
			
			throw new Exception(errorMessage)
		}
		
	}

	static void generateEnvironmentContext(String targetEnvironment, List awsServices, Environment environment) {
		String content = "#####################################\n" +
				" Environment Context:\n" +
				" #####################################\n"
		if(environment == null) {
			content = content + "\nEnvironment         = null"
		} else {
			content = content + "\nApplication name       = " + environment.applicationName
			content = content + "\nComponent name         = " + environment.componentName
			content = content + "\nComponent Version name = " + environment.componentVersionName
			content = content + "\nEnvironment name       = " + environment.name
			content = content + "\nEnvironment envType    = " + environment.envType
		}
		content = content + "\n---------------------------------------"
		content = content + "\nEnabled awsServices = " + awsServices
		content = content + "\n---------------------------------------"
		Logger.info content
	}

	static void generateSummaryReport(List awsServices, Map commandResultMap) {
		String commandResult = ""
		String failedCommandResult = ""
		String passededCommandResult = ""
		int count = 0
		int countFailed = 0
		int countPassed = 0
		commandResultMap.each { entry ->
			String awsService = awsServices.get(count)
			//commandResult = commandResult + "\n$entry.value = $awsService ($entry.key)"
			commandResult = commandResult + "\n$entry.value = $awsService"

			if(entry.value == Constants.COMMAND_STATUS_STRING_FAILED) {
				failedCommandResult = failedCommandResult + "\n$entry.value = $awsService"
				countFailed++
			} else if (entry.value == Constants.COMMAND_STATUS_STRING_PASSED) {
				passededCommandResult = passededCommandResult + "\n$entry.value = $awsService"
				countPassed++
			} else {
				// error, unlikely happen.
			}

			count++
		}

		/*
		 String summaryReport = "#####################################\n" +
		 " Summary Report: number of AWS services = " + count + "\n" +
		 " #####################################\n"
		 Logger.info summaryReport + commandResult
		 */

		String passedSummaryReport = "\n#####################################\n" +
				" Passed Summary Report: number of PASSED AWS services = " + countPassed + "\n" +
				" #####################################\n"

		Logger.info passedSummaryReport + passededCommandResult

		String failedSummaryReport = "\n#####################################\n" +
				" Failed Summary Report: number of FAILED AWS services = " + countFailed + "\n" +
				" #####################################\n"

		Logger.info failedSummaryReport + failedCommandResult
	}

	private void processJsonStringForAwsDeploymentConfig(String jsonString) {
		if(jsonString != null && jsonString.length() > 0) {
			this.awsDeploymentConfig = new AwsDeploymentConfig(jsonString)
		}
		Logger.info "awsDeploymentConfig = \n" + awsDeploymentConfig		
	}

}
