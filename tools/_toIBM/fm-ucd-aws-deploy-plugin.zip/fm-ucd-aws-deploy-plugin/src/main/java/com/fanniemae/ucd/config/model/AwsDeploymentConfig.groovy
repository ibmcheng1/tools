package com.fanniemae.ucd.config.model

import com.fanniemae.ucd.aws.deploy.common.ConfigFileWrapper
import com.ibm.issr.core.json.JsonHelper
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel

class AwsDeploymentConfig extends ConfigFileWrapper {
	public Map spec = null
	
	private String name
	
	// Member data
	private String apiVersion = ''
	private String kind = ''
	private Map metadata = null
	
	private List steps = []
	
	public AwsDeploymentConfig (String specification ) {
		
		// parse the json
		String specificationWithoutComments = JsonHelper.removeCommentLines(specification)
		try {
			spec = new groovy.json.JsonSlurper().parseText( specificationWithoutComments )
			if (spec.containsKey('kind')) {
				kind = spec.kind
				if(kind != null && kind == "AwsDeploymentConfig") {
					Logger.info "Found 'AwsDeploymentConfig' kind."
				} else {
					Logger.info "The kind [" + kind + "] is not supported."
					tagValidationError( "The kind [" + kind + "] is not supported." )
					//throw new Exception("The kind [" + kind + "] is not supported.")
				}
			}
			
			Map rawData = spec
			
			if (rawData.containsKey('apiVersion')) {
				apiVersion =  rawData.apiVersion
			}
			if (rawData.containsKey('kind')) {
				kind = rawData.kind
			}
			if (rawData.containsKey('metadata')) {
				metadata = rawData.metadata
				name = metadata.name
			}
			
			//-----------------------------------
			if (rawData.containsKey('spec')) {
				spec = rawData.spec
			}			
			//-------------------------------------
							
			//println "rawData: " + rawData
			//println "spec: " + spec
			
			if ((! spec.containsKey('steps')) || spec.steps.size()==0) {
				tagValidationError( "An 'steps' entry must be in the AwsDeploymentConfig, which contains the AWS deployment configuration." )
			} else {
				//Logger.info "AwsDeploymentConfig: spec.steps.size()=" + spec.steps.size()
				
				int itemNumber = 0
				spec.steps.each { Map step ->
					++itemNumber
					String name = step.name
					String type = step.type
					List command = step.command
					//Logger.info "AwsDeploymentConfig: processing  steps["+itemNumber+"]: name=" + name + ", type="+type + ", command="+command
					
					this.steps << new Step(name, type, command)
				}				
			}
		}
		catch (Throwable e) {
			e.printStackTrace()
			
			tagValidationError( e.message )
			
			if (Logger.displayDebug) {
				Logger.printStackTrace(LoggerLevel.ERROR, e)
			}
		}
	}
	
	
	public void performFullVerification() {
		// TBD
	}
	
	public String toString () {
		int stepsSize = steps.size()
		int count = 0
		String stepsString = "[\n\t    "
		steps.each { Step step ->
			if(count < stepsSize-1) {
				stepsString = stepsString + step.toString() + "\n\t    "
			} else {
				stepsString = stepsString + step.toString() + "]"
			}
			count ++
		}
		
		String toReturn = "[AwsDeploymentConfig: apiVersion=" +
			apiVersion +
			", \n	 steps="+stepsString +
			", \n    isValid="+this.isValid() +
			", \n    validationFailures="+this.getValidationFailures() +
			"]"
		return toReturn
	}

}
