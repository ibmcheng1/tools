package com.fanniemae.ucd.aws.deploy.common

import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel

/**
 * This is a common base class that can be used for classes
 * that wrap input configuration files, such as the awsManifest
 * of the ucdComponentsDef.json.  It defines common functionality,
 * such as error handling.
 */
class ConfigFileWrapper implements ValidationErrorReporter {
	
	/**
	 * If there are any validation problems, they are added to the '_validationErrors' and
	 * '_isValid' is set to false
	 */
	private List<String> _validationErrors = []
	private boolean _isValid = true
	
	/**
	 * Adds a new validation error to the list of errors.  This is public, but
	 * should only be called by the specification definition classes.
	 */
	public void tagValidationError( String errorMsg ) {
		_isValid = false
		_validationErrors << errorMsg
	}
	
	/**
	 * Is the specification valid?  If not valid, then
	 * you can call getValidationFailures() to get the list of failures.
	 */
	public boolean isValid() {
		return _isValid
	}
	
	/**
	 * Returns a list of validation error messages.  Note that each String entry in the
	 * List is one message.  Each message may be multiple lines long.
	 * @return
	 */
	public List<String> getValidationFailures() {
		return _validationErrors
	}
	
	/**
	 * Sends the list of validation failure messages to the logger.  It displays
	 * lines between the messages.
	 * @param loggerLevel Which logging level to use, such as LoggerLevel.ERROR
	 */
	public void logValidationFailures( LoggerLevel loggerLevel ) {
		boolean anyFailures = false
		validationFailures.each { String msg ->
			anyFailures = true
			Logger.println(loggerLevel, "----------------------------------------------------")
			Logger.println(loggerLevel, msg )
		}
		if (anyFailures) {
			Logger.println(loggerLevel, "----------------------------------------------------")
		}
	}

}
