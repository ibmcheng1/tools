package com.fanniemae.ucd.aws.deploy

import com.fanniemae.ucd.config.model.Environment
import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel

class AwsDeploymentHelper {
	static void copyDirectoryResourceToCurrentDirectoy (String sourceDirectoryResourcePath, String targetDirectoryName) {
		Logger.info "+++ copyDirectoryResourceToCurrentDirectoy(): sourceDirectoryResourcePath=" + sourceDirectoryResourcePath + ", targetDirectoryName="+targetDirectoryName
		
		File targetDirectory = new File(targetDirectoryName);
		if (! targetDirectory.exists()){
			targetDirectory.mkdir();
		}
						
		Logger.info "Target directory: " + targetDirectory
		Logger.info "Target directory absolutePath: " + targetDirectory.absolutePath
		
		displayDirectoryContent(targetDirectory)
		
		def sourceDirectoryResource = this.getClass().getResource(sourceDirectoryResourcePath)
		
		if(sourceDirectoryResource != null) {
			def sourceDirectoryURL = sourceDirectoryResource.toURI()
			String sourceDirectoryURLPath = sourceDirectoryURL.getPath();
			
			Logger.info "sourceDirectoryURL = " + sourceDirectoryURL
			Logger.info "sourceDirectoryURLPath = " + sourceDirectoryURLPath
			
			File sourceDirectory = new File(sourceDirectoryURLPath);
			File[] fileArray = sourceDirectory.listFiles()
			
			Logger.info "sourceDirectory = " + sourceDirectory
			Logger.info "sourceDirectory size = " + fileArray.length
			
			int count = 0
			for (File f : fileArray) {
				String sourceFileName = f.getName()
				String targetFileName = targetDirectoryName + "/" + sourceFileName
				Logger.info "Source file [" + (++count) + "] = " + sourceFileName + ", path = " + f
				
				File targetFile = new File(targetFileName)
				Logger.info "targetFileName = " + targetFileName + ", path = " + targetFile
				
				targetFile.text =  f.text
				targetFile.setExecutable(true)
			}
		}
		
		displayDirectoryContent(targetDirectory)
	}
	
	private static void displayDirectoryContent (File directory) {
		println "==========================================="
		println "displayDirectoryContent(): Files"
		println "==========================================="
		File[] fileArray = directory.listFiles()
		int count = 0
		for (File f : fileArray) {
			Logger.info "File [" + (++count) + "] = " + f.getName() + ", path = " + f
		}
		println "==========================================="
	}
	
	static CommandRunner executeShellScript( String script ) {
		// Execute the AWS script file that calls AWS
		File shellScript = new File(script)
		shellScript.setExecutable(true)
		shellScript.text = shellScript.text.replaceAll("\r\n", "\n") //run dos2unix
						
		Logger.debug "-> executeShellScript(): " + script
		Logger.debug "shellScript.absolutePath = " + shellScript.absolutePath
		
		CommandRunner commandRunner = new CommandRunner()
		boolean success = commandRunner
			//.setVerbose( Logger.displayDebug )
			.setCommand([ shellScript.absolutePath ])
			.execute()
			.wasSuccessful()
		Logger.debug "Shell successful? " + success
		return commandRunner
	}
	
	
	static CommandRunner executeShellCommandInGeneratedScript( String cmd ) {
		// Create and execute the script file that calls AWS
		File shellScript = new File('unixScript.ksh')
		shellScript.text = cmd
		shellScript.setExecutable(true)
		
		Logger.debug "-> executeShellCommandInGeneratedScript(): " + cmd
		Logger.debug "shellScript.absolutePath = " + shellScript.absolutePath
		Logger.debug "\n" + shellScript.text

		CommandRunner commandRunner = new CommandRunner()
		boolean success = commandRunner
			.setVerbose( Logger.displayDebug )
			.setCommand([ "./${shellScript.name}" ])
			.execute()
			.wasSuccessful()
		
		Logger.debug "Shell successful? " + success
		return commandRunner
	}
	
	static CommandRunner executeShellCommandAsItIs( String cmd ) {
		Logger.debug "-> executeShellCommandAsItIs(): " + cmd

		CommandRunner commandRunner = new CommandRunner()
		boolean success = commandRunner
			.setVerbose( Logger.displayDebug )
			.setCommand([ cmd ])
			.execute()
			.wasSuccessful()
		
		Logger.debug "Shell successful? " + success
		return commandRunner
	}
	
	static CommandRunner executeShellCommandArrayAsItIs( String[] cmd ) {
		Logger.debug "-> executeShellCommandArrayAsItIs(): " + cmd

		CommandRunner commandRunner = new CommandRunner()
		boolean success = commandRunner
			.setVerbose( Logger.displayDebug )
			.setCommand(cmd)
			.execute()
			.wasSuccessful()
		
		Logger.debug "Shell successful? " + success
		return commandRunner
	}
	
	static String getPathToOriginalAwsScriptsDirectory(String sourceDirectoryResourcePath) {
		String pathToOriginalAwsScriptsDirectory = null	
		def sourceDirectoryResource = AwsDeploymentHelper.class.getResource(sourceDirectoryResourcePath)
		if(sourceDirectoryResource != null) {
			def sourceDirectoryURL = sourceDirectoryResource.toURI()
			String sourceDirectoryURLPath = sourceDirectoryURL.getPath();					
			pathToOriginalAwsScriptsDirectory = sourceDirectoryURLPath
		}
		return pathToOriginalAwsScriptsDirectory
	}
	
	static String generateSupportingFiles () {
		// create generated folder on the current directory
		String targetDirectoryName = Constants.GENERATED_AWS_SHELL_SCRIPTS_DIRECTORY_NAME
		String sourceDirectoryResourcePath = Constants.AWS_SHELL_SCRIPTS_DIRECTORY_RESOURCE_PATH
		
		copyDirectoryResourceToCurrentDirectoy(sourceDirectoryResourcePath, targetDirectoryName)
	}


	static def buildAwsDeploymentPlan (List<String> awsServices, Map awsServicesScriptsMaps) {	
		String deploymentPlan = ""
		List deploymentPlanList = []
		awsServices.each { awsService ->
			String awsServiceScript = awsServicesScriptsMaps[awsService]
			if (awsServiceScript == null) {
				// error
				throw new Exception ("UCD Plugin internal error: AWS service script not found for enabled AWS service: " + awsService)
			} else {
				deploymentPlan = deploymentPlan + awsServiceScript +"\n"
				deploymentPlanList << awsServiceScript
			}
		}
					
		// return as String
		// return deploymentPlan
		
		// return as List
		return deploymentPlanList
	}
	
	static void printMapContent(Map map, String name) {		
		Logger.info "----------------------------------"
		Logger.info "Map Content: " + name + ", size = " + map.size()
		Logger.info "----------------------------------"
		map.each { entry ->
			Logger.info "    $entry.key : $entry.value"
		}
		Logger.info "--------------------------"

	}

	static void printListContent(List list, String name) {
		Logger.info "----------------------------------"
		Logger.info "List Content: " + name + ", size = " + list.size()
		Logger.info "----------------------------------"
		int count = 0
			list.each { Object o ->
				Logger.info " -> " + o.toString()
			}
		Logger.info "--------------------------"

	}
	
	static void executeDeploymentPlan (String targetEnvironment, Environment environment, List awsServices, List awsDeploymentPlanList) {
		boolean unexpectedErrorOccurred = false
		Map commandResultMap = [:]
		List commandRunnerList = []
		try {		
			if (environment != null) {
				if(targetEnvironment != environment.getName()) {
					throw new Exception ("The name of created Environment config object is '" + environment.getName() + ", but the targetEnvironment name is '" + targetEnvironment + "'")
				}
				
				// temporary: not to use environemnt, but to use caller that is DeploymentPlan
				//awsServices = environment.getEnabledAwsServices()
			} else {
				throw new Exception ("Environment [" + targetEnvironment + "] config object is not created.")
			}
			
			//List awsDeploymentPlanList = AwsDeploymentHelper.buildAwsDeploymentPlan(awsServices, awsServicesScriptsMaps)

			Logger.info "##############################"
			Logger.info "AWS Deployment Plan"
			Logger.info "##############################"
			Logger.info "Target environment [" + targetEnvironment + "]: "
			Logger.info "Enabled awsServices = " + awsServices + " , size = " + awsServices.size()
			Logger.info "awsDeploymentPlanList = " + awsDeploymentPlanList + " , size = " + awsDeploymentPlanList.size()
			Logger.info "##############################"
			Logger.info "Executing AWS Deployment Plan"
			Logger.info "##############################"

			int count = 0
			int serviceIndex = 1
			awsDeploymentPlanList.each { String script ->
				String awsService = awsServices.get(count++)
				Logger.info "---------------------------------"
				Logger.info "Deploying AWS service[" + (serviceIndex++) + "]: " + awsService
				Logger.info "---------------------------------"
				
				if(AwsDeployer.osType == "Windows") {
					Logger.error ("Shell script execution is not supported on Windows.")
					commandResultMap[script] = Constants.COMMAND_STATUS_STRING_FAILED
				} else {
					if(awsService == Constants.STEP_TYPE_STRING_CMD) {						
						String[] commandStringArray = script.split()
						if(commandStringArray.length > 1) {
							println "commandStringArray -> " + commandStringArray
							CommandRunner commandRunner = AwsDeploymentHelper.executeShellCommandArrayAsItIs(commandStringArray)
							commandRunnerList << commandRunner
							String consoleOutput = commandRunner.getConsoleOutput()
							if (! commandRunner.wasSuccessful()) {
								commandResultMap[script] = Constants.COMMAND_STATUS_STRING_FAILED
							} else {
								commandResultMap[script] = Constants.COMMAND_STATUS_STRING_PASSED
							}
						} else {
							CommandRunner commandRunner = AwsDeploymentHelper.executeShellCommandAsItIs(script)
							commandRunnerList << commandRunner
							String consoleOutput = commandRunner.getConsoleOutput()
							if (! commandRunner.wasSuccessful()) {
								commandResultMap[script] = Constants.COMMAND_STATUS_STRING_FAILED
							} else {
								commandResultMap[script] = Constants.COMMAND_STATUS_STRING_PASSED
							}

						}
						
					} else {
						CommandRunner commandRunner = AwsDeploymentHelper.executeShellScript(script)
						commandRunnerList << commandRunner
						String consoleOutput = commandRunner.getConsoleOutput()
						if (! commandRunner.wasSuccessful()) {
							commandResultMap[script] = Constants.COMMAND_STATUS_STRING_FAILED
						} else {
							commandResultMap[script] = Constants.COMMAND_STATUS_STRING_PASSED
						}
					}
				}
			}
		} catch (Throwable e) {
			e.printStackTrace()
			if (Logger.displayDebug) {
				Logger.printStackTrace(LoggerLevel.ERROR, e)
			}

			// There may be error thrown during parsing configuration or running command (e.g. file not found).
			unexpectedErrorOccurred = true
			throw e
		} finally {

			Logger.info "#####################################"
			Logger.info "All CommandRunners consoleOutputs: "
			Logger.info "#####################################"

			boolean isAllcommandRunnersPassed = true
			int count = 0
			commandRunnerList.each { CommandRunner commandRunner ->
				String consoleOutput = commandRunner.getConsoleOutput()
				String currentAwsService = awsServices.get(count++)
				Logger.info "----------------"
				Logger.info "consoleOutput: " + currentAwsService
				Logger.info "----------------"
				Logger.info consoleOutput
				Logger.info "----------------"
				if (! commandRunner.wasSuccessful()) {
					isAllcommandRunnersPassed = false
				}
			}

			AwsDeployer.generateEnvironmentContext(targetEnvironment, awsServices, environment)
			AwsDeployer.generateSummaryReport(awsServices, commandResultMap)

			if (unexpectedErrorOccurred == true) {
				throw new Exception( "Error: Unexpected Error Occurred." )
			}

			if (isAllcommandRunnersPassed == false) {
				throw new Exception( "Error: Not all AWS scripts PASSED. You need to investigate FAILED AWS service deployment." )
			}
		}
	}
	
}