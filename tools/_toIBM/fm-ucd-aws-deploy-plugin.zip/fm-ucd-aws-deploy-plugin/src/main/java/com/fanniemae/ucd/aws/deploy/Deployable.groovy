package com.fanniemae.ucd.aws.deploy

interface Deployable {
	
	void preDeploy()
	
	void deploy()
	
	void postDeploy()
}