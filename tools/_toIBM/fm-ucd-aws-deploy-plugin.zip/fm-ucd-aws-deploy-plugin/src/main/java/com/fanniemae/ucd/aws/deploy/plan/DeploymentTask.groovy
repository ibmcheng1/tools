package com.fanniemae.ucd.aws.deploy.plan

import com.fanniemae.ucd.aws.deploy.AwsDeploymentHelper
import com.fanniemae.ucd.aws.deploy.Constants
import com.fanniemae.ucd.aws.deploy.Deployable
import com.fanniemae.ucd.aws.deploy.controller.*
import com.fanniemae.ucd.config.model.*
import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger


class DeploymentTask implements Deployable {	
	DeploymentStep deploymentStep
	
	boolean isAwsServiceTaskEnabled = false
	
	String name = ''
	String type = ''
	String deploymentCommand
	
	int index
	int stepIndex
	String indexString 
	
	CommandRunner commandRunner
	boolean wasCommandRunnerSuccessful
	String status = Constants.COMMAND_STATUS_STRING_NOTSTARTED
	
	Map taskResultJsonMap = [:]
	List messages = []
	
	ControllerManager controllerManager
	
	public DeploymentTask(int index, String taskName, String type, String deploymentCommand, DeploymentStep deploymentStep) {
		this.name = taskName
		this.type = type
		this.deploymentCommand = deploymentCommand
		this.index = index
		this.stepIndex = deploymentStep.index
		this.indexString = this.stepIndex + "-" + this.index
		
		this.deploymentStep = deploymentStep
		this.controllerManager = this.deploymentStep.deploymentPlan.environment.controllerManager
		
		if(deploymentStep.enabledAwsServices.contains(taskName))	 {
			isAwsServiceTaskEnabled = true
		}
		
		taskResultJsonMap["name"] = this.name
		taskResultJsonMap["messages"] = messages
		taskResultJsonMap["status"] = status

	}

	void preDeploy( ) {
	// tbd
	}
	
	void deploy( ) {
		Logger.info "============================"
		Logger.info ">>>>>> " + this.toString()
		Logger.info "============================"
		
		if(this.isAwsServiceTaskEnabled == false) {
			String message = "AWS service, "+ name + ", is disabled."
			Logger.info (message)
			status = Constants.COMMAND_STATUS_STRING_SKIPPED
			messages << message
		} else {
			ControllerBase controller = controllerManager.getController (this)			
			if(controller == null) {
				// For simple aws deployment cases, in which it only needs to run single deployment script,
				// simply run the deployment script within the task, to simplify the coding.
				Logger.info "Specialized controller[" + name + "] not found. Simply run deployment script."
				commandRunner = AwsDeploymentHelper.executeShellScript(deploymentCommand)
				wasCommandRunnerSuccessful = commandRunner.wasSuccessful()
				if (! commandRunner.wasSuccessful()) {
					status = Constants.COMMAND_STATUS_STRING_FAILED
				} else {
					status = Constants.COMMAND_STATUS_STRING_PASSED
				}

				/*				
				String message = "AWS service, "+ name + ": required controller["+name+"] is null"
				Logger.info (message)
				status = Constants.COMMAND_STATUS_STRING_FAILED
				messages << message
				*/
	
			} else {
				controller.deploy()
				status = controller.controllerResultJsonMap["status"]
				commandRunner = controller.commandRunnersMap["deploymentCommand"]
			}
			
			//if it failed, add error message to messages list (for now assume it is the last line of the output)
			if (status == Constants.COMMAND_STATUS_STRING_FAILED) {
				String errorMessage = getErrorMessage(commandRunner)
				messages << errorMessage
			}
		}
		
		taskResultJsonMap["status"] = status
	}
	
	void postDeploy( ) {
	// tbd
	}
	
	private String getErrorMessage(CommandRunner commmandRunner) {
		String errorMessage
		
		if(commandRunner != null && commandRunner.getConsoleOutput() != null) {
			String output = commandRunner.getConsoleOutput()
			
			if (!output || output == "") {
				errorMessage = "No output from script"
			}
			errorMessage = output.split("\n").last()
/*            String[] output_lines = output.split("\n")
			if (output_lines.size() > 5) {
				errorMessage = output_lines.takeRight(5).join("\n");
			} else {
				errorMessage = output;
			} */
		} else {
			errorMessage = "commandRunner or consoleOutput is null"
		}
		
		return errorMessage
	}

	public String toString () {
		String toReturn = "[DeploymentTask(" +indexString+ "): name=" + name +
			", type="+type  + "]"
			
		return toReturn
	}
	
}