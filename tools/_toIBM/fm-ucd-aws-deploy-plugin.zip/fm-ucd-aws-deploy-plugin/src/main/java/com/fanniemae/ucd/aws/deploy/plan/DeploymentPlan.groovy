package com.fanniemae.ucd.aws.deploy.plan

import com.fanniemae.ucd.aws.deploy.AwsDeployer
import com.fanniemae.ucd.aws.deploy.AwsDeploymentHelper
import com.fanniemae.ucd.aws.deploy.Constants
import com.fanniemae.ucd.config.model.Environment
import com.fanniemae.ucd.config.model.Step
import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger

import groovy.json.JsonBuilder


class DeploymentPlan  {
	
	String targetEnvironment
	Environment environment
	List enabledAwsServices 
	
	List<Step> steps = []
	List stepCommands = []
	
	List deploymentCommands = []
	List awsServices = []
	Map awsServicesScriptsMaps = null
	
	List<DeploymentStep> deploymentStepsList = []
	
	// json result structure
	//   AwsDeploymentResult
	//		steps
	//------------------------
	//			name
	//			type
	//			command
	//			status
	//-----------------------
	//      failedSteps: []
	//      passedSteps: []
	//	    skippedSteps: []
	//	    notStartedSteps: []
	//      unknownSteps: []
	//    
	//		processViewStatus: []
	
	Map planResultJsonMap = [:] 
	List stepsResultsJsonList = []
	List failedStepsList = []
	List passedStepsList = []
	List skippedStepsList = []
	List notStartedStepsList = []
	List unknownStepsList = []
	
	String status = Constants.COMMAND_STATUS_STRING_NOTSTARTED
	
	public DeploymentPlan(String targetEnvironment, Environment environment, List<Step> steps, Map awsServicesScriptsMaps) {
		this.targetEnvironment = targetEnvironment
		this.environment = environment
		this.enabledAwsServices = environment.enabledAwsServices
		this.steps = steps
		this.awsServicesScriptsMaps = awsServicesScriptsMaps
		
		parseSteps()
		
		planResultJsonMap["steps"] = stepsResultsJsonList
		planResultJsonMap["notStartedSteps"] = notStartedStepsList
		planResultJsonMap["skippedSteps"] = skippedStepsList
		planResultJsonMap["passedSteps"] = passedStepsList
		planResultJsonMap["failedSteps"] = failedStepsList
				
		Logger.info "#################################"
		Logger.info "enabledAwsServices = " + enabledAwsServices
		Logger.info "#################################"
		Logger.info  this.toString()
		Logger.info "#################################"
	}
	
	private parseSteps() {
		Logger.info "+++ DeploymentPlan.parseSteps(): number of steps =" + steps.size()
		int index = 1
		steps.each { Step step ->
			String name = step.name
			String type = step.type
			List command = step.command
						
			//Logger.info "===================================================="
			//Logger.info "Steps["+index+"]: name=" + name + ", type="+type + ", command="+command
			//Logger.info "===================================================="
						
			DeploymentStep deploymentStep = new DeploymentStep((index++), step, this)
			deploymentStepsList << deploymentStep			
		}
	}
	
	public void deploy () {
		println ""
		println "###########################################"
		Logger.info "DeploymentPlan.deploy(): number of steps =" + steps.size()
		println "###########################################"
		println ""
		
		int itemNumber = 0
		
		boolean skipWhenStepFailed = AwsDeployer.failFastMode
		if (skipWhenStepFailed) {
			for(DeploymentStep step : deploymentStepsList) {
				++itemNumber
				step.deploy()
				
				if(step.status == Constants.COMMAND_STATUS_STRING_FAILED) {
					Logger.info "Abort deploying process becasue deployment step Failed: " + step.toString()
					break
				}
			}
					
			deploymentStepsList.each { DeploymentStep step ->
				stepsResultsJsonList << step.stepResultJsonMap
			}

		} else {			
			 deploymentStepsList.each { DeploymentStep step ->
				 ++itemNumber
				 step.deploy()
				 stepsResultsJsonList << step.stepResultJsonMap
			 } 
		}
				
		try {
			
			//displayStepsConsole()		
			
			generateJsonResult()
			
		} catch (Throwable t) {
			t.printStackTrace()
			throw t
		}
	}
	
	
	
	public void deploy_backup_TBD () {
		Logger.info "+++ DeploymentPlan.deploy(): number of steps =" + steps.size()
		
		int itemNumber = 0
		steps.each { Step step ->
			++itemNumber
			String name = step.name
			String type = step.type
			List command = step.command
			
			Logger.info "===================================================="
			Logger.info "AwsDeploymentPlan: deploying  steps["+itemNumber+"]: name=" + name + ", type="+type + ", command="+command	
			Logger.info "===================================================="
						
			if(type == Constants.STEP_TYPE_STRING_CMD) {				
				int count = 0
				String commandString = ""
				command.forEach { String argument ->
					if((count++) == 0) {
						commandString = commandString + argument
					} else {
						commandString = commandString + " " + argument
					}				
				}
				stepCommands << commandString
				
				prepareDeploymentCommand(type, commandString, awsServicesScriptsMaps)
				
			} else if (type == Constants.STEP_TYPE_STRING_AWS) {
				command.forEach { String argument -> 
					String commandString = ""
					commandString = commandString + argument
					stepCommands << commandString
					
					prepareDeploymentCommand(type, commandString, awsServicesScriptsMaps)
				}							
			} else {
				throw new Exception ("unknow Step type: " + type)
			}					
		}
		
		println ""
		AwsDeploymentHelper.printListContent(deploymentCommands, "deploymentCommands")
		
		int count = 0
		int serviceIndex = 1
		deploymentCommands.each { String command ->
			Logger.info  "Deploying AWS service[" + (serviceIndex++) + "]: " + awsServices.get(count++) + " -> deploymentCommand: " + command
		}
		
		
		AwsDeploymentHelper.executeDeploymentPlan(targetEnvironment, environment, awsServices, deploymentCommands)
		
	}
	
	void prepareDeploymentCommand(String type, String command, Map awsServicesScriptsMaps) {
		String awsService = command
		String commandToRun = null
		
		if(Constants.AWS_SERVICES_SCRIPTS_MAPS.containsKey(command)) {
			String awsServiceScript = awsServicesScriptsMaps[awsService]
			deploymentCommands << awsServiceScript	
			awsServices << awsService
			commandToRun = awsServiceScript	
					
		} else {
			deploymentCommands << command
			awsServices << Constants.STEP_TYPE_STRING_CMD
			commandToRun = command
		}
		
		Logger.info "commandToRun: " + commandToRun	
		
	}
	
	void generateJsonResult () {
		
		println "\n###########################################"
		println "DeploymentPlan.generateJsonResult()"
		println "###########################################\n"
			
		List processViewStatusList = []	
		int count = 0
		String indent = "  "
		stepsResultsJsonList.each { Map stepResultJsonMap ->
			++count
			String status = stepResultJsonMap["status"]
			if(status != null) {
				if(status == Constants.COMMAND_STATUS_STRING_NOTSTARTED) {
					notStartedStepsList << stepResultJsonMap["name"]
					indent = "  "
				} else if(status == Constants.COMMAND_STATUS_STRING_SKIPPED) {
					skippedStepsList << stepResultJsonMap["name"]
					indent = "      "
				} else if(status == Constants.COMMAND_STATUS_STRING_FAILED) {
					failedStepsList << stepResultJsonMap["name"]
					indent = "       "
				} else if(status == Constants.COMMAND_STATUS_STRING_PASSED) {
					passedStepsList << stepResultJsonMap["name"]
					indent = "       "
				} else {
					//unknown  - error
					unknownStepsList << stepResultJsonMap["name"]
				}
			}
					
			String statusEntry = status + ":" + indent + stepResultJsonMap["name"]
			processViewStatusList << statusEntry
			
			List taskResultJsonMapList = stepResultJsonMap["awsTasks"]
			if(taskResultJsonMapList != null && taskResultJsonMapList.size()> 0) {
				taskResultJsonMapList.each { Map taskResultJsonMap ->
					status = taskResultJsonMap["status"]
					if(status == Constants.COMMAND_STATUS_STRING_SKIPPED) {
						statusEntry = "     " + status + ":            " + taskResultJsonMap["name"]
					} else {
						statusEntry = "     " + status + ":             " + taskResultJsonMap["name"]
					}					
					processViewStatusList << statusEntry
				}
			}
		}
		
		planResultJsonMap["processViewStatus"] = processViewStatusList
		
		if(unknownStepsList.size() > 0) {
			planResultJsonMap["unknownSteps"] = unknownStepsList
		}
		
		if(stepsResultsJsonList.size() == notStartedStepsList.size()) {
			this.status = Constants.COMMAND_STATUS_STRING_NOTSTARTED
		} else {
			if(stepsResultsJsonList.size() == (skippedStepsList.size() + passedStepsList.size())) {
				this.status = Constants.COMMAND_STATUS_STRING_PASSED
			} else {
				this.status = Constants.COMMAND_STATUS_STRING_FAILED
			}
		}
		
		planResultJsonMap["Overall Status"] = this.status
				
		JsonBuilder json = new JsonBuilder(planResultJsonMap)
		
		def prettyString = json.toPrettyString()
		prettyString = prettyString.replace("\\\"\\\"", "")

		println "###########################################"
		println "Deployment Plan Result"
		println "###########################################"
		println "-------------------------------------------\n"
		println prettyString
		println "-------------------------------------------\n"		
		
		println "###########################################"
		println "Overall Deployment Status: " + this.status
		println "###########################################"

	}
	
	void displayStepsConsole () {
		
		println "\n###########################################"
		println "DeploymentPlan.displayStepsConsole()"
		println "###########################################\n"

		
		boolean isAllcommandRunnersPassed = true
		int count = 0
		deploymentStepsList.each { DeploymentStep deploymentStep ->
			Logger.info "\n================================"
			Logger.info "Step[" + deploymentStep.index + "] consoleOutput: " + deploymentStep.name
			Logger.info "================================"

			if(deploymentStep.type == Constants.STEP_TYPE_STRING_CMD) {
				CommandRunner commandRunner = deploymentStep.commandRunner
				if(commandRunner != null && commandRunner.getConsoleOutput() != null) {
					String consoleOutput = commandRunner.getConsoleOutput()					
					Logger.info consoleOutput
					Logger.info "----------------"
					if (! commandRunner.wasSuccessful()) {
						isAllcommandRunnersPassed = false
					}
				} else {
					Logger.info "commandRunner or consoleOutput is null"
					Logger.info "----------------"
					isAllcommandRunnersPassed = false	
				}
				 
				/*
				consoleOutput = commandRunner.getConsoleOutput()
				
				Logger.info "\n================================"
				Logger.info "consoleOutput: " + deploymentStep.name
				Logger.info "================================"
				Logger.info consoleOutput
				Logger.info "----------------"
				if (! commandRunner.wasSuccessful()) {
					isAllcommandRunnersPassed = false
				}
				*/
			} else if (deploymentStep.type == Constants.STEP_TYPE_STRING_AWS) {
				deploymentStep.printTasksConsole()
			}
		}
	}
	
	public String toString () {
		int stepsSize = steps.size()
		int count = 0
		String stepsString = "[\n\t    "
		steps.each { Step step ->
			if(count < stepsSize-1) {
				stepsString = stepsString + step.toString() + "\n\t    "				
			} else {
				stepsString = stepsString + step.toString() + "]"
			}
			count ++
		}
		
		stepsSize = deploymentStepsList.size()
		count = 0
		String commandStepsString = "[\n\t    "
		deploymentStepsList.each { DeploymentStep step ->
			if(count < stepsSize-1) {
				commandStepsString = commandStepsString + step.toString() + "\n\t    "
				
				List awsTaskList = step.awsTaskList
				awsTaskList.each { DeploymentTask task ->
					commandStepsString = commandStepsString + "\t" + task.toString() + "\n\t    "
				}
			} else {
				int awsTaskListSize = step.awsTaskList.size()
				if (awsTaskListSize == 0) {
					commandStepsString = commandStepsString + step.toString() + "]"
				} else {
					commandStepsString = commandStepsString + step.toString() + "\n\t    "
					List awsTaskList = step.awsTaskList
					int countTask = 0
					awsTaskList.each { DeploymentTask task ->
						if(countTask == (awsTaskListSize-1)) {
							commandStepsString = commandStepsString + "\t" + task.toString() + "]"
						} else {
							commandStepsString = commandStepsString + "\t" + task.toString() + "\n\t    "
						}						
						countTask++
					}
				}				
			}
			count ++
		}

		String toReturn = "[DeploymentPlan: " +
				"\n	 steps="+stepsString +
				"\n  deploymentSteps=" + commandStepsString +
				"]"
		return toReturn
	}
}