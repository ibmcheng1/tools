package com.fanniemae.ucd.config.model

import com.fanniemae.ucd.aws.deploy.Constants
import com.fanniemae.ucd.aws.deploy.common.ValidationErrorReporter
import com.ibm.issr.core.log.Logger
import com.fanniemae.ucd.aws.deploy.controller.*

class Environment {	
	String applicationName
	String applicationAppCode
	String applicationAssetId
	String applicationAppName
		
	String componentName = ""
	String componentVersionName = ""
	String name = ""
	String envType = ""	

	Map envProperties = [:]
	
	List enabledAwsServices = []		
	String generatedUcdEnvPropsFileString = null
	
	String pathToOriginalAwsScriptsDirectory = null
	Map awsServicesScriptsMaps = [:]
	
	String ucdComponentConfigPropertiesString = null
	
	ControllerManager controllerManager

	public Environment(String ucdComponentConfigPropertiesString ) {
		Logger.info "+++ Environment(): ucdComponentConfigPropertiesString"
		
		this.ucdComponentConfigPropertiesString = ucdComponentConfigPropertiesString
		Properties componentConfigProperties = parsePropertiesString(ucdComponentConfigPropertiesString)
		envProperties = componentConfigProperties
		
		if(envProperties.containsKey("application.name")) {
			applicationName = envProperties["application.name"]
		}
		
		if(envProperties.containsKey("application.appCode")) {
			applicationAppCode = envProperties["application.appCode"]
		}
		
		if(envProperties.containsKey("application.appName")) {
			applicationAppName = envProperties["application.appName"]
		}
		
		if(envProperties.containsKey("application.assetId")) {
			applicationAssetId = envProperties["application.assetId"]
		}
		
		if(envProperties.containsKey("component.name")) {
			componentName = envProperties["component.name"]
		}
		
		if(envProperties.containsKey("component.version.name")) {
			componentVersionName = envProperties["component.version.name"]
		}
		
		if(envProperties.containsKey("environment.name")) {
			name = envProperties["environment.name"]
		}
				
		if(envProperties.containsKey("environment.envType")) {
			envType = envProperties["environment.envType"]
		} 
				
		this.getPathToOriginalAwsScriptsDirectory()	
		envProperties.put("pluginScriptsPath", pathToOriginalAwsScriptsDirectory)
				
		this.populateAwsServicesScriptsMaps()	
		this.processEnvProperties()			
		this.createEnvProfileFile()
		
		controllerManager = new ControllerManager()
		
		Logger.info "--- Environment(): applicationName="+ applicationName + ", componentName=" + componentName + ", name=" + name + ", envType=" + envType
	}
	
	public void createEnvProfileFile() {
		Logger.info "+++ Environment.createEnvProfileFile(): name="+name + ", envType=" + envType
		
		def ucdEnvPropsFile = new File(Constants.UCD_ENV_PROPERTIES_FILE_NAME)
		if(ucdEnvPropsFile.exists()){
			Logger.info "Deleting existing UCD component environment profile file. Path = " + ucdEnvPropsFile.absolutePath
			ucdEnvPropsFile.delete();
		}
		Logger.info "Creating new UCD component environment profile file ..."
		ucdEnvPropsFile.createNewFile();
		Logger.info "New UCD component environment profile file path = " + ucdEnvPropsFile.absolutePath
	
		def currentDir = new File('')
		String currentDirectory = currentDir.getAbsolutePath()
		Logger.info "currentDirectory = " + currentDirectory
			
		ucdEnvPropsFile << "applicationName='" + this.applicationName + "'\n"
		ucdEnvPropsFile << "applicationAppCode='" + this.applicationAppCode + "'\n"
		ucdEnvPropsFile << "applicationAssetId='" + this.applicationAssetId + "'\n"
		ucdEnvPropsFile << "applicationAppName='" + this.applicationAppName + "'\n"
		
		ucdEnvPropsFile << "componentName='" + this.componentName + "'\n"
		ucdEnvPropsFile << "componentVersionName='" + this.componentVersionName + "'\n"
		ucdEnvPropsFile << "envName='" + this.name + "'\n"
		ucdEnvPropsFile << "envType='" + this.envType + "'\n"
		
		envProperties.each { entry ->
			String scriptKey = Constants.UCD_PROPERTIES_KEYS_TO_SCRIPTS_KEYS_MAP["$entry.key"]
			if(scriptKey != null) {
				
				ucdEnvPropsFile << "$scriptKey='$entry.value'\n"
			}
		}

		generatedUcdEnvPropsFileString = ucdEnvPropsFile.text
		Logger.info "------------------------------------"
		Logger.info "Generated UCD Environment Properties Content: " + Constants.UCD_ENV_PROPERTIES_FILE_NAME
		Logger.info "------------------------------------"
		Logger.info generatedUcdEnvPropsFileString
		Logger.info "------------------------------------"
		
		Logger.info "--- Environment.createEnvProfileFile()"
	}
	
	public String toString () {
		String toReturn = "\n                [Environment: applicationName=" + applicationName +
			", componentName="+componentName +
			", componentVersionName="+componentVersionName +
			", name="+name + 
			", envType="+envType + 
			", envProperties="+envProperties + 
			", enabledAwsServices="+enabledAwsServices + "]" +
			", pathToOriginalAwsScriptsDirectory="+pathToOriginalAwsScriptsDirectory +
			", ucdComponentConfigPropertiesString="+ucdComponentConfigPropertiesString +
			", awsServicesScriptsMaps="+awsServicesScriptsMaps + "]" 
		return toReturn
	}
		
	private Properties parsePropertiesString(String s) {
		Logger.info "+++ Environment.parsePropertiesString():"
		
		s = cleanUpProps(s)
		
		final Properties p = new Properties()
		p.load(new StringReader(s))
		
		
		Logger.info "--- Environment.parsePropertiesString()"
		return p
	}
	
	private String cleanUpProps(String props) {
	    def lines = props.split("\n")
	    String newString = ""
	    Boolean insideMultiLineProp = false
	    lines.each { line ->
	        if (line.contains("<beginProp>")) {
	            insideMultiLineProp=true
	            line = line.replaceAll("<beginProp>", "")
	        }
	        
	        if (line.contains("<endProp>")) {
	            insideMultiLineProp = false
	            line = line.replaceAll("<endProp>", "")
	            //line = line + "\\n\\"
	        }
	        
	        if (insideMultiLineProp) {
	            line = line + "\\n\\"
	        }
	        
	        newString = newString.concat(line + "\n")
	    }
	    
	    return newString
	}
	
	private void processEnvProperties() {	
		def tempEnabledAwsServices = []
		envProperties.each { entry ->
			String propertyName = entry.key
			// looking for awsService.deploy property to determine if it is enabled.
			// note, in properties file, all values are strings, there is no boolean value.

			if(propertyName.endsWith("deploy") && (entry.value == true || entry.value == "true")) {
				//Logger.info "------> Enabled AWS Service: " + propertyName + " = " + entry.value
				String enabledAwsService = Constants.AWS_SERVICES_CONTROL_FLAGS_TO_SERVICES_MAP[propertyName]
				if(enabledAwsService != null) {
					tempEnabledAwsServices << enabledAwsService
				} else if (propertyName.name != "ecs.deploy" ) { // ecs verification is moved to cfDeploy.sh
					// error
					Logger.error "Error: Enabled AWS Service Not Found " + propertyName + " = " + entry.value
				}
			}
		}
		Logger.debug "tempEnabledAwsServices: " + tempEnabledAwsServices
		
		List defaultAwsServicesOrderedlist = Constants.DEPLOYMENT_PLAN_DEFAULT_AWS_SERVICES_ORDERED_LIST
		Logger.debug "defaultAwsServicesOrderedlist: " + defaultAwsServicesOrderedlist
		defaultAwsServicesOrderedlist.each { awsService ->
			if(tempEnabledAwsServices.contains(awsService)) {
				enabledAwsServices << awsService
			}
		}
		Logger.debug "enabledAwsServices: " + enabledAwsServices
		
	}
	
	String getPathToOriginalAwsScriptsDirectory() {
		String sourceDirectoryResourcePath = Constants.AWS_SHELL_SCRIPTS_DIRECTORY_RESOURCE_PATH
		def sourceDirectoryResource = this.getClass().getResource(sourceDirectoryResourcePath)
		if(sourceDirectoryResource != null) {
			def sourceDirectoryURL = sourceDirectoryResource.toURI()
			String sourceDirectoryURLPath = sourceDirectoryURL.getPath();
			pathToOriginalAwsScriptsDirectory = sourceDirectoryURLPath
		}
	}
	
	void populateAwsServicesScriptsMaps() {
		Constants.AWS_SERVICES_SCRIPTS_MAPS.each { entry ->
			awsServicesScriptsMaps[entry.key] = pathToOriginalAwsScriptsDirectory + "/" + entry.value
		}
	}
	
	private void printStringLineByLine(String s) {
		println " "
		println "-----------------------------"
		println "Process String line by line: "
		println "-----------------------------"
		s.eachLine {
			println it
		}
	}
	
	private void printPropertiesContent(Properties p) {
		println " "
		println "-----------------------------"
		println "Content of Properties: "
		println "-----------------------------"
		p.each { entry ->
			println "    " + entry.key + " = " + entry.value
		}
		println " "
	}
}
