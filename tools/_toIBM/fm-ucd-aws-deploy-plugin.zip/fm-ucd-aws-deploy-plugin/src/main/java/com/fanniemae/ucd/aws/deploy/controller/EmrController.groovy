package com.fanniemae.ucd.aws.deploy.controller

import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel
import com.ibm.issr.core.plugin.AbortPluginException
import com.fanniemae.ucd.aws.deploy.AwsDeploymentHelper

/**
 * The EmrController manages deployment steps involving elastic map reduce
 * @author sxuwed
 *
 */
class EmrController extends AwsController {
	def script
	
	/**
	 * Constructor
	 *
	 */
	public EmrController(def script) {
		this.script = script
	}
	
	/**
	 * deploy: executes shell
	 * @return commandRunner
	 */
	public def deploy() {
		Logger.info "======================"
		Logger.info "EmrController.deploy()"
		Logger.info "======================"
		
		Logger.info "running: " + script
		
		CommandRunner commandRunner = AwsDeploymentHelper.executeShellScript(script)
		return commandRunner
	}
}