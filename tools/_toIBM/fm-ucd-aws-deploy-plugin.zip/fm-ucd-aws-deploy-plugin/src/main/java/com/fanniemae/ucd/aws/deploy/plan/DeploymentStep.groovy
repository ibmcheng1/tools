package com.fanniemae.ucd.aws.deploy.plan

import com.fanniemae.ucd.aws.deploy.AwsDeployer
import com.fanniemae.ucd.aws.deploy.AwsDeploymentHelper
import com.fanniemae.ucd.aws.deploy.Constants
import com.fanniemae.ucd.aws.deploy.Deployable
import com.fanniemae.ucd.config.model.Step
import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger

class DeploymentStep  implements Deployable {
	DeploymentPlan deploymentPlan
	List enabledAwsServices
	Map awsServicesScriptsMaps = null
	Step step = null
	
	String name = ''
	String type = ''
	List commandArguments = []
	
	int index

	String stepCommand
	String deploymentCommand
	
	CommandRunner commandRunner

	List<DeploymentTask> awsTaskList = []
	
	String status = Constants.COMMAND_STATUS_STRING_NOTSTARTED
	
	// Step result json structure
	//----------------------------
	//   [AwsDeploymentResult]
	//		[steps]
	//-----------------------------
	//			name
	//			type
	//			command
	//			status: 
	//			messages: []
	// 
	//			tasks: []
	//			
	//
	//
	
	Map stepResultJsonMap = [:]
	List messages = []
	List taskResultJsonMapList = []

	public DeploymentStep(int index, Step step, DeploymentPlan deploymentPlan) {
		this.step = step
		this.deploymentPlan = deploymentPlan
		this.enabledAwsServices = deploymentPlan.enabledAwsServices
		this.awsServicesScriptsMaps = deploymentPlan.awsServicesScriptsMaps
		
		this.name = step.name
		this.type = step.type
		this.commandArguments = step.command
		
		this.index = index
		
		stepResultJsonMap["name"] = this.name
		stepResultJsonMap["type"] = this.type
		stepResultJsonMap["command"] = this.commandArguments
		stepResultJsonMap["messages"] = messages
		stepResultJsonMap["status"] = status
		
		if(this.type == Constants.STEP_TYPE_STRING_AWS) {
			stepResultJsonMap["awsTasks"] = taskResultJsonMapList
		}
						
		if(type == Constants.STEP_TYPE_STRING_CMD) {
			int count = 0
			String commandString = ""
			commandArguments.forEach { String argument ->
				if((count++) == 0) {
					commandString = commandString + argument
				} else {
					commandString = commandString + " " + argument
				}
			}
			stepCommand = commandString
			deploymentCommand = commandString
			
		} else if (type == Constants.STEP_TYPE_STRING_AWS) {
			int taskIndex = 1
			commandArguments.forEach { String argument ->
				String awsTaskCommand = argument				
				deploymentCommand = awsServicesScriptsMaps[awsTaskCommand]		
										
				DeploymentTask deploymentTask = new DeploymentTask((taskIndex++), awsTaskCommand, type, deploymentCommand, this)
				
				awsTaskList << deploymentTask
			}
		} else {
			throw new Exception ("unknow Step type: " + type)
		}
	}
	
	void preDeploy( ) {
	// tbd
	}
	
	void deploy( ) {
		Logger.info "#########################"
		Logger.info ">>> " + this.toString()
		Logger.info "#########################"
		
		if(AwsDeployer.osType == "Windows") {
			String message = "DeploymentStep.deploy(): Shell script execution is not supported on Windows."
			Logger.error (message)
			status = Constants.COMMAND_STATUS_STRING_FAILED
			
			stepResultJsonMap["status"] = status
			messages << message
			return
		} 		
		
		if(type == Constants.STEP_TYPE_STRING_CMD) {
			String script = deploymentCommand
			String[] commandStringArray = script.split()
			if(commandStringArray.length > 1) {
				boolean shellScriptVerifiedPassed = true
				if(commandStringArray[0].endsWith(".sh")) {
					def tempFile = new File(commandStringArray[0])
					if(!tempFile.exists()){
						String message = "The shell script to run does not exist -> " + commandStringArray[0]
						Logger.error (message)
						status = Constants.COMMAND_STATUS_STRING_FAILED		
						stepResultJsonMap["status"] = status
						messages << message
						shellScriptVerifiedPassed = false
					} else {
						tempFile.setExecutable(true)
					}
				}
				
				if(shellScriptVerifiedPassed) {
					commandRunner = AwsDeploymentHelper.executeShellCommandArrayAsItIs(commandStringArray)
					if (! commandRunner.wasSuccessful()) {
						status = Constants.COMMAND_STATUS_STRING_FAILED
					} else {
						status = Constants.COMMAND_STATUS_STRING_PASSED
					}
					stepResultJsonMap["status"] = status
				}
				
			} else {
				commandRunner = AwsDeploymentHelper.executeShellCommandAsItIs(script)
				if (! commandRunner.wasSuccessful()) {
					status = Constants.COMMAND_STATUS_STRING_FAILED
				} else {
					status = Constants.COMMAND_STATUS_STRING_PASSED
				}
				stepResultJsonMap["status"] = status
			}		
		} else {
			// AWS
			//Logger.info "awsTaskList = " + awsTaskList
			int count = 0
			int taskIndex = 1
			awsTaskList.each { DeploymentTask task ->
				String awsService = task.name
				task.deploy()				
				taskResultJsonMapList << task.taskResultJsonMap
			}
			
			boolean isAllTaskPassedOrSkipped = true
			boolean isAllTaskSkipped = false
			int countSkipped = 0
			awsTaskList.each { DeploymentTask task ->
				if(task.status == Constants.COMMAND_STATUS_STRING_FAILED) {
					isAllTaskPassedOrSkipped = false 
				} else {
					if(task.status == Constants.COMMAND_STATUS_STRING_SKIPPED) {
						countSkipped++
						if(countSkipped == awsTaskList.size()) {
							isAllTaskSkipped = true
						}
					}
				}
			}
			
			if(isAllTaskSkipped) {
				this.status = Constants.COMMAND_STATUS_STRING_SKIPPED
			} else if(isAllTaskPassedOrSkipped) {
				this.status = Constants.COMMAND_STATUS_STRING_PASSED
			} else {
				this.status = Constants.COMMAND_STATUS_STRING_FAILED
			}
			
			stepResultJsonMap["status"] = status
		}
	}

	void postDeploy( ) {
	// tbd
	}

	/*	
	private String prepareAwsDeploymentCommand(String type, String command, Map awsServicesScriptsMaps) {
		String deploymentCommand = null
		if(type == Constants.STEP_TYPE_STRING_AWS && Constants.AWS_SERVICES_SCRIPTS_MAPS.containsKey(command)) {
			deploymentCommand = awsServicesScriptsMaps[command]
		} else {
			deploymentCommand = command			
		}		
		
		return deploymentCommand
	}
	*/	
	void printTasksConsole () {
		boolean isAllcommandRunnersPassed = true
		int count = 0
		awsTaskList.each { DeploymentTask deploymentTask ->
			Logger.info "----------------"
			Logger.info "Task[" + deploymentTask.indexString + "] consoleOutput: " + deploymentTask.name
			Logger.info "----------------"
			
			CommandRunner commandRunner = deploymentTask.commandRunner
			if(commandRunner != null && commandRunner.getConsoleOutput() != null) {
				String consoleOutput = commandRunner.getConsoleOutput()
				Logger.info consoleOutput
				Logger.info "----------------"
				if (! commandRunner.wasSuccessful()) {
					isAllcommandRunnersPassed = false
				}
			} else {
				Logger.info "commandRunner or consoleOutput is null"
				Logger.info "----------------"
				isAllcommandRunnersPassed = false
			}
		}
	}
	
	
	public String toString () {
		String toReturn = "[DeploymentStep("+index+"): name=" + name +
			", type="+type +
			", commandArguments="+commandArguments  + "]"
		return toReturn
	}
}