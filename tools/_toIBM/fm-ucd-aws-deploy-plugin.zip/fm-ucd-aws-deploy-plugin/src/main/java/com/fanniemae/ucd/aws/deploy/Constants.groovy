package com.fanniemae.ucd.aws.deploy

class Constants {
	
	public static final String AWS_SERVICE_NAME_S3 = 's3'
	public static final String AWS_SERVICE_NAME_EB = 'eb'
	public static final String AWS_SERVICE_NAME_CF = 'cf'
	public static final String AWS_SERVICE_NAME_EMR = 'emr'
	public static final String AWS_SERVICE_NAME_ECS = 'ecs'
	public static final String AWS_SERVICE_NAME_ECR = 'ecr'
	public static final String AWS_SERVICE_NAME_GLUE = 'glue'

	public static final def AWS_PROFILE_NAME = '.awsprofile'
	public static final def GENERATED_AWS_SHELL_SCRIPTS_DIRECTORY_NAME = '_generated_aws_shell_scripts'
	public static final def AWS_SHELL_SCRIPTS_DIRECTORY_RESOURCE_PATH = '/aws-shell-scripts'
	
	public static final def DEFAULT_UCD_DEPLOYMENT_TEMPLATE_FILE_PATH = './ucd-deployment-template.json'
	public static final def UCD_ENV_PROPERTIES_FILE_NAME = "ucd-comp-env-profile.properties"
	public static final def UCD_PROPERTIES_KEYS_TO_SCRIPTS_KEYS_MAP = ["iam.awsAccountId":"AWS_ACCOUNTID",
			"iam.awsRole":"ROLE",
			"s3.kmsKey": "KMS_KEY",
			"s3.s3Files":"S3_FILES",
			"cf.cftS3Location":"CFT_S3_LOCATION",
			"cf.parametersJson":"PARAMETERS_FILE",
			"cf.cloudformationTemplate":"TEMPLATE_FILE",
			"cf.stackName":"STACK_NAME",
			"cf.changeSet":"CF_CHANGE_SET",
			"cf.customTagsJsonFile":"CUSTOM_TAGS_JSON_FILE",
			"cf.s3NotificationJson":"NOTIFICATION_FILE",
			"eb.application":"AWS_APP_NAME",
			"eb.environment":"AWS_ENV_NAME",
			"eb.s3Location":"EB_S3_LOCATION",
			"component.version.name":"AWS_VER",
			"aws.region":"REGION",
			"emr.emrFiles":"EMR_FILES",
			"emr.emrS3Location":"S3_LOCATION",
			"emr.emrClusterName":"CLUSTER_NAME",
			"pluginScriptsPath":"SCRIPTS_PATH",
			"getParameters.containerImagesFile":"IMAGES_FILE",
			"getParameters.priorEnvRole":"SOURCE_ROLE",
			"getParameters.ApplicationShortName":"APP_SHORT_NAME",
			"getParameters.ClusterName":"CF_CLUSTER_NAME",
			"getParameters.ServiceName":"SERVICE_NAME",
			"getParameters.MeshName": "MESH_NAME",
			"environment.envType":"ENV_TYPE",
			"app.artifactory":"ARTIFACTORY",
			"ecr.sharedEcrRepos":"SHARED_ECR_REPOS",
//			"ecs.deploy":"ECS_DEPLOY",
			"ecs.enforceTwistlock":"ECS_ENFORCE_TWISTLOCK",
			"appmesh.deploy": "APPMESH_DEPLOY",
			"system.TWISTLOCK_URLS":"TWISTLOCK_URLS",
			"system.TW_DEFENDER_VERSION":"TW_DEFENDER_VERSION",
			"system.TWISTLOCK_DEV_USER":"TWISTLOCK_DEV_USER",
			"system.TWISTLOCK_DEV_PASS":"TWISTLOCK_DEV_PASS",
			"agent.agentHome":"AGENT_HOME",
			"agent.javaHome":"JAVA_HOME"]

	
	//public static final def AWS_SERVICES_SCRIPTS_MAPS = [s3: "./_generated_aws_shell_scripts/s3Deploy.sh",
	//	cf: "./_generated_aws_shell_scripts/cfDeploy.sh",
	//	emr: "./_generated_aws_shell_scripts/emrDeploy.sh"]

	public static final def AWS_SERVICES_SCRIPTS_MAPS = [s3: "s3Deploy.sh",
		cf: "cfDeploy.sh",
		emr: "emrDeploy.sh",
		eb: "ebDeploy.sh",
		ecr: "ecrDeploy.sh",
	//	ecs: "ecsDeploy.sh", // commented as the ecs verify functionality cfDeploy.sh
		glue: "glueDeploy.sh"]

	public static final def AWS_SERVICES_CONTROL_FLAGS_TO_SERVICES_MAP = ["s3.deploy": "s3", 
			"cf.deploy": "cf", 
			"emr.deploy": "emr", 
			"ecr.deploy": "ecr", 
			"ecs.deploy": "ecs", 
			"eb.deploy": "eb", 
			"glue.deploy": "glue"]
	
	public static final def DEPLOYMENT_PLAN_DEFAULT_AWS_SERVICES_ORDERED_LIST = ["s3","ecr","glue","cf","eb","ecs","emr"]
	
	public static final def STEP_TYPE_STRING_CMD = "CMD"
	public static final def STEP_TYPE_STRING_AWS = "AWS"
	
	public static final def COMMAND_STATUS_STRING_NOTSTARTED = "NOT-STARTED"
	public static final def COMMAND_STATUS_STRING_FAILED = "FAILED"
	public static final def COMMAND_STATUS_STRING_PASSED = "PASSED"
	public static final def COMMAND_STATUS_STRING_SKIPPED = "SKIPPED"
}