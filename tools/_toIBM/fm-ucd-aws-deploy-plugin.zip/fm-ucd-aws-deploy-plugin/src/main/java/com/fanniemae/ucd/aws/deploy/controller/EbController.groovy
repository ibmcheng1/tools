package com.fanniemae.ucd.aws.deploy.controller

import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel
import com.ibm.issr.core.plugin.AbortPluginException
import com.fanniemae.ucd.aws.deploy.AwsDeploymentHelper

/**
 * The EbController manages deployment steps involving elastic beanstalk
 * @author sxuwed
 *
 */
class EbController extends AwsController {
	def script
	
	/**
	 * Constructor
	 *
	 */
	public EbController(def script) {
		this.script = script
	}
	
	/**
	 * deploy: runs ebDeploy.sh
	 * @return commandRunner
	 */
	public def deploy() {
		Logger.info "======================"
		Logger.info "EbController.deploy()"
		Logger.info "======================"
		
		Logger.info "running: " + script
		
		CommandRunner commandRunner = AwsDeploymentHelper.executeShellScript(script)
		return commandRunner
	}
}