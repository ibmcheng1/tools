package com.fanniemae.ucd.aws.deploy.controller

import com.fanniemae.ucd.aws.deploy.AwsDeploymentHelper
import com.fanniemae.ucd.aws.deploy.Constants
import com.fanniemae.ucd.aws.deploy.Deployable
import com.fanniemae.ucd.aws.deploy.plan.DeploymentStep
import com.fanniemae.ucd.aws.deploy.plan.DeploymentTask
import com.fanniemae.ucd.config.model.Environment
import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger

class ControllerBase implements Deployable {
	DeploymentStep deploymentStep
	DeploymentTask deploymentTask
		
	String name = ''
	String type = Constants.STEP_TYPE_STRING_AWS
	String deploymentCommand
	Environment environment
	
	String pathToOriginalAwsScriptsDirectory
	Map awsServicesScriptsMaps	

	Map commandRunnersMap = [:]
	
	String status = Constants.COMMAND_STATUS_STRING_NOTSTARTED	
	Map controllerResultJsonMap = [:]
	List messages = []
	
	Properties outProps = new Properties()

	public ControllerBase( String name, Environment environment) {	
		this.name = name
		this.environment = environment
		
		this.pathToOriginalAwsScriptsDirectory = environment.pathToOriginalAwsScriptsDirectory
		this.awsServicesScriptsMaps = environment.awsServicesScriptsMaps		
		this.deploymentCommand = this.awsServicesScriptsMaps[this.name]
	}

	
	public ControllerBase( DeploymentTask deploymentTask) {
		this.deploymentTask = deploymentTask
		this.deploymentStep = deploymentTask.deploymentStep
		
		this.name = deploymentTask.name
		this.environment = deploymentTask.deploymentStep.deploymentPlan.environment
		
		this.pathToOriginalAwsScriptsDirectory = environment.pathToOriginalAwsScriptsDirectory
		this.awsServicesScriptsMaps = environment.awsServicesScriptsMaps	
		this.deploymentCommand = this.awsServicesScriptsMaps[this.name]
	}
	
	void preDeploy( ) {
	// tbd
	}
	
	void deploy( ) {
		Logger.info "-------------------------------------------"
		Logger.info ">>>>>>>>> " + this.toString() + " -> deploy"
		Logger.info "-------------------------------------------"
		
		runDeploymentCommand()
	}
	
	void postDeploy( ) {
	// tbd
	}

	void runDeploymentCommand () {
		Logger.info ">>>>>>>>>>>> " + this.toString() + " -> runDeploymentCommand -> " + deploymentCommand
		
		if (deploymentCommand == null || deploymentCommand == "") {
			String message = "Controller["+name+"]:  deploymentCommand is null."
			Logger.info (message)
			status = Constants.COMMAND_STATUS_STRING_FAILED
			messages << message			
		}  else {
			CommandRunner commandRunner = AwsDeploymentHelper.executeShellScript(deploymentCommand)
			commandRunnersMap["deploymentCommand"] = commandRunner
			if (! commandRunner.wasSuccessful()) {
				status = Constants.COMMAND_STATUS_STRING_FAILED
			} else {
				status = Constants.COMMAND_STATUS_STRING_PASSED
			}	
		}
				
		controllerResultJsonMap["status"] = status
		
	}
	
	public String toString () {
		String toReturn = "[Controller("+name+")]"
			
		return toReturn
	}
}