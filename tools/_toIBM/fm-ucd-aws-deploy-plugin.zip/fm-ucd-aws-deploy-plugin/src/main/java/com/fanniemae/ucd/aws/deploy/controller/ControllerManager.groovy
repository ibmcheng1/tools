package com.fanniemae.ucd.aws.deploy.controller

import com.fanniemae.ucd.aws.deploy.Constants
import com.fanniemae.ucd.aws.deploy.plan.DeploymentTask
import com.fanniemae.ucd.config.model.Environment

import com.ibm.issr.core.log.Logger

class ControllerManager {
	
	Map registeredControllersMap = [:]
	
	/**
	 * Deployment task can simply call this constructor to get controller for target AWS service
	 * 
	 * @param deploymentTask
	 * @return
	 */
	ControllerBase getController (DeploymentTask deploymentTask) {
		String name = deploymentTask.name
		if(registeredControllersMap[name] == null) {		
			ControllerBase controller = null
			switch(name) {
				// For advanced aws service deployment that requires its own implementation, 
				// return corresponding controller instances
				case "cf":
					controller = new CfController(deploymentTask)
					break
				default:
					// For simple cases, we may consider to return ControllerBase instance.
					// controller = new ControllerBase(deploymentTask)
					//
					// If controllers need to participate controller collaboration, they need to have controller classes.
					//
					// for now (TBD), if no controller, simply run the deployment script in task level.
				    Logger.info "Controller not available for AWS service[" + name + "]"
			}	
			
			if(controller != null) {
				registeredControllersMap[name] = controller
			}	
		}
				
		return registeredControllersMap[name]
	}

	/**
	 * Support controller collaboration in which controller instance needs to get reference to other controller instances.
	 * 
	 * @param name
	 * @param environment
	 * @return
	 */
	ControllerBase getController (String name, Environment environment) {
		if(registeredControllersMap[name] == null) {
			ControllerBase controller = null
			switch(name) {
				case "cf":
					controller = new CfController(name, environment)
					break
				default:
					// For simple cases, we may consider to return ControllerBase instance.
					// controller = new ControllerBase(deploymentTask)
					//
					// If controllers need to participate controller collaboration, they need to have controller classes.
					//
					// for now (TBD), if no controller, simply run the deployment script in task level.
				    Logger.info "Controller not available for AWS service[" + name + "]"
			}
			
			if(controller != null) {
				registeredControllersMap[name] = controller
			}
		}
				
		return registeredControllersMap[name]
	}

}