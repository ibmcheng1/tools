package com.fanniemae.ucd.aws.deploy.controller

import com.fanniemae.ucd.config.model.Environment

class ControllerFactory {
	
	public AwsController getAwsController(String awsService, def script, Environment environment) {
		switch(awsService) {
			case "s3":
				return new S3Controller(script)
				break
			case "eb":
				return new EbController(script)
				break
			case "ecr":
				return new EcrController(script)
				break
			case "emr":
				return new EmrController(script)
				break
			case "cf":
				return new CfController(script, environment)
				break
			case "ecs":
				return new EcsController(script)
				break
			default:
				throw new Exception("ERROR: " + awsService + " is currently not supported by the plugin")
		}	
	}
}