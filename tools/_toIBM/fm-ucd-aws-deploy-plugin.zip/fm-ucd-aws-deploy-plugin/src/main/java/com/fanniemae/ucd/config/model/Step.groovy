package com.fanniemae.ucd.config.model

import com.ibm.issr.core.json.JsonHelper
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel

class Step {
	// Member data
	private String name = ''
	private String type = ''
	private List command = []
	
	public Step (String name, String type, List command ) {
		this.name = name
		this.type = type
		this.command = command
	}
	
	public String toString () {
		String toReturn = "[Step: name=" + name +
			", type="+type +
			", command="+command  + "]"
		return toReturn
	}
}