package com.fanniemae.ucd.aws.deploy.controller

import com.ibm.issr.core.CommandRunner
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.log.LoggerLevel
import com.ibm.issr.core.plugin.AbortPluginException
import com.fanniemae.ucd.aws.deploy.*

/**
 * The S3Controller manages deployment steps involving s3
 * @author sxuwed
 *
 */
class S3Controller extends AwsController {
	def script
	
	/**
	 * Constructor
	 *
	 */
	public S3Controller(def script) {
		this.script = script
	}
	
	/**
	 * deploy: executes shell
	 * @return commandRunner
	 */
	public def deploy() {
		Logger.info "======================"
		Logger.info "S3Controller.deploy()"
		Logger.info "======================"
		
		Logger.info "running: " + script
		
		CommandRunner commandRunner = AwsDeploymentHelper.executeShellScript(script)
		return commandRunner
	}
}