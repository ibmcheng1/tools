package com.fanniemae.ucd.aws.deploy.controller

import com.fanniemae.ucd.aws.deploy.plan.DeploymentTask
import com.fanniemae.ucd.config.model.Environment
import com.ibm.issr.core.log.Logger

/**
 * The CfController manages deployment steps involving cloudformation stacks. Also inlcudes ecs/ecr steps
 * @author sxuwed
 *
 */
class CfController extends ControllerBase {
	
	public CfController( String name, Environment environment) {
		super( name, environment)
	}
	
	public CfController( DeploymentTask deploymentTask) {
		super(deploymentTask)
	}
	
	/**
	 * deploy: runs cloudformation related steps after the role is already assumed
	 * includes ecs specific step to insert twistlock defender into cf template
	 * @return
	 */
	void deploy() {
		Logger.info "-------------------------------------------"
		Logger.info ">>>>>>>>> " + this.toString() + " -> deploy"
		Logger.info "-------------------------------------------"
		
		def environmentProperties = environment.envProperties
		def ecsDeploy = environmentProperties["ecs.enforceTwistlock"]
		
		/**
		 * When there are ecs resources present in cf template modify cloudformation template to protect fargate task (adds twistlock defender)
		 */
		if (ecsDeploy == "true") {			
			/**we'll need to run the groovy step to add the protected task to cf template
			 * this will need to run in a separate groovy script since it needs a different version of groovy
			 * The groovy script to add the protected task will be called from cfDeploy.sh
			 * So we'll write environment property string to file so it can load properties there
			 */
			
			def environmentPropertiesString = environment.ucdComponentConfigPropertiesString
			def fileName = "ucd-comp-config-properties-string.txt" //maybe add to Constants class
			def envPropFile = new File(fileName)
			
			if (envPropFile.exists()) {
				envPropFile.delete()
			}
			
			envPropFile.write(environmentPropertiesString)
		}
		
		/**
		 * Deploy step for cloudformation:
		 * Run cfDeploy.sh for creating/updating cloudformation stack
		 */
		
		runDeploymentCommand()
	}
	
	
}