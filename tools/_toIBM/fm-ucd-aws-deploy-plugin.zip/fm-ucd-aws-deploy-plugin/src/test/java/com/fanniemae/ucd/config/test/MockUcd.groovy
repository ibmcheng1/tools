package com.fanniemae.ucd.config.test

import groovy.json.*

class MockUcd {
	Map ucdConfig = [:]
	String targetEnv = "MockEnv"
	
	public MockUcd() {
		setSystemProperties()
		setDefaultConfig()
	}
	
	public void set(String property, String value) {
		//can only set existing properties
		if (!ucdConfig.containsKey(property)) {
			throw new Exception("${property} is not an existing property for the MockEnv")
		}
		
		ucdConfig.put(property, value)
	}
	
	public String getPropertyString() {
		String propString = ""
		
		ucdConfig.each { prop ->
			String propLine = prop.key + "=" + prop.value + "\n"
			propString = propString.concat(propLine)
		}
		
		return propString
	}
	
	public void setDefaultConfig() {
		ucdConfig.put("environment.name", targetEnv)
		ucdConfig.put("environment.envType", "DEVL")
		ucdConfig.put("aws.region", "us-east-1")
		ucdConfig.put("iam.awsAccountId", "")
		ucdConfig.put("iam.awsRole", "")
		ucdConfig.put("s3.deploy", "false")
		ucdConfig.put("s3.kmsKey", "")
		ucdConfig.put("s3.s3Files", "")
		ucdConfig.put("cf.deploy", "false")
		ucdConfig.put("cf.parametersJson", "")
		ucdConfig.put("cf.cloudformationTemplate", "")
		ucdConfig.put("cf.cftS3Location", "")
		ucdConfig.put("cf.stackName", "")
		ucdConfig.put("emr.deploy", "false")
		ucdConfig.put("emr.emrFiles", "")
		ucdConfig.put("emr.emrS3Location", "")
		ucdConfig.put("emr.emrClusterName", "")
		ucdConfig.put("eb.deploy", "false")
		ucdConfig.put("eb.application", "")
		ucdConfig.put("eb.environment", "")
		ucdConfig.put("eb.s3Location", "")
		ucdConfig.put("component.version.name", "test-version")
		ucdConfig.put("ecr.sharedEcrRepos", "ssgecr")
		ucdConfig.put("ecr.deploy", "false")
		ucdConfig.put("app.artifactory", "false")
		ucdConfig.put("appmesh.deploy", "false")
		ucdConfig.put("ecs.deploy", "false")
		ucdConfig.put("ecs.enforceTwistlock", "false")
		ucdConfig.put("agent.agentHome", "")
		ucdConfig.put("process.requestId", "test")
		
		//we'll also mock getParameters step and treat these like env properties
		ucdConfig.put("getParameters.containerImagesFile", "images.txt")
		ucdConfig.put("getParameters.ApplicationShortName", "")
		ucdConfig.put("getParameters.ClusterName", "")
		ucdConfig.put("getParameters.ServiceName", "")
		ucdConfig.put("getParameters.priorEnvRole", "")
		ucdConfig.put("getParameters.MeshName", "")
		
		//Cloudformation changeset
		ucdConfig.put("cf.changeSet", "false")
		
		//Tags
		ucdConfig.put("cf.customTagsJsonFile", "")		
	}
	
	private void setSystemProperties() {
		String twistlockUrls = getTwistlockUrls()
		def (user, pass) = getTwistlockCreds()
		
		ucdConfig.put("system.TWISTLOCK_URLS", "<beginProp>" + twistlockUrls + "<endProp>")
		ucdConfig.put("system.TWISTLOCK_DEV_USER", user)
		ucdConfig.put("system.TWISTLOCK_DEV_PASS", pass)
		ucdConfig.put("system.TW_DEFENDER_VERSION", "defender_19_07_363")
	}
	
	private String getTwistlockUrls() {
		def twJson = [:]
		def urls = []
		
		//get dev for now
		urls << "https://internal-awseb-AWSEB-ADDK1VWHZWNY-1953211386.us-east-1.elb.amazonaws.com"
		urls << "internal-twstlk-devl-console-v1-elb-832208119.us-east-1.elb.amazonaws.com"
		twJson.put("DEVL", urls)
		twJson.put("TEST", urls)
		
		def jsonString = new JsonBuilder(twJson).toString()
		return jsonString
	}
	
	private List getTwistlockCreds() {
		def credsFileName = ".tw"
		def credsFile = new File(credsFileName)
		
		if (!credsFile.exists()) {
			throw new IOException("Missing creds file")
		}
		
		Properties props = new Properties()
		props.load(new StringReader(credsFile.text))
		
		//can add step here to decrypt, but for now use cleartext
		
		return [props["user"], props["pass"]]
	}
	
}