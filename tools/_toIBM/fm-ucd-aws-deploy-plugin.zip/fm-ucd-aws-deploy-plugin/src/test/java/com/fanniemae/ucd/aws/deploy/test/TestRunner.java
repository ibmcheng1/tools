package com.fanniemae.ucd.aws.deploy.test;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import com.ibm.issr.core.log.Logger;
import com.ibm.issr.core.log.LoggerLevel;

public class TestRunner {
	public String runTests() {
		int failedCount = 0;
		int totalCount;
		int passedCount;
		
		Result result = JUnitCore.runClasses(AwsDeployerTest.class);
		
		Logger.info("\n\n----------------------------");
		Logger.info("Test Results:");
		Logger.info("----------------------------");
		
		for (Failure failure : result.getFailures()) {
			System.out.println(failure.toString());
			failedCount++;
		}
		
		totalCount = result.getRunCount();
		passedCount = totalCount - failedCount;
		
		Logger.info(passedCount + " out of " + totalCount + " tests passed");
		
		if (!result.wasSuccessful()) {
			return "failed";
		} 
		return "passed";
	}
}
