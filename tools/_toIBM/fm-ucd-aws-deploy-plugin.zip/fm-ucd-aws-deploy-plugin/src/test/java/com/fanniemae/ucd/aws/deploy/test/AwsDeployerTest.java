package com.fanniemae.ucd.aws.deploy.test;

import static org.junit.jupiter.api.Assertions.*;
import com.fanniemae.ucd.aws.deploy.*;
import com.fanniemae.ucd.config.test.*;
import org.junit.Before;
import org.junit.Test;
import java.util.*;

public class AwsDeployerTest {
	AwsDeployer awsDeployer = new AwsDeployer();
	MockUcd ucdConfig = new MockUcd();
	ConfigHelper configHelper = new ConfigHelper();
	List<String> writableFiles = new ArrayList<String>();
	
	@Before
	public void setUp() {
		//reset files such as cft to default state in case tests modify them
		writableFiles.add("cf-fzm-ecs.yml");
		configHelper.setUpFilesForTest("tmp/artifacts", writableFiles);
		
		//set default ucd config
		ucdConfig.setDefaultConfig();
		ucdConfig.set("iam.awsAccountId", "398996153540");
		ucdConfig.set("iam.awsRole", "aabg2-aws2-poc1-cp-deploy");
	}
	
	//test s3 deploy passes with correct config
	@Test(expected = Test.None.class /* no exception expected */)
	public void testS3Passes() {
		//setup ucd config
		ucdConfig.set("s3.deploy", "true");
		ucdConfig.set("s3.s3Files", "<beginProp>tmp/artifacts/test.txt:s3://aabg2-aws2-poc1-us-east-1/cp-artifacts/source<endProp>");
		ucdConfig.set("s3.kmsKey", "d3035572-21a0-4ab4-a702-c9b1c5a00523");
		
		//deploy
		awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), ""); 
	}
	
	//test eb deploy passes with correct config
	@Test(expected = Test.None.class /* no exception expected */)
	public void testEbPasses() {
		//setup ucd config
		//ucdConfig.set("s3.deploy", "true");
		//ucdConfig.set("s3.s3Files", "<beginProp>tmp/artifacts/Tomcat8.5-source.zip:s3://aabg3-aws2-poc1-us-east-1/cp-artifacts/source<endProp>");
		//ucdConfig.set("s3.kmsKey", "8322699c-0c03-47e1-bb4e-97cb731e80a6");
		ucdConfig.set("eb.deploy", "true");
		ucdConfig.set("eb.application", "aabg2-eb-FZM");
		ucdConfig.set("eb.environment", "aabg2-eb-FZM-fzm-devl");
		ucdConfig.set("eb.s3Location", "s3://aabg2-aws2-poc1-us-east-1/cp-artifacts/source/Tomcat8.5-source.zip");
		
		//deploy
		awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), ""); 
	}
	
	//test ecr deploy from artifactory passes with correct config
	@Test(expected = Test.None.class /* no exception expected */)
	public void testEcrWithArtifactoryPasses() {
		//set up images.txt
		String imagesFileName = "images.txt";
		String sourceImage = "artifactory-np.fanniemae.com/fqd-jenkins-snapshot/fzm-ecs:V3.5-7d22a09486cae-29";
		String targetImage = "398996153540.dkr.ecr.us-east-1.amazonaws.com/aabg2/fzm-ecr:V3.5-7d22a09486cae-29";
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText(sourceImage, targetImage);
		
		//set up ucd inputs
		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ApplicationShortName", "aabg3");
		ucdConfig.set("ecr.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("app.artifactory", "true");
		
		//deploy
		awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), ""); 
	}
	
	//test ecr deploy from prior env ecr passes with correct config
	@Test(expected = Test.None.class /* no exception expected */)
	public void testEcrWithEcrPasses() {
		//set up images.txt
		String imagesFileName = "images.txt";
		String sourceImage = "398996153540.dkr.ecr.us-east-1.amazonaws.com/aabg3/fvq-ucd-images:V3.5-7d22a09486cae-29";
		String targetImage = "398996153540.dkr.ecr.us-east-1.amazonaws.com/aabg2/fzm-ecr:V3.5-7d22a09486cae-29";
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText(sourceImage, targetImage);
		
		//set up ucd inputs
		ucdConfig.set("getParameters.priorEnvRole", "aabg3-aws2-poc1-cp-deploy");
		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ApplicationShortName", "aabg3");
		ucdConfig.set("ecr.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("environment.envType", "TEST"); //need to test this scenario when higher than dev
		
		//deploy
		awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), ""); 
	}
	
	//test cf/ecs deploy passes with correct config (this assumes images are already in ecr)
	@Test(expected = Test.None.class /* no exception expected */)
	public void testCfAndEcsPasses() {
		//set up images.txt
		String imagesFileName = "images.txt";
		String targetImage = "398996153540.dkr.ecr.us-east-1.amazonaws.com/aabg2/fzm-ecr:V3.5-7d22a09486cae-29";
		String defenderImage = "398996153540.dkr.ecr.us-east-1.amazonaws.com/aabg2/fzm-ecr:defender_19_07_363";
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText("", targetImage);
		configHelper.appendToImagesText("", defenderImage);
		
		//set up ucd inputs
		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ClusterName", "aabg2-ecs-fzm-ecs");
		ucdConfig.set("getParameters.ServiceName", "fzm-certification-01");
		ucdConfig.set("ecs.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("cf.deploy", "true");
		ucdConfig.set("cf.parametersJson", "tmp/artifacts/cf-fzm-dev-cfg.json");
		ucdConfig.set("cf.cloudformationTemplate", "tmp/artifacts/test_cf-fzm-ecs.yml");
		ucdConfig.set("agent.agentHome", "/appl/ftxdply/ucd-test/agent");
		
		//deploy
		awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), ""); 
	}	
}