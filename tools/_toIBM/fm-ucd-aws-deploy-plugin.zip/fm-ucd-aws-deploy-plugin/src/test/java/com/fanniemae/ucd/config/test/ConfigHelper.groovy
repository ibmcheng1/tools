package com.fanniemae.ucd.config.test


class ConfigHelper {
	File imagesFile
	
	public void setUpImagesText(String imagesFileName) {
		this.imagesFile = new File(imagesFileName)
		
		if (imagesFile.exists()) {
			imagesFile.delete()
		}
		
		imagesFile.createNewFile()
	}
	
	public void appendToImagesText(String sourceImage, String targetImage) {
		if (!imagesFile || !imagesFile.exists()) {
			throw new IOException("image file is missing")
		}
		
		imagesFile.append(sourceImage + "," + targetImage + "\n")
	}
	
	public String getLastImage() {
		if (!imagesFile || !imagesFile.exists()) {
			throw new IOException("image file is missing")
		}
		
		if (!imagesFile.text.contains("\n")) {
			return imagesFile.text
		} 
		
		def lines = imagesFile.text.split("\n")
		return lines[lines.length -1].trim()
	}
	
	public void setUpFilesForTest(String path, List files) {
		files.each { fileName ->
			def fullPath = path + "/" + fileName
			def file = new File(fullPath)
			
			if (!file.exists()) {
				throw new IOException(fullPath + "is missing")
			}
			
			//create fresh writable version called test_<filename>
			def newFileName = "test_" + fileName
			def newFullPath = path + "/" + newFileName
			def newFile = new File(newFullPath)
			
			if (newFile.exists()) {
				newFile.delete()
			}
			
			newFile.createNewFile()
			newFile.setText(file.text)
		}
	}
}