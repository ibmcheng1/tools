package com.fanniemae.ucd.aws.deploy.test

//import static org.junit.jupiter.api.Assertions.*
import static org.junit.Assert.*;
import com.fanniemae.ucd.aws.deploy.*;
import com.fanniemae.ucd.config.test.*;
import org.junit.Before;
import org.junit.Test;
import java.util.*;
import com.ibm.issr.core.log.Logger

public class AwsDeployerTest {
	MockUcd ucdConfig = new MockUcd();
	ConfigHelper configHelper = new ConfigHelper();
	List<String> writableFiles = new ArrayList<String>();
	AwsDeployer awsDeployer;
	
	/*
	 * *****************************************************
	 * Test data:
	 * This is a list of all the data and aws resources needed for tests
	 * iam, s3, eb, ecr, cf, ecs, emr
	 * *****************************************************
	 */
	//iam and aws account
	String role = "fvq-sdbx-shrd-cp-deploy";
	String account = "243769994261";
	String appShortName = "fvq";
	
	//for s3 we need two s3 folders and two files to copy (that way can test with multiple s3 paths and files)
	String s3PathOne = "s3://fvq-sdbx-shrd-us-east-1/cp-artifacts/source";
	String s3PathTwo = "s3://fvq-sdbx-shrd-us-east-1/cp-artifacts/test"; //also used for cf package test
	String fileOne = "tmp/FVQ-eb/test2.txt";
	String fileTwo = "tmp/FVQ-eb/test.txt";
	String kmsKey = "d3afc0b9-a59d-4ec6-99ce-ac811bf40fb0";
	
	//for eb we need s3 file, eb app, eb env
	String ebApp = "fvq-eb-eb01";
	String ebEnv = "fvq-eb-eb01-eb01";
	String ebS3File = "s3://fvq-sdbx-shrd-us-east-1/cp-artifacts/source/Tomcat8.5-source.zip";
	
	//for ecr we need an artifactory image, two ecr repos and an accompanying role, and also the expected tw defender version
	String artifactoryImage = "artifactory-np.fanniemae.com/fqd-jenkins-snapshot/fzm-ecs:V3.5-fff6c311fc8eb-7";
	String ecrSourceImage = "243769994261.dkr.ecr.us-east-1.amazonaws.com/fvq/fvq01:V3.5-fff6c311fc8eb-7";
	String ecrTargetImage = ecrSourceImage; //for now just use dev one, but it's not really testing anything
	String sourceRole = role; // for now just use same one, but it's not really testing anything either, we need another ecr repo
	String imagesFileName = "images.txt";
	String defenderImage = "243769994261.dkr.ecr.us-east-1.amazonaws.com/fvq/fvq01:defender_19_07_363"; //line in images text
	String dockerCommand = "sudo /bin/docker";
	
	//for ecs/cf we need the ecs cluster and service, local files for template and parameters and the agent home (to find groovy 3)
	String ecsCluster = "fvq-ecs-01";
	String ecsService = "fzm-certification-automated-tests";
	String cfTemplate = "tmp/FVQ-ecs/test_cf-fvq-ecs.yml";
	String cfParameters = "tmp/FVQ-ecs/cf-fvq-dev-cfg.json";
	String agentHome = "/export/appl/ftxdply/ucd/agent";
	String groovy3Ver = "groovy-3.0.0-rc-1"; //groovy 3 for yaml parser that we expect to use
	
	
	/*
	 * *****************************************************
	 * Set up method that runs before each test:
	 * This resets ucd config and any local files that may have been modified
	 * *****************************************************
	 */
	@Before
	public void setUp() {
		//reset files such as cft to default state in case tests modify them
		writableFiles.add("cf-fvq-ecs.yml");
		configHelper.setUpFilesForTest("tmp/FVQ-ecs", writableFiles);
		
		//set default ucd config
		ucdConfig.setDefaultConfig();
		ucdConfig.set("iam.awsAccountId", account);
		ucdConfig.set("iam.awsRole", role);
		
		awsDeployer = new AwsDeployer();
	}
	
	/*
	 * *****************************************************
	 * Positive tests:
	 * Test that basic user scenarios are passing with correct input
	 * AWS Services: s3, eb, ecr, cf, ecs, emr
	 * *****************************************************
	 */
	//**************
	//s3 tests
	//**************
	//test s3 deploy can copy multiple files to multiple s3 buckets
	@Test(expected = Test.None.class /* no exception expected */)
	public void testS3Passes() {
		Logger.info "======================"
		Logger.info "Executing testcase [testS3Passes]"
		//given configuration for copying multiple files
		ucdConfig.set("s3.deploy", "true");
		ucdConfig.set("s3.s3Files", "<beginProp>" + fileOne + ":" + s3PathOne + "\n" + fileTwo + ":" + s3PathTwo + "<endProp>");
		ucdConfig.set("s3.kmsKey", kmsKey);
		
		//when we deploy
		awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		
		//then it doesn't return any exception
	}
	
	//test s3 deploy can do clean deploy
	@Test(expected = Test.None.class /* no exception expected */)
	public void testS3WithCleanDeployPasses() {
		Logger.info "======================"
		Logger.info "Executing testcase [testS3WithCleanDeployPasses]"
		//given configuration for copying and doing clean deploy
		ucdConfig.set("s3.deploy", "true");
		ucdConfig.set("s3.s3Files", "<beginProp>" + fileTwo + ":" + s3PathTwo + ":cleandeploy" + "<endProp>");
		ucdConfig.set("s3.kmsKey", kmsKey);
		
		//when we deploy
		awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		
		//then it doesn't return any exception
	}
	
	//**************
	//eb tests
	//**************
	//test eb deploy passes with correct config
	@Test(expected = Test.None.class /* no exception expected */)
	public void testEbPasses() {
		Logger.info "======================"
		Logger.info "Executing testcase [testEbPasses]"
		//given correct configuration for eb
		ucdConfig.set("eb.deploy", "true");
		ucdConfig.set("eb.application", ebApp);
		ucdConfig.set("eb.environment", ebEnv);
		ucdConfig.set("eb.s3Location", ebS3File);
		
		//when we deploy
		awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		
		//then it doesn't return any exception
	}
	
	//**************
	//ecr tests
	//**************
	//test ecr promote from artifactory to ecr passes with correct config
	@Test(expected = Test.None.class /* no exception expected */)
	public void testEcrWithArtifactoryPasses() {
		Logger.info "======================"
		Logger.info "Executing testcase [testEcrWithArtifactoryPasses]"
		//given correct input in images.txt and correct ucd config for artifactory promote
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText(artifactoryImage, ecrTargetImage);
		
		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ApplicationShortName", appShortName);
		ucdConfig.set("ecr.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("app.artifactory", "true");
		
		//when we deploy
		awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		
		//then it doesn't return any exception
	}
	
	//test ecr deploy from prior env ecr passes with correct config
	@Test(expected = Test.None.class /* no exception expected */)
	public void testEcrHigherEnvPasses() {
		Logger.info "======================"
		Logger.info "Executing testcase [testEcrHigherEnvPasses]"
		//given correct input in images.txt and correct ucd config for ecr promote
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText(ecrSourceImage, ecrTargetImage);
		
		ucdConfig.set("getParameters.priorEnvRole", sourceRole);
		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ApplicationShortName", appShortName);
		ucdConfig.set("ecr.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("environment.envType", "TEST"); //need to test this scenario when higher than dev
		
		//when we deploy
		awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		
		//then it doesn't return any exception
	}
	
	//test ecr step to dev passes with correct config
	@Test(expected = Test.None.class /* no exception expected */)
	public void testEcrLowerEnvPasses() {
		Logger.info "======================"
		Logger.info "Executing testcase [testEcrLowerEnvPasses]"
		//given correct input for ecr step in dev
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText(ecrSourceImage, ecrSourceImage);

		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ApplicationShortName", appShortName);
		ucdConfig.set("ecr.deploy", "true"); //normally would be set in Cf-Validate step
		
		//when we deploy
		awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		
		//then it doesn't return any exception
	}
	
	//test ecr step with no app short name passes with correct config
	@Test(expected = Test.None.class /* no exception expected */)
	public void testEcrWithNoAppShortNamePasses() {
		Logger.info "======================"
		Logger.info "Executing testcase [testEcrWithNoAppShortNamePasses]"
		//given correct input but without app short name
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText(ecrSourceImage, ecrSourceImage);

		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("ecr.deploy", "true"); //normally would be set in Cf-Validate step
		
		//when we deploy
		awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		
		//then it doesn't return any exception
	}
	
	//test ecr step adds the defender image to images file
	@Test
	public void testEcrAddsDefender() {
		Logger.info "======================"
		Logger.info "Executing testcase [testEcrAddsDefender]"
		//given correct input for ecr step
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText(ecrSourceImage, ecrSourceImage);
		
		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ApplicationShortName", appShortName);
		ucdConfig.set("ecr.deploy", "true"); //normally would be set in Cf-Validate step
		
		//when we deploy
		awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		
		//then it should add the defender as last line in defender image
		assertEquals(configHelper.getLastImage(), "," + defenderImage);
	}
	
	//**************
	//cf tests
	//**************
	//test cf/ecs deploy passes with correct config (this assumes images are already in ecr)
	@Test(expected = Test.None.class /* no exception expected */)
	public void testCfAndEcsPasses() {
		Logger.info "======================"
		Logger.info "Executing testcase [testCfAndEcsPasses]"
		//given correct config for cf and ecs
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText("", ecrTargetImage);
		configHelper.appendToImagesText("", defenderImage);
		
		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ClusterName", ecsCluster);
		ucdConfig.set("getParameters.ServiceName", ecsService);
//		ucdConfig.set("ecs.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("ecs.enforceTwistlock", "true");
		ucdConfig.set("cf.deploy", "true");
		ucdConfig.set("cf.parametersJson", cfParameters);
		ucdConfig.set("cf.cloudformationTemplate", cfTemplate);
		ucdConfig.set("agent.agentHome", agentHome);
		
		//when we deploy
		awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		
		//then it doesn't return any exception
	}
	
	//test cf/ecs deploy passes with correct config with package step (this assumes images are already in ecr)
	@Test(expected = Test.None.class /* no exception expected */)
	public void testCfWithPackagePasses() {
		Logger.info "======================"
		Logger.info "Executing testcase [testCfWithPackagePasses]"
		//given correct config for cf and ecs with package step (includes cf.cftS3Location)
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText("", ecrTargetImage);
		configHelper.appendToImagesText("", defenderImage);

		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ClusterName", ecsCluster);
		ucdConfig.set("getParameters.ServiceName", ecsService);
//		ucdConfig.set("ecs.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("ecs.enforceTwistlock", "true");
		ucdConfig.set("cf.deploy", "true");
		ucdConfig.set("cf.parametersJson", cfParameters);
		ucdConfig.set("cf.cloudformationTemplate", cfTemplate);
		ucdConfig.set("agent.agentHome", agentHome);
		ucdConfig.set("cf.cftS3Location", s3PathTwo);
		ucdConfig.set("s3.kmsKey", kmsKey);
		
		//when we deploy
		awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		
		//then it doesn't return any exception
	}
	
	//test cf deploy when cf.changeSet set to Preview )
	@Test(expected = Test.None.class /* no exception expected */)
	public void testCfPreviewChangeSet() {
		Logger.info "======================"
		Logger.info "Executing testcase [testCfPreviewChangeSet]"
		//given correct config for cf and ecs with package step (includes cf.cftS3Location)
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText("", ecrTargetImage);
		configHelper.appendToImagesText("", defenderImage);

		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ClusterName", ecsCluster);
		ucdConfig.set("getParameters.ServiceName", ecsService);
//		ucdConfig.set("ecs.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("ecs.enforceTwistlock", "true");
		ucdConfig.set("cf.deploy", "true");
		ucdConfig.set("cf.parametersJson", cfParameters);
		ucdConfig.set("cf.cloudformationTemplate", cfTemplate);
		ucdConfig.set("agent.agentHome", agentHome);
		ucdConfig.set("cf.cftS3Location", s3PathTwo);
		ucdConfig.set("s3.kmsKey", kmsKey);
		
		ucdConfig.set("cf.changeSet", "Preview")
		
		//when we deploy
		awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		
		//then it doesn't return any exception
	}
	
	//test cf deploy when cf.changeSet set to Preview )
	@Test(expected = Test.None.class /* no exception expected */)
	public void testCfExecuteChangeSet() {
		Logger.info "======================"
		Logger.info "Executing testcase [testCfExecuteChangeSet]"
		//given correct config for cf and ecs with package step (includes cf.cftS3Location)
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText("", ecrTargetImage);
		configHelper.appendToImagesText("", defenderImage);

		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ClusterName", ecsCluster);
		ucdConfig.set("getParameters.ServiceName", ecsService);
//		ucdConfig.set("ecs.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("ecs.enforceTwistlock", "true");
		ucdConfig.set("cf.deploy", "true");
		ucdConfig.set("cf.parametersJson", cfParameters);
		ucdConfig.set("cf.cloudformationTemplate", cfTemplate);
		ucdConfig.set("agent.agentHome", agentHome);
		ucdConfig.set("cf.cftS3Location", s3PathTwo);
		ucdConfig.set("s3.kmsKey", kmsKey);
		
		ucdConfig.set("cf.changeSet", "Execute")
		
		//when we deploy
		awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		
		//then it doesn't return any exception
	}

	//test cf deploy passes with commonTags set and customTagsJsonFile set)
	@Test(expected = Test.None.class /* no exception expected */)
	public void testCfCommonCustomTags() {
		Logger.info "======================"
		Logger.info "Executing testcase [testCfCommonCustomTags]"
		//given correct config for cf and ecs with package step (includes cf.cftS3Location)
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText("", ecrTargetImage);
		configHelper.appendToImagesText("", defenderImage);

		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ClusterName", ecsCluster);
		ucdConfig.set("getParameters.ServiceName", ecsService);
//		ucdConfig.set("ecs.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("ecs.enforceTwistlock", "true");
		ucdConfig.set("cf.deploy", "true");
		ucdConfig.set("cf.parametersJson", cfParameters);
		ucdConfig.set("cf.cloudformationTemplate", cfTemplate);
		ucdConfig.set("agent.agentHome", agentHome);
		ucdConfig.set("cf.cftS3Location", s3PathTwo);
		ucdConfig.set("s3.kmsKey", kmsKey);
		
		ucdConfig.set("cf.changeSet", "") // default is Execute
		ucdConfig.set("cf.customTagsJsonFile", "tmp/FVQ-ecs/customTagsTest.json")

		//when we deploy
		awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		
		//then it doesn't return any exception
	}

	//**************
	//ecs tests
	//**************
	
	//**************
	//emr tests
	//**************
	
	/*
	 * *****************************************************
	 * Negative tests:
	 * Test that different invalid inputs return expected error message
	 * AWS Services: s3, eb, ecr, cf, ecs, emr
	 * *****************************************************
	 */
	//**************
	//s3 tests
	//**************
	//test s3 deploy fails with invalid role
	@Test
	public void testS3FailsWithInvalidRole() {
		String fakeRole = "fake-role";
		String expectedError = "ERROR: Failed to assume the role: " + fakeRole;
		String error = "";
		
		Logger.info "======================"
		Logger.info "Executing testcase [testS3FailsWithInvalidRole]"
		//given otherwise valid s3 config
		ucdConfig.set("s3.deploy", "true");
		ucdConfig.set("s3.s3Files", "<beginProp>" + fileTwo + ":" + s3PathTwo + "<endProp>");
		ucdConfig.set("s3.kmsKey", kmsKey);
		
		//when we have invalid role
		ucdConfig.set("iam.awsRole", fakeRole);
		try {
			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		} catch(Exception e) {
			error = e.getMessage();
		}
		
		//then we get the expected error
		assertEquals(expectedError, error);
	}
	
	//test s3 deploy fails with invalid file line format
	@Test
	public void testS3FailsWithInvalidFormat() {
		String invalidLine = "invalid-path"; //this one fails because it is missing a colon and s3 path
		String expectedError = invalidLine + " line is invalid in fileNames property. Needs to be in this format: <sourceFile>:s3://<bucket>/<path>";
		String error = "";
		
		Logger.info "======================"
		Logger.info "Executing testcase [testS3FailsWithInvalidFormat]"
		//given otherwise valid s3 config
		ucdConfig.set("s3.deploy", "true");
		ucdConfig.set("s3.kmsKey", kmsKey);
		
		//when we have invalid s3 files line
		ucdConfig.set("s3.s3Files", "<beginProp>" + invalidLine + "<endProp>");
		try {
			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		} catch(Exception e) {
			error = e.getMessage();
		}
		
		//then we get the expected error
		assertEquals(expectedError, error);
	}
	
	//test s3 deploy fails with invalid s3 path
	@Test
	public void testS3FailsWithInvalids3Path() {
		String invalidS3Path = "s3://fake-path/";
		String expectedError = "Failed while copying " + fileTwo + " to " + invalidS3Path;
		String error = "";
		
		Logger.info "======================"
		Logger.info "Executing testcase [testS3FailsWithInvalids3Path]"
		//given otherwise valid s3 config
		ucdConfig.set("s3.deploy", "true");
		ucdConfig.set("s3.kmsKey", kmsKey);
		
		//when we have invalid s3 path
		ucdConfig.set("s3.s3Files", "<beginProp>" + fileTwo + ":" + invalidS3Path + "<endProp>");
		try {
			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		} catch(Exception e) {
			error = e.getMessage();
		}
		
		//then we get the expected error
		assertEquals(expectedError, error);
	}
	
	//**************
	//eb tests
	//**************
	//test eb deploy fails as expected with invalid role
	@Test
	public void testEbFailsWithInvalidRole() {
		String fakeRole = "fake-role";
		String expectedError = "ERROR: Failed to assume the role: " + fakeRole;
		String error = "";
		
		Logger.info "======================"
		Logger.info "Executing testcase [testEbFailsWithInvalidRole]"
		//given otherwise correct configuration for eb
		ucdConfig.set("eb.deploy", "true");
		ucdConfig.set("eb.application", ebApp);
		ucdConfig.set("eb.environment", ebEnv);
		ucdConfig.set("eb.s3Location", ebS3File);
		
		//when we deploy with an invalid role
		ucdConfig.set("iam.awsRole", fakeRole);
		try {
			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		} catch(Exception e) {
			error = e.getMessage();
		}
		
		//then we get the expected error
		assertEquals(expectedError, error);
	}
	
	
	//test eb deploy fails as expected with invalid app
	@Test
	public void testEbFailsWithInvalidApp() {
		String fakeApp = "fake-app";
		String expectedError = "ERROR: Can't find application: " + fakeApp;
		String error = "";
		
		Logger.info "======================"
		Logger.info "Executing testcase [testEbFailsWithInvalidApp]"
		//given otherwise correct configuration for eb
		ucdConfig.set("eb.deploy", "true");
		ucdConfig.set("eb.environment", ebEnv);
		ucdConfig.set("eb.s3Location", ebS3File);
		
		//when we deploy with an invalid eb app
		ucdConfig.set("eb.application", fakeApp);
		try {
			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		} catch(Exception e) {
			error = e.getMessage();
		}
		
		//then we get the expected error
		assertEquals(expectedError, error);
	}
	
	//test eb deploy fails as expected with invalid env
	@Test
	public void testEbFailsWithInvalidEnv() {
		String fakeEnv = "fake-env";
		String expectedError = "ERROR: Can't find environment: " + fakeEnv;
		String error = "";
		
		Logger.info "======================"
		Logger.info "Executing testcase [testEbFailsWithInvalidEnv]"
		//given otherwise correct configuration for eb
		ucdConfig.set("eb.deploy", "true");
		ucdConfig.set("eb.application", ebApp);
		ucdConfig.set("eb.s3Location", ebS3File);
		
		//when we deploy with an invalid eb env
		ucdConfig.set("eb.environment", fakeEnv);
		try {
			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		} catch(Exception e) {
			error = e.getMessage();
		}
		
		//then we get the expected error
		assertEquals(expectedError, error);
	}
	
	//test eb deploy fails as expected with invalid s3 file
	@Test
	public void testEbFailsWithInvalidS3File() {
		String fakeS3File = "fake-s3";
		String expectedError = "ERROR: Can't find the S3 Location: " + fakeS3File;
		String error = "";
		
		Logger.info "======================"
		Logger.info "Executing testcase [testEbFailsWithInvalidS3File]"
		//given otherwise correct configuration for eb
		ucdConfig.set("eb.deploy", "true");
		ucdConfig.set("eb.application", ebApp);
		ucdConfig.set("eb.environment", ebEnv);
		
		//when we deploy with an invalid s3 file
		ucdConfig.set("eb.s3Location", fakeS3File);
		try {
			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		} catch(Exception e) {
			error = e.getMessage();
		}
		
		//then we get the expected error
		assertEquals(expectedError, error);
	}
	
	//**************
	//ecr tests
	//**************
	//test ecr step fails as expected with image file that doesn't exist
	@Test
	public void testEcrFailsWithNoImageFile() {
		String invalidImagesFileName = "fake-images.txt";
		String expectedError = invalidImagesFileName + " wasn't created properly in getParameters step";
		String error = "";
		
		Logger.info "======================"
		Logger.info "Executing testcase [testEcrFailsWithNoImageFile]"
		//given otherwise correct input for ecr step
		ucdConfig.set("getParameters.ApplicationShortName", appShortName);
		ucdConfig.set("ecr.deploy", "true"); //normally would be set in Cf-Validate step
		
		//when we deploy with an invalid image file
		ucdConfig.set("getParameters.containerImagesFile", invalidImagesFileName);
		try {
			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		} catch(Exception e) {
			error = e.getMessage();
		}
		 
		//then we get the expected error
		assertEquals(expectedError, error);
	}
	
	//test ecr step fails as expected with empty image file
	@Test
	public void testEcrFailsWithNoEmptyFile() {
		String expectedError = imagesFileName + " is empty";
		String error = "";
		
		Logger.info "======================"
		Logger.info "Executing testcase [testEcrFailsWithNoEmptyFile]"
		//given otherwise correct input for ecr step
		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ApplicationShortName", appShortName);
		ucdConfig.set("ecr.deploy", "true"); //normally would be set in Cf-Validate step
		
		//when we deploy with an empty image file
		configHelper.setUpImagesText(imagesFileName); //this makes it empty
		try {
			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		} catch(Exception e) {
			error = e.getMessage();
		}
		 
		//then we get the expected error
		assertEquals(expectedError, error);
	}
	
	//test ecr step fails as expected with invalid source role
	@Test
	public void testEcrFailsWithInvalidSourceRole() {
		String fakeRole = "fake-role";
		String expectedError = "ERROR: Failed to assume the role: " + fakeRole;
		String error = "";
		
		Logger.info "======================"
		Logger.info "Executing testcase [testEcrFailsWithInvalidSourceRole]"
		//given otherwise valid config for ecr promote to higher env
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText(ecrSourceImage, ecrTargetImage);
		
		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ApplicationShortName", appShortName);
		ucdConfig.set("ecr.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("environment.envType", "TEST"); //need to test this scenario when higher than dev
		
		//when we deploy with an invalid source role
		ucdConfig.set("getParameters.priorEnvRole", fakeRole);
		try {
			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		} catch(Exception e) {
			error = e.getMessage();
		}
		 
		//then we get the expected error
		assertEquals(expectedError, error);
	}
	
	//test ecr step fails as expected with invalid target role
	@Test
	public void testEcrFailsWithInvalidTargetRole() {
		String fakeRole = "fake-role";
		String expectedError = "ERROR: Failed to assume the role: " + fakeRole;
		String error = "";
		
		Logger.info "======================"
		Logger.info "Executing testcase [testEcrFailsWithInvalidTargetRole]"
		//given otherwise valid config for ecr promote to higher env
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText(ecrSourceImage, ecrTargetImage);
		
		ucdConfig.set("getParameters.priorEnvRole", sourceRole);
		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ApplicationShortName", appShortName);
		ucdConfig.set("ecr.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("environment.envType", "TEST"); //need to test this scenario when higher than dev
		
		//when we deploy with an invalid target role
		ucdConfig.set("iam.awsRole", fakeRole);
		try {
			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		} catch(Exception e) {
			error = e.getMessage();
		}
		 
		//then we get the expected error
		assertEquals(expectedError, error);
	}
	
	//test ecr step fails as expected with invalid artifactory path
	@Test
	public void testEcrFailsWithInvalidArtifactory() {
		String invalidArtifactory = "fake-path";
		String expectedError = "Failed while running: " + dockerCommand + " pull " + invalidArtifactory;
		String error = "";
		
		Logger.info "======================"
		Logger.info "Executing testcase [testEcrFailsWithInvalidArtifactory]"
		//given otherwise correct config for ecr promote from artifactory
		configHelper.setUpImagesText(imagesFileName);
		
		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ApplicationShortName", appShortName);
		ucdConfig.set("ecr.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("app.artifactory", "true");
		
		//when we deploy with an invalid artifactory path
		configHelper.appendToImagesText(invalidArtifactory, ecrTargetImage);
		try {
			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		} catch(Exception e) {
			error = e.getMessage();
		}
		 
		//then we get the expected error
		assertEquals(expectedError, error);
	}
	
	//test ecr step fails as expected with invalid source ecr path
	@Test
	public void testEcrFailsWithInvalidSourceEcr() {
		String invalidEcrRepo = "ecr/fake-repo";
		String invalidImage = "fake-image";
		String invalidEcr = invalidEcrRepo + ":" + invalidImage;
		String expectedError = "Can't find image " + invalidImage + " in " + invalidEcrRepo;
		String error = "";
		
		Logger.info "======================"
		Logger.info "Executing testcase [testEcrFailsWithInvalidSourceEcr]"
		//given otherwise valid config for ecr promote to higher env
		configHelper.setUpImagesText(imagesFileName);
		
		ucdConfig.set("getParameters.priorEnvRole", sourceRole);
		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ApplicationShortName", appShortName);
		ucdConfig.set("ecr.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("environment.envType", "TEST"); //need to test this scenario when higher than dev
		
		//when we deploy with an invalid source ecr path
		configHelper.appendToImagesText(invalidEcr, ecrTargetImage);
		try {
			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		} catch(Exception e) {
			error = e.getMessage();
		}
		 
		//then we get the expected error
		assertEquals(expectedError, error);
	}
	
	//test ecr step fails as expected with invalid target ecr path
	@Test
	public void testEcrFailsWithInvalidTargetEcr() {
		String invalidEcrRepo = "ecr/fake-repo";
		String invalidImage = "fake-image";
		String invalidEcr = invalidEcrRepo + ":" + invalidImage;
		String expectedError = "Failed while running: " + dockerCommand + " push " + invalidEcrRepo + ":latest"; //for now latest gets pushed first
		String error = "";
		
		Logger.info "======================"
		Logger.info "Executing testcase [testEcrFailsWithInvalidTargetEcr]"
		//given otherwise valid config for ecr promote to higher env
		configHelper.setUpImagesText(imagesFileName);
		
		ucdConfig.set("getParameters.priorEnvRole", sourceRole);
		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ApplicationShortName", appShortName);
		ucdConfig.set("ecr.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("environment.envType", "TEST"); //need to test this scenario when higher than dev
		
		//when we deploy with an invalid target ecr path
		configHelper.appendToImagesText(ecrSourceImage, invalidEcr);
		try {
			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		} catch(Exception e) {
			error = e.getMessage();
		}
		 
		//then we get the expected error
		assertEquals(expectedError, error);
	}
	
	//**************
	//cf tests
	//**************
	//test cf/ecs fails when groovy 3 is missing from agent
	@Test
	public void testCfAndEcsFailsWithInvalidGroovyVer() {
		String invalidAgentHome = "/appl/ftxdply/ucd-fake/agent";
		String expectedError = "ERROR: can't find groovy version needed on this agent: " + invalidAgentHome + "/opt/" + groovy3Ver;
		String error = "";
		
		Logger.info "======================"
		Logger.info "Executing testcase [testCfAndEcsFailsWithInvalidGroovyVer]"
		//given otherwise correct config for cf and ecs
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText("", ecrTargetImage);
		configHelper.appendToImagesText("", defenderImage);
		
		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ClusterName", ecsCluster);
		ucdConfig.set("getParameters.ServiceName", ecsService);
//		ucdConfig.set("ecs.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("ecs.enforceTwistlock", "true");
		ucdConfig.set("cf.deploy", "true");
		ucdConfig.set("cf.parametersJson", cfParameters);
		ucdConfig.set("cf.cloudformationTemplate", cfTemplate);
		
		//when we deploy with invalid agent home
		ucdConfig.set("agent.agentHome", invalidAgentHome);
		try {
			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		} catch(Exception e) {
			error = e.getMessage();
		}
		 
		//then we get the expected error
		assertEquals(expectedError, error);
	}
	
	//test cf/ecs fails with invalid role
	@Test
	public void testCfAndEcsFailsWithInvalidRole() {
		String fakeRole = "fake-role";
		String expectedError = "ERROR: Failed to assume the role: " + fakeRole;
		String error = "";
		
		Logger.info "======================"
		Logger.info "Executing testcase [testCfAndEcsFailsWithInvalidRole]"
		//given otherwise correct config for cf and ecs
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText("", ecrTargetImage);
		configHelper.appendToImagesText("", defenderImage);
		
		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ClusterName", ecsCluster);
		ucdConfig.set("getParameters.ServiceName", ecsService);
//		ucdConfig.set("ecs.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("ecs.enforceTwistlock", "true");
		ucdConfig.set("cf.deploy", "true");
		ucdConfig.set("cf.parametersJson", cfParameters);
		ucdConfig.set("cf.cloudformationTemplate", cfTemplate);
		ucdConfig.set("agent.agentHome", agentHome);
		
		//when we deploy with invalid role
		ucdConfig.set("iam.awsRole", fakeRole);
		try {
			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		} catch(Exception e) {
			error = e.getMessage();
		}
		 
		//then we get the expected error
		assertEquals(expectedError, error);
	}
	
	//test cf/ecs fails with invalid parameter file
	@Test
	public void testCfAndEcsFailsWithInvalidParameterFile() {
		String fakeParameterFile = "fake-parameters.json";
		String expectedError = "Can't find parameters json file";
		String error = "";
		
		Logger.info "======================"
		Logger.info "Executing testcase [testCfAndEcsFailsWithInvalidParameterFile]"
		//given otherwise correct config for cf and ecs
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText("", ecrTargetImage);
		configHelper.appendToImagesText("", defenderImage);
		
		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ClusterName", ecsCluster);
		ucdConfig.set("getParameters.ServiceName", ecsService);
//		ucdConfig.set("ecs.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("ecs.enforceTwistlock", "true");
		ucdConfig.set("cf.deploy", "true");
		ucdConfig.set("cf.cloudformationTemplate", cfTemplate);
		ucdConfig.set("agent.agentHome", agentHome);
		
		//when we deploy with invalid parameters
		ucdConfig.set("cf.parametersJson", fakeParameterFile);
		try {
			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		} catch(Exception e) {
			error = e.getMessage();
		}
		 
		//then we get the expected error
		assertEquals(expectedError, error);
	}
	
	//test cf/ecs fails with invalid cf template yaml
	@Test
	public void testCfAndEcsFailsWithInvalidTemplateFile() {
		String fakeTemplateFile = "fake-template.yaml";
		String expectedError = "Can't find cloudformation template yaml file";
		String error = "";
		
		Logger.info "======================"
		Logger.info "Executing testcase [testCfAndEcsFailsWithInvalidTemplateFile]"
		//given otherwise correct config for cf and ecs
		configHelper.setUpImagesText(imagesFileName);
		configHelper.appendToImagesText("", ecrTargetImage);
		configHelper.appendToImagesText("", defenderImage);
		
		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
		ucdConfig.set("getParameters.ClusterName", ecsCluster);
		ucdConfig.set("getParameters.ServiceName", ecsService);
//		ucdConfig.set("ecs.deploy", "true"); //normally would be set in Cf-Validate step
		ucdConfig.set("ecs.enforceTwistlock", "true");
		ucdConfig.set("cf.deploy", "true");
		ucdConfig.set("cf.parametersJson", cfParameters);
		ucdConfig.set("agent.agentHome", agentHome);
		
		//when we deploy with invalid cf template
		ucdConfig.set("cf.cloudformationTemplate", fakeTemplateFile);
		try {
			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
		} catch(Exception e) {
			error = e.getMessage();
		}
		 
		//then we get the expected error
		assertEquals(expectedError, error);
	}
	
//	//test cf/ecs fails with invalid s3 path
//	@Test
//	public void testCfAndEcsFailsWithInvalidS3Path() {
//		String fakeS3Path = "s3://fake-s3";
//		String expectedError = "Failed while running: aws s3 cp new" + cfTemplate + " " + fakeS3Path + " --sse aws:kms --sse-kms-key-id " + kmsKey;
//		String error = "";
//
//		//given otherwise correct config for cf and ecs
//		configHelper.setUpImagesText(imagesFileName);
//		configHelper.appendToImagesText("", ecrTargetImage);
//		configHelper.appendToImagesText("", defenderImage);
//
//		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
//		ucdConfig.set("getParameters.ClusterName", ecsCluster);
//		ucdConfig.set("getParameters.ServiceName", ecsService);
//		ucdConfig.set("ecs.deploy", "true"); //normally would be set in Cf-Validate step
//		ucdConfig.set("cf.deploy", "true");
//		ucdConfig.set("cf.parametersJson", cfParameters);
//		ucdConfig.set("cf.cloudformationTemplate", cfTemplate);
//		ucdConfig.set("agent.agentHome", agentHome);
//		ucdConfig.set("s3.kmsKey", kmsKey);
//
//		//when we deploy with invalid cf s3 location
//		ucdConfig.set("cf.cftS3Location", fakeS3Path);
//		try {
//			//awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
//		} catch(Exception e) {
//			error = e.getMessage();
//		}
//
//		//then we get the expected error
//		assertEquals(expectedError, error);
//	}
	
	//**************
	//ecs tests
	//**************
	//test ecs verification fails with expected error message with invalid ecs service
//	@Test
//	public void testEcsFailsWithInvalidService() {
//		String fakeService = "fake-service";
//		String expectedError = "Can't find service: " + fakeService;
//		String error = "";
//		
//		Logger.info "======================"
//		Logger.info "Executing testcase [testEcsFailsWithInvalidService]"
//		//given otherwise correct config for ecs verify step
//		configHelper.setUpImagesText(imagesFileName);
//		configHelper.appendToImagesText("", ecrTargetImage);
//		configHelper.appendToImagesText("", defenderImage);
//		
//		ucdConfig.set("getParameters.containerImagesFile", imagesFileName);
//		ucdConfig.set("getParameters.ClusterName", ecsCluster);
////		ucdConfig.set("ecs.deploy", "true"); //normally would be set in Cf-Validate step
//		ucdConfig.set("ecs.enforceTwistlock", "true");
//		
//		//when we deploy with invalid service
//		ucdConfig.set("getParameters.ServiceName", fakeService);
//		try {
//			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
//		} catch(Exception e) {
//			error = e.getMessage();
//		}
//		 
//		//then we get the expected error
//		assertEquals(expectedError, error);
//	}
	
	//**************
	//emr tests
	//**************
	//test emr fails with expected error message when have invalid role
//	@Test
//	public void testEmrFailsWithInvalidRole() {
//		String fakeRole = "fake-role";
//		String expectedError = "";
//		String error = "";
//
//		//given otherwise correct config for emr step
//
//
//		//when we deploy with invalid role
//		ucdConfig.set("iam.awsRole", fakeRole);
//		try {
//			awsDeployer.deploy(ucdConfig.getTargetEnv(), ucdConfig.getPropertyString(), "");
//		} catch(Exception e) {
//			error = e.getMessage();
//		}
//
//		//then we get the expected error
//		assertEquals(expectedError, error);
//	}
	
}
