#!/usr/bin/env groovy
/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* UrbanCode Build
* UrbanCode Release
* AnthillPro
* (c) Copyright IBM Corporation 2011, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/

/* ***********************************************************************************************
 * July 2019 - jennieb@us.ibm.com 
 * inspect all generic processes (type=runProcess) of the calling application process
 * The preprocess step must have run successfully
 * The postprocess step must have been run yet (since we are inspecting before the deploy process)
 * Note: in the normal process, we can't deduce the actual generic name of the postProcess step since the child process
 * hasn't been generated yet. A missing post-process will prevent promotion, so the process developer
 * will learn by sad experience if they don't use provided guidelines. 
 * **********************************************************************************************
 */
import groovy.json.*
import com.urbancode.air.AirPluginTool;
com.urbancode.air.XTrustProvider.install()

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props  = apTool.getStepProperties();

def parentId       = props['parentRequestId'];
def preProcess     = props['preProcess'];
def postProcess    = props['postProcess']; 

println "============================================================" 
println "Parent Request Id: [$parentId]"
println "Required Processes: " + preProcess + ", " + postProcess
println ""


//~~~~~~~~~~~~~~~~~~~~~~~ MAIN ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*
def resturl  = "rest/deploy/applicationProcessRequest/${parentId}"
def curlOut = execCmd(apTool,resturl,"GET")
def json = new JsonSlurper().parseText(curlOut)

Boolean preProcessRan     = false  // this needs to flip to true
Boolean postProcessRan    = false  // this needs to stay false 
// println "DEBUG: App process:"
// println JsonOutput.prettyPrint(curlOut)
json.rootTrace.children.each { step ->
     //println "DEBUG: step: [$step]"
     def id      = step.childRequestId  // id is the object not the process
     def type    = step.type
     def display = step.displayName 
      // inspect each of the application processes' child generic process that has already run 
     if (type.equals("runProcess") && id != null) {  
         def childResturl  =  "rest/process/request/${id}"
         def childCurlOut  = execCmd(apTool,childResturl,"GET")
         def childJson     = new JsonSlurper().parseText(childCurlOut)
         def processName   = childJson?.process?.name
         def processStatus = childJson?.result
         println "**************************************************************************"
         println "Found Generic Process [$processName] with status [$processStatus]"
         if ( processName.equals(preProcess)) { 
               preProcessRan = true
            if (!processStatus.equals("SUCCEEDED") ) {
                println "Expecting [SUCCEEDED] but found [$processStatus]"
				println "ERROR: Pre-Deploy must be run successfully before any deployment processes"
                println "Please update your application process and try again"
				apTool.outProps.put('setFail','true') 
               }
	        }
        if ( processName.equals(postProcess) ) {
            postProcessRan = true
            println "ERROR: Post-Deploy Step has run before the deployment" 
            println "Post-Deploy Update must be the last step in the application process"
            println "Please update your application process and try again"
			apTool.outProps.put('setFail','true') 
             }
         println "**************************************************************************"
       }//if runProcess
} //each step

// Pre-Process Validation never ran
if (!preProcessRan) {
        println "**************************************************************************"
        println "ERROR: Pre-Deploy Validation Step must be run before the deployment" 
        println "Please update your application process and try again"
		println "**************************************************************************"

		apTool.outProps.put('setFail','true') 
		}
		
apTool.setOutputProperties()		  
System.exit(0)

//~~~~~~~~~~~~~~~~~~~~~~~~~~ DEBUG ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
//uncomment to print the app process tree
//println "Parent Process Info:"
//println JsonOutput.prettyPrint(curlOut)



//===========================================================================================
def execCmd(apTool,cmd,flag) {
   def method = "execCmd($apTool,$cmd,$flag)"
   def udUser = apTool.getAuthTokenUsername()  //PasswordIsAuthToken
   def udPass = apTool.getAuthToken()          //generated temporary token but in form ["token":"****"}]
   def udPassParsed = udPass.split(":")[1].split('"')[1]   // remove trailing slash
   
   def weburl = System.getenv("AH_WEB_URL")
   def msg         // error msg
   def udHost      = "${weburl}".split('https://')[1].replaceAll("/","")   //  ucdeploytest:8443 
   def curlString  = "https://${udUser}:${udPassParsed}@${udHost}/${cmd}"
      try {
        def proc=["curl", "-k","-s","-X","${flag}","${curlString}"].execute()
        def outputStream = new StringBuffer()
         proc.waitForProcessOutput(outputStream, System.err)
         def output = outputStream.toString().trim()
		 // println "DEBUG output: [$output]"
	     return output
		
    } catch (Exception e) { 
        setFailure(method,output)	
        }
} //execCmd

//******************************************************************************

def setFailure(method,msg) {
   println """
=============================================================================
ERROR on method call: [$method]
${msg}
=============================================================================
   """
    System.exit(1)
   }   
