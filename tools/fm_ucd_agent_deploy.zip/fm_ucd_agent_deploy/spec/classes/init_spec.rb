require 'spec_helper'
describe 'fm_ucd_agent_deploy' do
  context 'with default values for all parameters' do
    it { should contain_class('fm_ucd_agent_deploy') }
  end
end
