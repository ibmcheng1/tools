# Fact: ucd_agent_config
#
# Purpose: If UCD agent is installed, return all the configuration information.
#
# Caveats:
#

Facter.add(:ucd_agent_config) do
  confine :kernel => 'Linux'
  confine :ucd_agent_installed => true
  setcode do
    begin
      ver_info = Facter::Core::Execution.exec("cat /export/appl/ftxdply/agent/conf/installed_version")
      ver_info.split(/=/).last unless ver_info.empty?
    rescue Exception => e
      puts "Error occured evaluating fact ucd_agent_config"
      puts e.message
    end
  end
end
