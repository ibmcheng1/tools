# Fact: ucd_agent_installed
#
# Purpose: If UCD agent is installed, return true.
#
# Caveats:
#

Facter.add(:ucd_agent_installed) do
  confine :kernel => 'Linux'
  setcode do
    File.exist?('/export/appl/ftxdply/agent/bin/agent')
  end
end
