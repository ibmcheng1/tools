#!/usr/bin/env groovy
/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* UrbanCode Build
* UrbanCode Release
* AnthillPro
* (c) Copyright IBM Corporation 2011, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/

// Jan 2019 - jennieb@us.ibm.com
// Based on UrbanCode Deploy Version Plugin  66.972887
// restrict status to role-based ownership; 
// use this plugin to allow status to be added via process flow, but not directly by users

import com.urbancode.air.AirPluginTool;
import com.urbancode.ud.client.ComponentClient;

def apTool = new AirPluginTool(this.args[0], this.args[1]);

def props = apTool.getStepProperties();

def udUser = apTool.getAuthTokenUsername();
def udPass = apTool.getAuthToken();
def weburl = System.getenv("AH_WEB_URL");
def status = props['status'];
def componentName = props['componentName'];
def versionName   = props['versionName'];
def secUser       = props['statusOwner'];  //added
def secPass       = props['statusPass'];  //added

com.urbancode.air.XTrustProvider.install()

// instead of passthrough authentication (udUser, udPass) use secure user
// UCD needs to be configured to grant this user the secureAdmin role 

def udRestClient = new ComponentClient(new URI(weburl), secUser, secPass);

println "Adding status $status to version $versionName on component $componentName";
udRestClient.addComponentVersionStatus(componentName,versionName,status);
