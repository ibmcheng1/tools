import org.junit.jupiter.api.Test
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

class JiraJsonSample {
	// basic fields test without custom fields
	def static basicFieldsJsonStringOneLine = '''
	{"project":{"key":"ENTDTMDEV"},"issuetype":{"name":"Agile Release"},"summary":"Test creating issue summary","customfield_10049":"CHG0316805"}
    '''
	
	// modified - generated from JSON API - customfield_10044 - special String case need \\" xxx \\"
	def static customFieldJsonStringOneLine = '''
    {"customfield_10091":{"value":"No"},"customfield_10050":"2019-03-22","customfield_10051":"2019-02-21","customfield_10096":{"value":"No"},"customfield_10075":[{"name":"a03acpt"}],"customfield_10097":{"value":"Yes"},"customfield_10076":{"value":"Kanban"},"customfield_10098":{"value":"iCart"},"customfield_10099":{"value":"Git (Stash)"},"customfield_10078":{"value":"Application"},"customfield_10057":"Release R3","customfield_10104":{"value":"No"},"customfield_10049":"CHG0316805","customfield_10105":{"value":"No"},"customfield_10402":{"value":"Yes"},"customfield_10106":{"value":"No"},"customfield_10041":{"value":"HOPEX/SEAR"},"customfield_10064":{"name":"a03acpt"},"customfield_10042":{"value":"Xray for Jira with features traced to tests"},"customfield_10043":{"value":"Jira with features tagged to a specific release"},"customfield_10066":["Treasury"],"customfield_10044":{"value":"DOORS using the \\"Vison Document Template\\""},"customfield_10088":{"value":"No"},"customfield_10100":{"value":"No"},"customfield_10067":["DevOps Engineer"],"customfield_10045":{"value":"Agile Testing Document Template and Risk Assessment Matrix Template and stored in System of Record (SOR)"},"customfield_10101":{"value":"No"},"customfield_10102":{"value":"No"},"customfield_10103":{"value":"No"},"issuetype":{"name":"Agile Release"},"project":{"key":"ENTDTMDEV"},"summary":"Creating issue summary ..."}
    '''
	
	// generated from JSON API
	def static customFieldJsonStringOneLine2 = '''
    {"customfield_10091":{"value":"No"},"customfield_10050":"2019-03-22","customfield_10051":"2019-02-21","customfield_10096":{"value":"No"},"customfield_10075":[{"name":"a03acpt"}],"customfield_10097":{"value":"Yes"},"customfield_10076":{"value":"Kanban"},"customfield_10098":{"value":"iCart"},"customfield_10099":{"value":"Git (Stash)"},"customfield_10078":{"value":"Application"},"customfield_10057":"Release R3","customfield_10104":{"value":"No"},"customfield_10049":"CHG0316805","customfield_10105":{"value":"No"},"customfield_10402":{"value":"Yes"},"customfield_10106":{"value":"No"},"customfield_10041":{"value":"HOPEX/SEAR"},"customfield_10064":{"name":"a03acpt"},"customfield_10042":{"value":"Xray for Jira with features traced to tests"},"customfield_10043":{"value":"Jira with features tagged to a specific release"},"customfield_10066":["Treasury"],"customfield_10044":{"value":"DOORS using the \"Vison Document Template\""},"customfield_10088":{"value":"No"},"customfield_10100":{"value":"No"},"customfield_10067":["DevOps Engineer"],"customfield_10045":{"value":"Agile Testing Document Template and Risk Assessment Matrix Template and stored in System of Record (SOR)"},"customfield_10101":{"value":"No"},"customfield_10102":{"value":"No"},"customfield_10103":{"value":"No"},"issuetype":{"name":"Agile Release"},"project":{"key":"ENTDTMDEV"},"summary":"Creating issue summary ..."}
    '''
	
	// modified - generated from JSON API - customfield_10044
	def static customFieldJsonStringOneLineExcludingStandardField = '''
    {"customfield_10091":{"value":"No"},"customfield_10050":"2019-03-22","customfield_10051":"2019-02-21","customfield_10096":{"value":"No"},"customfield_10075":[{"name":"a03acpt"}],"customfield_10097":{"value":"Yes"},"customfield_10076":{"value":"Kanban"},"customfield_10098":{"value":"iCart"},"customfield_10099":{"value":"Git (Stash)"},"customfield_10078":{"value":"Application"},"customfield_10057":"Release R3","customfield_10104":{"value":"No"},"customfield_10049":"CHG0316805","customfield_10105":{"value":"No"},"customfield_10402":{"value":"Yes"},"customfield_10106":{"value":"No"},"customfield_10041":{"value":"HOPEX/SEAR"},"customfield_10064":{"name":"a03acpt"},"customfield_10042":{"value":"Xray for Jira with features traced to tests"},"customfield_10043":{"value":"Jira with features tagged to a specific release"},"customfield_10066":["Treasury"],"customfield_10044":{"value":"DOORS using the \\"Vison Document Template\\""},"customfield_10088":{"value":"No"},"customfield_10100":{"value":"No"},"customfield_10067":["DevOps Engineer"],"customfield_10045":{"value":"Agile Testing Document Template and Risk Assessment Matrix Template and stored in System of Record (SOR)"},"customfield_10101":{"value":"No"},"customfield_10102":{"value":"No"},"customfield_10103":{"value":"No"}}
    '''

	// generated from JSON API
	def static customFieldJsonStringOneLineExcludingStandardField2 = '''
    {"customfield_10091":{"value":"No"},"customfield_10050":"2019-03-22","customfield_10051":"2019-02-21","customfield_10096":{"value":"No"},"customfield_10075":[{"name":"a03acpt"}],"customfield_10097":{"value":"Yes"},"customfield_10076":{"value":"Kanban"},"customfield_10098":{"value":"iCart"},"customfield_10099":{"value":"Git (Stash)"},"customfield_10078":{"value":"Application"},"customfield_10057":"Release R3","customfield_10104":{"value":"No"},"customfield_10049":"CHG0316805","customfield_10105":{"value":"No"},"customfield_10402":{"value":"Yes"},"customfield_10106":{"value":"No"},"customfield_10041":{"value":"HOPEX/SEAR"},"customfield_10064":{"name":"a03acpt"},"customfield_10042":{"value":"Xray for Jira with features traced to tests"},"customfield_10043":{"value":"Jira with features tagged to a specific release"},"customfield_10066":["Treasury"],"customfield_10044":{"value":"DOORS using the \"Vison Document Template\""},"customfield_10088":{"value":"No"},"customfield_10100":{"value":"No"},"customfield_10067":["DevOps Engineer"],"customfield_10045":{"value":"Agile Testing Document Template and Risk Assessment Matrix Template and stored in System of Record (SOR)"},"customfield_10101":{"value":"No"},"customfield_10102":{"value":"No"},"customfield_10103":{"value":"No"}}
    '''
	
	def static sampleCustomFieldJsonString = '''
    {
        "project":
        {
            "key": "ENTDTMDEV"
        },
        "summary": "This is DTM create record test.",
        "issuetype":
        {
            "name": "Agile Release"
        }, 
        "customfield_10091": { "value": "No" },     
        "customfield_10050": "2019-03-22",
        "customfield_10051": "2019-02-21",
        "customfield_10096": { "value": "No" },
        "customfield_10075": [ {"name": "a03acpt" }],
        "customfield_10097": { "value": "Yes" },
        "customfield_10076": { "value": "Kanban" },
        "customfield_10098": { "value": "iCart" },
        "customfield_10099": { "value": "Git (Stash)" },
        "customfield_10078": { "value": "Application" },
        "customfield_10057": "Release R3",
        "customfield_10104": { "value": "No" },
        "customfield_10049": "CHG0316805",
        "customfield_10105": { "value": "No" },
        "customfield_10402": { "value": "Yes" },
        "customfield_10106": { "value": "No" },
        "customfield_10041": { "value": "HOPEX/SEAR" },
        "customfield_10064": { "name": "a03acpt" },
        "customfield_10042": { "value": "Xray for Jira with features traced to tests" },
        "customfield_10043": { "value": "Jira with features tagged to a specific release" },
        "customfield_10066": [ "Treasury" ],
        "customfield_10044": { "value": "DOORS using the \\"Vison Document Template\\"" },
        "customfield_10088": { "value": "No" },
        "customfield_10100": { "value": "No" },
        "customfield_10067": [ "DevOps Engineer" ],
        "customfield_10045": { "value": "Agile Testing Document Template and Risk Assessment Matrix Template and stored in System of Record (SOR)" },
        "customfield_10101": { "value": "No" },
        "customfield_10102": { "value": "No" },        
        "customfield_10103": { "value": "No" }           
    }
	'''
	
	def static sampleJsonString = '''
	{
    "fields":
    {
        "project":
        {
            "key": "ENTDTMDEV"
        },
        "summary": "This is DTM create record test.",
        "issuetype":
        {
            "name": "Agile Release"
        }, 
        "customfield_10091": { "value": "No" },     
        "customfield_10050": "2019-03-22",
        "customfield_10051": "2019-02-21",
        "customfield_10096": { "value": "No" },
        "customfield_10075": [ {"name": "a03acpt" }],
        "customfield_10097": { "value": "Yes" },
        "customfield_10076": { "value": "Kanban" },
        "customfield_10098": { "value": "iCart" },
        "customfield_10099": { "value": "Git (Stash)" },
        "customfield_10078": { "value": "Application" },
        "customfield_10057": "Release R3",
        "customfield_10104": { "value": "No" },
        "customfield_10049": "CHG0316805",
        "customfield_10105": { "value": "No" },
        "customfield_10402": { "value": "Yes" },
        "customfield_10106": { "value": "No" },
        "customfield_10041": { "value": "HOPEX/SEAR" },
        "customfield_10064": { "name": "a03acpt" },
        "customfield_10042": { "value": "Xray for Jira with features traced to tests" },
        "customfield_10043": { "value": "Jira with features tagged to a specific release" },
        "customfield_10066": [ "Treasury" ],
        "customfield_10044": { "value": "DOORS using the \\"Vison Document Template\\"" },
        "customfield_10088": { "value": "No" },
        "customfield_10100": { "value": "No" },
        "customfield_10067": [ "DevOps Engineer" ],
        "customfield_10045": { "value": "Agile Testing Document Template and Risk Assessment Matrix Template and stored in System of Record (SOR)" },
        "customfield_10101": { "value": "No" },
        "customfield_10102": { "value": "No" },        
        "customfield_10103": { "value": "No" }           
    }
	}
	'''
	
	def static  parsedSampleJson = new JsonSlurper().parseText '''
	{
    "fields":
    {
        "project":
        {
            "key": "ENTDTMDEV"
        },
        "summary": "This is DTM create record test.",
        "issuetype":
        {
            "name": "Agile Release"
        }, 
        "customfield_10091": { "value": "No" },     
        "customfield_10050": "2019-03-22",
        "customfield_10051": "2019-02-21",
        "customfield_10096": { "value": "No" },
        "customfield_10075": [ {"name": "a03acpt" }],
        "customfield_10097": { "value": "Yes" },
        "customfield_10076": { "value": "Kanban" },
        "customfield_10098": { "value": "iCart" },
        "customfield_10099": { "value": "Git (Stash)" },
        "customfield_10078": { "value": "Application" },
        "customfield_10057": "Release R3",
        "customfield_10104": { "value": "No" },
        "customfield_10049": "CHG0316805",
        "customfield_10105": { "value": "No" },
        "customfield_10402": { "value": "Yes" },
        "customfield_10106": { "value": "No" },
        "customfield_10041": { "value": "HOPEX/SEAR" },
        "customfield_10064": { "name": "a03acpt" },
        "customfield_10042": { "value": "Xray for Jira with features traced to tests" },
        "customfield_10043": { "value": "Jira with features tagged to a specific release" },
        "customfield_10066": [ "Treasury" ],
        "customfield_10044": { "value": "DOORS using the \\"Vison Document Template\\"" },
        "customfield_10088": { "value": "No" },
        "customfield_10100": { "value": "No" },
        "customfield_10067": [ "DevOps Engineer" ],
        "customfield_10045": { "value": "Agile Testing Document Template and Risk Assessment Matrix Template and stored in System of Record (SOR)" },
        "customfield_10101": { "value": "No" },
        "customfield_10102": { "value": "No" },        
        "customfield_10103": { "value": "No" }           
    }
	}
	'''

	private static def jsonFileName = 'json/createDTM-data.json' //System.getProperty("jsonFileName")
	
	private def data;
	
	private parseJSONFile(String fileName)
	{	
		println "fileName = " + fileName
		def jsonSlurper = new JsonSlurper()
		def reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName),"UTF-8"));
		data = jsonSlurper.parse(reader);
		println "parseJSONFile(): data = " + data
		
		return data
	}
	
	def get(String item)
	{
		def result = new ArrayList<String>();
		data = parseJSONFile()
		data.fields.each{result.add(it."${item}")}
		return  result
	}
	
	void processParsedJson(Object parsedJosn) {
		
		println '=============================================='
		parsedJosn.each { println it }
		println '=============================================='
		println 'parsedJosn.fields:          ' + parsedJosn.fields
		println 'parsedJosn.fields.project:  ' + parsedJosn.fields.project
		println '=============================================='
		
		def fieldMap = [:]
		fieldMap = parsedJosn.fields
		println 'fieldMap.project:             ' + fieldMap.project
		println 'fieldMap.issuetype:           ' + fieldMap.issuetype
		println 'fieldMap.customfield_10091:   ' + fieldMap.customfield_10091
		println 'fieldMap.customfield_10050:   ' + fieldMap.customfield_10050
		println 'fieldMap.customfield_10051:   ' + fieldMap.customfield_10051
		println 'fieldMap.customfield_10096:   ' + fieldMap.customfield_10096
		println 'fieldMap.customfield_10075:   ' + fieldMap.customfield_10075
		
		println '================================================='
		println 'fieldMap.size() = ' + fieldMap.size()
		println '================================================='
		fieldMap.each{ println it }
		println '=============================================='
		
		/*
		if (fieldMap != null) {
			fieldMap.each { key, value ->
				println "    key   = " + key
				println "    key class    = " + key.getClass().getName()
				println "    value = " + value
				println "    value class  = " + value.getClass().getName()
			}
		} else {
			println "fieldMap is null."
		}
		*/		
	}
	
	void processParsedCustomFieldJson(Object parsedJosn) {
		
		println '=============================================='
		parsedJosn.each { println it }
		println '=============================================='
		//println 'parsedJosn.fields:          ' + parsedJosn.fields
		//println 'parsedJosn.fields.project:  ' + parsedJosn.fields.project
		//println '=============================================='
		
		
		/*
		if (fieldMap != null) {
			fieldMap.each { key, value ->
				println "    key   = " + key
				println "    key class    = " + key.getClass().getName()
				println "    value = " + value
				println "    value class  = " + value.getClass().getName()
			}
		} else {
			println "fieldMap is null."
		}
		*/
	}
	
	
	//@Test
	void testParsedSampleJson () {
		println 'testParsedSampleJson() +++'
		processParsedJson(parsedSampleJson)
		println 'testParsedSampleJson() ---'
	}
	
	//@Test
	void testReadJsonFile () {
		println 'testReadJsonFile() +++'
		def parsedJson = this.parseJSONFile(jsonFileName)
		processParsedJson(parsedJson)
		println 'testReadJsonFile() ---'
	}
	
	//@Test
	void testSampleJsonString () {
		println 'testSampleJsonString() +++'
		def slurper = new JsonSlurper()
		def parsedJson = slurper.parseText(sampleJsonString)
		processParsedJson(parsedJson)
		println 'testSampleJsonString() ---'
	}
	
	//@Test
	void testSampleCustomFieldJsonString () {
		println 'testSampleCustomFieldJsonString() +++'
		def slurper = new JsonSlurper()
		def parsedJson = slurper.parseText(sampleCustomFieldJsonString)
		processParsedCustomFieldJson(parsedJson)
		println 'testSampleCustomFieldJsonString() ---'
	}
	
	@Test
	void testCustomFieldJsonStringOneLine () {
		println 'testCustomFieldJsonStringOneLine() +++'
		println 'customFieldJsonStringOneLine = ' + customFieldJsonStringOneLine
		def slurper = new JsonSlurper()
		def parsedJson = slurper.parseText(customFieldJsonStringOneLine)
		processParsedCustomFieldJson(parsedJson)
		println 'testCustomFieldJsonStringOneLine() ---'
	}
	
	//@Test
	void testCreateJosnProgrammatically () {
		println 'testCreateJosnProgrammatically() +++'
		// testing creating issue properties
		def projectKey = "ENTDTMDEV"
		def issueTypeName = "Agile Release"
		def summary = "Creating issue summary ..."
	
		// Create Issue as a HashMap object
		def fieldMap = [:]				
		fieldMap.put("customfield_10091", ["value": "No"])    // options
		fieldMap.put("customfield_10050", "2019-03-22")    // date
		fieldMap.put("customfield_10051", "2019-02-21")    // date
		fieldMap.put("customfield_10096", ["value": "No"])    // options
		
		fieldMap.put("customfield_10075", [["name": "a03acpt"]])    // array - "items": "user", 
		fieldMap.put("customfield_10097", ["value": "Yes"])    // options
		fieldMap.put("customfield_10076", ["value": "Kanban"])    // options
		fieldMap.put("customfield_10098", ["value": "iCart"])    // options
		
		fieldMap.put("customfield_10099", ["value": "Git (Stash)"])    // options
		fieldMap.put("customfield_10078", ["value": "Application"])    // options
		fieldMap.put("customfield_10057", "Release R3")    // string
		fieldMap.put("customfield_10104", ["value": "No"])    // options
		fieldMap.put("customfield_10049", "CHG0316805")    // string
		fieldMap.put("customfield_10105", ["value": "No"])    // options
		fieldMap.put("customfield_10402", ["value": "Yes"])    // options
		
		fieldMap.put("customfield_10106", ["value": "No"])    // options
		fieldMap.put("customfield_10041", ["value": "HOPEX/SEAR"])    // options
		fieldMap.put("customfield_10064", ["name": "a03acpt"] )    // user
		fieldMap.put("customfield_10042", ["value": "Xray for Jira with features traced to tests"])    // options
		fieldMap.put("customfield_10043", ["value": "Jira with features tagged to a specific release"])    // options
		fieldMap.put("customfield_10066", ["Treasury"])    // array
		fieldMap.put("customfield_10044", ["value": "DOORS using the \"Vison Document Template\""])    // options
		
		fieldMap.put("customfield_10088", ["value": "No"])    // options
		fieldMap.put("customfield_10100", ["value": "No"])    // options
		fieldMap.put("customfield_10067", ["DevOps Engineer"])    // array
		fieldMap.put("customfield_10045", ["value": "Agile Testing Document Template and Risk Assessment Matrix Template and stored in System of Record (SOR)"])    // options
		fieldMap.put("customfield_10101", ["value": "No"])    // options
		fieldMap.put("customfield_10102", ["value": "No"])    // options
		fieldMap.put("customfield_10103", ["value": "No"])    // options		
					
		// Add standard fields to JSON
		fieldMap.put("issuetype", ["name": issueTypeName])
		fieldMap.put("project", ["key": projectKey])
		fieldMap.put("summary", summary)
	
		def issueMap = [:]
		issueMap.put("fields",fieldMap)
	
		// Change mapping to JSON and prepare it to be sent via REST call
		JsonBuilder issueJSON = new JsonBuilder(issueMap)
		
		println '================================================='
		println 'issueMap: issueMap.size() = ' + issueMap.size()
		println '================================================='
		issueMap.each{ println it }
		println '================================================='
		println 'fieldMap: fieldMap.size() = ' + fieldMap.size()
		println '================================================='
		fieldMap.each{ println it }
		println '===================='
		
		//Map targetMap = issueMap
		Map targetMap = fieldMap
		createJsonString(targetMap)
		createJsonFile('testCreateJosnProgrammatically.json', targetMap)
		
		//println '===================='
		//def parsedJson = this.parseJSONFile('testCreateJosnProgrammatically.json')
		//processParsedJson(parsedJson)
		
		println 'testCreateJosnProgrammatically() ---'
	}
	
	void createJsonFile (String filename, Map data) {
		println 'createJsonFile() +++'

		/*
		def data = [
			name: "Foo Bar",
			year: "2018",
			timestamp: "2018-03-08T00:00:00",
			tags: [ "person", "employee"],
			grade: 3.14
		]
		*/
		 
		def json_str = JsonOutput.toJson(data)
		def json_beauty = JsonOutput.prettyPrint(json_str)
		File file = new File(filename)
		file.write(json_beauty)
		
		println 'createJsonFile() ---'
	}
	
	void createJsonString (Map data) {
		println 'createJsonString() +++'
		/*
		def data = [
			name: "Foo Bar",
			year: "2018",
			timestamp: "2018-03-08T00:00:00",
			tags: [ "person", "employee"],
			grade: 3.14
		]
		*/
		 
		def json_str = JsonOutput.toJson(data)
		println(json_str)
		 
		def json_beauty = JsonOutput.prettyPrint(json_str)
		println(json_beauty)		
		
		println 'createJsonString() ---'
	}
}
