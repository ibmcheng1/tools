import static org.junit.Assert.assertNull
import static org.junit.jupiter.api.Assertions.*
import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.dtm.FailMode
import com.urbancode.air.plugin.dtm.TextUtil
import com.urbancode.air.plugin.dtm.UCDDTMHelper
import com.urbancode.air.plugin.servicenow.UCDServiceNowHelper
import groovy.json.JsonBuilder
import groovy.json.JsonException
import groovy.json.JsonSlurper
import org.apache.http.impl.client.DefaultHttpClient
import org.junit.*
import org.junit.jupiter.api.Test

class JIRAHelperTest {	
	// Jira parameters
	def static serverUrl = "http://dlv-e9v-a002:8181/dtmtest"
	def static username = "g9ucdc"
	def static password = "Roxie_4m"
	def static proxyHost = null
	def static proxyPort = null
	def static allowInsecure = true
	
	static UCDDTMHelper dtm = null
	static DefaultHttpClient client = null
	
	// testing issue id for retrieving issue details
	def issueId = "ENTDTMDEV-4053" //"ENTDTMDEV-4040"
	
	// testing creating issue properties
	def projectKey = "ENTDTMDEV"	
	def issueTypeName = "Agile Release"
	def summary = "Creating issue summary ..."
	def issueDescription = "Creating issue description ..."
	
	def otherAllowedFields = ["project" , "summary", "issuetype"]
	
	def customFields = JiraJsonSample.customFieldJsonStringOneLine.trim() //props['customFields']?.trim()
	
	//////////////////////////////////////
	// snow parameters	
	//////////////////////////////////////
	//final def airPluginTool = new AirPluginTool(args[0], args[1])
	//final def props = airPluginTool.getStepProperties()
	
	def changeRequestId = 'CHG0316805' //props['changeRequestId']
	//def fields = props['fields']
	//println "Reading request with number ${changeRequestId}"
	//println "Fields requested in response ${fields}"
	/*
	 props.each{ key, value ->
		 println "Key = ${key}, value = ${value}"
	 }
	 */
	def snowTicketDetails = '{"end_date":"02-18-2019 05:00:00 AM","parent":"","u_shakeout_results_url":"","short_description":"UNIXSUPP PATCHING - PATCH - Nov 2018 AIX 7.1 TL5 SP3 - 7100-05-03-1846 Rollout 2018_11","work_start":"02-18-2019 01:00:00 AM","assignment_group":"UNIXSUPP PATCHING","u_jira_id":"","sys_updated_on":"02-23-2019 07:00:11 AM","type":"Normal","u_sox_relevance":null,"number":"CHG0350332","u_impacted_application":"Unix Support","urgency":"3 - Low","sys_created_on":"02-04-2019 09:17:49 AM","state":"Closed","u_expected_end_date":"","sys_created_by":"g3umkp","u_change_outcome":"Successful","start_date":"02-18-2019 01:00:00 AM","assigned_to":"Humair Junaid","cmdb_ci":"spliquid-db07alp3","u_environment":"Production","approval":"Approved","impact":"3-Moderate/Limited","u_project_id":"","active":"false","priority":"4 - Low","production_system":"false","cab_recommendation":"","expected_start":"","u_category":"Operational > Patching","work_end":"02-18-2019 04:02:18 AM","location":"","u_manager":"Vernon W Roach","cab_date":"","category":"Other"}'
	
	
	
	@BeforeClass
	public static void setUpClass() {
		// Initialize stuff once for ALL tests (run once)

		if(dtm == null) {
		    // Begin authentication steps with JIRA
		    dtm = new UCDDTMHelper()
		}
		
		if(client == null) {
			client = dtm.createClient(username, password, proxyHost, proxyPort, allowInsecure)
			println("setUpClass(): client = " + client)
		}
		
		if(client == null) {
			throw new Exception("client is null")
		}
	}

	@Before
	public void setUp() {
	  // Initialize stuff before every test (this is run twice in this example)
		println("setUp(): ")
	}
	
	//@Test
	void testGetSnowTicket () {
		/*
		UCDServiceNowHelper helper = new UCDServiceNowHelper(airPluginTool)
		def chgDetails = helper.getChangeRecord()
		if (chgDetails == null || chgDetails.toString().empty) {
			helper = null
			System.exit(1)
		}*/
		
		processSnowTicketJson(snowTicketDetails)
	}
	
	
	//@Test
	void testCreateIssue() {
		setUpClass();		
		processCustomFields();
				
		// Get the Create Issue metadata so we can determine what issue/field types are allowed
		def createIssueMeta = dtm.getCreateIssueMeta(client, serverUrl, projectKey)
		
		// createIssueMeta className: groovy.json.internal.LazyMap
		println "createIssueMeta className: " + createIssueMeta.getClass().getName()
		//println "createIssueMeta.projects = " + createIssueMeta.projects
		
		//createIssueMeta.each{ println it }
	
		// Fail if the given project is not found
		if (!createIssueMeta.projects) {
			println String.format('No project found with key "%s".', projectKey)
			System.exit(1)
		}
	
		// Fail if the given issue type is not allowed in the given project
		def metaIssueType = createIssueMeta.projects[0].issuetypes.find{it.name == issueTypeName}
		if (!metaIssueType) {
			println String.format('"%s" is not an allowed issue type in the project "%s".', issueTypeName, projectKey)
			System.exit(1)
		}
		
		//println "metaIssueType = " + metaIssueType
		
		
		// Create a list of objects representing the allowed fields [{"id": String, "name": String, "required": boolean}...]
		def allowedFields = metaIssueType.fields.collect { fieldId, fieldDef ->
			[id: fieldId, name: fieldDef.name, required: fieldDef.required]
		}
	
		println '--------------------------------'
		println "allowedFields.size() = " + allowedFields.size()
		
		println "-----------------"
		allowedFields.each { 
			// each element = java.util.LinkedHashMap
			
			//println it
			
			//println "-----------------"
			//for (Iterator i = it.entrySet().iterator(); i.hasNext();) {
			//	java.util.Map.Entry e = i.next(); // not allowed			
			//	println e.getKey() + " -> " + e.getValue()				
			//}
			 
		}
		println '--------------------------------'
		
		// Create Issue as a HashMap object
		def fieldMap = [:]
	
		// Add custom fields to JSON
		if (customFields != null) {
			customFields.each { key, value ->
				def id = allowedFields.find{
					//println 'it.name=' + it.name + ', it.id=' + it.id
					//it.name == key && it.id.startsWith('customfield_')
					it.id == key && ( it.id.startsWith('customfield_') || inOtherAllowedFields(it.id) )
				}?.id
		
				println "id = " + id
				println "    key = " + key
				println "    key class = " + key.getClass().getName()
				println "    value = " + value
				println "    value  = " + value.getClass().getName()
				println '--------------------------------'
				
				// Fail if the given custom field name is not in the list of allowed fields for this project and issue type
				if (!id) {
					println String.format('"%s" is not an allowed custom field for the given project and issue type.', key)
					System.exit(1)
				}
		
				fieldMap.put(id, value)
			}
		} else {
			println "customFields is null."
		}
		
		//populateFieldmapProgrammatically(fieldMap)
			

		def issueMap = [:]
		issueMap.put("fields",fieldMap)
	
		// Change mapping to JSON and prepare it to be sent via REST call
		JsonBuilder issueJSON = new JsonBuilder(issueMap)
		
		println '================================================='
		println 'issueMap and fieldMap: fieldMap.size() = ' + fieldMap.size()
		println '================================================='
		//issueMap.each{ println it }
		fieldMap.each{ println it }
		println '===================='
	
		// creating issue ....
		//if (!jira.createIssue(client, serverUrl, issueJSON)) {
		//	println "Create Issue failed. Review error output for details."
		//	System.exit(1)
		//}
	
	}
	
	boolean inOtherAllowedFields ( String fieldName ) {
		return otherAllowedFields.contains(fieldName)
	}
	
	void populateFieldmapProgrammatically(Map fieldMap) {
		fieldMap.put("customfield_10091", ["value": "No"])    // options
		fieldMap.put("customfield_10050", "2019-03-22")    // date
		fieldMap.put("customfield_10051", "2019-02-21")    // date
		fieldMap.put("customfield_10096", ["value": "No"])    // options
		
		fieldMap.put("customfield_10075", [["name": "a03acpt"]])    // array - "items": "user",
		fieldMap.put("customfield_10097", ["value": "Yes"])    // options
		fieldMap.put("customfield_10076", ["value": "Kanban"])    // options
		fieldMap.put("customfield_10098", ["value": "iCart"])    // options
		
		fieldMap.put("customfield_10099", ["value": "Git (Stash)"])    // options
		fieldMap.put("customfield_10078", ["value": "Application"])    // options
		fieldMap.put("customfield_10057", "Release R3")    // string
		fieldMap.put("customfield_10104", ["value": "No"])    // options
		fieldMap.put("customfield_10049", "CHG0316805")    // string
		fieldMap.put("customfield_10105", ["value": "No"])    // options
		fieldMap.put("customfield_10402", ["value": "Yes"])    // options
		
		fieldMap.put("customfield_10106", ["value": "No"])    // options
		fieldMap.put("customfield_10041", ["value": "HOPEX/SEAR"])    // options
		fieldMap.put("customfield_10064", ["name": "a03acpt"] )    // user
		fieldMap.put("customfield_10042", ["value": "Xray for Jira with features traced to tests"])    // options
		fieldMap.put("customfield_10043", ["value": "Jira with features tagged to a specific release"])    // options
		fieldMap.put("customfield_10066", ["Treasury"])    // array
		fieldMap.put("customfield_10044", ["value": "DOORS using the \"Vison Document Template\""])    // options
		
		fieldMap.put("customfield_10088", ["value": "No"])    // options
		fieldMap.put("customfield_10100", ["value": "No"])    // options
		fieldMap.put("customfield_10067", ["DevOps Engineer"])    // array
		fieldMap.put("customfield_10045", ["value": "Agile Testing Document Template and Risk Assessment Matrix Template and stored in System of Record (SOR)"])    // options
		fieldMap.put("customfield_10101", ["value": "No"])    // options
		fieldMap.put("customfield_10102", ["value": "No"])    // options
		fieldMap.put("customfield_10103", ["value": "No"])    // options
					
		// Add standard fields to JSON
		fieldMap.put("issuetype", ["name": issueTypeName])
		fieldMap.put("project", ["key": projectKey])
		fieldMap.put("summary", summary)
	}
	
	void processCustomFields() {
		println "1. customFields = " + customFields
		// Parse custom fields
		if (customFields) {
			try {
				customFields = new JsonSlurper().parseText(customFields)
				if (customFields instanceof List) {
					println "Expected Custom Fields to be a JSON object, but received a JSON array:"
					println()
					println new JsonBuilder(customFields)
					println()
					System.exit(1)
				}
			} catch (JsonException e) {
				println 'Failed to parse Custom Fields JSON:'
				println()
				println customFields
				println()
				System.exit(1)
			}
		}
		
		println "2. customFields = " + customFields
	}
	
	void processSnowTicketJson(String json) {
		
		def slurper = new JsonSlurper()
		def ticket = slurper.parseText(json)
		
		println '=============================================='
		println 'Snow Ticket Details'
		println '=============================================='
		println "Ticket:        " + ticket.number
		println "Desc:          " + ticket.short_description
		println "State:         " + ticket.state
		println "Approval:      " + ticket.approval		
		println '=============================================='
		ticket.each { println it }
		println '=============================================='
		println "Ticket:        " + ticket.number.getClass().getName()
		println "start_date:    " + ticket.start_date.getClass().getName()
		println "assigned_to:   " + ticket.assigned_to.getClass().getName()
		println "u_manager:   " + ticket.u_manager.getClass().getName()
		println "type:   " + ticket.type.getClass().getName()
	}
	
		
	void processJiraCreateJsonFile(File json) {
		
		def slurper = new JsonSlurper()
		def ticket = slurper.parseFile(file, charset);
		
		println '=============================================='
		println 'Snow Ticket Details'
		println '=============================================='
		println "Ticket:        " + ticket.number
		println "Desc:          " + ticket.short_description
		println "State:         " + ticket.state
		println "Approval:      " + ticket.approval
		println '=============================================='
		ticket.each { println it }
		println '=============================================='
		println "Ticket:        " + ticket.number.getClass().getName()
		println "start_date:    " + ticket.start_date.getClass().getName()
		println "assigned_to:   " + ticket.assigned_to.getClass().getName()
		println "u_manager:   " + ticket.u_manager.getClass().getName()
		println "type:   " + ticket.type.getClass().getName()
	}


	@Test
	void testReadIssue() {
		setUpClass();
		groovy.json.internal.LazyMap data = dtm.getIssue(client, serverUrl, issueId)
		// print out each element
		data.each{ println it }
		//println("issueId["+issueId+"]: " + data)
	}
	
	//@Test
	void testgetAllowedFields() {			
		setUpClass();		
		processCustomFields();
				
		// Get the Create Issue metadata so we can determine what issue/field types are allowed
		def createIssueMeta = dtm.getCreateIssueMeta(client, serverUrl, projectKey)
		
		// createIssueMeta className: groovy.json.internal.LazyMap
		println "createIssueMeta className: " + createIssueMeta.getClass().getName()
		//println "createIssueMeta.projects = " + createIssueMeta.projects
		
		//createIssueMeta.each{ println it }
	
		// Fail if the given project is not found
		if (!createIssueMeta.projects) {
			println String.format('No project found with key "%s".', projectKey)
			System.exit(1)
		}
	
		// Fail if the given issue type is not allowed in the given project
		def metaIssueType = createIssueMeta.projects[0].issuetypes.find{it.name == issueTypeName}
		if (!metaIssueType) {
			println String.format('"%s" is not an allowed issue type in the project "%s".', issueTypeName, projectKey)
			System.exit(1)
		}
		
		//println "metaIssueType = " + metaIssueType
		
		
		// Create a list of objects representing the allowed fields [{"id": String, "name": String, "required": boolean}...]
		def allowedFields = metaIssueType.fields.collect { fieldId, fieldDef ->
			[id: fieldId, name: fieldDef.name, required: fieldDef.required]
		}
	
		println "allowedFields.size() = " + allowedFields.size()
		
		println "-----------------"
		allowedFields.each { 
			// each element = java.util.LinkedHashMap
			
			//println it
			
			//println "-----------------"
			//for (Iterator i = it.entrySet().iterator(); i.hasNext();) {
			//	java.util.Map.Entry e = i.next(); // not allowed			
			//	println e.getKey() + " -> " + e.getValue()				
			//}
			 
		}
		println "-----------------"
	}

	
	@After
	public void tearDown() {
	  // Do something after each test (run twice in this example)
		println("tearDown(): ")
	}

	@AfterClass
	public static void tearDownClass() {
	  // Do something after ALL tests have been run (run once)
		println("tearDownClass(): ")
	}
	
}
