package org.test;

//@BeforeClass � Run once before any of the test methods in the class, public static void
//@AfterClass � Run once after all the tests in the class have been run, public static void
//@Before � Run before @Test, public void
//@After � Run after @Test, public void
//@Test � This is the test method to run, public void

import static org.junit.jupiter.api.Assertions.*;

import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;


class SimpleTest {
	
    @BeforeClass 
    public static void setupOnce() { 
        final Thread thread = new Thread() {
            public void run() {
               //launch application
            }
        }; 
        try { 
            thread.start(); 
        } catch (Exception ex) { } 
    }


	@Test
	void test() {
		fail("Not yet implemented");
	}

}
