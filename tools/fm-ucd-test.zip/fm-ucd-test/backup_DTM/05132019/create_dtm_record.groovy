import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.jira.addcomments.JIRAHelper
import com.urbancode.air.plugin.jira.addcomments.TextUtil
import groovy.json.JsonBuilder
import groovy.json.JsonException
import groovy.json.JsonSlurper
import org.apache.http.impl.client.DefaultHttpClient

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def props = apTool.getStepProperties()

final def serverUrl        = props['serverUrl']
final def username         = props['username']
final def password         = props['passwordScript']?:props['password']
final def projectKey       = props['projectKey']
final def summary          = props['summary']
final def issueTypeName    = props['issueTypeName']
def proxyHost = props['proxyHost']?.trim()
def proxyPort = props['proxyPort']?.trim()
boolean allowInsecure = (props['allowInsecure']?:"false").toBoolean()
def customFields           = props['customFields']?.trim()
def otherAllowedFields = ["project" , "summary", "issuetype"]

// Constants
final def dueDate          = Calendar.getInstance()  // right meow

// Construct an empty JIRAHelper class to call helper functions
JIRAHelper jira            = new JIRAHelper()       // Created to call helper methods

//------------------------------------------------------------------------------
// Script content
//------------------------------------------------------------------------------

println 'inFile:  ' + this.args[0]
println 'outFile: ' + this.args[1]
println "Server:\t$serverUrl"
println "token:\t$password"
println "Project:\t$projectKey"
println "issueTypeName:\t$issueTypeName"
println "summary:\t$summary"
println "dueDate:\t$dueDate"
println ""

// Parse custom fields
if (customFields) {
    try {
        customFields = new JsonSlurper().parseText(customFields)
        if (customFields instanceof List) {
            println "Expected Custom Fields to be a JSON object, but received a JSON array:"
            println()
            println new JsonBuilder(customFields)
            println()
            System.exit(1)
        }
    } catch (JsonException e) {
        println 'Failed to parse Custom Fields JSON:'
        println()
        println customFields
        println()
        System.exit(1)
    }
}

try {
    // Construct the HTTP client to allow user authentication
    DefaultHttpClient client
    client = jira.createClient(username, password, proxyHost, proxyPort, allowInsecure)

    // Get the Create Issue metadata so we can determine what issue/field types are allowed
    def createIssueMeta = jira.getCreateIssueMeta(client, serverUrl, projectKey)

    // Fail if the given project is not found
    if (!createIssueMeta.projects) {
        println String.format('No project found with key "%s".', projectKey)
        System.exit(1)
    }

    // Fail if the given issue type is not allowed in the given project
    def metaIssueType = createIssueMeta.projects[0].issuetypes.find{it.name == issueTypeName}
    if (!metaIssueType) {
        println String.format('"%s" is not an allowed issue type in the project "%s".', issueTypeName, projectKey)
        System.exit(1)
    }

    // Create a list of objects representing the allowed fields [{"id": String, "name": String, "required": boolean}...]
    def allowedFields = metaIssueType.fields.collect { fieldId, fieldDef ->
        [id: fieldId, name: fieldDef.name, required: fieldDef.required]
    }
	
	// TODO:
	// specifically retrieve projectKey, issueType, and summary field; and add into field map later.

    // Create Issue as a HashMap object
    def fieldMap = [:]

    // Add custom fields to JSON
    customFields.each { key, value ->
        def id = allowedFields.find{
            //it.name == key && it.id.startsWith('customfield_')
			it.id == key && ( it.id.startsWith('customfield_') || otherAllowedFields.contains(it.id) )
        }?.id

        // Fail if the given custom field name is not in the list of allowed fields for this project and issue type
        if (!id) {
            println String.format('"%s" is not an allowed custom field for the given project and issue type.', key)
            System.exit(1)
        }

        fieldMap.put(id, value)
    }

    // Add standard fields to JSON
    fieldMap.put("issuetype", ["name": issueTypeName])
    fieldMap.put("project", ["key": projectKey])
    fieldMap.put("summary", summary)

    def issueMap = [:]
    issueMap.put("fields",fieldMap)

    // Change mapping to JSON and prepare it to be sent via REST call
    JsonBuilder issueJSON = new JsonBuilder(issueMap)
	
	println '================================================='
	println 'fieldMap: fieldMap.size() = ' + fieldMap.size()
	println '================================================='
	fieldMap.each{ println it }
	println '===================='

	// output if necessary
	apTool.setOutputProperty('projectKey', projectKey)
	apTool.setOutputProperty('issuetype', issueTypeName)
	apTool.setOutputProperty('summary', summary)
	apTool.setOutputProperty('token', password)
	apTool.setOutputProperties();

    //if (!jira.createIssue(client, serverUrl, issueJSON)) {
    //    println "Create Issue failed. Review error output for details."
    //    System.exit(1)
    //}
	
	
}
catch (Exception e) {
    e.printStackTrace()
    throw new IllegalStateException("Full execution of create issue failed.")
}
