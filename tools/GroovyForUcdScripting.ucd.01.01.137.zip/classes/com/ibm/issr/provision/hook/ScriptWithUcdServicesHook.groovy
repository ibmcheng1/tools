package com.ibm.issr.provision.hook

import com.ibm.css.ucd.application.Application;
import com.ibm.css.ucd.resource.ResourceTree;
import com.ibm.css.ucd.services.UcdConnectionServices;

/**
 * Base class for a custom, plugin defined Groovy class which has access
 * to a UCD API interface.
 * @author ltclark
 *
 */
abstract class ScriptWithUcdServicesHook {
	/**
	 * Execute the script.  This is the function that implements the scipt. 
	 * @param ucdConnectionServices This is the handle to the UCD API Services.
	 * @param outProps Properties which are used as output properties for the Plugin Step.
	 * Call outProps.put(String propertyName, String propertyValue) to set an output property.
	 */
	public abstract void runScript( UcdConnectionServices ucdConnectionServices, Properties outProps );
}
