package com.ibm.issr.date

import groovy.time.TimeDuration

class DateHelper {
	/**
	 * When parsing data/time strings, parseDateTime() attempts to use format1 and then format2.
	 */
	public static String parseFormat1 = 'M/d/yy HH:mm'
	public static String parseFormat2 = 'M/d/yy'
	
	public static TimeDuration durationInDays( int days ) {
		return new TimeDuration(days, 0, 0, 0, 0)
	}
	
	public static TimeDuration durationInHours( int hours ) {
		return new TimeDuration(hours, 0, 0, 0)
	}
	
	/**
	 * The vision for this function is that it is a 'smart' date/time field parser.  Over time, it will evolve to handle
	 * increasingly flexible input.  For example, it would be nice to handle an input like "3 days ago".
	 * 
	 * Current implementation is ...
	 * Attempts to parse a date/time string in one of two different formats.  It tries
	 * format1 first.  If that fails, then it uses format2.  See https://docs.oracle.com/javase/7/docs/api/java/text/SimpleDateFormat.html
	 * for a description of the format options.  The idea is to support a date string with an optional time.  So it
	 * attempts to parse a date+time.  If that fails, then it just parses a date.  The default values can be overridden.
	 * If both formats fail, then this throws an execption.
	 * @param dateString The date value to format.
	 * @return The resulting Date if successful.
	 */
	public static Date parseDateTime( String dateString) {
		Date date = new Date()
		try {
			date = date.parse( parseFormat1, dateString )
		} catch (Exception e) {
			date = date.parse( parseFormat2, dateString )
		}
		return date
	}
}
