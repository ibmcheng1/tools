package com.ibm.issr.rest

import org.apache.http.HttpResponse
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.StringEntity

/**
 * This is an abstraction of a REST POST call to be used in conjunction with the RestClient class.
 * @author ltclark
 *
 */
class RestPost extends RestOperation {
	private HttpPost method;
	private String cachedPayload="";		// cache payload for debugging purposes
	
	/**
	 * Constructor
	 * @param restClient The associated Rest Client connection.
	 */
	public RestPost( RestServerConnection restClient ) {
		super( restClient, "Post" );
		method = new HttpPost();
	}
	
	/**
	 * Adds a set of parameters by providing one map.
	 * @param paramMap This is a map of parameter values as a groovy map, such as [a:"vala",b:"valb"].
	 * @return Return 'this'
	 */
	public RestPost addParameters( def paramMap ) {
		for (mapEntry in paramMap) {
			parameters.add( [key:mapEntry.key, value:mapEntry.value]);
		}
		return this;
	}
	
	/**
	 * Adds one parameter key/value pair.  Note
	 * @param key The key.
	 * @param value The string value.
	 * @return Returns 'this'
	 */
	public RestPost addParameter( String key, String value ) {
		parameters.add( [key:key,value:value] )
		return this
	}

	/**
	 * Sets the path of the rest call, such as "/rest/sample/call".  Doe NOT
	 * pass server information.
	 * @param path The path of the call.  Do NOT include parameters.
	 * @return Return 'this'.
	 */
	public RestPost setPath( String path ) {
		this._path = path;
		return this;
	}

	/**
	 * Sets the body/contents/payload of the Post call to a string value.
	 * @param payload
	 * @return Return 'this'.
	 */
	public RestPost setPayload( String payload ) {
		if (payload) {
			method.setEntity(new StringEntity(payload));
			cachedPayload = payload
		}
		return this;
	}
	
	
	/**
	 * Sets the body/contents/payload call to a JSON string version of an object.
	 * @param payload This is an object that is converted into a JSON string.
	 * @return Return 'this'.
	 */
	public RestPost setJsonPayloadToObject( def payload ) {
		if (payload) {
			cachedPayload = groovy.json.JsonOutput.toJson(payload)
			method.setEntity(new StringEntity( cachedPayload ));
		}
		return this;
	}
	
	/**
	 * Perform the POSt call!!
	 * @param processResponse This is called with the RestResponse as the one
	 * parameter.  It should process the response, such as { response.throwExceptionOnBadResponse(); return response.getResponseAsObject() }.
	 * The response is automatically closed after this closure is called.
	 * @return Returns the value returned by the closure.
	 */
	public def post( Closure processResponse ) {
		// Build the full url
		method.setURI( new URI(this.fullUrl) );
		response = restClient.client.execute(method)
		RestResponse response = new RestResponse( this, response )
		try {
			return processResponse( response )	
		}
		finally {
			response.close()
			method.releaseConnection()
		}
	}
	
	/**
	 * Performs a post, throws exception on any HTTP return code other than OK and then
	 * returns the JSON result string as an Object tree.
	 * @return The JSON result string as an Object tree.
	 */
	public def postAsObject() {
		return post() { RestResponse response ->
			response.throwExceptionOnBadResponse()
			return response.responseAsObject
		}
	}


	/**
	 * Performs a post, throws exception on any HTTP return code other than OK.  This ignores
	 * any body returned by the REST call (if there is any body returned).
	 */
	public void postWithNoReturnObject() {
		post() { RestResponse response ->
			response.throwExceptionOnBadResponse()
		}
	}
}
