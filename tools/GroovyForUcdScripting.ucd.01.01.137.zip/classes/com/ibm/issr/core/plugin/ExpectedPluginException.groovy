package com.ibm.issr.core.plugin

/**
 * Use this to throw known, expected error conditions from Plugins.
 * @author ltclark
 *
 */
class ExpectedPluginException extends AbortPluginException {

	public ExpectedPluginException(String msg) {
		super(msg);
	}

}
