package com.ibm.issr.core.json.builder

/**
 * Helper function for building json List string.  [ listElements ].
 * This is useful when you need more control of the process of creating JSON elements.
 * Call 'addEntry' for each additional entry in the list.  Then call
 * 'toJsonString()' to get the final string.
 * @author ltclark
 *
 */
class JsonListBuilder implements JsonBuilderInterface {
	List entries = []
	
	/**
	 * Adds another child member to the json list. 
	 * @param jsonStringEntry A self String contained definition of the child,
	 * such as a map or a list, such as "{'a':'b','c':'d'}".
	 * @return As a convenience, returns 'this'.
	 */
	public JsonListBuilder addEntry( String jsonStringEntry ) {
		entries << jsonStringEntry
		return this
	}
	
	/**
	 * Adds a new entry by adding a JsonBuilder (which outputs json)
	 * @param jsonBuilder The builder that emits the entry's value
	 * @return As a convenience, return 'this'.
	 */
	public JsonListBuilder addEntry( JsonBuilderInterface jsonBuilder ) {
		entries << jsonBuilder.toJsonString()
		return this
	}
	
	/**
	 * Returns the composite list as a json string.
	 */
	public String toJsonString() {
		StringBuffer retval = new StringBuffer( '[' )
		String delim = ''
		entries.each { String entry ->
			if (delim) {
				retval.append(delim)
			} else {
				delim = ','
			}
			retval.append(entry)
		}
		retval.append(']')
		return retval.toString()
	}
}
