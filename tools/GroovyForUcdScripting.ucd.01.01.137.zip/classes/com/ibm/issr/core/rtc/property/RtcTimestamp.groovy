package com.ibm.issr.core.rtc.property

import java.text.ParseException;

/**
 * An RTC Timestamp field is a java.sql.Timestamp.  RTC stores timestamps in GMT and NOT the local time.
 * This class has helper functions to work with RTC Timestamp fields.
 * @author ltclark
 *
 */
class RtcTimestamp {

	/**
	 * Converts an RTC Timestamp string (which is in GMT) into a Date field.
	 * @param timestampString A "Timestamp" formatted field, which is basically 'yyyy-MM-dd HH:mm:ss.s'
	 * where it goes to the fraction of a second.
	 * @return The corresponding date, which is timezone portable. 
	 * @throws ParseException Thrown if unable to parse the string.
	 */
	public static Date convertRtcTimestampStringToDate( String timestampString ) throws ParseException {
		// Parse the date ignoring the fractional seconds
		java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
		TimeZone timezone = TimeZone.getTimeZone('GMT')
		dateFormat.setTimeZone(timezone)
		return dateFormat.parse(timestampString)
	}

}
