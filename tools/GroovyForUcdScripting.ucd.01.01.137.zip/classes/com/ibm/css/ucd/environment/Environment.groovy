package com.ibm.css.ucd.environment

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.environment.EnvironmentApi
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.common.CacheData
import com.ibm.css.ucd.common.EntityWithNameIdAndTeams
import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.css.ucd.resource.ResourceTree
import com.ibm.css.ucd.services.ProcessRequestServices
import com.ibm.css.ucd.snapshot.Snapshot
import com.ibm.css.ucd.team.Team
import com.ibm.issr.core.log.Logger

/**
 * UCD Environment Entity representing one UCD Environment instance.
 * @author ltclark
 *
 */
class Environment extends EntityWithNameIdAndTeams {
	// Cached set of Environment entries.
	//	key = UcdServerConnection
	//	value = Map where
	//		key = id
	//		value = Environment
	static protected Map cache = [:]
	
	// The application that this environment is part of
	private Application _application
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the UCD Server.
	 * @param application The application which contains this environment.
	 * @param info This is an Object version of the call to /cli/environment/info.
	 * Note that it has at least two fields - name and id.
	 */
	public Environment( UcdServerConnection ucdServer, Application application, def info ) {
		super( ucdServer, new EnvironmentApi(ucdServer), info.name, info.id )
		this._application = application
	}
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 */
	public Environment( UcdServerConnection ucdServer, Application application, String name, String id ) {
		super( ucdServer, new EnvironmentApi(ucdServer), name, id )
		this._application = application
	}

	/**
	 * Cached creation of new entities.  If the entity is already in the cache, the existing entity
	 * is returned.  Otherwise, a new entity is created, added to the cache and returned.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param application The application that this environment is part of
	 * @param name The name.
	 * @param id The id.
	 * @return The requested entity.
	 */
	public static Environment getEnvironmentWithCache( UcdServerConnection ucdServer, Application application, String name, String id ) {
		if (! cache.containsKey(ucdServer)) {
			cache[ucdServer] = [:]
		}
		if (! cache[ucdServer].containsKey(id)) {
			cache[ucdServer][id] = new Environment( ucdServer, application, name, id )
		}
		return cache[ucdServer][id]
	}

	/**
	 * Returns the Application which this environment is in.
	 */
	public Application getApplication() {
		return _application
	}
	
	/**
	 * Is the given resourceNode a base resource for this environment?
	 * @param resourceNode A Resource Tree node
	 */
	public boolean hasBaseResource( ResourceNode resourceNode ) {
		boolean retval = false
		def baseResources = EnvironmentApi.getBaseResources( ucdServer, getId() )
		baseResources.each { def baseResource ->
			if (baseResource.id == resourceNode.getId()) {
				retval = true
			}
		}
		return retval
	}
	
	/**
	 * Return a List of the base resources for this environment.  Each
	 * member is of type ResourceNode
	 */
	public List getBaseResources() {
		ResourceTree resourceTree = new ResourceTree( ucdServer )
		List retval = []
		List baseResources = EnvironmentApi.getBaseResources( ucdServer, getId() )
		baseResources.each { def baseResource ->
			retval << resourceTree.getResourceNode( baseResource.path )
		}
		return retval
	}
	
	/**
	 * Adds a new Base Resource to this environment.
	 * @param resourceNode The base resource to add.
	 */
	public void addBaseResource( ResourceNode resourceNode ) {
		EnvironmentApi.addBaseResource(ucdServer, this.getId(), resourceNode.getId())
	}
	
	/**
	 * Is this entity linked to the given team and optionally to the resourceType.
	 * @param team The team to test for.
	 * @param resourceType The optional resource type. If this is null or an empty string, then this looks for a team without a type.
	 * If this is a non-empty string, then it looks for a matching resourceType entry for the team.
	 */
	public boolean isLinkedToTeam( Team team, String resourceType ) {
		return EnvironmentApi.isLinkedToTeam(ucdServer, this.getId(), team.getId(), resourceType)
	}
	
	/**
	 * Adds a link to the given team and optionally to the resourceType (if provided)
	 * @param team The team to test for.
	 * @param resourceType The optional resource type. If this is null or an empty string, then the team is added without a resource type.
	 * If this is a non-empty string, then the team is added with this resource type.
	 */
	public void addLinkToTeam( Team team, String resourceType="" ) {
		EnvironmentApi.addLinkToTeam(ucdServer, this.getId(), team.getId(), resourceType)
	}
	
	/**
	 * Creates a new snapshot of the environment.
	 * @param snapshotName The name of the new snapshot.
	 * @return Returns the new Snapshot entity.
	 */
	public Snapshot createSnapshot( String snapshotName ) {
		String snapshotId = EnvironmentApi.createSnapshot( ucdServer, this.getApplication().getId(), this.getId(), snapshotName )
		return new Snapshot( ucdServer, snapshotName, snapshotId )
	}
	
	/**
	 * Returns the newest/latest snapshot for this environment.  Returns null if no snapshots found.
	 */
	public Snapshot getLatestSnapshot() {
		def latestSnapshot = EnvironmentApi.getLatestSnapshot(ucdServer, this.getId() )
		if (latestSnapshot) {
			return new Snapshot( ucdServer, latestSnapshot.name, latestSnapshot.id )	
		} else {
			return null
		}
	}
	
	/**
	 * Returns a List of the properties in the environment.  This only checks the ad-hoc 'Environment Properties'.
	 * This does NOT include 'basic' (aka Template defined) properties or Component (Template) defined properties.
	 * @return This returns the structure returned by the '/cli/environment/getProperties' call which is
	 * a list.  Each member of the list has the following fields: id, name, value, description, secure (which is boolean).
	 */
	public List getProperties() {
		return EnvironmentApi.getEnvironmentProperties(ucdServer, this.getId() )
	}
	
	/**
	 * Sets an environment property.  Note that this does NOT set component defined environment
	 * properties.  Note that if a Component Process changes the Environment that the current process is running in, the changes do NOT
     * appear immediately.
	 * @param name The name of the property.
	 * @param value The value of the property.
	 * @param isSecure Is the new property a secure property.
	 */
	public void setProperty( String name, String value, boolean isSecure ) { 
		EnvironmentApi.setEnvironmentProperty( ucdServer, this.getId(), name, value, isSecure )
	}
	
	/**
	 * Does the named property exist for this environment??  This only checks the ad-hoc 'Environment Properties'.
	 * This does NOT include 'basic' (aka Template defined) properties or Component (Template) defined properties.
	 * @param name The desired property name.
	 */
	public boolean doesPropertyExist( String name ) {
		return EnvironmentApi.doesPropertyExist(ucdServer, this.getId(), name)
	}
	
	/**
	 * Copy properties from this environment to the targetEnvironment.  Note that this
	 * does NOT copy Component defined Environment properties.
	 * @param targetEnvironment The target environment.
	 * @param includeSecure Should secure fields be included?  If true, it defines the secure fields, but
	 * with an empty value because there is no way to get the value of a secure field via API calls.  If false,
	 * this totally skips secure fields.
	 * @param overWrite What if the target already has a matching property?  If 'overWrite' is true, then
	 * the value is reset, otherwise any existing target property is left untouched.
	 */
	public void copyPropertiesToTargetEnvironment( Environment targetEnvironment, boolean includeSecure, boolean overWrite ) {
		Logger.debug "copyProperties( sourceEnv='${this.name}', targetEnv='${targetEnvironment.name}', includeSecure=${includeSecure}, overWrite=${overWrite} )"
		
		// get the properties from the source
		List sourceProperties = this.getProperties()
		Logger.debug "Source properties: " + groovy.json.JsonOutput.toJson(sourceProperties)
		
		// If 'overWrite' is false, get the target properties to detect overwrite scenario
		Map targetPropertyMap = [:]	// key = property name, value = targetProperties entry
		if (! overWrite) {
			List targetProperties = targetEnvironment.getProperties()
			targetProperties.each { def propertyDef ->
				targetPropertyMap[propertyDef.name] = propertyDef
			}
			Logger.debug "indexed list of existing target properties: " + groovy.json.JsonOutput.toJson(targetPropertyMap)
		}  
		
		// Copy properties to the target
		sourceProperties.each { def propertyDef ->
			boolean skipProperty = false
			if ((! overWrite) && targetPropertyMap.containsKey(propertyDef.name)) {
				// matching target property already exists and overWrite is false
				skipProperty = true
			} else {
				if (propertyDef.secure) {
					// set the value to an empty string
					propertyDef.value = ""
					if (! includeSecure) {
						// it is not copying secure properties
						skipProperty = true
					}
				}
			}
			if (skipProperty) {
				Logger.debug "Skipping property '${propertyDef.name}'"
			} else {
				Logger.debug "Setting property '${propertyDef.name}'"
				targetEnvironment.setProperty(propertyDef.name, propertyDef.value, propertyDef.secure)
			}
		}
	}
	
	/**
	 * Calls an application process from this environment.  Note that this call automatically resets all data that
	 * is cached by this API, because the application process can change any data.
	 * @param processName The name of the process to call.
	 * @param onlyChanged Is the only changed flag set?
	 * @param snapshotName Optional name of the snapshot to use.  Otherwise, use empty string.
	 * @param componentVersions This is a List of the component versions.  Each entry in the list can be either
	 * a ComponentVersion class instance or a Map.  If it's a map, then the map must have 
	 * 'version' and 'component' entries - the component name or id and version name or id.  Note that you
	 * can use both the ComponentVersion and Map entries in the same list.
	 * @param props List of property values to send to the application process.  This can be an instance of the Properties class or
	 * it can be a Map with key/value pairs.
	 * @param scheduleFor If this is non-blank, then it is the server date and time to start the process in
	 * the format of yyyy-mm-dd hh:mm.  If blank, then start immediately.  If this is not empty, then 'waitForProcess' is automatically
	 * set to false.
	 * @param waitForProcess Wait for the nested process to complete before continuing??
	 * @return A list of return values - String requestId - the generated request ID;
	 * <ul>
	 * 	<li>String outputStatus - the status of the nested process of "Success", "Failure" or "Did Not Wait";</li>
	 *  <li>String requestStatus - the status that UCD returned for the request</li>
	 *  <li>String processStatus - the last status returned by checking the process' status.  Essentially, if 'waitForProcess' is
	 *  true and this returned 'processStatus' is anything except SUCCEEDED, then the process failed to run to completion.  Note
	 *  that it may have been cancelled or failed.</li>
	 *  <li>String webAddress = Web Address for the generated process</li>
	 *  <li>String processId - The process/request ID of the nested process.</li>
	 * </ul>
	 * Example call with return values: def (String outputStatus, String requestStatus, String processStatus, String webAddress) = callApplicationProcess(...)
	 */
	public List callApplicationProcess( String processName, boolean onlyChanged, String snapshotName, List componentVersions, def props, String scheduleFor, boolean waitForProcess ) {
		return (new ProcessRequestServices(ucdServer)).callApplicationProcess( _application, this, processName, onlyChanged, snapshotName, componentVersions, props, scheduleFor, waitForProcess )
	}

}
