package com.ibm.css.ucd.status;

import com.ibm.css.rest.ucd.UcdServerConnection;
import com.ibm.css.ucd.common.EntityWithNameAndId;

/**
 * Represents on Snapshot Status flag.  This represents the existence
 * of the flag and does NOT reflect a specific instance of the flag for a
 * ComponentVersion.
 *
 * @author LeonClark
 *
 */
public class SnapshotStatus extends EntityWithNameAndId {

	public SnapshotStatus(UcdServerConnection ucdServer, String name,
			String id) {
		super(ucdServer, name, id);
	}

}
