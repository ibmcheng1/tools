


package com.ibm.css.ucd.environmenttemplate

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.common.EntityWithNameAndId
import com.ibm.css.ucd.environment.Environment

class EnvironmentTemplate extends EntityWithNameAndId {
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 */
	public EnvironmentTemplate( UcdServerConnection ucdServer, String name, String id ) {
		super( ucdServer, name, id )
	}
	
	/**
	 * Creates a new Environment in the given application based on this template.  This is the same
	 * as calling Application.createEnvironmentFromTemplate(...).
	 * @param application The application to create the new environment in.
	 * @param environmentName The name of the new environment.
	 * @param description Optional description.
	 * @return The new environment
	 */
	public Environment createEnvironmentFromTemplate( Application application, String environmentName, String description='' ) {
		return application.createEnvironmentFromTemplate(environmentName, this, description)
	}

}
