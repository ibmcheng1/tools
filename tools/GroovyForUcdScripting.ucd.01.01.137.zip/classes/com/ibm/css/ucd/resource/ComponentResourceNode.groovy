

package com.ibm.css.ucd.resource

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.component.ComponentApi
import com.ibm.css.ucd.component.Component

/**
 * A UCD Resource Tree node for a Component reference.
 * @author ltclark
 *
 */
class ComponentResourceNode extends NonRootResourceNode {
	// Object version of the call to /cli/resource/info
	protected def info
	
	protected String _componentName
	// The cached Component
	protected Component _component = null
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the UCD Server.
	 * @param parentNode The parent node to this node.
	 * @param info This is an Object version of the call to /cli/resource/info.
	 * Note that it has at least two fields - name and id.
	 */
	public ComponentResourceNode( UcdServerConnection ucdServer, ResourceNode parentNode, def info ) {
		super( ucdServer, parentNode, info.name, info.id )
		this.info = info
		this._componentName = info.role.name
	}

	@Override
	public String getNodeType() {
		return COMPONENT_NODE_TYPE
	}
	
	public Component getComponent() {
		if (! _component) {
			_component = Component.getComponentWithCacheByName(ucdServer, _componentName)
		}
		return _component
	}

}
