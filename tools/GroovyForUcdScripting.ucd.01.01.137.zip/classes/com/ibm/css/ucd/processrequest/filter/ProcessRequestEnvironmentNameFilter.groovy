package com.ibm.css.ucd.processrequest.filter

import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.processrequest.ProcessRequest;
import com.ibm.issr.core.string.SimpleWildcard;

/**
 * Filter Process Request records based on the name of the environment.
 * @author ltclark
 *
 */
class ProcessRequestEnvironmentNameFilter extends ProcessRequestFilter {
	String environmentName
	String comparisonEnvironmentName		// case sensitive/insensitive comparison name.  If insensitive, this is lower case
	boolean caseSensitive
	
	/**
	 * Constructor.
	 * @param environmentName The name of the environment to search for with simple wildcards (*).
	 * @param caseSensitive Is the comparison of the environment name case sensitive.
	 */
	public ProcessRequestEnvironmentNameFilter( String environmentName, boolean caseSensitive ) {
		this.environmentName = environmentName
		this.caseSensitive = caseSensitive
		if (caseSensitive) {
			this.comparisonEnvironmentName = environmentName
		} else {
			this.comparisonEnvironmentName = environmentName.toLowerCase()
		}
	}
	
	@Override
	public boolean includeProcessRequestInFilter(ProcessRequest processRequest) {
		return true
	}
	
	@Override
	public Application getFilteringApplication() {
		// no application to filter on
		return null;
	}

	@Override
	public Date getFilteringStartedAfter() {
		// There is no date filtering
		return null;
	}

	@Override
	public boolean includeRawRecordInFilter(Object rawRecord) {
		boolean retval = false
		if (rawRecord.containsKey('environment') && rawRecord.environment.containsKey('name')) {
			if (SimpleWildcard.doesMatch( rawRecord.environment.name, comparisonEnvironmentName, caseSensitive )) {
				retval = true
			}
		}
		return retval
	}

	@Override
	public String getDescription() {
		String caseSensitiveClause
		if (caseSensitive) {
			caseSensitiveClause = '[case sensitive]'
		} else {
			caseSensitiveClause = '[case insensitive]'
		}
		String comparisonClause
		return "Environment is named '${environmentName}' ${caseSensitiveClause}"
	}

}
