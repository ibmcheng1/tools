package com.ibm.css.ucd.processrequest.filter

import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.processrequest.ProcessRequest
import com.ibm.css.ucd.snapshot.Snapshot

/**
 * Filter Process Request records that deployed a Snapshot
 * @author ltclark
 *
 */
class ProcessRequestSnapshotFilter extends ProcessRequestFilter {
	Snapshot snapshot
	
	/**
	 * Constructor.
	 * @param component The component to filter on.
	 */
	public ProcessRequestSnapshotFilter( Snapshot snapshot ) {
		this.snapshot = snapshot
	}

	@Override
	public Date getFilteringStartedAfter() {
		// There is no date filtering
		return null;
	}
	
	@Override
	public Application getFilteringApplication() {
		// no application to filter on
		return null;
	}

	@Override
	public boolean includeProcessRequestInFilter(ProcessRequest processRequest) {
		return true
	}

	@Override
	public boolean includeRawRecordInFilter(Object rawRecord) {
		if (rawRecord.containsKey('snapshot')) {
			if (rawRecord.snapshot.id == snapshot.id) {
				return true
			} else {
				return false
			}
		} else {
			return false
		}
	}

	@Override
	public String getDescription() {
		return "Deployed Component named '${component.name}'"
	}

}
