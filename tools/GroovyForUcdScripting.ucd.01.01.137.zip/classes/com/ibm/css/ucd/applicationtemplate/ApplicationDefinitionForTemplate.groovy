package com.ibm.css.ucd.applicationtemplate

import com.ibm.css.ucd.component.Component

class ApplicationDefinitionForTemplate {
	String name
	String description
	// List of 'Component' entries
	List components = []

	/**
	 * Constructor
	 * @param name The name of the new Application.
	 */
	public ApplicationDefinitionForTemplate( String name ) {
		this.name = name
	}

	public ApplicationDefinitionForTemplate description( String description ) {
		this.description = description
		return this
	}

	public ApplicationDefinitionForTemplate addComponent( Component component ) {
		components << component
		return this
	}
}
