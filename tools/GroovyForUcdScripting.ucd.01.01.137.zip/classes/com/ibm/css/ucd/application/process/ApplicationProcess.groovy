package com.ibm.css.ucd.application.process

import java.util.Map;

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.application.Application;
import com.ibm.css.ucd.common.EntityWithNameAndId

/**
 * ApplicationProcess Entity.
 * @author ltclark
 *
 */
class ApplicationProcess extends EntityWithNameAndId {
	// Cached set of entity entries.
	//	key = UcdServerConnection
	//	value = Map where
	//		key = id
	//		value = entity
	static protected Map cache = [:]
	
	/**
	 * Constructor.
	 * @param name
	 * @param id
	 */
	public ApplicationProcess( UcdServerConnection ucdServer, String name, String id ) {
		super( ucdServer, name, id )
	}
	
	/**
	 * Cached creation of new entities.  If the entity is already in the cache, the existing entity
	 * is returned.  Otherwise, a new entity is created, added to the cache and returned.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 * @return The requested entity.
	 */
	public static ApplicationProcess getApplicationProcessWithCache( UcdServerConnection ucdServer, String name, String id ) {
		if (! cache.containsKey(ucdServer)) {
			cache[ucdServer] = [:]
		}
		if (! cache[ucdServer].containsKey(id)) {
			cache[ucdServer][id] = new ApplicationProcess( ucdServer, name, id )
		}
		return cache[ucdServer][id]
	}
}
