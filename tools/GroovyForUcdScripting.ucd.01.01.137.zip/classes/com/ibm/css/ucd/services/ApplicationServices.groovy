package com.ibm.css.ucd.services

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.application.ApplicationApi
import com.ibm.css.rest.ucd.applicationtemplate.ApplicationTemplateApi
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.applicationtemplate.ApplicationTemplate

/**
 * Manage and access Application entities.
 * @author ltclark
 *
 */
class ApplicationServices {
	private UcdServerConnection ucdServer
	private ApplicationApi _applicationApi
	private ApplicationTemplateApi _applicationTemplateApi
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the server.
	 */
	public ApplicationServices( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
		_applicationApi = new ApplicationApi(ucdServer)
		_applicationTemplateApi = new ApplicationTemplateApi(ucdServer)
	}
	
	/**
	 * Does the named application exist?
	 * @param applicationName The name of the application.
	 */
	public boolean doesApplicationExist( String applicationName ) {
		return _applicationApi.doesApplicationExist(applicationName)
	}
	
	/**
	 * Iterates the list of all applications using the iterator.
	 * @param iterator This closure is called for each Application.  It takes one parameter 'Application application'
	 * and has no return value.
	 */
	public void iterateApplications( Closure iterator ) {
		// Get the list of applications.  The entries in the list are the raw 'information' objects returned by UCD.
		List applications = ApplicationApi.getApplications( ucdServer )
		applications.each { def appInfo ->
			// Convert app info into an Application
			Application application = new Application(ucdServer, appInfo.name, appInfo.id)
			// Call the iteration closure
			iterator( application )
		}
	}

	/**
	 * Returns the named Application.  Throws exception if not found.
	 * @param applicationName The name of the application.
	 */
	public Application getApplication( String applicationName ) {
		def info = _applicationApi.getApplicationInfo( applicationName )
		return new Application( ucdServer, info.name, info.id )
	}
	
	/**
	 * Returns the Application by ID.  Throws exception if not found.
	 */
	public Application getApplicationById( String applicationId ) {
		def info = _applicationApi.getApplicationInfo( applicationId )
		return new Application( ucdServer, info.name, info.id )
	}
	
	/**
	 * Is there an application template with the given name??
	 */
	public boolean doesApplicationTemplateExist( String name ) {
		boolean found = false
		List applicationTemplates =_applicationTemplateApi.getApplicationTemplates()
		applicationTemplates.each { def applicationTemplateEntry ->
			if (applicationTemplateEntry.name == name) {
				// FOUND
				found = true
			}
		}
		return found
	}
	
	/**
	 * Returns the named ApplicationTemplate.  Throws exception if not found.
	 * @param name The name of an Application Template.
	 */
	public ApplicationTemplate getApplicationTemplate( String name ) {
		ApplicationTemplate applicationTemplate = null
		List applicationTemplates =_applicationTemplateApi.getApplicationTemplates()
		applicationTemplates.each { def applicationTemplateEntry ->
			if (applicationTemplateEntry.name == name) {
				// FOUND
				applicationTemplate = new ApplicationTemplate( ucdServer, applicationTemplateEntry.name, applicationTemplateEntry.id )
			}
		}
		if (! applicationTemplate) {
			throw new Exception( "Unable to find an ApplicationTemplate named '" + name + "'" )
		}
		return applicationTemplate
	}
	
	/**
	 * Returns ApplicationTemplate by looking up an id.  Throws exception if not found.
	 */
	public ApplicationTemplate getApplicationTemplateById( String id ) {
		// get the application info
		def info = _applicationTemplateApi.getInfo(id)
		return new ApplicationTemplate(ucdServer, info.name, info.id, info)
	}

	/**
	 * Creates a new UCD Application which is NOT based on a template.  Throws exception on failure.
	 * @param applicationName The name of the new UCD Application.
	 * @param description Optional description of the new Application.  This can be null or an empty string.
	 * @param enforceCompleteSnapshots Should complete snapshots be enforced.
	 * @param notificationScheme Optional notification scheme name.  This can be null or an empty string.
	 * Returns A handle to the new application entity.
	 */
	public Application createApplication( String applicationName, String description="", boolean enforceCompleteSnapshots=false, String notificationScheme="" ) {
		String applicationId = _applicationApi.createApplication( applicationName, description, enforceCompleteSnapshots, notificationScheme )
		return new Application( ucdServer, applicationName, applicationId )
	}

	/**
	 * If the named application already exists, this returns the existing instance, otherwise, this creates a new application and returns it.  Throws exception on failure.
	 * @param applicationName The name of the new UCD Application.
	 * @param description Optional description of the new Application.  This can be null or an empty string.
	 * @param enforceCompleteSnapshots Should complete snapshots be enforced.
	 * @param notificationScheme Optional notification scheme name.  This can be null or an empty string.
	 * Returns A handle to the new or existing application entity.
	 */
	public Application getOrCreateApplication( String applicationName, String description="", boolean enforceCompleteSnapshots=false, String notificationScheme="" ) {
		if (doesApplicationExist(applicationName)) {
			return getApplication(applicationName)
		} else {
			return createApplication( applicationName, description, enforceCompleteSnapshots, notificationScheme )
		}
	}
}
