
package com.ibm.css.ucd.services

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.request.ProcessRequestApi
import com.ibm.css.ucd.status.ComponentVersionStatus
import com.ibm.css.ucd.status.SnapshotStatus
import com.ibm.issr.rest.RestGet

/**
 * Status services, including version and snapshot statuses.
 * @author ltclark
 *
 */
class StatusServices {
	// Cached list of SnapshotStatus'
	static List _cache_SnapshotStatusList = null
	// Cached list of ComponentVersionStatus'
	static List _cache_ComponentVersionStatusList = null
	
	private UcdServerConnection ucdServer
	private ProcessRequestApi _processRequestApi
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the server.
	 */
	public StatusServices( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
		_processRequestApi = new ProcessRequestApi(ucdServer)
	}
	
	/**
	 * Returns a List of all of the snapshot status flags defined for the system.
	 * Each member of the List of type SnapshotStatus
	 * @param resetCache The list is normally cached.  Pass true to this value to force a new call to UCD to get current status list.
	 */
	public List getSnapshotStatuses( boolean resetCache = false ) {
		if (resetCache || (! _cache_SnapshotStatusList)) {
			_cache_SnapshotStatusList = []
			List rawList = (new RestGet( ucdServer )).setPath("/cli/status/getStatuses")
				.addParameter("type", "snapshot")
				.getAsObject()
			rawList.each { def listEntry ->
				_cache_SnapshotStatusList << new SnapshotStatus(ucdServer, listEntry.name, listEntry.id)
			}
		}
		return _cache_SnapshotStatusList
	}
	
	/**
	 * Does the named Snapshot Status exist in this system?
	 * @param resetCache The list is normally cached.  Pass true to this value to force a new call to UCD to get current status list.
	 */
	public boolean doesSnapshotStatusExist( String name, boolean resetCache = false ) {
		SnapshotStatus snapshotStatus = getSnapshotStatuses(resetCache).find { SnapshotStatus snapshotStatus ->
			return (snapshotStatus.name == name)
		}
		return (snapshotStatus)
	}

	/**
	 * Return the named snapshot status.  Throws exception if not found.
	 * @param resetCache The list is normally cached.  Pass true to this value to force a new call to UCD to get current status list.
	 */
	public SnapshotStatus getSnapshotStatus( String name, boolean resetCache = false ) {
		SnapshotStatus snapshotStatus = getSnapshotStatuses(resetCache).find { SnapshotStatus snapshotStatus -> 
			return (snapshotStatus.name == name)
		}
		if (! snapshotStatus) {
			throw new Exception( "Unable to find a Snapshot Status named '" + name + "'" )
		} else {
			return snapshotStatus
		}
	}
	
	/**
	 * Returns a List of all of the componentVersion status flags defined for the system.
	 * Each member of the List of type ComponentVersionStatus
	 * @param resetCache The list is normally cached.  Pass true to this value to force a new call to UCD to get current status list.
	 */
	public List getComponentVersionStatuses( boolean resetCache = false ) {
		if (resetCache || (! _cache_ComponentVersionStatusList)) {
			_cache_ComponentVersionStatusList = []
			List rawList = (new RestGet( ucdServer )).setPath("/cli/status/getStatuses")
				.addParameter("type", "version")
				.getAsObject()
			rawList.each { def listEntry ->
				_cache_ComponentVersionStatusList << new ComponentVersionStatus(ucdServer, listEntry.name, listEntry.id)
			}
		}
		return _cache_ComponentVersionStatusList
	}
	
	/**
	 * Does the named ComponentVersion Status exist in this system?
	 * @param resetCache The list is normally cached.  Pass true to this value to force a new call to UCD to get current status list.
	 */
	public boolean doesComponentVersionStatusExist( String name, boolean resetCache = false ) {
		ComponentVersionStatus componentVersionStatus = getComponentVersionStatuses(resetCache).find { ComponentVersionStatus componentVersionStatus ->
			return (componentVersionStatus.name == name)
		}
		return (componentVersionStatus)
	}

	/**
	 * Return the named componentVersion status.  Throws exception if not found.
	 * @param resetCache The list is normally cached.  Pass true to this value to force a new call to UCD to get current status list.
	 */
	public ComponentVersionStatus getComponentVersionStatus( String name, boolean resetCache = false ) {
		ComponentVersionStatus componentVersionStatus = getComponentVersionStatuses(resetCache).find { ComponentVersionStatus componentVersionStatus ->
			return (componentVersionStatus.name == name)
		}
		if (! componentVersionStatus) {
			throw new Exception( "Unable to find a ComponentVersion Status named '" + name + "'" )
		} else {
			return componentVersionStatus
		}
	}

}
