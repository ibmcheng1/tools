package com.ibm.css.ucd.services

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.team.TeamApi
import com.ibm.css.ucd.team.Team;

class TeamServices {
	private UcdServerConnection ucdServer
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the server.
	 */
	public TeamServices( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
	}

	/**
	 * Returns the named Teat.  Throws exception if not found.
	 * @param name The name of the team.
	 */
	public Team getTeam( String name ) {
		return TeamApi.getTeamEntityFromName(ucdServer, name)
	}

}
