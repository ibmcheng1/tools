package com.ibm.css.ucd.services

import java.util.Date;

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.audithistory.AuditHistoryApi;
import com.ibm.css.ucd.audithistory.AuditHistoryEntry;
import com.ibm.issr.core.log.Logger;

/**
 * Manager class for interacting with the Audit History.
 * @author ltclark
 *
 */
class AuditHistoryServices {
	private UcdServerConnection ucdServer
	private AuditHistoryApi _auditHistoryApi
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the server.
	 */
	public AuditHistoryServices( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
		_auditHistoryApi = new AuditHistoryApi(ucdServer)
	}
	
	/**
	 * Returns a List of the audit history.
	 * @return A List of audit history entries.  Each entry is a Map which includes
	 * the following fields: 
	 */
	public List getAuditHistory() {
		List history = []
		int pageNumber=0
		while (true) {
			++pageNumber
//			Logger.info("${pageNumber}")
			List rawAuditHistory = _auditHistoryApi.getPageOfAuditHistory(pageNumber, true, 100)
			if (rawAuditHistory.size() == 0) {
				break;
			}
			rawAuditHistory.each { entry ->
				AuditHistoryEntry newEntry = new AuditHistoryEntry(entry.date, entry.eventType, entry.description, entry.objType, entry.objName, entry.objId, entry.userId, entry.userName, entry.status, entry.id, entry.ipAddress)
				history << newEntry
			}
		}
		return history
	}

	/**
	 * Iterates the audit history table calling the closure (aka function) for each record.
	 * @param executeOnEntry This is the closure that is called for each entry.  It takes one parameter, which is an AuditHistoryEntry.
	 */
	public void iterateAuditHistory( Closure executeOnEntry ) {
		List history = []
		int pageNumber=0
		while (true) {
			++pageNumber
//			Logger.info("${pageNumber}")
			List rawAuditHistory = _auditHistoryApi.getPageOfAuditHistory(pageNumber, true, 100)
			if (rawAuditHistory.size() == 0) {
				break;
			}
			rawAuditHistory.each { entry ->
				AuditHistoryEntry newEntry = new AuditHistoryEntry(entry.date, entry.eventType, entry.description, entry.objType, entry.objName, entry.objId, entry.userId, entry.userName, entry.status, entry.id, entry.ipAddress)
				executeOnEntry( newEntry )
			}
		}
	}
	
	/**
	 * Iterates the audit history table within the date range calling the closure (aka function) for each record.
	 * @param startDate The oldest/starting date to include in the retrieved records.  This is optional and may be null
	 * @param endDate The newest/end date to include in the retrieved.  This is optional and may be null.
	 * @param executeOnEntry This is the closure that is called for each entry.  It takes one parameter, which is an AuditHistoryEntry.
	 */
	public void iterateAuditHistory( Date startDate, Date endDate, Closure executeOnEntry ) {
		_auditHistoryApi.iterateAuditHistory(startDate, endDate ) { entry ->
				AuditHistoryEntry newEntry = new AuditHistoryEntry(entry.date, entry.eventType, entry.description, entry.objType, entry.objName, entry.objId, entry.userId, entry.userName, entry.status, entry.id, entry.ipAddress)
				executeOnEntry( newEntry )
		}
	}

	
	
	/**
	 * Deletes old audit history records from UCD that are older than the given date.
	 * If this fails, then an exception is thrown
	 * @param priorToDate Cutoff date.  It deletes records older than this.  It does NOT
	 * delete audit records with this date.
	 */
	public void deleteOldAuditHistoryEntries( Date priorToDate ) {
		_auditHistoryApi.deleteOldAuditHistoryEntries(priorToDate)
	}
}
