package com.ibm.css.ucd.services

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.component.ComponentApi
import com.ibm.css.ucd.component.Component;

/**
 * Manage and access Component entities.
 * @author ltclark
 *
 */
class ComponentServices {
	private UcdServerConnection ucdServer
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the server.
	 */
	public ComponentServices( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
	}

	/**
	 * Returns the named Component.  Throws exception if not found.
	 * @param componentName The name of the component.
	 */
	public Component getComponent( String componentName ) {
		return ComponentApi.getComponentEntityFromName(ucdServer, componentName)
	}
	
	/**
	 * Returns the Component given its ID.  Throws exception on error.
	 */
	public Component getComponentFromId( String componentId ) {
		return ComponentApi.getComponentEntityFromId(ucdServer, componentId)
	}

	/**
	 * Returns the List of ALL active components on the server.  The data
	 * type of each entry in the List is Component.
	 */
	public List getAllComponents() {
		return ComponentApi.getAllComponents(ucdServer)
	}
}
