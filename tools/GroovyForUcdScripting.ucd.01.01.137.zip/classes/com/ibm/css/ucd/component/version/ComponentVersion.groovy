
package com.ibm.css.ucd.component.version
import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.component.version.ComponentVersionApi
import com.ibm.css.ucd.common.CacheData;
import com.ibm.css.ucd.common.EntityWithNameAndId
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.status.*
import com.ibm.issr.core.log.Logger


class ComponentVersion extends EntityWithNameAndId {
	/**
	 * Cached set of entries for this entity
	 * <pre>
	 * key = UcdServerConnection
	 * value = Map where
	 *     key = id
	 *     value = entity class, such as Application or Environment
	 * </pre>
	 */
	static protected Map cache = [:]
	
	// Cached List of component version statuses.  Each entry of type ComponentVersionSnapshotInstance.
	CacheData _cached_componentVersionStatusInstances = new CacheData(ComponentVersion.class, false)

	// The component that this is a version of
	Component component
	
	// ** Additional Properties **
	// Component Versions have a different API (as of 7.0.2).  There is NO 'get Info' API call
	// for component versions.  The only way to get additional information is to
	// get all of the ComponentVersions for a Component!!  So, it's best to get all of the
	// component version data in the constructor.  But, some of the other functions create
	// a component version from just a name and id and don't have access to the additional data.
	// So, there is a simple constructor (with just name and id) and a constructor with more data.
	// If the additional data isn't loaded, then this throws an exception on attempts to
	// get the data.
	boolean additionalDataLoaded = false
	// '_created' is the date that the ComponentVersion was created and is cached
	long _created

	// ** Cached internal data **
	// _managedProperties is the list of associated Managed Properties.  If any property changes, reset this cached data back to null
	List _managedProperties = null
	
	/**
	 * Constructor.
	 * @param component The component that this is a version of
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 */
	public ComponentVersion( UcdServerConnection ucdServer, Component component, String name, String id ) {
		super( ucdServer, name, id )
		this.component = component
	}

	
	/**
	 * Constructor.
	 * @param component The component that this is a version of
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param versionData This is the data retrieved for each Component Version by the /cli/component/versions
	 * API call.
	 */
	public ComponentVersion( UcdServerConnection ucdServer, Component component, def versionData ) {
		super( ucdServer, versionData.name, versionData.id )
		this.component = component
		this.additionalDataLoaded = true
		this._created = versionData.created
	}

	/**
	 * Cached creation of new entities.  If the entity is already in the cache, the existing entity
	 * is returned.  Otherwise, a new entity is created, added to the cache and returned.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param component The component that this is a version of
	 * @param name The name.
	 * @param id The id.
	 * @return The requested entity.
	 */
	public static ComponentVersion getComponentVersionWithCache( UcdServerConnection ucdServer, Component component, String name, String id ) {
		if (! cache.containsKey(ucdServer)) {
			cache[ucdServer] = [:]
		}
		if (! cache[ucdServer].containsKey(id)) {
			cache[ucdServer][id] = new ComponentVersion( ucdServer, component, name, id )
		}
		return cache[ucdServer][id]
	}
	
	/**
	 * When a ComponentVersion is loaded into memory, the 'created' field may be known without the rest
	 * of the additional entity data.  In that case, this function can be called.
	 * @param created Date that this componentVersion was created in milliseconds.
	 */
	public void setCreated( long created ) {
		_created = created
	}

	/**
	 * Gets the date/timestamp (as long milliseconds) for the component Version.
	 */
	public long getCreated() {
		if (_created) {
			return _created
		} else if (! additionalDataLoaded) {
			throw new Exception( "INTERNAL ERROR - you can only retrieve this data the full ComponentVersion constructor is called")
		} else {
			return _created
		}
	}
	
	/**
	 * Returns the List of Managed Properties for this Component Version.
	 * @return This returns the return value from the /cli/version/versionPropDefs
	 * API call, which is a List of Mapped data.  At a minimum, each mapped entry
	 * has a name and value property.
	 */
	public List getManagedProperties() {
		if (! _managedProperties) {
			_managedProperties = ComponentVersionApi.getComponentVersionProperties( ucdServer, component.id, this.id )
		}
		return _managedProperties
	}
	
	
	/**
	 * Returns the value of the named managed property.  If not found, this throws an exception.
	 */
	public String getManagedProperty( String name ) {
		List managedProperties = getManagedProperties()
		String value = null
		managedProperties.each { def entry ->
			if (entry.name == name) {
				value = entry.value
			}
		}
		if (value == null) {
			throw new Exception( "Unable to find a property named '${name}' for version '${this.name}' of component '${component.name}'")
		}
		return value
	}
	
	/**
	 * Is there a named Managed Property for this component version with the given name?
	 */
	public boolean doesManagedPropertyExist( String name ) {
		List managedProperties = getManagedProperties()
		boolean found = false
		managedProperties.each { def entry ->
			if (entry.name == name) {
				found = true
			}
		}
		return found
	}
	
	/**
	 * Returns a List of the ComponentVersionStatusInstance elements associated with this component version.
	 * Each element of the list is of the type 'ComponentVersionStatusInstance'.  The list may be empty.
	 * @param resetCache If true, then resets the cache of status information
	 * for this objects and reloads from UCD Server.
	 */
	public List getComponentVersionStatuses(boolean resetCache=false) {
		List statusInstances = _cached_componentVersionStatusInstances.getCacheData(resetCache)
		if (statusInstances == null) {
			statusInstances = []
			List rawList = ComponentVersionApi.getComponentVersionFlags( ucdServer, this.id )
			rawList.each { def statusDef ->
				statusInstances << new ComponentVersionStatusInstance(ucdServer, this, statusDef.name, statusDef.id)
			}
			_cached_componentVersionStatusInstances.setCacheData(statusInstances)
		}
		return statusInstances
	}
	
	/**
	 * Does this component version have the given status?
	 * @param componentVersionStatus Component version status to test for
	 * @param resetCache If true, then resets the cache of status information
	 * for this object and reloads from UCD Server.
	 */
	public boolean hasComponentVersionStatus( ComponentVersionStatus componentVersionStatus, boolean resetCache=false ) {
		return getComponentVersionStatuses(resetCache).find { ComponentVersionStatusInstance componentVersionStatusInstance ->
			return componentVersionStatusInstance.getComponentVersionStatus().equals(componentVersionStatus)
		}
	}
	
	/**
	 * Adds the given status to this component version.
	 */
	public void addComponentVersionStatus( ComponentVersionStatus componentVersionStatus ) {
		ComponentVersionApi.setComponentVersionFlag(ucdServer, this.id, componentVersionStatus.name)
		// reset the cache
		_cached_componentVersionStatusInstances .clearCacheData()
	}
}
