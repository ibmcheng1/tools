package com.ibm.css.ucd.audithistory

/**
 * Audit History Entry.
 * @author ltclark
 *
 */
class AuditHistoryEntry {
	// Implementation Notes:
	//	Because there may be a massive number of audit records, data is re-used as much as possible within nested data classes
	
	long date
	String eventType
	String description
	String status
	String id
	String ipAddress
	NestedUser nestedUser
	NestedObject nestedObject
	
	class NestedObject {
		String objType
		String objName
		String objId
	}
	//  cached map.
	//	key = objectType, value = map
	//		key = objId, value = NestedObject 
	static Map nestedObjects = [:]
	
	class NestedUser {
		String userName
		String userId
	}
	// Map of nested user information
	// Key = userId, value = NestedUser entry
	static Map nestedUsers = [:]
	
	/**
	 * Returns the date of the event as a Date object.
	 */
	public Date getEventDate() {
		return new Date(date)
	}

	public String getObjType() {
		return nestedObject.objType
	}
	
	public String getObjName() {
		return nestedObject.objName
	}
	
	public String getObjId() {
		return nestedObject.objId
	}
	
	public String getUserName() {
		return nestedUser.userName
	}
	
	public String getUserId() {
		return nestedUser.userId
	}
	
	
	/**
	 * Constructor.  This is an example of the field values:
	 * 		"date": 1525813381401,
		"eventType": "Login",
		"description": "Login Attempt",
		"objType": "SecurityUser",
		"objName": "admin",
		"objId": "20000000000000000000000001000000",
		"userId": "20000000000000000000000001000000",
		"userName": "admin",
		"status": "Success",
		"id": "660af851-a95a-4e22-8e02-dfdfb0e9952c",
		"ipAddress": "127.0.0.1"
	 * @param date
	 * @param eventType
	 * @param description
	 * @param objType
	 * @param objName
	 * @param objId
	 * @param userId
	 * @param userName
	 * @param status
	 * @param id
	 * @param ipAddress
	 */
	public AuditHistoryEntry( long date, String eventType, String description, String objType, String objName, String objId, String userId, String userName, String status, String id, String ipAddress) {
		this.date = date
		this.eventType = eventType
		this.description = description
		this.status = status
		this.id = id
		this.ipAddress = ipAddress
		
		// Nested user
		if (nestedUsers.containsKey(userId)) {
			nestedUser = nestedUsers[userId]
		} else {
			nestedUser = new NestedUser()
			nestedUser.userName = userName
			nestedUser.userId = userId
			nestedUsers[userId] = nestedUser
		}
		
		// Nested object
		if (! nestedObjects.containsKey(objType)) {
			nestedObjects[objType] = [:]
		}
		if (nestedObjects[objType].containsKey(objId)) {
			nestedObject = nestedObjects[objType][objId]
		} else {
			nestedObject = new NestedObject()
			nestedObject.objType = objType
			nestedObject.objName = objName
			nestedObject.objId = objId
			nestedObjects[objType][objId] = nestedObject
		}
	}
	
	// TODO - function to get the date as a Date()
}
