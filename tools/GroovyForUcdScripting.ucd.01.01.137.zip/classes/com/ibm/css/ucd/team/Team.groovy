package com.ibm.css.ucd.team

import com.ibm.css.rest.ucd.UcdServerConnection;
import com.ibm.css.ucd.common.EntityWithNameAndId;

/**
 * Entity class for UCD Team
 * @author ltclark
 *
 */
class Team extends EntityWithNameAndId {
	
	/**
	 * Constructor.
	 * @param ucdServer The handle to the UCD Server.
	 * @param info This is an Object version of the call to /cli/team/info.
	 * Note that it has at least two fields - name and id.
	 */
	public Team( UcdServerConnection ucdServer, def info ) {
		super( ucdServer, info.name, info.id )
	}
	
	/**
	 * Constructor.
	 * @param ucdServer Handle to the UCD Server that this entity is part of.
	 * @param name The name.
	 * @param id The id.
	 */
	public Team( UcdServerConnection ucdServer, String name, String id ) {
		super( ucdServer, name, id )
	}



}
