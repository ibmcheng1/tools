package com.ibm.css.rest.ucd.resource

import java.util.List;

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.common.InfoHelper
import com.ibm.css.rest.ucd.common.TeamMembershipApi
import com.ibm.css.ucd.agent.Agent
import com.ibm.css.ucd.component.Component
import com.ibm.issr.rest.RestDelete
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPut

/**
 * Interface to the UCD Resource API REST calls.  This is a lightweight class and it is ok to create lots of instances of it.
 * @author ltclark
 */
class ResourceApi implements TeamMembershipApi {
	UcdServerConnection ucdServer
	
	/**
	 * Constructor for this light weight class.
	 * @param ucdServer Handle to UCD Server
	 */
	public ResourceApi( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
	}

		/**
	 * Returns the list of child resources of the given resource node.
	 * @param ucdServer Handle to UCD.
	 * @param resourcePath The parent resource.
	 * @return The list of child resources.  Specifically, this is the object returned by /cli/resource.
	 */
	public static def getChildren( UcdServerConnection ucdServer, String resourcePath ) {
		if (resourcePath) {
			return (new RestGet( ucdServer )).setPath("/cli/resource").addParameter("parent", resourcePath).getAsObject()
		} else {
			// For the root level tree, don't pass parent parameter
			return (new RestGet( ucdServer )).setPath("/cli/resource").getAsObject()
		}
	}
	
	
	/**
	 * Returns the detailed information about the resource tree node as per the /cli/resource/info REST call.
	 * @param ucdServer Handle to UCD.
	 * @param resourcePath EITHER an ID of a resource OR the path to a resource tree node, such as '/root/app/env/agent/comp'.
	 */
	public static def getInfo( UcdServerConnection ucdServer, String resourcePath ) {
		return (new ResourceApi( ucdServer )).getInfo(resourcePath)
	}
	
	
	/**
	 * Returns the detailed information about the resource tree node as per the /cli/resource/info REST call.
	 * @param ucdServer Handle to UCD.
	 * @param resourcePath EITHER an ID of a resource OR the path to a resource tree node, such as '/root/app/env/agent/comp'.
	 */
	public def getInfo( String resourcePath ) {
		return (new RestGet( ucdServer )).setPath("/cli/resource/info").addParameter("resource", resourcePath).getAsObject()
	}

	/**
	 * Does the named resource node exist?
	 * @param ucdServer API handle to the UCD Server.
	 * @param ucdServer Handle to UCD.
	 * @param resourcePath The path to a resource tree node, such as '/root/app/env/agent/comp'.
	 */
	public static boolean doesResourceNodeExist( UcdServerConnection ucdServer, String resourcePath ) {
		return (new RestGet( ucdServer )).setPath("/cli/resource/info")
			.addParameter("resource", resourcePath)
			.getAsExistenceTest()
	}

	
	/**
	 * Is the given resource tree node a Component Resource??
	 * @param ucdServer Handle to UCD.
	 * @param resourcePath The path to a resource tree node, such as '/root/app/env/agent/comp'.
	 */
	public static boolean isComponentResource(UcdServerConnection ucdServer, String resourcePath) {
		boolean retval = false
		def resourceInfo = getInfo(ucdServer, resourcePath)
		if (resourceInfo.containsKey('role')) {
			def roleInfo = resourceInfo.role
			if (roleInfo.containsKey('specialType') && roleInfo.specialType.equalsIgnoreCase('COMPONENT')) {
				retval = true
			}
		}
		return retval
	}
	
	
	/**
	 * Returns the list of versions currently in the physical inventory for the resource tree node.
	 * This can be called for a non-Component Resource node, but the return list will be empty.
	 * @param ucdServer Handle to UCD.
	 * @param resourcePath The path to a resource tree node, such as '/root/app/env/agent/comp'.
	 * @return A List with the following fields: versionId - the id of the version, versionName - the
	 * name of the version, componentName - the name of the component, date - integer date value deployed.
	 */
	public static def getComponentInventory( UcdServerConnection ucdServer, String resourcePath ) {
		def inventory = []

		def resourceInfo = getInfo(ucdServer, resourcePath)
		String resourceId = resourceInfo.id
				
		def rawInventory = (new RestGet( ucdServer )).setPath("/rest/inventory/resourceInventory/table").addParameter("rowsPerPage", '1000').addParameter("pageNumber", '1').
			addParameter("orderField", 'dateCreated').addParameter("sortType", 'desc').
			addParameter("filterFields", 'resourceId').addParameter("filterFields", 'ghostedDate').
			addParameter("filterValue_resourceId", resourceId).addParameter("filterType_resourceId", 'eq').addParameter("filterClass_resourceId", 'String').
			addParameter("filterValue_ghostedDate", '0').addParameter("filterType_ghostedDate", 'eq').addParameter("filterClass_ghostedDate", 'Long').
			getAsObject()

		rawInventory.records.each { rawInventoryRecord ->
			def inventoryRecord = [:]
			inventoryRecord.versionId = rawInventoryRecord.version.id
			inventoryRecord.versionName = rawInventoryRecord.version.name
			inventoryRecord.componentName = rawInventoryRecord.component.name
			inventoryRecord.date = rawInventoryRecord.date
			inventory << inventoryRecord
		}
	
		return inventory
	}
	
	/**
	 * Creates a new 'Group Node' Resource Node in the tree.  No return value.  Throws exception on failure.
	 * @param ucdServer API handle to the UCD Server.
	 * @param parentResourcePath The path to a resource tree node's parent, such as '/root/app/env/agent/comp'.
	 * @param name The name of the new node.
	 * @param resourceRoleName This is an optional name for a Resource Role to attach to the new Group node.
	 * @param resourceRoleProperties IF a resourceRoleName is provided, this is an optional list of the properties.
	 * This is a Map field.  Each entry is a propertyName=value pair where the map key is the property name and the
	 * map value is the property value.
	 */
	public static void createGroupResourceNode( UcdServerConnection ucdServer, String parentResourcePath, String name, String resourceRoleName=null, Map resourceRoleProperties=null ) {
		def payload = [
			name: name,
			parent: parentResourcePath
		]
		if (resourceRoleName) {
			payload.role = resourceRoleName
			if (resourceRoleProperties && (! resourceRoleProperties.isEmpty())) {
				payload.roleProperties = [:]
				resourceRoleProperties.each { String propertyName, def value ->
					payload.roleProperties[propertyName] = value
				}
			}
		}
		def responseObject = (new RestPut( ucdServer )).setPath("/cli/resource/create")
				.setJsonPayloadToObject(payload)
				.putWithNoReturnObject()
	}
	
	/**
	 * Creates a new 'Agent Node' Resource Node in the tree.  No return value.  Throws exception on failure.
	 * @param ucdServer API handle to the UCD Server.
	 * @param parentResourcePath The path to a resource tree node's parent, such as '/root/app/env/agent/comp'.
	 * @param name The name of the new node.
	 * @param agent The name of the linked agent.
	 */
	public static void createAgentResourceNode( UcdServerConnection ucdServer, String parentResourcePath, String name, Agent agent ) {
		def payload = [
			name: name,
			parent: parentResourcePath,
			agent: agent.getId()
		]
		def responseObject = (new RestPut( ucdServer )).setPath("/cli/resource/create")
				.setJsonPayloadToObject(payload)
				.putWithNoReturnObject()
	}
	
	/**
	 * Creates a new 'Component Node' Resource Node in the tree.  No return value.  Throws exception on failure.
	 * @param ucdServer API handle to the UCD Server.
	 * @param parentResourcePath The path to a resource tree node's parent, such as '/root/app/env/component/comp'.
	 * @param name The name of the new node.
	 * @param component The name of the linked component.
	 */
	public static void createComponentResourceNode( UcdServerConnection ucdServer, String parentResourcePath, String name, Component component ) {
		def payload = [
			name: name,
			parent: parentResourcePath,
			role: component.getName()
		]
		def responseObject = (new RestPut( ucdServer )).setPath("/cli/resource/create")
				.setJsonPayloadToObject(payload)
				.putWithNoReturnObject()
	}
	
	/**
	 * Does this entity contain a team entry for the team and resourceType?
	 * @param ucdServer UCD Server
	 * @param resourceId The ID of the resource.
	 * @param teamId The ID of the team.
	 * @param resourceType The optional resource type. If this is null or an empty string, then this looks for a team without a type.
	 * If this is a non-empty string, then it looks for a matching resourceType entry for the team.
	 */
	public static boolean isLinkedToTeam( UcdServerConnection ucdServer, String resourceId, String teamId, String resourceType="" ) {
		return (new ResourceApi(ucdServer)).isLinkedToTeam( resourceId, teamId, resourceType )
	}
	
	/**
	 * Does this entity contain a team entry for the team and resourceType?
	 * @param ucdServer UCD Server
	 * @param resourceId The ID of the resource.
	 * @param teamId The ID of the team.
	 * @param resourceType The optional resource type. If this is null or an empty string, then this looks for a team without a type.
	 * If this is a non-empty string, then it looks for a matching resourceType entry for the team.
	 */
	public boolean isLinkedToTeam( String resourceId, String teamId, String resourceType="" ) {
		return InfoHelper.isLinkedToTeam( getInfo(resourceId), teamId, resourceType )
	}

	/**
	 * Adds a link to the given team and optionally to the resourceType (if provided)
	 * @param ucdServer UCD Server
	 * @param resourceId The ID of the resource.
	 * @param teamId The ID of the team.
	 * @param resourceType The optional resource type. If this is null or an empty string, then the team is added without a resource type.
	 * If this is a non-empty string, then the team is added with this resource type.
	 */
	public static void addLinkToTeam( UcdServerConnection ucdServer, String resourceId, String teamId, String resourceType="" ) {
		(new ResourceApi(ucdServer)).addLinkToTeam( resourceId, teamId, resourceType )
	}
	
	/**
	 * Adds a link to the given team and optionally to the resourceType (if provided)
	 * @param ucdServer UCD Server
	 * @param resourceId The ID of the resource.
	 * @param teamId The ID of the team.
	 * @param resourceType The optional resource type. If this is null or an empty string, then the team is added without a resource type.
	 * If this is a non-empty string, then the team is added with this resource type.
	 */
	public void addLinkToTeam( String resourceId, String teamId, String resourceType="" ) {
		if (! resourceType) {
			// make sure that resourceType is not null, but an empty string
			resourceType = ""
		}
		(new RestPut( ucdServer )).setPath("/cli/resource/teams")
		.addParameter( "resource", resourceId )
		.addParameter( "team", teamId )
		.addParameter( "type", resourceType )
		.putWithNoReturnObject()
	}

	/**
	 * Returns a list of Teams (and corresponding resource types) linked to this entity.
	 * @param ucdServer UCD Server
	 * @param resourceId The ID of the resource.
	 * @return A List of the linked teams.  Each entry is a map with the fields: 'teamId' and 'resourceType'.  resourceType is empty
	 * for the 'default' resource type.
	 */
	@Deprecated
	public static List getLinkedTeams(UcdServerConnection ucdServer, String resourceId) {
		return (new ResourceApi(ucdServer)).getLinkedTeams( resourceId )
	}
	
	/**
	 * Returns a list of Teams (and corresponding resource types) linked to this entity.
	 * @param resourceId The ID of the resource.
	 * @return A List of the linked teams.  Each entry is a map with the fields: 'teamId', 'teamName' and 'resourceType'.  resourceType is empty
	 * for the 'default' resource type.
	 */
	public List getLinkedTeams( String resourceId) {
		return InfoHelper.getLinkedTeams( getInfo(resourceId) )
	}
	
	/**
	 * Removes a link to the given team and optionally to the resourceType (if provided)
	 * @param ucdServer UCD Server
	 * @param resourceId The ID of the resource.
	 * @param teamId The ID of the team.
	 * @param resourceType The optional resource type.
	 */
	@Deprecated
	public static void removeLinkToTeam( UcdServerConnection ucdServer, String resourceId, String teamId, String resourceType="" ) {
		(new ResourceApi(ucdServer)).removeLinkToTeam( resourceId, teamId, resourceType )
	}
	
	/**
	 * Removes a link to the given team and optionally to the resourceType (if provided)
	 * @param resourceId The ID of the resource.
	 * @param teamId The ID of the team.
	 * @param resourceType The optional resource type.
	 */
	public void removeLinkToTeam( String resourceId, String teamId, String resourceType="" ) {
		if (! resourceType) {
			// make sure that resourceType is not null, but an empty string
			resourceType = ""
		}
		RestDelete deleteCmd = (new RestDelete(ucdServer)).setPath("/cli/resource/teams")
		.addParameter( "resource", resourceId )
		.addParameter( "team", teamId )
		if (resourceType) {
			deleteCmd.addParameter( "type", resourceType )
		}
		deleteCmd.deleteWithNoReturnObject()
	}

	/**
	 * Removes links to ALL teams that the resource is linked to.
	 * @param ucdServer UCD Server
	 * @param resourceId The ID of the resource.
	 */
	@Deprecated
	public static void removeLinksToAllTeams( UcdServerConnection ucdServer, String resourceId ) {
		(new ResourceApi(ucdServer)).removeLinksToAllTeams( resourceId )
	}
	
	/**
	 * Removes links to ALL teams that the resource is linked to.
	 * @param resourceId The ID of the resource.
	 */
	public void removeLinksToAllTeams( String resourceId ) {
		// Get the list of teams
		List teams = getLinkedTeams( resourceId )
		teams.each { def teamEntry ->
			this.removeLinkToTeam( resourceId, teamEntry.teamId, teamEntry.resourceType)
		}
	}

	/**
	 * Adds a tag label to a resource tree node.
	 * @param ucdServer UCD Server
	 * @param resourceId The ID of the resource.
	 * @param tagName The tag to add.
	 */
	public static void addTag( UcdServerConnection ucdServer, String resourceId, String tagName ) {
		def responseObject = (new RestPut( ucdServer )).setPath("/cli/resource/tag")
		.addParameter( "resource", resourceId )
		.addParameter( "tag", tagName )
		.putWithNoReturnObject()
	}
	
	/**
	 * Sets the given ad-hoc property value for the resource.
	 */
	public static void setProperty( UcdServerConnection ucdServer, String resourceId, String name, String value ) {
		Map payload = ["resource":resourceId, "name":name, "value":value ]
		def responseObject = (new RestPut( ucdServer )).setPath("/cli/resource/setProperty")
			.setJsonPayloadToObject(payload)
			.putWithNoReturnObject()
	}
	
	
	/**
	 * Returns a list of properties.
	 * @param resourceId The ID of the resource.
	 * @return This returns the structure returned by the '/cli/environment/getProperties' call which is
	 * a list.  Each member of the list has the following fields: id, name, value, description, secure (which is boolean).
	 */
	public static def getProperties( UcdServerConnection ucdServer, String resourceId ) {
		return (new RestGet( ucdServer )).setPath("/cli/resource/getProperties")
		.addParameter( "resource", resourceId )
		.getAsObject()
	}

}
