package com.ibm.css.rest.ucd

import org.apache.http.client.HttpClient

import com.ibm.css.rest.ucd.server_version.UcdVersion6_2_7
import com.ibm.css.rest.ucd.server_version.VersionBaseClass
import com.ibm.issr.core.log.Logger
import com.ibm.issr.rest.RestServerConnection
import com.urbancode.ud.client.UDRestClient

/**
 * Represents a REST connection to a UCD Server.
 * @author ltclark
 *
 */
class UcdServerConnection extends RestServerConnection {
	
	/**
	 * Is the UCD Server at or above version 6.2.7?
	 * @return
	 */
	public boolean isServerVersionAtLeast6_2_7() {
		VersionBaseClass versionTester = new UcdVersion6_2_7()
		return versionTester.isVersionAtOrAbove(this)
	}
	
	/**
	 * The UDRestClient opens a REST Connection to the server.  But the HttpClient
	 * field is protected.  This child class simply exposes the HttpClient.
	 */
	class MyRestClient extends UDRestClient {
		public MyRestClient(URI url, String clientUser, String clientPassword) {
			super(url,clientUser,clientPassword)
		}
		
		public HttpClient getClient() {
			return super.client
		}
	}
	
	/**
	 * Open a client connection to the REST server.
	 * @param serverUrl - The basic URL to the server, such as "https://server:2134".  If part
	 * of the path is included, like "https://server:2134/path", this function extracts the base url.
	 * @param username User name to use for authentication.
	 * @param password Password for authentication.
	 * @return No return, but throws exception on failure.
	 */
	public openConnection( String serverUrl, String username, String password ) {
		this.openConnection(serverUrl, username, password, "", "")
	}
	
	/**
	 * Open a client connection to the REST server with optional Proxy information.  When an Agent
	 * is called via a UCD Relay, the agent is given an http proxy host and port for communicating
	 * back with the server.  If these are not blank, this function uses them.
	 * If there is a proxy username/password, set them before calling this.
	 * @param serverUrl - The basic URL to the server, such as "https://server:2134".  If part
	 * of the path is included, like "https://server:2134/path", this function extracts the base url.
	 * @param username User name to use for authentication.
	 * @param password Password for authentication.
	 * @param proxyHost Optional proxy host.  Pass null or an empty string if there is no proxy host.  If a proxy host
	 * is provided, then a proxy port must also be supplied.
	 * @param proxyPort Optional proxy port.  Pass null or an empty string if no proxy port.  This is actually an integer value.
	 * @return No return, but throws exception on failure.
	 */
	public openConnection( String serverUrl, String username, String password, String proxyHost, String proxyPort ) {
		this.openConnection(serverUrl, username, password, proxyHost, proxyPort, "", "")
	}
	
	/**
	 * Open a client connection to the REST server with optional Proxy information.  When an Agent
	 * is called via a UCD Relay, the agent is given an http proxy host and port for communicating
	 * back with the server.  If these are not blank, this function uses them.  This version of the function
	 * also takes a proxy username and password.
	 * @param serverUrl - The basic URL to the server, such as "https://server:2134".  If part
	 * of the path is included, like "https://server:2134/path", this function extracts the base url.
	 * @param username User name to use for authentication.
	 * @param password Password for authentication.
	 * @param proxyHost Optional proxy host.  Pass null or an empty string if there is no proxy host.  If a proxy host
	 * is provided, then a proxy port must also be supplied.
	 * @param proxyPort Optional proxy port.  Pass null or an empty string if no proxy port.  This is actually an integer value.
	 * @return No return, but throws exception on failure.
	 */
	public openConnection( String serverUrl, String username, String password, String proxyHost, String proxyPort, String proxyUsername, String proxyPassword ) {

		// Connecting to a UCD Server is getting increasingly complex.  There are several environment flag options that control the connection
		// Instead of trying to duplicate that code, this function calls the UDRestClient class from the latest UCD plugins and
		// let's it establish an appropriate connection. That class reads environment properties for ALL settings except for the serverUrl,
		// username and password. So the other parameters to this class are ignored.
		
		Logger.debug "openConnection( '${serverUrl}', '${username}', '${password}' )"
		def fullServerUrl = new URL( serverUrl );
		serverRootUrl = fullServerUrl.getProtocol() + "://" + fullServerUrl.getAuthority();

		MyRestClient myRestClient = new MyRestClient(new URI(serverUrl), username, password)
		
		client = myRestClient.getClient()

	}

}
