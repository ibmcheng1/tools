package com.ibm.css.rest.ucd.request.entity

/**
 * Represents the status of an Application Process Request.
 * @author ltclark
 *
 */
class ProcessRequestStatus {
	protected String _status
	protected String _result
	// Has the future schedule been canceled?
	protected boolean _isCanceledForFuture = false
	
	/**
	 * Constructor
	 * @param status The status field from get status API call.
	 * @param result The result field from the get status API call.
	 */
	public ProcessRequestStatus( String status, String result ) {
		this._status = status
		this._result = result
	}
	
	/**
	 * Returns the 'status' value returned by UCD's API
	 */
	public String getStatus() {
		return _status
	}
	
	/**
	 * Returns the 'result' value returned by the UCD's API.  However, if this
	 * Process Request has been canceled (current or future), it returns 'CANCELED'.
	 */
	public String getResult() {
		if (canceled) {
			return "CANCELED"
		} else {
			return _result
		}
	}
	
	/**
	 * Has the Process Request been canceled during execution or in the future?
	 * @return
	 */
	public boolean isCanceled() {
		return (_result.equalsIgnoreCase('CANCELED') || _isCanceledForFuture)
	}
	
	/**
	 * Is this Process Request scheduled for the future?
	 * @return
	 */
	public boolean isScheduledForFuture() {
		if (_result == 'SCHEDULED FOR FUTURE') {
			if (_isCanceledForFuture) {
				return false
			} else {
				return true
			}
		}	
	}
	
	/**
	 * This should only be called by the code that constructs this status object.  It
	 * is set to true if this is a Process Request that was scheduled for the future, but
	 * was canceled before it ran.
	 * @param value The value.
	 */
	public void setCanceledForFuture( boolean value ) {
		_isCanceledForFuture = value
	}
}
