package com.ibm.css.rest.ucd.team

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.team.Team
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPut

class TeamApi {
	/**
	 * Retrieves the list of teams in the UCD Server as an object set.
	 * Specifically, it returns an array of the teams.  The array elements
	 * include the fields 'name' and 'id'.
	 */
	public static def getTeams(UcdServerConnection ucdServer) {
		return (new RestGet( ucdServer )).setPath("/security/team").getAsObject()
	}

	/**
	 * Calls the rest call /cli/team/info to retrieve information about a specific team.
	 * @param ucdServer Handle to the UCD Server
	 * @param teamName The name of the team.
	 * @return Returns the object that the REST call returns.
	 */
	public static def getTeamInfo( UcdServerConnection ucdServer, String teamName ) {
		return (new RestGet( ucdServer )).setPath("/cli/team/info").addParameter("team", teamName).getAsObject()
	}
	
	/**
	 * Returns a Team entity for the named team or throws exception if not found.
	 * @param ucdServer The UCD Server
	 * @param name The name of the team
	 */
	public static Team getTeamEntityFromName( UcdServerConnection ucdServer, String name ) {
		return new Team( ucdServer, getTeamInfo(ucdServer,name))
	}
	
	/**
	 * Returns the list of team members (users and groups) and their Roles.
	 * @param ucdServer The UCD Server
	 * @param teamName The name of the team.
	 * @return A List of map entries.  Each entry has the following fields:
	 * 'boolean isUser' - user or group?, 'String name' - name of user or group,
	 * 'String id' - the ID of the user or group, 'roleName' - the name of the Role,
	 * 'roleId' - the ID of the role.
	 */
	public static List getTeamMembers( UcdServerConnection ucdServer, String teamName ) {
		List teamMembers = []
		def teamInfo = getTeamInfo(ucdServer, teamName)
		teamInfo.roleMappings.each { roleMapping->
			def teamMember = [:]
			teamMember.roleName = roleMapping.role.name
			teamMember.roleId = roleMapping.role.id
			if (roleMapping.containsKey("user")) {
				teamMember.isUser = true
				teamMember.name = roleMapping.user.name
				teamMember.id = roleMapping.user.id
			} else {
				teamMember.isUser = false
				teamMember.name = roleMapping.group.name
				teamMember.id = roleMapping.group.id
			}
			teamMembers << teamMember
		}
		return teamMembers

	}
	
	/**
	 * Is the named user a role member of the team.  This ONLY checks to see if the user is a direct
	 * member of the team in the role.  It does NOT check to see if the user has role membership via a group!!
	 * @param ucdServer Handle to the UCD server
	 * @param teamName The name of the team to check.
	 * @param userName The name of the user to check.
	 * @param roleName The name of the desired role.
	 * @return True if it is a member otherwise false.
	 */
	public static boolean isUserAMemberAsRole( UcdServerConnection ucdServer, String teamName, String userName, String roleName ) {
		def teamInfo = getTeamInfo(ucdServer, teamName)
		boolean retval = false
		teamInfo.roleMappings.each { roleMapping->
			if (roleMapping.role.name.equals(roleName) && roleMapping.containsKey("user") && roleMapping.user.name.equals(userName)) {
				retval = true
			}
		} 
		return retval
	} 
	
	/**
	 * Is the named group a role member of the team.
	 * @param ucdServer Handle to the UCD server
	 * @param teamName The name of the team to check.
	 * @param groupName The name of the group to check.
	 * @param roleName The name of the desired role.
	 * @return True if it is a member otherwise false.
	 */
	public static boolean isGroupAMemberAsRole( UcdServerConnection ucdServer, String teamName, String groupName, String roleName ) {
		def teamInfo = getTeamInfo(ucdServer, teamName)
		boolean retval = false
		teamInfo.roleMappings.each { roleMapping->
			if (roleMapping.role.name.equals(roleName) && roleMapping.containsKey("group") && roleMapping.group.name.equals(groupName)) {
				retval = true
			}
		} 
		return retval
	} 
	
	/**
	 * Adds the named user to the given team within the given role.  Note that this does
	 * NOT check to see if the user is already a role member of the given team first.
	 * @param ucdServer Handle to the UCD server
	 * @param teamName The name of the team.
	 * @param userName The name of the user.
	 * @param roleName The name of the role.
	 */
	public static void addUserToTeamAsRole( UcdServerConnection ucdServer, String teamName, String userName, String roleName ) {
		(new RestPut( ucdServer )).setPath("/cli/teamsecurity/users")
			.addParameter("user", userName)
			.addParameter("team", teamName)
			.addParameter("role", roleName)
			.putWithNoReturnObject()
	}
	
	/**
	 * Removes the named group from the given team/role.
	 * @param ucdServer Handle to the UCD server.
	 * @param teamName The name of the team.
	 * @param groupName The name of the group.
	 * @param roleName The name of the role.
	 */
	public static void removeGroupFromTeamRole( UcdServerConnection ucdServer, String teamName, String groupName, String roleName ) {

		//Logger.debug "TeamApi.removeGroupFromTeamRole(team=${teamName}, group=${groupName}, role=${roleName}"
		
		// get the and its members users/groups
		def teamDef = (new RestGet( ucdServer )).setPath("/cli/team/info")
			.addParameter('team', teamName)
			.getAsObject()
			
//		Logger.info "/cli/team/info returned ${groovy.json.JsonOutput.toJson(teamDef)}"
		
		// The update needs to be in the format:
		//	{ name: 'teamName',
		//		roleMappings: [
		//			{user: "userId", role: "roleId"},
		//			{group: "groupId", role: "roleId"},
		//			...
		//		]
		//	}
		
		def updateData = [name: teamName, roleMappings: []]
		teamDef.roleMappings.each { def entry ->
			if (entry.containsKey('group')) {
				if (entry.group.name==groupName && entry.role.name==roleName) {
					// This is the group, team, role that is being deleted, so skip processing it
				} else {
					updateData.roleMappings << [group:entry.group.id, role:entry.role.id]
				}
			} else if (entry.containsKey('user')) {
				updateData.roleMappings << [user:entry.user.id, role:entry.role.id]
			}
		}
		
//		Logger.info "Processed list is ${groovy.json.JsonOutput.toJson(updateData)}"

		(new RestPut( ucdServer )).setPath("/security/team/${teamDef.id}")
			.setJsonPayloadToObject(updateData)
			.putWithNoReturnObject()
	}
	/**
	 * Adds the named group to the given team within the given role.  Note that this does
	 * NOT check to see if the group is already a role member of the given team first.
	 * @param ucdServer Handle to the UCD server
	 * @param teamName The name of the team.
	 * @param groupName The name of the group.
	 * @param roleName The name of the role.
	 */
	public static void addGroupToTeamAsRole( UcdServerConnection ucdServer, String teamName, String groupName, String roleName ) {
		(new RestPut( ucdServer )).setPath("/cli/teamsecurity/groups")
			.addParameter("group", groupName)
			.addParameter("team", teamName)
			.addParameter("role", roleName)
			.putWithNoReturnObject()
	}
}
