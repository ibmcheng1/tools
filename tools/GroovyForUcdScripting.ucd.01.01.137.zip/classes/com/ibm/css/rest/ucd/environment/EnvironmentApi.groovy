package com.ibm.css.rest.ucd.environment

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.rest.ucd.common.InfoHelper
import com.ibm.css.rest.ucd.common.TeamMembershipApi;
import com.ibm.css.ucd.environment.Environment
import com.ibm.issr.rest.RestDelete
import com.ibm.issr.rest.RestGet
import com.ibm.issr.rest.RestPut

/**
 * Interface to the UCD Environment API REST calls.  This is a lightweight class and it is ok to create lots of instances of it.
 * @author ltclark
 */
class EnvironmentApi implements TeamMembershipApi {
	UcdServerConnection ucdServer
	
	/**
	 * Constructor for this light weight class.
	 * @param ucdServer Handle to UCD Server
	 */
	public EnvironmentApi( UcdServerConnection ucdServer ) {
		this.ucdServer = ucdServer
	}
	
	/**
	 * Returns the information for the environment given an application and environment.
	 * @param ucdServer Handle to the UCD Server.
	 * @param applicationId The ID of the application that the environment is in.
	 * @param environmentNameOrId The name or ID of the environment.
	 * @return The information returned by /cli/environment/info
	 */
	@Deprecated
	public static def getEnvironmentInfo( UcdServerConnection ucdServer, String applicationId, String environmentNameOrId ) {
		return (new EnvironmentApi(ucdServer)).getEnvironmentInfo( applicationId, environmentNameOrId)
	}
	
	/**
	 * Returns the information for the environment given an application and environment.
	 * @param applicationId The ID of the application that the environment is in.
	 * @param environmentNameOrId The name or ID of the environment.
	 * @return The information returned by /cli/environment/info
	 */
	public def getEnvironmentInfo( String applicationId, String environmentNameOrId ) {
		return (new RestGet( ucdServer )).setPath("/cli/environment/info").addParameter("application", applicationId).addParameter("environment",environmentNameOrId).getAsObject()
	}

	/**
	 * Returns the standard REST 'information' for this entity.  This is an alias for getEnvironmentInfo()
	 * @param ucdServer Handle to the UCD Server.
	 * @param applicationId The ID of the application that the environment is in.
	 * @param environmentNameOrId The name or ID of the environment.
	 * @return The information returned by /cli/.../info
	 */
	@Deprecated
	public static def getInfo( UcdServerConnection ucdServer, String applicationId, String environmentNameOrId ) {
		return (new EnvironmentApi(ucdServer)).getInfo( applicationId, environmentNameOrId )
	}
	
	/**
	 * Returns the standard REST 'information' for this entity.  This is an alias for getEnvironmentInfo()
	 * @param applicationId The ID of the application that the environment is in.
	 * @param environmentNameOrId The name or ID of the environment.
	 * @return The information returned by /cli/.../info
	 */
	public def getInfo( String applicationId, String environmentNameOrId ) {
		return getEnvironmentInfo( ucdServer, applicationId, environmentNameOrId )
	}

	/**
	 * Returns the information for the environment given JUST the environment ID.
	 * @param ucdServer Handle to the UCD Server.
	 * @param environmentId The ID of the environment to look up.
	 * @return The information returned by /cli/environment/info
	 */
	@Deprecated
	public static def getEnvironmentInfo( UcdServerConnection ucdServer, String environmentId ) {
		return (new EnvironmentApi(ucdServer)).getEnvironmentInfo( environmentId )
	}
	
	/**
	 * Returns the information for the environment given JUST the environment ID.
	 * @param environmentId The ID of the environment to look up.
	 * @return The information returned by /cli/environment/info
	 */
	public def getEnvironmentInfo( String environmentId ) {
		return (new RestGet( ucdServer )).setPath("/cli/environment/info").addParameter("environment",environmentId).getAsObject()
	}

	/**
	 * Returns the standard REST 'information' for this entity.  This is an alias for getEnvironmentInfo()
	 * @param ucdServer Handle to the UCD Server.
	 * @param environmentId The ID of the environment to look up.
	 * @return The information returned by /cli/.../info
	 */
	@Deprecated
	public static def getInfo( UcdServerConnection ucdServer, String environmentId ) {
		return (new EnvironmentApi(ucdServer)).getInfo( environmentId )
	}
	
	/**
	 * Returns the standard REST 'information' for this entity.  This is an alias for getEnvironmentInfo()
	 * @param environmentId The ID of the environment to look up.
	 * @return The information returned by /cli/.../info
	 */
	public def getInfo( String environmentId ) {
		return getEnvironmentInfo( environmentId )
	}

	
	/**
	 * Returns the Environment ID.
	 * @param ucdServer Handle to the UCD Server.
	 * @param applicationId The ID of the application that the environment is in.
	 * @param environmentName The name of the environment.
	 * @return The ID.
	 */
	@Deprecated
	public static String getEnvironmentId( UcdServerConnection ucdServer, String applicationId, String environmentName ) {
		return (new EnvironmentApi(ucdServer)).getEnvironmentId( environmentName )
	}
	
	/**
	 * Returns the Environment ID.
	 * @param applicationId The ID of the application that the environment is in.
	 * @param environmentName The name of the environment.
	 * @return The ID.
	 */
	public String getEnvironmentId( String applicationId, String environmentName ) {
		def environmentInfo = getEnvironmentInfo(applicationId, environmentName)
		return environmentInfo.id
	}

	/**
	 * Returns an Environment Entity for the named application.
	 * @param ucdServer Handle to the UCD Server.
	 * @param applicationId The ID of the application that the environment is in.
	 * @param environmentName The name of the environment.
	 */
	@Deprecated
	public static Environment getEnvironmentEntityFromName( UcdServerConnection ucdServer, String applicationId, String environmentName ) {
		return (new EnvironmentApi(ucdServer)).getEnvironmentEntityFromName( environmentName )
	}
	
	/**
	 * Returns an Environment Entity for the named application.
	 * @param applicationId The ID of the application that the environment is in.
	 * @param environmentName The name of the environment.
	 */
	public Environment getEnvironmentEntityFromName( String applicationId, String environmentName ) {
		return new Environment( ucdServer, getEnvironmentInfo( applicationId, environmentName ))
	}

	/**
	 * Does the named environment exist as a child of the application?
	 * @param ucdServer API handle to the UCD Server.
	 * @param applicationId The ID of the application that the environment is in.
	 * @param environmentName The name of the environment.
	 * @return true or false
	 */
	@Deprecated
	public static boolean doesEnvironmentExist( UcdServerConnection ucdServer, String applicationId, String environmentName ) {
		return (new EnvironmentApi(ucdServer)).doesEnvironmentExist( applicationId, environmentName )
	}
	
	/**
	 * Does the named environment exist as a child of the application?
	 * @param applicationId The ID of the application that the environment is in.
	 * @param environmentName The name of the environment.
	 * @return true or false
	 */
	public boolean doesEnvironmentExist( String applicationId, String environmentName ) {
		return (new RestGet( ucdServer )).setPath("/cli/environment/info")
			.addParameter("application", applicationId)
			.addParameter("environment",environmentName)
			.getAsExistenceTest()
	}

	
	
	/**
	 * Returns an array containing information on the base resources linked to
	 * the environment.
	 * @param ucdServer Handle to the server.
	 * @param environmentId The ID of the environment.
	 * @return Returns the information from the REST call to /cli/environment/getBaseResources
	 */
	@Deprecated
	public static def getBaseResources(UcdServerConnection ucdServer, String environmentId) {
		return (new EnvironmentApi(ucdServer)).getBaseResources( environmentId )
	}
	
	/**
	 * Returns an array containing information on the base resources linked to
	 * the environment.
	 * @param environmentId The ID of the environment.
	 * @return Returns the information from the REST call to /cli/environment/getBaseResources
	 */
	public def getBaseResources( String environmentId) {
		return (new RestGet( ucdServer )).setPath("/cli/environment/getBaseResources").addParameter("environment",environmentId).getAsObject()
	}
	
	/**
	 * Adds a new base resource to the environment.
	 * @param ucdServer UCD Server
	 * @param environmentId The environment's ID
	 * @param resourceId The ID of the resource node to add.
	 */
	@Deprecated
	public static void addBaseResource( UcdServerConnection ucdServer, String environmentId, String resourceId ) {
		(new EnvironmentApi(ucdServer)).addBaseResource( environmentId, resourceId )
	}

	/**
	 * Adds a new base resource to the environment.
	 * @param environmentId The environment's ID
	 * @param resourceId The ID of the resource node to add.
	 */
	public void addBaseResource( String environmentId, String resourceId ) {
		(new RestPut( ucdServer )).setPath("/cli/environment/addBaseResource")
		.addParameter( "environment", environmentId )
		.addParameter( "resource", resourceId )
		.putWithNoReturnObject()
	}
	
	/**
	 * Sets an environment property value. Note that this sets ad-hoc properties and NOT component based properties.
	 * Note that if a Component Process changes the Environment that the current process is running in, the changes do NOT
     * appear immediately.  When UCD calls a process, it copies the Environment properties to the process
     * instance and does NOT update and changes.  Note that this doesn't include 'description' because the underlying
     * REST API call that is made doesn't support 'description'.
	 * @param ucdServer Handle to the UCD Server
	 * @param environmentId Target environment.
	 * @param name The name of the property
	 * @param value The value of the property
	 * @param isSecure Is this a secure field?
	 */
	@Deprecated
	public static void setEnvironmentProperty( UcdServerConnection ucdServer, String environmentId, String name, String value, boolean isSecure=false ) {
		(new EnvironmentApi(ucdServer)).setEnvironmentProperty( environmentId, name, value, isSecure )
	}
	
	/**
	 * Sets an environment property value. Note that this sets ad-hoc properties and NOT component based properties.
	 * Note that if a Component Process changes the Environment that the current process is running in, the changes do NOT
	 * appear immediately.  When UCD calls a process, it copies the Environment properties to the process
	 * instance and does NOT update and changes.  Note that this doesn't include 'description' because the underlying
	 * REST API call that is made doesn't support 'description'.
	 * @param environmentId Target environment.
	 * @param name The name of the property
	 * @param value The value of the property
	 * @param isSecure Is this a secure field?
	 */
	public void setEnvironmentProperty( String environmentId, String name, String value, boolean isSecure=false ) {
		// Note: Starting with version 6.2.7 of UCD, the API call completely changed and now uses a json payload
		if (ucdServer.isServerVersionAtLeast6_2_7()) {
			def payload = [
				environment: environmentId,
				name: name,
				value: value,
				isSecure: isSecure
				]
			(new RestPut( ucdServer )).setPath("/cli/environment/propValue")
				.setPayload( groovy.json.JsonOutput.toJson( payload ) )
				.putWithNoReturnObject()
		} else {
			(new RestPut( ucdServer )).setPath("/cli/environment/propValue")
				.addParameter( "name", name )
				.addParameter( "value", value )
				.addParameter( "isSecure", isSecure.toString() )
				.addParameter( "environment", environmentId )
				.putWithNoReturnObject()
		}
	}
	
	/**
	 * Is there a property for the environment with the given name?  This only checks the ad-hoc 'Environment Properties'.
	 * This does NOT include 'basic' (aka Template defined) properties or Component (Template) defined properties.
	 */
	@Deprecated
	public static boolean doesPropertyExist( UcdServerConnection ucdServer, String environmentId, String name ) {
		return (new EnvironmentApi(ucdServer)).doesPropertyExist( environmentId, name )
	}

	/**
	 * Is there a property for the environment with the given name?  This only checks the ad-hoc 'Environment Properties'.
	 * This does NOT include 'basic' (aka Template defined) properties or Component (Template) defined properties.
	 */
	public boolean doesPropertyExist( String environmentId, String name ) {
		boolean found = false
		def properties = (new RestGet( ucdServer )).setPath("/cli/environment/getProperties")
			.addParameter("environment",environmentId)
			.getAsObject()
		properties.each { property ->
			if (property.name == name) {
				found = true
			}
		}
		return found
	}
	
	
	/**
	 * Creates a new environment.  This supports named parameters, such as
	 * createEnvironment( ucdServer, appId, envName, [ color: '%23ff0000', requireApprovals: true ] )
	 * @param namedParams For passing named parameters.  Supported are String description,
	 * String color (which is an RGB value), boolean requireApprovals and boolean
	 * noSelfApprovals.
	 * @param ucdServer API handle to the UCD Server.
	 * @param applicationId The ID of the application that the environment is in.
	 * @param environmentName The name of the environment.
	 */
	@Deprecated
	public static void createEnvironment( UcdServerConnection ucdServer, String applicationId, String environmentName, Map namedParams = null ) {
		(new EnvironmentApi(ucdServer)).createEnvironment( applicationId, environmentName, namedParams )
	}

	
	/**
	 * Creates a new environment.  This supports named parameters, such as
	 * createEnvironment( appId, envName, [ color: '%23ff0000', requireApprovals: true ] )
	 * @param namedParams For passing named parameters.  Supported are String description,
	 * String color (which is an RGB value), boolean requireApprovals and boolean
	 * noSelfApprovals.
	 * @param applicationId The ID of the application that the environment is in.
	 * @param environmentName The name of the environment.
	 */
	public void createEnvironment( String applicationId, String environmentName, Map namedParams = null ) {
		RestPut restPut = (new RestPut( ucdServer )).setPath("/cli/environment/createEnvironmentFromTemplate")
			.addParameter( "application", applicationId )
			.addParameter( "name", environmentName )
		if (namedParams) {
			namedParams.each{ def key, def value ->
				restPut.addParameter( key, value.toString() )
			}
		}
		restPut.putWithNoReturnObject()
	}
	
	/**
	 * Creates a new enviroment from an environment template.
	 * @param applicationId The application to add environment to.
	 * @param templateId The ID of the template to use.
	 * @param environmentName The name of the new environment.
	 */
	public void createEnvironmentFromTemplate( String applicationId, String templateId, String environmentName, String description='' ) {
		def payload = [
			applicationId: applicationId,
			description: description,
			name: environmentName,
			templateId: templateId
			]
		RestPut restPut = (new RestPut( ucdServer )).setPath("/cli/environment/createEnvironmentFromTemplate")
			.setPayload( groovy.json.JsonOutput.toJson(payload) )
			.putWithNoReturnObject()
	}

	/**
	 * Does the environment contain a team entry for the team and resourceType?
	 * @param ucdServer UCD Server
	 * @param environmentId The ID of the environment.
	 * @param teamId The ID of the team.
	 * @param resourceType The optional resource type. If this is null or an empty string, then this looks for a team without a type.
	 * If this is a non-empty string, then it looks for a matching resourceType entry for the team.
	 */
	@Deprecated
	public static boolean isLinkedToTeam( UcdServerConnection ucdServer, String environmentId, String teamId, String resourceType="" ) {
		return (new EnvironmentApi(ucdServer)).isLinkedToTeam( environmentId, teamId, resourceType )
	}
	
	/**
	 * Does the environment contain a team entry for the team and resourceType?
	 * @param environmentId The ID of the environment.
	 * @param teamId The ID of the team.
	 * @param resourceType The optional resource type. If this is null or an empty string, then this looks for a team without a type.
	 * If this is a non-empty string, then it looks for a matching resourceType entry for the team.
	 */
	public boolean isLinkedToTeam( String environmentId, String teamId, String resourceType="" ) {
		return InfoHelper.isLinkedToTeam( getInfo(environmentId), teamId, resourceType )
	}

	/**
	 * Returns a list of Teams (and corresponding resource types) linked to this entity.
	 * @param ucdServer UCD Server
	 * @param environmentId The ID of the environment.
	 * @return A List of the linked teams.  Each entry is a map with the fields: 'teamId' and 'resourceType'.  resourceType is empty
	 * for the 'default' resource type.
	 */
	@Deprecated
	public static List getLinkedTeams(UcdServerConnection ucdServer, String environmentId) {
		return (new EnvironmentApi(ucdServer)).getLinkedTeams( environmentId )
	}
	
	/**
	 * Returns a list of Teams (and corresponding resource types) linked to this entity.
	 * @param environmentId The ID of the environment.
	 * @return A List of the linked teams.  Each entry is a map with the fields: 'teamId', 'teamName' and 'resourceType'.  resourceType is empty
	 * for the 'default' resource type.
	 */
	public List getLinkedTeams( String environmentId) {
		return InfoHelper.getLinkedTeams( getInfo(environmentId) )
	}

	/**
	 * Removes a link to the given team and optionally to the resourceType (if provided)
	 * @param ucdServer UCD Server
	 * @param environmentId The ID of the environment.
	 * @param teamId The ID of the team.
	 * @param resourceType The optional resource type.
	 */
	@Deprecated
	public static void removeLinkToTeam( UcdServerConnection ucdServer, String environmentId, String teamId, String resourceType="" ) {
		(new EnvironmentApi(ucdServer)).removeLinkToTeam( environmentId, teamId, resourceType )
	}
	
	/**
	 * Removes a link to the given team and optionally to the resourceType (if provided)
	 * @param environmentId The ID of the environment.
	 * @param teamId The ID of the team.
	 * @param resourceType The optional resource type.
	 */
	public void removeLinkToTeam( String environmentId, String teamId, String resourceType="" ) {
		if (! resourceType) {
			// make sure that resourceType is not null, but an empty string
			resourceType = ""
		}
		RestDelete deleteCmd = (new RestDelete(ucdServer)).setPath("/cli/environment/teams")
		.addParameter( "environment", environmentId )
		.addParameter( "team", teamId )
		if (resourceType) {
			deleteCmd.addParameter( "type", resourceType )
		}
		deleteCmd.deleteWithNoReturnObject()
	}

	/**
	 * Removes links to ALL teams that the environment is linked to.
	 * @param ucdServer UCD Server
	 * @param environmentId The ID of the environment.
	 */
	@Deprecated
	public static void removeLinksToAllTeams( UcdServerConnection ucdServer, String environmentId ) {
		(new EnvironmentApi(ucdServer)).removeLinksToAllTeams( environmentId )
	}
	
	/**
	 * Removes links to ALL teams that the environment is linked to.
	 * @param environmentId The ID of the environment.
	 */
	public void removeLinksToAllTeams( String environmentId ) {
		// Get the list of teams
		List teams = getLinkedTeams( environmentId )
		teams.each { def teamEntry ->
			EnvironmentApi.removeLinkToTeam(ucdServer, environmentId, teamEntry.teamId, teamEntry.resourceType)
		}
	}

	/**
	 * Adds a link to the given team and optionally to the resourceType (if provided)
	 * @param ucdServer UCD Server
	 * @param environmentId The ID of the environment.
	 * @param teamId The ID of the team.
	 * @param resourceType The optional resource type. If this is null or an empty string, then the team is added without a resource type.
	 * If this is a non-empty string, then the team is added with this resource type.
	 */
	@Deprecated
	public static void addLinkToTeam( UcdServerConnection ucdServer, String environmentId, String teamId, String resourceType="" ) {
		(new EnvironmentApi(ucdServer)).addLinkToTeam( environmentId, teamId, resourceType )
	}
	
	/**
	 * Adds a link to the given team and optionally to the resourceType (if provided)
	 * @param environmentId The ID of the environment.
	 * @param teamId The ID of the team.
	 * @param resourceType The optional resource type. If this is null or an empty string, then the team is added without a resource type.
	 * If this is a non-empty string, then the team is added with this resource type.
	 */
	public void addLinkToTeam( String environmentId, String teamId, String resourceType="" ) {
		if (! resourceType) {
			// make sure that resourceType is not null, but an empty string
			resourceType = ""
		}
		(new RestPut( ucdServer )).setPath("/cli/environment/teams")
		.addParameter( "environment", environmentId )
		.addParameter( "team", teamId )
		.addParameter( "type", resourceType )
		.putWithNoReturnObject()
	}

	/**
	 * Creates a new snapshot of the environment.
	 * @param ucdServer UCD Server
	 * @param applicationId The ID of the application that the environment is in.  Note that this field should not
	 * be required, but when I am using just the environment ID, the call is failing!!
	 * @param environmentId The ID of the environment.
	 * @param snapshotName The name of the new snapshot.
	 * @return Returns the ID of the new snapshot.
	 */
	@Deprecated
	public static String createSnapshot( UcdServerConnection ucdServer, String applicationId, String environmentId, String snapshotName ) {
		return (new EnvironmentApi(ucdServer)).createSnapshot( applicationId, environmentId, snapshotName )
	}
	
	/**
	 * Creates a new snapshot of the environment.
	 * @param applicationId The ID of the application that the environment is in.  Note that this field should not
	 * be required, but when I am using just the environment ID, the call is failing!!
	 * @param environmentId The ID of the environment.
	 * @param snapshotName The name of the new snapshot.
	 * @return Returns the ID of the new snapshot.
	 */
	public String createSnapshot( String applicationId, String environmentId, String snapshotName ) {
		def retObject = (new RestPut( ucdServer )).setPath("/cli/snapshot/createSnapshotOfEnvironment")
		.addParameter( "environment", environmentId )
		.addParameter( "application", applicationId)
		.addParameter( "name", snapshotName )
		.putAsObject()
		return retObject.id
	}

	/**
	 * Looks up the latest snapshot for an environment.
	 * @param ucdServer UCD Server
	 * @param environmentId The environment.
	 * @return If there is no latest snapshot, this returns null.  Otherwise, this returns a map with an 'id' and 'name' field of the snapshot.
	 */
	@Deprecated
	public static def getLatestSnapshot( UcdServerConnection ucdServer, String environmentId ) {
		return (new EnvironmentApi(ucdServer)).getLatestSnapshot( environmentId )
	} 
	
	/**
	 * Looks up the latest snapshot for an environment.
	 * @param environmentId The environment.
	 * @return If there is no latest snapshot, this returns null.  Otherwise, this returns a map with an 'id' and 'name' field of the snapshot.
	 */
	public def getLatestSnapshot( String environmentId ) {
		// IMPLEMENTATION NOTE: The API call to UCD to get the latest snapshot is quite unusual!!
		// If there is no latest snapshot, the REST call doesn't return ANYTHING.  It returns no error (so it
		// looks like the call worked).  It returns no body.  It returns no response.  BUT, it DOES return.
		// I had to modify the getAsObject() function to handle a complete non-response (as a null return).
		def restReturn = (new RestGet( ucdServer )).setPath("/cli/environment/${environmentId}/snapshot")
			.getAsObject()
		if (restReturn) {
			return [ id: restReturn.id, name: restReturn.name ]
		} else {
			return null
		}
	}

	/**
	 * Returns a list of environment properties.  This only checks the ad-hoc 'Environment Properties'.
	 * This does NOT include 'basic' (aka Template defined) properties or Component (Template) defined properties.
	 * @param ucdServer UCD Server
	 * @param environmentId The environment.
	 * @return This returns the structure returned by the '/cli/environment/getProperties' call which is
	 * a list.  Each member of the list has the following fields: id, name, value, description, secure (which is boolean).
	 */
	@Deprecated
	public static def getEnvironmentProperties( UcdServerConnection ucdServer, String environmentId ) {
		return (new EnvironmentApi(ucdServer)).getEnvironmentProperties( environmentId )
	}

	/**
	 * Returns a list of environment properties.  This only checks the ad-hoc 'Environment Properties'.
	 * This does NOT include 'basic' (aka Template defined) properties or Component (Template) defined properties.
	 * @param environmentId The environment.
	 * @return This returns the structure returned by the '/cli/environment/getProperties' call which is
	 * a list.  Each member of the list has the following fields: id, name, value, description, secure (which is boolean).
	 */
	public def getEnvironmentProperties( String environmentId ) {
		return (new RestGet( ucdServer )).setPath("/cli/environment/getProperties")
		.addParameter( "environment", environmentId )
		.getAsObject()
	}
}
