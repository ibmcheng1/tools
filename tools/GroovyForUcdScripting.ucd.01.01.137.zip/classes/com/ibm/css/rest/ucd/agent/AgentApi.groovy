package com.ibm.css.rest.ucd.agent

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.agent.Agent
import com.ibm.issr.rest.RestGet

class AgentApi {
	/**
	 * Returns info about an Agent as per the /cli/agentCLI/info REST API call.
	 * @param ucdServer Handle to the UCD server.
	 * @param applicationName The name of the agent.
	 * @return The object map.
	 */
	public static def getAgentInfo( UcdServerConnection ucdServer, String agentName ) {
		return (new RestGet( ucdServer )).setPath("/cli/agentCLI/info")
			.addParameter("agent", agentName)
			.getAsObject()
	}
	
	/**
	 * Does the named agent exist?
	 * @param ucdServer Handle to the UCD server.
	 * @param applicationName The name of the agent.
	 */
	public static def doesAgentExist( UcdServerConnection ucdServer, String agentName ) {
		return (new RestGet( ucdServer )).setPath("/cli/agentCLI/info")
			.addParameter("agent", agentName)
			.getAsExistenceTest()
	}
	
	/**
	 * Returns 'Agent' entity class instance for named agent.  Throws exception on failure.
	 * @param ucdServer Handle to the UCD server.
	 * @param applicationName The name of the agent.
	 * @return The object map.
	 */
	public static Agent getAgentEntityFromName( UcdServerConnection ucdServer, String agentName ) {
		return new Agent( ucdServer, getAgentInfo( ucdServer, agentName ))
	}

}
