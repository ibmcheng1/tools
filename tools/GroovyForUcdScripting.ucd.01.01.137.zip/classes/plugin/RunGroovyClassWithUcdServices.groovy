package plugin

import com.ibm.css.rest.ucd.UcdServerConnection
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.dynamicgroovy.AdhocGroovyClassLoader
import com.ibm.issr.core.log.Logger
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook

class RunGroovyClassWithUcdServices extends UCPluginStepImplementation  {
	private UcdServerConnection ucdServer
	
	public static void main( java.lang.String[] args ) {
		def stepImpl = new RunGroovyClassWithUcdServices()
		stepImpl.performStep(args) { stepImpl.execute() }
	}
	
	/**
	 * This function implements the step!!
	 */
	void execute() {
		
		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************

		// Display a summary of what this plugin is going to do
		Logger.info "Run Groovy Class With Ucd Services"
		String groovyScript = retrieveInProp("groovyScript")
		String groovyScriptClassname = retrieveAndDisplayInProp("groovyScriptClassname")
		super.displayParameters()

		// Get handle to UCD Server
		ucdServer = new UcdServerConnection()
		ucdServer.openConnection(myRestServerUrl, myRestServerTokenUsername, myRestServerTokenPassword, myRestServerProxyHost, myRestServerProxyPort, myRestServerProxyUsername, myRestServerTokenPassword)
		
		// Load the dynamic ad-hoc extension point class
		ScriptWithUcdServicesHook buildOutHook = AdhocGroovyClassLoader.getInstance().loadAdhocGroovyClass(groovyScript, groovyScriptClassname).newInstance()
		
		buildOutHook.runScript( new UcdConnectionServices(ucdServer), outProps )
	}

}
