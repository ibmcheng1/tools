
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook

/**
 * Groovy script class which has access to UCD API Services.
 *
 */
class GetLatestComponentVersionsForApplication extends ScriptWithUcdServicesHook {
	//***************************
	//  UCD PARAMETERS
	//***************************

	String applicationName = "Sample App"
	String processRequestId = "${p:parentRequest.id}"
	
	
	/**
	 * This is the script function that is executed.
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {

		// Get the application
		Application application = ucdConnectionServices.getApplicationServices().getApplication(applicationName)

		// Get the components
		List applicationComponents = application.getComponents()
		
		// Get a filtered list of Versions for each component
		String filter = '1.*.0*'
		applicationComponents.each { Component component ->
			println "App Component: " + component.getName()
			List versions = component.getComponentVersionsMatchingWildcard(filter)
			//println "VERSIONS (json): " + groovy.json.JsonOutput.toJson( versions )
			versions.each { ComponentVersion version ->
				println "\tversion: ${version.name}, ${version.created}"
			}
			
			// Find the newest (most recently created) version
			ComponentVersion newestVersion = null
			versions.each { ComponentVersion version ->
				if (newestVersion==null || newestVersion.created<version.created) {
					newestVersion = version
				} 
			}
			if (newestVersion) {
				println "\t*** Newest version is ${newestVersion.name}"
			}
		}
		
	}
}