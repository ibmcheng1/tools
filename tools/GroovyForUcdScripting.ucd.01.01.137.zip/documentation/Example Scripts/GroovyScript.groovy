import com.ibm.css.ucd.agent.Agent
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.common.EntityWithNameIdAndTeams
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.resource.ComponentResourceNode;
import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.css.ucd.resource.ResourceTree
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.css.ucd.team.Team
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.plugin.PluginHelper
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook


/**
 * Groovy script class which has access to UCD API Services.
 */
class GroovyScript extends ScriptWithUcdServicesHook {
	UcdConnectionServices ucdConnectionServices
	
	// *****************************************
	//    PARAMETERS
	// *****************************************
	String applicationName = 'PIEE'

	// *****************************************
	//    SETTINGS
	// *****************************************
	String outputFileName = "applicationComponents.json"
	
	// *****************************************
	//    INTERNAL DATA
	// *****************************************
	// applicationComponents is a Map of the application's components.
	// key = component id, value is Component
	Map applicationComponents = [:]

	/**
	 * This is the script function that is executed.
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
		this.ucdConnectionServices = ucdConnectionServices
		
		// results is a map with the following fields
		//	application - structure with application information
		//		name
		//		id
		//	components - list of components in the application.  It is a list of structures.  Each member includes
		//		name - name of the component
		//		id - id of the component
		//	environments - List of environments.  Each member is a structure:
		//		name - String name of environment
		//		id - String id of environment
		//		components - List of components in the environment.  Each member includes
		//			name - name of the component
		//			resources - List of component resource locations
		//				path - the full path and name of the component resource location
		//				id - the id of the component resource
		//		missingComponents - List of app components not in environment.  Each member has
		//			name - name of component
		Map results = [
			"application":[
				"name": applicationName
				],
			"components":[],
			"environments":[]
			]

		// Get the application
		Application application = ucdConnectionServices.getApplicationServices().getApplication(applicationName)
		results.application.identity = application.id
		
		// Get the components in the application
		List components = application.getComponents()
		components.each { Component component ->
			Map componentDef = ["name":component.name, "id":component.id]
			results.components << componentDef
			// Add to the indexed list of components
			applicationComponents[component.id] = component
		}
		// Iterate the environments
		application.getEnvironments().each { Environment environment ->
			Map environmentDef = [ "name": environment.name, "id": environment.id, "components":[], "missingComponents":[] ]
			// Iterate the base resources for the environment
			environment.getBaseResources().each { ResourceNode resourceNode ->
				recursivelySearchForComponentResources( environmentDef.components, resourceNode )
			}
			// Figure out the missing components - to do so, build a Map of the environment components
			// where the key is the component name and the value is the environment component entry
			Map environmentComponentMap = [:]
			environmentDef.components.each { Map componentDef ->
				environmentComponentMap[componentDef.name] = componentDef
			}
			results.components.each { Map appComponentDef ->
				if (! environmentComponentMap.containsKey(appComponentDef.name)) {
					environmentDef.missingComponents << ["name":appComponentDef.name, "id":appComponentDef.id]
				}
			}
			results.environments << environmentDef
		}
		
		String resultsJson = groovy.json.JsonOutput.toJson( results )
		Logger.info "Results: " + resultsJson
		File outputFile = new File( outputFileName )
		outputFile.text = resultsJson
		Logger.info "Generated JSON data written to '" + outputFileName + "'"
	}
	
	/**
	 * Recursively search the resourceNode and children for ComponentResource's and add them
	 * to the 'componentList'.  However, make sure to ONLY include components which are in the application.
	 * @param componentList - This is part of the overall return data from this class.  This is the
	 * results.environments[n].components List.
	 * @param resourceNode The node to check.
	 */
	public void recursivelySearchForComponentResources( List componentList, ResourceNode resourceNode ) {
		if (resourceNode instanceof ComponentResourceNode) {
			// Found a Component resource Node!!
			ComponentResourceNode componentResource = resourceNode
			Component component = componentResource.getComponent()
			
			// only process this component if it is associated with the application
			if (applicationComponents.containsKey(component.id)) {
				// Update the 'componentList'
				Map matchingComponentListEntry = null
				componentList.each { Map componentListEntry ->
					if (componentListEntry.name == component.name){
						// found a match
						matchingComponentListEntry = componentListEntry
					} 
				}
				if (! matchingComponentListEntry) {
					matchingComponentListEntry = [ "name": component.name, "id": component.id, "resources": [] ]
					componentList << matchingComponentListEntry
				}
				matchingComponentListEntry.resources << [ "path": componentResource.getResourcePath(), "id": componentResource.getId() ]
			}
		}
		// Recurse
		resourceNode.getChildren().each { ResourceNode childResource ->
			recursivelySearchForComponentResources(componentList, childResource)
		}
	}
}
