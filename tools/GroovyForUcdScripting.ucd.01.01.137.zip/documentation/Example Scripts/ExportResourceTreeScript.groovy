

import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.css.ucd.resource.ResourceTree
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook

/**
 * This script exports the entire resource tree .
 * @author LeonClark
 *
 */
class ExportResourceTreeScript extends ScriptWithUcdServicesHook {
	ResourceTree resourceTree
	
	/**
	 * This is the script function that is executed.
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
		resourceTree = ucdConnectionServices.getResourceServices().getResourceTree()
		
		def resourceTreeData = describeNodeAndChildren( resourceTree )
		String exportedTree = groovy.json.JsonOutput.toJson( resourceTreeData ) 
		println exportedTree
		outProps.put( 'exportedTree', exportedTree )
	}
	
	/**
	 * Captures the description of this node and its children to a data structure.
	 * @param node The node
	 * @return Returns a Map describing the node and its children.
	 */
	public Map describeNodeAndChildren( ResourceNode node ) {
		Map data = [:]
		data.nodeType = node.getNodeType()
		data.resourcePath = node.getResourcePath()
		data.name = node.getName()
		if (! data.name) {
			data.name = ''
		}
		if (! node.isRootNode()) {
			String resourceRole = node.getResourceRole()
			if (resourceRole) {
				data.resourceRole = resourceRole
			}
			def tags = node.getTags()
			if (tags) {
				data.tags = tags
			}
		}
		
		List children = node.getChildren()
		List childrenData = []
		if (children.size() > 0) {
			data.children = []
			children.each { ResourceNode child ->
				data.children << describeNodeAndChildren(child)
			}
		} else {
			// This is a leaf, get it again (cached or not)
		}
		
		return data
	}
}
