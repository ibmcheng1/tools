import groovy.io.FileType

import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook

/**
 * Groovy script class which has access to UCD API Services.
 */
class TranslateToTargetComponents extends ScriptWithUcdServicesHook {
	def earMap = [
		[prefix:'ccm-ear', extension:'ear', component:'stub ccm ear', filename:'ccm.ear'],
		[prefix:'cdrs-ear', extension:'ear', component:'stub cdrs ear', filename:'cdrs.ear'],
		[prefix:'closeout-ear', extension:'ear', component:'stub closeout ear', filename:'closeout.ear'],
		[prefix:'cort-ear', extension:'ear', component:'stub cort ear', filename:'cort.ear']
	]

	UcdConnectionServices ucdConnectionServices
	

	/**
	 * This is the script function that is executed.
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
		this.ucdConnectionServices = ucdConnectionServices

		earMap.each { Map mapEntry -> println "prefix='${mapEntry.prefix}', extension='${mapEntry.extension}', component='${mapEntry.component}', filename='${mapEntry.filename}'" }
		
		// Iterate the files in the working directory
		def workingDir = new File('.')
		workingDir.eachFile(FileType.FILES) { File memberFile ->
			String filename = memberFile.name.toLowerCase()
			println "Checking file ${filename}"
			earMap.each { mapEntry ->
				if (filename.startsWith(mapEntry.prefix) && filename.endsWith(".${mapEntry.extension}")) {
					String version = filename.substring( mapEntry.prefix.length() + 1, filename.length() - (mapEntry.prefix.length() + 1) - (mapEntry.extension.length() + 1) )
					println "Found a match: file = ${memberFile.name}, component=${mapEntry.component}, version=${version}"
				}
			}
		}
	}
}
