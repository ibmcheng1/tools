import com.ibm.css.ucd.processrequest.ProcessRequest
import com.ibm.css.ucd.resource.ResourceTree
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger;
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook


class TransferPropertiesFromAppRequest2ComponentRequest extends ScriptWithUcdServicesHook {
	ResourceTree resourceTree
	
	String parentRequestId = "${p:parentRequest.id}"
	String requestId = "${p:request.id}"

	/**
	 * This is the script function that is executed.
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
		ProcessRequest applicationRequest = ucdConnectionServices.getProcessRequestServices().getProcessRequest(parentRequestId)
		//ProcessRequest componentRequest = ucdConnectionServices.getProcessRequestServices().getProcessRequest(requestId)
		
		Logger.info "Application Request Properties: ${groovy.json.JsonOutput.toJson( applicationRequest.getContextProperties() )}"
		
	}
}
