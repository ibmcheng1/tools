import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook
import com.ibm.issr.rest.RestPut

/**
 * Groovy script class which has access to UCD API Services.
 */
class CreateApplicationProcess extends ScriptWithUcdServicesHook {
	String componentRequestId = "${p:request.id}"
	String applicationRequestId = "${p:parentRequest.id}"
	
	UcdConnectionServices ucdConnectionServices
	Properties outProps

	/**
	 * Creates an application process in UCD from the JSON description in the file 'process.json'
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
		this.ucdConnectionServices = ucdConnectionServices
		this.outProps = outProps

		ucdConnectionServices.getUcdServer()
		
		def responseObject = (new RestPut( ucdConnectionServices.getUcdServer() )).setPath("/cli/applicationProcess/create")
			.setPayload(new File('process.json').text)
			.putWithNoReturnObject()
	}
}