import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.processrequest.ProcessRequest
import com.ibm.css.ucd.processrequest.ProcessRequestApproval
import com.ibm.css.ucd.processrequest.ProcessRequestApprovalDetail
import com.ibm.css.ucd.processrequest.filter.ProcessRequestApplicationFilter
import com.ibm.css.ucd.processrequest.filter.ProcessRequestApprovalUserFilter
import com.ibm.css.ucd.processrequest.filter.ProcessRequestComponentFilter
import com.ibm.css.ucd.processrequest.filter.ProcessRequestComponentVersionFilter
import com.ibm.css.ucd.processrequest.filter.ProcessRequestDateRangeFilter
import com.ibm.css.ucd.processrequest.filter.ProcessRequestEnvironmentNameFilter
import com.ibm.css.ucd.processrequest.filter.ProcessRequestSetOfFilters
import com.ibm.css.ucd.processrequest.filter.ProcessRequestSnapshotFilter
import com.ibm.css.ucd.processrequest.filter.ProcessRequestUserFilter
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.css.ucd.snapshot.Snapshot
import com.ibm.issr.core.json.builder.JsonListBuilder
import com.ibm.issr.core.json.builder.JsonMapBuilder
import com.ibm.issr.core.log.Logger
import com.ibm.issr.date.DateHelper
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook

/**
 * Groovy script class which has access to UCD API Services.
 */
class GenerateDeploymentHistory extends ScriptWithUcdServicesHook {

	String jsonDataFilename = '${p:config.JsonDataFilename}'

	/**
	 * This is the script function that is executed.
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
		// UCD Parameters
		String userName = "${p?:filter.userName}"
		String applicationName = "${p?:filter.applicationName}"
		String startDateTime = '${p?:filter.startDateTime}'
		String endDateTime = '${p?:filter.endDateTime}'
		String environmentName = "${p?:filter.environmentName}"
		boolean environmentNameCaseSensitive = ${p:filter.environmentNameCaseSensitive}
		String approvalUser = "${p?:filter.approvalUser}"
		String componentName = '${p?:filter.componentName}'
		String componentVersionName = '${p?:filter.componentVersionName}'
		String snapshotName = '${p?:filter.snapshotName}'
		
		if (ucdConnectionServices.ucdServer.isServerVersionAtLeast6_2_7()) {
			Logger.info "UCD Server is version 6.2.7 (or above)"
		} else {
			Logger.info "UCD Server is older than 6.2.7"
		}

		Application application
		
		ProcessRequestSetOfFilters setOfFilters = new ProcessRequestSetOfFilters()
		if (userName) {
			setOfFilters.addFilter(new ProcessRequestUserFilter(userName))
		}
		if (applicationName) {
			application = ucdConnectionServices.getApplicationServices().getApplication(applicationName)
			setOfFilters.addFilter(new ProcessRequestApplicationFilter(application))
		}
		if (environmentName) {
			setOfFilters.addFilter(new ProcessRequestEnvironmentNameFilter(environmentName,environmentNameCaseSensitive))
		}
		if (approvalUser) {
			setOfFilters.addFilter(new ProcessRequestApprovalUserFilter(approvalUser))
		}
		if (startDateTime || endDateTime) {
			Date startDate = null
			Date endDate = null
			if (startDateTime) {
				try {
					startDate = DateHelper.parseDateTime(startDateTime)
				} catch (Exception e) {
					throw new Exception("Start date of '" + startDateTime + "' is an invalid date/time", e)
				}
			}
			if (endDateTime) {
				try {
					endDate = DateHelper.parseDateTime(endDateTime)
				} catch (Exception e) {
					throw new Exception("End date of '" + endDateTime + "' is an invalid date/time", e)
				}
			}
			setOfFilters.addFilter(new ProcessRequestDateRangeFilter(startDate, endDate))
		}
		// NOte that it filters on ComponentVersion OR Component
		if (componentVersionName) {
			if (! componentName) {
				throw new Exception( 'You must provide a componentName if you give a componentVersionName')
			} else {
				ComponentVersion componentVersion = ucdConnectionServices.getComponentServices().getComponent(componentName).getComponentVersion(componentVersionName)
				setOfFilters.addFilter(new ProcessRequestComponentVersionFilter(componentVersion))
			}
		} else if (componentName) {
			Component component = ucdConnectionServices.getComponentServices().getComponent(componentName)
			setOfFilters.addFilter(new ProcessRequestComponentFilter(component))
		}
		if (snapshotName) {
			if (applicationName && application) {
				Snapshot snapshot = application.getSnapshot(snapshotName)
				setOfFilters.addFilter(new ProcessRequestSnapshotFilter(snapshot))
			} else {
				throw new Exception( 'You must provide an application name when you give a snapshot name' )
			}
		}

		Logger.info "Filtering on ... ${setOfFilters.getDescription()}"


		// Write JSON output
		String delim = ''		// no comma for first entry
		File out = new File(jsonDataFilename)
		// initialize to opening '[' in json
		out.text = '{"filterCriteria":' + groovy.json.JsonOutput.toJson( setOfFilters.getDescription() ) + ',\n"requests":[\n'

		ucdConnectionServices.getProcessRequestServices().iterateProcessRequestHistory( setOfFilters ) { ProcessRequest processRequest ->
			String json = convertProcessRequestToJson(processRequest,true,true)
			Logger.info json
			out.append delim + json + '\n'
			delim = ','
		}

		out.append ']}'
	}


	/**
	 * This converts a ProcessRequest into a json string.  It only does the fields that are needed and
	 * does some additional composite fields.
	 * @param processRequest The process request
	 * @param includeVersions Should version information be included??  Warning, including this information
	 * generally results in additional REST calls.
	 * @return A Json string for output.
	 */
	private String convertProcessRequestToJson( ProcessRequest processRequest, boolean includeVersions=false, boolean includeApprovalData=false ) {
		JsonMapBuilder jsonMapBuilder = (new JsonMapBuilder())
				.addEntry( 'id', processRequest.id )
				.addEntry( 'description', processRequest.description )
				.addEntry( 'duration', processRequest.duration )
				.addEntry( 'endTime', processRequest.getDisplayableEndTime() )
				.addEntry( 'onlyChanged', processRequest.onlyChanged )
				.addEntry( 'paused', processRequest.paused )
				.addEntry( 'result', processRequest.result )
				.addEntry( 'startTime', processRequest.getDisplayableStartTime() )
				.addEntry( 'startTime', "submitted: ${processRequest.submittedTime}<br/>\nstart: ${processRequest.startTime}<br/>\nscheduled: ${processRequest.scheduledTime}<br/>\n" )
				.addEntry( 'state', processRequest.state )
				.addEntry( 'status', processRequest.status )
				.addEntry( 'submittedTime', processRequest.getDisplayableSubmittedTime() )
				.addEntry( 'traceId', processRequest.traceId )
				.addEntry( 'url', processRequest.url )
				.addEntry( 'userName', processRequest.userName )
				.addEntry( 'scheduledTime', processRequest.getDisplayableScheduledTime() )
				.addEntry( 'statusOverview', processRequest.getStatusOverview() )
				.addEntry( 'displayableDuration', processRequest.getDisplayableDuration() )
				.addEntry( 'snapshotName', processRequest.getSnapshotName() )
				.addEntry( 'application',
				(new JsonMapBuilder())
				.addEntry("id", processRequest.application.id)
				.addEntry("name", processRequest.application.name)
				)
				.addEntry( 'applicationProcess',
				(new JsonMapBuilder())
				.addEntry("id", processRequest.applicationProcess.id)
				.addEntry("name", processRequest.applicationProcess.name)
				)
				.addEntry( 'environment',
				(new JsonMapBuilder())
				.addEntry("id", processRequest.environment.id)
				.addEntry("name", processRequest.environment.name)
				)

		if (processRequest.snapshot){
			jsonMapBuilder.addEntry( 'snapshot',
					(new JsonMapBuilder())
					.addEntry("id", processRequest.snapshot.id)
					.addEntry("name", processRequest.snapshot.name)
					)
		}

		if (includeVersions) {
			// includes the versions in a nested 'versions' list
			// As a convenience, this also adds a field name 'versionSummary' which
			//   is a multiline field.  Each version is on a line with the
			//   format '[componentName]: [versionNumber]'
			String versionSummary = ''
			String versionSummaryDelim = ''
			String versionSummaryHtml = ''
			String versionSummaryHtmlDelim = ''
			JsonListBuilder jsonListBuilder = new JsonListBuilder()
			processRequest.componentVersions.each { ComponentVersion versionEntry ->
				// Add to versionSummary
				versionSummary = versionSummary + "${versionSummaryDelim}${versionEntry.component.name}: ${versionEntry.name}"
				versionSummaryDelim = '\n'
				versionSummaryHtml = versionSummaryHtml + "${versionSummaryHtmlDelim}${versionEntry.component.name}: ${versionEntry.name}"
				versionSummaryHtmlDelim = '<br/>\n'
				// Add to the json list
				jsonListBuilder.addEntry(
					(new JsonMapBuilder())
					.addEntry('name', versionEntry.name)
					.addEntry('id', versionEntry.id)
					.addEntry('component',
						(new JsonMapBuilder())
						.addEntry('name', versionEntry.component.name)
						.addEntry('id', versionEntry.component.id)
						)
					)
			}
			jsonMapBuilder.addEntry("versions", jsonListBuilder)
			jsonMapBuilder.addEntry("versionSummary",versionSummary)
			jsonMapBuilder.addEntry("versionSummaryHtml",versionSummaryHtml)
		}
		
		if (includeApprovalData) {
			ProcessRequestApproval approval = processRequest.getApproval()
			if (approval) {
				jsonMapBuilder.addEntry( 'approvalStatus', approval.status )
				// Build a text field with a summary of the approvals
				String approvalSummary = ''
				String approvalSummaryDelim = ''
				String approvalSummaryHtml = ''
				String approvalSummaryHtmlDelim = ''
				// Add child list of detailed approvals
				JsonListBuilder detailedApprovalsListBuilder = new JsonListBuilder()
				jsonMapBuilder.addEntry( 'detailedApprovals', detailedApprovalsListBuilder )
				approval.detailedEntries.each { ProcessRequestApprovalDetail detailedEntry ->
					// Only include records in the approval summary that have a person (aka 'completedBy' is defined)
					if (detailedEntry.completedBy) {
						approvalSummary = approvalSummary + approvalSummaryDelim + detailedEntry.status
						approvalSummaryHtml = approvalSummaryHtml + approvalSummaryHtmlDelim + detailedEntry.status
						approvalSummary = approvalSummary + ' by ' + detailedEntry.completedBy
						approvalSummaryHtml = approvalSummaryHtml + ' by ' + detailedEntry.completedBy
						approvalSummaryDelim = '\n'
						approvalSummaryHtmlDelim = '<br/>\n'
					}
					// Add a child node in the json output for the detailed approval information
					JsonMapBuilder detailedApprovalNode = new JsonMapBuilder()
					detailedApprovalNode.addEntry('status', detailedEntry.status)
					if (detailedEntry.completedBy) {
						detailedApprovalNode.addEntry('completedBy', detailedEntry.completedBy)
					}
					detailedApprovalsListBuilder.addEntry(detailedApprovalNode)
				}
				jsonMapBuilder.addEntry( 'approvalList', approvalSummary )
				jsonMapBuilder.addEntry( 'approvalListHtml', approvalSummaryHtml )
			} else {
				// There is no approval information
				// set status to empty string
				jsonMapBuilder.addEntry( 'approvalStatus', '' )
				jsonMapBuilder.addEntry( 'approvalList', '' )
				jsonMapBuilder.addEntry( 'approvalListHtml', '' )
			}
		}

		return jsonMapBuilder.toJsonString()

	}
}
