
import java.util.List;
import java.util.Properties;

import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger;
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook

/**
 * Groovy script class which has access to UCD API Services.
 *
 */
class RunAppProcessForLatestApplicationComponents extends ScriptWithUcdServicesHook {
	//***************************
	//  UCD PARAMETERS
	//***************************
	String applicationName = "Sample App"
	String environmentName = "DEV"
	String processName = "Deploy"
	String processRequestId = "${p:parentRequest.id}"
	String versionFilter = '*'
	boolean onlyChanged = true
	boolean waitForProcess = true
	
	
	/**
	 * This is the script function that is executed.
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {

		// Get the application
		Application application = ucdConnectionServices.getApplicationServices().getApplication(applicationName)
		
		// Get the environment
		Environment environment = application.getEnvironment(environmentName)

		
		// Build a List of the latest component versions in the applications.  Each List entry is
		// a Map with two entries - 'version' is the Version ID and 'component' is the Component ID.
		// If a component has no newest version, it's not included in the list
		List applicationComponents = application.getComponents()
		List componentVersionList = []
		applicationComponents.each { Component component ->
			List versions = component.getComponentVersionsMatchingWildcard(versionFilter)
			// Find the newest (most recently created) version
			ComponentVersion newestVersion = null
			versions.each { ComponentVersion version ->
				if (newestVersion==null || newestVersion.created<version.created) {
					newestVersion = version
				} 
			}
			if (newestVersion) {
				componentVersionList << [component: component.id, version: newestVersion.id]
			}
		}
		Logger.info "Running for component versions: " +  groovy.json.JsonOutput.toJson( componentVersionList )
		
		
		List results = ucdConnectionServices.getProcessRequestServices().callApplicationProcess( application, environment, 
			processName, onlyChanged, '', componentVersionList, null, null, waitForProcess )
		
		Logger.info "Results from calling application process: " + groovy.json.JsonOutput.toJson( results )

		// Set the output property 'detailsLink' which causes UCD to put in a hyperlink to the child app process
		outProps.put( 'detailsLink', "#applicationProcessRequest/"+results[0])
	}
}