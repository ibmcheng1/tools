import com.ibm.css.ucd.agent.Agent
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.common.EntityWithNameIdAndTeams
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.css.ucd.resource.ResourceTree
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.css.ucd.team.Team
import com.ibm.issr.core.log.Logger
import com.ibm.issr.core.plugin.PluginHelper
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook


/**
 * Groovy script class which has access to UCD API Services.
 */
class CreateEnvironmentScript extends WizardFramework {
	UcdConnectionServices ucdConnectionServices

	/**
	 * This is the script function that is executed.
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
		this.ucdConnectionServices = ucdConnectionServices
		
		
		//**************************************************************
		// LOAD Configuration File, including processing tokens and token lists
		//**************************************************************

		loadAndPreprocessConfigurationFile( 'config.json' )	
		
		Logger.info "Creating new environment named '${config.environmentName}' for application '${config.applicationName}'"

				
		//**************************************************************
		// GET COMMON INFORMATION (app, etc)
		//**************************************************************

		
		// Get the application
		Application application = ucdConnectionServices.getApplicationServices().getApplication(config.applicationName)
		
		ResourceTree resourceTree = ucdConnectionServices.getResourceServices().getResourceTree()

		// Security team
		Team team = ucdConnectionServices.getTeamServices().getTeam(config.teamName)
		
		// Get handles to all of the Utility Components one time
		Component apacheUtilityComponent = getComponent('Apache Utility')
		Component targetHostUtilityComponent = getComponent('WebSphere Target Host Utility')
		Component targetHostNodeUtilityComponent = getComponent('WebSphere Target Host Node Utility')
		Component webSphereCellUtilityComponent = getComponent('WebSphere Cell Utility')
		
		
		//**************************************************************
		// GET / CREATE APPLICATION ENVIRONMENT
		//**************************************************************

		
		// Find or create Application Environment
		Environment environment = application.getOrCreateEnvironment( config.environmentName )
		setTeamSecurity( environment, "Environment named ${environment.getName()}", team, config.environmentType)
		
		setAdHocEnvironmentProperty( environment, 'wsadmin.throttle', "2", false)
		
		
		//**************************************************************
		// SETUP APPLICATION RESOURCE TREE BRANCH (/app/environment/...)
		//**************************************************************


		ResourceNode appResourceNode = getChildNode( resourceTree, config.applicationName )
		
		// Find or create child of Application Resource Node - which is for the specific environment
		ResourceNode envResourceNode = getOrCreateChildGroupNode(appResourceNode, config.environmentName)
		setTeamSecurity( envResourceNode, "Resource Tree Node ${envResourceNode.getResourcePath()}", team, "" )
		
		linkEnvironmentToBaseResourceNode( environment, envResourceNode )
		
		// Get the target host relay agent, which is used to launch calls to the remote Target Hosts (thus the name launchPadAgent)
		// and add to the resource tree
		ResourceNode targetHostRelayAgent = getOrCreateChildAgentNode(envResourceNode, config.targetHostRelayAgent, getAgent(config.targetHostRelayAgent))
		addTag( targetHostRelayAgent, "Target Hosts" )
				
		// Add each Target Host to the launchPadAgent
		config.targetHosts.each { def targetHostConfig ->
			String hostName = targetHostConfig.name
			ResourceNode targetHostNode = getOrCreateChildGroupNode(targetHostRelayAgent, "TARGET HOST: ${hostName}", "TargetHost", 
				[
					'remote.serverName':hostName,
					'remote.userName': getOptionalMapValue( targetHostConfig, 'remote.userName', 'wasadmin'),
					'remote.apacheBinPaths': getOptionalMapValue( targetHostConfig, 'remote.apacheBinPaths', 
'''/opt/WebSphere90/IBMIHS90/bin/
/opt/WebSphere90/IBMIHS90X/bin/'''),
					'remote.profileName': getOptionalMapValue( targetHostConfig, 'remote.profileName', 'Dmgr01'),
					'remote.ownership': getOptionalMapValue( targetHostConfig, 'remote.ownership', 'wasadmin:wasgroup'),
					'remote.installPath': getOptionalMapValue( targetHostConfig, 'remote.installPath', '/opt/wawf/app'),
					'remote.webSphereDirectory': getOptionalMapValue( targetHostConfig, 'remote.webSphereDirectory', 'WebSphere90')
				])
			
			// Add 'Apache Utility' component to the Remote Host
			ResourceNode apacheUtilityResourceNode = getOrCreateChildComponentNode(targetHostNode, apacheUtilityComponent.getName(), apacheUtilityComponent)
			
			// Add 'WebSphere Target Host Utility' component to the Remote Host
			ResourceNode targetHostUtilityResourceNode = getOrCreateChildComponentNode(targetHostNode, targetHostUtilityComponent.getName(), targetHostUtilityComponent)
			
			// Process 'includeComponents'
			includeComponents( targetHostConfig, targetHostNode )

			// Add the child WAS Nodes
			if (targetHostConfig.containsKey('nodes')) {
				targetHostConfig.nodes.each { def targetHostNodeConfig ->

					String wasTargetHostNodeName = targetHostNodeConfig.name
					ResourceNode wasTargetHostNodeResourceNode = getOrCreateChildGroupNode(targetHostNode, "NODE: ${wasTargetHostNodeName}", "TargetHostNode", ['node.name':wasTargetHostNodeName,'node.path':targetHostNodeConfig.path])
				
					// Add 'Target Host Node Utility' component to the Remote Host
					ResourceNode targetHostNodeUtilityResourceNode = getOrCreateChildComponentNode(wasTargetHostNodeResourceNode, targetHostNodeUtilityComponent.getName(), targetHostNodeUtilityComponent)
					
					// Process 'includeComponents'
					includeComponents( targetHostNodeConfig, wasTargetHostNodeResourceNode )
				}
			}
		}
		
		
		//**************************************************************
		// SETUP WAS CELL RESOURCE TREE BRANCH
		//**************************************************************

		
		// Get the WAS Cell to use
		ResourceNode wasCellResourceNode = getResourceNode( resourceTree, config.websphereCell )
		
		addTag( wasCellResourceNode.getParent(), "WebSphere Cell" )
		
		linkEnvironmentToBaseResourceNode(environment, wasCellResourceNode)
		
		ResourceNode webSphereCellUtilityResourceNode = getOrCreateChildComponentNode(wasCellResourceNode, webSphereCellUtilityComponent.getName(), webSphereCellUtilityComponent)

		// Process the clusters
		if (config.containsKey('websphereClusters')) {
			ResourceNode serverClustersResourceNode = getChildNode( wasCellResourceNode, 'ServerClusters' )
			addTag( serverClustersResourceNode, "WebSphere Clusters" )
			config.websphereClusters.each { Map websphereClusterConfig ->
				ResourceNode clusterResourceNode = getChildNode( serverClustersResourceNode, websphereClusterConfig.name )
				includeComponents(websphereClusterConfig, clusterResourceNode)
			}
		}
		
		// Process the nodes and servers
		ResourceNode wasNodesResourceNode = getChildNode( wasCellResourceNode, 'Nodes' )
		config.websphereNodes.each { websphereNodeConfig ->
			ResourceNode wasNodeResourceNode = getChildNode( wasNodesResourceNode, websphereNodeConfig.name ) 
			ResourceNode wasServersResourceNode = getChildNode( wasNodeResourceNode, 'Servers' )
			websphereNodeConfig.websphereServers.each { websphereServerConfig ->
				ResourceNode wasServerResourceNode = getChildNode( wasServersResourceNode, websphereServerConfig.name )
				includeComponents(websphereServerConfig, wasServerResourceNode)	
			}
		}
	}
}

/**
 * The WizardFramework is a re-usable base class for wizards.
 * It supports tokens and tokenLists.
 * Assumptions: The configuration file has a 'tokens' section which is 
 * list of token substitutions.
 * The config file has a 'components' section with a list of
 * components.  At a minimum each 'components' entry has a 'name' and
 * an optional 'includeInGroupTokens' attribute.
 * @author LeonClark
 *
 */
abstract class WizardFramework extends ScriptWithUcdServicesHook {
	/**
	 * config is the loaded and processed configuration file.
	 */
	public def config
	
	/**
	 * For a Mapped data object (where the field values are Mapped to the
	 * field names), look for an optional mapped 'fieldName'.  If the
	 * field is found, return its value, otherwise return the 'defaultValue'.
	 */
	def getOptionalMapValue( Map mappedData, String fieldName, def defaultValue ) {
		if (mappedData.containsKey(fieldName)) {
			return mappedData[fieldName]
		} else {
			return defaultValue
		}
	}
	
	/**
	 * Loads the named configuration file to the 'config' class property.
	 * This processes Tokens and Component List Tokens.
	 * @param configFileName The name of the json configuration file.
	 */
	void loadAndPreprocessConfigurationFile( String configFileName ) {
		// Load configuration
		try {
			// Remove comments
			String configBody = removeCommentLines(new File(configFileName).text)
			
			// Parse the file's text with embedded tokens and listTokens
			config = new groovy.json.JsonSlurper().parseText(configBody)

			// listTokensMap is used to build the listTokens.  It is a Map.  The
			// KEY is a listToken name.  The VALUE is a LIST of member (component) names
			def listTokensMap = [:]
			
			// define the 'listTokensMap' based on the 'groupTokens' field
			config.groupTokens.tokenize(',').each { String listTokenName ->
				listTokenName = listTokenName.trim()
				if (listTokenName) {
					if (! listTokensMap.containsKey(listTokenName)) {
						listTokensMap[listTokenName] = []
					}
				}
			}
			
			// Iterate the components in order to calculate the 'listTokens'
			Map missingGroups = [:]
			config.components.each { Map component ->
				if (component.containsKey('includeInGroupTokens')) {
					String includeInGroupTokens = component.includeInGroupTokens
					includeInGroupTokens.tokenize(',').each { String listTokenName -> 
						listTokenName = listTokenName.trim()
						if (listTokenName) {
							if (! listTokensMap.containsKey(listTokenName)) {
								missingGroups[listTokenName] = ''
							} else {
								listTokensMap[listTokenName] << component.name
							}
						}
					}
				}
			}
			if (missingGroups) {
				String delim = ''
				String groupList = ''
				missingGroups.each { String groupName, value ->
					groupList = groupList + delim + groupName
					delim = ','
				}
				Logger.error "The Group Token(s) named '" + groupList + "' is referenced but not declared in the 'groupTokens' field."
				System.exit(1)
			}
			
			// Add the listTokens to 'config.tokens'
			listTokensMap.each { String listTokenName, List members ->
				// build comma separated list of the members
				String delim = ''
				String memberList = ''
				members.each { String member ->
					memberList = memberList + delim + member
					delim = ','
				}
				config.tokens[listTokenName] = memberList
			}
			
			// Iterate and replace tokens
			// In order to handle token references to tokens, this tries up to 'maxTries' time or until a cycle
			// doesn't find any tokens.
			boolean anotherCycleNeeded = true
			int maxTries = 5
			int currentTry = 0
			while ((currentTry<maxTries) && anotherCycleNeeded) {
				++currentTry
				anotherCycleNeeded = false
				config.tokens.each { String tokenName, String tokenValue ->
					String tokenKey = '%' + tokenName + '%'
					if (configBody.contains(tokenKey)) {
						anotherCycleNeeded = true
						configBody = configBody.replaceAll( tokenKey, tokenValue)
					}
				}
			}
						
			// Reparse the file's text, but this time tokens are substituted
			config = new groovy.json.JsonSlurper().parseText(configBody)
			
			Logger.info "config file with comments removed and substituted tokens:\n${configBody}"
		}
		catch (Exception e) {
			throw new Exception( "Unable to read and parse '${configFileName}' configuration file - ${e.message}", e)
		}
	}
	
	/**
	 * Removes comments from the multiple line text string.  A comment is
	 * any line that starts with '//' or '#'.  This returns the stripped
	 * down version of the string.  Note that comment lines are replaced with
	 * empty lines so that line numbers are changed in the event of a parsing error.
	 */
	String removeCommentLines( String multilineText ) {
		String bodyWithoutComments = ''
		
		multilineText.eachLine { line, count ->
			if (line.startsWith('//') || line.startsWith('#')) {
				// This is a comment line, replace with blank line
				bodyWithoutComments = bodyWithoutComments + "\n"
			} else {
				bodyWithoutComments = bodyWithoutComments + line + '\n'
			}
		}

		return bodyWithoutComments
	}
	
	
	/**
	 * If 'configNode' has a child property called 'includeComponents' (which is a list
	 * of child components to add), then add the listed child components to 'resourceNode'.
	 * Essentially, this processes 'includeComponents' entries in the configuration definition. 
	 * @param configNode This is a node in the configuration file tree.
	 * @param resourceNode This is a node in UCD's Resource Tree to which the included components
	 * are added.
	 */
	void includeComponents( def configNode, ResourceNode resourceNode ) {
		if (configNode.containsKey('includeComponents')) {
			configNode.includeComponents.tokenize(',').each { String componentName ->
				componentName = componentName.trim()
				if (componentName) {
					getOrCreateChildComponentNode(resourceNode, componentName, getComponent(componentName))
				}
			}
		}

	}
	
	
	//**********************************************************
	// HELPER FUNCTIONS to make the flow easier to read while (a) displaying status information and
	// (b) adding error handling
	
	/**
	 * Retrieves existing named child node.
	 * @param parentNode The parent node.
	 * @param childName The name of the child node.
	 */
	ResourceNode getChildNode( ResourceNode parentNode, String childName ) {
		String msg = "Find a child of Resource Tree node '${parentNode.getResourcePath()}' named '${childName}'"
		boolean success = false
		ResourceNode childNode = null
		try {
			childNode = parentNode.getChildNode(childName)
			if (childNode) {
				success = true
			} else {
				success = false
			}
		}
		catch (Exception e) {
			success = false
		}
		if (success) {
			Logger.info msg + " - success"
		} else {
			PluginHelper.abortPlugin( "FAILED to " + msg )
		}
		return childNode
	}
	
	/**
	 * Return the resource node for the given resource path.
	 * @param resourcePath The path, such as '/root/env/sampleAgent/sampleComponent'
	 */
	ResourceNode getResourceNode( ResourceTree resourceTree, String resourcePath ) {
		String msg = "Find the Resource Tree node for '${resourcePath}'"
		ResourceNode resourceNode
		boolean success = true
		try {
			resourceNode = resourceTree.getResourceNode( resourcePath )
		}
		catch (Exception e) {
			success = false
		}
		if (success && resourceNode) {
			Logger.info msg + " - success"
		} else {
			PluginHelper.abortPlugin( "FAILED to " + msg )
		}
		return resourceNode
	}

	/**
	 * Attempts to find or create (if it doesn't exist) a named 'Group Node' child.  Note that
	 * an exception is thrown if there is already a child, but it is a different type.  Optionally, ResourceRole
	 * information can be provided (name and property list).  The ResourceRole information is ONLY used if the node
	 * is created.  If the node already exists, no attempt is made to change it.
	 * @param parentNode The handle to the parent node.
	 * @param nodeName The name of the new child Group Node
	 * @param resourceRoleName This is an optional name for a Resource Role to attach to the new Group node.
	 * @param resourceRoleProperties IF a resourceRoleName is provided, this is an optional list of the properties.
	 * This is a Map field.  Each entry is a propertyName=value pair where the map key is the property name and the
	 * map value is the property value.
	 */
	ResourceNode getOrCreateChildGroupNode( ResourceNode parentNode, String nodeName, String resourceRoleName=null, Map resourceRoleProperties=null ) {
		String msg = "Find or create Group child named '${nodeName}' to Resource Tree node '${parentNode.getResourcePath()}'"
		boolean success = false
		boolean alreadyExisted = false
		ResourceNode childNode = null
		try {
			if (parentNode.doesChildNodeExist(nodeName)) {
				alreadyExisted = true
			}
			childNode = parentNode.getOrCreateChildGroupNode( nodeName, resourceRoleName, resourceRoleProperties )
			if (childNode) {
				success = true
			} else {
				success = false
			}
		}
		catch (Exception e) {
			success = false
		}
		if (success) {
			if (alreadyExisted) {
				Logger.info msg + " - child already exists"
			} else {
				Logger.info msg + " - successfully added"
			}
		} else {
			PluginHelper.abortPlugin( "FAILED to " + msg )
		}
		return childNode
	}
	
	/**
	 * Attempts to find or create (if it doesn't exist) a named 'Agent Node' child.  Note that
	 * an exception is thrown if there is already a child, but it is a different type.  Optionally, ResourceRole
	 * information can be provided (name and property list).  The ResourceRole information is ONLY used if the node
	 * is created.  If the node already exists, no attempt is made to change it.
	 * @param parentNode The handle to the parent node.
	 * @param nodeName The name of the new child Agent Node
	 */
	ResourceNode getOrCreateChildAgentNode( ResourceNode parentNode, String nodeName, Agent agent ) {
		String msg = "Find or create Agent child named '${nodeName}' to Resource Tree node '${parentNode.getResourcePath()}'"
		boolean success = false
		boolean alreadyExisted = false
		ResourceNode childNode = null
		try {
			if (parentNode.doesChildNodeExist(nodeName)) {
				alreadyExisted = true
			}
			childNode = parentNode.getOrCreateChildAgentNode( nodeName, agent )
			if (childNode) {
				success = true
			} else {
				success = false
			}
		}
		catch (Exception e) {
			success = false
		}
		if (success) {
			if (alreadyExisted) {
				Logger.info msg + " - child already exists"
			} else {
				Logger.info msg + " - successfully added"
			}
		} else {
			PluginHelper.abortPlugin( "FAILED to " + msg )
		}
		return childNode
	}
	
	/**
	 * Attempts to find or create (if it doesn't exist) a named 'Component Node' child.  Note that
	 * an exception is thrown if there is already a child, but it is a different type.  Optionally, ResourceRole
	 * information can be provided (name and property list).  The ResourceRole information is ONLY used if the node
	 * is created.  If the node already exists, no attempt is made to change it.
	 * @param parentNode The handle to the parent node.
	 * @param nodeName The name of the new child Component Node
	 */
	ResourceNode getOrCreateChildComponentNode( ResourceNode parentNode, String nodeName, Component component ) {
		String msg = "Find or create Component child named '${nodeName}' to Resource Tree node '${parentNode.getResourcePath()}'"
		boolean success = false
		boolean alreadyExisted = false
		ResourceNode childNode = null
		try {
			if (parentNode.doesChildNodeExist(nodeName)) {
				alreadyExisted = true
			}
			childNode = parentNode.getOrCreateChildComponentNode( nodeName, component )
			if (childNode) {
				success = true
			} else {
				success = false
			}
		}
		catch (Exception e) {
			success = false
		}
		if (success) {
			if (alreadyExisted) {
				Logger.info msg + " - child already exists"
			} else {
				Logger.info msg + " - successfully added"
			}
		} else {
			PluginHelper.abortPlugin( "FAILED to " + msg )
		}
		return childNode
	}

	/**
	 * Sets team security for the entity to the given 'team' and option 'resourceType'.
	 * Note that this code can't figure out what the entity is (environment, resource, etc, so
	 * 'entityDescription' should be a description, such as 'resource tree node named /a/b/c'.
	 */
	void setTeamSecurity( EntityWithNameIdAndTeams entity, String entityDescription, Team team, String resourceType="" ) {
		String msg = "Assigning team '${team.getName()}' to ${entityDescription}"
		if (resourceType) {
			msg = msg + " for resource type '${resourceType}'"
		}
		// Set team for Environment
		if (entity.isLinkedToTeam(team, resourceType )) {
			Logger.info msg + " - already defined"
		} else {
			try {
				entity.addLinkToTeam(team, resourceType )
			} catch (Exception e) {
				PluginHelper.abortPlugin( "FAILED to " + msg )
			}
			Logger.info msg + " - succcessfully added"
		}

	}
	
	/**
	 * Looks up and returns the named component.
	 * @param componentName
	 * @return The component object.
	 */
	Component getComponent( String componentName ) {
		String msg = "Find component named '${componentName}'"
		boolean success = true
		Component component
		try {
			component = ucdConnectionServices.getComponentServices().getComponent(componentName)
		}
		catch (Exception e) {
			success = false
		}
		if (success && component) {
			Logger.info msg + " - success"
		} else {
			PluginHelper.abortPlugin( "FAILED to " + msg + " - component not found" )
		}
		return component
	}

	/**
	 * Looks up and returns the named agent.
	 * @param agentName
	 */
	Agent getAgent( String agentName ) {
		String msg = "Find agent named '${agentName}'"
		boolean success = true
		Agent agent
		try {
			agent = ucdConnectionServices.getAgentServices().getAgent(agentName)
		}
		catch (Exception e) {
			success = false
		}
		if (success && agent) {
			Logger.info msg + " - success"
		} else {
			PluginHelper.abortPlugin( "FAILED to " + msg + " - agent not found" )
		}
		return agent
	}

	/**
	 * Links the 'resourceNode' as a Base Resource for the environment (if not already linked)
	 */
	void linkEnvironmentToBaseResourceNode( Environment environment, ResourceNode resourceNode ) {
		String msg = "Assigning Resource Tree node '${resourceNode.getResourcePath()}' as a base resource for the environment '${environment.getName()}'}'"
		// Link the Application Environment to the environment Resource Tree node
		boolean success = true
		boolean alreadyExists = false
		try {
			if (environment.hasBaseResource(resourceNode)) {
				alreadyExists = true
			} else {
				environment.addBaseResource(resourceNode)
			}
		}
		catch (Exception e) {
			success = false
		}
		if (success) {
			if (alreadyExists) {
				Logger.info msg + " - already mapped"
			} else {
				Logger.info msg + " - success"
			}
		} else {
			PluginHelper.abortPlugin( "FAILED to " + msg )
		}
	}
	
	/**
	 * Attempts to set an ad-hoc property, but only does so if it isn't already defined.
	 * @param environment The environment.
	 * @param name Name of the property.
	 * @param value Value to set (if not already set).
	 * @param isSecure Is it a secure property?
	 */
	void setAdHocEnvironmentProperty( Environment environment, String name, String value, boolean isSecure ) {
		String msg = "Setting environment property named '${name}' to '${value}'"
		if (environment.doesPropertyExist(name)) {
			msg = msg + " - already defined"
		} else {
			environment.setProperty(name, value, isSecure)
			msg = msg + " - success"
		}
		Logger.info msg
	}
	
	/**
	 * Attempts to add a tag label to a resource tree node.
	 * @param resourceNode The node.
	 * @param tagName The label.
	 */
	void addTag( ResourceNode resourceNode, String tagName ) {
		String msg = "Assign tag label '${tagName}' + to Resource Tree node '${resourceNode.getResourcePath()}'"
		try {
			resourceNode.addTag( tagName )
			Logger.info msg + " - success"
		}
		catch (Exception e) {
			PluginHelper.abortPlugin( "FAILED to " + msg )
		}
	}

}
