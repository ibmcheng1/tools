
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.environment.Environment
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook

/**
 * Groovy script class which has access to UCD API Services.
 *
 */
class AnalyzeApplication extends ScriptWithUcdServicesHook {
	//***************************
	//  UCD PARAMETERS
	//***************************

	String applicationName = "${p:appName}"
	String processRequestId = "${p:parentRequest.id}"
	String outputFileName = "ApplicationAnalysis.json"
	
	
	/**
	 * This is the script function that is executed.
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {

		// This is the data to export.  It is a property map.
		// The keys are:
		//	components
		//		- This is the list of components in the Application
		//	environments
		//		- This is a list of environments in the Application
		Map exportData = [components:[], environments:[]]
		
		// Get the application
		Application application = ucdConnectionServices.getApplicationServices().getApplication(applicationName)

		// Get the components.  Each member is a 'Component'
		List applicationComponents = application.getComponents()
		
		// Get the environments
		List applicationEnvironments = application.getEnvironments()
		
		// loop through and process each component
		applicationComponents.each { Component component ->
			Map componentExportData = [name:component.name, id:component.id]
			// TODO - Include associated Component/Component Template TAGS
			exportData.components << componentExportData
		}
		
		// loop through and process each environment
		applicationEnvironments.each { Environment environment ->
			Map environmentExportData = [name:environment.name, id:environment.id]
			exportData.environments << environmentExportData
		}

		// save the file
		String resultsJson = groovy.json.JsonOutput.toJson( exportData )
		File outputFile = new File( outputFileName )
		outputFile.text = resultsJson
		Logger.info "Generated JSON data written to '" + outputFileName + "'"
	}
}