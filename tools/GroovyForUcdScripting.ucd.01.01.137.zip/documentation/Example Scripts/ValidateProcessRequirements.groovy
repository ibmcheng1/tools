import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.json.JsonHelper
import com.ibm.issr.core.log.Logger
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook

/**
 * Groovy script class which has access to UCD API Services.
 */
class ValidateProcessRequirements extends ScriptWithUcdServicesHook {

	/**
	 * Validate any Requirements that this Report Process has.  For example, check
	 * for the existence of certain plugins, components, processes, etc.  This can
	 * also check the report's 'report.config' file for needed data.
	 * 
	 * If the validation fails, display an appropriate message and fail the step.
	 * 
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
		Logger.info "Validating Report Process Requirements..."
				
		// Make sure that the Application has Components called ... TODO
		// Read 'report.config'
	}
}