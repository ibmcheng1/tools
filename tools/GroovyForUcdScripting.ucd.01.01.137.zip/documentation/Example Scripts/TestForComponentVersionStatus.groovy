
import com.ibm.css.ucd.application.Application
import com.ibm.css.ucd.component.Component
import com.ibm.css.ucd.component.version.ComponentVersion
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.css.ucd.snapshot.Snapshot
import com.ibm.css.ucd.status.ComponentVersionStatus
import com.ibm.issr.core.log.Logger
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook

/**
 * Groovy script class which has access to UCD API Services.
 *
 */
class TestForComponentVersionStatus extends ScriptWithUcdServicesHook {
	//***************************
	//  UCD PARAMETERS
	//***************************

	String applicationId = "${p:applicationId}"
	String snapshotName = "${p:snapshotName}"
	String statusName = "${p:statusName}"


	/**
	 * This is the script function that is executed.
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
		Logger.info "Testing for component version status: " + statusName
		Logger.info "Application ID: " + applicationId
		Logger.info "Snapshot name: " + snapshotName

		// Get the application
		Application application = ucdConnectionServices.getApplicationServices().getApplicationById( applicationId )
		Logger.info "Found application id " + application.id

		// Get the snapshot
		Snapshot snapshot = application.getSnapshot(snapshotName)
		Logger.info "Found snapshot id " + snapshot.id

		// Get the list of Component Versions in the snapshot
		List componentVersions = snapshot.getComponentVersionObjects()

		boolean foundForAllComponentVersions = true

		componentVersions.each { ComponentVersion componentVersion ->
			Logger.info "Found component version name: " + componentVersion.name + ", id: " + componentVersion.id + ", from component named: " + componentVersion.component.name

			// Get the list of status flags
			List statusFlags = componentVersion.getComponentVersionStatuses()
			boolean found = false
			statusFlags.each { ComponentVersionStatus status ->
				if (status.name == statusName) {
					// FOUND
					found = true
				}
			}

			if (! found) {
				Logger.error "Status NOT found for component version name: " + componentVersion.name + ", from component named: " + componentVersion.component.name
				foundForAllComponentVersions = false
			}
		}

		Logger.info "foundForAllComponentVersions? " + foundForAllComponentVersions
		
		outProps.put( "foundForAllComponentVersions", foundForAllComponentVersions.toString() )

		if (! foundForAllComponentVersions) {
			// For now, throw exception if not found
			throw new Exception( "Unable to find the status '" + statusName + "' for all component versions in the snapshot.")
		}
	}
}