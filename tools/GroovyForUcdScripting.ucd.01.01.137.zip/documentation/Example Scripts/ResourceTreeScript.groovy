

import com.ibm.css.ucd.resource.ResourceNode
import com.ibm.css.ucd.resource.ResourceTree
import com.ibm.css.ucd.services.UcdConnectionServices
import com.ibm.issr.core.log.Logger
import com.ibm.issr.provision.hook.ScriptWithUcdServicesHook

/**
 * This script tests out resource tree code.
 * @author LeonClark
 *
 */
class ResourceTreeScript extends ScriptWithUcdServicesHook {
	ResourceTree resourceTree
	
	/**
	 * This is the script function that is executed.
	 * @param ucdConnectionServices UCD API Services
	 */
	public void runScript(UcdConnectionServices ucdConnectionServices, Properties outProps ) {
		resourceTree = ucdConnectionServices.getResourceServices().getResourceTree()

		ResourceNode resourceNode
		
		// Get or find a root level folder named 'Testing Resource Tree'
		resourceNode = resourceTree.getOrCreateChildGroupNode('Testing Resource Tree')
		displayNode( 'getOrCreate()', resourceNode )
		
		// Get or find a root level folder named 'Testing Resource Tree'
		resourceNode = resourceTree.getOrCreateChildGroupNode('Testing Resource Tree')
		displayNode( 'getOrCreate()', resourceNode )

		resourceNode = resourceTree.getChildNode('Testing Resource Tree')
		displayNode( 'get()', resourceNode )
		
		resourceTree.resetCachedChildren()
		resourceNode = resourceTree.getChildNode('Testing Resource Tree')
		displayNode( 'get() after reset cache', resourceNode )

		// Walk the tree
		Logger.info "Iterating resource tree..."
		iterateTree( resourceTree )
		
		// Walk the tree
		Logger.info "Iterating resource tree again..."
		iterateTree( resourceTree )
		
		// Walk the tree
		Logger.info "Iterating resource tree again after reseting cache..."
		resourceTree.resetCachedChildren()
		iterateTree( resourceTree )
	}
	
	public void iterateTree( ResourceNode node ) {
		displayNode( 'walking', node )
		List children = node.getChildren()
		if (children.size() > 0) {
			children.each { ResourceNode child ->
				iterateTree(child)
			}
		} else {
			// This is a leaf, get it again (cached or not)
			displayNode( 're-get leaf', resourceTree.getResourceNode(node.resourcePath) )
		}
	}
	
	public void displayNode( String label, ResourceNode node ) {
		Logger.info "${label} Resource Node: classId=${node} name=${node.name}, resourcePath=${node.resourcePath}"
	}
}
