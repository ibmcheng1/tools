import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.dtm.UCDDTMHelper
import com.urbancode.air.plugin.dtm.FailMode
import com.urbancode.air.plugin.dtm.TextUtil

import groovy.json.JsonBuilder
import groovy.json.JsonException
import groovy.json.JsonSlurper
import org.apache.http.impl.client.DefaultHttpClient

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def props = apTool.getStepProperties()

final def serverUrl        = props['serverUrl']
final def username         = props['username']
final def password         = props['passwordScript']?:props['password']
final def projectKey       = props['projectKey']
final def summary          = props['summary']
final def issueTypeName    = props['issueTypeName']
final def releaseDeploymentDate    = props['releaseDeploymentDate']
def proxyHost = props['proxyHost']?.trim()
def proxyPort = props['proxyPort']?.trim()
boolean allowInsecure = (props['allowInsecure']?:"false").toBoolean()
def customFields           = props['customFields']?.trim()
def otherAllowedFields = ["project" , "summary", "issuetype"]

UCDDTMHelper dtm = new UCDDTMHelper()

//------------------------------------------------------------------------------
// Script content
//------------------------------------------------------------------------------

println 'inFile:  ' + this.args[0]
println 'outFile: ' + this.args[1]
println "Server:\t$serverUrl"
println "token:\t$password"
println "projectKey:\t$projectKey"
println "issueTypeName:\t$issueTypeName"
println "summary:\t$summary"
println "releaseDeploymentDate:\t$releaseDeploymentDate"
println ""

// Parse custom fields
if (customFields) {
    try {
        customFields = new JsonSlurper().parseText(customFields)
        if (customFields instanceof List) {
            println "Expected Custom Fields to be a JSON object, but received a JSON array:"
            println()
            println new JsonBuilder(customFields)
            println()
            System.exit(1)
        }
    } catch (JsonException e) {
        println 'Failed to parse Custom Fields JSON:'
        println()
        println customFields
        println()
        System.exit(1)
    }
}

try {
	
	def isProjectKeyFromJson = false
	def isIssueTypeNameFromJson = false
	def isSummaryFromJson = false
	def isReleaseDeploymentDateFromJson = false
	println 'Original customFields = ' + customFields
	if (customFields != null) {
		if(customFields.fields != null) {
			customFields = customFields.fields
		}
		println 'transformed customFields = ' + customFields
		
		// user input example:
		//user input - projectKey: ENTDTMDEV
		//user input - issuetype:  Agile Release
		//user input - summary:    Creating issue summary ...
		//
		// json field example
		//customFields.project:   [key:ENTDTMDEV]
		//customFields.issuetype: [name:Agile Release]
		//customFields.summary:   Creating issue summary ...
		
		if(projectKey == null || projectKey == '') {
			println 'getting projectKey from json ...'
			//customFields.project:   [key:ENTDTMDEV]
			if(customFields.project != null) {
				projectKey = customFields.project.key
				isProjectKeyFromJson = true
			}				
			println 'projectKey from json:   ' + projectKey
		}
		
		if(issueTypeName == null || issueTypeName == '') {
			println 'getting issueTypeName from json ...'
			//customFields.issuetype: [name:Agile Release]
			if(customFields.issuetype != null) {
				issueTypeName = customFields.issuetype.name	
				isIssueTypeNameFromJson = true
			}			
			println 'issueTypeName from json: ' + issueTypeName
		}
		
		if(summary == null || summary == '') {
			println 'getting summary from json ...'
			//customFields.summary:   Creating issue summary ...
			summary = customFields.summary
			println 'summary from json:   ' + summary
			if(summary) isSummaryFromJson = true
		}
		
		if(releaseDeploymentDate == null || releaseDeploymentDate == '') {
			println 'getting releaseDeploymentDate from json ...'
			releaseDeploymentDate = customFields.customfield_10050
			println 'releaseDeploymentDate from json:   ' + releaseDeploymentDate
			if(releaseDeploymentDate) isReleaseDeploymentDateFromJson = true
		}
		
		if(customFields.customfield_10049 != null) {
			def changeTicket = customFields.customfield_10049
			println 'changeTicket from json:    ' + changeTicket
		}
	}
	println '---------------------------------'
	println 'projectKey:            ' + projectKey
	println 'issueTypeName:         ' + issueTypeName
	println 'summary:               ' + summary
	println 'releaseDeploymentDate: ' + releaseDeploymentDate
	println '---------------------------------'
	println 'isProjectKeyFromJson:            ' + isProjectKeyFromJson
	println 'isIssueTypeNameFromJson:         ' + isIssueTypeNameFromJson
	println 'isSummaryFromJson:               ' + isSummaryFromJson
	println 'isReleaseDeploymentDateFromJson: ' + isReleaseDeploymentDateFromJson
	println '---------------------------------'
	println 'customFields = ' + customFields
	println '---------------------------------'
	
	if(projectKey == null || projectKey == '') {
		println 'Error: The projectKey can not be null or empty.'
		System.exit(1)
	}
	
	if(issueTypeName == null || issueTypeName == '') {
		println 'Error: The issueTypeName can not be null or empty.'
		System.exit(1)
	}
	
	if(summary == null || summary == '') {
		println 'Error: The summary can not be null or empty.'
		System.exit(1)
	}
	
	if(releaseDeploymentDate == null) {
		println 'Error: The releaseDeploymentDate can not be null.'
		System.exit(1)
	} else if (releaseDeploymentDate == ''){
		println 'Error: The releaseDeploymentDate can not be empty.'
		System.exit(1)
	} else {
		def dateParser = new java.text.SimpleDateFormat("yyyy-MM-dd")
		Date parsedReleaseDeploymentDate = null
		try {
			parsedReleaseDeploymentDate = dateParser.parse(releaseDeploymentDate)
		} catch (Exception e) {
			println 'Error: The releaseDeploymentDate must be in the format of yyyy-MM-dd'
			throw e
		}
		println 'parsed releaseDeploymentDate = ' + parsedReleaseDeploymentDate
	}
	
    // Construct the HTTP client to allow user authentication
    DefaultHttpClient client
    client = dtm.createClient(username, password, proxyHost, proxyPort, allowInsecure)

    // Get the Create Issue metadata so we can determine what issue/field types are allowed
    def createIssueMeta = dtm.getCreateIssueMeta(client, serverUrl, projectKey)

    // Fail if the given project is not found
    if (!createIssueMeta.projects) {
        println String.format('No project found with key "%s".', projectKey)
        System.exit(1)
    }

    // Fail if the given issue type is not allowed in the given project
    def metaIssueType = createIssueMeta.projects[0].issuetypes.find{it.name == issueTypeName}
    if (!metaIssueType) {
        println String.format('"%s" is not an allowed issue type in the project "%s".', issueTypeName, projectKey)
        System.exit(1)
    }

    // Create a list of objects representing the allowed fields [{"id": String, "name": String, "required": boolean}...]
    def allowedFields = metaIssueType.fields.collect { fieldId, fieldDef ->
        [id: fieldId, name: fieldDef.name, required: fieldDef.required]
    }
	
    // Create Issue as a HashMap object
    def fieldMap = [:]

    // Add custom fields to JSON
    customFields.each { key, value ->
        def id = allowedFields.find{
			it.id == key && ( it.id.startsWith('customfield_') || otherAllowedFields.contains(it.id) )
        }?.id
		
        // Fail if the given custom field name is not in the list of allowed fields for this project and issue type
        if (!id) {
            println String.format('"%s" is not an allowed custom field for the given project and issue type.', key)
            System.exit(1)
        }

        fieldMap.put(id, value)
    }

    // Add standard fields to JSON if necessary
	fieldMap.put("project", ["key": projectKey])
	
	if(isIssueTypeNameFromJson == false) {
		fieldMap.put("issuetype", ["name": issueTypeName])
	}
	
	if(isSummaryFromJson == false) {
		fieldMap.put("summary", summary)
	}
	
	fieldMap.put("customfield_10050", releaseDeploymentDate)

    def issueMap = [:]
    issueMap.put("fields",fieldMap)

    // Change mapping to JSON and prepare it to be sent via REST call
    JsonBuilder issueJSON = new JsonBuilder(issueMap)
	
	//println '================================================='
	//println 'fieldMap: fieldMap.size() = ' + fieldMap.size()
	//println '================================================='
	//fieldMap.each{ println it }
	//println '===================='

	String DTMRecordNumber = 'false'
	//DTMRecordNumber = dtm.createIssue(client, serverUrl, issueJSON)
    if (DTMRecordNumber == 'false') {
        println "Create DTM record failed. Review error output for details."
        System.exit(1)
    }
	
	println 'DTMRecordNumber = ' + DTMRecordNumber
	
	// output if necessary
	apTool.setOutputProperty('projectKey', projectKey)
	apTool.setOutputProperty('issuetype', issueTypeName)
	apTool.setOutputProperty('summary', summary)
	apTool.setOutputProperty('releaseDeploymentDate', releaseDeploymentDate)
	apTool.setOutputProperty('token', password)
	apTool.setOutputProperty('DTMRecordNumber', DTMRecordNumber)
	apTool.setOutputProperties();


}
catch (Exception e) {
    e.printStackTrace()
    throw new IllegalStateException("Full execution of create issue failed.")
}
