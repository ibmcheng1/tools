import com.example.s3.*;

//------------------------------------------------------------------------------
// Script content
//------------------------------------------------------------------------------


try {
	println 'AWS Deploy Main Script +++'
	AwsS3BucketOps.main(args)
	println 'AWS Deploy Main Script ---'
	
}
catch (Exception e) {
    e.printStackTrace()
    throw new IllegalStateException("Full execution of create issue failed.")
}
