# What's new in Chart Version 2.0.7
* IBM certified container

## Breaking Changes

# Fixes

# Prerequisites
* See README for prerequisites

# Documentation
* See README for documentation

# Version History

| Chart | Date | Image(s) Supported | Breaking Changes | Details |
| ----- | ---- | ------------------ | ---------------- | ------- | 
| 2.0.7 | January 14th, 2020 | ucdr: 7.0.5.0.1041488 | None | Version 7.0.5.0  |
| 2.0.6 | December 4th, 2019| ucdr: 7.0.4.2.1038002 | None | Version 7.0.4.2  |
| 2.0.5 | November 5th, 2019| ucdr: 7.0.4.1.1036185 | None | Support for latest UCD Server Release |
| 2.0.0 | October 1st, 2019 | ucdr: 7.0.4.0.1034011 | None | Support for latest UCD Server Release |
| 1.0.8 | September 3rd, 2019 | ucdr: 7.0.3.3.1031820 | None | Support for latest UCD Server Release |
| 1.0.7 | August 6th, 2019 | ucdr: 7.0.3.2.1028848 | None | Support for latest UCD Server Release |
| 1.0.6 | July 2nd, 2019 | ucdr: 7.0.3.1.1026877 | None | Support for latest UCD Server Release |
| 1.0.5 | June 11th, 2019 | ucdr: 7.0.3.0.1025086 | None | Support for latest UCD Server Release |
| 1.0.4 | May 7th, 2019 | ucdr: 7.0.2.3.1021487 | None | Support for latest UCD Server Release |
| 1.0.3 | March 12th, 2019| ucdr: 7.0.2.2.1017795 | None | Initial Release  |
