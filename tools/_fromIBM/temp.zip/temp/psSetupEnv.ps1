$env:Path = "D:\knowledge_AWS\cli-tools;$env:Path"
echo $env:Path
