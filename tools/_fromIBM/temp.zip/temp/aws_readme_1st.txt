###########################
Personal AWS account
###########################
AWS (display name: ibmcheng1) cheng1@us.ibm.com / Newp@ssw0rd -> Taiwan_508heime
https://aws.amazon.com/console/
AWS Security Credentials:
--------------------------
Access keys (access key ID and secret access key)
    Access Key ID:
        AKIAJUNA4M6WYALBGMUQ
    Secret Access Key:
        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
-------------
aws sts get-caller-identity
------------        
PS C:\Users\JerryCheng> aws --version
aws-cli/2.0.5 Python/3.7.5 Windows/10 botocore/2.0.0dev9
PS C:\Users\JerryCheng> aws sts get-caller-identity
{
    "UserId": "478967510620",
    "Account": "478967510620",
    "Arn": "arn:aws:iam::478967510620:root"
}
        
###########################
AWS IBM sandbox
###########################
AWS Account: 518493176437
USSR:        cheng1 / Roxie_4me
===
Access Key ID:           AKIAXROE2AJ23ZI62W2I
Secret Access Key:       4xFOHg6y65m00D3HlvWIuS6HSY3OdQMeSOoAc6To
===
Note, Logout of nacacces account and logon with your personal account.  
      Specify account ID 518493176437 when logging in.
---
My EC2 instance: ec2-34-220-113-40.us-west-2.compute.amazonaws.com
 // PowerShell in Windows 10

########################################
EC2
########################################
cd D:\knowledge_AWS\IBM-AWS-sandbox
cd D:\knowledge_commands\OpenShift\ocp-deployment-ccocp401
ssh -i cheng1Key.pem ec2-user@ec2-34-220-113-40.us-west-2.compute.amazonaws.com
---

Note, C:\Users\JerryCheng\.aws\credentials is updated to inlcude AWS profile
####################################
C:\Users\JerryCheng\.aws\credentials
####################################
[default]
aws_access_key_id=AKIAIXS7LHRWSVBFXUXQ
aws_secret_access_key=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

[AWS]
aws_access_key_id=AKIAXROE2AJ23ZI62W2I
aws_secret_access_key=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
###########################

########################################
Windows: set environment variable PATH
########################################
// PowerShell
$env:Path = "D:\knowledge_AWS\cli-tools";     (replaces existing path) 
$env:Path += ";D:\knowledge_AWS\cli-tools"    (appends to existing path)

$env:Path = "D:\knowledge_AWS\cli-tools;$env:Path"

// CommandPrompt
set PATH=D:\knowledge_AWS\cli-tools;%PATH%

########################################
// CF - Stack - cceks01-stack - VPC
########################################
SecurityGroups	sg-0f63deb71780578a4	
SubnetIds	subnet-08c3dacd2e47c1b5b,
		subnet-01102b351fc7ee56d,
		subnet-048be1ef6659112d5,
		subnet-00acaec2a97313147	
VpcId		vpc-0ec066342f6f19703

----------------
Parameters:

  VpcBlock:
    Type: String
    Default: 192.168.0.0/16
    Description: The CIDR range for the VPC. This should be a valid private (RFC 1918) CIDR range.

  PublicSubnet01Block:
    Type: String
    Default: 192.168.0.0/18
    Description: CidrBlock for public subnet 01 within the VPC

  PublicSubnet02Block:
    Type: String
    Default: 192.168.64.0/18
    Description: CidrBlock for public subnet 02 within the VPC

  PrivateSubnet01Block:
    Type: String
    Default: 192.168.128.0/18
    Description: CidrBlock for private subnet 01 within the VPC

  PrivateSubnet02Block:
    Type: String
    Default: 192.168.192.0/18
    Description: CidrBlock for private subnet 02 within the VPC


########################################
Key pairs
########################################
https://us-west-2.console.aws.amazon.com/ec2/v2/home?region=us-west-2#KeyPairs:
// Important, the cheng1Key.pem file must be "chmod 400" in Unix, 
//            or follow the following Windows 10 procedure.
// Unix chmod 400 equivalent in Windows PowerShell:
// https://stackoverflow.com/questions/43312953/using-icacls-to-set-file-permission-to-read-only
//
------------------------
# 1.
$path = ".\cheng1Key.pem"
# 2. Reset to remove explict permissions
icacls.exe $path /reset
#3. Give current user explicit read-permission
icacls.exe $path /GRANT:R "$($env:USERNAME):(R)"
#4. Disable inheritance and remove inherited permissions
icacls.exe $path /inheritance:r


###############
EKS - cceks01
###############
aws eks --region us-east-2 update-kubeconfig --name cluster_name
aws eks --region us-east-2 update-kubeconfig --name cceks01 --profile AWS

PS D:\knowledge_AWS\IBM-AWS-sandbox> D:\knowledge_AWS\cli-tools\kubectl.exe get svc
NAME         TYPE        CLUSTER-IP   EXTERNAL-IP   PORT(S)   AGE
kubernetes   ClusterIP   10.100.0.1   <none>        443/TCP   65m
PS D:\knowledge_AWS\IBM-AWS-sandbox>
-------


############################################
Tutorial: Deploy the Kubernetes Web UI (Dashboard)
############################################
============================================
Step 1: Deploy the Kubernetes Metrics Server
============================================
// Navigate to the latest release page of the metrics-server project on GitHub 
//      (https://github.com/kubernetes-sigs/metrics-server/releases/latest), 
//      then choose a source code archive for the latest release to download it.

// Apply all of the YAML manifests in the metrics-server-0.3.6/deploy/1.8+ directory (substituting your release version).
kubectl apply -f metrics-server-0.3.6/deploy/1.8+/
kubectl apply -f D:\knowledge_AWS\IBM-AWS-sandbox\EKS-addons\metrics-server-0.3.6\deploy\1.8+\

//Verify that the metrics-server deployment is running the desired number of pods with the following command.
kubectl get deployment metrics-server -n kube-system
---
Output:
NAME             DESIRED   CURRENT   UP-TO-DATE   AVAILABLE   AGE
metrics-server   1         1         1            1           56m
---


============================================
Step 2: Deploy the Dashboard
============================================

//Use the following command to deploy the Kubernetes dashboard.
kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/v2.0.0-beta8/aio/deploy/recommended.yaml

//Output:
---
namespace/kubernetes-dashboard created
serviceaccount/kubernetes-dashboard created
service/kubernetes-dashboard created
secret/kubernetes-dashboard-certs created
secret/kubernetes-dashboard-csrf created
secret/kubernetes-dashboard-key-holder created
configmap/kubernetes-dashboard-settings created
role.rbac.authorization.k8s.io/kubernetes-dashboard created
clusterrole.rbac.authorization.k8s.io/kubernetes-dashboard created
rolebinding.rbac.authorization.k8s.io/kubernetes-dashboard created
clusterrolebinding.rbac.authorization.k8s.io/kubernetes-dashboard created
deployment.apps/kubernetes-dashboard created
service/dashboard-metrics-scraper created
deployment.apps/dashboard-metrics-scraper created
---

============================================
Step 3: Create an eks-admin Service Account and Cluster Role Binding
============================================
Create a file called eks-admin-service-account.yaml with the text below. 
This manifest defines a service account and cluster role binding called eks-admin.
---
D:\knowledge_AWS\IBM-AWS-sandbox>kubectl apply -f EKS-addons\eks-admin-service-account.yaml
serviceaccount/eks-admin created
clusterrolebinding.rbac.authorization.k8s.io/eks-admin created
---

============================================
Step 4: Connect to the Dashboard
============================================
1. Retrieve an authentication token for the eks-admin service account. 
   Copy the <authentication_token> value from the output. 
   You use this token to connect to the dashboard.
   
kubectl -n kube-system describe secret $(kubectl -n kube-system get secret | grep eks-admin | awk '{print $1}')

---
Name:         eks-admin-token-qnkdc
Namespace:    kube-system
Labels:       <none>
Annotations:  kubernetes.io/service-account.name: eks-admin
              kubernetes.io/service-account.uid: 109d5cca-710a-11ea-b575-06b79012c8f2

Type:  kubernetes.io/service-account-token

Data
====
ca.crt:     1025 bytes
namespace:  11 bytes
token:      eyJhbGciOiJSUzI1NiIsImtpZCI6IiJ9.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJrdWJlLXN5c3RlbSIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJla3MtYWRtaW4tdG9rZW4tcW5rZGMiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC5uYW1lIjoiZWtzLWFkbWluIiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQudWlkIjoiMTA5ZDVjY2EtNzEwYS0xMWVhLWI1NzUtMDZiNzkwMTJjOGYyIiwic3ViIjoic3lzdGVtOnNlcnZpY2VhY2NvdW50Omt1YmUtc3lzdGVtOmVrcy1hZG1pbiJ9.PgB-RImYgonHJfME2__tO2E0uJgngqLiJKtVnX7JCb0hCT3XbNkFEePpS1yiYABKF4Ffffx9TAlWpvI1u_YsI4YGoLcCcrg5JYabF9y1_0HzwfGOZbyfJl4Z-0dnqd0vyVCucw6dXdE24ACJj4GC8uDAiaDoKDWrk6QtZTAlCYjITZODYieGZO2W0BvN8mxloRLzyy3gVAYcbnkiIJMFAPWnGy5kYjjbHQG3KHRLwKjwCLJqWj7whj_Dbgl-HXZnakvBG5HdryWYWFMJymLfiVG7rBE3TpNpD_UBJOYqKyTyoIhq_iPCP7hzwCbcumUp45UX4Ty50a7oOhnuwckERg
---

// kubectl get secret eks-admin-token-qnkdc -n kube-system
// kubectl describe secret eks-admin-token-qnkdc -n kube-system

---
PS D:\knowledge_AWS\IBM-AWS-sandbox> kubectl get secret eks-admin-token-qnkdc -n kube-system
NAME                    TYPE                                  DATA   AGE
eks-admin-token-qnkdc   kubernetes.io/service-account-token   3      8m55s

---
PS D:\knowledge_AWS\IBM-AWS-sandbox> kubectl describe secret eks-admin-token-qnkdc -n kube-system
Name:         eks-admin-token-qnkdc
Namespace:    kube-system
Labels:       <none>
Annotations:  kubernetes.io/service-account.name: eks-admin
              kubernetes.io/service-account.uid: 109d5cca-710a-11ea-b575-06b79012c8f2

Type:  kubernetes.io/service-account-token

Data
====
ca.crt:     1025 bytes
namespace:  11 bytes
token:      eyJhbGciOiJSUzI1NiIsImtpZCI6IiJ9.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJrdWJlLXN5c3RlbSIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJla3MtYWRtaW4tdG9rZW4tcW5rZGMiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC5uYW1lIjoiZWtzLWFkbWluIiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQudWlkIjoiMTA5ZDVjY2EtNzEwYS0xMWVhLWI1NzUtMDZiNzkwMTJjOGYyIiwic3ViIjoic3lzdGVtOnNlcnZpY2VhY2NvdW50Omt1YmUtc3lzdGVtOmVrcy1hZG1pbiJ9.PgB-RImYgonHJfME2__tO2E0uJgngqLiJKtVnX7JCb0hCT3XbNkFEePpS1yiYABKF4Ffffx9TAlWpvI1u_YsI4YGoLcCcrg5JYabF9y1_0HzwfGOZbyfJl4Z-0dnqd0vyVCucw6dXdE24ACJj4GC8uDAiaDoKDWrk6QtZTAlCYjITZODYieGZO2W0BvN8mxloRLzyy3gVAYcbnkiIJMFAPWnGy5kYjjbHQG3KHRLwKjwCLJqWj7whj_Dbgl-HXZnakvBG5HdryWYWFMJymLfiVG7rBE3TpNpD_UBJOYqKyTyoIhq_iPCP7hzwCbcumUp45UX4Ty50a7oOhnuwckERg
---

2. Start the kubectl proxy.

kubectl proxy

---
D:\knowledge_AWS\IBM-AWS-sandbox>kubectl proxy
Starting to serve on 127.0.0.1:8001
---

3. To access the dashboard endpoint, open the following link with a web browser: 

   http://localhost:8001/api/v1/namespaces/kubernetes-dashboard/services/https:kubernetes-dashboard:/proxy/#!/login.
   http://localhost:8001/api/v1/namespaces/kubernetes-dashboard/services/https:kubernetes-dashboard:/proxy/#/login
   http://localhost:8001/api/v1/namespaces/kubernetes-dashboard/services/https:kubernetes-dashboard:/proxy/
   
4. Choose Token, paste the <authentication_token> output from the previous command into the Token field, and choose SIGN IN.

5. Step 5: Next Steps
After you have connected to your Kubernetes cluster dashboard, you can view and control your cluster using your eks-admin service account. 
For more information about using the dashboard, see the project documentation on GitHub.

        https://github.com/kubernetes/dashboard
        
####################################
Access EKS NodeGroups' EC2 instances
####################################
ec2-3-17-150-185.us-east-2.compute.amazonaws.com   / 3.17.150.185
ec2-18-191-186-160.us-east-2.compute.amazonaws.com / 18.191.186.160

ssh -i keyPairs_ohio\cheng1Key.pem ec2-user@ec2-3-17-150-185.us-east-2.compute.amazonaws.com
ssh -i keyPairs_ohio\cheng1Key.pem ec2-user@ec2-18-191-186-160.us-east-2.compute.amazonaws.com

// web server - utilities 
// (http://18.221.73.11/) http://ec2-18-221-73-11.us-east-2.compute.amazonaws.com
D:\knowledge_AWS\IBM-AWS-sandbox 
ssh -i keyPairs_ohio\cheng1Key.pem ec2-user@18.221.73.11

scp -i keyPairs_ohio\cheng1Key.pem D:\Linux_Shared\mysql_driver\mysql-connector-java-5.1.46.jar ec2-user@18.221.73.11:/var/www/html/jdbc/
 
http://18.221.73.11/jdbc/mysql-connector-java-5.1.46.jar
 


// Linux
ssh -i keyPairs_ohio/cheng1Key.pem ec2-user@ec2-3-17-150-185.us-east-2.compute.amazonaws.com
ssh -i keyPairs_ohio/cheng1Key.pem ec2-user@ec2-18-191-186-160.us-east-2.compute.amazonaws.com

####################################
IBM Cloud Pak PodSecurityPolicy (PSP)
####################################
https://github.com/IBM/cloud-pak/tree/master/spec/security/psp

=========================
Applying IBM Cloud Pak PodSecurityPolicy resources to your cluster
==========================
To apply the IBM Cloud Pak PodSecurityPolicy resources to your cluster:
    Clone the IBM Cloud Pak git repository: 
        git clone https://github.com/IBM/cloud-pak
    Apply the specification yaml files to your cluster:
        cd D:\knowledge_AWS\IBM-AWS-sandbox\git 
        kubectl apply -f cloud-pak/spec/security/psp
        
---
PS D:\knowledge_AWS\IBM-AWS-sandbox\git> git clone https://github.com/IBM/cloud-pak
Cloning into 'cloud-pak'...
remote: Enumerating objects: 228, done.
remote: Counting objects: 100% (228/228), done.
remote: Compressing objects: 100% (159/159), done.
remote: Total 3660 (delta 81), reused 183 (delta 59), pack-reused 3432
Receiving objects: 100% (3660/3660), 293.26 MiB | 1.04 MiB/s, done.
Resolving deltas: 100% (1266/1266), done.

PS D:\knowledge_AWS\IBM-AWS-sandbox\git> kubectl apply -f cloud-pak/spec/security/psp
clusterrole.rbac.authorization.k8s.io/ibm-anyuid-clusterrole created
clusterrole.rbac.authorization.k8s.io/ibm-anyuid-hostaccess-clusterrole created
podsecuritypolicy.policy/ibm-anyuid-hostaccess-psp created
clusterrole.rbac.authorization.k8s.io/ibm-anyuid-hostpath-clusterrole created
podsecuritypolicy.policy/ibm-anyuid-hostpath-psp created
podsecuritypolicy.policy/ibm-anyuid-psp created
clusterrole.rbac.authorization.k8s.io/ibm-privileged-clusterrole created
podsecuritypolicy.policy/ibm-privileged-psp created
clusterrole.rbac.authorization.k8s.io/ibm-restricted-clusterrole created
podsecuritypolicy.policy/ibm-restricted-psp created
PS D:\knowledge_AWS\IBM-AWS-sandbox\git>
---
        

===========================
Applying a PodSecurityPolicy to your namespace
===========================
// https://rancher.com/learning-paths/introduction-to-kubernetes-namespaces/

1. To bind all ServiceAccounts in a namespace to a PodSecurityPolicy:
Run the following command:
---
kubectl -n <namespace-name> create rolebinding <rolebinding-name> --clusterrole=<psp-clusterrole-name> --group=system:serviceaccounts:<namespace-name>
---

>>> namespace-name = The name of Kubernetes namespace to bind to the target PodSecurityPolicy. 
>>> rolebinding-name = The name of the RoleBinding resource to create in the namespace. 
>>> psp-clusterrole-name = The name of the ClusterRole associated with the target PodSecurityPolicy.

Example:
---
kubectl -n default create rolebinding ibm-anyuid-clusterrole-rolebinding --clusterrole=ibm-anyuid-clusterrole --group=system:serviceaccounts:default
---
PS D:\knowledge_AWS\IBM-AWS-sandbox\git> kubectl -n default create rolebinding ibm-anyuid-clusterrole-rolebinding --clusterrole=ibm-anyuid-clusterrole --group=system:serviceaccounts:default
rolebinding.rbac.authorization.k8s.io/ibm-anyuid-clusterrole-rolebinding created
---


===========================
Validating which PodSecurityPolicies are bound to a namespace
===========================

Use the kubectl auth can-i command to determine if a user or ServiceAccount has authority to use a PodSecurityPolicy.
See the utility script getPSP.sh for an example on how to see all PodSecurityPolicies that are bound to a namespace.
---
cd D:\knowledge_AWS\IBM-AWS-sandbox\git\cloud-pak\samples\utilities
./getPSPs.sh <namespace>
---
// example
./getPSPs.sh default
Checking PSP configuration for namespace: cert-manager
ibm-privileged-psp (default)
ibm-restricted-psp (*, default)
---
// example
./getPSPs.sh cert-manager
Checking PSP configuration for namespace: cert-manager
ibm-privileged-psp (default)
ibm-restricted-psp (*, default)
---

# Check each service account to see if it's authorized.
kubectl -n default --quiet=true auth can-i use podsecuritypolicy/ibm-anyuid-psp --as system:serviceaccount:default:default

#####################################
Setting the namespace preference
#####################################
You can permanently save the namespace for all subsequent kubectl commands in that context.

kubectl config set-context --current --namespace=<insert-namespace-name-here>
# Validate it
kubectl config view --minify | grep namespace:

####################################
kubectl config current-context
kubectl config view

// https://rancher.com/learning-paths/introduction-to-kubernetes-namespaces/


####################################
UCD deployment
####################################
==========
// mysql
==========
cd D:\knowledge_AWS\IBM-AWS-sandbox\ucd\cheng1-mysql
cd /opt/ocp-deployment-ccocp401/cheng1-mysql
helm install mysql01 -f ./values.yaml . --namespace default --debug --tls

==========
// create ConfigMap - ucd-user-script
==========
cd D:\knowledge_AWS\IBM-AWS-sandbox\ucd\ucd-configmaps 
kubectl apply -f ucds-configmap.yaml
kubectl delete configmap ucd-user-script
kubectl describe configmap ucd-user-script

==========
// UCD Server
==========
cd D:\knowledge_AWS\IBM-AWS-sandbox\ucd\ucd-server-chart\charts\ibm-ucd-prod
cd /opt/ocp-deployment-ccocp401/ucd-server-chart/charts/ibm-ucd-prod
helm install ucd01 -f ./values.yaml . --namespace default
helm delete ucd01
helm upgrade ucd01 -f ./values.yaml . --namespace default
helm upgrade --install ucd01 -f ./values.yaml . --namespace default

====
Note,
1. EKS does not support "sessionAffinity: ClientIP" in service yaml file.  
        Need to change to "sessionAffinity: None"

2. use the following command to get "External Endpoints"
        kubectl get services -o wide
        
3. The "External Endpoints" created for "ucd01-ibm-ucd-prod" service is incorrectly to use http on 7919
        The correct "External Endpoints" is "https" on port 8443
        The hostname is correct.
        Need to manually construct the "External Endpoints" -> https://<hostname>:8443 
 
http://aaba3d62d714f11eaafb402e77b61620-666543383.us-east-2.elb.amazonaws.com:7919/       
https://aaba3d62d714f11eaafb402e77b61620-666543383.us-east-2.elb.amazonaws.com:8443/

====
D:\knowledge_AWS\IBM-AWS-sandbox\ucd\ucd-server-chart\charts\ibm-ucd-prod>kubectl get services -o wide
NAME                     TYPE           CLUSTER-IP       EXTERNAL-IP                                                               PORT(S)                                        AGE     SELECTOR
guestbook                LoadBalancer   10.100.218.6     a1ac64db0715211eab57506b79012c8f-488398970.us-east-2.elb.amazonaws.com    3000:30533/TCP                                 47m     app=guestbook
kubernetes               ClusterIP      10.100.0.1       <none>                                                                    443/TCP                                        32h     <none>
mysql01                  NodePort       10.100.194.193   <none>                                                                    3306:32238/TCP                                 3h30m   app=mysql01
redis-master             ClusterIP      10.100.203.122   <none>                                                                    6379/TCP                                       49m     app=redis,role=master
redis-slave              ClusterIP      10.100.167.26    <none>                                                                    6379/TCP                                       48m     app=redis,role=slave
ucd01-ibm-ucd-prod       LoadBalancer   10.100.180.219   aaba3d62d714f11eaafb402e77b61620-666543383.us-east-2.elb.amazonaws.com    8443:32009/TCP,7918:31038/TCP,7919:32606/TCP   65m     app.kubernetes.io/component=srv,app.kubernetes.io/instance=ucd01,app.kubernetes.io/name=ibm-ucd-prod
ucd01-ibm-ucd-prod-dfe   LoadBalancer   10.100.211.178   aaba2402f714f11eaafb402e77b61620-2132186806.us-east-2.elb.amazonaws.com   8443:32194/TCP                                 65m     app.kubernetes.io/component=dfe,app.kubernetes.io/instance=ucd01,app.kubernetes.io/name=ibm-ucd-prod
ucd01-ibm-ucd-prod-hl    ClusterIP      None             <none>                                                                    8443/TCP,7918/TCP,7919/TCP                     65m     app.kubernetes.io/component=srv,app.kubernetes.io/instance=ucd01,app.kubernetes.io/name=ibm-ucd-prod
---

==========
// Relay
==========
cd D:\knowledge_AWS\IBM-AWS-sandbox\ucd\agent-relay-chart\charts\ibm-ucdr-prod
cd /opt/ocp-deployment-ccocp401/agent-relay-chart/charts/ibm-ucdr-prod
helm install ucdr -f ./values.yaml . --namespace default
helm delete ucdr
helm upgrade ucdr -f ./values.yaml . --namespace default
helm upgrade --install ucdr -f ./values.yaml . --namespace default

==========
// Agent
==========
cd D:\knowledge_AWS\IBM-AWS-sandbox\ucd\ucd-agent-chart\charts\ibm-ucda-prod
cd /opt/ocp-deployment-ccocp401/ucd-agent-chart/charts/ibm-ucda-prod
helm install ucda -f ./values.yaml . --namespace default
helm delete ucda
helm upgrade ucda -f ./values.yaml . --namespace default
helm upgrade --install ucda -f ./values.yaml . --namespace default

---
Note,
D:\knowledge_AWS\IBM-AWS-sandbox\ucd\ucd-agent-chart\charts\ibm-ucda-prod>helm install ucda -f ./values.yaml . --namespace default
Error: chart requires kubeVersion: >=1.9 which is incompatible with Kubernetes v1.14.9-eks-502bfb

Solution: Update Chart.yaml file to have 
        kubeVersion: '>=v1.14.9-eks-502bfb'
---


###################################
You can then download a single fie from github repo with either:

wget https://github.com/ibmcheng1/tools/blob/master/tools/jdbc/mysql-connector-java-5.1.46.jar
curl https://github.com/ibmcheng1/tools/blob/master/tools/jdbc/mysql-connector-java-5.1.46.jar -o bcmrpi_defconfig












