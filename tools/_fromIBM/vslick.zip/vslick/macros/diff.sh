/*
$VerboseHistory: diff.sh$
*/
#if 0
_command paste();
_command c_enter();
_command undo();
_command undo_cursor();
_command maybe_complete();
_command bottom_of_buffer();
_command top_of_buffer();
_command page_up();
_command page_down();
_command cursor_up();
_command cursor_down();
_command cursor_left();
#endif

struct DIFF_UPDATE_INFO {
   int timer_handle;
   struct {
      int wid;
      boolean isdiff;
   }list[];
   //int wid_list[];
};

struct MERGE_CONFLICT_INFO {
   int ConflictArray[];
   int LastConflictNumber;
   int ResolvedArray[];
   int NumResolved;
};

struct DIFF_MISC_INFO {
   int DiffParentWID;
   _str Buf1StartTime;
   _str Buf2StartTime;
   int IntraLineIsOff;
   boolean DontDeleteMergeOutput;
   typeless Bookmarks;
   _str PreserveInfo;
   boolean AutoClose;
};
#define gMiscInfo          _ctlcopy_right.p_user

static void diff_select_line();
static void diff_select_char();
static void diff_cua_select();
static void diff_deselect();
static void diff_mode_split_insert_line();
static void diff_multi_delete(...);
static void diff_rubout();
static void diff_linewrap_rubout();
static void diff_linewrap_delete_char(...);
static void diff_delete_char();
static void diff_cut_line();
static void diff_delete_line();
static void diff_paste();
static void diff_copy_to_clipboard();
static void diff_copy_word();
static void diff_move_text_tab();
static void diff_ctab();
static void diff_cut_end_line();
static void diff_cut_word();
static void diff_delete_word();
static void diff_prev_word();
static void diff_next_word();
static void diff_complete_prev();
static void diff_complete_next();
static void diff_complete_more();
static int diff_save();
static int diff_find_next();

static void diff_bas_enter();
static void diff_c_enter();
static void diff_cmd_enter();
static void diff_for_enter();
static void diff_pascal_enter();
static void diff_prg_enter();

static void diff_mode_space();
static void diff_expand_alias();
static void diff_undo();
static void diff_undo_cursor();
static void diff_command(...);
static void diff_maybe_deselect_command(...);
static void diff_shift_selection_right();
static void diff_shift_selection_left();
static void diff_maybe_complete();
static void diff_close_form();
static void diff_next_window();
static int diff_exit();
static void diff_mou_click();
static void diff_cursor_left();
static void diff_cursor_right();
static void diff_mou_select_word();
static void diff_mou_select_line();
static void diff_end_line();
static void diff_find_matching_paren();
static void diff_join_line();
static void diff_find(...);
static void diff_mou_extend_selection();
static void diff_push_tag();
static void diff_pop_bookmark();
static void diff_cbacktab();
static void diff_next_proc();
static void diff_prev_proc();
static void diff_find_re();
static void diff_html_key();
static void diff_find_backwards();
static void diff_right_side_of_window();
static void diff_left_side_of_window();
static void diff_vi_restart_word();
static void diff_vi_ptab();
static void diff_vi_pbacktab();
static void diff_vi_begin_next_line();
static void diff_codehelp_complete();
static int diff_quit();

const    DIFF_FIRST_FILE = 1;
const    DIFF_SECOND_FILE = 2;
const    DIFF_UP = 1;
const    DIFF_DOWN = 2;
const    DIFF_GOTO_BOTTOM  = -1;
const    DIFF_GOTO_TOP     = -2;
const    DIFF_PAGE_UP      = -3;
const    DIFF_PAGE_DOWN    = -4;
const    DIFF_SET_CURSOR_Y = -5;
const    DIFF_RETURN_LINENUM = -6;

const    DIFF_DLLNAME='vsdiff.dll';

#define MATCHING_LINE 0x0
#define INSERTED_LINE 0x1
#define CHANGED_LINE  0x2
#define DELETED_LINE  0x4
static void diff_quote_key();

#define DEFAULT_IMAGINARY_TEXT "Imaginary Buffer Line"
