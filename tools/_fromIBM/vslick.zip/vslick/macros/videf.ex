R�    default-keys-on-drop-files-sb-page-down-sb-page-uptop-of-bufferbottom-of-bufferfast-scrollfast-scroll-vsb-thumb-pos-vsb-thumb-posfast-scrollfast-scrollfast-scrollscroll-begin-linescroll-end-line-sb-page-right-sb-page-left-hsb-thumb-pos-hsb-thumb-pos
-on-resize	-on-closecopy-to-clipboardcutpaste
cua-select
cua-select
cua-select
cua-select
cua-select
cua-select
cua-select
cua-select
cua-select
cua-select
cua-select
cua-select	mou-clickmou-select-wordmou-select-linemou-extend-selection
-on-selectalt-bookmarkcodehelp-completeexpand-aliashexexpand-extension-aliaspush-refdiffpush-tagpop-bookmarkundoclose-windownext-windowprev-window	safe-exit	vi-escapeex-prev-editvi-repeat-last-insert	vi-escapepush-tagdefault-keys:c-xpop-bookmarkcmdline-toggle
vi-page-upstop-processvi-pbacktabcut-end-linevi-page-down	vi-statusnext-window	cursor-upcursor-leftcursor-downcursor-rightvi-next-lineend-linevi-prev-lineabort	find-next	find-previ-searchvi-ptabvi-restart-insertion	quote-keyvi-restart-wordpastezoom-windowmaybe-completevi-maybe-keyin-match-parenvi-maybe-keyin-match-parenmaybe-list-matchesalias-cdalt-bookmarkcursor-erroralt-bookmarkexecute-selectionadjust-block-selectioncopy-to-cursor	join-linecutselect-linekeyin-buf-namereflow-paragraphroot-keydeffind-matching-parendeselect	safe-exitbegin-selectselect-charsplit-insert-linemove-text-tabruboutruboutundocopy-to-clipboard	kill-markbegin-line-text-toggleend-linecursor-leftcursor-right	cursor-upcursor-down
vi-page-upvi-page-downdelete-charinsert-togglenext-windowcut-linetop-of-bufferbottom-of-buffer	prev-word	next-wordtop-of-windowbottom-of-windowcbacktabhelpsavequitfileconfigcomparegui-opennext-bufferundojavadoc-editor	scroll-upscroll-downscroll-leftscroll-rightcenter-lineresyncshift-selection-leftshift-selection-rightredo	api-index	move-edgecreate-tileproject-buildproject-compileprev-bufferredo
next-errorupcase-wordlowcase-wordupcase-selectionlowcase-selectionproject-buildproject-compileprev-bufferundo-cursorrecord-macro-toggledefault-keys:c-xlist-buffersdefault-keys:c-x	safe-exitdefault-keys:c-xalias-cddefault-keys:c-xdosdefault-keys:c-xgui-opendefault-keys:c-xpop-bookmarkdefault-keys:c-xbottom-of-bufferdefault-keys:c-xloaddefault-keys:c-xstart-processdefault-keys:c-x
next-errordefault-keys:c-xinsert-toggledefault-keys:c-xreflow-selectiondefault-keys:c-xreverse-i-searchdefault-keys:c-xsavedefault-keys:c-xtop-of-bufferdefault-keys:c-x	copy-worddefault-keys:c-xnothingdefault-keys:c-xlist-clipboardsdefault-keys:c-xresumedefault-keys:c-xstart-recordingdefault-keys:c-xend-recordingdefault-keys:c-x
one-windowdefault-keys:c-xhsplit-windowdefault-keys:c-xcase-indirectdefault-keys:c-xfind-bufferdefault-keys:c-x
last-macrodefault-keys:c-xquitdefault-keys:c-xproject-builddefault-keys:c-xset-next-errordefault-keys:c-xnext-windowdefault-keys:c-xredodefault-keys:c-x
split-linedefault-keys:c-xmove-text-tabdefault-keys:c-xmove-text-backtabappend-to-clipboardlist-clipboards
append-cutvi-command-keysvi-maybe-normal-charactervi-maybe-normal-charactervi-maybe-normal-charactervi-maybe-normal-charactervi-maybe-normal-charactervi-maybe-normal-charactervi-maybe-normal-charactervi-maybe-normal-charactervi-maybe-normal-charactervi-maybe-normal-charactervi-maybe-normal-charactervi-maybe-normal-charactervi-toggle-case-charvi-countvi-cursor-rightvi-tab
vi-backtabvi-cursor-rightvi-cursor-leftvi-cursor-leftvi-forward-delete-charvi-cursor-leftvi-end-linevi-begin-next-linevi-begin-next-linevi-scroll-window-upvi-next-linevi-scroll-window-downvi-next-linevi-prev-linevi-prev-linevi-begin-prev-linevi-begin-linevi-begin-textvi-end-linevi-goto-colvi-prev-sentencevi-next-sentencevi-prev-paragraphvi-next-paragraphvi-prev-sectionvi-next-sectionvi-find-matching-parenvi-to-mark-linevi-to-mark-colex-prev-editvi-scroll-downvi-scroll-up	vi-filtervi-shift-text-leftvi-shift-text-right
vi-cb-namevi-repeat-char-searchvi-reverse-repeat-char-searchex-repeat-last-substitutevi-repeat-last-insert-or-deleteex-modeex-search-modeex-reverse-search-modevi-append-modevi-end-line-append-modevi-prev-wordvi-prev-word2vi-change-line-or-to-cursorvi-change-to-end	vi-deletevi-delete-to-endvi-end-wordvi-end-word2vi-char-search-forwardvi-char-search-backwardvi-goto-linevi-cursor-leftvi-top-of-windowvi-insert-modevi-begin-line-insert-modevi-next-linevi-join-linevi-prev-linevi-cursor-rightvi-bottom-of-windowvi-set-markvi-middle-of-windowex-repeat-searchex-reverse-repeat-searchvi-newline-modevi-above-newline-modevi-put-after-cursorvi-put-before-cursor
ex-ex-modevi-replace-charvi-replace-linevi-substitute-charvi-substitute-linevi-char-search-forward2vi-char-search-backward2vi-undovi-undo-cursorvi-next-wordvi-next-word2vi-forward-delete-charvi-backward-delete-charvi-yank-to-cursorvi-yank-linevi-zero-lineex-zzprocess-keysprocess-begin-lineprocess-enterprocess-ruboutprocess-begin-line
process-upprocess-downcursor-errorfileman-keysfileman-spacemaybe-normal-character
select-allfileman-backupfileman-copyfileman-deletefileman-editfileman-replacefileman-findfileman-movefileman-keyin-namefsort
for-selectfileman-attrfileman-enterfileman-enterfileman-select-upfileman-select-downfileman-deselect-upfileman-deselect-downfileman-help
slick-keysslick-spaceslick-enterc-begin
c-endbracepascal-keyspascal-spacepascal-enterpascal-npascal-npascal-dpascal-dpascal-ypascal-yc-keysc-spacec-enterc-begin
c-endbrace-LCUpdateOptionsreplace-def-data-update-sysmenu-bindingsmenu-mdi-bind-allrc.def-switchbuf-cd0-config-modify0def-process-tab-output0def-guidef-keysdef-alt-menudef-preplacedef-buflistdef-persistent-selectdef-advanced-selectdef-select-styledef-scursor-styledef-updown-coldef-hack-tabsdef-line-insertdef-next-word-styledef-top-bottom-styledef-linewrapdef-cursorwrapdef-jmp-on-tabdef-pulldef-from-cursordef-word-delimdef-restore-cursordef-modal-tabdef-one-filedef-leave-selecteddef-word-continue0def-deselect-pastedef-clipboardsdef-vi-insertion-posdef-vi-modedef-vi-charsdef-vi-chars2def-vi-show-msgdef-show-cb-namedef-vi-left-on-escapedef-ispf-flags0def-brief-word0R� 
   
�-                  �    :  )�:s|�: )�: )� )�: )�: ) : ) ) ) ):  ):  ):  ) ) )	:  )
:  ):  ): ): ):  ):  ):  ):  ): ��: 
   ):  ):  ): ):. )  ) ) )% ): ): ): ):) : ��8:* :  ��8:+ :  ��8 ( 8:  ) :' :  ��8e { * 8� � * 8O[* 8��* 8��* 8��* 8��* 8��* 8[h* 8k}* 8��* 8��* 8��* 8 * 8(* 8��* 8��* 8��* 8S�* 8ds* 8��* 8Um* 8{m* 8��* 8  :  ��8�8 + 8 , 8��8:/ :  ��8:  )$: ��8:  )� 01vi-keysDPCNAEC
A-Za-z0-9_?\!\@\#\$\%\^\&\*\(\)\-\+\|\=\\\{\}\[\]\"\39\`\:\;\~\?\/\,\.\>\<def-setup-fundamentalbMN=Fundamental,TABS=+8,MA=1 74 1,KEYTAB=default-keys,WW=1,IWT=0,ST=0,IN=1,WC=A-Za-z0-9_$,LN=,CF=4,def-setup-process^MN=Process,TABS=+8,MA=1 74 1,KEYTAB=process-keys,WW=1,IWT=0,ST=0,IN=1,WC=A-Za-z0-9_$,LN=,CF=4,def-setup-cUMN=C,TABS=+4,MA=1 74 1,KEYTAB=c-keys,WW=1,IWT=0,ST=0,IN=2,WC=A-Za-z0-9_$,LN=cpp,CF=1,def-setup-h@cdef-setup-cppdef-setup-cxxdef-setup-inldef-setup-pasbMN=Pascal,TABS=+3,MA=1 74 1,KEYTAB=pascal-keys,WW=1,IWT=0,ST=0,IN=2,WC=A-Za-z0-9_$,LN=pascal,CF=1,def-setup-sh@edef-begin-end-pas(begin),(case)|(end);Idef-begin-end-c!(#ifdef),(#ifndef),(#if)|(#endif)def-options-c4 1 1 0 4 1 1def-options-pas3 1 1 0 0 1 0def-options-e3 1 1 0 4 1 0def-setup-ecMN=Slick-C,TABS=+3,MA=1 74 1,KEYTAB=slick-keys,WW=1,IWT=0,ST=0,IN=2,WC=A-Za-z0-9_$,LN=slick-c,CF=1,def-begin-end-e(#if)|(#endif)def-begin-end-asm(proc)|(endp) (macro)|(endm);Idef-setup-asmhMN=Intel Assembly,TABS=+8,MA=1 74 1,KEYTAB=default-keys,WW=1,IWT=0,ST=0,IN=1,WC=A-Za-z0-9_$,LN=asm,CF=1,def-options-javadef-setup-javaYMN=Java,TABS=+8,MA=1 74 1,KEYTAB=c-keys,WW=1,IWT=0,ST=0,IN=2,WC=A-Za-z0-9_$,LN=java,CF=1,def-setup-bourneshellqMN=Bourne Shell,TABS=+8,MA=1 74 1,KEYTAB=ext_keys,WW=1,IWT=0,ST=0,IN=2,WC=A-Za-z0-9_$,LN=Bourne Shell,CF=1,LNL=0,def-options-bourneshell3 1 1 0 0 3 0def-options-cshdef-setup-cshgMN=C Shell,TABS=+8,MA=1 74 1,KEYTAB=ext_keys,WW=1,IWT=0,ST=0,IN=2,WC=A-Za-z0-9_$,LN=C Shell,CF=1,LNL=0,[A-Za-z0-9_$]S 0In~s    $     �$    �$    �� �  �� �  �� �  �$     �$     �$     �$     �$     �$     $     ($     9$     K$     Z$     h$     x$     �$     �$     �$     �$     �$     �$     �$     �$     $     $     "$     5� G  I$     \$     k$     �$     �$     �$     �$     �$     �$     8#     �� �  I#    Z#     s#     �� �  R�   R�#   h ��� � %F -�	   ��� R�   �R�.   � �� �f �j j �f �j ��	 �� R�   |R�$   � �� �F �� ��� �  ��� R�   3R��  � �@  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N  N� e  p    �  �  �  �V 
�  �  �J �F �� �   1F E  Y^ o� � R�   �R�(   � �� �J �N �N   � &� R�   NR��  T �  [b oF �R �N |R �F �  �  �  ^  �  f  5  }C �    x  5    �  O  w  �  �  �  �  �  �  �  �  �  �  o    �  �  �  �  �  �  �  �    3  W  o  �  �  �  �  �    A  j  �  �  �  �    3  .  O  t  �  �  F  H  V  �  b  �  �  �  �    '  @  �  |  �  �  �  �    0  Z  �  �  �  �  �  +    B  ]  �  �  "  �  4  �  |�	 H  �F �R )    �  �  �N � �F �� R�   �R�	   � � R�   �R�	   � �� R�   �R�	   � �� R�   �R�	   � �� R�   �R�	   � �� R�   nR�	   � � R�   OR�	   � `� R�   9R�	   � J� R�   R�	   � .� R�    R�	   � � R�   �
R�n   � ��
  �
  �
  �
  �
  �
  �
  �
  �
  �
  �
  �
  �
  �
  �
  �
  �
  �
  �
  �
  �
  �
  �
  �
  �
  �
� R�   �
R�	   � �
�  R�   �
R�	   � �
�  R�   �
R�	   � �
�! R�   f
R�	   � w
�! R�   N
R�	   � _
�" R�   -
R�	   � >
�" R�   
R�	   � %
�" R�   �	R�	   � 

�" R�   �	R�	   � �	�" R�   �	R�	   � �	�" R�   �	R�	   � �	�" R�   �	R�	   � �	�" R�   a	R�	   � r	�" R�   E	R�   | V	�# R�   &	R�   x 7	�# R�   	R�   t !	�# R�   �R�   l ��# R�   �R�   d ��# R�   �R�   \ ��# R�   �R�   X ��# R�   �R�   T ��# R�   lR�   P }�# R�   NR�   L _�# R�   �R�	   � ��" R�    R�<  H .	    #  0  <  I  V  `  l  v  �  �F 6�  �  �  �  �  �  �  �  �    �      �F �J *b 9� o� TZ a  j  \  S� r ��F *�  �  �  �  �  �  �  �  �  �  �N �� ��Z ��  ��  �  ��  ��  ��  ��  ��  ��  �  �  �  ��    ��    ��  $  ��  0  D  ��  ��  M  W  dV 2p  �  �  �  �  �  �  �  �  �  �  �  F     &  2R w� @F LN U  c  t  ~N �  �F "J �F �N j  u  >  I  T  _F �  �  4  8V *�  �  �  �  �  �  �  �  �  ��  �F "�        +  7  >  S  iN n  x  �  �  �  �F 
�  �  �J �  �  �  �    F "  .F :Z �b R 8Z +  <F �N 3F Cz �N �j �  �  �  �b �J �J �Z �� F N J bC VC +C C }C nC 7C EC �C �C �C �C �C �C �C �C �S � 