#ifndef TAGSDB_SH
#define TAGSDB_SH

//////////////////////////////////////////////////////////////////////
// Database file types that can be opened using this library
//
#define VS_DBTYPE_tags        0
#define VS_DBTYPE_references  1
#define VS_DBTYPE_msbrowse    2

//////////////////////////////////////////////////////////////////////
// Database flags indicating attributes for this tag database.
// The low sixteen bits are reserved for Visual SlickEdit development.
//
#define VS_DBFLAG_occurrences    0x00000001  // tag occurrences
#define VS_DBFLAG_no_occurrences 0x00000002  // user specifically said no to occurrences
#define VS_DBFLAG_reserved       0x0000fffc  // future expansion, reseerved by MicroEdge
#define VS_DBFLAG_user           0x00010000  // user flags

//////////////////////////////////////////////////////////////////////
// Database version, corresponding to Visual Slickedit, release 4.0c
//
#define VS_TAG_USER_VERSION             3000
#define VS_TAG_USER_VERSION_WIDE_FLAGS  3100
#define VS_TAG_USER_VERSION_FILE_TYPES  4000
#define VS_TAG_USER_VERSION_CASE_FIXED  4100
#define VS_TAG_USER_VERSION_EXCEPTIONS  4200
#define VS_TAG_USER_VERSION_COPY_FILES  4300
#define VS_TAG_USER_VERSION_RELATIVE    4400
#define VS_TAG_USER_VERSION_LARGE_IDS   5000
#define VS_TAG_USER_VERSION_DISK_HASH   5100
#define VS_TAG_USER_VERSION_REFERENCES  5200
#define VS_TAG_USER_VERSION_COMPACT     5300
#define VS_TAG_USER_VERSION_EXTENSIONS  5400
#define VS_TAG_USER_VERSION_OCCURRENCES 5500
#define VS_TAG_USER_VERSION_NO_NEXTPREV 5600
#define VS_TAG_LATEST_VERSION           5600
#define VS_REF_USER_VERSION             4000
#define VS_REF_USER_VERSION_RELATIVE    4100
#define VS_REF_USER_VERSION_LARGE_IDS   5000
#define VS_REF_USER_VERSION_DISK_HASH   5100
#define VS_REF_LATEST_VERSION           VS_TAG_LATEST_VERSION

//////////////////////////////////////////////////////////////////////
// Standard tag types, by default, always present in database
// standard type name is always "xxx" for VS_TAGTYPE_xxx,
// for example, the type name for VS_TAGTYPE_proc is "proc".
// ID's 37-127 are reserved for future use by Microedge.
//
#define VS_TAGTYPE_proc         1  // procedure or command
#define VS_TAGTYPE_proto        2  // function prototype
#define VS_TAGTYPE_define       3  // preprocessor macro definition
#define VS_TAGTYPE_typedef      4  // type definition
#define VS_TAGTYPE_gvar         5  // global variable declaration
#define VS_TAGTYPE_struct       6  // structure definition
#define VS_TAGTYPE_enumc        7  // enumeration value
#define VS_TAGTYPE_enum         8  // enumerated type
#define VS_TAGTYPE_class        9  // class definition
#define VS_TAGTYPE_union       10  // structure / union definition
#define VS_TAGTYPE_label       11  // label
#define VS_TAGTYPE_interface   12  // interface, eg, for Java
#define VS_TAGTYPE_constructor 13  // class constructor
#define VS_TAGTYPE_destructor  14  // class destructor
#define VS_TAGTYPE_package     15  // package / module / namespace
#define VS_TAGTYPE_var         16  // member of a class / struct / package
#define VS_TAGTYPE_lvar        17  // local variable declaration
#define VS_TAGTYPE_constant    18  // pascal constant
#define VS_TAGTYPE_function    19  // function
#define VS_TAGTYPE_property    20  // property
#define VS_TAGTYPE_program     21  // pascal program
#define VS_TAGTYPE_library     22  // pascal library
#define VS_TAGTYPE_parameter   23  // function or procedure parameter
#define VS_TAGTYPE_import      24  // package import or using
#define VS_TAGTYPE_friend      25  // C++ friend relationship
#define VS_TAGTYPE_database    26  // SQL/OO Database
#define VS_TAGTYPE_table       27  // Database Table
#define VS_TAGTYPE_column      28  // Database Column
#define VS_TAGTYPE_index       29  // Database index
#define VS_TAGTYPE_view        30  // Database view
#define VS_TAGTYPE_trigger     31  // Database trigger
#define VS_TAGTYPE_form        32  // GUI Form or window
#define VS_TAGTYPE_menu        33  // GUI Menu
#define VS_TAGTYPE_control     34  // GUI Control or Widget
#define VS_TAGTYPE_eventtab    35  // GUI Event table
#define VS_TAGTYPE_procproto   36  // Prototype for procedure
#define VS_TAGTYPE_task        37  // Ada task
#define VS_TAGTYPE_include     38  // C++ include or Ada with (dependency)
#define VS_TAGTYPE_file        39  // COBOL file descriptor
#define VS_TAGTYPE_group       40  // Container variable
#define VS_TAGTYPE_subfunc     41  // Nested function or cobol paragraph
#define VS_TAGTYPE_subproc     42  // Nested procedure or cobol paragraph
#define VS_TAGTYPE_cursor      43  // Database result set cursor
#define VS_TAGTYPE_LASTID      43  // last tag type ID
#define VS_TAGTYPE_FIRSTUSER  128  // first user-defined tag type ID

//////////////////////////////////////////////////////////////////////
// Tag type filtering flags, formerly PUSHTAG_* flags in slick.sh
//
#define VS_TAGFILTER_CASESENSITIVE 0x01
#define VS_TAGFILTER_PROC          0x02
#define VS_TAGFILTER_PROTO         0x04
#define VS_TAGFILTER_DEFINE        0x08
#define VS_TAGFILTER_ENUM          0x10
#define VS_TAGFILTER_GVAR          0x20
#define VS_TAGFILTER_TYPEDEF       0x40
#define VS_TAGFILTER_STRUCT        0x80
#define VS_TAGFILTER_UNION         0x100
#define VS_TAGFILTER_LABEL         0x200
#define VS_TAGFILTER_INTERFACE     0x400
#define VS_TAGFILTER_PACKAGE       0x800
#define VS_TAGFILTER_VAR           0x1000
#define VS_TAGFILTER_CONSTANT      0x2000
#define VS_TAGFILTER_PROPERTY      0x4000
#define VS_TAGFILTER_LVAR          0x8000
#define VS_TAGFILTER_MISCELLANEOUS 0x10000
#define VS_TAGFILTER_DATABASE      0x20000
#define VS_TAGFILTER_GUI           0x40000
#define VS_TAGFILTER_INCLUDE       0x80000
#define VS_TAGFILTER_SUBPROC       0x100000
#define VS_TAGFILTER_ANYTHING      0x1ffffe
#define VS_TAGFILTER_ANYPROC       (VS_TAGFILTER_PROTO|VS_TAGFILTER_PROC|VS_TAGFILTER_SUBPROC)
#define VS_TAGFILTER_ANYDATA       (VS_TAGFILTER_GVAR|VS_TAGFILTER_VAR|VS_TAGFILTER_LVAR|VS_TAGFILTER_PROPERTY|VS_TAGFILTER_CONSTANT)
#define VS_TAGFILTER_ANYSTRUCT     (VS_TAGFILTER_STRUCT|VS_TAGFILTER_UNION|VS_TAGFILTER_INTERFACE)
#define VS_TAGFILTER_NOBINARY      0x80000000

//////////////////////////////////////////////////////////////////////
// Flags associated with tags, denoting access restrictions and
// and other attributes of class members (proc's, proto's, and var's)
//    NOT virtual and NOT static implies normal class method
//    NOT protected and NOT private implies public
//    NOT const implies normal read/write access
//
#define VS_TAGFLAG_virtual      0x0001  // virtual function (instance)
#define VS_TAGFLAG_static       0x0002  // static method / member (class)
#define VS_TAGFLAG_access       0x000C  // access flags (public/protected/private/package)
#define VS_TAGFLAG_public       0x0000  // public access (test equality with flags&access)
#define VS_TAGFLAG_protected    0x0004  // protected access
#define VS_TAGFLAG_private      0x0008  // private access
#define VS_TAGFLAG_package      0x000C  // package access (for Java)
#define VS_TAGFLAG_const        0x0010  // const
#define VS_TAGFLAG_final        0x0020  // final
#define VS_TAGFLAG_abstract     0x0040  // abstract/deferred method
#define VS_TAGFLAG_inline       0x0080  // inline / out-of-line method
#define VS_TAGFLAG_operator     0x0100  // overloaded operator
#define VS_TAGFLAG_constructor  0x0200  // class constructor
#define VS_TAGFLAG_volatile     0x0400  // volatile method
#define VS_TAGFLAG_template     0x0800  // template class
#define VS_TAGFLAG_inclass      0x1000  // proc is in class definition?
#define VS_TAGFLAG_destructor   0x2000  // class destructor
#define VS_TAGFLAG_const_destr  0x2200  // class destructor or constructor
#define VS_TAGFLAG_synchronized 0x4000  // synchronized (thread safe)
#define VS_TAGFLAG_transient    0x8000  // transient / persistent data

#define VS_TAGFLAG_native       0x00010000  // Java native method?
#define VS_TAGFLAG_macro        0x00020000  // Tag was part of macro expansion?
#define VS_TAGFLAG_extern       0x00040000  // "extern" C prototype (not local)
#define VS_TAGFLAG_maybe_var    0x00080000  // Prototype which could be a variable.
#define VS_TAGFLAG_anonymous    0x00100000  // Anonymous structure or class
#define VS_TAGFLAG_mutable      0x00200000  // mutable C++ class member
#define VS_TAGFLAG_extern_macro 0x00400000  // external macro (COBOL copy file)
#define VS_TAGFLAG_linkage      0x00800000  // 01 level var in COBOL linkage section

//////////////////////////////////////////////////////////////////////
// Flags passed to tag to extract specific information about the
// current tag, using tag_get_detail(), below
//
#define VS_TAGDETAIL_max 256

#define VS_TAGDETAIL_current (VS_TAGDETAIL_max*0)
#define VS_TAGDETAIL_context (VS_TAGDETAIL_max*1)
#define VS_TAGDETAIL_local   (VS_TAGDETAIL_max*2)
#define VS_TAGDETAIL_match   (VS_TAGDETAIL_max*3)

#define VS_TAGDETAIL_name           0  // (string) tag name
#define VS_TAGDETAIL_type           1  // (string) tag type
#define VS_TAGDETAIL_type_id        2  // (int) unique id for tag type (VS_TAGTYPE_*)
#define VS_TAGDETAIL_file_name      3  // (string) full path of file the tag is located in
#define VS_TAGDETAIL_file_date      4  // (string) modification data of file when tagged
#define VS_TAGDETAIL_file_line      5  // (int) line number of tag within file
#define VS_TAGDETAIL_file_id        6  // (int) unique id for file the tag is located in
#define VS_TAGDETAIL_class_simple   7  // (string) name of class the tag is present in
#define VS_TAGDETAIL_class_name     8  // (string) name of class with outer classes
#define VS_TAGDETAIL_package        9  // (string) package/module/namespace tag belongs to
#define VS_TAGDETAIL_class_id      10  // (int) unique id for class tag belongs to
#define VS_TAGDETAIL_flags         11  // (int) tag flags (see VS_TAGFLAG_* above)
#define VS_TAGDETAIL_return        12  // (string) return type for functions, type of variables
#define VS_TAGDETAIL_arguments     13  // (string) function arguments
#define VS_TAGDETAIL_num_tags      17  // (int) number of tags/instances in database
#define VS_TAGDETAIL_num_classes   18  // (int) number of classes in database
#define VS_TAGDETAIL_num_files     19  // (int) number of files in database
#define VS_TAGDETAIL_num_types     20  // (int) number of types in database
#define VS_TAGDETAIL_num_refs      21  // (int) number of references/occurrences in database
#define VS_TAGDETAIL_throws        22  // (string) exceptions thrown by function
#define VS_TAGDETAIL_included_by   23  // (string) full path of parent source file
#define VS_TAGDETAIL_return_only   24  // (string) return type, no default args
#define VS_TAGDETAIL_return_value  25  // (string) default value for variable
#define VS_TAGDETAIL_file_ext      26  // (string) p_extension property for file
#define VS_TAGDETAIL_context_id    27  // (int) returns same result as tag_current_context()
#define VS_TAGDETAIL_local_id      28  // (int) returns same result as tag_current_local
#define VS_TAGDETAIL_current_file  29  // (int) returns name of file in current context

#define VS_TAGDETAIL_context_tag_file      (VS_TAGDETAIL_context+0)
#define VS_TAGDETAIL_context_name          (VS_TAGDETAIL_context+1)
#define VS_TAGDETAIL_context_type          (VS_TAGDETAIL_context+2)
#define VS_TAGDETAIL_context_file          (VS_TAGDETAIL_context+3)
#define VS_TAGDETAIL_context_line          (VS_TAGDETAIL_context+4)
#define VS_TAGDETAIL_context_start_linenum (VS_TAGDETAIL_context+4)
#define VS_TAGDETAIL_context_start_seekpos (VS_TAGDETAIL_context+5)
#define VS_TAGDETAIL_context_scope_linenum (VS_TAGDETAIL_context+6)
#define VS_TAGDETAIL_context_scope_seekpos (VS_TAGDETAIL_context+7)
#define VS_TAGDETAIL_context_end_linenum   (VS_TAGDETAIL_context+8)
#define VS_TAGDETAIL_context_end_seekpos   (VS_TAGDETAIL_context+9)
#define VS_TAGDETAIL_context_class         (VS_TAGDETAIL_context+10)
#define VS_TAGDETAIL_context_flags         (VS_TAGDETAIL_context+11)
#define VS_TAGDETAIL_context_args          (VS_TAGDETAIL_context+12)
#define VS_TAGDETAIL_context_return        (VS_TAGDETAIL_context+13)
#define VS_TAGDETAIL_context_outer         (VS_TAGDETAIL_context+14)
#define VS_TAGDETAIL_context_parents       (VS_TAGDETAIL_context+15)
#define VS_TAGDETAIL_context_throws        (VS_TAGDETAIL_context+16)
#define VS_TAGDETAIL_context_included_by   (VS_TAGDETAIL_context+17)
#define VS_TAGDETAIL_context_return_only   (VS_TAGDETAIL_context+18)
#define VS_TAGDETAIL_context_return_value  (VS_TAGDETAIL_context+19)

#define VS_TAGDETAIL_local_tag_file        (VS_TAGDETAIL_local+0)
#define VS_TAGDETAIL_local_name            (VS_TAGDETAIL_local+1)
#define VS_TAGDETAIL_local_type            (VS_TAGDETAIL_local+2)
#define VS_TAGDETAIL_local_file            (VS_TAGDETAIL_local+3)
#define VS_TAGDETAIL_local_line            (VS_TAGDETAIL_local+4)
#define VS_TAGDETAIL_local_start_linenum   (VS_TAGDETAIL_local+4)
#define VS_TAGDETAIL_local_start_seekpos   (VS_TAGDETAIL_local+5)
#define VS_TAGDETAIL_local_scope_linenum   (VS_TAGDETAIL_local+6)
#define VS_TAGDETAIL_local_scope_seekpos   (VS_TAGDETAIL_local+7)
#define VS_TAGDETAIL_local_end_linenum     (VS_TAGDETAIL_local+8)
#define VS_TAGDETAIL_local_end_seekpos     (VS_TAGDETAIL_local+9)
#define VS_TAGDETAIL_local_class           (VS_TAGDETAIL_local+10)
#define VS_TAGDETAIL_local_flags           (VS_TAGDETAIL_local+11)
#define VS_TAGDETAIL_local_args            (VS_TAGDETAIL_local+12)
#define VS_TAGDETAIL_local_return          (VS_TAGDETAIL_local+13)
#define VS_TAGDETAIL_local_outer           (VS_TAGDETAIL_local+14)
#define VS_TAGDETAIL_local_parents         (VS_TAGDETAIL_local+15)
#define VS_TAGDETAIL_local_throws          (VS_TAGDETAIL_local+16)
#define VS_TAGDETAIL_local_included_by     (VS_TAGDETAIL_local+17)
#define VS_TAGDETAIL_local_return_only     (VS_TAGDETAIL_local+18)
#define VS_TAGDETAIL_local_return_value    (VS_TAGDETAIL_local+19)

#define VS_TAGDETAIL_match_tag_file        (VS_TAGDETAIL_match+0)
#define VS_TAGDETAIL_match_name            (VS_TAGDETAIL_match+1)
#define VS_TAGDETAIL_match_type            (VS_TAGDETAIL_match+2)
#define VS_TAGDETAIL_match_file            (VS_TAGDETAIL_match+3)
#define VS_TAGDETAIL_match_line            (VS_TAGDETAIL_match+4)
#define VS_TAGDETAIL_match_start_linenum   (VS_TAGDETAIL_match+4)
#define VS_TAGDETAIL_match_start_seekpos   (VS_TAGDETAIL_match+5)
#define VS_TAGDETAIL_match_scope_linenum   (VS_TAGDETAIL_match+6)
#define VS_TAGDETAIL_match_scope_seekpos   (VS_TAGDETAIL_match+7)
#define VS_TAGDETAIL_match_end_linenum     (VS_TAGDETAIL_match+8)
#define VS_TAGDETAIL_match_end_seekpos     (VS_TAGDETAIL_match+9)
#define VS_TAGDETAIL_match_class           (VS_TAGDETAIL_match+10)
#define VS_TAGDETAIL_match_flags           (VS_TAGDETAIL_match+11)
#define VS_TAGDETAIL_match_args            (VS_TAGDETAIL_match+12)
#define VS_TAGDETAIL_match_return          (VS_TAGDETAIL_match+13)
#define VS_TAGDETAIL_match_outer           (VS_TAGDETAIL_match+14)
#define VS_TAGDETAIL_match_parents         (VS_TAGDETAIL_match+15)
#define VS_TAGDETAIL_match_throws          (VS_TAGDETAIL_match+16)
#define VS_TAGDETAIL_match_included_by     (VS_TAGDETAIL_match+17)
#define VS_TAGDETAIL_match_return_only     (VS_TAGDETAIL_match+18)
#define VS_TAGDETAIL_match_return_value    (VS_TAGDETAIL_match+19)

//////////////////////////////////////////////////////////////////////
// Standard file types, used to distinguish between source files
// pulled in naturally by tagging, object files, class files,
// executables, browser databaser, debug databases, and source files
// referenced by various other items.
//
#define VS_FILETYPE_source      0
#define VS_FILETYPE_references  1
#define VS_FILETYPE_include     2

//////////////////////////////////////////////////////////////////////
// Flags associated with tags, denoting access restrictions and
// and other attributes of class members (proc's, proto's, and var's)
//    NOT virtual and NOT static implies normal class method
//    NOT const implies normal read/write access
//    NOT volatile implies normal optimizations are safe
//
#define VS_INSTFLAG_static       0x01
#define VS_INSTFLAG_virtual      0x02
#define VS_INSTFLAG_volatile     0x04
#define VS_INSTFLAG_const        0x08

//////////////////////////////////////////////////////////////////////
// Standard reference types, by default, always present in database
// standard type name is always "xxx" for VS_REFTYPE_xxx,
// for example, the type name for VS_REFTYPE_proc is "proc".
//
#define VS_REFTYPE_unknown    0     // unspecified
#define VS_REFTYPE_macro      1     // use of #define'd macro
#define VS_REFTYPE_call       2     // function or procedure call
#define VS_REFTYPE_var        3     // use of a variable
#define VS_REFTYPE_import     4     // use of a package
#define VS_REFTYPE_derive     5     // class derivation
#define VS_REFTYPE_type       6     // use of abstract type
#define VS_REFTYPE_class      7     // instantiantion of class
#define VS_REFTYPE_constant   8     // use of constant value or enum value
#define VS_REFTYPE_label      9     // use of label for goto

//////////////////////////////////////////////////////////////////////
// Characters used as separators when storing compound strings
// in the database.
//
#define VS_TAGSEPARATOR_class     ":"  // seperates nested class names
#define VS_TAGSEPARATOR_package   "/"  // seperates class from package name
#define VS_TAGSEPARATOR_args      "\1" // seperates arguments from return type
#define VS_TAGSEPARATOR_throws    "\2" // seperates arguments from exceptions
#define VS_TAGSEPARATOR_parents   ";"  // seperates list of class parents
#define VS_TAGSEPARATOR_equals    "="  // seperates type of constant from value

/////////////////////////////////////////////////////////////////////
// Tag match types for speed insert of tag matches
#define VS_TAGMATCH_tag      0
#define VS_TAGMATCH_context  1
#define VS_TAGMATCH_local    2
#define VS_TAGMATCH_match    3

/////////////////////////////////////////////////////////////////////
// Options flags used by various functions in context.e
// for example _MatchSymbolInContext()
#define VS_TAGCONTEXT_ALLOW_locals         0x00000001
#define VS_TAGCONTEXT_ALLOW_private        0x00000002
#define VS_TAGCONTEXT_ALLOW_protected      0x00000004
#define VS_TAGCONTEXT_ALLOW_package        0x00000008
#define VS_TAGCONTEXT_ONLY_volatile        0x00000010
#define VS_TAGCONTEXT_ONLY_const           0x00000020
#define VS_TAGCONTEXT_ONLY_static          0x00000040
#define VS_TAGCONTEXT_ONLY_non_static      0x00000080
#define VS_TAGCONTEXT_ONLY_data            0x00000100
#define VS_TAGCONTEXT_ONLY_funcs           0x00000200
#define VS_TAGCONTEXT_ONLY_classes         0x00000400
#define VS_TAGCONTEXT_ONLY_packages        0x00000800
#define VS_TAGCONTEXT_ONLY_inclass         0x00001000
#define VS_TAGCONTEXT_ONLY_constructors    0x00002000
#define VS_TAGCONTEXT_ONLY_this_class      0x00004000
#define VS_TAGCONTEXT_ONLY_parents         0x00008000
#define VS_TAGCONTEXT_FIND_derived         0x00010000
#define VS_TAGCONTEXT_ALLOW_anonymous      0x00020000
#define VS_TAGCONTEXT_ONLY_locals          0x00040000
#define VS_TAGCONTEXT_ALLOW_any_tag_type   0x00080000
#define VS_TAGCONTEXT_ACCESS_private       0x0000000E
#define VS_TAGCONTEXT_ACCESS_protected     0x0000000C
#define VS_TAGCONTEXT_ACCESS_package       0x00000008
#define VS_TAGCONTEXT_ACCESS_public        0x00000000
#define VS_TAGCONTEXT_ANYTHING             VS_TAGCONTEXT_ACCESS_public

/////////////////////////////////////////////////////////////////////
// Context information retrieved by get_user_tag_info() and
// get_inheritance_tag_info(), see below.  This is used to determine
// what action to take when an item in the class browser or inheritance
// browser is selected.
//
// Use the following methods provided in cbrowser.e for
// initializing and comparing instances of this structure.
//    tag_browse_info_init(cm)
//    tag_browse_info_equal(cm1,cm2,case_sensitive)
//
struct VS_TAG_BROWSE_INFO {
   _str tag_database;      // filename of tag file (database)
   _str category;          // caption of tag category (see CB_*, above)
   _str class_name;        // class name for this tag
   _str member_name;       // the tag name
   _str qualified_name;    // qualified class name (if the tag is a class)
   _str type_name;         // tag type
   _str file_name;         // absolute path of file the tag is located in
   _str extension;         // p_extension property for 'file_name'
   int  line_no;           // line number tag should be found on
   int  seekpos;           // seek position of tag
   int  scope_line_no;     // line number of tag's scope start
   int  scope_seekpos;     // seek position of tag's scope start
   int  end_line_no;       // line number of tag's end
   int  end_seekpos;       // seek position of tag's end
   int  column_no;         // column position on line (p_col)
   int  flags;             // bit flags for tag attributes (see slick.sh)
   _str return_type;       // tag return type (unused)
   _str arguments;         // tag signature (function arguments)
   _str exceptions;        // exceptions throws by function or method
};


///////////////////////////////////////////////////////////////////////////
// Prototypes for the tagging function.
//

/**
 * Higher level than {@link tag_close_db}.  Closes the database for
 * write options, leaving it open for read options, caching
 * anything that was buffered.
 * 
 * @param file_name Name of tag file to close
 * @return 0 on success, <0 on error.
 * @see tag_close_db()
 * @since 3.0
 * @deprecated Use {@link tag_close_db()} instead with caching options.
 */
int tag_close_db2(_str file_name=null);

/**
 * Returns next tag name which is a prefix match of 'name'.
 * 'find_first' must be 1 to initialize matching.
 * Returns '' when no more matches are found.  find_first
 * must be 2 to terminate matching so that this procedure
 * may remove its temporary buffers.
 * 
 * @param name   tag name or tag prefix to search for
 * @param find_first Find first item (1) or find next (0), or terminate (2).
 * @param ext    file extension (p_extension)
 * @return 0 on success, nonzero on error.
 * @see tag_find_prefix()
 * @see tag_next_prefix()
 * @see f_match()
 * @see mt_match()
 * @since 2.0
 */
_str tag_match(_str name,int find_first,_str ext="");


///////////////////////////////////////////////////////////////////////////
// administrative functions
  
/**
 * Specify the amount of memory to use for the database cache.
 * 
 * @param cache_size amount of memory in bytes
 * @return 0 on success, <0 on error.  The minimum size cache allowed is 512k.
 * @since 3.0
 */
int tag_set_cache_size(int cache_size);

/**
 * Create a tag database, with standard tables, index, and types.
 * 
 * @param file_name file path where to create new database
 *                  If file_name exists, it will be truncated.
 * @param db_type (optional) if not given, creates tag database.
 *                if (db_type==VS_DBTYPE_references), then creates
 *                a tag references database.
 * @return database handle >= 0 on success, <0 on error.
 * @since 3.0
 */
int tag_create_db(_str file_name, int db_type=VS_DBTYPE_tags);

/**
 * Open an existing tag database and return a handle to the database.
 * This function opens the database for read-write access.
 * 
 * @param file_name file name of tag database to open.
 * @return database handle >= 0 on success, <0 on error.
 * @see tag_create_db()
 * @see tag_read_db()
 * @see tag_close_db()
 * @see tag_flush_db()
 * @see tag_current_db()
 * @see tag_close_all_db()
 * @since 3.0
 */
int tag_open_db(_str file_name);

/**
  Open an existing tag database and return a handle to the database.
  This function opens the database for read-only access.
  
  @param file_name        file name of tag database to open.

  @return database handle >= 0 on success, <0 on error.
*/
int tag_read_db(_str file_name);

/**
  Flush all unwritten data to disk for the database.
  
  @return 0 on success, <0 on error.
*/
int tag_flush_db();

/**
  Return the name of the database currently open
  
  @return name of database, or the empty string on error.
*/
_str tag_current_db();

/**
  Close the current tag database.
  
  @param file_name        (optional) explicite filename of database to close
                          otherwise the current open database is closed.
  @param leave_open       (optional) leave the tag file open read-only
  
  @return 0 on success, <0 on error.
*/
int tag_close_db(_str file_name=null,boolean leave_open=false);

/**
  Close all open tag databases.
  
  @return 0 on success, <0 on error.
*/
int tag_close_all_db();

/**
  Display the effective version of the tagsdb.dll
  
  @return nothing.
*/
void tagsdb_version();

/**
  Return the version of the tags database currently open.
  
  @return VS_TAG_USER_VERSION or higher.
*/
int tag_current_version();

/**
  Return the database description/title.
  
  @return database description, null terminated, or the empty string on error.
*/
_str tag_get_db_comment();

/**
  Sets the database description/title.
  
  @param comment          description or title of this database

  @return 0 on success, <0 on error.
*/
int tag_set_db_comment(_str comment);

/**
  Return the database flags VS_DBFLAG_*
  
  @return <0 on error, flags bitset on success.
*/
int tag_get_db_flags();

/**
  Sets the database flags VS_DBFLAG_*
  
  @param flags            bitset of VS_DBFLAG_*

  @return 0 on success, <0 on error.
*/
int tag_set_db_flags(int flags);


///////////////////////////////////////////////////////////////////////////
// insertion and removal of tags

/**
  Set up for inserting a series of tags from a single file for
  update.  Doing this allows the tag database engine to detect
  and handle updates more effeciently, even in the presence of
  duplicates.
  
  @param file_name        full path of file the tags are located in

  @return 0 on success, <0 on error.
*/
int tag_insert_file_start(_str file_name);

/**
  Clean up after inserting a series of tags from a single file
  for update.  Doing this allows the tag database engine to
  remove any tags from the database that are no longer valid.
  
  @return 0 on success, <0 on error.
*/
int tag_insert_file_end();

/**
  Remove all references from the given references (browse database or
  object) file from the database.  This is an effective, but costly way
  to perform an incremental update of the data imported from a
  references file.  First remove all items associated with that file,
  then insert them again.
  
  @param file_name        full path of file the reference info came from
  @param remove_file      if non-zero, the file is removed from the database

  @return 0 on success, <0 on error.
*/
int tag_remove_from_file(_str file_name, int RemoveFileRecord=0);


///////////////////////////////////////////////////////////////////////////
// file name handling functions
  
/**
  Modify the date of tagging for the given file.  Since date of tagging
  is not involved in indexing, this is safe to do in the record, in place.
  This method always uses the current date when setting the date of tagging.
  
  @param file_name        name of file to update date of tagging for
  @param modify_date      (optional) modification date when tagged, read from disk
                          if modify_date is NULL.  Format is YYYYMMDDHHMMSSmmm.

  @return 0 on success, <0 on error.
*/
int tag_set_date(_str file_name, _str modify_date=null);

/**
  Retrieve the date of tagging for the given file.
  The string returned by this function is structured such
  that consecutive dates are ordered lexicographically,
  and is reported in local time cooridinates (YYYYMMDDHHMMSSmmm).
  This function has the side effect of finding and position the file iterator
  on the given file name, returns BT_RECORD_NOT_FOUND_RC if file_name is not
  in the database.
  
  @param file_name        name of file to update date of tagging for
  @param modify_date      (reference) returns the file's modification date when tagged
  @param included_by      name of file that 'file_name' was included by

  @return 0 on success, <0 on error.
*/
int tag_get_date(_str file_name, _str &date_tagged, ...);

/**
  API function for setting the extension type for the given filename
  This corresponds to the p_extension property of 'file_name', not
  necessarily the literal extension of file_name.
  
  @param file_name        name of file to set extension for
  @param extension        p_extension property for file_name where tagged

  @return 0 on success, <0 on error.
*/
int tag_set_extension(_str file_name,_str extension);

/**
  API function for retrieving the extension type for the given filename
  This corresponds to the p_extension property of 'file_name', not
  necessarily the literal extension of file_name.
  
  @param file_name        name of file to set extension for
  @param extension        (reference) p_extension property for file_name

  @return 0 on success, <0 on error.
*/
int tag_get_extension(_str file_name, _str &extension);

/**
  Retreive the name of the next file included in this tag database.
  
  @param file_id          id of file, from tag_get_detail()
  @param file_name        (reference) full path of file containing tags

  @return 0 on success, <0 on error.
*/
int tag_get_file(int file_id, _str &file_name);

/**
  Retreive the name of the first file included in this tag database.
  
  @param file_name        (reference) full path of file containing tags
  @param search_for       (optional) specific file to search for (prefix search)
  
  @return 0 on success, <0 on error.
*/
int tag_find_file(_str &file_name, _str search_file=null);

/**
  Retreive the name of the next file included in this tag database.
  
  @param file_name        (reference) full path of file containing tags

  @return 0 on success, <0 on error
*/
int tag_next_file(_str &file_name);

/**
  Retrieve the name of the first file included by file_name
  
  @param file_name        full path of "main" source file
  @param include_name     (reference) full path of included file

  @return 0 on success, <0 on error.
*/
int tag_find_include_file(_str file_name, _str &include_name);

/**
  Retrieve the name of the next file included by file_name
  
  @param file_name        full path of "main" source file
  @param include_name     (reference) full path of included file

  @return 0 on success, <0 on error.
*/
int tag_next_include_file(_str file_name, _str &include_name);

/**
  Retreive the name of first the source file that included (directly
  or indirectly), the given file (expected to be an include file).
  
  @param file_name        full path of file that was included
  @param included_by      (reference) full path of source file

  @return 0 on success, <0 on error.
*/
int tag_find_included_by(_str file_name, _str &included_by);

/**
  Retreive the name of next the source file that included (directly
  or indirectly), the given file (expected to be an include file).
  
  @param file_name        full path of file that was included
  @param included_by      (reference) full path of source file

  @return 0 on success, <0 on error.
*/
int tag_next_included_by(_str file_name, _str &included_by);


///////////////////////////////////////////////////////////////////////////
// language/p_extension type name handling functions
  
/**
  API function for finding what languages/p_extension's are tagged
  in this database, typically, there is only one.  Note that if
  files are added and removed from a project, stale extension types
  may be left around.
  
  @param extension        (reference) set to first extension found
  @param search_for       (optional) particular extension to search for

  @return 0 on success, <0 on error.
*/
int tag_find_extension(_str &extension, _str search_ext=null);

/**
  API function for finding the next language/p_extension's tagged
  in this database.  See tag_find_extension (above).
  
  @param extension        (reference) set to first extension found

  @return 0 on success, <0 on error.
*/
int tag_next_extension(_str &extension);


///////////////////////////////////////////////////////////////////////////
// type name handling functions
  
/**
  Retreive the name of the next type included in this tag database.
  
  @param type_id          id of type, from tag_get_detail()
  @param type_name        (reference) full path of type containing tags

  @return 0 on success, <0 on error.
*/
int tag_get_type(int type_id, _str &type_name);

/**
  Retreive the name of the first type included in this tag database.
  
  @param type_name        (reference) full path of type containing tags
  @param search_for       (optional) specific type to search for (prefix search)
  
  @return 0 on success, <0 on error.
*/
int tag_find_type(_str &type_name, _str search_for=null);

/**
  Retreive the name of the next type included in this tag database.
  
  @param type_name        (reference) full path of type containing tags

  @return 0 on success, <0 on error.
*/
int tag_next_type(_str &type_name);

/**
  Filter the given tag type based on the given filter flags
  
  @param type_id          tag type ID
  @param filter_flags     VS_TAGFILTER_*
  @param type_name        (optional) look up type ID using this name
  @param tag_flags        (optional) check tag flags for VS_TAGFLAG_maybe_var

  @return 1 if the type is allowed according to the flags, 0 if not.
*/
int tag_filter_type(int type_id, int filter_flags, _str type_name=null, int tag_flags=0);


///////////////////////////////////////////////////////////////////////////
// NOTE: administrative functions are now in tagsmain.h
//  
// insertion and removal of tags
  
/**
  Insert the given tag with accompanying information into the
  the database.  This is the easiest to use version of insert,
  since you do not need to know the ID of the tag type, you
  simply pass a string.
  
  If a record with the same tag name, type, file, *and* class
  already exists in the database, the line number will be updated.
  Returns 
  
  @param tag_name         tag string
  @param tag_type         string specifying tag_type (see above for
                          list of standard type names).  If the string
                          is not a standard type, a new type will be
                          created and inserted in the tag database.
  @param file_name        full path of file the tag is located in
  @param line_no          (optional) line number of tag within file
  @param class_name       (optional) name of class that tag is present in,
                          use concatenation (as defined by language rules)
                          to specify names of inner classes.
  @param tag_flags        (optional) see VS_TAGFLAG_* above.
  @param signature        (optional) tag signature (return type, arguments, etc)

  @return 0 on success, <0 on error.
*/
int tag_insert_tag(_str tag_name, _str tag_type, _str file_name,
                   int line_no, _str class_name, int tag_flags, _str signature);

/**
  Insert the given tag with the accompanying information into the
  database.  This function is identical to vsTagInsert, except
  that rather than passing in a tag type, you pass in an int, using
  one of the standard types defined above (see VS_TAGTYPE_*).
 
  If a record with the same tag name, type, file, *and* class
  already exists in the database, the line number will be updated.
  
  @param tag_name         tag string
  @param type_id          tag type (see VS_TAGTYPE_*), will return an error
                          if (tag_type <= 0 || tag_type > VSTAGTYPE_LASTID).
  @param file_name        full path of file the tag is located in
  @param line_no          (optional) line number of tag within file
  @param class_name       (optional) name of class that tag is present in,
                          use concatenation (as defined by language rules)
                          to specify names of inner classes.
  @param tag_flags        (optional) see VS_TAGFLAG_* above.
  @param signature        (optional) tag signature (return type, arguments, etc)

  @return 0 on success, <0 on error.
*/
int tag_insert_simple(_str tag_name, int type_id, _str file_name, int line_no,
                      _str class_name, int tag_flags, _str signature);

/**
  Remove the current tag (most recently retrieved tag) from the database.
  
  @return 0 on success, <0 on error.
*/
int tag_remove_tag();

/**
  Remove all tags associated with the given class from the database.
  
  @param class_name       full name of the class the tag is associated with
                          if NULL, all non-class tags are removed.
  @param remove_class     if non-zero, the class is removed from the database,
                          in addition to the tags associated with the class.

  @return 0 on success, <0 on error.
*/
int tag_remove_from_class(_str class_name, boolean remove_class=false);

/**
  Modify the set of parent classes for a given class.
  Use the NULL or empty string to indicate that class_name is a base class.
  
  @param class_name       class to modify parent relationships for
  @param parents          classes that 'class_name' inherits from, semicolon separated

  @return 0 on success, <0 on error.
*/
int tag_set_inheritance(_str class_name, _str parents);

/**
  Retrieve the set of parent classes for a given class.
  
  This function has the side effect of position the class iterator on the
  given class.  Returns BT_RECORD_NOT_FOUND_RC if class_name is not
  in the database.
  
  @param class_name       class to modify parent relationships for
  @param parents          classes that 'class_name' inherits from, semicolon separated

  @return 0 on success, <0 on error.
*/
int tag_get_inheritance(_str class_name, _str &parents);


///////////////////////////////////////////////////////////////////////////
// Retrieval functions
  
/**
  Retrieve first tag with the given tag name, type, and class
  (all are necessary to uniquely identify a tag).  If class_name
  is unknown, simply use NULL.
  Use vsTagGetInfo (below) to extract the details about the tag.
  
  @param tag_name         name of tag to search for
  @param tag_type         tag type name (see VS_TAGTYPE_*)
  @param class_name       name of class that tag is present in,
                          use concatenation (as defined by language rules)
                          to specify names of inner classes.
  @param arguments        (optional) function arguments to attempt to
                          match.  Ignored if they result in no matches.

  @return 0 on success, <0 on error, or if no such tag.
*/
int tag_find_tag(_str tag_name, _str tag_type, _str class_name, _str signature=null);

/**
  Retrieve next tag with the given tag name, type, and class
  (all are necessary to uniquely identify a tag).  If class_name
  is unknown, simply use NULL.
  Use vsTagGetInfo (below) to extract the details about the tag.
  Should be called only after calling tag_find_tag.
  
  @param tag_name         name of tag to search for
  @param tag_type         tag type name (see VS_TAGTYPE_*)
  @param class_name       name of class that tag is present in,
                          use concatenation (as defined by language rules)
                          to specify names of inner classes.
  @param arguments        (optional) function arguments to attempt to
                          match.  Ignored if they result in no matches.

  @return 0 on success, <0 on error, or if no such tag.
*/
int tag_next_tag(_str tag_name, _str tag_type, _str class_name, _str signature=null);

/**
  Retrieve first with the given tag name.
  Use tag_get_info (below) to extract the details about the tag.
  
  @param tag_name         name of tag to search for
  @param file_name        full path to file containing tag
  @param line_no          line that tag is expected to be present on

  @return 0 on success, <0 on error, or if no such tag.
*/
int tag_find_closest(_str tag_name, _str file_name, int line_no, boolean case_sensitive=false);

/**
  Retrieve first tag with the given tag name (case-insensitive).
  Use vsTagGetInfo (below) to extract the details about the tag.
  
  @param tag_name         name of tag to search for
  @param case_sensitive   (optional, default false) case sensitive tag name comparison
  @param class_name       (optional) class name to search for tag in

  @return 0 on success, <0 on error, or if no such tag.
*/
int tag_find_equal(_str tag_name, boolean case_sensitive=false, _str class_name=null);

/**
  Retrieve the next tag with the same tag name as the last one retrieved.
  Should be called only after calling tag_find_equal or tag_find_tag.
  
  @param case_sensitive   (optional, default false) case sensitive tag name comparison
  @param class_name       (optional) class name to search for tag in
  
  @return 0 on success, <0 on error, or if no such tag.
*/
int tag_next_equal(boolean case_sensitive=false, _str class_name=null,
                   boolean skip_duplicates=false);

/**
  Retrieve the first tag with the given tag name (case-insensitive).
  
  @param tag_prefix       tag name prefix to search for
  @param case_sensitive   (optional, default false) case sensitive tag name comparison
  @param class_name       (optional) class name to search for tag in

  @return 0 on success, <0 on error, or if no such tag.
*/
int tag_find_prefix(_str tag_prefix, boolean case_sensitive=false, _str class_name=null);

/**
  Retrieve the next tag with the given prefix (case-insensitive).
  Should be called only after calling vsTagGetTagPrefix().
  
  @param tag_prefix       tag name prefix to search for
  @param case_sensitive   (optional, default false) case sensitive tag name comparison
  @param class_name       (optional) class name to search for tag in

  @return 0 on success, <0 on error, or if no such tag.
*/
int tag_next_prefix(_str tag_prefix, boolean case_sensitive=false,
                    _str class_name=null, boolean skip_duplicates=false);

/**
  Retrieve the next tag with the a tag name matching the given
  regular expression with the given matching options.
  
  @param tag_regex        tag name regular expression to search for
  @param search_options   search options, passed on to vsStrPos()

  @return 0 on success, <0 on error, or if no such tag.
*/
int tag_find_regex(_str tag_regex, _str options='');

/**
  Retrieve the next tag with the a tag name matching the given
  regular expression with the given matching options.
  Should be called only after calling tag_find_regex().
  
  @param tag_regex        tag name regular expression to search for
  @param search_options   search options, passed on to vsStrPos()

  @return 0 on success, <0 on error, or if no such tag.
*/
int tag_next_regex(_str tag_regex, _str options='');

/**
  Retrieve information about the current tag (as defined by calls
  to getTagEQ, getTagPrefix, getNextEQ, getNextPrefix).  If no such
  tag, all strings will be set to the empty string, and line_no will
  be set to 0.
  
  @param tag_name         (reference) tag string (native case)
  @param type_name        (reference) string specifying tag_type
                          (see above for list of standard type names).
  @param file_name        (reference) full path of file the tag is located in
  @param line_no          (reference) line number of tag within file
                          set to 0 if not defined.
  @param class_name       (reference) name of class that tag is present in,
                          uses concatenation (as defined by language rules)
                          to specify names of inner classes (see insert, above).
                          set to empty string if not defined.
  @param tag_flags        (reference) see VS_TAGFLAG_* above.

  @return nothing.
*/
void tag_get_info(_str &tag_name, _str &type_name, _str &file_name,
                  int &line_no, _str &class_name, int &tag_flags);

/**
  Retrieve specific details about the current tag (as defined by calls
  to getTagEQ, getTagPrefix, getNextEQ, getNextPrefix).  If no such
  tag, all strings will be set to the empty string, and ints to 0.
  See VS_TAGDETAIL_*, above.
  
  @param tag_detail       ID of detail to extract (VS_TAGDETAIL_*)
  @param result           (reference) set to value of requested tag detail

  @return nothing
*/
void tag_get_detail(int detail, var result);


///////////////////////////////////////////////////////////////////////////
// file-name based retrieval functions
  
/**
  Find the first tag in the given file.
  
  @param file_name        full path of file containing tags

  @return 0 on success, <0 on error.
*/
int tag_find_in_file(_str file_name);

/**
  Find the next tag in the current file.
  
  @return 0 on success, <0 on error.
*/
int tag_next_in_file();


///////////////////////////////////////////////////////////////////////////
// class-name based retrieval functions
  
/**
  Retreive the name of the first class included in this tag database.
  
  @param class_id         id of class/package, from tag_get_detail()
  @param class_name       (reference) name of class

  @return 0 on success, <0 on error.
*/
int tag_get_class(int class_id, _str &class_name);

/**
  Retreive the name of the first class included in this tag database.
  
  @param class_name       (reference) name of class
  @param search_for       (optional) specific class to search for (prefix search)
  @param normalize        (optional) normalize the class name (find what package it belongs to)
  @param ignore_case      (optional) perform case-insensitive search? (default is case-sensitive)
  @param cur_class_name   (optional) name of current class in context

  @return 0 on success, <0 on error.
*/
int tag_find_class(_str &class_name, _str search_class=null,
                   boolean normalize=false, boolean case_sensitive=true,
                   _str cur_class_name=null);

/**
  Retreive the name of the next class included in this tag database.
  
  @param class_name       (reference) name of class
  @param search_for       (optional) specific class to search for (prefix search)
  @param normalize        (optional) normalize the class name (find what package it belongs to)
  @param ignore_case      (optional) perform case-insensitive search? (default is case-sensitive)
  @param cur_class_name   (optional) name of current class in context

  @return 0 on success, <0 on error.
*/
int tag_next_class(_str &class_name, _str search_class=null,
                   boolean normalize=false,boolean case_sensitive=true,
                   _str cur_class_name=null);

/**
  Find the first class in the given class.
  
  @param class_name       name of class, containing tags

  @return 
*/
int tag_find_in_class(_str class_name);

/**
  Find the next tag in the given class.
  
  @return 0 on success, <0 on error.
*/
int tag_next_in_class();


///////////////////////////////////////////////////////////////////////////
// global identifier retrieval functions
  
/**
  Retrieve the first tag included in this tag database with global
  scope that is one of the given type (type_id) and that
  matches the given tag flag mask (mask & tag.mask != 0).
  Tag names are ordered lexicographically, case insensitive
  
  @param type_id          first type id (see VS_TAGTYPE_*, above)
                          if (type_id<0), returns tags with ID>VS_TAGTYPE_LASTID
  @param mask             flag mask (see VS_TAGFLAG_*, above)
  @param nzero            if 1, succeed if mask & tag.flags != 0
                          if 0, succeed if mask & tag.flags == 0

  @return 0 on success, <0 on error.
*/
int tag_find_global(int type_id, int mask, int nzero);

/**
  Retrieve the next tag included in this tag database with global
  scope that is one of the given type (type_id) and that
  matches the given tag flag mask (mask & tag.mask != 0).
  Tag names are ordered lexicographically, case insensitive
  
  @param type_id          first type id (see VS_TAGTYPE_*, above)
                          if (type_id<0), returns tags with ID>VS_TAGTYPE_LASTID
  @param mask             flag mask (see VS_TAGFLAG_*, above)
  @param nzero            if 1, succeed if mask & tag.flags != 0
                          if 0, succeed if mask & tag.flags == 0

  @return 0 on success, <0 on error.
*/
int tag_next_global(int type_id, int mask, int nzero);


///////////////////////////////////////////////////////////////////////////
// Class browser related functions

/**
  Speed-demon way to determine if the given type is a function or
  procedure type. (proc, proto, func, constr, or destr).
  
  @param type_name        string specifying tag's type name (from tag_get_info)

  @return 1 if the item is a func, 0, otherwise.
*/
int tag_tree_type_is_func(_str type_name);

/**
  Speed-demon way to determine if the given type is a class, struct,
  or union (class, struct, union).
  
  @param type_name        string specifying tag's type name (from tag_get_info)

  @return 1 if the item is a class, 0, otherwise.
*/
int tag_tree_type_is_class(_str type_name);

/**
  Speed-demon way to determine if the given type is a package,
  library, or program (package, lib, prog).
  
  @param type_name        string specifying tag's type name (from tag_get_info)

  @return 1 if the item is a package, 0, otherwise.
*/
int tag_tree_type_is_package(_str type_name);

/**
  Encode class name, member name, signature, etc. in order to make
  caption for tree item very quickly.  Returns the resulting tree caption
  as a NULL terminated string.
  
  The output string is generally formatted as follows:
  <PRE>
     member_name[()] <tab> [class_name::member_name[(arguments)]
  </PRE>
  Parenthesis are added only for function types (proc, proto, constr, destr, func).
  The result is returned as a pointer to a static character array.
  
  This function is highly optimized, since it is one of the most
  critical code paths used by the class browser.
  
  @param member_name      tag name
  @param type_name        tag type (from tag_get_info)
  @param class_name       enclosing class name for tag (from tag_get_info)
  @param flags            tag flags (from tag_get_info)
  @param arguments        tag argumetns (from tag_get_detail)
  @param include_tab      if 0, does not create separate tab for details

  @return caption as a statically allocated string.
*/
_str tag_tree_make_caption(_str member_name, _str type_name, _str class_name,
                           int flags, _str arguments, boolean include_tab=false);

/**
  Accellerated version of tag_tree_make_caption for handling case where
  you are creating a caption for the current tag, local, context, or
  match item.
  
  @param match_type       VS_TAGMATCH_*
  @param local_or_ctx_id  local, context, or match ID, 0 for current tag
  @param include_class    if 0, does not include class name
  @param include_args     if 0, does not include function signature
  @param include_tab      if 0, does not create separate tab for details

  @return The result is returned as a pointer to a static character array.
*/
_str tag_tree_make_caption_fast(int match_type,int local_or_context_id,
                                boolean include_class=true,boolean include_args=true,
                                boolean include_tab=false);

/**
  Filter the given item based on the given filtering flags, and
  determine the access level and member type.
  
  This is the DLL entry point for member filtration, all logic is offloaded
  to vsTagTreeFilterMember(), above.
  
  @param filter_flags     filtering options flags (see CB_SHOW_*) above
  @param type_name        tag type (from tag_get_info)
  @param in_class         if 1, treat as a class member, (class_name != '')
  @param tag_flags        tag bit flags (from tag_get_info)
  @param i_access         (reference) access level output
  @param i_type           (reference) item type for selecting icon

  @return 0 if the item is filtered out, 1 if it passes the filters.
*/
int tag_tree_filter_member(int filter_flags, _str type_name, int in_class,
                           int tag_flags, int &i_access, int &i_type);
/**
  Filter the given item based on the given filtering flags, and
  determine the access level and member type.
  
  This is the DLL entry point for member filtration, all logic is offloaded
  to vsTagTreeFilterMember(), above.
  
  @param filter_flags_1   filtering options flags, part 1 (see CB_SHOW_*) above
  @param filter_flags_2   filtering options flags, part 2 (see CB_SHOW_*) above
  @param type_name        tag type (from tag_get_info)
  @param in_class         if 1, treat as a class member, (class_name != '')
  @param tag_flags        tag bit flags (from tag_get_info)
  @param i_access         (reference) access level output
  @param i_type           (reference) item type for selecting icon

  @return 0 if the item is filtered out, 1 if it passes the filters.
*/
int tag_tree_filter_member2(int filter_flags_1, int filter_flags_2,
                            _str type_name, int in_class, int tag_flags,
                            int &i_access, int &i_type);

/**
  This function is called to prepare this module for inserting a large
  number of tags from a common class or category.  It copies a number
  of options and parameters into globals where they are accessed only
  by vsTagTreeAddClassMember().  This mitigates the parameter passing
  overhead normally required by vsTagTreeAddClassMember.
  
  @param f                window ID of form containing the class tree view
  @param i                tree index which items will be inserted under
  @param t                window ID of class browser tree view
  @param in_refresh       non-zero if we are in a refresh operation
  @param class_filter     regular expression for class filtering
  @param member_filter    regular expression for member filtering
  @param exception_name   name of tag to be allowed as an exception even
                          if class/member/attribute filtration fails.
  @param filter_flags     attribute (flag-based) filtration flags
  @param icons            two-dimensional array of tag bitmaps

  @return 0 on success, <0 on error.
*/
int tag_tree_prepare_expand(int f, int i, int t, int in_refresh,
                            _str class_filter, _str member_filter,
                            _str exception_name, int filter_flags,
                            var icons, int filter_flags2=0);

/**
  This function is used to get the picture indexes of the icons
  corresponding to the given i_access level and i_type category.
  You must call tag_tree_prepare_expand() prior to calling this function.
  i_access and i_type are typically obtained from tag_tree_filter_member.
  
  @param i_access         access level
  @param i_type           item type for selecting icon
  @param leaf_flag        (reference) is this item a container or leaf?
  @param pic_member       (reference) picture index for bitmap

  @return nothing.
*/
void tag_tree_select_bitmap(int i_access, int i_type, int &leaf_flag, int &pic_member);

/**
 * Simple to use, but very fast entry point for selecting the bitmap
 * to be displayed in the tree control corresponding to the given
 * tag information.  You must call tag_tree_prepare_expand() prior to
 * calling this function.
 * 
 * @param filter_flags_1  first part of class browser filter flags
 * @param filter_flags_2  second part of class browser filter flags
 * @param type_name       tag type name
 * @param class_name      tag class name, just checked for null/empty
 * @param tag_flags       tag flags, bitset of VS_TAGFLAG_*
 * @param leaf_flag       (reference) -1 implies leaf item, 0 or 1 container
 * @param pic_member      (reference) set to picture index of bitmap

 * @return 0 on success, <0 on error, >0 if filtered out.
 */
int tag_tree_get_bitmap(int filter_flags_1, int filter_flags_2,
                        _str type_name, _str class_name, int tag_flags,
                        int &leaf_flag, int &pic_member);

/**
  Add the members of the given class to the class browser tree view.
  
  @param class_name       name of class to add members of
  @param in_file_name     only add class members located in given file
  @param tag_file_id      unique numeric ID for tag file
  @param in_count         (reference, input, output), number of items inserted

  @return nothing
*/
int tag_tree_add_members_of(_str class_name, _str in_file_name,
                            int tag_file_id, int &in_count);

/**
  Add members with type t1 to the given category where the tag flags and
  the given mask are either zero or non-zero, as required by nzero.

  @param t1               tag type ID
  @param mask             bit mask (see VS_TAGFLAG_*, in tagsdb.h)
  @param nzero            add member if (mask & tag_flags) is zero or nonzero?
  @param category_name    tag category to add members from
  @param in_count         (reference, input, output), number of items inserted

  @return 0 on error, <0 on error.
*/
int tag_tree_add_members_in_category(int t1, int mask, int nzero,
                                     _str category_name, int &in_count);

/**
  Add members with type t1 to the given category where the tag flags and
  the given mask are either zero or non-zero, as required by nzero.
  
  @param prefix           tag name prefix to search for
  @param t1               tag type ID
  @param mask             bit mask (see VS_TAGFLAG_*, in tagsdb.h)
  @param nzero            add member if (mask & tag_flags) is zero or nonzero?
  @param category_name    tag category to add members from
  @param in_count         (reference, input, output), number of items inserted

  @return 0 on error, <0 on error.
*/
int tag_tree_add_members_in_section(_str prefix, int t1, int mask, int nzero,
                                    _str category_name, int &in_count);

/**
  Create the canononical tag display string of the form:
  <PRE>
     tag_name(class_name:type_name)flags
  </PRE>
  This is used to speed up find-tag and maketags for languages that
  do not insert tags from DLLs.
  
  @param tag_name         the name of the tag
  @param class_name       class/container the tag belongs to
  @param type_name        the tag type, (see VS_TAGTYPE_*)
                          (optional) integer tag flags (see VS_TAGFLAG_*)
                          
  @return The result is returned as a pointer to a statically allocated
          character string.
*/
_str tag_tree_compose_tag(_str tag_name, _str class_name, _str type_name,
                          int tag_flags=0,_str signature="",_str return_type="");

/**
  Decompose the canononical tag display string of the form:
  <PRE>
     tag_name(class_name:type_name)flags
  </PRE>
  This is used to speed up find-tag and maketags for languages that
  do not insert tags from DLLs.
  
  All output strings are set to the empty string if they do not match,
  tag_flags is set to 0 if there is no match.
  
  @param proc_name        tag display string
  @param tag_name         (reference) the name of the tag
  @param class_name       (reference) class/container the tag belongs to
  @param type_name        (reference) the tag type, (see VS_TAGTYPE_*)
  @param tag_flags        (reference) integer tag flags (see VS_TAGFLAG_*)

  @return nothing.
*/
void tag_tree_decompose_tag(_str proc_name, _str &tag_name, _str &class_name,
                            _str &type_name, int &tag_flags,
                            _str &arguments=null, _str &return_type=null);

/**
  Pretty-print function arguments to output buffer
  
  @param signature        signature, straight from the database

  @return The output is returned in a staticly allocated string pointer.
*/
_str tag_tree_format_args(_str signature);

/**
  API function for inserting a tag entry with supporting info into
  the given tree control.
  
  @param tree_wid         window ID of the tree control
  @param tree_index       parent index to insert item under
  @param include_tab      if 0, does not create separate tab for details
  @param force_leaf       if < 0, force leaf node, otherwise choose by type
  @param tree_flags       flags passed to vsTreeAddItem
  @param tag_name         name of entry
  @param type_name        type of tag, (see VS_TAGTYPE_*)
  @param file_name        path to file that is located in
  @param line_no          line number that tag is positioned on
  @param class_name       name of class that tag belongs to
  @param tag_flags        tag attributes (see VS_TAGFLAG_*)
  @param signature        arguments and return type

  @return tree index on success, <0 on error.
*/
int tag_tree_insert_tag(int tree_wid, int tree_index, int include_tab,
                        int force_leaf, int tree_flags, _str tag_name,
                        _str type_name, _str file_name, int line_no,
                        _str class_name, int tag_flags, _str signature);

/**
  Insert the given context, local, match, or current tag
  into the given tree.
  
  @param tree_id             tree widget to load info into
  @param tree_index          tree index to insert into
  @param match_type          VS_TAGMATCH_*
  @param local_or_ctx_id     local, context, or match ID, 0 for current tag
  @param include_tab         include tab when creating caption
  @param force_leaf          force item to be inserted as a leaf item
  @param tree_flags          tree flags to set for this item
  @param include_sig         include function/define/template signature
  @param include_class       include class name

  @return tree index on success, <0 on error.
*/
int tag_tree_insert_fast(int tree_wid, int tree_index, int match_type,
                         int match_id, int include_tab, int force_leaf,
                         int tree_flags, int include_sig, int include_class);

/**
  API function for inserting a tag entry with supporting info into
  the given list control.
                    
  @param list_wid         window ID of the list control
  @param include_tab      if 0, does not create separate tab for details
  @param indent_x         indent after bitmap, if 0, use default of 60 (TWIPS)
  @param tag_name         name of entry
  @param type_name        type of tag, (see VS_TAGTYPE_*)
  @param file_name        path to file that is located in
  @param line_no          line number that tag is positioned on
  @param class_name       name of class that tag belongs to
  @param tag_flags        tag attributes (see VS_TAGFLAG_*)
  @param signature        arguments and return type

  @return 0 on success, <0 on error.
*/
int tag_list_insert_tag(int list_wid, int include_tab, int indent_x,
                        _str tag_name, _str type_name, _str file_name,
                        int line_no, _str class_name, int tag_flags, _str signature);

/**
  Compare the two argument lists, this method works for both
  Delphi/Pascal/Ada style arguments and C/C++/Java style arguments.
  
  @param arg_list1        argument list number 1
  @param arg_list2        argument list number 2
  @param unqualify        loose comparison, peel off class qualifications

  @return 0 if they match, nonzero otherwise.
*/
int tag_tree_compare_args(_str args1, _str args2, boolean unqualify);

/**
  This function sets the user data for the given node in the given tree
  calculated using the algorithm designed for the class browser, creating
  a (potentially) large integer that may be decomposed to reveal a
  tag file ID, file ID, and line number.
  
  @param tree_wid         tree control to set user info for
  @param tree_index       index of node in tree to set info at
  @param tag_file_id      integer assigned to tag file that node comes from
  @param file_id          file ID of item being added to tree (0 for current)
  @param line_no          line number at which tag occurs

  @return nothing.
*/
void tag_tree_set_user_info(int tree_wid, int tree_index, int tag_file_id,
                            int file_id, int line_no);




///////////////////////////////////////////////////////////////////////////
// Functions for tracking tag instances
  
/**
  Add a new tag instance and return the unique tag ID associated
  with this new instance.  If an exact match already exists in the
  database, then just return the existing ID.
  
  @param inst_name        name of tag instance (case insensitive)
  @param inst_type        type of tag instance (see tagsmain.h, VS_TAGTYPE_*)
  @param inst_flags       reference attributes (see VS_REFFLAG_*)
  @param inst_class       class associated with tag (zero for global)
  @param inst_args        arguments associated with tag (eg. function args)
  @param file_name        name of file where tag instance is located
  @param line_no          line which tag instace is on

  @return tag instance ID on success, <0 on error.
*/
int tag_insert_instance(_str inst_name, _str inst_type, int inst_flags,
                        _str inst_class, _str inst_args, _str file_name, int line_no);

/**
  Extract the supplementary information associated with a tag instance.
  
  @param inst_id          unique ID of instance to get info about
                          (use tag_match_instance() to get this ID)
  @param inst_name        (reference) name of tag instance (case insensitive)
  @param inst_type        (reference) type of tag instance (see tagsmain.h, VS_TAGTYPE_*)
  @param inst_flags       (reference) reference attributes (see VS_REFFLAG_*)
  @param inst_class       (reference) class associated with tag (zero for global)
  @param inst_args        (reference) arguments associated with tag (eg. function args)
  @param file_name        (reference) name of file where tag instance is located
  @param line_no          (reference) line which tag instace is on

  @return nothing.
*/
void tag_get_instance_info(int inst_id, _str & inst_name, _str &inst_type,
                           int &inst_flags, _str &inst_class, _str &inst_args,
                           _str &file_name,  int &line_no);

/**
  Locate the tag instance matching the given parameters.
  Instances are matched by tag name first (which must match),
  then class, type, flags, arguments, and finally file and
  line proximity.
  
  @param inst_name        name of tag instance (case insensitive)
  @param inst_type        type of tag instance (see tagsmain.h, VS_TAGTYPE_*)
  @param inst_flags       reference attributes (see VS_REFFLAG_*)
  @param inst_class       class associated with tag (zero for global)
  @param inst_args        arguments associated with tag (eg. function args)
  @param file_name        name of file where tag instance is located
  @param line_no          line which tag instace is on
  @param case_sensitive   case sensitive name/class/args comparison

  @return The ID of the the most exact match available, or <0 on error.
*/
int tag_match_instance(_str inst_name, _str inst_type, int inst_flags,
                       _str inst_class, _str inst_args, _str file_name,
                       int line_no, int case_sensitive);


///////////////////////////////////////////////////////////////////////////
// Functions for tracking tag references
  
/**
  Add a tag reference located in the given file name and line number
  showing the tag instance (refto_id) used within the context
  (refby_id), also a tag instance.  refby_id==0 implies the tag
  was used as a global or the context is unknown.
  
  @param refto_id         unique ID of tag referenced (from tag_insert_instance)
  @param refby_id         unique ID of tag context (from tag_insert_instance)
  @param ref_file         name of references (browse db or object) file
  @param ref_type         type of reference (see VS_REFTYPE_*)
  @param file_name        name of file where reference occurs
  @param line_no          line where reference occurs

  @return 0 on success, <0 on error.
*/
int tag_insert_reference(int refto_id, int refby_id, _str ref_file,
                         int ref_type, _str file_name, int line_no);

/**
  Find the first tag instance referenced by the given tag instance.
  The tag is identified by its unique ID, see tag_match_instance().
  This is typically used with functions (caller/callee relationship)
  or structures (container/item relationships).
  
  @param inst_id          unique identifier of calling function.
  @param ref_type         (reference) reference type (see VS_REFTYPE_*)
  @param file_name        (reference) full path of file the tag is located in
  @param line_no          (reference) line number of tag within file

  @return instance ID on success, <0 on error.
*/
int tag_find_refer_to(int inst_id, int &ref_type, _str &file_name, int &line_no);

/**
  Find the next tag instance referenced by the given tag instance.
  The tag is identified by its unique ID, see tag_match_instance().
  This is typically used with functions (caller/callee relationship).
  
  @param inst_id          unique identifier of calling function.
  @param ref_type         (reference) reference type (see VS_REFTYPE_*)
  @param file_name        (reference) full path of file the tag is located in
  @param line_no          (reference) line number of tag within file

  @return instance ID on success, <0 on error.
*/
int tag_next_refer_to(int inst_id, int &ref_type, _str &file_name, int &line_no);

/**
  Find the first location in which the given tag is referenced.
  The tag is identified by its unique ID, see tag_match_instance().
  
  @param inst_id          unique identifier of calling function.
  @param ref_type         (reference) reference type (see VS_REFTYPE_*)
  @param file_name        (reference) full path of file the tag is located in
  @param line_no          (reference) line number of tag within file

  @return instance ID on success, <0 on error.
*/
int tag_find_refer_by(int inst_id, int &ref_type, _str &file_name, int &line_no);

/**
  Find the next location in which the given tag is referenced.
  The tag is identified by its unique ID, see ref_match_instance().
  
  @param inst_id         unique identifier of calling function.
  @param ref_type        (reference) reference type (see VS_REFTYPE_*)
  @param file_name       (reference) full path of file the tag is located in
  @param line_no         (reference) line number of tag within file

  @return instance ID on success, <0 on error.
*/
int tag_next_refer_by(int inst_id, int &ref_type, _str &file_name, int &line_no);



///////////////////////////////////////////////////////////////////////////
//  Context tracking related functions.
  
/**
  Add a tag and its context information to the context list.
  The context for the current tag includes all tag information,
  as well as the ending line number and begin/scope/end seek
  positions in the file.  If unknown, the end line number/seek
  position may be deferred, see tag_end_context().
  
  @param outer_context    context ID for the outer context (eg. class/struct)
  @param tag_name         tag string
  @param tag_type         string specifying tag_type
  @param file_name        full path of file the tag is located in
  @param start_line_no    start line number of tag within file
  @param start_seekpos    start seek position of tag within file
  @param scope_line_no    start line number of start of tag inner scope
  @param scope_seekpos    start seek position of tag inner scope
  @param end_line_no      (optional) ending line number of tag within file
  @param end_seekpos      (optional) end seek position of tag within file
  @param class_name       (optional) name of class that tag is present in,
                          use concatenation (as defined by language rules)
                          to specify names of inner classes.
  @param tag_flags        (optional) see VS_TAGFLAG_* above.
  @param signature        (optional) tag signature (return type, arguments, etc)

  @return sequence number (context_id) of tag context on success, or <0 on error.
*/
int tag_insert_context(int outer_context, _str tag_name, _str tag_type,
                       _str file_name, int start_line_no, int start_seekpos,
                       int scope_line_no, int scope_seekpos,
                       int end_line_no, int end_seekpos,
                       _str class_name, int tag_flags, _str signature);

/**
  Set the end positions of the context at with the given context ID.
  
  @param context_id       id for the context to modify
  @param end_line_no      ending line number of tag within file
  @param end_seekpos      end seek position of tag within file

  @return int VSAPI
*/
int tag_end_context(int context_id,int end_line_no, int end_seekpos);

/**
  Set the class inheritance for the given context tag.
  
  @param context_id       id for the context to modify
  @param parents          parents of the context item

  @return 0 on success, <0 on error.
*/
int tag_set_context_parents(int context_id, _str parents);

/**
  Clear all context information.
  
  @param file_name        (optional) name of file to initialize context to
                                                
  @return 0 on success, <0 on error.
*/
int tag_clear_context(.../*VSHREFVAR file_name*/);

/**
  Return the total number of context tags.
  
  @return the total number of context tags.
*/
int tag_get_num_of_context();

/**
  Retrieve information about the given context ID.
  
  @param context_id       context ID to look up (from tag_insert_context)
  @param tag_name         (reference) tag string (native case)
  @param type_name        (reference) string specifying tag_type
                          (see above for list of standard type names).
  @param file_name        (reference) full path of file the tag is located in
  @param start_line_no    (reference) start line number of tag within file
  @param start_seekpos    (reference) start seek position of tag within file
  @param scope_line_no    (reference)start line number of start of tag inner scope
  @param scope_seekpos    (reference) start seek position of tag inner scope
  @param end_line_no      (optional) ending line number of tag within file
  @param end_seekpos      (optional) end seek position of tag within file
  @param class_name       (reference) name of class that tag is present in,
                          uses concatenation (as defined by language rules)
                          to specify names of inner classes (see insert, above).
                          set to empty string if not defined.
  @param tag_flags        (reference) see VS_TAGFLAG_* above.
  @param signature        (reference) arguments or formal parameters
  @param return_type      (reference) constant value or return type

  @return 0 on success.
*/
int tag_get_context(int context_id, _str &tag_name, _str &type_name, _str &file_name,
                    int &start_line_no, int &start_seekpos,
                    int &scope_line_no, int &scope_seekpos,
                    int &end_line_no, int &end_seekpos,
                    _str &class_name, int &tag_flags,
                    _str &signature, _str &return_type);

/**
  Check if the current buffer position is still within the current context
  
  @return One of the following codes:
  <PRE>
      0 -- the context is not set or totally wrong
     -1 -- context info loaded, but the cursor is out of context
      1 -- the context is within the tag definition
      2 -- the context is within the scope of the tag/function
  </PRE>
*/
int tag_check_context();

/**
  Sort the items in the current context by seek position.
  The precise sort order is first by non-descrasing starting
  seekpos, and for items with identical start seek positions,
  non-increasing end seek position, and for items with identical
  span, the original insertion order for the items.
  
  In addition to sorting the items in the current context, this
  function computes the outer contexts for each item in the
  current context.
  
  @return 0 on success, <0 on error.
*/
int tag_sort_context();

/**
  Return the index of the current context item.
  
  @return <0 on error, 0 if no current context.
*/
int tag_current_context();

/**
  Return the index of the nearest context item.
  
  @param linenum          line number to check context on

  @return <0 on error, 0 if no such context.
*/
int tag_nearest_context(int linenum, int filter_flags=VS_TAGFILTER_ANYTHING);

/**
  Find a the first context entry with the given tag prefix, or if
  'exact', with the exact tag name.  Use case-sensitive match if
  case_sensitive != 0.
  
  @param tag_prefix       tag name or prefix of tag name
  @param exact            search for exact match or prefix match
  @param case_sensitive   case sensitive string comparison?
  @param allow_anon       (optional) pass through anonymous classes
  @param class_name       (optional) class to find item in

  @return context ID of tag if found, <0 on error or not found.
*/
int tag_find_context(_str tag_prefix, boolean exact, boolean case_sensitive,
                     boolean pass_through_anonymous=false, _str search_class_name=null);

/**
  Find a the next context entry with the given tag prefix, or if
  'exact', with the exact tag name.  Use case-sensitive match if
  case_sensitive != 0.
  
  @param tag_prefix       tag name or prefix of tag name
  @param exact            search for exact match or prefix match
  @param case_sensitive   case sensitive string comparison?
  @param allow_anon       (optional) pass through anonymous classes
  @param class_name       (optional) class to find item in

  @return context ID of tag if found, <0 on error or not found.
*/
int tag_next_context(_str tag_prefix, boolean exact, boolean case_sensitive,
                     boolean pass_through_anonymous=false, _str search_class_name=null);

/**
  Insert all the context items into the given tree.
  
  @param treeWID          tree widget to load info into
  @param treeIndex        tree index to insert into
  @param include_tab      include tab when creating caption
  @param force_leaf       force item to be inserted as a leaf item
  @param tree_flags       tree flags to set for this item
  @param pushtag_flags    PUSHTAG_*, see slick.sh

  @return 0 on success, <0 on error.
*/
int tag_tree_insert_context(int treeWID, int treeIndex, int pushtag_flags,
                            int include_tab, int force_leaf, int tree_flags);

/**
  Insert all the tags from the current context into the currently
  open tag file.  Assumes that the context is up-to-date at the
  time that this function is called.
  Returns 
  
  @param file_name        typically p_buf_name, absolute path of buffer

  @return 0 on success, <0 on error.
*/
int tag_transfer_context(_str file_name);


///////////////////////////////////////////////////////////////////////////
// Local declarations related tracking functions
  
/**
  Add a local variable tag and its information to the locals list.
  
  @param tag_name         tag string
  @param tag_type         string specifying tag_type
  @param file_name        full path of file the tag is located in
  @param line_no          start line number of tag within file
  @param class_name       (optional) name of class that tag is present in,
                          use concatenation (as defined by language rules)
                          to specify names of inner classes.
  @param tag_flags        (optional) see VS_TAGFLAG_* above.
  @param signature        (optional) tag signature (return type, arguments, etc)

  @return sequence number (local_id) of local variable on success, or <0 on error.
*/
int tag_insert_local(_str tag_name,_str tag_type,_str file_name,int line_no,
                     _str class_name,int tag_flags,_str signature);

/**
  Add a local variable tag and its information to the locals list.
  
  @param tag_name         tag string
  @param tag_type         string specifying tag_type
  @param file_name        full path of file the tag is located in
  @param start_linenum    start line number of tag within file
  @param start_seekpos    start seek position of tag within file
  @param scope_linenum    start line number of start of tag inner scope
  @param scope_seekpos    start seek position of tag inner scope
  @param end_linenum      (optional) ending line number of tag within file
  @param end_seekpos      (optional) end seek position of tag within file
  @param class_name       (optional) name of class that tag is present in,
                          use concatenation (as defined by language rules)
                          to specify names of inner classes.
  @param tag_flags        (optional) see VS_TAGFLAG_* above.
  @param signature        (optional) tag signature (return type, arguments, etc)

  @return sequence number (local_id) of local variable on success, or <0 on error.
*/
int tag_insert_local2(_str tag_name,_str tag_type,_str file_name,
                      int line_no,int seekpos,int scope_line_no,int scope_seekpos,
                      int end_line_no,int end_seekpos,
                      _str class_name,int tag_flags,_str signature);

/**
  Sort the local variables in the current context by seek position.
  The precise sort order is first by non-descrasing starting
  seekpos, and for items with identical start seek positions,
  non-increasing end seek position, and for items with identical
  span, the original insertion order for the items.
  
  In addition to sorting the local variables, this function computes
  the outer contexts.
  
  @return 0 on success, <0 on error.
*/
int tag_sort_locals();

/**
  Return the index of the current local variable.
  
  @return <0 on error, 0 if no current local variable.
*/
int tag_current_local();

/**
  Set the class inheritance for the given local tag.
  
  @param context_id       id for the context to modify
  @param parents          parents of the context item

  @return 0 on success, <0 on error.
*/
int tag_set_local_parents(int local_id, _str parents);

/**
  Return the total number of local variables
  
  @return the number of local variables
*/
int tag_get_num_of_locals();

/**
  Kill all locals after 'local_id', not including 'local_id'
  
  @param local_id         id for the local variable to start removing at
                          Use '0' to remove all locals.

  @return 0 on success, <0 on error.
*/
int tag_clear_locals(int local_id);

/**
  Retrieve information about the given local variable or parameter.
  
  @param local_id         local ID to look up (from tag_insert_local)
  @param tag_name         (reference) tag string (native case)
  @param type_name        (reference) string specifying tag_type
                          (see above for list of standard type names).
  @param file_name        (reference) full path of file the tag is located in
  @param line_no          (reference) start line number of tag within file
  @param class_name       (reference) name of class that tag is present in,
  @param tag_flags        uses concatenation (as defined by language rules)
                          to specify names of inner classes (see insert, above).
                          set to empty string if not defined.
                          (reference) see VS_TAGFLAG_* above.
  @param signature        (reference) arguments or formal parameters
  @param return_type      (reference) constant value or return type
                          
  @return 0 on success.
*/
int tag_get_local(int local_id,_str &tag_name,_str &type_name,_str &file_name,
                  int &line_no,_str & class_name,int &tag_flags,
                  _str &signature,_str &return_type);

/**
  Retrieve complete information about the given local ID.
  
  @param context_id       local ID to look up (from tag_insert_local)
  @param tag_name         (reference) tag string (native case)
  @param type_name        (reference) string specifying tag_type
                          (see above for list of standard type names).
  @param file_name        (reference) full path of file the tag is located in
  @param start_linenum    (reference) start line number of tag within file
  @param start_seekpos    (reference) start seek position of tag within file
  @param scope_linenum    (reference)start line number of start of tag inner scope
  @param scope_seekpos    (reference) start seek position of tag inner scope
  @param end_linenum      (optional) ending line number of tag within file
  @param end_seekpos      (optional) end seek position of tag within file
  @param class_name       (reference) name of class that tag is present in,
                          uses concatenation (as defined by language rules)
                          to specify names of inner classes (see insert, above).
                          set to empty string if not defined.
  @param tag_flags        (reference) see VS_TAGFLAG_* above.
  @param signature        (reference) arguments or formal parameters
  @param return_type      (reference) constant value or return type

  @return 0 on success.
*/
int tag_get_local2(int context_id, _str &tag_name, _str &type_name,
                   _str &file_name, int &start_line_no, int &start_seekpos,
                   int &scope_line_no, int &scope_seekpos,
                   int &end_line_no, int &end_seekpos,
                   _str &class_name, int &tag_flags, _str &signature, _str &return_type);

/**
  Find a the first local tag with the given tag prefix, or if
  'exact', with the exact tag name.  Use case-sensitive match if
  case_sensitive != 0.
  
  @param tag_prefix       tag name or prefix of tag name
  @param exact            search for exact match or prefix match
  @param case_sensitive   case sensitive string comparison?
  @param allow_anon       (optional) pass through anonymous classes
  @param class_name       (optional) class to find item in

  @return local ID of tag if found, <0 on error or not found.
*/
int tag_find_local(_str tag_prefix, boolean exact, boolean case_sensitive,
                   boolean pass_through_anonymous=false, _str search_class_name=null);

/**
  Find a the next local tag with the given tag prefix, or if
  'exact', with the exact tag name.  Use case-sensitive match if
  case_sensitive != 0.
  
  @param tag_prefix       tag name or prefix of tag name
  @param exact            search for exact match or prefix match
  @param case_sensitive   case sensitive string comparison?
  @param allow_anon       (optional) pass through anonymous classes
  @param class_name       (optional) class to find item in

  @return local ID of tag if found, <0 on error or not found.
*/
int tag_next_local(_str tag_prefix, boolean exact, boolean case_sensitive,
                   boolean pass_through_anonymous=false, _str search_class_name=null);


///////////////////////////////////////////////////////////////////////////
// Search match tracking related functions
  
/**
  Add a search match tag and its information to the matches list.
  
  @param tag_file         (optional) full path of tag file match came from
  @param tag_name         tag string
  @param tag_type         string specifying tag_type
  @param file_name        full path of file the tag is located in
  @param line_no          start line number of tag within file
  @param class_name       (optional) name of class that tag is present in,
                          use concatenation (as defined by language rules)
                          to specify names of inner classes.
  @param tag_flags        (optional) see VS_TAGFLAG_* above.
  @param signature        (optional) tag signature (return type, arguments, etc)

  @return sequence number (match_id) of matching tag on success, or <0 on error.
*/
int tag_insert_match(_str tag_file, _str tag_name, _str tag_type, 
                     _str file_name, int line_no, _str class_name,
                     int tag_flags, _str signature);

/**
  Add a search match tag and its information to the matches list.
  
  @param tag_file         (optional) full path of tag file match came from
  @param tag_name         tag string
  @param tag_type         string specifying tag_type
  @param file_name        full path of file the tag is located in
  @param start_linenum    start line number of tag within file
  @param start_seekpos    start seek position of tag within file
  @param scope_linenum    start line number of start of tag inner scope
  @param scope_seekpos    start seek position of tag inner scope
  @param end_linenum      (optional) ending line number of tag within file
  @param end_seekpos      (optional) end seek position of tag within file
  @param class_name       (optional) name of class that tag is present in,
                          use concatenation (as defined by language rules)
                          to specify names of inner classes.
  @param tag_flags         (optional) see VS_TAGFLAG_* above.
  @param signature         (optional) tag signature (return type, arguments, etc)

  @return sequence number (match_id) of matching tag on success, or <0 on error.
*/
int tag_insert_match2(_str tag_file, _str tag_name,_str tag_type,
                      _str file_name,int line_no,int seekpos,
                      int scope_line_no,int scope_seekpos,
                      int end_line_no,int end_seekpos,
                      _str class_name,int tag_flags,_str signature);

/**
  Speedy version of tag_insert_match that simply clones a context,
  local, or current tag match
  
  @param match_type       match type, VS_TAGMATCH_*, local, context, tag
  @param local_or_ctx_id  ID of local variable or tag in current context

  @return sequence number (match_id) of matching tag on success, or <0 on error.
*/
int tag_insert_match_fast(int match_type, int local_or_context_id);

/**
  Return the total number of search matches
  
  @return the total number of matches
*/
int tag_get_num_of_matches();

/**
  Kill all search matches.
  
  @return 0 on success, <0 on error.
*/
int tag_clear_matches();

/**
  Push the current match set onto the stack of match sets and
  initialize the new stack top to an empty match set
  
  @return 0 on success, <0 on error.
*/
int tag_push_matches();

/**
  Clear the current match set and pop it off of the stack.
*/
void tag_pop_matches();

/**
  Push the current match set onto the stack of match sets and
  transfer the context set to the top of the match set stack.
  
  @return 0 on success, <0 on error.
*/
int tag_push_context();

/**
  Transfers the current match set to the context set and
  pop it off of the match set stack.
*/
void tag_pop_context();

/**
  Retrieve information about the given search match.
  
  @param match_id         match ID to look up (from tag_insert_match)
  @param tag_file         (reference) tag file that match came from
  @param tag_name         (reference) tag string (native case)
  @param type_name        (reference) string specifying tag_type
                          (see above for list of standard type names).
  @param file_name        (reference) full path of file the tag is located in
  @param line_no          (reference) start line number of tag within file
  @param class_name       (reference) name of class that tag is present in,
                          uses concatenation (as defined by language rules)
                          to specify names of inner classes (see insert, above).
                          set to empty string if not defined.
  @param tag_flags        (reference) see VS_TAGFLAG_* above.
  @param signature        (reference) arguments or formal parameters
  @param return_type      (reference) constant value or return type

  @return 0 on success, <0 on error.
*/
int tag_get_match(int match_id, _str &tag_file, _str &tag_name, _str &type_name,
                  _str &file_name, int &line_no, _str &class_name, int &tag_flags,
                  _str &signature, _str &return_type);


/**
  Get the given detail type for the given item either as a
  context tag, local tag, or part of a match set.
  
  @param detail_id        VS_TAGDETAIL_* (see tagsdb.h)
  @param item_id          context_id, local_id, or match_id
  @param result           (reference) value of detail is returned here

  @return 0 on success, <0 on error.
*/
void tag_get_detail2(int detail_id, int item_id, var result);


///////////////////////////////////////////////////////////////////////////
// Utility functions for implementing context tagging functions,
// optimized version of former components of context.e
  
/**
  Returns true if at the current access level, we have access to the member
  with the given flags at our access level.
  
  @param context_flags    VS_TAGCONTEXT_*
  @param tag_flags        VS_TAGFLAG_* (from tag details)

  @return 1 if we have access to the tag, 0 if not
*/
int tag_check_access_level(int context_flags, int tag_flags);

/**
  Returns true if the tag having the given tag_flags and type matches the
  requirements set by the given context flags.
  
  @param context_flags    VS_TAGCONTEXT_*
  @param tag_flags        VS_TAGFLAG_* (from tag details)
  @param type_name        tag type (from tag details)

  @return Returns 1 if the tag with the given type and flags passes
          the context flags, otherwise, returns 0.
*/
int tag_check_context_flags(int context_flags, int tag_flags, _str type_name);

/**
  Decompose a class name into its outer component and
  inner class name only.  This is strictly a string function,
  no file I/O or searching is involved.
  
  @param class_name       class name to decompose
  @param inner_name       (reference) 'inner' class name (class name only)
  @param outer_name       (reference) 'outer' class name (class_name - inner_name)
*/
void tag_split_class_name(_str class_name, var inner_name, var outer_name);

/**
  Determine whether the class name and outer class name should be
  joined using a package seperator or class seperator and return
  the resulting string.  This involves searching for the outer
  class name as a package, if found, then use package string.
  The current object must be an editor control or current buffer.
  
  @param class_name       name of class to join (inner_class)
  @param outer_class      name of outer class or package to join
  @param tag_files        (reference, read-only array of strings)
                          list of tag files to search
  @param case_sensitive   1/0 for case-sensitive or case-insensitve search
  @param allow_anonymous (optional, default false) allow anonymous classes?

  @return Returns static string if outer_class :: class_name was found in
          the context or tag database, otherwise returns '';
*/
_str tag_join_class_name(_str class_name, _str outer_class, var tag_files,
                         boolean case_sensitive,.../*boolean allow_anonymous=false*/);

/**
  Determine if 'parent_class' is a parent of 'child_class', that is, does
  'child_class' derive either directly or transitively from 'parent_class'?
  
  @param parent_class     class to check if it is a parent (base class)
  @param child_class      class to check if it is derived from parent
  @param tag_files        (reference to _str[]) tag files to search
  @param case_sensitive   case sensitive (1) or case insensitive (0)
  @param normalize        attempt to normalize class name or take as-is?

  @return 1 if 'child_class' derives from 'search_class', otherwise 0.
*/
int tag_is_parent_class(_str parent_class, _str child_class,
                        var tag_files, boolean case_sensitive, boolean normalize);

/**
  Lookup 'symbol' and see if it could be a typedef symbol.  If so,
  return 1, otherwise return 0.
  
  This function ignores class scope.  Simply put, if 'symbol' is a typedef,
  anywhere, this function may return true.  Thus, it's should really be used
  only as an arbiter prior to attempting to match 'symbol' in context as a
  typedef.  The reason that this function behaves in this was is for speed
  and simplicity.  Otherwise, it would have to search all parent and outer
  class scopes, in addition to locals, context and tag files.
  
  @param symbol           symbol to investigate
  @param tag_files        (reference to _str[]) tag files to search
  @param case_sensitive   use case-sensitive comparisons?
  @param namespace_name   (optional) namespace or class to search

  @return 1 if 'symbol' could be a typedef, 0 otherwise, <0 on error.
*/
int tag_check_for_typedef(_str symbol, var tag_files, 
                          boolean case_sensitive, ... /* _str namesapce_name*/);

/**
  Look up 'symbol' and see if it is a simple preprocessing symbol.
  If so, return the value of symbol in alt_symbol.
  
  @param symbol           current symbol to look for
  @param line_no          if found in current context, define must be before 'line'
  @param tag_files        (reference to _str[]) list of tag files to search
  @param alt_symbol       (reference) returns value of #define

  @return the number of matches found, 0 if none found, <0 on error.
*/
int tag_check_for_define(_str symbol, int line_no, var tag_files, var alt_symbol);

/**
  Look up 'symbol' and see if it is a template class.
  If so, return the signature of the template in template_sig.
  The current object must be an editor control or current buffer.
  
  @param symbol           current symbol to look for
  @param outer_class      class that 'symbol' must be in
  @param case_sensitive   case_sensitive symbol comparison?
  @param tag_files        (reference to _str[]) tag files to search
  @param template_sig     (reference) returns signature of template_sig

  @return 1 if a match was found and sets template_sig, 0 of none found.
*/
int tag_check_for_template(_str symbol, _str outer_class,
                           boolean case_sensitive, var tag_files, var template_sig);

/**
  Look up 'symbol' and see if it is a package, namespace, module or unit.
                       
  @param symbol           current symbol to look for
  @param tag_files        (reference to _str[]) list of tag files to search
  @param exact_match      look for exact match rather than prefix match
  @param case_sensitive   case sensitive comparison?

  @return 1 if 'symbol' or prefix of matches package, otherwise returns 0.
*/
int tag_check_for_package(_str symbol, var tag_files,
                          boolean exact_match, boolean case_sensitive);

/**
  Check if the given class is in the same package as the other class.
  
  @param class1           first class name, qualified
  @param class2           second class name, qualified
  @param case_sensitive   case sensitive comparison for package names?

  @return true of so, false otherwise.
*/
int tag_is_same_package(_str class1, _str class2, boolean case_sensitive);

/**
  List the global symbols of the given type
  
  @param treewid          window id of tree control to insert into,
                          0 indicates to insert into a match set
  @param tree_index       tree index to insert matches under
  @param tag_files        (reference to _str[]) tag files to search
  @param type_id          first type id (see VS_TAGTYPE_*, above)
                          if (type_id<0), returns tags with ID>VS_TAGTYPE_LASTID
  @param mask             flag mask (see VS_TAGFLAG_*, above)
  @param nonzero          if 1, succeed if mask & tag.flags != 0
                          if 0, succeed if mask & tag.flags == 0
  @param vnum_matches     (reference) number of matches
  @param max_matches      maximum number of matches allowed
  
  @return nothing
*/
void tag_list_globals_of_type(int treewid, int tree_index, var tag_files,
                              int type_id, int mask, int nonzero,
                              var vnum_matches, int max_matches);

/**
  List the packages matching the given prefix expression.
                     
  @param treewid          window id of tree control to insert into,
                          0 indicates to insert into a match set
  @param tree_index       tree index to insert matches under
  @param prefix           symbol prefix to match
  @param tag_files        (reference to _str[]) tag files to search
  @param vnum_matches     (reference) number of matches
  @param max_matches      maximum number of matches allowed
  @param exact_match      exact match or prefix match (0)
  @param case_sensitive   case sensitive (1) or case insensitive (0)

  @return nothing
*/
void tag_list_context_packages(int treewid, int tree_index,
                               _str prefix, var tag_files,
                               var vnum_matches, int max_matches,
                               boolean exact_match, boolean case_sensitive);

/**
  List any symbols, reguardless of context or scope (excluding locals)
  matching the given prefix expression.
  
  @param treewid          window id of tree control to insert into,
                          0 indicates to insert into a match set
  @param tree_index       tree index to insert matches under
  @param prefix           symbol prefix to match
  @param tag_files        (reference to _str[]) tag files to search
  @param pushtag_flags    VS_TAGFILTER_*, tag filter flags
  @param context_flags    VS_TAGCONTEXT_*, tag context filter flags
  @param vnum_matches     (reference) number of matches
  @param max_matches      maximum number of matches allowed
  @param exact_match      exact match or prefix match (0)
  @param case_sensitive   case sensitive (1) or case insensitive (0)

  @return nothing.
*/
void tag_list_any_symbols(int treewid,int tree_index, _str prefix,
                          var tag_files, int pushtag_flags,int context_flags,
                          var vnum_matches,int max_matches,
                          boolean exact_match,boolean case_sensitive);

/**
  List the symbols found in files having the given 'base' filename
  and passing the given pushtag and context flags.
  
  @param treewid          window id of tree control to insert into,
                          0 indicates to insert into a match set
  @param tree_index       tree index to insert matches under
  @param prefix           symbol prefix to match
  @param tag_files        (reference to _str[]) tag files to search
  @param search_file_name (optional) file name to search for tags in
  @param pushtag_flags    VS_TAGFILTER_*, tag filter flags
  @param context_flags    VS_TAGCONTEXT_*, tag context filter flags
  @param vnum_matches     (reference) number of matches
  @param max_matches      maximum number of matches allowed
  @param exact_match      exact match or prefix match (0)
  @param case_sensitive   case sensitive (1) or case insensitive (0)

  @return nothing.
*/
void tag_list_in_file(int treewid,int tree_index,_str prefix,var tag_files,
                      _str search_file_name,int pushtag_flags,int context_flags,
                      var vnum_matches,int max_matches,
                      boolean exact_match,boolean case_sensitive);

/**
  List the global symbols visible in the given list of tag files
  matching the given tag filters and context flags.
  
  @param treewid          window id of tree control to insert into,
                          0 indicates to insert into a match set
  @param tree_index       tree index to insert matches under
  @param prefix           symbol prefix to match
  @param check_context    check for symbols in the current context?
  @param tag_files        (reference to _str[]) tag files to search
  @param pushtag_flags    VS_TAGFILTER_*, tag filter flags
  @param context_flags    VS_TAGCONTEXT_*, tag context filter flags
  @param vnum_matches     (reference) number of matches
  @param max_matches      maximum number of matches allowed
  @param exact_match      exact match or prefix match (0)
  @param case_sensitive   case sensitive (1) or case insensitive (0)

  @return nothing.
*/
void tag_list_context_globals(int treewid, int tree_index, _str prefix,
                              boolean check_context, var tag_files,
                              int pushtag_flags, int context_flags,
                              var vnum_matches, int max_matches,
                              boolean exact_match, boolean case_sensitive);

/**
  List the symbols imported into this context
  matching the given tag filters and context flags.
  
  @param treewid          window id of tree control to insert into,
                          0 indicates to insert into a match set
  @param tree_index       tree index to insert matches under
  @param prefix           symbol prefix to match
  @param tag_files        (reference to _str[]) tag files to search
  @param pushtag_flags    VS_TAGFILTER_*, tag filter flags
  @param context_flags    VS_TAGCONTEXT_*, tag context filter flags
  @param vnum_matches     (reference) number of matches
  @param max_matches      maximum number of matches allowed
  @param exact_match      exact match or prefix match (0)
  @param case_sensitive   case sensitive (1) or case insensitive (0)

  @return the number of import statements in the current context.
*/
void tag_list_context_imports(int treewid, int tree_index, _str prefix,
                              var tag_files,int pushtag_flags, int context_flags,
                              var vnum_matches, int max_matches,
                              boolean exact_match, boolean case_sensitive);

/**
  Attempt to locate the given symbol in the given class by searching
  local variables.  Recursively looks for symbols in enumerated
  types and anonymous unions (designated by having *both* the anonymous
  and 'maybe_var' tag flags).
  
  Look at num_matches to see if any matches were found.  Generally
  if (num_matches >= max_matches) there may be more matches, but
  the search terminated early.
  
  @param treewid          window id of tree control to insert into,
                          0 indicates to insert into a match set
  @param tree_index       tree index to insert matches under
  @param tag_files        symbol prefix to match
  @param prefix           name of class to search for matches
  @param search_class     (reference to _str[]) tag files to search
  @param pushtag_flags    VS_TAGFILTER_*, tag filter flags
  @param context_flags    VS_TAGCONTEXT_*, tag context filter flags
  @param vnum_matches     (reference) number of matches
  @param max_matches      maximum number of matches allowed
  @param exact_match      exact match or prefix match (0)
  @param case_sensitive   case sensitive (1) or case insensitive (0)

  @return 1 if the definition of the given class 'search_class_name' is found,
          othewise returns 0, indicating that no matches were found.
*/
int tag_list_class_locals(int treewid, int tree_index, var tag_files,
                          _str prefix, _str search_class,
                          int pushtag_flags, int context_flags,
                          var vnum_matches, int max_matches,
                          boolean exact_match, boolean case_sensitive);

/**
  Attempt to locate the given symbol in the given class by searching
  the current context.  Recursively looks for symbols in enumerated
  types and anonymous unions (designated by having *both* the anonymous
  and 'maybe_var' tag flags).
                      
  Look at num_matches to see if any matches were found.  Generally
  if (num_matches >= max_matches) there may be more matches, but
  the search terminated early.  
                      
  @param treewid          window id of tree control to insert into,
                          0 indicates to insert into a match set
  @param tree_index       tree index to insert matches under
  @param tag_files        symbol prefix to match
  @param prefix           name of class to search for matches
  @param search_class     (reference to _str[]) tag files to search
  @param pushtag_flags    VS_TAGFILTER_*, tag filter flags
  @param context_flags    VS_TAGCONTEXT_*, tag context filter flags
  @param vnum_matches     (reference) number of matches
  @param max_matches      maximum number of matches allowed
  @param exact_match      exact match or prefix match (0)
  @param case_sensitive   case sensitive (1) or case insensitive (0)

  @return 1 if the definition of the given class 'search_class_name' is found,
          othewise returns 0, indicating that no matches were found.
*/
int tag_list_class_context(int treewid, int tree_index, var tag_files,
                           _str prefix, _str search_class,
                           int pushtag_flags, int context_flags,
                           var vnum_matches, int max_matches,
                           boolean exact_match, boolean case_sensitive);

/**
  Attempt to locate the given symbol in the given class by searching
  the given tag files.  Recursively looks for symbols in enumerated
  types and anonymous unions (designated by having *both* the anonymous
  and 'maybe_var' tag flags).
                      
  Look at num_matches to see if any matches were found.  Generally
  if (num_matches >= max_matches) there may be more matches, but
  the search terminated early. 
  
  @param treewid          window id of tree control to insert into,
                          0 indicates to insert into a match set
  @param tree_index       tree index to insert matches under
  @param tag_files        symbol prefix to match
  @param prefix           name of class to search for matches
  @param search_class     (reference to _str[]) tag files to search
  @param pushtag_flags    VS_TAGFILTER_*, tag filter flags
  @param context_flags    VS_TAGCONTEXT_*, tag context filter flags
  @param vnum_matches     (reference) number of matches
  @param max_matches      maximum number of matches allowed
  @param exact_match      exact match or prefix match (0)
  @param case_sensitive   case sensitive (1) or case insensitive (0)

  @return 1 if the definition of the given class 'search_class_name' is found,
          othewise returns 0, indicating that no matches were found.
*/
int tag_list_class_tags(int treewid, int tree_index, var tag_files,
                        _str prefix, _str search_class,
                        int pushtag_flags, int context_flags,
                        var vnum_matches, int max_matches,
                        boolean exact_match, boolean case_sensitive);


///////////////////////////////////////////////////////////////////////////
// Word index (references) table maintenance functions.
//

/**
  Set up for inserting a series of occurrences from a single file
  for update.  Doing this allows the tag database engine to detect
  and handle updates more effeciently, even in the presence of
  duplicates.
  
  @param file_name        full path of file the tags are located in

  @return 0 on success, <0 on error.
*/
int tag_occurrences_start(_str file_name);

/**
  Clean up after inserting a series of occurrences from a single
  file for update.  Doing this allows the tag database engine to
  remove any occurrences from the database that are no longer valid.
  
  @return 0 on success, <0 on error.int VSAPI
*/
int tag_occurrences_end();

/**
  Insert a new occurrence into the word index.
  
  @param occur_name      Word to be indexed
  @param file_name       Path of file occurrence is located in

  @return 0 on success, <0 on error.
*/
int tag_insert_occurrence(_str occur_name, _str file_name);

/**
  Find the first occurrence with the given tag name or tag prefix.
  Use tag_get_occurrence (below) to get details about the occurrence.
             
  @param tag_name        Tag name or prefix to search for
  @param exact_match     Exact (word) match or prefix match (0)
  @param case_sensitive  Case sensitive search?

  @return 0 on success, BT_RECORD_NOT_FOUND_RC if not found, <0 on error.
*/
int tag_find_occurrence(_str tag_name,
                        boolean exact_match=true,
                        boolean case_sensitive=false);

/**
  Find the next occurrence with the given tag name or tag prefix.
  Use tag_get_occurrence (below) to get details about the occurrence.
             
  @param tag_name        Tag name or prefix to search for
  @param exact_match     Exact (word) match or prefix match (0)
  @param case_sensitive  Case sensitive search?

  @return 0 on success, BT_RECORD_NOT_FOUND_RC if not found, <0 on error.
*/
int tag_next_occurrence(_str tag_name,
                        boolean exact_match=true,
                        boolean case_sensitive=false);

/**
  Retrieve information about the current occurrence, as defined by
  tag_find_occurrence/tag_next_occurrence.
  
  @param occur_name      (output) Word to be indexed
  @param file_name       (output) Path of file occurrence is located in

  @return nothing.
*/
void tag_get_occurrence(_str &occur_name, _str &file_name);

/**
  Default function for matching occurrences and inserting them into
  the database.  Simply searches for words that are not in comments,
  strings, numbers, keywords, line numbers, or preprocessing, using
  the color coding engine.
  
  @param file_name        Name of buffer to search for occurrences in
  @param tag_name         Name of identifier to search for, null of anything
  @param case_sensitive   Case sensitive identifier search?
  @param start_seekpos    Seek position to start searching at, 0 means TOP
  @param stop_seekpos     Seek position to end searching at, 0 means EOF

  @return 0 on success, <0 on error.
*/
int tag_list_occurrences(_str file_name, _str tag_name=null,
                         boolean case_sensitive=true,
                         int start_seekpos=0, int stop_seekpos=0);

/**
  The current object must be an editor control positioned on
  the tag that you wish to find matches for, with the edit
  mode selected.
  
  @param errorArgs       Array of strings for return code
  @param tag_name        Name of occurrence to match against
  @param exact_match     Exact match or prefix match?
  @param case_sensitive  Case sensitive tag search?
  @param find_parents    Find instances of this tag in parent classes
  @param num_matches     (output) number of matches found
  @param max_matches     maximum number of matches to find

  @return 0 on success, <0 on error, >0 on context tagging error.
*/
int tag_context_match_tags(var errorArgs, _str &tag_name, boolean exact_match,
                           boolean case_sensitive, boolean find_parents, 
                           int &num_matches, int max_matches);

/**
 * Match occurrences of the given tag name in the current buffer,
 * starting at the specified start seek position and continuing
 * until the specified stop seek position.
 * 
 * @param errorArgs       (reference) error message parameters
 * @param tree_wid        window ID of tree control to insert into
 * @param tree_index      index of item in tree to insert under
 * @param tag_name        name of tag to search for
 * @param case_sensitive  case sensitive search?
 * @param file_name       path of file match tag is in
 * @param line_no         real line number match tag is located on
 * @param filter_flags    item filter flags
 * @param start_seekpos   starting seekpos, 0 means beginning of file
 * @param stop_seekpos    ending seekpos, 0 means EOF
 * @param num_matches     (reference) number of occurrence matches found
 * @param max_matches     maximum number of occurrences to find
 *
 * @return 0 on success, <0 on error, >0 on context tagging error.
 */
int tag_match_occurrences_in_file(var errorArgs,
                                  int tree_wid, int tree_index,
                                  _str tag_name, boolean case_sensitive,
                                  _str file_name, int line_no,
                                  int filter_flags,
                                  int start_seekpos/*=0*/, int stop_seekpos/*=0*/,
                                  int &num_matches, int max_matches);

/**
 * Match occurrences of the given tag name in the current buffer,
 * starting at the specified start seek position and continuing
 * until the specified stop seek position.
 * 
 * @param errorArgs       (reference) error message parameters
 * @param tree_wid        window ID of tree control to insert into
 * @param tree_index      index of item in tree to insert under
 * @param tag_name        name of tag to search for
 * @param case_sensitive  case sensitive search?
 * @param file_name       path of file match tag is in
 * @param line_no         real line number match tag is located on
 * @param alt_file_name   alternate path of file match tag is in
 * @param alt_line_no     alternate real line number match tag is located on
 * @param filter_flags    item filter flags
 * @param caller_id       context ID of item to look for uses in
 * @param start_seekpos   starting seekpos, 0 means beginning of file
 * @param stop_seekpos    ending seekpos, 0 means EOF
 * @param num_matches     (reference) number of occurrence matches found
 * @param max_matches     maximum number of occurrences to find
 *
 * @return 0 on success, <0 on error, >0 on context tagging error.
 */
int
tag_match_uses_in_file(var errorArgs,
                       int tree_wid, int tree_index,
                       boolean case_sensitive,
                       _str file_name, int line_no,
                       _str alt_file_name, int alt_line_no,
                       int filter_flags, int caller_id,
                       int start_seekpos, int stop_seekpos,
                       int &num_matches, int max_matches);

/**
 * List the files containing 'tag_name', matching by prefix or
 * case-sensitive, as specified.  Terminates search if a total
 * of max_refs are hit.  Items are inserted into the tree, with
 * the user data set to the file path.
 * 
 * @param tree_wid        window id of tree control to insert into
 * @param tree_index      index, usually TREE_ROOT_INDEX to insert under
 * @param tag_name        name of tag to search for
 * @param exact_match     exact match or prefix match
 * @param case_sensitive  case sensitive match, or case-insensitive
 * @param num_refs        (reference) number of references found so far
 * @param max_refs        maximum number of items to insert
 * 
 * @return 0 on success, <0 on error.
 */
int
tag_list_file_occurrences(int tree_wid, int tree_index,
                          _str tag_name, int exact_match,
                          int case_sensitive,
                          int &num_refs, int max_refs);

/**
 * For each item in 'class_parents', normalize the class and place it in
 * 'normal_parents', along with the tag type, placed in 'normal_types'.
 * 
 * @param class_parents   list of class names, seperated by semicolons
 * @param cur_class_name  class context in which to normalize class name
 * @param file_name       source file where reference to class name is
 * @param tag_files       list of tag files to search
 * @param allow_locals    allow local classes in list
 * @param case_sensitive  case sensitive tag search?
 * @param normal_parents  (output) list of normalized class names
 * @param normal_types    (output) list of tag types found for normalized class names
 * 
 * @return 0 on success, <0 on error.
 */
int tag_normalize_classes(_str class_parents,
                          _str cur_class_name, _str file_name, var tag_files,
                          boolean allow_locals, boolean case_sensitive,
                          _str &normal_parents, _str &normal_types);

/**
 * Attempt to locate the given symbol in the given class by searching
 * first locals, then the current file, then tag files, looking strictly
 * for the class definition, not just class members.  Recursively
 * looks for symbols in inherited classes and resolves items in
 * enumerated types to the correct class scope (since enums do not form
 * a namespace).  The order of searching parent classes is depth-first,
 * preorder (root node searched before children).
 * 
 * Look at num_matches to see if any matches were found.  Generally
 * if (num_matches >= max_matches) there may be more matches, but
 * the search terminated early.  Returns 1 if the definition of the given
 * class 'search_class' is found, othewise returns 0, indicating
 * that no matches were found.
 * 
 * The current object must be an editor control or the current buffer.
 * 
 * @param prefix          symbol prefix to match
 * @param search_class    name of class to search for matches
 * @param treewid         window id of tree control to insert into,
 *                        0 indicates to insert into a match set
 * @param tree_index      tree index to insert items under, ignored
 *                        if (treewid == 0)
 * @param tag_files       (reference to _str[]) tag files to search
 * @param pushtag_flags   VS_TAGFILTER_*, tag filter flags
 * @param context_flags   VS_TAGCONTEXT_*, tag context filter flags
 * @param num_matches     (reference) number of matches
 * @param max_matches     maximum number of matches allowed
 * @param exact_match     exact match or prefix match (0)
 * @param case_sensitive  case sensitive (1) or case insensitive (0)
 * 
 * @return 1 if the definition of the symbol is found, 0 otherwise, <0 on error.
 */
int tag_list_in_class(_str prefix, _str search_class,
                      int treewid, int tree_index, var tag_files,
                      int &num_matches, int max_matches,
                      int pushtag_flags, int context_flags,
                      boolean exact_match, boolean case_sensitive);

/**
 * Qualify the given class symbol by searching for symbols with
 * its name in the current context/scope.  This is used to resolve
 * partial class names, often found in class inheritance specifications.
 * The current object must be an editor control or current buffer.
 * 
 * @param qualified_name  (output) "qualified" symbol name
 * @param qualified_max   number of bytes allocated to qualified_name
 * @param search_name     name of symbol to search for
 * @param context_class   current class context (class name)
 * @param context_file    current file name
 * @param tag_files       list of tag files to search
 * @param case_sensitive  case sensitive tag search?
 * 
 * @return qualified name if successful, 'search_name' on error.
 */
int tag_qualify_symbol_name(_str &qualified_name,
                            _str search_name, _str context_class,
                            _str context_file, var tag_files,
                            boolean case_sensitive);

/**
 * Determine the name of the current class or package context.
 * The current object needs to be an editor control.
 * 
 * @param cur_tag_name    name of the current tag in context
 * @param cur_flags       bitset of VS_TAGFLAG_* for the current tag
 * @param cur_type_name   type (VS_TAGTYPE_*) of the current tag
 * @param cur_type_id     type ID (VS_TAGTYPE_*) of the current tag
 * @param cur_context     class name representing current context
 * @param cur_class       cur_context minus the package name
 * @param cur_package     only package name for the current context
 * 
 * @return 0 if no context, context ID >0 on success, <0 on error.
 */
int tag_get_current_context(_str &cur_tag_name,  int &cur_flags,
                            _str &cur_type_name, int &cur_type_id,
                            _str &cur_context,   _str &cur_class,
                            _str &cur_package);

/**
 * Match the given symbol based on the current context information.
 * Order of searching is:
 * <OL>
 * <LI> local variables in current function
 * <LI> members of current class, including inherited members
 * <LI> globals found in the current file
 * <LI> globals imported explicitely from current file
 * <LI> globals, (not static variables), found in other files
 * <LI> any symbol found in this file
 * <LI> any symbol found in any tag file
 * </OL>
 * Failing that, it repeats steps (1-6) with pushtag_flags set to -1,
 * thus disabling any filtering, unless 'strict' is true.
 * The current object must be an editor control or current buffer.
 * 
 * @param prefix          symbol prefix to match
 * @param search_class    name of class to search for matches
 * @param treewid         window id of tree control to insert into,
 *                        0 indicates to insert into a match set
 * @param tree_index      tree index to insert items under, ignored
 *                        if (treewid == 0)
 * @param tag_files       (reference to _str[]) tag files to search
 * @param num_matches     (reference) number of matches
 * @param max_matches     maximum number of matches allowed
 * @param pushtag_flags   VS_TAGFILTER_*, tag filter flags
 * @param context_flags   VS_TAGCONTEXT_*, tag context filter flags
 * @param exact_match     exact match or prefix match (0)
 * @param case_sensitive  case sensitive (1) or case insensitive (0)
 * @param strict          strict match, or allow any match?
 * @param find_parents    find parents of the given class?
 * @param find_all        find all instances, for each level of scope
 * 
 * @return 0 on success, <0 on error.
 */
int tag_match_symbol_in_context(_str prefix, _str search_class,
                                int treewid, int tree_index, var tag_files,
                                int &num_matches,int max_matches,
                                int pushtag_flags, int context_flags,
                                boolean exact_match, boolean case_sensitive,
                                boolean strict, boolean find_parents, boolean find_all);


/**
 * Match symbols in all tag files against the given member and class filters.
 * 
 * @param tree_wid        Window ID of the tree control
 * @param tree_index      Tree index to insert items under
 * @param progress_wid    Window id of progress label
 * @param member_filter   Prefix or regular expression for symbols
 * @param class_filter    Regex or prefix for class names
 * @param tag_files       list of tag files to search
 * @param filter_flags    Symbol filter flags (VS_TAGFILTER_*)
 * @param num_matches     (reference) number of matches found
 * @param max_matches     maximum number of matches to find
 * @param regex_match     perform regular expression match?
 * @param exact_match     exact match or prefix match?
 * @param case_sensitive  Case sensitive match or case-insensitive?
 *
 * @return Returns 0 on success, 1 if list was truncated,
 *         <0 on error.
 * @see tag_match
 * @since 5.0a
 */
int tag_pushtag_match(int tree_wid, int tree_index, int progress_wid,
                      _str member_filter, _str class_filter,
                      var tag_files, int filter_flags/*=VS_TAGFILTER_ANYTHING*/,
                      int &num_matches, int max_matches,
                      boolean regex_match/*=false*/, boolean exact_match/*=false*/,
                      boolean case_sensitive/*=false*/);


/**
 * Find all tags in the given tag databases matching
 * the given tag name, and possibly class or type
 * specification.  Places matches in taglist and
 * filelist, which are parallel arrays.
 * 
 * @param taglist         List of tag information, composed
 * @param filelist        List of corresponding filenames
 * @param proc_name       Composed tag name to search for
 * @param tag_files       List of tag files to search
 * 
 * @return 0 on succes, <0 on error.
 */
int tag_list_duplicate_tags(_str (&taglist)[], _str (&filelist)[],
                            _str proc_name, var tag_files);


#endif
