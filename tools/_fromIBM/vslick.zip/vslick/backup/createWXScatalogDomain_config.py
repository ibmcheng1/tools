###########################################################################################################################################
###   Signer Certification ###

wxsCatalogDomainName = "commDomain"

#wxsCatalog1 = "cdqlbap001"
#wxsCatalog2 = "cdqlbap002"
#wxsCatalog3 = "cdqlbap003"
wxsCatalog1 = "oc8721587607.ibm.com"
wxsCatalog2 = "oc8721587607.ibm.com"
wxsCatalog3 = "oc8721587607.ibm.com"
wxsCatalog1Port = "2809"
wxsCatalog2Port = "2810"
wxsCatalog3Port = "2811"
