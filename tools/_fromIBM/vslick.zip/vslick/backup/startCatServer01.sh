#!/bin/sh
fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

CATALOG_SERVER_NAME=${CATALOG_SERVER_NAME_PREFIX}0

APP_LOG_PATH=${WORKING_DIR}/logs/${CATALOG_SERVER_NAME}

if [[ ! -e ${WORKING_DIR}/logs ]]; then
    mkdir ${WORKING_DIR}/logs
    chmod 777 ${WORKING_DIR}/logs
fi

if [[ ! -e $APP_LOG_PATH ]]; then
    mkdir $APP_LOG_PATH
    chmod 777 ${APP_LOG_PATH}
fi


${OBJECTGRID_ROOT}/bin/startXsServer.sh ${CATALOG_SERVER_NAME} -domain $CATALOG_SERVICE_DOMAIN_NAME  -serverProps ${WORKING_DIR}/properties/objectGridServer.properties -jmxServicePort 1099 -listenerHost $CURRENT_HOST -listenerPort $CATALOGSERVER_LISTENER_PORT -jvmArgs -Xms256m -Xmx512m

