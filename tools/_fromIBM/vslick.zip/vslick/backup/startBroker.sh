#!/bin/sh

. /home/virtuser/.mqsiprofile

BROKER=$1

#Enable FP capabilities
mqsichangebroker "$BROKER" -f all

echo "starting ${BROKER} ..."
mqsistart "$BROKER"
