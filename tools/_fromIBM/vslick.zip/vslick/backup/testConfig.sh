#!/bin/ksh
echo ======================================
echo running testConfig.sh
echo ======================================

echo ----------------------------------------
echo Step 5-1: update ${INSTANCE_HOME}/idsslapd-ldapdb2/etc/ibmslapd.conf
echo ----------------------------------------
INSTANCE_NAME=ldapdb2
INSTANCE_HOME=/home/${INSTANCE_NAME}

LDAP_CONF_FILE=${INSTANCE_HOME}/idsslapd-ldapdb2/etc/ibmslapd.conf
if [ ! -f ${LDAP_CONF_FILE}.ori ]; then
  su - ${INSTANCE_NAME} -c "cp ${LDAP_CONF_FILE} ${LDAP_CONF_FILE}.ori"
fi

# replace "ibm-slapdPwEncryption: aes256" with "ibm-slapdPwEncryption: ssha256"
LDAP_OLD_String="ibm-slapdPwEncryption: aes256"
LDAP_NEW_String="ibm-slapdPwEncryption: ssha256"
sed -e "s|${LDAP_OLD_String}|${LDAP_NEW_String}|g" ${LDAP_CONF_FILE} > ${LDAP_CONF_FILE}.temp

# enable SSL
LDAP_OLD_String="ibm-slapdSecurity: none"
LDAP_NEW_String="ibm-slapdSecurity: SSL"
sed -e "s|${LDAP_OLD_String}|${LDAP_NEW_String}|g" ${LDAP_CONF_FILE} > ${LDAP_CONF_FILE}.temp

LDAP_OLD_String="ibm-slapdSslCertificate: none"
LDAP_NEW_String="ibm-slapdSslCertificate: LDAP_Cert"
sed -e "s|${LDAP_OLD_String}|${LDAP_NEW_String}|g" ${LDAP_CONF_FILE} > ${LDAP_CONF_FILE}.temp

LDAP_KEY_PATH=${INSTANCE_HOME}/idsslapd-ldapdb2/etc/ldap_key.kdb
LDAP_OLD_String="ibm-slapdSslKeyDatabase: key.kdb"
LDAP_NEW_String="ibm-slapdSslKeyDatabase: ${LDAP_KEY_PATH}"
sed -e "s|${LDAP_OLD_String}|${LDAP_NEW_String}|g" ${LDAP_CONF_FILE} > ${LDAP_CONF_FILE}.temp
 
echo "update ${LDAP_CONF_FILE} ..."
cp ${LDAP_CONF_FILE}.temp ${LDAP_CONF_FILE}

# copy ldap key files to LDAP server
cp -r ${IDS_INSTANCE_CREATION_CONFIG_PATH}/ldap_keystore/* ${INSTANCE_HOME}/idsslapd-ldapdb2/etc/
