#!/bin/sh
fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

echo ${OBJECTGRID_ROOT}

# DOMAIN number expected as parameter
if [ "$1" = "" ]
then
     # echo "Usage: script <DOMAIN #>"
     # exit
     DOMAIN=${CATALOG_SERVICE_DOMAIN_INDEX}
else
     DOMAIN=$1
fi

echo "DOMAIN = ${DOMAIN}" 
OFFSET=$(($DOMAIN * 10))

export ENDPOINTS=''
declare -i COUNT=0
for host in $CATALOG_HOSTS
do
  echo "Catalog host : $host"
  if ((0 != ${COUNT}))
    then
      ENDPOINTS=${ENDPOINTS},
  fi
  ENDPOINTS="${ENDPOINTS}${CATALOG_SERVER_NAME_PREFIX}${COUNT}:${host}:$((6600 + $OFFSET)):$((6601 + $OFFSET))" 

  let COUNT++
done

echo "Catalog Service Domain: DOMAIN = ${DOMAIN} , Name = ${CATALOG_SERVICE_DOMAIN_NAME}, OFFSET = ${OFFSET}"
echo "Catalog Service Domain: Endpoint = $ENDPOINTS"

COUNT=0
for host in $CATALOG_HOSTS
do
  SERVER_NAME=${CATALOG_SERVER_NAME_PREFIX}$COUNT
  LISTENER_PORT=$((2809 + $OFFSET))
  JMX_PORT=$((1099 + $DOMAIN))
  echo "start cat ${SERVER_NAME} server with LISTENER_PORT=${LISTENER_PORT} and JMX_PORT=${JMX_PORT} for DOMAIN $DOMAIN:[${CATALOG_SERVICE_DOMAIN_NAME}] on $host"
  if [[ ${CURRENT_HOST} == *$host* ]]; then
      ${OBJECTGRID_ROOT}/bin/startOgServer.sh ${SERVER_NAME} -domain ${CATALOG_SERVICE_DOMAIN_NAME} -serverProps ${WORKING_DIR}/properties/objectGridServer.properties -catalogServiceEndPoints $ENDPOINTS -listenerPort ${LISTENER_PORT} -jmxServicePort ${JMX_PORT} -listenerHost $host -quorum false -jvmArgs -Xmx512m &
  else
      ssh $host "cd ${WORKING_DIR};export JAVA_HOME=$JAVA_HOME;${OBJECTGRID_ROOT}/bin/startOgServer.sh ${SERVER_NAME} -domain ${CATALOG_SERVICE_DOMAIN_NAME} -serverProps ${WORKING_DIR}/properties/objectGridServer.properties -catalogServiceEndPoints $ENDPOINTS -listenerPort ${LISTENER_PORT} -jmxServicePort ${JMX_PORT} -listenerHost $host -quorum false -jvmArgs -Xmx512m" &
  fi
  let COUNT++
done
