#!/bin/sh
fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh


CONTAINER_SVR=${CONTAINER_SERVER_NAME_PREFIX}$1
HA_MAMAGER_PORT=$2
CONTAINER_LISTENER_PORT=$3


APP_LOG_PATH=${WORKING_DIR}/logs/${CONTAINER_SVR}


if [[ ! -e ${WORKING_DIR}/logs ]]; then
    mkdir ${WORKING_DIR}/logs
    chmod 777 ${WORKING_DIR}/logs
fi

if [[ ! -e $APP_LOG_PATH ]]; then
    mkdir $APP_LOG_PATH
    chmod 777 ${APP_LOG_PATH}
fi

${OBJECTGRID_ROOT}/bin/startXsServer.sh "$CONTAINER_SVR" -serverProps ${WORKING_DIR}/properties/objectGridServer.properties -haManagerPort $HA_MAMAGER_PORT -catalogServiceEndPoints $CATALOG_SERVICE_ENDPOINTS -objectgridFile "${OBJECT_GRID_XML}" -deploymentPolicyFile "${DEPLOYMENT_POLICY_XML}" -listenerPort $CONTAINER_LISTENER_PORT -jvmArgs -Xms2048m -Xmx3072m -cp "$APP_LIB_PATH" -Xgcpolicy:gencon -verbose:gc -Xverbosegclog:${APP_LOG_PATH}/verbose_gc.log,5,10000
