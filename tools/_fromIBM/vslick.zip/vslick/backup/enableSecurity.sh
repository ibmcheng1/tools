/home/virtuser/WMB/scripts/environment.sh

mqsichangeproperties "$BROKER" -o BrokerRegistry -n brokerKeystoreFile -v "/home/virtuser/WMB/Certificates/tchBrokerKeyStore.jks"
mqsichangeproperties "$BROKER" -o BrokerRegistry -n brokerTruststoreFile -v "/home/virtuser/WMB/Certificates/tchBrokerTrustStore.jks"
mqsisetdbparms "$BROKER" -n brokerKeystore::password -u ignore -p tchtsc
mqsisetdbparms "$BROKER" -n brokerTruststore::password -u ignore -p tchtsc
mqsichangeproperties "$BROKER" -e NotificationServices -o ComIbmJVMManager -n keystoreFile -v "/home/virtuser/WMB/Certificates/tchBrokerKeyStore.jks"
mqsichangeproperties "$BROKER" -e NotificationServices -o ComIbmJVMManager -n truststoreFile -v "/home/virtuser/WMB/Certificates/tchBrokerTrustStore.jks"
mqsichangeproperties "$BROKER" -e NotificationServices -o ComIbmJVMManager -n truststorePass -v defaultTruststore::password
mqsichangeproperties "$BROKER" -e NotificationServices -o ComIbmJVMManager -n keystorePass -v defaultKeystore::password
mqsichangeproperties "$BROKER" -e DeviceManagement -o ComIbmJVMManager -n keystoreFile -v "/home/virtuser/WMB/Certificates/tchBrokerKeyStore.jks"
mqsichangeproperties "$BROKER" -e DeviceManagement -o ComIbmJVMManager -n truststoreFile -v "/home/virtuser/WMB/Certificates/tchBrokerTrustStore.jks"
mqsichangeproperties "$BROKER" -e DeviceManagement -o ComIbmJVMManager -n truststorePass -v defaultTruststore::password
mqsichangeproperties "$BROKER" -e DeviceManagement -o ComIbmJVMManager -n keystorePass -v defaultKeystore::password
mqsichangeproperties "$BROKER" -e DPIManagementService -o ComIbmJVMManager -n keystoreFile -v "/home/virtuser/WMB/Certificates/tchBrokerKeyStore.jks"
mqsichangeproperties "$BROKER" -e DPIManagementService -o ComIbmJVMManager -n truststoreFile -v "/home/virtuser/WMB/Certificates/tchBrokerTrustStore.jks"
mqsichangeproperties "$BROKER" -e DPIManagementService -o ComIbmJVMManager -n truststorePass -v defaultTruststore::password
mqsichangeproperties "$BROKER" -e DPIManagementService -o ComIbmJVMManager -n keystorePass -v defaultKeystore::password
mqsichangeproperties "$BROKER" -e PaymentInstrumentRegistration -o ComIbmJVMManager -n keystoreFile -v "/home/virtuser/WMB/Certificates/tchBrokerKeyStore.jks"
mqsichangeproperties "$BROKER" -e PaymentInstrumentRegistration -o ComIbmJVMManager -n truststoreFile -v "/home/virtuser/WMB/Certificates/tchBrokerTrustStore.jks"
mqsichangeproperties "$BROKER" -e PaymentInstrumentRegistration -o ComIbmJVMManager -n truststorePass -v defaultTruststore::password
mqsichangeproperties "$BROKER" -e PaymentInstrumentRegistration -o ComIbmJVMManager -n keystorePass -v defaultKeystore::password
mqsichangeproperties "$BROKER" -e PaymentTransactionService -o ComIbmJVMManager -n keystoreFile -v "/home/virtuser/WMB/Certificates/tchBrokerKeyStore.jks"
mqsichangeproperties "$BROKER" -e PaymentTransactionService -o ComIbmJVMManager -n truststoreFile -v "/home/virtuser/WMB/Certificates/tchBrokerTrustStore.jks"
mqsichangeproperties "$BROKER" -e PaymentTransactionService -o ComIbmJVMManager -n truststorePass -v defaultTruststore::password
mqsichangeproperties "$BROKER" -e PaymentTransactionService -o ComIbmJVMManager -n keystorePass -v defaultKeystore::password
mqsichangeproperties "$BROKER" -e LookupPAN -o ComIbmJVMManager -n keystoreFile -v "/home/virtuser/WMB/Certificates/tchBrokerKeyStore.jks"
mqsichangeproperties "$BROKER" -e LookupPAN -o ComIbmJVMManager -n truststoreFile -v "/home/virtuser/WMB/Certificates/tchBrokerTrustStore.jks"
mqsichangeproperties "$BROKER" -e LookupPAN -o ComIbmJVMManager -n truststorePass -v defaultTruststore::password
mqsichangeproperties "$BROKER" -e LookupPAN -o ComIbmJVMManager -n keystorePass -v defaultKeystore::password
mqsichangeproperties "$BROKER" -e Admin -o ComIbmJVMManager -n keystoreFile -v "/home/virtuser/WMB/Certificates/tchBrokerKeyStore.jks"
mqsichangeproperties "$BROKER" -e Admin -o ComIbmJVMManager -n truststoreFile -v "/home/virtuser/WMB/Certificates/tchBrokerTrustStore.jks"
mqsichangeproperties "$BROKER" -e Admin -o ComIbmJVMManager -n truststorePass -v defaultTruststore::password
mqsichangeproperties "$BROKER" -e Admin -o ComIbmJVMManager -n keystorePass -v defaultKeystore::password
mqsisetdbparms "$BROKER" -n defaultKeystore::password -u ignore -p tchtsc
mqsisetdbparms "$BROKER" -n defaultTruststore::password -u ignore -p tchtsc
mqsichangeproperties "$BROKER" -b httplistener -o HTTPListener -n enableSSLConnector -v true

#Uncomment to enable mutual SSL
#mqsichangeproperties "$BROKER" -b httplistener -o HTTPSConnector -n clientAuth -v true

