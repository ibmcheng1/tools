#!/bin/sh
fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

# COUNT is the number of containers to start on the target host
# INDEX is the server index [0, 1, ...]
COUNT=$1
INDEX=$2

declare -i j=0
echo "Value of index: $INDEX"

for (( i=0, j=$INDEX; i < $COUNT; i++, ++j ))
do        
	APP_LOG_PATH=${WORKING_DIR}/logs/${CONTAINER_SERVER_NAME_PREFIX}$j
	if [[ ! -e $APP_LOG_PATH ]]; then
    		mkdir $APP_LOG_PATH
    		chmod 777 ${APP_LOG_PATH}
	fi
	
	${OBJECTGRID_ROOT}/bin/startOgServer.sh "${CONTAINER_SERVER_NAME_PREFIX}$j" -haManagerPort $((${CONTAINER_HA_PORT_STARTING} + $i)) -catalogServiceEndPoints $CATALOG_SERVICE_ENDPOINTS -objectgridFile "${OBJECT_GRID_XML}" -deploymentPolicyFile "${DEPLOYMENT_POLICY_XML}" -listenerPort $((${CONTAINER_LISTENER_PORT_STARTING} + $i)) -jvmArgs -Xms${CONTAINER_JVM_HEAP_SIZE}m -Xmx${CONTAINER_JVM_HEAP_SIZE}m -cp "$APP_LIB_PATH"
	sleep 10
done