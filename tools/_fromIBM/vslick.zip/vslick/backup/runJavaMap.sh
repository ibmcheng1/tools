#!/bin/sh

OBJECTGRID_ROOT=/Users/jian/og61_scenario1/wxs71/ObjectGrid
WORKING_DIR=/Users/jian/og61_scenario1/classes

CLASSPATH="$WORKING_DIR:$OBJECTGRID_ROOT/lib/objectgrid.jar"
PACKAGE=com.ibm.ws.objectgrid.test.scenario
CLASS=com.ibm.ws.objectgrid.test.scenario.DataServiceDriver

loop=20

size=20000   
threadLoad=20000
java -Xms1024m -Xmx1024m -cp $CLASSPATH $CLASS case001 usingLocalOG multiWorkerMode $threadLoad loop $loop size $size

size=20000   
threadLoad=10000
java -Xms1024m -Xmx1024m -cp $CLASSPATH $CLASS case002 usingLocalOG multiWorkerMode $threadLoad loop $loop size $size

size=20000   
threadLoad=5000
java -Xms1024m -Xmx1024m -cp $CLASSPATH $CLASS case004 usingLocalOG multiWorkerMode $threadLoad loop $loop size $size

size=20000   
threadLoad=2500
java -Xms1024m -Xmx1024m -cp $CLASSPATH $CLASS case008 usingLocalOG multiWorkerMode $threadLoad loop $loop size $size

size=20000   
threadLoad=1250
java -Xms1024m -Xmx1024m -cp $CLASSPATH $CLASS case016 usingLocalOG multiWorkerMode $threadLoad loop $loop size $size             
