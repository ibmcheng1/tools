#!/bin/ksh

export WAS_DMGR_PROFILE_ROOT=/opt/IBM/WebSphere/Profiles/DefaultDmgr01
export WAS_CUSTOMNODE_PROFILE_ROOT=/opt/IBM/WebSphere/Profiles/DefaultCustom01
# ideally, the hosts should be host names, not ip address.
export CUSTOMNODE_HOSTS="erdev046-1"
export CURRENT_HOST=`hostname`

echo WAS_DMGR_PROFILE_ROOT=$WAS_DMGR_PROFILE_ROOT
echo WAS_CUSTOMNODE_PROFILE_ROOT=$WAS_CUSTOMNODE_PROFILE_ROOT
echo CUSTOMNODE_HOSTS=$CUSTOMNODE_HOSTS

echo "------------------------------------"
echo "Starting Deployment Manager ...     "
echo "------------------------------------"
$WAS_DMGR_PROFILE_ROOT/bin/startManager.sh


echo "------------------------------------"
echo "Starting Custom Nodes ...     "
echo "------------------------------------"

for host in $CUSTOMNODE_HOSTS
do
  echo "starting WAS custom node on $host"
  if [[ ${CURRENT_HOST} == *$host* ]]; then
      $WAS_CUSTOMNODE_PROFILE_ROOT/bin/startNode.sh &
  else
      ssh $host "$WAS_CUSTOMNODE_PROFILE_ROOT/bin/startNode.sh" &
  fi
done


echo "Sleep 20 seconds ..."
sleep 20

echo "------------------------------------"
echo "Checking WAS processes ...     "
echo "------------------------------------"


ps -ef | grep dmgr

for host in $CUSTOMNODE_HOSTS
do
  if [[ ${CURRENT_HOST} == *$host* ]]; then
      ps -ef | grep nodeagent
  else
      ssh $host "ps -ef | grep nodeagent"
  fi
done



