#!/bin/sh

fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

echo servletUrl=$servletUrl
echo objectgridName=$objectgridName
echo mapName=$mapName

loop=30
actionListIndex=6
size=16000
threadLoad=1000
startKeyIndex=0
options="-disableRunGC"

./runDriver.sh -caseServlet -loop $loop -actionListIndex $actionListIndex -size $size -multiWorkerMode $threadLoad -startKeyIndex $startKeyIndex -dataServiceType 3 -servletUrl $servletUrl -objectgridName $objectgridName -mapName $mapName $options
