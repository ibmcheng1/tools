#!/bin/ksh
echo ======================================
echo running script01.sh
echo ======================================

echo WORKING_DIR=$WORKING_DIR
echo IDS_INSTALL_PATH=$IDS_INSTALL_PATH

# required properies to configure directory server instance
# Instance home: /home/myinst on AIX and Linux, and /export/home/myinst on Solaris
# instance name is also the owner name, db2 instance name, db2 database name

echo -------------------------------------
echo output content of properties file: ${IDS_CREATE_INSTANCE_PROPERTIES_FILE}
echo -------------------------------------
cat ${IDS_CREATE_INSTANCE_PROPERTIES_FILE}
echo -------------------------------------

. ${IDS_CREATE_INSTANCE_PROPERTIES_FILE}
                                
echo -------------------------------------
echo output required variables
echo -------------------------------------
echo INSTANCE_NAME=${INSTANCE_NAME}
echo UNSECURED_PORT=${UNSECURED_PORT}
echo SECURED_PORT=${SECURED_PORT}
echo ENCRYPTION_SEED=${ENCRYPTION_SEED}
echo ENCRYPTION_SALT=${ENCRYPTION_SALT}
echo INSTANCE_HOME=${INSTANCE_HOME}
echo INSTANCE_OWNER_PASSWORD=${INSTANCE_OWNER_PASSWORD}
echo ADMINISTRATOR_DN=${ADMINISTRATOR_DN}
echo ADMINISTRATOR_PASSWORD=${ADMINISTRATOR_PASSWORD}
echo SUFFIX_TO_ADD=${SUFFIX_TO_ADD}
echo LDIF_FILE_TO_LOAD=$LDIF_FILE_TO_LOAD
echo SCHEMA_FILE=$SCHEMA_FILE
echo SCHEMA_FOLDER=$SCHEMA_FOLDER
echo -------------------------------------

cd ${IDS_INSTALL_PATH}/sbin

echo ----------------------------------------
echo Step 1: creating directory server instance: root
echo ----------------------------------------

./idsicrt -I ${INSTANCE_NAME} -p ${UNSECURED_PORT} -s ${SECURED_PORT} -e ${ENCRYPTION_SEED} -g ${ENCRYPTION_SALT} -l /home/${INSTANCE_NAME} -G ${INSTANCE_NAME} -w ${INSTANCE_OWNER_PASSWORD} -n

echo ----------------------------------------
echo Step 2: Configuring DB2: directory server instance owner
echo ----------------------------------------

su - ${INSTANCE_NAME} -c "cd ${IDS_INSTALL_PATH}/sbin;./idscfgdb -I ${INSTANCE_NAME} -a ${INSTANCE_NAME} -w ${INSTANCE_OWNER_PASSWORD} -t ${INSTANCE_NAME} -l /home/${INSTANCE_NAME} -n"

echo ----------------------------------------
echo Step 3: Configure the administrator DN and password: directory server instance owner
echo ----------------------------------------

su - ${INSTANCE_NAME} -c "cd ${IDS_INSTALL_PATH}/sbin;./idsdnpw -I ${INSTANCE_NAME} -u ${ADMINISTRATOR_DN} -p ${ADMINISTRATOR_PASSWORD} -n"


echo -----------------------------------------------
echo Step 4: Configure the suffixes: directory server instance owner 
echo -----------------------------------------------
SUFFIX_TO_ADD="o=ER"
su - ${INSTANCE_NAME} -c "cd ${IDS_INSTALL_PATH}/sbin;./idscfgsuf -I ${INSTANCE_NAME} -s ${SUFFIX_TO_ADD} -n"
SUFFIX_TO_ADD="o=frd"
su - ${INSTANCE_NAME} -c "cd ${IDS_INSTALL_PATH}/sbin;./idscfgsuf -I ${INSTANCE_NAME} -s ${SUFFIX_TO_ADD} -n"
SUFFIX_TO_ADD="o=earlyrez"
su - ${INSTANCE_NAME} -c "cd ${IDS_INSTALL_PATH}/sbin;./idscfgsuf -I ${INSTANCE_NAME} -s ${SUFFIX_TO_ADD} -n"

echo ----------------------------------------
echo Step 5: update schema file V3.modifiedschema and load ${LDIF_FILE_TO_LOAD} into database ... 
echo ----------------------------------------
if [ -f ${SCHEMA_FILE} ]; then
  su - ${INSTANCE_NAME} -c "cp ${SCHEMA_FILE} /home/${INSTANCE_NAME}/idsslapd-${INSTANCE_NAME}/etc/V3.modifiedschema"
fi

if [ -d $SCHEMA_FOLDER ]then
  su - ${INSTANCE_NAME} -c "cp -r ${SCHEMA_FOLDER}/* /home/${INSTANCE_NAME}/idsslapd-${INSTANCE_NAME}/etc" 
fi

su - ${INSTANCE_NAME} -c "cd ${IDS_INSTALL_PATH}/sbin;./idsldif2db -i ${LDIF_FILE_TO_LOAD} -I ${INSTANCE_NAME}"

echo ----------------------------------------
echo Step 5-1: update ${INSTANCE_HOME}/idsslapd-ldapdb2/etc/ibmslapd.conf
echo ----------------------------------------

LDAP_CONF_FILE=${INSTANCE_HOME}/idsslapd-ldapdb2/etc/ibmslapd.conf
if [ ! -f ${LDAP_CONF_FILE}.ori ]; then
  su - ${INSTANCE_NAME} -c "cp ${LDAP_CONF_FILE} ${LDAP_CONF_FILE}.ori"
fi

# replace "ibm-slapdPwEncryption: aes256" with "ibm-slapdPwEncryption: ssha256"
LDAP_OLD_String="ibm-slapdPwEncryption: aes256"
LDAP_NEW_String="ibm-slapdPwEncryption: ssha256"
sed -e "s|${LDAP_OLD_String}|${LDAP_NEW_String}|g" ${LDAP_CONF_FILE} > ${LDAP_CONF_FILE}.temp
cp ${LDAP_CONF_FILE}.temp ${LDAP_CONF_FILE}

# enable SSL
LDAP_OLD_String="ibm-slapdSecurity: none"
LDAP_NEW_String="ibm-slapdSecurity: SSL"
sed -e "s|${LDAP_OLD_String}|${LDAP_NEW_String}|g" ${LDAP_CONF_FILE} > ${LDAP_CONF_FILE}.temp
cp ${LDAP_CONF_FILE}.temp ${LDAP_CONF_FILE}

LDAP_OLD_String="ibm-slapdSslCertificate: none"
LDAP_NEW_String="ibm-slapdSslCertificate: LDAP_Cert"
sed -e "s|${LDAP_OLD_String}|${LDAP_NEW_String}|g" ${LDAP_CONF_FILE} > ${LDAP_CONF_FILE}.temp
cp ${LDAP_CONF_FILE}.temp ${LDAP_CONF_FILE}

LDAP_KEY_PATH=${INSTANCE_HOME}/idsslapd-ldapdb2/etc/ldap_key.kdb
LDAP_OLD_String="ibm-slapdSslKeyDatabase: key.kdb"
LDAP_NEW_String="ibm-slapdSslKeyDatabase: ${LDAP_KEY_PATH}"
sed -e "s|${LDAP_OLD_String}|${LDAP_NEW_String}|g" ${LDAP_CONF_FILE} > ${LDAP_CONF_FILE}.temp
cp ${LDAP_CONF_FILE}.temp ${LDAP_CONF_FILE}

# copy ldap key files to LDAP server
cp -r ${IDS_INSTANCE_CREATION_CONFIG_PATH}/ldap_keystore/* ${INSTANCE_HOME}/idsslapd-ldapdb2/etc/

 
echo ----------------------------------------
echo Step 6: Starting Directory server: root
echo ----------------------------------------

./ibmslapd -I ${INSTANCE_NAME}

sleep 10

echo ----------------------------------------
echo Step 7: Verifying configuration by ps ${INSTANCE_NAME}  
echo ----------------------------------------

ps -ef | grep ${INSTANCE_NAME}


echo ----------------------------------------
echo Step 8: Verifying configuration by ldapsearch ... 
echo ----------------------------------------

${IDS_INSTALL_PATH}/bin/ldapsearch -s base -b "" objectclass=*


echo ----------------------------------------
echo Step 9: Verifying ${SUFFIX_TO_ADD} with base search ... 
echo ----------------------------------------

${IDS_INSTALL_PATH}/bin/ldapsearch -s base -b "${SUFFIX_TO_ADD}" objectclass=*


echo ----------------------------------------
echo Step 10: Verifying ${SUFFIX_TO_ADD} with sun tree search ... 
echo ----------------------------------------

${IDS_INSTALL_PATH}/bin/ldapsearch -s sub -b "${SUFFIX_TO_ADD}" objectclass=*

echo ======================================
echo end of script01.sh
echo ======================================

sudo -u ${INSTANCE_NAME} -i "${WORKING_DIR}/scripts/script02.sh ${IDS_INSTALL_PATH} ${INSTANCE_NAME} ${SUFFIX_TO_ADD}"
