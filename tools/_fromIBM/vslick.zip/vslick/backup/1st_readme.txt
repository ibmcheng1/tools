1. Modify setupEnv.bat first to set up the execution env for both client and server on the system
2. If the system is for launch OG cluster, then need to modify the host name to be the machine name specified in both cluster-config-scenario-X.xml and em-cluster-config-scenario-X.xml files.
   These two types of xml files are for launch Channel Framework based OG Cluster.
3. Required directory: OBJECTGRID_ROOT and JAVA_HOME
   
*****************************************************
Launch OG servers with Channel Framework approach:
*****************************************************
----------------------------
Support ObjectMap operations
----------------------------
cluster 0 : 1 servers, no partition, no replication
cluster 1 : 3 servers, no partition, async replication
cluster 2 : 3 servers, no partition, sync replication
cluster 3 : 3 servers, 3 partitions, asyn replication
cluster 4 : 3 servers, 3 partitions, syn replication

----------------------------
Support EM API operations
----------------------------
clusterEM 0 : 1 servers, no partition, no replication
clusterEM 1 : 3 servers, no partition, async replication
clusterEM 2 : 3 servers, no partition, sync replication
clusterEM 3 : 3 servers, 3 partitions, asyn replication
clusterEM 4 : 3 servers, 3 partitions, syn replication


*****************************************************
Launch OG servers with Catalog server approach:
*****************************************************
----------------------------
Support ObjectMap operations
----------------------------
cluster-catalog 0 : 1 servers, 1 partitions, no replication
cluster-catalog 1 : 2 servers, 1 partitions, 1 async replication
cluster-catalog 2 : 2 servers, 1 partitions, 1 sync replication
cluster-catalog 3 : 3 servers, 3 partitions, 1 asyn replication
cluster-catalog 4 : 3 servers, 3 partitions, 1 syn replication
cluster-catalog 5 : 3 servers, 1 partitions, 1 sync replication + 1 async replication
cluster-catalog 6 : 3 servers, 3 partitions, 1 sync replication + 1 async replication

----------------------------
Support EM API operations
----------------------------
clusterEM-catalog 0 : 1 servers, 1 partitions, no replication
clusterEM-catalog 1 : 2 servers, 1 partitions, 1 async replication
clusterEM-catalog 2 : 2 servers, 1 partitions, 1 sync replication
clusterEM-catalog 3 : 3 servers, 3 partitions, 1 asyn replication
clusterEM-catalog 4 : 3 servers, 3 partitions, 1 syn replication
clusterEM-catalog 5 : 3 servers, 1 partitions, 1 sync replication + 1 async replication
clusterEM-catalog 6 : 3 servers, 3 partitions, 1 sync replication + 1 async replication


*****************************************************
Launch DataServiceDriver commands for performance stats:
*****************************************************
----------------------------
ObjectMap operations
----------------------------
runMap: execute both runMap_local and runMap_remote commands consequently.
runMap_catalog: execute both runMap_local and runMap_catalog_remote commands consequently.
runMap_catalog_remote: remote catalog OG scenario, require OG cluster launched by "cluster-catalog X" command.
runMap_catalog_remote_test: test run for remote catalog OG scenario to ensure the catalog OG cluster is available and warm it up.
runMap_local: local OG scenario, no need of launching servers.
runMap_remote: remote OG scenario, require OG cluster launched by "cluster X" command.
runMap_remote_test: test run for remote OG scenario to ensure the OG cluster is available and warm it up.


----------------------------
EM API operations
----------------------------
runEM: execute both runEM_local and runEM_remote commands consequently.
runEM_catalog: execute both runEM_local and runEM_catalog_remote commands consequently.
runEM_catalog_remote: remote catalog OG EM scenario, require OG EM cluster launched by "clusterEM-catalog X" command.
runEM_catalog_remote_test: test run for remote catalog OG EM scenario to ensure the catalog OG EM cluster is available and warm it up.
runEM_local: local OG EM scenario, no need of launching servers.
runEM_remote: remote OG EM scenario, require OG EM cluster launched by "clusterEM X" command.
runEM_remote_test: test run for remote OG EM scenario to ensure the OG EM cluster is available and warm it up.


*****************************************************
ObjectMap benchmarking Example:
*****************************************************
1. Benchmarking ObjectMap remote channelF 1 server scenario
execute "cluster 0" on the server machine
execute "runMap_remote_test" first on client machine to warmup servers.
execute "runMap_remote" to get performance report.

The performance report will be "DataServiceDriver_RemoteOG_stat.cvs" that can be open by Excel.
The execution log will be "DataServiceDriver_RemoteOG_stat.log"


2. Benchmarking ObjectMap remote channelF AsyncR scenario
execute "cluster 1" on the server machine
execute "runMap_remote_test" first on client machine to warmup servers.
execute "runMap_remote" to get performance report.

The performance report will be "DataServiceDriver_RemoteOG_stat.cvs" that can be open by Excel.
The execution log will be "DataServiceDriver_RemoteOG_stat.log"


3. Benchmarking ObjectMap remote channelF AsyncR scenario
execute "cluster 2" on the server machine
execute "runMap_remote_test" first on client machine to warmup servers.
execute "runMap_remote" to get performance report.

The performance report will be "DataServiceDriver_RemoteOG_stat.cvs" that can be open by Excel.
The execution log will be "DataServiceDriver_RemoteOG_stat.log"

Note, usually a client machine is dedicated to a particular server machine.
After copy the performance data from the report to the driver report, it is better to delete both .log and .csv file.
So the next run won't be messed up by previous run.


4. Benchmarking ObjectMap remote Catalog 1 server scenario
execute "cluster-catalog 0" on the server machine
execute "runMap_catalog_remote_test" first on client machine to warmup servers.
execute "runMap_catalog_remote" to get performance report.

The performance report will be "DataServiceDriver_RemoteOG_stat.cvs" that can be open by Excel.
The execution log will be "DataServiceDriver_RemoteOG_stat.log"

4. Benchmarking ObjectMap Local OG scenario
execute "runMap_Local" to get performance report.
or, "runLocal_all" to get both ObjectMap and EM localOG reports as the same time.

*****************************************************
EM benchmarking Example:
*****************************************************
1. Benchmarking EM remote channelF 1 server scenario
execute "clusterEM 0" on the server machine
execute "runEM_remote_test" first on client machine to warmup servers.
execute "runEM_remote" to get performance report.

The performance report will be "DataServiceDriver_RemoteOG_EM_stat.cvs" that can be open by Excel.
The execution log will be "DataServiceDriver_RemoteOG_EM_stat.log"

2. Benchmarking EM remote Catalog 1 server scenario
execute "clusterEM-catalog 0" on the server machine
execute "runEM_catalog_remote_test" first on client machine to warmup servers.
execute "runEM_catalog_remote" to get performance report.

3. Benchmarking ObjectMap Local OG scenario
execute "runEM_Local" to get performance report.
or, "runLocal_all" to get both ObjectMap and EM localOG reports as the same time.


