#!/bin/sh

# The startContainerServer.sh expects the following parameters:
#
#CONTAINER_SVR=${CONTAINER_SERVER_NAME_PREFIX}$1
#HA_MAMAGER_PORT=$2
#CONTAINER_LISTENER_PORT=$3

./startContainerServer.sh 0 6602 2801
./startContainerServer.sh 1 6603 2802
