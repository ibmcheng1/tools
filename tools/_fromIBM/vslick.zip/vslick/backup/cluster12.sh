#!/bin/ksh

export OBJECTGRID_ROOT=/xd/xd601ms
export WORKING_DIR=./classes
export clusterfile=${WORKING_DIR}/META-INF/cluster-config-scenario-1.xml
export objectgridfile=${WORKING_DIR}/META-INF/objectgrid-definition-scenario-2.xml

export PATH=${OBJECTGRID_ROOT}/bin;${PATH}

startOgServer server1 -objectgridFile ${objectgridfile} -clusterFile ${clusterfile} -jvmArgs -cp ${WORKING_DIR}

startOgServer server2 -objectgridFile ${objectgridfile} -clusterFile ${clusterfile} -jvmArgs -cp ${WORKING_DIR}

startOgServer server3 -objectgridFile ${objectgridfile} -clusterFile ${clusterfile} -jvmArgs -cp ${WORKING_DIR}
