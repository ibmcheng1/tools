#!/bin/bash
auditdata_dir=/db2fs/db2auditdata
archive_dir=/db2fs/db2auditarchive
extract_dir=/db2fs/db2auditextract


ls -l ${archive_dir}
ls -l ${extract_dir}

archive_target="${archive_dir}/*"
extract_target="${extract_dir}/*"

echo archive_target=$archive_target
echo extract_target=$extract_target

rm ${archive_target}
rm ${extract_target}
