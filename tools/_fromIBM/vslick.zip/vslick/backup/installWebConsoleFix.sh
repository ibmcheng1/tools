#!/bin/ksh
# This script is intended to work on Linux with bash shell or AIX with ksh.
# Be sure to set the first line of the script appriately for the platform where
# it will be run.
#
#########################################################################

# When debugging on IPAS, source the virtualimage.properties
if [ -f /etc/virtualimage.properties ]; then
  . /etc/virtualimage.properties
fi

WORKING_DIR=`pwd`

echo WORKING_DIR=$WORKING_DIR
echo IDS_INSTALL_PATH=$IDS_INSTALL_PATH
echo IDS_SOFTWARE_PATH=$IDS_SOFTWARE_PATH

export WORKING_DIR
export IDS_INSTALL_PATH
export IDS_SOFTWARE_PATH

echo ======================================
echo start installing IDS Web Console Fix
echo ======================================

cd ${IDS_INSTALL_PATH}/appsrv/profiles/TDSWebAdminProfile/bin
./stopServer.sh server1
cp ${IDS_INSTALL_PATH}/appsrv/profiles/TDSWebAdminProfile/installedApps/DefaultNode/IDSWebApp.war.ear/IDSWebApp.war/WEB-INF/lib/IDSSrvAdm.jar ${IDS_INSTALL_PATH}/IDSSrvAdm.jar.ori
cp ${IDS_WEB_CONSOLE_FIX_PATH}/IDSSrvAdm.jar ${IDS_INSTALL_PATH}/appsrv/profiles/TDSWebAdminProfile/installedApps/DefaultNode/IDSWebApp.war.ear/IDSWebApp.war/WEB-INF/lib/IDSSrvAdm.jar
./startServer.sh server1
