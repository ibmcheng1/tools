############################################################
### Application Configuration Property file 
### Version 1.0
############################################################

ER_ENVIRONMENT = "int"
APPLICATION_name = "EarlyResolutionApp"

###########################################################################################################################################
###   Signer Certification and HTTP Session Management CONFIGURATION
###
###   Used to retrieve XC10 signer certification and configure session management with XC10 on the application.

CACHING_certAlias = "cachingalias"
CACHING_host = "20.176.240.149"
CACHING_user = "sessionERDev01"
CACHING_password = "cscibm_@UhTvF2CpD4u4"
CACHING_grid = "sessionERDev01"

wxsCatalog=""
userid=""
password=""
