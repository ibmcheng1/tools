import os
import sys
execfile('wsadminlib.py')

#import the applications config.py property file with input variables to be used into the script...

dir = os.getcwd()
fileName, fileExtension = os.path.splitext(sys.argv[0])

print "Configuration File Name: " + fileName
exec("from " + fileName + " import *")

print "---------------------------------------------"
print "deleting WXS catalog Service Domain"
print "---------------------------------------------"
print "wxsCatalogDomainName   = "+wxsCatalogDomainName

AdminTask.deleteXSDomain('[-name '+wxsCatalogDomainName+' ]') 

saveAndSyncAndPrintResult()
