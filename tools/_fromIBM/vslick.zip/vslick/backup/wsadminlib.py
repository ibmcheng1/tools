_modules = [
            'sys',
            'time',
            're',
            'glob',
            'os',
            'os.path',
            'getopt',
            'traceback',
           ]

for module in _modules:
  try:
    locals()[module] = __import__(module, {}, {}, [])
  except ImportError:
    print 'Error importing %s.' % module

try:
    AdminConfig = sys._getframe(1).f_locals['AdminConfig']
    AdminApp = sys._getframe(1).f_locals['AdminApp']
    AdminControl = sys._getframe(1).f_locals['AdminControl']
    AdminTask = sys._getframe(1).f_locals['AdminTask']
except:
    print "Warning: Caught exception accessing Admin objects. Continuing."

# Define False, True
(False,True)=(0,1)

##############################################################################
# Really basic stuff for messing around with configuration objects

def _splitlist(s):
    """Given a string of the form [item item item], return a list of strings, one per item.
    WARNING: does not yet work right when an item has spaces.  I believe in that case we'll be
    given a string like '[item1 "item2 with spaces" item3]'.
    """
    if s[0] != '[' or s[-1] != ']':
        raise "Invalid string: %s" % s
    return s[1:-1].split(' ')

def _splitlines(s):
  rv = [s]
  if '\r' in s:
    rv = s.split('\r\n')
  elif '\n' in s:
    rv = s.split('\n')
  if rv[-1] == '':
    rv = rv[:-1]
  return rv


def getObjectAttribute(objectid, attributename):
    """Return the value of the named attribute of the config object with the given ID.
    If there's no such attribute, returns None.
    If the attribute value looks like a list, converts it to a real python list.
    TODO: handle nested "lists"
    """
    #sop("getObjectAttribute:","AdminConfig.showAttribute(%s, %s)" % ( repr(objectid), repr(attributename) ))
    result = AdminConfig.showAttribute(objectid, attributename)
    if result != None and result.startswith("[") and result.endswith("]"):
        # List looks like "[value1 value2 value3]"
        result = _splitlist(result)
    return result

def setObjectAttributes(objectid, **settings):
    """Set some attributes on an object.
    Usage: setObjectAttributes(YourObjectsConfigId, attrname1=attrvalue1, attrname2=attrvalue2)
    for 0 or more attributes."""
    m = "setObjectAttributes:"
    #sop(m,"ENTRY(%s,%s)" % (objectid, repr(settings)))
    attrlist = []
    for key in settings.keys():
        #sop(m,"Setting %s=%s" % (key,settings[key]))
        attrlist.append( [ key, settings[key] ] )
    #sop(m,"Calling AdminConfig.modify(%s,%s)" % (repr(objectid),repr(attrlist)))
    AdminConfig.modify(objectid, attrlist)

def getObjectsOfType(typename, scope = None):
    """Return a python list of objectids of all objects of the given type in the given scope
    (another object ID, e.g. a node's object id to limit the response to objects in that node)
    Leaving scope default to None gets everything in the Cell with that type.
    ALWAYS RETURNS A LIST EVEN IF ONLY ONE OBJECT.
    """
    m = "getObjectsOfType:"
    if scope:
        #sop(m, "AdminConfig.list(%s, %s)" % ( repr(typename), repr(scope) ) )
        return _splitlines(AdminConfig.list(typename, scope))
    else:
        #sop(m, "AdminConfig.list(%s)" % ( repr(typename) ) )
        return _splitlines(AdminConfig.list(typename))


def enableCacheReplication(cacheobjectid, domainname, replicationType = 'PUSH'):
    """Enables data replication on any cache instance object, be it the default Dynacache object
    or an object or servlet cache instance."""
    m = "enableCacheReplication:"

    #sop(m,"dynacache=%s " % ( repr(dynacache), ))
    AdminConfig.modify(cacheobjectid, [['enableCacheReplication', 'true'], ['replicationType', replicationType]])
    drssettings = getObjectAttribute(cacheobjectid, 'cacheReplication')
    if drssettings == None:
        AdminConfig.create('DRSSettings', cacheobjectid, [['messageBrokerDomainName', domainname]])
        # Note: creating the DRSSettings object automagically sets the cacheReplication attribute
        # of the cache object to refer to it
    else:
        setObjectAttributes(drssettings, messageBrokerDomainName = domainname)

############################################################
# DynaCache related methods

def enableDynaCacheReplication(nodename, servername, domainname, replicationType = 'PUSH'):
    """Enables Data Replication for the dynacache service on the given server using a given replication type (defaults to PUSH)"""
    m = "enableDynaCacheReplication:"
    #sop(m,"Entry. nodename=%s servername=%s domainname=%s replicationType=%s" % ( repr(nodename), repr(servername), repr(domainname), replicationType ))
    server_id = getServerByNodeAndName(nodename, servername)
    #sop(m,"server_id=%s " % ( repr(server_id), ))
    dynacache = AdminConfig.list('DynamicCache',  server_id)
    enableCacheReplication(dynacache, domainname, replicationType)
        
############################################################
# cluster-related methods

def getServerClusterByName( name ):
    """Return the config object id for the named server cluster
    TODO: get rid of either this or getClusterId"""
    return getObjectByName( 'ServerCluster', name )

def getClusterId(clustername):
    """Return the config object id for the named server cluster.
    TODO: get rid of either this or getServerClusterByName"""
    return getServerClusterByName(clustername)

def listServersInCluster(clusterName):
    """Return a list of all servers (members) that are in the specified cluster"""
    m = "listServersInCluster:"
    sop(m,"clusterName = %s" % clusterName)
    clusterId = AdminConfig.getid("/ServerCluster:" + clusterName + "/")
    clusterMembers = _splitlines(AdminConfig.list("ClusterMember", clusterId ))
    return clusterMembers


############################################################
# server-related methods

def getServerByNodeAndName( nodename, servername ):
    """Return config id for a server"""
    return getObjectByNodeAndName( nodename, 'Server', servername )

############################################################
# misc methods

def getObjectByName( typename, objectname ):
    """Get an object of a given type and name - WARNING: the object should be unique in the cell; if not, use getObjectByNodeAndName instead."""
    all = _splitlines(AdminConfig.list( typename ))
    result = None
    for obj in all:
        name = AdminConfig.showAttribute( obj, 'name' )
        if name == objectname:
            if result != None:
                raise "FOUND more than one %s with name %s" % ( typename, objectname )
            result = obj
    return result

############################################################
# misc methods
def getSopTimestamp():
    """Returns the current system timestamp in a nice internationally-generic format."""
    # Assemble the formatting string in pieces, so that some code libraries do not interpret
    # the strings as special keywords and substitute them upon extraction.
    formatting_string = "[" + "%" + "Y-" + "%" + "m" + "%" + "d-" + "%" + "H" + "%" + "M-" + "%" + "S00]"
    return time.strftime(formatting_string)

DEBUG_SOP=0
def enableDebugMessages():
    """
    Enables tracing by making future calls to the sop() method actually print messages.
    A message will also be printed to notify the user that trace messages will now be printed.
    """
    global DEBUG_SOP
    DEBUG_SOP=1
    sop('enableDebugMessages', 'Verbose trace messages are now enabled; future debug messages will now be printed.')

def disableDebugMessages():
    """
    Disables tracing by making future calls to the sop() method stop printing messages.
    If tracing is currently enabled, a message will also be printed to notify the user that future messages will not be printed.
    (If tracing is currently disabled, no message will be printed and no future messages will be printed).
    """
    global DEBUG_SOP
    sop('enableDebugMessages', 'Verbose trace messages are now disabled; future debug messages will not be printed.')
    DEBUG_SOP=0

def sop(methodname,message):
    """Prints the specified method name and message with a nicely formatted timestamp.
    (sop is an acronym for System.out.println() in java)"""
    global DEBUG_SOP
    if(DEBUG_SOP):
        timestamp = getSopTimestamp()
        print "%s %s %s" % (timestamp, methodname, message)

def emptyString(strng):
    """Returns True if the string is null or empty."""
    if None == strng or "" == strng:
        return True
    return False

def getCellName():
    """Return the name of the cell we're connected to"""
    # AdminControl.getCell() is simpler, but only
    # available if we're connected to a running server.
    cellObjects = getObjectsOfType('Cell')  # should only be one
    cellname = getObjectAttribute(cellObjects[0], 'name')
    return cellname

def getCellId(cellname = None):
    """Return the config object ID of the cell we're connected to"""
    if cellname == None:
        cellname = getCellName()
    return AdminConfig.getid( '/Cell:%s/' % cellname )

def getNodeId( nodename ):
    """Given a node name, get its config ID"""
    return AdminConfig.getid( '/Cell:%s/Node:%s/' % ( getCellName(), nodename ) )

def getNodeName(node_id):
    """Get the name of the node with the given config object ID"""
    return getObjectAttribute(node_id, 'name')
    
def getServerId(nodename,servername):
    """Return the config id for a server or proxy.  Could be an app server or proxy server, etc"""
    id = getObjectByNodeAndName(nodename, "Server", servername) # app server
    if id == None:
        id = getObjectByNodeAndName(nodename, "ProxyServer", servername)
    return id

def getObjectByNodeAndName( nodename, typename, objectname ):
    """Get the config object ID of an object based on its node, type, and name"""
    # This version of getObjectByName distinguishes by node,
    # which should disambiguate some things...
    node_id = getNodeId(nodename)
    all = _splitlines(AdminConfig.list( typename, node_id ))
    result = None
    for obj in all:
        name = AdminConfig.showAttribute( obj, 'name' )
        if name == objectname:
            if result != None:
                raise "FOUND more than one %s with name %s" % ( typename, objectname )
            result = obj
    return result

def nodeIsDmgr( nodename ):
    """Return true if the node is the deployment manager"""
    return nodeHasServerOfType( nodename, 'DEPLOYMENT_MANAGER' )

def nodeIsUnmanaged( nodename ):
    """Return true if the node is an unmanaged node."""
    return not nodeHasServerOfType( nodename, 'NODE_AGENT' )

def nodeHasServerOfType( nodename, servertype ):
    node_id = getNodeId(nodename)
    serverEntries = _splitlines(AdminConfig.list( 'ServerEntry', node_id ))
    for serverEntry in serverEntries:
        sType = AdminConfig.showAttribute( serverEntry, "serverType" )
        if sType == servertype:
            return 1
    return 0

def listNodes():
    """Return list of node names, excluding the dmgr node.
       Beware, this list will include any existing IHS nodes."""
    m = "listNodes:"
    node_ids = _splitlines(AdminConfig.list( 'Node' ))
    result = []
    for node_id in node_ids:
        nodename = getNodeName(node_id)
        if not nodeIsDmgr(nodename):
            result.append(nodename)
    if 0 == len(result):
        sop(m,"Warning. No non-manager nodes are defined!!!")
    return result

def syncall():
    """Sync config to all nodes - return 0 on success, non-zero on error"""
    m = "wsadminlib.syncall"

    if whatEnv() == 'base':
        sop(m,"WebSphere Base, not syncing")
        return 0

    sop(m, "Start")

    returncode = 0

    nodenames = listNodes()
    for nodename in nodenames:
        # Note: listNodes() doesn't include the dmgr node - if it did, we'd
        # have to skip it
        # We do, however, have to skip unmanaged nodes.  These will show up
        # when there is a web server defined on a remote machine.
        if not nodeIsDmgr( nodename ) and not nodeIsUnmanaged( nodename ):
            sop(m,"Sync config to node %s" % nodename)
            Sync1 = AdminControl.completeObjectName( "type=NodeSync,node=%s,*" % nodename )
            if Sync1:
                rc = AdminControl.invoke( Sync1, 'sync' )
                if rc != 'true':  # failed
                    sop(m,"Sync of node %s FAILED" % nodename)
                    returncode = 1
            else:
                sop(m,"WARNING: was unable to get sync object for node %s - is node agent running?" % nodename)
                returncode = 2
    if returncode != 0:
        sop(m,"Syncall FAILED")
    sop(m,"Done")
    return returncode


############################################################
# ObjectCacheInstance related methods

def _getObjectScope(objectid):
    """Intended for private use within wsadminlib only.
    Pick out the part of the config object ID between the '('
    and the '|' -- we're going to use it in createObjectCache to identify the scope
    of the object"""
    return objectid.split("(")[1].split("|")[0]
    #if objectid is not None:
    #    return objectid.split("(")[1].split("|")[0]
    #else:
    #    return objectid

############################################################

def saveAndSync():
    """Save config changes and sync them - return 0 on sync success, non-zero on failure"""
    m = "save:"
    sop(m, "AdminConfig.queryChanges()")
    changes = _splitlines(AdminConfig.queryChanges())
    for change in changes:
        sop(m, "  "+change)
    rc = 0;
    sop(m, "AdminConfig.getSaveMode()")
    mode = AdminConfig.getSaveMode()
    sop(m, "  "+mode)
    sop(m, "AdminConfig.save()")
    AdminConfig.save()
    sop(m, "  Save complete!")
    rc = syncall()
    return rc

def saveAndSyncAndPrintResult():
    """Save config changes and sync them - prints save.result(0) on sync success, save.result(non-zero) on failure"""
    rc = saveAndSync()
    print "save.result(%s)" % (rc)

def save():
    """Save config changes and sync them - return 0 on sync success, non-zero on failure"""
    return saveAndSync()

def reset():
    """Reset config changes (allows throwing away changes before saving - just quitting your script without saving usually does the same thing)"""
    AdminConfig.reset()
    

###############################################################################
# Wrapper definitions for AdminConfig (logs activity automatically)
def remove( object ):
    """Removes the specified object"""
    sop("remove:", 'AdminConfig.remove(%s)' % ( repr(object) ) )
    AdminConfig.remove(object)
    
def removeAndCreate( type, parent, attrs, objectKeyNames, parentAttrName=None ):
    """Creates an object of a specific type under the parent with the given attributes.  If such an object already exists, and if that object has existing attributes matching attributes named by objectKeyNames, the existing object is first removed."""
    return _create(type, parent, attrs, objectKeyNames, parentAttrName, None)

def _create( type, parent, attrs, objectKeyNames, parentAttrName, template ):
    """Creates an object of a specific type under a specific parent with the given attrs and template.  parentAttrName defines the attribute name in the parent you want to create a type under. If an existing object has existing attributes matching attributes named by objectKeyNames, it will first be removed."""
    m = "_create:"
    if objectKeyNames:
        matchingAttrs = []
        for objectKeyName in objectKeyNames:
            for attr in attrs:
                if attr[0] == objectKeyName:
                    # assume that objectKeyNames are not specified more than once
                    matchingAttrs.append( [objectKeyName, attr[1]]  )
        if len(matchingAttrs)>0:
            findAndRemove(type, matchingAttrs, parent)
    if parentAttrName:
        sop(m, 'AdminConfig.create(%s, %s, %s, %s)' % (repr(type), repr(parent), repr(attrs), repr(parentAttrName)))
        object=AdminConfig.create(type, parent, attrs, parentAttrName)
    else:
        if template:
            sop(m, 'AdminConfig.create(%s, %s, %s, %s)' % (repr(type), repr(parent), repr(attrs), repr(template)))
            object=AdminConfig.create(type, parent, attrs, template)
        else:
            sop(m, 'AdminConfig.create(%s, %s, %s)' % (repr(type), repr(parent), repr(attrs)))
            object=AdminConfig.create(type, parent, attrs)
    return object

def findAndRemove( type, attrs, parent=None ):
    """Removes all the objects of a specific type under a specific parent that have attributes matching attrs"""
    children = getFilteredTypeList(type, attrs, parent)
    for child in children:
        remove(child)


def getFilteredTypeList( type, attrs, parent=None ):
    """Produces a list of all the objects of a specific type under a specific parent that have attributes matching attrs"""
    myList = getObjectsOfType(type, parent)
    return filterTypeList(myList, attrs)

def filterTypeList( list, attrs ):
    """Filters the input list for items with an attribute names matching the input attribute list"""
    newlist = []
    for item in list:
        # assume that the item is wanted
        addItem = 1
        for attr in attrs:
            value = getObjectAttribute( item, attr[0] )
            if value != attr[1]:
                # if any attribute of an item is not wanted, then the item is not wanted
                addItem = 0
        if addItem:
            newlist.append( item )
    return newlist
####################################################################################
# WXS , DynaCache, Cahce instances related methods
####################################################################################
####################################################################################

def printObject(name, object ):
    """Return the config object id for the named URIGroup."""
    if object is not None:
        print name + " = " + object
    else:
        print name + " = NONE"

def printAllObjectCacheInstances(scopeobjectid):
    """print all object cache instances"""
    scope = _getObjectScope(scopeobjectid)
    print "----------------------------------"
    print "Display All Object Cache Instance.  scope = " + scope
    print "----------------------------------"
    cache_ids = _splitlines(AdminConfig.list( 'ObjectCacheInstance' ))
    for id in cache_ids:
        #print "cache id = " + id
        cacheName = AdminConfig.showAttribute( id, "name" )
        idscope = _getObjectScope(id)
        if scope == idscope:
            print "cacheName = " + cacheName
     
def printAllServletCacheInstances(scopeobjectid):
    """print all servlet cache instances"""
    scope = _getObjectScope(scopeobjectid)
    print "----------------------------------"
    print "Display All Servlet Cache Instance.  scope = " + scope
    print "----------------------------------"
    cache_ids = _splitlines(AdminConfig.list( 'ServletCacheInstance' ))
    for id in cache_ids:
        #print "cache id = " + id
        cacheName = AdminConfig.showAttribute( id, "name" )
        idscope = _getObjectScope(id)
        if scope == idscope:
            print "cacheName = " + cacheName

###########################################################
# Create cache instances methods
#################################

def GetPropertiesDictionary(id):
        # needs a valid id and returns a dictionary of attributes
	dictionary = {}
	for item in AdminConfig.show(id).splitlines():
		item = item[1:-1]
		spacePos = item.find(' ')
		dictionary[item[0:spacePos]] = item[spacePos + 1:]
	return dictionary
        
def printPropertiesDictionary(id):
    propertyDictionary = GetPropertiesDictionary(id)
    print "----------------------------------"
    print "PropertyDictionary of id["+id+"]"
    print "----------------------------------"
    print propertyDictionary


def printPropertiesSet(id):
    propertySet = AdminConfig.showAttribute(id, "propertySet")
    if propertySet is None or propertySet == "":
        if propertySet is None:
            print "propertySet is NONE" 
        else:
            print "propertySet is \"\""
    else:
        print "propertySet = " + propertySet

def printCacheProviderAtScope(scopeobjectid):
    print "----------------------------------"
    print "Display All CacheProvider for the scope of " + scopeobjectid 
    print "----------------------------------"
    scope = _getObjectScope(scopeobjectid)
    found = False
    for cacheprovider in getObjectsOfType('CacheProvider'):
        if _getObjectScope(cacheprovider) == scope:
            print "Current cacheprovider = " + cacheprovider
            cacheproviderName = AdminConfig.showAttribute(cacheprovider, "name")
            print "    cacheproviderName = " + cacheproviderName
        #else:
        #    print "    scope not matched"
        #    cacheproviderName = AdminConfig.showAttribute(cacheprovider, "name")
        #    print "    cacheproviderName = " + cacheproviderName
            
    return None

def _getCacheProviderAtScope(scopeobjectid, cacheProviderType):
    scope = _getObjectScope(scopeobjectid)
    found = False
    for cacheprovider in getObjectsOfType('CacheProvider'):   
        if _getObjectScope(cacheprovider) == scope:
            cacheproviderName = AdminConfig.showAttribute(cacheprovider, "name")
            if cacheproviderName == "com.ibm.ws.objectgrid.dynacache.CacheProviderImpl" :               
                if cacheProviderType == "WXS":
                    return cacheprovider    
            else:
                if cacheProviderType != "WXS":
                    return cacheprovider
    
    # if reaching this point, means WXS provider is not found, create it.
    print "WXS Cache Provider is not found, create WXS Cache Provider" 
    if cacheProviderType == "WXS":
        print "Creating WXS Cache Provider"
        cacheprovider = createWXSCacheProvider(scopeobjectid)
        return cacheprovider        
    else:
        print "ERROR: no creation of WXS Cache Provider"
                
    return None


def createWXSCacheProvider ( scopeobjectid):
    name = "com.ibm.ws.objectgrid.dynacache.CacheProviderImpl"
    description = "WXS Cache Provider"
    attrs = []
    attrs.append( [ 'name', name ] )
    attrs.append( [ 'description', description ] )
    cacheProvider = create('CacheProvider', scopeobjectid, attrs, None)
    saveAndSyncAndPrintResult()
    return cacheProvider


def createObjectCache(scopeobjectid, name, jndiname, cacheProviderType):
    cacheprovider = _getCacheProviderAtScope(scopeobjectid, cacheProviderType)    
    if None == cacheprovider:
        raise Exception("COULD NOT FIND CacheProvider [%s] at the same scope as %s" % (cacheProviderType, scopeobjectid))

    return AdminTask.createObjectCacheInstance(cacheprovider, ["-name", name,"-jndiName", jndiname])
    

def createServletCache(scopeobjectid, name, jndiname, cacheProviderType):
    cacheprovider = _getCacheProviderAtScope(scopeobjectid, cacheProviderType)    
    if None == cacheprovider:
        raise Exception("COULD NOT FIND CacheProvider at the same scope as %s" % scopeobjectid)

    return AdminTask.createServletCacheInstance(cacheprovider, ["-name", name,"-jndiName", jndiname])

def setObjectCacheSettings( objectcache_id, settingname, settingvalue ):
    """Sets the specified ObjectCacheInstance setting."""
    m = "setObjectCacheSettings:"
    sop(m,"objectcache_id=%s settingname=%s settingvalue=%s" % ( repr(objectcache_id), repr(settingname), repr(settingvalue), ))
    AdminConfig.modify( objectcache_id, [[settingname, settingvalue]])
    actualvalue = AdminConfig.showAttribute( objectcache_id, settingname )
    sop(m,"Exit. Set %s to %s on objectCacheInstance %s" % ( repr(settingname), repr(actualvalue), repr(objectcache_id), ))


def setCacheInstanceSettings( cacheInstance_id, settingname, settingvalue ):
    """Sets the specified Cache Instance setting."""
    m = "setCacheInstanceSettings:"
    sop(m,"cacheInstance_id=%s settingname=%s settingvalue=%s" % ( repr(cacheInstance_id), repr(settingname), repr(settingvalue), ))
    AdminConfig.modify( cacheInstance_id, [[settingname, settingvalue]])
    actualvalue = AdminConfig.showAttribute( cacheInstance_id, settingname )
    sop(m,"Exit. Set %s to %s on Cache Instance %s" % ( repr(settingname), repr(actualvalue), repr(cacheInstance_id), ))

def printJ2EEResourcePropertySet(resourceId):
    propset = AdminConfig.list("J2EEResourcePropertySet", resourceId )
    print "----"
    print "printJ2EEResourcePropertySet(): "
    print "----" 
    if propset is None or propset == "":
        if propset is None:
            print "propset is NONE" 
        else:
            print "propset is \"\""
    else:
        for psItem in _splitlines(AdminConfig.list("J2EEResourceProperty", propset)):
            #print "psItem = " + psItem
            name = AdminConfig.showAttribute(psItem, "name")
            value = AdminConfig.showAttribute(psItem, "value")
            print name + " = " + value
        #endFor
    
    print "----"
    

# Function for creating resource custom properties
def createResourceCustomProperty(envEntry, propName, propValue):
    m = "createResourceCustomProperty"
    sop(m,"Entry: envEntry=%s propName=%s propValue=%s" % (envEntry, propName, propValue))
    propSet = AdminConfig.showAttribute(envEntry, 'propertySet') 
    if propSet == None:
        propSet = AdminConfig.create('J2EEResourcePropertySet',envEntry,[])

    name = ['name', propName]
    value = ['value', propValue]
    propAttrs = [name, value]

    modifiedOne = 0 
    if propSet != "":
            for psItem in _splitlines(AdminConfig.list("J2EEResourceProperty", propSet)):
                name = AdminConfig.showAttribute(psItem, "name")
                value = AdminConfig.showAttribute(psItem, "value")
                #print name + " = " + value
                if (propName == AdminConfig.showAttribute(psItem, "name")):
                    sop(m, "Modifying J2EEResourceProperty [%s , %s]" % (propName, propValue))                      
        	    try:
        	        AdminConfig.modify(psItem, [["value", propValue]])
        	    except AdminException, e:
        	        TR.error(m,"Exception modifying custom property: %s" % e, e)
                        sys.exit(0)
        	    #endTry
                       
                    modifiedOne = 1
                    #break
                #endIf
            #endFor

    if (not modifiedOne):
        sop(m, "Creating J2EEResourceProperty [%s , %s]" % (propName, propValue))
	try:
	    AdminConfig.create('J2EEResourceProperty', propSet, propAttrs)
	except AdminException, e:
	    TR.error(m,"Exception adding cell custom property: %s" % e, e)
            sys.exit(0)
	#endTry
    
    return


# Function for creating resource custom properties
def removeResourceCustomProperty(envEntry, propName):
    m = "removeResourceCustomProperty"
    sop(m,"Entry: envEntry=%s propName=%s" % (envEntry, propName))
    propSet = AdminConfig.showAttribute(envEntry, 'propertySet') 
    if propSet == None or propSet == "":
        return

    for psItem in _splitlines(AdminConfig.list("J2EEResourceProperty", propset)):
        name = AdminConfig.showAttribute(psItem, "name")
        value = AdminConfig.showAttribute(psItem, "value")
        print name + " = " + value
        if (propName == AdminConfig.showAttribute(psItem, "name")):
            sop(m, "Removing J2EEResourceProperty [%s]" % (propName))                      
	    try:
	        AdminConfig.remove(psItem)
	    except AdminException, e:
	        TR.error(m,"Exception removing custom property: %s" % e, e)
                sys.exit(0)
	    #endTry
               
            #break
        #endIf
    #endFor
    return



def createCellCustomProperty( cellId, name, value ):

	methodName = "createCellCustomProperty"

	# Check if custom property already exists	
	propList = AdminConfig.showAttribute(cellId, "properties")
	propList = propList [ 1:len(propList)-1].split(" ")
	modifiedOne = 0
	if (propList != ['']):
		for item in propList:
			itemName = AdminConfig.showAttribute(item, "name")
			if (itemName == name):
				modifiedOne = 1
				try:
					AdminConfig.modify(item, [["value", value]])
					TR.info( methodName, "Modified value of %s to %s." % (name, value))
				except AdminException, e:
					TR.error(methodName,"Exception modifying Cell custom property: %s" % e, e)
					sys.exit(0)
				#endTry
				break
			#endIf
		#endFor
	#endIf

	if (not modifiedOne):
		# create new property
		attrs = []
		attrs.append(["name", name])
		attrs.append(["value", value])
		try:
			AdminConfig.create("Property", cellId, attrs)
			TR.info( methodName, "Created new property with name and value of %s and %s." % (name, value))
		except AdminException, e:
			TR.error(methodName,"Exception adding cell custom property: %s" % e, e)
			sys.exit(0)
		#endTry
	#endIf
#endDef



def setCustomProperty( targetId, propertyName, propertyValue ):
    """Enables seamless failover on the specified targetName (in this cell)."""
    attrs = []
    attrs.append( [ 'name', propertyName ] )
    attrs.append( [ 'value', propertyValue ] )
    removeAndCreate('Property', targetId, attrs, ['name'], 'customProperties')


def createUserCustomProperty( targetId, name, value ):
    #jvm = getServerJvm(nodename,servername)
    attrs = []
    attrs.append( [ 'name', name ] )
    attrs.append( ['value', value] )
    return removeAndCreate('Property', targetId, attrs, ['name'])

#-------------------------------------------------------------------------------------------------
# Create  custom property
#-------------------------------------------------------------------------------------------------
def createCustomProperty (webContainerConfigID, customPropertyName, customPropertyDescription, customPropertyValue, customPropertyRequired ):
   createCounter = 0
   wwString = '[[name "' + str(customPropertyName) +                 '"] [description "' + str(customPropertyDescription) +      '"] [value "' + str(customPropertyValue) + '"] [required "' + str(customPropertyRequired) + '"]]'
   print "wwString: " + str(wwString)

   try: 
      AdminConfig.create('Property', webContainerConfigID, str(wwString)) 
      createCounter = createCounter + 1
   except:
      print " " * indentCount, "Create Web Container custom property " +  str(customPropertyName) + " failed."

   return createCounter

#-------------------------------------------------------------------------------------------------
# edit  custom property
#-------------------------------------------------------------------------------------------------
def editCustomProperty ( cpTarget, cpName, cpDesc, cpValue, cpRequired ):
	#    cpScope     - JVM Custom property scope
	#    cpName      - Name of Custom Property
	#    cpDesc      - Description of Custom Property
	#    cpValue     - Value of the Custom Property
        
        # Check to see if the property exists already (in a true iPAS environment this might never occur)
        propertyList = AdminConfig.list("Property",cpTarget)
        actionType = "create" 
        for prop in propertyList.split("\n"):
            thisProp = prop.rstrip()
            if (thisProp.find(cpName) == 0):
                pStart = thisProp.find('(')
	        propertyMap = thisProp[pStart:] 
                actionType = "modify"
            #endIf
        #endFor


	#jvmMap = AdminConfig.list('JavaVirtualMachine',server)
        
        attrName = ["name", cpName]
        attrDesc = ["description", cpDesc]
        attrValue = ["value", cpValue]
        attrRequired = ["required", cpRequired]

        attrs = [attrName, attrDesc, attrValue, attrRequired]

        if (actionType == "create"):
            print "Create a NEW custom property"
	    #newProperty = AdminConfig.create("Property", jvmMap, attrs )
            newProperty = AdminConfig.create("Property", cpTarget, attrs )
        else:
       	    print "Modify the existing custom property"
            newProperty = AdminConfig.modify(propertyMap, attrs )
        #endElse
        
        print "Custom Property " + cpName + " created successfully!"

#-----------------------------------------------------------------
# createJVMCustomProperty - Create a JVM customer property 
#                           definition to a Server.
#            
#-----------------------------------------------------------------
def createJVMCustomProperty ( cpTarget, cpName, cpDesc, cpValue, cpRequired ):
	#    cpScope     - JVM Custom property scope
	#    cpName      - Name of Custom Property
	#    cpDesc      - Description of Custom Property
	#    cpValue     - Value of the Custom Property


	print " "
	print "Creating Custom JVM Property " + cpName + "..."

        # Cycle through each server node to add the JVM Custom property too... 

	serverList=AdminConfig.list("Server")
	newProperty = ""

	if (len(serverList) > 0):
		for item in serverList.split("\n"):
			server = item.rstrip()
			if (server.find(cpTarget) >= 0):
                                print "SERVER FOUND: " + server

                                # Check to see if the property exists already (in a true iPAS environment this might never occur)
                                propertyList = AdminConfig.list("Property",server)
                                actionType = "create" 
                                for prop in propertyList.split("\n"):
                                    thisProp = prop.rstrip()
                                    if (thisProp.find(cpName) == 0):
                                        pStart = thisProp.find('(')
	                                propertyMap = thisProp[pStart:] 
                                        actionType = "modify"
                                    #endElse
                                #endFor


				jvmMap = AdminConfig.list('JavaVirtualMachine',server)

                 		print "  Name:           " + cpName
		                print "  Description:    " + cpDesc
		                print "  Value:          " + cpValue
                                print "  JVM:            " + jvmMap

                                attrName = ["name", cpName]
                                attrDesc = ["description", cpDesc]
                                attrValue = ["value", cpValue]
                                attrRequired = ["required", cpRequired]

                     		attrs = [attrName, attrDesc, attrValue, attrRequired]

                                if (actionType == "create"):
       	     	                      print "Create a NEW custom property"
	     	                      newProperty = AdminConfig.create("Property", jvmMap, attrs )
                                else:
       	     	                      print "Modify the existing custom property"
                                      newProperty = AdminConfig.modify(propertyMap, attrs )
                                #endElse
			#endIf
		#endFor
	#endIf

        print "Custom Property " + cpName + " created successfully!"
	
	return newProperty 
#endDef

############################################################
#  remove cache instances methods
############################################################

def removeObjectCacheInstance(scopeobjectid, targetName):
    """remove Object cache instance"""
    scope = _getObjectScope(scopeobjectid)
    print "----------------------------------"
    print "Removing Object Cache Instance: " + targetName + " from scope: " + scope
    cache_ids = _splitlines(AdminConfig.list( 'ObjectCacheInstance' ))
    removedCacheName = ""
    for id in cache_ids:
        cacheName = AdminConfig.showAttribute( id, "name" )
        if cacheName == targetName:
            idscope = _getObjectScope(id)
            if scope == idscope:
                #print "scope == idscope: scope="+ scope + ", idscope="+idscope  
                AdminConfig.remove(id)
                removedCacheName = targetName
                break    

    if removedCacheName == targetName:
        print "removed object cache instance: " + targetName
    else:
        print "Target object cache instance is not found"

    print "----------------------------------"

def removeServletCacheInstance(scopeobjectid, targetName):
    """remove Servlet cache instance"""
    scope = _getObjectScope(scopeobjectid)
    print "----------------------------------"
    print "Removing Servlet Cache Instance: " + targetName + " from scope: " + scope
    cache_ids = _splitlines(AdminConfig.list( 'ServletCacheInstance' ))
    removedCacheName = ""
    for id in cache_ids:        
        cacheName = AdminConfig.showAttribute( id, "name" )
        if cacheName == targetName:
            idscope = _getObjectScope(id)
            if scope == idscope:
                #print "scope == idscope: scope="+ scope + ", idscope="+idscope  
                AdminConfig.remove(id)
                removedCacheName = targetName
                break    
            
    if removedCacheName == targetName:
        print "removed servlet cache instance: " + targetName
    else:
        print "Target servlet cache instance is not found"
            
    print "----------------------------------"
