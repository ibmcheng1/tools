OPT_DEPLOY_JAR_PACKAGE_PATH="/opt/db2/V10.0.1"
JAR_PACKAGE_ZIP_NAME="db2jars.zip"

# This is a file that is used to test if jcc jas been installed to
# that location.
JAR_INSTALLED_FILENAME="db2jcc.jar"

# Where the script executes. This is where the application system lays down
# the script package
SCRIPT_EXECUTE_PATH="/tmp/db2drivers/"

echoThis()
{
  timestamp=""
  if [[ "$platform" == 'Linux' ]]; then 
     timestamp=`date --rfc-3339=seconds`
  elif [[ "$platform" == 'AIX' ]]; then  
     timestamp=` date +"%Y-%H-%d %r %Z"`
  fi 
  echo "[$timestamp] $@"
  echo "[$timestamp] $@" > /dev/stderr
}

platform='unknown' 
unamestr=`uname` 
if [[ "$unamestr" == 'Linux' ]]; then 
   platform='linux' 
elif [[ "$unamestr" == 'AIX' ]]; then    
   platform='AIX' 
fi

echoThis "Include standard environment variables"
set -x
echo "DB2UNIVERSAL_JDBC_DRIVER_PATH=/opt/db2/V10.0.1" >> /etc/virtualimage.properties
if [[ "$platform" == 'Linux' ]]; then 
  source /etc/virtualimage.properties
elif [[ "$platform" == 'AIX' ]]; then    
  . /etc/virtualimage.properties
fi
set -
echo

# Change the permissions. This is necessary because it is unzipped as virtuser.
if [ ! -f $OPT_DEPLOY_JAR_PACKAGE_PATH$JAR_INSTALLED_FILENAME ] 
then
   # install the JAR libraries if we have not already done so
   echoThis "Make the zip file very executable"
   set -x
   chmod 777 $SCRIPT_EXECUTE_PATH$JAR_PACKAGE_ZIP_NAME
   set -
   echo
fi

USER1000=`cat /etc/passwd | grep ":1000:" | cut -d : -f 1` 

# Install to the location expected by Websphere
if [ ! -f $OPT_DEPLOY_JAR_PACKAGE_PATH$JAR_INSTALLED_FILENAME ]
then
   echoThis "Creating V10.0.1 directory"
   mkdir /opt/db2
   mkdir $OPT_DEPLOY_JAR_PACKAGE_PATH
   chmod -R 777 $OPT_DEPLOY_JAR_PACKAGE_PATH
   ls -l $OPT_DEPLOY_JAR_PACKAGE_PATH
   echoThis "Extract the driver jars to Websphere directory: "$OPT_DEPLOY_JAR_PACKAGE_PATH
   set -x
   sudo -u $USER1000 unzip $UNZIP_OPTIONS -d $OPT_DEPLOY_JAR_PACKAGE_PATH $SCRIPT_EXECUTE_PATH$JAR_PACKAGE_ZIP_NAME
   set -
   echo
fi
