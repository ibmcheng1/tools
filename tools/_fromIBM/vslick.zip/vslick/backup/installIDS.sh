#!/bin/sh
echo ======================================
echo running installIDS.sh
echo ======================================

echo "------------------------------------------"
echo ENV_CONFIG_FILE=$ENV_CONFIG_FILE
echo "------------------------------------------"
if [ -f $ENV_CONFIG_FILE ]; then
  . $ENV_CONFIG_FILE
else
  echo "ERROR: ENV_CONFIG_FILE=${ENV_CONFIG_FILE} is not found"
  exit 1
fi

echo SOFTWARE_REPOSITORY=$SOFTWARE_REPOSITORY
echo IBMIM_installationDirectory=$IBMIM_installationDirectory
echo IBMIM_sharedResourcesDirectory=$IBMIM_sharedResourcesDirectory
echo IDS_SOFTWARE_PACKAGE=$IDS_SOFTWARE_PACKAGE
echo IDS_SOFTWARE_PATH=$IDS_SOFTWARE_PATH
echo IDS_INSTALL_RESPONSE_FILE=$IDS_INSTALL_RESPONSE_FILE

if [ ! -d $IBMIM_installationDirectory ]; then
   echo "Error: $IBMIM_installationDirectory does not exist."
   exit 1
fi

# GLPINS005E Error - Cannot run program idsLicense installing SDS 6.3.1
# Note: in Linux, the ksh is required to install IDS,  
# use this command to install ksh: yum install ksh

cd ${IBMIM_installationDirectory}/eclipse/tools

./imcl input ${IDS_SOFTWARE_PATH}/SilentInstallScripts/${IDS_INSTALL_RESPONSE_FILE} -log ${WORKING_DIR}/ids_silent_install_response.xml.log -acceptLicense -showProgress

echo ======================================
echo end of installIDS.sh
echo ======================================
