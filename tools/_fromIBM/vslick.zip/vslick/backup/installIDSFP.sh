#!/bin/ksh
# This script is intended to work on Linux with bash shell or AIX with ksh.
# Be sure to set the first line of the script appriately for the platform where
# it will be run.
#
#########################################################################

# When debugging on IPAS, source the virtualimage.properties
if [ -f /etc/virtualimage.properties ]; then
  . /etc/virtualimage.properties
fi

# temporary assign variable values.
IDS_INSTALL_PATH=/opt/IBM/ldap/V6.3.1
INSTANCE_NAME=ldapdb2
IDS_FP_PATH=/repository/downloads/fixes/ids/v6.3.1.8
 
WORKING_DIR=`pwd`

echo WORKING_DIR=$WORKING_DIR
echo IDS_INSTALL_PATH=$IDS_INSTALL_PATH

export WORKING_DIR
export IDS_INSTALL_PATH
export INSTANCE_NAME
export IDS_INSTALL_PATH

echo ======================================
echo Displaying current version information
echo ======================================
lslpp -l 'idsldap*'
${IDS_INSTALL_PATH}/idstools/deploy_IDSWebApp -v
${IDS_INSTALL_PATH}/java/bin/java -version
lslpp -l GSKit8*

echo ======================================
echo stopping IDS related processes
echo ======================================
${IDS_INSTALL_PATH}/sbin/ibmslapd -I $INSTANCE_NAME -k
${IDS_INSTALL_PATH}/sbin/ibmdiradm -I $INSTANCE_NAME -k
${IDS_INSTALL_PATH}/appsrv/profiles/TDSWebAdminProfile/bin/stopServer.sh server1

echo ======================================
echo Verifying IDS related processes
echo ======================================
#ps -ef | grep $INSTANCE_NAME
#ps -ef | grep server1
ps -ef | grep $IDS_INSTALL_PATH


echo ======================================
echo installing java FP
echo ======================================
cd ${IDS_INSTALL_PATH}
mv java java_old
tar -xvf ${IDS_FP_PATH}/6.0.16.0-ISS-JAVA-AIX-FP0000.tar

echo ======================================
echo verifying java version
echo ======================================
${IDS_INSTALL_PATH}/java/bin/java -version

echo ======================================
echo installing GSKIT FP
echo ======================================
# in NFS server, use the following command to extract GSKIT from tar.gz  
#   gunzip -c 8.0.50.34-ISS-GSKIT-AIX-FP0034.tar.gz | tar -xvf -
# this command will create 8.0.50.34-ISS-GSKIT-AIX-FP0034 folder.
 
cd ${IDS_FP_PATH}/8.0.50.34-ISS-GSKIT-AIX-FP0034 
ls -l

slibclean
installp -acXgYd . GSKit8

echo ======================================
echo verifying GSKIT
echo ======================================

lslpp -l GSKit8*
 
echo ======================================
echo installing IDS FP
echo ======================================
# in NFS server, use the following command to extract IDS from tar.gz  
#   gunzip -c 6.3.1.8-ISS-ISDS-AIX-IF0008.tar.gz | tar -xvf -
# this command will create 6.3.1.8-ISS-ISDS-AIX-IF0008 folder

cd ${IDS_FP_PATH}/6.3.1.8-ISS-ISDS-AIX-IF0008
license/idsLicense -q 
./idsinstall -u -f

echo ======================================
echo verifying IDS FP
echo ======================================

lslpp -l 'idsldap*' 

echo ======================================
echo Update Web Administration Tool
echo ======================================
# If the Web Administration Tool was updated, use the deploy_IDSWebApp script
# to do the following:
#    - Remove the previous Web Administration Tool (the IDSWebApp.war file) from
#      the embedded version of WebSphere Application Server - Express (the application server)
#    - Deploy the updated Web Administration Tool into the embedded version of WebSphere Application Server - Express
#    - Start the Application Server

cd ${IDS_INSTALL_PATH}/idstools
./deploy_IDSWebApp


# ./deploy_IDSWebApp -w <path_to_war_file> -p <emb_WAS_installed_path>
#    <path_to_war_file> is the fully qualified file path to the IDSWebApp.war file
#        that is being deployed. If not specified, this path defaults to
#        <LDAPHome>\idstools\IDSWebApp.war. The old IDSWebApp.war file (in
#        <emb_WAS_installed_path>\installableApps\) is renamed to
#        IDSWebApp.war_bkup_mm-dd-yy_HH-MM-SS before the new IDSWebApp.war file is
#        copied to <emb_WAS_installed_path>\installableApps\.
#
#    <emb_WAS_installed_path> is the fully qualified file path to the installed
#        embedded version of WebSphere Application Server- Express. If not specified,
#        this path defaults to <LDAPHome>/appsrv.
# ls -l ${IDS_INSTALL_PATH}/appsrv/installableApps
# ls -l ${IDS_INSTALL_PATH}/idstools


echo ======================================
echo starting IDS related processes
echo ======================================
cd ${IDS_INSTALL_PATH}/sbin 
${IDS_INSTALL_PATH}/sbin/ibmslapd -I $INSTANCE_NAME
${IDS_INSTALL_PATH}/sbin/ibmdiradm -I $INSTANCE_NAME
${IDS_INSTALL_PATH}/appsrv/profiles/TDSWebAdminProfile/bin/startServer.sh server1

echo ======================================
echo Displaying current version information
echo ======================================
lslpp -l 'idsldap*'
${IDS_INSTALL_PATH}/idstools/deploy_IDSWebApp -v
${IDS_INSTALL_PATH}/java/bin/java -version
lslpp -l GSKit8*
${IDS_INSTALL_PATH}/appsrv/bin/versionInfo.sh
