#!/bin/ksh

# ideally, the hosts should be host names, not ip address.
# For now, manually edit this CUSTOMNODE_HOSTS variable for each environment 
export CUSTOMNODE_HOSTS="cscertstcdc124.cdc-dc1.cscehub.com"
export DMGR_HOST="cscertstcdc123.cdc-dc1.cscehub.com"

export WORKING_DIR=${PWD}
echo WORKING_DIR=$WORKING_DIR
echo "---------------------------------"
export WAS_DMGR_PROFILE_ROOT=/opt/IBM/WebSphere/Profiles/DefaultDmgr01
export WAS_CUSTOMNODE_PROFILE_ROOT=/opt/IBM/WebSphere/Profiles/DefaultCustom01
export CURRENT_HOST=`hostname`

echo CURRENT_HOST=$CURRENT_HOST
echo WAS_DMGR_PROFILE_ROOT=$WAS_DMGR_PROFILE_ROOT
echo WAS_CUSTOMNODE_PROFILE_ROOT=$WAS_CUSTOMNODE_PROFILE_ROOT
echo CUSTOMNODE_HOSTS=$CUSTOMNODE_HOSTS

echo "------------------------------------"
echo "Starting Deployment Manager ...     "
echo "------------------------------------"
#$WAS_DMGR_PROFILE_ROOT/bin/startManager.sh

if [[ ${CURRENT_HOST} == $DMGR_HOST ]]; then
    echo "current host is DMGR host"
    $WAS_DMGR_PROFILE_ROOT/bin/startManager.sh
else
    echo "current host is NOT DMGR host. ssh to DMGR."
    ssh $DMGR_HOST "$WAS_DMGR_PROFILE_ROOT/bin/startManager.sh" &
fi

echo "------------------------------------"
echo "Starting Custom Nodes ...     "
echo "------------------------------------"

for host in $CUSTOMNODE_HOSTS
do
  echo "starting WAS custom node on $host"
  if [[ ${CURRENT_HOST} == *$host* ]]; then
      $WAS_CUSTOMNODE_PROFILE_ROOT/bin/startNode.sh &
  else
      ssh $host "$WAS_CUSTOMNODE_PROFILE_ROOT/bin/startNode.sh" &
  fi
done


echo "Sleep 20 seconds ..."
sleep 3

echo "------------------------------------"
echo "Checking WAS processes ...     "
echo "------------------------------------"

#ps -ef | grep dmgr

if [[ ${CURRENT_HOST} == $DMGR_HOST ]]; then
    echo "current host is DMGR host"
    ps -ef | grep dmgr
else
    echo "current host is NOT DMGR host. ssh to DMGR."
    ssh $DMGR_HOST "ps -ef | grep dmgr"
fi

for host in $CUSTOMNODE_HOSTS
do
  if [[ ${CURRENT_HOST} == *$host* ]]; then
      ps -ef | grep nodeagent
  else
      ssh $host "ps -ef | grep nodeagent"
  fi
done



