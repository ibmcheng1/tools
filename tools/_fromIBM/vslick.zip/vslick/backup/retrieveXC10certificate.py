import sys

#---------------------------------------------------------------------
#  Parse Command Line
#---------------------------------------------------------------------

cachingHost = "172.31.200.10"
print "Caching Host: "+cachingHost

#-----------------------------------------------------------------
#  Retrieve XC10 signer certificate
#-----------------------------------------------------------------

print "Retrieve XC10 signer certificate for Dmgr node"
AdminTask.retrieveSignerFromPort('[-keyStoreName CellDefaultTrustStore -keyStoreScope (cell):CloudBurstCell_1 -host '+cachingHost+' -port 443 -certificateAlias cachingAlias -sslConfigName CellDefaultSSLSettings -sslConfigScopeName (cell):CloudBurstCell_1 ]')
	
print "Saving config"
AdminConfig.save( )
