#!/bin/sh

echo program arguments: $@

export CLASSPATH="${WORKING_DIR}:${OBJECTGRID_ROOT}/lib/*:${WORKING_DIR}/properties:${WORKING_DIR}/lib/*" 
export PACKAGE=com.ibm.ws.objectgrid.test.scenario
export CLASS=${PACKAGE}.WXSDataServiceDriver

export output=${1}_${2}_${3}.log

echo $CLASSPATH
echo $PACKAGE
echo $CLASS
echo $output

${JAVA_HOME}/bin/java -Xms2048m -Xmx4096m -cp $CLASSPATH $CLASS $@
