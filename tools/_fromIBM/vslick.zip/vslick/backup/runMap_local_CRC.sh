#!/bin/sh

fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

echo catalogServiceEndPoints=$catalogServiceEndPoints
echo objectgridName=$objectgridName
echo mapName=$mapName

OBJECTGRID_FILE=xml/objectgrid-CRC.xml

usingLocalOG -objectgridFile=$OBJECTGRID_FILE 

loop=10
size=96000   

# autoThreadsMode
./runDriver.sh -usingLocalOG -objectgridFile $OBJECTGRID_FILE -autoThreadsMode -maxNumberOfThreads 16 -loop $loop -size $size -objectgridName $objectgridName -mapName $mapName
