set WAS_HOME=c:\was61
call %WAS_HOME%\bin\manageprofiles -augment -profileName Dmgr02 -templatePath %WAS_HOME%\profileTemplates\xs_augment\dmgr
call %WAS_HOME%\bin\manageprofiles -augment -profileName AppSrv02 -templatePath %WAS_HOME%\profileTemplates\xs_augment\default
