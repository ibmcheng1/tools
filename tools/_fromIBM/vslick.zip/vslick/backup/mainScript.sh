#!/bin/ksh

if [ -f /etc/virtualimage.properties ]; then
  . /etc/virtualimage.properties
fi

# WAS_USER and WAS_PASSWORD variable should be available in /etc/virtualimage.properties
#
ENV_CONFIG_PATH=/repository/ipas/deployment/uat/er_setup
ENV_CONFIG_FILE_NAME=env_config.properties
WAS_USER=wswuser
WAS_PASSWORD=passw0rd

export WORKING_DIR=${PWD}
chmod a+x ${WORKING_DIR}/*.sh
echo WORKING_DIR=$WORKING_DIR

echo "---------------------------------"
echo "Parameters from /etc/virtualimage.properties"
echo "---------------------------------"
echo WAS_INSTALL_ROOT=$WAS_INSTALL_ROOT
echo WAS_PROFILE_ROOT=$WAS_PROFILE_ROOT
export WAS_INSTALL_ROOT
export WAS_PROFILE_ROOT 
echo ENV_CONFIG_PATH=$ENV_CONFIG_PATH
echo ENV_CONFIG_FILE_NAME=$ENV_CONFIG_FILE_NAME
export ENV_CONFIG_FILE=${ENV_CONFIG_PATH}/${ENV_CONFIG_FILE_NAME}
echo ENV_CONFIG_FILE=$ENV_CONFIG_FILE
echo "---------------------------------"

ls -l ${ENV_CONFIG_PATH}

echo "---------------------------"
echo "copy all configuration files from ENV_CONFIG_PATH to WORKING directory"
echo "---------------------------"
cp -r ${ENV_CONFIG_PATH}/* $WORKING_DIR
chmod a+x ${WORKING_DIR}/*.sh

if [ -f $ENV_CONFIG_FILE ]; then
  . $ENV_CONFIG_FILE
else
  echo "ERROR: ENV_CONFIG_FILE=${ENV_CONFIG_FILE} is not found"
  exit 1
fi

echo "---------------------------------"
echo "Parameters from $ENV_CONFIG_FILE"
echo "---------------------------------"
echo ENV_ID=$ENV_ID
echo WAS_USER=$WAS_USER
echo WAS_PASSWORD=$WAS_PASSWORD
echo WAS_USER_ldap=$WAS_USER_ldap
echo WAS_PASSWORD_ldap=$WAS_PASSWORD_ldap
echo "---------------------------------"
export ENV_ID
export WAS_USER
export WAS_PASSWORD
export WAS_USER_ldap
export WAS_PASSWORD_ldap
echo "---------------------------------"
export host=$WAS_DMGR_host
export port=$WAS_DMGR_SOAP_port
echo "---------------------------------"
echo host=$host
echo port=$port
echo "---------------------------------"

#./runWsadmin.sh retrieveXC10certificate.py ${cellName} ${cachingHost} 
#./runWsadmin.sh enableAppXC10SessionMgmt.jy ${appName} ${cachingHost} ${cachingUser} ${cachingPassword} ${cachingGrid}
#./runWsadmin.sh AppUninstall.py ${appName}
#./runWsadmin.sh AppInstall.py ${appFileName} ${appName} ${appDisplayName} ${cellName} ${targetType} ${targetName} ${virtualHost}

${WORKING_DIR}/runWsadmin.sh main.py ER_config.py



