############################################################
### WAS Application Configuration Property file 
### Version 1.0.4
############################################################

#########################################################################################################################################
### USAGE NOTES:
###
### Do not DELETE any nnnnn_LIST arrays from this configuration file.
###
### To DISABLE the execution of any given configuration option below, simply set the nnnnn_LIST array to EMPTY
###    i.e.   CREATECLUSTER_LIST = []
###
### A LIST can contain one or more configuration items seperated by a comma.  Copy the keyword section and rename the prefix to a 
### unique name to be added to the LIST.
###    i.e.  CREATECLUSTER_LIST = [ 'CLUSTER1', 'CLUSTER2', 'CLUSTER3' ]
###
### Do NOT EVER CHANGE the last part of the name on the variable collections,  
###    i.e. CREATEDC1_nodeGroupName  (the _nodeGroupName is the required variable name used in the configuration build scripts.)
### Only the first part should ever be changed, 
###    i.e. CREATEDC1_nodeGroupName (the CREATEDC1 can be called anything but must be unique within this file.)




#########################################################################################################################################
###   CREATE DYNAMIC CLUSTER CONFIGURATION
###
###   Used to create a Cluster on an empty WAS instance.
###   {uniqueListName}_nodeGroupName   - the name of the nodeGroup to create for this dynamic cluster
###   {uniqueListName}_nodePrefix      - node prefix name of the nodes you wish to add to the above node Group.  Generally will be "appNode"
###   {uniqueListName}_clusterName     - the name you wish to give to this cluster
###   {uniqueListName}_operationalMode - the operational mode for the dynamic cluster. Values: automatic | manual 
###
###  NOTE: USE EITHER DYNAMIC CLUSTERS OR STATIC, but NOT BOTH, if using DYNAMIC, the static CREATECLUSTER_LIST and CREATESERVER_LIST 
###  arrays should be empty.

CREATE_DYNAMIC_CLUSTER_LIST = []


### Parameter Collection for: DATASOURCE Property ###
CREATEDC1_nodeGroupName = "{clusterName}NodeGroup"
CREATEDC1_nodePrefix = "appNode"
CREATEDC1_clusterName = "{clusterName}"
CREATEDC1_operationalMode = "{mode}"




#########################################################################################################################################
###   CREATE STATIC CLUSTER CONFIGURATION  
###
###   Used to create a Cluster on an empty WAS instance. 
###   {uniqueListName}_Name        - the name to assign to the cluster you are creating. Format: name.Cluster
###   {uniqueListName}_Desc        - description to display for this cluster.
###   {uniqueListName}_preferLocal - Values: true|false  
###
###  NOTE: USE EITHER DYNAMIC CLUSTERS OR STATIC, but NOT BOTH, if using STATIC, the CREATE_DYNAMIC_CLUSTER_LIST array should be empty.


# CREATECLUSTER_LIST = ['CLUSTER1', 'CLUSTER2']
CREATECLUSTER_LIST = []

### Parameter Collection for: Create Clusters ###
CLUSTER1_Name = "wxs.catalog.Cluster"
CLUSTER1_Desc = "WXS Catalog Server Cluster"
CLUSTER1_preferLocal = "true"
CLUSTER2_Name = "wxs.Cluster"
CLUSTER2_Desc = "WXS Container Server Cluster"
CLUSTER2_preferLocal = "true"


###########################################################################################################################################
###   CREATE STATIC SERVER CONFIGURATION
###
###   Used to create a Server on an empty WAS instance and add to a Cluster.
###   {uniqueListName}_serverName        - the name to assign to the server you are creating. Format: name.Server
###   {uniqueListName}_clusterName       - list the cluster name you wish to add this server too.  Cluster should have been created above.
###   {uniqueListName}_memberWeight      - cluster member weight, the number of requests directed to an application server.  Values: 0 to 20 
###   {uniqueListName}_nodeGroup         - nodeGroup you want to build the servers in.  Use With Dynamic clusters only, it should match the nodeGroup defined there.  
###   {uniqueListName}_clusterStyle      - the style type of cluster being used: Values: statis | dynamic
###


CREATESERVER_LIST = ['CREATESERVER1']

### Parameter Collection for: Create Servers  ###
CREATESERVER1_serverName = "wxs.Server"
CREATESERVER1_clusterName = "wxs.Cluster"
CREATESERVER1_memberWeight = "1"
CREATESERVER1_nodeGroup = "DefaultNodeGroup"
CREATESERVER1_clusterStyle = "static"


###########################################################################################################################################
###   ORACLE DATASOURCE PROPERTIES
###
###   Used to configure all Oracle database connection properties used by the application.
###   {uniqueListName}_Alias                 - the name to assign to user alias, containing the database access (uid,password)
###   {uniqueListName}_DatasourceName        - display name for the data source.
###   {uniqueListName}_jndi                  - specifies the Java Naming and Directory Interface (JNDI) name 
###   {uniqueListName}_dbURL                 - the Oracle jdbc connection string: Syntax: jdbc:oracle:thin:@dBServerName.comfin.ge.com:dBPortNumber:dBName
###   {uniqueListName}_uid                   - the database schema userid 
###   {uniqueListName}_password              - the password for the schema userid
###   {uniqueListName}_providerType          - jdbc Provider type: Values: "Oracle" 
###   {uniqueListName}_XA                    - specify whether to use XA driver connection or not.  Values: true | false
###   {uniqueListName}_jdbcPathName          - directory path to the location of the Oracle jdbc driver 
###   {uniqueListName}_defaultNativePathName - 
###   {uniqueListName}_driverType            - jdbc driver access Type. Values: 2 | 4 
###   {uniqueListName}_targetCluster         - target cluster scope for this db connection
###   {uniqueListName}_stmtCacheSize         - specify the number of statements that can be cached per connection, typical default value is 10
###   {uniqueListName}_maxConnections        - database maximum connections for the pool
###   {uniqueListName}_minConnections        - database minimum connections for the pool 



ORACLE_DATASOURCE_LIST = []
#ORACLE_DATASOURCE_LIST = ['ORACLEDS1']

### Parameter Collection for: DATASOURCE creation ###
ORACLEDS1_Alias = "{aliasName}_ALIAS"
ORACLEDS1_DatasourceName = "{dataSourceName}"
ORACLEDS1_jndi = "jdbc/{jndiName}"
ORACLEDS1_dbURL = "jdbc:oracle:thin:@//{databaseServerName}.comfin.ge.com:{dBPortNumber}/{dBName|SID}"
ORACLEDS1_uid = "{dbSchemaName}"
ORACLEDS1_password = "{dBPassword}"
ORACLEDS1_providerType = "Oracle"
ORACLEDS1_XA = "true"
ORACLEDS1_jdbcPathName = "/opt/IBM/WebSphere/AppServer/lib/ext/ojdbc6.jar"
ORACLEDS1_defaultNativePathName = ""
ORACLEDS1_driverType = "4"
ORACLEDS1_targetCluster = "{clusterName}.Cluster"
ORACLEDS1_stmtCacheSize = "60"
ORACLEDS1_maxConnections = "30"
ORACLEDS1_minConnections = "10"




###########################################################################################################################################
###   MICROSOFT SQL SERVER DATASOURCE PROPERTIES
###
###   Used to configure all MS SQL Server database connection properties used by the application.
###   {uniqueListName}_Alias                 - the name to assign to user alias, containing the database access (uid,password)
###   {uniqueListName}_DatasourceName        - display name for the data source.
###   {uniqueListName}_jndi                  - specifies the Java Naming and Directory Interface (JNDI) name
###   {uniqueListName}_uid                   - the database schema userid
###   {uniqueListName}_password              - the password for the schema userid
###   {uniqueListName}_providerType          - jdbc Provider type: Values: "Oracle" | "Microsoft SQL Server"
###   {uniqueListName}_XA                    - specify whether to use XA driver connection or not.  Values: true | false
###   {uniqueListName}_jdbcPathName          - directory path to the location of the Oracle jdbc driver
###   {uniqueListName}_defaultNativePathName -
###   {uniqueListName}_driverType            - jdbc driver access Type. Values: 2 | 4
###   {uniqueListName}_targetCluster         - target cluster scope for this db connection
###   {uniqueListName}_stmtCacheSize         - specify the number of statements that can be cached per connection, typical default value is 10
###   {uniqueListName}_maxConnections        - database maximum connections for the pool
###   {uniqueListName}_minConnections        - database minimum connections for the pool
###   {uniqueListName}_dbName                - SQL Server database name 
###   {uniqueListName}_dbServerHostName      - database server host name. Example: serverName.comfin.ge.com\xxxxx
###   {uniqueListName}_dbServerPort          - database server port number




SQLSERVER_DATASOURCE_LIST = []
#SQLSERVER_DATASOURCE_LIST = ['SQLSERVERDS1']

### Parameter Collection for: SQL SERVER DATASOURCE creation  ###
SQLSERVERDS1_Alias = "{aliasName}_ALIAS"
SQLSERVERDS1_DatasourceName = "{dataSourceName}"
SQLSERVERDS1_jndi = "jdbc/{jndiName}"
SQLSERVERDS1_uid = "{dbSchemaName}"
SQLSERVERDS1_password = "{dBPassword}"
SQLSERVERDS1_providerType = "Microsoft SQL Server"
SQLSERVERDS1_XA = "true"
SQLSERVERDS1_jdbcPathName = "/opt/IBM/WebSphere/AppServer/lib/ext/sqljdbc4.jar"
SQLSERVERDS1_defaultNativePathName = ""
SQLSERVERDS1_driverType = "4"
SQLSERVERDS1_targetCluster = "{clusterName}.Cluster"
SQLSERVERDS1_stmtCacheSize = "60"
SQLSERVERDS1_maxConnections = "30"
SQLSERVERDS1_minConnections = "10"
SQLSERVERDS1_dbName = "{databaseName}"
SQLSERVERDS1_dbServerHostName = "VIPALGAD04SQL01.comfin.ge.com\DEVINST01"
SQLSERVERDS1_dbServerPort = "1633"



###########################################################################################################################################
###   JVM PROPERTY CONFIGURATION
###
###   Used to configure all JVM settings for your application servers.
###   {uniqueListName}_NodeName         - WAS nodename of the jvm you want to update properties for
###   {uniqueListName}_ServerName       - WAS server name of the server you want to update
###   {uniqueListName}_ClassPath        - specifiy all custom classpath settings to add the to JVM
###   {uniqueListName}_MinHeap          - specify the Minumum heap size for the JVM memory
###   {uniqueListName}_MaxHeap          - specify the Maximum heap size for the JVM memory (limit to 2048 on 32 bit servers)
###   {uniqueListName}_Generic          - specify all generic jvm arguments to apply at startup time
###   {uniqueListName}_VerboseModeClass - specify whether to use verbose debug output for class loading.  Values: true | false
###   {uniqueListName}_VerboseGC        - set verbose garbage collection. Values: true | false 
###   {uniqueListName}_VerboseJNI       - specify whether to use verbose debug output for native method invocation. Values: true | false
###
###  Note: Each server node must have its own JVM properties collection defined below.  
###        This is not at the cluster level but the server level.


JVM_PROPERTY_LIST = [ ]

### Parameter Collection for: JVM Properties ###
JVM_PROPERTY1_NodeName = ""
JVM_PROPERTY1_ServerName = ""
JVM_PROPERTY1_ClassPath = ""
JVM_PROPERTY1_MinHeap = ""
JVM_PROPERTY1_MaxHeap = ""
JVM_PROPERTY1_Generic = ""
JVM_PROPERTY1_VerboseModeClass = "false"
JVM_PROPERTY1_VerboseGC = "false"
JVM_PROPERTY1_VerboseJNI = "false"


### Parameter Collection for: JVM Properties ###
JVM_PROPERTY2_NodeName = ""
JVM_PROPERTY2_ServerName = ""
JVM_PROPERTY2_ClassPath = ""
JVM_PROPERTY2_MinHeap = ""
JVM_PROPERTY2_MaxHeap = ""
JVM_PROPERTY2_Generic = ""
JVM_PROPERTY2_VerboseModeClass = "false"
JVM_PROPERTY2_VerboseGC = "false"
JVM_PROPERTY2_VerboseJNI = "false"


###########################################################################################################################################
###   JVM CUSTOM PROPERTY CONFIGURATION
###
###   Used to configure all JVM custom property settings for your application servers.
###   {uniqueListName}_Target     - WAS servername  to apply custom property to.
###   {uniqueListName}_Name       - specify the name of the custom property
###   {uniqueListName}_Desc       - specifiy the description text for the property
###   {uniqueListName}_Value      - specify the value to be given to this custom property
###   {uniqueListName}_required   - can be left blank (default) 
###
###  Note: Each server node must have its own JVM properties collection defined below.
###        This is not at the cluster level but the server level.



JVM_CUSTOMPROPERTY_LIST = [ ]

### Parameter Collection for: Custom JVM Properties ###
JVM_CUSTOMPROP1_Target = ""
JVM_CUSTOMPROP1_Name = ""
JVM_CUSTOMPROP1_Desc = ""
JVM_CUSTOMPROP1_Value = ""
JVM_CUSTOMPROP1_required = ""



###########################################################################################################################################
###   URL CONFIGURATION
###
###   Used to configure all JVM custom property settings for your application servers.
###   {uniqueListName}_Target     - WAS Cluster name to apply custom property to.
###   {uniqueListName}_Name       - specify the unique name of the URL property
###   {uniqueListName}_jndiName   - specifiy the jndi name used to reference this URL
###   {uniqueListName}_Desc       - specify the description for this url setting
###   {uniqueListName}_Spec       - specify the file specification to the location of the property file to source. FORMAT: "file:{directoryPath}/{filename}"
###


URL_LIST = []

### URL definition for thor.properties ###
URL_ENDPT_Target = "THOR.Cluster"
URL_ENDPT_Name = "dynamic_web_url_thor_properties"
URL_ENDPT_jndiName = "jndi_dynamic_web_url_thor_properties"
URL_ENDPT_Desc = "THOR Properties file"
URL_ENDPT_Spec = "file:/opt/GE-AppFolder/THOR/thor.properties"



###########################################################################################################################################
###   LDAP SECURITY CONFIGURATION
###
###   Used to configure LDAP federated security on the WAS server.
###   {uniqueListName}_existingRealmName  - name of the existing realm Name to delete.  Default: defaultWIMFileBasedRealm
###   {uniqueListName}_newRealmName       - name to give to the new realm being created
###   {uniqueListName}_primaryAdminId     - primary LDAP bind id to use
###
###
###   {uniqueListName}_id             - specify the id name to give to this LDAP repository
###   {uniqueListName}_ldapServerType - specify the type of LDAP Server. Values: SUNONE |
###   {uniqueListName}_host           - specify the host name of the LDAP server to connect to
###   {uniqueListName}_port           - specify the LDAP server port number to communicate on
###   {uniqueListName}_bindDN         - specify the bind id to be used to search ldap
###   {uniqueListName}_bindPassword   - specify the bind password for the bind id
###   {uniqueListName}_certMapMode    - specify the cert map mode: Values: exactdn |
###   {uniqueListName}_ldapBaseEntryDN- specify the LDAP base entry distinguished name i.e. o=ge.com
###   {uniqueListName}_realmName      - specify the realm Name
###   {uniqueListName}_groupBaseEntry - specify the group base entry
###   {uniqueListName}_groupRelDN     - specify the group relative distinguished name
###   {uniqueListName}_personBaseEntry- specify the person base entry
###   {uniqueListName}_personRelDN    - specify the person relative distinguished name
###   {uniqueListName}_orgBaseEntry   - specify the organization base entry
###   {uniqueListName}_orgRelDN       - specify the organization relative distinguished name
###



RENAMEREALM_LIST = []

### RENAME EXISTING SECURITY REALM ###
RENAMEREALM1_existingRealmName = "defaultWIMFileBasedRealm"
RENAMEREALM1_newRealmName = "ldap.stage.corporate.ge.com"
RENAMEREALM1_primaryAdminId = "idmwpsadmin"


CREATELDAPREPOSITORY_LIST = []
#CREATELDAPREPOSITORY_LIST = ['STAGELDAP']

### CREATE LDAP REPOSITORY ###
STAGELDAP_id = "STAGE LDAP"
STAGELDAP_ldapServerType = "SUNONE"
STAGELDAP_host = "ldap.stage.corporate.ge.com"
STAGELDAP_port = "2392"
STAGELDAP_bindDN = "uid=idmwpsadmin,ou=special users,o=ge.com"
STAGELDAP_bindPassword = "1bmwp5"
STAGELDAP_certMapMode = "exactdn"
STAGELDAP_ldapBaseEntryDN = "o=ge.com"
STAGELDAP_realmName = "ldap.stage.corporate.ge.com"
STAGELDAP_groupBaseEntry = "ou=gessogroups,ou=groups,o=ge.com"
STAGELDAP_groupRelDN = "gessouid"
STAGELDAP_personBaseEntry = "o=ge.com"
STAGELDAP_personRelDN = "uid"
STAGELDAP_orgBaseEntry = "o=ge.com"
STAGELDAP_orgRelDN = "o;ou;dc;cn"


