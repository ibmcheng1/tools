#!/bin/sh

OBJECTGRID_ROOT=/Users/jian/og61_scenario1/wxs71/ObjectGrid
WORKING_DIR=/Users/jian/og61_scenario1/classes

CLASSPATH="$WORKING_DIR:$OBJECTGRID_ROOT/lib/objectgrid.jar"
PACKAGE=com.ibm.ws.objectgrid.test.scenario
CLASS=com.ibm.ws.objectgrid.test.scenario.DataServiceDriver

loop=20

size=60000   
threadLoad=3750
java -Xms1024m -Xmx1024m -cp $CLASSPATH $CLASS multiWorkerMode $threadLoad 
loop $loop size $size dataServiceType 5 mapType 5 actionListIndex 15
