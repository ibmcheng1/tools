#!/bin/sh

sed -i 's//8.0.0.4/g' /opt/ibm/mqsi/8.0.0.1/bin/mqsiprofile
