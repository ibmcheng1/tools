#!/bin/sh
fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

${OBJECTGRID_ROOT}/bin/xsadmin.sh -ch tesoawsxs05q.tbccorp.com -p 1099 -teardown c0,c1,c2,c3,c4,c4,c6,c7,c8,c9,c0,c11,c12,c13,c14,c15,cs1_0,cs1_1,cs1_2 -force

