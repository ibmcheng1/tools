#!/bin/sh

binDir=`dirname $0`
. "$binDir"/setupEnv.sh

if [ "$2" = "" ]
then
  REMOTE_LOC=`pwd`
else
  REMOTE_LOC=$2
fi

if [ -e $1 ]
then
for host in $HOSTS
  do
    echo "------------------- Copying $1 to $host at $REMOTE_LOC"
    
      if [[ ${CURRENT_HOST} == *$host* ]]; then
          echo "Skip CURRENT_HOST=$host"
      else
          scp -r "$1" $host:$REMOTE_LOC
      fi
  done
else
  echo "$1 does not exist"
fi