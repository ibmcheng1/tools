#!/bin/sh

fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

echo servletUrl=$servletUrl
echo objectgridName=$objectgridName
echo mapName=$mapName

loop=1
actionListIndex=3
size=16000
threadLoad=2000
startKeyIndex=0
options="-disableRunGC -print"

./runDriver.sh -caseServlet -loop $loop -actionListIndex $actionListIndex -size $size -multiWorkerMode $threadLoad -startKeyIndex $startKeyIndex -dataServiceType 3 -servletUrl $servletUrl -objectgridName $objectgridName -mapName $mapName $options
   
