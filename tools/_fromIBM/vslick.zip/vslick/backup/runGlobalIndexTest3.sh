#!/bin/bash

# TITLE runGlobalIndexTest Linux

WORKING_DIR=/downloads/globalindextest
OBJECTGRID_ROOT=/opt/IBM/WebSphere/eXtremeScale/ObjectGrid
JAVA_HOME=/opt/IBM/WebSphere/eXtremeScale/java/jre

CLASSPATH=$WORKING_DIR/globalIndexTest.jar:$OBJECTGRID_ROOT/lib/objectgrid.jar:$OBJECTGRID_ROOT/dynacache/lib/wxsdynacache.jar
CLASS=com.ibm.ws.objectgrid.test.index.globalindex.GlobalIndexTest

catalogServiceEndpoints=xsextsrv2.torolab.ibm.com:2809
objectGridName=DYNACACHE_REMOTE
mapName=IBM_DC_PARTITIONED_baseCache
indexName=DEPENDENCY_ID_INDEX

$JAVA_HOME/bin/java -Xmx4096m -cp $CLASSPATH $CLASS 
-catalogServiceEndpoints $catalogServiceEndpoints -objectGridName $objectGridName -mapName $mapName -indexName $indexName -getDataBySerialPartition


