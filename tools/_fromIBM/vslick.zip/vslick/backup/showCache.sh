#!/bin/sh

fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

"$OBJECTGRID_ROOT"/bin/xscmd.sh -c showQuorumStatus -cep $CATALOG_SERVICE_ENDPOINTS
"$OBJECTGRID_ROOT"/bin/xscmd.sh -c listHosts -cep $CATALOG_SERVICE_ENDPOINTS
"$OBJECTGRID_ROOT"/bin/xscmd.sh -c showPlacement -cep $CATALOG_SERVICE_ENDPOINTS
"$OBJECTGRID_ROOT"/bin/xscmd.sh -c routetable -cep $CATALOG_SERVICE_ENDPOINTS
"$OBJECTGRID_ROOT"/bin/xscmd.sh -c showMapSizes -cep $CATALOG_SERVICE_ENDPOINTS