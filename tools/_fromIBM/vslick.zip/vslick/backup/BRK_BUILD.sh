#BROKER=BRKDEV01
#QMGR=WMQDEV01
#BROKERONE=BRKDEV01
#BROKERTWO=BRKDEV02
#BROKERTWOHOST=oc5300764161.ibm.com
#BROKERONEHOST=oc5300764160.ibm.com
#DB2IP=192.168.80.1
#DPIP=127.0.0.1

echo BROKER=$BROKER 
echo QMGR=$QMGR 
echo BROKERONE=$BROKERONE 
echo BROKERTWO=$BROKERTWO 
echo BROKERONEHOST=$BROKERONEHOST
echo BROKERTWOHOST=$BROKERTWOHOST  
echo DB2IP=$DB2IP 
echo DPIP=$DPIP
echo DOMAIN=$DOMAIN

echo Appending network suffix to hostname......
export BROKERONEHOST=${BROKERONEHOST}.${DOMAIN}
export BROKERTWOHOST=${BROKERTWOHOST}.${DOMAIN} 

echo BROKERONEHOST=$BROKERONEHOST
echo BROKERTWOHOST=$BROKERTWOHOST  

#Not needing exposed, just for testing
DBUSER=db2inst1
DBUSERPW=passw0rd
DPCERTPORT=7075

#export BROKER
#export WMQDEV01
#export DB2IP
#export DBUSER
#export DBUSERPW


. /opt/ibm/mqsi/8.0.0.1/bin/mqsiprofile
. /opt/ibm/mqsi/8.0.0.2/bin/mqsiprofile

#Create the environment file for the system
sed -e "s/DATAPOWERIP/$DPIP/g" -e "s/DBIP/$DB2IP/g" -e "s/DATAPOWERCERTPORT/$DPCERTPORT/g" -e "s/BROKER_NAME/$BROKER/g" -e "s/WMQ_QMGR_NAME/$QMGR/g" /home/virtuser/WMB/scripts/environment.sh.template > /home/virtuser/WMB/scripts/environment.sh
chmod a+x /home/virtuser/WMB/scripts/environment.sh

echo Stopping $BROKER ......
mqsistop $BROKER

#This should be completed by pure
#echo Creating the broker ....
#echo mqsicreatebroker $BROKER -q $QMGR

#mqsicreatebroker $BROKER -q $QMGR
echo =======================================
echo Setup the Global Cache across brokers
sed -e "s/BROKERONE/$BROKERONE/g" -e "s/BROKERHOSTONE/$BROKERONEHOST/g" -e "s/BROKERTWO/$BROKERTWO/g" -e "s/BROKERHOSTTWO/$BROKERTWOHOST/g" /home/virtuser/WMB/scripts/tch_mb_dev_global_cache.xml.template > /home/virtuser/WMB/scripts/tch_mb_dev_global_cache.xml

mqsichangebroker "$BROKER" -b /home/virtuser/WMB/scripts/tch_mb_dev_global_cache.xml

echo ======================================
echo Createing execution groups .......
mqsistart $BROKER
#Allow time for the Broker to start - normally 1 minute is adequate.
#If this is not done then we have problems creating the execution
#groups as they time out.
sleep 1m
mqsicreateexecutiongroup "$BROKER" -e DeviceManagement
mqsicreateexecutiongroup "$BROKER" -e DPIManagementService
mqsicreateexecutiongroup "$BROKER" -e NotificationServices
mqsicreateexecutiongroup "$BROKER" -e PaymentInstrumentRegistration
mqsicreateexecutiongroup "$BROKER" -e PaymentTransactionService
mqsicreateexecutiongroup "$BROKER" -e LookupPAN
mqsicreateexecutiongroup "$BROKER" -e Admin

echo ======================================
echo Enable fix pack 2 capabilities.......
mqsistop "$BROKER"

#Enable FP2 capabilities
mqsichangebroker "$BROKER" -f all

mqsistart "$BROKER"

echo ======================================
echo Creating configurable services
/home/virtuser/WMB/scripts/createConfigurableServices.sh

echo ======================================
echo Enable security 
/home/virtuser/WMB/scripts/enableSecurity.sh

echo ======================================
echo Create required MQ Resources 
runmqsc "$QMGR" < /home/virtuser/WMB/scripts/QDefs.mqsc
mqsireload "$BROKER"

echo mqsichangeproperties "$BROKER" -e Admin -o ExecutionGroup -n soapNodesUseEmbeddedListener -v false
mqsichangeproperties "$BROKER" -e Admin -o ExecutionGroup -n soapNodesUseEmbeddedListener -v false

echo ======================================
echo Deploy BAR files 
cd /home/virtuser/WMB/barFiles
/home/virtuser/WMB/barFiles/deployBARFiles.sh
cd /home/virtuser/WMB/scripts

echo ======================================
echo Enable custom properties 

echo mqsisetdbparms "$BROKER" -n jdbc::JDBC -u $DBUSER -p $DBUSERPW
mqsisetdbparms "$BROKER" -n jdbc::JDBC -u $DBUSER -p $DBUSERPW

#echo "Running echo aaa | /opt/mqm/samp/bin/amqsput TCH.LOADCACHE $QMGR"
#echo 'aaa' | /opt/mqm/samp/bin/amqsput TCH.LOADCACHE "$QMGR"

echo "Running mqsichangeproperties "$BROKER" -o ComIbmJVMManager  -n jvmMaxHeapSize -v 1073741824"
mqsichangeproperties "$BROKER" -o ComIbmJVMManager  -n jvmMaxHeapSize -v 1073741824

#echo "Running mqsicacheadmin "$BROKER" -c showMapSizes > CacheMapRPT.txt"
#mqsicacheadmin "$BROKER" -c showMapSizes > CacheMapRPT.txt

#Setup Record and Replay
echo ================================
echo Setup Record and Replay
/home/virtuser/WMB/scripts/createRecordAndReplay.sh

#Finially recycle the system for the changes to take effect
echo =================================
echo Recycling server...
mqsistop "$BROKER"
#mqsistart "$BROKER"
