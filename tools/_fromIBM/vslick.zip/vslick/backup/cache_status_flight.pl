#!/usr/bin/perl
#------------------------------------------------------------------------
# Copyright IBM Corporation 2013++
#------------------------------------------------------------------------
# Program: cache_status.pl (for use with Flight Recorder python script)
# Purpose: Gather WebSphere DynaCache statistics by starting and
#          managing FR python script.  Need to periodically check
#          WAS PID and restart if changed.  Stop FR.py if WAS is
#          stopped.  Stop everything at midnight.
# History:
# 2013/10/25 Created
# 2014/08/28 Log retention adjustment
#------------------------------------------------------------------------
# Sample cron entry:
# 01 0 * * * /usr/local/bin/cachemon.pl >/dev/null 2>&1
#------------------------------------------------------------------------

sub GetDateTime();
sub GetDate();
sub GetWASProcessPID();
sub CheckExitMidnight();
sub KillFlightRecorderProcesses();
sub RetainLogs();
sub GetDateTime3();
sub GetFRProcessPID();
sub CheckIfLauncherRunning();
sub CheckWaitPID();

use POSIX "sys_wait_h";

#---------------------------------
# User Adjustables
#---------------------------------
my $LogName="/tmp/cachestatus_fr";     # basename for log
my $loopFrequencySeconds=180;          # seconds between checks of FR
#---------------------------------
# End of User Adjustables
#---------------------------------

my $WorkingDirectory="/app/isteam/cachecheck";
my $PythonFlightRecorder="/app/isteam/cachecheck/DynaCacheStatistics.py";
my $Options="-lang jython -tracefile /dev/null";
my $Arguments="-cacheInstance * -sleepUnit minutes -sleepInterval 5 -fileAppend";
my $hostname; chop($hostname=`hostname -s`);
my $rc;
my $flightRecorderRunning=0;
my $WASProcessPID=0;
my $FRProcessPID=0;
my $JVMName="xx"; 
my $PriorWASProcessPID=-1;
my $PriorFRProcessPID=-1;



#---------------------------------------------------------------------------
# MAIN Main main
#---------------------------------------------------------------------------

umask(022);
setpriority(0,0,5);
setpgrp(0,$$);

CheckIfLauncherRunning();

if ( ! chdir($WorkingDirectory)) { print STDERR "ERROR: Can not cd to $WorkingDirectory\n"; exit(0); }

# Any previously running FR should be killed...
KillFlightRecorderProcesses();
RetainLogs();

   #---------------------------------
   # Start main loop
   #---------------------------------
   while (1)
   {

      GetWASProcessPID();
      GetFRProcessPID();
      printf("%s WASProcessPID=%d   JVMName=%s   FRProcessPID=%d\n",GetDateTime(),$WASProcessPID,$JVMName,$FRProcessPID);

      if ( $FRProcessPID ) {
         if ( $WASProcessPID>0 && $PriorWASProcessPID>0 && $WASProcessPID != $PriorWASProcessPID ) {
            # WAS PID Changed; need to kill FR (and restart later)
            printf("%s Warning: WAS PID changed. Prior=%d  Current=%d  Must stop FR\n",GetDateTime(),$PriorWASProcessPID,$WASProcessPID);
            KillFlightRecorderProcesses();
         }
      }

      if ( $FRProcessPID==0 && $WASProcessPID ) {
         #----------------------------------
         # WAS running & FR not running --> start FR
         #----------------------------------
         $FRProcessPID = fork();
         if ( ! defined $FRProcessPID ) { exit(0); }  # fork failed
         if ( $FRProcessPID != 0 ) {
            #-------------------------------
            # This is the parent process
            #-------------------------------
            printf("%s Launched FRProcessPID=%d\n",GetDateTime(),$FRProcessPID);
            sleep(2);
            CheckWaitPID();
         } else {
            #-------------------------------
            # exec the child process into a FlightRecorder
            #-------------------------------
            $FullLogName=$LogName . "." . $hostname . "." . GetDate() . ".log";
            $commandstring=sprintf("/usr/WebSphere/AppServer764/bin/wsadmin.sh %s -f %s %s %s \"$Arguments\" >/dev/null 2>&1",
               $Options,$PythonFlightRecorder,$JVMName,$FullLogName);
            setpgrp(0,$$);
            exec($commandstring);
            # NOTREACHED
            exit(0);
         }
      }

      elsif ( $FRProcessPID && $WASProcessPID ) {
         #---------------------------------
         # Everything running. Check if child 
         # is trying to exit...
         #---------------------------------
         CheckWaitPID();
      } 

      elsif ( $FRProcessPID && $WASProcessPID==0 ) {
         #---------------------------
         # WAS not running & FR running -> kill FR
         #---------------------------
         printf("%s WAS not running but FR is running! Kill FR\n",GetDateTime());
         KillFlightRecorderProcesses();
      }

      if ( CheckExitMidnight() ) {
         #---------------------------
         # It's nearing midnight
         #---------------------------
         printf("%s Midnight is just about here. Kill Flight Recorder if running\n",GetDateTime());
         if ( $flightRecorderRunning ) {
            KillFlightRecorderProcesses();
         }
         #---------------------------
         # Since not started by scheduler
         # let's just sleep into the next
         # day then exec into a new copy.
         #---------------------------
         # sleep($loopFrequencySeconds);
         # exec($0); # cool
         exit(0); # midnight is here - exit now
      }
 
      sleep($loopFrequencySeconds);

      $PriorWASProcessPID=$WASProcessPID;
      $PriorFRProcessPID=$FRProcessPID;
      printf("%s Waking from sleep. Last known state: WASProcessPID=%d FRProcessPID=%d\n",GetDateTime(),$PriorWASProcessPID,$PriorFRProcessPID);

   }

   exit(0); # all loops completed


#--------------------------------------------------------------
sub GetDateTime()
#--------------------------------------------------------------
{
   ($tSec,$tMin,$tHour,$tDay,$tMon,$tYear,,,)=localtime(time);
   return sprintf("%04d/%02d/%02d %02d:%02d:%02d",
       $tYear+=1900,$tMon+=1,$tDay,$tHour,$tMin,$tSec);
}

#--------------------------------------------------------------
sub GetDate()
#--------------------------------------------------------------
{
   ($tSec,$tMin,$tHour,$tDay,$tMon,$tYear,,,)=localtime(time);
   return sprintf("%04d%02d%02d",
       $tYear+=1900,$tMon+=1,$tDay);
}

#--------------------------------------------------------------
sub GetWASProcessPID()
#--------------------------------------------------------------
{
   $JVMName="xx"; # override later if found
   $WASProcessPID=0;  # initialize and override if found
   open INPUT,"/usr/bin/ps -ef | grep /usr/WebSphere/AppServer764/java/bin/java|";
   while (<INPUT>)
   {
      chomp;
      if ( / grep / || / nodeagent/ ) { next; }
      s/^[ ]+//;
      @ss = split(/[ ]+/,$_);
      if ( $ss[0] ne "wasadm" ) { next; }
      if ( index($_,"/usr/WebSphere/AppServer764/java/bin/java")>60) { next; }
      if ( $#ss < 50 ) { next; }
      $JVMName=$ss[$#ss];
      $WASProcessPID=$ss[1];
      last;
   }
   close INPUT;
}

#--------------------------------------------------------------
sub GetFRProcessPID()
#--------------------------------------------------------------
{
   # By my definition, the FR process is the wsadmin.sh script
   $FRProcessPID=0;  # initialize and override when found
   open INPUT,"/usr/bin/ps -ef | grep DynaCacheStatistics.py |";
   while (<INPUT>)
   {
      chomp;
      if ( /grep/ ) { next; }
      if ( index($_,"/usr/WebSphere/AppServer764/java/bin/java")>0) { next; }
      if ( ! /wsadmin\.sh/ ) { next; }
      s/^[ ]+//;
      @ss = split(/[ ]+/,$_);
      if ( $ss[0] ne "wasadm" ) { next; }
      $FRProcessPID=$ss[1];
      last;
   }
   close INPUT;
}

#--------------------------------------------------------------
sub KillFlightRecorderProcesses()
#--------------------------------------------------------------
{
   open INPUT,"/usr/bin/ps -ef | grep DynaCacheStatistics.py|";
   while (<INPUT>)
   {
      # first, find and kill "wsadmin DynaCacheStatistics.py" processes
      if ( /grep/ ) { next; }
      if ( index($_,"/usr/WebSphere/AppServer764/java/bin/java")>0) { next; }
      if ( ! /wsadmin\.sh/ ) { next; }
      s/^[ ]+//;
      @ss = split(/[ ]+/,$_);
      printf("%s About to kill FR PID = %d\n",GetDateTime(),$ss[1]);
      $killcommand=sprintf("kill -9 %s",$ss[1]);
      system($killcommand);
      sleep(1);
      waitpid($ss[1],1); # allow defunct to exit
   }
   close INPUT;
   $FRProcessPID=0;

   open INPUT,"/usr/bin/ps -ef | grep DynaCacheStatistics.py|";
   while (<INPUT>)
   {
      # second, find and kill "java DynaCacheStatistics.py" processes
      if ( /grep/ ) { next; }
      if ( index($_,"/usr/WebSphere/AppServer764/java/bin/java")<0) { next; }
      s/^[ ]+//;
      @ss = split(/[ ]+/,$_);
      printf("%s About to kill FR java PID = %d\n",GetDateTime(),$ss[1]);
      $killcommand=sprintf("kill -9 %s",$ss[1]);
      system($killcommand);
      sleep(1);
      waitpid($ss[1],1); # allow defunct to exit
   }
   close INPUT;

}

#--------------------------------------------------------------
sub CheckExitMidnight()
#--------------------------------------------------------------
{
   # If the julian date from now to projected time changes, then exit
   my @t1=localtime(time);
   my @t2=localtime(time+$loopFrequencySeconds);
   if ( $t1[7] != $t2[7] ) { return 1; }
   return 0;
}

#--------------------------------------------------------------
sub RetainLogs()
#--------------------------------------------------------------
{
   my @ss;
   $archiveDirectory="/LogArchive/cachestatus";
   if ( ! -d $archiveDirectory ) { return; }
   $filepattern=sprintf("%s.%s.*.log",$LogName,$hostname);
   @ss=glob($filepattern);
   foreach (@ss) {
     #$commandstring=sprintf("/usr/bin/touch -a -t %s %s >/dev/null 2>&1",GetDateTime3(),$_);
      $commandstring=sprintf("/usr/bin/cp -p %s %s >/dev/null 2>&1",$_,$archiveDirectory);
      system($commandstring);
   }
}

#--------------------------------------------------------------
sub GetDateTime3()
#--------------------------------------------------------------
{
   ($tSec,$tMin,$tHour,$tDay,$tMon,$tYear,,,)=localtime(time+604800);
   return sprintf("%04d%02d%02d%02d%02d.00",
      $tYear+=1900,$tMon+=1,$tDay,$tHour,$tMin);
}

#--------------------------------------------------------------
sub CheckIfLauncherRunning()
#--------------------------------------------------------------
{
   open INPUT,"/usr/bin/ps -ef | grep cache_status_flight.pl |";
   while (<INPUT>)
   {
      chomp;
      if ( /grep/ ) { next; }
      s/^[ ]+//;
      @tt = split(/[ ]+/,$_);
      if ( $tt[1] == $$ ) { next; }
      exit(0); # already running!
   }
   close INPUT;
}

#--------------------------------------------------------------
sub CheckWaitPID()
#--------------------------------------------------------------
{
   waitpid($FRProcessPID,1);  # Check for child exit with nohang waitpid
   $rc=$?;
   printf("%s RC=%d from waitpid for FRProcessPID=%d\n",GetDateTime(),$rc,$FRProcessPID);
   if ($rc==-1) {
      printf("%s FRProcessPID = %d\n",GetDateTime(),$FRProcessPID);
   }
   elsif ( $rc==0 ) {
      printf("%s waitpid says FR exited\n",GetDateTime());
   }
}
