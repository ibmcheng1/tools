#!/bin/sh

fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

echo servletUrl=$servletUrl
echo objectgridName=$objectgridName
echo mapName=$mapName

loop=300
size=16000
threadLoad=2000
startKeyIndex=0
options=""

./runDriver.sh -caseServlet -loop $loop -size $size -multiWorkerMode $threadLoad -startKeyIndex $startKeyIndex -dataServiceType 3 -servletUrl $servletUrl -objectgridName $objectgridName -mapName $mapName $options
