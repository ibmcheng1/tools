import os
import sys
execfile('wsadminlib.py')

#import the applications config.py property file with input variables to be used into the script...

dir = os.getcwd()
fileName, fileExtension = os.path.splitext(sys.argv[0])

print "Configuration File Name: " + fileName
exec("from " + fileName + " import *")
###########################################################


#################################################################
# NEW
#################################################################

def getServerJvmByServerId(server_id):
    """Return the config ID of the JVM object for this server"""
    # the pdefs come back as a string [item item item]
    pdefs = _splitlist(AdminConfig.showAttribute(server_id, 'processDefinitions'))
    pdef = None
    for p in pdefs:
        if -1 != p.find("JavaProcessDef"):
            pdef = p
            break
    if pdef: # found Java ProcessDef
        return _splitlist(AdminConfig.showAttribute(pdef, 'jvmEntries'))[0]
#endDef

def setJvmPropertyByServerId(server_id,name,value):
    print "setJvmPropertyByServerId: " + name + "=" + value 
    jvm = getServerJvmByServerId(server_id)
    attrs = []
    attrs.append( [ 'name', name ] )
    attrs.append( ['value', value] )
    return removeAndCreate('Property', jvm, attrs, ['name'])
#endDef

def removeJvmPropertyByServerId(server_id, cpname):
    print "-------------------------------------------------------"
    print "Remove JVM custom property ... server_id = " + server_id
    print "-------------------------------------------------------"
    cpTarget = getServerJvmByServerId(server_id)
    printObject("JVM: ", cpTarget)    
    propertyList = AdminConfig.list("Property",cpTarget)
    for prop in propertyList.split("\n"):
        thisProp = prop.rstrip()
        name = getObjectAttribute(thisProp, 'name')
        value = getObjectAttribute(thisProp, 'value')
                
        if (thisProp.find(cpname) == 0):
            print "Removing Property: " + name + "=" + value
            remove(thisProp)
        #endIf
    #endFor
#endDef

    
def displayJvmCustomPropertiesByServerId ( server_id):
    print "-------------------------------------------------------"
    print "Display JVM custom properties ... server_id = " + server_id
    print "-------------------------------------------------------"
    cpTarget = getServerJvmByServerId(server_id)
    printObject("JVM: ", cpTarget)    
    propertyList = AdminConfig.list("Property",cpTarget)
    for prop in propertyList.split("\n"):
        thisProp = prop.rstrip()
        # printObject("property", thisProp)
        name = getObjectAttribute(thisProp, 'name')
        value = getObjectAttribute(thisProp, 'value')
        # rintObject("name", name)
        # printObject("value", value)
        print "Property: " + name + "=" + value
    #endFor
#endDef
    
###########################################################
# local method 
###########################################################

def setJvmCustomPropertiesByCluster(clusterName) :
    print "==================================================================="
    print "Set JVM custom properties by Cluster:  clusterName = " + clusterName
    print "==================================================================="
    
    m = "setJvmCustomPropertiesByCluster:"
    clusterMembers = listServersInCluster(clusterName)
    for clusterMember in clusterMembers:
        nodeName = AdminConfig.showAttribute( clusterMember, "nodeName" )
        serverName = AdminConfig.showAttribute( clusterMember, "memberName" )
        #sop(m, "Show JVM custom properties of Server %s on Node %s" % (serverName, nodeName ))
        
        serverId = getServerId(nodeName,serverName)
        #sop(m,"serverId=%s " % ( repr(serverId), ))
                              
        print "-------------------------------------------------"
        print "Set JVM custom properties on server: " + serverName
        print "-------------------------------------------------"
        #WXS_cache_name = CBS_brandName + "_baseCache"        
        #setJvmPropertyByServerId(serverId,'com.ibm.websphere.xs.dynacache.cache_name',WXS_cache_name)
        
        setJvmPropertyByServerId(serverId,'com.ibm.websphere.xs.dynacache.map_template_name','IBM_DC_CRC_PARTITIONED_.*')

#endDef

def removeJvmCustomPropertiesByCluster(clusterName) :
    print "==================================================================="
    print "Remove JVM custom properties by Cluster:  clusterName = " + clusterName
    print "==================================================================="
    
    m = "setJvmCustomPropertiesByCluster:"
    clusterMembers = listServersInCluster(clusterName)
    for clusterMember in clusterMembers:
        nodeName = AdminConfig.showAttribute( clusterMember, "nodeName" )
        serverName = AdminConfig.showAttribute( clusterMember, "memberName" )
        #sop(m, "Show JVM custom properties of Server %s on Node %s" % (serverName, nodeName ))
        
        serverId = getServerId(nodeName,serverName)
        #sop(m,"serverId=%s " % ( repr(serverId), ))
                              
        print "-------------------------------------------------"
        print "Remove JVM custom properties on server: " + serverName
        print "-------------------------------------------------"
       
        removeJvmPropertyByServerId(serverId,'com.ibm.websphere.xs.dynacache.map_template_name')

#endDef

def displayJvmCustomPropertiesByCluster(clusterName) :
    print "==================================================================="
    print "Display JVM custom properties by Cluster:  clusterName = " + clusterName
    print "==================================================================="
    
    m = "displayJvmCustomPropertiesByCluster:"
    clusterMembers = listServersInCluster(clusterName)
    for clusterMember in clusterMembers:
        nodeName = AdminConfig.showAttribute( clusterMember, "nodeName" )
        serverName = AdminConfig.showAttribute( clusterMember, "memberName" )
        #sop(m, "Show JVM custom properties of Server %s on Node %s" % (serverName, nodeName ))
        
        serverId = getServerId(nodeName,serverName)
        #sop(m,"serverId=%s " % ( repr(serverId), ))       

        displayJvmCustomPropertiesByServerId(serverId)
        
#endDef


#---------------------------------------------------------
#  set dynacache configuration
#
#---------------------------------------------------------

enableDebugMessages()

#clusterName is defined in the applications config.py property file (cluster_config.py) 

cellName = AdminControl.getCell()
cellId = getCellId(None)

cluster = getClusterId(clusterName)

printObject("CBS_brandName", CBS_brandName)
printObject("clusterName", clusterName)
printObject("cellName", cellName)
printObject("cellId", cellId) 
printObject("cluster", cluster) 

scopeobjectid = cluster

#displayJvmCustomPropertiesByCluster(clusterName)

#setJvmCustomPropertiesByCluster(clusterName)
#removeJvmCustomPropertiesByCluster(clusterName)

#saveAndSyncAndPrintResult()

displayJvmCustomPropertiesByCluster(clusterName)

