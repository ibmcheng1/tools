#!/bin/sh
echo ======================================
echo running installPlugins.sh
echo ======================================

echo "------------------------------------------"
echo ENV_CONFIG_FILE=$ENV_CONFIG_FILE
echo "------------------------------------------"
if [ -f $ENV_CONFIG_FILE ]; then
  . $ENV_CONFIG_FILE
else
  echo "ERROR: ENV_CONFIG_FILE=${ENV_CONFIG_FILE} is not found"
  exit 1
fi

echo SOFTWARE_REPOSITORY=$SOFTWARE_REPOSITORY
echo IBMIM_installationDirectory=$IBMIM_installationDirectory
echo IBMIM_sharedResourcesDirectory=$IBMIM_sharedResourcesDirectory
echo Plugins_installationDirectory=$Plugins_installationDirectory
echo Plugins_packageID=$Plugins_packageID
echo Plugins_version=$Plugins_version
echo Plugins_packageID_version=$Plugins_packageID_version
echo Plugins_features=$Plugins_features
echo Plugins_packageID_features=$Plugins_packageID_features
echo Plugins_repositories=$Plugins_repositories
echo "------------------------------------------"

INSTALLATION_DIRECTORY=$Plugins_installationDirectory
PACKAGEID=$Plugins_packageID
VERSION=$Plugins_version
PACKAGEID_VERSION=$Plugins_packageID_version
FEATURES=$Plugins_features
PACKAGEID_FEATURES=$Plugins_packageID_features
REPOSITORIES=$Plugins_repositories
IFIX_PACKAGEID=$WAS_SUPPL_IFIX_SOFTWARE_PACKAGE
IFIX_REPOSITORIES=$WAS_SUPPL_IFIX_SOFTWARE_PATH

export IBMIM_installationDirectory
export IBMIM_sharedResourcesDirectory
export INSTALLATION_DIRECTORY
export PACKAGEID
export VERSION
export PACKAGEID_VERSION
export FEATURES
export PACKAGEID_FEATURES
export REPOSITORIES
export IFIX_PACKAGEID
export IFIX_REPOSITORIES

#${WORKING_DIR}/scripts/runImclInstall.sh

echo ======================================
echo end of installPlugins.sh
echo ======================================
