#!/bin/sh
echo ======================================
echo running installWAS.sh
echo ======================================

echo "------------------------------------------"
echo ENV_CONFIG_FILE=$ENV_CONFIG_FILE
echo "------------------------------------------"
if [ -f $ENV_CONFIG_FILE ]; then
  . $ENV_CONFIG_FILE
else
  echo "ERROR: ENV_CONFIG_FILE=${ENV_CONFIG_FILE} is not found"
  exit 1
fi

echo SOFTWARE_REPOSITORY=$SOFTWARE_REPOSITORY
echo IBMIM_installationDirectory=$IBMIM_installationDirectory
echo IBMIM_sharedResourcesDirectory=$IBMIM_sharedResourcesDirectory
echo WAS_installationDirectory=$WAS_installationDirectory
echo WAS_packageID=$WAS_packageID
echo WAS_version=$WAS_version
echo WAS_packageID_version=$WAS_packageID_version
echo WAS_features=$WAS_features
echo WAS_packageID_features=$WAS_packageID_features
echo WAS_repositories=$WAS_repositories

INSTALLATION_DIRECTORY=$WAS_installationDirectory
PACKAGEID=$WAS_packageID
VERSION=$WAS_version
PACKAGEID_VERSION=$WAS_packageID_version
FEATURES=$WAS_features
PACKAGEID_FEATURES=$WAS_packageID_features
REPOSITORIES=$WAS_repositories

echo INSTALLATION_DIRECTORY=$INSTALLATION_DIRECTORY
echo PACKAGEID=$PACKAGEID
echo VERSION=$VERSION
echo PACKAGEID_VERSION=$PACKAGEID_VERSION
echo FEATURES=$FEATURES
echo PACKAGEID_FEATURES=$PACKAGEID_FEATURES
echo REPOSITORIES=$REPOSITORIES

IFIX_PACKAGEID=$WAS_IFIX_SOFTWARE_PACKAGE
IFIX_REPOSITORIES=$WAS_IFIX_SOFTWARE_PATH

if [ ! -d $IBMIM_installationDirectory ]; then
   echo "Error: $IBMIM_installationDirectory does not exist."
   exit 1
fi

cd ${IBMIM_installationDirectory}/eclipse/tools

echo ----------------------------------------
echo installing packageID : $WAS_packageID
echo ----------------------------------------
#./imcl install ${PACKAGEID_FEATURES} -repositories ${REPOSITORIES} -installationDirectory ${INSTALLATION_DIRECTORY} -sharedResourcesDirectory ${IBMIM_sharedResourcesDirectory} -acceptLicense -showProgress
     
echo ----------------------------------------
echo installing applicable interim fix : $IFIX_PACKAGEID
echo ----------------------------------------
if [ $IFIX_PACKAGEID == "" ]; then
   echo "IFIX_PACKAGEID: [${IFIX_REPOSITORIES}] does not exist."
else
   echo "installing IFIX_PACKAGEID: [${IFIX_REPOSITORIES}]"
   #./imcl install ${IFIX_PACKAGEID} -repositories ${IFIX_REPOSITORIES} -installationDirectory ${INSTALLATION_DIRECTORY} -showProgress
fi

echo ======================================
echo end of installWAS.sh
echo ======================================
