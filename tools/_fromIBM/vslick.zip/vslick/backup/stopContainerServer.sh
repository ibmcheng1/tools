#!/bin/sh
fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

CONTAINER_SVR=${CONTAINER_SERVER_NAME_PREFIX}$1

"$OBJECTGRID_ROOT"/bin/xscmd.sh -cep $CATALOG_SERVICE_ENDPOINTS -c teardown -sl ${CONTAINER_SVR} -force
