#!/bin/sh
fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

SERVER_NAME=${CATALOG_SERVER_NAME_PREFIX}$1

"$OBJECTGRID_ROOT"/bin/xscmd.sh -cep $CATALOG_SERVICE_ENDPOINTS -c teardown -sl ${SERVER_NAME} -force
