#!/bin/sh
echo ======================================
echo running installIBMIM.sh
echo ======================================

echo "------------------------------------------"
echo ENV_CONFIG_FILE=$ENV_CONFIG_FILE
echo "------------------------------------------"
if [ -f $ENV_CONFIG_FILE ]; then
  . $ENV_CONFIG_FILE
else
  echo "ERROR: ENV_CONFIG_FILE=${ENV_CONFIG_FILE} is not found"
  exit 1
fi

echo SOFTWARE_REPOSITORY=$SOFTWARE_REPOSITORY
echo IBM_IM_SOFTWARE_PATH=$IBM_IM_SOFTWARE_PATH
echo IBMIM_installationDirectory=$IBMIM_installationDirectory

echo ----------------------------------------
echo installing IBMIM ...
echo ----------------------------------------

if [ ! -d $IBM_IM_SOFTWARE_PATH ]; then
   echo "  Error: $IBM_IM_SOFTWARE_PATH does not exist."
else
   cd ${IBM_IM_SOFTWARE_PATH}/tools
   ./imcl install com.ibm.cic.agent -repositories ${IBM_IM_SOFTWARE_PATH}/repository.config -installationDirectory $IBMIM_installationDirectory -accessRights admin -acceptLicense -showProgress
fi

echo ======================================
echo end of installIBMIM.sh
echo ======================================
