#!/bin/sh

# The path to the Websphere Extreme Scale.
WXS_HOME="/opt/IBM/eXtremeScale"

# The path to the ObjectGrid runtime root directory.
OBJECTGRID_ROOT="${WXS_HOME}/ObjectGrid"
#JAVA_HOME="${WXS_HOME}/java"
JAVA_HOME="${WXS_HOME}/java/jre"

# The domain environment and profile variables.
PROFILE="wxs.performance.grid"
PROFILE_INDEX=0
ENV_NAME="q"

# The path to the user WXS working directory
WORKING_DIR=${PWD}

# catalog service domain setting
CATALOG_SERVICE_DOMAIN_INDEX=$PROFILE_INDEX
CATALOG_SERVICE_DOMAIN_NAME=${PROFILE}Domain
CATALOG_SERVER_NAME_PREFIX=${PROFILE}${ENV_NAME}cat

# container server setting
CONTAINER_SERVER_NAME_PREFIX=${PROFILE}${ENV_NAME}con
CONTAINER_NUMBER_PER_NODE=1
CONTAINER_HA_PORT_STARTING=66${CATALOG_SERVICE_DOMAIN_INDEX}2 
CONTAINER_LISTENER_PORT_STARTING=28${CATALOG_SERVICE_DOMAIN_INDEX}0
CONTAINER_JVM_HEAP_SIZE=4096

# The host name used when starting catalog server. Use 'hostname' in actual environment. 
CURRENT_HOST=`hostname`

########################################
# Single catalog server scenario setting
########################################
# The listener port used when starting single catalog server scenario.
CATALOGSERVER_LISTENER_PORT=2809

# The catallog service endpoints used by starting container servers or clients in single catalog server scenario
#CATALOG_SERVICE_ENDPOINTS=${CURRENT_HOST}:2809
CATALOG_SERVICE_ENDPOINTS=pas01-grp034.aimsrv.net:2809

########################################

# WXS configuration files for starting container servers: 
# 1. objectgrid.xml deployment.xml
# 2. objectgrid.xml deployment-async.xml 
# 3. objectgrid.xml deployment-sync.xml
# 4. objectgrid-CRC.xml deployment.xml 
# 5. objectgrid-NoCopy.xml deployment.xml
# 6. objectgrid-NearCache-NCI.xml deployment.xml
# 7. objectgrid-NearCache-Locking-NONE.xml deployment.xml
# 8. objectgrid-NearCache-Locking-P.xml deployment.xml 

OBJECT_GRID_XML="${WORKING_DIR}/xml/objectgrid.xml"
#OBJECT_GRID_XML="${WORKING_DIR}/xml/objectgrid-CRC.xml"
#OBJECT_GRID_XML="${WORKING_DIR}/xml/objectgrid-NoCopy.xml"
#OBJECT_GRID_XML="${WORKING_DIR}/xml/objectgrid-NearCache.xml"
#OBJECT_GRID_XML="${WORKING_DIR}/xml/objectgrid-NearCache-NCI.xml"
#OBJECT_GRID_XML="${WORKING_DIR}/xml/objectgrid-Locking-NONE.xml"
#OBJECT_GRID_XML="${WORKING_DIR}/xml/objectgrid-Locking-P.xml"
DEPLOYMENT_POLICY_XML="${WORKING_DIR}/xml/deployment.xml"
#DEPLOYMENT_POLICY_XML="${WORKING_DIR}/xml/deployment-async.xml"
#DEPLOYMENT_POLICY_XML="${WORKING_DIR}/xml/deployment-sync.xml"

# properties file path to locate client or server properties files
PROPERTIES_PATH="${WORKING_DIR}/properties"

# classpath for starting container servers
APP_LIB_PATH="${WORKING_DIR}:${WORKING_DIR}/lib/*:${WORKING_DIR}/properties"

export WXS_HOME OBJECTGRID_ROOT JAVA_HOME WORKING_DIR CATALOG_SERVICE_DOMAIN_INDEX CATALOG_SERVICE_DOMAIN_NAME CATALOG_SERVER_NAME_PREFIX CONTAINER_SERVER_NAME_PREFIX CONTAINER_HA_PORT_STARTING CONTAINER_LISTENER_PORT_STARTING CONTAINER_JVM_HEAP_SIZE CONTAINER_NUMBER_PER_NODE CURRENT_HOST CATALOGSERVER_LISTENER_PORT CATALOG_SERVICE_ENDPOINTS OBJECT_GRID_XML DEPLOYMENT_POLICY_XML APP_LIB_PATH PROPERTIES_PATH HOSTS CATALOG_HOSTS CONTAINER_HOSTS
