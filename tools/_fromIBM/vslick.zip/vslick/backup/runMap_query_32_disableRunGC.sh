#!/bin/sh

fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

echo catalogServiceEndPoints=$catalogServiceEndPoints
echo objectgridName=$objectgridName
echo mapName=$mapName

loop=5
size=96000
actionListIndex=6
   
# 32 threads
threadLoad=3000
./runDriver.sh -case032 -disableRunGC -multiWorkerMode $threadLoad 
-actionListIndex
$actionListIndex -loop $loop -size $size -catalogServiceEndPoints $catalogServiceEndPoints -objectgridName $objectgridName -mapName $mapName


