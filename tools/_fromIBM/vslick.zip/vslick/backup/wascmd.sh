#!/bin/ksh

if [ -f /etc/virtualimage.properties ]; then
  . /etc/virtualimage.properties
fi

# WAS_USER and WAS_PASSWORD variable should be available in /etc/virtualimage.properties
# After script package has executed, the $ENV_CONFIG_FILE_NAME has copied 
# to working directory.
# This script should use local copy of $ENV_CONFIG_FILE_NAME

export WORKING_DIR=${PWD}
chmod a+x ${WORKING_DIR}/*.sh
echo WORKING_DIR=$WORKING_DIR
export ENV_CONFIG_FILE=${WORKING_DIR}/$ENV_CONFIG_FILE_NAME

echo "---------------------------------"
echo "Parameters from /etc/virtualimage.properties"
echo "---------------------------------"
echo WAS_INSTALL_ROOT=$WAS_INSTALL_ROOT
echo WAS_PROFILE_ROOT=$WAS_PROFILE_ROOT
export WAS_INSTALL_ROOT
export WAS_PROFILE_ROOT 

echo "---------------------------------"
echo "Parameters from ${ENV_CONFIG_FILE}"
echo "---------------------------------"
echo ENV_CONFIG_FILE=$ENV_CONFIG_FILE
if [ -f $ENV_CONFIG_FILE ]; then
  cat $ENV_CONFIG_FILE
  . $ENV_CONFIG_FILE
else
  echo "ERROR: ENV_CONFIG_FILE=${ENV_CONFIG_FILE} is not found"
  exit 1
fi

# The /etc/virtualimage.properties has original WAS_USER and WAS_PASSWORD 
# defined to run script package.
# After pattern instance is provisioned, the LDAP is enabled.
# The WAS user is WAS_USER_ldap after cell re-started.
# Caller of this script must override WAS_USER to WAS_USER_ldap and export 
# both WAS_USER and WAS_PASSWORD
# the runWsadmin.sh will use the current WAS_USER and WAS_PASSWORD 

echo "---------------------------------"
echo WAS_USER_ldap=$WAS_USER_ldap
echo WAS_PASSWORD_ldap=$WAS_PASSWORD_ldap
export WAS_USER=$WAS_USER_ldap
export WAS_PASSWORD=$WAS_PASSWORD_ldap
export WAS_USER_ldap
export WAS_PASSWORD_ldap
echo WAS_USER=$WAS_USER
echo WAS_PASSWORD=$WAS_PASSWORD
echo "---------------------------------"

if [ $# -ne 2 ]
then
    echo "  Usage: wascmd  <WAS_target> <WAS_action>"
    echo "  ----------------------------------------"
    echo "  Command examples:"
    echo "  ----------------------------------------"
    echo "  ./wascmd.sh cell start"
    echo "  ./wascmd.sh cell stop"
    echo "  ./wascmd.sh cluster start"
    echo "  ./wascmd.sh cluster stop"    
    echo "  ./wascmd.sh caching retrieveCert"
    echo "  ./wascmd.sh caching deleteCert"
    echo "  ./wascmd.sh app enableXC10Session"
    echo "  ./wascmd.sh app disableXC10Session"    
    echo "  ./wascmd.sh webserver copyKeystoreFromDmgrToWebServers"
    echo "  ./wascmd.sh webserver restart"
    echo "  ----------------------------------------"
    exit 1
fi

WAS_target=$1
WAS_action=$2

echo "WAS_target = ${WAS_target}"
echo "WAS_action = ${WAS_action}"


if [ $WAS_target = "cell" ]
then 
  echo "*** cell action ***"  
  if [ $WAS_action = "stop" ]
  then
    echo "stopping cell ..." 
    ${WORKING_DIR}/runWsadmin.sh cellStop.py ER_config.py
  else
    if [ $WAS_action = "start" ]
    then
      echo "starting cell ..." 
      ${WORKING_DIR}/cellStart.sh  
    else
      echo "ERROR: Unknown cell action !!!"
      exit 1 
    fi
  fi  
  exit 0
fi

if [ $WAS_target = "cluster" ]
then 
  echo "*** cluster action ***"  
  if [ $WAS_action = "stop" ]
  then
    echo "stopping cluster ..." 
    ${WORKING_DIR}/runWsadmin.sh clusterStop.py ER_config.py
  else
    if [ $WAS_action = "start" ]
    then
      echo "starting cluster ..." 
      ${WORKING_DIR}/runWsadmin.sh clusterStart.py ER_config.py  
    else
      echo "ERROR: Unknown cluster action !!!"
      exit 1 
    fi
  fi 
  exit 0
fi


if [ $WAS_target = "caching" ]
then 
  echo "*** caching action ***"  
  if [ $WAS_action = "retrieveCert" ]
  then
    echo "retrieving caching signer certificate ..." 
    ${WORKING_DIR}/runWsadmin.sh cachingCert.py ER_config.py retrieveCert
  else
    if [ $WAS_action = "deleteCert" ]
    then
      echo "deleting caching signer certificate ..." 
      ${WORKING_DIR}/runWsadmin.sh cachingCert.py ER_config.py deleteCert  
    else
      echo "ERROR: Unknown caching action !!!"
      exit 1 
    fi
  fi 
  exit 0
fi


if [ $WAS_target = "app" ]
then 
  echo "*** app action ***"  
  if [ $WAS_action = "enableXC10Session" ]
  then
    echo "enabling application with XC10 session management ..." 
    ${WORKING_DIR}/runWsadmin.sh appMgmt.py ER_config.py enableXC10Session
  else
    if [ $WAS_action = "disableXC10Session" ]
    then
      echo "disabling application with XC10 session management ..." 
      ${WORKING_DIR}/runWsadmin.sh appMgmt.py ER_config.py disableXC10Session  
    else
      echo "ERROR: Unknown app action !!!"
      exit 1 
    fi
  fi 
  exit 0
fi

if [ $WAS_target = "webserver" ]
then 
  echo "*** webserver action ***"  
  if [ $WAS_action = "copyKeystoreFromDmgrToWebServers" ]
  then
    echo "copy web server plugin key store from dmgr to web server plugin ..."
    ${WORKING_DIR}/runWsadmin.sh webserverMgmt.py ER_config.py copyKeystoreFromDmgrToWebServers
  else
    if [ $WAS_action = "restart" ]
    then
      echo "restart web server ..." 
      ${WORKING_DIR}/runWsadmin.sh webserverMgmt.py ER_config.py restart  
    else
      echo "ERROR: Unknown app action !!!"
      exit 1 
    fi
  fi 
  exit 0
fi

echo "ERROR - unknown WAS_target = ${WAS_target}"
exit 1



