WAS_HOME=/opt/IBM/WebSphere61/AppServer
cd $WAS_HOME
./manageprofiles.sh -augment -profileName imqDmgr -templatePath ${WAS_HOME}/profileTemplates/xs_augment/dmgr
./manageprofiles.sh -augment -profileName bdqDmgr -templatePath ${WAS_HOME}/profileTemplates/xs_augment/dmgr
./manageprofiles.sh -augment -profileName fgqDmgr -templatePath ${WAS_HOME}/profileTemplates/xs_augment/dmgr
./manageprofiles.sh -augment -profileName tsqDmgr -templatePath ${WAS_HOME}/profileTemplates/xs_augment/dmgr

./manageprofiles.sh -augment -profileName imq01 -templatePath ${WAS_HOME}/profileTemplates/xs_augment/managed
./manageprofiles.sh -augment -profileName bdq01 -templatePath ${WAS_HOME}/profileTemplates/xs_augment/managed
./manageprofiles.sh -augment -profileName fgq01 -templatePath ${WAS_HOME}/profileTemplates/xs_augment/managed
./manageprofiles.sh -augment -profileName tsq01 -templatePath ${WAS_HOME}/profileTemplates/xs_augment/managed
