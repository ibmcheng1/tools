#!/bin/ksh

echo ======================================
echo running stopips.sh
echo ======================================

/usr/sbin/rmdev -l ipsec_v4 
