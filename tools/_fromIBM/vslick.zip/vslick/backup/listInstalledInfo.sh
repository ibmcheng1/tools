#!/bin/sh
echo ======================================
echo running listInstalledInfo.sh
echo ======================================

echo "------------------------------------------"
echo ENV_CONFIG_FILE=$ENV_CONFIG_FILE
echo "------------------------------------------"
if [ -f $ENV_CONFIG_FILE ]; then
  . $ENV_CONFIG_FILE
else
  echo "ERROR: ENV_CONFIG_FILE=${ENV_CONFIG_FILE} is not found"
  exit 1
fi

echo IBMIM_installationDirectory=$IBMIM_installationDirectory
echo IBMIM_REPOSITORIES=$IBMIM_REPOSITORIES

if [ ! -d $IBMIM_installationDirectory ]; then
   echo "Error: $IBMIM_installationDirectory does not exist."
else
   cd ${IBMIM_installationDirectory}/eclipse/tools
      
   echo "----------------------------------------"
   echo "IBMIM: listInstallationDirectories -long ..."
   echo "----------------------------------------"
   ./imcl listInstallationDirectories -long
   
   echo "----------------------------------------"
   echo "IBMIM: listInstallationDirectories -verbose ..."
   echo "----------------------------------------"
   ./imcl listInstallationDirectories -verbose
   
   echo "----------------------------------------"
   echo "IBMIM: listInstalledPackages -long"
   echo "----------------------------------------"
   ./imcl listInstalledPackages -features -long
   
   echo "----------------------------------------"
   echo "IBMIM: listInstalledPackages -verbose"
   echo "----------------------------------------"
   ./imcl listInstalledPackages -features -verbose
   
fi

echo ======================================
echo end of listInstalledInfo .sh
echo ======================================
