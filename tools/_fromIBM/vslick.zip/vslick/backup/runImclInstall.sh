#!/bin/sh
echo ======================================
echo running runImclInstall.sh
echo ======================================

# caller must expport the following variables
echo IBMIM_installationDirectory=$IBMIM_installationDirectory
echo IBMIM_sharedResourcesDirectory=$IBMIM_sharedResourcesDirectory
echo INSTALLATION_DIRECTORY=$INSTALLATION_DIRECTORY
echo PACKAGEID=$PACKAGEID
echo VERSION=$VERSION
echo PACKAGEID_VERSION=$PACKAGEID_VERSION
echo FEATURES=$FEATURES
echo PACKAGEID_FEATURES=$PACKAGEID_FEATURES
echo REPOSITORIES=$REPOSITORIES
echo IFIX_PACKAGEID=$IFIX_PACKAGEID
echo IFIX_REPOSITORIES=$IFIX_REPOSITORIES

if [ ! -d $IBMIM_installationDirectory ]; then
   echo "Error: $IBMIM_installationDirectory does not exist."
   exit 1
fi

cd ${IBMIM_installationDirectory}/eclipse/tools

echo "------------------------------------------"
echo installing packageID : $WAS_packageID
echo "------------------------------------------"
./imcl install $PACKAGEID_FEATURES -repositories $REPOSITORIES -installationDirectory $INSTALLATION_DIRECTORY -sharedResourcesDirectory $IBMIM_sharedResourcesDirectory -acceptLicense -showProgress
     
echo "------------------------------------------"
echo installing applicable interim fix : $IFIX_PACKAGEID
echo "------------------------------------------"

if [ -z "$IFIX_PACKAGEID" ]; then
   echo "IFIX_PACKAGEID is unset. Skip installing IFIX."
else
   if [ -n "$IFIX_PACKAGEID" ]; then
      echo "installing $IFIX_PACKAGEID"
      # To check for non-null/non-zero string variable, i.e. if set
      ./imcl install $IFIX_PACKAGEID -repositories $IFIX_REPOSITORIES -installationDirectory $INSTALLATION_DIRECTORY -showProgress 
   else
      echo "IFIX_PACKAGEID is empty string. Skip installing IFIX."
   fi
fi

echo ======================================
echo end of runImclInstall.sh
echo ======================================
