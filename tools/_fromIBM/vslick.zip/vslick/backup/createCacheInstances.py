import os
import sys
execfile('wsadminlib.py')

#import the applications config.py property file with input variables to be used into the script...

dir = os.getcwd()
fileName, fileExtension = os.path.splitext(sys.argv[0])

print "Configuration File Name: " + fileName
exec("from " + fileName + " import *")

###########################################################
# local method 
###########################################################

def createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName ):      
        # parameter examples:
        # cacheInstance_type = "ObjectCacheInstance"
        # cacheInstance_name = "WCCatalogGroupDistributedMapCache"
        # cacheInstance_jndiname = "services/cache/" + cacheInstance_name
        # cacheInstance_cacheSize = "2001"
        # cacheInstance_cacheProviderType = "WXS"
        # cacheInstance_cacheName = "YYExtremeScaleCatalogEntryDMC"

        cacheInstanceId = getObjectByName( cacheInstance_type, cacheInstance_name )
        printObject(cacheInstance_name, cacheInstanceId)
        
        if cacheInstanceId is not None:
            print "#########################################"
            print "Edit CacheInstance: " + cacheInstance_name
            print "#########################################"
            printPropertiesDictionary(cacheInstanceId)
            printPropertiesSet(cacheInstanceId)
            
            print "----------------------------------"
            print "Display CustomProperty ..."
            print "----------------------------------"   
            printJ2EEResourcePropertySet(cacheInstanceId)    
            
        else:
            print "#########################################"
            print "Creating CacheInstance: " + cacheInstance_name + ", type = " + cacheInstance_type
            print "#########################################"
            
            if (cacheInstance_type == "ObjectCacheInstance"): 
                cacheInstanceId = createObjectCache(scopeobjectid, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheProviderType)
                # saveAndSyncAndPrintResult()
            else:
                cacheInstanceId = createServletCache(scopeobjectid, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheProviderType)
                # saveAndSyncAndPrintResult()
            
            print "----------------------------------"
            print "Setting Cahce Instance Setting ..."
            print "----------------------------------"
            setCacheInstanceSettings(cacheInstanceId, "cacheSize", cacheInstance_cacheSize)
            # saveAndSyncAndPrintResult()
            
            if (cacheInstance_cacheProviderType == "WXS"):
                    print "----------------------------------"
                    print "Setting CustomProperty for WXS cache provider..."
                    print "----------------------------------"
                    customPropertyName = "com.ibm.websphere.xs.dynacache.cache_name"
                    customPropertyValue = cacheInstance_cacheName
                    createResourceCustomProperty(cacheInstanceId, customPropertyName, customPropertyValue)
                    
                    setCacheInstanceSettings(cacheInstanceId, "enableCacheReplication", 'true')
                    
                    #saveAndSyncAndPrintResult()
            else:
                    print "----------------------------------"
                    print "Setting CustomProperty for default cache provider..."
                    print "----------------------------------"
                    setCacheInstanceSettings(cacheInstanceId, "enableCacheReplication", 'true')
                    domainName = "Dynacache"
                    enableCacheReplication(cacheInstanceId, domainName, replicationType = 'NONE')
                    #saveAndSyncAndPrintResult()
        
        printPropertiesDictionary(cacheInstanceId)
        printPropertiesSet(cacheInstanceId)
        printJ2EEResourcePropertySet(cacheInstanceId)
        
        return cacheInstanceId
#endDef

#---------------------------------------------------------
#  Configure WAS to use WXS as dynacache provider
#
#---------------------------------------------------------
#set cp [$AdminConfig getid /Node:myNode/CacheProvider:/]
#$AdminConfig create ObjectCacheInstance $cp { {name myOCI} {jndiName cache/myJNDI} {cacheSize 2000} {defaultPriority 1} {category myCat} {description MyDesc} {enableDiskOffload false} {diskOffloadLocation "/my/dir"} {flushToDiskOnStop true} {useListenerContext false} {disableDependencyId false} }
#$AdminConfig Save

enableDebugMessages()

#clusterName is defined in the applications config.py property file (cluster_config.py) 
#CBS_brandName is defined in the applications config.py property file (cluster_config.py)

cellName = AdminControl.getCell()
cellId = getCellId(None)

cluster = getClusterId(clusterName)

printObject("CBS_brandName", CBS_brandName)
printObject("clusterName", clusterName)
printObject("cellName", cellName)
printObject("cellId", cellId) 
printObject("cluster", cluster) 

scopeobjectid = cluster

#############################################################
# 1. create object cache instance: WCCatalogEntryDistributedMapCache
#############################################################
cacheInstance_name = "WCCatalogEntryDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "2001"
cacheInstance_cacheProviderType = "WXS"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleCatalogEntryDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )


#############################################################
# 2. create object cache instance: WCCatalogGroupDistributedMapCache
#############################################################
cacheInstance_name = "WCCatalogGroupDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "101"
cacheInstance_cacheProviderType = "WXS"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleCatalogGroupDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )


#############################################################
# 3. create object cache instance: WCMarketingDistributedMapCache
#############################################################
cacheInstance_name = "WCMarketingDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "3001"
cacheInstance_cacheProviderType = "WXS"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleMarketingDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )


#############################################################
# 4. create object cache instance: WCSystemDistributedMapCache
#############################################################
cacheInstance_name = "WCSystemDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "1000"
cacheInstance_cacheProviderType = "default"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleSystemDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )

#############################################################
# 5. create object cache instance: WCContractDistributedMapCache
#############################################################
cacheInstance_name = "WCContractDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "1000"
cacheInstance_cacheProviderType = "default"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleContractDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )

#############################################################
# 6. create object cache instance: WCPromotionDistributedMapCache
#############################################################
cacheInstance_name = "WCPromotionDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "1000"
cacheInstance_cacheProviderType = "default"
cacheInstance_cacheName = CBS_brandName + "ExtremeScalePromotionDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )


#############################################################
# 7. create object cache instance: WCPriceDistributedMapCache
#############################################################
cacheInstance_name = "WCPriceDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "1000"
cacheInstance_cacheProviderType = "default"
cacheInstance_cacheName = CBS_brandName + "ExtremeScalePriceDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )


#############################################################
# 8. create object cache instance: WCMiscDistributedMapCache
#############################################################
cacheInstance_name = "WCMiscDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "1000"
cacheInstance_cacheProviderType = "default"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleMiscDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )


#############################################################
# 9. create object cache instance: WCDistributedMapCache
#############################################################
cacheInstance_name = "WCDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "1000"
cacheInstance_cacheProviderType = "default"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )

#############################################################
# 10. create object cache instance: WCSessionDistributedMapCache
#############################################################
cacheInstance_name = "WCSessionDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "2000"
cacheInstance_cacheProviderType = "default"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleSessionDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )



#############################################################
# 11. create object cache instance: WCUserDistributedMapCache
#############################################################
cacheInstance_name = "WCUserDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "8000"
cacheInstance_cacheProviderType = "default"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleUserDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )


#############################################################
# 12. create Servlet cache instance: extremeScaleCache
#############################################################
cacheInstance_name = "extremeScaleCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "2001"
cacheInstance_cacheProviderType = "WXS"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleCacheA"
cacheInstance_type = "ServletCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )

#############################################################
# Final stage
#############################################################

saveAndSyncAndPrintResult()

printCacheProviderAtScope(scopeobjectid)
printAllObjectCacheInstances(scopeobjectid)
printAllServletCacheInstances(scopeobjectid)
    



