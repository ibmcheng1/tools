#!/bin/sh

export WORKING_DIR=${PWD}
echo WORKING_DIR=$WORKING_DIR

export ENV_CONFIG_FILE=${WORKING_DIR}/env_config.properties
echo ENV_CONFIG_FILE=$ENV_CONFIG_FILE

if [ -f $ENV_CONFIG_FILE ]; then
  . $ENV_CONFIG_FILE
else
  echo "ERROR: ENV_CONFIG_FILE=${ENV_CONFIG_FILE} is not found"
  exit 1
fi

echo "---------------------------------"
echo "WAS Parameters"
echo "---------------------------------"
echo ENV_ID=$ENV_ID
echo WAS_PROFILE_ROOT=$WAS_PROFILE_ROOT
echo WAS_USER=$WAS_USER
echo WAS_PASSWORD=$WAS_PASSWORD
export ENV_ID
export WAS_PROFILE_ROOT
export WAS_USER
export WAS_PASSWORD

${WORKING_DIR}/runWsadmin.sh showCaches.py cluster_config.py



