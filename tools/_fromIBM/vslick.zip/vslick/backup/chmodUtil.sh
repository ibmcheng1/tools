#!/bin/sh
fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

for host in $HOSTS
  do
    echo "--------------------> $host"
    
      if [[ ${CURRENT_HOST} == *$host* ]]; then
          chmod -R 777 /opt/csbwxs &
      else
          ssh $host "chmod -R 777 /opt/csbwxs" &
      fi
  done
