####################################################################    
import sys
import os
import fnmatch,re

from java.lang import String

runProcess=""

#import the applications config.py property file with input variables to be used into the script...

dir = os.getcwd()
fileName, fileExtension = os.path.splitext(sys.argv[0])

print "File Name: " + fileName
exec("from " + fileName + " import *")


# This scripts relies on the designated jython script library
# Process the resource file containing all of the admin task definitions

dir = os.getcwd()
print "current dir: " + dir
resources = dir+os.sep+"wsadminlib.py"
execfile(resources)

########################################
# Main
########################################
enableDebugMessages()

CELL_name=getCellName()

print "-------------------------------------------"
print "Retrieve Cell Certificates"
print "-------------------------------------------"
print "CELL_name         = " + CELL_name
print "APPLICATION_name  = " + APPLICATION_name
print "CACHING_certAlias = " + CACHING_certAlias
print "CACHING_host      = " + CACHING_host
print "CACHING_user      = " + CACHING_user
print "CACHING_password  = " + CACHING_password
print "CACHING_grid      = " + CACHING_grid
print "-------------------------------------------"

cellName = CELL_name
appName = APPLICATION_name
certAlias = CACHING_certAlias
cachingHost = CACHING_host
cachingUser = CACHING_user
cachingPassword = CACHING_password
cachingGrid = CACHING_grid

# deleteCellSignerCertificate( cellName, certAlias )
# disableAppXC10SessionMgmt( appName )

# retrieveCellCertificate( cellName, cachingHost , certAlias)
# enableAppXC10SessionMgmt( appName, cachingHost, cachingUser, cachingPassword, cachingGrid )


print "-------------------------------------------"
print "Setup WAS Security - LDAP"
print "-------------------------------------------"
print "GLOBAL_SECURITY_appSecurity = " + GLOBAL_SECURITY_appSecurity

print "-------------------------------------------"
print "Setup WAS Security - LDAP"
print "-------------------------------------------"
print "LDAP_server               = " + LDAP_server
print "LDAP_port                 = " + LDAP_port
print "LDAP_baseDN               = " + LDAP_baseDN
print "LDAP_primaryAdminId       = " + LDAP_primaryAdminId
if LDAP_serverId is not None:
    print "LDAP_serverId             = " + LDAP_serverId
if LDAP_serverPassword is not None:
    print "LDAP_serverPassword       = " + LDAP_serverPassword
print "LDAP_bindDN               = " + LDAP_bindDN
print "LDAP_bindPassword         = " + LDAP_bindPassword
print "LDAP_domain               = " + LDAP_domain
print "LDAP_type                 = " + LDAP_type
# print "LDAP_searchFilter         = " + LDAP_searchFilter
# print "LDAP_sslEnabled           = " + LDAP_sslEnabled
# print "LDAP_sslConfig            = " + LDAP_sslConfig
print "LDAP_enableJava2Security  = " + LDAP_enableJava2Security
print "-------------------------------------------"


print "-------------------------------------------"
print "Run ERClusterJythonScript "
print "-------------------------------------------"
print "ER_ENVIRONMENT             = " + ER_ENVIRONMENT
print "DB2_DBUser                 = " + DB2_DBUser
print "DB2_DBPassword             = " + DB2_DBPassword
print "DB2_DBServer               = " + DB2_DBServer
print "DB2_DBDatabase             = " + DB2_DBDatabase
print "DB2_DBPort                 = " + DB2_DBPort
print "ERAPP_custConf_dir         = " + ERAPP_custConf_dir
print "ERAPP_sdms_limitCustomers  = " + ERAPP_sdms_limitCustomers
print "-------------------------------------------"

isGlobalSecurityEnabled()
isAdminSecurityEnabled()
showSecurityConfig()
isAppSecurityEnabled()
configureAppSecurity(enable = GLOBAL_SECURITY_appSecurity)
isAppSecurityEnabled()

showIdMgrRepositories()
showLDAPUserRegistryId()

enableLTPALDAPSecurity(server = LDAP_server, 
                       port = LDAP_port, 
                       baseDN = LDAP_baseDN,
                       primaryAdminId = LDAP_primaryAdminId,
                       serverId = LDAP_serverId, 
                       serverPassword = LDAP_serverPassword,
                       bindDN = LDAP_bindDN, 
                       bindPassword = LDAP_bindPassword,
                       domain = LDAP_domain,
                       type = LDAP_type,
                       searchFilter = LDAP_searchFilter,
                       sslEnabled = LDAP_sslEnabled,
                       sslConfig = LDAP_sslConfig,
                       enableJava2Security = LDAP_enableJava2Security )
                       

runERClusterJythonScript(ER_ENVIRONMENT = ER_ENVIRONMENT,
                           DBUser = DB2_DBUser,
                           DBPassword = DB2_DBPassword,
                           DBServer = DB2_DBServer,
                           DBDatabase = DB2_DBDatabase,
                           DBPort = DB2_DBPort,
                           custConf_dir = ERAPP_custConf_dir,
                           sdms_limitCustomers = ERAPP_sdms_limitCustomers)

# After enabling LDAP security, if re-start cell, it will need WAS user defined in LDAP server
# Need to ensure LDAP server is ready for WAS cell.

stopAllServerClusters()

stopAllNodeAgents()

stopDmgr()                          
