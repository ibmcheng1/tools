#!/bin/sh

#DPIP=10.106.68.21 TSCPILOT001
#TCH_TSC_CLOUD_ID = TSCPILOT001 | TSCUAT001 | TSCSIT001

echo "DPIP = ${DPIP}"
echo "TCH_TSC_CLOUD_ID" = ${TCH_TSC_CLOUD_ID}   
   
sed -e "s/DATAPOWERIP/$DPIP/g" -e "s/TCH_TSC_CLOUD_ID/$TCH_TSC_CLOUD_ID/g" /db2home/db2inst1/DB2/installScript.sh.template > /db2home/db2inst1/DB2/installScript.sh

echo "chmod on /db2home/db2inst1/DB2/installScript.sh ..."

chmod 777 /db2home/db2inst1/DB2/installScript.sh

sudo -u db2inst1 -i /db2home/db2inst1/DB2/installScript.sh


