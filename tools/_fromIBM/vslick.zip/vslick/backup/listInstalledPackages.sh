#!/bin/sh
echo ======================================
echo running listAvailablePackages.sh
echo ======================================

echo "------------------------------------------"
echo ENV_CONFIG_FILE=$ENV_CONFIG_FILE
echo "------------------------------------------"
if [ -f $ENV_CONFIG_FILE ]; then
  . $ENV_CONFIG_FILE
else
  echo "ERROR: ENV_CONFIG_FILE=${ENV_CONFIG_FILE} is not found"
  exit 1
fi

echo IBMIM_installationDirectory=$IBMIM_installationDirectory
echo IBMIM_REPOSITORIES=$IBMIM_REPOSITORIES

echo ----------------------------------------
echo listing available packages ...
echo ----------------------------------------

if [ ! -d $IBMIM_installationDirectory ]; then
   echo "Error: $IBMIM_installationDirectory does not exist."
else
   cd ${IBMIM_installationDirectory}/eclipse/tools
   ./imcl listAvailablePackages -repositories $IBMIM_REPOSITORIES
fi

echo ======================================
echo end of listAvailablePackages .sh
echo ======================================
