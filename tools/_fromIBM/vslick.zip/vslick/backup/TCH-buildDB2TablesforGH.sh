# make sure DB2 is started
sudo -u db2inst1 db2start
sudo -u db2inst1 db2 "connect to tchdb"
sudo -u db2inst1 db2 -tvf /tmp/GH/ghtester_db2.sql