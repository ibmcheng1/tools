from string import Template

def add_arguments(parser):
  parser.add_argument('--localaddress',required=True)
  parser.add_argument('--remoteaddress',required=True)
  
def get_request(args):
  template = Template('''<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
  <soapenv:Header/>
    <soapenv:Body>
      <dp:request xmlns:dp="http://www.datapower.com/schemas/management">
        <dp:set-config>
	  <SNMPSettings>
	    <mAdminState>enabled</mAdminState>
	    <LocalAddress>${LOCALADDRESS}</LocalAddress>
	    <LocalPort>161</LocalPort>
	    <Targets>
	        <Host>${REMOTEADDRESS}</Host>
	        <Port>162</Port>
	        <Community>public</Community>
	        <TrapVersion>3</TrapVersion>
	        <SecurityName>itcam</SecurityName>
	        <SecurityLevel>authPriv</SecurityLevel>
	    </Targets>
	    <Users class="User">itcam</Users>
	    <SecurityLevel>authPriv</SecurityLevel>
	    <AccessLevel>read-only</AccessLevel>
	    <EnableDefaultTrapSubscriptions>on</EnableDefaultTrapSubscriptions>
	    <TrapPriority>warn</TrapPriority>
	    <TrapEventCode>0x00030002</TrapEventCode>
	    <TrapEventCode>0x00230003</TrapEventCode>
	    <TrapEventCode>0x00330002</TrapEventCode>
	    <TrapEventCode>0x00b30014</TrapEventCode>
	    <TrapEventCode>0x00e30001</TrapEventCode>
	    <TrapEventCode>0x00e40008</TrapEventCode>
	    <TrapEventCode>0x00f30008</TrapEventCode>
	    <TrapEventCode>0x01530001</TrapEventCode>
	    <TrapEventCode>0x01a2000e</TrapEventCode>
	    <TrapEventCode>0x01a40001</TrapEventCode>
	    <TrapEventCode>0x01a40005</TrapEventCode>
	    <TrapEventCode>0x01a40008</TrapEventCode>
	    <TrapEventCode>0x01b10006</TrapEventCode>
	    <TrapEventCode>0x01b10009</TrapEventCode>
	    <TrapEventCode>0x01b20002</TrapEventCode>
	    <TrapEventCode>0x01b20004</TrapEventCode>
	    <TrapEventCode>0x01b20008</TrapEventCode>
	    <TrapEventCode>0x02220001</TrapEventCode>
	    <TrapEventCode>0x02220003</TrapEventCode>
            <TrapEventCode>0x02240002</TrapEventCode>
	  </SNMPSettings>
        </dp:set-config>
      </dp:request>
    </soapenv:Body>
  </soapenv:Envelope>''')
  return template.substitute(LOCALADDRESS=args.localaddress,REMOTEADDRESS=args.remoteaddress)