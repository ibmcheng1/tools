import os
import sys
execfile('wsadminlib.py')

wxsCatalog=""
userid=""
password=""

def getServersByType(type, node):
        servers = []
        nId = AdminConfig.getid('/Node:' + node)
        svrs = AdminConfig.list('Server', nId)
        serverList = svrs.split('\n')
        for server in serverList:
                sType = AdminConfig.showAttribute(server, 'serverType')
                if sType == type:
                        sName = AdminConfig.showAttribute(server, 'name')
                        servers.append(sName)
        return servers


def printUsage():
	print "required parameters: -username <userid> -password <userpassword> -wxsCatalog <ip of catalog server>"
		
#---------------------------------------------------------
#  Configure WAS to use WXS as dynacache provider
#
#---------------------------------------------------------
arglength = len(sys.argv)
if(arglength <6):
	
	printUsage()
	print "error 1"
	sys.exit(-1)
else:
	i = 0  
while ( i < arglength ): 
	if (sys.argv[i] == "-wxsuser"):
		try:
			i = i+1
			userid=sys.argv[i]
		except:
			print("Incorrect number of parameters ")
			printUsage()
			sys.exit(-1)
	if (sys.argv[i] == "-wxspasswd"):
		try:
			i = i+1
			password=sys.argv[i]
		except:
			print("Incorrect number of parameters ")
			printUsage()
			sys.exit(-1)
	elif (sys.argv[i] == "-wxsCatalog"):
		try:
			i=i+1
			wxsCatalog=sys.argv[i]
		except:
			print("Incorrect number of parameters for WCS Server configuration")
			printUsage()
			sys.exit(-1)
	i=i+1

print "using Parameters: "+userid+","+ password +" ,"+wxsCatalog	
# Values for session replication NONE, DATA_REPLICATION,DATABASE
# Server type values include GENERIC_SERVER, WEB_SERVER

cellName = AdminControl.getCell()

#managedNodesStr = AdminTask.listNodes()
managedNodesStr = AdminTask.listManagedNodes()
managedNodes = managedNodesStr.split("\n")
for managedNode in managedNodes:
        print managedNode
        serverList=getServersByType('APPLICATION_SERVER',managedNode)
        for server in serverList:
                print "App Server :" + server
		createJvmProperty(managedNode,server,'com.ibm.websphere.xs.dynacache.topology','remote')
		createJvmProperty(managedNode,server,'com.ibm.websphere.xs.dynacache.disable_recursive_invalidate','true')
		createJvmProperty(managedNode,server,'com.ibm.websphere.xs.dynacache.ignore_value_in_change_event','true')
		createJvmProperty(managedNode,server,'com.ibm.websphere.xs.dynacache.enable_compression','true')
		createJvmProperty(managedNode,server,'com.ibm.ws.cache.CacheConfig.filterInactivityInvalidation','true')
		createJvmProperty(managedNode,server,'com.ibm.ws.cache.CacheConfig.ignoreValueInInvalidationEvent','true')
		createJvmProperty(managedNode,server,'com.ibm.ws.cache.CacheConfig.useServerClassLoader','true')

save()
AdminTask.createXSDomain('[-name csbDomain -default true -properties -defineDomainServers [[%s "" ,2809]]]' % wxsCatalog ) 
save()

print AdminTask.testXSDomainConnection('[-name csbDomain ]') 
