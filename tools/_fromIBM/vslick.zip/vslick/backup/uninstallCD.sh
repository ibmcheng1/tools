#!/bin/ksh
echo ======================================
echo running script01.sh
echo ======================================

echo WORKING_DIR=$WORKING_DIR
echo STERLING_CD_SOFTWARE_PATH=$STERLING_CD_SOFTWARE_PATH
echo CPIO_FILE_NAME=$CPIO_FILE_NAME
echo SterliingCD_TEMP=$SterliingCD_TEMP

echo list $IDS_SOFTWARE_PATH ...
echo
ls -l $STERLING_CD_SOFTWARE_PATH

echo ----------------------------------------
echo installing Sterling CD : ${STERLING_CD_SOFTWARE_PATH}/${CPIO_FILE_NAME}
echo ----------------------------------------
echo copying Sterling CD files to ${SterliingCD_TEMP}
cp -$STERLING_CD_SOFTWARE_PATH/* ${SterliingCD_TEMP}

chmod -R 777 ${SterliingCD_TEMP}
cd ${SterliingCD_TEMP}
echo "currrent directory: " ${PWD}
./cdinstall_a -f cdoptions.txt --cpioFile ${SterliingCD_TEMP}/${CPIO_FILE_NAME}

echo ======================================
echo end of script01.sh
echo ======================================
