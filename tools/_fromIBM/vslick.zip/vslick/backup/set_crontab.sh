#!/bin/bash
set +x

TEMPLATE_LOC=$1

echo "create db2inst1 crontab ... TEMPLATE_LOC=${TEMPLATE_LOC}"
crontab ${TEMPLATE_LOC}/crontab_template

exit 0
