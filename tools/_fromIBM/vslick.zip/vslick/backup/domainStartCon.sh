#!/bin/sh

declare -i SERVER_STARTING_INDEX=0

fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

COUNT=${CONTAINER_NUMBER_PER_NODE}

# DOMAIN number expected as parameter
if [ "$1" = "" ]
then
     # echo "Usage: script <DOMAIN #>"
     # exit
     DOMAIN=${CATALOG_SERVICE_DOMAIN_INDEX}
else
     DOMAIN=$1
fi

echo "DOMAIN = ${DOMAIN} , COUNT = ${COUNT}, CONTAINER_HOSTS = ${CONTAINER_HOSTS}"

# todo implement default slicing logic
dstring="domain${DOMAIN}"
eval DOMAIN_HOSTS=\$domain$DOMAIN
echo "Domain host list set to $DOMAIN_HOSTS"


for host in $CONTAINER_HOSTS
  do
	
	echo "Starting $COUNT Containers in $host $SERVER_STARTING_INDEX"
	if [[ ${CURRENT_HOST} == *$host* ]]; then
		${WORKING_DIR}/startContainerDomain.sh $COUNT $SERVER_STARTING_INDEX &
	else
		ssh $host "cd ${WORKING_DIR}; export JAVA_HOME=${JAVA_HOME}; ${WORKING_DIR}/startContainerDomain.sh $COUNT $SERVER_STARTING_INDEX" &
	fi
       SERVER_STARTING_INDEX=`expr $SERVER_STARTING_INDEX + $COUNT`
  done

date
echo ". . . Waiting for containers to come up . . . "

