#!/bin/ksh
# This script is intended to work on Linux with bash shell or AIX with ksh.
# Be sure to set the first line of the script appriately for the platform where
# it will be run.
#
#########################################################################

# When debugging on IPAS, source the virtualimage.properties
if [ -f /etc/virtualimage.properties ]; then
  . /etc/virtualimage.properties
fi

# temporary assign variable values.
IDS_INSTALL_PATH=/opt/IBM/ldap/V6.3.1
UPDATE_INSTALLER_PATH=/repository/downloads/fixes/ids/v6.3.1.8/eWAS_7.0.0.33/UpdateInstaller
eWAS_INSTALL_PATH=${IDS_INSTALL_PATH}/appsrv

echo WORKING_DIR=$WORKING_DIR
echo IDS_INSTALL_PATH=$IDS_INSTALL_PATH
echo eWAS_INSTALL_PATH=$IDS_INSTALL_PATH

export WORKING_DIR
export IDS_INSTALL_PATH
export eWAS_INSTALL_PATH

echo ======================================
echo installing updateinstaller
echo ======================================
cd $UPDATE_INSTALLER_PATH
./install -options ${UPDATE_INSTALLER_PATH}/responsefile.updiinstaller.txt -silent
cat /opt/IBM/WebSphere/UpdateInstaller/logs/install/log.txt

echo ======================================
echo stopping eWAS process
echo ======================================
${eWAS_INSTALL_PATH}/profiles/TDSWebAdminProfile/bin/stopServer.sh server1

echo ======================================
echo installing wWAS 7.0.0.33
echo ======================================
cd /opt/IBM/WebSphere/UpdateInstaller
./update.sh -silent -options /repository/downloads/fixes/ids/v6.3.1.8/eWAS_7.0.0.33/responsefiles/install.txt

echo ======================================
echo starting eWAS process
echo ======================================
${eWAS_INSTALL_PATH}/profiles/TDSWebAdminProfile/bin/startServer.sh server1

echo ======================================
echo verifyig eWAS version
echo ======================================
${eWAS_INSTALL_PATH}/bin/versionInfo.sh
${eWAS_INSTALL_PATH}/java/bin/java -version
