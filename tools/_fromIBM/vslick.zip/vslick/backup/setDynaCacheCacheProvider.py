import os
import sys
execfile('wsadminlib.py')

#import the applications config.py property file with input variables to be used into the script...

dir = os.getcwd()
fileName, fileExtension = os.path.splitext(sys.argv[0])

print "Configuration File Name: " + fileName
exec("from " + fileName + " import *")
###########################################################

def printObject(name, object ):
    """Return the config object id for the named URIGroup."""
    if object is not None:
        print name + " = " + object
    else:
        print name + " = NONE"

	
def GetPropertiesDictionary(id):
        # needs a valid id and returns a dictionary of attributes
	dictionary = {}
	for item in AdminConfig.show(id).splitlines():
		item = item[1:-1]
		spacePos = item.find(' ')
		dictionary[item[0:spacePos]] = item[spacePos + 1:]
	return dictionary
        
def printPropertiesDictionary(id):
    propertyDictionary = GetPropertiesDictionary(id)
    print "----------------------------------"
    print "PropertyDictionary of id["+id+"]"
    print "----------------------------------"
    print propertyDictionary


def printPropertiesSet(id):
    propertySet = AdminConfig.showAttribute(id, "propertySet")
    if propertySet is None or propertySet == "":
        if propertySet is None:
            print "propertySet is NONE" 
        else:
            print "propertySet is \"\""
    else:
        print "propertySet = " + propertySet

def printCacheProviderAtScope(scopeobjectid):
    print "----------------------------------"
    print "Display All CacheProvider for the scope of " + scopeobjectid 
    print "----------------------------------"
    scope = _getObjectScope(scopeobjectid)
    found = False
    for cacheprovider in getObjectsOfType('CacheProvider'):
        if _getObjectScope(cacheprovider) == scope:
            print "Current cacheprovider = " + cacheprovider
            cacheproviderName = AdminConfig.showAttribute(cacheprovider, "name")
            print "    cacheproviderName = " + cacheproviderName
        #else:
        #    print "    scope not matched"
        #    cacheproviderName = AdminConfig.showAttribute(cacheprovider, "name")
        #    print "    cacheproviderName = " + cacheproviderName
            
    return None

def _getCacheProviderAtScope(scopeobjectid, cacheProviderType):
    scope = _getObjectScope(scopeobjectid)
    found = False
    for cacheprovider in getObjectsOfType('CacheProvider'):   
        if _getObjectScope(cacheprovider) == scope:
            cacheproviderName = AdminConfig.showAttribute(cacheprovider, "name")
            if cacheproviderName == "com.ibm.ws.objectgrid.dynacache.CacheProviderImpl" :               
                if cacheProviderType == "WXS":
                    return cacheprovider    
            else:
                if cacheProviderType != "WXS":
                    return cacheprovider
    
    # if reaching this point, means WXS provider is not found, create it.
    print "WXS Cache Provider is not found, create WXS Cache Provider" 
    if cacheProviderType == "WXS":
        print "Creating WXS Cache Provider"
        cacheprovider = createWXSCacheProvider(scopeobjectid)
        return cacheprovider        
    else:
        print "ERROR: no creation of WXS Cache Provider"
                
    return None


def createWXSCacheProvider ( scopeobjectid):
    name = "com.ibm.ws.objectgrid.dynacache.CacheProviderImpl"
    description = "WXS Cache Provider"
    attrs = []
    attrs.append( [ 'name', name ] )
    attrs.append( [ 'description', description ] )
    cacheProvider = create('CacheProvider', scopeobjectid, attrs, None)
    saveAndSyncAndPrintResult()
    return cacheProvider


def createObjectCache(scopeobjectid, name, jndiname, cacheProviderType):
    cacheprovider = _getCacheProviderAtScope(scopeobjectid, cacheProviderType)    
    if None == cacheprovider:
        raise Exception("COULD NOT FIND CacheProvider [%s] at the same scope as %s" % (cacheProviderType, scopeobjectid))

    return AdminTask.createObjectCacheInstance(cacheprovider, ["-name", name,"-jndiName", jndiname])
    

def createServletCache(scopeobjectid, name, jndiname, cacheProviderType):
    cacheprovider = _getCacheProviderAtScope(scopeobjectid, cacheProviderType)    
    if None == cacheprovider:
        raise Exception("COULD NOT FIND CacheProvider at the same scope as %s" % scopeobjectid)

    return AdminTask.createServletCacheInstance(cacheprovider, ["-name", name,"-jndiName", jndiname])

def printAllObjectCacheInstances():
    """print all cache instances"""
    print "----------------------------------"
    print "Display All Object Cache Instance ..."
    print "----------------------------------"
    cache_ids = _splitlines(AdminConfig.list( 'ObjectCacheInstance' ))
    for id in cache_ids:
        print "cache id = " + id

def printAllServletCacheInstances():
    """print all cache instances"""
    print "----------------------------------"
    print "Display All Servlet Cache Instance ..."
    print "----------------------------------"
    cache_ids = _splitlines(AdminConfig.list( 'ServletCacheInstance' ))
    for id in cache_ids:
        print "cache id = " + id

def removeAllObjectCacheInstances():
    """remove all cache instances"""
    print "----------------------------------"
    print "Remove All Object Cache Instance ..."
    print "----------------------------------"
    cache_ids = _splitlines(AdminConfig.list( 'ObjectCacheInstance' ))
    for id in cache_ids:
        AdminConfig.remove(id)
        AdminConfig.save()    
        print "removed id = " + id

def setObjectCacheSettings( objectcache_id, settingname, settingvalue ):
    """Sets the specified ObjectCacheInstance setting."""
    m = "setObjectCacheSettings:"
    sop(m,"objectcache_id=%s settingname=%s settingvalue=%s" % ( repr(objectcache_id), repr(settingname), repr(settingvalue), ))
    AdminConfig.modify( objectcache_id, [[settingname, settingvalue]])
    actualvalue = AdminConfig.showAttribute( objectcache_id, settingname )
    sop(m,"Exit. Set %s to %s on objectCacheInstance %s" % ( repr(settingname), repr(actualvalue), repr(objectcache_id), ))


def setCacheInstanceSettings( cacheInstance_id, settingname, settingvalue ):
    """Sets the specified Cache Instance setting."""
    m = "setCacheInstanceSettings:"
    sop(m,"cacheInstance_id=%s settingname=%s settingvalue=%s" % ( repr(cacheInstance_id), repr(settingname), repr(settingvalue), ))
    AdminConfig.modify( cacheInstance_id, [[settingname, settingvalue]])
    actualvalue = AdminConfig.showAttribute( cacheInstance_id, settingname )
    sop(m,"Exit. Set %s to %s on Cache Instance %s" % ( repr(settingname), repr(actualvalue), repr(cacheInstance_id), ))

def printJ2EEResourcePropertySet(resourceId):
    propset = AdminConfig.list("J2EEResourcePropertySet", resourceId )
    print "----"
    print "printJ2EEResourcePropertySet(): "
    print "----" 
    if propset is None or propset == "":
        if propset is None:
            print "propset is NONE" 
        else:
            print "propset is \"\""
    else:
        for psItem in _splitlines(AdminConfig.list("J2EEResourceProperty", propset)):
            #print "psItem = " + psItem
            name = AdminConfig.showAttribute(psItem, "name")
            value = AdminConfig.showAttribute(psItem, "value")
            print name + " = " + value
        #endFor
    
    print "----"
    

# Function for creating resource custom properties
def createResourceCustomProperty(envEntry, propName, propValue):
    m = "createResourceCustomProperty"
    sop(m,"Entry: envEntry=%s propName=%s propValue=%s" % (envEntry, propName, propValue))
    propSet = AdminConfig.showAttribute(envEntry, 'propertySet') 
    if propSet == None:
        propSet = AdminConfig.create('J2EEResourcePropertySet',envEntry,[])

    name = ['name', propName]
    value = ['value', propValue]
    propAttrs = [name, value]

    modifiedOne = 0 
    if propSet != "":
            for psItem in _splitlines(AdminConfig.list("J2EEResourceProperty", propSet)):
                name = AdminConfig.showAttribute(psItem, "name")
                value = AdminConfig.showAttribute(psItem, "value")
                #print name + " = " + value
                if (propName == AdminConfig.showAttribute(psItem, "name")):
                    sop(m, "Modifying J2EEResourceProperty [%s , %s]" % (propName, propValue))                      
        	    try:
        	        AdminConfig.modify(psItem, [["value", propValue]])
        	    except AdminException, e:
        	        TR.error(m,"Exception modifying custom property: %s" % e, e)
                        sys.exit(0)
        	    #endTry
                       
                    modifiedOne = 1
                    #break
                #endIf
            #endFor

    if (not modifiedOne):
        sop(m, "Creating J2EEResourceProperty [%s , %s]" % (propName, propValue))
	try:
	    AdminConfig.create('J2EEResourceProperty', propSet, propAttrs)
	except AdminException, e:
	    TR.error(m,"Exception adding cell custom property: %s" % e, e)
            sys.exit(0)
	#endTry
    
    return


# Function for creating resource custom properties
def removeResourceCustomProperty(envEntry, propName):
    m = "removeResourceCustomProperty"
    sop(m,"Entry: envEntry=%s propName=%s" % (envEntry, propName))
    propSet = AdminConfig.showAttribute(envEntry, 'propertySet') 
    if propSet == None or propSet == "":
        return

    for psItem in _splitlines(AdminConfig.list("J2EEResourceProperty", propset)):
        name = AdminConfig.showAttribute(psItem, "name")
        value = AdminConfig.showAttribute(psItem, "value")
        print name + " = " + value
        if (propName == AdminConfig.showAttribute(psItem, "name")):
            sop(m, "Removing J2EEResourceProperty [%s]" % (propName))                      
	    try:
	        AdminConfig.remove(psItem)
	    except AdminException, e:
	        TR.error(m,"Exception removing custom property: %s" % e, e)
                sys.exit(0)
	    #endTry
               
            #break
        #endIf
    #endFor
    return



def createCellCustomProperty( cellId, name, value ):

	methodName = "createCellCustomProperty"

	# Check if custom property already exists	
	propList = AdminConfig.showAttribute(cellId, "properties")
	propList = propList [ 1:len(propList)-1].split(" ")
	modifiedOne = 0
	if (propList != ['']):
		for item in propList:
			itemName = AdminConfig.showAttribute(item, "name")
			if (itemName == name):
				modifiedOne = 1
				try:
					AdminConfig.modify(item, [["value", value]])
					TR.info( methodName, "Modified value of %s to %s." % (name, value))
				except AdminException, e:
					TR.error(methodName,"Exception modifying Cell custom property: %s" % e, e)
					sys.exit(0)
				#endTry
				break
			#endIf
		#endFor
	#endIf

	if (not modifiedOne):
		# create new property
		attrs = []
		attrs.append(["name", name])
		attrs.append(["value", value])
		try:
			AdminConfig.create("Property", cellId, attrs)
			TR.info( methodName, "Created new property with name and value of %s and %s." % (name, value))
		except AdminException, e:
			TR.error(methodName,"Exception adding cell custom property: %s" % e, e)
			sys.exit(0)
		#endTry
	#endIf
#endDef



def setCustomProperty( targetId, propertyName, propertyValue ):
    """Enables seamless failover on the specified targetName (in this cell)."""
    attrs = []
    attrs.append( [ 'name', propertyName ] )
    attrs.append( [ 'value', propertyValue ] )
    removeAndCreate('Property', targetId, attrs, ['name'], 'customProperties')


def createUserCustomProperty( targetId, name, value ):
    #jvm = getServerJvm(nodename,servername)
    attrs = []
    attrs.append( [ 'name', name ] )
    attrs.append( ['value', value] )
    return removeAndCreate('Property', targetId, attrs, ['name'])

#-------------------------------------------------------------------------------------------------
# Create  custom property
#-------------------------------------------------------------------------------------------------
def createCustomProperty (webContainerConfigID, customPropertyName, customPropertyDescription, customPropertyValue, customPropertyRequired ):
   createCounter = 0
   wwString = '[[name "' + str(customPropertyName) +                 '"] [description "' + str(customPropertyDescription) +      '"] [value "' + str(customPropertyValue) + '"] [required "' + str(customPropertyRequired) + '"]]'
   print "wwString: " + str(wwString)

   try: 
      AdminConfig.create('Property', webContainerConfigID, str(wwString)) 
      createCounter = createCounter + 1
   except:
      print " " * indentCount, "Create Web Container custom property " +  str(customPropertyName) + " failed."

   return createCounter

#-------------------------------------------------------------------------------------------------
# edit  custom property
#-------------------------------------------------------------------------------------------------
def editCustomProperty ( cpTarget, cpName, cpDesc, cpValue, cpRequired ):
	#    cpScope     - JVM Custom property scope
	#    cpName      - Name of Custom Property
	#    cpDesc      - Description of Custom Property
	#    cpValue     - Value of the Custom Property
        
        # Check to see if the property exists already (in a true iPAS environment this might never occur)
        propertyList = AdminConfig.list("Property",cpTarget)
        actionType = "create" 
        for prop in propertyList.split("\n"):
            thisProp = prop.rstrip()
            if (thisProp.find(cpName) == 0):
                pStart = thisProp.find('(')
	        propertyMap = thisProp[pStart:] 
                actionType = "modify"
            #endIf
        #endFor


	#jvmMap = AdminConfig.list('JavaVirtualMachine',server)
        
        attrName = ["name", cpName]
        attrDesc = ["description", cpDesc]
        attrValue = ["value", cpValue]
        attrRequired = ["required", cpRequired]

        attrs = [attrName, attrDesc, attrValue, attrRequired]

        if (actionType == "create"):
            print "Create a NEW custom property"
	    #newProperty = AdminConfig.create("Property", jvmMap, attrs )
            newProperty = AdminConfig.create("Property", cpTarget, attrs )
        else:
       	    print "Modify the existing custom property"
            newProperty = AdminConfig.modify(propertyMap, attrs )
        #endElse
        
        print "Custom Property " + cpName + " created successfully!"

#-----------------------------------------------------------------
# createJVMCustomProperty - Create a JVM customer property 
#                           definition to a Server.
#            
#-----------------------------------------------------------------
def createJVMCustomProperty ( cpTarget, cpName, cpDesc, cpValue, cpRequired ):
	#    cpScope     - JVM Custom property scope
	#    cpName      - Name of Custom Property
	#    cpDesc      - Description of Custom Property
	#    cpValue     - Value of the Custom Property


	print " "
	print "Creating Custom JVM Property " + cpName + "..."

        # Cycle through each server node to add the JVM Custom property too... 

	serverList=AdminConfig.list("Server")
	newProperty = ""

	if (len(serverList) > 0):
		for item in serverList.split("\n"):
			server = item.rstrip()
			if (server.find(cpTarget) >= 0):
                                print "SERVER FOUND: " + server

                                # Check to see if the property exists already (in a true iPAS environment this might never occur)
                                propertyList = AdminConfig.list("Property",server)
                                actionType = "create" 
                                for prop in propertyList.split("\n"):
                                    thisProp = prop.rstrip()
                                    if (thisProp.find(cpName) == 0):
                                        pStart = thisProp.find('(')
	                                propertyMap = thisProp[pStart:] 
                                        actionType = "modify"
                                    #endElse
                                #endFor


				jvmMap = AdminConfig.list('JavaVirtualMachine',server)

                 		print "  Name:           " + cpName
		                print "  Description:    " + cpDesc
		                print "  Value:          " + cpValue
                                print "  JVM:            " + jvmMap

                                attrName = ["name", cpName]
                                attrDesc = ["description", cpDesc]
                                attrValue = ["value", cpValue]
                                attrRequired = ["required", cpRequired]

                     		attrs = [attrName, attrDesc, attrValue, attrRequired]

                                if (actionType == "create"):
       	     	                      print "Create a NEW custom property"
	     	                      newProperty = AdminConfig.create("Property", jvmMap, attrs )
                                else:
       	     	                      print "Modify the existing custom property"
                                      newProperty = AdminConfig.modify(propertyMap, attrs )
                                #endElse
			#endIf
		#endFor
	#endIf

        print "Custom Property " + cpName + " created successfully!"
	
	return newProperty 
#endDef


def createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName ):      
        # cacheInstance_type = "ObjectCacheInstance"
        # cacheInstance_name = "WCCatalogGroupDistributedMapCache"
        # cacheInstance_jndiname = "services/cache/" + cacheInstance_name
        # cacheInstance_cacheSize = "2001"
        # cacheInstance_cacheProviderType = "WXS"
        # cacheInstance_cacheName = "YYExtremeScaleCatalogEntryDMC"

        cacheInstanceId = getObjectByName( cacheInstance_type, cacheInstance_name )
        printObject(cacheInstance_name, cacheInstanceId)
        
        if cacheInstanceId is not None:
            print "#########################################"
            print "Edit CacheInstance: " + cacheInstance_name
            print "#########################################"
            printPropertiesDictionary(cacheInstanceId)
            printPropertiesSet(cacheInstanceId)
            
            print "----------------------------------"
            print "Display CustomProperty ..."
            print "----------------------------------"   
            printJ2EEResourcePropertySet(cacheInstanceId)    
            
        else:
            print "#########################################"
            print "Creating CacheInstance: " + cacheInstance_name + ", type = " + cacheInstance_type
            print "#########################################"
            
            if (cacheInstance_type == "ObjectCacheInstance"): 
                cacheInstanceId = createObjectCache(scopeobjectid, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheProviderType)
                # saveAndSyncAndPrintResult()
            else:
                cacheInstanceId = createServletCache(scopeobjectid, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheProviderType)
                # saveAndSyncAndPrintResult()
            
            print "----------------------------------"
            print "Setting Cahce Instance Setting ..."
            print "----------------------------------"
            setCacheInstanceSettings(cacheInstanceId, "cacheSize", cacheInstance_cacheSize)
            saveAndSyncAndPrintResult()
            
            if (cacheInstance_cacheProviderType == "WXS"):
                    print "----------------------------------"
                    print "Setting CustomProperty for WXS cache provider..."
                    print "----------------------------------"
                    customPropertyName = "com.ibm.websphere.xs.dynacache.cache_name"
                    customPropertyValue = cacheInstance_cacheName
                    createResourceCustomProperty(cacheInstanceId, customPropertyName, customPropertyValue)
                    
                    customPropertyName = "com.ibm.ws.cache.CacheConfig.cacheProviderName"
                    customPropertyValue = "com.ibm.ws.objectgrid.dynacache.CacheProviderImpl"
                    createResourceCustomProperty(cacheInstanceId, customPropertyName, customPropertyValue)
                    
                    customPropertyName = "com.ibm.websphere.xs.dynacache.topology"
                    customPropertyValue = "remote"
                    createResourceCustomProperty(cacheInstanceId, customPropertyName, customPropertyValue)
                    
                    saveAndSyncAndPrintResult()
            else:
                    print "----------------------------------"
                    print "Setting CustomProperty for default cache provider..."
                    print "----------------------------------"
        
        printPropertiesDictionary(cacheInstanceId)
        printPropertiesSet(cacheInstanceId)
        printJ2EEResourcePropertySet(cacheInstanceId)
        
        return cacheInstanceId
#endDef

#################################################################
# NEW
#################################################################

def getServerJvmByServerId(server_id):
    """Return the config ID of the JVM object for this server"""
    # the pdefs come back as a string [item item item]
    pdefs = _splitlist(AdminConfig.showAttribute(server_id, 'processDefinitions'))
    pdef = None
    for p in pdefs:
        if -1 != p.find("JavaProcessDef"):
            pdef = p
            break
    if pdef: # found Java ProcessDef
        return _splitlist(AdminConfig.showAttribute(pdef, 'jvmEntries'))[0]

def createJvmPropertyByServerId(server_id,name,value):
    jvm = getServerJvmByServerId(server_id)
    attrs = []
    attrs.append( [ 'name', name ] )
    attrs.append( ['value', value] )
    return removeAndCreate('Property', jvm, attrs, ['name'])

def setDynaCacheByCluster(clusterName) :
    m = "printDynaCacheByCluster:"
    clusterMembers = listServersInCluster(clusterName)
    enabled = "true"
    for clusterMember in clusterMembers:
        nodeName = AdminConfig.showAttribute( clusterMember, "nodeName" )
        serverName = AdminConfig.showAttribute( clusterMember, "memberName" )
        sop(m, "Show DynaCache of Server %s on Node %s" % (serverName, nodeName ))
        
        serverId = getServerId(nodeName,serverName)
        sop(m,"serverId=%s " % ( repr(serverId), ))
        
        print "=============================="
        print "Enabling Servlet Caching on server: " + serverId
        print "=============================="        
        setServletCaching(serverId, enabled)
        #save()
        
        print "=============================="
        print "Current DynaCache before change ..."
        print "=============================="        
        dynacache = AdminConfig.list('DynamicCache',  serverId)
        attributes = AdminConfig.showall(dynacache)
        print "attributes: " + attributes
        
        print "=============================="
        print "DynaCache parameters"
        print "=============================="
        print "dynaCache_cacheProviderType      = " + dynaCache_cacheProviderType
        print "dynaCache_cacheSize              = " + dynaCache_cacheSize
        print "dynaCache_enableCacheReplication = " + dynaCache_enableCacheReplication
        if dynaCache_cacheProviderType == "default":
            print "dynaCache_defaultPriority = " + dynaCache_defaultPriority
            print "dynaCache_enableDiskOffload = " + dynaCache_enableDiskOffload
            print "dynaCache_diskOffloadLocation = " + dynaCache_diskOffloadLocation
            print "dynaCache_diskCacheSizeInGB = " + dynaCache_diskCacheSizeInGB
            print "dynaCache_diskCachePerformanceLevel = " + dynaCache_diskCachePerformanceLevel
            print "dynaCache_pushFrequency = " + dynaCache_pushFrequency
            print "dynaCache_domainName = " + dynaCache_domainName
        print "=============================="
        
        setDynaCache(serverId, dynaCache_cacheProviderType)
        #save()
        #saveAndSyncAndPrintResult()

        if dynaCache_cacheProviderType == "default":
            print "=============================="
            print "Set dynacache[default provider] replication on server level"
            print "=============================="
            domainName = dynaCache_domainName
            enableDynaCacheReplication(nodeName, serverName, domainName, replicationType = 'NONE')

        print "=============================="
        print "Current DynaCache after change ..."
        print "=============================="        
        dynacache = AdminConfig.list('DynamicCache',  serverId)
        attributes = AdminConfig.showall(dynacache)
        print "attributes: " + attributes
        
        print "=============================="
        print "Add WXS specific JVM custom properties ..."
        print "=============================="
        WXS_cache_name = CBS_brandName + "_baseCache"        
        createJvmPropertyByServerId(serverId,'com.ibm.websphere.xs.dynacache.cache_name',WXS_cache_name)

#endDef


def setDynaCache(server_id, cacheProviderType):
    m = "setDynaCache:"
    sop(m,"server_id=%s , cacheProviderType=%s" % ( repr(server_id), cacheProviderType))
    dynacache = AdminConfig.list('DynamicCache',  server_id)
    
    #sop(m,"dynacache=%s " % ( dynacache, ))
    #printPropertiesDictionary(dynacache)
    #printJ2EEResourcePropertySet(dynacache)
    #attributes = AdminConfig.showall(dynacache)
    #print "attributes: " + attributes
    

    print "=============================="
    print "DynaCache parameters"
    print "=============================="
    print "dynaCache_cacheProviderType      = " + dynaCache_cacheProviderType
    print "dynaCache_cacheSize              = " + dynaCache_cacheSize
    print "dynaCache_enableCacheReplication = " + dynaCache_enableCacheReplication
    if dynaCache_cacheProviderType == "default":
        print "dynaCache_defaultPriority = " + dynaCache_defaultPriority
        print "dynaCache_enableDiskOffload = " + dynaCache_enableDiskOffload
        print "dynaCache_diskOffloadLocation = " + dynaCache_diskOffloadLocation
        print "dynaCache_diskCacheSizeInGB = " + dynaCache_diskCacheSizeInGB
        print "dynaCache_diskCachePerformanceLevel = " + dynaCache_diskCachePerformanceLevel
        print "dynaCache_pushFrequency = " + dynaCache_pushFrequency
        print "dynaCache_domainName = " + dynaCache_domainName
    print "=============================="
       
    if dynaCache_cacheProviderType == "WXS":
        print "Setting Dynacache with WXS Cache Provider ... "
        setWXSCacheProvider(dynacache, dynaCache_cacheSize, dynaCache_enableCacheReplication)
    else:      
        print "=============================="
        print "Setting Dynacache with default Cache Provider ... "
        print "=============================="
        setDefaultCacheProvider(dynacache, dynaCache_cacheSize, dynaCache_enableCacheReplication, dynaCache_defaultPriority, dynaCache_enableDiskOffload, dynaCache_diskOffloadLocation, dynaCache_diskCacheSizeInGB, dynaCache_diskCachePerformanceLevel, dynaCache_pushFrequency)
                
#endDef


def setServletCaching( server_id, enabled, ):
    """Enables servlet caching in the webcontainer for the specified server."""
    m = "setServletCaching:"
    sop(m,"server_id=%s " % ( repr(server_id), ))
    if enabled != 'true' and enabled != 'false':
        raise m + " Error: enabled=%s. enabled must be 'true' or 'false'." % ( repr(enabled) )
    webcontainer = AdminConfig.list('WebContainer', server_id)
    sop(m,"webcontainer=%s " % ( repr(webcontainer), ))
    result = AdminConfig.modify(webcontainer, [['enableServletCaching', enabled]])
    sop(m,"Exit. result=%s" % ( repr(result), ))
   
#endDef

def setWXSCacheProvider( dynacache, cacheSize, enableCacheReplication):
    m = "setWXSCacheProvider:"
    sop(m,"dynacache=%s " % ( repr(dynacache), ))
    ### with WXS cache provider, the enableDiskOffload must be false.
    enableDiskOffload = "false"
    AdminConfig.modify(dynacache, [['cacheProvider', 'com.ibm.ws.objectgrid.dynacache.CacheProviderImpl']])
    AdminConfig.modify(dynacache, [['cacheSize', cacheSize]])
    AdminConfig.modify(dynacache, [['enableCacheReplication', enableCacheReplication]])
    AdminConfig.modify(dynacache, [['enableDiskOffload', enableDiskOffload]])
    #setCacheInstanceSettings(dynacache, "cacheSize", cacheSize)
    save()
    sop(m,"Exit.")
#endDef


def setDefaultCacheProvider( dynacache, cacheSize, enableCacheReplication, defaultPriority, enableDiskOffload, diskOffloadLocation, diskCacheSizeInGB, diskCachePerformanceLevel, pushFrequency):
    m = "setDefaultCacheProvider:"
    sop(m,"dynacache=%s " % ( repr(dynacache), ))
    AdminConfig.modify(dynacache, [['cacheProvider', '']])
    AdminConfig.modify(dynacache, [['cacheSize', cacheSize]])
    AdminConfig.modify(dynacache, [['enableCacheReplication', enableCacheReplication]]) 
    AdminConfig.modify(dynacache, [['defaultPriority', defaultPriority]])
    AdminConfig.modify(dynacache, [['enableDiskOffload', enableDiskOffload]])
    AdminConfig.modify(dynacache, [['diskOffloadLocation', diskOffloadLocation]])
    AdminConfig.modify(dynacache, [['diskCacheSizeInGB', diskCacheSizeInGB]])
    AdminConfig.modify(dynacache, [['diskCachePerformanceLevel', diskCachePerformanceLevel]])
    AdminConfig.modify(dynacache, [['pushFrequency', pushFrequency]])
    
    save()
    sop(m,"Exit.")
#endDef

#---------------------------------------------------------
#  Show dynacache configuration
#
#---------------------------------------------------------

enableDebugMessages()

#clusterName is defined in the applications config.py property file (cluster_config.py) 

cellName = AdminControl.getCell()
cellId = getCellId(None)

cluster = getClusterId(clusterName)

printObject("CBS_brandName", CBS_brandName)
printObject("clusterName", clusterName)
printObject("cellName", cellName)
printObject("cellId", cellId) 
printObject("cluster", cluster) 

scopeobjectid = cluster

setDynaCacheByCluster(clusterName)

saveAndSyncAndPrintResult()

