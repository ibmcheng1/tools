#!/bin/ksh

# Copyright IBM Corp. 2011
# All Rights Reserved
# This information contains sample code provided in source code form. You may copy, modify, and distribute these sample programs in any form without payment to IBM for the purposes of developing, using, marketing or distributing application programs conforming to the application programming interface for the operating platform for which the sample code is written. Notwithstanding anything to the contrary,  IBM PROVIDES THE SAMPLE SOURCE CODE ON AN "AS IS" BASIS AND IBM DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND ANY WARRANTY OR CONDITION OF NON-INFRINGEMENT.  IBM SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR OPERATION OF THE SAMPLE SOURCE CODE.  IBM HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS TO THE SAMPLE SOURCE CODE.

echo "---------------------------------"
echo "Parameters set by caller: "
echo "---------------------------------"
echo ENV_ID=$ENV_ID
echo WAS_USER=$WAS_USER
echo WAS_PASSWORD=$WAS_PASSWORD

#$WAS_PROFILE_ROOT/bin/wsadmin.sh -lang jython -user ${WAS_USER} -password ${WAS_PASSWORD} -f $@
       
$WAS_PROFILE_ROOT/bin/wsadmin.sh -lang jython -conntype SOAP -host $host -port $port -user ${WAS_USER} -password ${WAS_PASSWORD} -f $@

