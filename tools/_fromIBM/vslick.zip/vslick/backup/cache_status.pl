#!/usr/bin/perl
#------------------------------------------------------------------------
# Copyright IBM Corporation 2005, 2006, 2007, 2008, 2010, 2013
#------------------------------------------------------------------------
# Program: cachemon.pl
# Purpose: Gather WebSphere DynaCache statistics by issuing an HTTP 1.1
#          call to the relevent URL's and extracting from the resulting
#          HTML stream.
# Prereq:  You need Perl (obviously) and you need to have run the "h2ph"
#          command (as root) to create Perl header files, specifically
#          sys/socket.ph is needed.
# History:
# 2005/10/04 Created.
# 2006/02/21 Extract out logbase into a variable
# 2010/08/31 Changes for WAS v7
# 2013/01/31 Update for when disk offload disabled
#------------------------------------------------------------------------
# Sample cron entry:
# 01 0 * * * /usr/local/bin/cachemon.pl >/dev/null 2>&1
#------------------------------------------------------------------------

require 'sys/socket.ph';

sub GetDateTime();
sub GetWeekDay();
sub GetDate();
sub CheckExitMidnight();

#---------------------------------
# User Adjustables
#---------------------------------
#y $loopFrequencySeconds=60;        # seconds
my $loopFrequencySeconds=120;       # seconds
#y $loopcount=1440;                 # loops before exiting (24 hours)
my $loopcount=720;                  # loops before exiting (24 hours)
my $LogLevel="long";                # short or long
my $tcpport = "60002";              # Port to access cachemonitor at
my $logbase = "/tmp/cachestatus";   # log prefix including full path info
#---------------------------------
# End of User Adjustables
#---------------------------------


#---------------------------------------------------------------------------
sub open_socket
#---------------------------------------------------------------------------
{
    #----------------------------------
    # DO NOT MESS WITH THIS FUNCTION!!!
    #----------------------------------
    local($host,$port) = @_;
    $sockaddr='S n a4 x8';
    # chop($hostname=`hostname`);
    $port=(getservbyname($port, 'tcp'))[2]  unless $port =~ /^\d+$/;
    $me=pack($sockaddr,&AF_INET,0,(gethostbyname($hostname))[4]);
    $them=pack($sockaddr,&AF_INET,$port,(gethostbyname($host))[4]);
    socket(S,&PF_INET,&SOCK_STREAM,(getprotobyname('tcp'))[2]) || die "socket: $!";
    bind(S,$me) || return "bind: $!";
    connect(S,$them) || return "connect: $!";
    select(S); 
    $| = 1; 
    select(stdout);
    return "";
}


#---------------------------------------------------------------------------
# MAIN Main main
#---------------------------------------------------------------------------

   umask(022);
   setpriority(0,0,5);

   my $formatstringlong  = "%s  %6d  %6d  %6d  %10d  %10d  %10d  %10d  %10d  %7.1f  %6s\n",
   my $formatstringshort = "%s  %6d  %6d  %6d  %10d  %10d\n",

   my $hostname; chop($hostname=`hostname -s`);
   my $server = $hostname . ".staples.com";

   my $request1 = "GET /cachemonitor/statistics.jsp HTTP/1.1";
   my $request2 = "GET /cachemonitor/diskStatistics.jsp HTTP/1.1";
   my $request3 = "GET /cachemonitor/selectInstance.jsp?instance=baseCache HTTP/1.1";
   my $request4 = "GET /cachemonitor/selectInstance.jsp?refresh=true";

   #---------------------------------
   # Define cookie fields
   #---------------------------------
   my $cookieA = sprintf("Host: %s:%d",$server,$tcpport);
   my $cookieB = "Connection: Keep-Alive, TE";
   my $cookieC = "TE: trailers, deflate, gzip, compress";
   my $cookieD = "User-Agent: Fishzilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0) RPT-HTTPClient/0.3-3";
   my $cookieE = "Accept-Language: en-US";
   my $cookieF = "Accept: */*";
   my $cookieG = "Accept-Encoding: deflate, gzip, x-gzip, compress, x-compress";

   #---------------------------------
   # Construct full requests
   #---------------------------------
   $cookieA  = $cookieA . "\xd\xa" . $cookieB . "\xd\xa" . $cookieC . "\xd\xa" . $cookieD;
   $cookieA  = $cookieA . "\xd\xa" . $cookieE . "\xd\xa" . $cookieF . "\xd\xa" . $cookieG . "\xd\xa\xd\xa";
   $request1 = $request1 . "\xd\xa" . $cookieA;
   $request2 = $request2 . "\xd\xa" . $cookieA;
   $request3 = $request3 . "\xd\xa" . $cookieA;
   $request4 = $request4 . "\xd\xa" . $cookieA;

    #printf("D0: %s\n",$request1);
    #printf("D0: %s\n",$request2);
   # exit;

   #---------------------------------
   # Start main loop
   #---------------------------------
   while ( $loopcount )
   {
      $loopcount--;

      $outputfile=$logbase . "." . $hostname . "." . GetDate() . ".log";

      $outputfile2 = $outputfile;
      $outputfile=">>" . $outputfile;

      if ( ! -f $outputfile2 ) {
         # create log if needed
         open OUTFILE,$outputfile;
         if ( $LogLevel eq "long" ) {
            print OUTFILE "Date       Time      MaxInMem  InMem  OnDisk  CacheHits CacheMisses LRUEvicts ExplicitRemovals DiskEntries DiskSizeMB TimeoutInval\n";
         }
         elsif ( $LogLevel eq "short" ) {
            print OUTFILE "Date       Time      MaxInMem  InMem  OnDisk  CacheHits CacheMisses\n";
         }
         close OUTFILE;

         # manage the link...
	 # $commandstring=sprintf("/usr/bin/ln -f -s %s %s.log",$outputfile2,$logbase);
	 # system($commandstring);
      }

      $datetime = GetDateTime();  # used for logging

      #---------------------------------
      # Open socket
      #---------------------------------
      $status=&open_socket($server,$tcpport);
      if (! $status) {

          #printf("D7: Connected to port %d on %s\n",$tcpport,$server);

         #---------------------------------
         # Force cache instance
         #---------------------------------
         print S "$request3";
         while (<S>) { chomp; if ( /<\/HTML>/i ) { last; } }

      #  print S "$request4";
      #  while (<S>) { chomp; if ( /<\/HTML>/i ) { last; } }

          #printf("D8a: Issuing %s\n",$request1);
         #---------------------------------
         # Issue 1st URL
         #---------------------------------
         $count=-1;
         print S "$request1";
         while (<S>) {
            chomp;
            # printf("D1: [%s]\n",$_);
            if ( /<\/HTML>/i ) { last; }
            if ( /class=\"description-text\"/ ) {
               # printf("D2: [%s]\n",$_);
               s/^.*class=\"description-text\">//;
               s/<.*$//;
               s/ //g;
               $count++;
               $tempz[$count] = $_;
            }
         }
          #printf("D8d: Done with request1\n");
          #printf("D9a: Issuing %s\n",$request2);
 
         #---------------------------------
         # Issue 2nd URL
         #---------------------------------
         print S "$request2";
         while (<S>) {
            chomp;
            # printf("D9b: [%s]\n",$_);
            if ( /<\/HTML>/i ) { last; }
            if ( /class=\"description-text\"/ ) {
               # printf("D2: [%s]\n",$_);
               s/^.*class=\"description-text\">//;
               s/<.*$//;
               s/ //g;
               $count++;
               $tempz[$count] = $_;
            }
         }
         # printf("D9d: Done with request2\n");
         close(S);
      }
      else {
         ; # exit(1);
      }

      if (0) {
         for ( $mmm=0 ; $mmm<=$count ; $mmm++) {
            printf("D8: %d '%s'\n",$mmm,$tempz[$mmm]);
         }
      }

      if ( $#tempz <= 17 ) {
         # needed in case disk offload disabled
         for ( $mmm=$#tempz+1 ; $mmm<=27 ; $mmm++) { $tempz[$mmm]=0; }
      }

      #---------------------------------
      # Log results
      #---------------------------------
      if ( $status ) {
         $outstring = sprintf("%s Unable to connect to port %d: status = %s\n",$datetime,$tcpport,$status); 
      }
      elsif ( $LogLevel eq "long" ) {
         $outstring = sprintf($formatstringlong,
                              $datetime,
                              $tempz[1], $tempz[3], $diskentries, $tempz[5], $tempz[7],
                              $tempz[9],$tempz[11],$tempz[19],$tempz[21],$tempz[27]);
      }
      elsif ( $LogLevel eq "short" ) {
         $outstring = sprintf($formatstringshort,
                              $datetime,
                              $tempz[1], $tempz[3], $diskentries, $tempz[5], $tempz[7]);
      }

      # print $outstring;
      open OUTFILE,$outputfile;
      print OUTFILE $outstring;
      close OUTFILE;

      if ( CheckExitMidnight() ) {
         exit(0); # midnight is here - exit now
      }

      sleep($loopFrequencySeconds);

   }  # loopcount

   exit(0); # all loops completed


#--------------------------------------------------------------
sub GetDateTime()
#--------------------------------------------------------------
{
   ($tSec,$tMin,$tHour,$tDay,$tMon,$tYear,,,)=localtime(time);
   return sprintf("%04d/%02d/%02d %02d:%02d:%02d",
       $tYear+=1900,$tMon+=1,$tDay,$tHour,$tMin,$tSec);
}

#--------------------------------------------------------------
sub GetDate()
#--------------------------------------------------------------
{
   ($tSec,$tMin,$tHour,$tDay,$tMon,$tYear,,,)=localtime(time);
   return sprintf("%04d%02d%02d",
       $tYear+=1900,$tMon+=1,$tDay);
}

#--------------------------------------------------------------
sub GetWeekDay()
#--------------------------------------------------------------
{
   ($tSec,$tMin,$tHour,$tDay,$tMon,$tYear,$tWeekDay,,)=localtime(time);
   if ( $tWeekDay == 0 ) { return "Sun"; }
   if ( $tWeekDay == 1 ) { return "Mon"; }
   if ( $tWeekDay == 2 ) { return "Tue"; }
   if ( $tWeekDay == 3 ) { return "Wed"; }
   if ( $tWeekDay == 4 ) { return "Thu"; }
   if ( $tWeekDay == 5 ) { return "Fri"; }
                           return "Sat";
}

#--------------------------------------------------------------
sub CheckExitMidnight()
#--------------------------------------------------------------
{
   # If the julian date from now to projected time changes, then exit
   my @t1=localtime(time);
   my @t2=localtime(time+$loopFrequencySeconds);
   if ( $t1[7] != $t2[7] ) { return 1; }
   return 0;
}

