#!/bin/sh
echo ======================================
echo running listAvailablePackages.sh
echo ======================================

echo WORKING_DIR=$WORKING_DIR
REPOSITORIES=${WAS_855_SOFTWARE_PATH},${WAS_855_SUPPL_SOFTWARE_PATH},${WXS_86_SOFTWARE_PATH}
echo REPOSITORIES=$REPOSITORIES

# Location:
#  AIX   = /opt/IBM/InstallationManager
#  Linux = /opt/ibm/InstallationManager
IBMIM_installationDirectory=/opt/ibm/InstallationManager

echo ----------------------------------------
echo listing available packages ...
echo ----------------------------------------

if [ ! -d $IBMIM_installationDirectory ]; then
   echo "  Error: $IBMIM_installationDirectory does not exist."
else
   cd ${IBMIM_installationDirectory}/eclipse/tools
   ./imcl listAvailablePackages -repositories $REPOSITORIES
   cd $WORKING_DIR
fi

echo ======================================
echo end of listAvailablePackages .sh
echo ======================================
