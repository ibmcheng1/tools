############################################################
### ER Application Configuration Property file 
### Version 1.0
############################################################

ER_ENVIRONMENT = "int"
APPLICATION_name = "EarlyResolutionApp"

###########################################################################################################################################
###   Signer Certification and HTTP Session Management CONFIGURATION
###
###   Used to retrieve XC10 signer certification and configure session management with XC10 on the application.

CACHING_certAlias = "cachingalias"
CACHING_host = "20.176.240.149"
CACHING_user = "sessionERDev01"
CACHING_password = "cscibm_@UhTvF2CpD4u4"
CACHING_grid = "sessionERDev01"


###########################################################################################################################################
###   WAS Security configuration
###
###   

GLOBAL_SECURITY_appSecurity = "true"

print "-------------------------------------------"
print "ER_config.py: Global Security properties"
print "-------------------------------------------"
print "GLOBAL_SECURITY_appSecurity = " + GLOBAL_SECURITY_appSecurity

LDAP_server = "20.176.240.138" 
LDAP_port = "389" 
LDAP_baseDN = ""
LDAP_primaryAdminId = "cscwsadmin"
LDAP_serverId = None 
LDAP_serverPassword = None
LDAP_bindDN = "cn=root" 
LDAP_bindPassword = "passw0rd"
LDAP_domain = ""
LDAP_type = "IBM_DIRECTORY_SERVER"
LDAP_searchFilter = { 'userFilter': '(&(uid=%v)(objectclass=inetOrgPerson))', 'groupFilter': '(&(cn=%v)(|(objectclass=groupOfNames)(objectclass=groupOfUniqueNames)))' }
LDAP_sslEnabled = None
LDAP_sslConfig = None
LDAP_enableJava2Security = "false"


print "-------------------------------------------"
print "ER_config.py: LDAP properties"
print "-------------------------------------------"
print "LDAP_server               = " + LDAP_server
print "LDAP_port                 = " + LDAP_port
print "LDAP_baseDN               = " + LDAP_baseDN
print "LDAP_primaryAdminId       = " + LDAP_primaryAdminId
if LDAP_serverId is not None:
    print "LDAP_serverId             = " + LDAP_serverId
if LDAP_serverPassword is not None:
    print "LDAP_serverPassword       = " + LDAP_serverPassword
print "LDAP_bindDN               = " + LDAP_bindDN
print "LDAP_bindPassword         = " + LDAP_bindPassword
print "LDAP_domain               = " + LDAP_domain
print "LDAP_type                 = " + LDAP_type
# print "LDAP_searchFilter         = " + LDAP_searchFilter
# print "LDAP_sslEnabled           = " + LDAP_sslEnabled
# print "LDAP_sslConfig            = " + LDAP_sslConfig
print "LDAP_enableJava2Security  = " + LDAP_enableJava2Security
print "-------------------------------------------"


print "-------------------------------------------"
print "ER_config.py: ER DB2 properties"
print "-------------------------------------------"
print "-------------------------------------------"
print "ER_config.py: ER DB2 properties"
print "-------------------------------------------"
# DB2_DBUser = "db2inst1"
DB2_DBUser = "loadwusr"
DB2_DBPassword = "password" 
DB2_DBServer = "20.176.240.136"
# DB2_DBDatabase = "UATAPTST"
DB2_DBDatabase = "UAT"
DB2_DBPort = "50000"

print "-------------------------------------------"
print "ER_config.py: ER application specific properties"
print "-------------------------------------------"
ERAPP_custConf_dir = "/home/virtuser/" + ER_ENVIRONMENT
ERAPP_sdms_limitCustomers = ""


print "-------------------------------------------"
print "ER_config.py: ERClusterJythonScript properties"
print "-------------------------------------------"
print "ER_ENVIRONMENT             = " + ER_ENVIRONMENT
print "DB2_DBUser                 = " + DB2_DBUser
print "DB2_DBPassword             = " + DB2_DBPassword
print "DB2_DBServer               = " + DB2_DBServer
print "DB2_DBDatabase             = " + DB2_DBDatabase
print "DB2_DBPort                 = " + DB2_DBPort
print "ERAPP_custConf_dir         = " + ERAPP_custConf_dir
if ERAPP_sdms_limitCustomers is not None:
    print "ERAPP_sdms_limitCustomers  = " + ERAPP_sdms_limitCustomers
print "-------------------------------------------"


