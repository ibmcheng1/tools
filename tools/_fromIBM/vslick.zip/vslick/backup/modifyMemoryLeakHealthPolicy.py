
###############################################################################
# Licensed Material - Property of IBM
# 5724-I63, 5724-H88, (C) Copyright IBM Corp. 2013 - All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.
#
# DISCLAIMER:
# The following source code is sample code created by IBM Corporation.
# This sample code is provided to you solely for the purpose of assisting you
# in the  use of  the product. The code is provided 'AS IS', without warranty or
# condition of any kind. IBM shall not be liable for any damages arising out of 
# your use of the sample code, even if IBM has been advised of the possibility 
# of such damages.
###############################################################################
# Module:	setMemoryLeakHealthPolicy	
# 
# Description:	Create a cell custom property if it does not exist, otherwise
#		modify it.
#
# Author:	Chong Lee  chonglee@us.ibm.com
#
# History:	11DEC2013 - initial creation
#******************************************************************************
import sys
import utils
from Trace import Trace,Level
from com.ibm.websphere.management.exception import AdminException

# Instantiate a module level Trace instance
TR = Trace(__name__)

CELL_CUSTOM_PROPS_FILE = sys.argv[1]

#******************************************************************************
# Method Name:setMemoryLeakHealthPolicy	
# Desription:	Sets up the memory Leak Health property
#
# Parameters:	
#		name
#		desc
#		reactionMode
#		level
#		clusterType
#		addMember
#
# Author:   	Chong Lee- chonglee@us.ibm.com   	
#******************************************************************************
def setMemoryLeakHealthPolicy(  name,desc,reactionMode,level,clusterType,addMember ):

	methodName = "setMemoryLeakHealthPolicy"
	try:
              print "------------setting "+name+" ------------------"
              AdminTask.createHealthPolicy("-name "+name+" -description \""+desc+"\" -reactionMode "+reactionMode+" -addCondition [-type MEMORY_LEAK -params [[level "+level+"]]] -addAction [[HEAPDUMP 1] [RESTART_SERVER 2]] -addMember[["+clusterType+" "+addMember+"]]")
	except AdminException, e:
		TR.error(methodName,"Exception setting MemoryLeak Heap size: %s" % e,e)
		sys.exit(0)
	#endtry


####
def deleteMemoryLeak(name):
	methodName="deleteMemoryLeak"
	try:
		print "------------Deleting "+name+" ------------------"
		AdminTask.deleteHealthPolicy("[ -name "+name+"]")
		AdminConfig.save()
	except AdminException, e:
		TR.error(methodName, "Exception deleting "+name+" Health Policy: %s" %e,e)
		sys.exit(0)
	#endtry


methodName = "main"
TR.info(methodName, '*** Starting setMemoryLeakHealthPolicy  ***')

utils.readProperties ( CELL_CUSTOM_PROPS_FILE )

custom = utils.getProperty("CELL_CUSTOM.0")
baseName = "CELL_CUSTOM"


index=0
mapping = '['+custom+']'
while 1==1:
	custom = utils.getProperty(baseName + "." + str(index))

	if (custom == ''):
		 break
	#endIf

	# Pull the cell custom property parameters from the list
	itemList = custom.split(',')
	propname = itemList[0]
	print "propname: "+propname
	propdesc = itemList[1]
	print "Description: " + propdesc
	propreactionMode = itemList[2]
	print "propreactionMode: "+ propreactionMode
	propLevel=itemList[3]
	print "propLevel: " + propLevel
	propClusterType=itemList[4]
	print "propClusterType: " + propClusterType
	propAddMember=itemList[5]
	print "propAddMember :" + propAddMember
        deleteMemoryLeak(propname)
	setMemoryLeakHealthPolicy(propname,propdesc,propreactionMode,propLevel,propClusterType,propAddMember)
	mapping += '['+custom+']'
	index +=1
	continue
#endWhile

AdminConfig.save()
