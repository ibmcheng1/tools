import os
import sys
execfile('wsadminlib.py')

#import the applications config.py property file with input variables to be used into the script...

dir = os.getcwd()
fileName, fileExtension = os.path.splitext(sys.argv[0])

print "Configuration File Name: " + fileName
exec("from " + fileName + " import *")
###########################################################

def printObject(name, object ):
    """Return the config object id for the named URIGroup."""
    if object is not None:
        print name + " = " + object
    else:
        print name + " = NONE"

	
def GetPropertiesDictionary(id):
        # needs a valid id and returns a dictionary of attributes
	dictionary = {}
	for item in AdminConfig.show(id).splitlines():
		item = item[1:-1]
		spacePos = item.find(' ')
		dictionary[item[0:spacePos]] = item[spacePos + 1:]
	return dictionary
        
def printPropertiesDictionary(id):
    propertyDictionary = GetPropertiesDictionary(id)
    print "----------------------------------"
    print "PropertyDictionary of id["+id+"]"
    print "----------------------------------"
    print propertyDictionary


def printPropertiesSet(id):
    propertySet = AdminConfig.showAttribute(id, "propertySet")
    if propertySet is None or propertySet == "":
        if propertySet is None:
            print "propertySet is NONE" 
        else:
            print "propertySet is \"\""
    else:
        print "propertySet = " + propertySet

def printCacheProviderAtScope(scopeobjectid):
    print "----------------------------------"
    print "Display All CacheProvider for the scope of " + scopeobjectid 
    print "----------------------------------"
    scope = _getObjectScope(scopeobjectid)
    found = False
    for cacheprovider in getObjectsOfType('CacheProvider'):
        if _getObjectScope(cacheprovider) == scope:
            print "Current cacheprovider = " + cacheprovider
            cacheproviderName = AdminConfig.showAttribute(cacheprovider, "name")
            print "    cacheproviderName = " + cacheproviderName
        #else:
        #    print "    scope not matched"
        #    cacheproviderName = AdminConfig.showAttribute(cacheprovider, "name")
        #    print "    cacheproviderName = " + cacheproviderName
            
    return None

def _getCacheProviderAtScope(scopeobjectid, cacheProviderType):
    scope = _getObjectScope(scopeobjectid)
    found = False
    for cacheprovider in getObjectsOfType('CacheProvider'):   
        if _getObjectScope(cacheprovider) == scope:
            cacheproviderName = AdminConfig.showAttribute(cacheprovider, "name")
            if cacheproviderName == "com.ibm.ws.objectgrid.dynacache.CacheProviderImpl" :               
                if cacheProviderType == "WXS":
                    return cacheprovider    
            else:
                if cacheProviderType != "WXS":
                    return cacheprovider
    
    # if reaching this point, means WXS provider is not found, create it.
    print "WXS Cache Provider is not found, create WXS Cache Provider" 
    if cacheProviderType == "WXS":
        print "Creating WXS Cache Provider"
        cacheprovider = createWXSCacheProvider(scopeobjectid)
        return cacheprovider        
    else:
        print "ERROR: no creation of WXS Cache Provider"
                
    return None


def createWXSCacheProvider ( scopeobjectid):
    name = "com.ibm.ws.objectgrid.dynacache.CacheProviderImpl"
    description = "WXS Cache Provider"
    attrs = []
    attrs.append( [ 'name', name ] )
    attrs.append( [ 'description', description ] )
    cacheProvider = create('CacheProvider', scopeobjectid, attrs, None)
    saveAndSyncAndPrintResult()
    return cacheProvider


def createObjectCache(scopeobjectid, name, jndiname, cacheProviderType):
    cacheprovider = _getCacheProviderAtScope(scopeobjectid, cacheProviderType)    
    if None == cacheprovider:
        raise Exception("COULD NOT FIND CacheProvider [%s] at the same scope as %s" % (cacheProviderType, scopeobjectid))

    return AdminTask.createObjectCacheInstance(cacheprovider, ["-name", name,"-jndiName", jndiname])
    

def createServletCache(scopeobjectid, name, jndiname, cacheProviderType):
    cacheprovider = _getCacheProviderAtScope(scopeobjectid, cacheProviderType)    
    if None == cacheprovider:
        raise Exception("COULD NOT FIND CacheProvider at the same scope as %s" % scopeobjectid)

    return AdminTask.createServletCacheInstance(cacheprovider, ["-name", name,"-jndiName", jndiname])

def printAllObjectCacheInstances():
    """print all object cache instances"""
    print "----------------------------------"
    print "Display All Object Cache Instance.  scope = " + scope
    print "----------------------------------"
    cache_ids = _splitlines(AdminConfig.list( 'ObjectCacheInstance' ))
    for id in cache_ids:
        #print "cache id = " + id
        cacheName = AdminConfig.showAttribute( id, "name" )
        idscope = _getObjectScope(id)
        if scope == idscope:
            print "cacheName = " + cacheName
     
def printAllServletCacheInstances():
    """print all servlet cache instances"""
    print "----------------------------------"
    print "Display All Servlet Cache Instance.  scope = " + scope
    print "----------------------------------"
    cache_ids = _splitlines(AdminConfig.list( 'ServletCacheInstance' ))
    for id in cache_ids:
        #print "cache id = " + id
        cacheName = AdminConfig.showAttribute( id, "name" )
        idscope = _getObjectScope(id)
        if scope == idscope:
            print "cacheName = " + cacheName

def setObjectCacheSettings( objectcache_id, settingname, settingvalue ):
    """Sets the specified ObjectCacheInstance setting."""
    m = "setObjectCacheSettings:"
    sop(m,"objectcache_id=%s settingname=%s settingvalue=%s" % ( repr(objectcache_id), repr(settingname), repr(settingvalue), ))
    AdminConfig.modify( objectcache_id, [[settingname, settingvalue]])
    actualvalue = AdminConfig.showAttribute( objectcache_id, settingname )
    sop(m,"Exit. Set %s to %s on objectCacheInstance %s" % ( repr(settingname), repr(actualvalue), repr(objectcache_id), ))


def setCacheInstanceSettings( cacheInstance_id, settingname, settingvalue ):
    """Sets the specified Cache Instance setting."""
    m = "setCacheInstanceSettings:"
    sop(m,"cacheInstance_id=%s settingname=%s settingvalue=%s" % ( repr(cacheInstance_id), repr(settingname), repr(settingvalue), ))
    AdminConfig.modify( cacheInstance_id, [[settingname, settingvalue]])
    actualvalue = AdminConfig.showAttribute( cacheInstance_id, settingname )
    sop(m,"Exit. Set %s to %s on Cache Instance %s" % ( repr(settingname), repr(actualvalue), repr(cacheInstance_id), ))

def printJ2EEResourcePropertySet(resourceId):
    propset = AdminConfig.list("J2EEResourcePropertySet", resourceId )
    print "----"
    print "printJ2EEResourcePropertySet(): "
    print "----" 
    if propset is None or propset == "":
        if propset is None:
            print "propset is NONE" 
        else:
            print "propset is \"\""
    else:
        for psItem in _splitlines(AdminConfig.list("J2EEResourceProperty", propset)):
            #print "psItem = " + psItem
            name = AdminConfig.showAttribute(psItem, "name")
            value = AdminConfig.showAttribute(psItem, "value")
            print name + " = " + value
        #endFor
    
    print "----"
    

# Function for creating resource custom properties
def createResourceCustomProperty(envEntry, propName, propValue):
    m = "createResourceCustomProperty"
    sop(m,"Entry: envEntry=%s propName=%s propValue=%s" % (envEntry, propName, propValue))
    propSet = AdminConfig.showAttribute(envEntry, 'propertySet') 
    if propSet == None:
        propSet = AdminConfig.create('J2EEResourcePropertySet',envEntry,[])

    name = ['name', propName]
    value = ['value', propValue]
    propAttrs = [name, value]

    modifiedOne = 0 
    if propSet != "":
            for psItem in _splitlines(AdminConfig.list("J2EEResourceProperty", propSet)):
                name = AdminConfig.showAttribute(psItem, "name")
                value = AdminConfig.showAttribute(psItem, "value")
                #print name + " = " + value
                if (propName == AdminConfig.showAttribute(psItem, "name")):
                    sop(m, "Modifying J2EEResourceProperty [%s , %s]" % (propName, propValue))                      
        	    try:
        	        AdminConfig.modify(psItem, [["value", propValue]])
        	    except AdminException, e:
        	        TR.error(m,"Exception modifying custom property: %s" % e, e)
                        sys.exit(0)
        	    #endTry
                       
                    modifiedOne = 1
                    #break
                #endIf
            #endFor

    if (not modifiedOne):
        sop(m, "Creating J2EEResourceProperty [%s , %s]" % (propName, propValue))
	try:
	    AdminConfig.create('J2EEResourceProperty', propSet, propAttrs)
	except AdminException, e:
	    TR.error(m,"Exception adding cell custom property: %s" % e, e)
            sys.exit(0)
	#endTry
    
    return


# Function for creating resource custom properties
def removeResourceCustomProperty(envEntry, propName):
    m = "removeResourceCustomProperty"
    sop(m,"Entry: envEntry=%s propName=%s" % (envEntry, propName))
    propSet = AdminConfig.showAttribute(envEntry, 'propertySet') 
    if propSet == None or propSet == "":
        return

    for psItem in _splitlines(AdminConfig.list("J2EEResourceProperty", propset)):
        name = AdminConfig.showAttribute(psItem, "name")
        value = AdminConfig.showAttribute(psItem, "value")
        print name + " = " + value
        if (propName == AdminConfig.showAttribute(psItem, "name")):
            sop(m, "Removing J2EEResourceProperty [%s]" % (propName))                      
	    try:
	        AdminConfig.remove(psItem)
	    except AdminException, e:
	        TR.error(m,"Exception removing custom property: %s" % e, e)
                sys.exit(0)
	    #endTry
               
            #break
        #endIf
    #endFor
    return



def createCellCustomProperty( cellId, name, value ):

	methodName = "createCellCustomProperty"

	# Check if custom property already exists	
	propList = AdminConfig.showAttribute(cellId, "properties")
	propList = propList [ 1:len(propList)-1].split(" ")
	modifiedOne = 0
	if (propList != ['']):
		for item in propList:
			itemName = AdminConfig.showAttribute(item, "name")
			if (itemName == name):
				modifiedOne = 1
				try:
					AdminConfig.modify(item, [["value", value]])
					TR.info( methodName, "Modified value of %s to %s." % (name, value))
				except AdminException, e:
					TR.error(methodName,"Exception modifying Cell custom property: %s" % e, e)
					sys.exit(0)
				#endTry
				break
			#endIf
		#endFor
	#endIf

	if (not modifiedOne):
		# create new property
		attrs = []
		attrs.append(["name", name])
		attrs.append(["value", value])
		try:
			AdminConfig.create("Property", cellId, attrs)
			TR.info( methodName, "Created new property with name and value of %s and %s." % (name, value))
		except AdminException, e:
			TR.error(methodName,"Exception adding cell custom property: %s" % e, e)
			sys.exit(0)
		#endTry
	#endIf
#endDef



def setCustomProperty( targetId, propertyName, propertyValue ):
    """Enables seamless failover on the specified targetName (in this cell)."""
    attrs = []
    attrs.append( [ 'name', propertyName ] )
    attrs.append( [ 'value', propertyValue ] )
    removeAndCreate('Property', targetId, attrs, ['name'], 'customProperties')


def createUserCustomProperty( targetId, name, value ):
    #jvm = getServerJvm(nodename,servername)
    attrs = []
    attrs.append( [ 'name', name ] )
    attrs.append( ['value', value] )
    return removeAndCreate('Property', targetId, attrs, ['name'])

#-------------------------------------------------------------------------------------------------
# Create  custom property
#-------------------------------------------------------------------------------------------------
def createCustomProperty (webContainerConfigID, customPropertyName, customPropertyDescription, customPropertyValue, customPropertyRequired ):
   createCounter = 0
   wwString = '[[name "' + str(customPropertyName) +                 '"] [description "' + str(customPropertyDescription) +      '"] [value "' + str(customPropertyValue) + '"] [required "' + str(customPropertyRequired) + '"]]'
   print "wwString: " + str(wwString)

   try: 
      AdminConfig.create('Property', webContainerConfigID, str(wwString)) 
      createCounter = createCounter + 1
   except:
      print " " * indentCount, "Create Web Container custom property " +  str(customPropertyName) + " failed."

   return createCounter

#-------------------------------------------------------------------------------------------------
# edit  custom property
#-------------------------------------------------------------------------------------------------
def editCustomProperty ( cpTarget, cpName, cpDesc, cpValue, cpRequired ):
	#    cpScope     - JVM Custom property scope
	#    cpName      - Name of Custom Property
	#    cpDesc      - Description of Custom Property
	#    cpValue     - Value of the Custom Property
        
        # Check to see if the property exists already (in a true iPAS environment this might never occur)
        propertyList = AdminConfig.list("Property",cpTarget)
        actionType = "create" 
        for prop in propertyList.split("\n"):
            thisProp = prop.rstrip()
            if (thisProp.find(cpName) == 0):
                pStart = thisProp.find('(')
	        propertyMap = thisProp[pStart:] 
                actionType = "modify"
            #endIf
        #endFor


	#jvmMap = AdminConfig.list('JavaVirtualMachine',server)
        
        attrName = ["name", cpName]
        attrDesc = ["description", cpDesc]
        attrValue = ["value", cpValue]
        attrRequired = ["required", cpRequired]

        attrs = [attrName, attrDesc, attrValue, attrRequired]

        if (actionType == "create"):
            print "Create a NEW custom property"
	    #newProperty = AdminConfig.create("Property", jvmMap, attrs )
            newProperty = AdminConfig.create("Property", cpTarget, attrs )
        else:
       	    print "Modify the existing custom property"
            newProperty = AdminConfig.modify(propertyMap, attrs )
        #endElse
        
        print "Custom Property " + cpName + " created successfully!"

#-----------------------------------------------------------------
# createJVMCustomProperty - Create a JVM customer property 
#                           definition to a Server.
#            
#-----------------------------------------------------------------
def createJVMCustomProperty ( cpTarget, cpName, cpDesc, cpValue, cpRequired ):
	#    cpScope     - JVM Custom property scope
	#    cpName      - Name of Custom Property
	#    cpDesc      - Description of Custom Property
	#    cpValue     - Value of the Custom Property


	print " "
	print "Creating Custom JVM Property " + cpName + "..."

        # Cycle through each server node to add the JVM Custom property too... 

	serverList=AdminConfig.list("Server")
	newProperty = ""

	if (len(serverList) > 0):
		for item in serverList.split("\n"):
			server = item.rstrip()
			if (server.find(cpTarget) >= 0):
                                print "SERVER FOUND: " + server

                                # Check to see if the property exists already (in a true iPAS environment this might never occur)
                                propertyList = AdminConfig.list("Property",server)
                                actionType = "create" 
                                for prop in propertyList.split("\n"):
                                    thisProp = prop.rstrip()
                                    if (thisProp.find(cpName) == 0):
                                        pStart = thisProp.find('(')
	                                propertyMap = thisProp[pStart:] 
                                        actionType = "modify"
                                    #endElse
                                #endFor


				jvmMap = AdminConfig.list('JavaVirtualMachine',server)

                 		print "  Name:           " + cpName
		                print "  Description:    " + cpDesc
		                print "  Value:          " + cpValue
                                print "  JVM:            " + jvmMap

                                attrName = ["name", cpName]
                                attrDesc = ["description", cpDesc]
                                attrValue = ["value", cpValue]
                                attrRequired = ["required", cpRequired]

                     		attrs = [attrName, attrDesc, attrValue, attrRequired]

                                if (actionType == "create"):
       	     	                      print "Create a NEW custom property"
	     	                      newProperty = AdminConfig.create("Property", jvmMap, attrs )
                                else:
       	     	                      print "Modify the existing custom property"
                                      newProperty = AdminConfig.modify(propertyMap, attrs )
                                #endElse
			#endIf
		#endFor
	#endIf

        print "Custom Property " + cpName + " created successfully!"
	
	return newProperty 
#endDef


def createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName ):      
        # parameter examples:
        # cacheInstance_type = "ObjectCacheInstance"
        # cacheInstance_name = "WCCatalogGroupDistributedMapCache"
        # cacheInstance_jndiname = "services/cache/" + cacheInstance_name
        # cacheInstance_cacheSize = "2001"
        # cacheInstance_cacheProviderType = "WXS"
        # cacheInstance_cacheName = "YYExtremeScaleCatalogEntryDMC"

        cacheInstanceId = getObjectByName( cacheInstance_type, cacheInstance_name )
        printObject(cacheInstance_name, cacheInstanceId)
        
        if cacheInstanceId is not None:
            print "#########################################"
            print "Edit CacheInstance: " + cacheInstance_name
            print "#########################################"
            printPropertiesDictionary(cacheInstanceId)
            printPropertiesSet(cacheInstanceId)
            
            print "----------------------------------"
            print "Display CustomProperty ..."
            print "----------------------------------"   
            printJ2EEResourcePropertySet(cacheInstanceId)    
            
        else:
            print "#########################################"
            print "Creating CacheInstance: " + cacheInstance_name + ", type = " + cacheInstance_type
            print "#########################################"
            
            if (cacheInstance_type == "ObjectCacheInstance"): 
                cacheInstanceId = createObjectCache(scopeobjectid, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheProviderType)
                # saveAndSyncAndPrintResult()
            else:
                cacheInstanceId = createServletCache(scopeobjectid, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheProviderType)
                # saveAndSyncAndPrintResult()
            
            print "----------------------------------"
            print "Setting Cahce Instance Setting ..."
            print "----------------------------------"
            setCacheInstanceSettings(cacheInstanceId, "cacheSize", cacheInstance_cacheSize)
            # saveAndSyncAndPrintResult()
            
            if (cacheInstance_cacheProviderType == "WXS"):
                    print "----------------------------------"
                    print "Setting CustomProperty for WXS cache provider..."
                    print "----------------------------------"
                    customPropertyName = "com.ibm.websphere.xs.dynacache.cache_name"
                    customPropertyValue = cacheInstance_cacheName
                    createResourceCustomProperty(cacheInstanceId, customPropertyName, customPropertyValue)
                    
                    setCacheInstanceSettings(cacheInstanceId, "enableCacheReplication", 'true')
                    
                    #saveAndSyncAndPrintResult()
            else:
                    print "----------------------------------"
                    print "Setting CustomProperty for default cache provider..."
                    print "----------------------------------"
                    setCacheInstanceSettings(cacheInstanceId, "enableCacheReplication", 'true')
                    domainName = "Dynacache"
                    enableCacheReplication(cacheInstanceId, domainName, replicationType = 'NONE')
                    #saveAndSyncAndPrintResult()
        
        printPropertiesDictionary(cacheInstanceId)
        printPropertiesSet(cacheInstanceId)
        printJ2EEResourcePropertySet(cacheInstanceId)
        
        return cacheInstanceId
#endDef

#---------------------------------------------------------
#  Configure WAS to use WXS as dynacache provider
#
#---------------------------------------------------------
#set cp [$AdminConfig getid /Node:myNode/CacheProvider:/]
#$AdminConfig create ObjectCacheInstance $cp { {name myOCI} {jndiName cache/myJNDI} {cacheSize 2000} {defaultPriority 1} {category myCat} {description MyDesc} {enableDiskOffload false} {diskOffloadLocation "/my/dir"} {flushToDiskOnStop true} {useListenerContext false} {disableDependencyId false} }
#$AdminConfig Save

enableDebugMessages()

#clusterName is defined in the applications config.py property file (cluster_config.py) 
#CBS_brandName is defined in the applications config.py property file (cluster_config.py)

cellName = AdminControl.getCell()
cellId = getCellId(None)

cluster = getClusterId(clusterName)

printObject("CBS_brandName", CBS_brandName)
printObject("clusterName", clusterName)
printObject("cellName", cellName)
printObject("cellId", cellId) 
printObject("cluster", cluster) 

scopeobjectid = cluster
scope = _getObjectScope(scopeobjectid)
printObject("scope", scope)

#############################################################
# 1. create object cache instance: WCCatalogEntryDistributedMapCache
#############################################################
cacheInstance_name = "WCCatalogEntryDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "2001"
cacheInstance_cacheProviderType = "WXS"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleCatalogEntryDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )


#############################################################
# 2. create object cache instance: WCCatalogGroupDistributedMapCache
#############################################################
cacheInstance_name = "WCCatalogGroupDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "101"
cacheInstance_cacheProviderType = "WXS"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleCatalogEntryDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )


#############################################################
# 3. create object cache instance: WCMarketingDistributedMapCache
#############################################################
cacheInstance_name = "WCMarketingDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "3001"
cacheInstance_cacheProviderType = "WXS"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleCatalogEntryDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )


#############################################################
# 4. create object cache instance: WCSystemDistributedMapCache
#############################################################
cacheInstance_name = "WCSystemDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "1000"
cacheInstance_cacheProviderType = "default"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleSystemDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )

#############################################################
# 5. create object cache instance: WCContractDistributedMapCache
#############################################################
cacheInstance_name = "WCContractDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "1000"
cacheInstance_cacheProviderType = "default"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleContractDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )

#############################################################
# 6. create object cache instance: WCPromotionDistributedMapCache
#############################################################
cacheInstance_name = "WCPromotionDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "1000"
cacheInstance_cacheProviderType = "default"
cacheInstance_cacheName = CBS_brandName + "ExtremeScalePromotionDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )


#############################################################
# 7. create object cache instance: WCPriceDistributedMapCache
#############################################################
cacheInstance_name = "WCPriceDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "1000"
cacheInstance_cacheProviderType = "default"
cacheInstance_cacheName = CBS_brandName + "ExtremeScalePriceDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )


#############################################################
# 8. create object cache instance: WCMiscDistributedMapCache
#############################################################
cacheInstance_name = "WCMiscDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "1000"
cacheInstance_cacheProviderType = "default"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleMiscDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )


#############################################################
# 9. create object cache instance: WCDistributedMapCache
#############################################################
cacheInstance_name = "WCDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "1000"
cacheInstance_cacheProviderType = "default"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )

#############################################################
# 10. create object cache instance: WCSessionDistributedMapCache
#############################################################
cacheInstance_name = "WCSessionDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "2000"
cacheInstance_cacheProviderType = "default"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleSessionDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )



#############################################################
# 11. create object cache instance: WCUserDistributedMapCache
#############################################################
cacheInstance_name = "WCUserDistributedMapCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "8000"
cacheInstance_cacheProviderType = "default"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleUserDMC"
cacheInstance_type = "ObjectCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )


#############################################################
# 12. create Servlet cache instance: extremeScaleCache
#############################################################
cacheInstance_name = "extremeScaleCache"
cacheInstance_jndiname = "services/cache/" + cacheInstance_name
cacheInstance_cacheSize = "2001"
cacheInstance_cacheProviderType = "WXS"
cacheInstance_cacheName = CBS_brandName + "ExtremeScaleCacheA"
cacheInstance_type = "ServletCacheInstance"

createCacheInstance ( cacheInstance_type, cacheInstance_name, cacheInstance_jndiname, cacheInstance_cacheSize, cacheInstance_cacheProviderType, cacheInstance_cacheName )

#############################################################
# Final stage
#############################################################

saveAndSyncAndPrintResult()

printCacheProviderAtScope(scopeobjectid)
printAllObjectCacheInstances()
printAllServletCacheInstances()
    



