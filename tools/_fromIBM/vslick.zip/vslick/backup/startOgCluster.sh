./startContainerServer.sh 0 6602 2801
./startContainerServer.sh 1 6603 2802
./startContainerServer.sh 2 6604 2803
./startContainerServer.sh 3 6605 2804
