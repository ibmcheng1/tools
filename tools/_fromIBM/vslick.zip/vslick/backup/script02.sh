#!/bin/ksh
echo ======================================
echo running script01.sh
echo ======================================

echo WORKING_DIR=$WORKING_DIR
echo IDS_INSTALL_PATH=$IDS_INSTALL_PATH

# required properies to configure directory server instance
# Instance home: /home/myinst on AIX and Linux, and /export/home/myinst on Solaris
# instance name is also the owner name, db2 instance name, db2 database name

echo -------------------------------------
echo output content of properties file
echo -------------------------------------
cat ${IDS_CREATE_INSTANCE_PROPERTIES_FILE_01}
echo -------------------------------------

. ${IDS_CREATE_INSTANCE_PROPERTIES_FILE_01}

echo -------------------------------------
echo output required variables
echo -------------------------------------
echo INSTANCE_NAME=${INSTANCE_NAME}
echo UNSECURED_PORT=${UNSECURED_PORT}
echo SECURED_PORT=${SECURED_PORT}
echo ENCRYPTION_SEED=${ENCRYPTION_SEED}
echo ENCRYPTION_SALT=${ENCRYPTION_SALT}
echo INSTANCE_HOME=${INSTANCE_HOME}
echo INSTANCE_OWNER_PASSWORD=${INSTANCE_OWNER_PASSWORD}
echo ADMINISTRATOR_DN=${ADMINISTRATOR_DN}
echo ADMINISTRATOR_PASSWORD=${ADMINISTRATOR_PASSWORD}
echo SUFFIX_TO_ADD=${SUFFIX_TO_ADD}
echo LDIF_FILE_TO_LOAD=$LDIF_FILE_TO_LOAD
echo -------------------------------------

cd ${IDS_INSTALL_PATH}/sbin

echo ----------------------------------------
echo Step 1: creating directory server instance: root
echo ----------------------------------------

./idsicrt -I ${INSTANCE_NAME} -p ${UNSECURED_PORT} -s ${SECURED_PORT} -e ${ENCRYPTION_SEED} -g ${ENCRYPTION_SALT} -l /home/${INSTANCE_NAME} -G ${INSTANCE_NAME} -w ${INSTANCE_OWNER_PASSWORD} -n

echo ----------------------------------------
echo Step 2: Configuring DB2: directory server instance owner
echo ----------------------------------------

su - ${INSTANCE_NAME} -c "cd ${IDS_INSTALL_PATH}/sbin;./idscfgdb -I ${INSTANCE_NAME} -a ${INSTANCE_NAME} -w ${INSTANCE_OWNER_PASSWORD} -t ${INSTANCE_NAME} -l /home/${INSTANCE_NAME} -n"

echo ----------------------------------------
echo Step 3: Configure the administrator DN and password: directory server instance owner
echo ----------------------------------------

su - ${INSTANCE_NAME} -c "cd ${IDS_INSTALL_PATH}/sbin;./idsdnpw -I ${INSTANCE_NAME} -u ${ADMINISTRATOR_DN} -p ${ADMINISTRATOR_PASSWORD} -n"


echo -----------------------------------------------
echo Step 4: Configure the suffixes: directory server instance owner 
echo -----------------------------------------------

su - ${INSTANCE_NAME} -c "cd ${IDS_INSTALL_PATH}/sbin;./idscfgsuf -I ${INSTANCE_NAME} -s ${SUFFIX_TO_ADD} -n"

echo ----------------------------------------
echo Step 5: loading sample ldif data into database ... 
echo ----------------------------------------

su - ${INSTANCE_NAME} -c "cd ${IDS_INSTALL_PATH}/sbin;./idsldif2db -i ${LDIF_FILE_TO_LOAD} -I ${INSTANCE_NAME}"

echo ----------------------------------------
echo Step 6: Starting Directory server: root
echo ----------------------------------------

./ibmslapd -I ${INSTANCE_NAME}

sleep 10

echo ----------------------------------------
echo Step 7: Verifying configuration by ps ${INSTANCE_NAME}  
echo ----------------------------------------

ps -ef | grep ${INSTANCE_NAME}


echo ----------------------------------------
echo Step 8: Verifying configuration by ldapsearch ... 
echo ----------------------------------------

su - ${INSTANCE_NAME} -c "${IDS_INSTALL_PATH}/bin/ldapsearch -s base -b \"\" objectclass=*"


echo ----------------------------------------
echo Step 9: Verifying ${SUFFIX_TO_ADD} with base search ... 
echo ----------------------------------------

su - ${INSTANCE_NAME} -c "${IDS_INSTALL_PATH}/bin/ldapsearch -s base -b \"${SUFFIX_TO_ADD}\" objectclass=*"


echo ----------------------------------------
echo Step 10: Verifying ${SUFFIX_TO_ADD} with sun tree search ... 
echo ----------------------------------------

su - ${INSTANCE_NAME} -c "${IDS_INSTALL_PATH}/bin/ldapsearch -s sub -b \"${SUFFIX_TO_ADD}\" objectclass=*"

echo ======================================
echo end of script01.sh
echo ======================================
