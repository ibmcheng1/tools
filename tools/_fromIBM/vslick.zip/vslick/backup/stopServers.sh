#!/bin/sh
fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

"$OBJECTGRID_ROOT"/bin/xscmd.sh -cep $CATALOG_SERVICE_ENDPOINTS -c teardown -sl commqcon0,commqcon1,commqcon2,commqcon3,commqcon4,commqcon5,commqcon6,commqcon7,commqcon8,commqcon9,commqcon10,commqcon11,commqcon12,commqcon13,commqcon14,commqcon15 -force
