#############################
### application specific parameters
#############################
CBS_brandName = "FG"

###########################################
###   Cluster configuration ###
###########################################

#clusterName = "HttpSessionCluster"
#clusterName = "SampleCluster"
#clusterName = "fgd01_cluster"
#clusterName = "WC_bncperf_cluster"
clusterName = "WC_bncqa_cluster"

dataReplicationDomainName = "Dynacache"

###########################################
### Dynamic Caching service
###    dynaCache_cacheProviderType = default || WXS
###########################################
dynaCache_cacheProviderType = "WXS"
dynaCache_cacheSize = "20001"
dynaCache_enableCacheReplication = "true"

### default cache provider specific, these will be ignored if dynaCache_cacheProviderType = WXS
dynaCache_defaultPriority = "10"
dynaCache_enableDiskOffload = "true"
dynaCache_diskOffloadLocation = "/dynacache"
dynaCache_diskCacheSizeInGB = "8"
dynaCache_diskCachePerformanceLevel = "HIGH"
dynaCache_pushFrequency = "0"
dynaCache_domainName = dataReplicationDomainName

