#!/bin/ksh

echo ======================================
echo running startips.sh
echo ======================================

x ()
{
if [ $# -eq 1 ]; then
  /usr/sbin/mkdev -c ipsec -t 4 
  /usr/sbin/mkdev -c ipsec -t 6 > /dev/null 2>&1
  /usr/sbin/mkfilt -v 4 -u -z $1
  /usr/sbin/mkfilt -v 6 -u -z $1 > /dev/null 2>&1
else
  /usr/sbin/mkdev -c ipsec -t 4 $1
  /usr/sbin/mkdev -c ipsec -t 6 $1 > /dev/null 2>&1
  /usr/sbin/mkfilt -v 4 -z $2
  /usr/sbin/mkfilt -v 6 -z $2 > /dev/null 2>&1
fi
}
x  'p'
