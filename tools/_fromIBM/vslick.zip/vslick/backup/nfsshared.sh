echo "********** Logging Environment Variables **********"
set
echo "***************************************************"
echo 

. /etc/virtualimage.properties
export VM_IS_IP6
export PUBLIC_NETWORK_NIC
export PUBLIC_NETWORK_IS_IPV6
export PRIVATE_NETWORK_NIC
export PRIVATE_NETWORK_IS_IPV6

#unit test only
#export NFS_SERVER_HOST=172.27.14.3
#export NFS_MOUNT=/opt/IBM/HTTPServer/htdocs/repository
#export LOCAL_MOUNT=/opt/repository

export NFS_SERVER_HOST
export NFS_MOUNT
export LOCAL_MOUNT

echo NFS_SERVER_HOST=$NFS_SERVER_HOST
echo NFS_MOUNT=$NFS_MOUNT
echo LOCAL_MOUNT=$LOCAL_MOUNT 
              
echo Creating mount point
mkdir -p $LOCAL_MOUNT

echo showmount
showmount -e $NFS_SERVER_HOST

echo Mounting directory
mount $NFS_SERVER_HOST:$NFS_MOUNT $LOCAL_MOUNT

echo Verify the mount point 
mount
df -k

echo 
echo DONE.
