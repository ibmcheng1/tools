#!/bin/ksh
# This script is intended to work on Linux with bash shell or AIX with ksh.
# Be sure to set the first line of the script appriately for the platform where
# it will be run.
#
#########################################################################

# When debugging on IPAS, source the virtualimage.properties
if [ -f /etc/virtualimage.properties ]; then
  . /etc/virtualimage.properties
fi

WORKING_DIR=`pwd`

# need to do NFS mount before running this script
# IDS_SOFTWARE_PATH=/repository/downloads/sdsV6.3.1
IDS_FP_PATH=/repository/downloads/fixes/ids/v6.3.1.8

echo WORKING_DIR=$WORKING_DIR
echo IDS_SOFTWARE_PATH=$IDS_SOFTWARE_PATH

export WORKING_DIR
export IDS_SOFTWARE_PATH


echo ======================================
echo "installing GSKIT FP"
echo ======================================
# in NFS server, use the following command to extract GSKIT from tar.gz  
#   gunzip -c 8.0.50.34-ISS-GSKIT-AIX-FP0034.tar.gz | tar -xvf -
# this command will create 8.0.50.34-ISS-GSKIT-AIX-FP0034 folder.
 
cd ${IDS_FP_PATH}/8.0.50.34-ISS-GSKIT-AIX-FP0034 
ls -l

slibclean
installp -acXgYd . GSKit8

echo ======================================
echo verifying GSKIT
echo ======================================

lslpp -l GSKit8*

echo "---------------------------------"
echo "installing IDS 6.3.1.8 ..."
echo "---------------------------------"
cd ${IDS_FP_PATH}/6.3.1.8-ISS-ISDS-AIX-IF0008
license/idsLicense -q
#installp -ld ./images | grep idsldap.clt
#installp -acgXd ./images idsldap.cltbase631 idsldap.clt64bit631 idsldap.clt_max_crypto32bit631 idsldap.cltjava631
./idsinstall -u -f

echo ======================================
echo "Displaying current IDS version information"
echo ======================================
lslpp -l 'idsldap*' | grep idsldap.clt
