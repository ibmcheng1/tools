import sys

#---------------------------------------------------------------------
#  Parse Command Line: 'HttpSessionSample.war' HttpSessionSample wxs.httpsession.sample cellName cluster clusterName default_host 
#---------------------------------------------------------------------
appFileName=sys.argv[0]
print "App file name:    "+appFileName
appName=sys.argv[1]
print "App name: "+appName
appDisplayName = sys.argv[2]
print "App display name: "+appDisplayName
cellName = sys.argv[3]
print "Cell name:        "+cellName
targetType = sys.argv[4]
print "Target type:      "+targetType
targetName = sys.argv[5]
print "Target name       "+targetName
virtualHost = sys.argv[6]
print "Virtual host:     "+virtualHost

#-----------------------------------------------------------------
#  install application
#-----------------------------------------------------------------
AdminApp.install(appFileName, '[  -nopreCompileJSPs -distributeApp -nouseMetaDataFromBinary -nodeployejb -appname '+appName+' -createMBeansForResources -noreloadEnabled -nodeployws -validateinstall warn -noprocessEmbeddedConfig -filepermission .*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755 -noallowDispatchRemoteInclude -noallowServiceRemoteInclude -asyncRequestDispatchType DISABLED -nouseAutoLink -MapModulesToServers [[ '+appDisplayName+' '+appFileName+',WEB-INF/web.xml WebSphere:cell='+cellName+','+targetType+'='+targetName+' ]] -MapWebModToVH [[ '+appDisplayName+' '+appFileName+',WEB-INF/web.xml '+virtualHost+' ]] ]' )
AdminConfig.save()
