#!/bin/sh

echo program arguments: $@

fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

"$OBJECTGRID_ROOT"/bin/xscmd.sh -cep $CATALOG_SERVICE_ENDPOINTS $@
