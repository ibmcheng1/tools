import os
import sys
execfile('wsadminlib.py')

#---------------------------------------------------------
#  Configure WAS to use WXS as dynacache provider
#
#---------------------------------------------------------

enableDebugMessages()
m = "main"

saveAndSyncAndPrintResult()
