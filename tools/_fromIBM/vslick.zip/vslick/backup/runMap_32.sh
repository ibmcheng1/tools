#!/bin/sh

fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

echo catalogServiceEndPoints=$catalogServiceEndPoints
echo objectgridName=$objectgridName
echo mapName=$mapName

loop=1

# autoThreadsMode
size=96000   
./runDriver.sh -autoThreadsMode -loop $loop -size $size -catalogServiceEndPoints $catalogServiceEndPoints -objectgridName $objectgridName -mapName $mapName

# 1 thread
#threadLoad=96000
#./runDriver.sh -case001 -multiWorkerMode $threadLoad -loop $loop -size $size -catalogServiceEndPoints $catalogServiceEndPoints -objectgridName $objectgridName -mapName $mapName


# 32 threads
#threadLoad=3000
#./runDriver.sh -case032 -multiWorkerMode $threadLoad -loop $loop -size $size -catalogServiceEndPoints $catalogServiceEndPoints -objectgridName $objectgridName -mapName $mapName
