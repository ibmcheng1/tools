#!/bin/ksh

export WAS_DMGR_PROFILE_ROOT=/opt/IBM/WebSphere/Profiles/DefaultDmgr01
export WAS_CUSTOMNODE_PROFILE_ROOT=/opt/IBM/WebSphere/Profiles/DefaultCustom01
# ideally, the hosts should be host names, not ip address.
export CUSTOMNODE_HOSTS="20.176.240.134"
export CURRENT_HOST=`hostname`

echo WAS_DMGR_PROFILE_ROOT=$WAS_DMGR_PROFILE_ROOT
echo WAS_CUSTOMNODE_PROFILE_ROOT=$WAS_CUSTOMNODE_PROFILE_ROOT
echo CUSTOMNODE_HOSTS=$CUSTOMNODE_HOSTS

echo "------------------------------------"
echo "Stoppinging Custom Nodes ...     "
echo "------------------------------------"

for host in $CUSTOMNODE_HOSTS
do
  echo "Stoppinging WAS custom node on $host"
  if [[ ${CURRENT_HOST} == *$host* ]]; then
      $WAS_CUSTOMNODE_PROFILE_ROOT/bin/stopNode.sh &
  else
      ssh $host "$WAS_CUSTOMNODE_PROFILE_ROOT/bin/stopNode.sh" &
  fi
done


echo "Sleep 20 seconds ..."
sleep 20

echo "------------------------------------"
echo "Stopping Deployment Manager ...     "
echo "------------------------------------"
$WAS_DMGR_PROFILE_ROOT/bin/stopManager.sh


echo "------------------------------------"
echo "Checking WAS processes ...     "
echo "------------------------------------"

ps -ef | grep dmgr

for host in $CUSTOMNODE_HOSTS
do
  if [[ ${CURRENT_HOST} == *$host* ]]; then
      ps -ef | grep nodeagent
  else
      ssh $host "ps -ef | grep nodeagent"
  fi
done

