#!/bin/sh

if [ -f /etc/virtualimage.properties ]; then
  . /etc/virtualimage.properties
fi

export TEMS_HOST=`python get_registry_value.py ITM 1.0 Hub_TEMS_IP | tail -1`

## Testing only ------------------------------------
## export AGENT_INSTANCE_NAME=dpagent01
## export KQZ_SNMPEVENT_USER_NAME=itcam
## export KQZ_SNMPEVENT_AUTH_PASSWORD=password
## export KQZ_SNMPEVENT_PRIV_PASSWORD=password
## -------------------------------------------------

WORKING_DIR=${PWD}

echo "================================="
echo "Parameters:"
echo "================================="
echo AGENT_INSTANCE_NAME=$AGENT_INSTANCE_NAME
echo KQZ_SNMPEVENT_USER_NAME=$KQZ_SNMPEVENT_USER_NAME
echo KQZ_SNMPEVENT_AUTH_PASSWORD=$KQZ_SNMPEVENT_AUTH_PASSWORD
echo KQZ_SNMPEVENT_PRIV_PASSWORD=$KQZ_SNMPEVENT_PRIV_PASSWORD
echo "---------------------------------"
echo WORKING_DIR=$WORKING_DIR
echo TEMS_HOST=$TEMS_HOST
echo "---------------------------------"

## Configure ITCAM using the correct TEMS Host Name, KQZ_SNMPEVENT_USER_NAME, KQZ_SNMPEVENT_AUTH_PASSWORD, KQZ_SNMPEVENT_PRIV_PASSWORD
cp /tmp/itcamdp/silent_config_bn_tems.txt /tmp/itcamdp/silent_config_bn_tems-sed.txt
sed -i "s/{TEMS_HOST}/$TEMS_HOST/g" /tmp/itcamdp/silent_config_bn_tems-sed.txt
sed -i "s/{SNMP_USER_NAME}/$KQZ_SNMPEVENT_USER_NAME/g" /tmp/itcamdp/silent_config_bn_tems-sed.txt
sed -i "s/{AUTH_PASSWORD}/$KQZ_SNMPEVENT_AUTH_PASSWORD/g" /tmp/itcamdp/silent_config_bn_tems-sed.txt
sed -i "s/{PRIV_PASSWORD}/$KQZ_SNMPEVENT_PRIV_PASSWORD/g" /tmp/itcamdp/silent_config_bn_tems-sed.txt
/opt/IBM/ITCAMDP/bin/itmcmd config -A -p /tmp/itcamdp/silent_config_bn_tems-sed.txt -o $AGENT_INSTANCE_NAME bn

## Do some manual hacking to support IPv6
cp /opt/IBM/maestro/ITM/config/lz.ipv6config /opt/IBM/ITCAMDP/config/bn.ipv6config
echo -e "\n. /opt/IBM/ITCAMDP/config/bn.ipv6config" >> /opt/IBM/ITCAMDP/config/bn.ini
echo -e "\n. /opt/IBM/ITCAMDP/config/bn.ipv6config" >> /opt/IBM/ITCAMDP/config/bn_$AGENT_INSTANCE_NAME.config

## Enable syslog reception
if [[ ! -e /etc/rsyslog.conf.itcamdp.bak ]]; then
  cp /etc/rsyslog.conf /etc/rsyslog.conf.itcamdp.bak 
  sed -i 's/#$ModLoad imudp/$ModLoad imudp/g' /etc/rsyslog.conf
  sed -i 's/#$UDPServerRun 514/$UDPServerRun 514/g' /etc/rsyslog.conf
  service rsyslog restart
fi

## Start the agent
/opt/IBM/ITCAMDP/bin/itmcmd agent -o $AGENT_INSTANCE_NAME start bn

## verify /tmp/itcamdp/silent_config_bn_tems-sed.txt
echo "================================="
echo "verify /tmp/itcamdp/silent_config_bn_tems-sed.txt"
echo "================================="
cat /tmp/itcamdp/silent_config_bn_tems-sed.txt
