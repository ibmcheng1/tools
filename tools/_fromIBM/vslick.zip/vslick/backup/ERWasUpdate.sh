#!/bin/ksh
. /etc/virtualimage.properties

ER_ENVIRONMENT=$1
if [ -z "$ER_ENVIRONMENT" ]
then
   echo "ENV is not passed.. So looking in the Environment Variable"
   ER_ENVIRONMENT=$ER_ENVIRONMENT
fi

WAS_USERNAME=$2
if [ -z "$WAS_USERNAME" ]
then
   WAS_USERNAME=$WAS_USERNAME
else
   WAS_USERNAME=erwsadmin
fi

WAS_PASSWORD=$3
if [ -z "$WAS_PASSWORD" ]
then
   WAS_PASSWORD=$WAS_PASSWORD
else
   WAS_PASSWORD=Ibmuser9!
fi


WAS_USERNAME=wswuser
WAS_PASSWORD=p@ssw0rd

echo "======================================================================" 
echo "Configuring Data sources and JMS resources fro ER Application"
echo "ER_ENVIRONMENT = ${ER_ENVIRONMENT}"
echo "======================================================================" 
su wswuser -c "${PROFILE_ROOT}/bin/wsadmin.sh -lang jython -conntype SOAP -username $WAS_USERNAME -password $WAS_PASSWORD -f ERWasUpdate.py ${ER_ENVIRONMENT}" 

#su ${WAS_USERNAME} -c "${PROFILE_ROOT}/bin/wsadmin.sh -conntype SOAP -lang jython -username erwsadmin -password Ibmuser9! -f ERClusterJythonScript_mod.py ${ER_ENVIRONMENT}" 
rc=$?
if [ $rc -gt 0 ] 
then 
echo "****** wsadmin.sh returned RC = ${rc} ***************  details from  ${PROFILE_ROOT}/${PROFILE_NAME}/logs/wsadmin.traceout follow:"  
cat ${PROFILE_ROOT}/logs/wsadmin.traceout 
echo "****** End of wsadmin.traceout ***************"  
fi


