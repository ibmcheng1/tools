import os
import sys
execfile('wsadminlib.py')

#import the applications config.py property file with input variables to be used into the script...

dir = os.getcwd()
fileName, fileExtension = os.path.splitext(sys.argv[0])

print "Configuration File Name: " + fileName
exec("from " + fileName + " import *")

print "---------------------------------------------"
print "Creating WXS catalog Service Domain"
print "---------------------------------------------"
print "wxsCatalogDomainName   = "+wxsCatalogDomainName
print "wxsCatalog1 = "+wxsCatalog1
print "wxsCatalog2 = "+wxsCatalog2
print "wxsCatalog3 = "+wxsCatalog3
print "wxsCatalog1Port = "+wxsCatalog1Port
print "wxsCatalog2Port = "+wxsCatalog2Port
print "wxsCatalog3Port = "+wxsCatalog3Port	

AdminTask.createXSDomain('[-name '+wxsCatalogDomainName+' -default true -properties -defineDomainServers [[%s "" ,%s][%s "" ,%s][%s "" ,%s]]]' % (wxsCatalog1, wxsCatalog1Port, wxsCatalog2, wxsCatalog2Port, wxsCatalog3, wxsCatalog3Port) ) 

saveAndSyncAndPrintResult()

print AdminTask.testXSDomainConnection('[-name '+wxsCatalogDomainName+' ]') 
