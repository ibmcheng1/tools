#!/bin/sh

# THIS PRODUCT CONTAINS RESTRICTED MATERIALS OF IBM
# 5724-J34, 5655-P28  (C) COPYRIGHT International Business Machines Corp., 2006
# All Rights Reserved * Licensed Materials - Property of IBM
# US Government Users Restricted Rights - Use, duplication or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.

binDir=`dirname $0`

export OBJECTGRID_ROOT=/tmp/ObjectGrid
export WORKING_DIR=/tmp/og61_scenario1/classes
export JAVA_HOME=/opt/java5/java

export loop=1 
export size=20000   
export threadLoad=2500
export CLASSPATH=${WORKING_DIR}:${OBJECTGRID_ROOT}/lib/cglib.jar:${OBJECTGRID_ROOT}/lib/objectgrid.jar:${OBJECTGRID_ROOT}/lib/ogstreamquery.jar:${OBJECTGRID_ROOT}/samples/objectgridSamples.jar
export PACKAGE=com.ibm.ws.objectgrid.test.scenario
export CLASS=${PACKAGE}.DataServiceDriver

export output=out.log

${JAVA_HOME}/bin/java -Xms1024m -Xmx1024m -cp ${CLASSPATH} ${CLASS} interactive usingEM usingLocalOG multiWorkerMode ${threadLoad} loop ${loop} size ${size}
