. /home/virtuser/WMB/scripts/environment.sh

mqsiapplybaroverride -b DeviceManagementServiceproject.generated.bar -k DeviceManagementService -m com.tch.sc.devicemanagementservice.ManageDeviceRegistration#ManageDeviceRegistrationRequest.useHTTPS=true -o DeviceManagement.bar

mqsiapplybaroverride -b DPIManagementServiceproject.generated.bar -k DPIManagementService -m com.tch.sc.dpi.PerformDPIHealthCheck#PerformDPIHealthCheckRequest.useHTTPS=true,com.tch.sc.dpi.ProvisionDynamicPaymentInfo#ProvisionDPIRequest.useHTTPS=true,com.tch.sc.dpi.AcknowledgeDPI#AcknowledgeDPI.useHTTPS=true,com.tch.sc.dpi.GetDynamicPaymentInfo#additionalInstances=4,com.tch.sc.dpi.GetDynamicPaymentInfo#GetDynamicPaymentInfoRequest.useHTTPS=true -o DPIManagementService.bar

mqsiapplybaroverride -b NotificationServicesproject.generated.bar -k NotificationServices -m com.tch.sc.notificationservices.NotifyDPIStatus#NotifyDPIStatusRequest.useHTTPS=true,com.tch.sc.notificationservices.AcknowledgeNotification#AcknowledgeNotificationRequest.useHTTPS=true -o NotificationServices.bar

mqsiapplybaroverride -b PaymentInstrumentRegistrationproject.generated.bar -k PaymentInstrumentRegistration -m com.tch.sc.paymentinstrument.AddPaymentInstrument#additionalInstances=9,com.tch.sc.paymentinstrument.GetIssuerList#additionalInstances=4,com.tch.sc.paymentinstrument.GetIssuerList#GetIssuerReq.useHTTPS=true,com.tch.sc.paymentinstrument.GetIssuerEnrollmentAppURL#GetIssuerEnrollmentAppURLRequest.useHTTPS=true,com.tch.sc.paymentinstrument.AckAddPaymentInstrument#additionalInstances=9,com.tch.sc.paymentinstrument.AckAddPaymentInstrument#AckAddPaymentInstrumentRequest.useHTTPS=true,com.tch.sc.paymentinstrument.AddPaymentInstrument#AddPaymentInstument.useHTTPS=true,com.tch.sc.paymentinstrument.NotifyPaymentInstrumentActivation#NotifyPaymentInstrumentActivationRequest.useHTTPS=true -o PaymentInstrumentRegistration.bar

mqsiapplybaroverride -b PaymentTransactionServiceproject.generated.bar -k PaymentTransactionService -m com.tch.sc.paymenttransaction.SendTransactionHistory#SendTransactionHistoryRequest.useHTTPS=true,com.tch.sc.paymenttransaction.AckTransactionHistory#AckTransactionHistoryRequest.useHTTPS=true -o PaymentTransactionService.bar

mqsiapplybaroverride -b TCPFlowsproject.generated.bar -k TCPFlows -m AsyncReceiveTCPIP#additionalInstances=9,VaultTCPResponseFlow#RegisterVault.additionalInstances=9,"LoginCheck#SOAP Request.webServiceURL"="https://$DPIP:$DP_CERT_PORT/CredentialChecks" -o LookupPAN.bar

mqsiapplybaroverride -b CommonNamesproject.generated.bar -k CommonNames -m CommonName#additionalInstances=1 -o CommonName.bar 

mqsideploy "$BROKER" -e Admin -a PreloadCacheproject.generated.bar
mqsideploy "$BROKER" -e Admin -a CommonName.bar
mqsideploy "$BROKER" -e DeviceManagement -a DeviceManagement.bar

#Due to TCP socket holding, we need to stop the EG to stop issues
#mqsistopmsgflow "$BROKER" -e LookupPAN -k TCPFlows
#mqsistopmsgflow "$BROKER" -e LookupPAN
#mqsistartmsgflow "$BROKER" -e LookupPAN
mqsideploy "$BROKER" -e LookupPAN -a LookupPAN.bar
#mqsistartmsgflow "$BROKER" -e LookupPAN -k TCPFlows

mqsideploy "$BROKER" -e DPIManagementService -a DPIManagementService.bar
mqsideploy "$BROKER" -e NotificationServices -a NotificationServices.bar
mqsideploy "$BROKER" -e PaymentInstrumentRegistration -a PaymentInstrumentRegistration.bar
mqsideploy "$BROKER" -e PaymentTransactionService -a PaymentTransactionService.bar

#Enable monitoring
/home/virtuser/WMB/scripts/enableMonitoring.sh

