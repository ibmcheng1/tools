#!/bin/sh

fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

"$OBJECTGRID_ROOT"/bin/startConsoleServer.sh
