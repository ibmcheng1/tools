#!/bin/sh
fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

"$OBJECTGRID_ROOT"/bin/xscmd.sh -cep $CATALOG_SERVICE_ENDPOINTS -c teardown -sl fgqcon0,fgqcon1,fgqcon2,fgqcon3,fgqcon4,fgqcon5,fgqcon6,fgqcon7 -force
