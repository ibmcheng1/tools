import java.lang.System as sys
import sys

DataSources=['SQLPOOLDataSource','SQLPOOLReportDataSource']
JVM_INITIAL_HEAP_SIZE='1024'
JVM_MAX_HEAP_SIZE='2048'
DS_CONNECTION_POOL_MIN_CONNECTIONS='5'
DS_CONNECTION_POOL_MAX_CONNECTIONS='50'
DS_PROPERTY_01_NAME='webSphereDefaultIsolationLevel'
DS_PROPERTY_01_VALUE='2'
# to add or modify more property: add a pair of [DS_PROPERTY_xx_NAME, DS_PROPERTY_xx_VALUE]

Factories=['ERConnectionFactory','ERConnectionFactoryLoadBalanced','mdbConnectionFactory']
JMS_CONNECTION_POOL_MIN_CONNECTIONS='5'
JMS_CONNECTION_POOL_MAX_CONNECTIONS='50'

# Global Security setting
SECURITY_PROPERTY_01_NAME='com.ibm.ws.security.web.logoutOnHTTPSessionExpire'
SECURITY_PROPERTY_01_VALUE='true'

# Server session management
SM_PROPERTY_01_NAME='InvalidateOnUnauthorizedSessionRequestException'
SM_PROPERTY_01_VALUE='true'
SM_PROPERTY_02_NAME='ThrowSecurityExceptionOnGetSessionFalse'
SM_PROPERTY_02_VALUE='false'

# Server - Web container
WEB_PROPERTY_01_NAME='com.ibm.ws.webcontainer.enableErrorExceptionTypeFirst'
WEB_PROPERTY_01_VALUE='true'
WEB_PROPERTY_02_NAME='com.ibm.ws.webcontainer.invokeFiltersCompatibility'
WEB_PROPERTY_02_VALUE='true'
WEB_PROPERTY_03_NAME='com.ibm.ws.webcontainer.mapFiltersToAsterisk'
WEB_PROPERTY_03_VALUE='true'
WEB_PROPERTY_04_NAME='com.ibm.ws.webcontainer.removetrailingservletpathslash'
WEB_PROPERTY_04_VALUE='true'

# Server - Log file setting
SERVER_LOG_FILE_NAME='${SERVER_LOG_ROOT}/SystemOut.log'
SERVER_LOG_FILE_ROTATION_FILE_SIZE='true'
SERVER_LOG_FILE_ROTATION_MAX_SIZE='16'
SERVER_LOG_FILE_ROTATION_MAX_NUMBER='10'

SERVER_LOG_PROPERTY_01_NAME='com.ibm.ws.webcontainer.enableErrorExceptionTypeFirst'
SERVER_LOG_PROPERTY_01_VALUE='true'

################################################################
# End of change area
################################################################

# functions
def ClearEnvVariables(entries):
	# needs a list of entries to be removed
	vars=AdminConfig.list("VariableSubstitutionEntry").splitlines()
	for var in vars:
		name=AdminConfig.showAttribute(var,"symbolicName")
		if (name in entries):
			AdminConfig.remove(var)
	AdminConfig.save()
	
def GetPropertiesDictionary(id):
	# needs a valid id and returns a dictionary of attributes
	dictionary = {}
	for item in AdminConfig.show(id).splitlines():
		item = item[1:-1]
		spacePos = item.find(' ')
		dictionary[item[0:spacePos]] = item[spacePos + 1:]
	return dictionary

def GetNodeServerTuples():
	# return a list of tuples - (node, server)
	# for each node get the application server(s)
	# and ignore all other types
	node_server_tuples = []
	nodelist=AdminConfig.list("Node").splitlines()
	for node in nodelist:
		dictionary = GetPropertiesDictionary(node)
		nodename = dictionary["name"]
		serverlist=AdminConfig.list("Server", node).splitlines()
		for server in serverlist:
			dictionary = GetPropertiesDictionary(server)
			name = dictionary["name"]
			type = dictionary["serverType"]
			if (type == "APPLICATION_SERVER"):
				node_server_tuples.append((nodename,server))
	
	return node_server_tuples

def getObjectByName( typename, objectname ):
    """Get an object of a given type and name - WARNING: the object should be unique in the cell; if not, use getObjectByNodeAndName instead."""
    all = _splitlines(AdminConfig.list( typename ))
    result = None
    for obj in all:
        name = AdminConfig.showAttribute( obj, 'name' )
        if name == objectname:
            if result != None:
                raise "FOUND more than one %s with name %s" % ( typename, objectname )
            result = obj
    return result

def _splitlines(s):
  rv = [s]
  if '\r' in s:
    rv = s.split('\r\n')
  elif '\n' in s:
    rv = s.split('\n')
  if rv[-1] == '':
    rv = rv[:-1]
  return rv

def printAllOfObjectType(objectType):
    """print all ObjectType instances"""
    print "----------------------------------"
    print "Display All ObjectType instances: " + objectType
    print "----------------------------------"
    oids = _splitlines(AdminConfig.list( objectType ))
    for id in oids:
        #print "Object id = " + id
        name = AdminConfig.showAttribute( id, "name" )
        print "Object: name = " + name


def updateJ2EEResourceProperty(id, propName, propValue):
    """update or create custom properties of an configuration object"""
    print "----------------------------------"
    print "updateJ2EEResourceProperty: "
    print "----------------------------------"
    propset = AdminConfig.list("J2EEResourcePropertySet", id )
    customProperty = ""
    for psItem in _splitlines(AdminConfig.list("J2EEResourceProperty", propset)):
        #print("psItem: " + AdminConfig.showAttribute(psItem, "name"))
        if (propName == AdminConfig.showAttribute(psItem, "name")):
            customProperty = propName
            AdminConfig.modify(psItem, [["value", propValue]])
            break
        #endIf
    #endFor
    
    if (customProperty == ""):
	print("Adding custom properties: " + propName)
	DataSourcePropertySet=AdminConfig.showAttribute(id, 'propertySet')
	AdminConfig.create('J2EEResourceProperty', '' + DataSourcePropertySet + '', '[[name ' + propName + '] [type "java.lang.String"] [description ""] [value ' + propValue + '] [required "false"]]')
    else:
       	print "Modified customProperty: " + customProperty
    #endElse

def printProperties ( props ):
        properties = props[1:len(props)-1].split(" ")
        prop = ""
        for property in properties:
                name = AdminConfig.showAttribute(property, "name" )
                print "property name = " + name
        #endFor


def setProperty ( id, propName, propValue ):
        print "setProperty on object: " + id
        props = AdminConfig.showAttribute(id, "properties" )
        properties = props[1:len(props)-1].split(" ")
        prop = ""
        print "Locating the property named "+propName+" ..."
        for property in properties:
                name = AdminConfig.showAttribute(property, "name" )
                if (propName == name):
                        prop = property
                        print "Found it!"
                #endIf
        #endFor

        if (prop == ""):
                #print "No property named "+`propName`+" could be found!"     
                #print "Creating "+`propName`+" property and set to "+`propValue`+" ..."
                AdminConfig.create('Property', id, [['name',propName], ['value',propValue]])
        else:
                #print "Setting the value of the "+`propName`+" property to "+`propValue`+" ..."
                value = ["value", propValue]
                attrs = [value]
                AdminConfig.modify(prop, attrs )
        #endElse
#endDef

def setSessionManagementByCluster(clusterName) :
    print "setSessionManagementByCluster ..." + clusterName
    clusterId = AdminConfig.getid("/ServerCluster:" + clusterName + "/")
    clusterMembers = _splitlines(AdminConfig.list("ClusterMember", clusterId ))
    enabled = "true"
    for clusterMember in clusterMembers:
        nodeName = AdminConfig.showAttribute( clusterMember, "nodeName" )
        serverName = AdminConfig.showAttribute( clusterMember, "memberName" )
        serverId = getServerId(nodeName,serverName)
        print
        print('nodeName:' + nodeName + ', serverName:' + serverName + ', serverId:' + serverId)        
        
        # SessionManager setting
        sessionManager = AdminConfig.list('SessionManager',  serverId)
        #attributes = AdminConfig.showall(sessionManager)
        #print "attributes: " + attributes        
        setProperty ( sessionManager, SM_PROPERTY_01_NAME, SM_PROPERTY_01_VALUE )
        setProperty ( sessionManager, SM_PROPERTY_02_NAME, SM_PROPERTY_02_VALUE )

        props = AdminConfig.showAttribute(sessionManager, "properties" )
        print "after update: "
        printProperties ( props )
        
        # WebContainer setting
        webcontainer = AdminConfig.list('WebContainer', serverId)
        #print "webcontainer ..." + webcontainer
        setProperty ( webcontainer, WEB_PROPERTY_01_NAME, WEB_PROPERTY_01_VALUE )
        setProperty ( webcontainer, WEB_PROPERTY_02_NAME, WEB_PROPERTY_02_VALUE )
        setProperty ( webcontainer, WEB_PROPERTY_03_NAME, WEB_PROPERTY_03_VALUE )
        setProperty ( webcontainer, WEB_PROPERTY_04_NAME, WEB_PROPERTY_04_VALUE )
              
        props = AdminConfig.showAttribute(webcontainer, "properties" )
        print "after update: "
        printProperties ( props )

#endDef


def getServerId(nodename,servername):
    """Return the config id for a server or proxy.  Could be an app server or proxy server, etc"""
    id = getObjectByNodeAndName(nodename, "Server", servername) # app server
    if id == None:
        id = getObjectByNodeAndName(nodename, "ProxyServer", servername)
    return id
    

def getObjectByNodeAndName( nodename, typename, objectname ):
    """Get the config object ID of an object based on its node, type, and name"""
    # This version of getObjectByName distinguishes by node,
    # which should disambiguate some things...
    node_id = getNodeId(nodename)
    all = _splitlines(AdminConfig.list( typename, node_id ))
    result = None
    for obj in all:
        name = AdminConfig.showAttribute( obj, 'name' )
        if name == objectname:
            if result != None:
                raise "FOUND more than one %s with name %s" % ( typename, objectname )
            result = obj
    return result

def getNodeId( nodename ):
    """Given a node name, get its config ID"""
    return AdminConfig.getid( '/Cell:%s/Node:%s/' % ( AdminControl.getCell(), nodename ) )


###############################################################
            
# Properties determined at runtime
# get cell manager node name, which is the node name of the dmgr
CellManager=AdminControl.getNode()
# get cluster name - pick up the first cluster
Cluster=GetPropertiesDictionary(AdminConfig.list("ServerCluster").splitlines()[0])['name']
# get cell name
Cell=AdminControl.getCell()
# get all nodes and their application servers
NodeAndServers=GetNodeServerTuples()

print('Cell:' + Cell + ',CellManager:' + CellManager + ',Cluster:' + Cluster)

#########################################
# JVM Properties
#########################################

print("********* Setting server JVM properties *********************")
for i in range(len(NodeAndServers)):
	# Extract the node and server from the tuple instance
	(node, server) = NodeAndServers[i]
	serverName=GetPropertiesDictionary(server)["name"]

	print("Setting JVM properties for node:" + node + ", server:" + serverName),
	# jvms=AdminConfig.list("JavaVirtualMachine",server).splitlines();
	# AdminConfig.unsetAttributes(jvms[0], '["classpath"]')	
	# AdminTask.setJVMProperties('[-nodeName ' + node + ' -serverName ' + serverName + ' -classpath [' + ER_CONFIG_DIRECTORY + '/xml ' + ER_CONFIG_DIRECTORY + '/properties ' + ER_CONFIG_DIRECTORY + '/resource ] -initialHeapSize ' + JVM_INITIAL_HEAP_SIZE + ' -maximumHeapSize ' + JVM_MAX_HEAP_SIZE + ' -verboseModeClass false -verboseModeGarbageCollection false -verboseModeJNI false -runHProf false -hprofArguments -debugMode false -debugArgs "" -executableJarFileName -genericJvmArguments "-DSDMSConfig.release.name=9.1 -DloggingFlush=true -DstartTime=09-10-00 -Dws.ext.dirs=/ER/libs -Dsdms.environment=' + ER_ENVIRONMENT + ' -DlogName=' + ER_LOG + ' -DSDMSConfig.build.date=12/12/12 -DSDMSConfig.build.number=1234 -Xquickstart -Dsdms.limitCustomers=' + sdms_limitCustomers + ' -DcustConf.dir=' + custConf_dir + ' -DsystemConf.dir=' + custConf_dir + ' -DcustEncConf.dir=' + custConf_dir + '  -agentlib:getClasses" -disableJIT false]')   

	print("..................[DONE]")
print

#########################################
# DataSources
#########################################
#printAllOfObjectType('DataSource')
print("********* DataSources *********************")
for DataSource in DataSources:
	print("Process data source: " + DataSource)
        ds = getObjectByName('DataSource', DataSource)
        #print "DataSource ds = " + ds	
	#DataSourcePropertySet=AdminConfig.showAttribute(ds, 'propertySet')
        #print("DataSourcePropertySet = " + DataSourcePropertySet)
        
        print("Modifying custom properties for DataSource:" + DataSource)
        updateJ2EEResourceProperty(ds, DS_PROPERTY_01_NAME, DS_PROPERTY_01_VALUE)
        print("..................[DONE]")
               
        print("Modifying connection pool properties for DataSource:" + DataSource),
	ConnectionPool=AdminConfig.showAttribute(ds, 'connectionPool')
	AdminConfig.modify('' + ConnectionPool + '', '[[minConnections ' + DS_CONNECTION_POOL_MIN_CONNECTIONS + '] [maxConnections ' + DS_CONNECTION_POOL_MAX_CONNECTIONS + ']]')
	print("..................[DONE]")
               
	# Get the list of properties
	#DataSourceProperties=AdminConfig.list('J2EEResourceProperty', DataSourcePropertySet).splitlines()
	#print("..................[DONE]")
	
print


#########################################
# Security
#########################################
print("********* Security *********************")		
sec = AdminConfig.getid('/Security:/')
#print('sec:' + sec)
setProperty ( sec, SECURITY_PROPERTY_01_NAME, SECURITY_PROPERTY_01_VALUE )
print("..................[DONE]")
print

#########################################
# JMS Connection Factory
#########################################
print("********* JMS Connection Factories *********************")
#printAllOfObjectType('J2CConnectionFactory')		
for factory in Factories:
	print("Process J2CConnectionFactory: " + factory)
        factoryId = getObjectByName('J2CConnectionFactory', factory)
        print "J2CConnectionFactory factoryId = " + factoryId
	print("Modifying connection pool properties for J2CConnectionFactory: " + factory),
	factoryConnectionPool=AdminConfig.showAttribute(factoryId, 'connectionPool')
	AdminConfig.modify('' + factoryConnectionPool + '', '[[minConnections ' + JMS_CONNECTION_POOL_MIN_CONNECTIONS + '] [maxConnections ' + JMS_CONNECTION_POOL_MAX_CONNECTIONS + ']]')
	print("..................[DONE]")
print

#########################################
# Server Session Management
#########################################
print
setSessionManagementByCluster(Cluster)

#########################################
# Server web container 
#########################################


#########################################
# Server Log file 
#########################################

print('Saving created artifacts'),
AdminConfig.save()
print("..................[DONE]")

