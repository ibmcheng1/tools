#!/bin/sh
#
# This script is intended to work on Linux with bash shell or AIX with ksh.
# Be sure to set the first line of the script appriately for the platform where
# it will be run.
#
#########################################################################
echo ======================================
echo mainScript ...
echo ======================================
# When debugging on IPAS, source the virtualimage.properties
if [ -f /etc/virtualimage.properties ]; then
  . /etc/virtualimage.properties
fi

export VM_IS_IP6
export PUBLIC_NETWORK_NIC
export PUBLIC_NETWORK_IS_IPV6
export PRIVATE_NETWORK_NIC
export PRIVATE_NETWORK_IS_IPV6

WORKING_DIR=`pwd`
MQSI_NEW_VERSION=8.0.0.${FP_LEVEL}
FP_LEVEL=$WMB_FP_LEVEL
FP_FILE=$WMB_FP_FILE

export WORKING_DIR
export NFS_SERVER_HOST
export NFS_MOUNT
export LOCAL_MOUNT
export WMB_FP_LEVEL
export WMB_FP_FILE
export FP_LEVEL
export FP_FILE
export MQSI_NEW_VERSION

echo WORKING_DIR=$WORKING_DIR
echo NFS_SERVER_HOST=$NFS_SERVER_HOST
echo NFS_MOUNT=$NFS_MOUNT
echo LOCAL_MOUNT=$LOCAL_MOUNT
echo WMB_FP_LEVEL=$WMB_FP_LEVEL
echo WMB_FP_FILE=$WMB_FP_FILE
echo FP_LEVEL=$FP_LEVEL
echo FP_FILE=$FP_FILE
echo MQSI_BROKER_NAME=$MQSI_BROKER_NAME
echo MQSI_VERSION=$MQSI_VERSION
echo MQSI_NEW_VERSION=$MQSI_NEW_VERSION

chmod a+x ${WORKING_DIR}/scripts/*.sh

echo "---------------------------"
echo "Prepare NFS mounting ..."
echo "---------------------------"
# Connect to nfs
/0config/nodepkgs/common/scripts/firewall.sh open tcpout -network public -dest ${NFS_SERVER_HOST} -dport 2049
rc=`mount | grep "on ${LOCAL_MOUNT} type nfs"`
echo "NFS mount = $rc"
if [ "$rc" == "" ];
then
  if [ ! -d $LOCAL_MOUNT ];
  then
    echo "Create $LOCAL_MOUNT directory for mounting ..."
    mkdir $LOCAL_MOUNT
  fi
  echo "Mount NFS directory ..."
  mount ${NFS_SERVER_HOST}:${NFS_MOUNT} $LOCAL_MOUNT
fi
rc=`mount | grep "on ${LOCAL_MOUNT} type nfs"`
echo "NFS mount = $rc"
echo "ls -l ${LOCAL_MOUNT}"
ls -l $LOCAL_MOUNT
echo "---------------------------"


echo ======================================
echo invoke custom scripts
echo ======================================
${WORKING_DIR}/scripts/WMB_SilentInstall.sh $FP_LEVEL $FP_FILE $MQSI_BROKER_NAME

echo "--------------------------"
echo "return back to mainScript ..."
echo "--------------------------"

${WORKING_DIR}/scripts/startBroker.sh $MQSI_BROKER_NAME

echo "---------------------------"
echo "ps -ef | grep mqsi*"
echo "---------------------------"
sleep 5
ps -ef | grep mqsi*
