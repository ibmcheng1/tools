#!/bin/sh
fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

COUNT=$1
INDEX=$2

declare -i j=0
echo "Value of index: $INDEX"

for (( i=0, j=$INDEX; i < $COUNT; i++, ++j ))
do
	APP_LOG_PATH=${WORKING_DIR}/logs/c$j

	if [[ ! -e $APP_LOG_PATH ]]; then
    		mkdir $APP_LOG_PATH
    		chmod 777 ${APP_LOG_PATH}
	fi
	
	${OBJECTGRID_ROOT}/bin/startOgServer.sh "c$j" -haManagerPort $((6603 + $i)) -catalogServiceEndPoints $CATALOG_SERVICE_ENDPOINTS -objectgridFile "${OBJECT_GRID_XML}" -deploymentPolicyFile "${DEPLOYMENT_POLICY_XML}" -listenerPort $((2801 + $i)) -jvmArgs -Xms6144m -Xmx6144m -cp "$APP_LIB_PATH"
	sleep 10
done