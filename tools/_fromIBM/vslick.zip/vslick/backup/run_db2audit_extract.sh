#!/bin/bash

auditdata_dir=/db2fs/db2auditdata
archive_dir=/db2fs/db2auditarchive
extract_dir=/db2fs/db2auditextract

echo auditdata_dir=$auditdata_dir
echo archive_dir=$archive_dir
echo extract_dir=$extract_dir

set +x

if [ ! -d $archive_dir ]
then
    #echo " Directory $archive_dir does not exist. Make sure the directory exists before reissue the command." 
    #exit 3
    mkdir $archive_dir
fi

if [ ! -d $extract_dir ]
then
    #echo " Directory $log_dir does not exist. Make sure the directory exists before reissue the command." 
    #exit 2
    mkdir $extract_dir
fi

ls -l /db2fs
ls -l ${archive_dir} 

#db2audit archive
db2audit extract delasc to $extract_dir from files ${archive_dir}/*
