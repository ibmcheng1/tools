#/bin/sh

. /etc/virtualimage.properties
export VM_IS_IP6
export PUBLIC_NETWORK_NIC
export PUBLIC_NETWORK_IS_IPV6
export PRIVATE_NETWORK_NIC
export PRIVATE_NETWORK_IS_IPV6

## Testing only ------------------------------------
## export AGENT_INSTANCE_NAME=dpagent01
## export DP_DISPLAY_NAME=dp01
## export DP_XML_IP=172.21.20.20
## export DP_XML_PORT=5550
## export DP_XML_USERNAME=admin
## export DP_XML_PASSWORD=passw0rd
## export DP_PRIVATE_IP=fd8c:215d:178e:159:250:56ff:fe9d:3c34
## -------------------------------------------------

export AGENT_HOST=`ifconfig eth0 | grep inet6 | grep Global | awk '{print $3}' | cut -d / -f 1`

echo "================================="
echo "Parameters:"
echo "================================="
echo AGENT_INSTANCE_NAME=$AGENT_INSTANCE_NAME
echo DP_DISPLAY_NAME=$DP_DISPLAY_NAME
echo DP_XML_IP=$DP_XML_IP
echo DP_XML_PORT=$DP_XML_PORT
echo DP_XML_USERNAME=$DP_XML_USERNAME
echo DP_XML_PASSWORD=$DP_XML_PASSWORD
echo DP_PRIVATE_IP=$DP_PRIVATE_IP
echo "---------------------------------"
echo AGENT_HOST=$AGENT_HOST
echo "---------------------------------"

## Open the firewall between this script and DataPower
/0config/nodepkgs/common/scripts/firewall.sh open tcpout -network public -dest $DP_XML_IP -dport $DP_XML_PORT

## Configure DataPower
export PYTHONDONTWRITEBYTECODE=true
cd /tmp/itcamdp/dpScripts
chmod +x dpManage.py
./dpManage.py --request createHostAlias --save --host $DP_XML_IP --port $DP_XML_PORT --username $DP_XML_USERNAME --password $DP_XML_PASSWORD --aliasname mgmt6 --aliasip $DP_PRIVATE_IP
./dpManage.py --request createUser --save --host $DP_XML_IP --port $DP_XML_PORT --username $DP_XML_USERNAME --password $DP_XML_PASSWORD --newusername itcam --newpassword temppassword --access privileged --snmp
./dpManage.py --request changePassword --host $DP_XML_IP --port $DP_XML_PORT --username itcam --password temppassword --newpassword password
./dpManage.py --request setupSNMP --save --host $DP_XML_IP --port $DP_XML_PORT --username $DP_XML_USERNAME --password $DP_XML_PASSWORD --localaddress mgmt6 --remoteaddress $AGENT_HOST
./dpManage.py --request createSyslogTarget --save --host $DP_XML_IP --port $DP_XML_PORT --username $DP_XML_USERNAME --password $DP_XML_PASSWORD --identifier $DP_DISPLAY_NAME --localaddress mgmt6 --remoteaddress $AGENT_HOST
./dpManage.py --request createDomain --save --host $DP_XML_IP --port $DP_XML_PORT --username $DP_XML_USERNAME --password $DP_XML_PASSWORD --newdomain itcamdp
./dpManage.py --request uploadFile --host $DP_XML_IP --port $DP_XML_PORT --username $DP_XML_USERNAME --password $DP_XML_PASSWORD --domain itcamdp --directory cert:// --filename /tmp/itcamdp/ITCAMDP-certs.zip --extract
./dpManage.py --request importDomain --save --host $DP_XML_IP --port $DP_XML_PORT --username $DP_XML_USERNAME --password $DP_XML_PASSWORD --domain itcamdp --filename /tmp/itcamdp/ITCAMDP-export.zip
cd /tmp/itcamdp

## Close the firewall between this script and DataPower
/0config/nodepkgs/common/scripts/firewall.sh close tcpout -network public -dest $DP_XML_IP -dport $DP_XML_PORT

## Enable syslog for this DataPower
if grep -q $DP_DISPLAY_NAME /etc/rsyslog.conf; then
  echo ":hostname, isequal, \"$DP_DISPLAY_NAME\" /var/log/datapower.$DP_DISPLAY_NAME.log" >> /etc/rsyslog.conf
  service rsyslog restart
fi

## Stop the agent
/opt/IBM/ITCAMDP/bin/itmcmd agent -o $AGENT_INSTANCE_NAME stop bn

## Add/update configuration for the given datapower instance
cp /tmp/itcamdp/silent_config_bn_dp.txt /tmp/itcamdp/silent_config_bn_dp-sed.txt
sed -i "s/{DP_DISPLAY_NAME}/$DP_DISPLAY_NAME/g" /tmp/itcamdp/silent_config_bn_dp-sed.txt
sed -i "s/{DP_PRIVATE_IP}/$DP_PRIVATE_IP/g" /tmp/itcamdp/silent_config_bn_dp-sed.txt
sed -i "s/{DP_UID}/$DP_XML_USERNAME/g" /tmp/itcamdp/silent_config_bn_dp-sed.txt
sed -i "s/{DP_PASSWORD}/$DP_XML_PASSWORD/g" /tmp/itcamdp/silent_config_bn_dp-sed.txt
/opt/IBM/ITCAMDP/bin/itmcmd config -A -p /tmp/itcamdp/silent_config_bn_dp-sed.txt -o $AGENT_INSTANCE_NAME bn

## Open the firewall for the agent to talk to DataPower, and for DataPower to send SNMP and syslog data
/0config/nodepkgs/common/scripts/firewall.sh open tcpout -network private -dest $DP_PRIVATE_IP -dport 5551
/0config/nodepkgs/common/scripts/firewall.sh open in -network private -p udp -src $DP_PRIVATE_IP -dport 162
/0config/nodepkgs/common/scripts/firewall.sh open in -network private -p udp -src $DP_PRIVATE_IP -dport 514

## Start the agent
/opt/IBM/ITCAMDP/bin/itmcmd agent -o $AGENT_INSTANCE_NAME start bn