#!/bin/ksh

# cellName=CloudBurstCell_1
cellName=CSCCell_1
appName=HttpSessionSample
cachingHost="172.31.200.10"
cachingUser="sessionERDev01"
cachingPassword="cscibm_@UhTvF2CpD4u4"
cachingGrid="sessionGridDev01"

echo cellName=$cellName
echo appName=$appName
echo cachingHost=$cachingHost
echo cachingUser=$cachingUser
echo cachingPassword=$cachingPassword
echo cachingGrid=$cachingGrid

#./runWsadmin.sh retrieveXC10certificate.py ${cellName} ${cachingHost} 
#./runWsadmin.sh enableAppXC10SessionMgmt.jy ${appName} ${cachingHost} ${cachingUser} ${cachingPassword} ${cachingGrid}

# install testing application on target cluster
appFileName=HttpSessionSample.war
appName=HttpSessionSample
appDisplayName=wxs.httpsession.sample
cellName=CSCCell_1
targetType=cluster
targetName=CSC_Cluster_1
virtualHost=default_host

#./runWsadmin.sh AppUninstall.py ${appName}
#./runWsadmin.sh AppInstall.py ${appFileName} ${appName} ${appDisplayName} ${cellName} ${targetType} ${targetName} ${virtualHost}

./runWsadmin.sh main.py ER_config.py



