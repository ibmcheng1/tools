#!/bin/bash
##########################################################
##
## SCRIPT DESCRIPTION:
## Control script for WebSphere eXtreme Scale to 
## perform server cluster administration operations
##
## DETAILS:
## Script for stop/start/restart/backup which may also
## be used in conjunction with a WXS RC script in 
## /etc/rc.d in the event of physical server shutdowns
##
## DEPENDENCIES:
## - pget.awk
## - wxs.conf
##
## USAGE:
## WXSctl.sh <ACTION> <COMPONENT>
##
## 2013-08-30: Initial version created
## 2013-09-06: Added option to clear grid map
## 2013-09-20: Fixed copy paste error in "all" section
## 2013-09-24: Added catalog check for container up
##
## Michael Palassis <mpalassis@cornerstonebrands.com>
##
##########################################################

# Uncomment to debug script
#set -xv

SCRIPT_HOME=/opt/csbwxs
HOSTNAME="$(basename $(hostname) .cbi.intl)"
ARGNUM=$#
ACTION="$1"
COMP="$2"
shift 2		# shift by 2 argument place to pick up remaining arguments
ARGUMENTS="$@"
USER="wasadmin"
LOG=$SCRIPT_HOME/WXSctl.log
USAGE="Usage: $0 {start|stop|restart|status|clear} {catalog|container|all|map} {jvm1 jvm2 ...|brand}"

# Source the WXS environment variables
. $SCRIPT_HOME/setupEnv.sh




##################################################
## PREREQUISITES
##################################################

## Confirm sufficient parameters are passed
if [ $ARGNUM -lt 2 ]; then
   echo $USAGE; exit 1
fi

## Verify that user is correct
if [ "$(id -un)" != "$USER" ]; then
   echo "[!] Script must be run as the wasadmin user! Aborting..."; exit 1
fi

## Find config file
CONF=$SCRIPT_HOME/wxs.conf
if [ ! -r $CONF ]; then
    echo "[!] Couldn't read configuration file! Aborting..."; exit 1
fi

## Find pget.awk
PGET_CMD=/usr/local/bin/pget.awk
if [ ! -x $PGET_CMD ]; then
    echo "[!] Couldn't find pget.awk! Aborting..."; exit 1
fi

## Check if log file is bigger than 50MB then compress
if [ `stat -c %s $LOG` -gt 52428800 ]; then
   echo "[*] WXSctl log is bigger than 50MB, compressing..."
   gzip -f $LOG
fi

## Validate component 
if [ -z "$COMP" ]; then
   echo "[!] No component specified! Aborting..."; exit 1
else
  COMP=`echo $COMP | tr '[:lower:]' '[:upper:]'`
fi




##################################################
## FUNCTIONS
##################################################
function startCatalogServer () {
        HOST=$1
        JVM=$2
        # Set JVM parameters
        CATALOG_SERVICE_DOMAIN_INDEX=`$PGET_CMD SECTION=$JVM PARAM=CATALOG_SERVICE_DOMAIN_INDEX $CONF`
        CATALOGSERVER_LISTENER_PORT=`$PGET_CMD SECTION=$JVM PARAM=CATALOGSERVER_LISTENER_PORT $CONF`
        CATALOGSERVER_JMX_PORT=`$PGET_CMD SECTION=$JVM PARAM=CATALOGSERVER_JMX_PORT $CONF`
        CATALOGSERVER_JVM_ARGS=`$PGET_CMD SECTION=$JVM PARAM=CATALOGSERVER_JVM_ARGS $CONF`
        if [ -n "$(echo $HOST | grep $HOSTNAME 2>/dev/null)" ]; then
           echo "[.] Local call to $HOST to start Catalog Server JVM $JVM"
           # Run local start action
           cd $SCRIPT_HOME; $OBJECTGRID_ROOT/bin/startOgServer.sh $JVM -domain $CATALOG_SERVICE_DOMAIN_NAME -serverProps $WORKING_DIR/properties/objectGridServer.properties -catalogServiceEndPoints $CS_ENDPOINTS_FOR_CATALOG -listenerPort $CATALOGSERVER_LISTENER_PORT -jmxServicePort $CATALOGSERVER_JMX_PORT -listenerHost $HOST -quorum false -jvmArgs $CATALOGSERVER_JVM_ARGS &
        else
           echo "[.] Remote call to $HOST to start Catalog Server JVM $JVM"
           # Run remote start action
           ssh -q $USER@$HOST "cd $SCRIPT_HOME; $OBJECTGRID_ROOT/bin/startOgServer.sh $JVM -domain $CATALOG_SERVICE_DOMAIN_NAME -serverProps $WORKING_DIR/properties/objectGridServer.properties -catalogServiceEndPoints $CS_ENDPOINTS_FOR_CATALOG -listenerPort $CATALOGSERVER_LISTENER_PORT -jmxServicePort $CATALOGSERVER_JMX_PORT -listenerHost $HOST -quorum false -jvmArgs $CATALOGSERVER_JVM_ARGS" &
        fi
}

function stopCatalogServer () {
        JVM=$1
        echo "[.] XSCMD call to stop Catalog Server JVM $JVM"
        # Call xscmd with list of jvms to stop
        $OBJECTGRID_ROOT/bin/xscmd.sh -cep $CS_ENDPOINTS_FOR_CONTAINERS -c teardown -sl $JVM -force
}

function startContainerServer () {
        HOST=$1
        JVM=$2
        # Verify catalog server(s) up before starting up container
        $OBJECTGRID_ROOT/bin/xscmd.sh -c showQuorumStatus -cep $CS_ENDPOINTS_FOR_CONTAINERS > /dev/null 2>&1
        if [ $? -ne 0 ]; then
           echo "[!] CATALOG SERVER(S) NOT RUNNING!"; echo
        else
           # Set JVM parameters
           CONTAINERSERVER_HAMANAGER_PORT=`$PGET_CMD SECTION=$JVM PARAM=CONTAINERSERVER_HAMANAGER_PORT $CONF`
           CONTAINERSERVER_LISTENER_PORT=`$PGET_CMD SECTION=$JVM PARAM=CONTAINERSERVER_LISTENER_PORT $CONF`
           CONTAINERSERVER_JVM_ARGS=`$PGET_CMD SECTION=$JVM PARAM=CONTAINERSERVER_JVM_ARGS $CONF`
           # Execute action for component either local or remote
           if [ -n "$(echo $HOST | grep $HOSTNAME 2>/dev/null)" ]; then
              echo "[.] Local call to $HOST to start Container Server JVM $JVM"
              # Run local start action
              cd $SCRIPT_HOME; $OBJECTGRID_ROOT/bin/startOgServer.sh $JVM -serverProps $WORKING_DIR/properties/objectGridServer.properties -haManagerPort $CONTAINERSERVER_HAMANAGER_PORT -catalogServiceEndPoints $CS_ENDPOINTS_FOR_CONTAINERS -objectgridFile $OBJECT_GRID_XML -deploymentPolicyFile $DEPLOYMENT_POLICY_XML -listenerPort $CONTAINERSERVER_LISTENER_PORT -jvmArgs $CONTAINERSERVER_JVM_ARGS -cp $APP_LIB_PATH
           else
              echo "[.] Remote call to $HOST to start Container Server JVM $JVM"
              # Run remote start action
              ssh -qfn $USER@$HOST "cd $SCRIPT_HOME; $OBJECTGRID_ROOT/bin/startOgServer.sh $JVM -serverProps $WORKING_DIR/properties/objectGridServer.properties -haManagerPort $CONTAINERSERVER_HAMANAGER_PORT -catalogServiceEndPoints $CS_ENDPOINTS_FOR_CONTAINERS -objectgridFile $OBJECT_GRID_XML -deploymentPolicyFile $DEPLOYMENT_POLICY_XML -listenerPort $CONTAINERSERVER_LISTENER_PORT -jvmArgs $CONTAINERSERVER_JVM_ARGS -cp $APP_LIB_PATH"
           fi
        fi
}

function stopContainerServer () {
        JVM=$1
        echo "[.] XSCMD call to stop Container Server JVM $JVM"
        # Call xscmd with list of jvms to stop
        $OBJECTGRID_ROOT/bin/xscmd.sh -cep $CS_ENDPOINTS_FOR_CONTAINERS -c teardown -sl $JVM -force
}

function showCache () {
        echo "[.] Running WXS xscmd scripts to display status of various components..."
        # Kick off WXS status commands
        $OBJECTGRID_ROOT/bin/xscmd.sh -c showQuorumStatus -cep $CS_ENDPOINTS_FOR_CONTAINERS
        $OBJECTGRID_ROOT/bin/xscmd.sh -c listHosts -cep $CS_ENDPOINTS_FOR_CONTAINERS
        $OBJECTGRID_ROOT/bin/xscmd.sh -c showPlacement -cep $CS_ENDPOINTS_FOR_CONTAINERS
        $OBJECTGRID_ROOT/bin/xscmd.sh -c routetable -cep $CS_ENDPOINTS_FOR_CONTAINERS
        $OBJECTGRID_ROOT/bin/xscmd.sh -c showMapSizes -cep $CS_ENDPOINTS_FOR_CONTAINERS
}

function clearGridMap () {
        BRAND=$1
        MAPLIST=`$PGET_CMD SECTION=$BRAND PARAM=MAP $CONF`
        echo "[.] XSCMD call to clear grid maps..."
        for map in $MAPLIST; do
           echo $map
           $OBJECTGRID_ROOT/bin/xscmd.sh -cep $CS_ENDPOINTS_FOR_CONTAINERS -c clearGrid -f -g $DATA_GRID -ms $DATA_GRID -m $map
        done
}






##################################################
## MAIN
##################################################
cd $SCRIPT_HOME

# Set Catalog Service Endpoints for use by container servers
HOSTS=`$PGET_CMD SECTION=CATALOG PARAM=HOST $CONF`
i=0
for host in $HOSTS; do
    JVMS=`$PGET_CMD SECTION="$host~CATALOG" PARAM=JVM $CONF`
    # Loop through JVM list and call action function
    for jvm in $JVMS; do
        PORT=`$PGET_CMD SECTION="$jvm" PARAM=CATALOGSERVER_LISTENER_PORT $CONF`
        BUILD_CS_ENDPOINTS_CONT[i++]="$host:$PORT"
    done
done
IFS=,
CS_ENDPOINTS_FOR_CONTAINERS=`echo "${BUILD_CS_ENDPOINTS_CONT[*]}"`
unset IFS
echo "CS_ENDPOINTS_FOR_CONTAINERS: $CS_ENDPOINTS_FOR_CONTAINERS"

# Set Catalog Service Endpoints for use by catalog servers
i=0
for host in $HOSTS; do
    JVMS=`$PGET_CMD SECTION="$host~CATALOG" PARAM=JVM $CONF`
    # Loop through JVM list and call action function
    for jvm in $JVMS; do
        CLIENT_PORT=`$PGET_CMD SECTION="$jvm" PARAM=CATALOGSERVER_CLIENT_PORT $CONF`
        PEER_PORT=`$PGET_CMD SECTION="$jvm" PARAM=CATALOGSERVER_PEER_PORT $CONF`
        BUILD_CS_ENDPOINTS_CAT[i++]="$jvm:$host:$CLIENT_PORT:$PEER_PORT"
    done
done
IFS=,
CS_ENDPOINTS_FOR_CATALOG=`echo "${BUILD_CS_ENDPOINTS_CAT[*]}"`
unset IFS
echo "CS_ENDPOINTS_FOR_CATALOG: $CS_ENDPOINTS_FOR_CATALOG"


# Call appropriate action based on parameters passed
echo "" >> $LOG
echo "`date +%Y-%m-%d-%H%M%S` ~ BEGIN ~ $ACTION $COMP $ARGUMENTS" 2>&1 | tee -a $LOG
case "$COMP" in
        CATALOG)
               # Get list of hosts eligible to perform action
               HOSTS=`$PGET_CMD SECTION=$COMP PARAM=HOST $CONF`
               for host in $HOSTS; do
                  FULLJVMLIST="$FULLJVMLIST $($PGET_CMD SECTION="$host~$COMP" PARAM=JVM $CONF)"
               done
               # Verify on a catalog server
               if [ -z "$(echo $HOSTS | grep $HOSTNAME 2>/dev/null)" ]; then echo "[!] Must run command from a catalog server.  Exiting..."; exit 1; fi

               case $ACTION in
                    [sS][tT][aA][rR][tT])
                            # Loop through hosts list
                            for host in $HOSTS; do
                               COMPJVMSONHOST=`$PGET_CMD SECTION="$host~$COMP" PARAM=JVM $CONF`
                               # Set JVMS list if not passed as argument
                               if [ -z "$ARGUMENTS" ]; then
                                  JVMS=`$PGET_CMD SECTION="$host~$COMP" PARAM=JVM $CONF`
                               else
                                  JVMS="$ARGUMENTS"
                               fi
                               # Loop through JVM list and call action function
                               for jvm in $JVMS; do 
                                   echo "$COMPJVMSONHOST" | grep -q $jvm 2>/dev/null
                                   if [ $? -ne 0 ]; then
                                      echo "[~] Warning: JVM $jvm not defined for Host $host.  Skipping...";
                                   else
                                      startCatalogServer $host $jvm
                                   fi
                               done
                            done
                    ;;
                    [sS][tT][oO][pP])
                            # Loop through hosts list
                            i=0
                            FULLHOSTLIST=`$PGET_CMD SECTION=$COMP PARAM=HOST $CONF`
                            for host in $FULLHOSTLIST; do
                               COMPJVMSONHOST=`$PGET_CMD SECTION="$host~$COMP" PARAM=JVM $CONF`
                               # Set JVMS list if not passed as argument
                               if [ -z "$ARGUMENTS" ]; then
                                  JVMS=`$PGET_CMD SECTION="$host~$COMP" PARAM=JVM $CONF`
                               else
                                  JVMS="$ARGUMENTS"
                               fi
                               # Loop through JVM list and call action function
                               for jvm in $JVMS; do
                                   echo "$COMPJVMSONHOST" | grep -q $jvm 2>/dev/null
                                   if [ $? -ne 0 ]; then
                                      echo "[~] Warning: JVM $jvm not defined for Host $host.  Skipping...";
                                   else
                                      BUILDJVMLIST[i++]="$jvm"
                                   fi
                               done
                            done
                            # Using values in array, build comma separated list of JVMs
                            IFS=,
                            STOPJVMLIST=`echo "${BUILDJVMLIST[*]}"`
                            unset IFS
                            if [ -n "$STOPJVMLIST" ]; then
                               stopCatalogServer $STOPJVMLIST
                            else
                               echo "[!] No valid JVMs for stopping"
                            fi
                    ;;
                    [rR][eE][sS][tT][aA][rR][tT])
                        $SCRIPT_HOME/WXSctl.sh stop $COMP $ARGUMENTS
                        sleep 60
                        $SCRIPT_HOME/WXSctl.sh start $COMP $ARGUMENTS
                    ;;
                    *)
                        echo "$USAGE"
                        exit 1
                    ;;
               esac
        ;;

        CONTAINER)
               # If running from a catalog server then get list of hosts to perform action, otherwise assume running from local server
               CATALOG_HOSTS=`$PGET_CMD SECTION=CATALOG PARAM=HOST $CONF`
               if [ -n "$(echo $CATALOG_HOSTS | grep $HOSTNAME 2>/dev/null)" ]; then
                  HOSTS=`$PGET_CMD SECTION=$COMP PARAM=HOST $CONF`
               else
                  HOSTS="$HOSTNAME"
               fi
               # Set full JVM list for validating arguments passed
               COMP_HOSTS=`$PGET_CMD SECTION=$COMP PARAM=HOST $CONF`
               for host in $COMP_HOSTS; do
                  FULLJVMLIST="$FULLJVMLIST $($PGET_CMD SECTION="$host~$COMP" PARAM=JVM $CONF)"
               done

               case $ACTION in
                    [sS][tT][aA][rR][tT])
                            # Loop through hosts list
                            for host in $HOSTS; do
                               COMPJVMSONHOST=`$PGET_CMD SECTION="$host~$COMP" PARAM=JVM $CONF`
                               # Set JVMS list if not passed as argument
                               if [ -z "$ARGUMENTS" ]; then
                                  JVMS=`$PGET_CMD SECTION="$host~$COMP" PARAM=JVM $CONF`
                               else
                                  JVMS="$ARGUMENTS"
                               fi
                               # Loop through JVM list and call action function
                               for jvm in $JVMS; do
                                   echo "$COMPJVMSONHOST" | grep -q $jvm 2>/dev/null
                                   if [ $? -ne 0 ]; then
                                      echo "[~] Warning: JVM $jvm not defined for Host $host.  Skipping...";
                                   else
                                      startContainerServer $host $jvm
                                   fi
                               done
                            done
                    ;;
                    [sS][tT][oO][pP])
                            # Loop through hosts list
                            i=0
                            for host in $HOSTS; do
                               COMPJVMSONHOST=`$PGET_CMD SECTION="$host~$COMP" PARAM=JVM $CONF`
                               # Set JVMS list if not passed as argument
                               if [ -z "$ARGUMENTS" ]; then
                                  JVMS=`$PGET_CMD SECTION="$host~$COMP" PARAM=JVM $CONF`
                               else
                                  JVMS="$ARGUMENTS"
                               fi
                               # Loop through JVM list and call action function
                               for jvm in $JVMS; do
                                   echo "$COMPJVMSONHOST" | grep -q $jvm 2>/dev/null
                                   if [ $? -ne 0 ]; then
                                      echo "[~] Warning: JVM $jvm not defined for Host $host.  Skipping...";
                                   else
                                      BUILDJVMLIST[i++]="$jvm"
                                   fi
                               done
                            done
                            IFS=,
                            STOPJVMLIST=`echo "${BUILDJVMLIST[*]}"`
                            unset IFS
                            if [ -n "$STOPJVMLIST" ]; then
                               stopContainerServer $STOPJVMLIST
                            else
                               echo "[!] No valid JVMs for stopping"
                            fi
                    ;;
                    [rR][eE][sS][tT][aA][rR][tT])
                            $SCRIPT_HOME/WXSctl.sh stop $COMP $ARGUMENTS
                            $SCRIPT_HOME/WXSctl.sh start $COMP $ARGUMENTS
                    ;;
                    *)
                            echo "$USAGE"
                            exit 1
                    ;;
               esac
        ;;

        [aA][lL][lL])
               case $ACTION in
                    [sS][tT][aA][rR][tT])
                        $SCRIPT_HOME/WXSctl.sh start CATALOG
                        sleep 60
                        $SCRIPT_HOME/WXSctl.sh start CONTAINER
                    ;;
                    [sS][tT][oO][pP])
                        $SCRIPT_HOME/WXSctl.sh stop CONTAINER
                        $SCRIPT_HOME/WXSctl.sh stop CATALOG
                    ;;
                    [rR][eE][sS][tT][aA][rR][tT])
                        $SCRIPT_HOME/WXSctl.sh stop ALL
                        $SCRIPT_HOME/WXSctl.sh start ALL
                    ;;
                    [sS][tT][aA][tT][uU][sS])
                        showCache
                    ;;
                    *)
                        echo "$USAGE"
                        exit 1
                    ;;
               esac
        ;;

        [mM][aA][pP])
               case $ACTION in
                    [cC][lL][eE][aA][rR])
                        if [ -n "$ARGUMENTS" ]; then
                           clearGridMap $ARGUMENTS
                        else
                           echo "$USAGE"
                        fi
                    ;;
                    *)
                        echo "$USAGE"
                        exit 1
                    ;;
               esac
        ;;

        *)
               echo "$USAGE"
               exit 1
        ;;

esac
echo "`date +%Y-%m-%d-%H%M%S` ~ END ~ $ACTION $COMP $ARGUMENTS" 2>&1 | tee -a $LOG
echo
echo

exit 0
