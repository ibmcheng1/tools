#!/bin/sh

fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

echo servletUrl=$servletUrl
echo objectgridName=$objectgridName
echo mapName=$mapName

loop=1
actionListIndex=4
size=32000
threadLoad=4000
startKeyIndex=0
options="-disableRunGC -print"

./runDriver.sh -caseServlet -loop $loop -actionListIndex $actionListIndex -size $size -multiWorkerMode $threadLoad -startKeyIndex $startKeyIndex -dataServiceType 3 -servletUrl $servletUrl -objectgridName $objectgridName -mapName $mapName $options
   
