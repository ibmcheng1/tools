#!/bin/sh
# This script is intended to work on Linux with bash shell or AIX with ksh.
# Be sure to set the first line of the script appriately for the platform where
# it will be run.
#
###############################################################################
# Licensed Material - Property of IBM
# 5724-I63, 5724-H88, (C) Copyright IBM Corp. 2013 - All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.
#
# DISCLAIMER:
# The following source code is sample code created by IBM Corporation.
# This sample code is provided to you solely for the purpose of assisting you
# in the  use of  the product. The code is provided 'AS IS', without warranty or
# condition of any kind. IBM shall not be liable for any damages arising out of 
# your use of the sample code, even if IBM has been advised of the possibility 
# of such damages.
###############################################################################
# Authors: 	Chong Lee chognlee@us.ibm.com	
#
# History:
#         	11 DEC -2013 - initial script creation
#
# Shell script wrapper to launch Jython script that configures cell custom properties
#
# This script was developed to work on Linux or AIX VMs running on IBM PureApplication 
# System (IPAS). It is intended to run on any Linux environment, but it hasn't been 
# tested thoroughly on non-IPAS environments so some IPAS dependencies may have crept 
# into the script.
#
# This script invokes:
#    1. modifyMemoryLeakHealthPolicy.py
#
# This script was developed to work with a "higher level" controlling script that invokes
# this script.  The calling script may have a log file. If it is desired to have this
# script log trace output into the same log file as the calling script, the caller's
# log file path can be passed into this script.  This script also keeps its own log file 
# to make it convenient to look at specifically what this script did, without having to
# separate it from the caller's log file.
#
# The log file used by this script is in $PWD/logs.  When the script starts, it looks 
# for the logs directory and if it doesn't exist, it creates it.  It also looks for an
# existing log file and if one is found it rolls it off with a time stamp in the name  
# and creates a new one for the current run of the script.
#
# The underlying Jython script accepts several arguments so this script needs
# to be able to handle those arguments and pass them along accordingly.
#

function usage {
  echo "Usage: modifyMemoryLeakHealthPolicy.sh [options]"
  echo "   -user <username>             - (optional) WAS user name with administrator privileges"
  echo "                                  This must be a valid user in the WAS registry"
  echo "                                  Defaults to \$WAS_USERNAME"
  echo "   -password <password>         - (optional) WAS user password"
  echo "                                - NOTE: It is best to let wsadmin prompt for the user name and password."
  echo "                                  Defaults to \$WAS_PASSWORD" 
  echo "   -host <hostname>             - Name of host to use for wsadmin connection to a Deployment Manager"
  echo "                                - Defaults to \$DMGR_HOST then localhost"
  echo "   -port <portnumber>           - (optional) The JSR160RMI or SOAP port to use for wsadmin connection."
  echo "                                  SOAP defaults first to \$DMGR_JMX_PORT then to 8879.  JSR160RMI defaults to 9809."
  echo "   -conntype <conntype>         - (optional) The connection type. (defaults first to \$DMGR_CONNTYPE then to JSR160RMI)"
  echo "   -wasHome <washome>           - (semi-required) Root directory of profile or WAS installation or profile."
  echo "                                  Defaults in this order to: \$WAS_PROFILE_ROOT, \$WAS_INSTALL_ROOT and \$WAS_HOME",
  echo "                                  if -wasHome is not provided."
  echo "   -workingDirectory <dirpath>  - (optional) Path to directory where scripts and properties files are located."
  echo "                                  Defaults to \$PWD"
  echo "   -logfile <pathname>          - (optional) Path to a log file being used by the caller of this script."
  echo "                                  Trace from this shell script is tee'ed to the caller's log file."
  echo "   -trace <tracespec>           - (optional) <tracespec> is a WAS style trace string for the Jython modules to be traced at the"
  echo "                                  givent trace level.  The default trace level is INFO."
  echo "   -tracefile <pathname>        - (optional) Path to log file if Jython script trace is enabled. Defaults to logs/trace.log in \$PWD."
  echo "   -help|-h                     - emit this usage information"
  echo ""
  echo " The memoryLeakHealthPolicy.py script has the following options:"
  echo "   -cellProperties <pathname> 	- (required) file with the Cell Custom properties defined in it."
  echo "   	                          If the pathname begins with a / it is treated as absolute."
  echo "                                        Otherwise, the pathname is relative to the workingDirectory."
  echo ""
}

# Import the trace functions.
. ./traceFunctions.sh


# The quoted() function is used when there is a script argument that must be 
# quoted to be passed as an argument to a called script.  Shells often strip
# quotes from a command line argument. The quoted() function adds the quote
# delimiters back in.
# NOTE: bash has builtins for dealing with access to characters in a string.
# The use of expr is to be compatible with any other shells, in particular, ksh.
function quoted {
  s="$1"
  firstChar=$(expr substr $s 1 1)
  lastChar=$(expr substr $s ${#s} 1)
  if [ "${firstChar}" != "\"" ] || [ "${lastChar}" != "\"" ]; then
    s="\"${s}\""
  fi
  echo "$s"
}

# The makePath function takes two arguments.  The first is a working directory.
# The second is a relative or absolute path.  If the second argument is a relative
# path, then the working directory is used as the home directory and it is prepended
# to the given path.  If the second argument is an absolute path, then it is returned
# as is.
function makePath {
  local workingDir=$1
  local path=$2
  firstChar=$(expr substr $path 1 1)
  if [ "$firstChar" == "/" ]; then
    result="${path}"
  else
    result="${workingDir}/${path}"
  fi
  echo "$result"
}
    


###########################################################################
##### "Main" starts here
SCRIPT=${0##*/}

# When debugging on IPAS, source the virtualimage.properties
if [ -f /etc/virtualimage.properties ]; then
  . /etc/virtualimage.properties
fi

# All log files are written into a logs directory in the current directory.
# Make sure there is a "logs" directory in the current directory
if [ ! -d "${PWD}/logs" ]; then
  mkdir logs
  rc=$?
  if [ "$rc" != "0" ]; then
    # Not sure why this would ever happen, but...
    # Have to echo here since trace log is not set yet.
    echo "Creating ${PWD}/logs directory failed.  Exiting..."
    exit -1
  fi
fi

CALLER_LOGFILE=""
LOGFILE="${PWD}/logs/${SCRIPT%.*}.log"
if [ -f "$LOGFILE" ]; then
  rollFile "$LOGFILE"
fi

# initialize variables
user=""
password=""
host=""
port=""
conntype=""
wasHome=""
workingDirectory=""
logfile=""
trace=""
tracefile=""
cellProperties=""

# process the input args
# For keyword-value arguments the arg gets the keyword and
# the case statement assigns the value to a script variable.
# If any "switch" args are added to the command line args,
# then it wouldn't need a shift after processing the switch
# keyword.  The script variable for a switch argument would
# be initialized to "false" or the empty string and if the 
# switch is provided on the command line it would be assigned
# "true".
#
while (( $# > 0 )); do
  arg=$1
  case $arg in
    -h|-help ) usage; exit 0
                  ;;

    -user )     user=$2; shift
                ;;

    -password ) password=$2; shift
                ;;

    -host )     host=$2; shift
                ;;

    -port )     port=$2; shift
                ;;

    -conntype ) conntype=$2; shift
                ;;

    -wasHome )  wasHome=$2; shift
                ;;

    -workingDirectory )  workingDirectory=$2; shift
                         ;;
    
    -logfile|-logFile ) logfile=$2; shift
               		;;

    -trace ) trace=$2; shift
             ;;

    -tracefile ) tracefile=$2; shift
             ;;

    -cellProperties|-cell ) cellProperties=$2; shift
                 ;;

    * ) usage; info $LINENO "Unknown option: $arg in command line." 
        exit -1
        ;;
  esac
  # shift to next key-value pair
  shift
done



if [ -n "$logfile" ]; then
  # Include a "caller" log file
  CALLER_LOGFILE="$logfile"
fi

# If wasHome didn't come in on the command line check
# various env vars to get a value for wasHome.
if [ -z "$wasHome" ]; then
  wasHome="$WAS_PROFILE_ROOT"

  if [ -z "$wasHome" ]; then
    wasHome="$WAS_INSTALL_ROOT"
  fi

  if [ -z "$wasHome" ]; then
    wasHome="$WAS_HOME"
  fi

  # Check for requried parameter: wasHome
  if [ -z "$wasHome" ]; then
    info $LINENO "Couldn't find a value for the WAS home directory."
    info $LINENO "Either provide a value using the -wasHome command line option,"
    info $LINENO "or set WAS_PROFILE_ROOT, WAS_INSTALL_ROOT or WAS_HOME in the OS environment for the script."
    exit -1
  fi
fi

# For appearances sake, strip a potential trailing / from wasHome
wasHome=${wasHome%/}


# If neither user or password is provided on the command line, 
# then try WAS_USERNAME and WAS_PASSWORD
if [ -z "$user" ]; then
  user="$WAS_USERNAME"
  password="$WAS_PASSWORD"

  # If WAS_USERNAME and WAS_PASSWORD are not defined, then try DMGR_USERID and DMGR_PASSWORD
  # The IPAS nodes use DMGR_USERID and DMGR_PASSWORD in /etc/virtualimage.properties
  if [ -z "$user" ]; then
    user="$DMGR_USERID"
    password="$DMGR_PASSWORD"
  fi

  if [ -z "$user" ]; then
    trace $LINENO "WARNING, A WebSphere user and password has not been provided."
  fi
fi

# If user or password are in fact provided,
# then make sure both are provided.  
if [ -n "$user" ] && [ -z "$password" ]; then
  usage | tee -a $LOGFILE $CALLER_LOGFILE
  info $LINENO "If a WAS user is provided a password is required."
  info $LINENO "For security reasons, we recommend you let wsadmin prompt for user and password."
  exit -1
fi

if [ -z "$user" ] && [ -n "$password" ]; then
  usage | tee -a $LOGFILE $CALLER_LOGFILE
  info $LINENO "You provided a password but didn't provide a user."
  info $LINENO "For security reasons, we recommend you let wsadmin prompt for user and password."
  exit -1
fi

# Fill in default values for optional parameters:
#   host, conntype, port
#
if [ -z "$host" ]; then
  host=$DMGR_HOST
  if [ -z "$host" ]; then
    host=localhost
  fi
fi

if [ -z "$conntype" ]; then
  conntype=$DMGR_CONNTYPE
  if [ -z "$conntype" ]; then
    conntype=JSR160RMI
  fi
fi


# Default stand-alone server JSR160RMI port is 2809
# Default Deployment Manager JSR160RMI port is 9809
if [ -z "$port" ]; then
  if [ "$conntype" = "JSR160RMI" ]; then
    port=9809
  elif [ "$conntype" = "SOAP" ]; then
    if [ -n "$DMGR_JMX_PORT" ]; then
      port=$DMGR_JMX_PORT
    else
      port=8879
    fi
  else
    info $LINENO "Unrecognized connection type: $conntype"
    info $LINENO "Recognized connection types are JSR160RMI and SOAP"
    exit -1
  fi
fi

# Get workingDirectory or fill in default.
if [ -z "$workingDirectory" ]; then
  workingDirectory="$PWD"
else
  # for appearances sake strip potential trailing / from path
  workingDirectory="${workingDirectory%/}"
fi


# WARNING: The quoting of directory paths is intended to deal with the potential 
# for a space character in the path.  However, I'm not positive a path with space
# characters in it would really work.  Using a directory with a space character
# in it has NOT been tested.
#

WSADMIN=""${wasHome}"/bin/wsadmin.sh"

WSADMIN_ARGS="-lang jython -conntype $conntype -host $host -port $port"
if [ -n "$user" ] && [ -n "$password" ]; then
  WSADMIN_ARGS="$WSADMIN_ARGS -user $user -password $password"
fi

WSADMIN_ARGS="$WSADMIN_ARGS -f "${workingDirectory}"/modifyMemoryLeakHealthPolicy.py"

# Now add in the arguments for the Jython script.
# setMemoryLeakHealthPolicy.py arguments:
#   1. propertyFile
#
SCRIPT_ARGS=""

# NOTE: CELL_CUSTOM_PROPERTIES may be defined in the context of IPAS and will be 
# used as the file path for cellProperties if it is not provided on the 
# command line.
if [ -z "${cellProperties}" ]; then
  if [ -n "${CELL_CUSTOM_PROPERTIES}" ]; then
    cellProperties="${CELL_CUSTOM_PROPERTIES}"
  else
    info $LINENO "The -cellProperties argument or the CELL_CUSTOM_PROPERTIES env var must be defined."
  fi
fi
echo "-------------------------curl--------------------------------"
echo curl -f -O "http://${REMOTE_HOST_ADDRESS}/${CONFIG_DIRECTORY_LOCATION}/${cellProperties}"
curl -f -O "http://${REMOTE_HOST_ADDRESS}/${CONFIG_DIRECTORY_LOCATION}/${cellProperties}"
cellProperties=$(makePath "${workingDirectory}" "${cellProperties}")
SCRIPT_ARGS="$SCRIPT_ARGS -cellProperties "${cellProperties}""

# NOTE: wsadmin has a -tracefile arg so in order for the Jython script to provide a way to specify
# its trace file, we have to use -logfile as a Jython script argument.  We take the -tracefile coming
# in on this shell wrapper and supply it to the wsadmin invocation as a script argument using -logfile
# as the keyword.
if [ -n "$trace" ]; then
  trace=$(quoted "$trace")
  SCRIPT_ARGS="$SCRIPT_ARGS -trace "$trace""
  # If trace is enabled but logfile is not specified then logfile is logs/trace.log
  if [ -z "$tracefile" ]; then
    SCRIPT_ARGS="$SCRIPT_ARGS -logfile logs/trace.log"
  else
    SCRIPT_ARGS="$SCRIPT_ARGS -logfile "$tracefile""
  fi
fi

  
trace $LINENO "Launching: $WSADMIN "
info $LINENO "Command line arguments: $WSADMIN_ARGS $SCRIPT_ARGS"
$WSADMIN $WSADMIN_ARGS $SCRIPT_ARGS 2>&1 | tee -a $LOGFILE $CALLER_LOGFILE
rc=${PIPESTATUS[0]}
exit $rc

