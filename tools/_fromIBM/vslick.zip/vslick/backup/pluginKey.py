####################################################################    
import sys
import os
import fnmatch,re

from java.lang import String

runProcess=""

#import the applications config.py property file with input variables to be used into the script...

dir = os.getcwd()
fileName, fileExtension = os.path.splitext(sys.argv[0])

print "File Name: " + fileName
exec("from " + fileName + " import *")


# This scripts relies on the designated jython script library
# Process the resource file containing all of the admin task definitions

dir = os.getcwd()
print "current dir: " + dir
resources = dir+os.sep+"wsadminlib.py"
execfile(resources)

########################################
# Main
########################################
enableDebugMessages()

CELL_name=getCellName()

print "-------------------------------------------"
print "Retrieve Cell Certificates"
print "-------------------------------------------"
print "CELL_name         = " + CELL_name
print "APPLICATION_name  = " + APPLICATION_name
print "CACHING_certAlias = " + CACHING_certAlias
print "CACHING_host      = " + CACHING_host
print "CACHING_user      = " + CACHING_user
print "CACHING_password  = " + CACHING_password
print "CACHING_grid      = " + CACHING_grid
print "-------------------------------------------"

cellName = CELL_name
appName = APPLICATION_name
certAlias = CACHING_certAlias
cachingHost = CACHING_host
cachingUser = CACHING_user
cachingPassword = CACHING_password
cachingGrid = CACHING_grid

# sys.argv[0] is the ER_Config.py, other parameters start from position 1. 
action=sys.argv[1]
if action is not None:
    if (action == ""):
        print "ERROR: action is EMPTY"
    else:
        print "app action: "+action
        if (action == "enableXC10Session"):
            enableAppXC10SessionMgmt( appName, cachingHost, cachingUser, cachingPassword, cachingGrid )                       
        if (action == "disableXC10Session"):
            disableAppXC10SessionMgmt( appName )
        saveAndSyncAndPrintResult()
else:
  print "ERROR: Action is NONE"  
