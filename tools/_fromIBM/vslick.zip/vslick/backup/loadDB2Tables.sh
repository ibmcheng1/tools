#!/bin/sh
#Based on my work to fix GetIssuerList and ProvisionDynamicPaymentInfo I've included a new version of the process for the DB, the changes include:
#1. First install DB2 V10.1 as V9 will create a number of errors
#2. Create the database and associate tables 
#Open a DB2 command window and run:
#db2 create db tchdb
#db2 connect to TCHDB
COMMON_DDL="/tmp/WMB/DB2_Data/common.ddl"
TCH_SCHEME_DDL="/tmp/WMB/DB2_Data/tch_schema.ddl"
su - db2inst1 -c "db2 connect to TCHDB; db2 -tvf $COMMON_DDL;"
su - db2inst1 -c "db2 connect to TCHDB; db2 -tvf $TCH_SCHEME_DDL;"
#Errors did occur, but I just ignore these, as in general it appears to work:
#
#3. Import the sample data into the tables[attachment "tableData.zip" deleted by Neal Finkelstein/Paramus/IBM] 
#Extract the following ZIP into a directory:  
#Open a DB2 command window, and change directories to where you extracted the above, and run the following commands
#db2 connect to TCHDB
su - db2inst1 -c "db2 connect to TCHDB; db2 load from /tmp/WMB/tableData/Issuer_Master.csv of del replace into tch.Issuer_master nonrecoverable"
su - db2inst1 -c "db2 connect to TCHDB; db2 load from /tmp/WMB/tableData/Vault_Master.csv of del replace into tch.Vault_Master nonrecoverable"
su - db2inst1 -c "db2 connect to TCHDB; db2 load from /tmp/WMB/tableData/Acquirer_Master.csv of del replace into tch.Acquirer_Master nonrecoverable"
su - db2inst1 -c "db2 connect to TCHDB; db2 load from /tmp/WMB/tableData/Wallet_Provider_master.csv of del replace into tch.Wallet_Provider_master nonrecoverable"
su - db2inst1 -c "db2 connect to TCHDB; db2 load from /tmp/WMB/tableData/IID_Master.csv of del replace into tch.IID_master nonrecoverable"
su - db2inst1 -c "db2 connect to TCHDB; db2 load from /tmp/WMB/tableData/BIN_Master.csv of del replace into tch.BIN_master nonrecoverable"
su - db2inst1 -c "db2 connect to TCHDB; db2 load from /tmp/WMB/tableData/Issuer_Wallet_Provider_Mapping.csv of del replace into tch.Issuer_Wallet_Provider_mapping nonrecoverable"
su - db2inst1 -c "db2 connect to TCHDB; db2 load from /tmp/WMB/tableData/Message_Types.csv of del replace into tch.Message_Types nonrecoverable"
su - db2inst1 -c "db2 connect to TCHDB; db2 load from /tmp/WMB/tableData/Message_Certification.csv of del replace into tch.Message_Certification nonrecoverable"
su - db2inst1 -c "db2 connect to TCHDB; db2 load from /tmp/WMB/tableData/Issuer_Logo.csv of del replace into tch.Issuer_Master_Logo nonrecoverable"
#I've also included a simplified Issue logo file as it can be hard to read with all the data, if you would prefer to load this then use the following command:
su - db2inst1 -c "db2 connect to TCHDB; db2 load from Issuer_SimplifiedLogo.csv of del replace into tch.Issuer_Master_Logo nonrecoverable"
#4. At the moment the import of data seems to get slightly corrupted so run the following commands to fix up (I now understand why, but have not managed to fix it):
su - db2inst1 -c "db2 connect to tchdb; db2 -vtf /tmp/WMB/DB2_Data/update.sql"
