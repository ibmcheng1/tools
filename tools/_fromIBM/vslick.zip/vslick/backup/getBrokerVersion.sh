#!/bin/sh

BROKER=$1

echo "stopping ${BROKER} ..."
mqsistop "$BROKER"