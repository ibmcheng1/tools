#!/bin/ksh
#
# synchronize the deploy directory for an environment
# from apps1a to the other servers.
#
# NOTE: apps1a is considered the master, other servers
# will have files added/removed/changed in order to make
# them match apps1a
#
umask 027
ENV=$1


if [ ! "`hostname`" == "cscertstcdc074.cdc-dc1.cscehub.com" ]
then
  echo "This script can only be run from Dmanager cscertstcdc074.cdc-dc1.cscehub.com"
  exit 1
fi

RSYNC=/usr/bin/rsync
SSH=/usr/bin/ssh
#DIR=/export/opt/deploy/uat
DIR=/export/opt/deploy
DIRS="static"
#HOSTS="20.176.240.71 20.176.240.108 20.176.240.9"
HOSTS="20.176.240.71 20.176.240.108"
#HOSTS="20.176.240.108"


for host in $HOSTS
do
  d=$DIR
  echo "Syncing $ENV $d to $host..."
  # according to rsync man page, ssh prefers blocking io
  $RSYNC -a -v --delete --rsh=$SSH --blocking-io --exclude=.ssh/ $d/ $host:$d
  if [ $? -ne 0 ]
  then
    echo "**ERROR** Error syncing $d to $host"
    exit 2
  fi
  echo "OK $d"
done



exit 0
