#!/bin/sh
echo ======================================
echo running installWXSClientOnWAS8.sh
echo ======================================

echo "------------------------------------------"
echo ENV_CONFIG_FILE=$ENV_CONFIG_FILE
echo "------------------------------------------"
if [ -f $ENV_CONFIG_FILE ]; then
  . $ENV_CONFIG_FILE
else
  echo "ERROR: ENV_CONFIG_FILE=${ENV_CONFIG_FILE} is not found"
  exit 1
fi

echo SOFTWARE_REPOSITORY=$SOFTWARE_REPOSITORY
echo IBMIM_installationDirectory=$IBMIM_installationDirectory
echo IBMIM_sharedResourcesDirectory=$IBMIM_sharedResourcesDirectory
echo WAS_installationDirectory=$WAS_installationDirectory
echo WXS_CLIENT_packageID=$WXS_CLIENT_packageID
echo WXS_CLIENT_version=$WXS_CLIENT_version
echo WXS_CLIENT_packageID_version=$WXS_CLIENT_packageID_version
echo WXS_CLIENT_features=$WXS_CLIENT_features
echo WXS_CLIENT_packageID_features=$WXS_CLIENT_packageID_features
echo WXS_CLIENT_repositories=$WXS_CLIENT_repositories
echo "------------------------------------------"

INSTALLATION_DIRECTORY=$WXS_CLIENT_installationDirectory
PACKAGEID=$WXS_CLIENT_packageID
VERSION=$WXS_CLIENT_version
PACKAGEID_VERSION=$WXS_CLIENT_packageID_version
FEATURES=$WXS_CLIENT_features
PACKAGEID_FEATURES=$WXS_CLIENT_packageID_features
REPOSITORIES=$WXS_CLIENT_repositories
IFIX_PACKAGEID=$WXS_IFIX_SOFTWARE_PACKAGE
IFIX_REPOSITORIES=$WXS_IFIX_SOFTWARE_PATH

echo INSTALLATION_DIRECTORY=$INSTALLATION_DIRECTORY
echo PACKAGEID=$PACKAGEID
echo VERSION=$VERSION
echo PACKAGEID_VERSION=$PACKAGEID_VERSION
echo FEATURES=$FEATURES
echo PACKAGEID_FEATURES=$PACKAGEID_FEATURES
echo REPOSITORIES=$REPOSITORIES
echo IFIX_PACKAGEID=$IFIX_PACKAGEID
echo IFIX_REPOSITORIES=$IFIX_REPOSITORIES

export IBMIM_installationDirectory
export IBMIM_sharedResourcesDirectory
export INSTALLATION_DIRECTORY
export PACKAGEID
export VERSION
export PACKAGEID_VERSION
export FEATURES
export PACKAGEID_FEATURES
export REPOSITORIES
export IFIX_PACKAGEID
export IFIX_REPOSITORIES

${WORKING_DIR}/scripts/runImclInstall.sh

echo ======================================
echo end of installWXSClientOnWAS8.sh
echo ======================================
