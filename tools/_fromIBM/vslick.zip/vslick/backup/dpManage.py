#!/usr/bin/python
#
# Author: Andy Grohman, 2013-04-15
# Contributors: Ken Hygh, Manuel Rohmann
#
# Generic DP script wrapper
import argparse, os, httplib, base64, xml.dom.minidom
from string import Template
from datetime import datetime

def log(message):
  print datetime.now().strftime('%Y-%m-%d %H:%M:%S') + ' ' + message
  
def processRequest(connection,target,requestMessage,headers):
  connection.request('POST',target,requestMessage,headers)
  response = connection.getresponse()
  if(response.status == 200):
    responseMessage = response.read()
    dom = xml.dom.minidom.parseString(responseMessage)
    
    #-- Log results
    log('Response:')
    responseElements = dom.getElementsByTagNameNS('http://www.datapower.com/schemas/management','response')
    for element in responseElements:
      print '\n'.join([line for line in element.toprettyxml(indent=' '*2).split('\n') if line.strip()])
      
    #-- Check for errors
    resultElements = dom.getElementsByTagNameNS('http://www.datapower.com/schemas/management','result')
    for element in resultElements:
      if(element.hasChildNodes()):
        if(element.firstChild.nodeType != xml.dom.Node.TEXT_NODE or element.firstChild.data.strip() != 'OK'):
          exit(datetime.now().strftime('%Y-%m-%d %H:%M:%S') + ' Error.  At least one result node indicated non-OK status.')
  else:
    exit(datetime.now().strftime('%Y-%m-%d %H:%M:%S') + ' Error.  HTTP Result: ' + str(response.status) + ' ' + response.reason)

#
# main
#

#-- Load request module


command = ''
for part in sys.argv:
  command += part + ' '
log('Running: ' + str(command))

parser = argparse.ArgumentParser(description='Process a DataPower XML Management request.')
parser.add_argument('--request',required=True)

args,unknown = parser.parse_known_args()
requestModName = args.request + '.py'

if(os.path.exists(requestModName)):
  requestMod = __import__(args.request)
else:
  exit(datetime.now().strftime('%Y-%m-%d %H:%M:%S') + ' Error.  ' + requestModName + ' does not exist')

#-- Load arguments

parser.add_argument('--host',required=True)
parser.add_argument('--port',required=True)
parser.add_argument('--username',required=True)
parser.add_argument('--password',required=True)
parser.add_argument('--domain',default='default')
parser.add_argument('--save',action='store_true')
parser.add_argument('--debug',action='store_true')

requestMod.add_arguments(parser)

args = parser.parse_args()

#-- Prepare request message

connection = httplib.HTTPSConnection(args.host,args.port)
if(args.debug):
  connection.set_debuglevel(5)
target = args.host + ':' + args.port + '/service/mgmt/current'
requestMessage = requestMod.get_request(args)
headers = { 'Content-Type': 'text/xml',
            'Authorization': 'Basic ' + base64.encodestring(args.username + ':' + args.password)
          }

#-- Process request message

log('Sending request...')
processRequest(connection,target,requestMessage,headers)

#-- Save

if(args.save):
  log('Saving...')
  saveTemplate = Template('''<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
    <soapenv:Header/>
      <soapenv:Body>
        <dp:request domain="${DOMAIN}" xmlns:dp="http://www.datapower.com/schemas/management">
          <dp:do-action>
            <SaveConfig/>
          </dp:do-action>
        </dp:request>
      </soapenv:Body>
    </soapenv:Envelope>''')
  saveMessage = saveTemplate.substitute(DOMAIN=args.domain)
  processRequest(connection,target,saveMessage,headers)
  
log('Success.')