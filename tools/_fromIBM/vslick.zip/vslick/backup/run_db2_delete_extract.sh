#!/bin/bash
auditdata_dir=/db2fs/db2auditdata
archive_dir=/db2fs/db2auditarchive
extract_dir=/db2fs/db2auditextract

ls -l ${extract_dir}

echo remove extract_target=${extract_dir}/*

rm ${extract_dir}/*
