#!/bin/sh
fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

JAVA_HOME=${WXS_HOME}/java/jre
catalogServiceEndPoints=$CATALOG_SERVICE_ENDPOINTS
gridName=DYNACACHE_REMOTE
CLASSPATH=${WORKING_DIR}:${OBJECTGRID_ROOT}/lib/objectgrid.jar:${OBJECTGRID_ROOT}/dynacache/lib/wxsdynacache.jar

echo catalogServiceEndPoints = $catalogServiceEndPoints
echo CLASSPATH = $CLASSPATH

${JAVA_HOME}/bin/java -cp $CLASSPATH com.wxs.client.WXSClientDemo $catalogServiceEndPoints $gridName
