import os
import sys
execfile('wsadminlib.py')

#import the applications config.py property file with input variables to be used into the script...

dir = os.getcwd()
fileName, fileExtension = os.path.splitext(sys.argv[0])

print "Configuration File Name: " + fileName
exec("from " + fileName + " import *")
###########################################################

def printObject(name, object ):
    """Return the config object id for the named URIGroup."""
    if object is not None:
        print name + " = " + object
    else:
        print name + " = NONE"

def printAllObjectCacheInstances(scopeobjectid):
    """print all object cache instances"""
    scope = _getObjectScope(scopeobjectid)
    print "----------------------------------"
    print "Display All Object Cache Instance.  scope = " + scope
    print "----------------------------------"
    cache_ids = _splitlines(AdminConfig.list( 'ObjectCacheInstance' ))
    for id in cache_ids:
        #print "cache id = " + id
        cacheName = AdminConfig.showAttribute( id, "name" )
        idscope = _getObjectScope(id)
        if scope == idscope:
            print "cacheName = " + cacheName
     
def printAllServletCacheInstances(scopeobjectid):
    """print all servlet cache instances"""
    scope = _getObjectScope(scopeobjectid)
    print "----------------------------------"
    print "Display All Servlet Cache Instance.  scope = " + scope
    print "----------------------------------"
    cache_ids = _splitlines(AdminConfig.list( 'ServletCacheInstance' ))
    for id in cache_ids:
        #print "cache id = " + id
        cacheName = AdminConfig.showAttribute( id, "name" )
        idscope = _getObjectScope(id)
        if scope == idscope:
            print "cacheName = " + cacheName

def printCacheProviderAtScope(scopeobjectid):
    print "----------------------------------"
    print "Display All CacheProvider for the scope of " + scopeobjectid 
    print "----------------------------------"
    scope = _getObjectScope(scopeobjectid)
    found = False
    for cacheprovider in getObjectsOfType('CacheProvider'):
        if _getObjectScope(cacheprovider) == scope:
            print "Current cacheprovider = " + cacheprovider
            cacheproviderName = AdminConfig.showAttribute(cacheprovider, "name")
            print "    cacheproviderName = " + cacheproviderName
        #else:
        #    print "    scope not matched"
        #    cacheproviderName = AdminConfig.showAttribute(cacheprovider, "name")
        #    print "    cacheproviderName = " + cacheproviderName
            
    return None


def createWXSCacheProvider ( scopeobjectid):
    name = "com.ibm.ws.objectgrid.dynacache.CacheProviderImpl"
    description = "WXS Cache Provider"
    attrs = []
    attrs.append( [ 'name', name ] )
    attrs.append( [ 'description', description ] )
    cacheProvider = create('CacheProvider', scopeobjectid, attrs, None)
    saveAndSyncAndPrintResult()
    return cacheProvider
       
#---------------------------------------------------------
#  Display cluster scope cache instances
#
#---------------------------------------------------------

enableDebugMessages()
m = "main"

printObject("clusterName", clusterName)

cluster = getClusterId(clusterName)
printObject("cluster", cluster) 

scopeobjectid = cluster

printAllObjectCacheInstances(scopeobjectid)
printAllServletCacheInstances(scopeobjectid)


