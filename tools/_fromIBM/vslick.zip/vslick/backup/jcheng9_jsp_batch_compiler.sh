#!/bin/bash
# usage: deployment manager will execute this on all the app server/nodes
BIN=/opt2/websphere/appserver/profiles/ryelxwebeqaf1/bin
WAS_HOME=/export/home/wasadmin
APP_NAME=brazil-qa
MODULE=REPSuite.war
JVM1=brazil-qaf1

$BIN/JspBatchCompiler.sh -enterpriseapp.name $APP_NAME -server.name $JVM1 -jdkSourceLevel 15 -keepgenerated false -forceCompilation true -compileToWebInf false -useJDKCompiler true -compileAfterFailure true -log.level FINEST > $WAS_HOME/JspBatchCompiler_$JVM1.log  2>&1

