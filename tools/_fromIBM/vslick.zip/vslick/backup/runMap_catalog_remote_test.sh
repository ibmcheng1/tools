#!/bin/sh

fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

echo catalogServiceEndPoints=$catalogServiceEndPoints
echo objectgridName=$objectgridName
echo mapName=$mapName

loop=1
size=100   

# 1 thread
threadLoad=100
./runDriver.sh -case001 -multiWorkerMode $threadLoad -loop $loop -size $size -catalogServiceEndPoints $catalogServiceEndPoints -objectgridName $objectgridName -mapName $mapName

# autoThreadsMode
# size=1600
# ./runDriver.sh -autoThreadsMode -maxNumberOfThreads 16 -loop $loop -size $size -catalogServiceEndPoints $catalogServiceEndPoints -objectgridName $objectgridName -mapName $mapName

# 16 threads
size=16000
threadLoad=1000
./runDriver.sh -case016 -multiWorkerMode $threadLoad -loop $loop -size $size -catalogServiceEndPoints $catalogServiceEndPoints -objectgridName $objectgridName -mapName $mapName

