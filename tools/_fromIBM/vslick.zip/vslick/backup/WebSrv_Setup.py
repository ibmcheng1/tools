import sys
import os
import time
import fnmatch,re
from java.lang import String
from java.io import FileInputStream
from java.util import Properties
from java.io import File
import shutil
import socket
import stat

runProcess=""

#import the applications config.py property file with input variables to be used into the script...

dir = os.getcwd()
print "dir: " + dir
fileName, fileExtension = os.path.splitext(sys.argv[0])

# print "File Name: " + fileName
# exec("from " + fileName + " import *")
exec("from " + fileName + " import *")


#-------------------------------------------------------------------------------------------------
# MAKE_SURE_ALL_NODE_AGENTS_ARE_RUNNING
#-------------------------------------------------------------------------------------------------
def makeSureAllNodeAgentsAreRunning():

   global validationFailureCount
   global validationWarningCount
   global indentCount

   print "-" * 50
   print "Checking the run status of node agents..."
   indentCount = indentCount + 3
   runProcess="MAKE_SURE_ALL_NODE_AGENTS_ARE_RUNNING"

   notStartedList = numberOfNodeAgentsNotStarted()

   # A return value of None is different then an empty list. 
   if (notStartedList == None):
      print " " * indentCount, "validationWarning: There are no Node Agent(s)in the cell.  An example where this is ok is if the cell only has Web Servers."
      print " " * indentCount, "validationWarning: -- Some step(s) will be skipped because they require communication with the server(s) through a Node Agent, of which there are none."
   else:
      nodeAgentPresent = "true"

   # A return value of None is different then an empty list. 
   if (notStartedList != None):
      if len(notStartedList) > 0:
         for notStarted in notStartedList: 	
            print " " * indentCount, "validationERROR: Node agent " + str(notStarted) + " is not started."
         print " " * indentCount, "validationERROR: The number of node agents not started is greater then zero"
         validationFailureCount = validationFailureCount + 1
    
   print " " * indentCount, "Checking the run status of node agents completed. "
   print "-" * 50
   print ""


#-------------------------------------------------------------------------------------------------
# MAKE_SURE_ALL_SERVERS_ARE_RUNNING
#-------------------------------------------------------------------------------------------------
def makeSureAllServersAreRunning():

   global validationFailureCount
   global validationWarningCount
   global indentCount

   print "-" * 50
   print "Checking the run status of Servers..."
   runProcess="MAKE_SURE_ALL_SERVERS_ARE_RUNNING"

   if (validationFailureCount < 1) and (nodeAgentPresent == "true"):
      notStartedList = numberOfServersNotStarted()
      if len(notStartedList) > 0:
         for notStarted in notStartedList:         
            print " " * indentCount, "validationWarning: Server " + str(notStarted) + " is not started."
         print " " * indentCount, "validationWarning: The number of Servers not started is greater then zero"
     
         validationWarningCount = validationWarningCount + 1

      print " " * indentCount, "Checking the run status of Servers completed. "
      print "-" * 50
      print ""
   else:
      print " " * indentCount, "Checking the run status of Servers skipped.   "
      print "-" * 50
      print ""



#-------------------------------------------------------------------------------------------------
# Save and Synch changes
#-------------------------------------------------------------------------------------------------
def saveAndSynchChanges():

   global validationFailureCount
   global validationWarningCount
   global indentCount

   runProcess="SAVE"
   if (validationFailureCount < 1):
      if (validationWarningCount > 0):
         print "validationWarningCount: " + str(validationWarningCount)
      print "Saving changes.."
      AdminConfig.save()
      syncAllNodes()
      print "End time... " + time.ctime(time.time())  
      print " "  
   else:
      raise ValueError, "The validationFailureCount is " + str(validationFailureCount) + ". See prior errors for more details."

#-------------------------------------------------------------------------------------------------
# LOAD_VIRTUAL_IMAGE_PROPERTIES_FILE
#-------------------------------------------------------------------------------------------------
def loadVirtualImagePropFile(cellImageList):

   global validationFailureCount
   global validationWarningCount
   global indentCount

   if (validationFailureCount < 1):
      print "-" * 50
      print "Loading virtual image properties file..."
      runProcess="LOAD_VIRTUAL_IMAGE_PROPERTIES_FILE"

      if (len(CELL_IMAGE_LIST) > 0):
         for virtualimage in cellImageList:
            print " " * indentCount, "virtualimage[VIRTUAL_IMAGE_PROPERTIES_FILE_FULL_PATH_NAME_INDEX]: " + virtualimage[VIRTUAL_IMAGE_PROPERTIES_FILE_FULL_PATH_NAME_INDEX]  
            print " " * indentCount, "os.sep: " + os.sep	
            fullPathAndFileNameOfPropertiesFile = str(virtualimage[VIRTUAL_IMAGE_PROPERTIES_FILE_FULL_PATH_NAME_INDEX])
            print "fullPathAndFileNameOfPropertiesFile: " + str(fullPathAndFileNameOfPropertiesFile)
            virtualImageProperties = loadVirtualImagePropertiesFile(fullPathAndFileNameOfPropertiesFile)
            for propName in virtualImageProperties.propertyNames():
               print " " * indentCount, "propName: " + str(propName) + "  propValue: " + str(virtualImageProperties.getProperty(propName))
      else:
         validationFailureCount = validationFailureCount + 1
         print " " * indentCount, "validationERROR: The CELL_IMAGE_LIST is empty.  Populate the list in the config file " + str(sys.argv[0]) + " and try again." 
  
      print " " * indentCount, "Loading virtual image properties file completed   "
      print "-" * 50
      print ""


#-------------------------------------------------------------------------------------------------
# LOAD_CELL_PROPERTIES_LIST
#-------------------------------------------------------------------------------------------------
def loadCellPropertiesList(cellPropertiesList):

   global validationFailureCount
   global validationWarningCount
   global indentCount

   if (validationFailureCount < 1):
      print "-" * 50
      print "Loading cell properties list..."
      runProcess="LOAD_CELL_PROPERTIES_LIST"

      if (len(cellPropertiesList) > 0):
           printCELL_PROPERTIES_LIST(CELL_PROPERTIES_LIST)
      else:
         print " " * indentCount, "The CELL_PROPERTIES_LIST is empty.  Populate the list in the config file " + str(sys.argv[0]) + " and try again." 
 
      print " " * indentCount, "Loading cell properties list completed            "
      print "-" * 50
      print ""


#-------------------------------------------------------------------------------------------------
# LOAD_WEBSERVERS_LIST
#-------------------------------------------------------------------------------------------------
def loadWebServersList(webServersList):

   global validationFailureCount
   global validationWarningCount
   global indentCount

   if (validationFailureCount < 1):
      print "-" * 50
      print "Loading webservers list..."
      runProcess="LOAD_WEBSERVERS_LIST"

      if (len(webServersList) > 0):
           printWEBSERVERS_LIST(webServersList)
      else:
           validationFailureCount = validationFailureCount + 1
           print " " * indentCount, "validationERROR: The WEBSERVERS_LIST is empty.  Populate the list in the config file " + str(sys.argv[0]) + " and try again." 
 
      print " " * indentCount, "Loading webserver list completed                  "
      print "-" * 50
      print ""


#-------------------------------------------------------------------------------------------------
# LOAD_WEB_CONTAINER_CUSTOM_PROPERTY_LIST
#-------------------------------------------------------------------------------------------------
def loadWebContainerCustomPropList(webContainerCustomerPropertyList):

   global validationFailureCount
   global validationWarningCount

   if (validationFailureCount < 1):
      print "-" * 50
      print "Loading Web Container custom properties list..."
      runProcess="LOAD_WEB_CONTAINER_CUSTOM_PROPERTY_LIST"

      if (len(webContainerCustomerPropertyList) > 0):
              printWEB_CONTAINER_CUSTOM_PROPERTY_LIST(webContainerCustomerPropertyList)
      else:
           # An empty WEB_CONTAINER_CUSTOM_PROPERTY_LIST is not considered an error. 
           validationFailureCount = validationFailureCount + 0
 
      print " " * indentCount, "Loading Web Container custom properties list completed "
      print "-" * 50
      print ""


#-------------------------------------------------------------------------------------------------
# STOPPING_IHS_WEBSERVERS_FROM_OS
#-------------------------------------------------------------------------------------------------
def stoppingIHSWebServersFromOS(cellPropertiesList):

   global validationFailureCount
   global validationWarningCount
   global indentCount

   stopCounter = 0
   if (validationFailureCount < 1):
      print "-" * 50
      print "Stopping IHS webserver on cell..."
      runProcess="STOPPING_IHS_WEBSERVERS_FROM_OS"

      WEBSERVERS_STOP_LIST = [[]]
      if (validationFailureCount < 1):
         for cell in cellPropertiesList:
            # Stop web servers in WEBSERVERS_LIST
            for webServerParmList in WEBSERVERS_LIST:
               if (cell[CELL_NAME_INDEX] == webServerParmList[WEBSERVER_PARENT_CELL_NAME_INDEX]):
                  # Don't stop on Windows.  os.system() will not return.
                  # Stop manually on Windows.
                  if (not OS_Type.upper() == "WIN"):
                     print "   Stopping IHS server " + webServerParmList[WEBSERVER_IHS_NAME_INDEX] 
                     if (os.path.isfile(webServerParmList[WEBSERVER_IHS_COPY_TO_CONTROL_FILE_FULL_PATH_INDEX])):                               
                        commandString = webServerParmList[WEBSERVER_IHS_COPY_TO_CONTROL_FILE_FULL_PATH_INDEX]
                        commandString = commandString + str(" stop")
                        # print " " * indentCount, "commandString " + str(commandString) 
                        returnCode = os.system(commandString)
                        if (returnCode == 0):
                           print " " * indentCount, "Stop of IHS server " + webServerParmList[WEBSERVER_IHS_NAME_INDEX] + str(" completed.")
                        else:
                           print " " * indentCount, "Stop of IHS server " + webServerParmList[WEBSERVER_IHS_NAME_INDEX] + str(" failed.")                                                                 
                     # else:
                        # do nothing  
                  else:      
                     print " " * indentCount, "Stop IHS server " + webServerParmList[WEBSERVER_IHS_NAME_INDEX] + " manually." 

            # Stop web servers in EXPLICITLY_DELETE_WEBSERVERS_LIST
            for explicitlyDeleteWebServerList in EXPLICITLY_DELETE_WEBSERVERS_LIST:
               if (cell[CELL_NAME_INDEX] == explicitlyDeleteWebServerList[EXPLICITLY_DELETE_FROM_CELL_NAME_INDEX]):
                  # Don't stop on Windows.  os.system() will not return.
                  # Stop manually on Windows.
                  if (not OS_Type.upper() == "WIN"):
                     print " " * indentCount, "Stoping IHS server " + explicitlyDeleteWebServerList[EXPLICITLY_DELETE_WEBSERVER_NAME_INDEX] 
                     if (os.path.isfile(explicitlyDeleteWebServerList[EXPLICITLY_DELETE_IHS_CONTROL_FILE_FULL_PATH_INDEX])):                               
                        commandString = explicitlyDeleteWebServerList[EXPLICITLY_DELETE_IHS_CONTROL_FILE_FULL_PATH_INDEX]
                        commandString = commandString + str(" stop")
                        print " " * indentCount, "commandString " + str(commandString) 
                        returnCode = os.system(commandString)
                        if (returnCode == 0):
                           print " " * indentCount, "Stop of IHS server " + explicitlyDeleteWebServerList[EXPLICITLY_DELETE_WEBSERVER_NAME_INDEX] + str(" completed.")
                           stopCounter = stopCounter + 1
                        else:
                           print " " * indentCount, "Stop of IHS server " + explicitlyDeleteWebServerList[EXPLICITLY_DELETE_WEBSERVER_NAME_INDEX] + str(" failed.")                                                                 
                     # else:
                        # do nothing  
                  else:      
                    print " " * indentCount, "Stop IHS server " + explicitlyDeleteWebServerList[EXPLICITLY_DELETE_WEBSERVER_NAME_INDEX] + " manually." 
                            
         print " " * indentCount, "Stopping of " + str(stopCounter) + " IHS webserver(s) completed. "
         print "-" * 50
         print ""


#-------------------------------------------------------------------------------------------------
# REMOVAL_OF_IHS_PROFILE(S)_DIRECTORIES
#-------------------------------------------------------------------------------------------------
def removeIHSProfileOSDirectories(cellPropertiesList, webServersList):

   global validationFailureCount
   global validationWarningCount
   global indentCount

   removalCounter = 0
   if (validationFailureCount < 1):
      print "-" * 50
      print "Removal of IBM HTTP Server profile(s) directories..."
      runProcess="REMOVAL_OF_IHS_PROFILE(S)_OS_DIRECTORIES"

      if (validationFailureCount < 1):
         for cell in cellPropertiesList:
            for webServerParmList in webServersList:
               if (cell[CELL_NAME_INDEX] == webServerParmList[WEBSERVER_PARENT_CELL_NAME_INDEX]):
                  returnValue = removeOSDirectoriesForWebserver(webServerParmList)
                  if (returnValue == None) :
                     print " " * indentCount, "Removal of all IBM HTTP Server profile(s) directories failed."
                     validationFailureCount = validationFailureCount + 1
                  else:
                     removalCounter = removalCounter + len(returnValue)
 
      print " " * indentCount, "Removal of " + str(removalCounter) + " IBM HTTP Server profile(s) directories completed."
      print "-" * 50
      print ""


#-------------------------------------------------------------------------------------------------
# CREATE_IHS_PROFILE(S)
#-------------------------------------------------------------------------------------------------
def createIHSprofilesOnOS(cellPropertiesList, webServersList):

   global validationFailureCount
   global validationWarningCount
   global indentCount

   if (validationFailureCount < 1):
      print "-" * 50
      print "Creating IBM HTTP Server profile(s)..."
      runProcess="CREATE_IHS_PROFILE(S) ON OS"

      createCounter = 0

      for cell in cellPropertiesList:
         for webServerParmList in webServersList:
            if (cell[CELL_NAME_INDEX] == webServerParmList[WEBSERVER_PARENT_CELL_NAME_INDEX]):
               createNewOSDirectoriesForWebserver(webServerParmList)
               copyFileWithStringReplacements(webServerParmList[WEBSERVER_IHS_COPY_FROM_CONFIGURATION_FILE_FULL_PATH_INDEX], webServerParmList[WEBSERVER_IHS_COPY_TO_CONFIGURATION_FILE_FULL_PATH_INDEX], WEBSERVER_CONFIG_STRING_REPLACEMENT_LIST, webServerParmList)
               copyFileWithStringReplacements(webServerParmList[WEBSERVER_IHS_COPY_FROM_CONTROL_FILE_FULL_PATH_INDEX], webServerParmList[WEBSERVER_IHS_COPY_TO_CONTROL_FILE_FULL_PATH_INDEX], WEBSERVER_CONTROL_FILE_STRING_REPLACEMENT_LIST, webServerParmList)
               # Give Owner and Group execute permission.
               performUnixchmod(webServerParmList[WEBSERVER_IHS_OS_PERMISSIONS_INDEX], webServerParmList[WEBSERVER_IHS_COPY_TO_CONTROL_FILE_FULL_PATH_INDEX])
               performUnixchmod("ug+x", webServerParmList[WEBSERVER_IHS_COPY_TO_CONTROL_FILE_FULL_PATH_INDEX])
               performUnixchown(webServerParmList[WEBSERVER_IHS_OS_USER_NAME_INDEX], webServerParmList[WEBSERVER_IHS_COPY_TO_CONTROL_FILE_FULL_PATH_INDEX])
               performUnixchgrp(webServerParmList[WEBSERVER_IHS_OS_GROUP_NAME_INDEX], webServerParmList[WEBSERVER_IHS_COPY_TO_CONTROL_FILE_FULL_PATH_INDEX])
               createCounter = createCounter + 1
                    
      print " " * indentCount, "Creation of " + str(createCounter) + " IBM HTTP Server profile(s) on the OS completed."
      print "-" * 50
      print ""


#-------------------------------------------------------------------------------------------------
# STARTING_IHS_WEBSERVERS_FROM_OS
#-------------------------------------------------------------------------------------------------
def startIHSwebServersFromOS(cellPropertiesList, webServersList):

   global validationFailureCount
   global validationWarningCount
   global indentCount

   startCounter = 0
   if (validationFailureCount < 1):
      print "-" * 50
      print "Starting IHS webserver on cell..."
      runProcess="STARTING_IHS_WEBSERVERS_FROM_OS"

      if (validationFailureCount < 1):
         for cell in cellPropertiesList:
            for webServerParmList in webServersList:
               if (cell[CELL_NAME_INDEX] == webServerParmList[WEBSERVER_PARENT_CELL_NAME_INDEX]):
                  # Don't start on Windows.  os.system() will not return.
                  # Start manually on Windows.
                  if (not OS_Type.upper() == "WIN"):
                     print " " * indentCount, "Starting IHS server " + webServerParmList[WEBSERVER_IHS_NAME_INDEX] 
                     commandString = webServerParmList[WEBSERVER_IHS_COPY_TO_CONTROL_FILE_FULL_PATH_INDEX]
                     commandString = commandString + str(" start")
                     # print " " * indentCount, "commandString " + str(commandString) 
                     returnCode = os.system(commandString)
                     if (returnCode == 0):
                        print " " * indentCount, "Start of IHS server " + webServerParmList[WEBSERVER_IHS_NAME_INDEX] + str(" completed.")
                        startCounter = startCounter + 1
                     else:
                        print " " * indentCount, "Start of IHS server " + webServerParmList[WEBSERVER_IHS_NAME_INDEX] + str(" failed.")                                                                 
                  else:      
                     print "   Start IHS server " + webServerParmList[WEBSERVER_IHS_NAME_INDEX] + " manually." 
                            
      print " " * indentCount, "Start of " + str(startCounter) + " IHS webserver(s) completed.  "
      print "-" * 50
      print ""


#-------------------------------------------------------------------------------------------------
# EXPLICITLY_DELETE_WEBSERVERS_ON_CELL
#-------------------------------------------------------------------------------------------------
def explicitlyDeleteWebServersOnCell(cellPropertiesList, explicitlyDeleteWebServersList):

   global validationFailureCount
   global validationWarningCount
   global indentCount

   if (validationFailureCount < 1):
      print "-" * 50
      print "Explicitly delete Web Servers on cell..."
      runProcess="EXPLICITLY_DELETE_WEBSERVERS_ON_CELL"

      explicitWebServerDeleteCounter = 0
      explicitWebServerFoundCounter = 0
      if (validationFailureCount < 1):
         for cell in cellPropertiesList:
            if (IsRunningOnISCHost(cell)):
               for explicitlyDeleteList in explicitlyDeleteWebServersList:
                  if (cell[CELL_NAME_INDEX] == explicitlyDeleteList[EXPLICITLY_DELETE_FROM_CELL_NAME_INDEX]):
                     nodes = AdminConfig.list( "Node" ).split(lineSeparator)
                     for node in nodes:
                        # print " " * indentCount, "node: " + str(node)
                        if (node != None ) and (node.strip() != ''):                     	
                           simpleNodeName = AdminConfig.showAttribute(node, "name" )
                           # print " " * indentCount, "simpleNodeName: " + str(simpleNodeName)
                           # WebSrv_SetupList = AdminTask.listServers('[-serverType WEB_SERVER -nodeName ' + nodeName + ' ]').split(lineSeparator) 
                           WebSrv_SetupList = AdminTask.listServers('[-serverType WEB_SERVER -nodeName ' + simpleNodeName + ' ]').split(lineSeparator) 
                           # print " " * indentCount, "len(WebSrv_SetupList):  " + str(len(WebSrv_SetupList)) 
                           # print " " * indentCount, "WebSrv_SetupList:  " + str(WebSrv_SetupList) 
                           # If there are existing web servers delete them one at a time.
                           if (len(WebSrv_SetupList) > 0):
                              for webServer in WebSrv_SetupList:
                                 if (webServer != None ) and (webServer.strip() != ''):
                                    # The method listServers() will return an array of one blank entry 
                                    # when no matches are found.
                                    webServerSimpleName = AdminConfig.showAttribute(webServer, "name" )
                                    if (webServerSimpleName.upper() ==  explicitlyDeleteList[EXPLICITLY_DELETE_WEBSERVER_NAME_INDEX].upper()):
                                       if ((webServerSimpleName.upper() ==  explicitlyDeleteList[EXPLICITLY_DELETE_FROM_NODE_NAME_INDEX].upper()) or  
                                           ("*" ==  explicitlyDeleteList[EXPLICITLY_DELETE_FROM_NODE_NAME_INDEX])):
                                           deleteIfISCWebServerExists (simpleNodeName, webServerSimpleName)
                                           explicitWebServerFoundCounter = explicitWebServerFoundCounter + 1

      print " " * indentCount, str(explicitWebServerFoundCounter) + " : of the web servers configured for explicit delete were found on cell and deleted."
      print "-" * 50
      print ""


#-------------------------------------------------------------------------------------------------
# DELETING_WEBSERVERS_ON_CELL
#-------------------------------------------------------------------------------------------------
def deleteWebServersOnCell(cellPropertiesList, webServersList):

   global validationFailureCount
   global validationWarningCount
   global indentCount

   deleteCounter = 0
   if (validationFailureCount < 1):
      print "-" * 50
      print "Deleteing webserver on cell..."
      runProcess="DELETING_WEBSERVERS_ON_CELL"

      if (validationFailureCount < 1):
         for cell in CELL_PROPERTIES_LIST:
            if (IsRunningOnISCHost(cell)):
               for webServerParmList in WEBSERVERS_LIST:
                  if (cell[CELL_NAME_INDEX] == webServerParmList[WEBSERVER_PARENT_CELL_NAME_INDEX]):
                     nodes = AdminConfig.list( "Node" ).split(lineSeparator)
                     for node in nodes:
                           if (node != None ) and (node.strip() != ''):                            	
                              simpleNodeName = AdminConfig.showAttribute(node, "name" )
                              # print " " * indentCount, "nodeName: " + str(nodeName)
                              # WebSrv_SetupList = AdminTask.listServers('[-serverType WEB_SERVER -nodeName ' + nodeName + ' ]').split(lineSeparator) 
                              WebSrv_SetupList = AdminTask.listServers('[-serverType WEB_SERVER -nodeName ' + simpleNodeName + ' ]').split(lineSeparator) 
                              # print " " * indentCount, "len(WebSrv_SetupList):  " + str(len(WebSrv_SetupList)) 
                              # print " " * indentCount, "WebSrv_SetupList:  " + str(WebSrv_SetupList) 
                              # If there are existing web servers delete them one at a time.
                              if (len(WebSrv_SetupList) > 0):
                                 for webServer in WebSrv_SetupList:
                                    if (webServer != None ) and (webServer.strip() != ''):                                      	
                                       # The method listServers() will return an array of one blank entry 
                                       # when no matches are found.
                                       serverSimpleName = AdminConfig.showAttribute(webServer, "name" )
                                       if (serverSimpleName.upper() ==  webServerParmList[WEBSERVER_IHS_NAME_INDEX].upper()):
                                          returnCount = deleteIfISCWebServerExists (simpleNodeName, serverSimpleName)
                                          deleteCounter = deleteCounter + returnCount

      print " " * indentCount, "Deleting of " + str(deleteCounter) + " pre-existing webserver(s) on cell completed."
      print "-" * 50
      print ""


#-------------------------------------------------------------------------------------------------
# CONFIGURE_WEBSERVERS_ON_CELL
#-------------------------------------------------------------------------------------------------
def configWebServersOnCell(cellPropertiesList, webServersList):

   global validationFailureCount
   global validationWarningCount
   global indentCount

   if (validationFailureCount < 1):
      print "-" * 50
      print "Configuring webserver(s) on cell..."
      runProcess="CONFIGURE_WEBSERVERS_ON_CELL"
      configureCounter = 0

      if (validationFailureCount < 1):
         for cell in cellPropertiesList:
            if (IsRunningOnISCHost(cell)):
	       for webServerParmList in webServersList:
                  regularExpressionObject = re.compile(webServerParmList[WEBSERVER_ISC_BUILD_ON_NODES_PATTERN_INDEX])
                  if (cell[CELL_NAME_INDEX] == webServerParmList[WEBSERVER_PARENT_CELL_NAME_INDEX]):
                     nodes = AdminConfig.list( "Node" ).split(lineSeparator)
                     for node in nodes:
                        if (node != None ) and (node.strip() != ''):                            	
                           simpleNodeName = AdminConfig.showAttribute(node, "name" )
                           # print " " * indentCount, "node: " + str(node)
                           # print " " * indentCount, "webServerParmList[WEBSERVER_ISC_BUILD_ON_NODES_PATTERN_INDEX]: " + str(webServerParmList[WEBSERVER_ISC_BUILD_ON_NODES_PATTERN_INDEX])
                           # print " " * indentCount, "simpleNodeName: " + str(simpleNodeName)
                           # print " " * indentCount, "regularExpressionObject: " + str(regularExpressionObject)
                           searchResult = regularExpressionObject.search(simpleNodeName) 
                           # print " " * indentCount, "searchResult: " + str(searchResult)
                           if (searchResult != None):
                              print " " * indentCount, "Node " + str(simpleNodeName) + " matches RegExp '" + str(webServerParmList[WEBSERVER_ISC_BUILD_ON_NODES_PATTERN_INDEX]) + "'.  webServer(s) will be created on this node." 
                              createISCWebServerConfig(simpleNodeName, webServerParmList)
                              configureCounter = configureCounter + 1
                           else:
                              print " " * indentCount, "Node " + str(simpleNodeName) + " does not match RegExp '" + str(webServerParmList[WEBSERVER_ISC_BUILD_ON_NODES_PATTERN_INDEX]) + "'.  No WebServer will be created on this node." 
                              

      print " " * indentCount, "Configuring of " + str(configureCounter) + " webserver on cell completed."
      print "-" * 50
      print ""


#-------------------------------------------------------------------------------------------------
# DELETING_WEBCONTAINER_PROPERTY
#-------------------------------------------------------------------------------------------------
def deleteWebContainerProp(cellPropertiesList, WebContainerCustomPropertyList):

   global validationFailureCount
   global validationWarningCount
   global indentCount

   if (validationFailureCount < 1) and (nodeAgentPresent == "true"):
      print "-" * 50
      print "Deleteing webcontainer property..."
      runProcess="DELETING_WEBCONTAINER_PROPERTY"
      deleteCounter = 0

      if (validationFailureCount < 1):
         cells = AdminConfig.list("Cell").split(lineSeparator)

         if (len(cells) > 1):
            print " " * indentCount, "validationERROR: The number of cells found through reflection is greater then one."
            validationFailureCount = validationFailureCount + 1
         
         fullCellName = cells[0]
         simpleCellName = AdminConfig.showAttribute(cells[0], "name")
      
         for webContainerCustomPropertyParms in WebContainerCustomPropertyList:
            for cell in cellPropertiesList:
               if (IsRunningOnISCHost(cell)):
                  for webContainerCustomPropertyParmList in WEB_CONTAINER_CUSTOM_PROPERTY_LIST:
                     nodeRegularExpressionObject = re.compile(webContainerCustomPropertyParms[WEB_CONTAINER_CUSTOM_PROPERTY_BUILD_ON_NODES_PATTERN_INDEX])
                     serverRegularExpressionObject = re.compile(webContainerCustomPropertyParms[WEB_CONTAINER_CUSTOM_PROPERTY_BUILD_ON_SERVERS_PATTERN_INDEX])
                     if (cell[CELL_NAME_INDEX] == webContainerCustomPropertyParmList[WEBSERVER_PARENT_CELL_NAME_INDEX]):
                        nodes = AdminConfig.list( "Node" ).split(lineSeparator)
                        for node in nodes:
                           if (node != None ) and (node.strip() != ''):                               
                              simpleNodeName = AdminConfig.showAttribute(node, "name" )

                              wwString = "type=Server,cell=" + simpleCellName + ",node=" + simpleNodeName + ",*"
                              servers = AdminControl.queryNames(wwString).split(lineSeparator)
                              for server in servers:
                                 if (server != None ) and (server.strip() != ''):                               
                                    serverConfigIds =  AdminControl.getConfigId(server).split(lineSeparator)
                                    for serverConfigId in serverConfigIds:
                                       # serverConfigId = AdminConfig.getid(server)
                                       count = deleteIfWebContainerCustomPropertyExists (serverConfigId, webContainerCustomPropertyParmList[WEB_CONTAINER_CUSTOM_PROPERTY_NAME_INDEX])
                                       if count > 0:
                                          deleteCounter = count + deleteCounter

      print " " * indentCount, "Deleting of " + str(deleteCounter) + " webcontainer properties completed.    "
      print "-" * 50
      print ""


#-------------------------------------------------------------------------------------------------
# CONFIGURE_WEB_CONTAINER_CUSTOM_PROPERTY_ON_CELL
#-------------------------------------------------------------------------------------------------
def configWebContCustomPropOnCell(cellPropertiesList, WebContainerCustomPropertyList):

   global validationFailureCount
   global validationWarningCount
   global indentCount

   if (validationFailureCount < 1) and (nodeAgentPresent == "true"):
      print "-" * 50
      print "Configuring web container custom properties on cell..."
      runProcess="CONFIGURE_WEB_CONTAINER_CUSTOM_PROPERTY_ON_CELL"
      configureCounter = 0

      cells = AdminConfig.list("Cell").split(lineSeparator)

      if (len(cells) > 1):
         print " " * indentCount, "validationERROR: The number of cells found through reflection is greater then one."
         validationFailureCount = validationFailureCount + 1
         
      fullCellName = cells[0]
      simpleCellName = AdminConfig.showAttribute(cells[0], "name")
      
      for webContainerCustomPropertyParms in WebContainerCustomPropertyList:
         for cell in cellPropertiesList:
            if (IsRunningOnISCHost(cell)):
               ## TODO double check this double for loop through WebContainerCustomPropertyList
               for webContainerCustomPropertyParmList in WebContainerCustomPropertyList:
                  nodeRegularExpressionObject = re.compile(webContainerCustomPropertyParms[WEB_CONTAINER_CUSTOM_PROPERTY_BUILD_ON_NODES_PATTERN_INDEX])
                  serverRegularExpressionObject = re.compile(webContainerCustomPropertyParms[WEB_CONTAINER_CUSTOM_PROPERTY_BUILD_ON_SERVERS_PATTERN_INDEX])
                  if (cell[CELL_NAME_INDEX] == webContainerCustomPropertyParmList[WEBSERVER_PARENT_CELL_NAME_INDEX]):
                     nodes = AdminConfig.list( "Node" ).split(lineSeparator)
                     for node in nodes:
                        if (node != None ) and (node.strip() != ''):                               
                           simpleNodeName = AdminConfig.showAttribute(node, "name" )
                           wwString = "type=Server,cell=" + simpleCellName + ",node=" + simpleNodeName + ",*"
                           servers = AdminControl.queryNames(wwString).split(lineSeparator)
                           for server in servers:
                              if (server != None ) and (server.strip() != ''):                               
                                 serverConfigId =  AdminControl.getConfigId(server)
                                 webContainers = AdminConfig.list("WebContainer", serverConfigId).split(lineSeparator)
                                 if len(webContainers) > 1:
                                    # As per the requirements, this script does not need to support more then one Web Container per server.
                                    print " " * indentCount, "validationERROR: The number of WebContainers for server " + server + " is greater then one."
                                    for webContainer in webContainers:
                                       validationFailureCount = validationFailureCount + 1
                                 
                                 serverConfigId =  AdminControl.getConfigId(server)
                                 simpleServerName = AdminConfig.showAttribute(serverConfigId, "name" )
                                 nodeSearchResult   = nodeRegularExpressionObject.search(simpleNodeName) 
                                 serverSearchResult = serverRegularExpressionObject.search(simpleServerName) 

                                 if (nodeSearchResult != None) and (serverSearchResult != None) :
                                    count = createWebContainerCustomProperty (nodeSearchResult, webContainers[0], webContainerCustomPropertyParmList[WEB_CONTAINER_CUSTOM_PROPERTY_VALIDATION_EXPRESSION_INDEX], webContainerCustomPropertyParmList[WEB_CONTAINER_CUSTOM_PROPERTY_NAME_INDEX], webContainerCustomPropertyParmList[WEB_CONTAINER_CUSTOM_PROPERTY_DESCRIPTION_INDEX], webContainerCustomPropertyParmList[WEB_CONTAINER_CUSTOM_PROPERTY_VALUE_INDEX], webContainerCustomPropertyParmList[WEB_CONTAINER_CUSTOM_PROPERTY_REQUIRED_INDEX] )
                                    # print "count: " + str(count)
                                    if count > 0:
                                       configureCounter = configureCounter + count

      print " " * indentCount, "Configuration of " + str(configureCounter) + " web container custom properties on cell completed."
      print "-" * 50
      print ""


#########################################################################
#########################################################################
### Logic Mainline                                                    ### 
#########################################################################
#########################################################################
print "WebSrv_Setup.py"

# This scripts relies on the jython script library "resource_scripts.py"
# Process the resource file containing all of the admin task definitions

dir = os.getcwd()
# The windows operating system is assumed to be a developer's workstation.
if (OS_Type.upper() == "WIN"):
   dir = dir + str("\\..\\")
indentCount = 0

# Get and load the utility script methods
resources = dir+os.sep+"resource_scripts_105.py"
execfile(resources)

validationFailureCount = 0
validationWarningCount = 0
nodeAgentPresent = "false"

print " "  
print "Start time... " + time.ctime(time.time()) 
if len(sys.argv) == 2:
   action = sys.argv[1]
else:
   raise ValueError, "Invoked without required two command line parms usage is : WebSrv_Setup.py {parmFile.py} {ISC_VM_Part|IHS_VM_Part}"

print "Action: " + str(action)

try:

   if (action.upper() == "IHS_VM_PART"):
      loadCellPropertiesList(CELL_PROPERTIES_LIST)
      loadWebServersList(WEBSERVERS_LIST)
      stoppingIHSWebServersFromOS(CELL_PROPERTIES_LIST)
      removeIHSProfileOSDirectories(CELL_PROPERTIES_LIST, WEBSERVERS_LIST)
      createIHSprofilesOnOS(CELL_PROPERTIES_LIST, WEBSERVERS_LIST)
      startIHSwebServersFromOS(CELL_PROPERTIES_LIST, WEBSERVERS_LIST)
   elif (action.upper() == "ISC_VM_PART"): 
      makeSureAllNodeAgentsAreRunning()
      makeSureAllServersAreRunning()
      loadCellPropertiesList(CELL_PROPERTIES_LIST)
      loadWebServersList(WEBSERVERS_LIST)
      loadWebContainerCustomPropList(WEB_CONTAINER_CUSTOM_PROPERTY_LIST)
      explicitlyDeleteWebServersOnCell(CELL_PROPERTIES_LIST, EXPLICITLY_DELETE_WEBSERVERS_LIST)
      deleteWebServersOnCell(CELL_PROPERTIES_LIST, WEBSERVERS_LIST)
      configWebServersOnCell(CELL_PROPERTIES_LIST, WEBSERVERS_LIST)
      deleteWebContainerProp(CELL_PROPERTIES_LIST, WEB_CONTAINER_CUSTOM_PROPERTY_LIST)
      configWebContCustomPropOnCell(CELL_PROPERTIES_LIST, WEB_CONTAINER_CUSTOM_PROPERTY_LIST)
      saveAndSynchChanges()
   else:
      raise ValueError, "action: '" + str(action) + "' is not valid. Use 'IHS_VM_PART' or 'ISC_VM_PART'"

except:
  print "WebServers_ConfigScript.py Exception: An Error occurred during the " + runProcess + " configuration, processing has been halted..."
  print "WebServers_ConfigScript.py Unexpected error: ", sys.exc_info()[0], sys.exc_info()[1]
  sys.exit(1)
  