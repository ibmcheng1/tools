#!/bin/sh
# 
# input example: WMB_SilentInstall 4 /tmp/8.0.0-WS-MB-LINUXX64-FP0004.tar.Z
#
#   WMB_FP_LEVEL=4                                -> WMB FP level 8004
#   WMB_FP_FILE=/tmp/8.0.0-WS-MB-LINUXX64-FP0004.tar.Z -> WMB 8004 FP file
#   WMB_TEMP_DIR=FP8004                           -> FP8004


# Run the profile for WebSphere Message Broker (via a symlink)
. /home/virtuser/.mqsiprofile

WMB_FP_LEVEL=$1
WMB_FP_FILE=$2
BROKER=$3
WMB_TEMP_DIR=FP800${WMB_FP_LEVEL}
MQSI_NEW_VERSION=8.0.0.${WMB_FP_LEVEL}

# Stop broker
echo "stopping ${BROKER} ..."
mqsistop "$BROKER"

echo "-----------------------------------"
echo "WMB_SilentInstall $1 $2"
echo "-----------------------------------"
echo WMB_FP_LEVEL=$WMB_FP_LEVEL
echo WMB_FP_FILE=$WMB_FP_FILE
echo WMB_TEMP_DIR=$WMB_TEMP_DIR
echo MQSI_VERSION=$MQSI_VERSION
echo MQSI_NEW_VERSION=$MQSI_NEW_VERSION
echo "-----------------------------------"

#WMB FP00X Silent installations 
#Create the Directory:
if [ ! -d /var/mqsi/${WMB_TEMP_DIR} ]
then
   mkdir /var/mqsi/${WMB_TEMP_DIR}
fi

#Download and expand FIXPACK (resides in /var/mqsi this file s/b included in the image):
cd /var/mqsi/${WMB_TEMP_DIR}; tar -xvzf ${WMB_FP_FILE}
#Issue the command to do a silent install:
/var/mqsi/${WMB_TEMP_DIR}/disk1/setuplinuxx64.bin -i silent -DLICENSE_ACCEPTED=TRUE -DExternal_License_Path="/opt/ibm/mqsi/8.0.0.1/license/8.0.0.1"
# /home/virtuser/.bash_profile contains a line;
echo "sed -i 's/${MQSI_VERSION}/${MQSI_NEW_VERSION}/g' /opt/ibm/mqsi/8.0.0.1/bin/mqsiprofile"
sed -i 's/${MQSI_VERSION}/${MQSI_NEW_VERSION}/g' /opt/ibm/mqsi/8.0.0.1/bin/mqsiprofile
echo "--------------------------"
cat /opt/ibm/mqsi/8.0.0.1/bin/mqsiprofile
echo "---------------------------"
# Run the profile for WebSphere Message Broker (via a symlink) again
# becasue the /opt/ibm/mqsi/8.0.0.1/bin/mqsiprofile has changed 
. /home/virtuser/.mqsiprofile
echo "check WMB version after apply new FP ..."
echo MQSI_VERSION=$MQSI_VERSION
echo "---------------------------"

#Enable FP capabilities
mqsichangebroker "$BROKER" -f all
echo "starting ${BROKER} ..."
mqsistart "$BROKER"
