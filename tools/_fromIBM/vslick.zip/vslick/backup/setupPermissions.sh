#!/bin/bash

chmod a+x /home/virtuser/WMB/scripts/*.sh
chmod a+x /home/virtuser/WMB/barFiles/*.sh
chmod a+r -R /home/virtuser/WMB
chmod a+x /home/virtuser/.
/home/virtuser/WMB/scripts/BRK_BUILD.sh


sed -e "s/SYSLOGSERVERIP/$SYSLOGSERVERIP/g" ${PWD}/rsyslog.conf.wmb.template > ${PWD}/rsyslog.conf

echo "FIREWALL: allowing outgoing requests to $SYSLOGSERVERIP via 514 ..."
/sbin/iptables -I OUTPUT -p udp -d $SYSLOGSERVERIP --dport 514 -j ACCEPT

echo "check iptables status ..."
/etc/init.d/iptables status

echo "enable DB2 audit fcility ..."
sudo -u db2inst1 -i ${PWD}/set_db2audit.sh $auditdata_dir $archive_dir

echo "sleep 10 seconds ... "
sleep 10

echo "extract DB2 audit files ..."
sudo -u db2inst1 -i ${PWD}/run_db2_extract.sh

echo "set crontab under db2inst1 ..."
sudo -u db2inst1 -i ${PWD}/set_crontab.sh

echo "update rsyslog.conf ..."
cp /etc/rsyslog.conf /etc/rsyslog.conf.ori.bak
cp ${PWD}/rsyslog.conf /ect/rsyslog.conf

echo "restart rsyslog service"
service rsyslog restart

echo "verify user.log content"
tail /var/log/user.log

