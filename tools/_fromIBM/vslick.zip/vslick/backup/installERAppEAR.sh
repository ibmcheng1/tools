#!/bin/ksh
. /etc/virtualimage.properties

ER_ENVIRONMENT=$1
if [ -z "$ER_ENVIRONMRNT" ]
then
   echo "ER_ENVIRONMENT value not passed in .. Will read from ENV variable"
   ER_ENVIRONMENT=$ER_ENVIRONMENT
fi

if [ -z "$WAS_USERNAME" ]
then
   WAS_USERNAME=virtuser
fi


EAR_FILE_PATH=/export/opt/deploy/${ER_ENVIRONMENT}/current/earlyresolution.ear

echo "======================================================================" 
echo "Installing ${EAR_FILE_PATH}" 
echo "======================================================================" 
su ${WAS_USERNAME} -c "${PROFILE_ROOT}/${PROFILE_NAME}/bin/wsadmin.sh -lang jython -f installERAppEAR.py ${EAR_FILE_PATH}"  
rc=$?
if [ $rc -gt 0 ] 
then 
echo "****** wsadmin.sh returned RC = ${rc} ***************  details from  ${PROFILE_ROOT}/${PROFILE_NAME}/logs/wsadmin.traceout follow:"  
cat ${PROFILE_ROOT}/${PROFILE_NAME}/logs/wsadmin.traceout 
echo "****** End of wsadmin.traceout ***************"  
exit $rc
fi


 
