#!/bin/sh
fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

"$OBJECTGRID_ROOT"/bin/xscmd.sh -cep $CATALOG_SERVICE_ENDPOINTS -c teardown -sl fgqcat0,fgqcat1 -force
