#!/bin/sh

#Get Remote shared files from the GE Web Server
#Do not confuse the "GE Web Server", in the comment above, with the web server(s) 
#this script creates, they are not the same thing.
remoteWebServer=http://$REMOTE_HOST_ADDRESS/
echo "remoteWebServer is $remoteWebServer" 

# read the Resource scripts file from remote web server

    # get Resource Script file from the server
    appResourceLocation="ipas-shared/"
    appResourceFileName="resource_scripts_105.py"
    wasRootNonProfileBinFullPath="/opt/IBM/WebSphere/AppServer/bin"
    defaultProfileFullPath="/opt/IBM/WebSphere/Profiles"
    defaultWASProfileName=AppSrv01

    url=$remoteWebServer$appResourceLocation$appResourceFileName
    echo " Get file $appResourceFileName from $url" 
    curl -f -O $url
    if [ "$?" -ne "0" ]; then
       exit 1    
    fi   
    if [ -f $appResourceFileName ];
	  then
        echo "------------------------------------------------"
        echo " Processing file $appResourceFileName"
        echo "------------------------------------------------"	      
	  else
        echo "------------------------------------------------"
        echo " Error: File $appResourceFileName not found on the web server"
        echo "------------------------------------------------"	   
        exit 1
	fi

#read the Application environment control file from remote web server

#envControlFileURL=$ENVIRONMENT_CONTROL_FILE
#Strip any directory path that may be included in the file name...
#envControlFileName=$(basename $envControlFileURL)
envControlFileName=$CONTROL_FILE_NAME

# get the Control List File from the server
url=$remoteWebServer$CONFIG_DIRECTORY_LOCATION/$envControlFileName
echo " Get file $envControlFileName from + $url "
curl -f -O $url

if [ "$?" -ne "0" ];
then
   exit 1    
fi

if [ -f $envControlFileName ];
  then
        echo "------------------------------------------------"
        echo " Processing application control file: $envControlFileName "
        echo "------------------------------------------------"	      
  else
        echo "------------------------------------------------"
        echo " Error: Control File $envControlFileName not found on the remote web server: $url "
        echo "------------------------------------------------"	   
	   exit 1
fi


while read line	   
do
  echo " Processing line $line"
  # split line with space delimiter (default with IFS) - 1st token is control file type, 2nd token is File Name
  linetokens=($line)

 # Skip any blank lines in the file
  shopt -s extglob  # use extended pattern matching
  if [ -n "${line##+([[:space:]])}" ]; then
	    echo "Processing line: $line "
    else 
         continue
  fi

  # Check for comments in file and skip...
  firstChar=${linetokens[0]:0:1}
  if [ $firstChar = "#" ]
     then
        continue
  fi

  fileAction=${linetokens[0]}
  echo "Control type is: $fileAction "
  fileURL=${linetokens[1]}
  echo "fileURL is: $fileURL "
  wsadminFullPath=${linetokens[2]}
  # strip out the directory path from the file name if it exists...	
  fileName=$(basename $fileURL)

  # export the control file name for WAS_ConfigScript.py to read the environment variables
  #export CONTROLFILENAME=$fileName
  
  echo "Running configuration setup for $fileName..."
	
  # get file from the server
  url=$remoteWebServer$fileURL
  echo " Get file from + $url"
  curl -f -O $url

  if [ "$?" -ne "0" ];
  then
    exit 1    
  fi

  if [ -f $fileName ]; 
        then
            echo "------------------------------------------------"
            echo " Calling wsadmin to configure application $fileName"
           
           
        if [ $fileAction == "ISC_VM_Part" ];
            then  
                   echo " Calling Integrated Solution Console creation and configuration script $fileName "
            ${wsadminFullPath}/wsadmin.sh -conntype JSR160RMI -port 9809 -user $WAS_USERNAME -password $WAS_PASSWORD -lang jython -f WebSrv_Setup.py $fileName $fileAction
                # Check return code from the python script...
                returnCode=$?
                if [ "$returnCode" != 0 ]; then
                   echo "ERROR: WebSrv_Setup.py operation failed.  Configuration processing halted!!!!!!"
                   exit 1
                fi
           fi

		if [ $fileAction == "IHS_VM_Part" ]; then  
     	        echo " Calling Operating System only part of the IBM HTTP Server install and configuration script for a VM $fileName "
                # If exists, clean up the default WAS profile from a prior invoke that
                # did not complete clean.
                if [[ -d ${defaultProfileFullPath}/${defaultWASProfileName} ]]; then
                   printf "WebSrv_Setup.py A prior default profile %s exists.  It will be deleted and a new instance created. \n" ${defaultWASProfileName}
                   printf "This will insure a clean %s profile. \n" ${defaultWASProfileName}
                   ${wasRootNonProfileBinFullPath}/manageprofiles.sh -delete -profileName ${defaultWASProfileName}
                   echo rm -fR ${defaultProfileFullPath}/${defaultWASProfileName}
                   rm -fR ${defaultProfileFullPath}/${defaultWASProfileName}
                   printf "WebSrv_Setup.py Default profile %s deleted. \n" ${defaultWASProfileName}
                fi
                echo ${wasRootNonProfileBinFullPath}/manageprofiles.sh -create -profileName ${defaultWASProfileName} -isDefault -profilePath  ${defaultProfileFullPath}/${defaultWASProfileName}  
                ${wasRootNonProfileBinFullPath}/manageprofiles.sh -create -profileName ${defaultWASProfileName} -isDefault -profilePath ${defaultProfileFullPath}/${defaultWASProfileName}  
                returnCode=$?
                if [ "$returnCode" != 0 ]; then
                   echo "ERROR: WebSrv_Setup.py operation failed.  Unable to create a default WAS profile."
                   # Remove the default profile so no one thinks it is usable.
                   # The default profile is unusable in a true WAS federated node
                   # (a.k.a. manager server) way do to OS permission issues.
                   ${wasRootNonProfileBinFullPath}/manageprofiles.sh -delete -profileName ${defaultWASProfileName}
                   if [ "$returnCode" == 0 ]; then
                      printf "WebSrv_Setup.py Default profile %s deleted. \n" ${defaultWASProfileName}
                      rm -fR ${defaultProfileFullPath}/${defaultWASProfileName}
                      printf "WebSrv_Setup.py Default profile %s deleted. \n" ${defaultWASProfileName}
                   fi   
                   exit 1
                fi
			    ${wsadminFullPath}/wsadmin.sh -conntype NONE -lang jython -f WebSrv_Setup.py $fileName $fileAction
                # Check return code from the python script...
                returnCode=$?
                if [ "$returnCode" != 0 ]; then
                   echo "ERROR: WebSrv_Setup.py operation failed.  Configuration processing halted!!!!!!"
                   # Remove the default profile so no one thinks it is being used.
                   ${wasRootNonProfileBinFullPath}/manageprofiles.sh -delete -profileName ${defaultWASProfileName}
                   if [ "$returnCode" == 0 ]; then
                      rm -fR ${defaultProfileFullPath}/${defaultWASProfileName}
                      printf "WebSrv_Setup.py Default profile %s deleted. \n" ${defaultWASProfileName}
                   fi   
                   exit 1
                fi
                # Remove the default profile so no one thinks it is being used.
                ${wasRootNonProfileBinFullPath}/manageprofiles.sh -delete -profileName ${defaultWASProfileName}
                if [ "$returnCode" == 0 ]; then
                   rm -fR ${defaultProfileFullPath}/${defaultWASProfileName}
                   printf "WebSrv_Setup.py Default profile %s deleted. \n" ${defaultWASProfileName}
                fi   
           fi

		echo "------------------------------------------------"
	    	if [ $fileAction == "SETENV" ]; then
			echo " Calling the application Setup environment files script...."
			echo "add...script here...."
		fi
		echo "------------------------------------------------"
	else
           echo "------------------------------------------------"
           echo " Error: WAS Control file does not exist at: $url"
           echo "------------------------------------------------"
           exit 1
  fi 
  
done < $envControlFileName

echo "finished....."  

