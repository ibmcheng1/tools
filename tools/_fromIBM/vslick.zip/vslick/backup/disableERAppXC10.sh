#!/bin/ksh

./runWsadmin.sh enableERAppXC10.py ER_config.py


