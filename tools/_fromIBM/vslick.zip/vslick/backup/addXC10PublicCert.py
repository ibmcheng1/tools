import os
from java.lang import System
from java.lang import Exception as JavaException

SCRIPT_VERSION='9/21/2011'
alias = '\"ibm websphere datapower xc10\"'
saveNeeded = 0
errors = 0

def convertToList(inlist):
     outlist=[]
     if (len(inlist)>0 and inlist[0]=='[' and inlist[len(inlist)-1]==']'):
        inlist = inlist[1:len(inlist)-1]
        clist = inlist.split("\"")
     else:
        clist = inlist.split("\n")
     for elem in clist:
        elem=elem.rstrip();
        if (len(elem)>0):
           outlist.append(elem)
     return outlist

def addXC10PublicCert(printPrefix, pathToCert, cellName, nodeName, force):
     #print 'addXC10PublicCert('+printPrefix+','+pathToCert+','+cellName+','+nodeName+','+str(force)+')'
     keyStoreScope = '(cell):'+cellName
     keyStoreName = 'CellDefaultTrustStore'
     if (len(nodeName)>0):
          keyStoreName = 'NodeDefaultTrustStore'
          keyStoreScope = keyStoreScope+':(node):'+nodeName
        
     # Check if the alias is present already - if so, skip unless force is true
     try:
          #print 'keystore name is: '+keyStoreName+'. alias is: '+alias+'. keystore scope is: '+keyStoreScope
          AdminTask.getSignerCertificate('[-keyStoreName '+keyStoreName+' -certificateAlias '+alias+' -keyStoreScope '+keyStoreScope+']')
          if (force):
               print printPrefix+'XC10 public certificate found in '+keyStoreName+' '+keyStoreScope+' forcing removal ...'
               success = removeXC10PublicCert(printPrefix, cellName, nodeName)
               if (success > -1):
                    AdminTask.addSignerCertificate('[-certificateAlias '+alias+' -certificateFilePath \"'+pathToCert+'\" -keyStoreScope '+keyStoreScope+' -keyStoreName '+keyStoreName+' ]')
                    print printPrefix+'Added XC10 public certificate into '+keyStoreName+' '+keyStoreScope
                    global saveNeeded 
                    saveNeeded = 1
               else:
                    print printPrefix+'FAILURE: Could not remove the XC10 public certificate in keystore '+keyStoreName+' '+keyStoreScope+'.'
                    print printPrefix+'         Try to manually remove certificate then re-run: AdminTask.deleteSignerCertificate(\'[-keyStoreName '+keyStoreName+' -certificateAlias '+alias+' -keyStoreScope '+keyStoreScope+']\')'
                    global errors
                    errors = errors + 1
                    return
          else:
               print printPrefix+'XC10 public certificate found in '+keyStoreName+' '+keyStoreScope+' will not re-add.'
               return
     except JavaException, e:
          msg = str(e)
          msg.rstrip()
          msg =  msg[0:len(msg)-1]
          # Exception is thrown if the certificate is not present
          if (msg.find('does not exist') > -1):
               # certificate not already in truststore, so add it
               try:
                    AdminTask.addSignerCertificate('[-certificateAlias '+alias+' -certificateFilePath \"'+pathToCert+'\" -keyStoreScope '+keyStoreScope+' -keyStoreName '+keyStoreName+' ]')
                    global saveNeeded 
                    saveNeeded = 1
                    print printPrefix+'Added XC10 public certificate into '+keyStoreName+' '+keyStoreScope
                    return
               except JavaException,e2:
                    msg = str(e2)
                    msg.rstrip()
                    msg =  msg[0:len(msg)-1]
                    print printPrefix+'FAILURE: Could not add XC10 public certificate into keystore '+keyStoreName+' '+keyStoreScope+'.'
                    print printPrefix+'         Due to exception: '+msg
                    print printPrefix+'         Please manually add in the public signer certificate: '
                    print printPrefix+'         AdminTask.addSignerCertificate(\'[-certificateAlias '+alias+' -certificateFilePath '+pathToCert+' -keyStoreScope '+keyStoreScope+' -keyStoreName '+keyStoreName+' ]\')'
                    global errors
                    errors = errors + 1
          else:
               print printPrefix+'Unknown error: '+msg
               global errors
               errors = errors + 1

def removeXC10PublicCert(printPrefix, cellName, nodeName):
     try:
          keyStoreScope = '(cell):'+cellName
          keyStoreName = 'CellDefaultTrustStore'
          if (len(nodeName)>0):
               keyStoreName = 'NodeDefaultTrustStore'
               keyStoreScope = keyStoreScope+':(node):'+nodeName

          AdminTask.deleteSignerCertificate('[-keyStoreName '+keyStoreName+' -certificateAlias '+alias+' -keyStoreScope '+keyStoreScope+']')
          global saveNeeded 
          saveNeeded = 1
          print printPrefix+'Removed XC10 public certificate from '+keyStoreName+' '+keyStoreScope
          return 0
     except JavaException, e:
          msg = str(e)
          msg.rstrip()
          msg =  msg[0:len(msg)-1]
          # Exception is thrown if the certificate is not present
          if (msg.find('does not exist') > -1):
               print printPrefix+'XC10 Public certificate does not exist in keystore '+keyStoreName+' '+keyStoreScope+'. Nothing to remove.'
               print printPrefix+'        '+msg
               return 0
          else: 
               print printPrefix+'FAILURE: An exception occurred during the removal of the XC10 public certificate in keystore '+keyStoreName+' '+keyStoreScope+': '+msg
               global errors
               errors = errors + 1
               return -1

## 'Given an AdminConfig server object, return a dictionary of its name/value components.'
def ConfigIdAsDict( configID ) :
  funName = 'ConfigIdAsDict'           # Name of this function
  result  = {}                         # Result is a dictionary
  hier    = []                         # Initialize to simplifiy checks
  try :                                # Be prepared for an error
    import sys, re                     # Is sys.exc_info() available?
    #-----------------------------------------------------------------
    # Does the specified configID match our RegExp pattern?
    # Note: mo == Match Object, if mo != None, a match was found
    #-----------------------------------------------------------------
    mo = re.compile( r'^(\w+)\(([^|]+)\|[^)]+\)$' ).match( configID )
    if mo :
      Name = mo.group( 1 )
      hier = mo.group( 2 ).split( '/' )
    if mo and ( len( hier ) % 2 == 0 ) :
      #---------------------------------------------------------------
      # hier == Extracted config hierarchy string
      #---------------------------------------------------------------
      for i in range( 0, len( hier ), 2 ) :
        ( name, value ) = hier[ i ], hier[ i + 1 ]
        result[ name ] = value
      if result.has_key( 'Name' ) :
        print '''%s: Unexpected situation - "Name" attribute conflict,
  Name = "%s", Name prefix ignored: "%s"''' % ( funName, result[ 'Name' ], Name )
      else :
        result[ 'Name' ] = Name
    else :
      print '''%(funName)s:
  Warning: The specified configID doesn\'t match the expected pattern,
           and is ignored.
  configID: "%(configID)s"''' % locals()
  except :
    ( kind, value ) = sys.exc_info()[ :2 ]
    print '''%(funName)s: Unexpected exception.\n
  Exception  type: %(kind)s
  Exception value: %(value)s''' % locals()
  return result
  
# detect whether the topology has a deployment manager (ND WAS) or not (BASE WAS)
# returns 0 if false, 1 if true
def isNDEnvironment():
  for server in AdminConfig.list( 'Server' ).splitlines() :
    sDict = ConfigIdAsDict( server )
    server = sDict[ 'servers' ]
    node = sDict[ 'nodes' ]
    parms = '[-serverName %s -nodeName %s]' % ( server, node )
    sType = AdminTask.getServerType( parms )    
    #print '%10s : %21s : %s' % ( server, node, sType )  
    if (sType == 'DEPLOYMENT_MANAGER'):
      return 1
  return 1
  
# return the deployment manager node name from the topology, return "" is none found
def getDMgrNode():
  for server in AdminConfig.list( 'Server' ).splitlines() :
    sDict = ConfigIdAsDict( server )
    server = sDict[ 'servers' ]
    node = sDict[ 'nodes' ]
    parms = '[-serverName %s -nodeName %s]' % ( server, node )
    sType = AdminTask.getServerType( parms )    
    #print '%10s : %21s : %s' % ( server, node, sType )  
    if (sType == 'DEPLOYMENT_MANAGER'):
      return node
  return ""
      
               
#
# Start off main() program
#

print "############################################################"
print "## Add XC10 Public Certificate into all default truststores"
print "## Version:  "+SCRIPT_VERSION
print "############################################################"
print ""

force = 0
remove = 0
was_home = System.getenv("WAS_HOME")
print "WAS_HOME environment variable is: " + was_home
pathToCertificate = was_home + os.sep + 'properties' + os.sep + 'xc10public.key'

if (len(sys.argv)>0):
   for arg in range(len(sys.argv)):
       if (sys.argv[arg] == '-force'):
            force = 1
       elif (sys.argv[arg] == '-certPath'):
          arg = arg+1
          pathToCertificate = sys.argv[arg]
       elif (sys.argv[arg] == '-remove'):
          remove = 1

print 'Path to XC10 Public Certificate: '+pathToCertificate
print 'Force XC10 Public Certificate add into TrustStores?: '+str(force)
print 'Remove existing XC10 Public Certificate from all default TrustStores?: '+str(remove)
print ''
print 'Starting XC10 public certificate operations...'
print ''

# Find the cell name
cellId = AdminConfig.getid("/Cell:/")
cellName = cellId.split("(")[0]

# Add to the cell wide truststore
print 'Processing default truststore for cell '+cellName
printPrefix='     '

# Add to each node's truststore
nodes = convertToList(AdminTask.listNodes())
print ''
print 'Detected nodes: '+str(nodes)

# if this is an ND environment, then we modify the default trust store that is at the 
# cell level (we will modify the node level ones later)
# otherwise we skip cell level, as none would be there in Base WAS case (standalone)
if (isNDEnvironment() == 1):
  if (remove == 0):
    addXC10PublicCert(printPrefix, pathToCertificate,cellName, "", force)
  else:
    removeXC10PublicCert(printPrefix, cellName, "")

# get the name of the dmgr node (isn't necessarily "dmgr")
dmgrNode = getDMgrNode()

# if found, remove from list of nodes to process
if(dmgrNode != ""):          
    nodes.remove(dmgrNode)
print ''

# adding/removing signer cert to/from truststore at the node level for every known node in 
# the topology
for node in nodes:
  print 'Processing node '+node+'...'
  if (remove == 0):
    addXC10PublicCert(printPrefix, pathToCertificate, cellName, node, force)
  else:
    removeXC10PublicCert(printPrefix, cellName, node)
  print ''
print 'Completed XC10 public certificate operations.'

if (saveNeeded > 0 and errors == 0):
     print 'Saving configuration changes...'
     AdminConfig.save()
     print 'Configuration saved.'     
     count = -1;

     for node in nodes:
          count = count + 1
          try:
            Sync1 = AdminControl.completeObjectName('type=NodeSync,node='+node+',*')
            if (len(Sync1)>0):
                 if(count == 0):                    
                      print 'Syncing all nodes ... '               
                 success = AdminControl.invoke(Sync1, 'sync')
                 if (success == 'true'):
                      print '     Node '+node+' successfully synced'
                 else:
                      print '     FAILURE: Node '+node+' sync failed.  Please manually sync node.' 
            else:
                 print '     This is either a Base application server environment, or, if ND, the node agent for node '+node+' is stopped (could not locate NodeSync MBean). If ND, please manually sync node.'

          except JavaException,e:
               msg = str(e)
               print '     FAILURE: Node '+node+' sync failed due to exception.  Please manually sync node. Exception: '+msg 
          
     
     print 'Finished attempting to sync all nodes.'
     print ''
     print 'All WebSphere ND processes that communicate with XC10 appliances, including Deployment Manager, must be restarted to recognize new certificates.'
elif (saveNeeded > 0 and errors > 0):
     print 'Failures experienced during truststore editing, will not save pending changes.'
else:
     print 'No changes were successfully made, skipping configuration save.'     
