#!/bin/ksh
#
# synchronize the deploy directory for an environment
# from apps1a to the other servers.
#
# NOTE: apps1a is considered the master, other servers
# will have files added/removed/changed in order to make
# them match apps1a
#
umask 027
ENV=$1

if [ -z "$ENV" ]
then
  echo "Missing environment argument"
  echo "Usage: sync environment"
  exit 1
fi

if [ ! "`hostname`" == "cscertstcdc074.cdc-dc1.cscehub.com" ]
then
  echo "This script can only be run from Dmanager cscertstcdc074.cdc-dc1.cscehub.com"
  exit 1
fi

RSYNC=/usr/bin/rsync
SSH=/usr/bin/ssh
DIR=/export/opt/deploy/$ENV
DIRS="static"
HOSTS="20.176.240.71 20.176.240.108 20.176.240.9"
#HOSTS="20.176.240.71"

if [ ! -d "$DIR" ]
then
  echo "Invalid environment specified. $DIR is not a valid directory."
  exit 1
fi

if [ ! -O "$DIR/current" ]
then
  echo "Only the owner of $DIR can sync it"
  #exit 1
fi

for d in $DIRS
do
  if [ ! -d "$DIR/current/$d" ]
  then
    echo "Current $ENV deploy dir must have $d directory expanded"
    exit 1
  fi
done

for host in $HOSTS
do
  d=$DIR
  s=$DIR/current/static
  echo "Syncing $ENV $d to $host..."
  # according to rsync man page, ssh prefers blocking io
  $RSYNC -a -v --delete --rsh=$SSH --blocking-io --exclude=.ssh/ $d/ $host:$d
  if [ $? -ne 0 ]
  then
    echo "**ERROR** Error syncing $d to $host"
    exit 2
  fi
  echo "OK $d"
done

d=$DIR
host=20.176.240.9
$RSYNC -a -v --delete --rsh=$SSH --blocking-io --exclude=.ssh/ --include="*/static/*" $d/ $host:$d
if [ $? -ne 0 ]
then
  echo "**ERROR** Error syncing $d to $host"
  exit 2
fi
echo "OK $d"

exit 0
