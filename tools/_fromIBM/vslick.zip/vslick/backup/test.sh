#!/bin/sh
# This script is intended to work on Linux with bash shell or AIX with ksh.
# Be sure to set the first line of the script appriately for the platform where
# it will be run.
#
#########################################################################
echo ======================================
echo mainScript ...
echo ======================================
# When debugging on IPAS, source the virtualimage.properties
if [ -f /etc/virtualimage.properties ]; then
  . /etc/virtualimage.properties
fi

export VM_IS_IP6
export PUBLIC_NETWORK_NIC
export PUBLIC_NETWORK_IS_IPV6
export PRIVATE_NETWORK_NIC
export PRIVATE_NETWORK_IS_IPV6

WORKING_DIR=`pwd`

export WORKING_DIR
export NFS_SERVER_HOST
export NFS_MOUNT
export LOCAL_MOUNT
export MQSI_BROKER_NAME

echo WORKING_DIR=$WORKING_DIR
echo NFS_SERVER_HOST=$NFS_SERVER_HOST
echo NFS_MOUNT=$NFS_MOUNT
echo LOCAL_MOUNT=$LOCAL_MOUNT
echo MQSI_BROKER_NAME=$MQSI_BROKER_NAME

chmod a+x ${WORKING_DIR}/scripts/*.sh

if [ ! -d $LOCAL_MOUNT ]
then
   # Connect to nfs
   /0config/nodepkgs/common/scripts/firewall.sh open tcpout -network public -dest ${NFS_SERVER_HOST} -dport 2049
   mkdir $LOCAL_MOUNT
   mount ${NFS_SERVER_HOST}:${NFS_MOUNT} $LOCAL_MOUNT
fi

echo "ls -l ${LOCAL_MOUNT}"
ls -l $LOCAL_MOUNT

echo "--------------------------"
echo "Stopping Broker $MQSI_BROKER_NAME ..."
echo "--------------------------"

${WORKING_DIR}/scripts/stopBroker.sh $MQSI_BROKER_NAME
sleep 3

echo "---------------------------"
echo "installing applicable and required interim fixes ..."
echo "---------------------------"

INTERIM_FIX_DIRECTORY=/nfs/purescripts/wmb/fix/8.0.0.x-WS-MB-LinuxX64-LAIC99332
INSTALL_SCRIPT=install_8.0.0.x-WS-MB-LinuxX64-LAIC99332.sh
echo "1 -> ${INTERIM_FIX_DIRECTORY} => ${INSTALL_SCRIPT}"
cp -r $INTERIM_FIX_DIRECTORY/* $WORKING_DIR
chmod a+x ${WORKING_DIR}/*.sh
${WORKING_DIR}/${INSTALL_SCRIPT}

# continue with other interim fix directories


echo "--------------------------"
echo "Starting Broker $MQSI_BROKER_NAME ..."
echo "--------------------------"

${WORKING_DIR}/scripts/startBroker.sh $MQSI_BROKER_NAME

echo "---------------------------"
echo "ps -ef | grep mqsi*"
echo "---------------------------"
sleep 5
ps -ef | grep mqsi*
