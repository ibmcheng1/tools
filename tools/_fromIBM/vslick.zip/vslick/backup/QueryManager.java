// IBM Confidential OCO Source Material
// 5724-J34 (C) COPYRIGHT International Business Machines Corp. 2006
// The source code for this program is not published or otherwise divested
// of its trade secrets, irrespective of what has been deposited with the
// U.S. Copyright Office.
//
// $Id$
//
// Module  :  QueryManager.java
//
// Source File Description: Reference JavaDoc
//
// Change Activity:
//
// Reason       Version   Date         Userid    Change Description
// ------------ --------- ------------ --------- -----------------------------------------
// b834         6.1       04/26/2006   cdjohnson new part
// b998         6.1       05/22/2006   cdjohnson updated queryengine package names
// b1162        XD 6.1    08/03/2006   jian.tang Object query feature updates for M4
// b2399        WASX.XD   10/24/2006   jian.tang Object/Entity query client server support
// b3536        6.1       01/19/2007   cdjohnson Remove use of deprecated QueryEngine methods.
// b5747        XD6.1     02/17/2007   cdjohnson Add statement cache
// ------------ --------- ------------ --------- -----------------------------------------
package com.ibm.ws.objectgrid.query;

import java.util.Collection;

import com.ibm.ejs.ras.Tr;
import com.ibm.ejs.ras.TraceComponent;
import com.ibm.queryengine.ObjectGridQueryFactory;
import com.ibm.websphere.objectgrid.ObjectGridRuntimeException;
import com.ibm.ws.objectgrid.Constants;
import com.ibm.ws.objectgrid.ObjectGridManagerImpl;
import com.ibm.ws.objectgrid.SessionImpl;

/**
 * There is one QueryManager per ObjectGrid. Each QueryManager is a Query and QueryStatement factory and is
 * to be extended to allow creating Object and EntityManager queries.<p>
 *
 * Relevant Class Heirarchy:
 * QueryManager -> BaseQueryStatement -> BaseQuery -> ObjectMap (result)<p>
 *
 * Object Query and EntityManager Query have different implementatsions of each of the above classes.
 */
public abstract class QueryManager {
    private static final String CLASS_NAME = QueryManager.class.getName();

    private final static TraceComponent tc = Tr.register(CLASS_NAME, Constants.TR_GROUP_NAME,
            Constants.TR_RESOURCE_BUNDLE_NAME);

    /**
     * Map of QL strings to the ObjectQueryStatement
     */
    private StatementCache statementCache;

    /**
     * The main QueryEngine interface for creating ObjectGridQuery objects
     */
    protected ObjectGridQueryFactory ogQueryFactory;

    /** The parent QueryManager (if any) * */
    protected QueryManager parent;

    /**
     * Create a QueryManager with a thread-safe, statement cache.
     */
    protected QueryManager() {
        this(new StatementCache(500, null, null));
    }

    /**
     * Create a QueryManager with the specified statement cache.
     * @param cache
     */
    protected QueryManager(StatementCache cache) {
        super();
        this.statementCache = cache;
    }

    /**
     * Retrieve a BaseQueryStatement from the cache or create one if not created.  This method will not
     * cache the newly created statement.
     *
     * QueryManagers can have a parent/child relationship.  The child cache is always checked before the parent.
     */
    public BaseQueryStatement getQueryStatement(String queryString) {
        return statementCache.get(queryString);
    }

    /**
     * Factory for BaseQueryStatments
     */
    protected abstract BaseQueryStatement createQueryStatement(SessionImpl session, String queryString, String queryName);

    /**
     * Cache the EntityQueryStatement in this EntityQueryManager instance and set the QueryManager reference on the
     * statement to this QueryManager.
     */
    public void cacheQueryStatement(BaseQueryStatement stmt) {
//        String queryString = stmt.qlString;
        final boolean debugEnabled = ObjectGridManagerImpl.isTraceEnabled && tc.isDebugEnabled();
//        synchronized (statementCache) {
//            // Verify that it wasn't just added to our cache.
//            BaseQueryStatement oldStatement = statementCache.get(queryString);
//            if (oldStatement == null) {
                statementCache.put(stmt);
//
                if (debugEnabled) {
                    Tr.debug(tc, "Statement cached: " + stmt);
                }
//            } else if (oldStatement.queryMgr != this) {
//                if (debugEnabled) {
//                    Tr.debug(tc, "Statement exists in cache but has a different QueryManager!", new Object[] {
//                            "OLD Statement: " + oldStatement, "New Statement: " + stmt,
//                            new ObjectGridRuntimeException() });
//                }
//            }
//        }
    }

    public void removeCachedQueryStatement(BaseQueryStatement stmt) {
        if (ObjectGridManagerImpl.isTraceEnabled && tc.isDebugEnabled()) {
            Tr.debug(tc, "Statement remove: " + stmt);
        }
        statementCache.remove(stmt);
    }

    protected StatementCache getStatementCache() {
        return statementCache;
    }

    protected void setStatementCache(StatementCache cache) {
        this.statementCache = cache;
    }

    /**
     * Destroy this QueryManager instance and release all of its resources. Once destroyed, this QueryManager must not
     * be used anymore.
     */
    public void destroy() {
        statementCache.clear();
    }

    protected Collection getStatements() {
        return statementCache.statements();
    }

    /**
     * @return the ogQueryFactory
     */
    public ObjectGridQueryFactory getOgQueryFactory() {
        return ogQueryFactory;
    }

    /**
     * @param ogQueryFactory the ogQueryFactory to set
     */
    public void setOgQueryFactory(ObjectGridQueryFactory ogQueryFactory) {
        this.ogQueryFactory = ogQueryFactory;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getName()).append('@').append(Integer.toHexString(hashCode())).append(": ").append(
                "Scope=").append(parent == null ? "Non-Transactional" : "Transactional").append(", Cache Size=")
                .append(statementCache.size());
        return sb.toString();
    }

    protected static final String EOL = System.getProperty("line.separator");

    public String dumpCache() {
        StringBuffer sb = new StringBuffer();
        sb.append("QueryManager dump: ").append(toString()).append(EOL)
        .append("StatementCache:").append(EOL)
        .append(statementCache.dumpCache("  "));
        return sb.toString();
    }
}
