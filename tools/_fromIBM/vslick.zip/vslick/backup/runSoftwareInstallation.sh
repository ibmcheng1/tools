#!/bin/sh
echo ======================================
echo running runInstallSoftware.sh
echo ======================================

echo "------------------------------------------"
echo ENV_CONFIG_FILE=$ENV_CONFIG_FILE
echo "------------------------------------------"
if [ -f $ENV_CONFIG_FILE ]; then
  . $ENV_CONFIG_FILE
else
  echo "ERROR: ENV_CONFIG_FILE=${ENV_CONFIG_FILE} is not found"
  exit 1
fi

echo SOFTWARE_REPOSITORY=$SOFTWARE_REPOSITORY
echo IBMIM_installationDirectory=$IBMIM_installationDirectory
echo IBMIM_sharedResourcesDirectory=$IBMIM_sharedResourcesDirectory
echo WAS_installationDirectory=$WAS_installationDirectory

echo WAS_JAVA7_packageID=$WAS_JAVA7_packageID
echo WAS_JAVA7_version=$WAS_JAVA7_version
echo WAS_JAVA7_packageID_version=$WAS_JAVA7_packageID_version
echo WAS_JAVA7_features=$WAS_JAVA7_features
echo WAS_JAVA7_packageID_features=$WAS_JAVA7_packageID_features
echo WAS_JAVA7_repositories=$WAS_JAVA7_repositories
echo "------------------------------------------"

INSTALLATION_DIRECTORY=$WAS_installationDirectory
PACKAGEID=$WAS_JAVA7_packageID
VERSION=$WAS_JAVA7_version
PACKAGEID_VERSION=$WAS_JAVA7_packageID_version
FEATURES=$WAS_JAVA7_features
PACKAGEID_FEATURES=$WAS_JAVA7_packageID_features
REPOSITORIES=$WAS_JAVA7_repositories
IFIX_PACKAGEID=$WAS_JAVA7_IFIX_SOFTWARE_PACKAGE
IFIX_REPOSITORIES=$WAS_JAVA7_IFIX_SOFTWARE_PATH

echo INSTALLATION_DIRECTORY=$INSTALLATION_DIRECTORY
echo PACKAGEID=$PACKAGEID
echo VERSION=$VERSION
echo PACKAGEID_VERSION=$PACKAGEID_VERSION
echo FEATURES=$FEATURES
echo PACKAGEID_FEATURES=$PACKAGEID_FEATURES
echo REPOSITORIES=$REPOSITORIES
echo IFIX_PACKAGEID=$IFIX_PACKAGEID
echo IFIX_REPOSITORIES=$IFIX_REPOSITORIES

if [ ! -d $IBMIM_installationDirectory ]; then
   echo "Error: $IBMIM_installationDirectory does not exist."
   exit 1
fi

cd ${IBMIM_installationDirectory}/eclipse/tools

echo "------------------------------------------"
echo installing packageID : $WAS_packageID
echo "------------------------------------------"
./imcl install $PACKAGEID_FEATURES -repositories $REPOSITORIES -installationDirectory $INSTALLATION_DIRECTORY -sharedResourcesDirectory $IBMIM_sharedResourcesDirectory -acceptLicense -showProgress
     
echo "------------------------------------------"
echo installing applicable interim fix : $IFIX_PACKAGEID
echo "------------------------------------------"

if [ -z "$IFIX_PACKAGEID" ]; then
   echo "IFIX_PACKAGEID is unset. Skip installing IFIX."
else
   if [ -n "$IFIX_PACKAGEID" ]; then
      echo "installing $IFIX_PACKAGEID"
      # To check for non-null/non-zero string variable, i.e. if set
      ./imcl install $IFIX_PACKAGEID -repositories $IFIX_REPOSITORIES -installationDirectory $INSTALLATION_DIRECTORY -showProgress 
   else
      echo "IFIX_PACKAGEID is empty string. Skip installing IFIX."
   fi
fi

echo ======================================
echo end of installWASJava7.sh
echo ======================================
