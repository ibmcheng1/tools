#!/bin/bash

archive_dir=/db2fs/db2auditarchive
extract_dir=/db2fs/db2auditextract

echo archive_dir=$archive_dir
echo extract_dir=$extract_dir

set +x

export PATH=${PATH}:/db2home/db2inst1/sqllib/bin:/db2home/db2inst1/sqllib/adm:/db2home/db2inst1/sqllib/misc:/db2home/db2inst1/bin

echo "db2audit flush ..."
db2audit flush

echo "db2audit archive ..."
db2audit archive
db2audit archive database TCHDB
db2audit archive database AUDITDB
db2audit archive database ERRORDB

echo "db2audit extract ..."
db2audit extract delasc to $extract_dir from files ${archive_dir}/*

echo "ls -l $archive_dir ..."
ls -l $archive_dir
echo "rm ${archive_dir}/* ..."
rm ${archive_dir}/*
echo "ls -l ${archive_dir} ..."
ls -l ${archive_dir}
