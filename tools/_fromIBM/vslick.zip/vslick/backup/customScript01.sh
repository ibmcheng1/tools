#!/bin/ksh

echo ======================================
echo running customScript01.sh
echo ======================================

echo PARAMETER_1=$PARAMETER_1 
echo PARAMETER_2=$PARAMETER_2 
echo PARAMETER_3=$PARAMETER_3

 
echo ======================================
echo end of customScript01.sh
echo ======================================
