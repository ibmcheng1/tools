import os
import sys
execfile('wsadminlib.py')

#import the applications config.py property file with input variables to be used into the script...

dir = os.getcwd()
fileName, fileExtension = os.path.splitext(sys.argv[0])

print "Configuration File Name: " + fileName
exec("from " + fileName + " import *")

print "---------------------------------------------"
print "Creating Data Replication Domain and Data Replication"
print "---------------------------------------------"
#dataReplicationDomainName = "Dynacache"
print "dataReplicationDomainName = "+dataReplicationDomainName
cellId = getCellId(None)
drDomainId = AdminConfig.create('DataReplicationDomain', cellId, '[[name "'+dataReplicationDomainName+'"]]')
print "drDomainId = " + drDomainId
drId = AdminConfig.create('DataReplication', drDomainId, '[[requestTimeout 5] [numberOfReplicas -1] [encryptionType NONE]]') 
print "drId       = " + drId

saveAndSyncAndPrintResult()


