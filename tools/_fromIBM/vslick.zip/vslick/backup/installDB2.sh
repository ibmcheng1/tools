#!/bin/sh
echo ======================================
echo running installDB2.sh
echo ======================================

echo "------------------------------------------"
echo ENV_CONFIG_FILE=$ENV_CONFIG_FILE
echo "------------------------------------------"
if [ -f $ENV_CONFIG_FILE ]; then
  . $ENV_CONFIG_FILE
else
  echo "ERROR: ENV_CONFIG_FILE=${ENV_CONFIG_FILE} is not found"
  exit 1
fi

echo DB2_SOFTWARE_PACKAGE=$DB2_SOFTWARE_PACKAGE
echo DB2_SOFTWARE_PATH=$DB2_SOFTWARE_PATH
echo DB2_installationDirectory=$DB2_installationDirectory

DB2_INSTALL_COMMAND=${DB2_SOFTWARE_PATH}/db2_install
echo DB2_INSTALL_COMMAND=$DB2_INSTALL_COMMAND

if [ ! -f $DB2_INSTALL_COMMAND ]; then
   echo "Error: $DB2_INSTALL_COMMAND does not exist."
   exit 1
fi

echo list $DB2_SOFTWARE_PATH ...
ls $DB2_SOFTWARE_PATH

echo ----------------------------------------
echo installing DB2 from ${DB2_SOFTWARE_PATH}
echo ----------------------------------------

$DB2_INSTALL_COMMAND -n -p ESE -b $DB2_installationDirectory
{DB2_installationDirectory}/install/db2ls

echo ======================================
echo end of installDB2.sh
echo ======================================
