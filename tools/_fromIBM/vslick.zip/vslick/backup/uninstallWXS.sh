#!/bin/sh
echo ======================================
echo running installWXS.sh
echo ======================================

echo "------------------------------------------"
echo ENV_CONFIG_FILE=$ENV_CONFIG_FILE
echo "------------------------------------------"
if [ -f $ENV_CONFIG_FILE ]; then
  . $ENV_CONFIG_FILE
else
  echo "ERROR: ENV_CONFIG_FILE=${ENV_CONFIG_FILE} is not found"
  exit 1
fi

echo SOFTWARE_REPOSITORY=$SOFTWARE_REPOSITORY
echo IBMIM_installationDirectory=$IBMIM_installationDirectory
echo IBMIM_sharedResourcesDirectory=$IBMIM_sharedResourcesDirectory
echo WXS_installationDirectory=$WXS_installationDirectory
echo WXS_package_features=$WXS_package_features
echo WXS_repositories=$WXS_repositories

echo WXS_86_IFIX_SOFTWARE_PACKAGE=$WXS_86_IFIX_SOFTWARE_PACKAGE
echo WXS_86_IFIX_SOFTWARE_PATH=$WXS_86_IFIX_SOFTWARE_PATH

if [ ! -d $IBMIM_installationDirectory ]; then
   echo "Error: $IBMIM_installationDirectory does not exist."
   exit 1
fi

cd ${IBMIM_installationDirectory}/eclipse/tools

echo ----------------------------------------
echo installing WXS ...
echo ----------------------------------------
./imcl install ${WXS_package_features} -repositories ${WXS_repositories} -installationDirectory ${WXS_installationDirectory} -sharedResourcesDirectory ${IBMIM_sharedResourcesDirectory} -acceptLicense -showProgress
     
echo ----------------------------------------
echo installing applicable WXS interim fix ...
echo ----------------------------------------
if [ ! -d $WXS_86_IFIX_SOFTWARE_PATH ]; then
   echo "Error: $WXS_86_IFIX_SOFTWARE_PATH does not exist."
else
   ./imcl install ${WXS_package_features} -repositories ${WXS_repositories} -installationDirectory ${WXS_installationDirectory} -sharedResourcesDirectory ${IBMIM_sharedResourcesDirectory} -acceptLicense -showProgress
fi

echo ======================================
echo end of installWXS.sh
echo ======================================
