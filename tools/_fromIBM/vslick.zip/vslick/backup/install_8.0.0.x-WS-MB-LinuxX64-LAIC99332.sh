#!/bin/sh
echo ======================================
echo install interim fix 8.0.0.x-WS-MB-LinuxX64-LAIC99332.tar.gz
echo ======================================

WMB_INSTALLATION_DIRECTORY=/opt/ibm/mqsi/8.0.0.4

WORKING_DIR=`pwd`

echo WORKING_DIR=$WORKING_DIR
echo NFS_SERVER_HOST=$NFS_SERVER_HOST
echo NFS_MOUNT=$NFS_MOUNT
echo LOCAL_MOUNT=$LOCAL_MOUNT
echo FP_LEVEL=$FP_LEVEL
echo INTERIM_FIX_DIRECTORY=$INTERIM_FIX_DIRECTORY
echo INSTALL_SCRIPT=$INSTALL_SCRIPT
echo MQSI_BROKER_NAME=$MQSI_BROKER_NAME
echo WMB_INSTALLATION_DIRECTORY=$WMB_INSTALLATION_DIRECTORY


echo "--------------------------"
echo "Applying 8.0.0.x-WS-MB-LinuxX64-LAIC99332"
echo "--------------------------"
echo "1 -> tar -zxvf 8.0.0.x-WS-MB-LinuxX64-LAIC99332.tar.gz"
tar -zxvf 8.0.0.x-WS-MB-LinuxX64-LAIC99332.tar.gz
ls -l .

echo "2 -> Rename the jre16 directory under the WebSphere Message Broker installation directory"
if [ ! -d ${WMB_INSTALLATION_DIRECTORY}/jre16_before_8.0.0.x-WS-MB-LinuxX64-LAIC99332 ]
then
    mv ${WMB_INSTALLATION_DIRECTORY}/jre16 ${WMB_INSTALLATION_DIRECTORY}/jre16_before_8.0.0.x-WS-MB-LinuxX64-LAIC99332
fi
     
echo "3 -> Extract the tar file (amd64_linux_2_jre16.tar) into ${WMB_INSTALLATION_DIRECTORY}" 
tar -xvf amd64_linux_2_jre16.tar -C $WMB_INSTALLATION_DIRECTORY

echo "4 -> verify jre16 has been extracted ${WMB_INSTALLATION_DIRECTORY}"
if [ ! -d ${WMB_INSTALLATION_DIRECTORY}/jre16 ]
then
    echo "FAILED: 8.0.0.x-WS-MB-LinuxX64-LAIC99332.tar.gz failed to apply"
    echo "The ${WMB_INSTALLATION_DIRECTORY}/jre16 does not exist." 
else
    echo "PASSED: 8.0.0.x-WS-MB-LinuxX64-LAIC99332.tar.gz has been applied successfully." 
    echo "The ${WMB_INSTALLATION_DIRECTORY}/jre16 exists." 
fi

echo "5 -> print jre16 directory if found."
ls ${WMB_INSTALLATION_DIRECTORY} | grep jre16

