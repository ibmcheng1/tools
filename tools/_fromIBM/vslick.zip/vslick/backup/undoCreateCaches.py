import os
import sys
execfile('wsadminlib.py')

#import the applications config.py property file with input variables to be used into the script...

dir = os.getcwd()
fileName, fileExtension = os.path.splitext(sys.argv[0])

print "Configuration File Name: " + fileName
exec("from " + fileName + " import *")
###########################################################

def printObject(name, object ):
    """Return the config object id for the named URIGroup."""
    if object is not None:
        print name + " = " + object
    else:
        print name + " = NONE"

def printAllObjectCacheInstances(scopeobjectid):
    """print all object cache instances"""
    scope = _getObjectScope(scopeobjectid)
    print "----------------------------------"
    print "Display All Object Cache Instance.  scope = " + scope
    print "----------------------------------"
    cache_ids = _splitlines(AdminConfig.list( 'ObjectCacheInstance' ))
    for id in cache_ids:
        #print "cache id = " + id
        cacheName = AdminConfig.showAttribute( id, "name" )
        idscope = _getObjectScope(id)
        if scope == idscope:
            print "cacheName = " + cacheName
     
def printAllServletCacheInstances(scopeobjectid):
    """print all servlet cache instances"""
    scope = _getObjectScope(scopeobjectid)
    print "----------------------------------"
    print "Display All Servlet Cache Instance.  scope = " + scope
    print "----------------------------------"
    cache_ids = _splitlines(AdminConfig.list( 'ServletCacheInstance' ))
    for id in cache_ids:
        #print "cache id = " + id
        cacheName = AdminConfig.showAttribute( id, "name" )
        idscope = _getObjectScope(id)
        if scope == idscope:
            print "cacheName = " + cacheName

def removeAllObjectCacheInstances():
    """remove all cache instances"""
    print "----------------------------------"
    print "Remove All Object Cache Instance ..."
    print "----------------------------------"
    cache_ids = _splitlines(AdminConfig.list( 'ObjectCacheInstance' ))
    for id in cache_ids:
        cacheName = AdminConfig.showAttribute( id, "name" )
        print "remove cacheName = " + cacheName
        
        AdminConfig.remove(id)
        AdminConfig.save()    
        print "removed id = " + id


def removeAllServletCacheInstances():
    """remove all cache instances"""
    print "----------------------------------"
    print "Remove All Servlet Cache Instance ..."
    print "----------------------------------"
    cache_ids = _splitlines(AdminConfig.list( 'ServletCacheInstance' ))
    for id in cache_ids:        
        cacheName = AdminConfig.showAttribute( id, "name" )
        print "remove cacheName = " + cacheName
        
        AdminConfig.remove(id)
        AdminConfig.save()    
        print "removed id = " + id

def removeObjectCacheInstance(scopeobjectid, targetName):
    """remove Object cache instance"""
    scope = _getObjectScope(scopeobjectid)
    print "----------------------------------"
    print "Removing Object Cache Instance: " + targetName + " from scope: " + scope
    cache_ids = _splitlines(AdminConfig.list( 'ObjectCacheInstance' ))
    removedCacheName = ""
    for id in cache_ids:
        cacheName = AdminConfig.showAttribute( id, "name" )
        if cacheName == targetName:
            idscope = _getObjectScope(id)
            if scope == idscope:
                #print "scope == idscope: scope="+ scope + ", idscope="+idscope  
                AdminConfig.remove(id)
                removedCacheName = targetName
                break    

    if removedCacheName == targetName:
        print "removed object cache instance: " + targetName
    else:
        print "Target object cache instance is not found"

    print "----------------------------------"

def removeServletCacheInstance(scopeobjectid, targetName):
    """remove Servlet cache instance"""
    scope = _getObjectScope(scopeobjectid)
    print "----------------------------------"
    print "Removing Servlet Cache Instance: " + targetName + " from scope: " + scope
    cache_ids = _splitlines(AdminConfig.list( 'ServletCacheInstance' ))
    removedCacheName = ""
    for id in cache_ids:        
        cacheName = AdminConfig.showAttribute( id, "name" )
        if cacheName == targetName:
            idscope = _getObjectScope(id)
            if scope == idscope:
                #print "scope == idscope: scope="+ scope + ", idscope="+idscope  
                AdminConfig.remove(id)
                removedCacheName = targetName
                break    
            
    if removedCacheName == targetName:
        print "removed servlet cache instance: " + targetName
    else:
        print "Target servlet cache instance is not found"
            
    print "----------------------------------"
 
  
#---------------------------------------------------------
#  Main
#
#---------------------------------------------------------

enableDebugMessages()
m = "main"

printObject("clusterName", clusterName)

cluster = getClusterId(clusterName)
printObject("cluster", cluster) 

scopeobjectid = cluster

printAllObjectCacheInstances(scopeobjectid)
printAllServletCacheInstances(scopeobjectid)

############################################
# remove 11 WC base DistributedMapCache
############################################

removeObjectCacheInstance(scopeobjectid, 'WCCatalogEntryDistributedMapCache')
removeObjectCacheInstance(scopeobjectid, 'WCCatalogGroupDistributedMapCache')
removeObjectCacheInstance(scopeobjectid, 'WCContractDistributedMapCache')
removeObjectCacheInstance(scopeobjectid, 'WCDistributedMapCache')
removeObjectCacheInstance(scopeobjectid, 'WCMarketingDistributedMapCache')
removeObjectCacheInstance(scopeobjectid, 'WCMiscDistributedMapCache')
removeObjectCacheInstance(scopeobjectid, 'WCPriceDistributedMapCache')
removeObjectCacheInstance(scopeobjectid, 'WCPromotionDistributedMapCache')
removeObjectCacheInstance(scopeobjectid, 'WCSessionDistributedMapCache')
removeObjectCacheInstance(scopeobjectid, 'WCSystemDistributedMapCache')
removeObjectCacheInstance(scopeobjectid, 'WCUserDistributedMapCache')

############################################
# remove user-defined Servlet cache instances
############################################
removeServletCacheInstance(scopeobjectid, 'extremeScaleCache')

saveAndSyncAndPrintResult()

printAllObjectCacheInstances(scopeobjectid)
printAllServletCacheInstances(scopeobjectid)


