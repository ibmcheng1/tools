#!/bin/bash
set +x

#################################################################################
#
#  This script will set up DB2 Audit facility for instance level auditing. It will configure the po#  policy to audit everything. It will then start the audit facility.
# 
#  It should be run by instance owner ID.
#  
#  Two directories are needed for this set up.  One is used for DB2AUDIT Log and the other is
#  used for DB2AUDIT archives. These directories can grow if the logs are not deleted regularly.
#
#  The script is invoked using:
#  set_db2audit <sudit_log_dir> <audit_archive_dir> 
#
################################################################################

auditdata_dir=/db2fs/db2auditdata
archive_dir=/db2fs/db2auditarchive
extract_dir=/db2fs/db2auditextract

WORKING_DIR=${PWD}

echo WORKING_DIR=$WORKING_DIR
echo auditdata_dir=$auditdata_dir
echo archive_dir=$archive_dir
echo extract_dir=$extract_dir
echo SYSLOGSERVERIP=$SYSLOGSERVERIP


if [ ! -d $auditdata_dir ]
then
    mkdir $auditdata_dir
fi

if [ ! -d $archive_dir ]
then
    mkdir $archive_dir
fi

if [ ! -d $extract_dir ]
then
    mkdir $extract_dir
fi
########################################################

if [ $# -ne 2 ]
then
    echo "  Usage: set_db2audit  <audit_log_dir> <audit_archive_dir>"
    exit 1
fi

log_dir=$1
archive_dir=$2


echo "log_dir = ${log_dir}"
echo "archive_dir = ${archive_dir}"

if [ ! -d $log_dir ]
then
    mkdir $log_dir
fi

if [ ! -d $archive_dir ]
then
    #echo " Directory $archive_dir does not exist. Make sure the directory exists before reissue the command." 
    #exit 3
    mkdir $archive_dir
fi

rc=`db2 update dbm cfg using audit_buf_sz 64`
rc=`echo $rc|grep successfully|awk '{print $9}'`
if [ $rc != "successfully." ]
then 
   echo "***Update dbm cfg failed*** - Abort"
   exit 4
fi

rc=`db2audit configure scope all status both errortype audit`
rc=`echo $rc |grep succeeded |awk '{print $3}'`
if [ $rc != "succeeded." ]
then 
  echo "***db2audit configure policy failed - Abort"
  exit 5
fi

rc=`db2audit configure datapath $log_dir`
rc=`echo $rc |grep succeeded |awk '{print $3}'`
echo $rc
if [ $rc != "succeeded." ]
then 
  echo "***db2audit configure audit log path failed - Abort"
  exit 6
fi

rc=`db2audit configure archivepath $archive_dir`  
rc=`echo $rc |grep succeeded |awk '{print $3}'`
echo $rc
if [ $rc != "succeeded." ]
then 
  echo "***db2audit configure audit archive path failed - Abort"
  exit 7
fi

db2audit start

rc=`db2audit describe |grep active |awk '{print $3}'`
echo $rc
if [ $rc != "\"TRUE" ]
then 
  echo "***db2audit start failed - Abort"
  exit 8
fi

db2audit describe

exit 0
