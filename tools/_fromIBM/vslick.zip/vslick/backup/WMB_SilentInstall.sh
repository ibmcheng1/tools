#!/bin/sh
# 
# input example: WMB_SilentInstall 4 /tmp/8.0.0-WS-MB-LINUXX64-FP0004.tar.Z
#
#   WMB_FP_LEVEL=4                                -> WMB FP level 8004
#   WMB_FP_FILE=/tmp/8.0.0-WS-MB-LINUXX64-FP0004.tar.Z -> WMB 8004 FP file
#   WMB_TEMP_DIR=FP8004                           -> FP8004

# Run the profile for WebSphere Message Broker (via a symlink)
. /home/virtuser/.mqsiprofile

WMB_FP_LEVEL=$1
WMB_FP_FILE=$2
BROKER=$3
WMB_TEMP_DIR=FP800${WMB_FP_LEVEL}
MQSI_NEW_VERSION=8.0.0.${WMB_FP_LEVEL}

echo "stopping ${BROKER} ..."
mqsistop "$BROKER"

echo "---------------------------"
echo "ps -ef | grep mqsi*"
echo "---------------------------"
ps -ef | grep mqsi*

export MQSI_VERSION

echo "-----------------------------------"
echo "WMB_SilentInstall $1 $2"
echo "-----------------------------------"
echo WORKING_DIR=$WORKING_DIR
echo WMB_FP_LEVEL=$WMB_FP_LEVEL
echo WMB_FP_FILE=$WMB_FP_FILE
echo WMB_TEMP_DIR=$WMB_TEMP_DIR
echo MQSI_VERSION=$MQSI_VERSION
echo MQSI_NEW_VERSION=$MQSI_NEW_VERSION
echo "-----------------------------------"

#WMB FP00X Silent installations 
#Create the Directory:
if [ ! -d /var/mqsi/${WMB_TEMP_DIR} ]
then
   mkdir /var/mqsi/${WMB_TEMP_DIR}
fi

#Download and expand FIXPACK (resides in /var/mqsi this file s/b included in the image):
cd /var/mqsi/${WMB_TEMP_DIR}; tar -xvzf ${WMB_FP_FILE}
#Issue the command to do a silent install:
/var/mqsi/${WMB_TEMP_DIR}/disk1/setuplinuxx64.bin -i silent -DLICENSE_ACCEPTED=TRUE -DExternal_License_Path="/opt/ibm/mqsi/8.0.0.1/license/8.0.0.1"

# /home/virtuser/.bash_profile contains a line;
sed -e "s/MQSI_VERSION/$MQSI_VERSION/g" -e "s/MQSI_NEW_VERSION/$MQSI_NEW_VERSION/g" ${WORKING_DIR}/scripts/updateMQSIprofile.sh.template > ${WORKING_DIR}/scripts/updateMQSIprofile.sh
chmod a+x ${WORKING_DIR}/scripts/updateMQSIprofile.sh

echo "--------------------------"
echo "updateMQSIprofile.sh"
echo "--------------------------"
cat ${WORKING_DIR}/scripts/updateMQSIprofile.sh

${WORKING_DIR}/scripts/updateMQSIprofile.sh

echo "--------------------------"
cat /opt/ibm/mqsi/8.0.0.1/bin/mqsiprofile
echo "---------------------------"