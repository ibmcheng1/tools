
1. Unzip the wxstbc.zip and you will get the wxstbc folder as your wxs working directory.
e.g. after unzip, the path is c:\wxs_test\wxstbc
2. This working directory contains all scripts, properties files, xml files, and libraries (jar files)
3. The setupEnv script control environemnt setting, modify the setting to fit into your system.
   You must change the catalogServerListenerHost value to your machine name.

The following settingmust be reviewed and changed:

set OBJECTGRID_ROOT=c:/wxs86/ObjectGrid
set WORKING_DIR=C:/wxs_test/wxstbc
set JAVA_HOME=c:/wxs86/java
set catalogServerListenerHost=hostname

4. after change setupEnv, you can start servers from WXS working directory
(1) run startOgCluster script to start WXS testing environment in local machine.
(2) run stopCluster to stop the entire WXS testing environment

5. after the env is started, you can run demo program.

----
install IM
----
./imcl install com.ibm.cic.agent -repositories /tmp/IM/repository.config -installationDirectory /opt/ibm/InstallationManager/eclipe -accessRights admin -acceptLicense


-------------------
after install IM
-------------------
cd /opt/ibm/InstallationManager/eclipe/eclipse/tools
./imcl listAvailablePackages -repositories /tmp/WXS_8500

./imcl input /tmp/install-response-WXS85.xml -log /tmp/install_wxs85.log -acceptLicense -showProgress



-------------------------------------------------
IBMIM.exe -skipInstall "D:\downloads\wxs_v85\WS_XSCALE_V8.5_MP_ML\WXS_8500" -record C:\temp\install_response_file.xml


