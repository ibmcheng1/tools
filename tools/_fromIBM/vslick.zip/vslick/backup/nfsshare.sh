. /etc/virtualimage.properties

#NFS_MOUNT=/repository
echo "********** Logging Environment Variables **********"
echo "NFS_MOUNT = ${NFS_MOUNT}"
echo "***************************************************"
echo

mkdir -p $NFS_MOUNT

echo Set permissions
chmod -R ug+rwx $NFS_MOUNT

echo Verify the current mount point is being exported from this server
showmount -e

echo Export the file system
echo $NFS_MOUNT  >> /etc/exports


echo Start the NFS daemon
startsrc -g nfs

echo exportfs
exportfs -a

echo Verify the mount point is being exported from this server
showmount -e


echo 
echo DONE.
