#!/bin/sh

fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

echo catalogServiceEndPoints=$catalogServiceEndPoints
echo objectgridName=$objectgridName
echo mapName=$mapName

loop=5
size=96000

actionListIndex=81  
./runDriver.sh -caseBatchPutAll -actionListIndex $actionListIndex -loop $loop -size$size -catalogServiceEndPoints $catalogServiceEndPoints -objectgridName $objectgridName -mapName $mapName

./runDriver.sh -caseClearMap -clearMap -catalogServiceEndPoints $catalogServiceEndPoints -objectgridName $objectgridName -mapName $mapName

actionListIndex=82  
./runDriver.sh -caseBatchUpsertAll -actionListIndex $actionListIndex -loop 
$loop -size$size -catalogServiceEndPoints $catalogServiceEndPoints -objectgridName $objectgridName -mapName $mapName
