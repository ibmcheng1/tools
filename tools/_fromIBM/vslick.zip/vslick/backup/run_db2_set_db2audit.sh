#!/bin/sh

auditdata_dir=/db2fs/db2auditdata
archive_dir=/db2fs/db2auditarchive
extract_dir=/db2fs/db2auditextract

echo auditdata_dir=$auditdata_dir
echo archive_dir=$archive_dir
echo extract_dir=$extract_dir


echo "chmod on /db2home/db2inst1/set_db2audit.sh ..."
chmod a+x /db2home/db2inst1/DB2/set_db2audit.sh

sudo -u db2inst1 -i /db2home/db2inst1/set_db2audit.sh $auditdata_dir $archive_dir
sudo -u db2inst1 -i db2audit describe
cat /var/spool/cron/db2inst1

