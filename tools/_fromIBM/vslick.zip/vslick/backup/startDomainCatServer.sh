#!/bin/sh
fileDir=`dirname ${0}`
. "$fileDir"/setupEnv.sh

# Start one catlog server at a time
# required parameter
#   catalog server index, e.g. 0 or 1

if [ "$1" = "" ]
then
     echo "Usage: script <CATALOG_SERVER_INDEX #>"
     exit
else
    echo "Starting catalog server: ${CATALOG_SERVER_NAME_PREFIX}$1"
fi


DOMAIN=${CATALOG_SERVICE_DOMAIN_INDEX}
echo "DOMAIN = ${DOMAIN}" 
OFFSET=$(($DOMAIN * 10))

export ENDPOINTS=''
declare -i COUNT=0
for host in $CATALOG_HOSTS
do
  echo "Catalog host : $host"
  if ((0 != ${COUNT}))
    then
      ENDPOINTS=${ENDPOINTS},
  fi
  ENDPOINTS="${ENDPOINTS}${CATALOG_SERVER_NAME_PREFIX}${COUNT}:${host}:$((6600 + $OFFSET)):$((6601 + $OFFSET))" 

  let COUNT++
done

echo "Catalog Service Domain: DOMAIN = ${DOMAIN} , Name = ${CATALOG_SERVICE_DOMAIN_NAME}, OFFSET = ${OFFSET}"
echo "Catalog Service Domain: Endpoint = $ENDPOINTS"

SERVER_NAME=${CATALOG_SERVER_NAME_PREFIX}$1
LISTENER_PORT=$((2809 + $OFFSET))
JMX_PORT=$((1099 + $DOMAIN))

APP_LOG_PATH=${WORKING_DIR}/logs/${SERVER_NAME}

if [[ ! -e ${WORKING_DIR}/logs ]]; then
    mkdir ${WORKING_DIR}/logs
    chmod 777 ${WORKING_DIR}/logs
fi

if [[ ! -e $APP_LOG_PATH ]]; then
    mkdir $APP_LOG_PATH
    chmod 777 ${APP_LOG_PATH}
fi


for host in $CATALOG_HOSTS
do
  if [[ ${CURRENT_HOST} == *$host* ]]; then 
      echo "start cat ${SERVER_NAME} server with LISTENER_PORT=${LISTENER_PORT} and JMX_PORT=${JMX_PORT} for DOMAIN $DOMAIN:[${CATALOG_SERVICE_DOMAIN_NAME}] on $host"
      ${OBJECTGRID_ROOT}/bin/startOgServer.sh ${SERVER_NAME} -domain ${CATALOG_SERVICE_DOMAIN_NAME} -serverProps ${WORKING_DIR}/properties/objectGridServer.properties -catalogServiceEndPoints $ENDPOINTS -listenerPort ${LISTENER_PORT} -jmxServicePort ${JMX_PORT} -listenerHost $host -quorum false -jvmArgs -Xmx512m &
  fi
done

