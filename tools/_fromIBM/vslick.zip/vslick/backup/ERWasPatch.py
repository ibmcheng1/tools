import java.lang.System as sys
import sys
ER_ENVIRONMENT=sys.argv[0]
print ("ER_ENVIRONMENT = ", ER_ENVIRONMENT)

# Change these values to add/remove artifacts
DBUser='sdmmgr'
DBPassword='wind0ze' 
DBServer='20.176.255.51'
DBDatabase='sdmddb'
DBPort='50000'
custConf_dir='/home/wsuser'
sdms_limitCustomers=''
# ME Specific Values
MEDatabase='sdmddb'
MEDBUser='msgidprd'
MEPassword='wind0ze'
MEDataSource='me_ds'

Bus='ERbus'
Queues=['ErrorQueue','CallSaverQueue','EmailMessageQueue','WorkflowQueue','FidelityTransmitQueue','PhdTransmitQueue','DocGenQueue','VendorscapeTransmitQueue','FawsTransmitQueue','FileTransmitQueue','FidelityDataServiceQueue','FidelityDataServiceCommentQueue','WebCommandRequestQueue','WebCommandReplyQueue','CredcoTransmitQueue','CSCCreditTransmitQueue','ChaseTransmitQueue','FAPayTransmitQueue','AsyncProcessQueue','DocumentReferenceQueue','FiServTransmitQueue','QuandisTransmitQueue','FifthThirdTransmitQueue','WellsTransmitQueue']
Factories=['ERConnectionFactory','ERConnectionFactoryLoadBalanced','mdbConnectionFactory']
Topics=['ClusterCommandDistributedTopic']
DataSources=['SQLPOOLDataSource','SQLPOOLReportDataSource']
ClientProgramName='ERWebsphere'
SchemaName='UDBADM'
SIBusPermanentStoreDirectory='/export/opt/WASMessagingLogs'
SIBusLogDirectory='/export/opt/WASMessagingLogs'
ER_WAS_DIRECTORY='/export/opt/deploy/'+ ER_ENVIRONMENT +'/current'
DB2UNIVERSAL_JDBC_DRIVER_PATH=ER_WAS_DIRECTORY + '/lib/db2-10.5'
DB2UNIVERSAL_JDBC_DRIVER_NATIVEPATH=ER_WAS_DIRECTORY + '/lib/db2-10.5'
ER_CONFIG_DIRECTORY=ER_WAS_DIRECTORY + '/conf'
ER_LOG=ER_WAS_DIRECTORY + '/er.log'
JVM_INITIAL_HEAP_SIZE='64'
JVM_MAX_HEAP_SIZE='1024'
DS_CONNECTION_POOL_MIN_CONNECTIONS='0'
DS_CONNECTION_POOL_TEST_CONNECTION_INTERVAL='10'
DS_VALIDATE_NEW_CONNECTIONS_RETRY_COUNT='100'
DS_VALIDATE_NEW_CONNECTIONS_RETRY_INTERVAL='3'
# End of change area

# functions
def ClearEnvVariables(entries):
	# needs a list of entries to be removed
	vars=AdminConfig.list("VariableSubstitutionEntry").splitlines()
	for var in vars:
		name=AdminConfig.showAttribute(var,"symbolicName")
		if (name in entries):
			AdminConfig.remove(var)
	AdminConfig.save()
	
def GetPropertiesDictionary(id):
	# needs a valid id and returns a dictionary of attributes
	dictionary = {}
	for item in AdminConfig.show(id).splitlines():
		item = item[1:-1]
		spacePos = item.find(' ')
		dictionary[item[0:spacePos]] = item[spacePos + 1:]
	return dictionary

def GetNodeServerTuples():
	# return a list of tuples - (node, server)
	# for each node get the application server(s)
	# and ignore all other types
	node_server_tuples = []
	nodelist=AdminConfig.list("Node").splitlines()
	for node in nodelist:
		dictionary = GetPropertiesDictionary(node)
		nodename = dictionary["name"]
		serverlist=AdminConfig.list("Server", node).splitlines()
		for server in serverlist:
			dictionary = GetPropertiesDictionary(server)
			name = dictionary["name"]
			type = dictionary["serverType"]
			if (type == "APPLICATION_SERVER"):
				node_server_tuples.append((nodename,server))
	
	return node_server_tuples

# Properties determined at runtime
# get cell manager node name, which is the node name of the dmgr
CellManager=AdminControl.getNode()
# get cluster name - pick up the first cluster
Cluster=GetPropertiesDictionary(AdminConfig.list("ServerCluster").splitlines()[0])['name']
# get cell name
Cell=AdminControl.getCell()
# get all nodes and their application servers
NodeAndServers=GetNodeServerTuples()

print('Cell:' + Cell + ',CellManager:' + CellManager + ',Cluster:' + Cluster)
print("Clearing environment variable entries for DB2UNIVERSAL_JDBC_DRIVER_PATH and DB2UNIVERSAL_JDBC_DRIVER_NATIVEPATH"),
ClearEnvVariables(["DB2UNIVERSAL_JDBC_DRIVER_PATH", "DB2UNIVERSAL_JDBC_DRIVER_NATIVEPATH"])
print("..................[DONE]")
print("Setting environment variables - DB2UNIVERSAL_JDBC_DRIVER_PATH + DB2UNIVERSAL_JDBC_DRIVER_NATIVEPATH at the cell level"),
VarMap=AdminConfig.list('VariableMap','(cells/' + Cell + '|variables.xml#*').splitlines()[0]
AdminConfig.create('VariableSubstitutionEntry', '' + VarMap + '', '[[symbolicName "DB2UNIVERSAL_JDBC_DRIVER_PATH"] [description ""] [value ' + DB2UNIVERSAL_JDBC_DRIVER_PATH + ']]')
AdminConfig.create('VariableSubstitutionEntry', '' + VarMap + '', '[[symbolicName "DB2UNIVERSAL_JDBC_DRIVER_NATIVEPATH"] [description ""] [value ' +  DB2UNIVERSAL_JDBC_DRIVER_NATIVEPATH + ']]')
print("..................[DONE]")

print("Creating JDBC provider"),
JDBCProvider=AdminTask.createJDBCProvider('[-scope Cell=' + Cell + ' -databaseType DB2 -providerType "DB2 Universal JDBC Driver Provider" -implementationType "XA data source" -name "DB2 Universal JDBC Driver Provider (XA)" -description "Two-phase commit DB2 JCC provider that supports JDBC 3.0. Data sources that use this provider support the use of XA to perform 2-phase commit processing. Use of driver type 2 on the application server for z/OS is not supported for data sources created under this provider." -classpath [${DB2UNIVERSAL_JDBC_DRIVER_PATH}/db2jcc.jar ${DB2UNIVERSAL_JDBC_DRIVER_PATH}/db2jcc_license_cu.jar ${DB2UNIVERSAL_JDBC_DRIVER_PATH}/db2jcc_license_cisuz.jar ] -nativePath [${DB2UNIVERSAL_JDBC_DRIVER_NATIVEPATH} ] ]')
print("..................[DONE]")

print("Creating NON-XA JDBC Driver for ME Datastore")
MEJDBCProvider=AdminTask.createJDBCProvider('[-scope Cell=' + Cell + ' -databaseType DB2 -providerType "DB2 Universal JDBC Driver Provider" -implementationType "Connection pool data source" -name "DB2 Universal JDBC Driver Provider" -description "One-phase commit DB2 JCC provider that supports JDBC 3.0. Data sources that use this provider support only 1-phase commit processing. Use of driver type 2 on the application server for z/OS is not supported for data sources created under this provider." -classpath [${DB2UNIVERSAL_JDBC_DRIVER_PATH}/db2jcc.jar ${DB2UNIVERSAL_JDBC_DRIVER_PATH}/db2jcc_license_cu.jar ${DB2UNIVERSAL_JDBC_DRIVER_PATH}/db2jcc_license_cisuz.jar ] -nativePath [${DB2UNIVERSAL_JDBC_DRIVER_NATIVEPATH} ] ]')

print('Creating Auth Data Entry'),
AuthDataEntry=AdminTask.createAuthDataEntry('[-alias user_' + DBUser + ' -user ' + DBUser + ' -password ' + DBPassword + ' -description ]')
print('Creating ME Auth Data Entry'),
AuthDataEntry=AdminTask.createAuthDataEntry('[-alias user_' + MEDBUser + ' -user ' + MEDBUser + ' -password ' + MEPassword + ' -description ]')
print("..................[DONE]")
print

print("********* Setting server JVM properties *********************")
for i in range(len(NodeAndServers)):
	# Extract the node and server from the tuple instance
	(node, server) = NodeAndServers[i]
	serverName=GetPropertiesDictionary(server)["name"]

	print("Setting JVM properties for node:" + node + ", server:" + serverName),
	jvms=AdminConfig.list("JavaVirtualMachine",server).splitlines();
	AdminConfig.unsetAttributes(jvms[0], '["classpath"]')	
	AdminTask.setJVMProperties('[-nodeName ' + node + ' -serverName ' + serverName + ' -classpath [' + ER_CONFIG_DIRECTORY + '/xml ' + ER_CONFIG_DIRECTORY + '/properties ' + ER_CONFIG_DIRECTORY + '/resource ] -initialHeapSize ' + JVM_INITIAL_HEAP_SIZE + ' -maximumHeapSize ' + JVM_MAX_HEAP_SIZE + ' -verboseModeClass false -verboseModeGarbageCollection false -verboseModeJNI false -runHProf false -hprofArguments -debugMode false -debugArgs "" -executableJarFileName -genericJvmArguments "-DSDMSConfig.release.name=9.1 -DloggingFlush=true -DstartTime=09-10-00 -Dws.ext.dirs=/ER/libs -Dsdms.environment=' + ER_ENVIRONMENT + ' -DlogName=' + ER_LOG + ' -DSDMSConfig.build.date=12/12/12 -DSDMSConfig.build.number=1234 -Xquickstart -Dsdms.limitCustomers=' + sdms_limitCustomers + ' -DcustConf.dir=' + custConf_dir + ' -DsystemConf.dir=' + custConf_dir + ' -DcustEncConf.dir=' + custConf_dir + '  -agentlib:getClasses" -disableJIT false]')   

	print("..................[DONE]")
print

print("********* Setting Cluster Template JVM properties *********************")
templates = AdminConfig.listTemplates('Server',Cluster).splitlines()
template0 = templates[0]
jvm=AdminConfig.list("JavaVirtualMachine",template0)
AdminConfig.modify(jvm,[['classpath', '/ER/conf/xml;/ER/conf/properties;/ER/conf/resource'],['initialHeapSize',JVM_INITIAL_HEAP_SIZE],['maximumHeapSize',JVM_MAX_HEAP_SIZE ]])  
#AdminConfig.modify(jvm,[['genericJvmArguments', '-DSDMSConfig.release.name=9.1 -DloggingFlush=true -DstartTime=09-10-00 -Dws.ext.dirs=/ER/libs -Dsdms.environment=' + ER_ENVIRONMENT + ' -DlogName=%s -DSDMSConfig.build.date=12/12/12 -DSDMSConfig.build.number=1234 -Dsdms.limitCustomers=' + sdms_limitCustomers + ' -DcustConf.dir=' + custConf_dir + ' -Xquickstart -agentlib:getClasses' % ER_LOG]])
print("..................[DONE]")
print

print("********* DataSources *********************")
for DataSource in DataSources:
	print("Creating data source:" + DataSource),
	ds=AdminTask.createDatasource('' + JDBCProvider + '', '[-name ' + DataSource + ' -jndiName ' + DataSource + ' -dataStoreHelperClassName com.ibm.websphere.rsadapter.DB2UniversalDataStoreHelper -containerManagedPersistence true -componentManagedAuthenticationAlias "' + CellManager + '/user_' + DBUser + '"  -xaRecoveryAuthAlias "' + CellManager + '/user_' + DBUser + '" -configureResourceProperties [[databaseName java.lang.String ' + DBDatabase + '] [driverType java.lang.Integer 4] [serverName java.lang.String ' + DBServer + '] [portNumber java.lang.Integer ' + DBPort + ']]]')
	print("..................[DONE]")

	print("Creating mapping module for data source:" + DataSource),
	name='(' + ds.split('(')[1]
	MappingModule=AdminConfig.create('MappingModule', '' + name + '', '[[authDataAlias ' + CellManager + '/user_' + DBUser + '] [mappingConfigAlias ""]]')
	print("..................[DONE]")

	print("Modifying property authDataAlias for DataSource:" + DataSource),
	CMPConnectorFactory='(' + AdminConfig.list('CMPConnectorFactory','' + DataSource + '*').split('(')[1]
	AdminConfig.modify('' + CMPConnectorFactory + '', '[[name ' + DataSource + '_CF] [authDataAlias ' + CellManager + '/user_' + DBUser + '] [xaRecoveryAuthAlias "' + CellManager + '/user_' + DBUser + '"]]')
	AdminConfig.create('MappingModule', '' + CMPConnectorFactory + '', '[[authDataAlias ' + CellManager + '/user_' + DBUser + '] [mappingConfigAlias ""]]')
	print("..................[DONE]")

	print("Adding custom properties for DataSource:" + DataSource),
	DataSourcePropertySet=AdminConfig.showAttribute(ds, 'propertySet')
	AdminConfig.create('J2EEResourceProperty', '' + DataSourcePropertySet + '', '[[name "clientProgramName"] [type "java.lang.String"] [description ""] [value ' + ClientProgramName + '] [required "false"]]')
	AdminConfig.create('J2EEResourceProperty', '' + DataSourcePropertySet + '', '[[name "downgradeHoldCursorsUnderXa"] [type "java.lang.Boolean"] [description ""] [value true] [required "false"]]')
	print("..................[DONE]")

	print("Modifying connection pool properties for DataSource:" + DataSource),
	ConnectionPool=AdminConfig.showAttribute(ds, 'connectionPool')
	AdminConfig.modify('' + ConnectionPool + '', '[[minConnections ' + DS_CONNECTION_POOL_MIN_CONNECTIONS + '] [testConnectionInterval ' + DS_CONNECTION_POOL_TEST_CONNECTION_INTERVAL + '] [testConnection "true"]]')
	print("..................[DONE]")
	
	# Get the list of properties
	DataSourceProperties=AdminConfig.list('J2EEResourceProperty', DataSourcePropertySet).splitlines()
	
	print("Modifying property currentSchema for DataSource:" + DataSource),
	SchemaProperty='(' + filter(lambda x: not(x.find('currentSchema')), DataSourceProperties)[0].split('(')[1]
	AdminConfig.modify('' + SchemaProperty + '', '[[name "currentSchema"] [type "java.lang.String"] [description "Identifies the default schema name used to qualify unqualified database object references where applicable in dynamically prepared SQL statements. Unless currentSchema is used, the default schema name is the authorization id of the current session user."] [ value ' + SchemaName + '] [ required "false"]]')
	ValidateNewConnectionProperty='(' + filter(lambda x: not(x.find('validateNewConnection')), DataSourceProperties)[0].split('(')[1]
	AdminConfig.modify('' + ValidateNewConnectionProperty + '', '[[name "validateNewConnection"] [type "java.lang.Boolean"] [description "Setting this flag to true will cause to WebSphere Application Server to validate connections when they first get created and to keep trying to get a good connection from the database if the validation fails. Setting this flag to false prevents any additional validation from being performed - newly created connections are assumed to be valid and usable. "] [value "true"] [required "false"]]')
	ValidateNewConnectionRetryCountProperty='(' + filter(lambda x: not(x.find('validateNewConnectionRetryCount')), DataSourceProperties)[0].split('(')[1]
	AdminConfig.modify('' + ValidateNewConnectionRetryCountProperty + '',  '[[name "validateNewConnectionRetryCount"] [type "java.lang.Integer"] [description "This is useful only if validateNewConnection flag is true. This property controls how many times WebSphere will try to get a connection from the database before giving up"] [value ' + DS_VALIDATE_NEW_CONNECTIONS_RETRY_COUNT + '] [required "false"]]')
	ValidateNewConnectionRetryIntervalProperty='(' + filter(lambda x: not(x.find('validateNewConnectionRetryInterval')), DataSourceProperties)[0].split('(')[1]
	AdminConfig.modify('' + ValidateNewConnectionRetryIntervalProperty + '', '[[name "validateNewConnectionRetryInterval"] [type "java.lang.Long"] [description "This is useful only if validateNewConnection flag is true. This property controls the interval between retries to retrieve a connection from the database. Unit is seconds"] [value '+ DS_VALIDATE_NEW_CONNECTIONS_RETRY_INTERVAL + '] [required "false"]]')
	print("..................[DONE]")
	
	print("Modifying property resultSetHoldability for DataSource:" + DataSource),
	ResultSetHoldabilityProperty='(' + filter(lambda x: not(x.find('resultSetHoldability')), DataSourceProperties)[0].split('(')[1]
	AdminConfig.modify('' + ResultSetHoldabilityProperty + '', '[[name "resultSetHoldability"] [type "java.lang.Integer"] [description "Determine whether ResultSets are closed or kept open when committing a transaction. The possible values are:1(HOLD_CURSORS_OVER_COMMIT),2(CLOSE_CURSORS_AT_COMMIT)."] [ value "1"] [ required "false"]]')
	print("..................[DONE]")
	
	if (DataSource == 'SQLPOOLReportDataSource'):
		# Set the SQLPOOLReportDataSource readOnly property value to 'true'
		print("Modifying property readOnly for DataSource:" + "SQLPOOLReportDataSource"),
		ReadOnlyProperty='(' + filter(lambda x: not(x.find('readOnly')), DataSourceProperties)[0].split('(')[1]
		AdminConfig.modify('' + ReadOnlyProperty + '', '[[name "readOnly"] [type "java.lang.Boolean"] [description "This property creates a read only connection. By default this value is false."] [value "true"] [required "false"]]')
		print("..................[DONE]")

print

print("Creating ME data source:" + MEDataSource),
me_ds=AdminTask.createDatasource('' + MEJDBCProvider + '', '[-name ' + MEDataSource + ' -jndiName ' + MEDataSource + ' -dataStoreHelperClassName com.ibm.websphere.rsadapter.DB2UniversalDataStoreHelper -containerManagedPersistence true -componentManagedAuthenticationAlias "' + CellManager + '/user_' + MEDBUser + '" -configureResourceProperties [[databaseName java.lang.String ' + MEDatabase + '] [driverType java.lang.Integer 4] [serverName java.lang.String ' + DBServer + '] [portNumber java.lang.Integer ' + DBPort + ']]]')
print("..................[DONE]")
print("Creating mapping module for data source:" + MEDataSource),
name='(' + me_ds.split('(')[1]
MappingModule=AdminConfig.create('MappingModule', '' + me_ds + '', '[[authDataAlias ' + CellManager + '/user_' + MEDBUser + '] [mappingConfigAlias ""]]')
print("..................[DONE]")

#AdminTask.createDatasource('"DB2 Universal JDBC Driver Provider(cells/CloudBurstCell_11421949152097|resources.xml#JDBCProvider_1422552640083)"', '[-name MEDS -jndiName jndi/meds -dataStoreHelperClassName com.ibm.websphere.rsadapter.DB2UniversalDataStoreHelper -containerManagedPersistence true -componentManagedAuthenticationAlias -configureResourceProperties [[databaseName java.lang.String MSGQTEST] [driverType java.lang.Integer 4] [serverName java.lang.String 20.176.240.97] [portNumber java.lang.Integer 50000]]]')
#

print("********* Configure SO TAI *********************")
print("Creating  trust association interceptor "),
AdminTask.configureInterceptor('[-interceptor com.csc.security.ERSSOLogin ]')
print("..................[DONE]")
print("Enabling trustAssociation"),
AdminTask.configureTrustAssociation('-enable true')
print("..................[DONE]")
sec = AdminConfig.getid('/Security:/')
print("Creating global security customer property com.ibm.websphere.security.performTAIForUnprotectedURI, setting it to true"),
AdminConfig.create('Property', sec, [['name','com.ibm.websphere.security.performTAIForUnprotectedURI'], ['value','true']])
print("..................[DONE]")
print

print("********* SIBus and SIBusMember *********************")
# Create the JMS artifacts
print('Creating SIBus: ' + Bus),
AdminTask.createSIBus('[-bus ' + Bus + ' -busSecurity false -scriptCompatibility 6.1 ]')
print("..................[DONE]")

print('Creating SIBusMember for SIBus:' + Bus),
AdminTask.addSIBusMember('[-bus ' + Bus + ' -cluster ' + Cluster + ' -dataStore -createDefaultDatasource false -datasourceJndiName ' + MEDataSource + ' -createTables true -restrictLongDBLock true -schemaName ' +  MEDBUser +  ' ]')
print("..................[DONE]")
print

#AdminTask.addSIBusMember('[-bus DbBus -cluster CSCCluster -enableAssistance true -policyName HA -dataStore -createDefaultDatasource false -datasourceJndiName jdnc/meds -authAlias CloudBurstNode_11421949152097/me_alias -createTables true -restrictLongDBLock true -schemaName msgidwar ]')


print("********* Queues and QueueActivation Specifications *********************")

for queue in Queues:
		print('Creating JMS queue:' + queue),
		AdminTask.createSIBDestination('[-bus ' + Bus + ' -name ' + queue + ' -type Queue -reliability ASSURED_PERSISTENT -description -cluster ' + Cluster + ' ]') 
		AdminTask.createSIBJMSQueue('' + Cluster + '(cells/' + Cell + '/clusters/' + Cluster + '|cluster.xml)', '[-name ' + queue + ' -jndiName ' + queue + ' -description -deliveryMode Application -readAhead AsConnection -busName ' + Bus + ' -queueName ' + queue + ' -scopeToLocalQP false -producerBind false -producerPreferLocal true -gatherMessages false]')
		print("..................[DONE]")
		print
		
		print('Creating JMS Activation Spec at cluster level for queue:' + queue),
		AdminTask.createSIBJMSActivationSpec('' + Cluster + '(cells/' + Cell + '/clusters/' + Cluster + '|cluster.xml)', '[-name ' + queue + 'AS -jndiName ' + queue + 'AS -destinationJndiName ' + queue + ' -description -busName ' + Bus + ' -clientId -durableSubscriptionHome ' + Cluster + '.000-' + Bus + ' -destinationType javax.jms.Queue -messageSelector -acknowledgeMode Auto-acknowledge -subscriptionName -maxBatchSize 1 -maxConcurrency 10 -subscriptionDurability NonDurable -shareDurableSubscriptions InCluster -authenticationAlias -readAhead Default -target -targetType BusMember -targetSignificance Preferred -targetTransportChain -providerEndPoints -shareDataSourceWithCMP false -consumerDoesNotModifyPayloadAfterGet false -forwarderDoesNotModifyPayloadAfterSet false -alwaysActivateAllMDBs true -retryInterval 30 -autoStopSequentialMessageFailure 0 -failingMessageDelay 0]') 		
		print("..................[DONE]")

print("********* Topics and TopicActivationSpecifications *********************")		
# Create the topic AS and the topic
for topic in Topics:
	print('Creating JMS Activation Spec at cluster scope for topic:' + topic),
	AdminTask.createSIBJMSActivationSpec('' + Cluster + '(cells/' + Cell + '/clusters/' + Cluster + '|cluster.xml)', '[-name ' + topic + 'AS -jndiName ' + topic + 'AS  -destinationJndiName ' + topic + ' -description -busName ' + Bus + ' -clientId -durableSubscriptionHome ' + Cluster + '.000-' + Bus + ' -destinationType javax.jms.Topic -messageSelector -acknowledgeMode Auto-acknowledge -subscriptionName -maxBatchSize 1 -maxConcurrency 10 -subscriptionDurability NonDurable -shareDurableSubscriptions InCluster -authenticationAlias -readAhead Default -target -targetType BusMember -targetSignificance Preferred -targetTransportChain -providerEndPoints -shareDataSourceWithCMP false -consumerDoesNotModifyPayloadAfterGet false -forwarderDoesNotModifyPayloadAfterSet false -alwaysActivateAllMDBs true -retryInterval 30 -autoStopSequentialMessageFailure 0 -failingMessageDelay 0]') 
	print("..................[DONE]")
	print
	print('Creating JMS topic:' + topic),
	AdminTask.createSIBJMSTopic('' + Cell + '(cells/' + Cell + '|cell.xml)', '[-name ' + topic + ' -jndiName ' + topic + ' -description -topicName -deliveryMode Application -readAhead AsConnection -busName ' + Bus + ' -topicSpace Default.Topic.Space]')
	print("..................[DONE]")
print

# Create the connection factories
print("********* Connection Factories *********************")		
for factory in Factories:
	print('Creating JMS Connection Factory:' + factory),
	AdminTask.createSIBJMSConnectionFactory('' + Cell + '(cells/' + Cell + '|cell.xml)', '[-name ' + factory + ' -jndiName ' + factory + '  -description -category -busName ' + Bus + ' -clientID -nonPersistentMapping ExpressNonPersistent -readAhead Default -tempQueueNamePrefix -tempTopicNamePrefix -durableSubscriptionHome ' + CellManager + '.' + Cluster + '-' + Bus + ' -shareDurableSubscriptions InCluster -target -targetType BusMember -targetSignificance Preferred -targetTransportChain -providerEndPoints -connectionProximity Bus -containerAuthAlias -mappingAlias -authDataAlias -shareDataSourceWithCMP false -logMissingTransactionContext false -manageCachedHandles false -xaRecoveryAuthAlias -persistentMapping ReliablePersistent -consumerDoesNotModifyPayloadAfterGet false -producerDoesNotModifyPayloadAfterSet false]')
	print("..................[DONE]")
print

print('Saving created artifacts'),
AdminConfig.save()
print("..................[DONE]")
