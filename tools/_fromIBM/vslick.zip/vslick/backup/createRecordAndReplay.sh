. /home/virtuser/WMB/scripts/environment.sh

#Setup user accounts
echo ===================================================
echo Create DB2 User
adduser db2inst1 -G root,adm,mqm,mqbrkrs
echo passw0rd > passwd db2inst1


#Add the following lines into the .bash_profile for /root/.bash_profile and /home/virtuser/.bash_profile *********
echo ===================================================
echo Setting environment
cp /root/.bash_profile /root/.bash_profile.preinstall
cp /home/virtuser/.bash_profile /home/virtuser/.bash_profile.preinstall

echo . /home/db2inst1/sqllib/db2profile >> /root/.bash_profile 
echo export LIBPATH=/home/db2inst1/sqllib/lib:/home/db2inst1/sqllib/lib32:/home/db2inst1/sqllib/lib64:$LIBPATH >> /root/.bash_profile
echo export MQSI_LIBPATH64=/home/db2inst1/sqllib/lib64:$LIBPATH >> /root/.bash_profile
echo ODBCINI=/var/mqsi/odbc/odbc.ini >> /root/.bash_profile
echo export ODBCINI >> /root/.bash_profile
echo ODBCSYSINI=/var/mqsi/odbc/odbcinst.ini >> /root/.bash_profile
echo export ODBCSYSINI >> /root/.bash_profile

echo . /home/db2inst1/sqllib/db2profile >> /home/virtuser/.bash_profile
echo export LIBPATH=/home/db2inst1/sqllib/lib:/home/db2inst1/sqllib/lib32:/home/db2inst1/sqllib/lib64:$LIBPATH >> /home/virtuser/.bash_profile
echo export MQSI_LIBPATH64=/home/db2inst1/sqllib/lib64:$LIBPATH >> /home/virtuser/.bash_profile
echo ODBCINI=/var/mqsi/odbc/odbc.ini >> /home/virtuser/.bash_profile
echo export ODBCINI >> /home/virtuser/.bash_profile
echo ODBCSYSINI=/var/mqsi/odbc/odbcinst.ini >> /home/virtuser/.bash_profile
echo export ODBCSYSINI >> /home/virtuser/.bash_profile


# Creating odbc control files
cp /home/virtuser/WMB/scripts/odbcinst.ini /var/mqsi/odbc
cp /home/virtuser/WMB/scripts/odbc.ini /var/mqsi/odbc

chmod a+x /var/mqsi/odbc/odbcinst.ini
chmod a+x /var/mqsi/odbc/odbc.ini 


echo ====================================================
echo Configuring the DB2 client communication with the server

/opt/ibm/db2/V10.5/instance/db2icrt -a CLIENT db2inst1

sudo -u db2inst1 -i /home/virtuser/WMB/scripts/setupDB2Catalog.sh

#Setup WMB for communication to DBs
mqsistop "$BROKER"
mqsistart "$BROKER"
mqsisetdbparms "$BROKER" -n AUDITDB -u db2inst1 -p passw0rd
mqsisetdbparms "$BROKER" -n ERRORDB -u db2inst1 -p passw0rd
mqsicreateconfigurableservice "$BROKER" -c DataCaptureStore -o AuditDataCaptureStore -n dataSourceName,egForRecord,egForView -v AUDITDB,Admin,Admin
mqsicreateconfigurableservice "$BROKER" -c DataCaptureStore -o ErrorDataCaptureStore -n dataSourceName,egForRecord,egForView -v ERRORDB,Admin,Admin
mqsicreateconfigurableservice "$BROKER" -c DataCaptureSource -o AuditDataCapture -n dataCaptureStore,topic -v AuditDataCaptureStore,"\$SYS/Broker/"$BROKER"/Monitoring/#"
mqsicreateconfigurableservice "$BROKER" -c DataCaptureSource -o ErrorDataCapture -n dataCaptureStore,topic -v ErrorDataCaptureStore,"\$SYS/Broker/"$BROKER"/Monitoring/Admin/#"



