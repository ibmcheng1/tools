#define __cdecl 

#define __cplusplus 1

#define __declspec(type)

#define __IL21DEC__ 

#define __IMPConfig__ 

#define __IVPConfig__ 

#define __IVPNotify__ 

#define __IVPType__ 

#undef _MAC

#define __MIDL_DECLSPEC_DLLEXPORT 

#define __MIDL_DECLSPEC_DLLIMPORT 

#define __midl_proxy 

#define __MPEGTYPE__ 

#define __P(p) p

#define __PLACEMENT_NEW_INLINE 

#define __ptr64 

#define __RND_ERROR_CODES__ 

#define __RPC_CALLEE 

#define __RPC_FAR 

#define __RPC_MAC__ 

#define __RPC_USER 

#define __RPC_WIN32__ 

#define __SEC_FAR SEC_FAR

#define __STABLIZE__ 

#define __STDC__ 

#define __TEXT(quote) L##quote

#define _ACM_WAVEFILTER 

#define _ADM_IADMW_ 

#define _ADMEX_IADM_ 

#define _ADSHLP_ 

#define _AFX_ENABLE_INLINES 

#define _AFX_NO_NESTED_DERIVATION 

#define _AFX_INLINE inline

#define _AFX_PORTABLE 

#define _AFXCMN_INLINE inline

#define _AFXCOLL_INLINE inline

#define _AFXCTL_INLINE inline

#define _AFXCVIEW_INLINE inline

#define _AFXDAOCORE_INLINE inline

#define _AFXDAODFX_INLINE inline

#define _AFXDAOVIEW_INLINE inline

#define _AFXDBCORE_INLINE inline

#define _AFXDBRFX_INLINE inline

#define _AFXDBVIEW_INLINE inline

#define _AFXDISP_INLINE inline

#define _AFXDLGS_INLINE inline

#define _AFXEXT_INLINE inline

#define _AFXHTML_INLINE inline

#define _AFXINET_INLINE inline

#define _AFXISAPI_INLINE inline

#define _AFXMT_INLINE inline

#define _AFXODLGS_INLINE inline

#define _AFXOLE_INLINE inline

#define _AFXOLECLI_INLINE inline

#define _AFXOLEDOBJ_INLINE inline

#define _AFXOLESVR_INLINE inline

#define _AFXRICH_INLINE inline

#define _AFXSOCK_INLINE inline

#define _AFXWIN_INLINE inline

#define _ALERT_ 

#define _ALPHAOPS_ 

#define _ANSIAPI_INCL 

#define _ATL_DEBUG_ADDREF_RELEASE_IMPL(className) virtual ULONG STDMETHODCALLTYPE AddRef(void) = 0; \
	virtual ULONG STDMETHODCALLTYPE Release(void) = 0;

#define _ATL_DEBUG_INTERFACES 

#define _ATL_FREE_THREADED 
       
#define _ATL_IIDOF(x) IID_##x

#define _based(a) 

#define _BHERR_ 

#define _BHSUPP_ 

#define _BHTYPE_ 

#define _BITMASK(E, T) typedef int T

#define _BITMASK_OPS(T) 

#define _BUFFER_ 

#define _CATCH_ALL } catch (...) {
 
#define _CATCH_END }

#define _CDECL 

#define _cdecl 

#define _CLUSTER_API_ 

#define _CN _SPACE

#define _CNTSIZ(iter) ptrdiff_t

#define _CPC const char *

#define _CPUC const unsigned char *

#define _CRTIMP 

#define _DECLARE_DYNCREATE(class_name) _DECLARE_DYNAMIC(class_name) \
	static CObject* PASCAL CreateObject();

#define _DEVIOCTL_ 

#define _DLCAPI_ 

#define _far

#define _FILESYSTEMFSCTL_ 

#define _FILTER_ 

#define _FINITE 

#define _FRAME_ 

#define _huge

#define _IME_ 

#define _IMPLEMENT_RUNTIMECLASS(class_name, base_class_name, wSchema, pfnNew) CRuntimeClass* PASCAL class_name::_GetBaseClass() \
		{ return RUNTIME_CLASS(base_class_name); } \
	AFX_DATADEF CRuntimeClass class_name::class##class_name = { \
		#class_name, sizeof(class class_name), wSchema, pfnNew, \
			&class_name::_GetBaseClass, NULL }; \
	static const AFX_CLASSINIT _init_##class_name(&class_name::class##class_name); \
	CRuntimeClass* class_name::GetRuntimeClass() const \
		{ return &class_name::class##class_name; }

#define _INFCODE 1

#define _INILIB_ 

#define _IPX_ADAPTER_ 

#define _IPXCONST_ 

#define _IPXRIP_ 

#define _IPXRTDEF_ 

#define _IPXSAP_ 

#define _L(c) L##c

#define _LPIINTERNET 

#define _LPIINTERNETBINDINFO 

#define _MAPIOID_ 

#define _MCIDEVICEID_ 

#undef _MIPS_ 

#undef _MPPC_ 

#define _NATIVE_ 

#define _near 

#define _NTSECAPI_ 

#undef _OS2 

#define _PARSER_ 

#define _PC char *

#undef _PPC_ 

#define _PUC unsigned char *

#define _QUOTE(x) # x

#define _RASAUTH_ 

#define _RASEAPIF_ 

#define _RASSHOST_ 

#define _RESAPI_ 

#define _STCONS(ty, name, val) enum {name = val}

#define _STD std::

#define _STD_BEGIN namespace std {

#define _STD_END };

#define _STD_USING

#define _STDCONS

#define _SVCGUID_ 

#define _TDEF(x) = x

#define _TDEF2(x, y) = x, y

#define _TDEFP(x) 

#define _TEXT(x) __T(x)

#define _TRY_BEGIN try {

#define _UI unsigned int

#undef _UNICODE 

#define _WDBGEXTS_ 

#undef _WIN16 

#define _WIN32 1

#define _WINDOWS_ 

#define _WINSOCK2API_ 

#define _X86_ 

#define AFX_API 

#define AFX_INLINE inline

#define AFX_MSG_CALL 

#define AFX_PARSE_CALL 

#define AFXIS_DATADEF 

#define AFXISAPI __stdcall

#define AFXISAPI_CDECL __cdecl

#define and_eq &=

#define ANSI_ONLY 1

#define API SQLAPI

#define API_RET_TYPE NET_API_STATUS

#define ATL_NO_VTABLE

#define BEGIN_ACCESSOR(num, bAuto) if (nAccessor == num) \
	{ \
		if (pBinding != NULL) \
			*pAuto = bAuto;

#define BEGIN_ACCESSOR_MAP(x, num) public: \
	typedef x _classtype; \
	typedef x _OutputColumnsClass; \
	static ULONG _GetNumAccessors() { return num; } \
	static bool HasOutputColumns() { return true; } \
	inline static HRESULT _GetBindEntries(ULONG* pColumns, DBBINDING *pBinding, ULONG nAccessor, bool* pAuto, BYTE* pBuffer = NULL) \
	{ \
		ATLASSERT(pColumns != NULL); \
		DBPARAMIO eParamIO = DBPARAMIO_NOTPARAM; \
		ULONG nColumns = 0; \
		pBuffer;

#define BEGIN_ADO_BINDING(cls) public: \
	typedef cls ADORowClass; \
	const ADO_BINDING_ENTRY* STDMETHODCALLTYPE GetADOBindingEntries() { \
	static const ADO_BINDING_ENTRY rgADOBindingEntries[] = { 

#define BEGIN_CATEGORY_MAP(x) static const struct _ATL_CATMAP_ENTRY* GetCategoryMap() { \
   static const struct _ATL_CATMAP_ENTRY pMap[] = {

#define BEGIN_COLUMN_MAP(x) BEGIN_ACCESSOR_MAP(x, 1) \
		BEGIN_ACCESSOR(0, true)

#define BEGIN_COM_MAP(x) public: \
	typedef x _ComMapClass; \
	static HRESULT WINAPI _Cache(void* pv, REFIID iid, void** ppvObject, DWORD dw) \
	{ \
		_ComMapClass* p = (_ComMapClass*)pv; \
		p->Lock(); \
		HRESULT hRes = CComObjectRootBase::_Cache(pv, iid, ppvObject, dw); \
		p->Unlock(); \
		return hRes; \
	} \
	IUnknown* _GetRawUnknown() \
	{ ATLASSERT(_GetEntries()[0].pFunc == _ATL_SIMPLEMAPENTRY); return (IUnknown*)((int)this+_GetEntries()->dw); } \
	_ATL_DECLARE_GET_UNKNOWN(x) \
	HRESULT _InternalQueryInterface(REFIID iid, void** ppvObject) \
	{ return InternalQueryInterface(this, _GetEntries(), iid, ppvObject); } \
	const static _ATL_INTMAP_ENTRY* WINAPI _GetEntries() { \
	static const _ATL_INTMAP_ENTRY _entries[] = { DEBUG_QI_ENTRY(x)

#define BEGIN_CONNECTION_MAP(theClass, theBase) const AFX_CONNECTIONMAP* PASCAL theClass::_GetBaseConnectionMap() \
		{ return &theBase::connectionMap; } \
	const AFX_CONNECTIONMAP* theClass::GetConnectionMap() const \
		{ return &theClass::connectionMap; } \
	const AFX_DATADEF AFX_CONNECTIONMAP theClass::connectionMap = \
		{ &theClass::_GetBaseConnectionMap, &theClass::_connectionEntries[0], }; \
	const AFX_DATADEF AFX_CONNECTIONMAP_ENTRY theClass::_connectionEntries[] = \
	{

#define BEGIN_CONNECTION_PART(theClass, localClass) class X##localClass : public CConnectionPoint \
	{ \
	public: \
		X##localClass() \
			{ m_nOffset = offsetof(theClass, m_x##localClass); }

#define BEGIN_CONNECTION_POINT_MAP(x) typedef x _atl_conn_classtype; \
	static const _ATL_CONNMAP_ENTRY* GetConnMap(int* pnEntries) { \
	static const _ATL_CONNMAP_ENTRY _entries[] = {

#define BEGIN_DISPATCH_MAP(theClass, baseClass) const AFX_DISPMAP* PASCAL theClass::_GetBaseDispatchMap() \
		{ return &baseClass::dispatchMap; } \
	const AFX_DISPMAP* theClass::GetDispatchMap() const \
		{ return &theClass::dispatchMap; } \
	const AFX_DISPMAP theClass::dispatchMap = \
		{ &theClass::_GetBaseDispatchMap, &theClass::_dispatchEntries[0], \
			&theClass::_dispatchEntryCount }; \
	UINT theClass::_dispatchEntryCount = (UINT)-1; \
	const AFX_DISPMAP_ENTRY theClass::_dispatchEntries[] = \
	{

#define BEGIN_EVENT_MAP(theClass, baseClass) const AFX_EVENTMAP* theClass::GetEventMap() const \
		{ return &eventMap; } \
	const AFX_DATADEF AFX_EVENTMAP theClass::eventMap = \
		{ &(baseClass::eventMap), theClass::_eventEntries }; \
	const AFX_DATADEF AFX_EVENTMAP_ENTRY theClass::_eventEntries[] = \
	{

#define BEGIN_EVENTSINK_MAP(theClass, baseClass) const AFX_EVENTSINKMAP* PASCAL theClass::_GetBaseEventSinkMap() \
		{ return &baseClass::eventsinkMap; } \
	const AFX_EVENTSINKMAP* theClass::GetEventSinkMap() const \
		{ return &theClass::eventsinkMap; } \
	const AFX_EVENTSINKMAP theClass::eventsinkMap = \
		{ &theClass::_GetBaseEventSinkMap, &theClass::_eventsinkEntries[0], \
			&theClass::_eventsinkEntryCount }; \
	UINT theClass::_eventsinkEntryCount = (UINT)-1; \
	const AFX_EVENTSINKMAP_ENTRY theClass::_eventsinkEntries[] = \
	{

#define BEGIN_EXTENSION_SNAPIN_NODEINFO_MAP(classname) HRESULT GetDataClass(IDataObject* pDataObject, CSnapInItem** ppItem, DATA_OBJECT_TYPES* pType) \
	{ \
		if (ppItem == NULL) \
			return E_POINTER; \
		if (pType == NULL) \
			return E_POINTER; \
 \
		*ppItem = NULL; \
 \
		*pType = CCT_UNINITIALIZED; \
 \
		STGMEDIUM stgmedium = { TYMED_HGLOBAL, NULL }; \
		FORMATETC formatetc = { CSnapInItem::m_CCF_NODETYPE, \
			NULL, \
			DVASPECT_CONTENT, \
			-1, \
			TYMED_HGLOBAL \
		}; \
 \
		stgmedium.hGlobal = GlobalAlloc(0, sizeof(GUID)); \
		if (stgmedium.hGlobal == NULL) \
			return E_OUTOFMEMORY; \
 \
		HRESULT hr = pDataObject->GetDataHere(&formatetc, &stgmedium); \
		if (FAILED(hr)) \
		{ \
			GlobalFree(stgmedium.hGlobal); \
			return hr; \
		} \
 \
		GUID guid; \
		memcpy(&guid, stgmedium.hGlobal, sizeof(GUID)); \
 \
		GlobalFree(stgmedium.hGlobal); \
		hr = S_OK;

#define BEGIN_INTERFACE_MAP(theClass, theBase) const AFX_INTERFACEMAP* PASCAL theClass::_GetBaseInterfaceMap() \
		{ return &theBase::interfaceMap; } \
	const AFX_INTERFACEMAP* theClass::GetInterfaceMap() const \
		{ return &theClass::interfaceMap; } \
	const AFX_DATADEF AFX_INTERFACEMAP theClass::interfaceMap = \
		{ &theClass::_GetBaseInterfaceMap, &theClass::_interfaceEntries[0], }; \
	const AFX_DATADEF AFX_INTERFACEMAP_ENTRY theClass::_interfaceEntries[] = \
	{

#define BEGIN_INTERFACE_PART(localClass, baseClass) class X##localClass : public baseClass \
	{ \
	public: \
		STDMETHOD_(ULONG, AddRef)(); \
		STDMETHOD_(ULONG, Release)(); \
		STDMETHOD(QueryInterface)(REFIID iid, LPVOID* ppvObj);

#define BEGIN_INTERFACE_PART_DERIVE(localClass,baseClass) BEGIN_INTERFACE_PART(localClass,baseClass)

#define BEGIN_MESSAGE_MAP(theClass, baseClass) const AFX_MSGMAP* PASCAL theClass::_GetBaseMessageMap() \
		{ return &baseClass::messageMap; } \
	const AFX_MSGMAP* theClass::GetMessageMap() const \
		{ return &theClass::messageMap; } \
	AFX_DATADEF const AFX_MSGMAP theClass::messageMap = \
	{ &theClass::_GetBaseMessageMap, &theClass::_messageEntries[0] }; \
	const AFX_MSGMAP_ENTRY theClass::_messageEntries[] = \
	{

#define BEGIN_MSG_MAP(theClass) public: \
	BOOL ProcessWindowMessage(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, LRESULT& lResult, DWORD dwMsgMapID = 0) \
	{ \
		BOOL bHandled = TRUE; \
		hWnd; \
		uMsg; \
		wParam; \
		lParam; \
		lResult; \
		bHandled; \
		switch(dwMsgMapID) \
		{ \
		case 0:

#define BEGIN_OBJECT_MAP(x) static _ATL_OBJMAP_ENTRY x[] = {

#define BEGIN_OLEFACTORY(class_name) protected: \
	class class_name##Factory : public COleObjectFactoryEx \
	{ \
	public: \
		class_name##Factory(REFCLSID clsid, CRuntimeClass* pRuntimeClass, \
			BOOL bMultiInstance, LPCTSTR lpszProgID) : \
				COleObjectFactoryEx(clsid, pRuntimeClass, bMultiInstance, \
				lpszProgID) {} \
		virtual BOOL UpdateRegistry(BOOL);

#define BEGIN_PARAM_MAP(x) public: \
	typedef x _classtype; \
	typedef x _ParamClass; \
	static bool HasParameters() { return true; } \
	static HRESULT _GetParamEntries(ULONG* pColumns, DBBINDING *pBinding, BYTE* pBuffer = NULL) \
	{ \
		ATLASSERT(pColumns != NULL); \
		DBPARAMIO eParamIO = DBPARAMIO_INPUT; \
		int nColumns = 0; \
		pBuffer;

#define BEGIN_PROP_MAP(theClass) typedef _ATL_PROP_NOTIFY_EVENT_CLASS __ATL_PROP_NOTIFY_EVENT_CLASS; \
	typedef theClass _PropMapClass; \
	static ATL_PROPMAP_ENTRY* GetPropertyMap() \
	{ \
		static ATL_PROPMAP_ENTRY pPropMap[] = \
		{

#define BEGIN_PROPERTY_MAP(theClass) typedef _ATL_PROP_NOTIFY_EVENT_CLASS __ATL_PROP_NOTIFY_EVENT_CLASS; \
	typedef theClass _PropMapClass; \
	static ATL_PROPMAP_ENTRY* GetPropertyMap() \
	{ \
		static ATL_PROPMAP_ENTRY pPropMap[] = \
		{ \
			{OLESTR("_cx"), 0, &CLSID_NULL, NULL, offsetof(_PropMapClass, m_sizeExtent.cx), sizeof(long), VT_UI4}, \
			{OLESTR("_cy"), 0, &CLSID_NULL, NULL, offsetof(_PropMapClass, m_sizeExtent.cy), sizeof(long), VT_UI4},

#define BEGIN_PROPERTY_SET(guid) BEGIN_PROPERTY_SET_EX(guid, 0)

#define BEGIN_PROPERTY_SET_EX(guid, flags) if (pNumPropSets != NULL) \
{ \
	pSet[nCurProp].pPropSet = &guid; \
	pSet[nCurProp].dwFlags = flags; \
} \
static const UPROPINFO aProperty##guid[] = \
{

#define BEGIN_PROPPAGEIDS(class_name, count) static CLSID _rgPropPageIDs_##class_name[count]; \
	AFX_COMDAT ULONG _cPropPages_##class_name = (ULONG)-1; \
	LPCLSID class_name::GetPropPageIDs(ULONG& cPropPages) { \
		if (_cPropPages_##class_name == (ULONG)-1) { \
			_cPropPages_##class_name = count; \
			LPCLSID pIDs = _rgPropPageIDs_##class_name; \
			ULONG iPageMax = count; \
			ULONG iPage = 0;

#define BEGIN_PROPSET_MAP(Class) static UPROPSET* _GetPropSet(ULONG* pNumPropSets, ULONG* pcElemPerSupported, UPROPSET* pSet = NULL, GUID* pguidSet = (GUID*)&(GUID_NULL)) \
{ \
	typedef Class _PropSetClass; \
	ULONG& cElemsMax = *pcElemPerSupported; \
	cElemsMax = 0; \
	int nCurProp = 0; \
	int cRemainder = 0;

#define BEGIN_PROVIDER_COLUMN_MAP(theClass) typedef theClass _Class; \
	template <class T> \
	static ATLCOLUMNINFO* GetColumnInfo(T* pv, ULONG* pcCols) \
	{ \
	pv; \
	static ATLCOLUMNINFO _rgColumns [] = \
	{

#define BEGIN_SCHEMA_MAP(SchemaClass) typedef SchemaClass _SchemaClass; \
	HRESULT _SchemaSupport(GUID** ppGuid, \
						   IUnknown *pUnkOuter, \
						   REFIID rguidSchema, \
						   ULONG cRestrictions, \
						   const VARIANT rgRestrictions[], \
						   REFIID riid, \
						   ULONG cPropertySets, \
						   DBPROPSET rgPropertySets[], \
						   IUnknown **ppRowset) \
	{ \
	int cGuids = 0; \
	HRESULT hr = S_OK; \
	if (ppGuid != NULL) \
		*ppGuid = NULL;

#define BEGIN_SERVICE_MAP(x) public: \
	HRESULT _InternalQueryService(REFGUID guidService, REFIID riid, void** ppvObject) \
	{

#define BEGIN_SINK_MAP(_class) static const _ATL_EVENT_ENTRY<_class>* _GetSinkMap() \
	{ \
		typedef _class _atl_event_classtype; \
		static const _ATL_EVENT_ENTRY<_class> map[] = {

#define BEGIN_SNAPINCOMMAND_MAP(theClass, bIsExtension) HRESULT ProcessCommand(UINT nID, \
		bool& bHandled, \
		CSnapInObjectRootBase* pObj, \
		DATA_OBJECT_TYPES type) \
	{ \
			bHandled = true; \
			HRESULT hr = S_OK;

#define BEGIN_SNAPINTOOLBARID_MAP(theClass) public: \
	static CSnapInToolbarInfo* GetToolbarInfo() \
	{ \
		static CSnapInToolbarInfo m_toolbarInfo[] = \
		{

#define BHAPI WINAPI

#define BOOLAPI INTERNETAPI BOOL WINAPI

#define BSCAPI(RTYPE) RTYPE BSCCALL

#define CATCH(class, e) 

#define CATCH_ALL(e) else{CException *e=_afxExceptionLink.m_pException;

#define CHAIN_PROPERTY_SET(ChainClass) ULONG cPropSets##ChainClass, cElsSupported##ChainClass; \
		int cSets##ChainClass = (int)ChainClass::_GetPropSet(NULL, &cElsSupported##ChainClass); \
		if (pNumPropSets != NULL) \
		{ \
			UPROPSET* pSetA = (UPROPSET*)_alloca(sizeof(UPROPSET)*cSets##ChainClass); \
			UPROPSET* pSetTemp = ChainClass::_GetPropSet(&cPropSets##ChainClass, &cElsSupported##ChainClass, pSetA); \
			cElemsMax = (cElemsMax < cElsSupported##ChainClass) ? cElsSupported##ChainClass : cElemsMax; \
			ATLASSERT(pSetTemp); \
			for (ULONG iSet = nCurProp; iSet < nCurProp+cPropSets##ChainClass; iSet++) \
			{ \
				pSet[iSet].pPropSet = pSetTemp[iSet-nCurProp].pPropSet; \
				pSet[iSet].dwFlags = pSetTemp[iSet-nCurProp].dwFlags; \
				pSet[iSet].pUPropInfo = pSetTemp[iSet-nCurProp].pUPropInfo; \
				pSet[iSet].cUPropInfo = pSetTemp[iSet-nCurProp].cUPropInfo; \
			} \
		} \
		nCurProp += cSets##ChainClass;

#undef CINTERFACE 

#define CLRES_V1_FUNCTION_TABLE(_Name, _Version, _Prefix, _Arbitrate, _Release, _ResControl, _ResTypeControl) CLRES_FUNCTION_TABLE _Name={CLRES_V1_FUNCTION_SIZE,_Version,_Prefix##Open,_Prefix##Close,_Prefix##Online,_Prefix##Offline,_Prefix##Terminate,_Prefix##LooksAlive,_Prefix##IsAlive,_Arbitrate,_Release,_ResControl,_ResTypeControl}

#define CLUSPROP_SZ_DECLARE(name, cch) struct{CLUSPROP_SYNTAX Syntax;DWORD cbLength;WCHAR sz[(cch+1)&~1];}name

#define CM_EVENT_HANDLE HANDLE

#define COLUMN_ENTRY(nOrdinal, data) COLUMN_ENTRY_TYPE(nOrdinal, _OLEDB_TYPE(data), data)

#define COLUMN_ENTRY_EX(nOrdinal, wType, nLength, nPrecision, nScale, data, length, status) _COLUMN_ENTRY_CODE(nOrdinal, wType, nLength, nPrecision, nScale, offsetbuf(data), offsetbuf(length), offsetbuf(status))

#define COLUMN_ENTRY_LENGTH(nOrdinal, data, length) _COLUMN_ENTRY_CODE(nOrdinal, _OLEDB_TYPE(data), _SIZE_TYPE(data), 0, 0, offsetbuf(data), offsetbuf(length), 0)

#define COLUMN_ENTRY_LENGTH_STATUS(nOrdinal, data, length, status) _COLUMN_ENTRY_CODE(nOrdinal, _OLEDB_TYPE(data), _SIZE_TYPE(data), 0, 0, offsetbuf(data), offsetbuf(length), offsetbuf(status))

#define COLUMN_ENTRY_PS(nOrdinal, nPrecision, nScale, data) _COLUMN_ENTRY_CODE(nOrdinal, _OLEDB_TYPE(data), _SIZE_TYPE(data), nPrecision, nScale, offsetbuf(data), 0, 0)

#define COLUMN_ENTRY_PS_LENGTH(nOrdinal, nPrecision, nScale, data, length) _COLUMN_ENTRY_CODE(nOrdinal, _OLEDB_TYPE(data), _SIZE_TYPE(data), nPrecision, nScale, offsetbuf(data), offsetbuf(length), 0)

#define COLUMN_ENTRY_PS_LENGTH_STATUS(nOrdinal, nPrecision, nScale, data, length, status) _COLUMN_ENTRY_CODE(nOrdinal, _OLEDB_TYPE(data), _SIZE_TYPE(data), nPrecision, nScale, offsetbuf(data), offsetbuf(length), offsetbuf(status))

#define COLUMN_ENTRY_PS_STATUS(nOrdinal, nPrecision, nScale, data, status) _COLUMN_ENTRY_CODE(nOrdinal, _OLEDB_TYPE(data), _SIZE_TYPE(data), nPrecision, nScale, offsetbuf(data), 0, offsetbuf(status))

#define COLUMN_ENTRY_STATUS(nOrdinal, data, status) _COLUMN_ENTRY_CODE(nOrdinal, _OLEDB_TYPE(data), _SIZE_TYPE(data), 0, 0, offsetbuf(data), 0, offsetbuf(status))

#define COLUMN_ENTRY_TYPE(nOrdinal, wType, data) COLUMN_ENTRY_TYPE_SIZE(nOrdinal, wType, _SIZE_TYPE(data), data)

#define COLUMN_ENTRY_TYPE_SIZE(nOrdinal, wType, nLength, data) _COLUMN_ENTRY_CODE(nOrdinal, wType, nLength, 0, 0, offsetbuf(data), 0, 0)

#define COM_ALERT(x,y) COM_ALERTX(x,y,(com_logstr,

#define COM_EXIT com_exit:

#define COM_EXIT_RC com_exit: return(rc)

#define COM_INTERFACE_ENTRY_BREAK(x)\
	{&_ATL_IIDOF(x), \
	NULL, \
	_Break},

#define COM_INTERFACE_ENTRY_NOINTERFACE(x)\
	{&_ATL_IIDOF(x), \
	NULL, \
	_NoInterface},

#define COM_INTERFACE_ENTRY(x)\
	{&_ATL_IIDOF(x), \
	offsetofclass(x, _ComMapClass), \
	_ATL_SIMPLEMAPENTRY},

#define COM_INTERFACE_ENTRY_IID(iid, x)\
	{&iid,\
	offsetofclass(x, _ComMapClass),\
	_ATL_SIMPLEMAPENTRY},

#define COM_INTERFACE_ENTRY_IMPL(x)\
	COM_INTERFACE_ENTRY_IID(_ATL_IIDOF(x), x##Impl<_ComMapClass>)

#define COM_INTERFACE_ENTRY_IMPL_IID(iid, x)\
	COM_INTERFACE_ENTRY_IID(iid, x##Impl<_ComMapClass>)

#define COM_INTERFACE_ENTRY2(x, x2)\
	{&_ATL_IIDOF(x),\
	(DWORD)((x*)(x2*)((_ComMapClass*)8))-8,\
	_ATL_SIMPLEMAPENTRY},

#define COM_INTERFACE_ENTRY2_IID(iid, x, x2)\
	{&iid,\
	(DWORD)((x*)(x2*)((_ComMapClass*)8))-8,\
	_ATL_SIMPLEMAPENTRY},

#define COM_INTERFACE_ENTRY_FUNC(iid, dw, func)\
	{&iid, \
	dw, \
	func},

#define COM_INTERFACE_ENTRY_FUNC_BLIND(dw, func)\
	{NULL, \
	dw, \
	func},

#define COM_INTERFACE_ENTRY_TEAR_OFF(iid, x)\
	{&iid,\
	(DWORD)&_CComCreatorData<\
		CComInternalCreator< CComTearOffObject< x > >\
		>::data,\
	_Creator},

#define COM_INTERFACE_ENTRY_CACHED_TEAR_OFF(iid, x, punk)\
	{&iid,\
	(DWORD)&_CComCacheData<\
		CComCreator< CComCachedTearOffObject< x > >,\
		(DWORD)offsetof(_ComMapClass, punk)\
		>::data,\
	_Cache},

#define COM_INTERFACE_ENTRY_AGGREGATE(iid, punk)\
	{&iid,\
	(DWORD)offsetof(_ComMapClass, punk),\
	_Delegate},

#define COM_INTERFACE_ENTRY_AGGREGATE_BLIND(punk)\
	{NULL,\
	(DWORD)offsetof(_ComMapClass, punk),\
	_Delegate},

#define COM_INTERFACE_ENTRY_AUTOAGGREGATE(iid, punk, clsid)\
	{&iid,\
	(DWORD)&_CComCacheData<\
		CComAggregateCreator<_ComMapClass, &clsid>,\
		(DWORD)offsetof(_ComMapClass, punk)\
		>::data,\
	_Cache},

#define COM_INTERFACE_ENTRY_AUTOAGGREGATE_BLIND(punk, clsid)\
	{NULL,\
	(DWORD)&_CComCacheData<\
		CComAggregateCreator<_ComMapClass, &clsid>,\
		(DWORD)offsetof(_ComMapClass, punk)\
		>::data,\
	_Cache},

#define COM_INTERFACE_ENTRY_CHAIN(classname)\
	{NULL,\
	(DWORD)&_CComChainData<classname, _ComMapClass>::data,\
	_Chain},
       
#define COM_QUIT goto com_exit

#define CONNECTION_IID(iid) REFIID GetIID() { return iid; }

#define CONST const

#define CONST_VTBL const

#define CPPMOD extern "C"

#define CSTDSTUBBUFFER2RELEASE(pFactory) ULONG STDMETHODCALLTYPE CStdStubBuffer2_Release(IRpcStubBuffer *This) \
    { \
    return NdrCStdStubBuffer2_Release(This,(IPSFactoryBuffer *)pFactory); \
    }

#define CSTDSTUBBUFFERRELEASE(pFactory) ULONG STDMETHODCALLTYPE CStdStubBuffer_Release(IRpcStubBuffer *This) \
    { \
    return NdrCStdStubBuffer_Release(This,(IPSFactoryBuffer *)pFactory); \
    }

#define DAOBINDINGFUNC(f) STDAPI f (ULONG cb, DWORD dwUser, LPVOID *ppData)

#define DAOMFC_DYNAMIC_COLLECTION_DECL(objColl, objSingle, intSingle) class DLLEXPORT objColl : public CdbDynamicCollection \
		{ \
		public: \
																		 \
		objSingle                       Item                            (LONG i); \
		objSingle                       Item                            (LPCTSTR pstr); \
		VOID                            Append                          (objSingle &o); \
		objSingle                       operator[]                      (LONG i); \
		objSingle                       operator[]                      (LPCTSTR pstr); \
		}

#define DAOMFC_DYNAMIC_COLLECTION_IMPL(objColl, objSingle, intColl, intSingle) objSingle			objColl::Item				(LONG i) 		{ return (intSingle *)(ObItem(i).GetInterface(TRUE)); }	 \
		objSingle			objColl::Item				(LPCTSTR pstr)	{ return (intSingle *)(ObItem(pstr).GetInterface(TRUE)); } \
		VOID				objColl::Append				(objSingle &o)	{ ObAppend(o); } \
		objSingle			objColl::operator[]			(LONG i)		{ return (intSingle *)(Item(i).GetInterface(TRUE)); } \
		objSingle			objColl::operator[]			(LPCTSTR pstr)	{ return (intSingle *)(Item(pstr).GetInterface(TRUE)); }

#define DAOMFC_STATIC_COLLECTION_DECL(objColl, objSingle, intSingle) class DLLEXPORT objColl : public CdbStaticCollection \
		{ \
		public: \
																		 \
		objSingle                       Item                            (LONG i); \
		objSingle                       Item                            (LPCTSTR pstr); \
		objSingle                       operator[]                      (LONG i); \
		objSingle                       operator[]                      (LPCTSTR pstr); \
		}

#define DAOMFC_STATIC_COLLECTION_IMPL(objColl, objSingle, intColl, intSingle) objSingle			objColl::Item				(LONG i) 		{ return (intSingle *)(ObItem(i).GetInterface(TRUE)); }	 \
		objSingle			objColl::Item				(LPCTSTR pstr)	{ return (intSingle *)(ObItem(pstr).GetInterface(TRUE)); } \
		objSingle			objColl::operator[]			(LONG i)		{ return (intSingle *)(Item(i).GetInterface(TRUE)); } \
		objSingle			objColl::operator[]			(LPCTSTR pstr)	{ return (intSingle *)(Item(pstr).GetInterface(TRUE)); }

#define DBERRHANDLE_PROC FARPROC

#define DECLARE_AGGREGATABLE(x) public: \
	typedef CComCreator2< CComCreator< CComObject< x > >, CComCreator< CComAggObject< x > > > _CreatorClass;

#define DECLARE_API(s) CPPMOD VOID \
    s( \
        HANDLE                 hCurrentProcess, \
        HANDLE                 hCurrentThread, \
        ULONG                  dwCurrentPc, \
        ULONG                  dwProcessor, \
        PCSTR                  args \
     )

#define DECLARE_CLASSFACTORY() DECLARE_CLASSFACTORY_EX(CComClassFactory)

#define DECLARE_CLASSFACTORY2(lic) DECLARE_CLASSFACTORY_EX(CComClassFactory2<lic>)

#define DECLARE_CLASSFACTORY_AUTO_THREAD() DECLARE_CLASSFACTORY_EX(CComClassFactoryAutoThread)

#define DECLARE_CLASSFACTORY_SINGLETON(obj) DECLARE_CLASSFACTORY_EX(CComClassFactorySingleton<obj>)

#define DECLARE_CONNECTION_MAP() private: \
	static const AFX_CONNECTIONMAP_ENTRY _connectionEntries[]; \
protected: \
	static AFX_DATA const AFX_CONNECTIONMAP connectionMap; \
	static const AFX_CONNECTIONMAP* PASCAL _GetBaseConnectionMap(); \
	virtual const AFX_CONNECTIONMAP* GetConnectionMap() const;

#define DECLARE_DISPATCH_MAP() private: \
	static const AFX_DISPMAP_ENTRY _dispatchEntries[]; \
	static UINT _dispatchEntryCount; \
protected: \
	static AFX_DATA const AFX_DISPMAP dispatchMap; \
	static const AFX_DISPMAP* PASCAL _GetBaseDispatchMap(); \
	virtual const AFX_DISPMAP* GetDispatchMap() const;

#define DECLARE_DYNAMIC(class_name) protected: \
	static CRuntimeClass* PASCAL _GetBaseClass(); \
public: \
	static AFX_DATA CRuntimeClass class##class_name; \
	virtual CRuntimeClass* GetRuntimeClass() const;

#define DECLARE_DYNCREATE(class_name) DECLARE_DYNAMIC(class_name) \
	static CObject* PASCAL CreateObject();

#define DECLARE_EMPTY_MSG_MAP() public: \
	BOOL ProcessWindowMessage(HWND, UINT, WPARAM, LPARAM, LRESULT&, DWORD) \
	{ \
		return FALSE; \
	}

#define DECLARE_EVENT_MAP() private: \
	static const AFX_DATA AFX_EVENTMAP_ENTRY _eventEntries[]; \
protected: \
	static const AFX_DATA AFX_EVENTMAP eventMap; \
	virtual const AFX_EVENTMAP* GetEventMap() const;

#define DECLARE_EVENTSINK_MAP() private: \
	static const AFX_EVENTSINKMAP_ENTRY _eventsinkEntries[]; \
	static UINT _eventsinkEntryCount; \
protected: \
	static AFX_DATA const AFX_EVENTSINKMAP eventsinkMap; \
	static const AFX_EVENTSINKMAP* PASCAL _GetBaseEventSinkMap(); \
	virtual const AFX_EVENTSINKMAP* GetEventSinkMap() const;

#define DECLARE_GET_CONTROLLING_UNKNOWN() public: \
	virtual IUnknown* GetControllingUnknown() {return GetUnknown();}

#define DECLARE_HANDLE(name) typedef HANDLE name

#define DECLARE_HANDLE32(name) typedef HANDLE name

#define DECLARE_INTERFACE(iface) interface iface

#define DECLARE_INTERFACE_(iface, baseiface) interface iface : public baseiface

#define DECLARE_INTERFACE_MAP() private: \
	static const AFX_INTERFACEMAP_ENTRY _interfaceEntries[]; \
protected: \
	static AFX_DATA const AFX_INTERFACEMAP interfaceMap; \
	static const AFX_INTERFACEMAP* PASCAL _GetBaseInterfaceMap(); \
	virtual const AFX_INTERFACEMAP* GetInterfaceMap() const;

#define DECLARE_MAPI_INTERFACE(iface) DECLARE_INTERFACE(iface)

#define DECLARE_MAPI_INTERFACE_(iface, baseiface) DECLARE_INTERFACE_(iface, baseiface)

#define DECLARE_MAPI_INTERFACE_PTR(iface, piface) interface iface; typedef iface FAR * piface

#define DECLARE_MESSAGE_MAP() private: \
	static const AFX_MSGMAP_ENTRY _messageEntries[]; \
protected: \
	static AFX_DATA const AFX_MSGMAP messageMap; \
	static const AFX_MSGMAP* PASCAL _GetBaseMessageMap(); \
	virtual const AFX_MSGMAP* GetMessageMap() const;

#define DECLARE_NO_REGISTRY() static HRESULT WINAPI UpdateRegistry(BOOL /*bRegister*/) \
	{return S_OK;}

#define DECLARE_NOT_AGGREGATABLE(x) public: \
	typedef CComCreator2< CComCreator< CComObject< x > >, CComFailCreator<CLASS_E_NOAGGREGATION> > _CreatorClass;

#define DECLARE_OBJECT_DESCRIPTION(x) static LPCTSTR WINAPI GetObjectDescription() \
	{ \
		return _T(x); \
	}

#define DECLARE_OLECREATE(class_name) public: \
	static AFX_DATA COleObjectFactory factory; \
	static AFX_DATA const GUID guid;

#define DECLARE_OLECREATE_EX(class_name) BEGIN_OLEFACTORY(class_name) \
	END_OLEFACTORY(class_name)

#define DECLARE_OLECTLTYPE(class_name) virtual UINT GetUserTypeNameID(); \
	virtual DWORD GetMiscStatus();

#define DECLARE_OLETYPELIB(class_name) protected: \
		virtual UINT GetTypeInfoCount(); \
		virtual HRESULT GetTypeLib(LCID, LPTYPELIB*); \
		virtual CTypeLibCache* GetTypeLibCache();

#define DECLARE_ONLY_AGGREGATABLE(x) public: \
	typedef CComCreator2< CComFailCreator<E_FAIL>, CComCreator< CComAggObject< x > > > _CreatorClass;

#define DECLARE_OPAQUE32(name) struct name##__ { int unused; }; \
                typedef const struct name##__ FAR* name

#define DECLARE_POLY_AGGREGATABLE(x) public: \
	typedef CComCreator< CComPolyObject< x > > _CreatorClass;

#define DECLARE_PROPPAGEIDS(class_name) protected: \
		virtual LPCLSID GetPropPageIDs(ULONG& cPropPages);

#define DECLARE_PROTECT_FINAL_CONSTRUCT() void InternalFinalConstructAddRef() {InternalAddRef();} \
	void InternalFinalConstructRelease() {InternalRelease();}

#define DECLARE_REGISTRY(class, pid, vpid, nid, flags) static HRESULT WINAPI UpdateRegistry(BOOL bRegister) \
	{ \
		return _Module.UpdateRegistryClass(GetObjectCLSID(), pid, vpid, nid, \
			flags, bRegister); \
	}

#define DECLARE_REGISTRY_RESOURCE(x) static HRESULT WINAPI UpdateRegistry(BOOL bRegister) \
	{ \
	return _Module.UpdateRegistryFromResource(_T(#x), bRegister); \
	}

#define DECLARE_REGISTRY_RESOURCEID(x) static HRESULT WINAPI UpdateRegistry(BOOL bRegister) \
	{ \
	return _Module.UpdateRegistryFromResource(x, bRegister); \
	}

#define DECLARE_SERIAL(class_name) DECLARE_DYNCREATE(class_name) \
	friend CArchive& AFXAPI operator>>(CArchive& ar, class_name* &pOb);

#define DECLARE_STATIC_REGISTRY_RESOURCE(x) DECLARE_REGISTRY_RESOURCE(x)

#define DECLARE_STATIC_REGISTRY_RESOURCEID(x) DECLARE_REGISTRY_RESOURCEID(x)

#define DECLARE_VIEW_STATUS(statusFlags) DWORD _GetViewStatus() \
	{ \
		return statusFlags; \
	}

#define DECLARE_WND_CLASS(WndClassName) static CWndClassInfo& GetWndClassInfo() \
{ \
	static CWndClassInfo wc = \
	{ \
		{ sizeof(WNDCLASSEX), CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS, StartWindowProc, \
		  0, 0, NULL, NULL, NULL, (HBRUSH)(COLOR_WINDOW + 1), NULL, WndClassName, NULL }, \
		NULL, NULL, IDC_ARROW, TRUE, 0, _T("") \
	}; \
	return wc; \
}

#define DECLARE_WND_CLASS_EX(WndClassName, style, bkgnd) static CWndClassInfo& GetWndClassInfo() \
{ \
	static CWndClassInfo wc = \
	{ \
		{ sizeof(WNDCLASSEX), style, StartWindowProc, \
		  0, 0, NULL, NULL, NULL, (HBRUSH)(bkgnd + 1), NULL, WndClassName, NULL }, \
		NULL, NULL, IDC_ARROW, TRUE, 0, _T("") \
	}; \
	return wc; \
}

#define DECLARE_WND_SUPERCLASS(WndClassName, OrigWndClassName) static CWndClassInfo& GetWndClassInfo() \
{ \
	static CWndClassInfo wc = \
	{ \
		{ sizeof(WNDCLASSEX), 0, StartWindowProc, \
		  0, 0, NULL, NULL, NULL, NULL, NULL, WndClassName, NULL }, \
		OrigWndClassName, NULL, NULL, TRUE, 0, _T("") \
	}; \
	return wc; \
}

#define DECLSPEC_UUID(x) 

#define DEFINE_ADOGUID(name, l) DEFINE_GUID(name, l, 0, 0x10, 0x80,0,0,0xAA,0,0x6D,0x2E,0xA4)

#define DEFINE_AVIGUID(name, l, w1, w2) DEFINE_GUID(name, l, w1, w2, 0xC0,0,0,0,0,0,0,0x46)

#define DEFINE_COMMAND(x, szCommand) typedef x _CommandClass; \
	static HRESULT GetDefaultCommand(LPCTSTR* ppszCommand) \
	{ \
		*ppszCommand = szCommand; \
		return S_OK; \
	}

#define DEFINE_DAOGUID(name, l) DEFINE_GUID(name, l, 0, 0x10, 0x80,0,0,0xAA,0,0x6D,0x2E,0xA4)

#define DEFINE_EXCHEXTGUID(name, b) DEFINE_GUID(name, 0x00020D00 | (b), 0, 0, 0xC0,0,0,0,0,0,0,0x46)

#define DEFINE_EXCHFORMGUID(name, b) DEFINE_GUID(name, 0x00020D00 | (b), 0, 0, 0xC0,0,0,0,0,0,0,0x46)

#define DEFINE_GUID(name, l, w1, w2, b1, b2, b3, b4, b5, b6, b7, b8) EXTERN_C const GUID name

#define DEFINE_GUIDEX(name) EXTERN_C const CDECL GUID name

#define DEFINE_GUIDNAMED(n) n

#define DEFINE_IPTR(x) typedef IPTR(x) x##Ptr;

#define DEFINE_KSCREATE_DISPATCH_TABLE(tablename) KSOBJECT_CREATE_ITEM tablename[]=

#define DEFINE_KSDISPATCH_TABLE(tablename, DeviceIoControl, Read, Write, Flush, Close, QuerySecurity, SetSecurity, FastDeviceIoControl, FastRead, FastWrite) const KSDISPATCH_TABLE tablename={DeviceIoControl,Read,Write,Flush,Close,QuerySecurity,SetSecurity,FastDeviceIoControl,FastRead,FastWrite,}

#define DEFINE_KSEVENT_SET_TABLE(tablename) const KSEVENT_SET tablename[] =

#define DEFINE_KSEVENT_TABLE(tablename) const KSEVENT_ITEM tablename[] =

#define DEFINE_KSMETHOD_ALLOCATORSET(AllocatorSet, MethodAlloc, MethodFree) DEFINE_KSMETHOD_TABLE(AllocatorSet) { \
    DEFINE_KSMETHOD_ITEM_STREAMALLOCATOR_ALLOC(MethodAlloc), \
    DEFINE_KSMETHOD_ITEM_STREAMALLOCATOR_FREE(MethodFree) \
}

#define DEFINE_KSMETHOD_SET_TABLE(tablename) const KSMETHOD_SET tablename[] =

#define DEFINE_KSMETHOD_TABLE(tablename) const KSMETHOD_ITEM tablename[] =

#define DEFINE_KSPIN_DESCRIPTOR_TABLE(tablename) const KSPIN_DESCRIPTOR tablename[] =

#define DEFINE_KSPIN_INTERFACE_TABLE(tablename) const KSPIN_INTERFACE tablename[] =

#define DEFINE_KSPIN_MEDIUM_TABLE(tablename) const KSPIN_MEDIUM tablename[]=

#define DEFINE_KSPROPERTY_ALLOCATORSET(AllocatorSet, PropFunctionTable, PropStatus) DEFINE_KSPROPERTY_TABLE(AllocatorSet) { \
    DEFINE_KSPROPERTY_ITEM_STREAMALLOCATOR_STATUS(PropStatus), \
    DEFINE_KSPROPERTY_ITEM_STREAMALLOCATOR_FUNCTIONTABLE(PropFunctionTable) \
}

#define DEFINE_KSPROPERTY_CLOCKSET(ClockSet, PropTime, PropPhysicalTime, PropCorrelatedTime, PropCorrelatedPhysicalTime, PropResolution, PropState, PropFunctionTable, PropParent) DEFINE_KSPROPERTY_TABLE(ClockSet){DEFINE_KSPROPERTY_ITEM_CLOCK_TIME(PropTime),DEFINE_KSPROPERTY_ITEM_CLOCK_PHYSICALTIME(PropPhysicalTime),DEFINE_KSPROPERTY_ITEM_CLOCK_CORRELATEDTIME(PropCorrelatedTime),DEFINE_KSPROPERTY_ITEM_CLOCK_CORRELATEDPHYSICALTIME(PropCorrelatedPhysicalTime),DEFINE_KSPROPERTY_ITEM_CLOCK_RESOLUTION(PropResolution),DEFINE_KSPROPERTY_ITEM_CLOCK_STATE(PropState),DEFINE_KSPROPERTY_ITEM_CLOCK_FUNCTIONTABLE(PropFunctionTable),DEFINE_KSPROPERTY_ITEM_CLOCK_PARENT(PropParent)}

#define DEFINE_KSPROPERTY_PINSET(PinSet, PropGeneral, PropInstances, PropIntersection) DEFINE_KSPROPERTY_TABLE(PinSet){DEFINE_KSPROPERTY_ITEM_PIN_CINSTANCES(PropInstances),DEFINE_KSPROPERTY_ITEM_PIN_CTYPES(PropGeneral),DEFINE_KSPROPERTY_ITEM_PIN_DATAFLOW(PropGeneral),DEFINE_KSPROPERTY_ITEM_PIN_DATARANGES(PropGeneral),DEFINE_KSPROPERTY_ITEM_PIN_DATAINTERSECTION(PropIntersection),DEFINE_KSPROPERTY_ITEM_PIN_INTERFACES(PropGeneral),DEFINE_KSPROPERTY_ITEM_PIN_MEDIUMS(PropGeneral),DEFINE_KSPROPERTY_ITEM_PIN_COMMUNICATION(PropGeneral),DEFINE_KSPROPERTY_ITEM_PIN_CATEGORY(PropGeneral),DEFINE_KSPROPERTY_ITEM_PIN_NAME(PropGeneral)}

#define DEFINE_KSPROPERTY_SET_TABLE(tablename) const KSPROPERTY_SET tablename[] =

#define DEFINE_KSPROPERTY_STREAMINTERFACESET(StreamInterfaceSet, HeaderSizeHandler) DEFINE_KSPROPERTY_TABLE(StreamInterfaceSet){DEFINE_KSPROPERTY_ITEM_STREAMINTERFACE_HEADERSIZE(HeaderSizeHandler)}

#define DEFINE_KSPROPERTY_TABLE(tablename) const KSPROPERTY_ITEM tablename[] =

#define DEFINE_KSPROPERTY_TOPOLOGYSET(TopologySet, Handler) DEFINE_KSPROPERTY_TABLE(TopologySet) { \
    DEFINE_KSPROPERTY_ITEM_TOPOLOGY_CATEGORIES(Handler), \
    DEFINE_KSPROPERTY_ITEM_TOPOLOGY_NODES(Handler), \
    DEFINE_KSPROPERTY_ITEM_TOPOLOGY_CONNECTIONS(Handler), \
    DEFINE_KSPROPERTY_ITEM_TOPOLOGY_NAME(Handler) \
}

#define DEFINE_MIB_BUFFER(X,Y,Z) DWORD		__rgdwBuff[MIB_INFO_SIZE_IN_DWORDS(Y)]; \
    PMIB_OPAQUE_INFO    X = (PMIB_OPAQUE_INFO)__rgdwBuff; \
    Y *                 Z = (Y *)(X->rgbyData)

#define DEFINE_OID_1(name, b0, b1) EXTERN_C const BYTE FAR * name

#define DEFINE_OID_2(name, b0, b1, b2) EXTERN_C const BYTE FAR * name

#define DEFINE_OID_3(name, b0, b1, b2, b3) EXTERN_C const BYTE FAR * name

#define DEFINE_OID_4(name, b0, b1, b2, b3, b4) EXTERN_C const BYTE FAR * name

#define DEFINE_OLEDB_TYPE_FUNCTION(ctype, oledbtype) inline DBTYPE _GetOleDBType(ctype&) \
	{ \
		return oledbtype; \
	}

#define DEFINE_OLEGUID(name, l, w1, w2) DEFINE_GUID(name, l, w1, w2, 0xC0,0,0,0,0,0,0,0x46)

#define DEFINE_RULEEXTGUID(name, b) DEFINE_GUID(name, 0x00020E00 | (b), 0, 0, 0xC0,0,0,0,0,0,0,0x46)

#define DEFINE_SHLGUID(name, l, w1, w2) DEFINE_GUID(name, l, w1, w2, 0xC0,0,0,0,0,0,0,0x46)

#define DEFINE_SQLOLEGUID(name, l) DEFINE_GUID(name, l, 0x0bcc, 0x11ce, 0xa4, 0xb3, 0x00, 0xaa, 0x00, 0x4a, 0x34, 0xd5)

#define DLLCANUNLOADNOW(pFactory) HRESULT STDAPICALLTYPE DllCanUnloadNow() \
    { \
    return NdrDllCanUnloadNow( pFactory ); \
    }

#define DLLCANUNLOADNOW_ENTRY EXPANDED_ENTRY_PREFIX()##DllCanUnloadNow

#define DLLDATA_GETPROXYDLLINFO(pPFList,pClsid) void RPC_ENTRY GetProxyDllInfo( const ProxyFileInfo*** pInfo, const CLSID ** pId ) \
        { \
        *pInfo  = pPFList; \
        *pId    = pClsid; \
        };

#define DLLDATA_ROUTINES (pProxyFileList,pClsID ) \
    CLSID_PSFACTORYBUFFER \
    CStdPSFactoryBuffer       gPFactory = {0,0,0,0}; \
    DLLDATA_GETPROXYDLLINFO(pProxyFileList,pClsID) \
    DLLGETCLASSOBJECTROUTINE(pProxyFileList,pClsID,&gPFactory) \
    DLLCANUNLOADNOW(&gPFactory) \
    CSTDSTUBBUFFERRELEASE(&gPFactory) \
    CSTDSTUBBUFFER2RELEASE(&gPFactory) \
    DLLDUMMYPURECALL \
    DLLREGISTRY_ROUTINES(pProxyFileList, pClsID)

#define DLLDATA_STANDARD_ROUTINES DLLDATA_ROUTINES( (const ProxyFileInfo**) pProxyFileList, &CLSID_PSFactoryBuffer )

#define DLLDUMMYPURECALL void __cdecl _purecall(void) \
        { \
        }

#define dllexp __declspec( dllexport )

#define DLLGETCLASSOBJECT_ENTRY EXPANDED_ENTRY_PREFIX()##DllGetClassObject

#define DLLGETCLASSOBJECTROUTINE(pPFlist, pClsid,pFactory) HRESULT STDAPICALLTYPE DllGetClassObject ( \
     REFCLSID rclsid, \
     REFIID riid, \
     void ** ppv ) \
        { \
        return \
            NdrDllGetClassObject(rclsid,riid,ppv,pPFlist,pClsid,pFactory ); \
        }

#define DLLREGISTRY_ROUTINES(pProxyFileList, pClsID) REGISTER_PROXY_DLL_ROUTINES(pProxyFileList,pClsID)

#define DLLIMPORT __declspec( dllimport )

#define DLLMAIN_ENTRY EXPANDED_ENTRY_PREFIX()##DllMain

#define DLLREGISTERSERVER_ENTRY EXPANDED_ENTRY_PREFIX()##DllRegisterServer

#define DLLUNREGISTERSERVER_ENTRY EXPANDED_ENTRY_PREFIX()##DllUnregisterServer

#define END_ACCESSOR() } \
	else

#define END_ACCESSOR_MAP() ; \
		*pColumns = nColumns; \
		return S_OK; \
	}

#define END_ADO_BINDING() {0, adEmpty, 0, 0, 0, 0, 0, 0, 0, FALSE}}; \
	return rgADOBindingEntries;}

#define END_CATEGORY_MAP() { _ATL_CATMAP_ENTRY_END, NULL } }; \
   return( pMap ); }

#define END_COLUMN_MAP() END_ACCESSOR() \
	END_ACCESSOR_MAP()

#define END_COM_MAP() {NULL, 0, 0}}; return _entries;} \
	virtual ULONG STDMETHODCALLTYPE AddRef( void) = 0; \
	virtual ULONG STDMETHODCALLTYPE Release( void) = 0; \
	STDMETHOD(QueryInterface)(REFIID, void**) = 0;

#define END_CONNECTION_MAP() { NULL, (size_t)-1 } \
	};

#define END_CONNECTION_PART(localClass) } m_x##localClass; \
	friend class X##localClass;

#define END_CONNECTION_POINT_MAP() {(DWORD)-1} }; \
	if (pnEntries) *pnEntries = sizeof(_entries)/sizeof(_ATL_CONNMAP_ENTRY) - 1; \
	return _entries;}

#define END_DISPATCH_MAP() { VTS_NONE, DISPID_UNKNOWN, VTS_NONE, VT_VOID, \
		(AFX_PMSG)NULL, (AFX_PMSG)NULL, (size_t)-1, afxDispCustom } };

#define END_DONT_RESEND ((ULONG) 0x00040000)

#define END_EVENT_MAP() { afxEventCustom, DISPID_UNKNOWN, NULL, NULL }, \
	};

#define END_EVENTSINK_MAP() { VTS_NONE, DISPID_UNKNOWN, VTS_NONE, VT_VOID, \
		(AFX_PMSG)NULL, (AFX_PMSG)NULL, (size_t)-1, afxDispCustom, \
		(UINT)-1, 0 } };

#define END_EXTENSION_SNAPIN_NODEINFO_MAP() return CSnapInItem::GetDataClass(pDataObject, ppItem, pType); \
	};

#define END_INTERFACE_MAP() { NULL, (size_t)-1 } \
	};

#define END_INTERFACE_PART(localClass) } m_x##localClass; \
	friend class X##localClass;

#define END_INTERFACE_PART_OPTIONAL(localClass) }; \
	CInterfacePlaceHolder m_x##localClass; \
	friend class X##localClass;

#define END_MESSAGE_MAP() {0, 0, 0, 0, AfxSig_end, (AFX_PMSG)0 } \
	};

#define END_MSG_MAP() break; \
		default: \
			ATLTRACE2(atlTraceWindowing, 0, _T("Invalid message map ID (%i)\n"), dwMsgMapID); \
			ATLASSERT(FALSE); \
			break; \
		} \
		return FALSE; \
	}

#define END_OBJECT_MAP() {NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}};

#define END_OLECMD_MAP() {NULL, 0, 0} \
	};

#define END_OLEFACTORY(class_name) }; \
	friend class class_name##Factory; \
	static AFX_DATA class_name##Factory factory; \
public: \
	static AFX_DATA const GUID guid; \
	virtual HRESULT GetClassID(LPCLSID pclsid);

#define END_PARAM_MAP() *pColumns = nColumns; \
		return S_OK; \
	}

#define END_PARSE_MAP(theClass) }; \
	UINT PASCAL theClass::GetNumMapEntries() { \
		return sizeof(theClass::_parseEntries) / \
		sizeof(AFX_PARSEMAP_ENTRY); }

#define END_PROP_MAP() {NULL, 0, NULL, &IID_NULL, 0, 0, 0} \
		}; \
		return pPropMap; \
	}

#define END_PROPERTY_MAP() {NULL, 0, NULL, &IID_NULL, 0, 0, 0} \
		}; \
		return pPropMap; \
	}

#define END_PROPERTY_SET(guid) };if(pNumPropSets!=NULL){pSet[nCurProp].pUPropInfo=(UPROPINFO *) aProperty##guid;pSet[nCurProp].cUPropInfo=sizeof(aProperty##guid)/sizeof(UPROPINFO);cRemainder=(pSet[nCurProp].cUPropInfo%32)?1:0;if(cElemsMax<(pSet[nCurProp].cUPropInfo/32+cRemainder)){cElemsMax=(pSet[nCurProp].cUPropInfo/32+cRemainder);}}nCurProp++;

#define END_PROPERTY_SET_EX(define) 

#define END_PROVIDER_COLUMN_MAP };*pcCols=sizeof(_rgColumns)/sizeof(ATLCOLUMNINFO);return _rgColumns;}

#define END_PROPPAGEIDS(class_name) ASSERT(iPage == iPageMax); \
		} \
		cPropPages = _cPropPages_##class_name; \
		return _rgPropPageIDs_##class_name; }
        
#define END_PROPSET_MAP if(pNumPropSets!=NULL){if(IsEqualGUID(*pguidSet,GUID_NULL)){*pNumPropSets=nCurProp;return pSet;}else{*pNumPropSets=1;UINT i=0;for(;i<sizeof(pSet)/sizeof(UPROPSET)&&IsEqualGUID(*(pSet[i].pPropSet),*pguidSet);i++);return(i==sizeof(pSet)/sizeof(UPROPSET))?&pSet[0]:&pSet[i];}}return(UPROPSET *) nCurProp;}

#define END_PROPSET_MAP() if (pNumPropSets != NULL) \
	{ \
		if (IsEqualGUID(*pguidSet, GUID_NULL)) \
		{ \
			*pNumPropSets = nCurProp; \
			return pSet; \
		} \
		else \
		{ \
			*pNumPropSets = 1; \
			UINT i = 0; \
			for (; i < sizeof(pSet)/sizeof(UPROPSET) && IsEqualGUID(*(pSet[i].pPropSet), *pguidSet); i++); \
			return (i == sizeof(pSet)/sizeof(UPROPSET)) ? &pSet[0] : &pSet[i]; \
		} \
	} \
	return (UPROPSET*)nCurProp; \
	}

#define END_PROVIDER_COLUMN_MAP() }; *pcCols = sizeof(_rgColumns)/sizeof(ATLCOLUMNINFO); return _rgColumns;}

#define END_SCHEMA_MAP() if (ppGuid != NULL) \
			return hr; \
		return E_INVALIDARG; \
	}

#define END_SERVICE_MAP() return E_NOINTERFACE; \
	}

#define END_SINK_MAP() {0, NULL, 0, 0, NULL, NULL} }; return map;}

#define END_SNAPINCOMMAND_MAP() return hr; \
	}

#define END_SNAPINTOOLBARID_MAP() { NULL, NULL, NULL, 0, 0} \
		}; \
		return m_toolbarInfo; \
	}

#define EXCHANGE_IEXCHANGEEXPORTCHANGES_METHODS(IPURE) MAPIMETHOD(GetLastError)								 \
		(THIS_	HRESULT				hResult,				 \
		 	    ULONG				ulFlags,				 \
		 	    LPMAPIERROR FAR *	lppMAPIError) IPURE;	 \
	MAPIMETHOD(Config)										 \
		(THIS_	LPSTREAM			lpStream,				 \
				ULONG				ulFlags,				 \
				LPUNKNOWN			lpUnk,					 \
		 		LPSRestriction		lpRestriction,			 \
		 	    LPSPropTagArray		lpIncludeProps,			 \
		 	    LPSPropTagArray		lpExcludeProps,			 \
		 		ULONG				ulBufferSize) IPURE;	 \
	MAPIMETHOD(Synchronize)									 \
		(THIS_	ULONG FAR *			lpulSteps,				 \
				ULONG FAR *			lpulProgress) IPURE;	 \
	MAPIMETHOD(UpdateState)									 \
		(THIS_	LPSTREAM			lpStream) IPURE;

#define EXCHANGE_IEXCHANGEFASTTRANSFER_METHODS(IPURE) MAPIMETHOD(Config)											 \
		(THIS_	ULONG				ulFlags,					 \
				ULONG				ulTransferMethod) IPURE;	 \
	MAPIMETHOD(TransferBuffer)									 \
		(THIS_	ULONG				cb,							 \
				LPBYTE				lpb,						 \
				ULONG				*lpcbProcessed) IPURE;		 \
	STDMETHOD_(BOOL, IsInterfaceOk)								 \
		(THIS_	ULONG				ulTransferMethod,			 \
				REFIID				refiid,						 \
				LPSPropTagArray		lpptagList,					 \
				ULONG				ulFlags) IPURE;

#define EXCHANGE_IEXCHANGEFAVORITES_METHODS(IPURE) MAPIMETHOD(GetLastError)											 \
		(THIS_	HRESULT						hResult,					 \
				ULONG						ulFlags,					 \
				LPMAPIERROR FAR *			lppMAPIError) IPURE;		 \
	MAPIMETHOD(AddFavorites)											 \
		(THIS_	LPENTRYLIST					lpEntryList) IPURE;			 \
	MAPIMETHOD(DelFavorites)											 \
		(THIS_	LPENTRYLIST					lpEntryList) IPURE;			

#define EXCHANGE_IEXCHANGEIMPORTCONTENTSCHANGES_METHODS(IPURE) MAPIMETHOD(GetLastError)										 \
		(THIS_	HRESULT				hResult,						 \
		 	    ULONG				ulFlags,						 \
		 	    LPMAPIERROR FAR *	lppMAPIError) IPURE;			 \
	MAPIMETHOD(Config)												 \
		(THIS_	LPSTREAM				lpStream,					 \
		 		ULONG					ulFlags) IPURE;				 \
	MAPIMETHOD(UpdateState)											 \
		(THIS_	LPSTREAM				lpStream) IPURE;			 \
	MAPIMETHOD(ImportMessageChange)									 \
		(THIS_	ULONG					cpvalChanges,				 \
				LPSPropValue			ppvalChanges,				 \
				ULONG					ulFlags,					 \
				LPMESSAGE				*lppmessage) IPURE;			 \
	MAPIMETHOD(ImportMessageDeletion)								 \
		(THIS_	ULONG					ulFlags,					 \
		 		LPENTRYLIST				lpSrcEntryList) IPURE;		 \
	MAPIMETHOD(ImportPerUserReadStateChange)						 \
		(THIS_	ULONG					cElements,					 \
		 		LPREADSTATE			 	lpReadState) IPURE;			 \
	MAPIMETHOD(ImportMessageMove)									 \
		(THIS_	ULONG					cbSourceKeySrcFolder,		 \
		 		BYTE FAR *				pbSourceKeySrcFolder,		 \
		 		ULONG					cbSourceKeySrcMessage,		 \
		 		BYTE FAR *				pbSourceKeySrcMessage,		 \
		 		ULONG					cbPCLMessage,				 \
		 		BYTE FAR *				pbPCLMessage,				 \
		 		ULONG					cbSourceKeyDestMessage,		 \
		 		BYTE FAR *				pbSourceKeyDestMessage,		 \
		 		ULONG					cbChangeNumDestMessage,		 \
		 		BYTE FAR *				pbChangeNumDestMessage) IPURE;

#define EXCHANGE_IEXCHANGEIMPORTHIERARCHYCHANGES_METHODS(IPURE) MAPIMETHOD(GetLastError)										 \
		(THIS_	HRESULT				hResult,						 \
				ULONG 				ulFlags,						 \
				LPMAPIERROR FAR *	lppMAPIError) IPURE;			 \
	MAPIMETHOD(Config)												 \
		(THIS_	LPSTREAM				lpStream,					 \
		 		ULONG					ulFlags) IPURE;				 \
	MAPIMETHOD(UpdateState)											 \
		(THIS_	LPSTREAM				lpStream) IPURE;			 \
	MAPIMETHOD(ImportFolderChange)									 \
		(THIS_	ULONG						cpvalChanges,			 \
				LPSPropValue				ppvalChanges) IPURE;	 \
	MAPIMETHOD(ImportFolderDeletion)								 \
		(THIS_	ULONG						ulFlags,				 \
		 		LPENTRYLIST					lpSrcEntryList) IPURE;

#define EXCHANGE_IEXCHANGEMANAGESTORE_METHODS(IPURE) MAPIMETHOD(CreateStoreEntryID)										 \
		(THIS_	LPSTR						lpszMsgStoreDN,				 \
				LPSTR						lpszMailboxDN,				 \
				ULONG						ulFlags,					 \
				ULONG FAR *					lpcbEntryID,				 \
				LPENTRYID FAR *				lppEntryID) IPURE;			 \
	MAPIMETHOD(EntryIDFromSourceKey)									 \
		(THIS_	ULONG						cFolderKeySize,				 \
				BYTE FAR *					lpFolderSourceKey,			 \
				ULONG						cMessageKeySize,			 \
				BYTE FAR *					lpMessageSourceKey,			 \
				ULONG FAR *					lpcbEntryID,				 \
				LPENTRYID FAR *				lppEntryID) IPURE;			 \
	MAPIMETHOD(GetRights)												 \
		(THIS_	ULONG						cbUserEntryID,				 \
				LPENTRYID					lpUserEntryID,				 \
				ULONG						cbEntryID,					 \
				LPENTRYID					lpEntryID,					 \
				ULONG FAR *					lpulRights) IPURE;			 \
	MAPIMETHOD(GetMailboxTable)											 \
		(THIS_	LPSTR						lpszServerName,				 \
				LPMAPITABLE FAR *			lppTable,					 \
				ULONG						ulFlags) IPURE;				 \
	MAPIMETHOD(GetPublicFolderTable)									 \
		(THIS_	LPSTR						lpszServerName,				 \
				LPMAPITABLE FAR *			lppTable,					 \
				ULONG						ulFlags) IPURE;

#define EXCHANGE_IEXCHANGEMODIFYTABLE_METHODS(IPURE) MAPIMETHOD(GetLastError)											 \
		(THIS_	HRESULT						hResult,					 \
				ULONG						ulFlags,					 \
				LPMAPIERROR FAR *			lppMAPIError) IPURE;		 \
	MAPIMETHOD(GetTable)												 \
		(THIS_	ULONG						ulFlags,					 \
				LPMAPITABLE FAR *			lppTable) IPURE;			 \
	MAPIMETHOD(ModifyTable)												 \
		(THIS_	ULONG						ulFlags,					 \
				LPROWLIST					lpMods) IPURE;

#define EXCHANGE_IEXCHANGERULEACTION_METHODS(IPURE) MAPIMETHOD(ActionCount)												 \
		(THIS_	ULONG FAR *					lpcActions) IPURE;			 \
	MAPIMETHOD(GetAction)												 \
		(THIS_	ULONG						ulActionNumber,				 \
				LARGE_INTEGER	*			lpruleid,					 \
				LPACTION FAR *				lppAction) IPURE;

#define EXPENTRY CALLBACK

#define EXPORTAPI __declspec( dllexport )HRESULT

#define EXT_SNAPINMENUID(id) public: \
	static const UINT GetMenuID() \
	{ \
		static const UINT IDMENU = id; \
		return id; \
	}

#define EXTENSION_SNAPIN_DATACLASS(dataClass) dataClass m_##dataClass;

#define EXTENSION_SNAPIN_NODEINFO_ENTRY(dataClass) if (IsEqualGUID(guid, *(GUID*)m_##dataClass.GetNodeType())) \
		{ \
			*ppItem = m_##dataClass.GetExtNodeObject(pDataObject, &m_##dataClass); \
			_ASSERTE(*ppItem != NULL); \
			(*ppItem)->InitDataClass(pDataObject, &m_##dataClass); \
			return hr; \
		}

#define EXTERN_C extern "C"

#define EXTERN_C_BEGIN extern "C" {

#define EXTERN_C_END }

#define EXTERN_GUID(itf,l1,s1,s2,c1,c2,c3,c4,c5,c6,c7,c8) EXTERN_C const IID itf

#define EXTERN_PROCESS_LOCAL(class_name, ident_name) extern AFX_DATA PROCESS_LOCAL(class_name, ident_name)

#define EXTERN_PROXY_FILE(name) EXTERN_C const ProxyFileInfo name##_ProxyFileInfo;

#define EXTERN_THREAD_LOCAL(class_name, ident_name) extern AFX_DATA THREAD_LOCAL(class_name, ident_name)

#define far 

#define FAR 

#define huge 

#define HUGE 

#define HUGE_VAL _HUGE

#define IAPP(T) __IAPP_##T

#define IMANIP(T) __IMANIP_##T

#define IMPL_THUNK(n) __declspec(naked) inline HRESULT _QIThunk::f##n() \
{ \
	__asm mov eax, [esp+4] \
	__asm cmp dword ptr [eax+8], 0 \
	__asm jg goodref \
	__asm call atlBadThunkCall \
	__asm goodref: \
	__asm mov eax, [esp+4] \
	__asm mov eax, dword ptr [eax+4] \
	__asm mov [esp+4], eax \
	__asm mov eax, dword ptr [eax] \
	__asm mov eax, dword ptr [eax+4*n] \
	__asm jmp eax \
}

#define IMPLEMENT_BOOL_STOCKPROP(fname, pname, dispid) HRESULT STDMETHODCALLTYPE put_##fname(VARIANT_BOOL pname) \
	{ \
		ATLTRACE2(atlTraceControls,2,_T("CStockPropImpl::put_%s\n"), #fname); \
		T* pT = (T*) this; \
		if (pT->FireOnRequestEdit(dispid) == S_FALSE) \
			return S_FALSE; \
		pT->m_##pname = pname; \
		pT->m_bRequiresSave = TRUE; \
		pT->FireOnChanged(dispid); \
		pT->FireViewChange(); \
		pT->SendOnDataChange(NULL); \
		return S_OK; \
	} \
	HRESULT STDMETHODCALLTYPE get_##fname(VARIANT_BOOL* p##pname) \
	{ \
		ATLTRACE2(atlTraceControls,2,_T("CStockPropImpl::get_%s\n"), #fname); \
		T* pT = (T*) this; \
		*p##pname = pT->m_##pname ? VARIANT_TRUE : VARIANT_FALSE; \
		return S_OK; \
	}

#define IMPLEMENT_BSTR_STOCKPROP(fname, pname, dispid) HRESULT STDMETHODCALLTYPE put_##fname(BSTR pname) \
	{ \
		ATLTRACE2(atlTraceControls,2,_T("CStockPropImpl::put_%s\n"), #fname); \
		T* pT = (T*) this; \
		if (pT->FireOnRequestEdit(dispid) == S_FALSE) \
			return S_FALSE; \
		if (*(&(pT->m_##pname)) != NULL) \
			SysFreeString(*(&(pT->m_##pname))); \
		*(&(pT->m_##pname)) = SysAllocString(pname); \
		pT->m_bRequiresSave = TRUE; \
		pT->FireOnChanged(dispid); \
		pT->FireViewChange(); \
		pT->SendOnDataChange(NULL); \
		return S_OK; \
	} \
	HRESULT STDMETHODCALLTYPE get_##fname(BSTR* p##pname) \
	{ \
		ATLTRACE2(atlTraceControls,2,_T("CStockPropImpl::get_%s\n"), #fname); \
		T* pT = (T*) this; \
		*p##pname = SysAllocString(pT->m_##pname); \
		return S_OK; \
	}

#define IMPLEMENT_DYNAMIC(class_name, base_class_name) _IMPLEMENT_RUNTIMECLASS(class_name, base_class_name, 0xFFFF, NULL)

#define IMPLEMENT_DYNCREATE(class_name, base_class_name) CObject* PASCAL class_name::CreateObject() \
		{ return new class_name; } \
	_IMPLEMENT_RUNTIMECLASS(class_name, base_class_name, 0xFFFF, \
		class_name::CreateObject)

#define IMPLEMENT_OLECREATE(class_name, external_name, l, w1, w2, b1, b2, b3, b4, b5, b6, b7, b8) AFX_DATADEF COleObjectFactory class_name::factory(class_name::guid, \
		RUNTIME_CLASS(class_name), FALSE, _T(external_name)); \
	const AFX_DATADEF GUID class_name::guid = \
		{ l, w1, w2, { b1, b2, b3, b4, b5, b6, b7, b8 } };

#define IMPLEMENT_OLECREATE_EX (class_name, external_name, \
			l, w1, w2, b1, b2, b3, b4, b5, b6, b7, b8) \
	static const TCHAR _szProgID_##class_name[] = _T(external_name); \
	AFX_DATADEF class_name::class_name##Factory class_name::factory( \
		class_name::guid, RUNTIME_CLASS(class_name), FALSE, \
		_szProgID_##class_name); \
	const AFX_DATADEF GUID class_name::guid = \
		{ l, w1, w2, { b1, b2, b3, b4, b5, b6, b7, b8 } }; \
	HRESULT class_name::GetClassID(LPCLSID pclsid) \
		{ *pclsid = guid; return NOERROR; }

#define IMPLEMENT_OLECTLTYPE(class_name, idsUserTypeName, dwOleMisc) UINT class_name::GetUserTypeNameID() { return idsUserTypeName; } \
	DWORD class_name::GetMiscStatus() { return dwOleMisc; }

#define IMPLEMENT_OLETYPELIB(class_name, tlid, wVerMajor, wVerMinor) UINT class_name::GetTypeInfoCount() \
		{ return 1; } \
	HRESULT class_name::GetTypeLib(LCID lcid, LPTYPELIB* ppTypeLib) \
		{ return ::LoadRegTypeLib(tlid, wVerMajor, wVerMinor, lcid, ppTypeLib); } \
	CTypeLibCache* class_name::GetTypeLibCache() \
		{ return AfxGetTypeLibCache(&tlid); }

#define IMPLEMENT_RUNTIMECLASS(class_name, base_class_name, wSchema, pfnNew) CRuntimeClass *PASCAL class_name::_GetBaseClass(){return RUNTIME_CLASS(base_class_name);}AFX_COMDAT const AFX_DATADEF CRuntimeClass class_name::class##class_name={#class_name,sizeof(class class_name),wSchema,pfnNew,&class_name::_GetBaseClass,NULL};CRuntimeClass *class_name::GetRuntimeClass() const{return RUNTIME_CLASS(class_name);}

#define IMPLEMENT_SERIAL(class_name, base_class_name, wSchema) CObject* PASCAL class_name::CreateObject() \
		{ return new class_name; } \
	_IMPLEMENT_RUNTIMECLASS(class_name, base_class_name, wSchema, \
		class_name::CreateObject) \
	CArchive& AFXAPI operator>>(CArchive& ar, class_name* &pOb) \
		{ pOb = (class_name*) ar.ReadObject(RUNTIME_CLASS(class_name)); \
			return ar; }

#define IMPLEMENT_STOCKPROP(type, fname, pname, dispid) HRESULT STDMETHODCALLTYPE put_##fname(type pname) \
	{ \
		ATLTRACE2(atlTraceControls,2,_T("CStockPropImpl::put_%s\n"), #fname); \
		T* pT = (T*) this; \
		if (pT->FireOnRequestEdit(dispid) == S_FALSE) \
			return S_FALSE; \
		pT->m_##pname = pname; \
		pT->m_bRequiresSave = TRUE; \
		pT->FireOnChanged(dispid); \
		pT->FireViewChange(); \
		pT->SendOnDataChange(NULL); \
		return S_OK; \
	} \
	HRESULT STDMETHODCALLTYPE get_##fname(type* p##pname) \
	{ \
		ATLTRACE2(atlTraceControls,2,_T("CStockPropImpl::get_%s\n"), #fname); \
		T* pT = (T*) this; \
		*p##pname = pT->m_##pname; \
		return S_OK; \
	}

#define IN 

#define INIT_INTERFACE_PART(theClass, localClass) size_t m_nOffset; \
		INIT_INTERFACE_PART_DERIVE(theClass, localClass)

#define INIT_INTERFACE_PART_DERIVE(theClass, localClass) X##localClass() \
			{ m_nOffset = offsetof(theClass, m_x##localClass); }

#define interface struct

#define IOAPP(T) __IOAPP_##T

#define IOMANIP(T) __IOMANIP_##T

#define IOMANIPdeclare(T) class SMANIP(T) { \
public:	 \
	SMANIP(T)(ios& (*f)(ios&,T), T t) { _fp = f; _tp = t; } \
	friend istream& operator>>(istream& s, const SMANIP(T) & sm) { (*(sm._fp))(s,sm._tp); return s; } \
	friend ostream& operator<<(ostream& s, const SMANIP(T) & sm) { (*(sm._fp))(s,sm._tp); return s; } \
private:	 \
	ios& (* _fp)(ios&,T); \
	T _tp; \
};	\
class SAPP(T) {	 \
public:	 \
	SAPP(T)( ios& (*f)(ios&,T)) { _fp = f; }	 \
	SMANIP(T) operator()(T t) { return SMANIP(T)(_fp,t); } 	 \
private:	 \
	ios& (* _fp)(ios&,T); \
};	 \
class IMANIP(T) { \
public:	 \
	IMANIP(T)(istream& (*f)(istream&,T), T t) { _fp = f; _tp = t; } \
	friend istream& operator>>(istream& s, IMANIP(T) & sm) { (*sm._fp)(s,sm._tp); return s; } \
private:	 \
	istream& (* _fp)(istream&,T); \
	T _tp;	 \
};	 \
class IAPP(T) {	 \
public:	 \
	IAPP(T)( istream& (*f)(istream&,T)) { _fp = f; }	 \
	IMANIP(T) operator()(T t) { return IMANIP(T)(_fp,t); } 	 \
private:	 \
	istream& (* _fp)(istream&,T); \
};	 \
class OMANIP(T) { \
public:	 \
	OMANIP(T)(ostream& (*f)(ostream&,T), T t) { _fp = f; _tp = t; } \
	friend ostream& operator<<(ostream& s, OMANIP(T) & sm) { (*sm._fp)(s,sm._tp); return s; } \
private:	 \
	ostream& (* _fp)(ostream&,T); \
	T _tp; \
};	 \
class OAPP(T) {	 \
public:	 \
	OAPP(T)(ostream& (*f)(ostream&,T)) { _fp = f; }	 \
	OMANIP(T) operator()(T t) { return OMANIP(T)(_fp,t); } \
private:	 \
	ostream& (* _fp)(ostream&,T); \
};	 \
class IOMANIP(T) { \
public:	 \
	IOMANIP(T)(iostream& (*f)(iostream&,T), T t) { _fp = f; _tp = t; } \
	friend istream& operator>>(iostream& s, IOMANIP(T) & sm) { (*sm._fp)(s,sm._tp); return s; } \
	friend ostream& operator<<(iostream& s, IOMANIP(T) & sm) { (*sm._fp)(s,sm._tp); return s; } \
private:	 \
	iostream& (* _fp)(iostream&,T); \
	T _tp; \
};	 \
class IOAPP(T) {	 \
public:	 \
	IOAPP(T)( iostream& (*f)(iostream&,T)) { _fp = f; }	 \
	IOMANIP(T) operator()(T t) { return IOMANIP(T)(_fp,t); } 	 \
private:	 \
	iostream& (* _fp)(iostream&,T); \
};

#define IPTR(x) CIP<x, &IID_##x>

#define JAVACLASS(str) custom(TLBATTR_JAVACLASS,str)

// Some Tornado defines
#define local static

#define LOCAL static

#undef MAC 

#define make_a_proto(name) interface int name(int a1_##name, int a2_##name) const PURE;

#define MAKE_ENUM(Method, Interface) Interface##_##Method

#define MAKE_SIG(a, b, c, d) MAKE_LONG(MAKE_WORD(a, b), MAKE_WORD(c, d))

/*------------------------------------------------------------------------
 *
 *	Errors returned by Exchange Incremental Change Synchronization Interface
 *
 *-----------------------------------------------------------------------*/

#define MAKE_SYNC_E(err) (MAKE_SCODE(SEVERITY_ERROR, FACILITY_ITF, err))

#define MAKE_SYNC_W(warn) (MAKE_SCODE(SEVERITY_SUCCESS, FACILITY_ITF, warn))

#define MAPI_IABCONTAINER_METHODS(IPURE) MAPIMETHOD(CreateEntry) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                ULONG                       ulCreateFlags, \
                LPMAPIPROP FAR  *           lppMAPIPropEntry) IPURE; \
    MAPIMETHOD(CopyEntries) \
        (THIS_  LPENTRYLIST                 lpEntries, \
                ULONG                       ulUIParam, \
                LPMAPIPROGRESS              lpProgress, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(DeleteEntries) \
        (THIS_  LPENTRYLIST                 lpEntries, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(ResolveNames) \
        (THIS_  LPSPropTagArray             lpPropTagArray, \
                ULONG                       ulFlags, \
                LPADRLIST                   lpAdrList, \
                LPFlagList                  lpFlagList) IPURE;

#define MAPI_IABLOGON_METHODS(IPURE) MAPIMETHOD(GetLastError) \
        (THIS_  HRESULT                     hResult, \
                ULONG                       ulFlags, \
                LPMAPIERROR FAR *           lppMAPIError) IPURE; \
    MAPIMETHOD(Logoff) \
        (THIS_  ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(OpenEntry) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulObjType, \
                LPUNKNOWN FAR *             lppUnk) IPURE; \
    MAPIMETHOD(CompareEntryIDs) \
        (THIS_  ULONG                       cbEntryID1, \
                LPENTRYID                   lpEntryID1, \
                ULONG                       cbEntryID2, \
                LPENTRYID                   lpEntryID2, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulResult) IPURE; \
    MAPIMETHOD(Advise) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                ULONG                       ulEventMask, \
                LPMAPIADVISESINK            lpAdviseSink, \
                ULONG FAR *                 lpulConnection) IPURE; \
    MAPIMETHOD(Unadvise) \
        (THIS_  ULONG                       ulConnection) IPURE; \
    MAPIMETHOD(OpenStatusEntry) \
        (THIS_  LPCIID                       lpInterface, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulObjType, \
                LPMAPISTATUS FAR *          lppEntry) IPURE; \
    MAPIMETHOD(OpenTemplateID) \
        (THIS_  ULONG                       cbTemplateID, \
                LPENTRYID                   lpTemplateID, \
                ULONG                       ulTemplateFlags, \
                LPMAPIPROP                  lpMAPIPropData, \
                LPCIID                       lpInterface, \
                LPMAPIPROP FAR *            lppMAPIPropNew, \
                LPMAPIPROP                  lpMAPIPropSibling) IPURE; \
    MAPIMETHOD(GetOneOffTable) \
        (THIS_  ULONG                       ulFlags, \
                LPMAPITABLE FAR *           lppTable) IPURE; \
    MAPIMETHOD(PrepareRecips) \
        (THIS_  ULONG                       ulFlags, \
                LPSPropTagArray             lpPropTagArray, \
                LPADRLIST                   lpRecipList) IPURE;

#define MAPI_IABPROVIDER_METHODS(IPURE) MAPIMETHOD(Shutdown) \
        (THIS_  ULONG FAR *                 lpulFlags) IPURE; \
    MAPIMETHOD(Logon) \
        (THIS_  LPMAPISUP                   lpMAPISup, \
                ULONG                       ulUIParam, \
                LPTSTR                      lpszProfileName, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulpcbSecurity, \
                LPBYTE FAR *                lppbSecurity, \
                LPMAPIERROR FAR *           lppMAPIError, \
                LPABLOGON FAR *             lppABLogon) IPURE;

#define MAPI_IADDRBOOK_METHODS(IPURE) MAPIMETHOD(OpenEntry) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulObjType, \
                LPUNKNOWN FAR *             lppUnk) IPURE; \
    MAPIMETHOD(CompareEntryIDs) \
        (THIS_  ULONG                       cbEntryID1, \
                LPENTRYID                   lpEntryID1, \
                ULONG                       cbEntryID2, \
                LPENTRYID                   lpEntryID2, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulResult) IPURE; \
    MAPIMETHOD(Advise) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                ULONG                       ulEventMask, \
                LPMAPIADVISESINK            lpAdviseSink, \
                ULONG FAR *                 lpulConnection) IPURE; \
    MAPIMETHOD(Unadvise) \
        (THIS_  ULONG                       ulConnection) IPURE; \
    MAPIMETHOD(CreateOneOff) \
        (THIS_  LPTSTR                      lpszName, \
                LPTSTR                      lpszAdrType, \
                LPTSTR                      lpszAddress, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpcbEntryID, \
                LPENTRYID FAR *             lppEntryID) IPURE; \
    MAPIMETHOD(NewEntry) \
        (THIS_  ULONG                       ulUIParam, \
                ULONG                       ulFlags, \
                ULONG                       cbEIDContainer, \
                LPENTRYID                   lpEIDContainer, \
                ULONG                       cbEIDNewEntryTpl, \
                LPENTRYID                   lpEIDNewEntryTpl, \
                ULONG FAR *                 lpcbEIDNewEntry, \
                LPENTRYID FAR *             lppEIDNewEntry) IPURE; \
    MAPIMETHOD(ResolveName) \
        (THIS_  ULONG                       ulUIParam, \
                ULONG                       ulFlags, \
                LPTSTR                      lpszNewEntryTitle, \
                LPADRLIST                   lpAdrList) IPURE; \
    MAPIMETHOD(Address) \
        (THIS_  ULONG FAR *                 lpulUIParam, \
                LPADRPARM                   lpAdrParms, \
                LPADRLIST FAR *             lppAdrList) IPURE; \
    MAPIMETHOD(Details) \
        (THIS_  ULONG FAR *                 lpulUIParam, \
                LPFNDISMISS                 lpfnDismiss, \
                LPVOID                      lpvDismissContext, \
                ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                LPFNBUTTON                  lpfButtonCallback, \
                LPVOID                      lpvButtonContext, \
                LPTSTR                      lpszButtonText, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(RecipOptions) \
        (THIS_  ULONG                       ulUIParam, \
                ULONG                       ulFlags, \
                LPADRENTRY                  lpRecip) IPURE; \
    MAPIMETHOD(QueryDefaultRecipOpt) \
        (THIS_  LPTSTR                      lpszAdrType, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpcValues, \
                LPSPropValue FAR *          lppOptions) IPURE; \
    MAPIMETHOD(GetPAB) \
        (THIS_  ULONG FAR *                 lpcbEntryID, \
                LPENTRYID FAR *             lppEntryID) IPURE; \
    MAPIMETHOD(SetPAB) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID) IPURE; \
    MAPIMETHOD(GetDefaultDir) \
        (THIS_  ULONG FAR *                 lpcbEntryID, \
                LPENTRYID FAR *             lppEntryID) IPURE; \
    MAPIMETHOD(SetDefaultDir) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID) IPURE; \
    MAPIMETHOD(GetSearchPath) \
        (THIS_  ULONG                       ulFlags, \
                LPSRowSet FAR *             lppSearchPath) IPURE; \
    MAPIMETHOD(SetSearchPath) \
        (THIS_  ULONG                       ulFlags, \
                LPSRowSet                   lpSearchPath) IPURE; \
    MAPIMETHOD(PrepareRecips) \
        (THIS_  ULONG                       ulFlags, \
                LPSPropTagArray             lpPropTagArray, \
                LPADRLIST                   lpRecipList) IPURE;

/* IDistList Interface ----------------------------------------------------- */


#define MAPI_IDISTLIST_METHODS(IPURE) MAPIMETHOD(CreateEntry) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                ULONG                       ulCreateFlags, \
                LPMAPIPROP FAR  *           lppMAPIPropEntry) IPURE; \
    MAPIMETHOD(CopyEntries) \
        (THIS_  LPENTRYLIST                 lpEntries, \
                ULONG                       ulUIParam, \
                LPMAPIPROGRESS              lpProgress, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(DeleteEntries) \
        (THIS_  LPENTRYLIST                 lpEntries, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(ResolveNames) \
        (THIS_  LPSPropTagArray             lpPropTagArray, \
                ULONG                       ulFlags, \
                LPADRLIST                   lpAdrList, \
                LPFlagList                  lpFlagList) IPURE;

/* Interface used for registering and issuing notification callbacks. */


#define MAPI_IMAPIADVISESINK_METHODS(IPURE) MAPIMETHOD_(ULONG, OnNotify) \
        (THIS_  ULONG                       cNotif, \
                LPNOTIFICATION              lpNotifications) IPURE;

#define MAPI_IMAPICONTAINER_METHODS(IPURE) MAPIMETHOD(GetContentsTable) \
        (THIS_  ULONG                       ulFlags, \
                LPMAPITABLE FAR *           lppTable) IPURE; \
    MAPIMETHOD(GetHierarchyTable) \
        (THIS_  ULONG                       ulFlags, \
                LPMAPITABLE FAR *           lppTable) IPURE; \
    MAPIMETHOD(OpenEntry) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulObjType, \
                LPUNKNOWN FAR *             lppUnk) IPURE; \
    MAPIMETHOD(SetSearchCriteria) \
        (THIS_  LPSRestriction              lpRestriction, \
                LPENTRYLIST                 lpContainerList, \
                ULONG                       ulSearchFlags) IPURE; \
    MAPIMETHOD(GetSearchCriteria) \
        (THIS_  ULONG                       ulFlags, \
                LPSRestriction FAR *        lppRestriction, \
                LPENTRYLIST FAR *           lppContainerList, \
                ULONG FAR *                 lpulSearchState)IPURE;

#define MAPI_IMAPICONTROL_METHODS(IPURE) MAPIMETHOD(GetLastError) \
        (THIS_  HRESULT                     hResult, \
                ULONG                       ulFlags, \
                LPMAPIERROR FAR *           lppMAPIError) IPURE; \
    MAPIMETHOD(Activate) \
        (THIS_  ULONG                       ulFlags, \
                ULONG                       ulUIParam) IPURE; \
    MAPIMETHOD(GetState) \
        (THIS_  ULONG                       ulFlags, \
                ULONG FAR *                 lpulState) IPURE;

#define MAPI_IMAPIFOLDER_METHODS(IPURE) MAPIMETHOD(CreateMessage) \
        (THIS_  LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                LPMESSAGE FAR *             lppMessage) IPURE; \
    MAPIMETHOD(CopyMessages) \
        (THIS_  LPENTRYLIST                 lpMsgList, \
                LPCIID                      lpInterface, \
                LPVOID                      lpDestFolder, \
                ULONG                       ulUIParam, \
                LPMAPIPROGRESS              lpProgress, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(DeleteMessages) \
        (THIS_  LPENTRYLIST                 lpMsgList, \
                ULONG                       ulUIParam, \
                LPMAPIPROGRESS              lpProgress, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(CreateFolder) \
        (THIS_  ULONG                       ulFolderType, \
                LPTSTR                      lpszFolderName, \
                LPTSTR                      lpszFolderComment, \
                LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                LPMAPIFOLDER FAR *          lppFolder) IPURE; \
    MAPIMETHOD(CopyFolder) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                LPCIID                      lpInterface, \
                LPVOID                      lpDestFolder, \
                LPTSTR                      lpszNewFolderName, \
                ULONG                       ulUIParam, \
                LPMAPIPROGRESS              lpProgress, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(DeleteFolder) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                ULONG                       ulUIParam, \
                LPMAPIPROGRESS              lpProgress, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(SetReadFlags) \
        (THIS_  LPENTRYLIST                 lpMsgList, \
                ULONG                       ulUIParam, \
                LPMAPIPROGRESS              lpProgress, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(GetMessageStatus) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulMessageStatus) IPURE; \
    MAPIMETHOD(SetMessageStatus) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                ULONG                       ulNewStatus, \
                ULONG                       ulNewStatusMask, \
                ULONG FAR *                 lpulOldStatus) IPURE; \
    MAPIMETHOD(SaveContentsSort) \
        (THIS_  LPSSortOrderSet             lpSortCriteria, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(EmptyFolder) \
        (THIS_  ULONG                       ulUIParam, \
                LPMAPIPROGRESS              lpProgress, \
                ULONG                       ulFlags) IPURE;

#define MAPI_IMAPIFORM_METHODS(IPURE) MAPIMETHOD(SetViewContext) (THIS_ \
        /*in*/  LPMAPIVIEWCONTEXT pViewContext) IPURE; \
    MAPIMETHOD(GetViewContext) (THIS_ \
        /*out*/ LPMAPIVIEWCONTEXT FAR * ppViewContext) IPURE; \
    MAPIMETHOD(ShutdownForm)(THIS_ \
        /*in*/  ULONG ulSaveOptions) IPURE; \
    MAPIMETHOD(DoVerb) (THIS_ \
        /*in*/  LONG iVerb, \
        /*in*/  LPMAPIVIEWCONTEXT lpViewContext, /* can be null */ \
        /*in*/  ULONG hwndParent, \
        /*in*/  LPCRECT lprcPosRect) IPURE; \
    MAPIMETHOD(Advise)(THIS_ \
        /*in*/  LPMAPIVIEWADVISESINK pAdvise, \
        /*out*/ ULONG FAR * pdwStatus) IPURE; \
    MAPIMETHOD(Unadvise) (THIS_ \
        /*in*/  ULONG ulConnection) IPURE;

#define MAPI_IMAPIFORMADVISESINK_METHODS(IPURE) STDMETHOD(OnChange)(THIS_ ULONG ulDir) IPURE; \
    STDMETHOD(OnActivateNext)(THIS_ \
        /*in*/  LPCSTR lpszMessageClass, \
        /*in*/  ULONG ulMessageStatus, \
        /*in*/  ULONG ulMessageFlags, \
        /*out*/ LPPERSISTMESSAGE FAR * ppPersistMessage) IPURE;

#define MAPI_IMAPIFORMCONTAINER_METHODS(IPURE) MAPIMETHOD(InstallForm)(THIS_ \
        /*in*/  ULONG ulUIParam, \
        /*in*/  ULONG ulFlags, \
        /*in*/  LPCTSTR szCfgPathName) IPURE; \
    MAPIMETHOD(RemoveForm)(THIS_ \
        /*in*/  LPCSTR szMessageClass) IPURE; \
    MAPIMETHOD(ResolveMessageClass) (THIS_ \
        /*in*/  LPCSTR szMessageClass, \
        /*in*/  ULONG ulFlags, \
        /*out*/ LPMAPIFORMINFO FAR * pforminfo) IPURE; \
    MAPIMETHOD(ResolveMultipleMessageClasses) (THIS_ \
        /*in*/  LPSMESSAGECLASSARRAY pMsgClassArray, \
        /*in*/  ULONG ulFlags, \
        /*out*/ LPSMAPIFORMINFOARRAY FAR * ppfrminfoarray) IPURE; \
    MAPIMETHOD(CalcFormPropSet)(THIS_ \
        /*in*/  ULONG ulFlags, \
        /*out*/ LPMAPIFORMPROPARRAY FAR * ppResults) IPURE; \
    MAPIMETHOD(GetDisplay)(THIS_ \
        /*in*/  ULONG ulFlags, \
        /*out*/ LPTSTR FAR * pszDisplayName) IPURE;

#define MAPI_IMAPIFORMFACTORY_METHODS(IPURE) MAPIMETHOD(CreateClassFactory) (THIS_ \
        /*in*/  REFCLSID clsidForm, \
        /*in*/  ULONG ulFlags, \
        /*out*/ LPCLASSFACTORY FAR * lppClassFactory) IPURE; \
    MAPIMETHOD(LockServer) (THIS_ \
        /*in*/  ULONG ulFlags, \
        /*in*/  ULONG fLockServer) IPURE;

#define MAPI_IMAPIFORMINFO_METHODS(IPURE) MAPIMETHOD(CalcFormPropSet)(THIS_ \
        /*in*/  ULONG ulFlags, \
        /*out*/ LPMAPIFORMPROPARRAY FAR * ppFormPropArray) IPURE; \
    MAPIMETHOD(CalcVerbSet)(THIS_ \
        /*in*/  ULONG ulFlags, \
        /*out*/ LPMAPIVERBARRAY FAR * ppMAPIVerbArray) IPURE; \
    MAPIMETHOD(MakeIconFromBinary)(THIS_ \
        /*in*/ ULONG nPropID, \
        /*out*/ HICON FAR* phicon) IPURE; \
    MAPIMETHOD(SaveForm)(THIS_ \
        /*in*/ LPCTSTR szFileName) IPURE; \
    MAPIMETHOD(OpenFormContainer)(THIS_ \
        /*out*/ LPMAPIFORMCONTAINER FAR * ppformcontainer) IPURE;

#define MAPI_IMAPIFORMMGR_METHODS(IPURE) MAPIMETHOD(LoadForm)(THIS_ \
        /*in*/  ULONG ulUIParam, \
        /*in*/  ULONG ulFlags, \
        /*in*/  LPCSTR lpszMessageClass, \
        /*in*/  ULONG ulMessageStatus, \
        /*in*/  ULONG ulMessageFlags, \
        /*in*/  LPMAPIFOLDER pFolderFocus, \
        /*in*/  LPMAPIMESSAGESITE pMessageSite, \
        /*in*/  LPMESSAGE pmsg, \
        /*in*/  LPMAPIVIEWCONTEXT pViewContext, \
        /*in*/  REFIID riid, \
        /*out*/ LPVOID FAR *ppvObj) IPURE; \
    MAPIMETHOD(ResolveMessageClass)(THIS_ \
        /*in*/  LPCSTR szMsgClass, \
        /*in*/  ULONG ulFlags, \
        /*in*/  LPMAPIFOLDER pFolderFocus, /* can be null */ \
        /*out*/ LPMAPIFORMINFO FAR* ppResult) IPURE; \
    MAPIMETHOD(ResolveMultipleMessageClasses)(THIS_ \
        /*in*/  LPSMESSAGECLASSARRAY pMsgClasses, \
        /*in*/  ULONG ulFlags, \
        /*in*/  LPMAPIFOLDER pFolderFocus, /* can be null */ \
        /*out*/ LPSMAPIFORMINFOARRAY FAR * pfrminfoarray) IPURE; \
    MAPIMETHOD(CalcFormPropSet)(THIS_ \
        /*in*/  LPSMAPIFORMINFOARRAY pfrminfoarray, \
        /*in*/  ULONG ulFlags, \
        /*out*/ LPMAPIFORMPROPARRAY FAR* ppResults) IPURE; \
    MAPIMETHOD(CreateForm)(THIS_ \
        /*in*/  ULONG ulUIParam, \
        /*in*/  ULONG ulFlags, \
        /*in*/  LPMAPIFORMINFO pfrminfoToActivate, \
        /*in*/  REFIID refiidToAsk, \
        /*out*/ LPVOID FAR* ppvObj) IPURE; \
    MAPIMETHOD(SelectForm)(THIS_ \
        /*in*/  ULONG ulUIParam, \
        /*in*/  ULONG ulFlags, \
        /*in*/  LPCTSTR pszTitle, \
        /*in*/  LPMAPIFOLDER pfld, \
        /*out*/ LPMAPIFORMINFO FAR * ppfrminfoReturned) IPURE; \
    MAPIMETHOD(SelectMultipleForms)(THIS_ \
        /*in*/  ULONG ulUIParam, \
        /*in*/  ULONG ulFlags, \
        /*in*/  LPCTSTR pszTitle, \
        /*in*/  LPMAPIFOLDER pfld, \
        /*in*/  LPSMAPIFORMINFOARRAY pfrminfoarray, \
        /*out*/ LPSMAPIFORMINFOARRAY FAR * ppfrminfoarray) IPURE; \
    MAPIMETHOD(SelectFormContainer)(THIS_ \
        /*in*/  ULONG ulUIParam, \
        /*in*/  ULONG ulFlags, \
        /*out*/ LPMAPIFORMCONTAINER FAR * lppfcnt) IPURE; \
    MAPIMETHOD(OpenFormContainer)(THIS_ \
        /*in*/  HFRMREG hfrmreg, \
        /*in*/  LPUNKNOWN lpunk, \
        /*out*/ LPMAPIFORMCONTAINER FAR * lppfcnt) IPURE; \
    MAPIMETHOD(PrepareForm)(THIS_ \
        /*in*/  ULONG ulUIParam, \
        /*in*/  ULONG ulFlags, \
        /*in*/  LPMAPIFORMINFO pfrminfo) IPURE; \
    MAPIMETHOD(IsInConflict)(THIS_ \
        /*in*/  ULONG ulMessageFlags, \
        /*in*/  ULONG ulMessageStatus, \
        /*in*/  LPCSTR szMessageClass, \
        /*in*/  LPMAPIFOLDER pFolderFocus) IPURE;

/*-- IMAPIMessageSite ------------------------------------------------------*/


#define MAPI_IMAPIMESSAGESITE_METHODS(IPURE) MAPIMETHOD(GetSession) (THIS_ \
        /*out*/ LPMAPISESSION FAR * ppSession) IPURE; \
    MAPIMETHOD(GetStore) (THIS_ \
        /*out*/ LPMDB FAR * ppStore) IPURE; \
    MAPIMETHOD(GetFolder) (THIS_ \
        /*out*/ LPMAPIFOLDER FAR * ppFolder) IPURE; \
    MAPIMETHOD(GetMessage) (THIS_ \
        /*out*/ LPMESSAGE FAR * ppmsg) IPURE; \
    MAPIMETHOD(GetFormManager) (THIS_ \
        /*out*/ LPMAPIFORMMGR FAR * ppFormMgr) IPURE; \
    MAPIMETHOD(NewMessage) (THIS_ \
        /*in*/  ULONG fComposeInFolder, \
        /*in*/  LPMAPIFOLDER pFolderFocus, \
        /*in*/  LPPERSISTMESSAGE pPersistMessage, \
        /*out*/ LPMESSAGE FAR * ppMessage, \
        /*out*/ LPMAPIMESSAGESITE FAR * ppMessageSite, \
        /*out*/ LPMAPIVIEWCONTEXT FAR * ppViewContext) IPURE; \
    MAPIMETHOD(CopyMessage) (THIS_ \
        /*in*/  LPMAPIFOLDER pFolderDestination) IPURE; \
    MAPIMETHOD(MoveMessage) (THIS_ \
        /*in*/  LPMAPIFOLDER pFolderDestination, \
        /*in*/  LPMAPIVIEWCONTEXT pViewContext, \
        /*in*/  LPCRECT prcPosRect) IPURE; \
    MAPIMETHOD(DeleteMessage) (THIS_ \
        /*in*/  LPMAPIVIEWCONTEXT pViewContext, \
        /*in*/  LPCRECT prcPosRect) IPURE; \
    MAPIMETHOD(SaveMessage) (THIS) IPURE; \
    MAPIMETHOD(SubmitMessage) (THIS_ \
        /*in*/ ULONG ulFlags) IPURE; \
    MAPIMETHOD(GetSiteStatus) (THIS_ \
        /*out*/ LPULONG lpulStatus) IPURE;

#define MAPI_IMAPIPROGRESS_METHODS(IPURE) MAPIMETHOD(Progress) \
        (THIS_  ULONG                       ulValue, \
                ULONG                       ulCount, \
                ULONG                       ulTotal) IPURE; \
    MAPIMETHOD(GetFlags) \
        (THIS_  ULONG FAR *                 lpulFlags) IPURE; \
    MAPIMETHOD(GetMax) \
        (THIS_  ULONG FAR *                 lpulMax) IPURE; \
    MAPIMETHOD(GetMin) \
        (THIS_  ULONG FAR *                 lpulMin) IPURE; \
    MAPIMETHOD(SetLimits) \
        (THIS_  LPULONG                     lpulMin, \
                LPULONG                     lpulMax, \
                LPULONG                     lpulFlags) IPURE;

#define MAPI_IMAPIPROP_METHODS(IPURE) MAPIMETHOD(GetLastError) \
        (THIS_  HRESULT                     hResult, \
                ULONG                       ulFlags, \
                LPMAPIERROR FAR *           lppMAPIError) IPURE; \
    MAPIMETHOD(SaveChanges) \
        (THIS_ ULONG                        ulFlags) IPURE; \
    MAPIMETHOD(GetProps) \
        (THIS_  LPSPropTagArray             lpPropTagArray, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpcValues, \
                LPSPropValue FAR *          lppPropArray) IPURE; \
    MAPIMETHOD(GetPropList) \
        (THIS_  ULONG                       ulFlags, \
                LPSPropTagArray FAR *       lppPropTagArray) IPURE; \
    MAPIMETHOD(OpenProperty) \
        (THIS_  ULONG                       ulPropTag, \
                LPCIID                      lpiid, \
                ULONG                       ulInterfaceOptions, \
                ULONG                       ulFlags, \
                LPUNKNOWN FAR *             lppUnk) IPURE; \
    MAPIMETHOD(SetProps) \
        (THIS_  ULONG                       cValues, \
                LPSPropValue                lpPropArray, \
                LPSPropProblemArray FAR *   lppProblems) IPURE; \
    MAPIMETHOD(DeleteProps) \
        (THIS_  LPSPropTagArray             lpPropTagArray, \
                LPSPropProblemArray FAR *   lppProblems) IPURE; \
    MAPIMETHOD(CopyTo) \
        (THIS_  ULONG                       ciidExclude, \
                LPCIID                      rgiidExclude, \
                LPSPropTagArray             lpExcludeProps, \
                ULONG                       ulUIParam, \
                LPMAPIPROGRESS              lpProgress, \
                LPCIID                      lpInterface, \
                LPVOID                      lpDestObj, \
                ULONG                       ulFlags, \
                LPSPropProblemArray FAR *   lppProblems) IPURE; \
    MAPIMETHOD(CopyProps) \
        (THIS_  LPSPropTagArray             lpIncludeProps, \
                ULONG                       ulUIParam, \
                LPMAPIPROGRESS              lpProgress, \
                LPCIID                      lpInterface, \
                LPVOID                      lpDestObj, \
                ULONG                       ulFlags, \
                LPSPropProblemArray FAR *   lppProblems) IPURE; \
    MAPIMETHOD(GetNamesFromIDs) \
        (THIS_  LPSPropTagArray FAR *       lppPropTags, \
                LPGUID                      lpPropSetGuid, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpcPropNames, \
                LPMAPINAMEID FAR * FAR *    lpppPropNames) IPURE; \
    MAPIMETHOD(GetIDsFromNames) \
        (THIS_  ULONG                       cPropNames, \
                LPMAPINAMEID FAR *          lppPropNames, \
                ULONG                       ulFlags, \
                LPSPropTagArray FAR *       lppPropTags) IPURE;

#define MAPI_IMAPISESSION_METHODS(IPURE) MAPIMETHOD(GetLastError) \
        (THIS_  HRESULT                     hResult, \
                ULONG                       ulFlags, \
                LPMAPIERROR FAR *           lppMAPIError) IPURE; \
    MAPIMETHOD(GetMsgStoresTable) \
        (THIS_  ULONG                       ulFlags, \
                LPMAPITABLE FAR *           lppTable) IPURE; \
    MAPIMETHOD(OpenMsgStore) \
        (THIS_  ULONG                       ulUIParam, \
                ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                LPMDB FAR *                 lppMDB) IPURE; \
    MAPIMETHOD(OpenAddressBook) \
        (THIS_  ULONG                       ulUIParam, \
                LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                LPADRBOOK FAR *             lppAdrBook) IPURE; \
    MAPIMETHOD(OpenProfileSection) \
        (THIS_  LPMAPIUID                   lpUID, \
                LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                LPPROFSECT FAR *            lppProfSect) IPURE; \
    MAPIMETHOD(GetStatusTable) \
        (THIS_  ULONG                       ulFlags, \
                LPMAPITABLE FAR *           lppTable) IPURE; \
    MAPIMETHOD(OpenEntry) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulObjType, \
                LPUNKNOWN FAR *             lppUnk) IPURE; \
    MAPIMETHOD(CompareEntryIDs) \
        (THIS_  ULONG                       cbEntryID1, \
                LPENTRYID                   lpEntryID1, \
                ULONG                       cbEntryID2, \
                LPENTRYID                   lpEntryID2, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulResult) IPURE; \
    MAPIMETHOD(Advise) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                ULONG                       ulEventMask, \
                LPMAPIADVISESINK            lpAdviseSink, \
                ULONG FAR *                 lpulConnection) IPURE; \
    MAPIMETHOD(Unadvise) \
        (THIS_  ULONG                       ulConnection) IPURE; \
    MAPIMETHOD(MessageOptions) \
        (THIS_  ULONG                       ulUIParam, \
                ULONG                       ulFlags, \
                LPTSTR                      lpszAdrType, \
                LPMESSAGE                   lpMessage) IPURE; \
    MAPIMETHOD(QueryDefaultMessageOpt) \
        (THIS_  LPTSTR                      lpszAdrType, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpcValues, \
                LPSPropValue FAR *          lppOptions) IPURE; \
    MAPIMETHOD(EnumAdrTypes) \
        (THIS_  ULONG                       ulFlags, \
                ULONG FAR *                 lpcAdrTypes, \
                LPTSTR FAR * FAR *          lpppszAdrTypes) IPURE; \
    MAPIMETHOD(QueryIdentity) \
        (THIS_  ULONG FAR *                 lpcbEntryID, \
                LPENTRYID FAR *             lppEntryID) IPURE; \
    MAPIMETHOD(Logoff) \
        (THIS_  ULONG                       ulUIParam, \
                ULONG                       ulFlags, \
                ULONG                       ulReserved) IPURE; \
    MAPIMETHOD(SetDefaultStore) \
        (THIS_  ULONG                       ulFlags, \
                ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID) IPURE; \
    MAPIMETHOD(AdminServices) \
        (THIS_  ULONG                       ulFlags, \
                LPSERVICEADMIN FAR *        lppServiceAdmin) IPURE; \
    MAPIMETHOD(ShowForm) \
        (THIS_  ULONG                       ulUIParam, \
                LPMDB                       lpMsgStore, \
                LPMAPIFOLDER                lpParentFolder, \
                LPCIID                      lpInterface, \
                ULONG                       ulMessageToken, \
                LPMESSAGE                   lpMessageSent, \
                ULONG                       ulFlags, \
                ULONG                       ulMessageStatus, \
                ULONG                       ulMessageFlags, \
                ULONG                       ulAccess, \
                LPSTR                       lpszMessageClass) IPURE; \
    MAPIMETHOD(PrepareForm) \
        (THIS_  LPCIID                      lpInterface, \
                LPMESSAGE                   lpMessage, \
                ULONG FAR *                 lpulMessageToken) IPURE;

#define MAPI_IMAPISTATUS_METHODS(IPURE) MAPIMETHOD(ValidateState) \
        (THIS_  ULONG                       ulUIParam, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(SettingsDialog) \
        (THIS_  ULONG                       ulUIParam, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(ChangePassword) \
        (THIS_  LPTSTR                      lpOldPass, \
                LPTSTR                      lpNewPass, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(FlushQueues) \
        (THIS_  ULONG                       ulUIParam, \
                ULONG                       cbTargetTransport, \
                LPENTRYID                   lpTargetTransport, \
                ULONG                       ulFlags) IPURE;

/* Function pointer for GetReleaseInfo */


#define MAPI_IMAPISUPPORT_METHODS1(IPURE) MAPIMETHOD(GetLastError) \
        (THIS_  HRESULT                     hResult, \
                ULONG                       ulFlags, \
                LPMAPIERROR FAR *           lppMAPIError) IPURE; \
    MAPIMETHOD(GetMemAllocRoutines) \
        (THIS_  LPALLOCATEBUFFER FAR *      lpAllocateBuffer, \
                LPALLOCATEMORE FAR *        lpAllocateMore, \
                LPFREEBUFFER FAR *          lpFreeBuffer) IPURE; \
    MAPIMETHOD(Subscribe) \
        (THIS_  LPNOTIFKEY                  lpKey, \
                ULONG                       ulEventMask, \
                ULONG                       ulFlags, \
                LPMAPIADVISESINK            lpAdviseSink, \
                ULONG FAR *                 lpulConnection) IPURE; \
    MAPIMETHOD(Unsubscribe) \
        (THIS_  ULONG                       ulConnection) IPURE; \
    MAPIMETHOD(Notify) \
        (THIS_  LPNOTIFKEY                  lpKey, \
                ULONG                       cNotification, \
                LPNOTIFICATION              lpNotifications, \
                ULONG FAR *                 lpulFlags) IPURE; \
    MAPIMETHOD(ModifyStatusRow) \
        (THIS_  ULONG                       cValues, \
                LPSPropValue                lpColumnVals, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(OpenProfileSection) \
        (THIS_  LPMAPIUID                   lpUid, \
                ULONG                       ulFlags, \
                LPPROFSECT FAR *            lppProfileObj) IPURE; \
    MAPIMETHOD(RegisterPreprocessor) \
        (THIS_  LPMAPIUID                   lpMuid, \
                LPTSTR                      lpszAdrType, \
                LPTSTR                      lpszDLLName, \
                LPSTR   /* String8! */      lpszPreprocess, \
                LPSTR   /* String8! */      lpszRemovePreprocessInfo, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(NewUID) \
        (THIS_  LPMAPIUID                   lpMuid) IPURE; \
    MAPIMETHOD(MakeInvalid) \
        (THIS_  ULONG                       ulFlags, \
                LPVOID                      lpObject, \
                ULONG                       ulRefCount, \
                ULONG                       cMethods) IPURE;

#define MAPI_IMAPISUPPORT_METHODS2(IPURE) MAPIMETHOD(SpoolerYield) \
        (THIS_  ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(SpoolerNotify) \
        (THIS_  ULONG                       ulFlags, \
                LPVOID                      lpvData) IPURE; \
    MAPIMETHOD(CreateOneOff) \
        (THIS_  LPTSTR                      lpszName, \
                LPTSTR                      lpszAdrType, \
                LPTSTR                      lpszAddress, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpcbEntryID, \
                LPENTRYID FAR *             lppEntryID) IPURE; \
    MAPIMETHOD(SetProviderUID) \
        (THIS_  LPMAPIUID                   lpProviderID, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(CompareEntryIDs) \
        (THIS_  ULONG                       cbEntry1, \
                LPENTRYID                   lpEntry1, \
                ULONG                       cbEntry2, \
                LPENTRYID                   lpEntry2, \
                ULONG                       ulCompareFlags, \
                ULONG FAR *                 lpulResult) IPURE; \
    MAPIMETHOD(OpenTemplateID) \
        (THIS_  ULONG                       cbTemplateID, \
                LPENTRYID                   lpTemplateID, \
                ULONG                       ulTemplateFlags, \
                LPMAPIPROP                  lpMAPIPropData, \
                LPCIID                      lpInterface, \
                LPMAPIPROP FAR *            lppMAPIPropNew, \
                LPMAPIPROP                  lpMAPIPropSibling) IPURE; \
    MAPIMETHOD(OpenEntry) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                LPCIID                      lpInterface, \
                ULONG                       ulOpenFlags, \
                ULONG FAR *                 lpulObjType, \
                LPUNKNOWN FAR *             lppUnk) IPURE; \
    MAPIMETHOD(GetOneOffTable) \
        (THIS_  ULONG                       ulFlags, \
                LPMAPITABLE FAR *           lppTable) IPURE; \
    MAPIMETHOD(Address) \
        (THIS_  ULONG FAR *                 lpulUIParam, \
                LPADRPARM                   lpAdrParms, \
                LPADRLIST FAR *             lppAdrList) IPURE; \
    MAPIMETHOD(Details) \
        (THIS_  ULONG FAR *                 lpulUIParam, \
                LPFNDISMISS                 lpfnDismiss, \
                LPVOID                      lpvDismissContext, \
                ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                LPFNBUTTON                  lpfButtonCallback, \
                LPVOID                      lpvButtonContext, \
                LPTSTR                      lpszButtonText, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(NewEntry) \
        (THIS_  ULONG                       ulUIParam, \
                ULONG                       ulFlags, \
                ULONG                       cbEIDContainer, \
                LPENTRYID                   lpEIDContainer, \
                ULONG                       cbEIDNewEntryTpl, \
                LPENTRYID                   lpEIDNewEntryTpl, \
                ULONG FAR *                 lpcbEIDNewEntry, \
                LPENTRYID FAR *             lppEIDNewEntry) IPURE; \
    MAPIMETHOD(DoConfigPropsheet) \
        (THIS_  ULONG                       ulUIParam, \
                ULONG                       ulFlags, \
                LPTSTR                      lpszTitle, \
                LPMAPITABLE                 lpDisplayTable, \
                LPMAPIPROP                  lpCOnfigData, \
                ULONG                       ulTopPage) IPURE; \
    MAPIMETHOD(CopyMessages) \
        (THIS_  LPCIID                      lpSrcInterface, \
                LPVOID                      lpSrcFolder, \
                LPENTRYLIST                 lpMsgList, \
                LPCIID                      lpDestInterface, \
                LPVOID                      lpDestFolder, \
                ULONG                       ulUIParam, \
                LPMAPIPROGRESS              lpProgress, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(CopyFolder) \
        (THIS_  LPCIID                      lpSrcInterface, \
                LPVOID                      lpSrcFolder, \
                ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                LPCIID                      lpDestInterface, \
                LPVOID                      lpDestFolder, \
                LPTSTR                      lszNewFolderName, \
                ULONG                       ulUIParam, \
                LPMAPIPROGRESS              lpProgress, \
                ULONG                       ulFlags) IPURE;

#define MAPI_IMAPISUPPORT_METHODS3(IPURE) MAPIMETHOD(DoCopyTo) \
        (THIS_  LPCIID                      lpSrcInterface, \
                LPVOID                      lpSrcObj, \
                ULONG                       ciidExclude, \
                LPCIID                      rgiidExclude, \
                LPSPropTagArray             lpExcludeProps, \
                ULONG                       ulUIParam, \
                LPMAPIPROGRESS              lpProgress, \
                LPCIID                      lpDestInterface, \
                LPVOID                      lpDestObj, \
                ULONG                       ulFlags, \
                LPSPropProblemArray FAR *   lppProblems) IPURE; \
    MAPIMETHOD(DoCopyProps) \
        (THIS_  LPCIID                      lpSrcInterface, \
                LPVOID                      lpSrcObj, \
                LPSPropTagArray             lpIncludeProps, \
                ULONG                       ulUIParam, \
                LPMAPIPROGRESS              lpProgress, \
                LPCIID                      lpDestInterface, \
                LPVOID                      lpDestObj, \
                ULONG                       ulFlags, \
                LPSPropProblemArray FAR *   lppProblems) IPURE; \
    MAPIMETHOD(DoProgressDialog) \
        (THIS_  ULONG                       ulUIParam, \
                ULONG                       ulFlags, \
                LPMAPIPROGRESS FAR *        lppProgress) IPURE; \
    MAPIMETHOD(ReadReceipt) \
        (THIS_  ULONG                       ulFlags, \
                LPMESSAGE                   lpReadMessage, \
                LPMESSAGE FAR *             lppEmptyMessage) IPURE; \
    MAPIMETHOD(PrepareSubmit) \
        (THIS_  LPMESSAGE                   lpMessage, \
                ULONG FAR *                 lpulFlags) IPURE; \
    MAPIMETHOD(ExpandRecips) \
        (THIS_  LPMESSAGE                   lpMessage, \
                ULONG FAR *                 lpulFlags) IPURE; \
    MAPIMETHOD(UpdatePAB) \
        (THIS_  ULONG                       ulFlags, \
                LPMESSAGE                   lpMessage) IPURE; \
    MAPIMETHOD(DoSentMail) \
        (THIS_  ULONG                       ulFlags, \
                LPMESSAGE                   lpMessage) IPURE; \
    MAPIMETHOD(OpenAddressBook) \
        (THIS_  LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                LPADRBOOK FAR *             lppAdrBook) IPURE; \
    MAPIMETHOD(Preprocess) \
        (THIS_  ULONG                       ulFlags, \
                ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID) IPURE; \
    MAPIMETHOD(CompleteMsg) \
        (THIS_  ULONG                       ulFlags, \
                ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID) IPURE; \
    MAPIMETHOD(StoreLogoffTransports) \
        (THIS_  ULONG FAR *                 lpulFlags) IPURE; \
    MAPIMETHOD(StatusRecips) \
        (THIS_  LPMESSAGE                   lpMessage, \
                LPADRLIST                   lpRecipList) IPURE; \
    MAPIMETHOD(WrapStoreEntryID) \
        (THIS_  ULONG                       cbOrigEntry, \
                LPENTRYID                   lpOrigEntry, \
                ULONG FAR *                 lpcbWrappedEntry, \
                LPENTRYID FAR *             lppWrappedEntry) IPURE; \
    MAPIMETHOD(ModifyProfile) \
        (THIS_  ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(IStorageFromStream) \
        (THIS_  LPUNKNOWN                   lpUnkIn, \
                LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                LPSTORAGE FAR *             lppStorageOut) IPURE; \
    MAPIMETHOD(GetSvcConfigSupportObj) \
        (THIS_  ULONG                       ulFlags, \
                LPMAPISUP FAR *             lppSvcSupport) IPURE;

#define MAPI_IMAPITABLE_METHODS(IPURE) MAPIMETHOD(GetLastError) \
        (THIS_  HRESULT                     hResult, \
                ULONG                       ulFlags, \
                LPMAPIERROR FAR *           lppMAPIError) IPURE; \
    MAPIMETHOD(Advise) \
        (THIS_  ULONG                       ulEventMask, \
                LPMAPIADVISESINK            lpAdviseSink, \
                ULONG FAR *                 lpulConnection) IPURE; \
    MAPIMETHOD(Unadvise) \
        (THIS_  ULONG                       ulConnection) IPURE; \
    MAPIMETHOD(GetStatus) \
        (THIS_  ULONG FAR *                 lpulTableStatus, \
                ULONG FAR *                 lpulTableType) IPURE; \
    MAPIMETHOD(SetColumns) \
        (THIS_  LPSPropTagArray             lpPropTagArray, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(QueryColumns) \
        (THIS_  ULONG                       ulFlags, \
                LPSPropTagArray FAR *       lpPropTagArray) IPURE; \
    MAPIMETHOD(GetRowCount) \
        (THIS_  ULONG                       ulFlags, \
                ULONG FAR *                 lpulCount) IPURE; \
    MAPIMETHOD(SeekRow) \
        (THIS_  BOOKMARK                    bkOrigin, \
                LONG                        lRowCount, \
                LONG FAR *                  lplRowsSought) IPURE; \
    MAPIMETHOD(SeekRowApprox) \
        (THIS_  ULONG                       ulNumerator, \
                ULONG                       ulDenominator) IPURE; \
    MAPIMETHOD(QueryPosition) \
        (THIS_  ULONG FAR *                 lpulRow, \
                ULONG FAR *                 lpulNumerator, \
                ULONG FAR *                 lpulDenominator) IPURE; \
    MAPIMETHOD(FindRow) \
        (THIS_  LPSRestriction              lpRestriction, \
                BOOKMARK                    bkOrigin, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(Restrict) \
        (THIS_  LPSRestriction              lpRestriction, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(CreateBookmark) \
        (THIS_  BOOKMARK FAR *              lpbkPosition) IPURE; \
    MAPIMETHOD(FreeBookmark) \
        (THIS_  BOOKMARK                    bkPosition) IPURE; \
    MAPIMETHOD(SortTable) \
        (THIS_  LPSSortOrderSet             lpSortCriteria, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(QuerySortOrder) \
        (THIS_  LPSSortOrderSet FAR *       lppSortCriteria) IPURE; \
    MAPIMETHOD(QueryRows) \
        (THIS_  LONG                        lRowCount, \
                ULONG                       ulFlags, \
                LPSRowSet FAR *             lppRows) IPURE; \
    MAPIMETHOD(Abort) (THIS) IPURE; \
    MAPIMETHOD(ExpandRow) \
        (THIS_  ULONG                       cbInstanceKey, \
                LPBYTE                      pbInstanceKey, \
                ULONG                       ulRowCount, \
                ULONG                       ulFlags, \
                LPSRowSet FAR *             lppRows, \
                ULONG FAR *                 lpulMoreRows) IPURE; \
    MAPIMETHOD(CollapseRow) \
        (THIS_  ULONG                       cbInstanceKey, \
                LPBYTE                      pbInstanceKey, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulRowCount) IPURE; \
    MAPIMETHOD(WaitForCompletion) \
        (THIS_  ULONG                       ulFlags, \
                ULONG                       ulTimeout, \
                ULONG FAR *                 lpulTableStatus) IPURE; \
    MAPIMETHOD(GetCollapseState) \
        (THIS_  ULONG                       ulFlags, \
                ULONG                       cbInstanceKey, \
                LPBYTE                      lpbInstanceKey, \
                ULONG FAR *                 lpcbCollapseState, \
                LPBYTE FAR *                lppbCollapseState) IPURE; \
    MAPIMETHOD(SetCollapseState) \
        (THIS_  ULONG                       ulFlags, \
                ULONG                       cbCollapseState, \
                LPBYTE                      pbCollapseState, \
                BOOKMARK FAR *              lpbkLocation) IPURE;

#define MAPI_IMAPIVIEWADVISESINK_METHODS(IPURE) MAPIMETHOD(OnShutdown)(THIS) IPURE; \
    MAPIMETHOD(OnNewMessage)(THIS) IPURE; \
    MAPIMETHOD(OnPrint)(THIS_ \
        /*in*/ ULONG dwPageNumber, \
        /*in*/ HRESULT hrStatus) IPURE; \
    MAPIMETHOD(OnSubmitted) (THIS) IPURE; \
    MAPIMETHOD(OnSaved) (THIS) IPURE;

#define MAPI_IMAPIVIEWCONTEXT_METHODS(IPURE) MAPIMETHOD(SetAdviseSink)(THIS_ \
        /*in*/  LPMAPIFORMADVISESINK pmvns) IPURE; \
    MAPIMETHOD(ActivateNext)(THIS_ \
        /*in*/  ULONG ulDir, \
        /*in*/  LPCRECT prcPosRect) IPURE; \
    MAPIMETHOD(GetPrintSetup)(THIS_ \
        /*in*/  ULONG ulFlags, \
        /*out*/ LPFORMPRINTSETUP FAR * lppFormPrintSetup) IPURE; \
    MAPIMETHOD(GetSaveStream)(THIS_ \
        /*out*/ ULONG FAR * pulFlags, \
        /*out*/ ULONG FAR * pulFormat, \
        /*out*/ LPSTREAM FAR * ppstm) IPURE; \
    MAPIMETHOD(GetViewStatus) (THIS_ \
        /*out*/ LPULONG lpulStatus) IPURE;

#define MAPI_IMESSAGE_METHODS(IPURE) MAPIMETHOD(GetAttachmentTable) \
        (THIS_  ULONG                       ulFlags, \
                LPMAPITABLE FAR *           lppTable) IPURE; \
    MAPIMETHOD(OpenAttach) \
        (THIS_  ULONG                       ulAttachmentNum, \
                LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                LPATTACH FAR *              lppAttach) IPURE; \
    MAPIMETHOD(CreateAttach) \
        (THIS_  LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulAttachmentNum, \
                LPATTACH FAR *              lppAttach) IPURE; \
    MAPIMETHOD(DeleteAttach) \
        (THIS_  ULONG                       ulAttachmentNum, \
                ULONG                       ulUIParam, \
                LPMAPIPROGRESS              lpProgress, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(GetRecipientTable) \
        (THIS_  ULONG                       ulFlags, \
                LPMAPITABLE FAR *           lppTable) IPURE; \
    MAPIMETHOD(ModifyRecipients) \
        (THIS_  ULONG                       ulFlags, \
                LPADRLIST                   lpMods) IPURE; \
    MAPIMETHOD(SubmitMessage) \
        (THIS_  ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(SetReadFlag) \
        (THIS_  ULONG                       ulFlags) IPURE;

#define MAPI_IMSGSERVICEADMIN_METHODS(IPURE) MAPIMETHOD(GetLastError) \
        (THIS_  HRESULT                     hResult, \
                ULONG                       ulFlags, \
                LPMAPIERROR FAR *           lppMAPIError) IPURE; \
    MAPIMETHOD(GetMsgServiceTable) \
        (THIS_  ULONG                       ulFlags, \
                LPMAPITABLE FAR *           lppTable) IPURE; \
    MAPIMETHOD(CreateMsgService) \
        (THIS_  LPTSTR                      lpszService, \
                LPTSTR                      lpszDisplayName, \
                ULONG                       ulUIParam, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(DeleteMsgService) \
        (THIS_  LPMAPIUID                   lpUID) IPURE; \
    MAPIMETHOD(CopyMsgService) \
        (THIS_  LPMAPIUID                   lpUID, \
                LPTSTR                      lpszDisplayName, \
                LPCIID                      lpInterfaceToCopy, \
                LPCIID                      lpInterfaceDst, \
                LPVOID                      lpObjectDst, \
                ULONG                       ulUIParam, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(RenameMsgService) \
        (THIS_  LPMAPIUID                   lpUID, \
                ULONG                       ulFlags, \
                LPTSTR                      lpszDisplayName) IPURE; \
    MAPIMETHOD(ConfigureMsgService) \
        (THIS_  LPMAPIUID                   lpUID, \
                ULONG                       ulUIParam, \
                ULONG                       ulFlags, \
                ULONG                       cValues, \
                LPSPropValue                lpProps) IPURE; \
    MAPIMETHOD(OpenProfileSection) \
        (THIS_  LPMAPIUID                   lpUID, \
                LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                LPPROFSECT FAR *            lppProfSect) IPURE; \
    MAPIMETHOD(MsgServiceTransportOrder) \
        (THIS_  ULONG                       cUID, \
                LPMAPIUID                   lpUIDList, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(AdminProviders) \
        (THIS_  LPMAPIUID                   lpUID, \
                ULONG                       ulFlags, \
                LPPROVIDERADMIN FAR *       lppProviderAdmin) IPURE; \
    MAPIMETHOD(SetPrimaryIdentity) \
        (THIS_  LPMAPIUID                   lpUID, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(GetProviderTable) \
        (THIS_  ULONG                       ulFlags, \
                LPMAPITABLE FAR *           lppTable) IPURE;

#define MAPI_IMSGSTORE_METHODS(IPURE) MAPIMETHOD(Advise) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                ULONG                       ulEventMask, \
                LPMAPIADVISESINK            lpAdviseSink, \
                ULONG FAR *                 lpulConnection) IPURE; \
    MAPIMETHOD(Unadvise) \
        (THIS_  ULONG                       ulConnection) IPURE; \
    MAPIMETHOD(CompareEntryIDs) \
        (THIS_  ULONG                       cbEntryID1, \
                LPENTRYID                   lpEntryID1, \
                ULONG                       cbEntryID2, \
                LPENTRYID                   lpEntryID2, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulResult) IPURE; \
    MAPIMETHOD(OpenEntry) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulObjType, \
                LPUNKNOWN FAR *             lppUnk) IPURE; \
    MAPIMETHOD(SetReceiveFolder) \
        (THIS_  LPTSTR                      lpszMessageClass, \
                ULONG                       ulFlags, \
                ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID) IPURE; \
    MAPIMETHOD(GetReceiveFolder) \
        (THIS_  LPTSTR                      lpszMessageClass, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpcbEntryID, \
                LPENTRYID FAR *             lppEntryID, \
                LPTSTR FAR *                lppszExplicitClass) IPURE; \
    MAPIMETHOD(GetReceiveFolderTable) \
        (THIS_  ULONG                       ulFlags, \
                LPMAPITABLE FAR *           lppTable) IPURE; \
    MAPIMETHOD(StoreLogoff) \
        (THIS_  ULONG FAR *                 lpulFlags) IPURE; \
    MAPIMETHOD(AbortSubmit) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(GetOutgoingQueue) \
        (THIS_  ULONG                       ulFlags, \
                LPMAPITABLE FAR *           lppTable) IPURE; \
    MAPIMETHOD(SetLockState) \
        (THIS_  LPMESSAGE                   lpMessage, \
                ULONG                       ulLockState) IPURE; \
    MAPIMETHOD(FinishedMsg) \
        (THIS_  ULONG                       ulFlags, \
                ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID) IPURE; \
    MAPIMETHOD(NotifyNewMail) \
        (THIS_  LPNOTIFICATION              lpNotification) IPURE;

#define MAPI_IMSLOGON_METHODS(IPURE) MAPIMETHOD(GetLastError) \
        (THIS_  HRESULT                     hResult, \
                ULONG                       ulFlags, \
                LPMAPIERROR FAR *           lppMAPIError) IPURE; \
    MAPIMETHOD(Logoff) \
        (THIS_  ULONG FAR *                 lpulFlags) IPURE; \
    MAPIMETHOD(OpenEntry) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulObjType, \
                LPUNKNOWN FAR *             lppUnk) IPURE; \
    MAPIMETHOD(CompareEntryIDs) \
        (THIS_  ULONG                       cbEntryID1, \
                LPENTRYID                   lpEntryID1, \
                ULONG                       cbEntryID2, \
                LPENTRYID                   lpEntryID2, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulResult) IPURE; \
    MAPIMETHOD(Advise) \
        (THIS_  ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                ULONG                       ulEventMask, \
                LPMAPIADVISESINK            lpAdviseSink, \
                ULONG FAR *                 lpulConnection) IPURE; \
    MAPIMETHOD(Unadvise) \
        (THIS_  ULONG                       ulConnection) IPURE; \
    MAPIMETHOD(OpenStatusEntry) \
        (THIS_  LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulObjType, \
                LPVOID FAR *                lppEntry) IPURE;

#define MAPI_IMSPROVIDER_METHODS(IPURE) MAPIMETHOD(Shutdown) \
        (THIS_  ULONG FAR *                 lpulFlags) IPURE; \
    MAPIMETHOD(Logon) \
        (THIS_  LPMAPISUP                   lpMAPISup, \
                ULONG                       ulUIParam, \
                LPTSTR                      lpszProfileName, \
                ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                ULONG                       ulFlags, \
                LPCIID                      lpInterface, \
                ULONG FAR *                 lpcbSpoolSecurity, \
                LPBYTE FAR *                lppbSpoolSecurity, \
                LPMAPIERROR FAR *           lppMAPIError, \
                LPMSLOGON FAR *             lppMSLogon, \
                LPMDB FAR *                 lppMDB) IPURE; \
    MAPIMETHOD(SpoolerLogon) \
        (THIS_  LPMAPISUP                   lpMAPISup, \
                ULONG                       ulUIParam, \
                LPTSTR                      lpszProfileName, \
                ULONG                       cbEntryID, \
                LPENTRYID                   lpEntryID, \
                ULONG                       ulFlags, \
                LPCIID                      lpInterface, \
                ULONG                       cbSpoolSecurity, \
                LPBYTE                      lpbSpoolSecurity, \
                LPMAPIERROR FAR *           lppMAPIError, \
                LPMSLOGON FAR *             lppMSLogon, \
                LPMDB FAR *                 lppMDB) IPURE; \
    MAPIMETHOD(CompareStoreIDs) \
        (THIS_  ULONG                       cbEntryID1, \
                LPENTRYID                   lpEntryID1, \
                ULONG                       cbEntryID2, \
                LPENTRYID                   lpEntryID2, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulResult) IPURE;

#define MAPI_IPERSISTMESSAGE_METHODS(IPURE) MAPIMETHOD(GetClassID) (THIS_ LPCLSID lpClassID) IPURE; \
    MAPIMETHOD(IsDirty)(THIS) IPURE; \
    MAPIMETHOD(InitNew)(THIS_ \
        /*in*/ LPMAPIMESSAGESITE pMessageSite, \
        /*in*/ LPMESSAGE pMessage) IPURE; \
    MAPIMETHOD(Load)(THIS_ \
        /*in*/ LPMAPIMESSAGESITE pMessageSite, \
        /*in*/ LPMESSAGE pMessage, \
        /*in*/ ULONG ulMessageStatus, \
        /*in*/ ULONG ulMessageFlags) IPURE; \
    MAPIMETHOD(Save)(THIS_ \
        /*in*/ LPMESSAGE pMessage, \
        /*in*/ ULONG fSameAsLoad) IPURE; \
    MAPIMETHOD(SaveCompleted)(THIS_ \
        /*in*/ LPMESSAGE pMessage) IPURE; \
    MAPIMETHOD(HandsOffMessage)(THIS) IPURE;

#define MAPI_IPROFADMIN_METHODS(IPURE) MAPIMETHOD(GetLastError) \
        (THIS_  HRESULT                     hResult, \
                ULONG                       ulFlags, \
                LPMAPIERROR FAR *           lppMAPIError) IPURE; \
    MAPIMETHOD(GetProfileTable) \
        (THIS_  ULONG                       ulFlags, \
                LPMAPITABLE FAR *           lppTable) IPURE; \
    MAPIMETHOD(CreateProfile) \
        (THIS_  LPTSTR                      lpszProfileName, \
                LPTSTR                      lpszPassword, \
                ULONG                       ulUIParam, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(DeleteProfile) \
        (THIS_  LPTSTR                      lpszProfileName, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(ChangeProfilePassword) \
        (THIS_  LPTSTR                      lpszProfileName, \
                LPTSTR                      lpszOldPassword, \
                LPTSTR                      lpszNewPassword, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(CopyProfile) \
        (THIS_  LPTSTR                      lpszOldProfileName, \
                LPTSTR                      lpszOldPassword, \
                LPTSTR                      lpszNewProfileName, \
                ULONG                       ulUIParam, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(RenameProfile) \
        (THIS_  LPTSTR                      lpszOldProfileName, \
                LPTSTR                      lpszOldPassword, \
                LPTSTR                      lpszNewProfileName, \
                ULONG                       ulUIParam, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(SetDefaultProfile) \
        (THIS_  LPTSTR                      lpszProfileName, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(AdminServices) \
        (THIS_  LPTSTR                      lpszProfileName, \
                LPTSTR                      lpszPassword, \
                ULONG                       ulUIParam, \
                ULONG                       ulFlags, \
                LPSERVICEADMIN FAR *        lppServiceAdmin) IPURE;

#define MAPI_IPROPDATA_METHODS(IPURE) MAPIMETHOD(HrSetObjAccess) \
        (THIS_  ULONG                       ulAccess) IPURE; \
    MAPIMETHOD(HrSetPropAccess) \
        (THIS_  LPSPropTagArray             lpPropTagArray, \
                ULONG FAR *                 rgulAccess) IPURE; \
    MAPIMETHOD(HrGetPropAccess) \
        (THIS_  LPSPropTagArray FAR *       lppPropTagArray, \
                ULONG FAR * FAR *           lprgulAccess) IPURE; \
    MAPIMETHOD(HrAddObjProps) \
        (THIS_  LPSPropTagArray             lppPropTagArray, \
                LPSPropProblemArray FAR *   lprgulAccess) IPURE;

#define MAPI_IPROVIDERADMIN_METHODS(IPURE) MAPIMETHOD(GetLastError) \
        (THIS_  HRESULT                     hResult, \
                ULONG                       ulFlags, \
                LPMAPIERROR FAR *           lppMAPIError) IPURE; \
    MAPIMETHOD(GetProviderTable) \
        (THIS_  ULONG                       ulFlags, \
                LPMAPITABLE FAR *           lppTable) IPURE; \
    MAPIMETHOD(CreateProvider) \
        (THIS_  LPTSTR                      lpszProvider, \
                ULONG                       cValues, \
                LPSPropValue                lpProps, \
                ULONG                       ulUIParam, \
                ULONG                       ulFlags, \
                MAPIUID FAR *               lpUID) IPURE; \
    MAPIMETHOD(DeleteProvider) \
        (THIS_  LPMAPIUID                   lpUID) IPURE; \
    MAPIMETHOD(OpenProfileSection) \
        (THIS_  LPMAPIUID                   lpUID, \
                LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                LPPROFSECT FAR *            lppProfSect) IPURE;

#define MAPI_ISPOOLERHOOK_METHODS(IPURE) MAPIMETHOD(InboundMsgHook) \
        (THIS_  LPMESSAGE                   lpMessage, \
                LPMAPIFOLDER                lpFolder, \
                LPMDB                       lpMDB, \
                ULONG FAR *                 lpulFlags, \
                ULONG FAR *                 lpcbEntryID, \
                LPBYTE FAR *                lppEntryID) IPURE; \
    MAPIMETHOD(OutboundMsgHook) \
        (THIS_  LPMESSAGE                   lpMessage, \
                LPMAPIFOLDER                lpFolder, \
                LPMDB                       lpMDB, \
                ULONG FAR *                 lpulFlags, \
                ULONG FAR *                 lpcbEntryID, \
                LPBYTE FAR *                lppEntryID) IPURE;

#define MAPI_ITABLEDATA_METHODS(IPURE) MAPIMETHOD(HrGetView) \
        (THIS_  LPSSortOrderSet             lpSSortOrderSet, \
                CALLERRELEASE FAR *         lpfCallerRelease, \
                ULONG                       ulCallerData, \
                LPMAPITABLE FAR *           lppMAPITable) IPURE; \
    MAPIMETHOD(HrModifyRow) \
        (THIS_  LPSRow) IPURE; \
    MAPIMETHOD(HrDeleteRow) \
        (THIS_  LPSPropValue                lpSPropValue) IPURE; \
    MAPIMETHOD(HrQueryRow) \
        (THIS_  LPSPropValue                lpsPropValue, \
                LPSRow FAR *                lppSRow, \
                ULONG FAR *                 lpuliRow) IPURE; \
    MAPIMETHOD(HrEnumRow) \
        (THIS_  ULONG                       ulRowNumber, \
                LPSRow FAR *                lppSRow) IPURE; \
    MAPIMETHOD(HrNotify) \
        (THIS_  ULONG                       ulFlags, \
                ULONG                       cValues, \
                LPSPropValue                lpSPropValue) IPURE; \
    MAPIMETHOD(HrInsertRow) \
        (THIS_  ULONG                       uliRow, \
                LPSRow                      lpSRow) IPURE; \
    MAPIMETHOD(HrModifyRows) \
        (THIS_  ULONG                       ulFlags, \
                LPSRowSet                   lpSRowSet) IPURE; \
    MAPIMETHOD(HrDeleteRows) \
        (THIS_  ULONG                       ulFlags, \
                LPSRowSet                   lprowsetToDelete, \
                ULONG FAR *                 cRowsDeleted) IPURE;

#define MAPI_ITNEF_METHODS(IPURE) MAPIMETHOD(AddProps) \
        (THIS_  ULONG                       ulFlags, \
                ULONG                       ulElemID, \
                LPVOID                      lpvData, \
                LPSPropTagArray             lpPropList) IPURE; \
    MAPIMETHOD(ExtractProps) \
        (THIS_  ULONG                       ulFlags, \
                LPSPropTagArray             lpPropList, \
                LPSTnefProblemArray FAR *   lpProblems) IPURE; \
    MAPIMETHOD(Finish) \
        (THIS_  ULONG                       ulFlags, \
                WORD FAR *                  lpKey, \
                LPSTnefProblemArray FAR *   lpProblems) IPURE; \
    MAPIMETHOD(OpenTaggedBody) \
        (THIS_  LPMESSAGE                   lpMessage, \
                ULONG                       ulFlags, \
                LPSTREAM FAR *              lppStream) IPURE; \
    MAPIMETHOD(SetProps) \
        (THIS_  ULONG                       ulFlags, \
                ULONG                       ulElemID, \
                ULONG                       cValues, \
                LPSPropValue                lpProps) IPURE; \
    MAPIMETHOD(EncodeRecips) \
        (THIS_  ULONG                       ulFlags, \
                LPMAPITABLE                 lpRecipientTable) IPURE; \
    MAPIMETHOD(FinishComponent) \
        (THIS_  ULONG                       ulFlags, \
                ULONG                       ulComponentID, \
                LPSPropTagArray             lpCustomPropList, \
                LPSPropValue                lpCustomProps, \
                LPSPropTagArray             lpPropList, \
                LPSTnefProblemArray FAR *   lpProblems) IPURE;

#define MAPI_IUNKNOWN_METHODS(IPURE) MAPIMETHOD(QueryInterface) \
        (THIS_ REFIID riid, LPVOID FAR * ppvObj) IPURE; \
    MAPIMETHOD_(ULONG,AddRef)  (THIS) IPURE; \
    MAPIMETHOD_(ULONG,Release) (THIS) IPURE;

#define MAPI_IXPLOGON_METHODS(IPURE) MAPIMETHOD(AddressTypes) \
        (THIS_  ULONG FAR *                 lpulFlags, \
                ULONG FAR *                 lpcAdrType, \
                LPTSTR FAR * FAR *          lpppAdrTypeArray, \
                ULONG FAR *                 lpcMAPIUID, \
                LPMAPIUID FAR * FAR *       lpppUIDArray) IPURE; \
    MAPIMETHOD(RegisterOptions) \
        (THIS_  ULONG FAR *                 lpulFlags, \
                ULONG FAR *                 lpcOptions, \
                LPOPTIONDATA FAR *          lppOptions) IPURE; \
    MAPIMETHOD(TransportNotify) \
        (THIS_  ULONG FAR *                 lpulFlags, \
                LPVOID FAR *                lppvData) IPURE; \
    MAPIMETHOD(Idle) \
        (THIS_  ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(TransportLogoff) \
        (THIS_  ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(SubmitMessage) \
        (THIS_  ULONG                       ulFlags, \
                LPMESSAGE                   lpMessage, \
                ULONG FAR *                 lpulMsgRef, \
                ULONG FAR *                 lpulReturnParm) IPURE; \
    MAPIMETHOD(EndMessage) \
        (THIS_  ULONG                       ulMsgRef, \
                ULONG FAR *                 lpulFlags) IPURE; \
    MAPIMETHOD(Poll) \
        (THIS_  ULONG FAR *                 lpulIncoming) IPURE; \
    MAPIMETHOD(StartMessage) \
        (THIS_  ULONG                       ulFlags, \
                LPMESSAGE                   lpMessage, \
                ULONG FAR *                 lpulMsgRef) IPURE; \
    MAPIMETHOD(OpenStatusEntry) \
        (THIS_  LPCIID                      lpInterface, \
                ULONG                       ulFlags, \
                ULONG FAR *                 lpulObjType, \
                LPMAPISTATUS FAR *          lppEntry) IPURE; \
    MAPIMETHOD(ValidateState) \
        (THIS_  ULONG                       ulUIParam, \
                ULONG                       ulFlags) IPURE; \
    MAPIMETHOD(FlushQueues) \
        (THIS_  ULONG                       ulUIParam, \
                ULONG                       cbTargetTransport, \
                LPENTRYID                   lpTargetTransport, \
                ULONG                       ulFlags) IPURE;

#define MAPI_IXPPROVIDER_METHODS(IPURE) MAPIMETHOD(Shutdown) \
        (THIS_  ULONG FAR *                 lpulFlags) IPURE; \
    MAPIMETHOD(TransportLogon) \
        (THIS_  LPMAPISUP                   lpMAPISup, \
                ULONG                       ulUIParam, \
                LPTSTR                      lpszProfileName, \
                ULONG FAR *                 lpulFlags, \
                LPMAPIERROR FAR *           lppMAPIError, \
                LPXPLOGON FAR *             lppXPLogon) IPURE;

#define MAPIMETHOD(method) MAPIMETHOD_(HRESULT, method)

#define MAPIMETHOD_(type, method) STDMETHOD_(type, method)

#define MAPIMETHOD_DECLARE(type, method, prefix) STDMETHODIMP_(type) prefix##method

#define MAPIMETHOD_TYPEDEF(type, method, prefix) typedef type (STDMETHODCALLTYPE prefix##method##_METHOD)

#define MIDL_INTERFACE(x) struct

#define NCB_POST void CALLBACK

#define NDR_SHAREABLE static

#define near 

#define NEAR 

#define NORPC 

#define NTExport NTExportW

#define OAPP(T) __OAPP_##T

#define OMANIP(T) __OMANIP_##T

#define packed
 
#define PROCESS_LOCAL(class_name, ident_name) AFX_DATADEF CProcessLocal<class_name> ident_name;

#define Prop_Val_Union union _PV

#define PROXYFILE_LIST_START const ProxyFileInfo  *  aProxyFileList[]    = {

#define PURE = 0

#define RASAMBA struct tagRASAMBA

#define RASAMBW struct tagRASAMBW

#define RASCONNA struct tagRASCONNA

#define RASCONNSTATE enum tagRASCONNSTATE

#define RASCONNSTATUS RASCONNSTATUSA

#define RASCONNSTATUSA struct tagRASCONNSTATUSA

#define RASCONNSTATUSW struct tagRASCONNSTATUSW

#define RASCONNW struct tagRASCONNW

#define RASDIALEXTENSIONS struct tagRASDIALEXTENSIONS

#define RASDIALPARAMS RASDIALPARAMSW

#define RASDIALPARAMSA struct tagRASDIALPARAMSA

#define RASDIALPARAMSW struct tagRASDIALPARAMSW

#define RASENTRYNAME RASENTRYNAMEA

#define RASENTRYNAMEA struct tagRASENTRYNAMEA

#define RASENTRYNAMEW struct tagRASENTRYNAMEW

#define RASPPPIP RASPPPIPA

#define RASPPPIPA struct tagRASPPPIPA

#define RASPPPIPW struct tagRASPPPIPW

#define RASPPPIPX RASPPPIPXA

#define RASPPPIPXA struct tagRASPPPIPXA

#define RASPPPIPXW struct tagRASIPXW

#define RASPPPNBF RASPPPNBFW

#define RASPPPNBFA struct tagRASPPPNBFA

#define RASPPPNBFW struct tagRASPPPNBFW

#define RASPROJECTION enum tagRASPROJECTION

#define REFERENCE_PROXY_FILE(name) & name##_ProxyFileInfo 

#define REGISTER_PROXY_DLL_ROUTINES(pProxyFileList, pClsID) HINSTANCE hProxyDll = 0; \
 \
    BOOL WINAPI DllMain( \
        HINSTANCE  hinstDLL, \
        DWORD  fdwReason, \
        LPVOID  lpvReserved) \
    { \
        if(fdwReason == DLL_PROCESS_ATTACH) \
            hProxyDll = hinstDLL; \
        return TRUE; \
    } \
 \
    HRESULT STDAPICALLTYPE DllRegisterServer() \
    { \
        return NdrDllRegisterProxy(hProxyDll, pProxyFileList, pClsID); \
    } \
 \
    HRESULT STDAPICALLTYPE DllUnregisterServer() \
    { \
        return NdrDllUnregisterProxy(hProxyDll, pProxyFileList, pClsID); \
    }  

// Helper macros
#define RUNTIME_CLASS(class_name) (&class_name::class##class_name)

#define SAPP(T) __SAPP_##T

#define SizedADRLIST(_centries, _name) struct _ADRLIST_ ## _name \
{ \
    ULONG           cEntries; \
    ADRENTRY        aEntries[_centries]; \
} _name

#define SizedDtblButton(n,u) struct _DTBLBUTTON_ ## u \
{ \
    DTBLBUTTON  dtblbutton; \
    TCHAR       lpszLabel[n]; \
} u

#define SizedDtblCheckBox(n,u) struct _DTBLCHECKBOX_ ## u \
{ \
    DTBLCHECKBOX    dtblcheckbox; \
    TCHAR       lpszLabel[n]; \
} u

#define SizedDtblComboBox(n,u) struct _DTBLCOMBOBOX_ ## u \
{ \
    DTBLCOMBOBOX    dtblcombobox; \
    TCHAR           lpszCharsAllowed[n]; \
} u

#define SizedDtblEdit(n,u) struct _DTBLEDIT_ ## u \
{ \
    DTBLEDIT    dtbledit; \
    TCHAR       lpszCharsAllowed[n]; \
} u

#define SizedDtblGroupBox(n,u) struct _DTBLGROUPBOX_ ## u \
{ \
    DTBLGROUPBOX    dtblgroupbox; \
    TCHAR           lpszLabel[n]; \
} u

#define SizedDtblLabel(n,u) struct _DTBLLABEL_ ## u \
{ \
    DTBLLABEL   dtbllabel; \
    TCHAR       lpszLabelName[n]; \
} u

#define SizedDtblPage(n,n1,u) struct _DTBLPAGE_ ## u \
{ \
    DTBLPAGE    dtblpage; \
    TCHAR       lpszLabel[n]; \
    TCHAR       lpszComponent[n1]; \
} u

#define SizedDtblRadioButton(n,u) struct _DTBLRADIOBUTTON_ ## u \
{ \
    DTBLRADIOBUTTON dtblradiobutton; \
    TCHAR           lpszLabel[n]; \
} u

#define SizedENTRYID(_cb, _name) struct _ENTRYID_ ## _name \
{ \
    BYTE    abFlags[4]; \
    BYTE    ab[_cb]; \
} _name

#define SizedNOTIFKEY(_cb, _name) struct _NOTIFKEY_ ## _name \
{ \
    ULONG       cb; \
    BYTE        ab[_cb]; \
} _name

#define SizedSPropAttrArray(_cattr, _name) struct _SPropAttrArray_ ## _name \
{ \
    ULONG   cValues; \
    ULONG   aPropAttr[_cattr]; \
} _name

#define SizedSPropProblemArray(_cprob, _name) struct _SPropProblemArray_ ## _name \
{ \
    ULONG           cProblem; \
    SPropProblem    aProblem[_cprob]; \
} _name

/*  SPropTagArray */

#define SizedSPropTagArray(_ctag, _name) struct _SPropTagArray_ ## _name \
{ \
    ULONG   cValues; \
    ULONG   aulPropTag[_ctag]; \
} _name

#define SizedSRowSet(_crow, _name) struct _SRowSet_ ## _name \
{ \
    ULONG           cRows; \
    SRow            aRow[_crow]; \
} _name

#define SizedSSortOrderSet(_csort, _name) struct _SSortOrderSet_ ## _name \
{ \
    ULONG           cSorts; \
    ULONG           cCategories; \
    ULONG           cExpanded; \
    SSortOrder      aSort[_csort]; \
} _name

#define SMANIP(T) __SMANIP_##T

#define SNAPINMENUID(id) public: \
	static const UINT GetMenuID() \
	{ \
		static const UINT IDMENU = id; \
		return id; \
	}

#define STDAPI EXTERN_C HRESULT STDAPICALLTYPE

#define STDAPI_(type) EXTERN_C type STDAPICALLTYPE

#define STDAPIV EXTERN_C HRESULT STDAPIVCALLTYPE

#define STDAPIV_(type) EXTERN_C type STDAPIVCALLTYPE

#define STDMETHOD(method) virtual HRESULT STDMETHODCALLTYPE method

#define STDMETHOD_(type,method) virtual type STDMETHODCALLTYPE method

#define TEXT(quote) __TEXT(quote)

#define THROW(e) throw e

#undef UNICODE 

#undef UNICODE_ONLY

#undef UNICODEOLE32 

#define USES_CONVERSION int _convert = 0;

#define va_dcl va_list va_alist;

#define WAB_IWABOBJECT_METHODS(IPURE) MAPIMETHOD(GetLastError) \
            (THIS_  HRESULT hResult, \
                    ULONG   ulFlags, \
                    LPMAPIERROR FAR * lppMAPIError) IPURE; \
        MAPIMETHOD(AllocateBuffer) \
            (THIS_  ULONG   cbSize, \
                    LPVOID FAR *    lppBuffer) IPURE; \
        MAPIMETHOD(AllocateMore) \
            (THIS_  ULONG   cbSize, \
                    LPVOID  lpObject, \
                    LPVOID  FAR *   lppBuffer) IPURE; \
        MAPIMETHOD(FreeBuffer) \
            (THIS_  LPVOID  lpBuffer) IPURE; \
        MAPIMETHOD(Backup) \
            (THIS_  LPTSTR  lpFileName) IPURE; \
        MAPIMETHOD(Import) \
            (THIS_   LPTSTR lpFileName) IPURE; \
        MAPIMETHOD(Find) \
            (THIS_  LPADRBOOK lpIAB, \
                    HWND    hWnd) IPURE; \
        MAPIMETHOD(VCardDisplay) \
            (THIS_  LPADRBOOK lpIAB, \
                    HWND    hWnd, \
                    LPTSTR  lpszFileName) IPURE; \
        MAPIMETHOD(LDAPUrl) \
            (THIS_  LPADRBOOK   lpIAB, \
                    HWND        hWnd, \
                    ULONG       ulFlags, \
                    LPTSTR      lpszURL, \
                    LPMAILUSER *lppMailUser) IPURE; \
        MAPIMETHOD(VCardCreate) \
            (THIS_  LPADRBOOK   lpIAB, \
                    ULONG       ulFlags, \
                    LPTSTR      lpszVCard, \
                    LPMAILUSER  lpMailUser) IPURE; \
        MAPIMETHOD(VCardRetrieve) \
            (THIS_  LPADRBOOK   lpIAB, \
                    ULONG       ulFlags, \
                    LPTSTR      lpszVCard, \
                    LPMAILUSER *lppMailUser) IPURE; \
        MAPIMETHOD(GetMe) \
            (THIS_  LPADRBOOK   lpIAB, \
                    ULONG       ulFlags, \
                    DWORD *     lpdwAction, \
                    SBinary *   lpsbEID, \
                    ULONG       ulReserved) IPURE; \
        MAPIMETHOD(SetMe) \
            (THIS_  LPADRBOOK   lpIAB, \
                    ULONG       ulFlags, \
                    SBinary     sbEID, \
                    ULONG       ulReserved) IPURE;

#define WDBGAPI __stdcall

#undef WIN16 

#define WIN32 1

#define WINOLEAPI STDAPI

#define WINOLEAPI_(type) STDAPI_(type)

#define WINOLEAUTAPI STDAPI

#define WINOLEAUTAPI_(type) STDAPI_(type)

#define WINSCARDAPI 

#define WINSCARDDATA __declspec(dllimport)

#define WSPAPI WSAAPI

#define VSDEFAULT(a) =a

#define VSREF(a) &a
