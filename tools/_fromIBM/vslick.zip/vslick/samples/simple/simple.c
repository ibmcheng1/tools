/*
    This example can be compiled with
         Microsoft Visual C++, Microsoft C 8.0, or IBM C Set++

    *  Compile this 32 bit DLL.
       For Windows NT and Chicago
         nmake

       For OS/2, type
         nmake -f makefile.os2

    *  Load this DLL by typing "dload simple.dll" on the Visual SlickEdit
       command line.

    *  To execute the dllproc command, type "dllproc" on the Visual
       SlickEdit command line.  Try executing "dllproc Line1 2" to
       pass arguments to this command.  The dllproc command can be
       bound to a key. The only way to call dllproc2, is to write a
       macro which calls it.

    The dunload command can be used to unload a DLL.  This deletes
    all register functions defined by the DLL being unloaded.  If
    your DLL is already loaded, you will not be able to rebuild the
    dll until you unload it.


*/
#include <stdio.h>
#include <stdlib.h>
// vsapi.h includes windows.h or os2.h
// For OS/2 you may need to define some more INCL_???? here
#include <vsapi.h>


EXTERN_C_BEGIN
/*
  vsdllinit is called from dllmain.obj which is typically linked in
  your DLL.
  This entry point gets called no matter how the
  dll gets loaded.
*/
void VSAPI vsDllInit()
{
}
/*
   You must export your functions here instead 
   of vsDllInit if you have dll's which share
   each other functions.
*/
void VSAPI vsDllRegisterExports()
{
   // dllproc can be bound to a key because it is a command
   // When a string parameter is not given, a string of length 0 is passed.
   // When a numeric parameter is not given, 0 is passed.
   vsDllExport("_command void dllproc(VSPSZ,int)",
               VSARG_FILE,  // Indicate completion on file names for first argument
               VSARG2_NCW|VSARG2_ICON|VSARG2_READ_ONLY
                            // Indicate this command is allowed when
                            // there are no MDI child windows, when the
                            // active MDI child window is iconized, and
                            // when the current buffer is read only.
               );
   // The purpose for defined a dllproc2 which is not a command is to allow
   // a Slick-C macro to call the proc.
   vsDllExport("VSPSZ dllproc2()",0,0);
}
/*
  vsdllexit is called from dllmain.obj which is typically linked in
  your DLLs when the DLL is unloaded.  This function must defined if
  dllmain.obj is linked in your DLL.
*/
void VSAPI vsDllExit()
{
}

void VSAPI dllproc(VSPSZ pszLine1,int LineNum)
{
   long status;

   // Current object/window is mdi child
   status=vsExecute(0,"edit junk","");
   if (status && status!=NEW_FILE_RC) {
      vsMessageBox("dllproc: Error loading file",0,VSMB_OK);
      return;
   }
   if (status==NEW_FILE_RC) {
      // Delete the blank line in the new file created
      vsDeleteLine(0);
   }
   vsInsertLine(0,pszLine1,-1);
   vsInsertLine(0,"this is line 2",-1);
   vsInsertLine(0,"this is line 3",-1);
   // Set the current line to LineNum
   vsPropSetI(0,VSP_LINE,LineNum);
}
VSPSZ VSAPI dllproc2()
{
   return("result string from dllproc2");
}
EXTERN_C_END
