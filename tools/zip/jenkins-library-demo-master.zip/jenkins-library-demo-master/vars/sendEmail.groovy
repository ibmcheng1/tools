import com.bcbssc.itbsa.jenkins.GlobalVars

def call(String toAddresses, 
         String ccAddresses, 
         String bccAddresses, 
         String fromAddresses, 
         String replyToAddresses, 
         String subjectLine, 
         String bodyText) {

    try {
        echo ">> Sending an email notification."

        mail bcc: bccAddresses, 
            body: bodyText, 
            cc: ccAddresses, 
            from: fromAddresses, 
            replyTo: replyToAddresses, 
            subject: subjectLine, 
            to: toAddresses
    } catch (err) {
        echo "An error occurred: " + err.message
        currentBuild.result = 'FAILURE'
        throw(err)
    }
}