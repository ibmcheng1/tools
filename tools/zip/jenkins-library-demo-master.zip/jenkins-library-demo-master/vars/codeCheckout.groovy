import com.bcbssc.itbsa.jenkins.GlobalVars

def call(String branchName) {
    try {
        echo ">> Checking out project.  Current branch: " + branchName

        checkout scm

        gitCommit = sh(script: 'git rev-parse --short HEAD', returnStdout: true).trim()
        echo " >> Commit ID: ${gitCommit}" 
            
        return gitCommit
    } catch (err) {
        echo "An error occurred: " + err.message
        currentBuild.result = 'FAILURE'
        throw(err)
    }
}