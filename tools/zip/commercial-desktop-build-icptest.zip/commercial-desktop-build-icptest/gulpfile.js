const gulp = require('gulp');
const HubRegistry = require('gulp-hub');
const browserSync = require('browser-sync');

const conf = require('./conf/gulp.conf');

// Load some files into the registry
const hub = new HubRegistry([conf.path.tasks('*.js')]);

// Tell gulp to use the tasks just loaded
gulp.registry(hub);

gulp.task('build', gulp.series(gulp.parallel('other', 'webpack:dist')));
gulp.task('lint', gulp.series(gulp.parallel('other', 'webpack:lint')));
gulp.task('doc', gulp.series("jsdoc:clean", "jsdoc:generate"));

gulp.task('test', gulp.series('karma:single-run', 'sonar'));
gulp.task('test:dev', gulp.series('karma:single-run'));
gulp.task('test:auto', gulp.series('karma:auto-run'));

// Loop through all envIds and create a serve and serve:dist task for each
conf.envIds.forEach(id => {
  gulp.task('serve:'+id, gulp.series('webpack:watch:'+id, 'watch', 'browsersync:'+id));
  gulp.task('serve:dist:'+id, gulp.series('default', 'browsersync:dist:'+id));
});

gulp.task('default', gulp.series('clean', 'build'));
gulp.task('watch', watch);

function reloadBrowserSync(cb) {
  browserSync.reload();
  cb();
}

function watch(done) {
  gulp.watch(conf.path.tmp('index.html'), reloadBrowserSync);
  done();
}
