process.env.NODE_ENV = 'test';

const path = require('path');

const gulp = require('gulp');
const del = require('del');
const exec = require('child_process').exec;

const conf = require('../conf/gulp.conf');

gulp.task('jsdoc:clean', jsDocClean);
gulp.task('jsdoc:generate', jsDocGenerate);

function jsDocClean() {
  return del([conf.paths.doc]);
}

function jsDocGenerate(done) {
  //exec('node ./node_modules/jsdoc/jsdoc.js -c ./conf/jsdoc.conf.json -d ./doc -t ./node_modules/ink-docstrap/template ./src/**/*.js ./src/**/*.vue', (err, stdout, stderr) => {
  exec('jsdoc -c ./conf/jsdoc.conf.json -d ./doc -t ./node_modules/ink-docstrap/template -r ./src', (err, stdout, stderr) => {
    console.log(stdout);
    console.log(stderr);
    done(err);
  });
}
