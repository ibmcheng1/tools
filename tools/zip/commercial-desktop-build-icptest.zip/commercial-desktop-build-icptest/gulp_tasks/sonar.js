const gulp = require('gulp');
const gsonar = require('gulp-sonar');
const conf = require('../conf/gulp.conf');
const sonarConf = require('../conf/sonar.conf');
const parseArgs = require('minimist');

gulp.task('sonar', sonar);

function sonar() {
    const args = parseArgs(process.argv);

    const branchName = args.BRANCH_NAME || 'dev';

    return gulp.src(conf.paths.src, {read: false}).pipe(gsonar(sonarConf(branchName)));
}
