const gulp = require('gulp');
const browserSync = require('browser-sync');
const spa = require('browser-sync-spa');

const browserSyncConf = require('../conf/browsersync.conf');
const gulpConf = require('../conf/gulp.conf');

browserSync.use(spa());

// Loop through all envIds and create a browsersync and browsersync:dist task for each
gulpConf.envIds.forEach(id => {
    gulp.task('browsersync:'+id, getBrowserSyncServe(id, false));
    gulp.task('browsersync:dist:'+id, getBrowserSyncServe(id, true));
});

function getBrowserSyncServe(/* String */ environment, /* boolean */ isDist){
    return function (done) {
        browserSync.init(browserSyncConf(environment, isDist));
        done();
    }
}
