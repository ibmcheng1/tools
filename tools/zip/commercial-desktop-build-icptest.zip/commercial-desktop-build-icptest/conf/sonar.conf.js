const conf = require('./gulp.conf');
const fs = require('fs');

module.exports = function (branchName) {
  // for some reason, this read is relative to where the command is executed from. Assuming the command is run from the
  // root directory might be dangerous? Maybe?
  var package = JSON.parse(fs.readFileSync('./package.json'));
  return {
    sonar: {
      host: {
        url: 'http://a70lpcomsnrq001.a70adom.bcbssc.com',
      },
      projectKey: package.name,
      projectName: package.name,
      projectVersion: package.version + ":" + branchName,
      sources: conf.paths.src,
      language: 'js',
      sourceEncoding: 'UTF-8',
      javascript: {
        lcov: {
          reportPaths: 'coverage/lcov/lcov.info'
        }
      },
      exec: {
        maxBuffer: 1024*1024
      }
    }
  };
};
