const conf = require('./gulp.conf');

module.exports = function (config) {
    const configuration = {
        basePath: '../',
        singleRun: false,
        autoWatch: true,
        logLevel: 'INFO',
        junitReporter: {
            outputDir: 'test-reports',
            outputFile: 'test-results.xml'
        },
        browsers: [
            'chromeNoSandbox'
        ],
        customLaunchers: {
            chromeNoSandbox: {
                base: 'ChromeHeadless',
                flags: ['--no-sandbox'] // No sandbox flag allows chrome headless to be run in a Docker container
            }
        },
        frameworks: [
            'jasmine'
        ],
        files: [
            'node_modules/es6-shim/es6-shim.js',
            conf.path.src('index.spec.js')
        ],
        preprocessors: {
            [conf.path.src('index.spec.js')]: [
                'webpack'
            ]
        },
        reporters: ['progress', 'coverage', 'junit'],
        coverageReporter: {
            dir: 'coverage/',
            reporters: [
              {type: 'html', subdir: 'html'},
              {type: 'lcov', subdir: 'lcov'}
            ],
            check: {
              // There are other options we may want to add in here. For example, we might change the code coverage for vue files.
              // See https://github.com/karma-runner/karma-coverage/blob/master/docs/configuration.md#check for more info.
                global: {
                    lines: 80,
                    branches: 70,
                    statements: 80,
                    functions: 80,
                    excludes: [
                        '**/*.spec.js',
                        '**/mock/**/*.js',
                        '**/DefaultApplicationControlLinks.js'
                    ]
                }
            }
        },
        webpack: require('./webpack-test.conf'),
        webpackMiddleware: {
            noInfo: true
        },
        plugins: [
            require('karma-jasmine'),
            require('karma-junit-reporter'),
            require('karma-coverage'),
            require('karma-chrome-launcher'),
            require('karma-webpack'),
            require('karma-spec-reporter')
        ]
    };

    config.set(configuration);
};
