const conf = require('./gulp.conf');

function getEnvironmentBuildDirectory (/* String */ builtDir, /* String */ environment) {
    return builtDir + '/' + environment;
}

module.exports = function (/* String */ environment, /* boolean */ isDist) {

  const baseDir = (isDist ?
      [ getEnvironmentBuildDirectory(conf.paths.dist, environment) ] :
      [ getEnvironmentBuildDirectory(conf.paths.tmp, environment), conf.paths.src ]);

  return {
      server: {
          baseDir: baseDir
      },
      open: false
  };

};