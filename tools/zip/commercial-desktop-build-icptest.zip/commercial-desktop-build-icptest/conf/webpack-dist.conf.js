const webpack = require('webpack');
const conf = require('./gulp.conf');
const path = require('path');

const HtmlWebpackPlugin = require('html-webpack-plugin');
const FailPlugin = require('webpack-fail-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const pkg = require('../package.json');
const autoprefixer = require('autoprefixer');

const distEntry = {
    app: `./${conf.path.src('index')}`,
    vendor: Object.keys(pkg.dependencies)
};

const distModule = {
    rules: [{
        test: /\.json$/,
        use: ['json-loader']
    }, {
        test: /\.(js|vue)$/,
        exclude: /node_modules/,
        enforce: 'pre',
        use: [{
            loader: 'eslint-loader',
            options: {
                outputReport: {
                    filePath: '../lint/checkstyle.xml',
                    formatter: require('eslint/lib/formatters/checkstyle')
                }
            }
        }]
    }, {
        test: /\.css$/,
        use: [
            MiniCssExtractPlugin.loader,
            'css-loader?minimize!postcss-loader'
        ]
    }, {
        test: /\.(gif|png|jp(e*)g)$/,
        use: [{
            loader: 'url-loader',
            options: {
                limit: 8000, // convert images < 8kb to base64 strings
                name: 'images/[hash]-[name].[ext]'
            }
        }]
    }, {
        test: /\.scss$/,
        use: [{
            loader: 'style-loader' // creates style nodes from JS strings
        }, {
            loader: 'css-loader' // translates CSS into CommonJS
        }, {
            loader: 'sass-loader' // compiles Sass to CSS again to fix invalid css
        }, {
            loader: 'string-replace-loader',
            options: {
                multiple: [
                    {search: '@media\\s*\\(min-width\\:\\s*576px\\)', replace: '.breakpoint-min-sm', flags: 'g', strict: true},
                    {search: '@media\\s*\\(min-width\\:\\s*768px\\)', replace: '.breakpoint-min-md', flags: 'g', strict: true},
                    {search: '@media\\s*\\(min-width\\:\\s*992px\\)', replace: '.breakpoint-min-lg', flags: 'g', strict: true},
                    {search: '@media\\s*\\(min-width\\:\\s*1200px\\)', replace: '.breakpoint-min-xl', flags: 'g', strict: true},
                    {search: '@media\\s*\\(max-width\\:\\s*575\\.98px\\)', replace: '.breakpoint-max-sm', flags: 'g', strict: true},
                    {search: '@media\\s*\\(max-width\\:\\s*767\\.98px\\)', replace: '.breakpoint-max-md', flags: 'g', strict: true},
                    {search: '@media\\s*\\(max-width\\:\\s*991\\.98px\\)', replace: '.breakpoint-max-lg', flags: 'g', strict: true},
                    {search: '@media\\s*\\(max-width\\:\\s*1199\\.98px\\)', replace: '.breakpoint-max-xl', flags: 'g', strict: true}
                ]
            }
        },
        {
            loader: 'sass-loader' // compiles Sass to CSS
        }]
    }, {
        test: /.(ttf|otf|eot|svg|woff(2)?)(\?[a-z0-9]+)?$/,
        use: [{
            loader: 'file-loader',
            options: {
                name: '[name].[ext]'
            }
        }]
    }, {
        test: /\.js$/,
        exclude: /node_modules/,
        use: ['babel-loader']
    }, {
        test: /\.vue$/,
        use: ['vue-loader']
    }]
};

const distOptimization = {
    minimize: true,
    splitChunks: {name: 'vendor'}
};

const distPlugins = [
    new webpack.optimize.OccurrenceOrderPlugin(),
    new webpack.NoEmitOnErrorsPlugin(),
    // The fail plugin should not be necessary in Webpack 2+, but failures are very inconsistent without it.
    // It needs to stay in place until research can be done to figure out what plugin(s) are not behaving
    // when it comes to emitting failures/errors.
    FailPlugin,
    new HtmlWebpackPlugin({
        template: conf.path.src('index.html')
    }),
    new MiniCssExtractPlugin({
        filename: '[name]-[hash].css',
        chunkFilename: '[id]-[hash].css'
    }),
    new webpack.LoaderOptionsPlugin({
        options: {
            postcss: () => [autoprefixer]
        }
    })
];

module.exports = [{
    // Dev build
    mode: 'production', // treat dist builds as a production build for optimizations
    entry: distEntry,
    output: {
        path: path.join(process.cwd(), conf.paths.dist, 'dev'),
        filename: '[name]-[hash].js'
    },
    module: distModule,
    optimization: distOptimization,
    plugins: distPlugins.concat([new webpack.DefinePlugin({
        'process.env.NODE_ENV': '"dev"'
    })])
}, {
    // Virtual build
    mode: 'production', // treat dist builds as a production build for optimizations
    entry: distEntry,
    output: {
        path: path.join(process.cwd(), conf.paths.dist, 'virtual'),
        filename: '[name]-[hash].js'
    },
    module: distModule,
    optimization: distOptimization,
    plugins: distPlugins.concat([new webpack.DefinePlugin({
        'process.env.NODE_ENV': '"virtual"'
    })])
}, {
    // Unit build
    mode: 'production', // treat dist builds as a production build for optimizations
    entry: distEntry,
    output: {
        path: path.join(process.cwd(), conf.paths.dist, 'unit'),
        filename: '[name]-[hash].js'
    },
    module: distModule,
    optimization: distOptimization,
    plugins: distPlugins.concat([new webpack.DefinePlugin({
        'process.env.NODE_ENV': '"unit"'
    })])
}, {
    // System build
    mode: 'production', // treat dist builds as a production build for optimizations
    entry: distEntry,
    output: {
        path: path.join(process.cwd(), conf.paths.dist, 'system'),
        filename: '[name]-[hash].js'
    },
    module: distModule,
    optimization: distOptimization,
    plugins: distPlugins.concat([new webpack.DefinePlugin({
        'process.env.NODE_ENV': '"system"'
    })])
}, {
    // Qual build
    mode: 'production', // treat dist builds as a production build for optimizations
    entry: distEntry,
    output: {
        path: path.join(process.cwd(), conf.paths.dist, 'qual'),
        filename: '[name]-[hash].js'
    },
    module: distModule,
    optimization: distOptimization,
    plugins: distPlugins.concat([new webpack.DefinePlugin({
        'process.env.NODE_ENV': '"qual"'
    })])
}, {
    // Production build
    mode: 'production', // treat dist builds as a production build for optimizations
    entry: distEntry,
    output: {
        path: path.join(process.cwd(), conf.paths.dist, 'production'),
        filename: '[name]-[hash].js'
    },
    module: distModule,
    optimization: distOptimization,
    plugins: distPlugins.concat([new webpack.DefinePlugin({
        'process.env.NODE_ENV': '"production"'
    })])
}];
