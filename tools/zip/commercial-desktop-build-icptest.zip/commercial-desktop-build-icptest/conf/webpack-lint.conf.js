// ESLint configuration options:
// https://eslint.org/docs/user-guide/configuring

//  @ ./src/app sync \.(js|ts|tsx)$
//  @ ./src/index.spec.js

const webpack = require('webpack');
const conf = require('./gulp.conf');
const path = require('path');

const FailPlugin = require('webpack-fail-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const pkg = require('../package.json');
const autoprefixer = require('autoprefixer');

module.exports = {
    mode: 'development',
    entry: {
        app: `./${conf.path.src('index')}`,
        test: `./${conf.path.src('index.spec')}`,
        vendor: Object.keys(pkg.dependencies)
    },
    output: {
        path: path.join(process.cwd(), conf.paths.dist),
        filename: '[name]-[hash].js'
    },
    module: {
        rules: [{
            test: /\.(js|vue)$/,
            exclude: /node_modules/,
            enforce: 'pre',
            use: [{
                loader: 'eslint-loader',
                options: {
                    outputReport: {
                        filePath: '../lint/checkstyle.xml',
                        formatter: require('eslint/lib/formatters/checkstyle')
                    }
                }
            }]
        }, {
            test: /\.css$/,
            use: [
                MiniCssExtractPlugin.loader,
                'css-loader'
            ]
        }, {
            test: /\.(gif|png|jp(e*)g)$/,
            use: [{
                loader: 'url-loader',
                options: {
                    limit: 8000, // convert images < 8kb to base64 strings
                    name: 'images/[hash]-[name].[ext]'
                }
            }]
        }, {
            test: /\.scss$/,
            use: [{
                loader: 'style-loader' // creates style nodes from JS strings
            }, {
                loader: 'css-loader' // translates CSS into CommonJS
            }, {
                loader: 'sass-loader' // compiles Sass to CSS again to fix invalid css
            }, {
                loader: 'string-replace-loader',
                options: {
                    multiple: [
                        {search: '@media\\s*\\(min-width\\:\\s*576px\\)', replace: '.breakpoint-min-sm', flags: 'g', strict: true},
                        {search: '@media\\s*\\(min-width\\:\\s*768px\\)', replace: '.breakpoint-min-md', flags: 'g', strict: true},
                        {search: '@media\\s*\\(min-width\\:\\s*992px\\)', replace: '.breakpoint-min-lg', flags: 'g', strict: true},
                        {search: '@media\\s*\\(min-width\\:\\s*1200px\\)', replace: '.breakpoint-min-xl', flags: 'g', strict: true},
                        {search: '@media\\s*\\(max-width\\:\\s*575\\.98px\\)', replace: '.breakpoint-max-sm', flags: 'g', strict: true},
                        {search: '@media\\s*\\(max-width\\:\\s*767\\.98px\\)', replace: '.breakpoint-max-md', flags: 'g', strict: true},
                        {search: '@media\\s*\\(max-width\\:\\s*991\\.98px\\)', replace: '.breakpoint-max-lg', flags: 'g', strict: true},
                        {search: '@media\\s*\\(max-width\\:\\s*1199\\.98px\\)', replace: '.breakpoint-max-xl', flags: 'g', strict: true}
                    ]
                }
            }, {
                loader: 'sass-loader' // compiles Sass to CSS
            }]
        }, {
            test: /.(ttf|otf|eot|svg|woff(2)?)(\?[a-z0-9]+)?$/,
            use: [{
                loader: 'file-loader',
                options: {
                    name: '[name].[ext]'
                }
            }]
        }, {
            test: /\.vue$/,
            use: ['vue-loader']
        }]
    },
    plugins: [
        // The fail plugin should not be necessary in Webpack 2+, but failures are very inconsistent without it.
        // It needs to stay in place until research can be done to figure out what plugin(s) are not behaving
        // when it comes to emitting failures/errors.
        FailPlugin,
        new MiniCssExtractPlugin({
            filename: '[name].css',
            chunkFilename: '[id].css'
        }),
        new webpack.LoaderOptionsPlugin({
            options: {
                postcss: () => [autoprefixer]
            }
        })
    ]
};
