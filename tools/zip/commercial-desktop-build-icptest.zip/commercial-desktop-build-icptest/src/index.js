import './setup-components';

import Vue from 'vue';
import VueRouter from 'vue-router';

Vue.use(VueRouter);

// Import the necessary CSS files for theming
import 'bootstrap-vue/dist/bootstrap-vue.css';
import 'font-awesome/css/font-awesome.css';
import './customer-service-manager.scss';
import './icons-custom.css';

import DataStore from './app/store/DataStore.js';
import {routes} from './app/router/routes.js';

const router = new VueRouter({
    mode: 'history',
    routes
});

export default new Vue({
    el: '#root',
    store: DataStore.store,
    router,
    render: h => h('router-view')
});
