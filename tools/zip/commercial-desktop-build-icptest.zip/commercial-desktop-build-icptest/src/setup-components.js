import BootstrapVue from 'bootstrap-vue';
import Vue from 'vue';

import FilterUtil from './app/util/FilterUtil.js';

Vue.use(BootstrapVue);

// Define components that are globally available.
import Accordion from './app/layout-components/Accordion.vue';
import AccordionGroup from './app/layout-components/AccordionGroup.vue';
import AccordionItem from './app/layout-components/AccordionItem.vue';
import Alerts from './app/components/Alerts.vue';
import AppResizePanesComponent from './app/layout-components/AppResizePanes.vue';
import AppTabPanelComponent from './app/layout-components/AppTabPanel.vue';
import AppWindowManagerComponent from './app/layout-components/AppWindowManager.vue';
import CallTimer from './app/components/CallTimer.vue';
import ContactHistory from './app/components/ContactHistory.vue';
import ContractSummary from './app/components/ContractSummary.vue';
import DesktopApplicationControls from './app/components/DesktopApplicationControls.vue';
import EmulatorSession from './app/components/EmulatorSession.vue';
import ExceptionsSummary from './app/components/ExceptionsSummary.vue';
import FamilySummary from './app/components/FamilySummary.vue';
import Links from './app/components/Links.vue';
import SubscriberSummary from './app/components/SubscriberSummary.vue';
import PatientSummary from './app/components/PatientSummary.vue';
import PhoneControls from './app/components/phone-controls/PhoneControls.vue';
import ActivitySummary from './app/components/ActivitySummary.vue';
import BillingSummarySubscriber from './app/components/BillingSummarySubscriber.vue';

Vue.component('accordion', Accordion);
Vue.component('accordion-group', AccordionGroup);
Vue.component('accordion-item', AccordionItem);
Vue.component('alerts', Alerts);
Vue.component('app-resize-panes', AppResizePanesComponent);
Vue.component('app-tab-panel', AppTabPanelComponent);
Vue.component('app-window-manager', AppWindowManagerComponent);
Vue.component('call-timer', CallTimer);
Vue.component('contact-history', ContactHistory);
Vue.component('contract-summary', ContractSummary);
Vue.component('desktop-application-controls', DesktopApplicationControls);
Vue.component('emulator-session', EmulatorSession);
Vue.component('exceptions-summary', ExceptionsSummary);
Vue.component('family-summary', FamilySummary);
Vue.component('links', Links);
Vue.component('subscriber-summary', SubscriberSummary);
Vue.component('patient-summary', PatientSummary);
Vue.component('phone-controls', PhoneControls);
Vue.component('activity-summary', ActivitySummary);

Vue.component('billing-summary-subscriber', BillingSummarySubscriber);

/*
 * Define a filter for Vue to use to substring text.
 */
Vue.filter('substring', (text, start, length) => {
    return text.substring(start, length);
});

/*
 * Define a filter for Vue to use for dates (moments).
 */
Vue.filter('moment', date => {
    return FilterUtil.formatDate(date);
});

/*
 * Define a filter for Vue to use for currency.
 */
Vue.filter('currency', value => {
    return FilterUtil.formatCurrency(value);
});
