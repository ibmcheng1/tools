/**
 * The main application namespace
 * @namespace app
 */
