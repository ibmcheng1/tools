<template>
    <app-window-manager :layout="desktopView"/>
</template>

<script>
import {csrDesktopLayout} from './layout-components/layouts/DesktopLayout-CSR.js';

export default {
    name: 'Main',
    props: {
        desktopView: {
            type: Object,
            default: () => {
                return csrDesktopLayout;
            }
        }
    }
};
</script>
