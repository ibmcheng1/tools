import Vue from 'vue';
import Main from './Main.vue';

describe('Main', () => {
    let component;

    function _createComponent() {
        const Constructor = Vue.extend(Main);

        // build the component
        component = new Constructor();
    }

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('is named Main', () => {
        expect(Main.name).toEqual('Main');
    });

    it('returns CSR layout name by default', () => {
        _createComponent();

        expect(component.desktopView.layoutName).toBe('CSR');
    });
});
