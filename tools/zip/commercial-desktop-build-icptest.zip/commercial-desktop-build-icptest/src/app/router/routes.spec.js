import {createLayoutProp} from './routes.js';

describe('Routes', () => {
    it('csr-desktop on route, layout name is CSR', () => {
        const currRoute = {
            params: {
                desktopUrl: 'csr-desktop'
            }
        };
        const layout = createLayoutProp(currRoute);
        expect(layout.desktopView.layoutName).toBe('CSR');
    });

    it('mcs-desktop on route, layout name is MCS', () => {
        const currRoute = {
            params: {
                desktopUrl: 'mcs-desktop'
            }
        };
        const layout = createLayoutProp(currRoute);
        expect(layout.desktopView.layoutName).toBe('MCS');
    });

    it('mbr-desktop on route, layout name is MBR', () => {
        const currRoute = {
            params: {
                desktopUrl: 'mbr-desktop'
            }
        };
        const layout = createLayoutProp(currRoute);
        expect(layout.desktopView.layoutName).toBe('MBR');
    });

    it('while on mcs-desktop, there is a component/tab called Exceptions Summary', () => {
        const currRoute = {
            params: {
                desktopUrl: 'mcs-desktop'
            }
        };
        const layout = createLayoutProp(currRoute);
        expect(layout.desktopView.panes[0].panes[1].layout[0].layout[1].component).toBe('exceptions-summary');
    });

    it('while on the mbr-desktop Subscriber Tab, there is a component called Billing Summary', () => {
        const currRoute = {
            params: {
                desktopUrl: 'mbr-desktop'
            }
        };
        const layout = createLayoutProp(currRoute);
        expect(layout.desktopView.panes[0].panes[1].layout[2].layout[0].component).toBe('billing-summary-subscriber');
    });
});
