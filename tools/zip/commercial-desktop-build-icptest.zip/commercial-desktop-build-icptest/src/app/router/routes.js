import Main from '../../app/Main.vue';
import {csrDesktopLayout} from '../layout-components/layouts/DesktopLayout-CSR.js';
import {mcsDesktopLayout} from '../layout-components/layouts/DesktopLayout-MCS.js';
import {mbrDesktopLayout} from '../layout-components/layouts/DesktopLayout-MBR.js';

function createLayoutProp(route) {
    if (route.params.desktopUrl === 'csr-desktop') {
        return {desktopView: csrDesktopLayout};
    } else if (route.params.desktopUrl === 'mcs-desktop') {
        return {desktopView: mcsDesktopLayout};
    } else if (route.params.desktopUrl === 'mbr-desktop') {
        return {desktopView: mbrDesktopLayout};
    }
}

export const routes = [
    {
        path: '/',
        component: Main,
        props: createLayoutProp
    },
    {
        path: '/:desktopUrl',
        component: Main,
        props: createLayoutProp
    },
    {
        path: '*',
        components: {
            default: Main
        }
    }
];

export {createLayoutProp};
