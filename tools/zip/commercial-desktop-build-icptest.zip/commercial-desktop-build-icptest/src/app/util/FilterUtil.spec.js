import FilterUtil from './FilterUtil.js';

describe('FilterUtil formatting tests', () => {
    it('expect FilterUtil not be be null', () => {
        expect(FilterUtil).not.toBe(null);
    });

    it('expect FilterUtil.formatCurrency(null) to return \'-\'', () => {
        expect(FilterUtil.formatCurrency(null)).toEqual('-');
    });

    let undefinedValue;
    it('expect FilterUtil.formatCurrency(undefined) to return \'-\'', () => {
        expect(FilterUtil.formatCurrency(undefinedValue)).toEqual('-');
    });

    it('expect FilterUtil.formatCurrency(\'1\') to return two places of decimal', () => {
        expect(FilterUtil.formatCurrency('1')).toEqual('1.00');
    });

    it('expect FilterUtil.formatCurrency(\'1.550\') to return two places of decimal', () => {
        expect(FilterUtil.formatCurrency('1.550')).toEqual('1.55');
    });

    it('expect FilterUtil.formatDate(null) to return \'-\'', () => {
        expect(FilterUtil.formatDate(null)).toEqual('-');
    });

    it('expect FilterUtil.formatDate(undefined) to return \'-\'', () => {
        expect(FilterUtil.formatDate(undefinedValue)).toEqual('-');
    });

    it('expect FilterUtil.formatDate(\'2003-05-09\') to return \'05/09/2003\'', () => {
        expect(FilterUtil.formatDate('2003-05-09')).toEqual('05/09/2003');
    });
});
