import StringUtil from './StringUtil.js';

describe('StringUtil.isBlank()', () => {
    it('expect StringUtil not to be null', () => {
        expect(StringUtil).not.toBe(null);
    });

    it('expect StringUtil.isBlank(\'\')  to be true', () => {
        expect(StringUtil.isBlank('')).toBe(true);
    });

    it('expect StringUtil.isBlank(\' \') to be true', () => {
        expect(StringUtil.isBlank(' ')).toBe(true);
    });

    it('expect StringUtil.isBlank(null) to be true', () => {
        expect(StringUtil.isBlank(null)).toBe(true);
    });

    let value;
    it('expect StringUtil.isBlank(undefined) to be true', () => {
        expect(StringUtil.isBlank(value)).toBe(true);
    });

    it('expect StringUtil.isBlank(\'hello\') to be false', () => {
        expect(StringUtil.isBlank('hello')).toBe(false);
    });
});

describe('StringUtil.isNotBlank()', () => {
    it('expect StringUtil.isNotBlank(\'\')  to be false', () => {
        expect(StringUtil.isNotBlank('')).toBe(false);
    });

    it('expect StringUtil.isNotBlank(\' \') to be false', () => {
        expect(StringUtil.isNotBlank(' ')).toBe(false);
    });

    it('expect StringUtil.isNotBlank(null) to be false', () => {
        expect(StringUtil.isNotBlank(null)).toBe(false);
    });

    let value;
    it('expect StringUtil.isNotBlank(undefined) to be false', () => {
        expect(StringUtil.isNotBlank(value)).toBe(false);
    });

    it('expect StringUtil.isNotBlank(\'hello\') to be true', () => {
        expect(StringUtil.isNotBlank('hello')).toBe(true);
    });
});

describe('StringUtil.isString()', () => {
    it('expect StringUtil.isString(\'hello\')  to be true', () => {
        expect(StringUtil.isString('hello')).toBe(true);
    });

    it('expect StringUtil.isString(\'\') to be true', () => {
        expect(StringUtil.isString('')).toBe(true);
    });

    it('expect StringUtil.isString(null) to be false', () => {
        expect(StringUtil.isString(null)).toBe(false);
    });

    let value;
    it('expect StringUtil.isString(undefined) to be false', () => {
        expect(StringUtil.isString(value)).toBe(false);
    });

    it('expect StringUtil.isString({}) to be false', () => {
        expect(StringUtil.isString({})).toBe(false);
    });

    it('expect StringUtil.isString([]) to be false', () => {
        expect(StringUtil.isString([])).toBe(false);
    });
});

describe('StringUtil.isNullOrUndefined()', () => {
    it('expect StringUtil.isNullOrUndefined(\'hello\')  to be false', () => {
        expect(StringUtil.isNullOrUndefined('hello')).toBe(false);
    });

    it('expect StringUtil.isNullOrUndefined(null) to be true', () => {
        expect(StringUtil.isNullOrUndefined(null)).toBe(true);
    });

    let value;
    it('expect StringUtil.isNullOrUndefined(undefined) to be true', () => {
        expect(StringUtil.isNullOrUndefined(value)).toBe(true);
    });

    it('expect StringUtil.isNullOrUndefined({}) to be false', () => {
        expect(StringUtil.isNullOrUndefined({})).toBe(false);
    });

    it('expect StringUtil.isString([]) to be false', () => {
        expect(StringUtil.isString([])).toBe(false);
    });
});

describe('StringUtil.toString()', () => {
    it('expect StringUtil.toString(\'hello\')  to be \'hello\'', () => {
        expect(StringUtil.toString('hello')).toEqual('hello');
    });

    it('expect StringUtil.toString(null) to be \'\'', () => {
        expect(StringUtil.toString(null)).toEqual('');
    });

    let value;
    it('expect StringUtil.toString(undefined) to be \'\'', () => {
        expect(StringUtil.toString(value)).toEqual('');
    });

    it('expect StringUtil.toString(null, \'default\') to be \'default\'', () => {
        expect(StringUtil.toString(null, 'default')).toEqual('default');
    });

    it('expect StringUtil.toString([]]) to be \'\'', () => {
        expect(StringUtil.toString([])).toEqual('');
    });
});

describe('StringUtil.upperCase()', () => {
    it('expect StringUtil.upperCase(\'HELLO\')  to be \'HELLO\'', () => {
        expect(StringUtil.upperCase('HELLO')).toEqual('HELLO');
    });

    it('expect StringUtil.upperCase(\'hello\')  to be \'HELLO\'', () => {
        expect(StringUtil.upperCase('hello')).toEqual('HELLO');
    });

    it('expect StringUtil.upperCase(null) to be \'\'', () => {
        expect(StringUtil.upperCase(null)).toEqual('');
    });

    let value;
    it('expect StringUtil.upperCase(undefined) to be \'\'', () => {
        expect(StringUtil.upperCase(value)).toEqual('');
    });
});

describe('StringUtil.lowerCase()', () => {
    it('expect StringUtil.lowerCase(\'hello\')  to be \'hello\'', () => {
        expect(StringUtil.lowerCase('hello')).toEqual('hello');
    });

    it('expect StringUtil.lowerCase(\'HELLO\')  to be \'hello\'', () => {
        expect(StringUtil.lowerCase('HELLO')).toEqual('hello');
    });

    it('expect StringUtil.lowerCase(null) to be \'\'', () => {
        expect(StringUtil.lowerCase(null)).toEqual('');
    });

    let value;
    it('expect StringUtil.lowerCase(undefined) to be \'\'', () => {
        expect(StringUtil.lowerCase(value)).toEqual('');
    });
});

describe('StringUtil.leftPad()', () => {
    it('expect StringUtil.leftPad(\'hello\', \'0\', 6) to be \'0hello\'', () => {
        expect(StringUtil.leftPad('hello', '0', 6)).toEqual('0hello');
    });

    it('expect StringUtil.leftPad(\'hello\', 0, 6) to be \'0hello\'', () => {
        expect(StringUtil.leftPad('hello', 0, 6)).toEqual(' hello');
    });

    it('expect StringUtil.leftPad(\'hello\', \'0\', 0)  to be \'hello\'', () => {
        expect(StringUtil.leftPad('hello', '0', 0)).toEqual('hello');
    });

    it('expect StringUtil.leftPad(\'hello\', \'1234560\', 7) to be \'12hello\'', () => {
        expect(StringUtil.leftPad('hello', '1234560', 7)).toEqual('12hello');
    });

    it('expect StringUtil.leftPad(\'h\', \'00000\', 6) to be \'00000h\'', () => {
        expect(StringUtil.leftPad('h', '0000', 6)).toEqual('00000h');
    });
});
