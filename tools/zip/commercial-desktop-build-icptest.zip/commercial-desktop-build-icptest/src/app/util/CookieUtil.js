/**
 * A utility module providing common cookie functionality.
 *
 * @module CookieUtil
 * @memberof app
 */

/**
 * Retrieve the default coverage type from the cookie store
 *
 * @param {String} name The name of the cookie
 * @param {Node} name The document of the page
 */
exports.getDefaultCoverageCookie = function (document) {
    return this.getCookie('com.bcbssc.desktop.DefaultCoverageType', document);
};

/**
 * Retrieve a cookie name from the cookie store
 *
 * @param {String} name The name of the cookie
 * @param {Node} name The document of the page
 */
exports.getCookie = function (name, document) {
    const match = document.cookie.match(new RegExp(name + '=([^;]+)'));

    if (match) {
        return match[1];
    }

    return;
};

/**
 * Deletes all cookies
 */
exports.deleteCookies = function () {
    const cookies = document.cookie.split(';');

    for (let i = 0; i < cookies.length; i++) {
        const cookie = cookies[i];
        const equalPosition = cookie.indexOf('=');
        const name = equalPosition > -1 ? cookie.substr(0, equalPosition) : cookie;
        document.cookie = name + '=;expires=Thu, 01 Jan 1970 00:00:00 GMT';
    }
};
