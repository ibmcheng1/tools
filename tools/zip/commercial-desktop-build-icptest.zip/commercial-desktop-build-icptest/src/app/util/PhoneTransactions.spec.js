import StateMachine from 'javascript-state-machine';
import PhoneTransactions from './PhoneTransactions.js';

describe('PhoneTransactions tests', () => {
    let psm = null;

    beforeEach(() => {
        psm = new StateMachine(PhoneTransactions);
    });

    it('expect PhoneTransactions.onEnterLoaded() to return status \'LOGGED OUT\'', () => {
        psm.onEnterLoaded();
        expect(psm.phoneStatusMsg).toEqual('LOGGED OUT');
    });

    it('expect PhoneTransactions.onEnterCallCenterSelection() to return a list of callCenters', () => {
        psm.onEnterCallCenterSelection();
        expect(psm.callCenters.length).toBe(4);
    });

    it('expect PhoneTransactions.init to be \'loading\'', () => {
        expect(PhoneTransactions.init).toBe('loading');
    });
});
