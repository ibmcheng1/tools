/**
 * Provide the state and transition declarations for a phone control or similar component
 *
 * @module PhoneTransactions
 * @memberof app
 */
import StateMachineHistory from 'javascript-state-machine/lib/history';

export default {
    data: {
        phoneStatusMsg: '',
        callCenters: []
    },
    methods: {
        /**
         * Enter 'loaded' state
         */
        onEnterLoaded() {
            this.phoneStatusMsg = 'LOGGED OUT';
        },
        /**
         * Enter 'callcenterselection' state
         */
        onEnterCallCenterSelection() {
            // TODO load data from RULEs
            this.callCenters = [];
            this.callCenters.push('Sandbox');
            this.callCenters.push('BlueChoice Health Plan');
            this.callCenters.push('Provider Services');
            this.callCenters.push('National Alliance');
        },
        /**
         * Log state and history
         * TODO Enable/Disable this development logging
         * @param {*} lifecycle
         */
        onTransition(lifecycle) {
            console.log('onTransition: transition: [' + lifecycle.transition + '] from: [' + lifecycle.from + '] to: [' + lifecycle.to + '] history: [' + this.history + ']');
        }
    },
    plugins: [
        // provides state transaction history, e.g <code>StateMachine.history()</code>
        new StateMachineHistory()
    ],
    init: 'loading',
    transitions: [
        {name: 'start', from: 'loading', to: 'loaded'},
        {name: 'displayCallCenters', from: 'loaded', to: 'callCenterSelection'},
        {name: 'reset', from: '*', to: () => {
            return 'loading';
        }}
    ]
};
