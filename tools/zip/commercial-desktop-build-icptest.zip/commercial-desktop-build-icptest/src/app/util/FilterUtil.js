/**
 * A utility module providing common filter functionality. The presentation tier uses these methods when rendering view
 * data. The test layer will use these methods when verifying test data against that rendered by the view.
 *
 * @module FilterUtil
 * @memberof app
 */
import StringUtil from './StringUtil.js';
import moment from 'moment';

/**
 * Format a date value using a predefined date format template.
 *
 * @param {String} date The date to format
 * @return {String} the date in the following format 'MM/DD/YYYY', or '-' if the date value is not valid.
 */
exports.formatDate = function (date) {
    let formattedDate = '-';
    if (StringUtil.isNotBlank(date)) {
        formattedDate = moment(date).format('MM/DD/YYYY');
    }
    return formattedDate;
};

/**
 * Format a currency value to two fixed places of decimal.
 *
 * @param {String} currency The currency to format
 * @return {String} the currency formatted to two fixed decimal places, or '-' if the currency value is not valid.
 */
exports.formatCurrency = function (currency) {
    let formattedCurrency = '-';
    if (StringUtil.isNotBlank(currency) && !isNaN(currency)) {
        formattedCurrency = parseFloat(currency).toFixed(2);
    }
    return formattedCurrency;
};
