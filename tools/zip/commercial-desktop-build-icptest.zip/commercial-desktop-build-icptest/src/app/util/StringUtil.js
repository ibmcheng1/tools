/**
 * @module StringUtil
 * @memberof app.util
 */

/**
 * Get the string representation of the value, converts the value to string.
 *
 * @param {object} value The value to convert
 * @param {string} [defaultValue=''] The default value to return.
 * @return {string|defaultValue}
 */
exports.toString = function (value) {
    let returnValue = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';

    if (!this.isNullOrUndefined(value)) {
        if (this.isString(value)) {
            returnValue = value;
        } else {
            returnValue = String(value);
        }
    }
    return returnValue;
};

/**
 * Checks if value is null or undefined
 *
 * @param {object} value The value to check
 * @return {boolean} true if undefined or null, false otherwise
 */
exports.isNullOrUndefined = function (value) {
    return value === undefined || value === null;
};

/**
 * Checks whether value is a string primitive type.
 *
 * @param {object} value the value to check
 * @return {boolean} true if value is string primitive type or false otherwise.
 * @example
 *     StringUtils.isString('123'); // return true
 */
exports.isString = function (value) {
    return typeof value === 'string';
};

/**
 * Checks if value is empty or contains only whitespaces.
 *
 * @param {string} value the value to check
 * @return {boolean} true if is empty or contains only whitespaces or false otherwise.
 * @example
*      StringUtils.isBlank(''); // returns true
 */
exports.isBlank = function (value) {
    const returnValue = this.toString(value);
    return returnValue.trim().length === 0;
};

/**
 * Checks if value is not empty.
 *
 * @param {string} value the value to check
 * @return {boolean} false if is empty or contains only whitespaces or true otherwise.
 * @example
 *     StringUtils.isNotBlank('123') // returns true
 */
exports.isNotBlank = function (value) {
    return !this.isBlank(value);
};

/**
 * Converts string to upper case.
 *
 * @param  {string} value the value to convert to upper case.
 * @return {string} the upper case string.
 * @example
 *     StringUtils.upperCase('abc'); // returns 'ABC'
 */
exports.upperCase = function (value) {
    const returnValue = this.toString(value);
    return returnValue.toUpperCase();
};

/**
 * Converts string to lower case.
 *
 * @param {string} value the value to convert to lower case.
 * @return {string} the upper case string.
 * @example
 *     StringUtils.lowerCase('ABC'); // returns 'abc'
 */
exports.lowerCase = function (value) {
    const returnValue = this.toString(value);
    return returnValue.toLowerCase();
};

/**
 * Left pads the given string with a character (default to spaces),
 * up to a total length.
 *
 * @param {string} value the value to be padded.
 * @param {string} padString the string used for padding.
 * @param {int} totalLength the expected length of the string to be returned.
 * @return {string} the padded string.
 * @example
 *     StringUtils.leftPad('999', '0', 10); // returns '0000000999'
 * @example
 *     StringUtils.leftPad('abc', '123456', 5); // returns '12abc'
 */
exports.leftPad = function (value, padString, totalLength) {
    totalLength >>= 0; // truncate if number or convert non-number to 0;
    padString = String((typeof padString === 'string' ? padString : ' '));
    if (value.length > totalLength) {
        return String(value);
    }

    totalLength -= value.length;
    if (totalLength > padString.length) {
        padString += padString.repeat(totalLength / padString.length); // append to original to ensure we are longer than needed
    }
    const retVal = padString.slice(0, totalLength) + String(value);
    return retVal;
};
