import Vue from 'vue';
import Alerts from './Alerts.vue';
import DesktopBaseComponent from './DesktopBaseComponent.vue';
import DataStore from './../store/DataStore.js';
import {mockAlerts as fullMock} from './../store/mock/alerts/AlertsMock.js';
import {mockNoAlerts as noAlertsMock} from './../store/mock/alerts/NoAlertsMock.js';
import assigndeep from 'assign-deep';

describe('Alerts', () => {
    let component;

    function _createComponent(model) {
        const Constructor = Vue.extend(Alerts);
        DataStore.store.state.alerts = model;
        component = new Constructor({
            store: DataStore.store
        }).$mount();
    }

    beforeEach(() => {
        // prevent the component from trying to load data
        spyOn(DesktopBaseComponent.methods, 'refreshData').and.returnValue(1);
    });

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
        DataStore.store.dispatch('setDatabaseId', null);
    });

    it('is named Alerts', () => {
        expect(Alerts.name).toEqual('Alerts');
    });

    it('retrieves computed database ID', (done) => {
        done();
    });

    it('does not display alerts section when alerts object is empty', done => {
        _createComponent({});
        Vue.nextTick(() => {
            const node = component.$el.querySelectorAll('[data-test-ref="alerts-section"]');
            expect(node.length).toEqual(0);
            done();
        });
    });

    it('returns data when a database ID exists', done => {
        _createComponent(fullMock);
        DataStore.store.dispatch('setDatabaseId', 1);
        Vue.nextTick(() => {
            component.getData().then((data) => {
                expect(data.alerts.length).toEqual(fullMock.alerts.length);
                done();
            });
        });
    });

    it('clears alerts data when clearData is called', done => {
        _createComponent(fullMock);
        component.clearData();
        Vue.nextTick(() => {
            expect(component.alerts).toEqual({});
            done();
        });
    });

    it('returns no data when database ID does not exist', done => {
        _createComponent(fullMock);
        DataStore.store.dispatch('setDatabaseId', null);
        setTimeout(() => {
            component.getData().then(data => {
                expect(data).toBeUndefined();
                done();
            });
        }, 500);
    });

    it('does not display tabs when there are no subscriber products', done => {
        _createComponent(assigndeep({}, fullMock, {subscriberProducts: []}));
        Vue.nextTick(() => {
            const node = component.$el.querySelector('[data-test-ref="alerts-tabs"]');
            expect(node).toBeNull();
            done();
        });
    });

    it('displays the Health tab when subscriber has medical coverage', done => {
        _createComponent(assigndeep({}, fullMock, {subscriberProducts: ['Products.MEDICAL']}));
        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="product-tab-title"]');
            let hasHealthTab = false;
            for (const node of nodes) {
                if (node.parentNode.innerText.trim() === 'Health') {
                    hasHealthTab = true;
                    break;
                }
            }
            expect(hasHealthTab).toBeTruthy();
            done();
        });
    });

    it('displays the Dental tab when subscriber has dental coverage', done => {
        _createComponent(assigndeep({}, fullMock, {subscriberProducts: ['Products.DENTAL']}));
        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="product-tab-title"]');
            let hasHealthTab = false;
            for (const node of nodes) {
                if (node.parentNode.innerText.trim() === 'Dental') {
                    hasHealthTab = true;
                    break;
                }
            }
            expect(hasHealthTab).toBeTruthy();
            done();
        });
    });

    it('makes the Health tab active when the product selected is medical', done => {
        _createComponent(fullMock);
        Vue.nextTick(() => {
            const tabs = component.$el.querySelectorAll('[data-test-ref="product-tab-title"]');
            for (const tab of tabs) {
                if (tab.parentNode.innerText.trim() === 'Health') {
                    expect(tab.parentNode.className.indexOf('active')).toBeGreaterThanOrEqual(0);
                }
                if (tab.parentNode.innerText.trim() === 'Dental') {
                    expect(tab.parentNode.className.indexOf('active')).toBeGreaterThanOrEqual(-1);
                }
            }
            done();
        });
    });

    it('makes the Dental tab active when the product selected is dental', done => {
        _createComponent(assigndeep({}, fullMock, {selectedProductCode: 'Products.DENTAL'}));
        Vue.nextTick(() => {
            const tabs = component.$el.querySelectorAll('[data-test-ref="product-tab-title"]');
            for (const tab of tabs) {
                if (tab.parentNode.innerText.trim() === 'Health') {
                    expect(tab.parentNode.className.indexOf('active')).toBeGreaterThanOrEqual(-1);
                }
                if (tab.parentNode.innerText.trim() === 'Dental') {
                    expect(tab.parentNode.className.indexOf('active')).toBeGreaterThanOrEqual(0);
                }
            }
            done();
        });
    });

    it('displays an alert indicator when one is present in alerts', done => {
        _createComponent(fullMock);
        Vue.nextTick(() => {
            const childNodes = component.$el.querySelectorAll('span.fa-csm-alert-grandfathered');
            expect(childNodes.length).toBe(1);
            done();
        });
    });

    it('Displays the correct number of member alerts.', done => {
        _createComponent(fullMock);
        let alertCount = 0;
        fullMock.memberAlerts.forEach((memberAlert) => {
            alertCount += (memberAlert[1] ? memberAlert[1].length : 0);
        });
        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="alert-type-instance"]');
            expect(nodes.length).toEqual(alertCount);
            done();
        });
    });

    it('displays the correct tab content based on product selected', done => {
        _createComponent(fullMock);
        DataStore.store.dispatch('setDatabaseId', '1');
        Vue.nextTick(() => {
            let nodes = component.$el.querySelectorAll('[data-test-ref="health-tab-body"]');
            expect(nodes.length).toEqual(1);
            component.$el.querySelector('a.nav-link:not(.active)').click();
            Vue.nextTick(() => {
                nodes = component.$el.querySelectorAll('[data-test-ref="dental-tab-body"]');
                expect(nodes.length).toEqual(1);
                done();
            });
        });
    });

    it('displays product tabs and "No Alerts" when alerts is empty', done => {
        _createComponent(noAlertsMock);
        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="product-tab-title"]');
            expect(nodes.length).toEqual(2);
            const node = component.$el.querySelector('[data-test-ref="no-alerts-card"]');
            expect(node.textContent.trim()).toBe('No Alerts');
            done();
        });
    });

    it('displays correct alert description when deferral card is clicked', done => {
        _createComponent(fullMock);
        DataStore.store.dispatch('setDatabaseId', 1);
        component.getData().then(() => {
            const deferralNode = component.$el.querySelector('[data-test-ref="deferral-record-2"]');
            deferralNode.click();
            // Give the DOM a second to update.
            setTimeout(() => {
                const alertDescNode = component.$el.querySelector('[data-test-ref="alert-description-2"]');
                expect(alertDescNode.textContent.trim()).toContain('Read processing exception on member/family');
                done();
            }, 1000);
        });
    });

    it('toggles the alert arrow when deferral alerts are clicked', done => {
        _createComponent(fullMock);
        DataStore.store.dispatch('setDatabaseId', 1);
        component.getData().then(() => {
            const deferralNode = component.$el.querySelector('[data-test-ref="deferral-record-2"]');
            deferralNode.click();
            setTimeout(() => {
                const caretNode = component.$refs['caret-0020'];
                expect(caretNode[0].className).toBe('fa fa-caret-up');
                done();
            }, 1000);
        });
    });

    it('clears array of alert descriptions before populating them', done => {
        _createComponent();
        component.populateAlertDescriptions(fullMock.memberAlerts);
        expect(component.alertDescriptions.length).toBe(4);
        component._clearAlertDescriptions();
        expect(component.alertDescriptions.length).toBe(0);
        component.populateAlertDescriptions(fullMock.memberAlerts.slice(0,2));
        expect(component.alertDescriptions.length).toBe(2);
        done();
    });
});
