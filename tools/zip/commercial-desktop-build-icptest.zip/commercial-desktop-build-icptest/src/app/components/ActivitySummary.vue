<template>
    <section
        class="app-section-activity-summary app-section-padded"
        aria-label="Activity Summary">
        <template v-if="hasActivity">
            <b-container
                fluid
                class="p-0">
                <b-row class="border-bottom">
                    <b-col cols="4">
                        <template
                            v-if="activity">
                            <button
                                :disabled="activity.hasPrevPage == 'N'"
                                @click="previousPage(activity)">
                                Previous
                            </button>
                            <button
                                :disabled="activity.hasNextPage == 'N'"
                                @click="nextPage(activity)">
                                Next
                            </button>
                        </template>
                    </b-col>
                    <b-col cols="8">
                        <b-form-group label="Include Voids?">
                            <b-form-radio-group
                                id="void-radios"
                                v-model="selectedVoids"
                                name="radioSubComponent">
                                <b-form-radio value="yes">Yes</b-form-radio>
                                <b-form-radio value="no">No</b-form-radio>
                            </b-form-radio-group>
                        </b-form-group>
                    </b-col>
                </b-row>
                <b-row>
                    <b-col>
                        <dl class="definition-list definition-list-lines border-bottom">
                            <template v-if="!activity.showMedicalManagementLinks">
                                <dt data-test-ref="activity-summary-case-mgmt-label">Case Management:</dt>
                                <dd data-test-ref="activity-summary-case-mgmt-data">{{ underCaseManagement }}</dd>
                            </template>
                            <template v-else>
                                <dt data-test-ref="activity-summary-behavioral-case-mgmt-label">Behavioral Case Management:</dt>
                                <dd data-test-ref="activity-summary-behavioral-case-mgmt-data">{{ underCaseManagement }}</dd>
                                <dt>Medical Case Management:</dt>
                                <dd data-test-ref="activity-summary-med-case-mgmt-data">
                                    <template v-if="isLink(activity.medicalCaseManagementIndicator)">
                                        <b-link
                                            href="openCaseManagement"
                                            data-test-ref="activity-summary-med-case-mgmt-link">
                                            {{ indicatorText(activity.medicalCaseManagementIndicator) }}
                                        </b-link>
                                    </template>
                                    <template v-else>
                                        {{ indicatorText(activity.medicalCaseManagementIndicator) }}
                                    </template>
                                </dd>
                                <dt>Disease Management:</dt>
                                <dd data-test-ref="activity-summary-disease-case-mgmt-data">
                                    <template v-if="isLink(activity.diseaseManagementIndicator)">
                                        <b-link
                                            href="openDiseaseManagement"
                                            data-test-ref="activity-summary-disease-case-mgmt-link">
                                            {{ indicatorText(activity.diseaseManagementIndicator) }}
                                        </b-link>
                                    </template>
                                    <template v-else>
                                        {{ indicatorText(activity.diseaseManagementIndicator) }}
                                    </template>
                                </dd>
                                <dt>Maternity Management:</dt>
                                <dd data-test-ref="activity-summary-maternity-case-mgmt-data">
                                    <template v-if="isLink(activity.maternityManagementIndicator)">
                                        <b-link
                                            href="openMaternityManagement"
                                            data-test-ref="activity-summary-maternity-case-mgmt-link">
                                            {{ indicatorText(activity.maternityManagementIndicator) }}
                                        </b-link>
                                    </template>
                                    <template v-else>
                                        {{ indicatorText(activity.maternityManagementIndicator) }}
                                    </template>
                                </dd>
                                <dt>Wellness Management:</dt>
                                <dd data-test-ref="activity-summary-wellness-case-mgmt-data">
                                    <template v-if="isLink(activity.wellnessManagementIndicator)">
                                        <b-link
                                            href="openWellnessManagement"
                                            data-test-ref="activity-summary-wellness-case-mgmt-link">
                                            {{ indicatorText(activity.wellnessManagementIndicator) }}
                                        </b-link>
                                    </template>
                                    <template v-else>
                                        {{ indicatorText(activity.wellnessManagementIndicator) }}
                                    </template>
                                </dd>
                            </template>
                        </dl>
                    </b-col>
                </b-row>
                <template v-if="activity.authorizations === null || activity.authorizations.length === 0">
                    <b-row>
                        <b-col
                            data-test-ref="activity-summary-no-auths-text">
                            No activity summary data found.
                        </b-col>
                    </b-row>
                </template>
                <template v-else>
                    <!-- create entries for each authorization record -->
                    <b-col
                        v-for="(authRecord) in activity.authorizations"
                        :key="authRecord.authorizationNumber"
                        class="border-bottom">
                        <!-- header row for each record -->
                        <b-row>
                            <b-col cols="8">
                                <dl class="definition-list definition-list-lines">
                                    <dt>
                                        <b-link
                                            href="openEmulator"
                                            data-test-ref="activity-summary-auth-date-link">
                                            {{ formatDate(authRecord.beginDate) }}
                                        </b-link>
                                    </dt>
                                    <dd data-test-ref="activity-summary-auth-number">{{ authRecord.authorizationNumber }}</dd>
                                </dl>
                            </b-col>
                            <b-col cols="4">
                                <dl class="definition-list definition-list-lines">
                                    <dt>Status:</dt>
                                    <dd data-test-ref="activity-summary-auth-status">{{ authRecord.status }}</dd>
                                </dl>
                            </b-col>
                            <template
                                v-if="isNotBlank(authRecord.extension)">
                                <b-col cols="3">
                                    <dl class="definition-list definition-list-lines">
                                        <dt>Ext:</dt>
                                        <dd data-test-ref="activity-summary-auth-ext-text">
                                            <template
                                                v-if="authRecord.extension === 'EXT' || authRecord.extension === 'E&S'">
                                                <b-link
                                                    href="openEmulatorExt"
                                                    data-test-ref="activity-summary-auth-ext-link">
                                                    {{ authRecord.extension }}
                                                </b-link>
                                            </template>
                                            <template
                                                v-else-if="authRecord.extension === 'SRV'">
                                                <b-link
                                                    href="openEmulatorSrv"
                                                    data-test-ref="activity-summary-auth-srv-link">
                                                    {{ authRecord.extension }}
                                                </b-link>
                                            </template>
                                            <template v-else>
                                                {{ authRecord.extension }}
                                            </template>
                                        </dd>
                                    </dl>
                                </b-col>
                            </template>
                        </b-row>
                        <!-- authorization info for each entry -->
                        <b-row>
                            <b-col>
                                <dl class="definition-list definition-list-lines definition-list-lines-long">
                                    <template v-if="isNotBlank(authRecord.activity)">
                                        <dt>Activity:</dt>
                                        <dd data-test-ref="activity-summary-activity-text">{{ authRecord.activity }}</dd>
                                    </template>
                                    <template v-if="isNotBlank(authRecord.function)">
                                        <dt>Function:</dt>
                                        <dd data-test-ref="activity-summary-function-text">{{ authRecord.function }}</dd>
                                    </template>
                                    <template v-if="isNotBlank(authRecord.program)">
                                        <dt>Program:</dt>
                                        <dd data-test-ref="activity-summary-program-text">{{ authRecord.program }}</dd>
                                    </template>
                                    <template v-if="isNotBlank(authRecord.rendering.name.firstName)">
                                        <dt>Provider:</dt>
                                        <dd data-test-ref="activity-summary-provider-text">{{ authRecord.rendering.name.firstName }}</dd>
                                    </template>
                                    <template v-if="isNotBlank(authRecord.facility.name.firstName)">
                                        <dt>Facility:</dt>
                                        <dd data-test-ref="activity-summary-facility-text">{{ authRecord.facility.name.firstName }}</dd>
                                    </template>
                                    <template v-if="isNotBlank(authRecord.origination.description)">
                                        <dt>Origination:</dt>
                                        <dd data-test-ref="activity-summary-origination-text">{{ authRecord.origination.description }}</dd>
                                    </template>
                                    <template v-if="isNotBlank(authRecord.reviewer.firstName)">
                                        <dt>Reviewer:</dt>
                                        <dd data-test-ref="activity-summary-reviewer-text">{{ authRecord.reviewer.firstName }}</dd>
                                    </template>
                                </dl>
                                <b-link
                                    href="openAuthAttachments"
                                    data-test-ref="activity-summary-attachments-link">
                                    View All Attachments
                                </b-link>
                            </b-col>
                        </b-row>
                    </b-col>
                </template>
            </b-container>
        </template>
        <template v-else>
            &nbsp;
        </template>
    </section>
</template>

<script>
import DesktopBaseComponent from './DesktopBaseComponent.vue';
import StringUtil from '../util/StringUtil';
import FilterUtil from '../util/FilterUtil';

export default {
    name: 'ActivitySummary',
    extends: DesktopBaseComponent,
    data() {
        return {
            selectedVoids: 'yes',
            hasSummaryLinks: false
        };
    },
    computed: {
        /**
         * A computed property to get the current database id
         */
        databaseId() {
            return this.$store.getters.getDatabaseId;
        },
        /**
         * A computed property to get the current patient id
         */
        patientId() {
            return this.$store.getters.getPatientId;
        },
        /**
         * A computed property to determine if activity summary data is available
         */
        hasActivity() {
            return this.$store.getters.getActivitySummary && this.$store.getters.getActivitySummary.authorizations;
        },
        /**
         * A computed property to pull the activity summary information
         */
        activity() {
            if (this.hasActivity) {
                return this.$store.getters.getActivitySummary;
            }
            return null;
        },
        /**
         * a computed property to determine the text for case management
         */
        underCaseManagement() {
            if (this.activity.underCaseManagement) {
                return 'YES';
            }
            return 'NO';
        }
    },
    watch: {
        /**
         * When the database id is changed, go get the data.
         */
        databaseId() {
            this.refreshData(true);
        },
        /**
         * When the patient id is changed, go get the data.
         */
        patientId() {
            this.refreshData(true);
        }
    },
    /** @lends app.components.PatientSummary.prototype */
    methods: {
        /**
         * get the patient's activity summary data
         */
        getData() {
            // if the database id and patient ID are provided, go get the patient
            if (this.databaseId && this.patientId) {
                return this.$store.dispatch('retrieveActivitySummary', {subscriberId: this.databaseId, memberKeyId: this.patientId});
            }
            // with no database id and patient id, return a promise that immediately resolves
            return Promise.resolve();
        },
        /**
         * clear the patient's activity summary data
         */
        clearData() {
            // clear out any lingering context in the store
            this.$store.dispatch('clearActivitySummary');
        },

        includesVoided() {
            return this.selectedVoids === 'yes';
        },
        /**
         * loads the next activity summary information if next button is clicked and there is more data.
         */
        nextPage(data) {
            const includeVoid = this.includesVoided();
            if (data.hasNextPage === 'Y') {
                data.pageNumber++;
                this.$store.dispatch('retrieveActivitySummary', {subscriberId: this.databaseId, memberKeyId: this.patientId, includeVoids: includeVoid, pageNumber: data.pageNumber});
            }
        },
        /**
         * loads the previous activity summary information if next button is clicked and there is any previous data to load.
         */
        previousPage(data) {
            const includeVoid = this.includesVoided();
            if (data.hasPrevPage === 'Y') {
                data.pageNumber--;
                this.$store.dispatch('retrieveActivitySummary', {subscriberId: this.databaseId, memberKeyId: this.patientId, includeVoids: includeVoid, pageNumber: data.pageNumber});
            }
        },

        /**
         * get text based on indicator
         */
        indicatorText(indicator) {
            let result = null;

            if (indicator === 'Y') {
                result = 'Eligible for this Program';
            } else if (indicator === 'E') {
                result = 'Enrolled in this Program';
            } else if (indicator === 'N') {
                result = 'Program Not Available';
            } else {
                result = '';
            }

            return result;
        },
        /**
         * determine if a link should be created based on the indicator
         */
        isLink(indicator) {
            let link = false;

            if (indicator === 'Y' || indicator === 'E') {
                link = true;
            }

            return link;
        },
        /**
         * determine if a string is not blank
         */
        isNotBlank(stringToCheck) {
            return StringUtil.isNotBlank(stringToCheck);
        },
        /**
         * format the date in MM/dd/yyyy format
         */
        formatDate(date) {
            return FilterUtil.formatDate(date);
        }
    }
};
</script>
