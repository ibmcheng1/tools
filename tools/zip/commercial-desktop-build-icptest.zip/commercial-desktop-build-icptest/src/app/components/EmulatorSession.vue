<template>
    <div>
        Emulator Session TODO
    </div>
</template>

<script>

    export default {
        name: 'EmulatorSession',
        created() {
            this.$emit('loaded');
        }
    };

</script>
