import Vue from 'vue';
import ContactHistory from './ContactHistory.vue';
import DesktopBaseComponent from './DesktopBaseComponent.vue';
import DataStore from './../store/DataStore.js';
import {mockContacts as fullMock} from './../store/mock/contact-history/ContactHistoryMock.js';

describe('ContactHistory', () => {
    let component;

    function _createComponent(model, mcs) {
        const Constructor = Vue.extend(ContactHistory);

        // set the contact history model object into the store
        DataStore.store.state.contactHistory = model;
        if (mcs) {
            DataStore.store.state.desktopName = 'MCS';
        }

        // build the component and mount it
        component = new Constructor({
            store: DataStore.store
        }).$mount();
    }

    beforeEach(() => {
        // prevent the component from trying to load a subscriber or summary links
        spyOn(DesktopBaseComponent.methods, 'refreshData').and.returnValue(1);
        spyOn(DesktopBaseComponent.methods, 'cacheSummaryLinks').and.returnValue(1);
        jasmine.getEnv().allowRespy(true);
    });

    afterEach(() => {
        jasmine.getEnv().allowRespy(false);
        if (component) {
            DataStore.store.state.desktopName = 'CSR';
            component.$destroy();
        }
    });

    it('is named ContactHistory', () => {
        expect(ContactHistory.name).toEqual('ContactHistory');
    });

    it('has a computed contactHistory hook', () => {
        expect(typeof ContactHistory.computed.contactHistory).toBe('function');
    });

    it('has a computed hasContactHistory hook', () => {
        expect(typeof ContactHistory.computed.hasContactHistory).toBe('function');
    });

    it('has a method getData hook providing this components specific behavior when loading its data', () => {
        expect(typeof ContactHistory.methods.getData).toBe('function');
    });

    it('has a method clearData hook that provides this components specific behavior when clearing its data', () => {
        expect(typeof ContactHistory.methods.clearData).toBe('function');
    });

    it('has "Type", "Date", "Details" and "Owner in table header"', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const contactHistoryType = component.$el.querySelectorAll('.sorting');
            expect(contactHistoryType[0].innerText.trim()).toBe('Type');
            expect(contactHistoryType[1].innerText.trim()).toBe('Date');
            expect(contactHistoryType[2].innerText.trim()).toBe('Details');
            expect(contactHistoryType[3].innerText.trim()).toBe('Owner');
            done();
        });
    });

    it('has displayed a type, a date, details, and an owner in first row of table', done => {
        _createComponent(fullMock);
        Vue.nextTick(() => {
            const contactHistoryRows = component.$el.querySelectorAll('tbody tr td');
            expect(contactHistoryRows[0].innerText.trim()).toBe('CL');
            expect(contactHistoryRows[1].innerText.trim()).toBe('06/04/18');
            expect(contactHistoryRows[2].innerText.trim()).toBe('MEMBER LOGGED INTO MIM SUCCESSFULHEALTH:MEMBER NUMBER: 123456789CLIENT ID: MEMMED00101');
            expect(contactHistoryRows[3].innerText.trim()).toBe('INTERNET WEBSITE');
            done();
        });
    });

    it('has all inform records from mock', done => {
        _createComponent(fullMock);
        Vue.nextTick(() => {
            const contactHistoryRows = component.$el.querySelectorAll('tbody tr');
            expect(contactHistoryRows.length).toEqual(242);
            done();
        });
    });

    it('ensure getData is called when data is refreshed', done => {
        _createComponent(fullMock);

        const getDataSpy = spyOn(ContactHistory.methods, 'getData').and.callThrough();
        const refreshDataSpy = spyOn(DesktopBaseComponent.methods, 'refreshData').and.callFake(() => {
            ContactHistory.methods.getData().then(() => {
            });
        });

        DesktopBaseComponent.methods.refreshData(true);

        Vue.nextTick(() => {
            expect(refreshDataSpy).toHaveBeenCalled();
            expect(getDataSpy).toHaveBeenCalled();
            done();
        });
    });

    it('ensure refreshData is called when databaseId is updated', done => {
        _createComponent(fullMock);

        const refreshDataSpy = spyOn(component, 'refreshData').and.returnValue(1);

        component.$store.dispatch('setDatabaseId', '55');

        Vue.nextTick(() => {
            expect(refreshDataSpy).toHaveBeenCalled();
            done();
        });
    });

    it('sort descending by status codes only', () => {
        const preContactHistoryList = [
            {
                statusCode: {type: 'XU'}
            },
            {
                statusCode: {type: 'CL'}
            },
            {
                statusCode: {type: 'OP'}
            },
            {
                statusCode: {type: 'XU'}
            },
            {
                statusCode: {type: 'CL'}
            },
            {
                statusCode: {type: 'OP'}
            }
        ];

        const expectedContactHistoryList = [
            {
                statusCode: {type: 'OP'}
            },
            {
                statusCode: {type: 'OP'}
            },
            {
                statusCode: {type: 'XU'}
            },
            {
                statusCode: {type: 'XU'}
            },
            {
                statusCode: {type: 'CL'}
            },
            {
                statusCode: {type: 'CL'}
            }
        ];

        preContactHistoryList.sort((a, b) => {
            return ContactHistory.methods.statusComparator(a, b, 'statusCode.type', true);
        });

        expect(preContactHistoryList).toEqual(expectedContactHistoryList);
    });

    it('sort ascending by status codes only', () => {
        const preContactHistoryList = [
            {
                statusCode: {type: 'XU'}
            },
            {
                statusCode: {type: 'CL'}
            },
            {
                statusCode: {type: 'OP'}
            },
            {
                statusCode: {type: 'XU'}
            },
            {
                statusCode: {type: 'CL'}
            },
            {
                statusCode: {type: 'OP'}
            }
        ];

        const expectedContactHistoryList = [
            {
                statusCode: {type: 'CL'}
            },
            {
                statusCode: {type: 'CL'}
            },
            {
                statusCode: {type: 'XU'}
            },
            {
                statusCode: {type: 'XU'}
            },
            {
                statusCode: {type: 'OP'}
            },
            {
                statusCode: {type: 'OP'}
            }
        ];

        preContactHistoryList.sort((a, b) => {
            return ContactHistory.methods.statusComparator(a, b, 'statusCode.type', false);
        });

        expect(preContactHistoryList).toEqual(expectedContactHistoryList);
    });

    it('sort ascending by status codes with timestamp', () => {
        const preContactHistoryList = [
            {
                statusCode: {type: 'XU'},
                timestamp: '2018-06-11'
            },
            {
                statusCode: {type: 'CL'},
                timestamp: '2018-06-04'
            },
            {
                statusCode: {type: 'OP'},
                timestamp: '2018-06-01'
            },
            {
                statusCode: {type: 'XU'},
                timestamp: '2018-06-01'
            },
            {
                statusCode: {type: 'CL'},
                timestamp: '2018-06-05'
            },
            {
                statusCode: {type: 'OP'},
                timestamp: '2018-06-02'
            }
        ];

        const expectedContactHistoryList = [
            {
                statusCode: {type: 'CL'},
                timestamp: '2018-06-05'
            },
            {
                statusCode: {type: 'CL'},
                timestamp: '2018-06-04'
            },
            {
                statusCode: {type: 'XU'},
                timestamp: '2018-06-01'
            },
            {
                statusCode: {type: 'XU'},
                timestamp: '2018-06-11'
            },
            {
                statusCode: {type: 'OP'},
                timestamp: '2018-06-01'
            },
            {
                statusCode: {type: 'OP'},
                timestamp: '2018-06-02'
            }
        ];

        preContactHistoryList.sort((a, b) => {
            return ContactHistory.methods.statusComparator(a, b, 'statusCode.type', false);
        });

        expect(preContactHistoryList).toEqual(expectedContactHistoryList);
    });

    it('sort descending by status codes with timestamp', () => {
        const preContactHistoryList = [
            {
                statusCode: {type: 'XU'},
                timestamp: '2018-06-11'
            },
            {
                statusCode: {type: 'CL'},
                timestamp: '2018-06-04'
            },
            {
                statusCode: {type: 'OP'},
                timestamp: '2018-06-01'
            },
            {
                statusCode: {type: 'XU'},
                timestamp: '2018-06-01'
            },
            {
                statusCode: {type: 'CL'},
                timestamp: '2018-06-05'
            },
            {
                statusCode: {type: 'OP'},
                timestamp: '2018-06-02'
            }
        ];

        const expectedContactHistoryList = [
            {
                statusCode: {type: 'OP'},
                timestamp: '2018-06-01'
            },
            {
                statusCode: {type: 'OP'},
                timestamp: '2018-06-02'
            },
            {
                statusCode: {type: 'XU'},
                timestamp: '2018-06-01'
            },
            {
                statusCode: {type: 'XU'},
                timestamp: '2018-06-11'
            },
            {
                statusCode: {type: 'CL'},
                timestamp: '2018-06-05'
            },
            {
                statusCode: {type: 'CL'},
                timestamp: '2018-06-04'
            }
        ];

        preContactHistoryList.sort((a, b) => {
            return ContactHistory.methods.statusComparator(a, b, 'statusCode.type', true);
        });

        preContactHistoryList.sort((a, b) => {
            return ContactHistory.methods.statusComparator(a, b, 'statusCode.type', false);
        });

        preContactHistoryList.sort((a, b) => {
            return ContactHistory.methods.statusComparator(a, b, 'statusCode.type', true);
        });

        expect(preContactHistoryList).toEqual(expectedContactHistoryList);
    });

    it('sort ascending by date', () => {
        const preContactHistoryList = [
            {
                timestamp: '2017-06-11'
            },
            {
                timestamp: '2018-06-01'
            },
            {
                timestamp: '2018-06-03'
            },
            {
                timestamp: '2018-06-02'
            }
        ];

        const expectedContactHistoryList = [
            {
                timestamp: '2017-06-11'
            },
            {
                timestamp: '2018-06-01'
            },
            {
                timestamp: '2018-06-02'
            },
            {
                timestamp: '2018-06-03'
            }
        ];

        preContactHistoryList.sort((a, b) => {
            return ContactHistory.methods.defaultComparator(a, b, 'timestamp', false);
        });

        expect(preContactHistoryList).toEqual(expectedContactHistoryList);
    });

    it('sort descending by date', () => {
        const preContactHistoryList = [
            {
                timestamp: '2017-06-11'
            },
            {
                timestamp: '2018-06-01'
            },
            {
                timestamp: '2018-06-03'
            },
            {
                timestamp: '2018-06-02'
            }
        ];

        const expectedContactHistoryList = [
            {
                timestamp: '2018-06-03'
            },
            {
                timestamp: '2018-06-02'
            },
            {
                timestamp: '2018-06-01'
            },
            {
                timestamp: '2017-06-11'
            }
        ];

        preContactHistoryList.sort((a, b) => {
            return ContactHistory.methods.defaultComparator(a, b, 'timestamp', true);
        });

        expect(preContactHistoryList).toEqual(expectedContactHistoryList);
    });

    it('sort ascending by details', () => {
        const preContactHistoryList = [
            {
                requestVerbiage: 'details1'
            },
            {
                requestVerbiage: 'detailsB'
            },
            {
                requestVerbiage: 'detailsA'
            },
            {
                requestVerbiage: 'detailsC'
            }
        ];

        const expectedContactHistoryList = [
            {
                requestVerbiage: 'details1'
            },
            {
                requestVerbiage: 'detailsA'
            },
            {
                requestVerbiage: 'detailsB'
            },
            {
                requestVerbiage: 'detailsC'
            }
        ];

        preContactHistoryList.sort((a, b) => {
            return ContactHistory.methods.defaultComparator(a, b, 'requestVerbiage', false);
        });

        expect(preContactHistoryList).toEqual(expectedContactHistoryList);
    });

    it('sort descending by details', () => {
        const preContactHistoryList = [
            {
                requestVerbiage: 'details1'
            },
            {
                requestVerbiage: 'detailsB'
            },
            {
                requestVerbiage: 'detailsA'
            },
            {
                requestVerbiage: 'detailsC'
            }
        ];

        const expectedContactHistoryList = [
            {
                requestVerbiage: 'detailsC'
            },
            {
                requestVerbiage: 'detailsB'
            },
            {
                requestVerbiage: 'detailsA'
            },
            {
                requestVerbiage: 'details1'
            }
        ];

        preContactHistoryList.sort((a, b) => {
            return ContactHistory.methods.defaultComparator(a, b, 'requestVerbiage', true);
        });

        expect(preContactHistoryList).toEqual(expectedContactHistoryList);
    });

    it('sort ascending by owner', () => {
        const preContactHistoryList = [
            {
                employeeName: 'INTERNET WEBSITE 3'
            },
            {
                employeeName: 'ANDREW JONES'
            },
            {
                employeeName: 'INTERNET WEBSITE 1'
            },
            {
                employeeName: 'INTERNET WEBSITE 2'
            },
            {
                employeeName: 'BRIAN MURPHY'
            }
        ];

        const expectedContactHistoryList = [
            {
                employeeName: 'ANDREW JONES'
            },
            {
                employeeName: 'BRIAN MURPHY'
            },
            {
                employeeName: 'INTERNET WEBSITE 1'
            },
            {
                employeeName: 'INTERNET WEBSITE 2'
            },
            {
                employeeName: 'INTERNET WEBSITE 3'
            }
        ];
        preContactHistoryList.sort((a, b) => {
            return ContactHistory.methods.defaultComparator(a, b, 'employeeName', false);
        });

        expect(preContactHistoryList).toEqual(expectedContactHistoryList);
    });

    it('sort descending by owner', () => {
        const preContactHistoryList = [
            {
                employeeName: 'INTERNET WEBSITE 3'
            },
            {
                employeeName: 'ANDREW JONES'
            },
            {
                employeeName: 'INTERNET WEBSITE 1'
            },
            {
                employeeName: 'INTERNET WEBSITE 2'
            },
            {
                employeeName: 'BRIAN MURPHY'
            }
        ];

        const expectedContactHistoryList = [
            {
                employeeName: 'INTERNET WEBSITE 3'
            },
            {
                employeeName: 'INTERNET WEBSITE 2'
            },
            {
                employeeName: 'INTERNET WEBSITE 1'
            },
            {
                employeeName: 'BRIAN MURPHY'
            },
            {
                employeeName: 'ANDREW JONES'
            }
        ];

        preContactHistoryList.sort((a, b) => {
            return ContactHistory.methods.defaultComparator(a, b, 'employeeName', true);
        });

        expect(preContactHistoryList).toEqual(expectedContactHistoryList);
    });

    it('sort changed callback sort timestamp column and check busy flag', done => {
        const preContactHistoryList = [
            {
                timestamp: '2017-06-11'
            },
            {
                timestamp: '2018-06-01'
            },
            {
                timestamp: '2018-06-03'
            },
            {
                timestamp: '2018-06-02'
            }
        ];

        const expectedContactHistoryList = [
            {
                timestamp: '2018-06-03'
            },
            {
                timestamp: '2018-06-02'
            },
            {
                timestamp: '2018-06-01'
            },
            {
                timestamp: '2017-06-11'
            }
        ];

        _createComponent(preContactHistoryList);

        Vue.nextTick(() => {
            expect(component.isBusy).toBe(false);
            component.sortChanged({sortBy: 'timestamp', sortDesc: false});
            expect(component.isBusy).toBe(false);

            expect(preContactHistoryList).toEqual(expectedContactHistoryList);
            done();
        });
    });

    it('sort changed callback sort status column and check busy flag', done => {
        const preContactHistoryList = [
            {
                statusCode: {type: 'XU'}
            },
            {
                statusCode: {type: 'CL'}
            },
            {
                statusCode: {type: 'OP'}
            },
            {
                statusCode: {type: 'XU'}
            },
            {
                statusCode: {type: 'CL'}
            },
            {
                statusCode: {type: 'OP'}
            }
        ];

        const expectedContactHistoryList = [
            {
                statusCode: {type: 'OP'}
            },
            {
                statusCode: {type: 'OP'}
            },
            {
                statusCode: {type: 'XU'}
            },
            {
                statusCode: {type: 'XU'}
            },
            {
                statusCode: {type: 'CL'}
            },
            {
                statusCode: {type: 'CL'}
            }
        ];

        _createComponent(preContactHistoryList);

        Vue.nextTick(() => {
            expect(component.isBusy).toBe(false);
            component.sortChanged({sortBy: 'statusCode.type', sortDesc: false});
            expect(component.isBusy).toBe(false);

            expect(preContactHistoryList).toEqual(expectedContactHistoryList);
            done();
        });
    });

    it('has date formatter for timestamp column', () => {
        let formattedDate = ContactHistory.methods.formatDate('2018-03-15-13.24.55.000476');
        expect(formattedDate).toEqual('03/15/18');

        formattedDate = ContactHistory.methods.formatDate('2000-03-15-13.24.55.000476');
        expect(formattedDate).toEqual('03/15/00');

        formattedDate = ContactHistory.methods.formatDate('1970-03-15-13.24.55.000476');
        expect(formattedDate).toEqual('03/15/70');

        formattedDate = ContactHistory.methods.formatDate('2031-03-15-13.24.55.000476');
        expect(formattedDate).toEqual('03/15/31');

        formattedDate = ContactHistory.methods.formatDate('2018-03-1');
        expect(formattedDate).toEqual('2018-03-1');
    });

    it('displays the filter dropdown when on MCS Desktop', done => {
        _createComponent(fullMock, true);

        component.$on('loaded', () => {
            const filterList = component.$el.querySelectorAll('[data-test-ref="filter-list"]');
            expect(filterList.length).toEqual(1);
            done();
        });
    });

    it('does not display the filter dropdown when on CSR Desktop', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const filterList = component.$el.querySelectorAll('[data-test-ref="filter-list"]');

            expect(filterList.length).toEqual(0);
            done();
        });
    });

    it('does not display the filter dropdown when there is an error loading filter', done => {
        spyOn(component.$store, 'dispatch').and.callFake(() => {
            return Promise.reject(new Error('this is a test'));
        });
        _createComponent(fullMock, true);

        component.$on('loaded', () => {
            const filterList = component.$el.querySelectorAll('[data-test-ref="filter-list"]');
            expect(filterList.length).toEqual(0);
            done();
        });
    });

    it('clears contact history when clear data is called', () => {
        const spy = spyOn(component.$store, 'dispatch');
        _createComponent(fullMock);

        component.clearData();
        expect(spy).toHaveBeenCalledWith('clearContactHistory');
    });

    it('if there is no selected filter, get filter data on get data', () => {
        _createComponent(fullMock);
        component.$store.dispatch('setDatabaseId', '1');
        const spy = spyOn(component, 'getFilter');

        component.selectedFilter = '';
        component.getData();
        expect(spy).toHaveBeenCalled();
    });

    it('if there is a selected filter, do not get filter data on get data', () => {
        _createComponent(fullMock);
        component.$store.dispatch('setDatabaseId', '1');
        const spy = spyOn(component, 'getFilter');

        component.getData();
        expect(spy).not.toHaveBeenCalled();
    });

    it('when get data is called, make sure selected filter is applied', (done) => {
        _createComponent(fullMock);
        component.$store.dispatch('setDatabaseId', '1');
        const spy = spyOn(component.$store, 'dispatch').and.callThrough();

        component.selectedFilter = '1,A';
        component.getData().then(() => {
            expect(spy).toHaveBeenCalledWith('retrieveContactHistory', {memberKeyId: '1', company: '1', employee: 'A'});
            done();
        });
    });

    it('when get data is called, make sure selected filter is applied if only a company', (done) => {
        _createComponent(fullMock);
        component.$store.dispatch('setDatabaseId', '1');
        const spy = spyOn(component.$store, 'dispatch').and.callThrough();

        component.selectedFilter = '1';
        component.getData().then(() => {
            expect(spy).toHaveBeenCalledWith('retrieveContactHistory', {memberKeyId: '1', company: '1', employee: undefined});
            done();
        });
    });

    it('when get data is called, make sure there is a reject when retrieveContactHistory fails', (done) => {
        _createComponent(fullMock);
        component.$store.dispatch('setDatabaseId', '1');
        spyOn(component.$store, 'dispatch').and.callFake(() => {
            return Promise.reject();
        });

        component.getData().catch(() => {
            done();
        });
    });

    it('when get data is called, make sure there is a reject when getFilter fails', (done) => {
        _createComponent(fullMock);
        component.$store.dispatch('setDatabaseId', '1');
        spyOn(component, 'getFilter').and.callFake(() => {
            return Promise.reject(new Error('this is a test'));
        });

        component.selectedFilter = null;

        component.getData().catch(() => {
            done();
        });
    });
});
