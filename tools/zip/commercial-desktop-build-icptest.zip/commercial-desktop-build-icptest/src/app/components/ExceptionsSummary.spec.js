import Vue from 'vue';
import ExceptionsSummary from './ExceptionsSummary.vue';
import DesktopBaseComponent from './DesktopBaseComponent.vue';

import DataStore from './../store/DataStore.js';
import {mockExceptions as fullMock} from './../store/mock/exceptions-summary/ExceptionsMock.js';
import {mockExceptionsNoAlerts as fullMockNoAlerts} from './../store/mock/exceptions-summary/ExceptionsMockNoAlerts.js';

describe('Exceptions Summary Tests', () => {
    let component;

    function _createComponent(model) {
        const Constructor = Vue.extend(ExceptionsSummary);
        // set the exceptions model object into the store
        DataStore.store.state.exceptions = model;

        // build the component and mount it
        component = new Constructor({
            store: DataStore.store
        }).$mount();
    }

    beforeEach(() => {
        // prevent the component from trying to load exceptions or summary links
        spyOn(DesktopBaseComponent.methods, 'refreshData').and.returnValue(1);
        spyOn(DesktopBaseComponent.methods, 'cacheSummaryLinks').and.returnValue(1);
        jasmine.getEnv().allowRespy(true);
    });

    afterEach(() => {
        jasmine.getEnv().allowRespy(false);
        if (component) {
            component.$destroy();
        }
    });

    it('is named ExceptionsSummary', () => {
        expect(ExceptionsSummary.name).toEqual('ExceptionsSummary');
    });

    it('has a computed exceptions hook', () => {
        expect(typeof ExceptionsSummary.computed.exceptions).toBe('function');
    });

    it('has a databaseId watch', () => {
        expect(typeof ExceptionsSummary.watch.databaseId).toBe('function');
    });

    it('has a list of all exceptions', () => {
        _createComponent(fullMock);
        expect(component.exceptions.length).toEqual(fullMock.length);
    });

    it('displays nothing when there is no data', done => {
        _createComponent({});

        Vue.nextTick(() => {
            const body = component.$el;
            expect(body.innerText.trim()).toBe('');
            done();
        });
    });

    it('displays all exceptions', done => {
        _createComponent(fullMock);
        Vue.nextTick(() => {
            expect(component.$el.querySelectorAll('[data-test-ref="exception"]').length).toEqual(fullMock.length);
            done();
        });
    });

    // Exception 'Applies to' value
    it('displays patient name and ID', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="applies-to"]');
            Array.prototype.forEach.call(nodes, (appliesTo, index) => {
                // the value should be patientName and patientID
                expect(appliesTo.innerText.trim()).toBe((fullMock[index].patientName + ' ' + fullMock[index].patientID).trim());
            });
            done();
        });
    });

    // Exception 'Type' value
    it('displays Type', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="type"]');
            Array.prototype.forEach.call(nodes, (type, index) => {
                let testType = '';
                if (fullMock[index].controlCode) {
                    if (fullMock[index].controlCode.code) {
                        testType += fullMock[index].controlCode.code.trim();
                    }
                    if (fullMock[index].controlCode.description) {
                        testType += ' - ' + fullMock[index].controlCode.description.trim();
                    }
                }

                // the value should be the exception type
                expect(type.innerText.trim()).toBe(testType);
            });
            done();
        });
    });

    // Exception 'Type' value
    it('displays Deferral', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="deferral"]');
            Array.prototype.forEach.call(nodes, (deferral, index) => {
                // the value should be the exception deferral
                const deferralText = fullMock[index].deferral;
                if (deferralText) {
                    expect(deferral.innerText.trim()).toBe(deferralText);
                } else {
                    expect(deferral.innerText.trim()).toBe('-');
                }
            });
            done();
        });
    });

    // Exception 'Type' value
    it('displays Description', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="description"]');
            Array.prototype.forEach.call(nodes, (description, index) => {
                // the value should be the exception description
                const descriptionText = fullMock[index].exceptionDescription;
                if (descriptionText) {
                    expect(description.innerText.trim()).toBe(descriptionText);
                } else {
                    expect(description.innerText.trim()).toBe('-');
                }
            });
            done();
        });
    });

    // Displays alert where applicable
    it('displays alert', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="exception"]');
            Array.prototype.forEach.call(nodes, (alert, index) => {
                // The alert icon should display when the alert indicator is true
                const alertIconNode = nodes[index].querySelector('[data-test-ref="alert"]');
                if (fullMock[index].alertExceptionIndicator) {
                    expect(alertIconNode).toBeTruthy();
                } else {
                    expect(alertIconNode).toBeFalsy();
                }
            });
            done();
        });
    });

    it('adds alert class when there are alerts', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const hasAlertClass = component.$el.classList.contains('app-section-has-alert');
            expect(hasAlertClass).toBeTruthy();
            done();
        });
    });

    it('removes alert class when there are no alerts', done => {
        _createComponent(fullMockNoAlerts);

        Vue.nextTick(() => {
            const hasAlertClass = component.$el.classList.contains('app-section-has-alert');
            expect(hasAlertClass).toBeFalsy();
            done();
        });
    });

    it('ensure getData is called when data is refreshed', done => {
        _createComponent(fullMock);

        const getDataSpy = spyOn(ExceptionsSummary.methods, 'getData').and.callThrough();
        const refreshDataSpy = spyOn(DesktopBaseComponent.methods, 'refreshData').and.callFake(() => {
            ExceptionsSummary.methods.getData().then(() => {
            });
        });

        DesktopBaseComponent.methods.refreshData(true);

        Vue.nextTick(() => {
            expect(refreshDataSpy).toHaveBeenCalled();
            expect(getDataSpy).toHaveBeenCalled();
            done();
        });
    });

    it('ensure refreshData is called when databaseId is updated', done => {
        _createComponent(fullMock);
        const refreshDataSpy = spyOn(component, 'refreshData').and.returnValue(1);
        component.$store.dispatch('setDatabaseId', '55');
        Vue.nextTick(() => {
            expect(refreshDataSpy).toHaveBeenCalled();
            done();
        });
    });

    it('clears exceptions when clearData is called', done => {
        _createComponent(fullMock);
        component.clearData();
        expect(component.$store.getters.getExceptions).toEqual({});
        done();
    });

    it('updates alert flag when data is changed', done => {
        _createComponent(fullMockNoAlerts);

        Vue.nextTick(() => {
            expect(component.hasAlert).toBeFalsy();
            done();
        });
    });

    it('alert flag is true when there are exceptions that have alerts', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            expect(component.hasAlert).toBeTruthy();
            done();
        });
    });
});
