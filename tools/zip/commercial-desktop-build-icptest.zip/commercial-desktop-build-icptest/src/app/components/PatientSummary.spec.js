import Vue from 'vue';
import PatientSummary from './PatientSummary.vue';
import DesktopBaseComponent from './DesktopBaseComponent.vue';
import DataStore from './../store/DataStore.js';
import {mockPatientSummary as fullMock1} from './../store/mock/patient-summary/PatientSummaryOneMock.js';
import {mockPatientSummary as fullMock2} from './../store/mock/patient-summary/PatientSummaryTwoMock.js';

import assigndeep from 'assign-deep';

describe('PatientSummary', () => {
    let component;

    function _createComponent(model) {
        const Constructor = Vue.extend(PatientSummary);

        // set the patient model object into the store
        DataStore.store.state.patientSummary = model;

        // build the component and mount it
        component = new Constructor({
            store: DataStore.store
        }).$mount();
    }

    beforeEach(() => {
        // prevent the component from trying to load a subscriber or summary links
        spyOn(DesktopBaseComponent.methods, 'refreshData').and.returnValue(1);
    });

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('has a computed hasPatient hook', () => {
        expect(typeof PatientSummary.computed.hasPatient).toBe('function');
    });

    it('has a computed patient hook', () => {
        expect(typeof PatientSummary.computed.patient).toBe('function');
    });

    // patient name
    it('has displayed name', done => {
        _createComponent(fullMock1);

        Vue.nextTick(() => {
            const name = component.$el.querySelectorAll('[data-test-ref="patient-summary-name"]')[0];
            // there should be only one name
            expect(name).toBeTruthy();
            // the value should be 'MICHAEL TESTING'
            expect(name.innerText.trim()).toBe('MICHAEL TESTING');
            done();
        });
    });

    // address1 line
    it('has displayed address line 1', done => {
        _createComponent(fullMock1);

        Vue.nextTick(() => {
            const addressLine = component.$el.querySelectorAll('[data-test-ref="patient-summary-address1"]');
            // there should be only one address1
            expect(addressLine.length).toEqual(1);
            // the value should be 'P O BOX  24015'
            expect(addressLine[0].innerText.trim()).toBe('P O BOX  24015');
            done();
        });
    });

    // address2 line
    it('has displayed address line 2', done => {
        _createComponent(fullMock2);

        Vue.nextTick(() => {
            const addressLine = component.$el.querySelectorAll('[data-test-ref="patient-summary-address2"]');
            // there should be only one address2
            expect(addressLine.length).toEqual(1);
            // the value should be 'Suite C'
            expect(addressLine[0].innerText.trim()).toBe('Suite C');
            done();
        });
    });

    // city, state, zip
    it('has displayed city, state, zip', done => {
        _createComponent(fullMock1);

        Vue.nextTick(() => {
            const cityStateZip = component.$el.querySelectorAll('[data-test-ref="patient-summary-city-state-zip"]');
            expect(cityStateZip.length).toEqual(1);
            expect(cityStateZip[0].innerText.trim()).toBe('COLUMBIA, SC 29224 4015');
            done();
        });
    });

    // check for gender relationship header
    it('has displayed gender relationship header', done => {
        _createComponent(fullMock1);

        Vue.nextTick(() => {
            const genderRelationshipHeader = component.$el.querySelectorAll('[data-test-ref="patient-summary-gender-relationship"]');
            expect(genderRelationshipHeader.length).toEqual(1);
            expect(genderRelationshipHeader[0].innerText.trim()).toBe('MALE SUBSCRIBER');
            done();
        });
    });

    // check for birthdate
    it('has displayed birthdate', done => {
        _createComponent(fullMock1);

        Vue.nextTick(() => {
            const birthdate = component.$el.querySelectorAll('[data-test-ref="patient-summary-birthdate"]');
            expect(birthdate.length).toEqual(1);
            expect(birthdate[0].innerText.trim()).toBe('10/01/1958');
            done();
        });
    });

    // check for member ID
    it('has displayed member ID', done => {
        _createComponent(fullMock1);

        Vue.nextTick(() => {
            const memberId = component.$el.querySelectorAll('[data-test-ref="patient-summary-memberId"]');
            expect(memberId.length).toEqual(1);
            expect(memberId[0].innerText.trim()).toBe('001');
            done();
        });
    });

    // check for CES member number, when exists
    it('has displayed CES member number, when it exists', done => {
        _createComponent(fullMock1);

        Vue.nextTick(() => {
            const memberNumber = component.$el.querySelectorAll('[data-test-ref="patient-summary-ces-member-number"]');
            expect(memberNumber.length).toEqual(1);
            expect(memberNumber[0].innerText.trim()).toBe('01');
            done();
        });
    });

    // check for lack of CES member number, when it doesn't exist
    it('has displayed CES member number, when it exists', done => {
        _createComponent(assigndeep({}, fullMock1, {
            cesMemberNumber: ''
        }));

        Vue.nextTick(() => {
            const memberNumber = component.$el.querySelectorAll('[data-test-ref="patient-summary-ces-member-number"]');
            expect(memberNumber.length).toEqual(0);
            done();
        });
    });

    // check for the records link
    it('has displayed the records link', done => {
        _createComponent(fullMock1);

        Vue.nextTick(() => {
            const recordsLinks = component.$el.querySelectorAll('[data-test-ref="patient-summary-records-link"]');
            expect(recordsLinks.length).toEqual(1);
            done();
        });
    });

    // check for the PCP links, when the PCP name exists
    it('has displayed PCP label and link, when it exists', done => {
        _createComponent(assigndeep({}, fullMock1, {
            primaryCarePhysicianId: '001',
            primaryCarePhysicianName: 'Dr. Smith'
        }));

        Vue.nextTick(() => {
            const pcpLabels = component.$el.querySelectorAll('[data-test-ref="patient-summary-label-link"]');
            const pcpDescriptions = component.$el.querySelectorAll('[data-test-ref="patient-summary-pcp-id-name-link"]');
            expect(pcpLabels.length).toEqual(1);
            expect(pcpDescriptions.length).toEqual(1);
            done();
        });
    });

    // check for the no PCP label and description, when the PCP does not exist
    it('has displayed the non PCP label and link, when the PCP does not exist', done => {
        _createComponent(assigndeep({}, fullMock1, {
            primaryCarePhysicianId: '',
            primaryCarePhysicianName: ''
        }));

        Vue.nextTick(() => {
            const pcpLabels = component.$el.querySelectorAll('[data-test-ref="patient-summary-pcp-label-no-pcp"]');
            const pcpDescriptions = component.$el.querySelectorAll('[data-test-ref="patient-summary-pcp-description-no-pcp"]');
            expect(pcpLabels.length).toEqual(1);
            expect(pcpDescriptions.length).toEqual(1);
            done();
        });
    });

    it('calls refresh data when the database id changes', done => {
        _createComponent(fullMock1);

        component.$store.dispatch('setDatabaseId', 'test');

        spyOn(component, 'refreshData').and.callFake(() => {
            component.$store.dispatch('clearDatabaseId');
            done();
        });
    });

    it('return promise when calling get data without subscriber and patient IDs', done => {
        _createComponent(fullMock1);

        component.$store.dispatch('clearDatabaseId');
        component.$store.dispatch('clearPatientId');

        component.getData().then(() => {
            done();
        });
    });

    it('return patient summary data when calling get data with subscriber and patient IDs', done => {
        _createComponent(fullMock1);
        component.$store.dispatch('setDatabaseId', '123456789');
        component.$store.dispatch('setPatientId', '001');

        component.getData().then(() => {
            component.$store.dispatch('clearDatabaseId');
            component.$store.dispatch('clearPatientId');
            done();
        });
    });

    it('make sure clear data clears the patient', () => {
        _createComponent(fullMock1);

        const spy = spyOn(component.$store, 'dispatch');
        component.clearData();

        expect(spy).toHaveBeenCalledWith('clearPatientSummary');
    });
});
