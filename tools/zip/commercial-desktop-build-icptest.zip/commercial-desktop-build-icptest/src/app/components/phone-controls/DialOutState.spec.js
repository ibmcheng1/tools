import Vue from 'vue';
import DialOutState from './DialOutState.vue';

import StateMachine from 'javascript-state-machine';
import PhoneTransactions from './PhoneTransactions.js';

describe('DialOutState', () => {
    let component;

    /*
     * Create an instance of the (phone controls) DialOutState component
     */
    function _createComponent() {
        const Constructor = Vue.extend(DialOutState);
        // build the component and mount it
        component = new Constructor({
            propsData: {
                phoneStateMachine: new StateMachine(PhoneTransactions)
            }
        }).$mount();
    }

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('is named DialOutState', () => {
        expect(DialOutState.name).toEqual('DialOutState');
    });

    it('has a method call', () => {
        expect(typeof DialOutState.methods.call).toBe('function');
    });

    it('has a method cancel', () => {
        expect(typeof DialOutState.methods.cancel).toBe('function');
    });

    it('displays a list of campaigns', done => {
        _createComponent();

        component.phoneStateMachine.start();
        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();
        component.phoneStateMachine.dialout();

        Vue.nextTick(() => {
            const campaigns = component.$el.querySelectorAll('[data-test-ref="campaign-items"]');
            expect(campaigns.length).toBe(7);
            done();
        });
    });

    it('state is \'loggedOn\' when the call button is clicked', done => {
        _createComponent();

        component.phoneStateMachine.start();
        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();

        Vue.nextTick(() => {
            expect(component.phoneStateMachine.state).toBe('loggedOn');
            done();
        });
    });

    it('state is \'loggedOn\' when the cancel button is clicked', done => {
        _createComponent();

        component.phoneStateMachine.start();
        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();
        component.phoneStateMachine.dialout();

        Vue.nextTick(() => {
            const buttons = component.$el.querySelectorAll('[data-test-ref="cancel-button"]');
            expect(buttons.length).toBe(1);
            buttons[0].click();
            expect(component.phoneStateMachine.state).toBe('loggedOn');
            done();
        });
    });
});
