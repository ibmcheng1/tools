<template>
    <span class="form-inline d-inline-flex align-middle">
        <span class="form-group mr-2">
            <label
                for="callReadyReasonSelect"
                class="mr-2">Reason</label>
            <b-form-select
                id="callReadyReasonSelect"
                data-test-ref="select-not-ready-reasons"
                @change="reasonSelected($event)">
                <option
                    v-for="(reason, index) in phoneStateMachine.awayReasons"
                    :key="reason"
                    :value="index"
                    data-test-ref="not-ready-reasons">{{ reason }}
                </option>
            </b-form-select>
        </span>
        <b-button
            :disabled="isDisabled"
            variant="light"
            data-test-ref="go-unavailable-button"
            @click="goUnavailable">Go Unavailable</b-button>
    </span>
</template>

<script>

export default {
    /** @lends app.components.ReadyState.prototype */
    name: 'ReadyState',
    props: {
        phoneStateMachine: {
            default: null,
            type: Object,
            required: true
        }
    },
    data: () => {
        return {
            navigationButtonDisabled: true
        };
    },
    computed: {
        /**
         * Enable / disable the Consult button
         */
        isDisabled() {
            return this.navigationButtonDisabled;
        }
    },
    methods: {
        /**
         * Navigate to loggedOn state by initiating a not ready transition
         */
        goUnavailable() {
            this.phoneStateMachine.notready();
        },
        /**
         * User selected an away reason code, enable the go unavailable button when the
         * user selects a valid option
         * @param event get the selected reason
         *
         */
        reasonSelected(event) {
            this.navigationButtonDisabled = true;
            if (event && event.target && event.target.value) {
                if (event.target.value !== '0') {
                    this.navigationButtonDisabled = false;
                }
            }
        }
    }
};
</script>
