<template>
    <span>
        <b-button
            variant="light"
            data-test-ref="signoff-button"
            @click="signoff">Sign Off</b-button>
        <b-button
            variant="light"
            data-test-ref="ready-button"
            @click="ready">Ready</b-button>
        <b-button
            variant="light"
            data-test-ref="dialout-button"
            @click="dialOut">Dial-Out</b-button>
    </span>
</template>

<script>
export default {
    /** @lends app.components.LoggedOnState.prototype */
    name: 'LoggedOnState',
    props: {
        phoneStateMachine: {
            default: null,
            type: Object,
            required: true
        }
    },
    methods: {
        signoff() {
            this.phoneStateMachine.signoff();
        },
        ready() {
            this.phoneStateMachine.ready();
        },
        dialOut() {
            this.phoneStateMachine.dialout();
        }
    }
};
</script>
