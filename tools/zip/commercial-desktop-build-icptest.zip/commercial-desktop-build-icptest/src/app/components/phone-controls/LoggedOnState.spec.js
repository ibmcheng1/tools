import Vue from 'vue';
import LoggedOnState from './LoggedOnState.vue';

import StateMachine from 'javascript-state-machine';
import PhoneTransactions from './PhoneTransactions.js';

describe('LoggedOnState', () => {
    let component;

    /*
     * Create an instance of the phone controls parent component
     */
    function _createComponent() {
        const Constructor = Vue.extend(LoggedOnState);
        // build the component and mount it
        component = new Constructor({
            propsData: {
                phoneStateMachine: new StateMachine(PhoneTransactions)
            }
        }).$mount();
    }

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('is named LoggedOnState', () => {
        expect(LoggedOnState.name).toEqual('LoggedOnState');
    });

    it('has a method signoff', () => {
        expect(typeof LoggedOnState.methods.signoff).toBe('function');
    });

    it('has a method ready', () => {
        expect(typeof LoggedOnState.methods.ready).toBe('function');
    });

    it('has a method dialOut', () => {
        expect(typeof LoggedOnState.methods.dialOut).toBe('function');
    });

    it('state is \'signOff\' when the signoff button is clicked', done => {
        _createComponent();

        component.phoneStateMachine.start();
        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();

        Vue.nextTick(() => {
            const signoffButtons = component.$el.querySelectorAll('[data-test-ref="signoff-button"]');
            expect(signoffButtons.length).toBe(1);
            signoffButtons[0].click();
            expect(component.phoneStateMachine.state).toBe('signOff');
            done();
        });
    });

    it('state is \'dialOut\' when the dial out button is clicked', done => {
        _createComponent();

        component.phoneStateMachine.start();
        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();

        Vue.nextTick(() => {
            const dialOutButtons = component.$el.querySelectorAll('[data-test-ref="dialout-button"]');
            expect(dialOutButtons.length).toBe(1);
            dialOutButtons[0].click();
            expect(component.phoneStateMachine.state).toBe('dialOut');
            done();
        });
    });

    it('state is \'ready\' when the ready button is clicked', done => {
        _createComponent();

        component.phoneStateMachine.start();
        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();

        Vue.nextTick(() => {
            const dialOutButtons = component.$el.querySelectorAll('[data-test-ref="ready-button"]');
            expect(dialOutButtons.length).toBe(1);
            dialOutButtons[0].click();
            expect(component.phoneStateMachine.state).toBe('ready');
            done();
        });
    });
});
