import Vue from 'vue';
import CallCenterSelectionState from './CallCenterSelectionState.vue';

import StateMachine from 'javascript-state-machine';
import PhoneTransactions from './PhoneTransactions.js';

describe('CallCenterSelectionState', () => {
    let component;

    /*
     * Create an instance of the (phone controls) CallCenterSelection component
     */
    function _createComponent() {
        const Constructor = Vue.extend(CallCenterSelectionState);
        // build the component and mount it
        component = new Constructor({
            propsData: {
                phoneStateMachine: new StateMachine(PhoneTransactions)
            }
        }).$mount();
    }

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('is named CallCenterSelection', () => {
        expect(CallCenterSelectionState.name).toEqual('CallCenterSelectionState');
    });

    it('has a method signon', () => {
        expect(typeof CallCenterSelectionState.methods.signon).toBe('function');
    });

    it('state is \'initialized\' once the component is mounted', done => {
        _createComponent();

        component.phoneStateMachine.start();
        Vue.nextTick(() => {
            expect(component.phoneStateMachine.state).toBe('initialized');
            done();
        });
    });

    it('displays call centers', done => {
        _createComponent();

        // transition through state machine to 'callCenterSelection' state
        component.phoneStateMachine.start();
        component.phoneStateMachine.displaycallcenters();

        Vue.nextTick(() => {
            const callCenters = component.$el.querySelectorAll('[data-test-ref="call-center-list"]');
            expect(callCenters.length).toBe(4);
            done();
        });
    });

    it('state is \'loggedOn\' when the signon button is clicked', done => {
        _createComponent();

        component.phoneStateMachine.start();
        component.phoneStateMachine.displaycallcenters();

        Vue.nextTick(() => {
            const buttons = component.$el.querySelectorAll('[data-test-ref="signon-button"]');
            expect(buttons.length).toBe(1);
            buttons[0].click();
            expect(component.phoneStateMachine.state).toBe('loggedOn');
            done();
        });
    });
});
