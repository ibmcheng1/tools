import Vue from 'vue';
import OnCallState from './OnCallState.vue';

import StateMachine from 'javascript-state-machine';
import PhoneTransactions from './PhoneTransactions.js';

describe('OnCallState', () => {
    let component;

    /*
     * Create an instance of the (phone controls) OnCallState component
     */
    function _createComponent() {
        const Constructor = Vue.extend(OnCallState);
        // build the component and mount it
        component = new Constructor({
            propsData: {
                phoneStateMachine: new StateMachine(PhoneTransactions)
            }
        }).$mount();
    }

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('is named OnCallState', () => {
        expect(OnCallState.name).toEqual('OnCallState');
    });

    it('has a method onCall', () => {
        expect(typeof OnCallState.methods.onCall).toBe('function');
    });

    it('has a method onConsultCall', () => {
        expect(typeof OnCallState.methods.onConsultCall).toBe('function');
    });

    it('has a method consult', () => {
        expect(typeof OnCallState.methods.consult).toBe('function');
    });

    it('has a method onConsultEndCall', () => {
        expect(typeof OnCallState.methods.onConsultEndCall).toBe('function');
    });

    it('has a method transfer', () => {
        expect(typeof OnCallState.methods.transfer).toBe('function');
    });

    it('can click the transfer button', done => {
        _createComponent();

        Vue.nextTick(() => {
            const buttons = component.$el.querySelectorAll('[data-test-ref="transfer-button"]');
            expect(buttons.length).toBe(1);
            buttons[0].click();
            done();
        });
    });

    it('state is \'onCall\' after state dialout', done => {
        _createComponent();

        component.phoneStateMachine.start();
        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();
        component.phoneStateMachine.dialout();
        component.phoneStateMachine.makecall();

        Vue.nextTick(() => {
            expect(component.phoneStateMachine.state).toBe('onCall');
            done();
        });
    });

    it('display call button label as \'On Call (Click to Hold)\'', done => {
        _createComponent();

        Vue.nextTick(() => {
            const buttons = component.$el.querySelectorAll('[data-test-ref="on-call-click-to-hold-button"]');
            expect(buttons.length).toBe(1);
            expect(buttons[0].innerText).toBe('On Call (Click to Hold)');
            done();
        });
    });

    it('display the consult button when disabled', done => {
        _createComponent();

        Vue.nextTick(() => {
            const buttons = component.$el.querySelectorAll('[data-test-ref="consult-button"]');
            expect(buttons.length).toBe(1);
            expect(buttons[0].disabled).toBeTruthy();
            done();
        });
    });

    it('display the consult button when not disabled', done => {
        _createComponent();

        const buttons = component.$el.querySelectorAll('[data-test-ref="on-call-click-to-hold-button"]');
        expect(buttons.length).toBe(1);
        buttons[0].click();

        Vue.nextTick(() => {
            expect(buttons[0].disabled).toBeFalsy();
            done();
        });
    });

    it('display clicked call button label as \'On Hold (Click to Talk)\'', done => {
        _createComponent();

        Vue.nextTick(() => {
            const buttons = component.$el.querySelectorAll('[data-test-ref="on-call-click-to-hold-button"]');
            expect(buttons.length).toBe(1);
            expect(buttons[0].innerText).toBe('On Call (Click to Hold)');
            buttons[0].click();

            Vue.nextTick(() => {
                const buttons = component.$el.querySelectorAll('[data-test-ref="on-call-click-to-hold-button"]');
                expect(buttons.length).toBe(1);
                expect(buttons[0].innerText).toBe('On Hold (Click to Talk)');
                done();
            });
        });
    });

    it('display phone status toggles between \'ON CALL\' and \'ON HOLD\'', done => {
        _createComponent();

        component.phoneStateMachine.start();
        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();
        component.phoneStateMachine.dialout();
        component.phoneStateMachine.makecall();

        Vue.nextTick(() => {
            expect(component.phoneStateMachine.phoneStatusMsg).toBe('ON CALL');

            const buttons = component.$el.querySelectorAll('[data-test-ref="on-call-click-to-hold-button"]');
            expect(buttons.length).toBe(1);
            buttons[0].click();

            expect(component.phoneStateMachine.phoneStatusMsg).toBe('ON HOLD');

            buttons[0].click();
            expect(component.phoneStateMachine.phoneStatusMsg).toBe('ON CALL');
            done();
        });
    });

    it('display consult on call, and end consult buttons when the consult button is clicked', done => {
        _createComponent();

        Vue.nextTick(() => {
            let buttons = component.$el.querySelectorAll('[data-test-ref="on-call-consult-button"]');
            expect(buttons.length).toBe(0);

            buttons = component.$el.querySelectorAll('[data-test-ref="end-consult-button"]');
            expect(buttons.length).toBe(0);

            buttons = component.$el.querySelectorAll('[data-test-ref="on-call-click-to-hold-button"]');
            expect(buttons.length).toBe(1);
            buttons[0].click(); // enable the consult button by clicking the on call button

            Vue.nextTick(() => {
                buttons = component.$el.querySelectorAll('[data-test-ref="consult-button"]');
                expect(buttons.length).toBe(1);

                buttons[0].click(); // click the consult button to enable the consult call and end call buttons

                Vue.nextTick(() => {
                    buttons = component.$el.querySelectorAll('[data-test-ref="on-call-consult-button"]');
                    expect(buttons.length).toBe(1); // on call consult button is shown
                    expect(buttons[0].innerText).toBe('On Call (Click to Hold)');

                    buttons = component.$el.querySelectorAll('[data-test-ref="end-consult-button"]');
                    expect(buttons.length).toBe(1); // end consult button is shown

                    buttons = component.$el.querySelectorAll('[data-test-ref="consult-button"]');
                    expect(buttons.length).toBe(0); // consult button was removed
                    done();
                });
            });
        });
    });

    it('display consult on call and end consult buttons, check on call consult button\'s toggle text', done => {
        _createComponent();

        Vue.nextTick(() => {
            let buttons = component.$el.querySelectorAll('[data-test-ref="on-call-click-to-hold-button"]');
            expect(buttons.length).toBe(1);
            buttons[0].click(); // enable the consult button by clicking the on call button

            Vue.nextTick(() => {
                buttons = component.$el.querySelectorAll('[data-test-ref="consult-button"]');
                expect(buttons.length).toBe(1);
                buttons[0].click(); // click the consult button to enable the consult call and end call buttons

                Vue.nextTick(() => {
                    buttons = component.$el.querySelectorAll('[data-test-ref="on-call-consult-button"]');
                    expect(buttons[0].innerText).toBe('On Call (Click to Hold)');
                    expect(buttons.length).toBe(1); // on call consult button is shown
                    buttons[0].click();

                    Vue.nextTick(() => {
                        expect(buttons[0].innerText).toBe('On Hold (Click to Talk)');
                        buttons[0].click();

                        Vue.nextTick(() => {
                            expect(buttons[0].innerText).toBe('On Call (Click to Hold)');
                            done();
                        });
                    });
                });
            });
        });
    });

    it('displays the consult end call button', done => {
        _createComponent();

        Vue.nextTick(() => {
            let buttons = component.$el.querySelectorAll('[data-test-ref="on-call-click-to-hold-button"]');
            expect(buttons.length).toBe(1);
            buttons[0].click(); // enable the consult button by clicking the on call button

            Vue.nextTick(() => {
                buttons = component.$el.querySelectorAll('[data-test-ref="consult-button"]');
                expect(buttons.length).toBe(1);
                buttons[0].click();

                Vue.nextTick(() => {
                    buttons = component.$el.querySelectorAll('[data-test-ref="end-consult-button"]');
                    expect(buttons.length).toBe(1);
                    done();
                });
            });
        });
    });

    it('click the consult end call button to remove the consult on call button, and show the consult button', done => {
        _createComponent();

        let buttons = component.$el.querySelectorAll('[data-test-ref="on-call-click-to-hold-button"]');
        expect(buttons.length).toBe(1);
        buttons[0].click(); // enable the consult button by clicking the on call button

        Vue.nextTick(() => {
            buttons = component.$el.querySelectorAll('[data-test-ref="consult-button"]');
            expect(buttons.length).toBe(1); // consult button
            buttons[0].click(); // click the consult button

            Vue.nextTick(() => {
                buttons = component.$el.querySelectorAll('[data-test-ref="on-call-consult-button"]');
                expect(buttons.length).toBe(1); // on call consult button

                buttons = component.$el.querySelectorAll('[data-test-ref="end-consult-button"]');
                expect(buttons.length).toBe(1); // on call consult end task button
                buttons[0].click();

                Vue.nextTick(() => {
                    buttons = component.$el.querySelectorAll('[data-test-ref="on-call-consult-button"]');
                    expect(buttons.length).toBe(0); // on call consult button
                    done();
                });
            });
        });
    });
});
