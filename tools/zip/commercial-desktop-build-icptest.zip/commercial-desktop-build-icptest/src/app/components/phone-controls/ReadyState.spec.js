import Vue from 'vue';
import ReadyState from './ReadyState.vue';

import StateMachine from 'javascript-state-machine';
import PhoneTransactions from './PhoneTransactions.js';

describe('ReadyState', () => {
    let component;

    /*
     * Create an instance of the (phone controls) OnCallState component
     */
    function _createComponent() {
        const Constructor = Vue.extend(ReadyState);
        // build the component and mount it
        component = new Constructor({
            propsData: {
                phoneStateMachine: new StateMachine(PhoneTransactions)
            }
        }).$mount();
    }

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('is named OnCallState', () => {
        expect(ReadyState.name).toEqual('ReadyState');
    });

    it('has a method goUnavailable', () => {
        expect(typeof ReadyState.methods.goUnavailable).toBe('function');
    });

    it('has a method reasonSelected', () => {
        expect(typeof ReadyState.methods.reasonSelected).toBe('function');
    });

    it('has a computed method isDisabled', () => {
        expect(typeof ReadyState.computed.isDisabled).toBe('function');
    });

    it('state is \'ready\'', done => {
        _createComponent();

        component.phoneStateMachine.start();
        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();
        component.phoneStateMachine.ready();

        Vue.nextTick(() => {
            expect(component.phoneStateMachine.state).toBe('ready');
            done();
        });
    });

    it('display the go unavailable button as disabled', done => {
        _createComponent();

        Vue.nextTick(() => {
            const buttons = component.$el.querySelectorAll('[data-test-ref="go-unavailable-button"]');
            expect(buttons.length).toBe(1);
            expect(buttons[0].disabled).toBeTruthy();
            done();
        });
    });

    it('display drop down away reasons', done => {
        _createComponent();

        component.phoneStateMachine.start();
        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();
        component.phoneStateMachine.ready();

        Vue.nextTick(() => {
            const reasons = component.$el.querySelectorAll('[data-test-ref="not-ready-reasons"]');
            expect(reasons.length).toBe(5);
            done();
        });
    });

    it('display go unavailable button as enabled when the reason selected method is invoked with value other than \'0\'', done => {
        _createComponent();

        component.phoneStateMachine.start();
        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();
        component.phoneStateMachine.ready();

        const selectReasons = component.$el.querySelectorAll('[data-test-ref="select-not-ready-reasons"]');
        expect(selectReasons.length).toBe(1);

        component.reasonSelected({target: {value: '2'}});

        Vue.nextTick(() => {
            const buttons = component.$el.querySelectorAll('[data-test-ref="go-unavailable-button"]');
            expect(buttons.length).toBe(1);
            expect(buttons[0].disabled).toBeFalsy();
            done();
        });
    });

    it('display go unavailable button as disabled when the reason selected method is invoked with value of \'0\'', done => {
        _createComponent();

        component.phoneStateMachine.start();
        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();
        component.phoneStateMachine.ready();

        const selectReasons = component.$el.querySelectorAll('[data-test-ref="select-not-ready-reasons"]');
        expect(selectReasons.length).toBe(1);

        component.reasonSelected({target: {value: '0'}});

        Vue.nextTick(() => {
            const buttons = component.$el.querySelectorAll('[data-test-ref="go-unavailable-button"]');
            expect(buttons.length).toBe(1);
            expect(buttons[0].disabled).toBeTruthy();
            done();
        });
    });

    it('navigates to \'loggedOn\' state when go unavailable button is clicked', done => {
        _createComponent();

        component.phoneStateMachine.start();
        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();
        component.phoneStateMachine.ready();

        const selectReasons = component.$el.querySelectorAll('[data-test-ref="select-not-ready-reasons"]');
        expect(selectReasons.length).toBe(1);

        component.reasonSelected({target: {value: '1'}});

        Vue.nextTick(() => {
            const buttons = component.$el.querySelectorAll('[data-test-ref="go-unavailable-button"]');
            expect(buttons.length).toBe(1);
            expect(buttons[0].disabled).toBeFalsy();
            buttons[0].click();

            expect(component.phoneStateMachine.state).toBe('loggedOn');
            done();
        });
    });
});
