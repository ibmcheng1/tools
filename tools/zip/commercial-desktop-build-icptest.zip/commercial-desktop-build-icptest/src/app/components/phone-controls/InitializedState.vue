<template>
    <span>
        <b-button
            data-test-ref="signon-button"
            variant="light"
            @click="signon">Sign On</b-button>
    </span>
</template>

<script>
export default {
    /** @lends app.components.InitializedState.prototype */
    name: 'InitializedState',
    props: {
        phoneStateMachine: {
            default: null,
            type: Object,
            required: true
        }
    },
    methods: {
        /**
         * Sign on button clicked event
         */
        signon() {
            this.phoneStateMachine.displaycallcenters();
        }
    }
};
</script>
