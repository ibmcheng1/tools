<template>
    <span class="form-inline d-inline-flex align-middle">
        <span class="form-group mr-2">
            <label
                for="callCenterSelect"
                class="mr-2">Call Center</label>
            <b-form-select
                id="callCenterSelect">
                <option
                    v-for="callCenter in phoneStateMachine.callCenters"
                    :key="callCenter"
                    data-test-ref="call-center-list">{{ callCenter }}
                </option>
            </b-form-select>
        </span>
        <b-button
            variant="light"
            data-test-ref="signon-button"
            @click="signon">Sign On</b-button>
    </span>
</template>

<script>
export default {
    /** @lends app.components.CallCenterSelectionState.prototype */
    name: 'CallCenterSelectionState',
    props: {
        phoneStateMachine: {
            default: null,
            type: Object,
            required: true
        }
    },
    methods: {
        signon() {
            this.$root.$emit('signon-notification'); // update signon call timer
            this.phoneStateMachine.selectcallcenters();
        }
    }
};
</script>
