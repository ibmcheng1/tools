import StateMachine from 'javascript-state-machine';
import PhoneTransactions from './PhoneTransactions.js';

describe('PhoneTransactions tests', () => {
    let psm = null;

    beforeEach(() => {
        psm = new StateMachine(PhoneTransactions);
    });

    it('expect onEnterInitialized() to return status \'LOGGED OUT\'', () => {
        psm.onEnterInitialized();
        expect(psm.phoneStatusMsg).toEqual('LOGGED OUT');
    });

    it('expect onEnterCallCenterSelection() to return a list of callCenters', () => {
        psm.onEnterCallCenterSelection();
        expect(psm.callCenters.length).toBe(4);
    });

    it('expect PhoneTransactions.init to be \'loading\'', () => {
        expect(PhoneTransactions.init).toBe('loading');
    });

    it('expect onEnterLoggedOn() to update phoneStatusMessage', () => {
        psm.onEnterLoggedOn();
        expect(psm.phoneStatusMsg).toBe('UNAVAILABLE');
    });

    it('expect onEnterSignOff() to update message', () => {
        psm.onEnterSignOff();
        expect(psm.message).toBe('Are you sure you want to log off?');
    });

    it('expect onLeaveSignOff() to update message', () => {
        psm.onLeaveSignOff();
        expect(psm.message).toBe('');
    });

    it('expect onEnterDialOut() to update message', () => {
        psm.onEnterDialOut();
        expect(psm.message).toBe('The call will connect to your phone first. You must answer it to complete the outbound call.');
    });

    it('expect onLeaveDialOut() to update message', () => {
        psm.onLeaveDialOut();
        expect(psm.message).toBe('');
    });
});
