<template>
    <span>
        <b-button
            variant="light"
            data-test-ref="yes-button"
            @click="yes">Yes</b-button>
        <b-button
            variant="light"
            data-test-ref="no-button"
            @click="no">No</b-button>
    </span>
</template>

<script>
export default {
    /** @lends app.components.SignOffState.prototype */
    name: 'SignOffState',
    props: {
        phoneStateMachine: {
            default: null,
            type: Object,
            required: true
        }
    },
    methods: {
        yes() {
            this.phoneStateMachine.signoffyes();
        },
        no() {
            this.phoneStateMachine.signoffno();
        }
    }
};
</script>
