<template>
    <span>
        <span class="label">Line 1</span>
        <span>
            <b-button
                :variant="callVariant"
                data-test-ref="on-call-click-to-hold-button"
                @click="onCall">{{ callButtonText }}</b-button>
            <b-button
                variant="light"
                data-test-ref="transfer-button"
                @click="transfer">Transfer</b-button>
            <span class="label">Line 2</span>
            <template v-if="!consultRequested">
                <b-button
                    :disabled = "isConsultDisabled"
                    variant="light"
                    data-test-ref="consult-button"
                    @click="consult">Consult</b-button>
            </template>
            <template v-if="consultRequested">
                <b-button
                    :variant="consultVariant"
                    data-test-ref="on-call-consult-button"
                    @click="onConsultCall">{{ consultButtonText }}</b-button>
                <b-button
                    variant="light"
                    data-test-ref="end-consult-button"
                    @click="onConsultEndCall">End Consult</b-button>
            </template>
        </span>
    </span>
</template>

<script>
const ON_CALL_CLICK_TO_HOLD = 'On Call (Click to Hold)';
const ON_HOLD_CLICK_TO_TALK = 'On Hold (Click to Talk)';

export default {
    /** @lends app.components.OnCallState.prototype */
    name: 'OnCallState',
    props: {
        phoneStateMachine: {
            default: null,
            type: Object,
            required: true
        }
    },
    data: () => {
        return {
            consultDisabled: true,
            consultRequested: null,

            // Call section data
            isOnCall: true,
            callVariant: 'success',
            callButtonText: ON_CALL_CLICK_TO_HOLD,

            // Consult call section data
            isOnConsultCall: true,
            consultVariant: 'success',
            consultButtonText: ON_CALL_CLICK_TO_HOLD
        };
    },
    computed: {
        /**
         * Enable / disable the Consult button
         */
        isConsultDisabled() {
            return this.consultDisabled;
        }
    },
    methods: {
        /**
         * The call button was clicked this can toggle the phone status between ON CALL/ON HOLD and also enable/disable the Consult button
         */
        onCall() {
            this.isOnCall = !this.isOnCall;
            this.consultDisabled = this.isOnCall;
            this.callVariant = this.isOnCall ? 'success' : 'warning';
            this.callButtonText = this.isOnCall ? ON_CALL_CLICK_TO_HOLD : ON_HOLD_CLICK_TO_TALK;

            if (!this.isOnCall) {
                this.$root.$emit('hold-notification'); // if on hold then update call timer
            }
            this.phoneStateMachine.phoneStatusMsg = this.isOnCall ? 'ON CALL' : 'ON HOLD';
        },
        /**
         * The on consult call button was clicked
         */
        onConsultCall() {
            this.isOnConsultCall = !this.isOnConsultCall;
            this.consultVariant = this.isOnConsultCall ? 'success' : 'warning';
            this.consultButtonText = (this.isOnConsultCall) ? ON_CALL_CLICK_TO_HOLD : ON_HOLD_CLICK_TO_TALK;
        },
        /**
         * Transfer this call
         */
        transfer() {
            // TODO transfer logic launches attached application
        },
        /**
         * Allow the user to consult with another party/agent
         */
        consult() {
            this.consultRequested = true;
        },
        /**
         * End the consult call
         */
        onConsultEndCall() {
            this.consultRequested = false;
        }
    }
};
</script>
