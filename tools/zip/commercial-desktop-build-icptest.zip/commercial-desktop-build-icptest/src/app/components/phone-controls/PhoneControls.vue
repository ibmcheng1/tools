<template>
    <div
        class="app-phone-controls"
        aria-label="Phone Controls">
        <span
            v-b-tooltip.hover.bottomright
            title="Concierge Agent JOHN SMITH"
            class="fa fa-csm-headset-circle-o align-middle mr-1"
            data-test-ref="concierge-icon"></span>
        <span
            class="fa fa-csm-phone-circle-o align-middle"
            data-test-ref="phone-icon"></span>
        <span
            class="align-middle mx-2"
            data-test-ref="phone-status-message">{{ phoneStateMachine.phoneStatusMsg }}</span>

        <template v-if="phoneStateMachine.state === 'initialized'">
            <phone-controls-initialized-state
                :phone-state-machine="phoneStateMachine"
                data-test-ref="initialized-state-component"/>
        </template>

        <template v-if="phoneStateMachine.state === 'callCenterSelection'">
            <phone-controls-call-center-selection-state
                :phone-state-machine="phoneStateMachine"
                data-test-ref="call-center-selection-state-component"/>
        </template>

        <template v-if="phoneStateMachine.state === 'loggedOn'">
            <phone-controls-logged-on-state
                :phone-state-machine="phoneStateMachine"
                data-test-ref="logged-on-state-component"/>
        </template>

        <template v-if="phoneStateMachine.state === 'signOff'">
            <phone-controls-sign-off-state
                :phone-state-machine="phoneStateMachine"
                data-test-ref="sign-off-state-component"/>
        </template>

        <template v-if="phoneStateMachine.state === 'dialOut'">
            <phone-controls-dial-out-state
                :phone-state-machine="phoneStateMachine"
                data-test-ref="dial-out-state-component"/>
        </template>

        <template v-if="phoneStateMachine.state === 'onCall'">
            <phone-controls-on-call-state
                :phone-state-machine="phoneStateMachine"
                data-test-ref="on-call-state-component"/>
        </template>

        <template v-if="phoneStateMachine.state === 'ready'">
            <phone-controls-ready-state
                :phone-state-machine="phoneStateMachine"
                data-test-ref="ready-state-component"/>
        </template>

        <span data-test-ref="message">{{ phoneStateMachine.message }}</span>
    </div>
</template>

<script>
import StateMachine from 'javascript-state-machine';
import PhoneTransactions from './PhoneTransactions.js';

import InitializedState from './InitializedState.vue';
import CallCenterSelectionState from './/CallCenterSelectionState.vue';
import LoggedOnState from './LoggedOnState.vue';
import SignOffState from './SignOffState.vue';
import DialOutState from './DialOutState.vue';
import OnCallState from './OnCallState.vue';
import ReadyState from './ReadyState.vue';

export default {
    /** @lends app.components.PhoneControls.prototype */
    name: 'PhoneControls',
    components: {
        'phone-controls-initialized-state': InitializedState,
        'phone-controls-call-center-selection-state': CallCenterSelectionState,
        'phone-controls-logged-on-state': LoggedOnState,
        'phone-controls-sign-off-state': SignOffState,
        'phone-controls-dial-out-state': DialOutState,
        'phone-controls-on-call-state': OnCallState,
        'phone-controls-ready-state': ReadyState
    },
    data: () => {
        return {
            phoneStateMachine: null
        };
    },
    created() {
        this.phoneStateMachine = new StateMachine(PhoneTransactions);
        this.phoneStateMachine.start();
    }
};
</script>
