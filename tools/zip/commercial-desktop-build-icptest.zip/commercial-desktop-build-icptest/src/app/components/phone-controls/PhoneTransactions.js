/**
 * Provide the state and transition declarations for a phone control or similar component
 *
 * @module PhoneTransactions
 * @memberof app
 */
import StateMachineHistory from 'javascript-state-machine/lib/history';

export default {
    data: {
        phoneStatusMsg: '', // phone status message, example logged out, unavailable, ready
        callCenters: [], // list of available call centers for this logged in user
        campaigns: [], // list of available campaigns for this logged in user
        awayReasons: [], // list of away reasons displayed in a drop down when the logged in user's call is in the ready state
        message: '' // general purpose message used to display informational, warning and error messages
    },
    methods: {
        /**
         * Enter 'initialized' state
         */
        onEnterInitialized() {
            this.phoneStatusMsg = 'LOGGED OUT';
        },
        /**
         * Enter 'callcenterselection' state
         */
        onEnterCallCenterSelection() {
            // TODO load data from RULEs
            this.callCenters = [];

            this.callCenters.push('Sandbox');
            this.callCenters.push('BlueChoice Health Plan');
            this.callCenters.push('Provider Services');
            this.callCenters.push('National Alliance');
        },
        onEnterLoggedOn() {
            this.phoneStatusMsg = 'UNAVAILABLE';
        },
        onEnterSignOff() {
            this.message = 'Are you sure you want to log off?';
        },
        onLeaveSignOff() {
            this.message = '';
        },
        onEnterDialOut() {
            // TODO load campaign data from service
            this.campaigns = [];

            this.campaigns.push('Aging Off Outbound - Calls Recorded');
            this.campaigns.push('HR OUTBOUND - CALL RECORDED');
            this.campaigns.push('PG Medicaid Dialout');
            this.campaigns.push('PBT ARBITRARY DIALOUT - test');
            this.campaigns.push('PBT ARBITRARY CALL - RECORDED');
            this.campaigns.push('Test Dialout 1-803-788-0500');
            this.campaigns.push('CF ARBITRARY DIALOUT');

            this.message = 'The call will connect to your phone first. You must answer it to complete the outbound call.';
        },
        onLeaveDialOut() {
            this.message = '';
        },
        onEnterOnCall() {
            this.phoneStatusMsg = 'ON CALL';
        },
        onEnterReady() {
            this.phoneStatusMsg = 'READY';

            // TODO load away reasons from phone api
            this.awayReasons = [];
            this.awayReasons.push('Choose one...');
            this.awayReasons.push('Not Ready');
            this.awayReasons.push('Post Call Work');
            this.awayReasons.push('TimeKeeping');
            this.awayReasons.push('Work Mode');
        },

        /**
         * Log state and history in development mode
         * @param {*} lifecycle
         */
        onTransition(lifecycle) {
            if (process.env.NODE_ENV === 'dev') {
                console.log('onTransition: transition: [' + lifecycle.transition + '] from: [' + lifecycle.from + '] to: [' + lifecycle.to + '] history: [' + this.history + ']');
            }
        }
    },
    plugins: [
        // provides state transaction history, e.g <code>StateMachine.history()</code>
        new StateMachineHistory()
    ],
    init: 'loading',
    transitions: [
        {name: 'start', from: 'loading', to: 'initialized'},
        {name: 'displaycallcenters', from: 'initialized', to: 'callCenterSelection'},
        {name: 'selectcallcenters', from: 'callCenterSelection', to: 'loggedOn'},
        {name: 'signoff', from: 'loggedOn', to: 'signOff'},
        {name: 'signoffyes', from: 'signOff', to: 'initialized'},
        {name: 'signoffno', from: 'signOff', to: 'loggedOn'},
        {name: 'dialout', from: 'loggedOn', to: 'dialOut'},
        {name: 'canceldialout', from: 'dialOut', to: 'loggedOn'},
        {name: 'makecall', from: 'dialOut', to: 'onCall'},
        {name: 'ready', from: 'loggedOn', to: 'ready'},
        {name: 'notready', from: 'ready', to: 'loggedOn'}

    ]
};
