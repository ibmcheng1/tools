import Vue from 'vue';
import SignOffState from './SignOffState.vue';

import StateMachine from 'javascript-state-machine';
import PhoneTransactions from './PhoneTransactions.js';

describe('SignOffState', () => {
    let component;

    /*
        * Create an instance of the (phone controls) SignOffState component
        */
    function _createComponent() {
        const Constructor = Vue.extend(SignOffState);
        // build the component and mount it
        component = new Constructor({
            propsData: {
                phoneStateMachine: new StateMachine(PhoneTransactions)
            }
        }).$mount();
    }

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('is named SignOffState', () => {
        expect(SignOffState.name).toEqual('SignOffState');
    });

    it('has a method yes', () => {
        expect(typeof SignOffState.methods.yes).toBe('function');
    });

    it('has a method no', () => {
        expect(typeof SignOffState.methods.no).toBe('function');
    });

    it('state is \'initialized\' when the yes button is clicked', done => {
        _createComponent();

        component.phoneStateMachine.start();
        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();
        component.phoneStateMachine.signoff();

        Vue.nextTick(() => {
            const buttons = component.$el.querySelectorAll('[data-test-ref="yes-button"]');
            expect(buttons.length).toBe(1);
            buttons[0].click();
            expect(component.phoneStateMachine.state).toBe('initialized');
            done();
        });
    });

    it('state is \'loggedOn\' when the yes button is clicked', done => {
        _createComponent();

        component.phoneStateMachine.start();
        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();
        component.phoneStateMachine.signoff();

        Vue.nextTick(() => {
            const buttons = component.$el.querySelectorAll('[data-test-ref="no-button"]');
            expect(buttons.length).toBe(1);
            buttons[0].click();
            expect(component.phoneStateMachine.state).toBe('loggedOn');
            done();
        });
    });
});
