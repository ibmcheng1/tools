<template>
    <span class="form-inline d-inline-flex align-middle">
        <span class="form-group mr-2">
            <label
                for="callCampaignSelect"
                class="mr-2">Campaign</label>
            <b-form-select
                id="callCampaignSelect">
                <option
                    v-for="campaign in phoneStateMachine.campaigns"
                    :key="campaign"
                    data-test-ref="campaign-items">{{ campaign }}
                </option>
            </b-form-select>
        </span>
        <span class="form-group mr-2">
            <label
                for="phoneNumberId"
                class="mr-2 wc-8">Phone Number</label>
            <b-form-input id="phoneNumberId"></b-form-input>
        </span>
        <b-button
            variant="light"
            data-test-ref="call-button"
            @click="call">Call</b-button>
        <b-button
            variant="light"
            data-test-ref="cancel-button"
            @click="cancel">Cancel</b-button>
    </span>
</template>

<script>
export default {
    /** @lends app.components.DialOutState.prototype */
    name: 'DialOutState',
    props: {
        phoneStateMachine: {
            default: null,
            type: Object,
            required: true
        }
    },
    methods: {
        call() {
            this.phoneStateMachine.makecall();
        },
        cancel() {
            this.phoneStateMachine.canceldialout();
        }
    }
};
</script>
