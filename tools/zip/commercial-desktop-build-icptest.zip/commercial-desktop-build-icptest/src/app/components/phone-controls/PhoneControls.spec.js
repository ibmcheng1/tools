import Vue from 'vue';
import PhoneControls from './PhoneControls.vue';

describe('PhoneControls', () => {
    let component;

    /*
     * Create an instance of the phone controls parent component
     */
    function _createComponent() {
        const Constructor = Vue.extend(PhoneControls);
        // build the component and mount it
        component = new Constructor({
        }).$mount();
    }

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('is named PhoneControls', () => {
        expect(PhoneControls.name).toEqual('PhoneControls');
    });

    it('has a method created', () => {
        expect(typeof PhoneControls.created).toBe('function');
    });

    it('displays phone status \'LOGGED OUT\' once the component is mounted', done => {
        _createComponent();

        Vue.nextTick(() => {
            const phoneStatusMsgs = component.$el.querySelectorAll('[data-test-ref="phone-status-message"]');
            expect(phoneStatusMsgs.length).toBe(1);
            expect(phoneStatusMsgs[0].innerText).toBe('LOGGED OUT');
            done();
        });
    });

    it('state is \'initialized\' once the component is mounted', done => {
        _createComponent();

        Vue.nextTick(() => {
            expect(component.phoneStateMachine.state).toBe('initialized');
            done();
        });
    });

    it('displays the initialized state component', done => {
        _createComponent();

        Vue.nextTick(() => {
            const components = component.$el.querySelectorAll('[data-test-ref="initialized-state-component"]');
            expect(components.length).toBe(1);
            done();
        });
    });

    it('displays the callcenter selection state component', done => {
        _createComponent();

        component.phoneStateMachine.displaycallcenters();

        Vue.nextTick(() => {
            const components = component.$el.querySelectorAll('[data-test-ref="call-center-selection-state-component"]');
            expect(components.length).toBe(1);
            done();
        });
    });

    it('displays the loggedon state component', done => {
        _createComponent();

        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();

        Vue.nextTick(() => {
            const components = component.$el.querySelectorAll('[data-test-ref="logged-on-state-component"]');
            expect(components.length).toBe(1);
            done();
        });
    });

    it('displays the signoff state component', done => {
        _createComponent();

        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();
        component.phoneStateMachine.signoff();

        Vue.nextTick(() => {
            const components = component.$el.querySelectorAll('[data-test-ref="sign-off-state-component"]');
            expect(components.length).toBe(1);
            done();
        });
    });

    it('displays the initialized state component when Yes is selected in the sign off state component', done => {
        _createComponent();

        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();
        component.phoneStateMachine.signoff();
        component.phoneStateMachine.signoffyes();

        Vue.nextTick(() => {
            const components = component.$el.querySelectorAll('[data-test-ref="initialized-state-component"]');
            expect(components.length).toBe(1);
            done();
        });
    });

    it('displays the logged on state component when No is selected in the sign off state component', done => {
        _createComponent();

        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();
        component.phoneStateMachine.signoff();
        component.phoneStateMachine.signoffno();

        Vue.nextTick(() => {
            const components = component.$el.querySelectorAll('[data-test-ref="logged-on-state-component"]');
            expect(components.length).toBe(1);
            done();
        });
    });

    it('displays the dial out state component', done => {
        _createComponent();

        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();
        component.phoneStateMachine.dialout();

        Vue.nextTick(() => {
            const components = component.$el.querySelectorAll('[data-test-ref="dial-out-state-component"]');
            expect(components.length).toBe(1);
            done();
        });
    });

    it('displays the on call state component', done => {
        _createComponent();

        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();
        component.phoneStateMachine.dialout();
        component.phoneStateMachine.makecall();

        Vue.nextTick(() => {
            const components = component.$el.querySelectorAll('[data-test-ref="on-call-state-component"]');
            expect(components.length).toBe(1);
            done();
        });
    });

    it('displays the ready state component', done => {
        _createComponent();

        component.phoneStateMachine.displaycallcenters();
        component.phoneStateMachine.selectcallcenters();
        component.phoneStateMachine.ready();

        Vue.nextTick(() => {
            const components = component.$el.querySelectorAll('[data-test-ref="ready-state-component"]');
            expect(components.length).toBe(1);
            done();
        });
    });

    it('contains the concierge icon', done => {
        _createComponent();

        Vue.nextTick(() => {
            const components = component.$el.querySelectorAll('[data-test-ref="concierge-icon"]');
            expect(components.length).toBe(1);
            done();
        });
    });
});
