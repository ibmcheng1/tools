import Vue from 'vue';
import InitializedState from './InitializedState.vue';

import StateMachine from 'javascript-state-machine';
import PhoneTransactions from './PhoneTransactions.js';

describe('InitializedState', () => {
    let component;

    /*
     * Create an instance of the (phone controls) Initialized component
     */
    function _createComponent() {
        const Constructor = Vue.extend(InitializedState);
        // build the component and mount it
        component = new Constructor({
            propsData: {
                phoneStateMachine: new StateMachine(PhoneTransactions)
            }
        }).$mount();
    }

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('is named Initialized', () => {
        expect(InitializedState.name).toEqual('InitializedState');
    });

    it('has a method signon', () => {
        expect(typeof InitializedState.methods.signon).toBe('function');
    });

    it('state is \'initialized\' once the component is mounted', done => {
        _createComponent();

        component.phoneStateMachine.start();
        Vue.nextTick(() => {
            expect(component.phoneStateMachine.state).toBe('initialized');
            done();
        });
    });

    it('state is \'callCenterSelection\' when the signon button is clicked', done => {
        _createComponent();

        component.phoneStateMachine.start();
        Vue.nextTick(() => {
            const signonButtons = component.$el.querySelectorAll('[data-test-ref="signon-button"]');
            expect(signonButtons.length).toBe(1);
            signonButtons[0].click();
            expect(component.phoneStateMachine.state).toBe('callCenterSelection');
            done();
        });
    });
});
