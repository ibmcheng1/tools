import Vue from 'vue';
import BillingSummarySubscriber from './BillingSummarySubscriber.vue';
import DesktopBaseComponent from './DesktopBaseComponent.vue';

import DataStore from './../store/DataStore.js';

import {mockSubscriberBillingSummary as fullMock} from './../store/mock/billing-summary-subscriber/BillingSummaryMock.js';
import assigndeep from 'assign-deep';

describe('BillingSummarySubscriber', () => {
    let component;

    function _createComponent(model) {
        const Constructor = Vue.extend(BillingSummarySubscriber);

        // set the billing summary model into the store
        DataStore.store.state.billingSummarySubscriber = model;

        // build the component and mount it
        component = new Constructor({
            store: DataStore.store
        }).$mount();
    }

    beforeEach(() => {
        spyOn(DesktopBaseComponent.methods, 'refreshData').and.returnValue(1);
        spyOn(DesktopBaseComponent.methods, 'cacheSummaryLinks').and.returnValue(1);
    });

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('is named BillingSummarySubscriber', () => {
        expect(BillingSummarySubscriber.name).toEqual('BillingSummarySubscriber');
    });

    it('has a method getData()', () => {
        expect(typeof BillingSummarySubscriber.methods.getData).toBe('function');
    });

    it('has a method clearData()', () => {
        expect(typeof BillingSummarySubscriber.methods.clearData).toBe('function');
    });

    it('has a computed billingSummary property', () => {
        expect(typeof BillingSummarySubscriber.computed.billingSummary).toBe('function');
    });

    it('has a computed billingInformation property', () => {
        expect(typeof BillingSummarySubscriber.computed.billingInformation).toBe('function');
    });

    it('has a computed groupPolicy property', () => {
        expect(typeof BillingSummarySubscriber.computed.groupPolicy).toBe('function');
    });

    it('has a computed individualPolicy property', () => {
        expect(typeof BillingSummarySubscriber.computed.individualPolicy).toBe('function');
    });

    it('displays nothing when there is no data', done => {
        _createComponent({});

        Vue.nextTick(() => {
            const body = component.$el;
            expect(body.innerText.trim()).toBe('');
            done();
        });
    });

    it('displays error message when policyTypeNotFound is true', done => {
        _createComponent({
            policyTypeNotFound: true
        });

        Vue.nextTick(() => {
            const policyMessages = component.$el.querySelectorAll('[data-test-ref="policy-type-not-found"]');
            expect(policyMessages.length).toBe(1);
            expect(policyMessages[0].innerText).toBe('Subscriber was not found on CES.');
            done();
        });
    });

    it('does not display error message when policyTypeNotFound is false', done => {
        _createComponent({
            policyTypeNotFound: false
        });

        Vue.nextTick(() => {
            const messages = component.$el.querySelectorAll('[data-test-ref="policy-type-not-found"]');
            expect(messages.length).toBe(0);
            done();
        });
    });

    it('displays blank page when billingInformationLoaded is false', done => {
        _createComponent({
            policyTypeNotFound: false,
            billingInformationLoaded: false
        });

        Vue.nextTick(() => {
            const body = component.$el;
            expect(body.innerText.trim()).toBe('');
            done();
        });
    });

    it('displays error message when billingInformation is empty', done => {
        _createComponent({
            policyTypeNotFound: false,
            billingInformationLoaded: true,
            billingInformation: ''
        });

        Vue.nextTick(() => {
            const messages = component.$el.querySelectorAll('[data-test-ref="billing-information-not-found"]');
            expect(messages.length).toBe(1);
            expect(messages[0].innerText).toBe('No billing summary data found.');
            done();
        });
    });

    // begin links section
    it('displays Accounts Receivable link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="accounts-receivable-link"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('Accounts Receivable');
            expect(nodes[0].getAttribute('href')).toBe('http://www.fullstackradio.com/episodes');
            expect(nodes[0].getAttribute('target')).toBe('_blank');
            done();
        });
    });

    it('does not display Accounts Receivable link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                hasCoveragePeriods: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="accounts-receivable-link"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Active Members link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="active-members-link"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('Active Members');
            expect(nodes[0].getAttribute('href')).toBe('https://news.vuejs.org/');
            expect(nodes[0].getAttribute('target')).toBe('_blank');
            done();
        });
    });

    it('does not display Active Members link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="active-members-link"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Bill Info History link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="billing-number-link"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('Bill Info History');
            expect(nodes[0].getAttribute('href')).toBe('https://vuejs.org/');
            expect(nodes[0].getAttribute('target')).toBe('_blank');
            done();
        });
    });

    it('does not display Bill Info History link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="billing-number-link"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Delinquency Status link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="delinquency-status-link"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('Delinquency Status');
            expect(nodes[0].getAttribute('href')).toBe('https://vuejs.org/v2/guide/');
            expect(nodes[0].getAttribute('target')).toBe('_blank');
            done();
        });
    });

    it('does not display Delinquency Status link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="delinquency-status-link"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Employee List link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="employee-list-link"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('Employee List');
            expect(nodes[0].getAttribute('href')).toBe('https://vuejs.org/v2/guide/#Conditionals-and-Loops');
            expect(nodes[0].getAttribute('target')).toBe('_blank');
            done();
        });
    });

    it('does not display Employee List link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="employee-list-link"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays One Time Payment link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="one-time-payment-link"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('One Time Payment');
            expect(nodes[0].getAttribute('href')).toBe('https://vuejs.org/v2/guide/#Handling-User-Input');
            expect(nodes[0].getAttribute('target')).toBe('_blank');
            done();
        });
    });

    it('does not display One Time Payment link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="one-time-payment-link"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });
    // end links section

    // begin data section
    it('displays Contract Type Group', done => {
        _createComponent({
            policyTypeNotFound: false,
            billingInformationLoaded: true,
            billingInformation: {
                groupPolicy: true
            }
        });

        Vue.nextTick(() => {
            let nodes = component.$el.querySelectorAll('[data-test-ref="group-policy"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('GROUP');

            nodes = component.$el.querySelectorAll('[data-test-ref="individual-policy"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Contract Type Individual', done => {
        _createComponent({
            policyTypeNotFound: false,
            billingInformationLoaded: true,
            billingInformation: {
                groupPolicy: false
            }
        });

        Vue.nextTick(() => {
            let nodes = component.$el.querySelectorAll('[data-test-ref="individual-policy"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('INDIVIDUAL');

            nodes = component.$el.querySelectorAll('[data-test-ref="group-policy"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Bill Number', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="billing-number"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('036011100');
            done();
        });
    });

    it('does not display Bill Number', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="billing-number"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Master AR link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="master-ar-number-link"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('036011100');
            expect(nodes[0].getAttribute('href')).toBe('https://vuejs.org/v2/guide/list.html#Replacing-an-Array');
            expect(nodes[0].getAttribute('target')).toBe('_blank');
            done();
        });
    });

    it('does not display Master AR link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                masterARNumber: null
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="master-ar-number-link"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Client Number link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="client-number-link"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('00006');
            expect(nodes[0].getAttribute('href')).toBe('https://vuejs.org/v2/guide/list.html');
            expect(nodes[0].getAttribute('target')).toBe('_blank');
            done();
        });
    });

    it('does not display Client Number link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="client-number-link"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Payment Summary', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="payment-number"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('12345');
            done();
        });
    });

    it('does not display Payment Summary', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="payment-number"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Due Date', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="due-date"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('10/01/2008');
            done();
        });
    });

    it('does not display Due Date', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                dueDate: null
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="due-date"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Statement Created', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="statement-created-date"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('09/17/2008');
            done();
        });
    });

    it('does not display Statement Created', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="statement-created-date"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Current Balance Group', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="group-policy-current-balance"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('55.22');
            done();
        });
    });

    it('displays Current Balance Individual link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="individual-policy-current-balance-link"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('55.22');
            expect(nodes[0].getAttribute('href')).toBe('https://vuejs.org/v2/guide/installation.html');
            expect(nodes[0].getAttribute('target')).toBe('_blank');
            done();
        });
    });

    it('does not display Current Balance Individual', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="individual-policy-current-balance-link"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('does not display Current Balance Group', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="group-policy-current-balance"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Last Payment', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="last-payment-amount"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('34.56');
            done();
        });
    });

    it('displays Last Payment formatted currency', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false,
                lastPayment: 123.1
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="last-payment-amount"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('123.10');
            done();
        });
    });

    it('does not display Last Payment', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="last-payment-amount"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Received Date', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));
        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="last-payment-received-date"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('10/01/2008');
            done();
        });
    });

    it('does not display Received Date', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="last-payment-received-date"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays List Bill Name', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="list-bill-name"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('BCBSSC');
            done();
        });
    });

    it('does not display List Bill Name', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="list-bill-name"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays List Bill Account Number', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="list-bill-account-name-link"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('ACC12345');
            expect(nodes[0].getAttribute('href')).toBe('https://vuejs.org/v2/guide/list.html#v-for-with-v-if');
            expect(nodes[0].getAttribute('target')).toBe('_blank');
            done();
        });
    });

    it('does not display List Bill Account Number', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="list-bill-account-name-link"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays List Bill Contact', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="list-bill-contact-name"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('ACCOUNTS BILLTEST');
            done();
        });
    });

    it('does not display List Bill Contact', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="list-bill-contact-name"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays List Bill Phone Number', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="list-bill-phone-number"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('803-111-2222');
            done();
        });
    });

    it('does not display List Bill Phone Number', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="list-bill-phone-number"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Bank Name', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="bank-account-name"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('FIRST TEST BANK');
            done();
        });
    });

    it('does not display Bank Name', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="bank-account-name"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Bank Account Number link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="bank-account-number-link"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('1234567890');
            expect(nodes[0].getAttribute('href')).toBe('https://vuejs.org/v2/guide/class-and-style.html');
            expect(nodes[0].getAttribute('target')).toBe('_blank');
            done();
        });
    });

    it('does not display Bank Account Number link', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="bank-account-number-link"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays ABA Routing Number', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="aba-routing-number"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('12345-6789');
            done();
        });
    });

    it('does not display ABA Routing Number', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="aba-routing-number"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Credit Card Number', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));
        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="credit-card-number-link"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('4013-1111-2222-3333');
            expect(nodes[0].getAttribute('href')).toBe('https://vuejs.org/v2/guide/class-and-style.html#Array-Syntax');
            expect(nodes[0].getAttribute('target')).toBe('_blank');
            done();
        });
    });

    it('does not display Credit Card Number', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="credit-card-number-link"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Credit Card Expiration Date', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="credit-card-expiration"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('10/01/2008');
            done();
        });
    });

    it('does not display Credit Card Expiration Date', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="credit-card-expiration"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Bill Mode', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="bill-mode-code-and-description"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('03 - SEMI ANNUALLY - 180 DAYS');
            done();
        });
    });

    it('does not display Bill Mode', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                billModeCode: null
            }
        }));
        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="bill-mode-code-and-description"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Bill Due Day', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="bill-due-day"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('01');
            done();
        });
    });

    it('does not display Bill Due Day', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                dueDay: null
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="bill-due-day"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Sort', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="bill-sort-code-description"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('SORT BY DEPARTMENTS IN AL');
            done();
        });
    });

    it('does not display Sort', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="bill-sort-code-description"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Suppress Bill', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="suppress-bill"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('NO');
            done();
        });
    });

    it('does not display Suppress Bill', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="suppress-bill"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Bill Format', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="bill-format-code"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('26 - FULL BILL TO ALT STRUCTUR');
            done();
        });
    });

    it('does not display Bill Format', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="bill-format-code"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Create AR', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="create-ar"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('NO');
            done();
        });
    });

    it('does not display Create AR', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="create-ar"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Payment Method', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="payment-method-code-and-description"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('01 - CHECK');
            done();
        });
    });

    it('does not display Payment Method', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }))

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="payment-method-code-and-description"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });

    it('displays Output Type', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: true
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="output-type"]');
            expect(nodes.length).toBe(1);
            expect(nodes[0].innerText).toBe('WEB & PAPER');
            done();
        });
    });

    it('does not display Output Type', done => {
        _createComponent(assigndeep({}, fullMock, {
            billingInformation: {
                groupPolicy: false
            }
        }));

        Vue.nextTick(() => {
            const nodes = component.$el.querySelectorAll('[data-test-ref="output-type"]');
            expect(nodes.length).toBe(0);
            done();
        });
    });
    // end data section
});
