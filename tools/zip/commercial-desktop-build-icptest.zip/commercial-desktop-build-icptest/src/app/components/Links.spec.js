import Vue from 'vue';
import Links from './Links.vue';
import DataStore from './../store/DataStore.js';
import {mockNavLinkCategories as fullMock} from './../store/mock/nav-links/NavLinkCategoriesMock.js';
import {mockNavLinkCategoriesMbr as fullMock2} from './../store/mock/nav-links/NavLinkCategoriesMbrMock.js';
import {mockNavLinkCategoriesMcs as fullMock3} from './../store/mock/nav-links/NavLinkCategoriesMcsMock.js';
describe('Links', () => {
    let linksComponent;

    function _createComponent(model) {
        const Constructor = Vue.extend(Links);
        // set the nav links categories model object into the store
        DataStore.store.state.navLinkCategories = model;
        // build the component and mount it
        linksComponent = new Constructor({
            store: DataStore.store
        }).$mount();
    }

    afterEach(() => {
        if (linksComponent) {
            linksComponent.$destroy();
        }
    });

    it('is named Links', () => {
         expect(Links.name).toEqual('Links');
    });

    it('constructs without errors', () => {
        _createComponent();
    });

    it('when onActivate Called, will set categoryTitle ', done => {
        _createComponent(fullMock);

        linksComponent.onActivate(fullMock.items[0].items[0]).then(() => {
            expect(linksComponent.categoryTitle).toEqual('CLAIMS & BENEFITS');
            expect(linksComponent.navLinks[0].clientCode).toEqual('BCBSSC');
            done();
        });
    });

    it('when onActivate Called on mbr desktop, will set categoryTitle ', done => {
        _createComponent(fullMock2);

        linksComponent.onActivate(fullMock2.items[0]).then(() => {
            expect(linksComponent.categoryTitle).toEqual('AGENT/AGENCY INFORMATION');
            expect(linksComponent.navLinks[0].clientCode).toEqual('X');
            done();
        });
    });

    it('when onActivate Called on mbr desktop, will set categoryTitle for children of branch ', done => {
        _createComponent(fullMock2);

        linksComponent.onActivate(fullMock2.items[1].children[0].children[1]).then(() => {
            expect(linksComponent.categoryTitle).toEqual('UPDATE');
            expect(linksComponent.navLinks[0].clientCode).toEqual('X');
            done();
        });
    });

    it('when onActivate Called on mcs desktop, will set categoryTitle ', done => {
        _createComponent(fullMock3);

        linksComponent.onActivate(fullMock3.items[0]).then(() => {
            expect(linksComponent.categoryTitle).toEqual('DOCUMENTS');
            expect(linksComponent.navLinks[0].clientCode).toEqual('X');
            done();
        });
    });

    it('when onActivate Called on mcs desktop, will set categoryTitle for children of branch ', done => {
        _createComponent(fullMock3);

        linksComponent.onActivate(fullMock3.items[3].children[0]).then(() => {
            expect(linksComponent.categoryTitle).toEqual('AMMS CLAIM SCREENS');
            expect(linksComponent.navLinks[0].clientCode).toEqual('X');
            done();
        });
    });
});
