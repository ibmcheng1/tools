<template>
    <section
        class="app-section-application-controls"
        aria-label="Application Controls">
        <b-card class="app-section-application-controls-header">
            <template slot="header">
                <h1
                    data-test-ref="desktop-app-controls-title">{{ desktopAppControlTitle }}</h1>
                <template v-if="$store.getters.getDesktopName === 'MBR'">
                    <b-nav
                        tabs
                        class="nav-trim mr-auto">
                        <b-nav-item
                            :active="isTabActive('Subscriber')"
                            data-test-ref="subscriber-tab"
                            @click="tabSelected('Subscriber')">Subscriber</b-nav-item>
                        <b-nav-item
                            :active="isTabActive('Group')"
                            data-test-ref="group-tab"
                            @click="tabSelected('Group')">Group</b-nav-item>
                    </b-nav>
                </template>
                <div class="d-inline-block float-right">
                    <b-button
                        v-if="$store.getters.getDesktopName === 'MCS'"
                        :disabled="loadButtonDisabled"
                        data-test-ref="desktop-app-controls-load-button"
                        variant="light"
                        @click="loadFromEmulator">Load</b-button>
                    <call-timer ref="callTimer" />
                </div>
            </template>
            <div class="card-text">
                <div class="clearfix my-3">
                    <div class="float-right">
                        <template
                            v-for="(controlLink, controlLinkIndex) in controlLinks">
                            <b-link
                                :key="controlLink.functionId"
                                :disabled="isDisabled(controlLink.linkDesc)"
                                :data-test-ref="'desktop-app-controls-control-link-' + controlLink.functionId"
                                href="javascript:void(0)"
                                @click="getClick(controlLink.linkDesc)">{{ controlLink.linkDesc }}</b-link>
                            <template v-if="controlLinkIndex < controlLinks.length-1">&nbsp;|&nbsp;</template>
                        </template>
                        <b-dropdown
                            text="Application Controls"
                            variant="outline-inverted"
                            size="sm"
                            class="ml-4">
                            <template v-for="functionNavLink in functionNavLinks">
                                <b-dropdown-item
                                    v-if="linkShouldDisplay(functionNavLink)"
                                    :key="functionNavLink.functionId"
                                    :data-test-ref="'desktop-app-controls-function-nav-link-' + functionNavLink.functionId"
                                    @click="getClick(functionNavLink.linkDesc)">{{ functionNavLink.linkDesc }}</b-dropdown-item>
                            </template>
                        </b-dropdown>
                    </div>
                    <!-- Modal displays when exit control link clicked -->
                    <b-modal
                        ref="exitDesktopModal"
                        title="Are you sure you want to exit Desktop?"
                        body-class="d-none"
                        @ok="exitDesktop()">
                    </b-modal>
                </div>

                <div class="mt-4 mb-3">
                    <phone-controls/>
                    <div class="alert alert-outline alert-inverted alert-trim float-right">{{ state }}</div>
                </div>

            </div>
            <template slot="footer">
                <template v-if="this.$store.getters.getDesktopName === 'MBR' && this.$store.getters.getActiveTabName === 'Group'">
                    <div class="form-inline d-inline-flex">
                        <div class="form-group">
                            <label
                                for="groupId">Group ID</label>
                            <b-form-input
                                id="groupId"
                                v-model.lazy="groupId"
                                data-test-ref="group-id">
                            </b-form-input>
                        </div>
                    </div>
                </template>
                <template v-else>
                    <div class="form-inline d-inline-flex">
                        <div class="form-group">
                            <label
                                for="databaseId">Database ID</label>
                            <b-form-input
                                id="databaseId"
                                v-model.lazy="databaseId"></b-form-input>
                        </div>
                        <div class="form-group">
                            <label
                                for="patientId">Patient ID</label>
                            <b-form-input
                                id="patientId"
                                v-model.lazy="patientId"
                                :value="patientId"
                                class="wc-5">
                            </b-form-input>
                        </div>
                    </div>
                </template>
                <b-nav
                    tabs
                    class="nav-trim ml-auto">
                    <b-nav-item-dropdown
                        :active="activeTab === activeSession"
                        :text="activeSession">
                        <b-dropdown-item @click="onSelectTab('Session 1')">Session 1</b-dropdown-item>
                        <b-dropdown-item @click="onSelectTab('Session 2')">Session 2</b-dropdown-item>
                        <b-dropdown-item @click="onSelectTab('Session 3')">Session 3</b-dropdown-item>
                    </b-nav-item-dropdown>
                    <b-nav-item
                        :active="activeTab == 'Links'"
                        @click="onSelectTab('Links')">
                        Links
                    </b-nav-item>
                    <b-nav-item
                        :active="activeTab == 'Alerts'"
                        class="nav-item-danger"
                        @click="onSelectTab('Alerts')">
                        Alerts
                    </b-nav-item>
                </b-nav>
            </template>
        </b-card>
        <b-tabs
            v-model="tabIndex"
            class="app-section-application-controls-tabs tabs-content-only">
            <b-tab title="Session 1">
                <emulator-session/>
            </b-tab>
            <b-tab title="Session 2">
                <emulator-session/>
            </b-tab>
            <b-tab title="Session 3">
                <emulator-session/>
            </b-tab>
            <b-tab title="Links">
                <links></links>
            </b-tab>
            <b-tab title="Alerts">
                <alerts></alerts>
            </b-tab>
        </b-tabs>
    </section>
</template>

<script>
    import Vue from 'vue';
    import CookieUtil from '../util/CookieUtil.js';
    import StringUtil from '../util/StringUtil.js';

    export default {
        name: 'DesktopApplicationControls',

        data() {
            return {
                activeTab: 'Session 1',
                activeSession: 'Session 1',
                tabIndex: 0,
                localDatabaseId: '',
                localPatientId: '',
                localGroupId: '',
                functionNavLinks: [],
                controlLinks: []
            };
        },
        computed: {
            state() {
                return this.$store.getters.getDesktopState;
            },
            databaseId: {
                // The get and set functions cannot refer to "this" unless non-arrow functions are used
                get: function () { // eslint-disable-line object-shorthand
                    return this.$store.getters.getDatabaseId;
                },
                set: function (value) { // eslint-disable-line object-shorthand
                    this.localDatabaseId = value;
                }
            },
            patientId: {
                // The get and set functions cannot refer to "this" unless non-arrow functions are used
                get: function () { // eslint-disable-line object-shorthand
                    return this.$store.getters.getPatientId;
                },
                set: function (value) { // eslint-disable-line object-shorthand
                    this.localPatientId = value;
                }
            },
            groupId: {
                // The get and set functions cannot refer to "this" unless non-arrow functions are used
                get: function () { // eslint-disable-line object-shorthand
                    return this.$store.getters.getGroupId;
                },
                set: function (value) { // eslint-disable-line object-shorthand
                    this.localGroupId = value;
                }
            },
            // Computed property to determine title text for the Desktop App Controls,
            // based on the current Desktop, i.e. Customer Service, Managed Care, etc.
            desktopAppControlTitle() {
                if (this.$store.getters.getDesktopName === 'CSR') {
                    return 'Customer Service Manager';
                } else if (this.$store.getters.getDesktopName === 'MCS') {
                    return 'Care Manager';
                } else if (this.$store.getters.getDesktopName === 'MBR') {
                    return 'Membership and Billing';
                }
                return 'No title';
            },
            loadButtonDisabled() {
                if (this.databaseId && this.patientId) {
                    return true;
                }
                return false;
            }
        },
        mounted() {
            // load the call center attributes into the data store
            const callCenterName = 'BCBSSCSandbox'; // default to sandbox
            let coverageType = CookieUtil.getDefaultCoverageCookie(document);
            if (!coverageType) {
                coverageType = 'Health';          // default to Health
            }

            // TODO: update the call center name to be the call center name selected
            this.$store.dispatch('retrieveCallCenterAttributes', {callCenterName, coverageType});

            // Emit the <code>loaded</code> event when the application control links and defined links are retrieved, note
            // if a service error occurs a default set of links is returned to allow the desktop to function.
            this.$store.dispatch('retrieveApplicationControlLinks', this.$store.getters.getDesktopName).then((response) => {
                this.populateLinks(response, [{functionType: 'FUNCNAVLINK', collection: this.functionNavLinks},
                                              {functionType: 'CONTROLLINK', collection: this.controlLinks}]);
                this.$emit('loaded');
            });
        },
        methods: {
            /**
             * Changes tab index based on tag name
             */
            onSelectTab(tabName) {
                this.activeTab = tabName;
                if (tabName === 'Session 1') {
                    this.tabIndex = 0;
                } else if (tabName === 'Session 2') {
                    this.tabIndex = 1;
                } else if (tabName === 'Session 3') {
                    this.tabIndex = 2;
                } else if (tabName === 'Links') {
                    this.tabIndex = 3;
                } else if (tabName === 'Alerts') {
                    this.tabIndex = 4;
                }
                if (tabName.indexOf('Session') === 0) {
                    this.activeSession = tabName;
                }
            },

            /**
             * Should angry load the desktop and blow away any research or call mode subscriber currently loaded without end task
             */
            incomingCall() {
                this.clearDesktop();

                // Wait for desktop to re-render after clear.  This is for the case of the same subscriber being loaded for incoming call
                Vue.nextTick().then(() => {
                    // TODO Refactor to use actual CTI data
                    if (this.$store.getters.getDesktopName === 'MBR' && this.$store.getters.getActiveTabName === 'Group') {
                        this.groupId = '123456';
                    } else {
                        this.databaseId = '111111111';
                    }
                    this.loadDesktop('Call Mode');
                });
            },

            /**
             * Sets data to the store and sets the state
             */
            loadDesktop(state) {
                if (this.$store.getters.getDesktopName === 'MCS') {
                    if (StringUtil.isNotBlank(this.localDatabaseId) && StringUtil.isNotBlank(this.localPatientId)) {
                        this.$store.dispatch('setDatabaseId', this.localDatabaseId);
                        this.$store.dispatch('setPatientId', this.localPatientId);
                        this.$store.dispatch('setDesktopState', state);
                    }
                } else if (this.$store.getters.getDesktopName === 'MBR' && this.$store.getters.getActiveTabName === 'Group') {
                    this.$store.dispatch('setGroupId', this.localGroupId);
                    this.$store.dispatch('setDesktopState', state);
                } else if (StringUtil.isNotBlank(this.localDatabaseId)) {
                    this.$store.dispatch('setDatabaseId', this.localDatabaseId);
                    this.$store.dispatch('setDesktopState', state);
                }
            },

            exitDesktop() {
                this.clearDesktop();
                this.$root.$emit('Signing off CTI');
                this.$root.$emit('Signing off Emulator');
            },

            /**
             * Clears the desktop by setting the state to ready and clearing the database id and patient id from the store
             */
            clearDesktop() {
                this.$store.dispatch('setDesktopState', 'Ready');
                this.$store.dispatch('clearDatabaseId');
                this.$store.dispatch('clearPatientId');
                this.$store.dispatch('clearGroupId');
            },

            /**
             * Load links defined in the <code>linkTypesToPopulate</code> parameter from the application control links previously retrieved
             *
             * @param [Array] applicationControlLinks list of all rules link types
             * @param [Array] linkTypesToPopulate contains the link functionType to retrieve and populate in the collection object
             */
            populateLinks(applicationControlLinks, linkTypesToPopulate) {
                if (applicationControlLinks && linkTypesToPopulate) {
                    applicationControlLinks.forEach((item) => {
                        linkTypesToPopulate.forEach((link) => {
                            if (item.functionType === link.functionType) {
                                link.collection.push(item);
                            }
                        });
                    });
                }
            },

            /**
             * Disables based on state and link description
             */
            isDisabled(linkDescription) {
                if (linkDescription === 'New Call' || linkDescription === 'Research' || linkDescription === 'Exit' || linkDescription === 'Workload') {
                    if (this.state === 'Call Mode' || this.state === 'Member Search') {
                        return true;
                    }
                } else if (linkDescription === 'End Task') {
                    if (this.state === 'Ready' || this.state === 'Ending Task') {
                        return true;
                    }
                }

                return false;
            },

            /**
             * Gets the function to call based on link description.  This may be replaced once attached apps are integrated
             */
            getClick(linkDescription) {
                if (linkDescription === 'New Call') {
                    this.loadDesktop('Call Mode');
                } else if (linkDescription === 'Research') {
                    this.loadDesktop('Member Search');
                } else if (linkDescription === 'End Task') {
                    this.clearDesktop();
                } else if (linkDescription === 'Exit') {
                    this.$refs.exitDesktopModal.show();
                } else if (linkDescription === 'Subscriber Search') {
                    this.incomingCall();
                } else if (linkDescription === 'Workload') {
                    this.openWorkloadEmulator();
                    this.$store.dispatch('setDesktopState', 'Member Search');
                }
            },
            /**
             * Gets the function to call based on link description.  This may be replaced once attached apps are integrated
             */
            openWorkloadEmulator() {
                // Eventually open the HTML 5 3270 emulator, for
                // now just place some mock data on the component
                // Placing data on the component from the emulator will
                // probably need to go to the load function later.
                this.localDatabaseId = '123456789';
                this.localPatientId = '001';
            },
            /**
             * Reloads the desktop with data from the emulator
             */
            loadFromEmulator() {
                // TODO: interface with the emulator, check for correct data, then place
                // subscriber ID and patient ID on the component locally
                this.clearDesktop();
                this.loadDesktop('Member Search');
            },
           /**
             * Read the selected tab state from the data store, compare the selected tab in the desktop with the
             * application managers tab information
             * @param name tab name selected
             * @return true if the tab is active
             */
            isTabActive(name) {
                return name === this.$store.getters.getActiveTabName;
            },
           /**
             * User selected the Subscriber or Group Tab
             * Set the datastore active tab selected and fire an event indicating the tab name selected. The datastore value
             * is used to synchronize the desktop tabs presented to the user and the 'real' desktop tabs responsible for
             * switching between Subscriber and Group
             * @param name tab name selected
             */
            tabSelected(name) {
                if (name === 'Subscriber' || name === 'Group') {
                    this.$store.dispatch('setActiveTabName', name);

                    if (name === 'Subscriber') {
                        this.$root.$emit('subscriberSelectionNotification');
                    } else {
                        this.$root.$emit('groupSelectionNotification');
                    }
                }
            },
            /**
             * Determine if a link should be displayed
             */
            linkShouldDisplay(item) {
                let retValue = true;

                // When on the MBR Desktop, links with "SUBSCRIBER" in the comments
                // field should only display when on the Subscriber "tab"
                if (this.$store.getters.getDesktopName === 'MBR' && item.comments === 'SUBSCRIBER' &&
                    this.$store.getters.getActiveTabName !== 'Subscriber') {
                    retValue = false;
                }

                return retValue;
            }
        }
    };
</script>
