<template>
    <b-card
        no-body
        class="app-call-timers">
        <b-card-body>
            <span class="fa fa-clock-o align-middle">
                <span class="sr-only">Call Status</span>
            </span>
            <span class="align-middle">
                <span
                    data-test-ref="call-timer-primary-label">
                    {{ primaryTimerText }}
                </span>
                <span
                    data-test-ref="call-timer-primary-time">
                    {{ formattedPrimaryTime }}
                </span>
                &nbsp;&nbsp;|&nbsp;&nbsp;
                <span
                    :class="flashingClassObject"
                    data-test-ref="call-timer-secondary-label">
                    {{ secondaryTimerText }}
                </span>
                <span
                    :class="flashingClassObject"
                    data-test-ref="call-timer-secondary-time">
                    {{ formattedSecondaryTime }}
                </span>
            </span>
        </b-card-body>
    </b-card>
</template>

<script>
import StringUtil from '../util/StringUtil';

export default {
    name: 'CallTimer',
    data: () => {
        return {
            primaryTimerText: 'Call:',          // default value
            primaryInternalTimer: null,
            primaryTotalTimerSeconds: 0,
            secondaryTimerText: 'On Hold:',     // default value
            secondaryInternalTimer: null,
            secondaryTotalTimerSeconds: 0
        };
    },
    computed: {
        /**
         * A computed property to get the formatted time of the primary timer
         */
        formattedPrimaryTime() {
            return this.formatTime(this.primaryTotalTimerSeconds);
        },
        /**
         * A computed property to get the formatted time of the secondary timer
         */
        formattedSecondaryTime() {
            return this.formatTime(this.secondaryTotalTimerSeconds);
        },
        /**
         * Computed property for determining classes for making the timer flash
         */
        flashingClassObject() {
            return {
                'text-danger-light': this.isThresholdTimeExceeded,
                'animate-flash': this.isThresholdTimeExceeded
            };
        },
        /**
         * determine if the timer has exceeded the threshold limit
         */
        isThresholdTimeExceeded() {
            if (this.secondaryTimerThreshold && this.secondaryTotalTimerSeconds > this.secondaryTimerThreshold) {
                return true;
            }

            return false;
        },
        /**
         * Get the threshold from the store
         */
        secondaryTimerThreshold() {
            if (this.secondaryTimerText === 'On Hold:') {
                return this.$store.getters.getCallCenterAttributes.maxHoldTime;
            } else if (this.secondaryTimerText === 'Wrap-Up:') {
                return this.$store.getters.getCallCenterAttributes.wrapUpTime;
            }

            return null;
        }
    },

    watch: {
        isThresholdTimeExceeded(isOverThreshold) {
            if (isOverThreshold) {
                // only focus the window once
                window.focus();
            }
        }
    },

    created() {
        this.$emit('loaded');

        // Add listeners here for reacting to CTI/Call Events

        /**
         * For testing purposes only, selectively consume a notification event that based on current call timer state
         * will either start or stop call timers
         */
        this.$root.$on('signon-notification', () => {
            if (this.primaryInternalTimer) {
                this.stopPrimaryTimer();
                this.stopSecondaryTimer();
            } else {
                this.startPrimaryTimer();
            }
        });
        /**
         * For testing purposes only, selectively consume a notification event that based on current call timer state
         * will either start or stop hold timers
         */
        this.$root.$on('hold-notification', () => {
            if (this.secondaryInternalTimer) {
                this.stopSecondaryTimer();
            } else {
                this.startSecondaryTimer('On Hold:');
            }
        });
        this.$root.$on('start-call', () => {
            this.startPrimaryTimer();
        });
        this.$root.$on('start-hold', () => {
            this.startSecondaryTimer('On Hold:');
        });
        this.$root.$on('start-wrap-up', () => {
            this.startSecondaryTimer('Wrap-Up:');
        });
        this.$root.$on('start-not-ready', () => {
            this.startSecondaryTimer('Not Ready:');
        });
        this.$root.$on('start-work-mode', () => {
            this.startSecondaryTimer('Work Mode:');
        });
        this.$root.$on('stop-call', () => {
            this.stopPrimaryTimer();
            this.stopSecondaryTimer();
        });
        this.$root.$on(['stop-hold', 'stop-wrap-up', 'stop-not-ready', 'stop-work-mode'], () => {
            this.stopSecondaryTimer();
        });
    },

    /** @lends app.components.CallTimer.prototype */
    methods: {
        /**
         * format the time for display, i.e. HH:MM:SS
         */
        formatTime(timeInSeconds) {
            const hours = Math.floor(timeInSeconds / 3600);
            const minutes = Math.floor((timeInSeconds - (hours * 3600)) / 60);
            const seconds = timeInSeconds - ((hours * 3600) + (minutes * 60));

            return StringUtil.leftPad(hours.toString(), '0', 2) + ':' +
                    StringUtil.leftPad(minutes.toString(), '0', 2) + ':' +
                    StringUtil.leftPad(seconds.toString(), '0', 2);
        },
        /**
         * start the primary timer
         */
        startPrimaryTimer() {
            if (this.primaryInternalTimer) {
                this.stopPrimaryTimer();
            }

            const _this = this;
            this.primaryInternalTimer = setInterval(() => {
                ++_this.primaryTotalTimerSeconds;
            }, 1000);
        },
        /**
         * stop the primary timer
         */
        stopPrimaryTimer() {
            this.primaryInternalTimer = clearInterval(this.primaryInternalTimer);
            this.primaryTotalTimerSeconds = 0;
        },
        /**
         * start the secondary timer
         */
        startSecondaryTimer(labelText) {
            if (this.secondaryInternalTimer !== undefined && this.secondaryInternalTimer !== null) {
                this.stopSecondaryTimer();
            }

            this.secondaryTimerText = labelText;

            const _this = this;
            this.secondaryInternalTimer = setInterval(() => {
                ++_this.secondaryTotalTimerSeconds;
            }, 1000);
        },
        /**
         * stop the secondary timer
         */
        stopSecondaryTimer() {
            this.secondaryInternalTimer = clearInterval(this.secondaryInternalTimer);
            this.secondaryTotalTimerSeconds = 0;
        }
    }
};
</script>
