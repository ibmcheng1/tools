<template>
    <section
        aria-label="Family Summary"
        class="app-section-exceptions-summary">
        <b-card
            v-for="(familyMember, index) in family.familySummary"
            :key="familyMember.memberId"
            role="section"
            class="card-summary-section">
            <template slot="header">
                <span
                    :class="(familyMember.memberId == patientId) ? 'text-success' : null"
                    class="fa fa-user"></span>
                <h2>
                    <span class="sr-only">Member Name:</span>
                    <template
                        v-if="familyMember.name">
                        <div
                            data-test-ref="member-name">
                            {{ familyMember.name.firstName }} {{ familyMember.name.lastName }}
                        </div>
                    </template>
                </h2>
                <span
                    v-if="familyMember.memberId == patientId"
                    class="text-success float-right mr-2">
                    <span class="fa fa-check"></span>
                    Selected
                </span>
                <b-button
                    v-else
                    variant="success"
                    class="float-right"
                    @click="setPatientId(familyMember.memberId)">
                    <span class="fa fa-check"></span>
                    Select
                </b-button>
            </template>
            <b-container
                fluid
                class="p-0">
                <b-row
                    class="row-divider">
                    <b-col cols="8">
                        <dl class="definition-list definition-list-lines">
                            <dt>
                                Date of Birth
                            </dt>
                            <dd data-test-ref="birthdate">
                                {{ familyMember.dateOfBirth | moment }}
                            </dd>
                            <template v-if="familyMember.dependentVerified">
                                <dt>
                                    Verified
                                </dt>
                                <dd data-test-ref="verified-dependent">
                                    {{ familyMember.dependentVerified }}
                                </dd>
                            </template>
                            <template v-if="familyMember.alternateNames && familyMember.alternateNames.length > 0">
                                <dt>
                                    Nickname
                                </dt>
                                <dd data-test-ref="alternate-names">
                                    <template
                                        v-for="(alternateNames, index) in familyMember.alternateNames"
                                    ><template v-if="index > 0">, </template>{{ alternateNames.firstName }}</template>
                                </dd>
                            </template>
                            <dt>
                                Member
                            </dt>
                            <dd data-test-ref="member-id">
                                {{ familyMember.memberId }}
                            </dd>
                            <template v-if="familyMember.name">
                                <dt>
                                    Member Status
                                </dt>
                                <dd data-test-ref="gender-family-status">
                                    {{ familyMember.sexName }} {{ familyMember.relationshipName }}
                                </dd>
                            </template>
                            <template v-if="familyMember.updateByEmployee">
                                <dt>
                                    Status
                                </dt>
                                <dd>
                                    <div data-test-ref="update-employee-status">
                                        <template v-if="familyMember.updateByEmployee == 'MB099'">
                                            Active - Billed
                                        </template>
                                        <template v-else-if="familyMember.updateByEmployee == 'MB098'">
                                            Active - Billed
                                        </template>
                                        <template v-else>
                                            Unknown
                                        </template>
                                    </div>
                                </dd>
                            </template>
                            <template v-if="familyMember.deferrals.length > 0 && findSummaryLink('patient-inquiry')">
                                <dt>
                                    Deferrals
                                </dt>
                                <dd>
                                    <b-link
                                        :href="findSummaryLink('patient-inquiry').transaction"
                                        data-test-ref="family-summary-patient-inquiry"
                                        target="_blank">Member has special deferrals/overrides.</b-link>
                                </dd>
                            </template>
                        </dl>
                    </b-col>
                    <b-col cols="4">
                        <template v-if="findSummaryLink('patient-deduct-oop')">
                            <b-link
                                :href="findSummaryLink('patient-deduct-oop').transaction"
                                :data-test-ref="'family-summary-patient-deduct-oop' + index"
                                target="_blank">Deductible/OOP</b-link><br>
                        </template>
                        <template v-if="findSummaryLink('patient-inquiry')">
                            <b-link
                                :href="findSummaryLink('patient-inquiry').transaction"
                                :data-test-ref="'family-summary-patient-inquiry' + index"
                                target="_blank">Patient Inquiry</b-link><br>
                        </template>
                        <template v-if="findSummaryLink('fep-eligibility')">
                            <b-link
                                :href="findSummaryLink('fep-eligibility').transaction"
                                :data-test-ref="'family-summary-fep-eligibility' + index"
                                target="_blank">Eligibility</b-link><br>
                        </template>
                        <b-link
                            :data-test-ref="'family-summary-member-status-history' + index"
                            href="openMemberStatusHistory()"
                            target="_blank">Member Status History</b-link><br>
                        <b-link
                            :data-test-ref="'family-summary-mobile-notifications' + index"
                            href="openMobileNotifications()"
                            target="_blank">Mobile Notifications</b-link>

                    </b-col>
                </b-row>
            </b-container>
        </b-card>
    </section>
</template>

<script>
import DesktopBaseComponent from './DesktopBaseComponent.vue';

export default {
    name: 'FamilySummary',
    extends: DesktopBaseComponent,
    computed: {
        /**
         * A computed property to get the current database id
         */
        databaseId() {
            return this.$store.getters.getDatabaseId;
        },
        /**
         * A computed property to get the family
         */
        family() {
            return this.$store.getters.getFamily;
        },
        /**
         * A computed property to get the current patient id
         */
        patientId() {
            return this.$store.getters.getPatientId;
        }
    },
    watch: {
        /**
         * When the database id is changed, go get the data.
         */
        databaseId() {
            this.refreshData(true);
        },
        /**
         * When we get a list of family members, set the patient id to the first member returned
         */
        family() {
            if (this.family.familySummary && this.family.familySummary[0] && this.family.familySummary[0].memberId) {
                this.setPatientId(this.family.familySummary[0].memberId);
            }
        }
    },
    /** @lends app.components.SubscriberSummary.prototype */
    methods: {
        /**
         * get the subscriber
         */
        getData() {
            // if the database id is provided, go get the subscriber
            if (this.databaseId) {
                return this.$store.dispatch('retrieveFamily', {memberKeyId: this.databaseId});
            }
            // with no database id, return a promise that immediately resolves
            return Promise.resolve();
        },
        /**
         * clear the subscriber
         */
        clearData() {
            this.setPatientId('');
            // clear out any lingering context in the store
            this.$store.dispatch('clearFamily');
        },
        /**
         * set patient id to the patient id in the row that was clicked
         */
        setPatientId(patientId) {
            this.$store.dispatch('setPatientId', patientId);
        }
    }
};
</script>
