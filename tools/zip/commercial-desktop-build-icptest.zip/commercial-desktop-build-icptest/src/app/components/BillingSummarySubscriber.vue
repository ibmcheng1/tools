<template>
    <section
        class="app-section-billing-summary"
        aria-label="Billing Summary Subscriber">
        <template v-if="billingSummary">
            <template v-if="billingSummary.policyTypeNotFound">
                <b-alert
                    variant="danger"
                    data-test-ref="policy-type-not-found"
                    show>Subscriber was not found on CES.</b-alert>
            </template>
            <template v-else-if="!billingSummary.billingInformationLoaded">
                <!-- no billing info loaded = display nothing -->
            </template>
            <template v-else-if="!billingSummary.billingInformation">
                <b-alert
                    variant="danger"
                    data-test-ref="billing-information-not-found"
                    show>No billing summary data found.</b-alert>
            </template>
            <!-- Display billing summary information -->
            <template v-else>
                <b-container
                    fluid
                    class="p-0">
                    <b-row>
                        <b-col cols="8">
                            <dl class="definition-list definition-list-lines">
                                <dt>
                                    Contract Type
                                </dt>
                                <template v-if="groupPolicy">
                                    <dd data-test-ref="group-policy">GROUP</dd>
                                </template>
                                <template v-else>
                                    <dd data-test-ref="individual-policy">INDIVIDUAL</dd>
                                </template>
                                <template v-if="groupPolicy && billingInformation.billNumber">
                                    <dt>
                                        Bill Number
                                    </dt>
                                    <dd data-test-ref="billing-number">{{ billingInformation.billNumber }}</dd>
                                </template>
                                <template v-if="billingInformation.masterARNumber">
                                    <dt>
                                        Master AR
                                    </dt>
                                    <dd>
                                        <b-link
                                            href="https://vuejs.org/v2/guide/list.html#Replacing-an-Array"
                                            data-test-ref="master-ar-number-link"
                                            target="_blank">{{ billingInformation.masterARNumber }}</b-link>
                                    </dd>
                                </template>
                                <template v-if="groupPolicy && billingInformation.clientNumber">
                                    <dt>
                                        Client Number
                                    </dt>
                                    <dd>
                                        <b-link
                                            href="https://vuejs.org/v2/guide/list.html"
                                            data-test-ref="client-number-link"
                                            target="_blank">{{ billingInformation.clientNumber }}</b-link>
                                    </dd>
                                </template>
                                <template v-if="groupPolicy && billingInformation.paymentSummaryNumber">
                                    <dt>
                                        Payment Summary
                                    </dt>
                                    <dd data-test-ref="payment-number">{{ billingInformation.paymentSummaryNumber }}</dd>
                                </template>
                                <template v-if="billingInformation.dueDate">
                                    <dt>
                                        Due Date
                                    </dt>
                                    <dd data-test-ref="due-date">{{ billingInformation.dueDate | moment }}</dd>
                                </template>
                                <template v-if="groupPolicy && billingInformation.statementCreatedDate">
                                    <dt>
                                        Statement Created
                                    </dt>
                                    <dd data-test-ref="statement-created-date">{{ billingInformation.statementCreatedDate | moment }}</dd>
                                </template>
                                <template v-if="billingInformation.currentBalance">
                                    <dt>
                                        Current Balance
                                    </dt>
                                    <template v-if="individualPolicy">
                                        <dd>
                                            <b-link
                                                href="https://vuejs.org/v2/guide/installation.html"
                                                data-test-ref="individual-policy-current-balance-link"
                                                target="_blank">{{ billingInformation.currentBalance | currency }}</b-link>
                                        </dd>
                                    </template>
                                    <template v-else-if="groupPolicy">
                                        <dd data-test-ref="group-policy-current-balance">{{ billingInformation.currentBalance | currency }}</dd>
                                    </template>
                                </template>
                                <template v-if="individualPolicy && billingInformation.lastPayment">
                                    <dt>
                                        Last Payment
                                    </dt>
                                    <dd data-test-ref="last-payment-amount">{{ billingInformation.lastPayment | currency }}</dd>
                                </template>
                                <template v-if="individualPolicy && billingInformation.lastPaymentReceivedDate">
                                    <dt>
                                        Received Date
                                    </dt>
                                    <dd data-test-ref="last-payment-received-date">{{ billingInformation.lastPaymentReceivedDate | moment }}</dd>
                                </template>
                                <template v-if="individualPolicy && (billingInformation.listBillName || billingInformation.listBillAccountNumber || billingInformation.listBillContactName)">
                                    <template v-if="billingInformation.listBillName">
                                        <dt>
                                            List Bill Name
                                        </dt>
                                        <dd data-test-ref="list-bill-name">{{ billingInformation.listBillName }}</dd>
                                    </template>
                                    <!-- emulator -->
                                    <template v-if="individualPolicy && billingInformation.listBillAccountNumber">
                                        <dt>
                                            List Bill Account Number
                                        </dt>
                                        <dd>
                                            <b-link
                                                href="https://vuejs.org/v2/guide/list.html#v-for-with-v-if"
                                                data-test-ref="list-bill-account-name-link"
                                                target="_blank">{{ billingInformation.listBillAccountNumber }}</b-link>
                                        </dd>
                                    </template>
                                    <template v-if="individualPolicy && billingInformation.listBillContactName">
                                        <dt>
                                            List Bill Contact
                                        </dt>
                                        <dd data-test-ref="list-bill-contact-name">{{ billingInformation.listBillContactName }}</dd>
                                    </template>
                                    <template v-if="individualPolicy && billingSummary.listBillPhoneNumber">
                                        <dt>
                                            List Bill Phone Number
                                        </dt>
                                        <dd data-test-ref="list-bill-phone-number">{{ billingSummary.listBillPhoneNumber }}</dd>
                                    </template>
                                </template>
                                <template v-if="individualPolicy && (billingInformation.bankAccountName || billingInformation.bankAccountNumber || billingInformation.abaRoutingNumber )">
                                    <template v-if="billingInformation.bankAccountName">
                                        <dt>
                                            Bank Name
                                        </dt>
                                        <dd data-test-ref="bank-account-name">{{ billingInformation.bankAccountName }}</dd>
                                    </template>
                                    <!-- emulator -->
                                    <template v-if="individualPolicy && billingInformation.bankAccountNumber">
                                        <dt>
                                            Bank Account Number
                                        </dt>
                                        <dd>
                                            <b-link
                                                href="https://vuejs.org/v2/guide/class-and-style.html"
                                                data-test-ref="bank-account-number-link"
                                                target="_blank">{{ billingInformation.bankAccountNumber }}</b-link>
                                        </dd>
                                    </template>
                                    <template v-if="individualPolicy && billingInformation.abaRoutingNumber">
                                        <dt>
                                            ABA Routing Number
                                        </dt>
                                        <dd data-test-ref="aba-routing-number">{{ billingInformation.abaRoutingNumber }}</dd>
                                    </template>
                                </template>
                                <template v-if="individualPolicy && (billingInformation.creditCardNumber || billingInformation.creditCardExpiration)">
                                    <!-- emulator -->
                                    <template v-if="individualPolicy && billingInformation.creditCardNumber">
                                        <dt>
                                            Credit Card Number
                                        </dt>
                                        <dd>
                                            <b-link
                                                href="https://vuejs.org/v2/guide/class-and-style.html#Array-Syntax"
                                                data-test-ref="credit-card-number-link"
                                                target="_blank">{{ billingInformation.creditCardNumber }}</b-link>
                                        </dd>
                                    </template>
                                    <template v-if="individualPolicy && billingInformation.creditCardExpiration">
                                        <dt>
                                            Expiration Date
                                        </dt>
                                        <dd data-test-ref="credit-card-expiration">{{ billingInformation.creditCardExpiration | moment }}</dd>
                                    </template>
                                </template>
                                <template v-if="(billingInformation.billModeCode && billingInformation.billModeCode.code)">
                                    <dt>
                                        Bill Mode
                                    </dt>
                                    <dd data-test-ref="bill-mode-code-and-description">{{ billingInformation.billModeCode.code }} - {{ billingInformation.billModeCode.description }}</dd>
                                </template>
                                <template v-if="billingInformation.dueDay">
                                    <dt>
                                        Bill Due Day
                                    </dt>
                                    <dd data-test-ref="bill-due-day">{{ billingInformation.dueDay }}</dd>
                                </template>
                                <template v-if="groupPolicy && (billingInformation.sortCode && billingInformation.sortCode.description)">
                                    <dt>
                                        Sort
                                    </dt>
                                    <dd data-test-ref="bill-sort-code-description">{{ billingInformation.sortCode.description }}</dd>
                                </template>
                                <template v-if="groupPolicy && billingInformation.suppressDescription">
                                    <dt>
                                        Suppress Bill
                                    </dt>
                                    <dd data-test-ref="suppress-bill">{{ billingInformation.suppressDescription }}</dd>
                                </template>
                                <template v-if="groupPolicy && (billingInformation.billFormatCode && billingInformation.billFormatCode.code)">
                                    <dt>
                                        Bill Format
                                    </dt>
                                    <dd data-test-ref="bill-format-code">{{ billingInformation.billFormatCode.code }} - {{ billingInformation.billFormatCode.description }}</dd>
                                </template>
                                <template v-if="groupPolicy && billingInformation.accountsRecievableCreationDescription">
                                    <dt>
                                        Create AR
                                    </dt>
                                    <dd data-test-ref="create-ar">{{ billingInformation.accountsRecievableCreationDescription }}</dd>
                                </template>
                                <template v-if="groupPolicy && (billingInformation.paymentMethodCode && billingInformation.paymentMethodCode.code)">
                                    <dt>
                                        Payment Method
                                    </dt>
                                    <dd data-test-ref="payment-method-code-and-description">{{ billingInformation.paymentMethodCode.code }} - {{ billingInformation.paymentMethodCode.description }}</dd>
                                </template>
                                <template v-if="groupPolicy && (billingInformation.outputTypeCode && billingInformation.outputTypeCode.description)">
                                    <dt>
                                        Output Type
                                    </dt>
                                    <dd data-test-ref="output-type">{{ billingInformation.outputTypeCode.description }}</dd>
                                </template>
                            </dl>
                        </b-col>
                        <b-col cols="4">
                            <nav>
                                <!-- dialog -->
                                <template v-if="billingInformation.hasCoveragePeriods">
                                    <b-link
                                        href="http://www.fullstackradio.com/episodes"
                                        data-test-ref="accounts-receivable-link"
                                        target="_blank">Accounts Receivable</b-link><br>
                                </template>
                                <!-- emulator -->
                                <template v-if="individualPolicy && billingInformation.listBillAccountNumber">
                                    <b-link
                                        href="https://news.vuejs.org/"
                                        data-test-ref="active-members-link"
                                        target="_blank">Active Members</b-link><br>
                                </template>
                                <!-- emulator -->
                                <template v-if="individualPolicy && billingInformation.billNumber">

                                    <b-link
                                        href="https://vuejs.org/"
                                        data-test-ref="billing-number-link"
                                        target="_blank">Bill Info History</b-link><br>
                                </template>
                                <!-- dialog -->
                                <template v-if="groupPolicy && billingInformation.delinquencyStatus">
                                    <b-link
                                        href="https://vuejs.org/v2/guide/"
                                        data-test-ref="delinquency-status-link"
                                        target="_blank">Delinquency Status</b-link><br>
                                </template>
                                <!-- dialog -->
                                <template v-if="groupPolicy">
                                    <b-link
                                        href="https://vuejs.org/v2/guide/#Conditionals-and-Loops"
                                        data-test-ref="employee-list-link"
                                        target="_blank">Employee List</b-link><br>
                                </template>
                                <!-- emulator -->
                                <template v-if="individualPolicy">
                                    <b-link
                                        href="https://vuejs.org/v2/guide/#Handling-User-Input"
                                        data-test-ref="one-time-payment-link"
                                        target="_blank">One Time Payment</b-link><br>
                                </template>
                                <!-- emulator -->
                                <template>
                                    <b-link
                                        href="https://vuejs.org/v2/guide/computed.html"
                                        data-test-ref="statement-search-link"
                                        target="_blank">Statement Search</b-link><br>
                                </template>
                            </nav>
                        </b-col>
                    </b-row>
                </b-container>
            </template>
        </template>
        <template v-else>
            &nbsp;
        </template>
    </section>
</template>

<script>

import DesktopBaseComponent from './DesktopBaseComponent.vue';

export default {
    name: 'BillingSummarySubscriber',
    extends: DesktopBaseComponent,
    data: () => {
        return {
            hasSummaryLinks: false
        };
    },
    computed: {
        /**
         * A computed property to determine if there is an error.
         */
        hasError() {
            return this.error;
        },
        /**
         * A computed property to get the current database id
         */
        databaseId() {
            return this.$store.getters.getDatabaseId;
        },
        /**
         * A computed property for billing summary subscriber
         */
        billingSummary() {
            let billingSummary = null;
            if (this.$store.getters.getBillingSummarySubscriber) {
                billingSummary = this.$store.getters.getBillingSummarySubscriber;
            }
            return billingSummary;
        },
        /**
         * A computed property for billing summary subscriber's billingInformation
         */
        billingInformation() {
            let billingInformation = null;
            if (this.$store.getters.getBillingSummarySubscriber.billingInformation) {
                billingInformation = this.$store.getters.getBillingSummarySubscriber.billingInformation;
            }
            return billingInformation;
        },
        /**
         * A computed property for billing summary individual policy
         */
        individualPolicy() {
            let groupPolicy = null;
            if (this.$store.getters.getBillingSummarySubscriber) {
                groupPolicy = this.$store.getters.getBillingSummarySubscriber.billingInformation.groupPolicy;
            }
            return !groupPolicy;
        },
        /**
         * A computed property for billing summary group policy
         */
        groupPolicy() {
            let groupPolicy = null;
            if (this.$store.getters.getBillingSummarySubscriber) {
                groupPolicy = this.$store.getters.getBillingSummarySubscriber.billingInformation.groupPolicy;
            }
            return groupPolicy;
        }
    },
    /** @lends app.components.BillingSummarySubscriber.prototype */
    watch: {
        /**
         * When the database id is changed, go get the data.
         */
        databaseId() {
            this.refreshData(true);
        }
    },
    /** @lends app.components.BillingSummarySubscriber.prototype */
    methods: {
        /**
         * Get Data from the store
         */
        getData() {
            // if the database id is provided, retrieve billing summary information for this subscriber
            if (this.databaseId) {
                return this.$store.dispatch('retrieveBillingSummarySubscriber', {subscriberId: this.databaseId});
            }
            // with no database id, return a promise that immediately resolves
            return Promise.resolve();
        },
        /**
         * Clear data
         */
        clearData() {
            this.$store.dispatch('clearBillingSummarySubscriber');
        }
    }
};
</script>
