<template>
    <section
        class="app-section-patient-summary app-section-padded"
        aria-label="Patient Summary">
        <template v-if="hasPatient">
            <b-container
                fluid
                class="p-0">
                <b-row>
                    <b-col cols="4">
                        <dl class="definition-list definition-list-basic">
                            <dt class="sr-only">Name</dt>
                            <dd
                                v-if="patient.name"
                                data-test-ref="patient-summary-name">
                                {{ patient.name }}
                            </dd>
                            <dt class="sr-only">Address 1</dt>
                            <dd
                                v-if="patient.address1"
                                data-test-ref="patient-summary-address1">
                                {{ patient.address1 }}
                            </dd>
                            <dt class="sr-only">Address 2</dt>
                            <dd
                                v-if="patient.address2"
                                data-test-ref="patient-summary-address2">
                                {{ patient.address2 }}
                            </dd>
                            <dt class="sr-only">City, State Zip</dt>
                            <dd
                                v-if="patient.cityStateZip"
                                data-test-ref="patient-summary-city-state-zip">
                                {{ patient.cityStateZip }}
                            </dd>
                        </dl>
                    </b-col>
                    <b-col cols="8">
                        <h2
                            data-test-ref="patient-summary-gender-relationship">
                            {{ patient.gender }} {{ patient.relationship }}</h2>
                        <dl class="definition-list definition-list-lines">
                            <dt>Date of Birth:</dt>
                            <dd
                                data-test-ref="patient-summary-birthdate">
                                {{ patient.birthdate }}</dd>
                            <dt>Patient ID Number:</dt>
                            <dd
                                data-test-ref="patient-summary-memberId">
                                {{ patient.memberId }}</dd>
                            <template
                                v-if="patient.cesMemberNumber">
                                <dt>CES Member Number:</dt>
                                <dd
                                    data-test-ref="patient-summary-ces-member-number">
                                    {{ patient.cesMemberNumber }}</dd>
                            </template>
                        </dl>
                    </b-col>
                </b-row>
                <b-row>
                    <b-col>
                        <b-link
                            data-test-ref="patient-summary-records-link"
                            target="_blank"
                            href="https://www.southcarolinablues.com/web/public/sc/">
                            View All Medical Records
                        </b-link>
                    </b-col>
                </b-row>
                <b-row>
                    <b-col cols="10">
                        <dl class="definition-list definition-list-basic">
                            <template
                                v-if="patient.primaryCarePhysicianName">
                                <dt>
                                    <b-link
                                        href="openPos4SummaryEmulator()"
                                        data-test-ref="patient-summary-label-link">
                                        PCP:
                                    </b-link>
                                </dt>
                                <dd>
                                    <b-link
                                        href="openProviderSummaryEmulator()"
                                        data-test-ref="patient-summary-pcp-id-name-link">
                                        {{ patient.primaryCarePhysicianId }} - {{ patient.primaryCarePhysicianName }}
                                    </b-link>
                                </dd>
                            </template>
                            <template v-else>
                                <dt
                                    data-test-ref="patient-summary-pcp-label-no-pcp">
                                    PCP:</dt>
                                <dd
                                    data-test-ref="patient-summary-pcp-description-no-pcp">
                                    No PCP Selected</dd>
                            </template>
                        </dl>
                    </b-col>
                    <b-col cols="2">
                        <b-link
                            href="openAlertsEmulator()"
                            data-test-ref="patient-summary-alerts-link"
                            class="float-right">
                            Alerts
                        </b-link>
                    </b-col>
                </b-row>
            </b-container>
        </template>
        <template v-else>
            &nbsp;
        </template>
    </section>
</template>

<script>
import DesktopBaseComponent from './DesktopBaseComponent.vue';

export default {
    name: 'PatientSummary',
    extends: DesktopBaseComponent,
    computed: {
        /**
         * A computed property to get the current database id
         */
        databaseId() {
            return this.$store.getters.getDatabaseId;
        },
        /**
         * A computed property to get the current patient id
         */
        patientId() {
            return this.$store.getters.getPatientId;
        },
        /**
         * A computed property to determine if there is a patient available
         */
        hasPatient() {
            return this.$store.getters.getPatientSummary && this.$store.getters.getPatientSummary.memberId;
        },
        /**
         * A computed property to pull the patient summary information
         */
        patient() {
            if (this.hasPatient) {
                return this.$store.getters.getPatientSummary;
            }
            return null;
        }
    },
    watch: {
        /**
         * When the database id is changed, go get the data.
         */
        databaseId() {
            this.refreshData(true);
        },
        /**
         * When the patient id is changed, go get the data.
         */
        patientId() {
            this.refreshData(true);
        }
    },
    /** @lends app.components.PatientSummary.prototype */
    methods: {
        /**
         * get the patient data
         */
        getData() {
            // if the database id and patient ID are provided, go get the patient
            if (this.databaseId && this.patientId) {
                return this.$store.dispatch('retrievePatientSummary', {memberKeyId: this.databaseId, patientId: this.patientId});
            }
            // with no database id and patient id, return a promise that immediately resolves
            return Promise.resolve();
        },
        /**
         * clear the subscriber
         */
        clearData() {
            // clear out any lingering context in the store
            this.$store.dispatch('clearPatientSummary');
        }
    }
};
</script>
