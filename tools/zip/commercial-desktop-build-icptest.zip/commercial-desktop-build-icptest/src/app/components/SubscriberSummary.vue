<template>
    <section
        class="app-section-subscriber-summary app-section-padded"
        aria-label="Subscriber Summary">
        <template v-if="hasSubscriber">
            <b-container
                fluid
                class="p-0">
                <b-row>
                    <b-col cols="5">
                        <h2
                            v-if="subscriber && subscriber.name && (subscriber.name.firstName || subscriber.name.middleName || subscriber.name.lastName)"
                            data-test-ref="subscriber-name">
                            {{ subscriber.name.firstName }} {{ subscriber.name.middleName | substring(0, 1) }} {{ subscriber.name.lastName }}
                        </h2>
                        <dl class="definition-list definition-list-basic">
                            <template v-if="address">
                                <dt class="sr-only">Address</dt>
                                <dd
                                    v-if="address.address1"
                                    data-test-ref="address-line">
                                    {{ address.address1 }}
                                </dd>
                                <dd
                                    v-if="address.address2"
                                    data-test-ref="address-line">
                                    {{ address.address2 }}
                                </dd>
                                <dd
                                    v-if="(address.city || address.state || address.zip)"
                                    data-test-ref="city-state-zip">
                                    {{ address.city }}, {{ address.state }} {{ address.zipcode }} {{ address.zipcodePostFix }}
                                </dd>
                                <dd
                                    v-if="address.countyCode && (address.countyCode.code || address.countyCode.description)"
                                    data-test-ref="county-code-description">
                                    {{ address.countyCode.code }}
                                    <template v-if="address.countyCode && address.countyCode.description"> - {{ address.countyCode.description }}</template>
                                    <template v-else> - UNKNOWN</template>
                                </dd>
                            </template>
                            <template v-if="subscriber && subscriber.phone && subscriber.phone.prefix">
                                <dt class="sr-only">Phone Number</dt>
                                <dd>
                                    <span data-test-ref="phone-number">({{ subscriber.phone.areaCode }}) {{ subscriber.phone.prefix }}-{{ subscriber.phone.suffix }}</span>
                                    <a
                                        v-b-tooltip.hover.focus
                                        v-if="hasMorePhoneNumbers"
                                        :title="morePhoneNumbers"
                                        href="javascript:void(0)"
                                        data-test-ref="more-phone-numbers">
                                        (see more)
                                    </a>
                                </dd>
                            </template>
                        </dl>
                    </b-col>
                    <b-col cols="7">
                        <dl class="definition-list definition-list-lines">
                            <dt>Service Center</dt>
                            <dd data-test-ref="service-center">
                                <template v-if="subscriber && subscriber.serviceCenter && subscriber.serviceCenter.description">
                                    <!-- TODO - change href to open service center attached app -->
                                    <b-link
                                        href="openServiceCenter()"
                                        class="service-center"
                                        target="_blank">{{ subscriber.serviceCenter.description }}</b-link>
                                </template>
                                <template v-else>
                                    No Information Found
                                </template>
                            </dd>
                        </dl>
                        <template v-if="subscriber && ($store.getters.getDesktopName === 'MCS')">
                            <b-row>
                                <b-col>
                                    <b-button
                                        data-test-ref="subscriber-summary-patient-select-button"
                                        variant="light"
                                        @click="openPatientSelectionApp">Patient selection</b-button>
                                </b-col>
                            </b-row>
                        </template>
                    </b-col>
                </b-row>

                <!-- TODO - MCS Desktop add patient selection here -->
                <!-- TODO - MCS Desktop add carrierInfo in here -->

                <b-row class="row-divider">
                    <b-col cols="8">
                        <dl class="definition-list definition-list-lines">
                            <dt>
                                ID Card Number
                            </dt>
                            <dd data-test-ref="id-card-number">
                                <template v-if="subscriber && subscriber.idCardNumber">
                                    <template v-if="subscriber && subscriber.ces">{{ subscriber.alphaPrefix }}</template>{{ subscriber.idCardNumber }}
                                </template>
                            </dd>
                            <dt>
                                Last ID Card Created
                            </dt>
                            <dd data-test-ref="last-id-card-issue-date">
                                <template v-if="subscriber && subscriber.lastIdCardIssueDate">
                                    {{ subscriber.lastIdCardIssueDate | moment }}
                                </template>
                            </dd>
                            <dt>
                                Date of Birth
                            </dt>
                            <dd data-test-ref="birthdate">
                                <template v-if="subscriber && subscriber.birthdate">
                                    {{ subscriber.birthdate | moment }}
                                </template>
                                <template v-else>UNKNOWN</template>
                            </dd>

                            <!-- TODO - verify with Beth that date of hire (TOTL info) does not need to be in here -->

                            <template v-if="agent.name.lastName && ($store.getters.getDesktopName === 'MBR')">
                                <dt>
                                    Agent Name
                                </dt>
                                <dd data-test-ref="agent-name">
                                    {{ agent.name.firstName }} {{ agent.name.lastName }}
                                </dd>
                            </template>
                            <template v-if="agency.name.lastName && ($store.getters.getDesktopName === 'MBR')">
                                <dt>
                                    Agency Name
                                </dt>
                                <dd data-test-ref="agency-name">
                                    {{ agency.name.lastName }}
                                </dd>
                            </template>
                            <template v-if="agent.id && ($store.getters.getDesktopName === 'MBR')">
                                <dt>
                                    Agent Number
                                </dt>
                                <dd data-test-ref="agent-number">
                                    {{ agent.id }}
                                </dd>
                            </template>
                            <template v-if="agent.phone.areaCode && agent.phone.prefix && agent.phone.suffix && ($store.getters.getDesktopName === 'MBR')">
                                <dt>
                                    Agent Phone
                                </dt>
                                <dd data-test-ref="agent-phone-number">
                                    ({{ agent.phone.areaCode }}) {{ agent.phone.prefix }}-{{ agent.phone.suffix }}
                                </dd>
                            </template>
                            <template v-if="hicnumber && findSummaryLink('medicare-info')">
                                <dt>
                                    Medicare ID
                                </dt>
                                <dd>
                                    <!-- TODO change href to run emulator transaction -->
                                    <b-link
                                        :href="findSummaryLink('medicare-info').transaction"
                                        data-test-ref="medicare-info"
                                        target="_blank">{{ hicnumber }}</b-link>
                                </dd>
                            </template>
                            <template v-if="subscriber.originalEffectiveDate && ($store.getters.getDesktopName === 'MBR')">
                                <dt>
                                    Effective Date
                                </dt>
                                <dd data-test-ref="original-effective-date">
                                    {{ formatDate(subscriber.originalEffectiveDate) }}
                                </dd>
                            </template>
                            <template v-if="subscriber.maintenanceDate && ($store.getters.getDesktopName === 'MBR')">
                                <dt>
                                    Maintenance Date
                                </dt>
                                <dd data-test-ref="maintenance-date">
                                    {{ formatDate(subscriber.maintenanceDate) }}
                                </dd>
                            </template>
                            <template v-if="subscriber.coverage && ($store.getters.getDesktopName === 'MBR')">
                                <dt>
                                    Coverage
                                </dt>
                                <dd data-test-ref="subscriber-coverage">
                                    {{ subscriber.coverage }}
                                </dd>
                            </template>
                            <template v-if="subscriber.fep">
                                <dt>
                                    Subscriber Status
                                </dt>
                                <dd data-test-ref="subscriber-status">
                                    {{ subscriber.employeeStatus }}
                                </dd>
                            </template>

                            <template v-if="accountInformation && accountInformation.accountStatus">
                                <dt>
                                    Payment Option
                                </dt>
                                <dd>
                                    <!-- TODO - make this a link to the HSA application to the payment options window -->
                                    <b-link
                                        href="openPaymentOption()"
                                        data-test-ref="payment-option"
                                        target="_blank">{{ accountInformation.paymentOption }}</b-link>
                                </dd>
                                <dt>
                                    Health Savings Account
                                </dt>
                                <dd>
                                    <!-- TODO - make this a link to the HSA applicaiton -->
                                    <b-link
                                        href="openHSA()"
                                        data-test-ref="account-status"
                                        target="_blank">{{ accountInformation.accountStatus }}</b-link>
                                </dd>
                            </template>
                            <template v-if="subscriber && subscriber.carrierName && ($store.getters.getDesktopName === 'MCS')">
                                <dt data-test-ref="subscriber-summary-carrier-label">Carrier</dt>
                                <dd>
                                    <span data-test-ref="subscriber-summary-carrier">{{ subscriber.carrierName }}</span>
                                    <template v-if="subscriber.carrierRestricted">
                                        <b-col
                                            class="text-danger"
                                            data-test-ref="subscriber-summary-carrier-restricted">
                                            RESTRICTED
                                        </b-col>
                                    </template>
                                </dd>
                            </template>
                        </dl>
                    </b-col>
                    <b-col cols="4">
                        <nav>
                            <template v-if="findSummaryLink('address-history')">
                                <!-- TODO - make sure this link runs the correct emulator transaction -->
                                <b-link
                                    :href="findSummaryLink('address-history').transaction"
                                    data-test-ref="address-history"
                                    target="_blank">Address History</b-link><br>
                            </template>
                            <template v-if="findSummaryLink('application-summary')">
                                <!-- TODO - make sure this link runs the correct emulator transaction -->
                                <b-link
                                    :href="findSummaryLink('application-summary').transaction"
                                    data-test-ref="application-summary"
                                    target="_blank">Application Summary</b-link><br>
                            </template>
                            <template v-if="findSummaryLink('contract-status')">
                                <!-- TODO - make sure this link runs the correct emulator transaction -->
                                <b-link
                                    :href="findSummaryLink('contract-status').transaction"
                                    data-test-ref="contract-status"
                                    target="_blank">Contract Status</b-link><br>
                            </template>
                            <template v-if="subscriber.cesExceptionIndicator && findSummaryLink('ces-exceptions')">
                                <!-- TODO - make sure this link runs the correct emulator transaction -->
                                <b-link
                                    :href="findSummaryLink('ces-exceptions').transaction"
                                    data-test-ref="ces-exceptions"
                                    target="_blank">CES Exceptions</b-link><br>
                            </template>
                            <template v-if="subscriber.relatedInformationIndicator && findSummaryLink('ces-related')">
                                <!-- TODO - make sure this link runs the correct emulator transaction -->
                                <b-link
                                    :href="findSummaryLink('ces-related').transaction"
                                    data-test-ref="ces-related"
                                    target="_blank">CES Related</b-link><br>
                            </template>
                            <template v-if="findSummaryLink('email-addresses')">
                                <!-- TODO - make sure this link runs the correct emulator transaction -->
                                <b-link
                                    :href="findSummaryLink('email-addresses').transaction"
                                    data-test-ref="email-addresses"
                                    target="_blank">E-mail Addresses</b-link><br>
                            </template>
                            <template v-if="findSummaryLink('exceptions-summary')">
                                <!-- TODO - make sure this link runs the correct emulator transaction -->
                                <b-link
                                    :href="findSummaryLink('exceptions-summary').transaction"
                                    data-test-ref="exceptions-summary"
                                    target="_blank">Exceptions</b-link><br>
                            </template>
                            <template v-if="findSummaryLink('hippa-information')">
                                <!-- TODO - make sure this link runs the correct emulator transaction -->
                                <b-link
                                    :href="findSummaryLink('hippa-information').transaction"
                                    data-test-ref="hippa-information"
                                    target="_blank">HIPAA Information</b-link><br>
                            </template>
                            <template v-if="findSummaryLink('image-history')">
                                <!-- TODO - make sure this link runs the correct emulator transaction -->
                                <b-link
                                    :href="findSummaryLink('image-history').transaction"
                                    data-test-ref="image-history"
                                    target="_blank">Image History</b-link><br>
                            </template>
                            <template v-if="findSummaryLink('subscriber-status-history')">
                                <!-- TODO - make sure this link runs the correct emulator transaction -->
                                <b-link
                                    :href="findSummaryLink('subscriber-status-history').transaction"
                                    data-test-ref="subscriber-status-history"
                                    target="_blank">Subscriber Status History</b-link><br>
                            </template>
                        </nav>
                    </b-col>
                </b-row>
            </b-container>
        </template>
        <template v-else>
            &nbsp;
        </template>
    </section>
</template>

<script>
import DesktopBaseComponent from './DesktopBaseComponent.vue';
import StringUtil from '../util/StringUtil';
import FilterUtil from '../util/FilterUtil';

export default {
    name: 'SubscriberSummary',
    extends: DesktopBaseComponent,
    computed: {
        /**
         * A computed property to get the current database id
         */
        databaseId() {
            return this.$store.getters.getDatabaseId;
        },
        /**
         * A computed property to get the subscriber
         */
        subscriber() {
            let subscriber = null;
            if (this.$store.getters.getSubscriber) {
                subscriber = this.$store.getters.getSubscriber.subscriber;
            }
            return subscriber;
        },
        /**
         * A computed property to get the hicNumber (medicare)
         */
        hicnumber() {
            let hic = null;
            if (this.$store.getters.getSubscriber) {
                hic = this.$store.getters.getSubscriber.hicNumber;
            }
            return hic;
        },

        /**
         * A computed property to get the subscriber address
         */
        address() {
            let address = null;
            if (this.$store.getters.getSubscriber && this.$store.getters.getSubscriber.subscriber) {
                address = this.$store.getters.getSubscriber.subscriber.address;
            }
            return address;
        },
        /**
         * A computed property to get the account information
         */
        accountInformation() {
            let accountInformation = null;
            if (this.$store.getters.getSubscriber) {
                accountInformation = this.$store.getters.getSubscriber.financialAccount;
            }
            return accountInformation;
        },
        /**
         * A computed property to determine if there is a subscriber available
         */
        hasSubscriber() {
            return this.$store.getters.getSubscriber && this.$store.getters.getSubscriber.subscriberId;
        },
        /**
         * A computed property to determine if there are extra phone numbers available
         */
        hasMorePhoneNumbers() {
            return StringUtil.isNotBlank(this.morePhoneNumbers);
        },
        /**
         * A computed property to get extra phone numbers to display
         */
        morePhoneNumbers() {
            let morePhoneNumbers = null;
            if (this.$store.getters.getSubscriber) {
                morePhoneNumbers = this.$store.getters.getSubscriber.phoneToolTipString;
            }
            return morePhoneNumbers;
        },
        /**
         * A computed property to get the subscriber agent
         */
        agent() {
            let agent = null;
            if (this.$store.getters.getSubscriber) {
                agent = this.$store.getters.getSubscriber.agent;
            }
            return agent;
        },
        /**
         * A computed property to get the subscriber agency
         */
        agency() {
            let agency = null;
            if (this.$store.getters.getSubscriber) {
                agency = this.$store.getters.getSubscriber.agent.agency;
            }
            return agency;
        }
    },
    watch: {
        /**
         * When the database id is changed, go get the data.
         */
        databaseId() {
            this.refreshData(true);
        }
    },
    /** @lends app.components.SubscriberSummary.prototype */
    methods: {
        /**
         * get the subscriber
         */
        getData() {
            // if the database id is provided, go get the subscriber
            if (this.databaseId) {
                return this.$store.dispatch('retrieveSubscriber', {memberKeyId: this.databaseId});
            }
            // with no database id, return a promise that immediately resolves
            return Promise.resolve();
        },
        /**
         * clear the subscriber
         */
        clearData() {
            // clear out any lingering context in the store
            this.$store.dispatch('clearSubscriber');
        },
        /**
         * open the attached app for patient selection
         */
        openPatientSelectionApp() {
            // TODO: Do what's needed to open up the patient selection attached app
        },
        /**
         * Display the date in MM/dd/yyyy format
         */
        formatDate(date) {
            return FilterUtil.formatDate(date);
        }
    }
};
</script>
