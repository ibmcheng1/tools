import Vue from 'vue';
import DesktopApplicationControls from './DesktopApplicationControls.vue';
import DataStore from './../store/DataStore.js';

import {mockApplicationControlLinksCsr} from './../store/mock/application-control-links/ApplicationControlLinksMockCSR.js';
import {mockApplicationControlLinksMcs} from './../store/mock/application-control-links/ApplicationControlLinksMockMCS.js';
import {mockApplicationControlLinksMbr} from './../store/mock/application-control-links/ApplicationControlLinksMockMBR.js';

describe('DesktopApplicationControls', () => {
    let component;

    function _createComponent(mount, state) {
        const Constructor = Vue.extend(DesktopApplicationControls);

        if (state) {
            DataStore.store.state.desktopState = state;
        }

        // build the component and mount it
        component = new Constructor({
            store: DataStore.store
        });

        if (mount) {
            component.$mount();
        }
    }

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('has a method onSelectTab defined', () => {
        expect(typeof DesktopApplicationControls.methods.onSelectTab).toBe('function');
    });

    it('has a method loadDesktop defined', () => {
        expect(typeof DesktopApplicationControls.methods.loadDesktop).toBe('function');
    });

    it('has a method clearData defined', () => {
        expect(typeof DesktopApplicationControls.methods.clearDesktop).toBe('function');
    });

    it('has a method populateLinks defined', () => {
        expect(typeof DesktopApplicationControls.methods.populateLinks).toBe('function');
    });

    it('when desktop is cleared databaseId and patientId are empty', () => {
        _createComponent(true);

        component.$store.dispatch('setDatabaseId', 'TEST');
        component.$store.dispatch('setPatientId', 'TEST');

        component.clearDesktop();

        expect(component.$store.getters.getDatabaseId).toEqual('');
        expect(component.$store.getters.getPatientId).toEqual('');
    });

    it('when desktop is researched, databaseId is populated in the store and the state is in Member Search', () => {
        _createComponent();

        component.databaseId = 'test';
        component.loadDesktop('Member Search');

        expect(component.$store.getters.getDatabaseId).toEqual('test');
        expect(component.state).toEqual('Member Search');
    });

    it('when desktop is call mode, databaseId is populated in the store and the state is in Call Mode', () => {
        _createComponent();

        component.databaseId = 'test';
        component.loadDesktop('Call Mode');

        expect(component.$store.getters.getDatabaseId).toEqual('test');
        expect(component.state).toEqual('Call Mode');
    });

    it('when desktop is receiving an incoming call, current subscriber is blown away and databaseId and patientId are populated in the store and the state is in Call Mode', (done) => {
        _createComponent();

        component.databaseId = 'test';
        component.loadDesktop('Member Search');

        expect(component.$store.getters.getDatabaseId).toEqual('test');
        expect(component.state).toEqual('Member Search');

        component.incomingCall();

        Vue.nextTick().then(() => {
            expect(component.$store.getters.getDatabaseId).toEqual('111111111');
            expect(component.state).toEqual('Call Mode');
            done();
        });
    });

    it('when desktop is initially loaded, callCenterAttributes are retrieved', (done) => {
        _createComponent(false);
        const dispatchSpy = spyOn(component.$store, 'dispatch').and.callThrough();
        const callCenterName = 'BCBSSCSandbox';
        const coverageType = 'Health';

        component.$on('loaded', () => {
            expect(dispatchSpy).toHaveBeenCalledWith('retrieveCallCenterAttributes', {callCenterName, coverageType});
            done();
        });

        component.$mount();
    });

    it('when Session 1 is selected, the tab index is = 0', () => {
        _createComponent(true);
        component.onSelectTab('Session 1');
        expect(component.tabIndex).toEqual(0);
    });

    it('when Session 2 is selected, the tab index is = 1', () => {
        _createComponent(true);
        component.onSelectTab('Session 2');
        expect(component.tabIndex).toEqual(1);
    });

    it('when Session 3 is selected, the tab index is = 2', () => {
        _createComponent(true);
        component.onSelectTab('Session 3');
        expect(component.tabIndex).toEqual(2);
    });

    it('when Links is selected, the tab index is = 3', () => {
        _createComponent(true);
        component.onSelectTab('Links');
        expect(component.tabIndex).toEqual(3);
    });

    it('when Alerts is selected, the tab index is = 4', () => {
        _createComponent(true);
        component.onSelectTab('Alerts');
        expect(component.tabIndex).toEqual(4);
    });

    it('when confirmed to exit desktop, a CTI sign off event is emitted', (done) => {
        _createComponent(true);

        component.$root.$on('Signing off CTI', () => {
            done();
        });

        component.exitDesktop();
    });

    it('when confirmed to exit desktop, an emulator sign off event is emitted', (done) => {
        _createComponent(true);

        component.$root.$on('Signing off Emulator', () => {
            done();
        });

        component.exitDesktop();
    });

    it('when patient id is set, set the local patient id', () => {
        _createComponent();
        component.patientId = 'test';
        expect(component.localPatientId).toEqual('test');
    });

    it('should populate defined links from the CSR mock', () => {
        _createComponent(true);
        const functionNavLinks = [];
        const controlLinks = [];
        component.populateLinks(mockApplicationControlLinksCsr, [{functionType: 'FUNCNAVLINK', collection: functionNavLinks},
                                                                {functionType: 'CONTROLLINK', collection: controlLinks}]);

        expect(functionNavLinks.length).toBe(7);
        expect(controlLinks.length).toBe(4);
    });

    it('should populate defined links from the MCS mock', () => {
        _createComponent(true);
        const functionNavLinks = [];
        const controlLinks = [];
        component.populateLinks(mockApplicationControlLinksMcs, [{functionType: 'FUNCNAVLINK', collection: functionNavLinks},
                                                                {functionType: 'CONTROLLINK', collection: controlLinks}]);

        expect(functionNavLinks.length).toBe(9);
        expect(controlLinks.length).toBe(5);
    });

    it('when on CSR Desktop, title text should display correctly', done => {
        _createComponent(true);
        component.$store.dispatch('setDesktopName', 'CSR');

        Vue.nextTick(() => {
            const appControlsTitles = component.$el.querySelectorAll('[data-test-ref="desktop-app-controls-title"]');
            expect(appControlsTitles[0].innerText).toBe('Customer Service Manager');
            expect(component.desktopAppControlTitle).toBe('Customer Service Manager');
            done();
        });
    });

    it('when on MCS Desktop, title text should display correctly', done => {
        _createComponent(true);
        component.$store.dispatch('setDesktopName', 'MCS');

        Vue.nextTick(() => {
            const appControlsTitles = component.$el.querySelectorAll('[data-test-ref="desktop-app-controls-title"]');
            expect(appControlsTitles[0].innerText).toBe('Care Manager');
            expect(component.desktopAppControlTitle).toBe('Care Manager');
            done();
        });
    });

    it('isDisabled should return true when new call and call mode', () => {
        _createComponent(false, 'Call Mode');

        expect(component.isDisabled('New Call')).toBeTruthy();
    });

    it('isDisabled should return true when new call and member search', () => {
        _createComponent(false, 'Member Search');

        expect(component.isDisabled('New Call')).toBeTruthy();
    });

    it('isDisabled should return true when research call mode', () => {
        _createComponent(false, 'Call Mode');

        expect(component.isDisabled('Research')).toBeTruthy();
    });

    it('isDisabled should return true when research member search', () => {
        _createComponent(false, 'Member Search');

        expect(component.isDisabled('Research')).toBeTruthy();
    });

    it('isDisabled should return true when end task ready', () => {
        _createComponent(false, 'Ready');

        expect(component.isDisabled('End Task')).toBeTruthy();
    });

    it('isDisabled should return true when end task Ending Task', () => {
        _createComponent(false, 'Ending Task');

        expect(component.isDisabled('End Task')).toBeTruthy();
    });

    it('isDisabled should return false when new call ready', () => {
        _createComponent(false, 'Ready');

        expect(component.isDisabled('New Call')).toBeFalsy();
    });

    it('isDisabled should return false when research ready', () => {
        _createComponent(false, 'Ready');

        expect(component.isDisabled('Research')).toBeFalsy();
    });

    it('isDisabled should return false when end task call mode', () => {
        _createComponent(false, 'Call Mode');

        expect(component.isDisabled('End Task')).toBeFalsy();
    });

    it('isDisabled should return false when unknown call mode', () => {
        _createComponent(false, 'Call Mode');

        expect(component.isDisabled('asddfgghk')).toBeFalsy();
    });

    it('new call click should load desktop with call mode', () => {
        _createComponent(false);

        const spy = spyOn(component, 'loadDesktop');
        component.getClick('New Call');

        expect(spy).toHaveBeenCalledWith('Call Mode');
    });

    it('research click should load desktop with member search', () => {
        _createComponent(false);

        const spy = spyOn(component, 'loadDesktop');
        component.getClick('Research');

        expect(spy).toHaveBeenCalledWith('Member Search');
    });

    it('end task should clear desktop', () => {
        _createComponent(false);

        const spy = spyOn(component, 'clearDesktop');
        component.getClick('End Task');

        expect(spy).toHaveBeenCalled();
    });

    it('clicking exit should call the show function', () => {
        _createComponent();

        component.$mount();

        const spy = spyOn(component.$refs.exitDesktopModal, 'show');
        component.getClick('Exit');
        expect(spy).toHaveBeenCalled();
    });

    it('subscriber search should incoming call', () => {
        _createComponent(false);

        const spy = spyOn(component, 'incomingCall');
        component.getClick('Subscriber Search');

        expect(spy).toHaveBeenCalled();
    });

    it('random clicks should do nothing', () => {
        _createComponent(false);

        component.getClick('asd');
    });

    it('on MCS Desktop, patient ID and subscriber ID are set, load desktop', () => {
        _createComponent(true);
        component.$store.dispatch('setDesktopName', 'MCS');
        const dispatchSpy = spyOn(component.$store, 'dispatch').and.callThrough();
        component.localDatabaseId = '123456789';
        component.localPatientId = '001';

        component.loadDesktop('Call Mode');

        expect(dispatchSpy).toHaveBeenCalledWith('setDatabaseId', '123456789');
        expect(dispatchSpy).toHaveBeenCalledWith('setPatientId', '001');
        expect(dispatchSpy).toHaveBeenCalledWith('setDesktopState', 'Call Mode');
    });

    it('on MCS Desktop, subscriber ID is set, patient ID is not set, do NOT load desktop', () => {
        _createComponent(true);
        component.$store.dispatch('setDesktopName', 'MCS');
        const dispatchSpy = spyOn(component.$store, 'dispatch').and.callThrough();
        component.localDatabaseId = '123456789';

        component.loadDesktop('Call Mode');

        expect(dispatchSpy).not.toHaveBeenCalledWith('setDatabaseId', '123456789');
        expect(dispatchSpy).not.toHaveBeenCalledWith('setPatientId', '001');
        expect(dispatchSpy).not.toHaveBeenCalledWith('setDesktopState', 'Call Mode');
    });

    it('on CSR Desktop, subscriber ID is set, patient ID is not set, load desktop', () => {
        _createComponent(true);
        component.$store.dispatch('setDesktopName', 'CSR');
        const dispatchSpy = spyOn(component.$store, 'dispatch').and.callThrough();
        component.localDatabaseId = '123456789';

        component.loadDesktop('Call Mode');

        expect(dispatchSpy).toHaveBeenCalledWith('setDatabaseId', '123456789');
        expect(dispatchSpy).toHaveBeenCalledWith('setDesktopState', 'Call Mode');
    });

    it('on CSR Desktop, subscriber ID and patient ID are not set, do NOT load desktop', () => {
        _createComponent(true);
        component.$store.dispatch('setDesktopName', 'CSR');
        const dispatchSpy = spyOn(component.$store, 'dispatch').and.callThrough();

        component.loadDesktop('Call Mode');

        expect(dispatchSpy).not.toHaveBeenCalledWith('setDatabaseId', '123456789');
        expect(dispatchSpy).not.toHaveBeenCalledWith('setDesktopState', 'Call Mode');
    });

    it('For MCS desktop, workload link should open emulator', () => {
        _createComponent(true);
        component.$store.dispatch('setDesktopName', 'MCS');
        const dispatchSpy = spyOn(component.$store, 'dispatch').and.callThrough();
        const spy = spyOn(component, 'openWorkloadEmulator').and.callThrough();

        component.getClick('Workload');

        expect(spy).toHaveBeenCalled();
        expect(component.localDatabaseId).toBe('123456789');
        expect(component.localPatientId).toBe('001');
        expect(dispatchSpy).toHaveBeenCalledWith('setDesktopState', 'Member Search');
    });

    it('For MCS desktop, the load button should reload the desktop from the local subscriber and patient ID', (done) => {
        _createComponent(true);

        component.$store.dispatch('setDesktopName', 'MCS');
        component.databaseId = '112233445';
        component.patientId = '001';

        component.loadFromEmulator();

        Vue.nextTick().then(() => {
            expect(component.$store.getters.getDatabaseId).toEqual('112233445');
            expect(component.$store.getters.getPatientId).toEqual('001');
            expect(component.state).toEqual('Member Search');
            done();
        });
    });

    it('should populate defined links from the MBR mock', () => {
        _createComponent(true);
        const functionNavLinks = [];
        const controlLinks = [];
        component.populateLinks(mockApplicationControlLinksMbr, [{functionType: 'FUNCNAVLINK', collection: functionNavLinks},
                                                                {functionType: 'CONTROLLINK', collection: controlLinks}]);

        expect(functionNavLinks.length).toBe(7);
        expect(controlLinks.length).toBe(4);
    });

    it('when on MBR Desktop, title text should display correctly', done => {
        _createComponent(true);
        component.$store.dispatch('setDesktopName', 'MBR');

        Vue.nextTick(() => {
            const appControlsTitles = component.$el.querySelectorAll('[data-test-ref="desktop-app-controls-title"]');
            expect(appControlsTitles[0].innerText).toBe('Membership and Billing');
            expect(component.desktopAppControlTitle).toBe('Membership and Billing');
            done();
        });
    });

    it('for MBR, Subscriber tab, Claims and Health Management links should display', done => {
        _createComponent(false);

        component.$on('loaded', () => {
            Vue.nextTick(() => {
                const claimsFuncNavLinks = component.$el.querySelectorAll('[data-test-ref="desktop-app-controls-function-nav-link-L00665"]');
                const healthMgmtFuncNavLinks = component.$el.querySelectorAll('[data-test-ref="desktop-app-controls-function-nav-link-L00662"]');
                expect(claimsFuncNavLinks[0].innerText).toBe('Claims');
                expect(healthMgmtFuncNavLinks[0].innerText).toBe('Health Management');
                done();
            });
        });

        component.$store.dispatch('setDesktopName', 'MBR');
        component.$store.dispatch('setActiveTabName', 'Subscriber');
        component.$mount();
    });

    it('for MBR, Group tab, Claims and Health Management links should NOT display', done => {
        _createComponent(false);

        component.$on('loaded', () => {
            Vue.nextTick(() => {
                const claimsFuncNavLinks = component.$el.querySelectorAll('[data-test-ref="desktop-app-controls-function-nav-link-L00665"]');
                const healthMgmtFuncNavLinks = component.$el.querySelectorAll('[data-test-ref="desktop-app-controls-function-nav-link-L00662"]');
                expect(claimsFuncNavLinks.length).toBe(0);
                expect(healthMgmtFuncNavLinks.length).toBe(0);
                done();
            });
        });

        component.$store.dispatch('setDesktopName', 'MBR');
        component.$store.dispatch('setActiveTabName', 'Group');
        component.$mount();
    });

    it('when desktop is cleared groupId is empty', done => {
        _createComponent(true);

        component.$store.dispatch('setGroupId', 'TEST');
        component.clearDesktop();

        Vue.nextTick(() => {
            expect(component.$store.getters.getGroupId).toEqual('');
            done();
        });
    });

    it('when MBR Group view is selected the group id field is shown', done => {
        _createComponent(true);

        component.$store.dispatch('setDesktopName', 'MBR');
        component.$store.dispatch('setActiveTabName', 'Group');

        Vue.nextTick(() => {
            const groupIdNodes = component.$el.querySelectorAll('[data-test-ref="group-id"]');
            expect(groupIdNodes.length).toBe(1);
            done();
        });
    });

    it('when MBR Subscriber view is selected the group id field is not shown', done => {
        _createComponent(true);

        component.$store.dispatch('setDesktopName', 'MBR');
        component.$store.dispatch('setActiveTabName', 'Subscriber');

        Vue.nextTick(() => {
            const groupIdNodes = component.$el.querySelectorAll('[data-test-ref="group-id"]');
            expect(groupIdNodes.length).toBe(0);
            done();
        });
    });

    it('when MBR desktop in Group view receives an incoming call, current groupId is set to incoming call value and the desktop state is Call Mode', (done) => {
        _createComponent(true);

        component.$store.dispatch('setDesktopName', 'MBR');
        component.$store.dispatch('setActiveTabName', 'Group');
        component.groupId = 'test';

        component.loadDesktop('Member Search');

        expect(component.$store.getters.getGroupId).toEqual('test');
        expect(component.state).toEqual('Member Search');

        component.incomingCall();

        Vue.nextTick().then(() => {
            expect(component.$store.getters.getGroupId).toEqual('123456');
            expect(component.state).toEqual('Call Mode');
            done();
        });
    });

    it('when MBR Subscriber view is selected, the active tab name changes and the notification event is fired', done => {
        _createComponent(true);

        component.$root.$on('subscriberSelectionNotification', () => {
            Vue.nextTick(() => {
                expect(component.$store.getters.getActiveTabName).toBe('Subscriber');
                done();
            });
        });

        component.tabSelected('Subscriber');
    });

    it('when MBR Group view is selected, the active tab name changes and the notification event is fired', done => {
        _createComponent(true);

        component.$root.$on('groupSelectionNotification', () => {
            Vue.nextTick(() => {
                expect(component.$store.getters.getActiveTabName).toBe('Group');
                done();
            });
        });

        component.tabSelected('Group');
    });

    it('when MBR view other than subscriber or group is selected, the active tab name should not change', () => {
        _createComponent(true);

        const prevActiveTabName = component.$store.getters.getActiveTabName;

        component.tabSelected('foobar');
        expect(component.$store.getters.getActiveTabName).toBe(prevActiveTabName);
    });
});
