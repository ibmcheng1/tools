import Vue from 'vue';
import FamilySummary from './FamilySummary.vue';
import DesktopBaseComponent from './DesktopBaseComponent.vue';
import DataStore from './../store/DataStore.js';
import {mockFamily as fullMock} from './../store/mock/family-summary/FamilyMock.js';
import {mockFamilySummaryLinks as summaryLinksMock} from './../store/mock/family-summary/FamilySummaryLinksMock.js';

// import assigndeep from 'assign-deep';

describe('FamilySummary', () => {
    let component;

    function _createComponent(model, summaryLinkModel) {
        const Constructor = Vue.extend(FamilySummary);

        // set the contract model object into the store
        DataStore.store.state.family = model;

        // build the component and mount it
        component = new Constructor({
            store: DataStore.store
        }).$mount();

        if (summaryLinkModel) {
            component.summaryLinks = summaryLinkModel;
        } else {
            component.summaryLinks = summaryLinksMock;
        }
    }

    beforeEach(() => {
        // prevent the component from trying to load contracts or summary links
        spyOn(DesktopBaseComponent, 'mounted').and.returnValue(1);
        spyOn(DesktopBaseComponent.methods, 'cacheSummaryLinks').and.returnValue(1);
    });

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('has a method getData hook providing this components specific behavior when loading its data', () => {
        expect(typeof FamilySummary.methods.getData).toBe('function');
    });

    it('has a method clearData hook it providing this components specific behavior when clearing its data', () => {
        expect(typeof FamilySummary.methods.clearData).toBe('function');
    });

    it('ensure getData returns a promise', done => {
        _createComponent([]);

        component.getData().then(() => {
            done();
        });
    });

    it('ensure cleardata clears the family in the store', () => {
        _createComponent(fullMock);

        const spy = spyOn(component.$store, 'dispatch').and.returnValue(1);
        component.clearData();

        expect(spy).toHaveBeenCalledWith('clearFamily');
    });

    it('ensure refreshData is called when databaseId is updated', done => {
        _createComponent(fullMock);

        const refreshDataSpy = spyOn(component, 'refreshData').and.returnValue(1);

        component.$store.dispatch('setDatabaseId', '56');

        Vue.nextTick(() => {
            expect(refreshDataSpy).toHaveBeenCalled();
            done();
        });
    });

    it('has displayed name', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const name = component.$el.querySelectorAll('[data-test-ref="member-name"]');
            expect(name.length).toEqual(3);
            expect(name[0].innerText.trim()).toBe('MICHAEL TESTING');
            done();
        });
    });

    it('displays correct michael testing birthdate', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const birthdate = component.$el.querySelectorAll('[data-test-ref="birthdate"]');
            expect(birthdate[0].innerText.trim()).toBe('10/01/1958');
            done();
        });
    });

    it('dependent is verified', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const dependent = component.$el.querySelectorAll('[data-test-ref="verified-dependent"]');
            expect(dependent.length).toEqual(3);
            expect(dependent[0].innerText.trim()).toBe('VERIFIED NON-STATE');
            done();
        });
    });

    it('alternate names display', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const alternate = component.$el.querySelectorAll('[data-test-ref="alternate-names"]');
            expect(alternate[0].innerText).toBe('Mr. testing, Mr. test data');
            done();
        });
    });

    it('has gender and family status', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const genderFamily = component.$el.querySelectorAll('[data-test-ref="gender-family-status"]');
            expect(genderFamily.length).toEqual(3);
            expect(genderFamily[0].innerText.trim()).toBe('MALE SUBSCRIBER');
            done();
        });
    });

    it('displays Patient Inquiry for first family member when Family summary links is available', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const patientInquiry = component.$el.querySelectorAll('[data-test-ref="family-summary-patient-inquiry0"]');
            expect(patientInquiry.length).toEqual(1);
            expect(patientInquiry[0].href).toBe('http://google.com/');
            done();
        });
    });

    it('displays Patient Inquiry for second family member when summary links is available', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const patientInquiry = component.$el.querySelectorAll('[data-test-ref="family-summary-patient-inquiry1"]');
            expect(patientInquiry.length).toEqual(1);
            expect(patientInquiry[0].href).toBe('http://google.com/');
            done();
        });
    });

    it('displays Patient Inquiry for third family member when summary links is available', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const patientInquiry = component.$el.querySelectorAll('[data-test-ref="family-summary-patient-inquiry2"]');
            expect(patientInquiry.length).toEqual(1);
            expect(patientInquiry[0].href).toBe('http://google.com/');
            done();
        });
    });

    it('displays Patient Deduct OOP for first family member when summary link is available', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const patientDeduct = component.$el.querySelectorAll('[data-test-ref="family-summary-patient-deduct-oop0"]');
            expect(patientDeduct.length).toEqual(1);
            expect(patientDeduct[0].href).toBe('http://lmgtfy.com/');
            done();
        });
    });

    it('displays Patient Deduct OOP for second family member when summary link is available', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const patientDeduct = component.$el.querySelectorAll('[data-test-ref="family-summary-patient-deduct-oop1"]');
            expect(patientDeduct.length).toEqual(1);
            expect(patientDeduct[0].href).toBe('http://lmgtfy.com/');
            done();
        });
    });

    it('displays Patient Deduct OOP for third family member when summary link is available', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const patientDeduct = component.$el.querySelectorAll('[data-test-ref="family-summary-patient-deduct-oop2"]');
            expect(patientDeduct.length).toEqual(1);
            expect(patientDeduct[0].href).toBe('http://lmgtfy.com/');
            done();
        });
    });

    it('displays FEP Eligibility for first family member when summary link is available', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const fepEligibility = component.$el.querySelectorAll('[data-test-ref="family-summary-fep-eligibility0"]');
            expect(fepEligibility.length).toEqual(1);
            expect(fepEligibility[0].href).toBe('http://duckduckgo.com/');
            done();
        });
    });

    it('displays FEP Eligibility for second Family member when summary link is available', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const fepEligibility = component.$el.querySelectorAll('[data-test-ref="family-summary-fep-eligibility1"]');
            expect(fepEligibility.length).toEqual(1);
            expect(fepEligibility[0].href).toBe('http://duckduckgo.com/');
            done();
        });
    });

    it('displays FEP Eligibility for third family member when summary link is available', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const fepEligibility = component.$el.querySelectorAll('[data-test-ref="family-summary-fep-eligibility2"]');
            expect(fepEligibility.length).toEqual(1);
            expect(fepEligibility[0].href).toBe('http://duckduckgo.com/');
            done();
        });
    });

    it('when user clicks row patient id is set', () => {
        _createComponent(fullMock);

        // patient id will be set to TEST
        component.setPatientId('TEST');
        expect(component.$store.getters.getPatientId).toEqual('TEST');
    });
});
