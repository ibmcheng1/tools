import Vue from 'vue';
import ActivitySummary from './ActivitySummary.vue';
import DesktopBaseComponent from './DesktopBaseComponent.vue';
import DataStore from './../store/DataStore.js';
import {mockActivitySummary as fullMock} from './../store/mock/activity-summary/ActivitySummaryMock.js';
import {mockActivitySummaryPageTwo as fullMock2} from './../store/mock/activity-summary/ActivitySummaryPageTwoMock.js';
import assigndeep from 'assign-deep';

describe('ActivitySummary', () => {
    let component;

    function _createComponent(model) {
        const Constructor = Vue.extend(ActivitySummary);

        // set the activity summary model object into the store
        DataStore.store.state.activitySummary = model;

        // build the component and mount it
        component = new Constructor({
            store: DataStore.store
        }).$mount();
    }

    beforeEach(() => {
        // prevent the component from trying to load a subscriber or summary links
        spyOn(DesktopBaseComponent.methods, 'refreshData').and.returnValue(1);
    });

    afterEach(() => {
        if (component) {
            component.$store.dispatch('clearDatabaseId');
            component.$store.dispatch('clearPatientId');
            component.$destroy();
        }
    });

    it('has a computed databaseId hook', () => {
        expect(typeof ActivitySummary.computed.databaseId).toBe('function');
    });

    it('has a computed patientId hook', () => {
        expect(typeof ActivitySummary.computed.patientId).toBe('function');
    });

    it('has a computed hasActivity hook', () => {
        expect(typeof ActivitySummary.computed.hasActivity).toBe('function');
    });

    it('has a computed activity hook', () => {
        expect(typeof ActivitySummary.computed.activity).toBe('function');
    });

    it('has a computed underCaseManagement hook', () => {
        expect(typeof ActivitySummary.computed.underCaseManagement).toBe('function');
    });

    // Begin Vue Component Tests
    it('case management, without medical management links, under case management', done => {
        _createComponent(assigndeep({}, fullMock, {
            showMedicalManagementLinks: false,
            underCaseManagement: true
        }));

        Vue.nextTick(() => {
            const label = component.$el.querySelectorAll('[data-test-ref="activity-summary-case-mgmt-label"]')[0];
            const data = component.$el.querySelectorAll('[data-test-ref="activity-summary-case-mgmt-data"]')[0];
            expect(label.innerText.trim()).toBe('Case Management:');
            expect(data.innerText.trim()).toBe('YES');
            done();
        });
    });

    it('case management, without medical management links, not under case management', done => {
        _createComponent(assigndeep({}, fullMock, {
            showMedicalManagementLinks: false,
            underCaseManagement: false
        }));

        Vue.nextTick(() => {
            const label = component.$el.querySelectorAll('[data-test-ref="activity-summary-case-mgmt-label"]')[0];
            const data = component.$el.querySelectorAll('[data-test-ref="activity-summary-case-mgmt-data"]')[0];
            expect(label.innerText.trim()).toBe('Case Management:');
            expect(data.innerText.trim()).toBe('NO');
            done();
        });
    });

    it('case management, with medical management links, under case management', done => {
        _createComponent(assigndeep({}, fullMock, {
            showMedicalManagementLinks: true,
            underCaseManagement: true
        }));

        Vue.nextTick(() => {
            const label = component.$el.querySelectorAll('[data-test-ref="activity-summary-behavioral-case-mgmt-label"]')[0];
            const data = component.$el.querySelectorAll('[data-test-ref="activity-summary-behavioral-case-mgmt-data"]')[0];
            expect(label.innerText.trim()).toBe('Behavioral Case Management:');
            expect(data.innerText.trim()).toBe('YES');
            done();
        });
    });

    it('case management, with medical management links, not under case management', done => {
        _createComponent(assigndeep({}, fullMock, {
            showMedicalManagementLinks: true,
            underCaseManagement: false
        }));

        Vue.nextTick(() => {
            const label = component.$el.querySelectorAll('[data-test-ref="activity-summary-behavioral-case-mgmt-label"]')[0];
            const data = component.$el.querySelectorAll('[data-test-ref="activity-summary-behavioral-case-mgmt-data"]')[0];
            expect(label.innerText.trim()).toBe('Behavioral Case Management:');
            expect(data.innerText.trim()).toBe('NO');
            done();
        });
    });

    it('med case management, indicator is "Y", is a link', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const link = component.$el.querySelectorAll('[data-test-ref="activity-summary-med-case-mgmt-link"]')[0];
            expect(link.innerText.trim()).toBe('Eligible for this Program');
            done();
        });
    });

    it('med case management, indicator is "E", is a link', done => {
        _createComponent(assigndeep({}, fullMock, {
            medicalCaseManagementIndicator: 'E'
        }));

        Vue.nextTick(() => {
            const link = component.$el.querySelectorAll('[data-test-ref="activity-summary-med-case-mgmt-link"]')[0];
            expect(link.innerText.trim()).toBe('Enrolled in this Program');
            done();
        });
    });

    it('med case management, indicator is "N", is just text', done => {
        _createComponent(assigndeep({}, fullMock, {
            medicalCaseManagementIndicator: 'N'
        }));

        Vue.nextTick(() => {
            const data = component.$el.querySelectorAll('[data-test-ref="activity-summary-med-case-mgmt-data"]')[0];
            expect(data.innerText.trim()).toBe('Program Not Available');
            done();
        });
    });

    it('med case management, indicator is "foo", is just empty text', done => {
        _createComponent(assigndeep({}, fullMock, {
            medicalCaseManagementIndicator: 'foo'
        }));

        Vue.nextTick(() => {
            const data = component.$el.querySelectorAll('[data-test-ref="activity-summary-med-case-mgmt-data"]')[0];
            expect(data.innerText.trim()).toBe('');
            done();
        });
    });

    it('disease case management, indicator is "Y", is a link', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const link = component.$el.querySelectorAll('[data-test-ref="activity-summary-disease-case-mgmt-link"]')[0];
            expect(link.innerText.trim()).toBe('Eligible for this Program');
            done();
        });
    });

    it('disease case management, indicator is "E", is a link', done => {
        _createComponent(assigndeep({}, fullMock, {
            diseaseManagementIndicator: 'E'
        }));

        Vue.nextTick(() => {
            const link = component.$el.querySelectorAll('[data-test-ref="activity-summary-disease-case-mgmt-link"]')[0];
            expect(link.innerText.trim()).toBe('Enrolled in this Program');
            done();
        });
    });

    it('disease case management, indicator is "N", is just text', done => {
        _createComponent(assigndeep({}, fullMock, {
            diseaseManagementIndicator: 'N'
        }));

        Vue.nextTick(() => {
            const data = component.$el.querySelectorAll('[data-test-ref="activity-summary-disease-case-mgmt-data"]')[0];
            expect(data.innerText.trim()).toBe('Program Not Available');
            done();
        });
    });

    it('disease case management, indicator is "foo", is just empty text', done => {
        _createComponent(assigndeep({}, fullMock, {
            diseaseManagementIndicator: 'foo'
        }));

        Vue.nextTick(() => {
            const data = component.$el.querySelectorAll('[data-test-ref="activity-summary-disease-case-mgmt-data"]')[0];
            expect(data.innerText.trim()).toBe('');
            done();
        });
    });

    it('maternity case management, indicator is "Y", is a link', done => {
        _createComponent(assigndeep({}, fullMock, {
            maternityManagementIndicator: 'Y'
        }));

        Vue.nextTick(() => {
            const link = component.$el.querySelectorAll('[data-test-ref="activity-summary-maternity-case-mgmt-link"]')[0];
            expect(link.innerText.trim()).toBe('Eligible for this Program');
            done();
        });
    });

    it('maternity case management, indicator is "E", is a link', done => {
        _createComponent(assigndeep({}, fullMock, {
            maternityManagementIndicator: 'E'
        }));

        Vue.nextTick(() => {
            const link = component.$el.querySelectorAll('[data-test-ref="activity-summary-maternity-case-mgmt-link"]')[0];
            expect(link.innerText.trim()).toBe('Enrolled in this Program');
            done();
        });
    });

    it('maternity case management, indicator is "N", is just text', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const data = component.$el.querySelectorAll('[data-test-ref="activity-summary-maternity-case-mgmt-data"]')[0];
            expect(data.innerText.trim()).toBe('Program Not Available');
            done();
        });
    });

    it('maternity case management, indicator is "foo", is just empty text', done => {
        _createComponent(assigndeep({}, fullMock, {
            maternityManagementIndicator: 'foo'
        }));

        Vue.nextTick(() => {
            const data = component.$el.querySelectorAll('[data-test-ref="activity-summary-maternity-case-mgmt-data"]')[0];
            expect(data.innerText.trim()).toBe('');
            done();
        });
    });

    it('wellness case management, indicator is "Y", is a link', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const link = component.$el.querySelectorAll('[data-test-ref="activity-summary-wellness-case-mgmt-link"]')[0];
            expect(link.innerText.trim()).toBe('Eligible for this Program');
            done();
        });
    });

    it('wellness case management, indicator is "E", is a link', done => {
        _createComponent(assigndeep({}, fullMock, {
            wellnessManagementIndicator: 'E'
        }));

        Vue.nextTick(() => {
            const link = component.$el.querySelectorAll('[data-test-ref="activity-summary-wellness-case-mgmt-link"]')[0];
            expect(link.innerText.trim()).toBe('Enrolled in this Program');
            done();
        });
    });

    it('wellness case management, indicator is "N", is just text', done => {
        _createComponent(assigndeep({}, fullMock, {
            wellnessManagementIndicator: 'N'
        }));

        Vue.nextTick(() => {
            const data = component.$el.querySelectorAll('[data-test-ref="activity-summary-wellness-case-mgmt-data"]')[0];
            expect(data.innerText.trim()).toBe('Program Not Available');
            done();
        });
    });

    it('wellness case management, indicator is "foo", is just empty text', done => {
        _createComponent(assigndeep({}, fullMock, {
            wellnessManagementIndicator: 'foo'
        }));

        Vue.nextTick(() => {
            const data = component.$el.querySelectorAll('[data-test-ref="activity-summary-wellness-case-mgmt-data"]')[0];
            expect(data.innerText.trim()).toBe('');
            done();
        });
    });

    it('authorizations is empty, no text displayed', done => {
        _createComponent(assigndeep({}, fullMock, {
            authorizations: []
        }));

        Vue.nextTick(() => {
            const text = component.$el.querySelectorAll('[data-test-ref="activity-summary-no-auths-text"]')[0];
            expect(text.innerText.trim()).toBe('No activity summary data found.');
            done();
        });
    });

    it('date link for auth records', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const authDateLinks = component.$el.querySelectorAll('[data-test-ref="activity-summary-auth-date-link"]');
            expect(authDateLinks.length).toBe(50);
            expect(authDateLinks[0].innerText.trim()).toBe('02/23/2010');
            done();
        });
    });

    it('auth number for auth records', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const authNumbers = component.$el.querySelectorAll('[data-test-ref="activity-summary-auth-number"]');
            expect(authNumbers.length).toBe(50);
            expect(authNumbers[0].innerText.trim()).toBe('W005414032907');
            done();
        });
    });

    it('auth status for auth records', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const authStatuses = component.$el.querySelectorAll('[data-test-ref="activity-summary-auth-status"]');
            expect(authStatuses.length).toBe(50);
            expect(authStatuses[0].innerText.trim()).toBe('WIP');
            done();
        });
    });

    it('ensure extension does not show when empty', done => {
        _createComponent(assigndeep({}, fullMock, {
            authorizations: [
                {
                    activity: '',
                    authorizationNumber: 'W005414032907',
                    beginDate: '2010-02-23T00:00:00-0500',
                    extension: '',
                    facility: {
                        name: {
                            firstName: ''
                        }
                    },
                    function: '',
                    origination: {
                        description: 'WIP'
                    },
                    program: '',
                    rendering: {
                        name: {
                            firstName: ''
                        }
                    },
                    reviewer: {
                        firstName: 'DESKTOP DEVELOPER RACF'
                    },
                    status: 'WIP'
                }
            ]
        }));

        Vue.nextTick(() => {
            const extTexts = component.$el.querySelectorAll('[data-test-ref="activity-summary-auth-ext-text"]');
            expect(extTexts.length).toBe(0);
            done();
        });
    });

    it('ensure extension EXT shows up as link', done => {
        _createComponent(assigndeep({}, fullMock, {
            authorizations: [
                {
                    activity: '',
                    authorizationNumber: 'W005414032907',
                    beginDate: '2010-02-23T00:00:00-0500',
                    extension: 'EXT',
                    facility: {
                        name: {
                            firstName: ''
                        }
                    },
                    function: '',
                    origination: {
                        description: 'WIP'
                    },
                    program: '',
                    rendering: {
                        name: {
                            firstName: ''
                        }
                    },
                    reviewer: {
                        firstName: 'DESKTOP DEVELOPER RACF'
                    },
                    status: 'WIP'
                }
            ]
        }));

        Vue.nextTick(() => {
            const extLinks = component.$el.querySelectorAll('[data-test-ref="activity-summary-auth-ext-link"]');
            expect(extLinks.length).toBe(1);
            expect(extLinks[0].innerText.trim()).toBe('EXT');
            done();
        });
    });

    it('ensure extension E&S shows up as link', done => {
        _createComponent(assigndeep({}, fullMock, {
            authorizations: [
                {
                    activity: '',
                    authorizationNumber: 'W005414032907',
                    beginDate: '2010-02-23T00:00:00-0500',
                    extension: 'E&S',
                    facility: {
                        name: {
                            firstName: ''
                        }
                    },
                    function: '',
                    origination: {
                        description: 'WIP'
                    },
                    program: '',
                    rendering: {
                        name: {
                            firstName: ''
                        }
                    },
                    reviewer: {
                        firstName: 'DESKTOP DEVELOPER RACF'
                    },
                    status: 'WIP'
                }
            ]
        }));

        Vue.nextTick(() => {
            const extLinks = component.$el.querySelectorAll('[data-test-ref="activity-summary-auth-ext-link"]');
            expect(extLinks.length).toBe(1);
            expect(extLinks[0].innerText.trim()).toBe('E&S');
            done();
        });
    });

    it('ensure extension SRV shows up as link', done => {
        _createComponent(assigndeep({}, fullMock, {
            authorizations: [
                {
                    activity: '',
                    authorizationNumber: 'W005414032907',
                    beginDate: '2010-02-23T00:00:00-0500',
                    extension: 'SRV',
                    facility: {
                        name: {
                            firstName: ''
                        }
                    },
                    function: '',
                    origination: {
                        description: 'WIP'
                    },
                    program: '',
                    rendering: {
                        name: {
                            firstName: ''
                        }
                    },
                    reviewer: {
                        firstName: 'DESKTOP DEVELOPER RACF'
                    },
                    status: 'WIP'
                }
            ]
        }));

        Vue.nextTick(() => {
            const extLinks = component.$el.querySelectorAll('[data-test-ref="activity-summary-auth-srv-link"]');
            expect(extLinks.length).toBe(1);
            expect(extLinks[0].innerText.trim()).toBe('SRV');
            done();
        });
    });

    it('ensure unknown extension shows up as text', done => {
        _createComponent(assigndeep({}, fullMock, {
            authorizations: [
                {
                    activity: '',
                    authorizationNumber: 'W005414032907',
                    beginDate: '2010-02-23T00:00:00-0500',
                    extension: '???',
                    facility: {
                        name: {
                            firstName: ''
                        }
                    },
                    function: '',
                    origination: {
                        description: 'WIP'
                    },
                    program: '',
                    rendering: {
                        name: {
                            firstName: ''
                        }
                    },
                    reviewer: {
                        firstName: 'DESKTOP DEVELOPER RACF'
                    },
                    status: 'WIP'
                }
            ]
        }));

        Vue.nextTick(() => {
            const extTexts = component.$el.querySelectorAll('[data-test-ref="activity-summary-auth-ext-text"]');
            expect(extTexts.length).toBe(1);
            expect(extTexts[0].innerText.trim()).toBe('???');
            done();
        });
    });

    it('ensure activity text displays', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const entries = component.$el.querySelectorAll('[data-test-ref="activity-summary-activity-text"]');
            expect(entries.length).toBe(1);
            expect(entries[0].innerText.trim()).toBe('ADMISSION');
            done();
        });
    });

    it('ensure function text displays', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const entries = component.$el.querySelectorAll('[data-test-ref="activity-summary-function-text"]');
            expect(entries.length).toBe(1);
            expect(entries[0].innerText.trim()).toBe('PRECERTIFICATION AND ADMI');
            done();
        });
    });

    it('ensure program text displays', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const entries = component.$el.querySelectorAll('[data-test-ref="activity-summary-program-text"]');
            expect(entries.length).toBe(1);
            expect(entries[0].innerText.trim()).toBe('MEDICAL');
            done();
        });
    });

    it('ensure provider text displays', done => {
        _createComponent(assigndeep({}, fullMock, {
            authorizations: [
                {
                    activity: '',
                    authorizationNumber: 'W005414032907',
                    beginDate: '2010-02-23T00:00:00-0500',
                    extension: 'EXT',
                    facility: {
                        name: {
                            firstName: ''
                        }
                    },
                    function: '',
                    origination: {
                        description: 'WIP'
                    },
                    program: '',
                    rendering: {
                        name: {
                            firstName: 'JOHN'
                        }
                    },
                    reviewer: {
                        firstName: 'DESKTOP DEVELOPER RACF'
                    },
                    status: 'WIP'
                }
            ]
        }));

        Vue.nextTick(() => {
            const entries = component.$el.querySelectorAll('[data-test-ref="activity-summary-provider-text"]');
            expect(entries.length).toBe(1);
            expect(entries[0].innerText.trim()).toBe('JOHN');
            done();
        });
    });

    it('ensure facility text displays', done => {
        _createComponent(assigndeep({}, fullMock, {
            authorizations: [
                {
                    activity: '',
                    authorizationNumber: 'W005414032907',
                    beginDate: '2010-02-23T00:00:00-0500',
                    extension: 'EXT',
                    facility: {
                        name: {
                            firstName: 'ST JOHN HOSPITAL'
                        }
                    },
                    function: '',
                    origination: {
                        description: 'WIP'
                    },
                    program: '',
                    rendering: {
                        name: {
                            firstName: 'JOHN'
                        }
                    },
                    reviewer: {
                        firstName: 'DESKTOP DEVELOPER RACF'
                    },
                    status: 'WIP'
                }
            ]
        }));

        Vue.nextTick(() => {
            const entries = component.$el.querySelectorAll('[data-test-ref="activity-summary-facility-text"]');
            expect(entries.length).toBe(1);
            expect(entries[0].innerText.trim()).toBe('ST JOHN HOSPITAL');
            done();
        });
    });

    it('ensure origination text displays', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const entries = component.$el.querySelectorAll('[data-test-ref="activity-summary-origination-text"]');
            expect(entries.length).toBe(50);
            expect(entries[0].innerText.trim()).toBe('WIP');
            done();
        });
    });

    it('ensure reviewer text displays', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const entries = component.$el.querySelectorAll('[data-test-ref="activity-summary-reviewer-text"]');
            expect(entries.length).toBe(50);
            expect(entries[0].innerText.trim()).toBe('DESKTOP DEVELOPER RACF');
            done();
        });
    });

    it('ensure attachments links display', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const entries = component.$el.querySelectorAll('[data-test-ref="activity-summary-attachments-link"]');
            expect(entries.length).toBe(50);
            expect(entries[0].innerText.trim()).toBe('View All Attachments');
            done();
        });
    });

    it('ensure activity returns null with null auths', () => {
        _createComponent(assigndeep({}, fullMock, {
            authorizations: null
        }));

        expect(component.activity).toBeNull();
    });

    it('ensure refresh data is called when the databaseId changes', done => {
        _createComponent(fullMock);
        component.$store.dispatch('setDatabaseId', 'test');

        spyOn(component, 'refreshData').and.callFake(() => {
            done();
        });
    });

    it('return promise when calling get data without subscriber and patient IDs', done => {
        _createComponent(fullMock);

        component.$store.dispatch('clearDatabaseId');
        component.$store.dispatch('clearPatientId');

        component.getData().then(() => {
            done();
        });
    });

    it('return activity summary data when calling get data with subscriber and patient IDs', done => {
        _createComponent(fullMock);
        component.$store.dispatch('setDatabaseId', '123456789');
        component.$store.dispatch('setPatientId', '001');

        component.getData().then(() => {
            done();
        });
    });

    it('make sure clear data clears the activity data', () => {
        _createComponent(fullMock);

        const spy = spyOn(component.$store, 'dispatch');
        component.clearData();

        expect(spy).toHaveBeenCalledWith('clearActivitySummary');
    });

    it('if next button pressed, will increment the page number by one.  Should go from page 0 to page 1.', () => {
        _createComponent(fullMock);

        expect(fullMock.pageNumber).toBe(0);
        component.nextPage(fullMock);

        Vue.nextTick(() => {
            expect(fullMock.pageNumber).toBe(1); 
            done();
        });
    });

    it('if next button pressed, DataStore call is made by retrieveActivitySummary', () => {
        _createComponent(fullMock);

        const spy = spyOn(component.$store, 'dispatch');
        component.nextPage(fullMock);

        expect(spy).toHaveBeenCalledWith('retrieveActivitySummary', {subscriberId: component.databaseId, memberKeyId: component.patientId, includeVoids: true, pageNumber: fullMock.pageNumber});
    });

    it('if prev button pressed, will decrement the page number by one.  Should go from page 1 to page 0.', () => {
        _createComponent(fullMock2);

        expect(fullMock2.pageNumber).toBe(1);
        component.previousPage(fullMock2);

        Vue.nextTick(() => {
            expect(fullMock2.pageNumber).toBe(0); 
            done();
        });
    });

    it('if prev button pressed, DataStore call is made by retrieveActivitySummary', () => {
        _createComponent(fullMock2);

        const spy = spyOn(component.$store, 'dispatch');
        component.previousPage(fullMock2);

        expect(spy).toHaveBeenCalledWith('retrieveActivitySummary', {subscriberId: component.databaseId, memberKeyId: component.patientId, includeVoids: true, pageNumber: fullMock2.pageNumber});
    });
});
