<template>
    <section
        v-if="alerts"
        class="app-section-alerts"
        aria-label="Alerts"
        data-test-ref="alerts-section">
        <b-card
            no-body
            class="card-clear-tabs">
            <b-tabs
                v-if="hasSubscriberProducts"
                ref="productTabs"
                card
                data-test-ref="alerts-tabs"
                @input="changeProduct">
                <b-tab
                    v-for="product in subscriberProducts"
                    :id="product"
                    :key="product"
                    :active="isSelected(product)"
                    data-test-ref="product-tab-content">
                    <template slot="title">
                        <span
                            :class="getTitleClass(product)"
                            data-test-ref="product-tab-title">
                        </span>
                        {{ getTitleText(product) }}
                    </template>
                    <span
                        v-if="isSelected(product)"
                        :data-test-ref="getTitleText(product).toLowerCase() + '-tab-body'">
                        <b-card
                            v-if="alertsList.length <= 0"
                            no-body
                            data-test-ref="no-alerts-card">
                            No Alerts
                        </b-card>
                        <span
                            v-for="(alert, index) in alertsList"
                            :key="index"
                            data-test-ref="alert-indicators">
                            <b-card
                                v-if="alert.grandfatherIndicator"
                                id="grandfatherIcon"
                                class="app-alert-status-icon">
                                <span
                                    slot="header"
                                    class="fa fa-csm-alert-grandfathered"></span>
                                Grandfathered
                            </b-card>
                            <b-card
                                v-if="alert.isDelinquent"
                                id="delinquentIcon"
                                class="app-alert-status-icon">
                                <span
                                    slot="header"
                                    class="fa fa-csm-alert-delinquent"></span>
                                Delinquent
                            </b-card>
                            <b-card
                                v-if="alert.memberSpecialNoteRecords"
                                id="moreNotesIcon"
                                tag="a"
                                href="javascript:void(0)"
                                class="app-alert-status-icon">
                                <span
                                    slot="header"
                                    class="fa fa-csm-alert-more-notes"></span>
                                More Notes
                            </b-card>
                            <b-card
                                v-if="alert.isResponseRequired"
                                id="cobIcon"
                                tag="a"
                                href="javascript:void(0)"
                                class="app-alert-status-icon">
                                <span
                                    slot="header"
                                    class="fa fa-csm-alert-cob"></span>
                                COB
                            </b-card>
                        </span>
                        <span
                            v-for="(memberAlert, memberAlertIndex) in memberAlerts"
                            :key="memberAlert[0].patientName + memberAlert[0].patientId"
                            data-test-ref="member-alerts-loop">
                            <b-card class="app-alert-status-category">
                                <h2 slot="header">{{ memberAlert[0].patientName }}<br>{{ memberAlert[0].patientId }}</h2>
                                <span
                                    v-for="(record, recordsIndex) in memberAlert[1]"
                                    :key="recordsIndex">
                                    <b-card
                                        v-if="record.alertType === 'EXCEPTION_ALERT' && record.controlCode"
                                        class="app-alert-status-code"
                                        data-test-ref="alert-type-instance">
                                        <h3 slot="header">{{ record.controlCode.code }}</h3>
                                        {{ record.controlCode.description }}
                                    </b-card>
                                    <b-card
                                        v-if="hasDeferral(record)"
                                        :data-test-ref="'deferral-record-' + memberAlertIndex"
                                        tag="a"
                                        href="javascript:void(0)"
                                        class="app-alert-status-code-description"
                                        @click="showHideDescription(memberAlertIndex, memberAlert[0].patientId + recordsIndex)">
                                        {{ record.deferral }}
                                        <span v-if="hasOverride(record)">
                                            <hr>
                                            {{ record.override }}
                                        </span>
                                        <span
                                            :ref="'caret-' + memberAlert[0].patientId + recordsIndex"
                                            :class="caretPosition('caret-' + memberAlert[0].patientId + recordsIndex)">
                                        </span>
                                        <input
                                            :ref="memberAlert[0].patientId + recordsIndex"
                                            :value="record.exceptionDescription"
                                            type="hidden">
                                    </b-card>
                                    <b-card
                                        v-if="record.alertType === 'CLAIMS_ALERT' && record.claimStatusAlert"
                                        tag="a"
                                        href="javascript:void(0)"
                                        class="app-alert-status-icon"
                                        data-test-ref="alert-type-instance">
                                        <span
                                            slot="header"
                                            class="fa fa-csm-alert-claim-status"></span>
                                        Claim Status
                                    </b-card>
                                    <b-card
                                        v-if="record.alertType === 'SUBROGATION_ALERT' && record.claimSubrogationAlert"
                                        tag="a"
                                        href="javascript:void(0)"
                                        class="app-alert-status-icon"
                                        data-test-ref="alert-type-instance">
                                        <span
                                            slot="header"
                                            class="fa fa-csm-alert-subrogation"></span>
                                        Claim Status
                                    </b-card>
                                    <b-card
                                        v-else-if="record.alertType === 'MOBILE_NOTIFICATIONS_ALERT'"
                                        tag="a"
                                        href="javascript:void(0)"
                                        class="app-alert-status-icon"
                                        data-test-ref="alert-type-instance">
                                        <span
                                            slot="header"
                                            class="fa fa-csm-alert-mobile-notifications"></span>
                                        Mobile
                                    </b-card>
                                </span>
                            </b-card>
                            <b-alert
                                v-if="alertDescriptions.length > 0"
                                :ref="memberAlert[0].patientName + memberAlert[0].patientId"
                                :show="alertDescriptions[memberAlertIndex].show"
                                :data-test-ref="'alert-description-' + memberAlertIndex"
                                dismissible
                                fade
                                variant="dark"
                                class="mb-3"
                                @dismissed="showHideDescription(memberAlertIndex)">
                                <strong>Description:</strong> {{ alertDescriptions[memberAlertIndex].description }}
                            </b-alert>
                        </span>
                    </span>
                </b-tab>
            </b-tabs>
        </b-card>
    </section>
</template>

<script>
import DesktopBaseComponent from './DesktopBaseComponent.vue';

export default {
    name: 'Alerts',
    extends: DesktopBaseComponent,
    data: () => {
        return {
            hasSummaryLinks: false,
            alertDescriptions: [],
            caretPositions: {}
        };
    },
    computed: {
        databaseId() {
            return this.$store.getters.getDatabaseId;
        },
        alerts() {
            let alerts;
            if (this.$store.getters.getAlerts) {
                alerts = this.$store.getters.getAlerts;
            }
            return alerts;
        },
        hasAlerts() {
            return this.alerts && this.alerts.alerts;
        },
        hasSubscriberProducts() {
            return this.alerts.subscriberProducts && this.alerts.subscriberProducts.length > 0;
        },
        alertsList() {
            return this.alerts.alerts;
        },
        memberAlerts() {
            const memberAlerts = this.alerts.memberAlerts ? this.alerts.memberAlerts : [];
            return Array.from(memberAlerts);
        },
        subscriberProducts() {
            return this.alerts.subscriberProducts.slice(0).sort().reverse();
        }
    },
    watch: {
        databaseId() {
            this.refreshData(true);
        }
    },
    methods: {
        getData() {
            let dataPromise;
            if (this.databaseId) {
                dataPromise = this.$store.dispatch('retrieveAlerts', {
                    memberKeyId: this.databaseId,
                    selectedProductCode: this.alerts.selectedProductCode,
                    callCenterName: 'BCBSSCSandbox'
                }).then((data) => {
                    this.populateAlertDescriptions(data.memberAlerts);
                    return data;
                });
            } else {
                dataPromise = Promise.resolve();
            }
            return dataPromise;
        },
        clearData() {
            this.$store.dispatch('clearAlerts');
            this.caretPositions = {};
        },
        isSelected(product) {
            return this.alerts.selectedProductCode === product;
        },
        getTitleText(product) {
            let titleText = '';
            switch (product) {
            case 'Products.MEDICAL':
                titleText = 'Health';
                break;
            case 'Products.DENTAL':
                titleText = 'Dental';
                break;
            default:
                break;
            }
            return titleText;
        },
        getTitleClass(product) {
            return 'fa fa-csm-contract-' + this.getTitleText(product).toLowerCase();
        },
        changeProduct(tabIndex) {
            const product = this.$refs.productTabs.tabs[tabIndex].id;
            // If databaseId is set
            if (this.databaseId && this.databaseId.length > 0) {
                this.alerts.selectedProductCode = product;
                this.getData();
            }
        },
        hasDeferral(memberAlert) {
            let hasDeferral = false;
            if (memberAlert.deferral && memberAlert.deferral.length > 0) {
                hasDeferral = true;
            }
            return hasDeferral;
        },
        hasOverride(memberAlert) {
            return memberAlert.override && memberAlert.override.length > 0;
        },
        _clearAlertDescriptions() {
            this.alertDescriptions.length = 0;
        },
        populateAlertDescriptions(memberAlerts) {
            const len = memberAlerts.length;
            this._clearAlertDescriptions();
            for (let i = 0; i < len; i++) {
                this.alertDescriptions.push({show: false, description: null, descriptionRef: ''});
            }
        },
        showHideDescription(descriptionIndex, descriptionRef) {
            let descriptionNode;
            let alertDescriptionData;
            if (descriptionRef) {
                descriptionNode = this.$refs[descriptionRef] ? this.$refs[descriptionRef][0] : null;
            }
            if (descriptionIndex) {
                alertDescriptionData = this.alertDescriptions[descriptionIndex];
            }
            if (alertDescriptionData) {
                if (alertDescriptionData.show) {
                    if (!descriptionRef || alertDescriptionData.descriptionRef === descriptionRef) {
                        alertDescriptionData.show = false;
                        this.caretPosition('caret-' + alertDescriptionData.descriptionRef, 'user');
                    } else {
                        if (descriptionNode) {
                            alertDescriptionData.description = descriptionNode.value;
                        }
                        alertDescriptionData.descriptionRef = descriptionRef;
                        this.caretPosition('caret-' + descriptionRef, 'user');
                    }
                } else {
                    if (descriptionNode) {
                        alertDescriptionData.description = descriptionNode.value;
                    }
                    alertDescriptionData.descriptionRef = descriptionRef;
                    alertDescriptionData.show = true;
                    this.caretPosition('caret-' + descriptionRef, 'user');
                }
            } else {
                let msg = 'showHideDescription possibly invalid references.';
                msg += ' descriptionIndex: ' + descriptionIndex;
                msg += ' descriptionRef: ' + descriptionRef;
                console.warn(msg);
            }
        },
        /* This method handles the initializing and toggling of the fa-caret-(up|down) class
        (the small arrow icon) used in deferral alerts. The caret must be set to down on
        initial page rendering and toggled when the user clicks on the component or when
        the user dismisses the alert description box. */
        caretPosition(caretRef, source) {
            const down = 'fa fa-caret-down';
            const up = 'fa fa-caret-up';
            let position = down;
            if (this.caretPositions[caretRef]) {
                if (source === 'user') {
                    position = this.caretPositions[caretRef] === down ? up : down;
                    this.caretPositions[caretRef] = position;
                } else {
                    position = this.caretPositions[caretRef];
                }
            } else {
                this.caretPositions[caretRef] = down;
            }
            return position;
        }
    }
};

</script>
