import Vue from 'vue';
import DesktopBaseComponent from './DesktopBaseComponent.vue';
import DataStore from './../store/DataStore.js';

describe('DesktopBaseComponent', () => {
    let component;

    function _createComponent() {
        const Constructor = Vue.extend(DesktopBaseComponent);

        component = new Constructor({
            store: DataStore.store
        });
    }

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('is named DesktopBaseComponent', () => {
        expect(DesktopBaseComponent.name).toEqual('DesktopBaseComponent');
    });

    it('loading returns true when loading data is true', () => {
        _createComponent();

        component.loadingData = true;

        expect(component.loading).toBeTruthy();
    });

    it('loading returns true when loading data is true and loading summary links is true', () => {
        _createComponent();

        component.loadingData = true;
        component.loadingSummaryLinks = true;

        expect(component.loading).toBeTruthy();
    });

    it('loading returns true when loading summary links is true', () => {
        _createComponent();

        component.loadingSummaryLinks = true;

        expect(component.loading).toBeTruthy();
    });

    it('emits an authorizationError event on 403 errors', (done) => {
        _createComponent();

        const error = {
            response: {
                status: 403
            }
        };

        component.$on('authorizationError', () => {
            done();
        });

        component.errorHandler(error);
    });

    it('emits a systemError event on non-403 errors', (done) => {
        _createComponent();

        const error = {
            response: {
                status: 404
            }
        };

        component.$on('systemError', () => {
            done();
        });

        component.errorHandler(error);
    });

    it('refresh data sets loading data to true, calls clear data and set data and emits a loaded', (done) => {
        _createComponent();

        const clearSpy = spyOn(component, 'clearData').and.callThrough();
        const cacheSummaryLinksSpy = spyOn(component, 'cacheSummaryLinks');

        component.refreshData();

        expect(component.loadingData).toBeTruthy();
        expect(clearSpy).toHaveBeenCalled();
        expect(cacheSummaryLinksSpy).toHaveBeenCalled();

        component.$on('loaded', () => {
            expect(component.loadingData).toBeFalsy();
            done();
        });
    });

    it('refresh data calls the error handler when get data returns an error', (done) => {
        _createComponent();

        const errorSpy = spyOn(component, 'errorHandler');

        spyOn(component, 'getData').and.callFake(() => {
            return Promise.reject();
        });

        component.refreshData(true);

        component.$on('loaded', () => {
            expect(errorSpy).toHaveBeenCalled();
            done();
        });
    });

    it('refresh data is called when forced', (done) => {
        _createComponent();
        component.loadingData = true;

        component.refreshData(true);

        component.$on('loaded', () => {
            done();
        });
    });

    it('refresh data does not load cache summary links when forced', () => {
        _createComponent();

        const cacheSummaryLinksSpy = spyOn(component, 'cacheSummaryLinks');

        component.refreshData(true);

        expect(cacheSummaryLinksSpy).not.toHaveBeenCalled();
    });

    it('refresh data does not load cache summary links when summary links are loaded', () => {
        _createComponent();

        component.loadedSummaryLinks = true;

        const cacheSummaryLinksSpy = spyOn(component, 'cacheSummaryLinks');

        component.refreshData();

        expect(cacheSummaryLinksSpy).not.toHaveBeenCalled();
    });

    it('refresh data should not do anything', () => {
        _createComponent();

        component.loadingSummaryLinks = true;

        component.refreshData();
    });

    it('cache summary links sets loading summary links to true', () => {
        _createComponent();

        component.cacheSummaryLinks();
        expect(component.loadingSummaryLinks).toBeTruthy();
    });
});
