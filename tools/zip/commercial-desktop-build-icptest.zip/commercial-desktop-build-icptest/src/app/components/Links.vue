<template>
    <section
        class="app-section-links"
        aria-label="Links">
        <b-card
            no-body
            class="card-clear-tabs">
            <b-tabs card>
                <b-tab>
                    <template slot="title">
                        <span class="fa fa-csm-links-explore"></span>
                        Explore
                    </template>
                    <b-container
                        fluid
                        class="p-0">
                        <b-row>
                            <b-col
                                cols="12"
                                sm="6">
                                <h2>Select a Category</h2>
                                <template v-if="navLinkCategories.items">
                                    <template
                                        v-if="navLinkCategories.items[0].items">
                                        <accordion
                                            :tree="navLinkCategories.items[0].items"
                                            flush
                                            @activate="onActivate($event)"/>
                                    </template>
                                    <template
                                        v-else>
                                        <accordion
                                            :tree="navLinkCategories.items"
                                            flush
                                            @activate="onActivate($event)"/>
                                    </template>
                                </template>
                            </b-col>
                            <b-col
                                v-if="isActive"
                                cols="12"
                                sm="6">
                                <h2>Browsing {{ categoryTitle }}</h2>
                                <b-list-group>
                                    <b-list-group-item
                                        v-for="index in navLinks"
                                        :key="index.linkDesc">
                                        <b-link>{{ index.linkDesc }}</b-link>
                                    </b-list-group-item>
                                </b-list-group>
                            </b-col>
                        </b-row>
                    </b-container>
                </b-tab>
                <b-tab>
                    <template slot="title">
                        <span class="fa fa-csm-links-search"></span>
                        Search
                    </template>
                </b-tab>
            </b-tabs>
        </b-card>
    </section>
</template>

<script>
export default {
    name: 'Links',
    data() {
        return {
            categoryTitle: '',
            categoryId: '',
            isActive: false,
            wasClicked: false,
            navLinkCategoriesObject: {},
            navLinkCategories: {},
            navLinks: []

        };
    },
    mounted() {
        // call service directly, no need to go through the store
        this.$store.dispatch('retrieveNavLinkCategories', this.$store.getters.getDesktopName).then((response) => {
        // update title here so it won't update before links are brought in
            this.navLinkCategories = response;
        });
    },
    methods: {
        onActivate(category) {
            this.isActive = true;
            // call service directly, no need to go through the store
            return this.$store.dispatch('retrieveNavLinks', category.id).then((response) => {
                // update title here so it won't update before links are brought in
                this.categoryTitle = category.description;
                this.navLinks = response;
            });
        }
    }
};
</script>
