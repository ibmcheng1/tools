<template>
    <section
        :class="hasAlert ? 'app-section-has-alert' : null"
        class="app-section-exceptions-summary"
        aria-label="Exceptions Summary">
        <b-card
            v-for="exception in exceptions"
            :key="exception.priority"
            class="card-summary-section"
            role="section"
            data-test-ref="exception">
            <template slot="header">
                <span
                    v-if="exception.alertExceptionIndicator === true"
                    class="fa fa-exclamation-circle text-danger"
                    data-test-ref="alert">
                    <span class="sr-only">Exception</span>
                </span>
                <h2>
                    <span data-test-ref="applies-to">{{ exception.patientName }} {{ exception.patientID }}</span>
                    <template v-if="exception.controlCode">
                        &nbsp;&nbsp;|&nbsp;&nbsp;
                        <span data-test-ref="type">
                            <template v-if="exception.controlCode.code">{{ exception.controlCode.code.trim() }}</template>
                            <template v-if="exception.controlCode.description">- {{ exception.controlCode.description.trim() }}</template>
                        </span>
                    </template>
                </h2>
            </template>
            <dl class="definition-list definition-list-lines definition-list-lines-long">
                <dt>
                    Deferral
                </dt>
                <dd data-test-ref="deferral">
                    {{ exception.deferral || '-' }}
                </dd>
                <dt>
                    Description
                </dt>
                <dd data-test-ref="description">
                    {{ exception.exceptionDescription || '-' }}
                </dd>
            </dl>
        </b-card>
    </section>
</template>
<script>
import DesktopBaseComponent from './DesktopBaseComponent.vue';

export default {
    name: 'ExceptionsSummary',
    extends: DesktopBaseComponent,
    data: () => {
        return {
            hasSummaryLinks: false
        };
    },
    computed: {
        /**
         * A computed property to get the current database id
         */
        databaseId() {
            return this.$store.getters.getDatabaseId;
        },
        /**
         * A computed property to get the exceptions
         */
        exceptions() {
            let exceptions = null;
            if (this.$store.getters.getExceptions) {
                exceptions = this.$store.getters.getExceptions;
            }
            return exceptions;
        },
        hasAlert() {
            if (this.exceptions && this.exceptions.length > 0) {
                for (let i = 0; i < this.exceptions.length; i++) {
                    if (this.exceptions[i].alertExceptionIndicator) {
                        return true;
                    }
                }
            }
            return false;
        }
    },
    watch: {
        /**
         * When the database id is changed, go get the data.
         */
        databaseId() {
            this.refreshData(true);
        }
    },
    methods: {
        /**
         * get the exceptions
         */
        getData() {
            // if the database id is provided, go get the exceptions
            if (this.databaseId) {
                return this.$store.dispatch('retrieveExceptions', {memberKeyId: this.databaseId});
            }
            // with no database id, return a promise that immediately resolves
            return Promise.resolve();
        },
        /**
         * clear the exceptions
         */
        clearData() {
            // clear out any lingering context in the store
            this.$store.dispatch('clearExceptions');
        }
    }
};
</script>
