<script>
export default {
    name: 'DesktopBaseComponent', // value of 'name' is overwritten by child
    data: () => {
        return {
            loadingData: false,
            loadingSummaryLinks: false,
            loadedSummaryLinks: false,
            hasSummaryLinks: true, // this value needs to be overridden in the data section
                                   // if your component doesn't have summary links.  It will
                                   // cause us to not try to retrieve them.
            summaryLinks: [],
            error: false
        };
    },
    computed: {
        loading() {
            return this.loadingData || this.loadingSummaryLinks;
        }
    },
    mounted() {
        this.refreshData(); // TODO Remove refreshData on mount when vuex is updated to include loading desktop action
        this.cacheSummaryLinks();
    },
    /** @lends app.components.DesktopBaseComponent.prototype */
    methods: {
        /**
         * refresh data for this component...also loads summary links if needed.  If already loading don't refresh
         * unless forced
        */
        refreshData(force) {
            if (!this.loadingData || force) {
                // If summary links have not been loaded (if there was a failure), try and load them again on refresh
                // This will only work if not forced (when refresh icon is clicked)
                if (!this.loadedSummaryLinks && !force) {
                    this.cacheSummaryLinks();
                }

                this.loadingData = true;
                this.$emit('loading');

                this.clearData();
                this.getData().then(() => {
                    // Let Vuex handle the response
                }, dataError => {
                    this.errorHandler(dataError);
                })
                .finally(() => {
                    this.loadingData = false;
                    this.$emit('loaded');
                });
            }
        },
        /**
         * gets and caches summary links for this component.  Summary links key is the name of the component and the desktop name
         */
        cacheSummaryLinks() {
            if (this.hasSummaryLinks) {
                this.loadingSummaryLinks = true;

                // The name of the (child) component and desktop name are used as a keys to get summary links
                this.$store.dispatch('retrieveSummaryLinks', {component: this.$options.name, desktopName: this.$store.getters.getDesktopName}).then(response => {
                    this.summaryLinks = response;
                    this.loadedSummaryLinks = true;
                }, dataError => {
                    console.error('There was an error retrieving summary links for "' + this.$options.name + '": ' + dataError);
                })
                .finally(() => {
                    this.loadingSummaryLinks = false;
                });
            }
        },
        /**
         * helper method for finding a summary link by name
         */
        findSummaryLink(name) {
            return this.summaryLinks.find(element => {
                return element.name === name;
            });
        },
        /**
         * Gets the data for the component.  Overridden by the extending business component.
         */
        getData() {
            // Override getData
            return Promise.resolve();
        },
        /**
         * Clears the data for the component.  Overridden by the extending business component.
         */
        clearData() {
            // Override clearData
            return Promise.resolve();
        },
        /**
         * Handled the standard error scenarios for the business components.  Can be overridden if additional
         * logic is needed.
         *
         * @param {Error} error The error to handle
         */
        errorHandler(error) {
            let errorEvent = null;
            if (typeof error === 'object' && error.response && error.response.status === 403) {
                // not authorized to view this data
                errorEvent = 'authorizationError';
            } else {
                // generic error, send it over to the default error page
                errorEvent = 'systemError';
            }
            this.$emit(errorEvent);
        }
    }
};
</script>
