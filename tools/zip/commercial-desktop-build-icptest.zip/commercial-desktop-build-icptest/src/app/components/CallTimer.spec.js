import Vue from 'vue';
import CallTimer from './CallTimer.vue';
import DataStore from './../store/DataStore.js';
import {mockCallCenterAttributesHealth as fullMock} from './../store/mock/call-center-data/CallCenterMockHealth.js';

describe('CallTimer', () => {
    let component;

    function _createComponent(model) {
        const Constructor = Vue.extend(CallTimer);

        // set the call center mock model object into the store
        DataStore.store.state.callCenterAttributes = model;

        // build the component and mount it
        component = new Constructor({
            store: DataStore.store
        }).$mount();
    }

    beforeEach(() => {
        jasmine.clock().install();
    });

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
        jasmine.clock().uninstall();
    });

    it('is named CallTimer', () => {
        expect(CallTimer.name).toEqual('CallTimer');
    });

    it('primary timer label text displays default', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const primaryTimerLabel = component.$el.querySelectorAll('[data-test-ref="call-timer-primary-label"]');
            expect(primaryTimerLabel.length).toEqual(1);
            expect(primaryTimerLabel[0].innerText.trim()).toBe('Call:');
            done();
        });
    });

    it('primary timer time displays default of zeroes', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const primaryTimerTime = component.$el.querySelectorAll('[data-test-ref="call-timer-primary-time"]');
            expect(primaryTimerTime.length).toEqual(1);
            expect(primaryTimerTime[0].innerText.trim()).toBe('00:00:00');
            done();
        });
    });

    it('secondary timer label text displays default', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const secondaryTimerLabel = component.$el.querySelectorAll('[data-test-ref="call-timer-secondary-label"]');
            expect(secondaryTimerLabel.length).toEqual(1);
            expect(secondaryTimerLabel[0].innerText.trim()).toBe('On Hold:');
            done();
        });
    });

    it('secondary timer time displays default of zeroes', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const secondaryTimerTime = component.$el.querySelectorAll('[data-test-ref="call-timer-secondary-time"]');
            expect(secondaryTimerTime.length).toEqual(1);
            expect(secondaryTimerTime[0].innerText.trim()).toBe('00:00:00');
            done();
        });
    });

    it('primary timer time displays 00:00:00, after starting and stopping the timer', done => {
        _createComponent(fullMock);
        component.startPrimaryTimer();
        component.stopPrimaryTimer();

        Vue.nextTick(() => {
            const primaryTimerTime = component.$el.querySelectorAll('[data-test-ref="call-timer-primary-time"]');
            expect(primaryTimerTime.length).toEqual(1);
            expect(primaryTimerTime[0].innerText.trim()).toBe('00:00:00');
            done();
        });
    });

    it('secondary timer time displays 00:00:00, after starting and stopping the timer', done => {
        _createComponent(fullMock);
        component.startSecondaryTimer('On Hold:');
        component.stopSecondaryTimer();

        Vue.nextTick(() => {
            const secondaryTimerTime = component.$el.querySelectorAll('[data-test-ref="call-timer-secondary-time"]');
            expect(secondaryTimerTime.length).toEqual(1);
            expect(secondaryTimerTime[0].innerText.trim()).toBe('00:00:00');
            done();
        });
    });

    it('start primary timer after starting the timer once', done => {
        _createComponent(fullMock);
        component.startPrimaryTimer();
        component.startPrimaryTimer();
        component.stopPrimaryTimer();

        Vue.nextTick(() => {
            const primaryTimerTime = component.$el.querySelectorAll('[data-test-ref="call-timer-primary-time"]');
            expect(primaryTimerTime.length).toEqual(1);
            expect(primaryTimerTime[0].innerText.trim()).toBe('00:00:00');
            done();
        });
    });

    it('start secondary timer after starting the timer once', done => {
        _createComponent(fullMock);
        component.startSecondaryTimer();
        component.startSecondaryTimer();
        component.stopSecondaryTimer();

        Vue.nextTick(() => {
            const secondaryTimerTime = component.$el.querySelectorAll('[data-test-ref="call-timer-secondary-time"]');
            expect(secondaryTimerTime.length).toEqual(1);
            expect(secondaryTimerTime[0].innerText.trim()).toBe('00:00:00');
            done();
        });
    });

    it('2 seconds after primary timer starts, timer is correct', done => {
        _createComponent(fullMock);
        component.$root.$emit('start-call');
        jasmine.clock().tick(2000);
        expect(component.primaryTotalTimerSeconds).toBe(2);
        component.$root.$emit('stop-call');
        done();
    });

    it('2 seconds after secondary timer starts, timer is correct', done => {
        _createComponent(fullMock);
        component.$root.$emit('start-hold');
        jasmine.clock().tick(2000);
        expect(component.secondaryTotalTimerSeconds).toBe(2);
        component.$root.$emit('stop-hold');
        done();
    });

    it('secondary setInterval timer set after start hold event', done => {
        _createComponent(fullMock);
        component.$root.$emit('start-hold');

        Vue.nextTick(() => {
            const secondaryTimerTime = component.$el.querySelectorAll('[data-test-ref="call-timer-secondary-time"]');
            expect(secondaryTimerTime.length).toEqual(1);
            expect(component.secondaryInternalTimer).not.toBe(undefined);
            expect(component.secondaryInternalTimer).not.toBe(null);
            component.$root.$emit('stop-hold');
            done();
        });
    });

    it('secondary setInterval timer set after start wrap-up event', done => {
        _createComponent(fullMock);
        component.$root.$emit('start-wrap-up');

        Vue.nextTick(() => {
            const secondaryTimerTime = component.$el.querySelectorAll('[data-test-ref="call-timer-secondary-time"]');
            expect(secondaryTimerTime.length).toEqual(1);
            expect(component.secondaryInternalTimer).not.toBe(undefined);
            expect(component.secondaryInternalTimer).not.toBe(null);
            component.$root.$emit('stop-wrap-up');
            done();
        });
    });

    it('secondary setInterval timer set after start not-ready event', done => {
        _createComponent(fullMock);
        component.$root.$emit('start-not-ready');

        Vue.nextTick(() => {
            const secondaryTimerTime = component.$el.querySelectorAll('[data-test-ref="call-timer-secondary-time"]');
            expect(secondaryTimerTime.length).toEqual(1);
            expect(component.secondaryInternalTimer).not.toBe(undefined);
            expect(component.secondaryInternalTimer).not.toBe(null);
            component.$root.$emit('stop-not-ready');
            done();
        });
    });

    it('secondary setInterval timer set after start work-mode event', done => {
        _createComponent(fullMock);
        component.$root.$emit('start-work-mode');

        Vue.nextTick(() => {
            const secondaryTimerTime = component.$el.querySelectorAll('[data-test-ref="call-timer-secondary-time"]');
            expect(secondaryTimerTime.length).toEqual(1);
            expect(component.secondaryInternalTimer).not.toBe(undefined);
            expect(component.secondaryInternalTimer).not.toBe(null);
            component.$root.$emit('stop-work-mode');
            done();
        });
    });

    it('After secondary timer passes on-hold threshold, the secondary timer is flashing', done => {
        _createComponent(fullMock);

        component.$root.$emit('start-hold');
        jasmine.clock().tick((component.secondaryTimerThreshold * 1000) + 1000);

        Vue.nextTick(() => {
            const secondaryTimerLabel = component.$el.querySelectorAll('[data-test-ref="call-timer-secondary-label"]');
            const secondaryTimerTime = component.$el.querySelectorAll('[data-test-ref="call-timer-secondary-time"]');

            expect(secondaryTimerLabel.length).toEqual(1);
            expect(secondaryTimerTime.length).toEqual(1);
            expect(secondaryTimerLabel[0].classList).toContain('animate-flash');
            expect(secondaryTimerLabel[0].classList).toContain('text-danger-light');
            expect(secondaryTimerTime[0].classList).toContain('animate-flash');
            expect(secondaryTimerTime[0].classList).toContain('text-danger-light');

            component.$root.$emit('stop-hold');
            done();
        });
    });

    it('After secondary timer passes wrap-up threshold, the secondary timer is flashing', done => {
        _createComponent(fullMock);

        component.$root.$emit('start-wrap-up');
        jasmine.clock().tick((component.secondaryTimerThreshold * 1000) + 1000);

        Vue.nextTick(() => {
            const secondaryTimerLabel = component.$el.querySelectorAll('[data-test-ref="call-timer-secondary-label"]');
            const secondaryTimerTime = component.$el.querySelectorAll('[data-test-ref="call-timer-secondary-time"]');

            expect(secondaryTimerLabel.length).toEqual(1);
            expect(secondaryTimerTime.length).toEqual(1);
            expect(secondaryTimerLabel[0].classList).toContain('animate-flash');
            expect(secondaryTimerLabel[0].classList).toContain('text-danger-light');
            expect(secondaryTimerTime[0].classList).toContain('animate-flash');
            expect(secondaryTimerTime[0].classList).toContain('text-danger-light');

            component.$root.$emit('stop-wrap-up');
            done();
        });
    });

    it('2 seconds after \'signon-notification\' event, the primary timer is correct', done => {
        _createComponent(fullMock);
        component.$root.$emit('signon-notification');

        jasmine.clock().tick(2000);
        expect(component.primaryTotalTimerSeconds).toBe(2); // primary timer counts 2 seconds
        done();
    });

    it('2 seconds after \'signon-notification\' event, a second \'signon-notification\' event resets timers', done => {
        _createComponent(fullMock);
        component.$root.$emit('signon-notification');

        jasmine.clock().tick(2000);
        expect(component.primaryTotalTimerSeconds).toBe(2); // primary timer counts 2 seconds

        component.$root.$emit('signon-notification');
        expect(component.primaryInternalTimer).not.toBeDefined(); // primary timer reset
        expect(component.secondaryInternalTimer).not.toBeDefined(); // secondary timer reset

        done();
    });

    it('2 seconds after \'hold-notification\' event, the secondary timer is correct', done => {
        _createComponent(fullMock);
        component.$root.$emit('hold-notification');

        jasmine.clock().tick(2000);
        expect(component.secondaryTotalTimerSeconds).toBe(2); // primary timer counts 2 seconds
        done();
    });

    it('2 seconds after \'hold-notification\' event, a second \'hold-notification\' event resets timers', done => {
        _createComponent(fullMock);
        component.$root.$emit('hold-notification');

        jasmine.clock().tick(2000);
        expect(component.secondaryTotalTimerSeconds).toBe(2); // primary timer counts 2 seconds

        component.$root.$emit('hold-notification');
        expect(component.secondaryInternalTimer).not.toBeDefined(); // secondary timer reset

        done();
    });
});
