import Vue from 'vue';
import ContractSummary from './ContractSummary.vue';
import DesktopBaseComponent from './DesktopBaseComponent.vue';

import DataStore from './../store/DataStore.js';
import {mockContract as fullMock} from './../store/mock/contract-summary/ContractMock.js';
import {mockContractSummaryLinks as summaryLinksMock} from './../store/mock/contract-summary/ContractSummaryLinksMock.js';

import CookieUtil from '../util/CookieUtil.js';

import assigndeep from 'assign-deep';

describe('ContractSummary', () => {
    let component;

    function _createComponent(model, summaryLinkModel) {
        const Constructor = Vue.extend(ContractSummary);

        // set the contract model object into the store
        DataStore.store.state.contracts = model;

        // build the component and mount it
        component = new Constructor({
            store: DataStore.store
        }).$mount();

        if (summaryLinkModel) {
            component.summaryLinks = summaryLinkModel;
        } else {
            component.summaryLinks = summaryLinksMock;
        }
    }

    beforeEach(() => {
        spyOn(DesktopBaseComponent.methods, 'refreshData').and.returnValue(1);
        spyOn(DesktopBaseComponent.methods, 'cacheSummaryLinks').and.returnValue(1);
    });

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
        CookieUtil.deleteCookies();
    });

    it('is named ContractSummary', () => {
        expect(ContractSummary.name).toEqual('ContractSummary');
    });

    it('has a method getData hook providing this components specific behavior when loading its data', () => {
        expect(typeof ContractSummary.methods.getData).toBe('function');
    });

    it('has a method clearData hook it providing this components specific behavior when clearing its data', () => {
        expect(typeof ContractSummary.methods.clearData).toBe('function');
    });

    it('has a computed subscriber hook', () => {
        expect(typeof ContractSummary.computed.subscriber).toBe('function');
    });

    it('has a computed contracts hook', () => {
        expect(typeof ContractSummary.computed.contracts).toBe('function');
    });

    it('displays nothing when there is no data', done => {
        _createComponent({});

        Vue.nextTick(() => {
            const body = component.$el;
            expect(body.innerText.trim()).toBe('');
            done();
        });
    });

    it('displays no coverage data message when there are no contracts', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [],
                DEN: [],
                DUG: []
            }
        }));

        Vue.nextTick(() => {
            const noContracts = component.$el.querySelectorAll('[data-test-ref=no-contract-data-found]');
            expect(noContracts.length).toEqual(1);
            expect(noContracts[0].innerText.trim()).toBe('No coverage data found.');
            done();
        });
    });

    it('displays no health coverage data message when there are no contracts and the subscriber is FEP', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: true
            }
        }));

        Vue.nextTick(() => {
            const noContracts = component.$el.querySelectorAll('[data-test-ref=no-contract-data-found]');
            expect(noContracts.length).toEqual(1);
            expect(noContracts[0].innerText.trim()).toBe('No health coverage data found.');
            done();
        });
    });

    it('displays FEP title if the subscriber is FEP', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                fep: true
            }
        }));

        Vue.nextTick(() => {
            const fepTitle = component.$el.querySelectorAll('[data-test-ref=fep-title]');
            expect(fepTitle.length).toEqual(1);
            expect(fepTitle[0].innerText).toBe('FEDERAL EMPLOYEE PROGRAM');
            done();
        });
    });

    it('displays all tabs correctly', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                FOO: []
            }
        }));

        Vue.nextTick(() => {
            const navTabsList = component.$el.querySelectorAll('[data-test-ref=nav-tabs]');
            expect(navTabsList.length).toEqual(1);

            const navLinks = navTabsList[0].querySelectorAll('.nav-link');
            expect(navLinks[0].innerText.trim()).toBe('Health');
            expect(navLinks[1].innerText.trim()).toBe('Dental');
            expect(navLinks[2].innerText.trim()).toBe('Drug');

            done();
        });
    });

    it('displays more than one health contract', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        coveragePeriod: {
                            endDate: '2003-06-01T00:00:00-0400',
                            startDate: '2002-06-01T00:00:00-0400'
                        }
                    },
                    {
                        coveragePeriod: {
                            endDate: '2006-08-01T00:00:00-0400',
                            startDate: '2005-08-01T00:00:00-0400'
                        }
                    }
                ],
                DEN: [],
                DUG: []
            }
        }));

        Vue.nextTick(() => {
            const coveragePeriodList = component.$el.querySelectorAll('[data-test-ref=coverage-period-link]');
            expect(coveragePeriodList.length).toEqual(2);

            expect(coveragePeriodList[0].innerText.trim()).toBe('06/01/2002 - 06/01/2003');
            expect(coveragePeriodList[1].innerText.trim()).toBe('08/01/2005 - 08/01/2006');

            done();
        });
    });

    it('displays coverage date links correctly', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        coveragePeriod: {
                            endDate: '2003-06-01T00:00:00-0400',
                            startDate: '2002-06-01T00:00:00-0400'
                        }
                    }
                ],
                DEN: [],
                DUG: []
            }
        }));

        Vue.nextTick(() => {
            const coveragePeriodList = component.$el.querySelectorAll('[data-test-ref=coverage-period-link]');
            expect(coveragePeriodList.length).toEqual(1);
            expect(coveragePeriodList[0].getAttribute('href')).toBe('https://scholar.google.ca/');
            expect(coveragePeriodList[0].getAttribute('target')).toBe('_blank');

            done();
        });
    });

    it('displays coverage date links correctly for FEP subscriber', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        coveragePeriod: {
                            endDate: '2003-06-01T00:00:00-0400',
                            startDate: '2002-06-01T00:00:00-0400'
                        }
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: true
            }
        }));

        Vue.nextTick(() => {
            const coveragePeriodList = component.$el.querySelectorAll('[data-test-ref=coverage-period-link-fep]');
            expect(coveragePeriodList.length).toEqual(1);
            expect(coveragePeriodList[0].getAttribute('href')).toBe('http://yippy.com');
            expect(coveragePeriodList[0].getAttribute('target')).toBe('_blank');

            done();
        });
    });

    it('displays coverage type for FEP subscriber', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: true
            }
        }));

        Vue.nextTick(() => {
            const contractTypeList = component.$el.querySelectorAll('[data-test-ref=contract-type-fep]');
            expect(contractTypeList.length).toEqual(1);
            expect(contractTypeList[0].innerText.trim()).toBe('FAMILY');

            done();
        });
    });

    it('displays employee status for FEP subscriber', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        employeeStatus: 'EMPLOYED'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: true
            }
        }));

        Vue.nextTick(() => {
            const employeeStatusList = component.$el.querySelectorAll('[data-test-ref=contract-employee-status-fep]');
            expect(employeeStatusList.length).toEqual(1);
            expect(employeeStatusList[0].innerText.trim()).toBe('EMPLOYED');

            done();
        });
    });

    it('does not display FEP coverage type when subscriber is not FEP', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const contractTypeList = component.$el.querySelectorAll('[data-test-ref=contract-type-fep]');
            expect(contractTypeList.length).toEqual(0);

            done();
        });
    });

    it('does not display FEP employee status when subscriber is not FEP', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const employeeStatusList = component.$el.querySelectorAll('[data-test-ref=contract-employee-status-fep]');
            expect(employeeStatusList.length).toEqual(0);

            done();
        });
    });

    it('displays benefit period links', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        }
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const benefitPeriodLinkList = component.$el.querySelectorAll('[data-test-ref=benefit-period-link]');
            expect(benefitPeriodLinkList.length).toEqual(1);
            expect(benefitPeriodLinkList[0].getAttribute('href')).toBe('https://www.webopedia.com/');
            expect(benefitPeriodLinkList[0].getAttribute('target')).toBe('_blank');

            done();
        });
    });

    it('does not display benefit period links for FEP subscriber', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        }
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: true
            }
        }));

        Vue.nextTick(() => {
            const benefitPeriodLinkList = component.$el.querySelectorAll('[data-test-ref=benefit-period-link]');
            expect(benefitPeriodLinkList.length).toEqual(0);

            done();
        });
    });

    it('displays pre existing when start and end date are available', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            endDate: '2003-04-01T00:00:00-0500',
                            startDate: '2002-04-01T00:00:00-0500'
                        }
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const preexistingConditionList = component.$el.querySelectorAll('[data-test-ref=pre-existing-period]');
            expect(preexistingConditionList.length).toEqual(1);
            expect(preexistingConditionList[0].innerText.trim()).toBe('04/01/2002 - 04/01/2003');

            done();
        });
    });

    it('does not display pre existing if end date is missing', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            // endDate: '2003-04-01T00:00:00-0500',
                            startDate: '2002-04-01T00:00:00-0500'
                        }
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const preexistingConditionList = component.$el.querySelectorAll('[data-test-ref=pre-existing-period]');
            expect(preexistingConditionList.length).toEqual(0);

            done();
        });
    });

    it('does not display pre existing if start date is missing', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            // startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        }
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const preexistingConditionList = component.$el.querySelectorAll('[data-test-ref=pre-existing-period]');
            expect(preexistingConditionList.length).toEqual(0);

            done();
        });
    });

    it('does not display pre existing for FEP subscriber', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            endDate: '2003-04-01T00:00:00-0500',
                            startDate: '2002-04-01T00:00:00-0500'
                        }
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: true
            }
        }));

        Vue.nextTick(() => {
            const preexistingConditionList = component.$el.querySelectorAll('[data-test-ref=pre-existing-period]');
            expect(preexistingConditionList.length).toEqual(0);

            done();
        });
    });

    it('displays contract type', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        }
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const contractTypeList = component.$el.querySelectorAll('[data-test-ref=contract-type]');
            expect(contractTypeList.length).toEqual(1);
            expect(contractTypeList[0].innerText.trim()).toBe('FAMILY');

            done();
        });
    });

    it('does not display contract type for FEP subscriber', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        }
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: true
            }
        }));

        Vue.nextTick(() => {
            const contractTypeList = component.$el.querySelectorAll('[data-test-ref=contract-type]');
            expect(contractTypeList.length).toEqual(0);

            done();
        });
    });

    it('displays service center link', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        serviceCenterName: 'MOHASCO'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const serviceCenterList = component.$el.querySelectorAll('[data-test-ref=service-center-link]');
            expect(serviceCenterList.length).toEqual(1);
            expect(serviceCenterList[0].innerText.trim()).toBe('MOHASCO');
            expect(serviceCenterList[0].getAttribute('href')).toBe('openServiceCenter()');
            expect(serviceCenterList[0].getAttribute('target')).toBe('_blank');

            done();
        });
    });

    it('does not display service center link for FEP subscriber', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        serviceCenterName: 'MOHASCO'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: true
            }
        }));

        Vue.nextTick(() => {
            const serviceCenterList = component.$el.querySelectorAll('[data-test-ref=service-center-link]');
            expect(serviceCenterList.length).toEqual(0);

            done();
        });
    });

    it('displays amms group name', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const ammsGroupNameList = component.$el.querySelectorAll('[data-test-ref=amms-group-name]');
            expect(ammsGroupNameList.length).toEqual(1);
            expect(ammsGroupNameList[0].innerText.trim()).toBe('TEST GROUP DO NOT USE');

            done();
        });
    });

    it('does not display amms group name for FEP subscriber', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: true
            }
        }));

        Vue.nextTick(() => {
            const ammsGroupNameList = component.$el.querySelectorAll('[data-test-ref=amms-group-name]');
            expect(ammsGroupNameList.length).toEqual(0);

            done();
        });
    });

    it('displays group verbiage', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const ammsGroupVerbiageList = component.$el.querySelectorAll('[data-test-ref=amms-group-verbiage]');
            expect(ammsGroupVerbiageList.length).toEqual(1);
            expect(ammsGroupVerbiageList[0].innerText.trim()).toBe('Group Verbiage Example');

            done();
        });
    });

    it('does not display group verbiage for FEP subscriber', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: true
            }
        }));

        Vue.nextTick(() => {
            const ammsGroupVerbiageList = component.$el.querySelectorAll('[data-test-ref=amms-group-verbiage]');
            expect(ammsGroupVerbiageList.length).toEqual(0);

            done();
        });
    });

    it('displays amms group code link', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example',
                        groupCode: '036011101'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const ammsGroupCodeLinkList = component.$el.querySelectorAll('[data-test-ref=amms-group-code-link]');
            expect(ammsGroupCodeLinkList.length).toEqual(1);
            expect(ammsGroupCodeLinkList[0].innerText.trim()).toBe('036011101');
            expect(ammsGroupCodeLinkList[0].getAttribute('href')).toBe('http://google.com');
            expect(ammsGroupCodeLinkList[0].getAttribute('target')).toBe('_blank');

            done();
        });
    });

    it('does not display amms group code link for FEP subscriber', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example',
                        groupCode: '036011101'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: true
            }
        }));

        Vue.nextTick(() => {
            const ammsGroupCodeLinkList = component.$el.querySelectorAll('[data-test-ref=amms-group-code-link]');
            expect(ammsGroupCodeLinkList.length).toEqual(0);

            done();
        });
    });

    it('displays found on link', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example',
                        groupCode: '036011101',
                        coverageSystem: 'CES'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const foundOnLinkList = component.$el.querySelectorAll('[data-test-ref=found-on-link]');
            expect(foundOnLinkList.length).toEqual(1);
            expect(foundOnLinkList[0].innerText.trim()).toBe('CES');
            expect(foundOnLinkList[0].getAttribute('href')).toBe('http://dogpile.com');
            expect(foundOnLinkList[0].getAttribute('target')).toBe('_blank');

            done();
        });
    });

    it('does not display found on link for FEP subscriber', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example',
                        groupCode: '036011101',
                        coverageSystem: 'CES'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: true
            }
        }));

        Vue.nextTick(() => {
            const foundOnLinkList = component.$el.querySelectorAll('[data-test-ref=found-on-link]');
            expect(foundOnLinkList.length).toEqual(0);

            done();
        });
    });

    it('displays ces group number', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example',
                        cesGroupNumber: '0000667'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const cesGroupNumberList = component.$el.querySelectorAll('[data-test-ref=ces-group-number]');
            expect(cesGroupNumberList.length).toEqual(1);
            expect(cesGroupNumberList[0].innerText.trim()).toBe('0000667');

            done();
        });
    });

    it('does not display ces group number for FEP subscriber', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example',
                        cesGroupNumber: '0000667'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: true
            }
        }));

        Vue.nextTick(() => {
            const cesGroupNumberList = component.$el.querySelectorAll('[data-test-ref=ces-group-number]');
            expect(cesGroupNumberList.length).toEqual(0);

            done();
        });
    });

    it('displays drug description when the drug description is available', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example',
                        cesGroupNumber: '0000667',
                        drugProcessingCode: {
                            code: 'Z',
                            description: 'ZERTEC'
                        }
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const drugDescriptionList = component.$el.querySelectorAll('[data-test-ref=drug-indicator-description]');
            expect(drugDescriptionList.length).toEqual(1);
            expect(drugDescriptionList[0].innerText.trim()).toBe('ZERTEC');

            done();
        });
    });

    it('does not display drug description when the drug description is available and subscriber is FEP', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example',
                        cesGroupNumber: '0000667',
                        drugProcessingCode: {
                            code: 'Z',
                            description: 'ZERTEC'
                        }
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: true
            }
        }));

        Vue.nextTick(() => {
            const drugDescriptionList = component.$el.querySelectorAll('[data-test-ref=drug-indicator-description]');
            expect(drugDescriptionList.length).toEqual(0);

            done();
        });
    });

    it('does not display drug description when the drug description is null', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example',
                        cesGroupNumber: '0000667',
                        drugProcessingCode: {
                            code: 'Z',
                            description: null
                        }
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const drugDescriptionList = component.$el.querySelectorAll('[data-test-ref=drug-indicator-description]');
            expect(drugDescriptionList.length).toEqual(0);

            done();
        });
    });

    it('displays format number', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example',
                        cesGroupNumber: '0000667',
                        drugProcessingCode: {
                            code: 'Z',
                            description: 'ZERTEC'
                        },
                        formatNumber: 'A FORMAT NUMBER'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const formatNumberList = component.$el.querySelectorAll('[data-test-ref=format-number]');
            expect(formatNumberList.length).toEqual(1);
            expect(formatNumberList[0].innerText.trim()).toBe('A FORMAT NUMBER');

            done();
        });
    });

    it('does not display format number for FEP subscriber', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example',
                        cesGroupNumber: '0000667',
                        drugProcessingCode: {
                            code: 'Z',
                            description: 'ZERTEC'
                        },
                        formatNumber: 'A FORMAT NUMBER'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: true
            }
        }));

        Vue.nextTick(() => {
            const formatNumberList = component.$el.querySelectorAll('[data-test-ref=format-number]');
            expect(formatNumberList.length).toEqual(0);

            done();
        });
    });

    it('displays plan code', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example',
                        cesGroupNumber: '0000667',
                        drugProcessingCode: {
                            code: 'Z',
                            description: 'ZERTEC'
                        },
                        formatNumber: 'A FORMAT NUMBER',
                        planCode: '885'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const formatNumberList = component.$el.querySelectorAll('[data-test-ref=plan-code]');
            expect(formatNumberList.length).toEqual(1);
            expect(formatNumberList[0].innerText.trim()).toBe('885');

            done();
        });
    });

    it('does not display plan code for FEP subscriber', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example',
                        cesGroupNumber: '0000667',
                        drugProcessingCode: {
                            code: 'Z',
                            description: 'ZERTEC'
                        },
                        formatNumber: 'A FORMAT NUMBER',
                        planCode: '885'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: true
            }
        }));

        Vue.nextTick(() => {
            const formatNumberList = component.$el.querySelectorAll('[data-test-ref=plan-code]');
            expect(formatNumberList.length).toEqual(0);

            done();
        });
    });

    it('displays exception records', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example',
                        groupCode: '036011101',
                        certificationExceptionRecords: [
                            {
                                ControlCode: {
                                    code: 55,
                                    description: '55_description'
                                },
                                patientId: '001',
                                deferral: 'deferral',
                                exceptionDescription: 'Description of this Exception 1',
                                patientName: 'Bob',
                                controlDate: '2018-04-01T00:00:00-0400',
                                alertExceptionIndicator: true,
                                contractLevelExceptionIndicator: true,
                                priority: 1
                            },
                            {
                                ControlCode: {
                                    code: 55,
                                    description: '55_description'
                                },
                                patientId: '001',
                                deferral: 'deferral',
                                exceptionDescription: 'Description of this Exception 1',
                                patientName: 'Bob',
                                controlDate: '2018-04-01T00:00:00-0400',
                                alertExceptionIndicator: true,
                                contractLevelExceptionIndicator: true,
                                priority: 1
                            }
                        ]
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const exceptionrecordList = component.$el.querySelectorAll('[data-test-ref=exception-record-title]');
            expect(exceptionrecordList.length).toEqual(2);

            done();
        });
    });

    it('does not display exception records when subscriber is FEP', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example',
                        groupCode: '036011101',
                        certificationExceptionRecords: [
                            {
                            },
                            {
                            }
                        ]
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: true
            }
        }));

        Vue.nextTick(() => {
            const exceptionrecordList = component.$el.querySelectorAll('[data-test-ref=exception-record-title]');
            expect(exceptionrecordList.length).toEqual(0);

            done();
        });
    });

    it('displays exception records with all expected data', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example',
                        groupCode: '036011101',
                        certificationExceptionRecords: [
                            {
                                ControlCode: {code: 55, description: 'a control code description 1.'},
                                patientId: '001',
                                deferral: 'deferral code 1',
                                exceptionDescription: 'Exception description 1',
                                patientName: 'MICHAEL TESTING',
                                controlDate: '2018-04-01T00:00:00-0400',
                                alertExceptionIndicator: true,
                                contractLevelExceptionIndicator: true,
                                priority: 1
                            },
                            {
                                ControlCode: {code: 23, description: 'a control code description 2.'},
                                patientId: '002',
                                deferral: 'deferral code 2',
                                exceptionDescription: 'Exception description 2',
                                patientName: 'TERRI TESTING',
                                controlDate: '2018-04-23T00:00:00-0400',
                                alertExceptionIndicator: true,
                                contractLevelExceptionIndicator: true,
                                priority: 2
                            }
                        ],
                        coverageSystem: 'CES'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const exceptionrecordList = component.$el.querySelectorAll('[data-test-ref=exception-record-title]');
            expect(exceptionrecordList.length).toEqual(2);

            const certificationDates = component.$el.querySelectorAll('[data-test-ref=exception-record-certification-date]');
            expect(certificationDates.length).toEqual(2);

            expect(certificationDates[0].innerText.trim()).toBe('04/01/2018');
            expect(certificationDates[1].innerText.trim()).toBe('04/23/2018');

            const patientNames = component.$el.querySelectorAll('[data-test-ref=exception-record-patient-name]');
            expect(patientNames.length).toEqual(2);
            expect(patientNames[0].innerText.trim()).toBe('MICHAEL TESTING');
            expect(patientNames[1].innerText.trim()).toBe('TERRI TESTING');

            const exceptionDescriptions = component.$el.querySelectorAll('[data-test-ref=exception-record-exception-description]');
            expect(exceptionDescriptions.length).toEqual(2);
            expect(exceptionDescriptions[0].innerText.trim()).toBe('Exception description 1');
            expect(exceptionDescriptions[1].innerText.trim()).toBe('Exception description 2');

            done();
        });
    });

    it('displays exception information for CES membership information', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example',
                        groupCode: '036011101',
                        certificationExceptionRecords: [
                            {
                                ControlCode: {code: 55, description: 'a control code description 1.'},
                                patientId: '001',
                                exceptionDescription: 'Exception description 1',
                                patientName: 'MICHAEL TESTING',
                                controlDate: '2018-04-01T00:00:00-0400'
                            },
                            {
                                ControlCode: {code: 23, description: 'a control code description 2.'},
                                patientId: '002',
                                exceptionDescription: 'Exception description 2',
                                patientName: 'TERRI TESTING',
                                controlDate: '2018-04-23T00:00:00-0400'
                            }
                        ],
                        coverageSystem: 'CES'
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const exceptionrecordList = component.$el.querySelectorAll('[data-test-ref=exception-record-title]');
            expect(exceptionrecordList.length).toEqual(2);

            const emulatorLinks = component.$el.querySelectorAll('[data-test-ref=exception-record-emulator-link]');
            expect(emulatorLinks.length).toEqual(2);
            expect(emulatorLinks[0].getAttribute('href')).toBe('http://amazon.com');
            expect(emulatorLinks[1].getAttribute('href')).toBe('http://amazon.com');

            const patientNames = component.$el.querySelectorAll('[data-test-ref=exception-record-patient-name-has]');
            expect(patientNames.length).toEqual(2);
            expect(patientNames[0].innerText.trim()).toBe('HAS');
            expect(patientNames[1].innerText.trim()).toBe('HAS');

            const hasLinks = component.$el.querySelectorAll('[data-test-ref=exception-record-exception-description]');
            expect(hasLinks.length).toEqual(2);
            expect(hasLinks[0].innerText.trim()).toBe('Exception description 1');
            expect(hasLinks[1].innerText.trim()).toBe('Exception description 2');

            done();
        });
    });

    it('does not display exception description when not CES', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY',
                        employeeStatus: 'EMPLOYED',
                        currentBenefitPeriod: {
                            end: '04/01',
                            start: '04/01'
                        },
                        preexistingPeriod: {
                            startDate: '2002-04-01T00:00:00-0500',
                            endDate: '2003-04-01T00:00:00-0500'
                        },
                        groupName: 'TEST GROUP DO NOT USE',
                        groupVerbiage: 'Group Verbiage Example',
                        groupCode: '036011101',
                        certificationExceptionRecords: [
                            {
                                ControlCode: {
                                    code: 55,
                                    description: '55_description'
                                },
                                patientId: '001',
                                deferral: 'deferral',
                                exceptionDescription: 'Description of this Exception 1',
                                patientName: 'Bob',
                                controlDate: '2018-04-01T00:00:00-0400',
                                alertExceptionIndicator: true,
                                contractLevelExceptionIndicator: true,
                                priority: 1
                            },
                            {
                                ControlCode: {
                                    code: 55,
                                    description: '55_description'
                                },
                                patientId: '001',
                                deferral: 'deferral',
                                exceptionDescription: 'Description of this Exception 1',
                                patientName: 'Bob',
                                controlDate: '2018-04-01T00:00:00-0400',
                                alertExceptionIndicator: true,
                                contractLevelExceptionIndicator: true,
                                priority: 1
                            }
                        ]
                    }
                ],
                DEN: [],
                DUG: []
            },
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const exceptionrecordList = component.$el.querySelectorAll('[data-test-ref=exception-record-title]');
            expect(exceptionrecordList.length).toEqual(2);

            const exceptionDescriptions = component.$el.querySelectorAll('[data-test-ref=exception-record-exception-description]');
            expect(exceptionDescriptions.length).toEqual(0);

            done();
        });
    });

    it('displays eligibility and benefits link', done => {
        const newObj =
            {
                contracts: {
                    MED: [
                        {
                            type: 'FAMILY'
                        }
                    ]
                },
                subscriber: {
                    fep: false
                }
            };

        _createComponent(newObj);

        Vue.nextTick(() => {
            const eligAndBeneLinkList = component.$el.querySelectorAll('[data-test-ref=eligibility-and-benefits-link]');
            expect(eligAndBeneLinkList.length).toEqual(1);
            expect(eligAndBeneLinkList[0].innerText.trim()).toBe('Eligibility and Benefits');
            expect(eligAndBeneLinkList[0].getAttribute('href')).toBe('openEligibility()');
            expect(eligAndBeneLinkList[0].getAttribute('target')).toBe('_blank');

            done();
        });
    });

    it('displays coverage information link', done => {
        const newObj =
            {
                contracts: {
                    MED: [
                        {
                            type: 'FAMILY'
                        }
                    ]
                },
                subscriber: {
                    ces: true,
                    fep: false
                }
            };
        _createComponent(newObj);

        Vue.nextTick(() => {
            const coverageInformationLinkList = component.$el.querySelectorAll('[data-test-ref=coverage-information-link]');
            expect(coverageInformationLinkList.length).toEqual(1);
            expect(coverageInformationLinkList[0].innerText.trim()).toBe('Coverage Information');
            expect(coverageInformationLinkList[0].getAttribute('href')).toBe('https://scholar.google.ca/');
            expect(coverageInformationLinkList[0].getAttribute('target')).toBe('_blank');

            done();
        });
    });

    it('displays benefit booklet link', done => {
        const newObj =
            {
                contracts: {
                    MED: [
                        {
                            type: 'FAMILY',
                            status: 'YES'
                        }
                    ]
                },
                subscriber: {
                    ces: true,
                    fep: false
                }
            };

        _createComponent(newObj);

        Vue.nextTick(() => {
            const benefitBookletLinkList = component.$el.querySelectorAll('[data-test-ref=benefit-booklet-link]');
            expect(benefitBookletLinkList.length).toEqual(1);
            expect(benefitBookletLinkList[0].innerText.trim()).toBe('Benefit Documents');
            expect(benefitBookletLinkList[0].getAttribute('href')).toBe('openImagesSearch(\'BENEFIT_DOCUMENTS\')');
            expect(benefitBookletLinkList[0].getAttribute('target')).toBe('_blank');

            done();
        });
    });

    it('ensure refreshData() calls component.getData()', done => {
        jasmine.getEnv().allowRespy(true);

        const getDataSpy = spyOn(ContractSummary.methods, 'getData').and.callThrough();
        const refreshDataSpy = spyOn(DesktopBaseComponent.methods, 'refreshData').and.callFake(() => {
            ContractSummary.methods.getData().then(() => {
            });
        });

        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY'
                    }
                ]
            }
        }));

        DesktopBaseComponent.methods.refreshData(true);

        Vue.nextTick(() => {
            expect(refreshDataSpy).toHaveBeenCalled();
            expect(getDataSpy).toHaveBeenCalled();

            done();
        });
    });

    it('ensure refreshData() calls component.clearData()', done => {
        jasmine.getEnv().allowRespy(true);

        const clearDataSpy = spyOn(ContractSummary.methods, 'clearData').and.returnValue(1);
        const refreshDataSpy = spyOn(DesktopBaseComponent.methods, 'refreshData').and.callFake(() => {
            ContractSummary.methods.clearData();
        });

        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY'
                    }
                ]
            }
        }));

        DesktopBaseComponent.methods.refreshData(true);

        Vue.nextTick(() => {
            expect(refreshDataSpy).toHaveBeenCalled();
            expect(clearDataSpy).toHaveBeenCalled();

            done();
        });
    });

    it('ensure refreshData() is called when databaseId is updated', done => {
        _createComponent(assigndeep({}, fullMock, {
            contracts: {
                MED: [
                    {
                        type: 'FAMILY'
                    }
                ]
            }
        }));

        jasmine.getEnv().allowRespy(true);
        const refreshDataSpy = spyOn(component, 'refreshData').and.returnValue(1);

        component.$store.dispatch('setDatabaseId', '99');

        Vue.nextTick(() => {
            expect(refreshDataSpy).toHaveBeenCalled();
            done();
        });
    });

    it('displays correct tab when default view is set', done => {
        document.cookie = 'com.bcbssc.desktop.DefaultCoverageType=Dental';

        _createComponent(fullMock);

        Vue.nextTick(() => {
            const navTabsList = component.$el.querySelectorAll('[data-test-ref="nav-tabs"]');
            expect(navTabsList.length).toEqual(1);

            const navLinks = navTabsList[0].querySelectorAll('.nav-link');
            expect(navLinks[0].getAttribute('aria-selected')).toBe('false'); // Health
            expect(navLinks[1].getAttribute('aria-selected')).toBe('true'); // Dental
            expect(navLinks[2].getAttribute('aria-selected')).toBe('false'); // Drug
            done();
        });
    });
});
