<template>
    <section
        class="app-section-contract-summary"
        aria-label="Contract Summary">
        <template v-if="contracts && subscriber">
            <template v-if="(!contracts.MED || contracts.MED.length === 0) && (!contracts.DEN || contracts.DEN.length === 0) && (!contracts.DUG || contracts.DUG.length === 0)">
                <b-alert
                    variant="warning"
                    data-test-ref="no-contract-data-found"
                    show>
                    No<template v-if="subscriber.fep"> health</template> coverage data found.
                </b-alert>
            </template>
            <template v-else>
                <p
                    v-if="subscriber.fep"
                    data-test-ref="fep-title">FEDERAL EMPLOYEE PROGRAM</p>

                <b-tabs
                    nav-class="nav-justified nav-icons"
                    data-test-ref="nav-tabs">
                    <b-tab
                        v-for="(contract, contractName) in contracts"
                        :key="contractName"
                        :active="isTabActive(lookupTitle(contractName))"
                        :id="lookupTitle(contractName)"
                        fluid>
                        <template slot="title">
                            <span :class="'fa fa-csm-contract-' + lookupTitle(contractName).toLowerCase()"></span>
                            {{ lookupTitle(contractName) }}
                        </template>
                        <b-card
                            v-for="(contract, index) in contracts[contractName]"
                            :key="index"
                            role="section"
                            class="card-summary-section">
                            <template
                                v-if="contract && contract.coveragePeriod && contract.coveragePeriod.startDate"
                                slot="header">
                                <span :class="'fa fa-csm-contract-status-' + contractStatus(contract)"></span>
                                <h2>
                                    COVERAGE DATE
                                    <template v-if="subscriber.fep">
                                        <template v-if="findSummaryLink('fep-member-info')">
                                            <b-link
                                                :href="findSummaryLink('fep-member-info').transaction"
                                                data-test-ref="coverage-period-link-fep"
                                                target="_blank">
                                                <template v-if="contract.coveragePeriod.endDate">{{ contract.coveragePeriod.startDate | moment }}>
                                                    <span>{{ contract.coveragePeriod.startDate | moment }} - {{ contract.coveragePeriod.endDate | moment }}</span>
                                                </template>

                                                <template v-else>
                                                    <span>{{ contract.coveragePeriod.startDate | moment }}</span>
                                                </template>
                                            </b-link>
                                        </template>
                                    </template>
                                    <template v-else>
                                        <template v-if="findSummaryLink('coverage-info')">
                                            <b-link
                                                :href="findSummaryLink('coverage-info').transaction"
                                                data-test-ref="coverage-period-link"
                                                target="_blank">
                                                <template v-if="contract.coveragePeriod.endDate">
                                                    <span>{{ contract.coveragePeriod.startDate | moment }} - {{ contract.coveragePeriod.endDate | moment }}</span>
                                                </template>
                                                <template v-else>
                                                    <span>{{ contract.coveragePeriod.startDate | moment }}</span>
                                                </template>
                                            </b-link>
                                        </template>
                                    </template>
                                </h2>
                            </template>
                            <b-container
                                fluid
                                class="p-0">
                                <b-row class="row-divider">
                                    <b-col cols="8">
                                        <dl class="definition-list definition-list-lines">
                                            <template v-if="subscriber.fep">
                                                <template v-if="contract.type">
                                                    <dt>
                                                        Contract Type
                                                    </dt>
                                                    <dd data-test-ref="contract-type-fep">{{ contract.type }}</dd>
                                                </template>
                                                <template v-if="contract.employeeStatus">
                                                    <dt>
                                                        Employment Status
                                                    </dt>
                                                    <dd data-test-ref="contract-employee-status-fep">{{ contract.employeeStatus }}</dd>
                                                </template>
                                            </template>

                                            <template v-else>
                                                <template v-if="contract.currentBenefitPeriod && contract.currentBenefitPeriod.start && contract.currentBenefitPeriod.end">
                                                    <dt>
                                                        Benefit Period
                                                    </dt>
                                                    <dd>
                                                        <template v-if="findSummaryLink('benefit-period')">
                                                            <b-link
                                                                :href="findSummaryLink('benefit-period').transaction"
                                                                data-test-ref="benefit-period-link"
                                                                target="_blank">{{ contract.currentBenefitPeriod.start }} - {{ contract.currentBenefitPeriod.end }}
                                                            </b-link>
                                                        </template>
                                                    </dd>
                                                </template>

                                                <template v-if="contract.preexistingPeriod && contract.preexistingPeriod.startDate && contract.preexistingPeriod.endDate">
                                                    <dt>
                                                        Preexisting
                                                    </dt>
                                                    <dd data-test-ref="pre-existing-period">{{ contract.preexistingPeriod.startDate | moment }} - {{ contract.preexistingPeriod.endDate | moment }}</dd>
                                                </template>

                                                <template v-if="contract.type">
                                                    <dt>
                                                        Contract Type
                                                    </dt>
                                                    <dd data-test-ref="contract-type">{{ contract.type }}</dd>
                                                </template>

                                                <template v-if="contract.serviceCenterName">
                                                    <dt>
                                                        Service Center
                                                    </dt>
                                                    <dd data-test-ref="service-center-name">
                                                        <b-link
                                                            href="openServiceCenter()"
                                                            target="_blank"
                                                            data-test-ref="service-center-link">{{ contract.serviceCenterName }}
                                                        </b-link>
                                                    </dd>
                                                </template>

                                                <template v-if="contract.groupName">
                                                    <dt>
                                                        AMMS Group Name
                                                    </dt>
                                                    <dd data-test-ref="amms-group-name">{{ contract.groupName }}</dd>
                                                </template>

                                                <template v-if="contract.groupVerbiage">
                                                    <dt>
                                                        &nbsp;
                                                    </dt>
                                                    <dd data-test-ref="amms-group-verbiage">{{ contract.groupVerbiage }}</dd>
                                                </template>

                                                <template v-if="contract.groupCode">
                                                    <dt>
                                                        AMMS Group Number
                                                    </dt>
                                                    <dd>
                                                        <template v-if="findSummaryLink('amms-group-lookup')">
                                                            <b-link
                                                                :href="findSummaryLink('amms-group-lookup').transaction"
                                                                target="_blank"
                                                                data-test-ref="amms-group-code-link">{{ contract.groupCode }}
                                                            </b-link>
                                                        </template>
                                                    </dd>
                                                </template>

                                                <template
                                                    v-for="(exceptionRecord, index) in contract.certificationExceptionRecords">
                                                    <template v-if="exceptionRecord.controlDate && exceptionRecord.exceptionDescription">
                                                        <dt
                                                            :key="contractName + index + '_title'"
                                                            data-test-ref="exception-record-title">
                                                            Certification Date
                                                        </dt>
                                                        <dd :key="contractName + index + '_description'">
                                                            <div
                                                                data-test-ref="exception-record-certification-date">{{ exceptionRecord.controlDate | moment }}
                                                            </div>
                                                            <div
                                                                v-if="exceptionRecord.patientName"
                                                                data-test-ref="exception-record-patient-name">{{ exceptionRecord.patientName }}
                                                            </div>
                                                            <template
                                                                v-if="contract.coverageSystem === 'CES' && findSummaryLink('coordination-of-benefits')">
                                                                <b-link
                                                                    :href="findSummaryLink('coordination-of-benefits').transaction"
                                                                    data-test-ref="exception-record-emulator-link"
                                                                    target="_blank">
                                                                    <span
                                                                        v-if="exceptionRecord.patientName"
                                                                        data-test-ref="exception-record-patient-name-has">
                                                                        HAS
                                                                    </span>
                                                                    <span
                                                                        data-test-ref="exception-record-exception-description">
                                                                        {{ exceptionRecord.exceptionDescription }}
                                                                    </span>
                                                                </b-link>
                                                            </template>
                                                        </dd>
                                                    </template>
                                                </template>
                                                <template v-if="contract.coverageSystem">
                                                    <dt>
                                                        Found On
                                                    </dt>
                                                    <dd>
                                                        <template v-if="findSummaryLink('memb-system')">
                                                            <b-link
                                                                :href="findSummaryLink('memb-system').transaction"
                                                                target="_blank"
                                                                data-test-ref="found-on-link">{{ contract.coverageSystem }}
                                                            </b-link>
                                                        </template>
                                                    </dd>
                                                </template>

                                                <template v-if="contract.cesGroupNumber">
                                                    <dt>
                                                        CES Group Number
                                                    </dt>
                                                    <dd data-test-ref="ces-group-number">{{ contract.cesGroupNumber }}
                                                    </dd>
                                                </template>

                                                <template v-if="contract && contract.drugProcessingCode && contract.drugProcessingCode.description">
                                                    <dt>
                                                        Drug Indicator
                                                    </dt>
                                                    <dd data-test-ref="drug-indicator-description">{{ contract.drugProcessingCode.description }}
                                                    </dd>
                                                </template>

                                                <template v-if="contract.formatNumber">
                                                    <dt>
                                                        Format Number
                                                    </dt>
                                                    <dd data-test-ref="format-number">{{ contract.formatNumber }}
                                                    </dd>
                                                </template>

                                                <template v-if="contract.planCode">
                                                    <dt>
                                                        Plan Code
                                                    </dt>
                                                    <dd data-test-ref="plan-code">{{ contract.planCode }}
                                                    </dd>
                                                </template>
                                            </template>
                                        </dl>
                                    </b-col>
                                    <b-col cols="4">
                                        <nav>
                                            <b-link
                                                href="openImagesSearch('BENEFIT_DOCUMENTS')"
                                                data-test-ref="benefit-booklet-link"
                                                target="_blank">
                                                Benefit Documents
                                            </b-link><br>
                                            <template v-if="subscriber.ces && contract.status !== 'NO' && findSummaryLink('coverage-info')">
                                                <b-link
                                                    :href="findSummaryLink('coverage-info').transaction"
                                                    data-test-ref="coverage-information-link"
                                                    target="_blank">
                                                    Coverage Information
                                                </b-link><br>
                                            </template>
                                            <b-link
                                                href="openEligibility()"
                                                data-test-ref="eligibility-and-benefits-link"
                                                target="_blank">
                                                Eligibility and Benefits
                                            </b-link>
                                        </nav>
                                    </b-col>
                                </b-row>
                            </b-container>
                        </b-card>
                    </b-tab>
                </b-tabs>
            </template>
        </template>
        <template v-else>
            &nbsp;
        </template>
    </section>
</template>

<script>
import DesktopBaseComponent from './DesktopBaseComponent.vue';
import CookieUtil from '../util/CookieUtil.js';

export default {
    name: 'ContractSummary',
    extends: DesktopBaseComponent,
    data: () => {
        return {
            defaultContractView: 'Health'
        };
    },
    computed: {
        /**
         * A computed property to determine if there is an error.
         */
        hasError() {
            return this.error;
        },
        /**
         * A computed property to get the current database id
         */
        databaseId() {
            return this.$store.getters.getDatabaseId;
        },
        /**
         * A computed property for contracts
         */
        contracts() {
            let contracts = null;
            if (this.$store.getters.getContracts) {
                contracts = this.$store.getters.getContracts.contracts;
            }
            return contracts;
        },
        /**
         * A computed property for subscriber
         */
        subscriber() {
            let subscriber = null;
            if (this.$store.getters.getContracts) {
                subscriber = this.$store.getters.getContracts.subscriber;
            }
            return subscriber;
        }
    },
    /** @lends app.components.ContractSummary.prototype */
    watch: {
        /**
         * When the database id is changed, go get the data.
         */
        databaseId() {
            this.refreshData(true);
        }
    },
    created() {
        const coverage = CookieUtil.getDefaultCoverageCookie(document);
        if (coverage) {
            this.defaultContractView = coverage;
        } else {
            console.log('No contract cookie found.  Defaulting to: ' + this.defaultContractView);
        }
    },
    /** @lends app.components.ContractSummary.prototype */
    methods: {
        /**
         * get Contract(s)
         */
        getData() {
            // if the database id is provided, go get the contracts
            if (this.databaseId) {
                return this.$store.dispatch('retrieveContracts', {memberKeyId: this.databaseId});
            }
            // with no database id, return a promise that immediately resolves
            return Promise.resolve();
        },
        /**
         * clear data
         */
        clearData() {
            this.$store.dispatch('clearContracts');
        },
        /**
         * Return the product description using a business product key.
         * @return product description
         */
        lookupTitle(contractName) {
            let description = null;

            switch (contractName) {
            case 'MED':
                description = 'Health';
                break;
            case 'DEN':
                description = 'Dental';
                break;
            case 'DUG':
                description = 'Drug';
                break;
            default:
                description = '';
            }

            return description;
        },
        /**
         * Returns true or false based on the default tab
         *
         * @param {name} name The name of the tab to check if it is active
         */
        isTabActive(name) {
            if (name === this.defaultContractView) {
                return true;
            }
            return false;
        },
        /**
         * Returns lowercase contract status
         *
         * @param {Contract} contract The contract definition
         */
        contractStatus(contract) {
            let contractStatus = '';

            if (contract) {
                if (contract.futureContract) {
                    contractStatus = 'future';
                } else if (contract.status) {
                    contractStatus = contract.status;
                }
            }
            return contractStatus.toLowerCase();
        }
    }
};
</script>
