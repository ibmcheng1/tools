import Vue from 'vue';
import SubscriberSummary from './SubscriberSummary.vue';
import DesktopBaseComponent from './DesktopBaseComponent.vue';
import DataStore from './../store/DataStore.js';
import {mockSubscriber as fullMock} from './../store/mock/subscriber-summary/SubscriberMock.js';
import {mockSubscriberSummaryLinks as summaryLinksMock} from './../store/mock/subscriber-summary/SubscriberSummaryLinksMock.js';
import {mockSubscriberSummaryLinks as mbrSummaryLinksMock} from './../store/mock/subscriber-summary/MBR-SubscriberSummaryLinksMock.js';

import assigndeep from 'assign-deep';

describe('SubscriberSummary', () => {
    let component;

    function _createComponent(model, summaryLinkModel) {
        const Constructor = Vue.extend(SubscriberSummary);

        // set the subscriber model object into the store
        DataStore.store.state.subscriber = model;

        // build the component and mount it
        component = new Constructor({
            store: DataStore.store
        }).$mount();

        if (summaryLinkModel) {
            component.summaryLinks = summaryLinkModel;
        } else {
            component.summaryLinks = summaryLinksMock;
        }
    }

    beforeEach(() => {
        // prevent the component from trying to load a subscriber or summary links
        spyOn(DesktopBaseComponent.methods, 'refreshData').and.returnValue(1);
        spyOn(DesktopBaseComponent.methods, 'cacheSummaryLinks').and.returnValue(1);
    });

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('is named SubscriberSummary', () => {
        expect(SubscriberSummary.name).toEqual('SubscriberSummary');
    });

    it('has a computed subscriber hook', () => {
        expect(typeof SubscriberSummary.computed.subscriber).toBe('function');
    });

    it('has a computed address hook', () => {
        expect(typeof SubscriberSummary.computed.address).toBe('function');
    });

    it('has a computed accountInformation hook', () => {
        expect(typeof SubscriberSummary.computed.accountInformation).toBe('function');
    });

    it('has a computed agent hook', () => {
        expect(typeof SubscriberSummary.computed.agent).toBe('function');
    });

    it('has a computed agency hook', () => {
        expect(typeof SubscriberSummary.computed.agency).toBe('function');
    });

    // subscriber name
    it('has displayed name', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const name = component.$el.querySelectorAll('[data-test-ref="subscriber-name"]')[0];
            // there should be only one name
            expect(name).toBeTruthy();
            // the value should be 'MICHAEL A TESTING'
            expect(name.innerText.trim()).toBe('MICHAEL A TESTING');
            done();
        });
    });

    it('has hidden name with no values', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                name: {
                    firstName: null,
                    middleName: null,
                    lastName: null
                }
            }
        }));

        Vue.nextTick(() => {
            const name = component.$el.querySelectorAll('[data-test-ref="subscriber-name"]')[0];
            // there should be no name field
            expect(name).toBeUndefined();
            done();
        });
    });

    // address lines
    it('has displayed address lines (only one)', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const addressLine = component.$el.querySelectorAll('[data-test-ref="address-line"]');
            // there should be only one addressLine
            expect(addressLine.length).toEqual(1);
            // the value should be 'P O BOX  24015'
            expect(addressLine[0].innerText.trim()).toBe('P O BOX  24015');
            done();
        });
    });

    it('has displayed address lines (more than one)', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                address: {
                    address1: 'PO BOX 654897',
                    address2: 'C/O ROLD GOLD'
                }
            }
        }));

        Vue.nextTick(() => {
            const addressLines = component.$el.querySelectorAll('[data-test-ref="address-line"]');
            // there should be two address lines
            expect(addressLines.length).toEqual(2);
            // the value should be 'PO BOX 654897'
            expect(addressLines[0].innerText.trim()).toBe('PO BOX 654897');
            expect(addressLines[1].innerText.trim()).toBe('C/O ROLD GOLD');
            done();
        });
    });

    // city, state, zip
    it('has displayed city, state, zip', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const cityStateZip = component.$el.querySelectorAll('[data-test-ref="city-state-zip"]');
            expect(cityStateZip.length).toEqual(1);
            expect(cityStateZip[0].innerText.trim()).toBe('COLUMBIA, SC 29224 4015');
            done();
        });
    });

    it('does not display city, state, zip with no data', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                address: {
                    city: null,
                    state: null,
                    zip: null
                }
            }
        }));

        Vue.nextTick(() => {
            const cityStateZip = component.$el.querySelectorAll('[data-test-ref="city-state-zip"]');
            expect(cityStateZip.length).toEqual(0);
            done();
        });
    });

    // county-code info
    it('has displayed county-code', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const county = component.$el.querySelectorAll('[data-test-ref="county-code-description"]');
            expect(county.length).toEqual(1);
            expect(county[0].innerText).toContain('040');
            done();
        });
    });

    it('has displayed county-code with no information', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                address: {
                    countyCode: {
                        code: ''
                    }
                }
            }
        }));

        Vue.nextTick(() => {
            const county = component.$el.querySelectorAll('[data-test-ref="county-code-description"]');
            expect(county.length).toEqual(1);
            expect(county[0].innerText.trim()).toBe('- RICHLAND');
            done();
        });
    });

    // county-description info
    it('has displayed county-description', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const county = component.$el.querySelectorAll('[data-test-ref="county-code-description"]');
            expect(county.length).toEqual(1);
            expect(county[0].innerText).toContain(' - RICHLAND');
            done();
        });
    });

    it('has displayed county-description with no information', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                address: {
                    countyCode: {
                        description: null
                    }
                }
            }
        }));

        Vue.nextTick(() => {
            const county = component.$el.querySelectorAll('[data-test-ref="county-code-description"]');
            expect(county.length).toEqual(1);
            expect(county[0].innerText).toContain(' - UNKNOWN');
            done();
        });
    });

    // phone number
    it('has displayed phone-number', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const phoneNumber = component.$el.querySelectorAll('[data-test-ref="phone-number"]');
            expect(phoneNumber.length).toEqual(1);
            expect(phoneNumber[0].innerText.trim()).toBe('(803) 456-4564');
            done();
        });
    });

    it('has no displayed phone-number when no phone number is available', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                phone: null
            }
        }));

        Vue.nextTick(() => {
            const phoneNumber = component.$el.querySelectorAll('[data-test-ref="phone-number"]');
            expect(phoneNumber.length).toEqual(0);
            done();
        });
    });

    it('has no displayed phone-number when the phone number is empty', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                phone: {
                    areaCode: null,
                    prefix: null,
                    suffix: null
                }
            }
        }));

        Vue.nextTick(() => {
            const phoneNumber = component.$el.querySelectorAll('[data-test-ref="phone-number"]');
            expect(phoneNumber.length).toEqual(0);
            done();
        });
    });

    // more phone numbers
    it('has displayed more indicator when extra phone numbers are available', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const morePhoneNumbers = component.$el.querySelectorAll('[data-test-ref="more-phone-numbers"]');
            expect(morePhoneNumbers.length).toEqual(1);
            expect(morePhoneNumbers[0].innerText.trim()).toBe('(see more)');
            expect(morePhoneNumbers[0].getAttribute('data-original-title')).toBe(fullMock.phoneToolTipString);
            done();
        });
    });

    it('has no displayed more indicator when no primary phone number is available', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                phone: null
            }
        }));

        Vue.nextTick(() => {
            const morePhoneNumbers = component.$el.querySelectorAll('[data-test-ref="more-phone-numbers"]');
            expect(morePhoneNumbers.length).toEqual(0);
            done();
        });
    });

    it('has no displayed more indicator when the primary phone number is empty', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                phone: {
                    areaCode: null,
                    prefix: null,
                    suffix: null
                }
            }
        }));

        Vue.nextTick(() => {
            const morePhoneNumbers = component.$el.querySelectorAll('[data-test-ref="more-phone-numbers"]');
            expect(morePhoneNumbers.length).toEqual(0);
            done();
        });
    });

    it('has no displayed more indicator when extra phone numbers are not available', done => {
        _createComponent(assigndeep({}, fullMock, {
            phoneToolTipString: null
        }));

        Vue.nextTick(() => {
            const morePhoneNumbers = component.$el.querySelectorAll('[data-test-ref="more-phone-numbers"]');
            expect(morePhoneNumbers.length).toEqual(0);
            done();
        });
    });

    it('has no displayed more indicator when extra phone numbers are empty', done => {
        _createComponent(assigndeep({}, fullMock, {
            phoneToolTipString: ''
        }));

        Vue.nextTick(() => {
            const morePhoneNumbers = component.$el.querySelectorAll('[data-test-ref="more-phone-numbers"]');
            expect(morePhoneNumbers.length).toEqual(0);
            done();
        });
    });

    // service center info
    it('has displayed service-center', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const serviceCenter = component.$el.querySelectorAll('[data-test-ref="service-center"]');
            expect(serviceCenter.length).toEqual(1);
            expect(serviceCenter[0].innerText).toBe('MOHASCO');
            done();
        });
    });

    it('has displayed service-center with no information', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                serviceCenter: {
                    description: null
                }
            }
        }));

        Vue.nextTick(() => {
            const serviceCenter = component.$el.querySelectorAll('[data-test-ref="service-center"]');
            expect(serviceCenter.length).toEqual(1);
            expect(serviceCenter[0].innerText.trim()).toBe('No Information Found');
            done();
        });
    });

    // id card number info
    it('has displayed id-card-number', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const idCardNumber = component.$el.querySelectorAll('[data-test-ref="id-card-number"]');
            expect(idCardNumber.length).toEqual(1);
            expect(idCardNumber[0].innerText.trim()).toBe('ZCZ065922516805');
            done();
        });
    });

    it('has displayed id-card-number with no ces information', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                ces: false
            }
        }));

        Vue.nextTick(() => {
            const idCardNumber = component.$el.querySelectorAll('[data-test-ref="id-card-number"]');
            expect(idCardNumber.length).toEqual(1);
            expect(idCardNumber[0].innerText.trim()).toBe('065922516805');
            done();
        });
    });

    it('has displayed id-card-number with no information', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                idCardNumber: null
            }
        }));

        Vue.nextTick(() => {
            const idCardNumber = component.$el.querySelectorAll('[data-test-ref="id-card-number"]');
            expect(idCardNumber.length).toEqual(1);
            expect(idCardNumber[0].innerText.trim()).toBe('');
            done();
        });
    });

    // last id card issue date info
    it('has displayed last-id-card-issue-date', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const lastIdCardIssueDate = component.$el.querySelectorAll('[data-test-ref="last-id-card-issue-date"]');
            expect(lastIdCardIssueDate.length).toEqual(1);
            expect(lastIdCardIssueDate[0].innerText.trim()).toBe('05/10/2018');
            done();
        });
    });

    it('has displayed last-id-card-issue-date with no information', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                lastIdCardIssueDate: null
            }
        }));

        Vue.nextTick(() => {
            const lastIdCardIssueDate = component.$el.querySelectorAll('[data-test-ref="last-id-card-issue-date"]');
            expect(lastIdCardIssueDate.length).toEqual(1);
            expect(lastIdCardIssueDate[0].innerText.trim()).toBe('');
            done();
        });
    });

    // birthdate info
    it('has displayed birthdate', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const birthdate = component.$el.querySelectorAll('[data-test-ref="birthdate"]');
            expect(birthdate.length).toEqual(1);
            expect(birthdate[0].innerText.trim()).toBe('10/01/1958');
            done();
        });
    });

    it('has displayed birthdate with no information', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                birthdate: null
            }
        }));

        Vue.nextTick(() => {
            const birthdate = component.$el.querySelectorAll('[data-test-ref="birthdate"]');
            expect(birthdate.length).toEqual(1);
            expect(birthdate[0].innerText.trim()).toBe('UNKNOWN');
            done();
        });
    });

    // account payment options info
    it('has displayed payment-option', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const paymentOption = component.$el.querySelectorAll('[data-test-ref="payment-option"]');
            expect(paymentOption.length).toEqual(1);
            expect(paymentOption[0].innerText).toBe('None');
            done();
        });
    });

    it('has displayed payment-option with no information', done => {
        _createComponent(assigndeep({}, fullMock, {
            financialAccount: {
                accountStatus: null
            }
        }));

        Vue.nextTick(() => {
            const paymentOption = component.$el.querySelectorAll('[data-test-ref="payment-option"]');
            expect(paymentOption.length).toEqual(0);
            done();
        });
    });

    // account payment options info
    it('has displayed account-status', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const accountStatus = component.$el.querySelectorAll('[data-test-ref="account-status"]');
            expect(accountStatus.length).toEqual(1);
            expect(accountStatus[0].innerText).toBe('OPEN');
            done();
        });
    });

    it('has displayed account-status with no information', done => {
        _createComponent(assigndeep({}, fullMock, {
            financialAccount: {
                accountStatus: null
            }
        }));

        Vue.nextTick(() => {
            const accountStatus = component.$el.querySelectorAll('[data-test-ref="account-status"]');
            expect(accountStatus.length).toEqual(0);
            done();
        });
    });

    // medicare information
    it('has displayed Medicare information if it exists', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const medicare = component.$el.querySelectorAll('[data-test-ref="medicare-info"]');
            // There are two divs with class "medicare-info" - the label
            // and the data field.
            expect(medicare.length).toEqual(1);
            // The data field's value should be "TEST_HIC_NUMBER"
            expect(medicare[0].innerText.trim()).toBe('TEST_HIC_NUMBER');
            expect(medicare[0].href).toBe('http://duckduckgo.com/');
            done();
        });
    });

    it('has not displayed Medicare information if it is blank', done => {
        _createComponent(assigndeep({}, fullMock, {
            hicNumber: ''
        }));

        Vue.nextTick(() => {
            const medicare = component.$el.querySelectorAll('[data-test-ref="medicare-info"]');
            // no fields should exist with the class subscriber-status if
            // medicare info was false.
            expect(medicare.length).toEqual(0);
            done();
        });
    });

    it('has not displayed Medicare information if there is no summary link available', done => {
        _createComponent(fullMock, []);

        Vue.nextTick(() => {
            const medicare = component.$el.querySelectorAll('[data-test-ref="medicare-info"]');
            expect(medicare.length).toEqual(0);
            done();
        });
    });

    // fep subscriber status info
    it('has displayed Subscriber Status field if fep is true', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                fep: true,
                employeeStatus: 'TEST_STATUS'
            }
        }));

        Vue.nextTick(() => {
            const fep = component.$el.querySelectorAll('[data-test-ref="subscriber-status"]');
            // There are two divs with class "subscriber-status" - the label
            // and the data field.
            expect(fep.length).toEqual(1);
            // The data field's value should be "TEST_STATUS"
            expect(fep[0].innerText.trim()).toBe('TEST_STATUS');
            done();
        });
    });

    it('has not displayed Subscriber Status field if fep is false', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                fep: false
            }
        }));

        Vue.nextTick(() => {
            const fep = component.$el.querySelectorAll('[data-test-ref="subscriber-status"]');
            // no fields should exist with the class subscriber-status if
            // fep was false.
            expect(fep.length).toEqual(0);
            done();
        });
    });

    // make sure it doesn't load anything when there is no subscriber
    it('displays nothing when there is no subscriber', done => {
        _createComponent({});

        Vue.nextTick(() => {
            const body = component.$el;
            // check if the content of the body is a non-breaking space (&nbsp; aka unicode \u00A0)
            expect(body.innerText.trim()).toBe('');
            const fep = component.$el.querySelectorAll('[data-test-ref="subscriber-status"]');
            // no fields should exist with the class subscriber-status if
            // fep was false.
            expect(fep.length).toEqual(0);
            done();
        });
    });

    it('displays CES Exceptions when ces exceptions are available', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const cesException = component.$el.querySelectorAll('[data-test-ref="ces-exceptions"]');
            expect(cesException.length).toEqual(1);
            expect(cesException[0].href).toBe('http://lmgtfy.com/');
            done();
        });
    });

    it('displays nothing for CES Exceptions when ces exceptions are unavailable', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                cesExceptionIndicator: false
            }
        }));

        Vue.nextTick(() => {
            const cesException = component.$el.querySelectorAll('[data-test-ref="ces-exceptions"]');
            expect(cesException.length).toEqual(0);
            done();
        });
    });

    it('displays nothing for CES Exceptions when ces exceptions are available, but there is no summary link', done => {
        _createComponent(fullMock, []);

        Vue.nextTick(() => {
            const cesException = component.$el.querySelectorAll('[data-test-ref="ces-exceptions"]');
            expect(cesException.length).toEqual(0);
            done();
        });
    });

    it('displays CES Related when ces related are available', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const cesRelated = component.$el.querySelectorAll('[data-test-ref="ces-related"]');
            expect(cesRelated.length).toEqual(1);
            expect(cesRelated[0].href).toBe('http://google.com/');
            done();
        });
    });

    it('displays nothing for CES Related when ces related are unavailable', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                relatedInformationIndicator: false
            }
        }));

        Vue.nextTick(() => {
            const cesRelated = component.$el.querySelectorAll('[data-test-ref="ces-related"]');
            expect(cesRelated.length).toEqual(0);
            done();
        });
    });

    it('displays nothing for CES Related when ces related are available, but there is no summary link', done => {
        _createComponent(fullMock, []);

        Vue.nextTick(() => {
            const cesRelated = component.$el.querySelectorAll('[data-test-ref="ces-related"]');
            expect(cesRelated.length).toEqual(0);
            done();
        });
    });

    it('displays email address when summary link is available', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const emailAddress = component.$el.querySelectorAll('[data-test-ref="email-addresses"]');
            expect(emailAddress.length).toEqual(1);
            expect(emailAddress[0].href).toBe('http://stackoverflow.com/');
            done();
        });
    });

    it('displays no email address when summary link is unavailable', done => {
        _createComponent(fullMock, []);

        Vue.nextTick(() => {
            const emailAddress = component.$el.querySelectorAll('[data-test-ref="email-addresses"]');
            expect(emailAddress.length).toEqual(0);
            done();
        });
    });

    // TODO - make sure refresh data is called when the database id is changed
    it('should try to refresh the data when the database id is changed', () => {
        // it's not entirely clear how to do this. I've tried setting the property and watching for the change, but it
        // never triggers. I tried pulling in @vue/test-utils to try to help, but it wasn't working either.
    });

    it('displays HIPPA information when summary link is available', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const hippaInformation = component.$el.querySelectorAll('[data-test-ref="hippa-information"]');
            expect(hippaInformation.length).toEqual(1);
            expect(hippaInformation[0].href).toBe('http://amazon.com/');
            done();
        });
    });

    it('displays no HIPPA information when summary link is unavailable', done => {
        _createComponent(fullMock, []);

        Vue.nextTick(() => {
            const hippaInformation = component.$el.querySelectorAll('[data-test-ref="hippa-information"]');
            expect(hippaInformation.length).toEqual(0);
            done();
        });
    });

    it('displays Image History when summary link is available', done => {
        _createComponent(fullMock);

        Vue.nextTick(() => {
            const imageHistory = component.$el.querySelectorAll('[data-test-ref="image-history"]');
            expect(imageHistory.length).toEqual(1);
            expect(imageHistory[0].href).toBe('http://dogpile.com/');
            done();
        });
    });

    it('displays no Image History when summary link is unavailable', done => {
        _createComponent(fullMock, []);

        Vue.nextTick(() => {
            const imageHistory = component.$el.querySelectorAll('[data-test-ref="image-history"]');
            expect(imageHistory.length).toEqual(0);
            done();
        });
    });

    it('calls refresh data when the database id changes', done => {
        _createComponent(fullMock);

        component.$store.dispatch('setDatabaseId', 'test');

        spyOn(component, 'refreshData').and.callFake(() => {
            done();
        });
    });

    it('return promise when calling get data', done => {
        _createComponent(fullMock);

        component.getData().then(() => {
            done();
        });
    });

    it('make sure clear data clears the subscriber', () => {
        _createComponent(fullMock);

        const spy = spyOn(component.$store, 'dispatch');
        component.clearData();

        expect(spy).toHaveBeenCalledWith('clearSubscriber');
    });

    it('on MCS desktop, patient selection button displays', done => {
        _createComponent(fullMock);

        component.$store.dispatch('setDesktopName', 'MCS');

        Vue.nextTick(() => {
            const patientSelectButtons = component.$el.querySelectorAll('[data-test-ref="subscriber-summary-patient-select-button"]');

            expect(patientSelectButtons.length).toEqual(1);
            done();
        });
    });

    it('on CSR desktop, patient selection button DOES NOT display', done => {
        _createComponent(fullMock);

        component.$store.dispatch('setDesktopName', 'CSR');

        Vue.nextTick(() => {
            const patientSelectButtons = component.$el.querySelectorAll('[data-test-ref="subscriber-summary-patient-select-button"]');

            expect(patientSelectButtons.length).toEqual(0);
            done();
        });
    });

    it('on MCS desktop, when populated, carrier info displays', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                carrierName: 'Large Group ASO',
                carrierRestricted: false
            }
        }));

        component.$store.dispatch('setDesktopName', 'MCS');

        Vue.nextTick(() => {
            const carrierLabels = component.$el.querySelectorAll('[data-test-ref="subscriber-summary-carrier-label"]');
            const carrierFields = component.$el.querySelectorAll('[data-test-ref="subscriber-summary-carrier"]');

            expect(carrierLabels.length).toEqual(1);
            expect(carrierLabels[0].innerText.trim()).toBe('Carrier');
            expect(carrierFields.length).toEqual(1);
            expect(carrierFields[0].innerText.trim()).toBe('Large Group ASO');

            done();
        });
    });

    it('on CSR desktop, when populated, carrier info does NOT display', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                carrierName: 'Large Group ASO',
                carrierRestricted: false
            }
        }));

        component.$store.dispatch('setDesktopName', 'CSR');

        Vue.nextTick(() => {
            const carrierLabels = component.$el.querySelectorAll('[data-test-ref="subscriber-summary-carrier-label"]');
            const carrierFields = component.$el.querySelectorAll('[data-test-ref="subscriber-summary-carrier"]');

            expect(carrierLabels.length).toEqual(0);
            expect(carrierFields.length).toEqual(0);

            done();
        });
    });

    it('on MCS desktop, when populated, and restricted, carrier restricted tag displays', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                carrierName: 'Large Group ASO',
                carrierRestricted: true
            }
        }));

        component.$store.dispatch('setDesktopName', 'MCS');

        Vue.nextTick(() => {
            const carrierRestrictedCols = component.$el.querySelectorAll('[data-test-ref="subscriber-summary-carrier-restricted"]');

            expect(carrierRestrictedCols.length).toEqual(1);
            expect(carrierRestrictedCols[0].innerText.trim()).toBe('RESTRICTED');

            done();
        });
    });

    it('on MCS desktop, when populated, and NOT restricted, carrier restricted tag does NOT display', done => {
        _createComponent(assigndeep({}, fullMock, {
            subscriber: {
                carrierName: 'Large Group ASO',
                carrierRestricted: false
            }
        }));

        component.$store.dispatch('setDesktopName', 'MCS');

        Vue.nextTick(() => {
            const carrierRestrictedCols = component.$el.querySelectorAll('[data-test-ref="subscriber-summary-carrier-restricted"]');

            expect(carrierRestrictedCols.length).toEqual(0);

            done();
        });
    });

    it('date formatter method formats date to MM/DD/YYYY', () => {
        const formattedDate = SubscriberSummary.methods.formatDate('2018-03-15T00:00:00-0400');
        expect(formattedDate).toEqual('03/15/2018');
    });

    it('on MBR desktop, address history link is  displayed', done => {
        _createComponent(fullMock, mbrSummaryLinksMock);

        component.$store.dispatch('setDesktopName', 'MBR');

        Vue.nextTick(() => {
            const addressHistoryLink = component.$el.querySelectorAll('[data-test-ref="address-history"]');

            expect(addressHistoryLink.length).toEqual(1);
            done();
        });
    });

    it('on MBR desktop, application summary link is displayed', done => {
        _createComponent(fullMock, mbrSummaryLinksMock);

        component.$store.dispatch('setDesktopName', 'MBR');

        Vue.nextTick(() => {
            const applicationSummaryLink = component.$el.querySelectorAll('[data-test-ref="application-summary"]');

            expect(applicationSummaryLink.length).toEqual(1);
            done();
        });
    });

    it('on MBR desktop, contract status link is  displayed', done => {
        _createComponent(fullMock, mbrSummaryLinksMock);

        component.$store.dispatch('setDesktopName', 'MBR');

        Vue.nextTick(() => {
            const contractStatusLink = component.$el.querySelectorAll('[data-test-ref="contract-status"]');

            expect(contractStatusLink.length).toEqual(1);
            done();
        });
    });

    it('on MBR desktop, exceptions summary link is displayed', done => {
        _createComponent(fullMock, mbrSummaryLinksMock);

        component.$store.dispatch('setDesktopName', 'MBR');

        Vue.nextTick(() => {
            const exceptionsSummaryLink = component.$el.querySelectorAll('[data-test-ref="exceptions-summary"]');

            expect(exceptionsSummaryLink.length).toEqual(1);
            done();
        });
    });

    it('on MBR desktop, subscriber status history link is displayed', done => {
        _createComponent(fullMock, mbrSummaryLinksMock);

        component.$store.dispatch('setDesktopName', 'MBR');

        Vue.nextTick(() => {
            const subscriberStatusHistoryLink = component.$el.querySelectorAll('[data-test-ref="subscriber-status-history"]');

            expect(subscriberStatusHistoryLink.length).toEqual(1);
            done();
        });
    });

    it('if desktop is not MBR, MBR specific subscriber summary links do not display', done => {
        _createComponent(fullMock);

        component.$store.dispatch('setDesktopName', 'CSR');

        Vue.nextTick(() => {
            const addressHistoryLink = component.$el.querySelectorAll('[data-test-ref="address-history"]');
            const applicationSummaryLink = component.$el.querySelectorAll('[data-test-ref="application-summary"]');
            const contractStatusLink = component.$el.querySelectorAll('[data-test-ref="contract-status"]');
            const exceptionsSummaryLink = component.$el.querySelectorAll('[data-test-ref="exceptions-summary"]');
            const subscriberStatusHistoryLink = component.$el.querySelectorAll('[data-test-ref="subscriber-status-history"]');

            expect(addressHistoryLink.length).toEqual(0);
            expect(applicationSummaryLink.length).toEqual(0);
            expect(contractStatusLink.length).toEqual(0);
            expect(exceptionsSummaryLink.length).toEqual(0);
            expect(subscriberStatusHistoryLink.length).toEqual(0);
            done();
        });
    });

    it('on MBR desktop, agent name is displayed', done => {
        _createComponent(fullMock);

        component.$store.dispatch('setDesktopName', 'MBR');

        Vue.nextTick(() => {
            const agentName = component.$el.querySelectorAll('[data-test-ref="agent-name"]');

            expect(agentName.length).toEqual(1);
            expect(agentName[0].innerText.trim()).toBe('FIRSTNAME LASTNAME');
            done();
        });
    });

    it('on MBR desktop, no agent name is displayed when agent is empty', done => {
        _createComponent();

        component.$store.dispatch('setDesktopName', 'MBR');

        Vue.nextTick(() => {
            const agentName = component.$el.querySelectorAll('[data-test-ref="agent-name"]');

            expect(agentName.length).toEqual(0);
            done();
        });
    });

    it('if desktop is not MBR, no agent name is displayed', done => {
        _createComponent(fullMock);

        component.$store.dispatch('setDesktopName', 'CSR');

        Vue.nextTick(() => {
            const agentName = component.$el.querySelectorAll('[data-test-ref="agent-name"]');

            expect(agentName.length).toEqual(0);
            done();
        });
    });

    it('on MBR desktop, agency name is displayed', done => {
        _createComponent(fullMock);

        component.$store.dispatch('setDesktopName', 'MBR');

        Vue.nextTick(() => {
            const agencyName = component.$el.querySelectorAll('[data-test-ref="agency-name"]');

            expect(agencyName.length).toEqual(1);
            expect(agencyName[0].innerText.trim()).toBe('HOME OFFICE');
            done();
        });
    });

    it('on MBR desktop, no agency name is displayed when agent is empty', done => {
        _createComponent();

        component.$store.dispatch('setDesktopName', 'MBR');

        Vue.nextTick(() => {
            const agencyName = component.$el.querySelectorAll('[data-test-ref="agency-name"]');

            expect(agencyName.length).toEqual(0);
            done();
        });
    });

    it('if desktop is not MBR, no agency name is displayed', done => {
        _createComponent(fullMock);

        component.$store.dispatch('setDesktopName', 'CSR');

        Vue.nextTick(() => {
            const agencyName = component.$el.querySelectorAll('[data-test-ref="agency-name"]');

            expect(agencyName.length).toEqual(0);
            done();
        });
    });

    it('on MBR desktop, agent number is displayed', done => {
        _createComponent(fullMock);

        component.$store.dispatch('setDesktopName', 'MBR');

        Vue.nextTick(() => {
            const agentNumber = component.$el.querySelectorAll('[data-test-ref="agent-number"]');

            expect(agentNumber.length).toEqual(1);
            expect(agentNumber[0].innerText.trim()).toBe('001T13');
            done();
        });
    });

    it('on MBR desktop, no agent number is displayed when agent is empty', done => {
        _createComponent();

        component.$store.dispatch('setDesktopName', 'MBR');

        Vue.nextTick(() => {
            const agentNumber = component.$el.querySelectorAll('[data-test-ref="agent-number"]');

            expect(agentNumber.length).toEqual(0);
            done();
        });
    });

    it('if desktop is not MBR, no agent number is displayed', done => {
        _createComponent(fullMock);

        component.$store.dispatch('setDesktopName', 'CSR');

        Vue.nextTick(() => {
            const agentNumber = component.$el.querySelectorAll('[data-test-ref="agent-number"]');

            expect(agentNumber.length).toEqual(0);
            done();
        });
    });
    it('on MBR desktop, original effective date is displayed', done => {
        _createComponent(fullMock);

        component.$store.dispatch('setDesktopName', 'MBR');

        Vue.nextTick(() => {
            const originalEffectiveDate = component.$el.querySelectorAll('[data-test-ref="original-effective-date"]');

            expect(originalEffectiveDate.length).toEqual(1);
            expect(originalEffectiveDate[0].innerText.trim()).toBe('06/01/2002');
            done();
        });
    });

    it('on MBR desktop, no original effective date is displayed when original effective date is empty', done => {
        _createComponent();

        component.$store.dispatch('setDesktopName', 'MBR');

        Vue.nextTick(() => {
            const originalEffectiveDate = component.$el.querySelectorAll('[data-test-ref="original-effective-date"]');

            expect(originalEffectiveDate.length).toEqual(0);
            done();
        });
    });

    it('if desktop is not MBR, no original effective date is displayed', done => {
        _createComponent(fullMock);

        component.$store.dispatch('setDesktopName', 'CSR');

        Vue.nextTick(() => {
            const originalEffectiveDate = component.$el.querySelectorAll('[data-test-ref="original-effective-date"]');

            expect(originalEffectiveDate.length).toEqual(0);
            done();
        });
    });
    it('on MBR desktop, maintenance date is displayed', done => {
        _createComponent(fullMock);

        component.$store.dispatch('setDesktopName', 'MBR');

        Vue.nextTick(() => {
            const maintenanceDate = component.$el.querySelectorAll('[data-test-ref="maintenance-date"]');

            expect(maintenanceDate.length).toEqual(1);
            expect(maintenanceDate[0].innerText.trim()).toBe('06/01/2005');
            done();
        });
    });

    it('on MBR desktop, no maintenance date is displayed when maintenance date is empty', done => {
        _createComponent();

        component.$store.dispatch('setDesktopName', 'MBR');

        Vue.nextTick(() => {
            const maintenanceDate = component.$el.querySelectorAll('[data-test-ref="maintenance-date"]');

            expect(maintenanceDate.length).toEqual(0);
            done();
        });
    });

    it('if desktop is not MBR, no maintenance date is displayed', done => {
        _createComponent(fullMock);

        component.$store.dispatch('setDesktopName', 'CSR');

        Vue.nextTick(() => {
            const maintenanceDate = component.$el.querySelectorAll('[data-test-ref="maintenance-date"]');

            expect(maintenanceDate.length).toEqual(0);
            done();
        });
    });
    it('on MBR desktop, subscriber coverage is displayed', done => {
        _createComponent(fullMock);

        component.$store.dispatch('setDesktopName', 'MBR');

        Vue.nextTick(() => {
            const subscriberCoverage = component.$el.querySelectorAll('[data-test-ref="subscriber-coverage"]');

            expect(subscriberCoverage.length).toEqual(1);
            expect(subscriberCoverage[0].innerText.trim()).toBe('TEST COVERAGE');
            done();
        });
    });

    it('on MBR desktop, no subscriber coverage is displayed when coverage is empty', done => {
        _createComponent();

        component.$store.dispatch('setDesktopName', 'MBR');

        Vue.nextTick(() => {
            const subscriberCoverage = component.$el.querySelectorAll('[data-test-ref="subscriber-coverage"]');

            expect(subscriberCoverage.length).toEqual(0);
            done();
        });
    });

    it('if desktop is not MBR, no subscriber coverage is displayed', done => {
        _createComponent(fullMock);

        component.$store.dispatch('setDesktopName', 'CSR');

        Vue.nextTick(() => {
            const subscriberCoverage = component.$el.querySelectorAll('[data-test-ref="subscriber-coverage"]');

            expect(subscriberCoverage.length).toEqual(0);
            done();
        });
    });
});
