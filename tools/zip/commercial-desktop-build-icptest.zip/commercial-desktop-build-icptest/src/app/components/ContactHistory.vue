<template>
    <section
        v-if="hasContactHistory"
        class="app-section-contact-history"
        aria-label="Contact History">
        <b-form-select
            v-if="filter"
            v-model="selectedFilter"
            data-test-ref="filter-list">
            <option
                v-for="filterName in Object.keys(filter)"
                :key="filterName"
                :value="filter[filterName]"
                :data-test-ref="filterName">{{ filterName }}
            </option>
        </b-form-select>
        <b-table
            ref="contactHistoryTable"
            :no-local-sorting="true"
            :sort-by.sync="sortBy"
            :sort-desc.sync="sortDirection"
            :busy.sync="isBusy"
            :striped="true"
            :small="true"
            :fields="[{
                          key: 'statusCode.type',
                          label: 'Type',
                          sortable: true
                      },
                      {
                          key: 'timestamp',
                          label: 'Date',
                          formatter: 'formatDate',
                          sortable: true
                      },
                      {
                          key: 'requestVerbiage',
                          label: 'Details',
                          sortable: true
                      },
                      {
                          key: 'employeeName',
                          label: 'Owner',
                          sortable: true
                      }
            ]"
            :items="contactHistory"
            data-test-ref="contact-history-table"
            @sort-changed="sortChanged"
        ></b-table>
    </section>
</template>

<script>
import DesktopBaseComponent from './DesktopBaseComponent.vue';
import StringUtil from '../util/StringUtil';
import get from 'lodash.get';
import moment from 'moment';

// poor man's enum
const StatusCodeEnum = Object.freeze({
    OPEN: 'OP',
    CLOSED: 'CL',
    TRANSFERED: 'XU'
});

const ColumnEnum = Object.freeze({
    STATUS: 'statusCode.type',
    TIMESTAMP: 'timestamp'
});

const DirectionEnum = Object.freeze({
    ASCENDING: false,
    DESCENDING: true
});

export default {
    name: 'ContactHistory',
    extends: DesktopBaseComponent,
    data: () => {
        return {
            hasSummaryLinks: false,
            sortBy: ColumnEnum.STATUS,
            sortDirection: DirectionEnum.ASCENDING,
            isBusy: false,
            filter: null, // Object
            selectedFilter: null
        };
    },
    computed: {
         /**
         * A computed property to get the current database id
         */
        databaseId() {
            return this.$store.getters.getDatabaseId;
        },
        /**
         * A computed property to get the contactHistory
         */
        contactHistory() {
            let contactHistory = [];
            if (this.$store.getters.getContactHistory) {
                contactHistory = this.$store.getters.getContactHistory;
            }
            return contactHistory;
        },
        /**
         * A computed property to determine if there is a contactHistory available
         */
        hasContactHistory() {
            return (this.$store.getters.getContactHistory && this.$store.getters.getContactHistory.length > 0);
        }
    },
    /** @lends app.components.ContactHistory.prototype */
    watch: {
        /**
         * When the database id is changed, go get the data.
         */
        databaseId() {
            this.refreshData(true);
        },
        /**
         * When a new filter is selected, go get new data
         */
        selectedFilter() {
            this.refreshData(true);
        }
    },
    mounted() {
        // Retrieve Filter list for MCS Desktop
        if (this.$store.getters.getDesktopName === 'MCS') {
            this.getFilter().finally(() => {
                this.$emit('loaded');
            });
        } else {
            this.selectedFilter = '1'; // TODO Read from store the Inform profile to get CSA company code
            this.$emit('loaded');
        }
    },
    /** @lends app.components.ContactHistory.prototype */
    methods: {
        /**
         * get the filter list
         */
        getFilter() {
            return new Promise((resolve, reject) => {
                this.$store.dispatch('retrieveContactHistoryFilter').then((data) => {
                    this.filter = data;
                    // Set the default selection to the first filter
                    if (Object.keys(this.filter).length > 0) {
                        const firstKey = Object.keys(this.filter)[0];
                        this.selectedFilter = this.filter[firstKey];
                    }
                    resolve(data);
                }, dataError => {
                    console.error('Unable to retrieve Contact History Filter: ' + dataError);
                    reject(dataError);
                });
            });
        },
        /**
         * get the contactHistory items, and sort this data by status column for initial display
         */
        getData() {
            // if the database id is provided, go get the contactHistory
            if (this.databaseId) {
                // Get the filter list again if nothing is selected
                let filterPromise;
                if (this.selectedFilter) {
                    filterPromise = Promise.resolve();
                } else {
                    filterPromise = this.getFilter();
                }

                return new Promise((resolve, reject) => {
                    // Retrieve contact history once the filter data is returned
                    filterPromise.then(() => {
                        const splitFilter = this.selectedFilter.split(',');

                        // Filter always contains a company code, and may contain an employee to use with the search
                        const company = splitFilter[0];
                        let employee;
                        if (splitFilter.length > 1) {
                            employee = splitFilter[1];
                        }

                        this.$store.dispatch('retrieveContactHistory', {memberKeyId: this.databaseId, company, employee}).then((items) => {
                            items.sort((objectA, objectB) => {
                                return this.statusComparator(objectA, objectB, ColumnEnum.STATUS, DirectionEnum.DESCENDING);
                            });
                            resolve(items);
                        }, dataError => {
                            reject(dataError);
                        });
                    }, dataError => {
                        reject(dataError);
                    });
                });
            }

            // with no database id, return a promise that immediately resolves
            return Promise.resolve();
        },
        /**
         * clear the contactHistory
         */
        clearData() {
            // clear out any lingering context in the store
            this.$store.dispatch('clearContactHistory');
        },
        /**
         * Display the date as a MM/DD/YY value, by truncating the existing date value and applying
         * a format using the moment library.
         */
        formatDate(value) {
            let formattedDate = value;
            const MINIMUM_DATE_LEN = 10;

            if (formattedDate && formattedDate.length > MINIMUM_DATE_LEN) {
                formattedDate = moment(value.substring(0, MINIMUM_DATE_LEN)).format('MM/DD/YY');
            }
            return formattedDate;
        },
        /**
         * Event method callback fired by <code>b-table</code> component when user selects a table header for sorting. Here we provide
         * the sort ascending and sort descending implementation for the status column sort. For other columns we provide a
         * standard ascending/descending string compare sort functions.
         *
         * @param {Context} sorting context provides the field key name being sorted and the sort direction
         */
        sortChanged(ctx) {
            let direction = DirectionEnum.ASCENDING;
            const table = this.$refs.contactHistoryTable;

            this.isBusy = true;

            if (ctx) {
                if (!ctx.sortDesc) {
                    direction = DirectionEnum.DESCENDING;
                }
                if (ctx.sortBy === ColumnEnum.STATUS) {
                    table.items.sort((objectA, objectB) => {
                        return this.statusComparator(objectA, objectB, ctx.sortBy, direction);
                    });
                } else {
                    table.items.sort((objectA, objectB) => {
                        return this.defaultComparator(objectA, objectB, ctx.sortBy, direction);
                    });
                }
            }
            this.isBusy = false;
        },
        /**
         * Status comparator
         * If a parmeter is null or undefined it is converted to an empty string before comparison.
         *
         * @param {Object} objectA the first row being compared
         * @param {Object} objectB the second row being compared to the first
         * @param {String} key the table column selected
         * @param {Boolean} descending the sort direction
         * @return {Number} 1, -1, or 0
         */
        statusComparator(objectA, objectB, key, descending) {
            let compareValue = 0;

            const compareStatusA = StringUtil.toString(get(objectA, key));
            const compareStatusB = StringUtil.toString(get(objectB, key));

            if (descending) {
                compareValue = this.statusDescending(compareStatusA, compareStatusB);
            } else {
                compareValue = this.statusAscending(compareStatusA, compareStatusB);
            }

            if (compareValue === 0) {
                compareValue = this.sortStatusByDate(objectA, objectB);
            }
            return compareValue;
        },
        /**
         * Default comparator
         * If a parmeter is null or undefined it is converted to an empty string before comparison.
         *
         * @param {Object} objectA the first row being compared
         * @param {Object} objectB the second row being compared to the first
         * @param {String} key the table column selected
         * @param {Boolean} descending the sort direction
         * @return {Number} 1, -1, or 0
         */
        defaultComparator(objectA, objectB, key, descending) {
            let compareValue = 0;

            const compareStatusA = StringUtil.toString(get(objectA, key));
            const compareStatusB = StringUtil.toString(get(objectB, key));

            if (descending) {
                compareValue = this.defaultDescending(compareStatusA, compareStatusB);
            } else {
                compareValue = this.defaultAscending(compareStatusA, compareStatusB);
            }
            return compareValue;
        },
        /**
         * Status only comparator ascending
         * If a parmeter is null or undefined it is converted to an empty string before comparison.
         *
         * @param {Object} compareStatusA the first row being compared
         * @param {Object} compareStatusB the second row being compared to the first
         * @return {Number} 1, -1, or 0
         */
        statusAscending(compareStatusA, compareStatusB) {
            let compareValue = 0;

            if (compareStatusA === StatusCodeEnum.TRANSFERED && compareStatusB === StatusCodeEnum.OPEN) {
                compareValue = -1;
            } else if (compareStatusA === StatusCodeEnum.OPEN && compareStatusB === StatusCodeEnum.TRANSFERED) {
                compareValue = 1;
            } else {
                compareValue = compareStatusA.localeCompare(compareStatusB);
            }
            return compareValue;
        },
        /**
         * Status only comparator descending
         * If a parmeter is null or undefined it is converted to an empty string before comparison.
         *
         * @param {Object} compareStatusA the first value being compared
         * @param {Object} compareStatusB the second value being compared to the first
         * @return {Number} 1, -1, or 0
         */
        statusDescending(compareStatusA, compareStatusB) {
            let compareValue = 0;

            if (compareStatusA === StatusCodeEnum.TRANSFERED && compareStatusB === StatusCodeEnum.OPEN) {
                compareValue = 1;
            } else if (compareStatusA === StatusCodeEnum.OPEN && compareStatusB === StatusCodeEnum.TRANSFERED) {
                compareValue = -1;
            } else {
                compareValue = -compareStatusA.localeCompare(compareStatusB);
            }
            return compareValue;
        },
        /**
         * Default string comparator ascending
         *
         * @param {Object} compareStatusA the first row being compared
         * @param {Object} compareStatusB the second row being compared to the first
         * @return {Number} 1, -1, or 0
         */
        defaultAscending(compareStatusA, compareStatusB) {
            return compareStatusA.localeCompare(compareStatusB);
        },
        /**
         * Default string comparator descending
         *
         * @param {Object} compareStatusA the first row being compared
         * @param {Object} compareStatusB the second row being compared to the first
         * @return {Number} 1, -1, or 0
         */
        defaultDescending(compareStatusA, compareStatusB) {
            return -this.defaultAscending(compareStatusA, compareStatusB);
        },
        /**
         * When we sort by the status code, we then want to sort by date, with closed informs sorted newest to oldest,
         * and all other statuses by oldest to newest.
         * @param {Object} objectA the first row being compared
         * @param {Object} objectB the second row being compared to the first
         */
        sortStatusByDate(objectA, objectB) {
            let compareValue = 0;

            if (objectA && objectB) {
                const compareStatusA = StringUtil.toString(get(objectA, ColumnEnum.STATUS));
                const compareStatusB = StringUtil.toString(get(objectB, ColumnEnum.STATUS));

                if (compareStatusA === StatusCodeEnum.CLOSED && compareStatusB === StatusCodeEnum.CLOSED) {
                    compareValue = this.dateComparatorDescending(get(objectA, ColumnEnum.TIMESTAMP), get(objectB, ColumnEnum.TIMESTAMP));
                } else {
                    compareValue = this.dateComparatorAscending(get(objectA, ColumnEnum.TIMESTAMP), get(objectB, ColumnEnum.TIMESTAMP));
                }
            }

            return compareValue;
        },
        /**
         * Date comparator ascending
         * If a parmeter is null or undefined it is converted to an empty string before comparison.
         * Note here sorting date by string as its a string value
         *
         * @param {String} dateA the first date value being compared
         * @param {String} dateB the second date value being compared to the first
         * @return {Number} 1, -1, or 0
         */
        dateComparatorAscending(dateA, dateB) {
            const compareDateA = StringUtil.toString(dateA);
            const compareDateB = StringUtil.toString(dateB);

            return compareDateA.localeCompare(compareDateB);
        },
        /**
         * Date comparator descending
         * If a parmeter is null or undefined it is converted to an empty string before comparison.
         * Note here sorting date by string as its a string value
         *
         * @param {String} dateA the first date value being compared
         * @param {String} dateB the second date value being compared to the first
         * @return {Number} 1, -1, or 0
         */
        dateComparatorDescending(dateA, dateB) {
            return -this.dateComparatorAscending(dateA, dateB);
        }
    }
};

</script>
