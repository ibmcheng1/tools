<template>
    <div
        :class="{ 'app-resizing': resizing, 'app-resize-panes-vertical': displayVertical }"
        :data-layout-id="id"
        class="app-resize-panes">
        <div class="app-resize-pane-drop-before"></div>
        <template v-for="(definition, i) in layout">
            <div
                :key="definition.id + '-panes'"
                :style="{
                    'width': (!displayVertical) ? paneSizes[i] + 'px' : null,
                    'height': (displayVertical) ? paneSizes[i] + 'px' : null
                }"
                class="app-resize-pane">
                <template v-if="definition.type == 'panes'">
                    <app-resize-panes
                        :layout="definition.layout"
                        :id="definition.id"
                        @tab-drag="onTabDrag($event)"></app-resize-panes>
                </template>
                <template v-else-if="definition.type == 'tabs'">
                    <app-tab-panel
                        :tabs="definition.layout"
                        :id="definition.id"
                        :hide-tabs="definition.hideTabs || false"
                        @tab-drag="onTabDrag($event)"></app-tab-panel>
                </template>
            </div>
            <div
                v-if="i &lt; layout.length-1"
                :key="definition.id + '-separator'"
                :data-separator-index="i+1"
                :class="{ 'app-resizing': resizing &amp;&amp; resizingIndex == i }"
                tabindex="-1"
                class="app-resize-pane-separator"
                @mousedown="onMouseDownSeparator($event, i)"></div>
        </template>
        <div class="app-resize-pane-drop-after"></div>
    </div>
</template>

<script>

    import Vue from 'vue';

    const mouseUpListeners = [];

    const registerMouseUpListener = (listener) => {
        mouseUpListeners.push(listener);
    };
    const unregisterMouseUpListener = (listener) => {
        for (let i = 0, il = mouseUpListeners.length; i < il; i++) {
            if (mouseUpListeners[i] === listener) {
                mouseUpListeners.splice(i, 1);
                break;
            }
        }
    };

    const mouseMoveListeners = [];

    const registerMouseMoveListener = (listener) => {
        mouseMoveListeners.push(listener);
    };
    const unregisterMouseMoveListener = (listener) => {
        for (let i = 0, il = mouseMoveListeners.length; i < il; i++) {
            if (mouseMoveListeners[i] === listener) {
                mouseMoveListeners.splice(i, 1);
                break;
            }
        }
    };

    const resizeListeners = [];

    // Exporting for unit testing
    export const registerResizeListener = (listener) => {
        resizeListeners.push(listener);
    };
    const unregisterResizeListener = (listener) => {
        for (let i = 0, il = resizeListeners.length; i < il; i++) {
            if (resizeListeners[i] === listener) {
                resizeListeners.splice(i, 1);
                break;
            }
        }
    };

    document.addEventListener('mouseup', (e) => {
        for (let i = 0, il = mouseUpListeners.length; i < il; i++) {
            mouseUpListeners[i](e);
        }
    });

    document.addEventListener('mousemove', (e) => {
        for (let i = 0, il = mouseMoveListeners.length; i < il; i++) {
            mouseMoveListeners[i](e);
        }
    });

    window.addEventListener('mouseleave', (e) => {
        for (let i = 0, il = mouseUpListeners.length; i < il; i++) {
            mouseUpListeners[i](e);
        }
    });

    let lastResizeTime = 0;
    let resizeDebounceHandle = null;

    // Exporting for unit testing
    export function resizeWindowEventListener(e) {
        // This throttles & debounces the last call for performance.
        const doResize = () => {
            for (let i = 0, il = resizeListeners.length; i < il; i++) {
                resizeListeners[i](e);
            }
            lastResizeTime = window.performance.now();
        };
        const time = window.performance.now();
        if (time - lastResizeTime > 50) {
            doResize();
        }
        clearTimeout(resizeDebounceHandle);
        resizeDebounceHandle = setTimeout(() => {
            doResize();
        }, 51);
    }

    window.addEventListener('resize', resizeWindowEventListener);

    /**
     * AppResizePanes layout vue component.  This component creates a resizable container
     * for AppTabPanel components.
     *
     * @class AppResizePanes
     * @memberof app.layout-components
     */
    export default {
        name: 'AppResizePanes',
        props: {
            id: {
                default: null,
                type: [Number, String]
            },
            layout: {
                default: () => {
                    return [];
                },
                type: Array
            },
            vertical: {
                default: true,
                type: Boolean
            }
        },
        data() {
            return {
                displayVertical: true,
                paneSizes: [],
                resizing: false,
                resizingIndex: 0
            };
        },
        watch: {
            layout: {
                immediate: true,
                handler(layout) {
                    Vue.nextTick(() => {
                        if (layout.length !== this.paneSizes.length) {
                            this.paneSizes = [];
                        }
                        const sizes = [];
                        let sizeTotal = 0;
                        const containerSize = ((this.vertical) ? this.$el.clientHeight : this.$el.clientWidth) - (6 * (layout.length - 1));
                        for (let i = 0, il = layout.length; i < il; i++) {
                            const size = (this.paneSizes[i]) ? this.paneSizes[i] : layout[i].size || 1;
                            sizeTotal += size;
                            sizes.push(size);
                        }
                        for (let i = 0, il = sizes.length; i < il; i++) {
                            sizes[i] = ((sizes[i] / sizeTotal) * containerSize);
                            this.paneSizes[i] = sizes[i];
                        }
                        this.$forceUpdate();
                    });
                }
            },
            vertical: {
                immediate: true,
                handler(vertical) {
                    this.displayVertical = vertical;
                }
            }
        },
        /**
         * Vue lifecycle callback for mounting the component
         */
        mounted() {
            registerMouseUpListener(this.onMouseUpDocument);
            registerMouseMoveListener(this.onMouseMoveDocument);
            if (this.$parent && (this.$parent.$options._componentTag === 'app-window-manager' || this.$parent.$options._componentTag === 'app-resize-panes')) {
                this.displayVertical = (typeof this.$parent.displayVertical === 'undefined') ? false : !this.$parent.displayVertical;
                this.$parent.$on('resize', this.onResizeWindow);
            } else {
                registerResizeListener(this.onResizeWindow);
            }
        },
        /**
         * Vue lifecycle callback for destroying the component
         */
        destroyed() {
            unregisterMouseUpListener(this.onMouseUpDocument);
            unregisterMouseMoveListener(this.onMouseMoveDocument);
            unregisterResizeListener(this.onResizeWindow);
            if (this.$parent) {
                this.$parent.$off('resize', this.onResizeWindow);
            }
        },
        /** @lends app.layout-components.AppResizePanes.prototype */
        methods: {
            /**
             * Go to a specific view
             *
             * @param {string} viewName the name of the view to go to
             */
            goToView(viewName) {
                this.view = viewName;
            },
            /**
             * Event handler for when a separator node is given a mouse down event.
             * Initializes the resizing logic for the pane.
             *
             * @param {Event} e the event from the mouse down
             * @param {number} i the index of the separator node
             */
            onMouseDownSeparator(e, i) {
                if (e.which === 1) {
                    e.preventDefault();
                    this.resizing = true;
                    this.resizingIndex = i;
                    this.onMouseMoveDocument(e);
                }
            },
            /**
             * Event handler for when mouse is moved while resizing is enabled.
             * Performs the logic of resizing the panels as the mouse is moved.
             *
             * @param {Event} e the event from the mouse move
             */
            onMouseMoveDocument(e) {
                if (this.resizing) {
                    const pos = (this.displayVertical) ? e.pageY : e.pageX;
                    const containerSize = (this.displayVertical) ? this.$el.clientHeight : this.$el.clientWidth;
                    const containerOffset = (this.displayVertical) ? this.$el.getBoundingClientRect().top : this.$el.getBoundingClientRect().left;
                    let containerPos = (pos - containerOffset) / containerSize;
                    let leadingSize = 0;
                    let paneSizeTotal = 0;
                    for (let i = 0, il = this.layout.length; i < il; i++) {
                        if (i < this.resizingIndex) {
                            leadingSize += this.paneSizes[i];
                        }
                        paneSizeTotal += this.paneSizes[i];
                    }
                    const prevPaneSize = this.paneSizes[this.resizingIndex];
                    const nextPaneSize = this.paneSizes[this.resizingIndex + 1];
                    const resizingSize = prevPaneSize + nextPaneSize;
                    if (containerPos < leadingSize / containerSize) {
                        containerPos = leadingSize / containerSize;
                    }
                    if (containerPos > (leadingSize + resizingSize) / containerSize) {
                        containerPos = (leadingSize + resizingSize) / containerSize;
                    }
                    this.paneSizes[this.resizingIndex] = (containerPos * paneSizeTotal) - leadingSize;
                    this.paneSizes[this.resizingIndex + 1] = resizingSize - this.paneSizes[this.resizingIndex];
                    this.$forceUpdate();
                    this.$emit('resize');
                }
            },
            /**
             * Event handler for when mouse button is released.
             * Turns off the resizing mode if currently enabled.
             *
             * @param {Event} e the event from the mouse move
             */
            onMouseUpDocument(e) {
                if (e.which === 1) {
                    this.resizing = false;
                }
            },
            /**
             * Event handler for when the window is resized.
             * Performs the logic of resizing the panels as the window is resized.
             */
            onResizeWindow() {
                Vue.nextTick(() => {
                    const sizes = [];
                    let sizeTotal = 0;
                    const containerSize = ((this.displayVertical) ? this.$el.clientHeight : this.$el.clientWidth) - (6 * (this.layout.length - 1));
                    for (let i = 0, il = this.layout.length; i < il; i++) {
                        const size = this.paneSizes[i] || 1;
                        sizeTotal += size;
                        sizes.push(size);
                    }
                    for (let i = 0, il = sizes.length; i < il; i++) {
                        sizes[i] = ((sizes[i] / sizeTotal) * containerSize);
                        this.paneSizes[i] = sizes[i];
                    }
                    this.$forceUpdate();
                });
                this.$emit('resize');
            },
            /**
             * Event handler for when a tab is dragged.
             * Emits a tab-drag event
             */
            onTabDrag(e) {
                this.$emit('tab-drag', e);
            }
        }
    };
</script>
