<template>
    <div
        class="accordion"
        role="tablist">
        <template v-if="tree">
            <template v-for="(branch, i) of tree">
                <accordion-group
                    v-if="branch.children"
                    :key="i"
                    :tree-definition="branch"
                    @activate="$emit('activate', $event)"/>
                <accordion-item
                    v-else
                    :key="i"
                    :tree-definition="branch"
                    @activate="$emit('activate', $event)"/>
            </template>
        </template>
        <slot></slot>
    </div>
</template>

<script>

    /**
     * Accordion layout vue component.
     *
     * @class Accordion
     * @memberof app.layout-components
     */
    export default {
        name: 'Accordion',

        props: {
            tree: {
                default: null,
                type: Array
            }
        }
    };

</script>
