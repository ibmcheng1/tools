/**
 * The layout-components namespace
 * @namespace app.layout-components
 */
