export const mcsDesktopLayout =
    {
        layoutName: 'MCS',
        panes: [
            {
                type: '',
                title: '',
                panes: [
                    {
                        type: 'panes',
                        size: 0.64,
                        layout: [
                            {
                                type: 'tabs',
                                size: 0.8,
                                hideTabs: true,
                                layout: [
                                    {
                                        title: 'Desktop Application Controls',
                                        component: 'desktop-application-controls'
                                    }
                                ]
                            },
                            {
                                type: 'tabs',
                                size: 0.2,
                                layout: [
                                    {
                                        title: 'Contact History',
                                        component: 'contact-history',
                                        refreshable: true
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        type: 'panes',
                        size: 0.36,
                        layout: [
                            {
                                type: 'tabs',
                                layout: [
                                    {
                                        title: 'Subscriber Summary',
                                        component: 'subscriber-summary',
                                        refreshable: true
                                    },
                                    {
                                        title: 'Exceptions Summary',
                                        component: 'exceptions-summary',
                                        refreshable: true
                                    }
                                ]
                            },
                            {
                                type: 'tabs',
                                layout: [
                                    {
                                        title: 'Patient Summary',
                                        component: 'patient-summary',
                                        refreshable: true
                                    }
                                ]
                            },
                            {
                                type: 'tabs',
                                layout: [
                                    {
                                        title: 'Contract Summary',
                                        component: 'contract-summary',
                                        refreshable: true
                                    }
                                ]
                            },
                            {
                                type: 'tabs',
                                layout: [
                                    {
                                        title: 'Activity Summary',
                                        component: 'activity-summary',
                                        refreshable: true
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    };
