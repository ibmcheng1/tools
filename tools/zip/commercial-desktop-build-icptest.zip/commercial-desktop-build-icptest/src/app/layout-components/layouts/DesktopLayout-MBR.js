export const mbrDesktopLayout =
    {
        layoutName: 'MBR',
        panes: [
            {
                type: '',
                title: 'Subscriber',
                panes: [
                    {
                        type: 'panes',
                        size: 0.64,
                        layout: [
                            {
                                type: 'tabs',
                                size: 0.6,
                                hideTabs: true,
                                layout: [
                                    {
                                        title: 'Desktop Application Controls',
                                        component: 'desktop-application-controls'
                                    }
                                ]
                            },
                            {
                                type: 'tabs',
                                size: 0.4,
                                layout: [
                                    {
                                        title: 'Contact History',
                                        component: 'contact-history',
                                        refreshable: true
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        type: 'panes',
                        size: 0.36,
                        layout: [
                            {
                                id: '20',
                                type: 'tabs',
                                layout: [
                                    {
                                        title: 'Subscriber Summary',
                                        component: 'subscriber-summary',
                                        refreshable: true
                                    }
                                ]
                            },
                            {
                                type: 'tabs',
                                layout: [
                                    {
                                        title: 'Contract Summary',
                                        component: 'contract-summary',
                                        refreshable: true
                                    }
                                ]
                            },
                            {
                                type: 'tabs',
                                layout: [
                                    {
                                        title: 'Billing Summary',
                                        component: 'billing-summary-subscriber',
                                        refreshable: true
                                    }
                                ]
                            },
                            {
                                type: 'tabs',
                                layout: [
                                    {
                                        title: 'Family Summary',
                                        component: 'family-summary',
                                        refreshable: true
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                type: '',
                title: 'Group',
                panes: [
                    {
                        type: 'panes',
                        size: 0.64,
                        layout: [
                            {

                                type: 'tabs',
                                size: 0.6,
                                hideTabs: true,
                                layout: [
                                    {
                                        title: 'Desktop Application Controls',
                                        component: 'desktop-application-controls'
                                    }
                                ]
                            },
                            {
                                type: 'tabs',
                                size: 0.4,
                                layout: [
                                    {
                                        title: 'Contact History',
                                        component: 'contact-history',
                                        refreshable: true
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        type: 'panes',
                        size: 0.36,
                        layout: [
                            {
                                type: 'tabs',
                                layout: [
                                    {
                                        title: 'Contract Summary',
                                        component: 'contract-summary',
                                        refreshable: true
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    };
