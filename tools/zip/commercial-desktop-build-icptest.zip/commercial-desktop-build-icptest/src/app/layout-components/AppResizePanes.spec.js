import Vue from 'vue';
import AppResizePanes from './AppResizePanes.vue';

describe('AppResizePanes', () => {
    let component;

    function _createComponent(config) {
        const Constructor = Vue.extend(AppResizePanes);
        const propsData = config.propsData;
        const events = config.events;
        // build the component and mount it
        component = new Constructor({
            propsData
        });
        if (events) {
            for (let e = 0; e < events.length; e++) {
                const event = events[e];
                component.$on(event.name, event.callback);
            }
        }
        component.$mount();
    }

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('is named app-resize-panes', () => {
        expect(AppResizePanes.name).toEqual('AppResizePanes');
    });

    it('renders a layout with 4 tabs when given a layout property with 4 components', done => {
        _createComponent({
            propsData: {
                layout: [
                    {
                        type: 'tabs',
                        size: 0.4,
                        hideTabs: true,
                        layout: [
                            {
                                title: 'Test',
                                component: 'b-button'
                            }
                        ]
                    },
                    {
                        type: 'tabs',
                        id: 'emulators',
                        size: 0.6,
                        hideTabs: true,
                        layout: [
                            {
                                title: 'Session 1',
                                component: 'b-button'
                            },
                            {
                                title: 'Session 2',
                                component: 'b-button'
                            },
                            {
                                title: 'Session 3',
                                component: 'b-button'
                            }
                        ]
                    }
                ]
            }
        });

        Vue.nextTick(() => {
            expect(component).not.toBe(null);
            expect(component.$el.querySelectorAll('.tab-pane').length).toBe(4);
            done();
        });
    });

    it('sets the view to the specified view name when goToView is executed.', () => {
        _createComponent({});
        component.goToView('test-view');
        expect(component.view).toBe('test-view');
    });

    it('sets the resizing flag to true and calls the onMouseMoveDocument callback when the mouse down event is detected for the left button on a separator.', done => {
        _createComponent({});
        component.onMouseMoveDocument = () => {
            expect(component.resizing).toBe(true);
            expect(component.resizingIndex).toBe(2);
            done();
        };
        component.onMouseDownSeparator({which: 1, preventDefault: () => {}}, 2); // 1 represents a left click
    });

    it('does not set the resizing flag to true and call the onMouseMoveDocument callback when the mouse down event is detected for a non-left button on a separator.', () => {
        _createComponent({});
        component.onMouseMoveDocument = () => {};
        component.onMouseDownSeparator({which: 0, preventDefault: () => {}}, 2); // 0 represents a non-left click
        expect(component.resizing).toBe(false);
    });

    it('resets the resizing flag to false when the mouse up event is detected for the left button.', () => {
        _createComponent({});
        component.resizing = true;
        component.onMouseUpDocument({which: 1}); // 1 represents a left click
        expect(component.resizing).toBe(false);
    });

    it('does not reset the resizing flag to false when the mouse up event is detected for a non-left button.', () => {
        _createComponent({});
        component.resizing = true;
        component.onMouseUpDocument({which: 0}); // 0 represents a non-left click
        expect(component.resizing).toBe(true);
    });

    it('emits a resize event when a mouse move event is detected when resizing mode is enabled', done => {
        _createComponent({
            events: [
                {name: 'resize', callback: () => done()}
            ]
        });
        component.resizing = true;
        component.onMouseMoveDocument({pageX: 0, pageY: 0});
    });

    it('emits a resize event when a resize window event is detected', done => {
        _createComponent({
            events: [
                {name: 'resize', callback: () => done()}
            ]
        });
        component.onResizeWindow();
    });

    it('emits a tab-drag event when the onTabDrag callback is executed.', done => {
        _createComponent({
            events: [
                {name: 'tab-drag', callback: () => done()}
            ]
        });
        component.onTabDrag();
    });

    // TODO this test will break sporadically, may be related to setTimeout
    // it('runs any registered resize event listeners when the window resize event handler runs', done => {
    //     registerResizeListener(e => {
    //         expect(e.name).toBe('test');
    //         done();
    //     });
    //     resizeWindowEventListener({name: 'test'});
    // });
});
