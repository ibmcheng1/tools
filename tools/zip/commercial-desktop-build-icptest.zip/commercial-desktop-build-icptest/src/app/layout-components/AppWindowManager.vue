<template>
    <div
        :class="{ 'app-dragging': draggingTab }"
        class="app-window-manager">
        <div class="app-window-manager-panes">
            <b-tabs
                ref="subscriberGroupTabs"
                class="app-window-manager-layouts"
                data-test-ref="subscriber-group-tab-selection">
                <b-tab
                    v-for="(tab, tabIndex) in panes"
                    :title="tab.title"
                    :key="tabIndex"
                    @click="setActiveTabName(tab.title)">
                    <app-resize-panes
                        :vertical="false"
                        :layout="tab.panes"
                        :id="-1"></app-resize-panes>
                </b-tab>
            </b-tabs>
        </div>
        <div
            v-if="draggingTab"
            :style="{ left: mouseX+'px', top: mouseY+'px' }"
            class="app-window-manager-drag-icon"></div>
    </div>
</template>

<script>

    const resizeListeners = [];

    // Exporting for unit testing
    export const registerResizeListener = (listener) => {
        resizeListeners.push(listener);
    };
    const unregisterResizeListener = (listener) => {
        for (let i = 0, il = resizeListeners.length; i < il; i++) {
            if (resizeListeners[i] === listener) {
                resizeListeners.splice(i, 1);
                break;
            }
        }
    };

    let lastResizeTime = 0;
    let resizeDebounceHandle = null;

    // Exporting for unit testing
    export function resizeWindowEventListener(e) {
        // This throttles & debounces the last call for performance.
        const doResize = () => {
            for (let i = 0, il = resizeListeners.length; i < il; i++) {
                resizeListeners[i](e);
            }
            lastResizeTime = window.performance.now();
        };
        const time = window.performance.now();
        if (time - lastResizeTime > 50) {
            doResize();
        }
        clearTimeout(resizeDebounceHandle);
        resizeDebounceHandle = setTimeout(() => {
            doResize();
        }, 51);
    }

    window.addEventListener('resize', resizeWindowEventListener);

    /**
     * AppWindowManager layout vue component.  This component is the overall desktop window
     * layout manager and controls the overall layout.
     *
     * @class AppWindowManager
     * @memberof app.layout-components
     */
    export default {
        name: 'AppWindowManager',
        props: {
            layout: {
                default: () => {
                    return {
                        panels: [],
                        windows: []
                    };
                },
                type: Object
            }
        },
        data() {
            return {
                docked: [],
                draggingTab: false,
                draggingTabDefinition: null,
                mouseX: 0,
                mouseY: 0,
                panes: [],
                windows: [],
                uidCounter: 0
            };
        },
        watch: {
            layout: {
                immediate: true,
                handler(layout) {
                    if (layout.panes) {
                        // stringify + parse = poor man's clone
                        this.panes = JSON.parse(JSON.stringify(layout.panes));
                    }
                    this.idTabsRecursive(this.docked);
                    this.idTabsRecursive(this.panes);
                    this.idTabsRecursive(this.windows);

                    // Store the desktop layout name in the store for other components' use
                    this.$store.dispatch('setDesktopName', layout.layoutName);
                }
            },
            panes: {
                immediate: true,
                handler(/* panes */) {

                }
            },
            windows: {
                immediate: true,
                handler(/* windows */) {

                }
            }
        },
        mounted() {
            registerResizeListener(this.onResizeWindow);
            // register an event listener for MBR  group tab selection
            this.$root.$on('groupSelectionNotification', this.groupSelectionNotification);
            // register an event listener for MBR subscriber tab selection
            this.$root.$on('subscriberSelectionNotification', this.subscriberSelectionNotification);
        },
        destroyed() {
            unregisterResizeListener(this.onResizeWindow);
        },
        /** @lends app.layout-components.AppWindowManager.prototype */
        methods: {

            /**
             * Recursively builds the layout containers for the application.
             *
             * @param {Element} root the root node to start the recursive building
             */
            idTabsRecursive(root) {
                for (let i = 0, il = root.length; i < il; i++) {
                    if (root[i].layout) {
                        if (root[i].layout[0].component) {
                            root[i].id = root[i].layout[0].component;
                        } else {
                            // this keeps ids from being set to undefined
                            // without it chrome will throw an error for multiple key ids with the same value
                            root[i].id = this.uidCounter++;
                        }
                        this.idTabsRecursive(root[i].layout);
                    } else if (root[i].panes) {
                        this.idTabsRecursive(root[i].panes);
                    }
                }
            },

            /**
             * Callback function for the window resize event.  Emits a custom resize event
             * on this component.
             */
            onResizeWindow(e) {
                this.$emit('resize', e);
            },

            onMinimizeWindow(/* id */) {

            },
            /**
             * Registered event listener selects the <code>Subscriber</code> tab to display the Subscriber view.
             */
            subscriberSelectionNotification() {
                this.$refs.subscriberGroupTabs.setTab(0, true);
            },
            /**
             * Registered event listener selects the <code>Group</code> tab to display the Group view.
             */
            groupSelectionNotification() {
                // TODO replace with attached app
                // When a subscriber is loaded having a group id(s) use a group id value to load the group view components
                if (this.$store.getters.getSubscriber &&
                    this.$store.getters.getSubscriber.subscriber &&
                    this.$store.getters.getSubscriber.subscriber.coverageItems &&
                    this.$store.getters.getSubscriber.subscriber.coverageItems.length > 0) {
                    for (const coverageItem of this.$store.getters.getSubscriber.subscriber.coverageItems) {
                        if (coverageItem.group && coverageItem.group.id) {
                            this.$store.dispatch('setGroupId', coverageItem.group.id);
                            break;
                        }
                    }
                }
                this.$refs.subscriberGroupTabs.setTab(1, true);
            },
            /**
             * store the clicked tab name in the data store
             */
            setActiveTabName(title) {
                this.$store.dispatch('setActiveTabName', title);
            }
        }
    };
</script>
