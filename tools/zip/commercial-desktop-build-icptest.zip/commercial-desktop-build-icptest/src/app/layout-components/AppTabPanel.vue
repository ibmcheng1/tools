<template>
    <b-container
        :class="{
            'breakpoint-min-sm': breakpoints.minSm,
            'breakpoint-min-md': breakpoints.minMd,
            'breakpoint-min-lg': breakpoints.minLg,
            'breakpoint-min-xl': breakpoints.minXl,
            'breakpoint-max-sm': breakpoints.maxSm,
            'breakpoint-max-md': breakpoints.maxMd,
            'breakpoint-max-lg': breakpoints.maxLg,
            'breakpoint-max-xl': breakpoints.maxXl,
            'app-tab-panel-expand-sidebar-left': showLeftSidebar,
            'app-tab-panel-expand-sidebar-right': showRightSidebar
        }"
        :data-layout-id="id"
        fluid
        class="app-tab-panel"
    >
        <b-row no-gutters>
            <b-col class="app-tab-panel-sidebar-left">
                <slot name="sidebar-left"></slot>
            </b-col>
            <b-col
                ref="tabPanelMain"
                class="app-tab-panel-main">
                <div
                    v-if="tabs && tabs[tabIndex] && tabs[tabIndex].refreshable"
                    class="app-tab-panel-controls">
                    <a
                        href="javascript:void(0)"
                        class="fa fa-refresh"
                        @click="refresh">
                        <span class="sr-only">Refresh</span>
                    </a>
                </div>
                <b-card
                    :class="hideTabs ? 'app-tab-panel-tabs-content-only' : null"
                    no-body
                    class="app-tab-panel-tabs">
                    <b-tabs
                        ref="tabs"
                        v-model="tabIndex"
                        card>
                        <b-tab
                            v-for="(tab, i) in tabs"
                            :key="i"
                            :title="tab.title">
                            <b-container
                                v-if="isLoading"
                                fluid
                                class="text-center">
                                <div class="p-3">
                                    <div class="loader"></div>
                                </div>
                            </b-container>
                            <b-container
                                v-if="!isLoading && errorMessage"
                                fluid>
                                <b-row>
                                    <b-alert
                                        variant="danger"
                                        show>
                                        <h3 class="app-tab-panel-title text-center">
                                            {{ errorMessage }}
                                        </h3>
                                    </b-alert>
                                </b-row>
                            </b-container>
                            <div
                                v-show="!isLoading"
                                ref="component"
                                :is="tab.component"
                                :="tab.props"
                                @loading="loading()"
                                @loaded="loaded()"
                                @systemError="systemError()"
                                @authorizationError="authorizationError()">
                            </div>
                        </b-tab>
                    </b-tabs>
                </b-card>
            </b-col>
            <b-col class="app-tab-panel-sidebar-right">
                <slot name="sidebar-right"></slot>
            </b-col>
        </b-row>
    </b-container>
</template>

<script>

    const resizeListeners = [];

    export const registerResizeListener = (listener) => {
        resizeListeners.push(listener);
    };
    const unregisterResizeListener = (listener) => {
        for (let i = 0, il = resizeListeners.length; i < il; i++) {
            if (resizeListeners[i] === listener) {
                resizeListeners.splice(i, 1);
                break;
            }
        }
    };

    let lastResizeTime = 0;
    let resizeDebounceHandle = null;

    // Exporting for unit testing
    export function resizeWindowEventListener(e) {
        // This throttles & debounces the last call for performance.
        const doResize = () => {
            for (let i = 0, il = resizeListeners.length; i < il; i++) {
                resizeListeners[i](e);
            }
            lastResizeTime = window.performance.now();
        };
        const time = window.performance.now();
        if (time - lastResizeTime > 50) {
            doResize();
        }
        clearTimeout(resizeDebounceHandle);
        resizeDebounceHandle = setTimeout(() => {
            doResize();
        }, 51);
    }

    window.addEventListener('resize', resizeWindowEventListener);

    /**
     * AppTabPanel layout vue component.  This component is the tab based wrapper for
     * all business components and integrates with their lifecycle.
     *
     * @class AppTabPanel
     * @memberof app.layout-components
     */
    export default {
        name: 'AppTabPanel',
        props: {
            id: {
                default: null,
                type: [Number, String]
            },
            hideTabs: {
                default: false,
                type: Boolean
            },
            refreshable: {
                default: false,
                type: Boolean
            },
            showLeftSidebar: {
                type: Boolean,
                default: false
            },
            showRightSidebar: {
                type: Boolean,
                default: false
            },
            tabs: {
                default: () => {
                    return [];
                },
                type: Array
            }
        },
        data() {
            return {
                breakpoints: {
                    minSm: false,
                    minMd: false,
                    minLg: false,
                    minXl: false,
                    maxSm: false,
                    maxMd: false,
                    maxLg: false,
                    maxXl: false
                },
                mouseDownTabIndex: -1,
                mouseDownTabX: 0,
                mouseDownTabY: 0,
                isLoading: true,
                errorMessage: '',
                tabIndex: 0
            };
        },
        mounted() {
            if (this.$parent && (this.$parent.$options._componentTag === 'app-window-manager' || this.$parent.$options._componentTag === 'app-resize-panes')) {
                this.$parent.$on('resize', this.onResizeDocument);
            } else {
                registerResizeListener(this.onResizeDocument);
            }

            // Need to wait to run initial sizing calculation.
            setTimeout(() => {
                this.onResizeDocument();
            }, 0);
        },
        destroyed() {
            if (this.$parent) {
                this.$parent.$off('resize', this.onResizeDocument);
            }
            unregisterResizeListener(this.onResizeDocument);
        },
        /** @lends app.layout-components.AppTabPanel.prototype */
        methods: {

            /**
             * Callback for the document resize event.
             * Calculates breakpoints for the AppTabPanel component.
             */
            onResizeDocument() {
                if (this.$refs.tabPanelMain) {
                    const tabContentWidth = this.$refs.tabPanelMain.clientWidth;

                    this.breakpoints.maxSm = (tabContentWidth < 576);
                    this.breakpoints.maxMd = (tabContentWidth < 768);
                    this.breakpoints.maxLg = (tabContentWidth < 992);
                    this.breakpoints.maxXl = (tabContentWidth < 1200);
                    this.breakpoints.minSm = (tabContentWidth >= 576);
                    this.breakpoints.minMd = (tabContentWidth >= 768);
                    this.breakpoints.minLg = (tabContentWidth >= 992);
                    this.breakpoints.minXl = (tabContentWidth >= 1200);
                }
            },

            /**
             * Callback for the loading event from a business component.
             * Sets the isLoading flag to true and clears any current error messages.
             */
            loading() {
                this.isLoading = true;
                this.errorMessage = '';
            },

            /**
             * Callback for the loaded event from a business component.
             * Sets the isLoading flag to false.
             */
            loaded() {
                this.isLoading = false;
            },

            /**
             * Click handler for the refresh icon.  Calls the refreshData method on the
             * business component for the currently selected tab.
             */
            refresh() {
                if (this.$refs.component[this.tabIndex] && this.$refs.component[this.tabIndex].refreshData) {
                    this.$refs.component[this.tabIndex].refreshData(true);
                }
            },

            /**
             * Callback for the systemError event from a business component.
             * Sets the errorMessage field to the standard technical difficulties message.
             */
            systemError() {
                this.errorMessage = 'The system is not responding or is experiencing technical difficulties';
            },

            /**
             * Callback for the authorizationError event from a business component.
             * Sets the errorMessage field to the standard authorization failure message.
             */
            authorizationError() {
                this.errorMessage = 'You do not have authorization to use this feature';
            }
        }
    };
</script>
