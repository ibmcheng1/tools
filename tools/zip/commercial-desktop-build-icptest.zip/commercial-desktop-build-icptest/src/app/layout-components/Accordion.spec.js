import Vue from 'vue';
import Accordion from './Accordion.vue';
import DesktopBaseComponent from '../components/DesktopBaseComponent.vue';

describe('Accordion', () => {
    let component;

    function _createComponent() {
        const Constructor = Vue.extend(Accordion);

        component = new Constructor({}).$mount();
    }

    beforeEach(() => {
        // prevent the component from trying to load contracts or summary links
        spyOn(DesktopBaseComponent.methods, 'refreshData').and.returnValue(1);
        spyOn(DesktopBaseComponent.methods, 'cacheSummaryLinks').and.returnValue(1);
    });

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('is named Accordion', () => {
        expect(Accordion.name).toEqual('Accordion');
    });

    it('constructs without errors', () => {
        _createComponent();
    });
});
