import Vue from 'vue';
import AppWindowManager from './AppWindowManager.vue';
import DataStore from './../store/DataStore.js';

describe('AppWindowManager', () => {
    let component;

    function _createComponent(config) {
        const Constructor = Vue.extend(AppWindowManager);
        // build the component and mount it
        component = new Constructor({
            propsData: {
                layout: config.layout
            },
            store: DataStore.store
        });
        if (config.events) {
            for (let e = 0; e < config.events.length; e++) {
                component.$on(config.events[e].name, config.events[e].callback);
            }
        }
        component.$mount();
    }

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('is named app-window-manager', () => {
        expect(AppWindowManager.name).toEqual('AppWindowManager');
    });

    it('renders a layout with 4 tabs when given a layout property with 4 components', done => {
        _createComponent({
            layout: {
                panes: [
                    {
                        type: '',
                        title: '',
                        panes: [
                            {
                                type: 'panes',
                                size: 1,
                                layout: [
                                    {
                                        type: 'tabs',
                                        size: 0.4,
                                        hideTabs: true,
                                        layout: [
                                            {
                                                title: 'Test',
                                                component: 'b-button'
                                            }
                                        ]
                                    },
                                    {
                                        type: 'tabs',
                                        id: 'emulators',
                                        size: 0.6,
                                        hideTabs: true,
                                        layout: [
                                            {
                                                title: 'Test 1',
                                                component: 'b-button'
                                            },
                                            {
                                                title: 'Test 2',
                                                component: 'b-button'
                                            },
                                            {
                                                title: 'Test 3',
                                                component: 'b-button'
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        });

        Vue.nextTick(() => {
            expect(component).not.toBe(null);
            expect(component.$el.querySelectorAll('.app-resize-panes .tab-pane').length).toBe(4);
            done();
        });
    });

    it('renders a layout with 1 tab, the tab title is set as the data-layout-id', done => {
        _createComponent({
            layout: {
                panes: [
                    {
                        type: '',
                        title: '',
                        panes: [
                            {
                                type: 'panes',
                                size: 1,
                                layout: [
                                    {
                                        type: 'tabs',
                                        size: 0.4,
                                        hideTabs: true,
                                        layout: [
                                            {
                                                title: 'Test',
                                                component: 'b-button'
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        });

        Vue.nextTick(() => {
            const dataLayoutIds = component.$el.querySelectorAll('[data-layout-id=b-button]');
            expect(component).not.toBe(null);
            expect(dataLayoutIds.length).toBe(1);
            done();
        });
    });

    it('emits a resize event when the onResizeWindow callback is executed.', done => {
        _createComponent({
            layout: {panes: []},
            events: [
                {name: 'resize', callback: () => done()}
            ]
        });
        component.onResizeWindow();
    });

    // TODO this test will break poradically, may be related to setTimeout
    // it('runs any registered resize event listeners when the window resize event handler runs', done => {
    //     registerResizeListener(e => {
    //         expect(e.name).toBe('test');
    //         done();
    //     });
    //     resizeWindowEventListener({name: 'test'});
    // });

    it('calls registered subscriber tab listener', done => {
        const subscriberListenerSpy = spyOn(AppWindowManager.methods, 'subscriberSelectionNotification').and.callThrough();
        _createComponent({
            layout: {panes: []}
        });

        component.$root.$emit('subscriberSelectionNotification');

        Vue.nextTick(() => {
            expect(subscriberListenerSpy).toHaveBeenCalled();
            done();
        });
    });

    it('calls registered group tab listener', done => {
        const groupListenerSpy = spyOn(AppWindowManager.methods, 'groupSelectionNotification').and.returnValue(1);
        _createComponent({
            layout: {panes: []}
        });

        component.$root.$emit('groupSelectionNotification');

        Vue.nextTick(() => {
            expect(groupListenerSpy).toHaveBeenCalled();
            done();
        });
    });

    it('sets the group id in the store when the subscriber has group coverage', done => {
        _createComponent({
            layout: {panes: []}
        });

        const subscriber = {subscriber: {coverageItems: [{group: {id: 123456}}]}
        };

        component.$store.commit('SET_SUBSCRIBER', subscriber);
        component.$root.$emit('groupSelectionNotification');

        Vue.nextTick(() => {
            expect(component.$store.getters.getGroupId).toBe(123456);
            done();
        });
    });

    it('does not set the group id in the store when the subscriber has no group coverage', done => {
        _createComponent({
            layout: {panes: []}
        });

        const subscriber = {};

        component.$store.commit('SET_SUBSCRIBER', subscriber); // subscriber does not have group coverage
        component.$store.commit('SET_GROUP_ID', ''); // reset the group id
        component.$root.$emit('groupSelectionNotification');

        Vue.nextTick(() => {
            expect(component.$store.getters.getGroupId).toBe('');
            done();
        });
    });
});
