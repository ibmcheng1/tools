<template>
    <b-button
        class="accordion-item"
        @click="$emit('activate', treeDefinition)">
        <template v-if="treeDefinition && treeDefinition.description">{{ treeDefinition.description }}</template>
        <slot></slot>
    </b-button>
</template>

<script>

    /**
     * Accordion item layout vue component.
     *
     * @class AccordionItem
     * @memberof app.layout-components
     */
    export default {
        name: 'AccordionItem',

        props: {
            treeDefinition: {
                default: null,
                type: Object
            }
        }
    };

</script>
