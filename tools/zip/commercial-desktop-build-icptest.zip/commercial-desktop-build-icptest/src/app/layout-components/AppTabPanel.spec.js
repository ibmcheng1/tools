import Vue from 'vue';
import AppTabPanel from './AppTabPanel.vue';

describe('AppTabPanel', () => {
    let component;

    function _createComponent(config) {
        const Constructor = Vue.extend(AppTabPanel);
        const propsData = config.propsData;
        const events = config.events;
        // build the component and mount it
        component = new Constructor({
            propsData
        });
        if (events) {
            for (let e = 0; e < events.length; e++) {
                const event = events[e];
                component.$on(event.name, event.callback);
            }
        }
        component.$mount();
    }

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('is named app-tab-panel', () => {
        expect(AppTabPanel.name).toEqual('AppTabPanel');
    });

    it('sets the isLoading flag to true and clears any error messages when the loading method is executed', () => {
        _createComponent({});
        component.isLoading = false;
        component.errorMessage = 'the sky is falling!';
        component.loading();
        expect(component.isLoading).toBe(true);
        expect(component.errorMessage).toBe('');
    });

    it('sets the errorMessage to the technical difficulties message when the systemError method is executed', () => {
        _createComponent({});
        component.errorMessage = '';
        component.systemError();
        expect(component.errorMessage).toBe('The system is not responding or is experiencing technical difficulties');
    });

    it('sets the errorMessage to the authorization message when the authorizationError method is executed', () => {
        _createComponent({});
        component.errorMessage = '';
        component.authorizationError();
        expect(component.errorMessage).toBe('You do not have authorization to use this feature');
    });

    // TODO this test will break poradically, may be related to setTimeout
    // it('runs any registered resize event listeners when the window resize event handler runs', done => {
    //     registerResizeListener(e => {
    //         expect(e.name).toBe('test');
    //         done();
    //     });
    //     resizeWindowEventListener({name: 'test'});
    // });
});
