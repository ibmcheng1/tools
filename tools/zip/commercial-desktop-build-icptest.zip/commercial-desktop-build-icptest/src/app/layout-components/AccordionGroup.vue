<template>
    <b-card
        no-body
        class="accordion-group">
        <b-card-header role="tab">
            <b-button
                v-b-toggle="id"
                href="javascript:void(0)">
                <template v-if="treeDefinition && treeDefinition.description">{{ treeDefinition.description }}</template>
                <slot name="title"></slot>
            </b-button>
        </b-card-header>
        <b-collapse
            :id="id"
            role="tabpanel">
            <b-card-body>
                <template v-if="treeDefinition">
                    <template v-for="(branch, i) of treeDefinition.children">
                        <accordion-group
                            v-if="branch.children"
                            :key="i"
                            :tree-definition="branch"
                            @activate="$emit('activate', $event)"/>
                        <accordion-item
                            v-else
                            :key="i"
                            :tree-definition="branch"
                            @activate="$emit('activate', $event)"/>
                    </template>
                </template>
                <slot></slot>
            </b-card-body>
        </b-collapse>
    </b-card>
</template>

<script>
    // Counter for automatic unique ID of b-collapse components.
    let UID_COUNTER = 0;

    /**
     * Accordion group layout vue component.
     *
     * @class AccordionGroup
     * @memberof app.layout-components
     */
    export default {
        name: 'AccordionGroup',

        props: {
            treeDefinition: {
                default: null,
                type: Object
            }
        },

        data() {
            return {
                id: null
            };
        },

        /**
         * Vue lifecycle callback for component creation
         */
        created() {
            this.id = 'accordion-uid-' + UID_COUNTER++;
        }
    };

</script>
