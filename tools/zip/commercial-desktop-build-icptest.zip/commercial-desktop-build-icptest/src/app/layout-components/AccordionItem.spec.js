import Vue from 'vue';
import AccordionItem from './AccordionItem.vue';
import DesktopBaseComponent from '../components/DesktopBaseComponent.vue';

describe('AccordionItem', () => {
    let component;

    function _createComponent() {
        const Constructor = Vue.extend(AccordionItem);

        component = new Constructor({}).$mount();
    }

    beforeEach(() => {
        // prevent the component from trying to load contracts or summary links
        spyOn(DesktopBaseComponent.methods, 'refreshData').and.returnValue(1);
        spyOn(DesktopBaseComponent.methods, 'cacheSummaryLinks').and.returnValue(1);
    });

    afterEach(() => {
        if (component) {
            component.$destroy();
        }
    });

    it('is named AccordionItem', () => {
        expect(AccordionItem.name).toEqual('AccordionItem');
    });

    it('constructs without errors', () => {
        _createComponent();
    });
});
