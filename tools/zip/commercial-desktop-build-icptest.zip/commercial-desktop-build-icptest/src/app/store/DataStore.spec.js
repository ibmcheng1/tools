import {mutations, actions, subscriberCancelTokenSource, contractsCancelTokenSource, familyCancelTokenSource,
        contactHistoryCancelTokenSource, exceptionsCancelTokenSource, callCenterAttrCancelTokenSource,
        applicationControlLinksCancelTokenSource, contactHistoryFilterCancelTokenSource, activitySummaryCancelTokenSource, coverageSummaryCancelTokenSource, billingSummarySubscriberCancelTokenSource,
        billingSummaryGroupCancelTokenSource, patientSummaryCancelTokenSource, groupSummaryCancelTokenSource,
        alertsCancelTokenSource, navLinksCancelTokenSource, navLinkCategoriesCancelTokenSource} from './DataStore';

import {axios} from './config.js';

const {SET_DESKTOP_STATE} = mutations;
const {SET_DATABASE_ID} = mutations;
const {SET_SUBSCRIBER} = mutations;
const {SET_CONTRACTS} = mutations;
const {SET_FAMILY} = mutations;
const {SET_EXCEPTIONS} = mutations;
const {SET_PATIENT_ID} = mutations;
const {SET_CONTACT_HISTORY} = mutations;
const {SET_CALL_CENTER_ATTRIBUTES} = mutations;
const {SET_ACTIVITY_SUMMARY} = mutations;
const {SET_COVERAGE_SUMMARY} = mutations;
const {SET_BILLING_SUMMARY_SUBSCRIBER} = mutations;
const {SET_BILLING_SUMMARY_GROUP} = mutations;
const {SET_PATIENT_SUMMARY} = mutations;
const {SET_GROUP_ID} = mutations;
const {SET_GROUP_SUMMARY} = mutations;
const {SET_ALERTS} = mutations;
const {SET_SELECTED_PRODUCT} = mutations;

describe('DataStore', () => {
    /**
     * Actions
     */
    it('should set desktop state', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.setDesktopState(spy, 'test');
        expect(spy.commit).toHaveBeenCalledWith('SET_DESKTOP_STATE', 'test');
    });

    it('should set database ID', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.setDatabaseId(spy, 'test');
        expect(spy.commit).toHaveBeenCalledWith('SET_DATABASE_ID', 'test');
    });

    it('should clear the Database ID', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.clearDatabaseId(spy);
        expect(spy.commit).toHaveBeenCalledWith('SET_DATABASE_ID', '');
    });

    it('should set the active tab name', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.setActiveTabName(spy, 'test');
        expect(spy.commit).toHaveBeenCalledWith('SET_ACTIVE_TAB_NAME', 'test');
    });

    it('should set the desktop name', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.setDesktopName(spy, 'test');
        expect(spy.commit).toHaveBeenCalledWith('SET_DESKTOP_NAME', 'test');
    });

    it('should retrieve summary links', done => {
        const context = {};

        const promise = actions.retrieveSummaryLinks(context, {component: 'FamilySummary'});

        promise.then(data => {
            expect(data).toBeDefined();
            done();
        });
    });

    it('should retrieve MBR summary links for subscriber summary', done => {
        const context = {};

        const promise = actions.retrieveSummaryLinks(context, {component: 'SubscriberSummary', desktopName: 'MBR'});

        promise.then(data => {
            expect(data).toBeDefined();
            done();
        });
    });

    it('should not retrieve summary links', done => {
        const context = {};

        const promise = actions.retrieveSummaryLinks(context, {component: 'shouldnotwork'});

        promise.catch(error => {
            expect(error).toBeDefined();
            done();
        });
    });

    it('should retrieve contracts', done => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        const promise = actions.retrieveContracts(spy, {memberKeyId: '123456789'});
        promise.then(data => {
            expect(data).toBeDefined();
            expect(spy.commit).toHaveBeenCalledWith('SET_CONTRACTS', data);
            done();
        });
    });

    it('should not retrieve contracts', done => {
        const context = {};

        const promise = actions.retrieveContracts(context, {memberKeyId: 'shouldnotwork'});

        promise.catch(error => {
            expect(error).toBeDefined();
            done();
        });
    });

    it('should cancel retrieve contracts', () => {
        const context = {};

        actions.retrieveContracts(context, {memberKeyId: '123456789'});
        contractsCancelTokenSource.cancel('test cancel');
    });

    it('should clear the contracts', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.retrieveContracts(spy, {memberKeyId: '123456789'});
        actions.clearContracts(spy);

        expect(spy.commit).toHaveBeenCalledWith('SET_CONTRACTS', {});
    });

    it('should retrieve subscriber', done => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        const promise = actions.retrieveSubscriber(spy, {memberKeyId: '123456789'});

        promise.then(data => {
            expect(data).toBeDefined();
            expect(spy.commit).toHaveBeenCalledWith('SET_SUBSCRIBER', data);
            done();
        });
    });

    it('should not retrieve subscriber', done => {
        const context = {};

        const promise = actions.retrieveSubscriber(context, {memberKeyId: 'shouldnotwork'});

        promise.catch(error => {
            expect(error).toBeDefined();
            done();
        });
    });

    it('should cancel retrieve subscriber', () => {
        const context = {};

        actions.retrieveSubscriber(context, {memberKeyId: '123456789'});
        subscriberCancelTokenSource.cancel('test cancel');
    });

    it('should clear the subscriber', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.retrieveSubscriber(spy, {memberKeyId: '123456789'});
        actions.clearSubscriber(spy);

        expect(spy.commit).toHaveBeenCalledWith('SET_SUBSCRIBER', {});
    });

    it('should retrieve family', done => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        const promise = actions.retrieveFamily(spy, {memberKeyId: '123456789'});

        promise.then(data => {
            expect(data).toBeDefined();
            expect(spy.commit).toHaveBeenCalledWith('SET_FAMILY', data);
            done();
        });
    });

    it('should not retrieve family', done => {
        const context = {};

        const promise = actions.retrieveFamily(context, {memberKeyId: 'shouldnotwork'});

        promise.catch(error => {
            expect(error).toBeDefined();
            done();
        });
    });

    it('should cancel retrieve family', () => {
        const context = {};

        actions.retrieveFamily(context, {memberKeyId: '123456789'});
        familyCancelTokenSource.cancel('test cancel');
    });

    it('should clear the family', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.retrieveFamily(spy, {memberKeyId: '123456789'});
        actions.clearFamily(spy);

        expect(spy.commit).toHaveBeenCalledWith('SET_FAMILY', {});
    });

    it('should retrieve contacts', done => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        const promise = actions.retrieveContactHistory(spy, {memberKeyId: '123456789'});

        promise.then(data => {
            expect(data).toBeDefined();
            expect(spy.commit).toHaveBeenCalledWith('SET_CONTACT_HISTORY', data);
            done();
        });
    });

    it('should not retrieve contacts', done => {
        const context = {};

        const promise = actions.retrieveContactHistory(context, {memberKeyId: 'shouldnotwork'});

        promise.catch(error => {
            expect(error).toBeDefined();
            done();
        });
    });

    it('should cancel retrieve contacts', () => {
        const context = {};

        actions.retrieveContactHistory(context, {memberKeyId: '123456789'});
        contactHistoryCancelTokenSource.cancel('test cancel');
    });

    it('should clear the contacts', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.retrieveContactHistory(spy, {memberKeyId: '123456789'});
        actions.clearContactHistory(spy);

        expect(spy.commit).toHaveBeenCalledWith('SET_CONTACT_HISTORY', {});
    });

    it('should retrieve exceptions', done => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        const promise = actions.retrieveExceptions(spy, {memberKeyId: '123456789'});

        promise.then(data => {
            expect(data).toBeDefined();
            expect(spy.commit).toHaveBeenCalledWith('SET_EXCEPTIONS', data);
            done();
        });
    });

    it('should not retrieve exceptions', done => {
        const context = {};

        const promise = actions.retrieveExceptions(context, {memberKeyId: 'shouldnotwork'});

        promise.catch(error => {
            expect(error).toBeDefined();
            done();
        });
    });

    it('should cancel retrieve exceptions', () => {
        const context = {};

        actions.retrieveExceptions(context, {memberKeyId: '123456789'});
        exceptionsCancelTokenSource.cancel('test cancel');
    });

    it('should clear the exceptions', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.retrieveExceptions(spy, {memberKeyId: '123456789'});
        actions.clearExceptions(spy);

        expect(spy.commit).toHaveBeenCalledWith('SET_EXCEPTIONS', {});
    });

    it('should clear the Patient ID', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.clearPatientId(spy);
        expect(spy.commit).toHaveBeenCalledWith('SET_PATIENT_ID', '');
    });

    it('should retrieve call center attributes', done => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        const promise = actions.retrieveCallCenterAttributes(spy, {callCenterName: 'BCBSSCSandbox', coverageType: 'Health'});
        promise.then(data => {
            expect(data).toBeDefined();
            expect(spy.commit).toHaveBeenCalledWith('SET_CALL_CENTER_ATTRIBUTES', data);
            done();
        });
    });

    it('should retrieve application control links', done => {
        const context = {};

        const promise = actions.retrieveApplicationControlLinks(context, 'CSR');
        promise.then(data => {
            expect(data).toBeDefined();
            done();
        });
    });

    it('should NOT retrieve call center attributes', done => {
        const context = {};

        const promise = actions.retrieveCallCenterAttributes(context, {callCenterName: 'FOO', coverageType: 'BAR'});

        promise.catch(error => {
            expect(error).toBeDefined();
            done();
        });
    });

    it('should retrieve a default set of application control links when the application control links service fails.', done => {
        const context = {};

        const promise = actions.retrieveApplicationControlLinks(context, 'causeerror');
        promise.then(data => {
            expect(data).toBeDefined();
            expect(data.length).toBe(2);
            done();
        });
    });

    it('should cancel retrieve call center attributes', () => {
        const context = {};

        actions.retrieveCallCenterAttributes(context, {callCenterName: 'BCBSSCSandbox', coverageType: 'Health'});
        callCenterAttrCancelTokenSource.cancel('test cancel');
    });

    it('should clear the call center attributes', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.retrieveCallCenterAttributes(spy, {callCenterName: 'BCBSSCSandbox', coverageType: 'Health'});
        actions.clearCallCenterAttributes(spy);

        expect(spy.commit).toHaveBeenCalledWith('SET_CALL_CENTER_ATTRIBUTES', {});
    });

    it('should cancel retrieve application control links', () => {
        const context = {};

        actions.retrieveApplicationControlLinks(context);
        applicationControlLinksCancelTokenSource.cancel('test cancel');
    });

    it('should retrieve contact history filter', done => {
        const promise = actions.retrieveContactHistoryFilter({});

        promise.then(data => {
            expect(data).toBeDefined();
            done();
        });
    });

    it('should retrieve activity summary', done => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        const promise = actions.retrieveActivitySummary(spy, {subscriberId: '111111111', memberKeyId: '001', includeVoids: 'true', lastViewedAuthorization: 'W123456789'});

        promise.then(data => {
            expect(data).toBeDefined();
            expect(spy.commit).toHaveBeenCalledWith('SET_ACTIVITY_SUMMARY', data);
            done();
        });
    });

    it('should cancel retrieve activity summary', () => {
        const context = {};

        actions.retrieveActivitySummary(context, {subscriberId: '111111111', memberKeyId: '001', includeVoids: 'true', lastViewedAuthorization: 'W123456789'});
        activitySummaryCancelTokenSource.cancel('test cancel');
    });

    it('should NOT retrieve activity summary', done => {
        const context = {};

        const promise = actions.retrieveActivitySummary(context, {subscriberId: 'shouldnotwork'});

        promise.catch(error => {
            expect(error).toBeDefined();
            done();
        });
    });

    it('should cancel retrieve contact history filter', () => {
        actions.retrieveContactHistoryFilter({});
        contactHistoryFilterCancelTokenSource.cancel('test cancel');
    });

    it('should clear the activity summary', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.retrieveActivitySummary(spy, {subscriberId: '111111111', memberKeyId: '001', includeVoids: 'true', lastViewedAuthorization: 'W123456789'});
        actions.clearActivitySummary(spy);

        expect(spy.commit).toHaveBeenCalledWith('SET_ACTIVITY_SUMMARY', {});
    });

    it('should retrieve coverage summary', done => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        const promise = actions.retrieveCoverageSummary(spy, {memberKeyId: '123456789'});
        promise.then(data => {
            expect(data).toBeDefined();
            expect(spy.commit).toHaveBeenCalledWith('SET_COVERAGE_SUMMARY', data);
            done();
        });
    });

    it('should not retrieve coverage summary', done => {
        const context = {};

        const promise = actions.retrieveCoverageSummary(context, {memberKeyId: 'shouldnotwork'});

        promise.catch(error => {
            expect(error).toBeDefined();
            done();
        });
    });

    it('should cancel retrieve coverage summary', () => {
        const context = {};

        actions.retrieveCoverageSummary(context, {memberKeyId: '123456789'});
        coverageSummaryCancelTokenSource.cancel('test cancel');
    });

    it('should retrieve billing summary for subscriber', done => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        const promise = actions.retrieveBillingSummarySubscriber(spy, {subscriberId: '111111111'});

        promise.then(data => {
            expect(data).toBeDefined();
            expect(spy.commit).toHaveBeenCalledWith('SET_BILLING_SUMMARY_SUBSCRIBER', data);
            done();
        });
    });

    it('should cancel retrieve billing summary for subscriber', () => {
        const context = {};

        actions.retrieveBillingSummarySubscriber(context, {subscriberId: '111111111'});
        billingSummarySubscriberCancelTokenSource.cancel('test cancel');
    });

    it('should NOT retrieve billing summary for subscriber', done => {
        const context = {};

        const promise = actions.retrieveBillingSummarySubscriber(context, {subscriberId: 'shouldnotwork'});

        promise.catch(error => {
            expect(error).toBeDefined();
            done();
        });
    });

    it('should clear the contracts', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.retrieveCoverageSummary(spy, {memberKeyId: '123456789'});
        actions.clearCoverageSummary(spy);

        expect(spy.commit).toHaveBeenCalledWith('SET_COVERAGE_SUMMARY', {});
    });

    it('should clear the billing summary for subscriber', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.retrieveBillingSummarySubscriber(spy, {subscriberId: '111111111'});
        actions.clearBillingSummarySubscriber(spy);

        expect(spy.commit).toHaveBeenCalledWith('SET_BILLING_SUMMARY_SUBSCRIBER', {});
    });

    it('should retrieve billing summary for group', done => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        const promise = actions.retrieveBillingSummaryGroup(spy, {billingSummaryGroupId: 'abc123def456'});

        promise.then(data => {
            expect(data).toBeDefined();
            expect(spy.commit).toHaveBeenCalledWith('SET_BILLING_SUMMARY_GROUP', data);
            done();
        });
    });

    it('should cancel retrieve billing summary for group', () => {
        const context = {};

        actions.retrieveBillingSummaryGroup(context, {billingSummaryGroupId: 'abc123def456'});
        billingSummaryGroupCancelTokenSource.cancel('test cancel');
    });

    it('should NOT retrieve billing summary for group', done => {
        const context = {};

        const promise = actions.retrieveBillingSummaryGroup(context, {billingSummaryGroupId: 'shouldnotwork'});

        promise.catch(error => {
            expect(error).toBeDefined();
            done();
        });
    });

    it('should clear the billing summary for group', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.retrieveBillingSummaryGroup(spy, {billingSummaryGroupId: 'abc123def456'});
        actions.clearBillingSummaryGroup(spy);

        expect(spy.commit).toHaveBeenCalledWith('SET_BILLING_SUMMARY_GROUP', {});
    });

    it('should retrieve patient summary', done => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        const promise = actions.retrievePatientSummary(spy, {memberKeyId: '111111111', patientId: '001'});

        promise.then(data => {
            expect(data).toBeDefined();
            expect(spy.commit).toHaveBeenCalledWith('SET_PATIENT_SUMMARY', data);
            done();
        });
    });

    it('should cancel retrieve patient summary', () => {
        const context = {};

        actions.retrievePatientSummary(context, {memberKeyId: '111111111', patientId: '001'});
        patientSummaryCancelTokenSource.cancel('test cancel');
    });

    it('should NOT retrieve patient summary', done => {
        const context = {};

        const promise = actions.retrievePatientSummary(context, {memberKeyId: 'shouldnotwork', patientId: 'shouldnotwork'});

        promise.catch(error => {
            expect(error).toBeDefined();
            done();
        });
    });

    it('should clear the patient summary', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.retrievePatientSummary(spy, {memberKeyId: '111111111', patientId: '001'});
        actions.clearPatientSummary(spy);

        expect(spy.commit).toHaveBeenCalledWith('SET_PATIENT_SUMMARY', {});
    });

    it('should set Group ID', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.setGroupId(spy, 'test');
        expect(spy.commit).toHaveBeenCalledWith('SET_GROUP_ID', 'test');
    });

    it('should clear the Group ID', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.clearGroupId(spy);
        expect(spy.commit).toHaveBeenCalledWith('SET_GROUP_ID', '');
    });

    it('should retrieve group summary', done => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        const promise = actions.retrieveGroupSummary(spy, {groupSummaryId: 'abc123def456'});

        promise.then(data => {
            expect(data).toBeDefined();
            expect(spy.commit).toHaveBeenCalledWith('SET_GROUP_SUMMARY', data);
            done();
        });
    });

    it('should cancel retrieve group summary', () => {
        const context = {};

        actions.retrieveGroupSummary(context, {groupSummaryId: 'abc123def456'});
        groupSummaryCancelTokenSource.cancel('test cancel');
    });

    it('should NOT retrieve group summary', done => {
        const context = {};

        const promise = actions.retrieveGroupSummary(context, {groupSummaryId: 'shouldnotwork'});

        promise.catch(error => {
            expect(error).toBeDefined();
            done();
        });
    });

    it('should clear the group summary', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.retrieveGroupSummary(spy, {groupSummaryId: 'abc123def456'});
        actions.clearGroupSummary(spy);

        expect(spy.commit).toHaveBeenCalledWith('SET_GROUP_SUMMARY', {});
    });

    it('should retrieve alerts', done => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        const promise = actions.retrieveAlerts(spy, {memberKeyId: '123', selectedProductCode: 'DRG'});

        promise.then(data => {
            expect(data).toBeDefined();
            expect(spy.commit).toHaveBeenCalledWith('SET_ALERTS', data);
            done();
        });
    });

    it('should cancel retrieve alerts', () => {
        const context = {};

        actions.retrieveAlerts(context, {memberKeyId: '123', selectedProductCode: 'DRG'});
        alertsCancelTokenSource.cancel('test cancel');
    });

    it('should NOT retrieve alerts', done => {
        const context = {};

        const promise = actions.retrieveAlerts(context, {memberKeyId: 'shouldnot', selectedProductCode: 'work'});

        promise.catch(error => {
            expect(error).toBeDefined();
            done();
        });
    });

    it('should clear the alerts', () => {
        const spy = jasmine.createSpyObj('context', ['commit']);

        actions.retrieveAlerts(spy, {memberKeyId: '123', selectedProductCode: 'DRG'});
        actions.clearAlerts(spy);

        expect(spy.commit).toHaveBeenCalledWith('SET_ALERTS', {});
    });

    it('should retrieve nav links', done => {
        const context = {};

        const promise = actions.retrieveNavLinks(context, 'C00730-C00740');

        promise.then(data => {
            expect(data).toBeDefined();
            done();
        });
    });

    it('should cancel retrieve nav links', () => {
        const context = {};

        actions.retrieveNavLinks(context, 'C00730-C00740');
        navLinksCancelTokenSource.cancel('test cancel');
    });

    it('should NOT retrieve nav links', done => {
        const context = {};

        const promise = actions.retrieveNavLinks(context, 'thiswillnotwork');

        promise.catch(error => {
            expect(error).toBeDefined();
            done();
        });
    });

    it('should retrieve nav link categories', done => {
        const context = {};

        const promise = actions.retrieveNavLinkCategories(context, 'MBR');

        promise.then(data => {
            expect(data).toBeDefined();
            done();
        });
    });

    it('should cancel retrieve nav link categories', () => {
        const context = {};

        actions.retrieveNavLinkCategories(context, 'C00730-C00740');
        navLinkCategoriesCancelTokenSource.cancel('test cancel');
    });

    it('should NOT retrieve nav link categories', done => {
        const context = {};

        const promise = actions.retrieveNavLinkCategories(context, 'thiswillnotwork');

        promise.catch(error => {
            expect(error).toBeDefined();
            done();
        });
    });

    /**
     * Mutations
     */
    it('should set the Desktop State', () => {
        const state = {desktopState: 'test'};

        SET_DESKTOP_STATE(state, 'TEST');

        expect(state.desktopState).toEqual('TEST');
    });

    it('should set the Database ID', () => {
        const state = {databaseId: 'test'};

        SET_DATABASE_ID(state, 'TEST');

        expect(state.databaseId).toEqual('TEST');
    });

    it('should set the subscriber', () => {
        const state = {subscriber: 'test'};

        SET_SUBSCRIBER(state, 'TEST');

        expect(state.subscriber).toEqual('TEST');
    });

    it('should set the contracts', () => {
        const state = {contracts: 'test'};

        SET_CONTRACTS(state, 'TEST');

        expect(state.contracts).toEqual('TEST');
    });

    it('should set the family', () => {
        const state = {family: 'test'};

        SET_FAMILY(state, 'TEST');

        expect(state.family).toEqual('TEST');
    });

    it('should set the exceptions', () => {
        const state = {exceptions: 'test'};

        SET_EXCEPTIONS(state, 'TEST');

        expect(state.exceptions).toEqual('TEST');
    });

    it('should set the Patient ID', () => {
        const state = {patientId: 'test'};

        SET_PATIENT_ID(state, 'TEST');

        expect(state.patientId).toEqual('TEST');
    });

    it('should set the contactHistory', () => {
        const state = {contactHistory: 'test'};

        SET_CONTACT_HISTORY(state, 'TEST');

        expect(state.contactHistory).toEqual('TEST');
    });

    it('should set the call center attributes', () => {
        const state = {callCenterAttributes: 'test'};

        SET_CALL_CENTER_ATTRIBUTES(state, 'TEST');

        expect(state.callCenterAttributes).toEqual('TEST');
    });

    it('should set the Activity Summary', () => {
        const state = {test: 'test'};

        SET_ACTIVITY_SUMMARY(state, 'TEST');

        expect(state.activitySummary).toEqual('TEST');
    });

    it('should set the Coverage Summary', () => {
        const state = {test: 'test'};

        SET_COVERAGE_SUMMARY(state, 'TEST');

        expect(state.coverageSummary).toEqual('TEST');
    });

    it('should set the Subscriber Billing Summary', () => {
        const state = {test: 'test'};

        SET_BILLING_SUMMARY_SUBSCRIBER(state, 'TEST');

        expect(state.billingSummarySubscriber).toEqual('TEST');
    });

    it('should set the Group Billing Summary', () => {
        const state = {test: 'test'};

        SET_BILLING_SUMMARY_GROUP(state, 'TEST');

        expect(state.billingSummaryGroup).toEqual('TEST');
    });

    it('should set the Patient Summary', () => {
        const state = {test: 'test'};

        SET_PATIENT_SUMMARY(state, 'TEST');

        expect(state.patientSummary).toEqual('TEST');
    });

    it('should set the Group Id', () => {
        const state = {test: 'test'};

        SET_GROUP_ID(state, 'TEST');

        expect(state.groupId).toEqual('TEST');
    });

    it('should set the Group Summary', () => {
        const state = {test: 'test'};

        SET_GROUP_SUMMARY(state, 'TEST');

        expect(state.groupSummary).toEqual('TEST');
    });

    it('should set the Alerts', () => {
        const state = {test: 'test'};

        SET_ALERTS(state, 'TEST');

        expect(state.alerts).toEqual('TEST');
    });

    it('should set the Selected Product', () => {
        const state = {test: 'test'};

        SET_SELECTED_PRODUCT(state, 'TEST');

        expect(state.selectedProductCode).toEqual('TEST');
    });
});
