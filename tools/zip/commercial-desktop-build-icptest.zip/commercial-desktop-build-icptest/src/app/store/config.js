/**
 * Configures the endpoints and determines if mocked responses should be used
 */

import Axios from 'axios';
import MockAdapter from 'axios-mock-adapter';

import {mockSubscriber} from './mock/subscriber-summary/SubscriberMock.js';
import {mockSubscriberSummaryLinks} from './mock/subscriber-summary/SubscriberSummaryLinksMock.js';
import {mockSubscriber as numberOne} from './mock/subscriber-summary/NumberOneMock.js';
import {mockSubscriberSummaryLinks as mbrSummaryLinks} from './mock/subscriber-summary/MBR-SubscriberSummaryLinksMock.js';

import {mockContract} from './mock/contract-summary/ContractMock.js';
import {mockContractSummaryLinks} from './mock/contract-summary/ContractSummaryLinksMock.js';

import {mockFamily} from './mock/family-summary/FamilyMock.js';
import {mockFamilySummaryLinks} from './mock/family-summary/FamilySummaryLinksMock.js';

import {mockExceptions} from './mock/exceptions-summary/ExceptionsMock.js';
import {mockExceptionsNoAlerts} from './mock/exceptions-summary/ExceptionsMockNoAlerts.js';

import {mockNotAuthorized} from './mock/NotAuthorizedMock.js';
import {mockServiceError} from './mock/ServiceErrorMock.js';

import {mockContacts} from './mock/contact-history/ContactHistoryMock.js';
import {mockContactsFilter} from './mock/contact-history/ContactHistoryFilterMock.js';

import {mockNavLinkCategories} from './mock/nav-links/NavLinkCategoriesMock.js';
import {mockNavLinkCategoriesMbr} from './mock/nav-links/NavLinkCategoriesMbrMock.js';
import {mockNavLinkCategoriesMcs} from './mock/nav-links/NavLinkCategoriesMcsMock.js';

import {mockNavLinks as claimsAndBenefits} from './mock/nav-links/ClaimsAndBenefitsNavLinksMock.js';
import {mockNavLinks as claimsAdjustments} from './mock/nav-links/ClaimsAdjustmentsNavLinksMock.js';
import {mockNavLinks as claimsDental} from './mock/nav-links/ClaimsDentalNavLinksMock.js';
import {mockNavLinks as claimsHealth} from './mock/nav-links/ClaimsHealthNavLinksMock.js';

import {mockNavLinks as createAndMaintainGroup} from './mock/nav-links/CreateAndMaintainGroupNavLinks.js';
import {mockNavLinks as createAndMaintainGroupSetup} from './mock/nav-links/CreateAndMaintainGroupSetupNavLinks.js';
import {mockNavLinks as createAndMaintainGroupUpdate} from './mock/nav-links/CreateAndMaintainGroupUpdateNavLinks.js';
import {mockNavLinks as createAndMaintainGroupInquiry} from './mock/nav-links/CreateAndMaintainGroupInquiryNavLinks.js';
import {mockNavLinks as createAndMaintainBill} from './mock/nav-links/CreateAndMaintainBillProcessingNavLinks.js';
import {mockNavLinks as agentAndAgency} from './mock/nav-links/AgentAgencyNavLinksMock.js';

import {mockNavLinks as documentNavCategory} from './mock/nav-links/DocumentsNavLinksMock.js';
import {mockNavLinks as researchHealthClaims} from './mock/nav-links/ResearchHealthClaimsNavLinksMock.js';
import {mockNavLinks as ammsClaimScreens} from './mock/nav-links/AmmsClaimScreensNavLinksMock.js';

import {mockAlerts} from './mock/alerts/AlertsMock.js';
import {mockNoAlerts} from './mock/alerts/NoAlertsMock.js';
import {mockCallCenterAttributesHealth} from './mock/call-center-data/CallCenterMockHealth.js';
import {mockCallCenterAttributesDental} from './mock/call-center-data/CallCenterMockDental.js';

import {mockApplicationControlLinksCsr} from './mock/application-control-links/ApplicationControlLinksMockCSR.js';
import {mockApplicationControlLinksMcs} from './mock/application-control-links/ApplicationControlLinksMockMCS.js';
import {mockApplicationControlLinksMbr} from './mock/application-control-links/ApplicationControlLinksMockMBR.js';

import {mockPatientSummary as mockPatientOne} from './mock/patient-summary/PatientSummaryOneMock.js';
import {mockPatientSummary as mockPatientTwo} from './mock/patient-summary/PatientSummaryTwoMock.js';
import {mockPatientSummaryLinks} from './mock/patient-summary/PatientSummaryLinksMock.js';

import {mockActivitySummary} from './mock/activity-summary/ActivitySummaryMock.js';
import {mockActivitySummaryPageTwo} from './mock/activity-summary/ActivitySummaryPageTwoMock.js';

import {mockSubscriberBillingSummary} from './mock/billing-summary-subscriber/BillingSummaryMock.js';
import {mockGroupBillingSummary} from './mock/billing-summary-group/BillingSummaryMock.js';

import {mockGroup} from './mock/group-summary/GroupMock.js';

import {mockCoverage} from './mock/coverage-and-rate-summary/CoverageMock.js';
import {mockCoverageSummaryLinks} from './mock/coverage-and-rate-summary/CoverageSummaryLinksMock.js';

let baseURL = '';
let mock = false;

/*
 * TODO - These base urls are assuming API Connect. When we figure out how we are going to get
 * this to work with the base desktop server/docker containers we will need to change the
 * definitions. We may even want to be able configure the endpoint as part of the run
 * command.
 */
if (process.env.NODE_ENV === 'production') {
    baseURL = 'https://production.api.bcbssc.com/';
} else if (process.env.NODE_ENV === 'qual') {
    baseURL = 'https://qual.api.bcbssc.com/';
} else if (process.env.NODE_ENV === 'system') {
    baseURL = 'http://af-mj454mr.a70adom.bcbssc.com:9080/';
} else if (process.env.NODE_ENV === 'unit') {
    baseURL = 'http://af-mj454mr.a70adom.bcbssc.com:9080/';
} else if (process.env.NODE_ENV === 'virtual') {
    baseURL = 'http://a70lscomrtvs001.a70adom.bcbssc.com:2080/';
} else if (!process.env.NODE_ENV || process.env.NODE_ENV === 'dev') {
    baseURL = 'http://af-mj454mr.a70adom.bcbssc.com:9080/';
    mock = true;
}

export const axios = Axios.create({
    baseURL,
    timeout: 30000,
    headers: {'x-ibm-client-id': '4bd5b3eb-f4b3-46f4-a9ce-c36bdb1788c6', 'Cache-Control': 'no-cache'}
});

// Add a param to disable caching
axios.interceptors.request.use((config) => {
    const dateString = JSON.stringify(new Date());
    if (config.params) {
        config.params._ = dateString;
    } else {
        config.params = {_: dateString};
    }
    return config;
});

/**
 * If mock, setup the different mock responses based on path
 */
if (mock) {
    console.warn('Mocking api responses!');

    const mockAdapter = new MockAdapter(axios, {delayResponse: 1000});

    // Mock Service Errors
    mockAdapter.onGet(/customer-service\/.+\/notauthorized/).reply(403, mockNotAuthorized); // not authorized response
    mockAdapter.onGet(/customer-service\/.+\/serviceerror/).reply(500, mockServiceError); // service error response

    // Subscriber Summary
    mockAdapter.onGet('subscriber/111111111/summary').reply(200, numberOne); // Make it so
    mockAdapter.onGet(/subscriber\/.+\/summary/).reply(200, mockSubscriber);
    mockAdapter.onGet('customer-service/summary-links/SubscriberSummary/MBR').reply(200, mbrSummaryLinks);
    mockAdapter.onGet(/customer-service\/summary-links\/SubscriberSummary/).reply(200, mockSubscriberSummaryLinks);

    // Contract Summary
    mockAdapter.onGet(/customer-service\/summary-links\/ContractSummary/).reply(200, mockContractSummaryLinks);
    mockAdapter.onGet(/subscriber\/.+\/contracts/).reply(200, mockContract);

    // Family Summary
    mockAdapter.onGet(/customer-service\/summary-links\/FamilySummary/).reply(200, mockFamilySummaryLinks);
    mockAdapter.onGet(/subscriber\/.+\/family/).reply(200, mockFamily);

    // Contact History
    mockAdapter.onGet(/customer-service\/contact-filter-list/).reply(200, mockContactsFilter);
    mockAdapter.onGet(/subscriber\/.+\/contacts/).reply(200, mockContacts);

    // Exception Summary
    mockAdapter.onGet('subscriber/111111111/exceptions').reply(200, mockExceptionsNoAlerts);
    mockAdapter.onGet(/subscriber\/.+\/exceptions/).reply(200, mockExceptions);

    // Alerts
    mockAdapter.onGet(/customer-service\/alerts\/111111111/).reply(200, mockNoAlerts); // no alerts for William Thomas Riker
    mockAdapter.onGet(/customer-service\/alerts\/.+/).reply(200, mockAlerts);

    // Patient Summary
    mockAdapter.onGet(/customer-service\/summary-links\/PatientSummary/).reply(200, mockPatientSummaryLinks);
    mockAdapter.onGet(/customer-service\/patient-summary\/.+\/001/).reply(200, mockPatientOne);
    mockAdapter.onGet(/customer-service\/patient-summary\/.+\/002/).reply(200, mockPatientTwo);

    // Activity Summary
    mockAdapter.onGet(/customer-service\/activity-summary\/111111111\/001\/true\/W123456789/).reply(200, mockActivitySummary);
    mockAdapter.onGet(/customer-service\/activity-summary\/1111\/001\/true\/1/).reply(200, mockActivitySummaryPageTwo);
    mockAdapter.onGet(/customer-service\/activity-summary\//).reply(200, mockActivitySummary);

    // Nav Links
    mockAdapter.onGet(/customer-service\/navlinkcategories\/CSR/).reply(200, mockNavLinkCategories); // navigation link categories - good response
    mockAdapter.onGet('/customer-service/navlinks/C00002-C00002').reply(200, claimsAndBenefits); // navLinks - claims and benefits
    mockAdapter.onGet('/customer-service/navlinks/C00001-C00001').reply(200, claimsAdjustments); // navLinks - claims adjustments
    mockAdapter.onGet('/customer-service/navlinks/C00600-C00600').reply(200, claimsDental); // navLinks - claims dental
    mockAdapter.onGet('/customer-service/navlinks/C00650-C00650').reply(200, claimsHealth); // navLinks - claims health

    // Nav Links MBR
    mockAdapter.onGet(/customer-service\/navlinkcategories\/MBR/).reply(200, mockNavLinkCategoriesMbr); // navigation link categories - good response
    mockAdapter.onGet('/customer-service/navlinks/C00013-C00013').reply(200, agentAndAgency);
    mockAdapter.onGet('/customer-service/navlinks/C00730-C00740').reply(200, createAndMaintainGroup); // navLinks - claims and benefits
    mockAdapter.onGet('/customer-service/navlinks/C00740-C00750').reply(200, createAndMaintainGroupSetup);
    mockAdapter.onGet('/customer-service/navlinks/C00740-C00760').reply(200, createAndMaintainGroupUpdate);
    mockAdapter.onGet('/customer-service/navlinks/C00740-C00770').reply(200, createAndMaintainGroupInquiry);
    mockAdapter.onGet('/customer-service/navlinks/C00730-C00790').reply(200, createAndMaintainBill);

    // Nav Links MCS
    mockAdapter.onGet(/customer-service\/navlinkcategories\/MCS/).reply(200, mockNavLinkCategoriesMcs); // navigation link categories - good response
    mockAdapter.onGet('/customer-service/navlinks/C00014-C00014').reply(200, documentNavCategory);
    mockAdapter.onGet('/customer-service/navlinks/C00016-C00016').reply(200, researchHealthClaims);
    mockAdapter.onGet('/customer-service/navlinks/C00016-C00513').reply(200, ammsClaimScreens);

    // Call Center Attributes
    mockAdapter.onGet(/customer-service\/app-controls\/callCenterAttributes\/BCBSSCSandbox\/Health/).reply(200, mockCallCenterAttributesHealth); // Health
    mockAdapter.onGet(/customer-service\/app-controls\/callCenterAttributes\/BCBSSCSandbox\/Dental/).reply(200, mockCallCenterAttributesDental); // Dental

    // Application Control Links
    mockAdapter.onGet(/customer-service\/application-control-links\/CSR/).reply(200, mockApplicationControlLinksCsr); // CSR
    mockAdapter.onGet(/customer-service\/application-control-links\/MCS/).reply(200, mockApplicationControlLinksMcs); // MCS
    mockAdapter.onGet(/customer-service\/application-control-links\/MBR/).reply(200, mockApplicationControlLinksMbr); // MBR
    mockAdapter.onGet(/customer-service\/application-control-links-group\/MBR/).reply(200, mockApplicationControlLinksMbr); // MBR, group view

    // Coverage and Rate Summary
    mockAdapter.onGet(/customer-service\/summary-links\/CoverageSummary/).reply(200, mockCoverageSummaryLinks);
    mockAdapter.onGet(/subscriber\/.+\/coverage/).reply(200, mockCoverage);

    // Billing Summary Subscriber
    mockAdapter.onGet(/customer-service\/billing-summary-subscriber\/111111111/).reply(200, mockSubscriberBillingSummary);
    mockAdapter.onGet(/customer-service\/billing-summary-subscriber\//).reply(200, mockSubscriberBillingSummary);

    // Billing Summary Group
    mockAdapter.onGet(/customer-service\/billing-summary-group\/abc123def456/).reply(200, mockGroupBillingSummary);
    mockAdapter.onGet(/customer-service\/billing-summary-group\//).reply(200, mockGroupBillingSummary);

    // Group Summary
    mockAdapter.onGet(/customer-service\/group-summary\/abc123def456/).reply(200, mockGroup);
    mockAdapter.onGet(/customer-service\/group-summary\//).reply(200, mockGroup);
}
