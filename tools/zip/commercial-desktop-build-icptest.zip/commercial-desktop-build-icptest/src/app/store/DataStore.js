import Vue from 'vue';
import Vuex from 'vuex';
import VuexPersist from 'vuex-persist';

Vue.use(Vuex);

import Axios from 'axios'; // Axios reference is used to generate a cancel token
import {axios} from './config.js';
import {defaultApplicationControlLinks} from './DefaultApplicationControlLinks.js';

let subscriberCancelToken;
export let subscriberCancelTokenSource;

let contractsCancelToken;
export let contractsCancelTokenSource;

let familyCancelToken;
export let familyCancelTokenSource;

let contactHistoryCancelToken;
export let contactHistoryCancelTokenSource;

let exceptionsCancelToken;
export let exceptionsCancelTokenSource;

let alertsCancelToken;
export let alertsCancelTokenSource;

let callCenterAttrCancelToken;
export let callCenterAttrCancelTokenSource;

let applicationControlLinksCancelToken;
export let applicationControlLinksCancelTokenSource;

let patientSummaryCancelToken;
export let patientSummaryCancelTokenSource;

let contactHistoryFilterCancelToken;
export let contactHistoryFilterCancelTokenSource;

let navLinkCategoriesCancelToken;
export let navLinkCategoriesCancelTokenSource;

let navLinksCancelToken;
export let navLinksCancelTokenSource;

let activitySummaryCancelToken;
export let activitySummaryCancelTokenSource;

let coverageSummaryCancelToken;
export let coverageSummaryCancelTokenSource;

let billingSummarySubscriberCancelToken;
export let billingSummarySubscriberCancelTokenSource;

let billingSummaryGroupCancelToken;
export let billingSummaryGroupCancelTokenSource;

let groupSummaryCancelToken;
export let groupSummaryCancelTokenSource;

export const state = {
    desktopState: 'Ready',
    databaseId: '',
    patientId: '',
    groupId: '',
    subscriber: {},
    contracts: {},
    family: {},
    contactHistory: [],
    exceptions: {},
    alerts: {},
    callCenterAttributes: [],
    patientSummary: {},
    desktopName: '',
    activitySummary: {},
    activeTabName: 'Subscriber',
    coverageSummary: {},
    billingSummarySubscriber: {},
    billingSummaryGroup: {},
    groupSummary: {}
};

export const getters = {
    getDesktopState: state => state.desktopState,
    getDatabaseId: state => state.databaseId,
    getPatientId: state => state.patientId,
    getGroupId: state => state.groupId,
    getSubscriber: state => state.subscriber,
    getContracts: state => state.contracts,
    getFamily: state => state.family,
    getContactHistory: state => state.contactHistory,
    getExceptions: state => state.exceptions,
    getAlerts: state => state.alerts,
    getCallCenterAttributes: state => state.callCenterAttributes,
    getPatientSummary: state => state.patientSummary,
    getDesktopName: state => state.desktopName,
    getActivitySummary: state => state.activitySummary,
    getActiveTabName: state => state.activeTabName,
    getCoverageSummary: state => state.coverageSummary,
    getBillingSummarySubscriber: state => state.billingSummarySubscriber,
    getBillingSummaryGroup: state => state.billingSummaryGroup,
    getGroupSummary: state => state.groupSummary
};

export const mutations = {
    SET_DESKTOP_STATE: (state, payload) => {
        state.desktopState = payload;
    },
    SET_DATABASE_ID: (state, payload) => {
        state.databaseId = payload;
    },
    SET_PATIENT_ID: (state, payload) => {
        state.patientId = payload;
    },
    SET_GROUP_ID: (state, payload) => {
        state.groupId = payload;
    },
    SET_SUBSCRIBER: (state, payload) => {
        state.subscriber = payload;
    },
    SET_CONTRACTS: (state, payload) => {
        state.contracts = payload;
    },
    SET_FAMILY: (state, payload) => {
        state.family = payload;
    },
    SET_CONTACT_HISTORY: (state, payload) => {
        state.contactHistory = payload;
    },
    SET_EXCEPTIONS: (state, payload) => {
        state.exceptions = payload;
    },
    SET_ALERTS: (state, payload) => {
        state.alerts = payload;
    },
    SET_SELECTED_PRODUCT: (state, payload) => {
        state.selectedProductCode = payload;
    },
    SET_CALL_CENTER_ATTRIBUTES: (state, payload) => {
        state.callCenterAttributes = payload;
    },
    SET_PATIENT_SUMMARY: (state, payload) => {
        state.patientSummary = payload;
    },
    SET_DESKTOP_NAME: (state, payload) => {
        state.desktopName = payload;
    },
    SET_ACTIVITY_SUMMARY: (state, payload) => {
        state.activitySummary = payload;
    },
    SET_BILLING_SUMMARY_SUBSCRIBER: (state, payload) => {
        state.billingSummarySubscriber = payload;
    },
    SET_BILLING_SUMMARY_GROUP: (state, payload) => {
        state.billingSummaryGroup = payload;
    },
    SET_ACTIVE_TAB_NAME: (state, payload) => {
        state.activeTabName = payload;
    },
    SET_COVERAGE_SUMMARY: (state, payload) => {
        state.coverageSummary = payload;
    },
    SET_GROUP_SUMMARY: (state, payload) => {
        state.groupSummary = payload;
    }
};

export const actions = {
    setDesktopState: (context, payload) => {
        context.commit('SET_DESKTOP_STATE', payload);
    },
    setDatabaseId: (context, payload) => {
        context.commit('SET_DATABASE_ID', payload);
    },
    clearDatabaseId: (context) => {
        context.commit('SET_DATABASE_ID', '');
    },
    setPatientId: (context, payload) => {
        context.commit('SET_PATIENT_ID', payload);
    },
    clearPatientId: (context) => {
        context.commit('SET_PATIENT_ID', '');
    },
    setGroupId: (context, payload) => {
        context.commit('SET_GROUP_ID', payload);
    },
    clearGroupId: (context) => {
        context.commit('SET_GROUP_ID', '');
    },
    retrieveSubscriber: (context, payload) => {
        subscriberCancelToken = Axios.CancelToken;
        subscriberCancelTokenSource = subscriberCancelToken.source();

        return new Promise((resolve, reject) => {
            axios.get('subscriber/' + payload.memberKeyId + '/summary', {
                cancelToken: subscriberCancelTokenSource.token
            })
            .then(response => {
                context.commit('SET_SUBSCRIBER', response.data);
                resolve(response.data);
            })
            .catch(error => {
                if (Axios.isCancel(error)) {
                    console.log('retrieveSubscriberSummaryCancelled!', error.message);
                } else {
                    reject(error);
                }
            });
        });
    },
    clearSubscriber: context => {
        if (subscriberCancelTokenSource) {
            subscriberCancelTokenSource.cancel('Clearing subscriber');
        }
        context.commit('SET_SUBSCRIBER', {});
    },
    /**
     * Retrieve summary links based on component name and desktopName.
     * Note we do not store this response data in the store.
     *
     * @param payload
     * @return {Promise}
     */
    retrieveSummaryLinks: (context, payload) => {
        return new Promise((resolve, reject) => {
            axios.get('customer-service/summary-links/' + payload.component + '/' + payload.desktopName)
            .then(response => {
                resolve(response.data);
            })
            .catch(error => {
                reject(error);
            });
        });
    },
    retrieveContracts: (context, payload) => {
        contractsCancelToken = Axios.CancelToken;
        contractsCancelTokenSource = contractsCancelToken.source();

        return new Promise((resolve, reject) => {
            axios.get('subscriber/' + payload.memberKeyId + '/contracts', {
                cancelToken: contractsCancelTokenSource.token
            })
            .then(response => {
                context.commit('SET_CONTRACTS', response.data);
                resolve(response.data);
            })
            .catch(error => {
                if (Axios.isCancel(error)) {
                    console.log('retrieveContractSummaryCancelled!', error.message);
                } else {
                    reject(error);
                }
            });
        });
    },
    clearContracts: context => {
        if (contractsCancelTokenSource) {
            contractsCancelTokenSource.cancel('Clearing contracts');
        }
        context.commit('SET_CONTRACTS', {});
    },
    retrieveFamily: (context, payload) => {
        familyCancelToken = Axios.CancelToken;
        familyCancelTokenSource = familyCancelToken.source();

        return new Promise((resolve, reject) => {
            axios.get('subscriber/' + payload.memberKeyId + '/family', {
                cancelToken: familyCancelTokenSource.token
            })
            .then(response => {
                context.commit('SET_FAMILY', response.data);
                resolve(response.data);
            })
            .catch(error => {
                if (Axios.isCancel(error)) {
                    console.log('retrieveFamilyCancelled!', error.message);
                } else {
                    reject(error);
                }
            });
        });
    },
    clearFamily: context => {
        if (familyCancelTokenSource) {
            familyCancelTokenSource.cancel('Clearing family');
        }
        context.commit('SET_FAMILY', {});
    },
    retrieveContactHistory: (context, payload) => {
        contactHistoryCancelToken = Axios.CancelToken;
        contactHistoryCancelTokenSource = contactHistoryCancelToken.source();

        return new Promise((resolve, reject) => {
            axios.get('subscriber/' + payload.memberKeyId + '/contacts', {
                cancelToken: contactHistoryCancelTokenSource.token,
                params: {
                    company: payload.company,
                    employee: payload.employee
                }
            })
            .then(response => {
                context.commit('SET_CONTACT_HISTORY', response.data);
                resolve(response.data);
            })
            .catch(error => {
                if (Axios.isCancel(error)) {
                    console.log('retrieveContactHistoryCancelled!', error.message);
                } else {
                    reject(error);
                }
            });
        });
    },
    clearContactHistory: context => {
        if (contactHistoryCancelTokenSource) {
            contactHistoryCancelTokenSource.cancel('Clearing contactHistory');
        }
        context.commit('SET_CONTACT_HISTORY', {});
    },
    retrieveNavLinkCategories: (context, payload) => {
        navLinkCategoriesCancelToken = Axios.CancelToken;
        navLinkCategoriesCancelTokenSource = navLinkCategoriesCancelToken.source();

        return new Promise((resolve, reject) => {
            axios.get('customer-service/navlinkcategories/' + payload, {
                cancelToken: navLinkCategoriesCancelTokenSource.token
            })
            .then(response => {
                resolve(response.data);
            }).catch(error => {
                if (Axios.isCancel(error)) {
                    console.log('retrieveExceptionsSummaryCancelled!', error.message);
                } else {
                    reject(error);
                }
            });
        });
    },
    retrieveNavLinks: (context, payload) => {
        navLinksCancelToken = Axios.CancelToken;
        navLinksCancelTokenSource = navLinksCancelToken.source();

        return new Promise((resolve, reject) => {
            axios.get('customer-service/navlinks/' + payload, {
                cancelToken: navLinksCancelTokenSource.token
            })
            .then(response => {
                resolve(response.data);
            })
            .catch(error => {
                if (Axios.isCancel(error)) {
                    console.log('retrieveNavLinksCancelled!', error.message);
                } else {
                    reject(error);
                }
            });
        });
    },
    retrieveExceptions: (context, payload) => {
        exceptionsCancelToken = Axios.CancelToken;
        exceptionsCancelTokenSource = exceptionsCancelToken.source();

        return new Promise((resolve, reject) => {
            axios.get('subscriber/' + payload.memberKeyId + '/exceptions', {
                cancelToken: exceptionsCancelTokenSource.token
            })
            .then(response => {
                context.commit('SET_EXCEPTIONS', response.data);
                resolve(response.data);
            })
            .catch(error => {
                if (Axios.isCancel(error)) {
                    console.log('retrieveExceptionsSummaryCancelled!', error.message);
                } else {
                    reject(error);
                }
            });
        });
    },
    clearExceptions: context => {
        if (exceptionsCancelTokenSource) {
            exceptionsCancelTokenSource.cancel('Clearing exceptions');
        }
        context.commit('SET_EXCEPTIONS', {});
    },

    retrieveAlerts: (context, payload) => {
        alertsCancelToken = Axios.CancelToken;
        alertsCancelTokenSource = alertsCancelToken.source();

        return new Promise((resolve, reject) => {
            axios.get('customer-service/alerts/' + payload.memberKeyId + '/' + payload.selectedProductCode, {
                params: {
                    callCenterName: payload.callCenterName
                },
                cancelToken: alertsCancelTokenSource.token
            }).then(response => {
                if (payload.selectedProductCode) {
                    response.data.selectedProductCode = payload.selectedProductCode;
                }
                context.commit('SET_ALERTS', response.data);
                resolve(response.data);
            }).catch(error => {
                if (Axios.isCancel(error)) {
                    console.log('retrieveAlertsCancelled!', error.message);
                } else {
                    reject(error);
                }
            });
        });
    },

    clearAlerts: context => {
        if (alertsCancelTokenSource) {
            alertsCancelTokenSource.cancel('Clearing alerts');
        }
        context.commit('SET_ALERTS', {});
    },

    retrieveCallCenterAttributes: (context, payload) => {
        callCenterAttrCancelToken = Axios.CancelToken;
        callCenterAttrCancelTokenSource = callCenterAttrCancelToken.source();

        return new Promise((resolve, reject) => {
            axios.get('customer-service/app-controls/callCenterAttributes/' + payload.callCenterName + '/' + payload.coverageType, {
                cancelToken: callCenterAttrCancelTokenSource.token
            })
            .then(response => {
                context.commit('SET_CALL_CENTER_ATTRIBUTES', response.data);
                resolve(response.data);
            })
            .catch(error => {
                if (Axios.isCancel(error)) {
                    console.log('retrieveCallCenterAttributesCancelled!', error.message);
                } else {
                    reject(error);
                }
            });
        });
    },
    clearCallCenterAttributes: context => {
        if (callCenterAttrCancelTokenSource) {
            callCenterAttrCancelTokenSource.cancel('Clearing call center attributes');
        }
        context.commit('SET_CALL_CENTER_ATTRIBUTES', {});
    },
    /**
     * Retrieve all rules defined links.
     * Note we do not store this response data in the store.
     * Note in the event of a service failure a default set of link(s) are returned
     *
     * @param payload TODO provide a MenuConfiguration object
     * @return {Promise}
     */
    retrieveApplicationControlLinks: (context, payload) => {
        applicationControlLinksCancelToken = Axios.CancelToken;
        applicationControlLinksCancelTokenSource = applicationControlLinksCancelToken.source();

        return new Promise((resolve) => {
            axios.get('customer-service/application-control-links/' + payload, {
                cancelToken: applicationControlLinksCancelTokenSource.token
            })
            .then(response => {
                resolve(response.data);
            })
            .catch(error => {
                if (Axios.isCancel(error)) {
                    console.log('applicationControlLinksCancelled!', error.message);
                } else {
                    // Return a default control link that will allow the desktop to function
                    resolve(defaultApplicationControlLinks);
                }
            });
        });
    },
    retrievePatientSummary: (context, payload) => {
        patientSummaryCancelToken = Axios.CancelToken;
        patientSummaryCancelTokenSource = patientSummaryCancelToken.source();

        return new Promise((resolve, reject) => {
            axios.get('customer-service/patient-summary/' + payload.memberKeyId + '/' + payload.patientId, {
                cancelToken: patientSummaryCancelTokenSource.token
            })
            .then(response => {
                context.commit('SET_PATIENT_SUMMARY', response.data);
                resolve(response.data);
            })
            .catch(error => {
                if (Axios.isCancel(error)) {
                    console.log('retrievePatientSummaryCancelled!', error.message);
                } else {
                    reject(error);
                }
            });
        });
    },
    clearPatientSummary: context => {
        if (patientSummaryCancelTokenSource) {
            patientSummaryCancelTokenSource.cancel('Clearing patient summary');
        }
        context.commit('SET_PATIENT_SUMMARY', {});
    },
    setDesktopName: (context, payload) => {
        context.commit('SET_DESKTOP_NAME', payload);
    },
    retrieveContactHistoryFilter: () => {
        contactHistoryFilterCancelToken = Axios.CancelToken;
        contactHistoryFilterCancelTokenSource = contactHistoryFilterCancelToken.source();

        return new Promise((resolve, reject) => {
            axios.get('customer-service/contact-filter-list', {
                cancelToken: contactHistoryFilterCancelTokenSource.token
            })
            .then(response => {
                resolve(response.data);
            })
            .catch(error => {
                if (Axios.isCancel(error)) {
                    console.log('retrieveContactHistoryFilterCancelled!', error.message);
                } else {
                    reject(error);
                }
            });
        });
    },
    /**
     * Retrieve the activity summary for a subscriber.
     * The activity summary is stored in the data store
     *
     * @param payload // uses subscriberId, memberKeyId, includeVoids, and lastViewedAuthorizations
     * @return {Promise}
     */
    retrieveActivitySummary: (context, payload) => {
        activitySummaryCancelToken = Axios.CancelToken;
        activitySummaryCancelTokenSource = activitySummaryCancelToken.source();

        return new Promise((resolve, reject) => {
            axios.get('customer-service/activity-summary/' + payload.subscriberId + '/' + payload.memberKeyId + '/' + payload.includeVoids + '/' + payload.pageNumber, {
                cancelToken: activitySummaryCancelTokenSource.token
            })
            .then(response => {
                context.commit('SET_ACTIVITY_SUMMARY', response.data);
                resolve(response.data);
            })
            .catch(error => {
                if (Axios.isCancel(error)) {
                    console.log('activitySummaryCancelled!', error.message);
                } else {
                    reject(error);
                }
            });
        });
    },
    clearActivitySummary: context => {
        if (activitySummaryCancelTokenSource) {
            activitySummaryCancelTokenSource.cancel('Clearing Activity Summary');
        }
        context.commit('SET_ACTIVITY_SUMMARY', {});
    },
    /**
     * Retrieve the billing summary for a subscriber.
     * The billing summary is stored in the data store
     *
     * @param payload // uses subscriberId
     * @return {Promise}
     */
    retrieveBillingSummarySubscriber: (context, payload) => {
        billingSummarySubscriberCancelToken = Axios.CancelToken;
        billingSummarySubscriberCancelTokenSource = billingSummarySubscriberCancelToken.source();

        return new Promise((resolve, reject) => {
            axios.get('customer-service/billing-summary-subscriber/' + payload.subscriberId, {
                cancelToken: billingSummarySubscriberCancelTokenSource.token
            })
            .then(response => {
                context.commit('SET_BILLING_SUMMARY_SUBSCRIBER', response.data);
                resolve(response.data);
            })
            .catch(error => {
                if (Axios.isCancel(error)) {
                    console.log('billingSummarySubscriberCancelled!', error.message);
                } else {
                    reject(error);
                }
            });
        });
    },
    clearBillingSummarySubscriber: context => {
        if (billingSummarySubscriberCancelTokenSource) {
            billingSummarySubscriberCancelTokenSource.cancel('Clearing Billing Summary Subscriber');
        }
        context.commit('SET_BILLING_SUMMARY_SUBSCRIBER', {});
    },
    /**
     * Retrieve the billing summary for a group.
     * The billing summary is stored in the data store
     *
     * @param payload  uses Billing Summary Group ID, an encoded ID including
     *                 Master AR, CES Group, Product Code and Coverage ID
     * @return {Promise}
     */
    retrieveBillingSummaryGroup: (context, payload) => {
        billingSummaryGroupCancelToken = Axios.CancelToken;
        billingSummaryGroupCancelTokenSource = billingSummaryGroupCancelToken.source();

        return new Promise((resolve, reject) => {
            axios.get('customer-service/billing-summary-group/' + payload.billingSummaryGroupId, {
                cancelToken: billingSummaryGroupCancelTokenSource.token
            })
            .then(response => {
                context.commit('SET_BILLING_SUMMARY_GROUP', response.data);
                resolve(response.data);
            })
            .catch(error => {
                if (Axios.isCancel(error)) {
                    console.log('billingSummaryGroupCancelled!', error.message);
                } else {
                    reject(error);
                }
            });
        });
    },
    clearBillingSummaryGroup: context => {
        if (billingSummaryGroupCancelTokenSource) {
            billingSummaryGroupCancelTokenSource.cancel('Clearing Billing Summary Group');
        }
        context.commit('SET_BILLING_SUMMARY_GROUP', {});
    },
    setActiveTabName: (context, payload) => {
        context.commit('SET_ACTIVE_TAB_NAME', payload);
    },
    /**
     * Retrieve the coverage and rate summary information.
     * The coverage and rate summary is stored in the data store
     *
     * @param payload
     * @return {Promise}
     */
    retrieveCoverageSummary: (context, payload) => {
        coverageSummaryCancelToken = Axios.CancelToken;
        coverageSummaryCancelTokenSource = coverageSummaryCancelToken.source();

        return new Promise((resolve, reject) => {
            axios.get('subscriber/' + payload.memberKeyId + '/coverage', {
                cancelToken: coverageSummaryCancelTokenSource.token
            })
            .then(response => {
                context.commit('SET_COVERAGE_SUMMARY', response.data);
                resolve(response.data);
            })
            .catch(error => {
                if (Axios.isCancel(error)) {
                    console.log('retrieveCoverageSummaryCancelled!', error.message);
                } else {
                    reject(error);
                }
            });
        });
    },
    /**
     * Retrieve the group summary information.
     * The group summary is stored in the data store
     *
     * @param payload  uses groupSummaryID, an encoded ID including CES Group,
     *                 Product Code and Coverage ID
     * @return {Promise}
     */
    retrieveGroupSummary: (context, payload) => {
        groupSummaryCancelToken = Axios.CancelToken;
        groupSummaryCancelTokenSource = groupSummaryCancelToken.source();

        return new Promise((resolve, reject) => {
            axios.get('customer-service/group-summary/' + payload.groupSummaryId, {
                cancelToken: groupSummaryCancelTokenSource.token
            })
            .then(response => {
                context.commit('SET_GROUP_SUMMARY', response.data);
                resolve(response.data);
            })
            .catch(error => {
                if (Axios.isCancel(error)) {
                    console.log('groupSummaryCancelled!', error.message);
                } else {
                    reject(error);
                }
            });
        });
    },
    clearCoverageSummary: context => {
        if (coverageSummaryCancelTokenSource) {
            coverageSummaryCancelTokenSource.cancel('Clearing coverage summary');
        }
        context.commit('SET_COVERAGE_SUMMARY', {});
    },
    clearGroupSummary: context => {
        if (groupSummaryCancelTokenSource) {
            groupSummaryCancelTokenSource.cancel('Clearing Group Summary');
        }
        context.commit('SET_GROUP_SUMMARY', {});
    }
};

// Keep data stored in session storage so store is not cleared on browser refresh
const vuexSessionStorage = new VuexPersist({
    key: 'commercial-desktop-veux',
    storage: window.sessionStorage
});

export default {
    name: 'DataStore',
    store: new Vuex.Store({
        state,
        getters,
        mutations,
        actions,
        plugins: [vuexSessionStorage.plugin]
    })
};
