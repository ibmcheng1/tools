/* eslint-disable */
export const mockCoverageSummaryLinks = [
    {
        'name': 'base-rates',
        'transaction-type': 'url',
        'transaction': 'http://lmgtfy.com'
    },
    {
        'name': 'benefit-documents',
        'transaction-type': 'url',
        'transaction': 'http://google.com'
    },
    {
        'name': 'output-rules',
        'transaction-type': 'url',
        'transaction': 'http://google.com'
    }
]