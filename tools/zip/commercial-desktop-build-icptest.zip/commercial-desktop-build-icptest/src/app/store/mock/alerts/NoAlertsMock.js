/* eslint-disable */
export const mockNoAlerts = {
    "alerts": [],
    "selectedProductCode": "Products.DENTAL",
    "subscriberProducts": ["Products.DENTAL", "Products.MEDICAL"]
}
