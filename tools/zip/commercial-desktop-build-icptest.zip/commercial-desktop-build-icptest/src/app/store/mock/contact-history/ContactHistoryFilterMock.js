/* eslint-disable */
export const mockContactsFilter = {
    "PRIVATE BUSINESS":"3",
    "FEP":"1",
    "BLUEVUE":"5,PARADIGMH",
    "CBA":"6"
};