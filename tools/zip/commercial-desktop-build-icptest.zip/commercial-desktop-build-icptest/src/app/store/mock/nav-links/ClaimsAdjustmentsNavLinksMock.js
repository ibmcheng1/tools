/* eslint-disable */
export const mockNavLinks = [
    {
      "altFunction": "",
      "category": "",
      "childLinks": [
        
      ],
      "clientCode": "BCBSSC",
      "comments": "AMLK",
      "companyCode": "3",
      "departmentCode": "461",
      "divisionCode": "33",
      "functionId": "C00001",
      "functionType": "NAVLINK",
      "keyType": "",
      "keyValue": "",
      "linkAction": "H^AMLK@E^AMLK",
      "linkDesc": "DEFERRED CLAIMS BY OPERATOR (AMLK)",
      "noteLine": "",
      "planCode": "",
      "regionId": "DVOST1",
      "regionType": "",
      "requestReason": "",
      "resolution": "",
      "rpn": "",
      "seq": 1,
      "source": "",
      "subMenu": false,
      "subfunctionId": "L00080",
      "taskKey": "",
      "timestamp": ""
    }
  ]