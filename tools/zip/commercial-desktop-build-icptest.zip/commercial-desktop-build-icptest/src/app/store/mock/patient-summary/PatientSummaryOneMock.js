/* eslint-disable */
export const mockPatientSummary = {
  "address1": "P O BOX  24015",
  "address2": "",
  "birthdate": "10\/01\/1958",
  "cesMemberNumber": "01",
  "cityStateZip": "COLUMBIA, SC 29224 4015",
  "gender": "MALE",
  "memberEmpty": false,
  "memberId": "001",
  "memberNull": false,
  "name": "MICHAEL TESTING",
  "primaryCarePhysicianId": null,
  "primaryCarePhysicianName": null,
  "relationship": "SUBSCRIBER",
  "selectedMember": {
    "address": {
      "address1": "P O BOX  24015",
      "address2": "",
      "address3": "",
      "address4": null,
      "address5": null,
      "city": "COLUMBIA",
      "country": null,
      "county": "040",
      "countyCode": {
        "code": "040",
        "description": null,
        "key": "040",
        "name": "040",
        "rpn": null,
        "state": null,
        "value": null
      },
      "province": null,
      "region": null,
      "state": "SC",
      "stateCode": {
        "code": "SC",
        "description": null,
        "key": "SC",
        "name": "SC",
        "value": null
      },
      "zipcode": "29224",
      "zipcodePostFix": "4015"
    },
    "age": null,
    "alternateNames": [

    ],
    "birthdate": "10\/01\/1958",
    "cancelCode": {
      "code": null,
      "description": null,
      "key": null,
      "name": null,
      "value": null
    },
    "cardNumber": null,
    "carrierName": null,
    "carrierRestricted": false,
    "cesMemberNumber": "01",
    "confidentialClaimIndicator": false,
    "dateOfBirth": "1958-10-01T00:00:00-0400",
    "deferrals": [

    ],
    "dependentIndicator": "C",
    "dependentVerified": "VERIFIED NON-STATE",
    "employmentStatus": {
      "code": null,
      "description": null,
      "key": null,
      "name": null,
      "value": null
    },
    "id": null,
    "idCode": {
      "code": null,
      "description": null,
      "key": null,
      "name": null,
      "value": null
    },
    "maritalStatus": {
      "code": null,
      "description": null,
      "key": null,
      "maritalStatusDate": null,
      "name": null,
      "value": null
    },
    "medicareNumber": null,
    "memberId": "001",
    "memberStatus": {
      "code": null,
      "description": null,
      "key": null,
      "name": null,
      "value": null
    },
    "memberSubscriber": true,
    "name": {
      "firstName": "MICHAEL",
      "lastName": "TESTING",
      "middleName": "",
      "prefixName": null,
      "suffixName": ""
    },
    "originalEnrollmentDate": null,
    "overAgeDependent": {
      "certifiedDate": null,
      "code": null,
      "description": null,
      "key": null,
      "name": null,
      "value": null
    },
    "overrides": [

    ],
    "phone": {
      "areaCode": null,
      "extension": null,
      "prefix": null,
      "suffix": null,
      "type": null
    },
    "planCode": null,
    "preferredLanguage": {
      "code": null,
      "description": null,
      "key": null,
      "name": null,
      "value": null
    },
    "previousMemberId": null,
    "primaryCarePhysicianFound": false,
    "primaryCarePhysicianId": null,
    "primaryCarePhysicianName": null,
    "privacyIndicator": "",
    "recordBeginDate": null,
    "recordTermDate": null,
    "relationship": {
      "code": "1",
      "description": null,
      "key": "1",
      "name": "1",
      "value": null
    },
    "relationshipCode": "1",
    "relationshipName": "SUBSCRIBER",
    "setupDate": null,
    "sex": {
      "code": null,
      "description": null,
      "key": null,
      "name": null,
      "value": null
    },
    "sexCode": null,
    "sexName": "MALE",
    "socialSecurityNumber": null,
    "subscriberId": null,
    "suppressIdCards": {
      "code": null,
      "description": null,
      "key": null,
      "name": null,
      "value": null
    },
    "tobaccoUsage": {
      "code": null,
      "description": null,
      "key": null,
      "name": null,
      "value": null
    },
    "understandsEnglish": false,
    "updateByEmployee": "CI300",
    "updateDate": null,
    "verifiedPatientIndicator": "Y",
    "visionPlanPatientId": null
  }
}
