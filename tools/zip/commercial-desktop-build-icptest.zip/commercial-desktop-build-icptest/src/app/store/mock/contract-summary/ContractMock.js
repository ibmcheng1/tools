/* eslint-disable */
export const mockContract = {
    "benefitBooklets": null,
    "contractTypes": null,
    "contracts": {
        "MED": [
        {
            "ammsGroupNumber": "036011101",
            "benefitBookletAvailable": false,
            "benefitBookletRequestDate": "2018-05-22T12:00:00-0400",
            "benefitType": null,
            "benefitTypeDesc": null,
            "certificationExceptionRecords": [
                {
                    "ControlCode": {"code": "55", "description": "55_description"},
                    "patientId": "001",
                    "deferral": "deferral",
                    "exceptionDescription": "Description of this Exception 1",
                    "patientName": "",
                    "controlDate": "2018-04-01T00:00:00-0400",
                    "alertExceptionIndicator": true,
                    "contractLevelExceptionIndicator": true,
                    "priority": 1
                },
                {
                    "ControlCode": {"code": "88", "description": "88_description"},
                    "patientId": "002",
                    "deferral": "deferral",
                    "exceptionDescription": "Description of this Exception 2",
                    "patientName": "MICHAEL TESTING",
                    "controlDate": "2017-06-01T00:00:00-0400",
                    "alertExceptionIndicator": false,
                    "contractLevelExceptionIndicator": true,
                    "priority": 2
                }
            ],
            "cesGroupNumber": "0000667",
            "coveragePeriod": {
            "end": "",
            "endDate": "06\/01\/2003",
            "fromEdit": false,
            "start": "06\/01\/2002",
            "startDate": "2002-06-01T00:00:00-0400",
            "toEdit": false
            },
            "coverageSystem": "CES",
            "currentBenefitPeriod": {
            "end": "04\/01",
            "endDate": null,
            "fromEdit": false,
            "start": "04\/01",
            "startDate": null,
            "toEdit": false
            },
            "drugProcessingCode": {
            "code": "Z",
            "description": 'ZERTEC',
            "key": "Z",
            "name": "Z",
            "value": null
            },
            "eligibilityTransactionDate": "2018-05-22T12:00:00-0400",
            "employeeStatus": "EMPLOYED",
            "formatNumber": null,
            "futureContract": false,
            "groupCode": "036011101",
            "groupName": "TEST GROUP DO NOT USE",
            "groupVerbiage": 'Group Verbiage Example',
            "key": null,
            "noCoveragePeriod": {
            "end": null,
            "endDate": null,
            "fromEdit": false,
            "start": null,
            "startDate": null,
            "toEdit": false
            },
            "planCode": "885",
            "preexistingPeriod": {
            "end": "04\/01\/2003",
            "endDate": "2003-04-01T00:00:00-0500",
            "fromEdit": false,
            "start": "04\/01\/2002",
            "startDate": "2002-04-01T00:00:00-0500",
            "toEdit": false
            },
            "serviceCenterCode": "B01",
            "serviceCenterName": "MOHASCO",
            "status": "YES",
            "type": "FAMILY"
        },
        {
            "ammsGroupNumber": "036011101",
            "benefitBookletAvailable": false,
            "benefitBookletRequestDate": "2018-05-22T12:00:00-0400",
            "benefitType": null,
            "benefitTypeDesc": null,
            "certificationExceptionRecords": [
                {
                    "ControlCode": {"code": "55", "description": "controlcodedesc"},
                    "patientId": "001",
                    "deferral": "deferral",
                    "exceptionDescription": "exceptionDescription",
                    "patientName": "MOCHA TESTING",
                    "controlDate": "2018-04-01T00:00:00-0400",
                    "alertExceptionIndicator": true,
                    "contractLevelExceptionIndicator": true,
                    "priority": 2
                }
            ],
            "cesGroupNumber": "0000667",
            "coveragePeriod": {
            "end": "",
            "endDate": "07\/01\/2013",
            "fromEdit": false,
            "start": "07\/01\/2012",
            "startDate": "2012-07-01T00:00:00-0400",
            "toEdit": false
            },
            "coverageSystem": "CES",
            "currentBenefitPeriod": {
            "end": "04\/01",
            "endDate": null,
            "fromEdit": false,
            "start": "04\/01",
            "startDate": null,
            "toEdit": false
            },
            "drugProcessingCode": {
            "code": "Z",
            "description": null,
            "key": "Z",
            "name": "Z",
            "value": null
            },
            "eligibilityTransactionDate": "2018-05-22T12:00:00-0400",
            "employeeStatus": null,
            "formatNumber": 'FORMAT NUMBER',
            "futureContract": false,
            "groupCode": "036011101",
            "groupName": "TEST GROUP DO NOT USE",
            "groupVerbiage": 'Group Verbiage Example',
            "key": null,
            "noCoveragePeriod": {
            "end": null,
            "endDate": null,
            "fromEdit": false,
            "start": null,
            "startDate": null,
            "toEdit": false
            },
            "planCode": "885",
            "preexistingPeriod": {
            "end": "04\/01\/2003",
            "endDate": "2003-04-01T00:00:00-0500",
            "fromEdit": false,
            "start": "04\/01\/2002",
            "startDate": "2002-04-01T00:00:00-0500",
            "toEdit": false
            },
            "serviceCenterCode": "B01",
            "serviceCenterName": "MOHASCO",
            "status": "NO",
            "type": "FAMILY"
        },
        {
            "ammsGroupNumber": "036011300",
            "benefitBookletAvailable": false,
            "benefitBookletRequestDate": "2018-05-22T12:00:00-0400",
            "benefitType": null,
            "benefitTypeDesc": null,
            "certificationExceptionRecords": [

            ],
            "cesGroupNumber": "0000777",
            "coveragePeriod": {
            "end": "",
            "endDate": null,
            "fromEdit": false,
            "start": "08\/01\/2002",
            "startDate": "2002-08-01T00:00:00-0400",
            "toEdit": false
            },
            "coverageSystem": "CES",
            "currentBenefitPeriod": {
            "end": "06\/01",
            "endDate": null,
            "fromEdit": false,
            "start": "06\/01",
            "startDate": null,
            "toEdit": false
            },
            "drugProcessingCode": {
            "code": "Z",
            "description": null,
            "key": "Z",
            "name": "Z",
            "value": null
            },
            "eligibilityTransactionDate": "2018-05-22T12:00:00-0400",
            "employeeStatus": null,
            "formatNumber": null,
            "futureContract": true,
            "groupCode": "036011101",
            "groupName": "TEST GROUP DO NOT USE",
            "groupVerbiage": 'Group Verbiage Example',
            "key": null,
            "noCoveragePeriod": {
            "end": null,
            "endDate": null,
            "fromEdit": false,
            "start": null,
            "startDate": null,
            "toEdit": false
            },
            "planCode": "035",
            "preexistingPeriod": {
            "end": "04\/01\/2003",
            "endDate": "2003-04-01T00:00:00-0500",
            "fromEdit": false,
            "start": "04\/01\/2002",
            "startDate": "2002-04-01T00:00:00-0500",
            "toEdit": false
            },
            "serviceCenterCode": "B01",
            "serviceCenterName": "MOHASCO",
            "status": "NO",
            "type": "FAMILY"
        }
        ],
        "DEN": [
        {
            "ammsGroupNumber": "036011101",
            "benefitBookletAvailable": false,
            "benefitBookletRequestDate": "2018-05-22T12:00:00-0400",
            "benefitType": null,
            "benefitTypeDesc": null,
            "certificationExceptionRecords": [
                {
                    "ControlCode": {"code": "55", "description": "55_description"},
                    "patientId": "001",
                    "deferral": "deferral",
                    "exceptionDescription": "Description of this Exception 1",
                    "patientName": "",
                    "controlDate": "2018-04-01T00:00:00-0400",
                    "alertExceptionIndicator": true,
                    "contractLevelExceptionIndicator": true,
                    "priority": 1
                },
                {
                    "ControlCode": {"code": "88", "description": "88_description"},
                    "patientId": "002",
                    "deferral": "deferral",
                    "exceptionDescription": "Description of this Exception 2",
                    "patientName": "MICHAEL TESTING",
                    "controlDate": "2017-06-01T00:00:00-0400",
                    "alertExceptionIndicator": false,
                    "contractLevelExceptionIndicator": true,
                    "priority": 2
                }
            ],
            "cesGroupNumber": "0000667",
            "coveragePeriod": {
            "end": "",
            "endDate": null,
            "fromEdit": false,
            "start": "01\/01\/2003",
            "startDate": "2003-01-01T00:00:00-0500",
            "toEdit": false
            },
            "coverageSystem": "CES",
            "currentBenefitPeriod": {
            "end": "05\/01",
            "endDate": null,
            "fromEdit": false,
            "start": "05\/01",
            "startDate": null,
            "toEdit": false
            },
            "drugProcessingCode": {
            "code": "Z",
            "description": null,
            "key": "Z",
            "name": "Z",
            "value": null
            },
            "eligibilityTransactionDate": "2018-05-22T12:00:00-0400",
            "employeeStatus": null,
            "formatNumber": null,
            "futureContract": false,
            "groupCode": "036011101",
            "groupName": "TEST GROUP DO NOT USE",
            "groupVerbiage": 'Group Verbiage Example',
            "key": null,
            "noCoveragePeriod": {
            "end": null,
            "endDate": null,
            "fromEdit": false,
            "start": null,
            "startDate": null,
            "toEdit": false
            },
            "planCode": "885",
            "preexistingPeriod": {
            "end": "",
            "endDate": null,
            "fromEdit": false,
            "start": "",
            "startDate": null,
            "toEdit": false
            },
            "serviceCenterCode": "A01",
            "serviceCenterName": "SMALL GROUP MEMBERSHIP",
            "status": "MAYBE",
            "type": "FAMILY"
        },
        {
            "ammsGroupNumber": "036022222",
            "benefitBookletAvailable": true,
            "benefitBookletRequestDate": "2018-05-22T12:00:00-0400",
            "benefitType": null,
            "benefitTypeDesc": null,
            "certificationExceptionRecords": [

            ],
            "cesGroupNumber": "0000999",
            "coveragePeriod": {
            "end": "",
            "endDate": null,
            "fromEdit": false,
            "start": "02\/01\/2003",
            "startDate": "2003-02-01T00:00:00-0500",
            "toEdit": false
            },
            "coverageSystem": "CES",
            "currentBenefitPeriod": {
            "end": "05\/01",
            "endDate": null,
            "fromEdit": false,
            "start": "05\/01",
            "startDate": null,
            "toEdit": false
            },
            "drugProcessingCode": {
            "code": "A",
            "description": null,
            "key": "A",
            "name": "A",
            "value": null
            },
            "eligibilityTransactionDate": "2018-05-22T12:00:00-0400",
            "employeeStatus": null,
            "formatNumber": null,
            "futureContract": true,
            "groupCode": "036011101",
            "groupName": "TEST GROUP DO NOT USE",
            "groupVerbiage": null,
            "key": null,
            "noCoveragePeriod": {
            "end": null,
            "endDate": null,
            "fromEdit": false,
            "start": null,
            "startDate": null,
            "toEdit": false
            },
            "planCode": "035",
            "preexistingPeriod": {
            "end": "",
            "endDate": null,
            "fromEdit": false,
            "start": "",
            "startDate": null,
            "toEdit": false
            },
            "serviceCenterCode": "A01",
            "serviceCenterName": "SMALL GROUP MEMBERSHIP",
            "status": "MAYBE",
            "type": "FAMILY"
        }
        ],
        "DUG": [
        {
            "ammsGroupNumber": "036011101",
            "benefitBookletAvailable": false,
            "benefitBookletRequestDate": "2018-05-22T12:00:00-0400",
            "benefitType": null,
            "benefitTypeDesc": null,
            "certificationExceptionRecords": [

            ],
            "cesGroupNumber": "0000667",
            "coveragePeriod": {
            "end": "",
            "endDate": null,
            "fromEdit": false,
            "start": "06\/01\/2002",
            "startDate": "2002-06-01T00:00:00-0400",
            "toEdit": false
            },
            "coverageSystem": "CES",
            "currentBenefitPeriod": {
            "end": "06\/01",
            "endDate": null,
            "fromEdit": false,
            "start": "06\/01",
            "startDate": null,
            "toEdit": false
            },
            "drugProcessingCode": {
            "code": "Z",
            "description": "ZERTEC",
            "key": "Z",
            "name": "Z",
            "value": null
            },
            "eligibilityTransactionDate": "2018-05-22T12:00:00-0400",
            "employeeStatus": null,
            "formatNumber": null,
            "futureContract": false,
            "groupCode": "036011101",
            "groupName": "TEST GROUP DO NOT USE",
            "groupVerbiage": null,
            "key": null,
            "noCoveragePeriod": {
            "end": null,
            "endDate": null,
            "fromEdit": false,
            "start": null,
            "startDate": null,
            "toEdit": false
            },
            "planCode": "885",
            "preexistingPeriod": {
            "end": "04\/01\/2003",
            "endDate": "2003-04-01T00:00:00-0500",
            "fromEdit": false,
            "start": "04\/01\/2002",
            "startDate": "2002-04-01T00:00:00-0500",
            "toEdit": false
            },
            "serviceCenterCode": "B01",
            "serviceCenterName": "MOHASCO",
            "status": "YES",
            "type": "FAMILY"
        }
        ]
    },
    "errorOccured": false,
    "exceptionRecord": null,
    "loadableSubscriber": {
        "PAI": false,
        "activeDate": null,
        "activelyCovered": true,
        "address": {
        "address1": "P O BOX  24015",
        "address2": "",
        "address3": null,
        "address4": null,
        "address5": null,
        "city": "COLUMBIA",
        "country": null,
        "county": "040",
        "countyCode": {
            "code": "040",
            "description": "RICHLAND",
            "key": "040",
            "name": "040",
            "rpn": null,
            "state": null,
            "value": "RICHLAND"
        },
        "province": null,
        "region": null,
        "state": "SC",
        "stateCode": {
            "code": "SC",
            "description": null,
            "key": "SC",
            "name": "SC",
            "value": null
        },
        "zipcode": "29224",
        "zipcodePostFix": "4015"
        },
        "alphaPrefix": "ZCZ",
        "ammsGroupNumber": "036011101",
        "bill": {
        "amountReceivable": null,
        "arHistoryIndicator": null,
        "balanceAmount": null,
        "billFormat": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "billNumber": null,
        "billedDate": null,
        "billingFrequency": null,
        "clientNumber": null,
        "createARIndicator": null,
        "creationDate": null,
        "dueDate": null,
        "dueDay": null,
        "employeeListIndicator": null,
        "lastPaymentAmount": null,
        "lastPaymentDate": null,
        "listBillAccountNumber": "",
        "masterARNumber": null,
        "mode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "outputType": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "paymentMethod": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "paymentSummary": null,
        "providerId": null,
        "reasonCode": null,
        "recordCode": null,
        "renderTime": null,
        "serviceId": null,
        "sort": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "supressBillIndicator": null,
        "viewStatementIndicator": null
        },
        "birthdate": "10\/01\/1958",
        "businessSector": "",
        "carrierName": "",
        "carrierRestricted": false,
        "ces": true,
        "cesExceptionIndicator": true,
        "cesGroupNumber": "0000667",
        "cisiRpn": null,
        "clientCode": {
        "code": "00006",
        "description": "TEST SPECIAL PROJECTS AREA",
        "key": "00006",
        "name": "00006",
        "value": "TEST SPECIAL PROJECTS AREA"
        },
        "coverage": null,
        "coverageContinuationTypeCode": {
        "code": "",
        "description": null,
        "key": "",
        "name": "",
        "value": null
        },
        "coverageItems": [
        {
            "active": true,
            "benefitSystem": "OLD",
            "coverageId": {
            "benefitLevel": "001",
            "coverageLevelCode": "C",
            "coverageNumber": "0000006",
            "productCode": "Products.DENTAL"
            },
            "drugProcessingCode": {
            "code": "",
            "description": null,
            "key": "",
            "name": "",
            "value": null
            },
            "effectiveDate": "2003-01-01T00:00:00-0500",
            "group": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "agency": null,
            "anniversaryDate": null,
            "benefitSystem": null,
            "billDueDate": null,
            "billingAgencyCode": null,
            "billingAgentCode": null,
            "cancelCode": null,
            "cancelReasonCode": null,
            "clientContribution": null,
            "clientDescription": null,
            "clientNumber": null,
            "clientServiceCenterCode": null,
            "contactInformation": null,
            "contactName": null,
            "contractRule": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "contractTypes": null,
            "coverageEffectiveDate": null,
            "coverages": null,
            "dateBegin": null,
            "dateEnd": null,
            "departments": null,
            "drugOptionCode": null,
            "effectiveDate": null,
            "fax": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "groupCoverageBeginDate": null,
            "groupCoverageTermDate": null,
            "groupDescription": null,
            "groupLeader": null,
            "groupName": null,
            "groupNumberAmms": null,
            "groupNumberCes": null,
            "groupType": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "id": "0000667",
            "idCardType": null,
            "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "lastBillAmount": null,
            "lastBillDate": null,
            "maintenenceDate": null,
            "masterARNumber": null,
            "masterCoverageRateBegin": null,
            "masterCoverageRateEnd": null,
            "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "outputRules": null,
            "paymentSummaryNumber": null,
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "probationaryPeriods": null,
            "productRule": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "ratingCounty": null,
            "rpn": null,
            "salesRepresentative": {
                "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
                },
                "id": null,
                "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
                },
                "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
                },
                "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                }
            },
            "serviceRepresentative": {
                "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
                },
                "id": null,
                "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
                },
                "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
                },
                "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                }
            },
            "sicCode": null,
            "specialHandling": null,
            "statusDescription": null,
            "subClientDescription": null,
            "subClientNumber": null,
            "terminationDate": null
            },
            "listBillIndicator": "",
            "majorMedicalWaiverCode": {
            "code": "",
            "description": null,
            "key": "",
            "name": "",
            "value": null
            },
            "memberId": null,
            "oldGroup": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "agency": null,
            "anniversaryDate": null,
            "benefitSystem": null,
            "billDueDate": null,
            "billingAgencyCode": null,
            "billingAgentCode": null,
            "cancelCode": null,
            "cancelReasonCode": null,
            "clientContribution": null,
            "clientDescription": null,
            "clientNumber": null,
            "clientServiceCenterCode": null,
            "contactInformation": null,
            "contactName": null,
            "contractRule": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "contractTypes": null,
            "coverageEffectiveDate": null,
            "coverages": null,
            "dateBegin": null,
            "dateEnd": null,
            "departments": null,
            "drugOptionCode": null,
            "effectiveDate": null,
            "fax": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "groupCoverageBeginDate": null,
            "groupCoverageTermDate": null,
            "groupDescription": null,
            "groupLeader": null,
            "groupName": null,
            "groupNumberAmms": null,
            "groupNumberCes": null,
            "groupType": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "id": "036011101",
            "idCardType": null,
            "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "lastBillAmount": null,
            "lastBillDate": null,
            "maintenenceDate": null,
            "masterARNumber": null,
            "masterCoverageRateBegin": null,
            "masterCoverageRateEnd": null,
            "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "outputRules": null,
            "paymentSummaryNumber": null,
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "probationaryPeriods": null,
            "productRule": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "ratingCounty": null,
            "rpn": null,
            "salesRepresentative": {
                "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
                },
                "id": null,
                "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
                },
                "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
                },
                "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                }
            },
            "serviceRepresentative": {
                "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
                },
                "id": null,
                "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
                },
                "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
                },
                "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                }
            },
            "sicCode": null,
            "specialHandling": null,
            "statusDescription": null,
            "subClientDescription": null,
            "subClientNumber": null,
            "terminationDate": null
            },
            "periods": null,
            "serviceCenter": "A01",
            "type": null
        },
        {
            "active": true,
            "benefitSystem": null,
            "coverageId": {
            "benefitLevel": "001",
            "coverageLevelCode": "C",
            "coverageNumber": "0000006",
            "productCode": "Products.MEDICAL"
            },
            "drugProcessingCode": {
            "code": "",
            "description": null,
            "key": "",
            "name": "",
            "value": null
            },
            "effectiveDate": "2002-06-01T00:00:00-0400",
            "group": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "agency": null,
            "anniversaryDate": null,
            "benefitSystem": null,
            "billDueDate": null,
            "billingAgencyCode": null,
            "billingAgentCode": null,
            "cancelCode": null,
            "cancelReasonCode": null,
            "clientContribution": null,
            "clientDescription": null,
            "clientNumber": null,
            "clientServiceCenterCode": null,
            "contactInformation": null,
            "contactName": null,
            "contractRule": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "contractTypes": null,
            "coverageEffectiveDate": null,
            "coverages": null,
            "dateBegin": null,
            "dateEnd": null,
            "departments": null,
            "drugOptionCode": null,
            "effectiveDate": null,
            "fax": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "groupCoverageBeginDate": null,
            "groupCoverageTermDate": null,
            "groupDescription": null,
            "groupLeader": null,
            "groupName": null,
            "groupNumberAmms": null,
            "groupNumberCes": null,
            "groupType": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "id": "0000667",
            "idCardType": null,
            "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "lastBillAmount": null,
            "lastBillDate": null,
            "maintenenceDate": null,
            "masterARNumber": null,
            "masterCoverageRateBegin": null,
            "masterCoverageRateEnd": null,
            "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "outputRules": null,
            "paymentSummaryNumber": null,
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "probationaryPeriods": null,
            "productRule": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "ratingCounty": null,
            "rpn": null,
            "salesRepresentative": {
                "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
                },
                "id": null,
                "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
                },
                "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
                },
                "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                }
            },
            "serviceRepresentative": {
                "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
                },
                "id": null,
                "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
                },
                "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
                },
                "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                }
            },
            "sicCode": null,
            "specialHandling": null,
            "statusDescription": null,
            "subClientDescription": null,
            "subClientNumber": null,
            "terminationDate": null
            },
            "listBillIndicator": "",
            "majorMedicalWaiverCode": {
            "code": "",
            "description": null,
            "key": "",
            "name": "",
            "value": null
            },
            "memberId": null,
            "oldGroup": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "agency": null,
            "anniversaryDate": null,
            "benefitSystem": null,
            "billDueDate": null,
            "billingAgencyCode": null,
            "billingAgentCode": null,
            "cancelCode": null,
            "cancelReasonCode": null,
            "clientContribution": null,
            "clientDescription": null,
            "clientNumber": null,
            "clientServiceCenterCode": null,
            "contactInformation": null,
            "contactName": null,
            "contractRule": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "contractTypes": null,
            "coverageEffectiveDate": null,
            "coverages": null,
            "dateBegin": null,
            "dateEnd": null,
            "departments": null,
            "drugOptionCode": null,
            "effectiveDate": null,
            "fax": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "groupCoverageBeginDate": null,
            "groupCoverageTermDate": null,
            "groupDescription": null,
            "groupLeader": null,
            "groupName": null,
            "groupNumberAmms": null,
            "groupNumberCes": null,
            "groupType": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "id": "036011101",
            "idCardType": null,
            "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "lastBillAmount": null,
            "lastBillDate": null,
            "maintenenceDate": null,
            "masterARNumber": null,
            "masterCoverageRateBegin": null,
            "masterCoverageRateEnd": null,
            "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "outputRules": null,
            "paymentSummaryNumber": null,
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "probationaryPeriods": null,
            "productRule": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "ratingCounty": null,
            "rpn": null,
            "salesRepresentative": {
                "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
                },
                "id": null,
                "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
                },
                "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
                },
                "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                }
            },
            "serviceRepresentative": {
                "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
                },
                "id": null,
                "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
                },
                "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
                },
                "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                }
            },
            "sicCode": null,
            "specialHandling": null,
            "statusDescription": null,
            "subClientDescription": null,
            "subClientNumber": null,
            "terminationDate": null
            },
            "periods": null,
            "serviceCenter": "B01",
            "type": null
        }
        ],
        "databaseNumber": "123456789",
        "dateOfBirth": "1958-10-01T00:00:00-0400",
        "drugIndicator": "Z",
        "employeeStatus": null,
        "engagementMemberRecords": null,
        "eobRecipient": "",
        "exceptionIndicator": false,
        "extraPhoneNumbers": [

        ],
        "fep": false,
        "formatNumber": null,
        "groupNumberCheckDigit": "",
        "groupPrefix": "GROUP - MAJOR",
        "hireDate": null,
        "id": "123456789",
        "idCardNumber": "065922516805",
        "idCode": {
        "code": null,
        "description": null,
        "key": null,
        "name": null,
        "value": null
        },
        "isMobileNotificationsEnabledForGroup": null,
        "lastIdCardDate": null,
        "lastIdCardIssueDate": "2018-05-18T00:00:00-0400",
        "latestCoverage": {
        "active": true,
        "benefitSystem": "OLD",
        "coverageId": {
            "benefitLevel": "001",
            "coverageLevelCode": "C",
            "coverageNumber": "0000006",
            "productCode": "Products.DENTAL"
        },
        "drugProcessingCode": {
            "code": "",
            "description": null,
            "key": "",
            "name": "",
            "value": null
        },
        "effectiveDate": "2003-01-01T00:00:00-0500",
        "group": {
            "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
            },
            "agency": null,
            "anniversaryDate": null,
            "benefitSystem": null,
            "billDueDate": null,
            "billingAgencyCode": null,
            "billingAgentCode": null,
            "cancelCode": null,
            "cancelReasonCode": null,
            "clientContribution": null,
            "clientDescription": null,
            "clientNumber": null,
            "clientServiceCenterCode": null,
            "contactInformation": null,
            "contactName": null,
            "contractRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "contractTypes": null,
            "coverageEffectiveDate": null,
            "coverages": null,
            "dateBegin": null,
            "dateEnd": null,
            "departments": null,
            "drugOptionCode": null,
            "effectiveDate": null,
            "fax": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
            },
            "groupCoverageBeginDate": null,
            "groupCoverageTermDate": null,
            "groupDescription": null,
            "groupLeader": null,
            "groupName": null,
            "groupNumberAmms": null,
            "groupNumberCes": null,
            "groupType": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "id": "0000667",
            "idCardType": null,
            "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "lastBillAmount": null,
            "lastBillDate": null,
            "maintenenceDate": null,
            "masterARNumber": null,
            "masterCoverageRateBegin": null,
            "masterCoverageRateEnd": null,
            "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
            },
            "outputRules": null,
            "paymentSummaryNumber": null,
            "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
            },
            "probationaryPeriods": null,
            "productRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "ratingCounty": null,
            "rpn": null,
            "salesRepresentative": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            }
            },
            "serviceRepresentative": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            }
            },
            "sicCode": null,
            "specialHandling": null,
            "statusDescription": null,
            "subClientDescription": null,
            "subClientNumber": null,
            "terminationDate": null
        },
        "listBillIndicator": "",
        "majorMedicalWaiverCode": {
            "code": "",
            "description": null,
            "key": "",
            "name": "",
            "value": null
        },
        "memberId": null,
        "oldGroup": {
            "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
            },
            "agency": null,
            "anniversaryDate": null,
            "benefitSystem": null,
            "billDueDate": null,
            "billingAgencyCode": null,
            "billingAgentCode": null,
            "cancelCode": null,
            "cancelReasonCode": null,
            "clientContribution": null,
            "clientDescription": null,
            "clientNumber": null,
            "clientServiceCenterCode": null,
            "contactInformation": null,
            "contactName": null,
            "contractRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "contractTypes": null,
            "coverageEffectiveDate": null,
            "coverages": null,
            "dateBegin": null,
            "dateEnd": null,
            "departments": null,
            "drugOptionCode": null,
            "effectiveDate": null,
            "fax": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
            },
            "groupCoverageBeginDate": null,
            "groupCoverageTermDate": null,
            "groupDescription": null,
            "groupLeader": null,
            "groupName": null,
            "groupNumberAmms": null,
            "groupNumberCes": null,
            "groupType": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "id": "036011101",
            "idCardType": null,
            "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "lastBillAmount": null,
            "lastBillDate": null,
            "maintenenceDate": null,
            "masterARNumber": null,
            "masterCoverageRateBegin": null,
            "masterCoverageRateEnd": null,
            "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
            },
            "outputRules": null,
            "paymentSummaryNumber": null,
            "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
            },
            "probationaryPeriods": null,
            "productRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "ratingCounty": null,
            "rpn": null,
            "salesRepresentative": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            }
            },
            "serviceRepresentative": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            }
            },
            "sicCode": null,
            "specialHandling": null,
            "statusDescription": null,
            "subClientDescription": null,
            "subClientNumber": null,
            "terminationDate": null
        },
        "periods": null,
        "serviceCenter": "A01",
        "type": null
        },
        "maintenanceDate": null,
        "memberId": "001",
        "members": [
        {
            "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
            },
            "age": null,
            "alternateNames": [

            ],
            "birthdate": "09\/01\/1960",
            "cancelCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "cardNumber": null,
            "carrierName": null,
            "carrierRestricted": false,
            "cesMemberNumber": "02",
            "confidentialClaimIndicator": false,
            "dateOfBirth": "1960-09-01T00:00:00-0400",
            "deferrals": [

            ],
            "dependentIndicator": "C",
            "dependentVerified": "VERIFIED NON-STATE",
            "employmentStatus": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "id": null,
            "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "maritalStatus": {
            "code": null,
            "description": null,
            "key": null,
            "maritalStatusDate": null,
            "name": null,
            "value": null
            },
            "medicareNumber": null,
            "memberId": "002",
            "memberStatus": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "memberSubscriber": false,
            "name": {
            "firstName": "MARTHA",
            "lastName": "TESTING",
            "middleName": "",
            "prefixName": null,
            "suffixName": ""
            },
            "originalEnrollmentDate": null,
            "overAgeDependent": {
            "certifiedDate": null,
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "overrides": [

            ],
            "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
            },
            "planCode": null,
            "preferredLanguage": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "previousMemberId": null,
            "primaryCarePhysicianFound": false,
            "primaryCarePhysicianId": null,
            "primaryCarePhysicianName": null,
            "privacyIndicator": "Y",
            "recordBeginDate": null,
            "recordTermDate": null,
            "relationship": {
            "code": "4",
            "description": null,
            "key": "4",
            "name": "4",
            "value": null
            },
            "relationshipCode": "4",
            "relationshipName": "SPOUSE",
            "setupDate": null,
            "sex": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "sexCode": null,
            "sexName": "FEMALE",
            "socialSecurityNumber": null,
            "subscriberId": null,
            "suppressIdCards": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "tobaccoUsage": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "understandsEnglish": false,
            "updateByEmployee": "CI300",
            "updateDate": null,
            "verifiedPatientIndicator": "Y",
            "visionPlanPatientId": null
        },
        {
            "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
            },
            "age": null,
            "alternateNames": [

            ],
            "birthdate": "10\/01\/1958",
            "cancelCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "cardNumber": null,
            "carrierName": null,
            "carrierRestricted": false,
            "cesMemberNumber": "01",
            "confidentialClaimIndicator": false,
            "dateOfBirth": "1958-10-01T00:00:00-0400",
            "deferrals": [

            ],
            "dependentIndicator": "C",
            "dependentVerified": "VERIFIED NON-STATE",
            "employmentStatus": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "id": null,
            "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "maritalStatus": {
            "code": null,
            "description": null,
            "key": null,
            "maritalStatusDate": null,
            "name": null,
            "value": null
            },
            "medicareNumber": null,
            "memberId": "001",
            "memberStatus": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "memberSubscriber": true,
            "name": {
            "firstName": "MICHAEL",
            "lastName": "TESTING",
            "middleName": "",
            "prefixName": null,
            "suffixName": ""
            },
            "originalEnrollmentDate": null,
            "overAgeDependent": {
            "certifiedDate": null,
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "overrides": [

            ],
            "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
            },
            "planCode": null,
            "preferredLanguage": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "previousMemberId": null,
            "primaryCarePhysicianFound": false,
            "primaryCarePhysicianId": null,
            "primaryCarePhysicianName": null,
            "privacyIndicator": "",
            "recordBeginDate": null,
            "recordTermDate": null,
            "relationship": {
            "code": "1",
            "description": null,
            "key": "1",
            "name": "1",
            "value": null
            },
            "relationshipCode": "1",
            "relationshipName": "SUBSCRIBER",
            "setupDate": null,
            "sex": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "sexCode": null,
            "sexName": "MALE",
            "socialSecurityNumber": null,
            "subscriberId": null,
            "suppressIdCards": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "tobaccoUsage": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "understandsEnglish": false,
            "updateByEmployee": "CI300",
            "updateDate": null,
            "verifiedPatientIndicator": "Y",
            "visionPlanPatientId": null
        },
        {
            "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
            },
            "age": null,
            "alternateNames": [

            ],
            "birthdate": "10\/01\/2002",
            "cancelCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "cardNumber": null,
            "carrierName": null,
            "carrierRestricted": false,
            "cesMemberNumber": "03",
            "confidentialClaimIndicator": false,
            "dateOfBirth": "2002-10-01T00:00:00-0400",
            "deferrals": [

            ],
            "dependentIndicator": "C",
            "dependentVerified": "VERIFIED NON-STATE",
            "employmentStatus": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "id": null,
            "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "maritalStatus": {
            "code": null,
            "description": null,
            "key": null,
            "maritalStatusDate": null,
            "name": null,
            "value": null
            },
            "medicareNumber": null,
            "memberId": "003",
            "memberStatus": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "memberSubscriber": false,
            "name": {
            "firstName": "TERRI",
            "lastName": "TESTING",
            "middleName": "R",
            "prefixName": null,
            "suffixName": ""
            },
            "originalEnrollmentDate": null,
            "overAgeDependent": {
            "certifiedDate": null,
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "overrides": [

            ],
            "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
            },
            "planCode": null,
            "preferredLanguage": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "previousMemberId": null,
            "primaryCarePhysicianFound": false,
            "primaryCarePhysicianId": null,
            "primaryCarePhysicianName": null,
            "privacyIndicator": "",
            "recordBeginDate": null,
            "recordTermDate": null,
            "relationship": {
            "code": "6",
            "description": null,
            "key": "6",
            "name": "6",
            "value": null
            },
            "relationshipCode": "6",
            "relationshipName": "DEPENDENT",
            "setupDate": null,
            "sex": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "sexCode": null,
            "sexName": "FEMALE",
            "socialSecurityNumber": null,
            "subscriberId": null,
            "suppressIdCards": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "tobaccoUsage": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "understandsEnglish": false,
            "updateByEmployee": "CI300",
            "updateDate": null,
            "verifiedPatientIndicator": "Y",
            "visionPlanPatientId": null
        }
        ],
        "name": {
        "firstName": "MICHAEL",
        "lastName": "TESTING",
        "middleName": "",
        "prefixName": null,
        "suffixName": null
        },
        "notes": null,
        "originalEffectiveDate": "2002-06-01T00:00:00-0400",
        "phone": {
        "areaCode": "803",
        "extension": null,
        "prefix": "456",
        "suffix": "4564",
        "type": null
        },
        "policyType": "GROUP",
        "relatedInformationIndicator": false,
        "relationshipCode": null,
        "relationshipName": "SUBSCRIBER",
        "searchType": null,
        "selectedAMMSPatientId": null,
        "selectedPatientId": "001",
        "serviceCenter": {
        "code": "B01",
        "description": "MOHASCO",
        "key": "B01",
        "location": null,
        "name": "B01",
        "value": "MOHASCO"
        },
        "sexCode": null,
        "sexName": "MALE",
        "socialSecurityNumber": "",
        "subscriberMember": {
        "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "rpn": null,
            "state": null,
            "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
        },
        "age": null,
        "alternateNames": [

        ],
        "birthdate": "10\/01\/1958",
        "cancelCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "cardNumber": null,
        "carrierName": null,
        "carrierRestricted": false,
        "cesMemberNumber": "01",
        "confidentialClaimIndicator": false,
        "dateOfBirth": "1958-10-01T00:00:00-0400",
        "deferrals": [

        ],
        "dependentIndicator": "C",
        "dependentVerified": "VERIFIED NON-STATE",
        "employmentStatus": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "id": null,
        "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "maritalStatus": {
            "code": null,
            "description": null,
            "key": null,
            "maritalStatusDate": null,
            "name": null,
            "value": null
        },
        "medicareNumber": null,
        "memberId": "001",
        "memberStatus": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "memberSubscriber": true,
        "name": {
            "firstName": "MICHAEL",
            "lastName": "TESTING",
            "middleName": "",
            "prefixName": null,
            "suffixName": ""
        },
        "originalEnrollmentDate": null,
        "overAgeDependent": {
            "certifiedDate": null,
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "overrides": [

        ],
        "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
        },
        "planCode": null,
        "preferredLanguage": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "previousMemberId": null,
        "primaryCarePhysicianFound": false,
        "primaryCarePhysicianId": null,
        "primaryCarePhysicianName": null,
        "privacyIndicator": "",
        "recordBeginDate": null,
        "recordTermDate": null,
        "relationship": {
            "code": "1",
            "description": null,
            "key": "1",
            "name": "1",
            "value": null
        },
        "relationshipCode": "1",
        "relationshipName": "SUBSCRIBER",
        "setupDate": null,
        "sex": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "sexCode": null,
        "sexName": "MALE",
        "socialSecurityNumber": null,
        "subscriberId": null,
        "suppressIdCards": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "tobaccoUsage": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "understandsEnglish": false,
        "updateByEmployee": "CI300",
        "updateDate": null,
        "verifiedPatientIndicator": "Y",
        "visionPlanPatientId": null
        },
        "totl": false
    },
    "subscriber": {
        "PAI": false,
        "activeDate": null,
        "activelyCovered": true,
        "address": {
        "address1": "P O BOX  24015",
        "address2": "",
        "address3": null,
        "address4": null,
        "address5": null,
        "city": "COLUMBIA",
        "country": null,
        "county": "040",
        "countyCode": {
            "code": "040",
            "description": null,
            "key": "040",
            "name": "040",
            "rpn": null,
            "state": null,
            "value": null
        },
        "province": null,
        "region": null,
        "state": "SC",
        "stateCode": {
            "code": "SC",
            "description": null,
            "key": "SC",
            "name": "SC",
            "value": null
        },
        "zipcode": "29224",
        "zipcodePostFix": "4015"
        },
        "alphaPrefix": "ZCZ",
        "ammsGroupNumber": "036011101",
        "bill": {
        "amountReceivable": null,
        "arHistoryIndicator": null,
        "balanceAmount": null,
        "billFormat": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "billNumber": null,
        "billedDate": null,
        "billingFrequency": null,
        "clientNumber": null,
        "createARIndicator": null,
        "creationDate": null,
        "dueDate": null,
        "dueDay": null,
        "employeeListIndicator": null,
        "lastPaymentAmount": null,
        "lastPaymentDate": null,
        "listBillAccountNumber": "",
        "masterARNumber": null,
        "mode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "outputType": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "paymentMethod": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "paymentSummary": null,
        "providerId": null,
        "reasonCode": null,
        "recordCode": null,
        "renderTime": null,
        "serviceId": null,
        "sort": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "supressBillIndicator": null,
        "viewStatementIndicator": null
        },
        "birthdate": "10\/01\/1958",
        "businessSector": "",
        "carrierName": null,
        "carrierRestricted": false,
        "ces": true,
        "cesExceptionIndicator": true,
        "cesGroupNumber": "0000667",
        "cisiRpn": null,
        "clientCode": {
        "code": "00006",
        "description": "TEST SPECIAL PROJECTS AREA",
        "key": "00006",
        "name": "00006",
        "value": "TEST SPECIAL PROJECTS AREA"
        },
        "coverage": null,
        "coverageContinuationTypeCode": {
        "code": "",
        "description": null,
        "key": "",
        "name": "",
        "value": null
        },
        "coverageItems": [
        {
            "active": true,
            "benefitSystem": null,
            "coverageId": {
            "benefitLevel": "001",
            "coverageLevelCode": "C",
            "coverageNumber": "0000006",
            "productCode": "Products.DENTAL"
            },
            "drugProcessingCode": {
            "code": "",
            "description": null,
            "key": "",
            "name": "",
            "value": null
            },
            "effectiveDate": "2003-01-01T00:00:00-0500",
            "group": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "agency": null,
            "anniversaryDate": null,
            "benefitSystem": null,
            "billDueDate": null,
            "billingAgencyCode": null,
            "billingAgentCode": null,
            "cancelCode": null,
            "cancelReasonCode": null,
            "clientContribution": null,
            "clientDescription": null,
            "clientNumber": null,
            "clientServiceCenterCode": null,
            "contactInformation": null,
            "contactName": null,
            "contractRule": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "contractTypes": null,
            "coverageEffectiveDate": null,
            "coverages": null,
            "dateBegin": null,
            "dateEnd": null,
            "departments": null,
            "drugOptionCode": null,
            "effectiveDate": null,
            "fax": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "groupCoverageBeginDate": null,
            "groupCoverageTermDate": null,
            "groupDescription": null,
            "groupLeader": null,
            "groupName": null,
            "groupNumberAmms": null,
            "groupNumberCes": null,
            "groupType": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "id": "0000667",
            "idCardType": null,
            "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "lastBillAmount": null,
            "lastBillDate": null,
            "maintenenceDate": null,
            "masterARNumber": null,
            "masterCoverageRateBegin": null,
            "masterCoverageRateEnd": null,
            "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "outputRules": null,
            "paymentSummaryNumber": null,
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "probationaryPeriods": null,
            "productRule": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "ratingCounty": null,
            "rpn": null,
            "salesRepresentative": {
                "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
                },
                "id": null,
                "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
                },
                "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
                },
                "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                }
            },
            "serviceRepresentative": {
                "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
                },
                "id": null,
                "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
                },
                "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
                },
                "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                }
            },
            "sicCode": null,
            "specialHandling": null,
            "statusDescription": null,
            "subClientDescription": null,
            "subClientNumber": null,
            "terminationDate": null
            },
            "listBillIndicator": "",
            "majorMedicalWaiverCode": {
            "code": "",
            "description": null,
            "key": "",
            "name": "",
            "value": null
            },
            "memberId": null,
            "oldGroup": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "agency": null,
            "anniversaryDate": null,
            "benefitSystem": null,
            "billDueDate": null,
            "billingAgencyCode": null,
            "billingAgentCode": null,
            "cancelCode": null,
            "cancelReasonCode": null,
            "clientContribution": null,
            "clientDescription": null,
            "clientNumber": null,
            "clientServiceCenterCode": null,
            "contactInformation": null,
            "contactName": null,
            "contractRule": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "contractTypes": null,
            "coverageEffectiveDate": null,
            "coverages": null,
            "dateBegin": null,
            "dateEnd": null,
            "departments": null,
            "drugOptionCode": null,
            "effectiveDate": null,
            "fax": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "groupCoverageBeginDate": null,
            "groupCoverageTermDate": null,
            "groupDescription": null,
            "groupLeader": null,
            "groupName": null,
            "groupNumberAmms": null,
            "groupNumberCes": null,
            "groupType": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "id": "036011101",
            "idCardType": null,
            "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "lastBillAmount": null,
            "lastBillDate": null,
            "maintenenceDate": null,
            "masterARNumber": null,
            "masterCoverageRateBegin": null,
            "masterCoverageRateEnd": null,
            "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "outputRules": null,
            "paymentSummaryNumber": null,
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "probationaryPeriods": null,
            "productRule": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "ratingCounty": null,
            "rpn": null,
            "salesRepresentative": {
                "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
                },
                "id": null,
                "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
                },
                "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
                },
                "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                }
            },
            "serviceRepresentative": {
                "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
                },
                "id": null,
                "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
                },
                "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
                },
                "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                }
            },
            "sicCode": null,
            "specialHandling": null,
            "statusDescription": null,
            "subClientDescription": null,
            "subClientNumber": null,
            "terminationDate": null
            },
            "periods": null,
            "serviceCenter": "A01",
            "type": null
        },
        {
            "active": true,
            "benefitSystem": null,
            "coverageId": {
            "benefitLevel": "001",
            "coverageLevelCode": "C",
            "coverageNumber": "0000006",
            "productCode": "Products.MEDICAL"
            },
            "drugProcessingCode": {
            "code": "",
            "description": null,
            "key": "",
            "name": "",
            "value": null
            },
            "effectiveDate": "2002-06-01T00:00:00-0400",
            "group": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "agency": null,
            "anniversaryDate": null,
            "benefitSystem": null,
            "billDueDate": null,
            "billingAgencyCode": null,
            "billingAgentCode": null,
            "cancelCode": null,
            "cancelReasonCode": null,
            "clientContribution": null,
            "clientDescription": null,
            "clientNumber": null,
            "clientServiceCenterCode": null,
            "contactInformation": null,
            "contactName": null,
            "contractRule": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "contractTypes": null,
            "coverageEffectiveDate": null,
            "coverages": null,
            "dateBegin": null,
            "dateEnd": null,
            "departments": null,
            "drugOptionCode": null,
            "effectiveDate": null,
            "fax": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "groupCoverageBeginDate": null,
            "groupCoverageTermDate": null,
            "groupDescription": null,
            "groupLeader": null,
            "groupName": null,
            "groupNumberAmms": null,
            "groupNumberCes": null,
            "groupType": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "id": "0000667",
            "idCardType": null,
            "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "lastBillAmount": null,
            "lastBillDate": null,
            "maintenenceDate": null,
            "masterARNumber": null,
            "masterCoverageRateBegin": null,
            "masterCoverageRateEnd": null,
            "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "outputRules": null,
            "paymentSummaryNumber": null,
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "probationaryPeriods": null,
            "productRule": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "ratingCounty": null,
            "rpn": null,
            "salesRepresentative": {
                "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
                },
                "id": null,
                "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
                },
                "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
                },
                "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                }
            },
            "serviceRepresentative": {
                "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
                },
                "id": null,
                "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
                },
                "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
                },
                "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                }
            },
            "sicCode": null,
            "specialHandling": null,
            "statusDescription": null,
            "subClientDescription": null,
            "subClientNumber": null,
            "terminationDate": null
            },
            "listBillIndicator": "",
            "majorMedicalWaiverCode": {
            "code": "",
            "description": null,
            "key": "",
            "name": "",
            "value": null
            },
            "memberId": null,
            "oldGroup": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "agency": null,
            "anniversaryDate": null,
            "benefitSystem": null,
            "billDueDate": null,
            "billingAgencyCode": null,
            "billingAgentCode": null,
            "cancelCode": null,
            "cancelReasonCode": null,
            "clientContribution": null,
            "clientDescription": null,
            "clientNumber": null,
            "clientServiceCenterCode": null,
            "contactInformation": null,
            "contactName": null,
            "contractRule": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "contractTypes": null,
            "coverageEffectiveDate": null,
            "coverages": null,
            "dateBegin": null,
            "dateEnd": null,
            "departments": null,
            "drugOptionCode": null,
            "effectiveDate": null,
            "fax": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "groupCoverageBeginDate": null,
            "groupCoverageTermDate": null,
            "groupDescription": null,
            "groupLeader": null,
            "groupName": null,
            "groupNumberAmms": null,
            "groupNumberCes": null,
            "groupType": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "id": "036011101",
            "idCardType": null,
            "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "lastBillAmount": null,
            "lastBillDate": null,
            "maintenenceDate": null,
            "masterARNumber": null,
            "masterCoverageRateBegin": null,
            "masterCoverageRateEnd": null,
            "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "outputRules": null,
            "paymentSummaryNumber": null,
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "probationaryPeriods": null,
            "productRule": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "ratingCounty": null,
            "rpn": null,
            "salesRepresentative": {
                "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
                },
                "id": null,
                "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
                },
                "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
                },
                "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                }
            },
            "serviceRepresentative": {
                "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
                },
                "id": null,
                "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
                },
                "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
                },
                "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                }
            },
            "sicCode": null,
            "specialHandling": null,
            "statusDescription": null,
            "subClientDescription": null,
            "subClientNumber": null,
            "terminationDate": null
            },
            "periods": null,
            "serviceCenter": "B01",
            "type": null
        }
        ],
        "databaseNumber": "123456789",
        "dateOfBirth": "1958-10-01T00:00:00-0400",
        "drugIndicator": "Z",
        "employeeStatus": null,
        "engagementMemberRecords": null,
        "eobRecipient": "",
        "exceptionIndicator": false,
        "extraPhoneNumbers": null,
        "fep": false,
        "formatNumber": null,
        "groupNumberCheckDigit": "",
        "groupPrefix": "03",
        "hireDate": null,
        "id": "123456789",
        "idCardNumber": "065922516805",
        "idCode": {
        "code": null,
        "description": null,
        "key": null,
        "name": null,
        "value": null
        },
        "isMobileNotificationsEnabledForGroup": null,
        "lastIdCardDate": null,
        "lastIdCardIssueDate": "2018-05-18T00:00:00-0400",
        "latestCoverage": {
        "active": true,
        "benefitSystem": null,
        "coverageId": {
            "benefitLevel": "001",
            "coverageLevelCode": "C",
            "coverageNumber": "0000006",
            "productCode": "Products.DENTAL"
        },
        "drugProcessingCode": {
            "code": "",
            "description": null,
            "key": "",
            "name": "",
            "value": null
        },
        "effectiveDate": "2003-01-01T00:00:00-0500",
        "group": {
            "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
            },
            "agency": null,
            "anniversaryDate": null,
            "benefitSystem": null,
            "billDueDate": null,
            "billingAgencyCode": null,
            "billingAgentCode": null,
            "cancelCode": null,
            "cancelReasonCode": null,
            "clientContribution": null,
            "clientDescription": null,
            "clientNumber": null,
            "clientServiceCenterCode": null,
            "contactInformation": null,
            "contactName": null,
            "contractRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "contractTypes": null,
            "coverageEffectiveDate": null,
            "coverages": null,
            "dateBegin": null,
            "dateEnd": null,
            "departments": null,
            "drugOptionCode": null,
            "effectiveDate": null,
            "fax": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
            },
            "groupCoverageBeginDate": null,
            "groupCoverageTermDate": null,
            "groupDescription": null,
            "groupLeader": null,
            "groupName": null,
            "groupNumberAmms": null,
            "groupNumberCes": null,
            "groupType": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "id": "0000667",
            "idCardType": null,
            "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "lastBillAmount": null,
            "lastBillDate": null,
            "maintenenceDate": null,
            "masterARNumber": null,
            "masterCoverageRateBegin": null,
            "masterCoverageRateEnd": null,
            "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
            },
            "outputRules": null,
            "paymentSummaryNumber": null,
            "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
            },
            "probationaryPeriods": null,
            "productRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "ratingCounty": null,
            "rpn": null,
            "salesRepresentative": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            }
            },
            "serviceRepresentative": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            }
            },
            "sicCode": null,
            "specialHandling": null,
            "statusDescription": null,
            "subClientDescription": null,
            "subClientNumber": null,
            "terminationDate": null
        },
        "listBillIndicator": "",
        "majorMedicalWaiverCode": {
            "code": "",
            "description": null,
            "key": "",
            "name": "",
            "value": null
        },
        "memberId": null,
        "oldGroup": {
            "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
            },
            "agency": null,
            "anniversaryDate": null,
            "benefitSystem": null,
            "billDueDate": null,
            "billingAgencyCode": null,
            "billingAgentCode": null,
            "cancelCode": null,
            "cancelReasonCode": null,
            "clientContribution": null,
            "clientDescription": null,
            "clientNumber": null,
            "clientServiceCenterCode": null,
            "contactInformation": null,
            "contactName": null,
            "contractRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "contractTypes": null,
            "coverageEffectiveDate": null,
            "coverages": null,
            "dateBegin": null,
            "dateEnd": null,
            "departments": null,
            "drugOptionCode": null,
            "effectiveDate": null,
            "fax": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
            },
            "groupCoverageBeginDate": null,
            "groupCoverageTermDate": null,
            "groupDescription": null,
            "groupLeader": null,
            "groupName": null,
            "groupNumberAmms": null,
            "groupNumberCes": null,
            "groupType": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "id": "036011101",
            "idCardType": null,
            "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "lastBillAmount": null,
            "lastBillDate": null,
            "maintenenceDate": null,
            "masterARNumber": null,
            "masterCoverageRateBegin": null,
            "masterCoverageRateEnd": null,
            "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
            },
            "outputRules": null,
            "paymentSummaryNumber": null,
            "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
            },
            "probationaryPeriods": null,
            "productRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
            },
            "ratingCounty": null,
            "rpn": null,
            "salesRepresentative": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            }
            },
            "serviceRepresentative": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            }
            },
            "sicCode": null,
            "specialHandling": null,
            "statusDescription": null,
            "subClientDescription": null,
            "subClientNumber": null,
            "terminationDate": null
        },
        "periods": null,
        "serviceCenter": "A01",
        "type": null
        },
        "maintenanceDate": null,
        "memberId": null,
        "members": null,
        "name": {
        "firstName": "MICHAEL",
        "lastName": "TESTING",
        "middleName": "",
        "prefixName": null,
        "suffixName": null
        },
        "notes": null,
        "originalEffectiveDate": "2002-06-01T00:00:00-0400",
        "phone": {
        "areaCode": null,
        "extension": null,
        "prefix": null,
        "suffix": null,
        "type": null
        },
        "policyType": null,
        "relatedInformationIndicator": false,
        "relationshipCode": null,
        "relationshipName": null,
        "searchType": null,
        "selectedAMMSPatientId": null,
        "selectedPatientId": null,
        "serviceCenter": {
        "code": "B01",
        "description": null,
        "key": "B01",
        "location": null,
        "name": "B01",
        "value": null
        },
        "sexCode": "M",
        "sexName": null,
        "socialSecurityNumber": "",
        "subscriberMember": null,
        "totl": false
    }
}