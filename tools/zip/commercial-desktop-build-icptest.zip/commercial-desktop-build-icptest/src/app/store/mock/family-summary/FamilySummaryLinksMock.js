/* eslint-disable */
export const mockFamilySummaryLinks = [
    {
        'name': 'patient-deduct-oop',
        'transaction-type': 'url',
        'transaction': 'http://lmgtfy.com'
    },
    {
        'name': 'patient-inquiry',
        'transaction-type': 'url',
        'transaction': 'http://google.com'
    },
    {
        'name': 'fep-eligibility',
        'transaction-type': 'url',
        'transaction': 'http://duckduckgo.com'
    }
]
