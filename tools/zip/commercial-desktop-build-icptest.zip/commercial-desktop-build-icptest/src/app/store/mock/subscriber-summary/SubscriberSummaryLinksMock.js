/* eslint-disable */
export const mockSubscriberSummaryLinks = [
    {
        'name': 'ces-exceptions',
        'transaction-type': 'url',
        'transaction': 'http://lmgtfy.com'
    },
    {
        'name': 'ces-related',
        'transaction-type': 'url',
        'transaction': 'http://google.com'
    },
    {
        'name': 'email-addresses',
        'transaction-type': 'url',
        'transaction': 'http://stackoverflow.com'
    },
    {
        'name': 'hippa-information',
        'transaction-type': 'url',
        'transaction': 'http://amazon.com'
    },
    {
        'name': 'image-history',
        'transaction-type': 'url',
        'transaction': 'http://dogpile.com'
    },
    {
        'name': 'medicare-info',
        'transaction-type': 'url',
        'transaction': 'http://duckduckgo.com'
    }
]
