/* eslint-disable */
export const mockNavLinkCategories = {
    "identifier": "id",
    "label": "description",
    "items": [
        {
            "identifier": "id",
            "label": "description",
            "items": [
              {
                "id": "C00002-C00002",
                "type": "NAVCATEGORY",
                "description": "CLAIMS & BENEFITS"
              },
              {
                "id": "C00600-C00600",
                "type": "NAVCATEGORY",
                "description": "CLAIMS - DENTAL"
              },
              {
                "id": "C00650-C00650",
                "type": "NAVCATEGORY",
                "description": "CLAIMS - HEALTH"
              },
              {
                "id": "C00001-C00001",
                "type": "NAVCATEGORY",
                "description": "CLAIMS ADJUSTMENTS"
              },
              {
                "id": "C00550-C00550",
                "type": "NAVCATEGORY",
                "description": "CONSUMER DRIVEN HEALTH PLANS"
              },
              {
                "id": "C00008-C00008",
                "type": "NAVCATEGORY",
                "description": "DENTAL"
              },
              {
                "id": "C00014-C00014",
                "type": "NAVCATEGORY",
                "description": "DOCUMENTS"
              },
              {
                "id": "C00003-C00003",
                "type": "NAVCATEGORY",
                "description": "EXPLANATION OF BENEFITS"
              },
              {
                "id": "C00012-C00012",
                "type": "NAVCATEGORY",
                "description": "FEP"
              },
              {
                "id": "C00010-C00010",
                "type": "NAVCATEGORY",
                "description": "FINANCIAL"
              },
              {
                "id": "C00005-C00005",
                "type": "NAVCATEGORY",
                "description": "GROUP ELIGIBILITY INFO"
              },
              {
                "id": "C00011-C00011",
                "type": "NAVCATEGORY",
                "description": "ITS"
              },
              {
                "id": "C00006-C00006",
                "type": "NAVCATEGORY",
                "description": "MAINTENANCE TRANSACTIONS"
              },
              {
                "id": "C00015-C00015",
                "type": "NAVCATEGORY",
                "description": "MANAGED CARE"
              },
              {
                "id": "C00036-C00036",
                "type": "NAVCATEGORY",
                "description": "OLD MEMBERSHIP SYSTEM"
              },
              {
                "id": "C00009-C00009",
                "type": "NAVCATEGORY",
                "description": "PROVIDER DATA"
              },
              {
                "id": "C00007-C00007",
                "type": "NAVCATEGORY",
                "description": "REFERENCE"
              },
              {
                "id": "C00018-C00018",
                "type": "NAVCATEGORY",
                "description": "RESEARCH DENTAL CLAIMS"
              },
              {
                "id": "C00016-C00016",
                "type": "NAVCATEGORY",
                "description": "RESEARCH HEALTH CLAIMS"
              },
              {
                "id": "C00034-C00034",
                "type": "NAVCATEGORY",
                "description": "SUBSCRIBER CROSS REFERENCE"
              },
              {
                "id": "C00004-C00004",
                "type": "NAVCATEGORY",
                "description": "SUBSCRIBER ELIGIBILITY INFO"
              },
              {
                "id": "C00700-C00700",
                "type": "NAVCATEGORY",
                "description": "SUPPORT ACCESS"
              }
            ]
        }
    ]
}
