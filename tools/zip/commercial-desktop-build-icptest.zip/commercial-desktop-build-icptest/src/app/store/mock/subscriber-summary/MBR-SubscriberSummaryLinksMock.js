/* eslint-disable */
export const mockSubscriberSummaryLinks = [
    {
        'name': 'ces-exceptions',
        'transaction-type': 'url',
        'transaction': 'http://lmgtfy.com'
    },
    {
        'name': 'ces-related',
        'transaction-type': 'url',
        'transaction': 'http://google.com'
    },
    {
        'name': 'email-addresses',
        'transaction-type': 'url',
        'transaction': 'http://stackoverflow.com'
    },
    {
        'name': 'hippa-information',
        'transaction-type': 'url',
        'transaction': 'http://amazon.com'
    },
    {
        'name': 'image-history',
        'transaction-type': 'url',
        'transaction': 'http://dogpile.com'
    },
    {
        'name': 'medicare-info',
        'transaction-type': 'url',
        'transaction': 'http://duckduckgo.com'
    },
    {
        'name': 'address-history',
        'transaction-type': 'url',
        'transaction': 'http://weather.com'
    },
    {
        'name': 'application-summary',
        'transaction-type': 'url',
        'transaction': 'https://www.wikipedia.org/'
    },
    {
        'name': 'contract-status',
        'transaction-type': 'url',
        'transaction': 'https://github.com/'
    },
    {
        'name': 'exceptions-summary',
        'transaction-type': 'url',
        'transaction': 'https://www.w3schools.com/'
    },
    {
        'name': 'subscriber-status-history',
        'transaction-type': 'url',
        'transaction': 'https://www.udemy.com/'
    }
]
