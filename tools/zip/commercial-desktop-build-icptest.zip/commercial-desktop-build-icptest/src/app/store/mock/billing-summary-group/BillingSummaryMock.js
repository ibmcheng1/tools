/* eslint-disable */
export const mockGroupBillingSummary = {
    "billingInformation": {
        "abaRoutingNumber": "",
        "accountsRecievableCreationDescription": "YES",
        "addressTypeCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "bankAccountName": "",
        "bankAccountNumber": "",
        "billFormatCode": {
            "code": "P1",
            "description": "FULL BILL TO GRP W/SUBPRD",
            "key": "P1",
            "name": "P1",
            "value": "FULL BILL TO GRP W/SUBPRD"
        },
        "billModeCode": {
            "code": "01",
            "description": "MONTHLY - 30 DAYS",
            "key": "01",
            "name": "01",
            "value": "MONTHLY - 30 DAYS"
        },
        "billNumber": "255487600",
        "billingAgent": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "agency": {
                "address": {
                    "address1": null,
                    "address2": null,
                    "address3": null,
                    "address4": null,
                    "address5": null,
                    "city": null,
                    "country": null,
                    "county": null,
                    "countyCode": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "rpn": null,
                        "state": null,
                        "value": null
                    },
                    "province": null,
                    "region": null,
                    "state": null,
                    "stateCode": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "zipcode": null,
                    "zipcodePostFix": null
                },
                "agent": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "id": null,
                "idCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "name": {
                    "firstName": null,
                    "lastName": null,
                    "middleName": null,
                    "prefixName": null,
                    "suffixName": null
                },
                "phone": {
                    "areaCode": null,
                    "extension": null,
                    "prefix": null,
                    "suffix": null,
                    "type": null
                }
            },
            "agentCode": null,
            "agentLookUpName": null,
            "agentLookupName": null,
            "authorizedForHSA": false,
            "id": null,
            "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "individualHealthEffectiveDate": null,
            "individualHealthTermDate": null,
            "individualhealthStatus": null,
            "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            }
        },
        "businessTypeCode": {
            "code": "MAJ",
            "description": "MAJOR GROUP INSURED BUSIN",
            "key": "MAJ",
            "name": "MAJ",
            "value": "MAJOR GROUP INSURED BUSIN"
        },
        "clientNumber": "00732",
        "creditCardExpiration": null,
        "creditCardNumber": "",
        "currentBalance": null,
        "delinquencyStatus": false,
        "dueDate": "2018-07-01T00:00:00-0400",
        "dueDay": "01",
        "groupName": "PALMETTO CORP OF CONWAY",
        "groupNumber": null,
        "groupPolicy": true,
        "hasCoveragePeriods": false,
        "lastPayment": null,
        "lastPaymentReceivedDate": null,
        "listBillAccountNumber": null,
        "listBillContactName": null,
        "listBillName": null,
        "listBillNumber": "000000000",
        "listBillPhoneNumber": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
        },
        "masterARNumber": "00000001195140",
        "outputTypeCode": {
            "code": "06",
            "description": "WEB & PAPER",
            "key": "06",
            "name": "06",
            "value": "WEB & PAPER"
        },
        "paymentMethodCode": {
            "code": "01",
            "description": "CHECK",
            "key": "01",
            "name": "01",
            "value": "CHECK"
        },
        "paymentSummaryNumber": "1460",
        "reportIdentifier": "PVTBBILL",
        "sortCode": {
            "code": null,
            "description": "ALPHABETICALLY WITHIN GRO",
            "key": null,
            "name": null,
            "value": "ALPHABETICALLY WITHIN GRO"
        },
        "statementCreatedDate": "2018-06-15T00:00:00-0400",
        "suppressDescription": "NO"
    },
    "billingInformationLoaded": true,
    "dynaGroup": {
        "address": {
            "address1": "PALMETTO CORP OF CONWAY",
            "address2": "ATTN KIM WEAVER",
            "address3": "P O BOX 346",
            "address4": "ACTIVE",
            "address5": null,
            "city": "CONWAY",
            "country": null,
            "county": null,
            "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
            },
            "province": null,
            "region": null,
            "state": "SC",
            "stateCode": {
                "code": "SC",
                "description": "",
                "key": "SC",
                "name": "SC",
                "value": ""
            },
            "zipcode": "29528",
            "zipcodePostFix": "0346"
        },
        "agency": null,
        "anniversaryDate": "2013-12-01T00:00:00-0500",
        "benefitSystem": "OLD",
        "billDueDate": "2018-07-01T00:00:00-0400",
        "billingAgencyCode": {
            "code": "Z34",
            "description": "MCLAUGHLIN & SMOAK LLC",
            "key": "Z34",
            "name": "Z34",
            "value": "MCLAUGHLIN & SMOAK LLC"
        },
        "billingAgentCode": {
            "code": "Z34003",
            "description": "UNKNOWN",
            "key": "Z34003",
            "name": "Z34003",
            "value": "UNKNOWN"
        },
        "cancelCode": null,
        "cancelReasonCode": null,
        "clientContribution": {
            "code": "A",
            "description": "EMPLOYER PAYS LESS THAN 100%",
            "key": "A",
            "name": "A",
            "value": "EMPLOYER PAYS LESS THAN 100%"
        },
        "clientDescription": "PALMETTO CORP OF CONWAY",
        "clientNumber": "00732",
        "clientServiceCenterCode": {
            "code": "FPB",
            "description": "PALMETTO CORP OF CONWAY",
            "key": "FPB",
            "name": "FPB",
            "value": "PALMETTO CORP OF CONWAY"
        },
        "contactInformation": null,
        "contactName": "KIM  WEAVER",
        "contractRule": {
            "code": "N",
            "description": "NO TC'S NEED TO MATCH",
            "key": "N",
            "name": "N",
            "value": "NO TC'S NEED TO MATCH"
        },
        "contractTypes": [
            {
                "contractBaseRate": 1208.85,
                "contractTypeCode": {
                    "code": "F",
                    "description": "FAMILY",
                    "key": "F",
                    "name": "F",
                    "value": "FAMILY"
                }
            },
            {
                "contractBaseRate": 432.19,
                "contractTypeCode": {
                    "code": "I",
                    "description": "INDIVIDUAL",
                    "key": "I",
                    "name": "I",
                    "value": "INDIVIDUAL"
                }
            },
            {
                "contractBaseRate": 822.31,
                "contractTypeCode": {
                    "code": "IC",
                    "description": "INDIVIDUAL AND CHILDREN",
                    "key": "IC",
                    "name": "IC",
                    "value": "INDIVIDUAL AND CHILDREN"
                }
            },
            {
                "contractBaseRate": 994.06,
                "contractTypeCode": {
                    "code": "IS",
                    "description": "INDIVIDUAL AND SPOUSE",
                    "key": "IS",
                    "name": "IS",
                    "value": "INDIVIDUAL AND SPOUSE"
                }
            },
            {
                "contractBaseRate": 0,
                "contractTypeCode": {
                    "code": "NB",
                    "description": "NON BILLABLE",
                    "key": "NB",
                    "name": "NB",
                    "value": "NON BILLABLE"
                }
            }
        ],
        "coverageEffectiveDate": "2006-01-01T00:00:00-0500",
        "coverages": null,
        "dateBegin": "2015-12-01T00:00:00-0500",
        "dateEnd": null,
        "departments": [],
        "drugOptionCode": {
            "code": "",
            "description": "",
            "key": "",
            "name": "",
            "value": ""
        },
        "effectiveDate": null,
        "fax": {
            "areaCode": "",
            "extension": null,
            "prefix": "",
            "suffix": "",
            "type": null
        },
        "groupCoverageBeginDate": "2006-12-01T00:00:00-0500",
        "groupCoverageTermDate": null,
        "groupDescription": "ACTIVE",
        "groupLeader": null,
        "groupName": "PALMETTO CORP OF CONWAY",
        "groupNumberAmms": "255487600",
        "groupNumberCes": "0012345",
        "groupType": {
            "code": "LG",
            "description": "FULLY INSURED 100+",
            "key": "LG",
            "name": "LG",
            "value": "FULLY INSURED 100+"
        },
        "id": null,
        "idCardType": null,
        "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "lastBillAmount": 152366.03,
        "lastBillDate": "2018-06-15T00:00:00-0400",
        "maintenenceDate": null,
        "masterARNumber": "00000001195140",
        "masterCoverageRateBegin": "2017-12-01T00:00:00-0500",
        "masterCoverageRateEnd": null,
        "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
        },
        "outputRules": {
            "dateBegin": "2018-01-01T00:00:00-0500",
            "dateEnd": null,
            "drugEligibilityTapeCode": {
                "code": "G",
                "description": "APCS ELIGIBILITY BASED ON GCCF",
                "key": "G",
                "name": "G",
                "value": "APCS ELIGIBILITY BASED ON GCCF"
            },
            "explanationOfBenefitsCode": {
                "code": "0",
                "description": "EOBS ARE SENT TO THE SUBSCRIBER'S ADDRESS 0=BLANK",
                "key": "0",
                "name": "0",
                "value": "EOBS ARE SENT TO THE SUBSCRIBER'S ADDRESS 0=BLANK"
            },
            "idCardAlphaPrefix": "ZCW",
            "idCardFormatCode": {
                "code": "MDX",
                "description": "COPY OF CARD TYPE MCQ",
                "key": "MDX",
                "name": "MDX",
                "value": "COPY OF CARD TYPE MCQ"
            },
            "idCardLiteratureCode": {
                "code": "D",
                "description": "ID CARD ONLY - NATIONAL ACCOUNT",
                "key": "D",
                "name": "D",
                "value": "ID CARD ONLY - NATIONAL ACCOUNT"
            },
            "idCardMailCode": {
                "code": "1",
                "description": "ID CARDS ARE TO BE MAILED TO SUBSCRIBERS",
                "key": "1",
                "name": "1",
                "value": "ID CARDS ARE TO BE MAILED TO SUBSCRIBERS"
            },
            "idCardPrintCode": {
                "code": "S",
                "description": "PRINT ID CARD ALPHA PREFIX",
                "key": "S",
                "name": "S",
                "value": "PRINT ID CARD ALPHA PREFIX"
            },
            "idCardSequenceCode": {
                "code": "1",
                "description": "SORT ID CARDS ALPHABETICALLY",
                "key": "1",
                "name": "1",
                "value": "SORT ID CARDS ALPHABETICALLY"
            },
            "reportRouteCodeClaims": {
                "code": "B2N",
                "description": "COLUMBIA INSURED",
                "key": "B2N",
                "name": "B2N",
                "value": "COLUMBIA INSURED"
            },
            "reportRouteCodeMembership": {
                "code": "MG1",
                "description": "MAJOR GROUP  AX-D10",
                "key": "MG1",
                "name": "MG1",
                "value": "MAJOR GROUP  AX-D10"
            }
        },
        "paymentSummaryNumber": "1460",
        "phone": {
            "areaCode": "843",
            "extension": "",
            "prefix": "365",
            "suffix": "2156",
            "type": null
        },
        "probationaryPeriods": [
            {
                "employeeClassCode": {
                    "code": "A",
                    "description": "ALL EMPLOYEES NOT IDENTIFIED BY ANOTHER EMPL CODE",
                    "key": "A",
                    "name": "A",
                    "value": "ALL EMPLOYEES NOT IDENTIFIED BY ANOTHER EMPL CODE"
                },
                "newHireCode": {
                    "code": "N",
                    "description": "COVERAGE DATE NOT CALCULATED - USE KEYED DATA",
                    "key": "N",
                    "name": "N",
                    "value": "COVERAGE DATE NOT CALCULATED - USE KEYED DATA"
                },
                "newHirePeriodCode": {
                    "code": "0",
                    "description": null,
                    "key": "0",
                    "name": "0",
                    "value": null
                },
                "recordBeginDate": "2016-12-01T00:00:00-0500",
                "recordEndDate": null,
                "rehireCode": {
                    "code": "N",
                    "description": "COVERAGE DATE NOT CALCULATED - USE KEYED DATA",
                    "key": "N",
                    "name": "N",
                    "value": "COVERAGE DATE NOT CALCULATED - USE KEYED DATA"
                },
                "rehirePeriodCode": {
                    "code": "0",
                    "description": null,
                    "key": "0",
                    "name": "0",
                    "value": null
                }
            }
        ],
        "productRule": {
            "code": "16",
            "description": "MEDICAL AND VISION - OPTIONAL",
            "key": "16",
            "name": "16",
            "value": "MEDICAL AND VISION - OPTIONAL"
        },
        "ratingCounty": {
            "code": "26",
            "description": "HORRY",
            "key": "26",
            "name": "26",
            "rpn": "001",
            "state": null,
            "value": "HORRY"
        },
        "rpn": "001",
        "salesRepresentative": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
                "code": "035",
                "description": null,
                "key": "035",
                "name": "035",
                "value": null
            },
            "name": {
                "firstName": null,
                "lastName": "KATHERYN WONDER-CHS REP",
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            }
        },
        "serviceRepresentative": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
                "code": "098",
                "description": null,
                "key": "098",
                "name": "098",
                "value": null
            },
            "name": {
                "firstName": null,
                "lastName": "STEPHANIE AUSTIN-MJR GRP COLA",
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            },
            "representative": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            }
        },
        "sicCode": {
            "code": "2951",
            "description": "PETROLEUM REFINING",
            "key": "2951",
            "name": "2951",
            "value": "PETROLEUM REFINING"
        },
        "specialHandling": [
            {
                "begin": "2014-11-01T00:00:00-0400",
                "code": "HP",
                "description": "DO NOT CREATE HIPAA PREX LETTE",
                "end": null,
                "level": "CLIENT"
            },
            {
                "begin": "2013-03-01T00:00:00-0500",
                "code": "TP",
                "description": "DO NOT CREATE TPR/COB EXPIRATI",
                "end": null,
                "level": "CLIENT"
            }
        ],
        "statusDescription": null,
        "subClientDescription": "",
        "subClientNumber": "",
        "terminationDate": null
    },
    "dynaGroupCoverage": {
        "ammsGroupNumber": "255487600",
        "coverageBeginDate": "2006-01-01T00:00:00-0500",
        "coverageDescription": "PPO PLAN",
        "coverageEndDate": null,
        "coverageId": {
            "benefitLevel": "001",
            "coverageLevelCode": "C",
            "coverageNumber": "0000732",
            "productCode": "Products.MEDICAL"
        },
        "rateDescription": "PPO PLAN",
        "rateLevelCode": "C",
        "rateNumber": "0000732",
        "rateSuffixNumber": "01"
    },
    "groupName": "PALMETTO CORP OF CONWAY",
    "id": "0012345",
    "listBillPhoneNumber": "null-null",
    "masterARNumber": "00000001195140"
}