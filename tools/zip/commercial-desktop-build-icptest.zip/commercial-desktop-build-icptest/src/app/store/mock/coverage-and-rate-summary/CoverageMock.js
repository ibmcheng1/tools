/* eslint-disable */
export const mockCoverage = {
    "benefitBooklets": null,
    "coverage": {
      "ammsGroupNumber": "002002000",
      "coverageBeginDate": "1990-01-01T00:00:00-0500",
      "coverageDescription": "ECONOMY PLAN A\/001",
      "coverageEndDate": "2005-01-01T00:00:00-0500",
      "coverageId": {
        "benefitLevel": "001",
        "coverageLevelCode": "C",
        "coverageNumber": "0000001",
        "productCode": "Products.MEDICAL"
      },
      "rateDescription": "STATE COMPREHENSIVE ASO",
      "rateLevelCode": "C",
      "rateNumber": "0000001",
      "rateSuffixNumber": "01"
    },
    "group": {
      "address": {
        "address1": "STATE OF SOUTH CAROLINA",
        "address2": "PEBA",
        "address3": "POST OFFICE BOX 11661",
        "address4": "",
        "address5": null,
        "city": "COLUMBIA",
        "country": null,
        "county": null,
        "countyCode": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "rpn": null,
          "state": null,
          "value": null
        },
        "province": null,
        "region": null,
        "state": "SC",
        "stateCode": {
          "code": "SC",
          "description": "",
          "key": "SC",
          "name": "SC",
          "value": ""
        },
        "zipcode": "29211",
        "zipcodePostFix": "1661"
      },
      "agency": null,
      "anniversaryDate": "1982-07-01T00:00:00-0400",
      "benefitSystem": null,
      "billDueDate": null,
      "billingAgencyCode": {
        "code": "",
        "description": "",
        "key": "",
        "name": "",
        "value": ""
      },
      "billingAgentCode": {
        "code": "",
        "description": "",
        "key": "",
        "name": "",
        "value": ""
      },
      "cancelCode": null,
      "cancelReasonCode": null,
      "clientContribution": {
        "code": "N",
        "description": "EMPLOYER PAYS ZERO PERCENT",
        "key": "N",
        "name": "N",
        "value": "EMPLOYER PAYS ZERO PERCENT"
      },
      "clientDescription": "STATE OF SOUTH CAROLINA",
      "clientNumber": "00001",
      "clientServiceCenterCode": {
        "code": "SSS",
        "description": "STATE UNIT",
        "key": "SSS",
        "name": "SSS",
        "value": "STATE UNIT"
      },
      "contactInformation": null,
      "contactName": "BOB DAVIS",
      "contractRule": {
        "code": "N",
        "description": "NO TC'S NEED TO MATCH",
        "key": "N",
        "name": "N",
        "value": "NO TC'S NEED TO MATCH"
      },
      "contractTypes": [
        {
          "contractBaseRate": 1,
          "contractTypeCode": {
            "code": "CI",
            "description": "CHILDREN INDIVIDUAL",
            "key": "CI",
            "name": "CI",
            "value": "CHILDREN INDIVIDUAL"
          }
        },
        {
          "contractBaseRate": 1,
          "contractTypeCode": {
            "code": "CM",
            "description": "CHILDREN MULTIPLE",
            "key": "CM",
            "name": "CM",
            "value": "CHILDREN MULTIPLE"
          }
        },
        {
          "contractBaseRate": 1,
          "contractTypeCode": {
            "code": "F",
            "description": "FAMILY",
            "key": "F",
            "name": "F",
            "value": "FAMILY"
          }
        },
        {
          "contractBaseRate": 1,
          "contractTypeCode": {
            "code": "I",
            "description": "INDIVIDUAL",
            "key": "I",
            "name": "I",
            "value": "INDIVIDUAL"
          }
        },
        {
          "contractBaseRate": 1,
          "contractTypeCode": {
            "code": "IC",
            "description": "INDIVIDUAL AND CHILDREN",
            "key": "IC",
            "name": "IC",
            "value": "INDIVIDUAL AND CHILDREN"
          }
        },
        {
          "contractBaseRate": 1,
          "contractTypeCode": {
            "code": "IS",
            "description": "INDIVIDUAL AND SPOUSE",
            "key": "IS",
            "name": "IS",
            "value": "INDIVIDUAL AND SPOUSE"
          }
        }
      ],
      "coverageEffectiveDate": "1990-01-01T00:00:00-0500",
      "coverages": {
        "Products.DENTAL": [
          {
            "ammsGroupNumber": "00Z002000",
            "coverageBeginDate": "2002-01-01T00:00:00-0500",
            "coverageDescription": "STATE DENTAL PLAN",
            "coverageEndDate": null,
            "coverageId": {
              "benefitLevel": "001",
              "coverageLevelCode": "C",
              "coverageNumber": "0000001",
              "productCode": "Products.DENTAL"
            },
            "rateDescription": "STATE DENTAL PLAN",
            "rateLevelCode": "C",
            "rateNumber": "0000001",
            "rateSuffixNumber": "01"
          },
          {
            "ammsGroupNumber": "00S002000",
            "coverageBeginDate": "2002-01-01T00:00:00-0500",
            "coverageDescription": "STATE DENTAL PLAN W\/DEN PLUS",
            "coverageEndDate": null,
            "coverageId": {
              "benefitLevel": "002",
              "coverageLevelCode": "C",
              "coverageNumber": "0000001",
              "productCode": "Products.DENTAL"
            },
            "rateDescription": "STATE DENTAL PLAN W\/DEN PLUS",
            "rateLevelCode": "C",
            "rateNumber": "0000001",
            "rateSuffixNumber": "01"
          }
        ],
        "Products.VISION": [
          {
            "ammsGroupNumber": "002090000",
            "coverageBeginDate": "2010-01-01T00:00:00-0500",
            "coverageDescription": "STATE VISION",
            "coverageEndDate": null,
            "coverageId": {
              "benefitLevel": "001",
              "coverageLevelCode": "C",
              "coverageNumber": "0000001",
              "productCode": "Products.VISION"
            },
            "rateDescription": "STATE VISION",
            "rateLevelCode": "C",
            "rateNumber": "0000001",
            "rateSuffixNumber": "01"
          }
        ],
        "Products.MEDICAL": [
          {
            "ammsGroupNumber": "002002000",
            "coverageBeginDate": "1990-01-01T00:00:00-0500",
            "coverageDescription": "ECONOMY PLAN A\/001",
            "coverageEndDate": "2005-01-01T00:00:00-0500",
            "coverageId": {
              "benefitLevel": "001",
              "coverageLevelCode": "C",
              "coverageNumber": "0000001",
              "productCode": "Products.MEDICAL"
            },
            "rateDescription": "STATE COMPREHENSIVE ASO",
            "rateLevelCode": "C",
            "rateNumber": "0000001",
            "rateSuffixNumber": "01"
          },
          {
            "ammsGroupNumber": "002032000",
            "coverageBeginDate": "1990-01-01T00:00:00-0500",
            "coverageDescription": "STANDARD PLAN B\/002",
            "coverageEndDate": null,
            "coverageId": {
              "benefitLevel": "002",
              "coverageLevelCode": "C",
              "coverageNumber": "0000001",
              "productCode": "Products.MEDICAL"
            },
            "rateDescription": "STATE COMPREHENSIVE ASO",
            "rateLevelCode": "C",
            "rateNumber": "0000001",
            "rateSuffixNumber": "01"
          },
          {
            "ammsGroupNumber": "002072000",
            "coverageBeginDate": "2005-01-01T00:00:00-0500",
            "coverageDescription": "SAVINGS PLAN OPTION (HDHP)",
            "coverageEndDate": null,
            "coverageId": {
              "benefitLevel": "014",
              "coverageLevelCode": "C",
              "coverageNumber": "0000001",
              "productCode": "Products.MEDICAL"
            },
            "rateDescription": "SAVINGS PLAN OPTION (HDHP)",
            "rateLevelCode": "C",
            "rateNumber": "0000001",
            "rateSuffixNumber": "01"
          },
          {
            "ammsGroupNumber": "002002000",
            "coverageBeginDate": "1990-01-01T00:00:00-0500",
            "coverageDescription": "REFUSAL TO BCBS COVERAGE",
            "coverageEndDate": "2005-01-01T00:00:00-0500",
            "coverageId": {
              "benefitLevel": "001",
              "coverageLevelCode": "R",
              "coverageNumber": "REFUSAL",
              "productCode": "Products.MEDICAL"
            },
            "rateDescription": "REFUSAL OF BCBS COVERAGE",
            "rateLevelCode": "R",
            "rateNumber": "REFUSAL",
            "rateSuffixNumber": "01"
          }
        ]
      },
      "dateBegin": "2004-01-01T00:00:00-0500",
      "dateEnd": null,
      "departments": [
        
      ],
      "drugOptionCode": {
        "code": "N\/A",
        "description": "NOT APPLICABLE",
        "key": "N\/A",
        "name": "N\/A",
        "value": "NOT APPLICABLE"
      },
      "effectiveDate": null,
      "fax": {
        "areaCode": "",
        "extension": null,
        "prefix": "",
        "suffix": "",
        "type": null
      },
      "groupCoverageBeginDate": "2000-01-01T00:00:00-0500",
      "groupCoverageTermDate": "2005-01-01T00:00:00-0500",
      "groupDescription": "STATE PERSONNEL DEPT",
      "groupLeader": null,
      "groupName": "STATE PERSONNEL DEPT",
      "groupNumberAmms": "002002000",
      "groupNumberCes": "0000001",
      "groupType": {
        "code": "GR",
        "description": "LOCAL - GROUP",
        "key": "GR",
        "name": "GR",
        "value": "LOCAL - GROUP"
      },
      "id": null,
      "idCardType": null,
      "idCode": {
        "code": null,
        "description": null,
        "key": null,
        "name": null,
        "value": null
      },
      "lastBillAmount": 0,
      "lastBillDate": null,
      "maintenenceDate": null,
      "masterARNumber": "",
      "masterCoverageRateBegin": "2000-01-01T00:00:00-0500",
      "masterCoverageRateEnd": null,
      "name": {
        "firstName": null,
        "lastName": null,
        "middleName": null,
        "prefixName": null,
        "suffixName": null
      },
      "outputRules": {
        "dateBegin": "2002-01-01T00:00:00-0500",
        "dateEnd": null,
        "drugEligibilityTapeCode": {
          "code": "",
          "description": "NO ELIGIBILITY TAPE CODE",
          "key": "",
          "name": "",
          "value": "NO ELIGIBILITY TAPE CODE"
        },
        "explanationOfBenefitsCode": {
          "code": "0",
          "description": "EOBS ARE SENT TO THE SUBSCRIBER'S ADDRESS 0=BLANK",
          "key": "0",
          "name": "0",
          "value": "EOBS ARE SENT TO THE SUBSCRIBER'S ADDRESS 0=BLANK"
        },
        "idCardAlphaPrefix": "ZCS",
        "idCardFormatCode": {
          "code": "ST1",
          "description": "STATE OF SOUTH CAROLINA",
          "key": "ST1",
          "name": "ST1",
          "value": "STATE OF SOUTH CAROLINA"
        },
        "idCardLiteratureCode": {
          "code": "",
          "description": "CODE NOT ON REFERENCE TABLE",
          "key": "",
          "name": "",
          "value": "CODE NOT ON REFERENCE TABLE"
        },
        "idCardMailCode": {
          "code": "1",
          "description": "ID CARDS ARE TO BE MAILED TO SUBSCRIBERS",
          "key": "1",
          "name": "1",
          "value": "ID CARDS ARE TO BE MAILED TO SUBSCRIBERS"
        },
        "idCardPrintCode": {
          "code": "P",
          "description": "ISSUE GRP ALPHA PREFIX ID CRDS",
          "key": "P",
          "name": "P",
          "value": "ISSUE GRP ALPHA PREFIX ID CRDS"
        },
        "idCardSequenceCode": {
          "code": "1",
          "description": "SORT ID CARDS ALPHABETICALLY",
          "key": "1",
          "name": "1",
          "value": "SORT ID CARDS ALPHABETICALLY"
        },
        "reportRouteCodeClaims": {
          "code": "B1R",
          "description": "STATE GROUP",
          "key": "B1R",
          "name": "B1R",
          "value": "STATE GROUP"
        },
        "reportRouteCodeMembership": {
          "code": "ST1",
          "description": "STATE MEMBERSHIP",
          "key": "ST1",
          "name": "ST1",
          "value": "STATE MEMBERSHIP"
        }
      },
      "paymentSummaryNumber": "",
      "phone": {
        "areaCode": "803",
        "extension": "",
        "prefix": "734",
        "suffix": "0575",
        "type": null
      },
      "probationaryPeriods": [
        
      ],
      "productRule": {
        "code": "11",
        "description": "MEDICAL AND DENTAL - OPTIONAL",
        "key": "11",
        "name": "11",
        "value": "MEDICAL AND DENTAL - OPTIONAL"
      },
      "ratingCounty": {
        "code": "40",
        "description": "RICHLAND",
        "key": "40",
        "name": "40",
        "rpn": "001",
        "state": null,
        "value": "RICHLAND"
      },
      "rpn": "001",
      "salesRepresentative": {
        "address": {
          "address1": null,
          "address2": null,
          "address3": null,
          "address4": null,
          "address5": null,
          "city": null,
          "country": null,
          "county": null,
          "countyCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "rpn": null,
            "state": null,
            "value": null
          },
          "province": null,
          "region": null,
          "state": null,
          "stateCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "zipcode": null,
          "zipcodePostFix": null
        },
        "id": null,
        "idCode": {
          "code": "",
          "description": null,
          "key": "",
          "name": "",
          "value": null
        },
        "name": {
          "firstName": null,
          "lastName": "",
          "middleName": null,
          "prefixName": null,
          "suffixName": null
        },
        "phone": {
          "areaCode": null,
          "extension": null,
          "prefix": null,
          "suffix": null,
          "type": null
        },
        "representative": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        }
      },
      "serviceRepresentative": {
        "address": {
          "address1": null,
          "address2": null,
          "address3": null,
          "address4": null,
          "address5": null,
          "city": null,
          "country": null,
          "county": null,
          "countyCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "rpn": null,
            "state": null,
            "value": null
          },
          "province": null,
          "region": null,
          "state": null,
          "stateCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "zipcode": null,
          "zipcodePostFix": null
        },
        "id": null,
        "idCode": {
          "code": "",
          "description": null,
          "key": "",
          "name": "",
          "value": null
        },
        "name": {
          "firstName": null,
          "lastName": "",
          "middleName": null,
          "prefixName": null,
          "suffixName": null
        },
        "phone": {
          "areaCode": null,
          "extension": null,
          "prefix": null,
          "suffix": null,
          "type": null
        },
        "representative": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        }
      },
      "sicCode": null,
      "specialHandling": [
        {
          "begin": "1990-09-01T00:00:00-0400",
          "code": "OS",
          "description": "STUDENT CERT OF OVERAGE DEPEND",
          "end": null,
          "level": "CLIENT"
        },
        {
          "begin": "1990-09-01T00:00:00-0400",
          "code": "P1",
          "description": "USE FILE DATE FOR PREX CALCULA",
          "end": null,
          "level": "CLIENT"
        },
        {
          "begin": "2010-05-06T00:00:00-0400",
          "code": "P2",
          "description": "USE PREX END DT FOR PREX CALCU",
          "end": null,
          "level": "CLIENT"
        },
        {
          "begin": "1990-09-01T00:00:00-0400",
          "code": "RL",
          "description": "SPOUSE LOAD TO RELATOR TABLE",
          "end": null,
          "level": "CLIENT"
        },
        {
          "begin": "1990-09-01T00:00:00-0400",
          "code": "ST",
          "description": "EMPLOYEE STATUS LOADED FROM B8",
          "end": null,
          "level": "CLIENT"
        },
        {
          "begin": "1990-01-01T00:00:00-0500",
          "code": "TC",
          "description": "TERMINATE CONTRACT ONLY",
          "end": null,
          "level": "CLIENT"
        },
        {
          "begin": "1990-09-01T00:00:00-0400",
          "code": "TM",
          "description": "GENERATE TIMELINESS REPORT",
          "end": null,
          "level": "CLIENT"
        },
        {
          "begin": "2010-12-01T00:00:00-0500",
          "code": "TP",
          "description": "DO NOT CREATE TPR\/COB EXPIRATI",
          "end": null,
          "level": "CLIENT"
        },
        {
          "begin": "2002-12-04T00:00:00-0500",
          "code": "25",
          "description": "CREATE DISABILITY INFO IN BATC",
          "end": null,
          "level": "CLIENT"
        }
      ],
      "statusDescription": null,
      "subClientDescription": "STATE OF SOUTH CAROLINA",
      "subClientNumber": "0001",
      "terminationDate": null
    },
    "groupCoverageDateBegin": "01\/01\/2000",
    "groupCoverageDateEnd": "01\/01\/2005",
    "groupCoverageListTransaction": "H^GENO<GROUP#>@E^GENO",
    "groupCoverageStatus": "TERMINATED",
    "groupCoverageStatusText": "TERMINATED",
    "hasDentalCoverages": true,
    "hasMedicalCoverages": true,
    "hasVisionCoverages": true,
    "masterCoverageRateBegin": "01\/01\/2000",
    "masterCoverageRateEnd": "",
    "needToFetchData": true,
    "noDataFound": false,
    "portletLoaded": false,
    "productCode": "MED",
    "serviceCenterTransaction": "I^SVCC<CENTER#><RPN_CISI#>@E"
  }