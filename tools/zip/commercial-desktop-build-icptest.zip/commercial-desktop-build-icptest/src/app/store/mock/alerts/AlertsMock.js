/* eslint-disable */
export const mockAlerts = {
  "alerts": 
  [{
      "grandfatherIndicator": true
  },
  {
      "memberExceptions": {
          "": [{
              "alertExceptionIndicator": true,
              "contractLevelExceptionIndicator": true,
              "controlCode": {
                  "code": "PE",
                  "description": "Receive Electronic EOBs",
                  "key": "PE",
                  "name": "PE",
                  "value": "Receive Electronic EOBs"
              },
              "controlDate": null,
              "deferral": null,
              "exceptionDescription": null,
              "override": null,
              "patientID": "",
              "patientName": "CONTRACT",
              "priority": null
          }],
          "001": [{
              "alertExceptionIndicator": true,
              "contractLevelExceptionIndicator": false,
              "controlCode": {
                  "code": "CM",
                  "description": "Case Management",
                  "key": "CM",
                  "name": "CM",
                  "value": "Case Management"
              },
              "controlDate": null,
              "deferral": null,
              "exceptionDescription": null,
              "override": null,
              "patientID": "001",
              "patientName": "MICHAEL",
              "priority": null
          },
          {
              "alertExceptionIndicator": true,
              "contractLevelExceptionIndicator": false,
              "controlCode": {
                  "code": "DB",
                  "description": "Diabetes",
                  "key": "DB",
                  "name": "DB",
                  "value": "Diabetes"
              },
              "controlDate": null,
              "deferral": null,
              "exceptionDescription": null,
              "override": null,
              "patientID": "001",
              "patientName": "MICHAEL",
              "priority": null
          }],
          "002": [{
              "alertExceptionIndicator": true,
              "contractLevelExceptionIndicator": false,
              "controlCode": {
                  "code": "CN",
                  "description": "Processing Exception",
                  "key": "CN",
                  "name": "CN",
                  "value": "Processing Exception"
              },
              "controlDate": null,
              "deferral": "D5B84",
              "exceptionDescription": "Read processing exception on member/family",
              "override": null,
              "patientID": "002",
              "patientName": "MARTHA",
              "priority": null
          },
          {
              "alertExceptionIndicator": true,
              "contractLevelExceptionIndicator": false,
              "controlCode": {
                  "code": "CM",
                  "description": "Case Management",
                  "key": "CM",
                  "name": "CM",
                  "value": "Case Management"
              },
              "controlDate": null,
              "deferral": null,
              "exceptionDescription": null,
              "override": null,
              "patientID": "002",
              "patientName": "MARTHA",
              "priority": null
          }],
          "003": [{
              "alertExceptionIndicator": true,
              "contractLevelExceptionIndicator": false,
              "controlCode": {
                  "code": "CN",
                  "description": "Processing Exception",
                  "key": "CN",
                  "name": "CN",
                  "value": "Processing Exception"
              },
              "controlDate": null,
              "deferral": "D5B84",
              "exceptionDescription": "Read processing exception on member/family",
              "override": null,
              "patientID": "003",
              "patientName": "TERRI",
              "priority": null
          }],
          "???": [{
              "alertExceptionIndicator": true,
              "contractLevelExceptionIndicator": false,
              "controlCode": {
                  "code": "CM",
                  "description": "Case Management",
                  "key": "CM",
                  "name": "CM",
                  "value": "Case Management"
              },
              "controlDate": null,
              "deferral": null,
              "exceptionDescription": null,
              "override": null,
              "patientID": "???",
              "patientName": "JOHN",
              "priority": null
          }]
      }
  },
  {
      "memberSpecialNoteRecords": [{
          "contractLevelRecordIndicator": true,
          "notesText": ["TEST III",
                        "TEST II RSET",
                        "RSET TEST"],
                        "patientFirstName": "CONTRACT",
                        "patientId": null
      },
      {
          "contractLevelRecordIndicator": false,
          "notesText": ["THIS IS TO TEST THE NOTESAND I AM CHECKING EVERY BIT OF IT",
                        "JOHN NOTES"],
                        "patientFirstName": "JOHN",
                        "patientId": null
      },
      {
          "contractLevelRecordIndicator": false,
          "notesText": ["TERRI NOTES"],
          "patientFirstName": "TERRI",
          "patientId": null
      },
      {
          "contractLevelRecordIndicator": false,
          "notesText": ["MARTHA NOTES"],
          "patientFirstName": "MARTHA",
          "patientId": null
      }]
  },
  {
      "mobileNotificationAlerts": {
          "002": {
              "alertType": "",
              "ammsGroupNumber": "036011101",
              "applicationMessage": null,
              "businessSectorCode": "PCL",
              "cesMemberNumber": "02",
              "consentDate": null,
              "consentType": "NORECORD",
              "dateOfBirth": "1960-09-01T00:00:00-0400",
              "firstName": "MARTHA",
              "gender": "F",
              "idCardNumber": "ZCZ065922516805",
              "lastName": "TESTING",
              "mobileNumber": "",
              "patientId": "002",
              "product": null,
              "relationShip": {
                  "code": "4",
                  "description": null,
                  "key": "4",
                  "name": "4",
                  "value": null
              },
              "showAlert": true,
              "templateCode": "l.c74.28a.1070"
          }
      }
  }],
    "memberAlerts": 
            [
                [
                    {
                        patientId: null,
                        patientName: "CONTRACT"
                    },
                    null
                ],
                [
                    {
                        patientId: "001",
                        patientName: "MICHAEL"
                    },
                    [
                        {
                            "alertType": "EXCEPTION_ALERT",
                            "claimStatusAlert": false,
                            "claimStatusCategoryDescription": null,
                            "claimSubrogationAlert": false,
                            "controlCode": {
                                "code": "CM",
                                "description": "Case Management",
                                "key": "CM",
                                "name": "CM",
                                "value": "Case Management"
                            },
                            "deferral": null,
                            "exceptionDescription": null,
                            "override": null
                        },
                        {
                            "alertType": "EXCEPTION_ALERT",
                            "claimStatusAlert": false,
                            "claimStatusCategoryDescription": null,
                            "claimSubrogationAlert": false,
                            "controlCode": {
                                "code": "DB",
                                "description": "Diabetes",
                                "key": "DB",
                                "name": "DB",
                                "value": "Diabetes"
                            },
                            "deferral": null,
                            "exceptionDescription": null,
                            "override": null
                        },
                        {
                            "alertType": "EXCEPTION_ALERT",
                            "claimStatusAlert": false,
                            "claimStatusCategoryDescription": null,
                            "claimSubrogationAlert": false,
                            "controlCode": {
                                "code": "CN",
                                "description": "Processing Exception",
                                "key": "CN",
                                "name": "CN",
                                "value": "Processing Exception"
                            },
                            "deferral": "D5B84",
                            "exceptionDescription": "Foobar",
                            "override": null
                        }
                    ]
                ],
                [
                    {
                        patientId: "002",
                        patientName: "MARTHA"
                    },
                    [
                        {
                            "alertType": "EXCEPTION_ALERT",
                            "claimStatusAlert": false,
                            "claimStatusCategoryDescription": null,
                            "claimSubrogationAlert": false,
                            "controlCode": {
                                "code": "CN",
                                "description": "Processing Exception",
                                "key": "CN",
                                "name": "CN",
                                "value": "Processing Exception"
                            },
                            "deferral": "D5B84",
                            "exceptionDescription": "Read processing exception on member/family",
                            "override": null
                        },
                        {
                            "alertType": "EXCEPTION_ALERT",
                            "claimStatusAlert": false,
                            "claimStatusCategoryDescription": null,
                            "claimSubrogationAlert": false,
                            "controlCode": {
                                "code": "CM",
                                "description": "Case Management",
                                "key": "CM",
                                "name": "CM",
                                "value": "Case Management"
                            },
                            "deferral": null,
                            "exceptionDescription": null,
                            "override": null
                        },
                        {
                            "alertType": "MOBILE_NOTIFICATIONS_ALERT",
                            "claimStatusAlert": false,
                            "claimStatusCategoryDescription": null,
                            "claimSubrogationAlert": false,
                            "controlCode": null,
                            "deferral": null,
                            "exceptionDescription": null,
                            "override": null
                        }
                    ]
                ],
                [
                    {
                        patientId: "003",
                        patientName: "TERRI"
                    },
                    [
                        {
                            "alertType": "EXCEPTION_ALERT",
                            "claimStatusAlert": false,
                            "claimStatusCategoryDescription": null,
                            "claimSubrogationAlert": false,
                            "controlCode": {
                                "code": "CM",
                                "description": "Case Management",
                                "key": "CM",
                                "name": "CM",
                                "value": "Case Management"
                            },
                            "deferral": null,
                            "exceptionDescription": null,
                            "override": null
                        }
                    ]
                ]
            ],
  "selectedProductCode": "Products.MEDICAL",
  "subscriber": {
      "PAI": false,
      "activeDate": null,
      "activelyCovered": true,
      "address": {
          "address1": "P O BOX  24015",
          "address2": "",
          "address3": null,
          "address4": null,
          "address5": null,
          "city": "COLUMBIA",
          "country": null,
          "county": "040",
          "countyCode": {
              "code": "040",
              "description": "RICHLAND",
              "key": "040",
              "name": "040",
              "rpn": null,
              "state": null,
              "value": "RICHLAND"
          },
          "province": null,
          "region": null,
          "state": "SC",
          "stateCode": {
              "code": "SC",
              "description": null,
              "key": "SC",
              "name": "SC",
              "value": null
          },
          "zipcode": "29224",
          "zipcodePostFix": "4015"
      },
      "alphaPrefix": "ZCZ",
      "ammsGroupNumber": "036011101",
      "bill": {
          "amountReceivable": null,
          "arHistoryIndicator": null,
          "balanceAmount": null,
          "billFormat": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "billNumber": null,
          "billedDate": null,
          "billingFrequency": null,
          "clientNumber": null,
          "createARIndicator": null,
          "creationDate": null,
          "dueDate": null,
          "dueDay": null,
          "employeeListIndicator": null,
          "lastPaymentAmount": null,
          "lastPaymentDate": null,
          "listBillAccountNumber": "",
          "masterARNumber": null,
          "mode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "outputType": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "paymentMethod": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "paymentSummary": null,
          "providerId": null,
          "reasonCode": null,
          "recordCode": null,
          "renderTime": null,
          "serviceId": null,
          "sort": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "supressBillIndicator": null,
          "viewStatementIndicator": null
      },
      "birthdate": "10/01/1958",
      "businessSector": "PCL",
      "carrierName": "",
      "carrierRestricted": false,
      "ces": true,
      "cesExceptionIndicator": true,
      "cesGroupNumber": "0000667",
      "cisiRpn": null,
      "clientCode": {
          "code": "00006",
          "description": "TEST SPECIAL PROJECTS AREA",
          "key": "00006",
          "name": "00006",
          "value": "TEST SPECIAL PROJECTS AREA"
      },
      "coverage": null,
      "coverageContinuationTypeCode": {
          "code": "",
          "description": null,
          "key": "",
          "name": "",
          "value": null
      },
      "coverageItems": [{
          "active": true,
          "benefitSystem": "OLD",
          "coverageId": {
              "benefitLevel": "001",
              "coverageLevelCode": "C",
              "coverageNumber": "0000006",
              "productCode": "Products.DENTAL"
          },
          "drugProcessingCode": {
              "code": "",
              "description": null,
              "key": "",
              "name": "",
              "value": null
          },
          "effectiveDate": "2003-01-01T00:00:00-0500",
          "group": {
              "address": {
                  "address1": null,
                  "address2": null,
                  "address3": null,
                  "address4": null,
                  "address5": null,
                  "city": null,
                  "country": null,
                  "county": null,
                  "countyCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "rpn": null,
                      "state": null,
                      "value": null
                  },
                  "province": null,
                  "region": null,
                  "state": null,
                  "stateCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  },
                  "zipcode": null,
                  "zipcodePostFix": null
              },
              "agency": null,
              "anniversaryDate": null,
              "benefitSystem": null,
              "billDueDate": null,
              "billingAgencyCode": null,
              "billingAgentCode": null,
              "cancelCode": null,
              "cancelReasonCode": null,
              "clientContribution": null,
              "clientDescription": null,
              "clientNumber": null,
              "clientServiceCenterCode": null,
              "contactInformation": null,
              "contactName": null,
              "contractRule": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "contractTypes": null,
              "coverageEffectiveDate": null,
              "coverages": null,
              "dateBegin": null,
              "dateEnd": null,
              "departments": null,
              "drugOptionCode": null,
              "effectiveDate": null,
              "fax": {
                  "areaCode": null,
                  "extension": null,
                  "prefix": null,
                  "suffix": null,
                  "type": null
              },
              "groupCoverageBeginDate": null,
              "groupCoverageTermDate": null,
              "groupDescription": null,
              "groupLeader": null,
              "groupName": null,
              "groupNumberAmms": null,
              "groupNumberCes": null,
              "groupType": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "id": "0000667",
              "idCardType": null,
              "idCode": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "lastBillAmount": null,
              "lastBillDate": null,
              "maintenenceDate": null,
              "masterARNumber": null,
              "masterCoverageRateBegin": null,
              "masterCoverageRateEnd": null,
              "name": {
                  "firstName": null,
                  "lastName": null,
                  "middleName": null,
                  "prefixName": null,
                  "suffixName": null
              },
              "outputRules": null,
              "paymentSummaryNumber": null,
              "phone": {
                  "areaCode": null,
                  "extension": null,
                  "prefix": null,
                  "suffix": null,
                  "type": null
              },
              "probationaryPeriods": null,
              "productRule": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "ratingCounty": null,
              "rpn": null,
              "salesRepresentative": {
                  "address": {
                      "address1": null,
                      "address2": null,
                      "address3": null,
                      "address4": null,
                      "address5": null,
                      "city": null,
                      "country": null,
                      "county": null,
                      "countyCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "rpn": null,
                          "state": null,
                          "value": null
                      },
                      "province": null,
                      "region": null,
                      "state": null,
                      "stateCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "value": null
                      },
                      "zipcode": null,
                      "zipcodePostFix": null
                  },
                  "id": null,
                  "idCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  },
                  "name": {
                      "firstName": null,
                      "lastName": null,
                      "middleName": null,
                      "prefixName": null,
                      "suffixName": null
                  },
                  "phone": {
                      "areaCode": null,
                      "extension": null,
                      "prefix": null,
                      "suffix": null,
                      "type": null
                  },
                  "representative": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  }
              },
              "serviceRepresentative": {
                  "address": {
                      "address1": null,
                      "address2": null,
                      "address3": null,
                      "address4": null,
                      "address5": null,
                      "city": null,
                      "country": null,
                      "county": null,
                      "countyCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "rpn": null,
                          "state": null,
                          "value": null
                      },
                      "province": null,
                      "region": null,
                      "state": null,
                      "stateCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "value": null
                      },
                      "zipcode": null,
                      "zipcodePostFix": null
                  },
                  "id": null,
                  "idCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  },
                  "name": {
                      "firstName": null,
                      "lastName": null,
                      "middleName": null,
                      "prefixName": null,
                      "suffixName": null
                  },
                  "phone": {
                      "areaCode": null,
                      "extension": null,
                      "prefix": null,
                      "suffix": null,
                      "type": null
                  },
                  "representative": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  }
              },
              "sicCode": null,
              "specialHandling": null,
              "statusDescription": null,
              "subClientDescription": null,
              "subClientNumber": null,
              "terminationDate": null
          },
          "listBillIndicator": "",
          "majorMedicalWaiverCode": {
              "code": "",
              "description": null,
              "key": "",
              "name": "",
              "value": null
          },
          "memberId": null,
          "oldGroup": {
              "address": {
                  "address1": null,
                  "address2": null,
                  "address3": null,
                  "address4": null,
                  "address5": null,
                  "city": null,
                  "country": null,
                  "county": null,
                  "countyCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "rpn": null,
                      "state": null,
                      "value": null
                  },
                  "province": null,
                  "region": null,
                  "state": null,
                  "stateCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  },
                  "zipcode": null,
                  "zipcodePostFix": null
              },
              "agency": null,
              "anniversaryDate": null,
              "benefitSystem": null,
              "billDueDate": null,
              "billingAgencyCode": null,
              "billingAgentCode": null,
              "cancelCode": null,
              "cancelReasonCode": null,
              "clientContribution": null,
              "clientDescription": null,
              "clientNumber": null,
              "clientServiceCenterCode": null,
              "contactInformation": null,
              "contactName": null,
              "contractRule": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "contractTypes": null,
              "coverageEffectiveDate": null,
              "coverages": null,
              "dateBegin": null,
              "dateEnd": null,
              "departments": null,
              "drugOptionCode": null,
              "effectiveDate": null,
              "fax": {
                  "areaCode": null,
                  "extension": null,
                  "prefix": null,
                  "suffix": null,
                  "type": null
              },
              "groupCoverageBeginDate": null,
              "groupCoverageTermDate": null,
              "groupDescription": null,
              "groupLeader": null,
              "groupName": null,
              "groupNumberAmms": null,
              "groupNumberCes": null,
              "groupType": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "id": "036011101",
              "idCardType": null,
              "idCode": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "lastBillAmount": null,
              "lastBillDate": null,
              "maintenenceDate": null,
              "masterARNumber": null,
              "masterCoverageRateBegin": null,
              "masterCoverageRateEnd": null,
              "name": {
                  "firstName": null,
                  "lastName": null,
                  "middleName": null,
                  "prefixName": null,
                  "suffixName": null
              },
              "outputRules": null,
              "paymentSummaryNumber": null,
              "phone": {
                  "areaCode": null,
                  "extension": null,
                  "prefix": null,
                  "suffix": null,
                  "type": null
              },
              "probationaryPeriods": null,
              "productRule": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "ratingCounty": null,
              "rpn": null,
              "salesRepresentative": {
                  "address": {
                      "address1": null,
                      "address2": null,
                      "address3": null,
                      "address4": null,
                      "address5": null,
                      "city": null,
                      "country": null,
                      "county": null,
                      "countyCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "rpn": null,
                          "state": null,
                          "value": null
                      },
                      "province": null,
                      "region": null,
                      "state": null,
                      "stateCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "value": null
                      },
                      "zipcode": null,
                      "zipcodePostFix": null
                  },
                  "id": null,
                  "idCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  },
                  "name": {
                      "firstName": null,
                      "lastName": null,
                      "middleName": null,
                      "prefixName": null,
                      "suffixName": null
                  },
                  "phone": {
                      "areaCode": null,
                      "extension": null,
                      "prefix": null,
                      "suffix": null,
                      "type": null
                  },
                  "representative": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  }
              },
              "serviceRepresentative": {
                  "address": {
                      "address1": null,
                      "address2": null,
                      "address3": null,
                      "address4": null,
                      "address5": null,
                      "city": null,
                      "country": null,
                      "county": null,
                      "countyCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "rpn": null,
                          "state": null,
                          "value": null
                      },
                      "province": null,
                      "region": null,
                      "state": null,
                      "stateCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "value": null
                      },
                      "zipcode": null,
                      "zipcodePostFix": null
                  },
                  "id": null,
                  "idCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  },
                  "name": {
                      "firstName": null,
                      "lastName": null,
                      "middleName": null,
                      "prefixName": null,
                      "suffixName": null
                  },
                  "phone": {
                      "areaCode": null,
                      "extension": null,
                      "prefix": null,
                      "suffix": null,
                      "type": null
                  },
                  "representative": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  }
              },
              "sicCode": null,
              "specialHandling": null,
              "statusDescription": null,
              "subClientDescription": null,
              "subClientNumber": null,
              "terminationDate": null
          },
          "periods": null,
          "serviceCenter": "A01",
          "type": null
      },
      {
          "active": true,
          "benefitSystem": null,
          "coverageId": {
              "benefitLevel": "001",
              "coverageLevelCode": "C",
              "coverageNumber": "0000006",
              "productCode": "Products.MEDICAL"
          },
          "drugProcessingCode": {
              "code": "",
              "description": null,
              "key": "",
              "name": "",
              "value": null
          },
          "effectiveDate": "2002-06-01T00:00:00-0400",
          "group": {
              "address": {
                  "address1": null,
                  "address2": null,
                  "address3": null,
                  "address4": null,
                  "address5": null,
                  "city": null,
                  "country": null,
                  "county": null,
                  "countyCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "rpn": null,
                      "state": null,
                      "value": null
                  },
                  "province": null,
                  "region": null,
                  "state": null,
                  "stateCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  },
                  "zipcode": null,
                  "zipcodePostFix": null
              },
              "agency": null,
              "anniversaryDate": null,
              "benefitSystem": null,
              "billDueDate": null,
              "billingAgencyCode": null,
              "billingAgentCode": null,
              "cancelCode": null,
              "cancelReasonCode": null,
              "clientContribution": null,
              "clientDescription": null,
              "clientNumber": null,
              "clientServiceCenterCode": null,
              "contactInformation": null,
              "contactName": null,
              "contractRule": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "contractTypes": null,
              "coverageEffectiveDate": null,
              "coverages": null,
              "dateBegin": null,
              "dateEnd": null,
              "departments": null,
              "drugOptionCode": null,
              "effectiveDate": null,
              "fax": {
                  "areaCode": null,
                  "extension": null,
                  "prefix": null,
                  "suffix": null,
                  "type": null
              },
              "groupCoverageBeginDate": null,
              "groupCoverageTermDate": null,
              "groupDescription": null,
              "groupLeader": null,
              "groupName": null,
              "groupNumberAmms": null,
              "groupNumberCes": null,
              "groupType": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "id": "0000667",
              "idCardType": null,
              "idCode": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "lastBillAmount": null,
              "lastBillDate": null,
              "maintenenceDate": null,
              "masterARNumber": null,
              "masterCoverageRateBegin": null,
              "masterCoverageRateEnd": null,
              "name": {
                  "firstName": null,
                  "lastName": null,
                  "middleName": null,
                  "prefixName": null,
                  "suffixName": null
              },
              "outputRules": null,
              "paymentSummaryNumber": null,
              "phone": {
                  "areaCode": null,
                  "extension": null,
                  "prefix": null,
                  "suffix": null,
                  "type": null
              },
              "probationaryPeriods": null,
              "productRule": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "ratingCounty": null,
              "rpn": null,
              "salesRepresentative": {
                  "address": {
                      "address1": null,
                      "address2": null,
                      "address3": null,
                      "address4": null,
                      "address5": null,
                      "city": null,
                      "country": null,
                      "county": null,
                      "countyCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "rpn": null,
                          "state": null,
                          "value": null
                      },
                      "province": null,
                      "region": null,
                      "state": null,
                      "stateCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "value": null
                      },
                      "zipcode": null,
                      "zipcodePostFix": null
                  },
                  "id": null,
                  "idCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  },
                  "name": {
                      "firstName": null,
                      "lastName": null,
                      "middleName": null,
                      "prefixName": null,
                      "suffixName": null
                  },
                  "phone": {
                      "areaCode": null,
                      "extension": null,
                      "prefix": null,
                      "suffix": null,
                      "type": null
                  },
                  "representative": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  }
              },
              "serviceRepresentative": {
                  "address": {
                      "address1": null,
                      "address2": null,
                      "address3": null,
                      "address4": null,
                      "address5": null,
                      "city": null,
                      "country": null,
                      "county": null,
                      "countyCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "rpn": null,
                          "state": null,
                          "value": null
                      },
                      "province": null,
                      "region": null,
                      "state": null,
                      "stateCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "value": null
                      },
                      "zipcode": null,
                      "zipcodePostFix": null
                  },
                  "id": null,
                  "idCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  },
                  "name": {
                      "firstName": null,
                      "lastName": null,
                      "middleName": null,
                      "prefixName": null,
                      "suffixName": null
                  },
                  "phone": {
                      "areaCode": null,
                      "extension": null,
                      "prefix": null,
                      "suffix": null,
                      "type": null
                  },
                  "representative": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  }
              },
              "sicCode": null,
              "specialHandling": null,
              "statusDescription": null,
              "subClientDescription": null,
              "subClientNumber": null,
              "terminationDate": null
          },
          "listBillIndicator": "",
          "majorMedicalWaiverCode": {
              "code": "",
              "description": null,
              "key": "",
              "name": "",
              "value": null
          },
          "memberId": null,
          "oldGroup": {
              "address": {
                  "address1": null,
                  "address2": null,
                  "address3": null,
                  "address4": null,
                  "address5": null,
                  "city": null,
                  "country": null,
                  "county": null,
                  "countyCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "rpn": null,
                      "state": null,
                      "value": null
                  },
                  "province": null,
                  "region": null,
                  "state": null,
                  "stateCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  },
                  "zipcode": null,
                  "zipcodePostFix": null
              },
              "agency": null,
              "anniversaryDate": null,
              "benefitSystem": null,
              "billDueDate": null,
              "billingAgencyCode": null,
              "billingAgentCode": null,
              "cancelCode": null,
              "cancelReasonCode": null,
              "clientContribution": null,
              "clientDescription": null,
              "clientNumber": null,
              "clientServiceCenterCode": null,
              "contactInformation": null,
              "contactName": null,
              "contractRule": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "contractTypes": null,
              "coverageEffectiveDate": null,
              "coverages": null,
              "dateBegin": null,
              "dateEnd": null,
              "departments": null,
              "drugOptionCode": null,
              "effectiveDate": null,
              "fax": {
                  "areaCode": null,
                  "extension": null,
                  "prefix": null,
                  "suffix": null,
                  "type": null
              },
              "groupCoverageBeginDate": null,
              "groupCoverageTermDate": null,
              "groupDescription": null,
              "groupLeader": null,
              "groupName": null,
              "groupNumberAmms": null,
              "groupNumberCes": null,
              "groupType": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "id": "036011101",
              "idCardType": null,
              "idCode": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "lastBillAmount": null,
              "lastBillDate": null,
              "maintenenceDate": null,
              "masterARNumber": null,
              "masterCoverageRateBegin": null,
              "masterCoverageRateEnd": null,
              "name": {
                  "firstName": null,
                  "lastName": null,
                  "middleName": null,
                  "prefixName": null,
                  "suffixName": null
              },
              "outputRules": null,
              "paymentSummaryNumber": null,
              "phone": {
                  "areaCode": null,
                  "extension": null,
                  "prefix": null,
                  "suffix": null,
                  "type": null
              },
              "probationaryPeriods": null,
              "productRule": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "ratingCounty": null,
              "rpn": null,
              "salesRepresentative": {
                  "address": {
                      "address1": null,
                      "address2": null,
                      "address3": null,
                      "address4": null,
                      "address5": null,
                      "city": null,
                      "country": null,
                      "county": null,
                      "countyCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "rpn": null,
                          "state": null,
                          "value": null
                      },
                      "province": null,
                      "region": null,
                      "state": null,
                      "stateCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "value": null
                      },
                      "zipcode": null,
                      "zipcodePostFix": null
                  },
                  "id": null,
                  "idCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  },
                  "name": {
                      "firstName": null,
                      "lastName": null,
                      "middleName": null,
                      "prefixName": null,
                      "suffixName": null
                  },
                  "phone": {
                      "areaCode": null,
                      "extension": null,
                      "prefix": null,
                      "suffix": null,
                      "type": null
                  },
                  "representative": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  }
              },
              "serviceRepresentative": {
                  "address": {
                      "address1": null,
                      "address2": null,
                      "address3": null,
                      "address4": null,
                      "address5": null,
                      "city": null,
                      "country": null,
                      "county": null,
                      "countyCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "rpn": null,
                          "state": null,
                          "value": null
                      },
                      "province": null,
                      "region": null,
                      "state": null,
                      "stateCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "value": null
                      },
                      "zipcode": null,
                      "zipcodePostFix": null
                  },
                  "id": null,
                  "idCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  },
                  "name": {
                      "firstName": null,
                      "lastName": null,
                      "middleName": null,
                      "prefixName": null,
                      "suffixName": null
                  },
                  "phone": {
                      "areaCode": null,
                      "extension": null,
                      "prefix": null,
                      "suffix": null,
                      "type": null
                  },
                  "representative": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  }
              },
              "sicCode": null,
              "specialHandling": null,
              "statusDescription": null,
              "subClientDescription": null,
              "subClientNumber": null,
              "terminationDate": null
          },
          "periods": null,
          "serviceCenter": "B01",
          "type": null
      }],
      "databaseNumber": "999574317",
      "dateOfBirth": "1958-10-01T00:00:00-0400",
      "drugIndicator": "Z",
      "employeeStatus": null,
      "engagementMemberRecords": {
          "001": {
              "alertType": "",
              "ammsGroupNumber": "036011101",
              "applicationMessage": null,
              "businessSectorCode": "PCL",
              "cesMemberNumber": "01",
              "consentDate": "2018-05-03T13:39:48-0400",
              "consentType": "WRITTEN",
              "dateOfBirth": "1958-10-01T00:00:00-0400",
              "firstName": "MICHAEL",
              "gender": "M",
              "idCardNumber": "ZCZ065922516805",
              "lastName": "TESTING",
              "mobileNumber": "12438900900",
              "patientId": "001",
              "product": null,
              "relationShip": {
                  "code": "1",
                  "description": null,
                  "key": "1",
                  "name": "1",
                  "value": null
              },
              "showAlert": false,
              "templateCode": ""
          },
          "002": {
              "alertType": "",
              "ammsGroupNumber": "036011101",
              "applicationMessage": null,
              "businessSectorCode": "PCL",
              "cesMemberNumber": "02",
              "consentDate": null,
              "consentType": "NORECORD",
              "dateOfBirth": "1960-09-01T00:00:00-0400",
              "firstName": "MARTHA",
              "gender": "F",
              "idCardNumber": "ZCZ065922516805",
              "lastName": "TESTING",
              "mobileNumber": "",
              "patientId": "002",
              "product": null,
              "relationShip": {
                  "code": "4",
                  "description": null,
                  "key": "4",
                  "name": "4",
                  "value": null
              },
              "showAlert": true,
              "templateCode": "l.c74.28a.1070"
          },
          "003": {
              "alertType": "UNDERAGE",
              "ammsGroupNumber": "036011101",
              "applicationMessage": null,
              "businessSectorCode": "PCL",
              "cesMemberNumber": "03",
              "consentDate": null,
              "consentType": "NORECORD",
              "dateOfBirth": "2002-10-01T00:00:00-0400",
              "firstName": "TERRI",
              "gender": "F",
              "idCardNumber": "ZCZ065922516805",
              "lastName": "TESTING",
              "mobileNumber": "",
              "patientId": "003",
              "product": null,
              "relationShip": {
                  "code": "6",
                  "description": null,
                  "key": "6",
                  "name": "6",
                  "value": null
              },
              "showAlert": false,
              "templateCode": "l.c74.28a.1070"
          }
      },
      "eobRecipient": "",
      "exceptionIndicator": false,
      "extraPhoneNumbers": [],
      "fep": false,
      "formatNumber": null,
      "groupNumberCheckDigit": "",
      "groupPrefix": "GROUP - MAJOR",
      "hireDate": null,
      "id": "999574317",
      "idCardNumber": "065922516805",
      "idCode": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
      },
      "isMobileNotificationsEnabledForGroup": true,
      "lastIdCardDate": null,
      "lastIdCardIssueDate": "2018-06-07T00:00:00-0400",
      "latestCoverage": {
          "active": true,
          "benefitSystem": "OLD",
          "coverageId": {
              "benefitLevel": "001",
              "coverageLevelCode": "C",
              "coverageNumber": "0000006",
              "productCode": "Products.DENTAL"
          },
          "drugProcessingCode": {
              "code": "",
              "description": null,
              "key": "",
              "name": "",
              "value": null
          },
          "effectiveDate": "2003-01-01T00:00:00-0500",
          "group": {
              "address": {
                  "address1": null,
                  "address2": null,
                  "address3": null,
                  "address4": null,
                  "address5": null,
                  "city": null,
                  "country": null,
                  "county": null,
                  "countyCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "rpn": null,
                      "state": null,
                      "value": null
                  },
                  "province": null,
                  "region": null,
                  "state": null,
                  "stateCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  },
                  "zipcode": null,
                  "zipcodePostFix": null
              },
              "agency": null,
              "anniversaryDate": null,
              "benefitSystem": null,
              "billDueDate": null,
              "billingAgencyCode": null,
              "billingAgentCode": null,
              "cancelCode": null,
              "cancelReasonCode": null,
              "clientContribution": null,
              "clientDescription": null,
              "clientNumber": null,
              "clientServiceCenterCode": null,
              "contactInformation": null,
              "contactName": null,
              "contractRule": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "contractTypes": null,
              "coverageEffectiveDate": null,
              "coverages": null,
              "dateBegin": null,
              "dateEnd": null,
              "departments": null,
              "drugOptionCode": null,
              "effectiveDate": null,
              "fax": {
                  "areaCode": null,
                  "extension": null,
                  "prefix": null,
                  "suffix": null,
                  "type": null
              },
              "groupCoverageBeginDate": null,
              "groupCoverageTermDate": null,
              "groupDescription": null,
              "groupLeader": null,
              "groupName": null,
              "groupNumberAmms": null,
              "groupNumberCes": null,
              "groupType": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "id": "0000667",
              "idCardType": null,
              "idCode": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "lastBillAmount": null,
              "lastBillDate": null,
              "maintenenceDate": null,
              "masterARNumber": null,
              "masterCoverageRateBegin": null,
              "masterCoverageRateEnd": null,
              "name": {
                  "firstName": null,
                  "lastName": null,
                  "middleName": null,
                  "prefixName": null,
                  "suffixName": null
              },
              "outputRules": null,
              "paymentSummaryNumber": null,
              "phone": {
                  "areaCode": null,
                  "extension": null,
                  "prefix": null,
                  "suffix": null,
                  "type": null
              },
              "probationaryPeriods": null,
              "productRule": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "ratingCounty": null,
              "rpn": null,
              "salesRepresentative": {
                  "address": {
                      "address1": null,
                      "address2": null,
                      "address3": null,
                      "address4": null,
                      "address5": null,
                      "city": null,
                      "country": null,
                      "county": null,
                      "countyCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "rpn": null,
                          "state": null,
                          "value": null
                      },
                      "province": null,
                      "region": null,
                      "state": null,
                      "stateCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "value": null
                      },
                      "zipcode": null,
                      "zipcodePostFix": null
                  },
                  "id": null,
                  "idCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  },
                  "name": {
                      "firstName": null,
                      "lastName": null,
                      "middleName": null,
                      "prefixName": null,
                      "suffixName": null
                  },
                  "phone": {
                      "areaCode": null,
                      "extension": null,
                      "prefix": null,
                      "suffix": null,
                      "type": null
                  },
                  "representative": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  }
              },
              "serviceRepresentative": {
                  "address": {
                      "address1": null,
                      "address2": null,
                      "address3": null,
                      "address4": null,
                      "address5": null,
                      "city": null,
                      "country": null,
                      "county": null,
                      "countyCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "rpn": null,
                          "state": null,
                          "value": null
                      },
                      "province": null,
                      "region": null,
                      "state": null,
                      "stateCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "value": null
                      },
                      "zipcode": null,
                      "zipcodePostFix": null
                  },
                  "id": null,
                  "idCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  },
                  "name": {
                      "firstName": null,
                      "lastName": null,
                      "middleName": null,
                      "prefixName": null,
                      "suffixName": null
                  },
                  "phone": {
                      "areaCode": null,
                      "extension": null,
                      "prefix": null,
                      "suffix": null,
                      "type": null
                  },
                  "representative": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  }
              },
              "sicCode": null,
              "specialHandling": null,
              "statusDescription": null,
              "subClientDescription": null,
              "subClientNumber": null,
              "terminationDate": null
          },
          "listBillIndicator": "",
          "majorMedicalWaiverCode": {
              "code": "",
              "description": null,
              "key": "",
              "name": "",
              "value": null
          },
          "memberId": null,
          "oldGroup": {
              "address": {
                  "address1": null,
                  "address2": null,
                  "address3": null,
                  "address4": null,
                  "address5": null,
                  "city": null,
                  "country": null,
                  "county": null,
                  "countyCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "rpn": null,
                      "state": null,
                      "value": null
                  },
                  "province": null,
                  "region": null,
                  "state": null,
                  "stateCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  },
                  "zipcode": null,
                  "zipcodePostFix": null
              },
              "agency": null,
              "anniversaryDate": null,
              "benefitSystem": null,
              "billDueDate": null,
              "billingAgencyCode": null,
              "billingAgentCode": null,
              "cancelCode": null,
              "cancelReasonCode": null,
              "clientContribution": null,
              "clientDescription": null,
              "clientNumber": null,
              "clientServiceCenterCode": null,
              "contactInformation": null,
              "contactName": null,
              "contractRule": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "contractTypes": null,
              "coverageEffectiveDate": null,
              "coverages": null,
              "dateBegin": null,
              "dateEnd": null,
              "departments": null,
              "drugOptionCode": null,
              "effectiveDate": null,
              "fax": {
                  "areaCode": null,
                  "extension": null,
                  "prefix": null,
                  "suffix": null,
                  "type": null
              },
              "groupCoverageBeginDate": null,
              "groupCoverageTermDate": null,
              "groupDescription": null,
              "groupLeader": null,
              "groupName": null,
              "groupNumberAmms": null,
              "groupNumberCes": null,
              "groupType": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "id": "036011101",
              "idCardType": null,
              "idCode": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "lastBillAmount": null,
              "lastBillDate": null,
              "maintenenceDate": null,
              "masterARNumber": null,
              "masterCoverageRateBegin": null,
              "masterCoverageRateEnd": null,
              "name": {
                  "firstName": null,
                  "lastName": null,
                  "middleName": null,
                  "prefixName": null,
                  "suffixName": null
              },
              "outputRules": null,
              "paymentSummaryNumber": null,
              "phone": {
                  "areaCode": null,
                  "extension": null,
                  "prefix": null,
                  "suffix": null,
                  "type": null
              },
              "probationaryPeriods": null,
              "productRule": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "ratingCounty": null,
              "rpn": null,
              "salesRepresentative": {
                  "address": {
                      "address1": null,
                      "address2": null,
                      "address3": null,
                      "address4": null,
                      "address5": null,
                      "city": null,
                      "country": null,
                      "county": null,
                      "countyCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "rpn": null,
                          "state": null,
                          "value": null
                      },
                      "province": null,
                      "region": null,
                      "state": null,
                      "stateCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "value": null
                      },
                      "zipcode": null,
                      "zipcodePostFix": null
                  },
                  "id": null,
                  "idCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  },
                  "name": {
                      "firstName": null,
                      "lastName": null,
                      "middleName": null,
                      "prefixName": null,
                      "suffixName": null
                  },
                  "phone": {
                      "areaCode": null,
                      "extension": null,
                      "prefix": null,
                      "suffix": null,
                      "type": null
                  },
                  "representative": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  }
              },
              "serviceRepresentative": {
                  "address": {
                      "address1": null,
                      "address2": null,
                      "address3": null,
                      "address4": null,
                      "address5": null,
                      "city": null,
                      "country": null,
                      "county": null,
                      "countyCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "rpn": null,
                          "state": null,
                          "value": null
                      },
                      "province": null,
                      "region": null,
                      "state": null,
                      "stateCode": {
                          "code": null,
                          "description": null,
                          "key": null,
                          "name": null,
                          "value": null
                      },
                      "zipcode": null,
                      "zipcodePostFix": null
                  },
                  "id": null,
                  "idCode": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  },
                  "name": {
                      "firstName": null,
                      "lastName": null,
                      "middleName": null,
                      "prefixName": null,
                      "suffixName": null
                  },
                  "phone": {
                      "areaCode": null,
                      "extension": null,
                      "prefix": null,
                      "suffix": null,
                      "type": null
                  },
                  "representative": {
                      "code": null,
                      "description": null,
                      "key": null,
                      "name": null,
                      "value": null
                  }
              },
              "sicCode": null,
              "specialHandling": null,
              "statusDescription": null,
              "subClientDescription": null,
              "subClientNumber": null,
              "terminationDate": null
          },
          "periods": null,
          "serviceCenter": "A01",
          "type": null
      },
      "maintenanceDate": null,
      "memberId": "001",
      "members": [{
          "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "rpn": null,
                  "state": null,
                  "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
          },
          "age": null,
          "alternateNames": [],
          "birthdate": "09/01/1960",
          "cancelCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "cardNumber": null,
          "carrierName": null,
          "carrierRestricted": false,
          "cesMemberNumber": "02",
          "confidentialClaimIndicator": false,
          "dateOfBirth": "1960-09-01T00:00:00-0400",
          "deferrals": [],
          "dependentIndicator": "C",
          "dependentVerified": "VERIFIED NON-STATE",
          "employmentStatus": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "id": null,
          "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "maritalStatus": {
              "code": null,
              "description": null,
              "key": null,
              "maritalStatusDate": null,
              "name": null,
              "value": null
          },
          "medicareNumber": null,
          "memberId": "002",
          "memberStatus": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "memberSubscriber": false,
          "name": {
              "firstName": "MARTHA",
              "lastName": "TESTING",
              "middleName": "",
              "prefixName": null,
              "suffixName": ""
          },
          "originalEnrollmentDate": null,
          "overAgeDependent": {
              "certifiedDate": null,
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "overrides": [],
          "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
          },
          "planCode": null,
          "preferredLanguage": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "previousMemberId": null,
          "primaryCarePhysicianFound": false,
          "primaryCarePhysicianId": null,
          "primaryCarePhysicianName": null,
          "privacyIndicator": "Y",
          "recordBeginDate": null,
          "recordTermDate": null,
          "relationship": {
              "code": "4",
              "description": null,
              "key": "4",
              "name": "4",
              "value": null
          },
          "relationshipCode": "4",
          "relationshipName": "SPOUSE",
          "setupDate": null,
          "sex": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "sexCode": null,
          "sexName": "FEMALE",
          "socialSecurityNumber": null,
          "subscriberId": null,
          "suppressIdCards": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "tobaccoUsage": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "understandsEnglish": false,
          "updateByEmployee": "CI300",
          "updateDate": null,
          "verifiedPatientIndicator": "Y",
          "visionPlanPatientId": null
      },
      {
          "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "rpn": null,
                  "state": null,
                  "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
          },
          "age": null,
          "alternateNames": [],
          "birthdate": "10/01/1958",
          "cancelCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "cardNumber": null,
          "carrierName": null,
          "carrierRestricted": false,
          "cesMemberNumber": "01",
          "confidentialClaimIndicator": false,
          "dateOfBirth": "1958-10-01T00:00:00-0400",
          "deferrals": [],
          "dependentIndicator": "C",
          "dependentVerified": "VERIFIED NON-STATE",
          "employmentStatus": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "id": null,
          "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "maritalStatus": {
              "code": null,
              "description": null,
              "key": null,
              "maritalStatusDate": null,
              "name": null,
              "value": null
          },
          "medicareNumber": null,
          "memberId": "001",
          "memberStatus": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "memberSubscriber": true,
          "name": {
              "firstName": "MICHAEL",
              "lastName": "TESTING",
              "middleName": "",
              "prefixName": null,
              "suffixName": ""
          },
          "originalEnrollmentDate": null,
          "overAgeDependent": {
              "certifiedDate": null,
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "overrides": [],
          "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
          },
          "planCode": null,
          "preferredLanguage": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "previousMemberId": null,
          "primaryCarePhysicianFound": false,
          "primaryCarePhysicianId": null,
          "primaryCarePhysicianName": null,
          "privacyIndicator": "",
          "recordBeginDate": null,
          "recordTermDate": null,
          "relationship": {
              "code": "1",
              "description": null,
              "key": "1",
              "name": "1",
              "value": null
          },
          "relationshipCode": "1",
          "relationshipName": "SUBSCRIBER",
          "setupDate": null,
          "sex": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "sexCode": null,
          "sexName": "MALE",
          "socialSecurityNumber": null,
          "subscriberId": null,
          "suppressIdCards": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "tobaccoUsage": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "understandsEnglish": false,
          "updateByEmployee": "CI300",
          "updateDate": null,
          "verifiedPatientIndicator": "Y",
          "visionPlanPatientId": null
      },
      {
          "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "rpn": null,
                  "state": null,
                  "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
          },
          "age": null,
          "alternateNames": [],
          "birthdate": "10/01/2002",
          "cancelCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "cardNumber": null,
          "carrierName": null,
          "carrierRestricted": false,
          "cesMemberNumber": "03",
          "confidentialClaimIndicator": false,
          "dateOfBirth": "2002-10-01T00:00:00-0400",
          "deferrals": [],
          "dependentIndicator": "C",
          "dependentVerified": "VERIFIED NON-STATE",
          "employmentStatus": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "id": null,
          "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "maritalStatus": {
              "code": null,
              "description": null,
              "key": null,
              "maritalStatusDate": null,
              "name": null,
              "value": null
          },
          "medicareNumber": null,
          "memberId": "003",
          "memberStatus": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "memberSubscriber": false,
          "name": {
              "firstName": "TERRI",
              "lastName": "TESTING",
              "middleName": "R",
              "prefixName": null,
              "suffixName": ""
          },
          "originalEnrollmentDate": null,
          "overAgeDependent": {
              "certifiedDate": null,
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "overrides": [],
          "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
          },
          "planCode": null,
          "preferredLanguage": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "previousMemberId": null,
          "primaryCarePhysicianFound": false,
          "primaryCarePhysicianId": null,
          "primaryCarePhysicianName": null,
          "privacyIndicator": "",
          "recordBeginDate": null,
          "recordTermDate": null,
          "relationship": {
              "code": "6",
              "description": null,
              "key": "6",
              "name": "6",
              "value": null
          },
          "relationshipCode": "6",
          "relationshipName": "DEPENDENT",
          "setupDate": null,
          "sex": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "sexCode": null,
          "sexName": "FEMALE",
          "socialSecurityNumber": null,
          "subscriberId": null,
          "suppressIdCards": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "tobaccoUsage": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "understandsEnglish": false,
          "updateByEmployee": "CI300",
          "updateDate": null,
          "verifiedPatientIndicator": "Y",
          "visionPlanPatientId": null
      }],
      "name": {
          "firstName": "MICHAEL",
          "lastName": "TESTING",
          "middleName": "",
          "prefixName": null,
          "suffixName": null
      },
      "notes": null,
      "originalEffectiveDate": "2002-06-01T00:00:00-0400",
      "phone": {
          "areaCode": "803",
          "extension": null,
          "prefix": "456",
          "suffix": "4564",
          "type": null
      },
      "policyType": "GROUP",
      "relatedInformationIndicator": false,
      "relationshipCode": null,
      "relationshipName": "SUBSCRIBER",
      "searchType": null,
      "selectedAMMSPatientId": null,
      "selectedPatientId": "001",
      "serviceCenter": {
          "code": "B01",
          "description": "MOHASCO",
          "key": "B01",
          "location": null,
          "name": "B01",
          "value": "MOHASCO"
      },
      "sexCode": "M",
      "sexName": "MALE",
      "socialSecurityNumber": "",
      "subscriberMember": {
          "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "rpn": null,
                  "state": null,
                  "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                  "code": null,
                  "description": null,
                  "key": null,
                  "name": null,
                  "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
          },
          "age": null,
          "alternateNames": [],
          "birthdate": "10/01/1958",
          "cancelCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "cardNumber": null,
          "carrierName": null,
          "carrierRestricted": false,
          "cesMemberNumber": "01",
          "confidentialClaimIndicator": false,
          "dateOfBirth": "1958-10-01T00:00:00-0400",
          "deferrals": [],
          "dependentIndicator": "C",
          "dependentVerified": "VERIFIED NON-STATE",
          "employmentStatus": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "id": null,
          "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "maritalStatus": {
              "code": null,
              "description": null,
              "key": null,
              "maritalStatusDate": null,
              "name": null,
              "value": null
          },
          "medicareNumber": null,
          "memberId": "001",
          "memberStatus": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "memberSubscriber": true,
          "name": {
              "firstName": "MICHAEL",
              "lastName": "TESTING",
              "middleName": "",
              "prefixName": null,
              "suffixName": ""
          },
          "originalEnrollmentDate": null,
          "overAgeDependent": {
              "certifiedDate": null,
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "overrides": [],
          "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
          },
          "planCode": null,
          "preferredLanguage": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "previousMemberId": null,
          "primaryCarePhysicianFound": false,
          "primaryCarePhysicianId": null,
          "primaryCarePhysicianName": null,
          "privacyIndicator": "",
          "recordBeginDate": null,
          "recordTermDate": null,
          "relationship": {
              "code": "1",
              "description": null,
              "key": "1",
              "name": "1",
              "value": null
          },
          "relationshipCode": "1",
          "relationshipName": "SUBSCRIBER",
          "setupDate": null,
          "sex": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "sexCode": null,
          "sexName": "MALE",
          "socialSecurityNumber": null,
          "subscriberId": null,
          "suppressIdCards": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "tobaccoUsage": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
          },
          "understandsEnglish": false,
          "updateByEmployee": "CI300",
          "updateDate": null,
          "verifiedPatientIndicator": "Y",
          "visionPlanPatientId": null
      },
      "totl": false
  },
  "subscriberProducts": ["Products.DENTAL",
                         "Products.MEDICAL"]
}