/* eslint-disable */
export const mockCallCenterAttributesHealth = {
    "numberOfCallsForRepeatCaller": 3,
    "numberOfDaysForRepeatCaller": 30,
    "sourceTypesForRepeatCaller": [
        "12",
        "13",
        "19"
    ],
    "departmentTypeForRepeatCaller": [
        "440",
        "8B8",
        "304"
    ],
    "divisionTypeForRepeatCaller": [
        "30",
        "32",
        "34"
    ],
    "wrapUpTime": 5,
    "maxHoldTime": 5,
    "companyTypeForCOBInforms": "3",
    "divisionTypeForCOBInforms": "30",
    "departmentTypeForCOBInforms": "420",
    "employeeIdForCOBInforms": "FULCSRIM"
}
