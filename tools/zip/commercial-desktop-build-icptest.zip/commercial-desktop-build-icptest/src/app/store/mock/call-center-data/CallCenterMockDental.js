/* eslint-disable */
export const mockCallCenterAttributesDental = {
    "numberOfCallsForRepeatCaller": 10,
    "numberOfDaysForRepeatCaller": 90,
    "sourceTypesForRepeatCaller": [
        "22",
        "23",
        "29"
    ],
    "departmentTypeForRepeatCaller": [
        "540",
        "9B8",
        "404"
    ],
    "divisionTypeForRepeatCaller": [
        "40",
        "42",
        "44"
    ],
    "wrapUpTime": 5,
    "maxHoldTime": 5,
    "companyTypeForCOBInforms": "4",
    "divisionTypeForCOBInforms": "40",
    "departmentTypeForCOBInforms": "520",
    "employeeIdForCOBInforms": "DENTSRIM"
}
