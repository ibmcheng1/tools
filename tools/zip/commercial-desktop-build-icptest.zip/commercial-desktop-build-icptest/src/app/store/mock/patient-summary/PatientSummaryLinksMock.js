/* eslint-disable */
export const mockPatientSummaryLinksMock = [
    {
        'name': 'patient-benefit-period-summary',
        'transaction-type': 'url',
        'transaction': 'http://lmgtfy.com'
    },
    {
        'name': 'provider-summary',
        'transaction-type': 'url',
        'transaction': 'http://google.com'
    },
    {
        'name': 'pos4-summary',
        'transaction-type': 'url',
        'transaction': 'http://duckduckgo.com'
    }
]
