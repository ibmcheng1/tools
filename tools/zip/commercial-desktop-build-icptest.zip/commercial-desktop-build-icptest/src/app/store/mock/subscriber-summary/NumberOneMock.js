/* eslint-disable */
export const mockSubscriber = {
  "agent": {
    "address": {
      "address1": null,
      "address2": null,
      "address3": null,
      "address4": null,
      "address5": null,
      "city": null,
      "country": null,
      "county": null,
      "countyCode": {
        "code": null,
        "description": null,
        "key": null,
        "name": null,
        "rpn": null,
        "state": null,
        "value": null
      },
      "province": null,
      "region": null,
      "state": null,
      "stateCode": {
        "code": null,
        "description": null,
        "key": null,
        "name": null,
        "value": null
      },
      "zipcode": null,
      "zipcodePostFix": null
    },
    "agency": {
      "address": {
        "address1": null,
        "address2": null,
        "address3": null,
        "address4": null,
        "address5": null,
        "city": null,
        "country": null,
        "county": null,
        "countyCode": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "rpn": null,
          "state": null,
          "value": null
        },
        "province": null,
        "region": null,
        "state": null,
        "stateCode": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        },
        "zipcode": null,
        "zipcodePostFix": null
      },
      "agent": {
        "code": null,
        "description": null,
        "key": null,
        "name": null,
        "value": null
      },
      "id": null,
      "idCode": {
        "code": null,
        "description": null,
        "key": null,
        "name": null,
        "value": null
      },
      "name": {
        "firstName": null,
        "lastName": null,
        "middleName": null,
        "prefixName": null,
        "suffixName": null
      },
      "phone": {
        "areaCode": null,
        "extension": null,
        "prefix": null,
        "suffix": null,
        "type": null
      }
    },
    "agentCode": null,
    "agentLookUpName": null,
    "agentLookupName": null,
    "authorizedForHSA": false,
    "id": null,
    "idCode": {
      "code": null,
      "description": null,
      "key": null,
      "name": null,
      "value": null
    },
    "individualHealthEffectiveDate": null,
    "individualHealthTermDate": null,
    "individualhealthStatus": null,
    "name": {
      "firstName": null,
      "lastName": null,
      "middleName": null,
      "prefixName": null,
      "suffixName": null
    },
    "phone": {
      "areaCode": null,
      "extension": null,
      "prefix": null,
      "suffix": null,
      "type": null
    }
  },
  "applicationDataPresent": false,
  "bill": null,
  "errorOccured": false,
  "exceptionsSummaryRecords": [
    {
      "alertExceptionIndicator": true,
      "contractLevelExceptionIndicator": true,
      "controlCode": {
        "code": "PE",
        "description": "Receive Electronic EOBs",
        "key": "PE",
        "name": "PE",
        "value": "Receive Electronic EOBs"
      },
      "controlDate": "2017-07-14T00:00:00-0400",
      "deferral": "",
      "exceptionDescription": "",
      "override": null,
      "patientID": "",
      "patientName": "CONTRACT",
      "priority": 1
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": true,
      "controlCode": {
        "code": "OCN",
        "description": "",
        "key": "OCN",
        "name": "OCN",
        "value": ""
      },
      "controlDate": "2018-05-11T00:00:00-0400",
      "deferral": "MISC INFO:",
      "exceptionDescription": "VERIFIED NO OTHER COVERAGE",
      "override": null,
      "patientID": "",
      "patientName": "CONTRACT",
      "priority": 2
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": true,
      "controlCode": {
        "code": "OCN",
        "description": "",
        "key": "OCN",
        "name": "OCN",
        "value": ""
      },
      "controlDate": "2018-05-02T00:00:00-0400",
      "deferral": "MISC INFO:",
      "exceptionDescription": "VERIFIED NO OTHER COVERAGE",
      "override": null,
      "patientID": "",
      "patientName": "CONTRACT",
      "priority": 3
    },
    {
      "alertExceptionIndicator": true,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "CM",
        "description": "Case Management",
        "key": "CM",
        "name": "CM",
        "value": "Case Management"
      },
      "controlDate": "2004-09-17T00:00:00-0400",
      "deferral": "",
      "exceptionDescription": "",
      "override": null,
      "patientID": "???",
      "patientName": "JOHN",
      "priority": 4
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "01",
        "description": "",
        "key": "01",
        "name": "01",
        "value": ""
      },
      "controlDate": "2004-09-17T00:00:00-0400",
      "deferral": "MISC INFO:",
      "exceptionDescription": "MED",
      "override": null,
      "patientID": "???",
      "patientName": "JOHN",
      "priority": 5
    },
    {
      "alertExceptionIndicator": true,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "CM",
        "description": "Case Management",
        "key": "CM",
        "name": "CM",
        "value": "Case Management"
      },
      "controlDate": "2005-03-11T00:00:00-0500",
      "deferral": "",
      "exceptionDescription": "",
      "override": null,
      "patientID": "001",
      "patientName": "MICHAEL",
      "priority": 6
    },
    {
      "alertExceptionIndicator": true,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "DB",
        "description": "Diabetes",
        "key": "DB",
        "name": "DB",
        "value": "Diabetes"
      },
      "controlDate": "2009-06-01T00:00:00-0400",
      "deferral": "",
      "exceptionDescription": "",
      "override": null,
      "patientID": "001",
      "patientName": "MICHAEL",
      "priority": 7
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "DF",
        "description": "",
        "key": "DF",
        "name": "DF",
        "value": ""
      },
      "controlDate": "2009-06-01T00:00:00-0400",
      "deferral": "MISC INFO:",
      "exceptionDescription": "GENERAL INFO: D5B84",
      "override": null,
      "patientID": "001",
      "patientName": "MICHAEL",
      "priority": 8
    },
    {
      "alertExceptionIndicator": true,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "CN",
        "description": "Processing Exception",
        "key": "CN",
        "name": "CN",
        "value": "Processing Exception"
      },
      "controlDate": "2012-09-01T00:00:00-0400",
      "deferral": "D5B84",
      "exceptionDescription": "Read processing exception on member\/family",
      "override": null,
      "patientID": "002",
      "patientName": "MARTHA",
      "priority": 9
    },
    {
      "alertExceptionIndicator": true,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "CM",
        "description": "Case Management",
        "key": "CM",
        "name": "CM",
        "value": "Case Management"
      },
      "controlDate": "2002-10-01T00:00:00-0400",
      "deferral": "",
      "exceptionDescription": "",
      "override": null,
      "patientID": "002",
      "patientName": "MARTHA",
      "priority": 10
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "DF",
        "description": "",
        "key": "DF",
        "name": "DF",
        "value": ""
      },
      "controlDate": "2012-09-01T00:00:00-0400",
      "deferral": "MISC INFO:",
      "exceptionDescription": "GENERAL INFO: D5B84",
      "override": null,
      "patientID": "002",
      "patientName": "MARTHA",
      "priority": 11
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "DP",
        "description": "",
        "key": "DP",
        "name": "DP",
        "value": ""
      },
      "controlDate": "2012-09-01T00:00:00-0400",
      "deferral": "MISC INFO:",
      "exceptionDescription": "GENERAL INFO: D5B84    K0001",
      "override": null,
      "patientID": "002",
      "patientName": "MARTHA",
      "priority": 12
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "DF",
        "description": "",
        "key": "DF",
        "name": "DF",
        "value": ""
      },
      "controlDate": "2012-09-01T00:00:00-0400",
      "deferral": "MISC INFO:",
      "exceptionDescription": "GENERAL INFO: D5B84",
      "override": null,
      "patientID": "002",
      "patientName": "MARTHA",
      "priority": 13
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "DP",
        "description": "",
        "key": "DP",
        "name": "DP",
        "value": ""
      },
      "controlDate": "2012-09-01T00:00:00-0400",
      "deferral": "MISC INFO:",
      "exceptionDescription": "GENERAL INFO: D5B84    E0601 E0601",
      "override": null,
      "patientID": "002",
      "patientName": "MARTHA",
      "priority": 14
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "DF",
        "description": "",
        "key": "DF",
        "name": "DF",
        "value": ""
      },
      "controlDate": "2012-09-01T00:00:00-0400",
      "deferral": "MISC INFO:",
      "exceptionDescription": "GENERAL INFO: D5B84",
      "override": null,
      "patientID": "002",
      "patientName": "MARTHA",
      "priority": 15
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "DP",
        "description": "",
        "key": "DP",
        "name": "DP",
        "value": ""
      },
      "controlDate": "2012-09-01T00:00:00-0400",
      "deferral": "MISC INFO:",
      "exceptionDescription": "GENERAL INFO: D5B84    E0562 E0562",
      "override": null,
      "patientID": "002",
      "patientName": "MARTHA",
      "priority": 16
    },
    {
      "alertExceptionIndicator": true,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "CN",
        "description": "Processing Exception",
        "key": "CN",
        "name": "CN",
        "value": "Processing Exception"
      },
      "controlDate": "2012-01-03T00:00:00-0500",
      "deferral": "D5B84",
      "exceptionDescription": "Read processing exception on member\/family",
      "override": null,
      "patientID": "003",
      "patientName": "TERRI",
      "priority": 17
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "DF",
        "description": "",
        "key": "DF",
        "name": "DF",
        "value": ""
      },
      "controlDate": "2012-01-03T00:00:00-0500",
      "deferral": "MISC INFO:",
      "exceptionDescription": "GENERAL INFO: D5B84",
      "override": null,
      "patientID": "003",
      "patientName": "TERRI",
      "priority": 18
    }
  ],
  "financialAccount": {
    "accountBalance": null,
    "accountBalanceDate": null,
    "accountNumber": null,
    "accountStatus": "OPEN",
    "accountType": null,
    "availableBalance": null,
    "financialInstitution": {
      "fridayHoursOfOperation": "",
      "mondayHoursOfOperation": "",
      "name": "",
      "phoneNumber": "",
      "routingNumber": null,
      "saturdayHoursOfOperation": "",
      "sundayHoursOfOperation": "",
      "thursdayHoursOfOperation": "",
      "tuesdayHoursOfOperation": "",
      "url": null,
      "wednesdayHoursOfOperation": ""
    },
    "interestRate": null,
    "lastInterestPaymentAmount": null,
    "lastStatementBalance": null,
    "lastStatementDate": null,
    "paymentAllowed": false,
    "paymentOption": "None",
    "yearToDateInterestPaid": null
  },
  "hicNumber": "TEST_HIC_NUMBER",
  "loadableSubscriber": {
    "PAI": false,
    "activeDate": null,
    "activelyCovered": null,
    "address": {
      "address1": "P O BOX  24015",
      "address2": "",
      "address3": null,
      "address4": null,
      "address5": null,
      "city": "COLUMBIA",
      "country": null,
      "county": "040",
      "countyCode": {
        "code": "040",
        "description": "RICHLAND",
        "key": "040",
        "name": "040",
        "rpn": null,
        "state": null,
        "value": "RICHLAND"
      },
      "province": null,
      "region": null,
      "state": "SC",
      "stateCode": {
        "code": "SC",
        "description": null,
        "key": "SC",
        "name": "SC",
        "value": null
      },
      "zipcode": "29224",
      "zipcodePostFix": "4015"
    },
    "alphaPrefix": "ZCZ",
    "ammsGroupNumber": "036011101",
    "bill": {
      "amountReceivable": null,
      "arHistoryIndicator": null,
      "balanceAmount": null,
      "billFormat": {
        "code": null,
        "description": null,
        "key": null,
        "name": null,
        "value": null
      },
      "billNumber": null,
      "billedDate": null,
      "billingFrequency": null,
      "clientNumber": null,
      "createARIndicator": null,
      "creationDate": null,
      "dueDate": null,
      "dueDay": null,
      "employeeListIndicator": null,
      "lastPaymentAmount": null,
      "lastPaymentDate": null,
      "listBillAccountNumber": "",
      "masterARNumber": null,
      "mode": {
        "code": null,
        "description": null,
        "key": null,
        "name": null,
        "value": null
      },
      "outputType": {
        "code": null,
        "description": null,
        "key": null,
        "name": null,
        "value": null
      },
      "paymentMethod": {
        "code": null,
        "description": null,
        "key": null,
        "name": null,
        "value": null
      },
      "paymentSummary": null,
      "providerId": null,
      "reasonCode": null,
      "recordCode": null,
      "renderTime": null,
      "serviceId": null,
      "sort": {
        "code": null,
        "description": null,
        "key": null,
        "name": null,
        "value": null
      },
      "supressBillIndicator": null,
      "viewStatementIndicator": null
    },
    "birthdate": "10\/01\/1958",
    "businessSector": "",
    "carrierName": "",
    "carrierRestricted": false,
    "ces": true,
    "cesExceptionIndicator": true,
    "cesGroupNumber": "0000667",
    "cisiRpn": null,
    "clientCode": {
      "code": "00006",
      "description": "TEST SPECIAL PROJECTS AREA",
      "key": "00006",
      "name": "00006",
      "value": "TEST SPECIAL PROJECTS AREA"
    },
    "coverage": null,
    "coverageContinuationTypeCode": {
      "code": "",
      "description": null,
      "key": "",
      "name": "",
      "value": null
    },
    "coverageItems": [
      {
        "active": true,
        "benefitSystem": "OLD",
        "coverageId": {
          "benefitLevel": "001",
          "coverageLevelCode": "C",
          "coverageNumber": "0000006",
          "productCode": "Products.DENTAL"
        },
        "drugProcessingCode": {
          "code": "",
          "description": null,
          "key": "",
          "name": "",
          "value": null
        },
        "effectiveDate": "2003-01-01T00:00:00-0500",
        "group": {
          "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "rpn": null,
              "state": null,
              "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
          },
          "agency": null,
          "anniversaryDate": null,
          "benefitSystem": null,
          "billDueDate": null,
          "billingAgencyCode": null,
          "billingAgentCode": null,
          "cancelCode": null,
          "cancelReasonCode": null,
          "clientContribution": null,
          "clientDescription": null,
          "clientNumber": null,
          "clientServiceCenterCode": null,
          "contactInformation": null,
          "contactName": null,
          "contractRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "contractTypes": null,
          "coverageEffectiveDate": null,
          "coverages": null,
          "dateBegin": null,
          "dateEnd": null,
          "departments": null,
          "drugOptionCode": null,
          "effectiveDate": null,
          "fax": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "groupCoverageBeginDate": null,
          "groupCoverageTermDate": null,
          "groupDescription": null,
          "groupLeader": null,
          "groupName": null,
          "groupNumberAmms": null,
          "groupNumberCes": null,
          "groupType": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "id": "0000667",
          "idCardType": null,
          "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "lastBillAmount": null,
          "lastBillDate": null,
          "maintenenceDate": null,
          "masterARNumber": null,
          "masterCoverageRateBegin": null,
          "masterCoverageRateEnd": null,
          "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
          },
          "outputRules": null,
          "paymentSummaryNumber": null,
          "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "probationaryPeriods": null,
          "productRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "ratingCounty": null,
          "rpn": null,
          "salesRepresentative": {
            "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "name": {
              "firstName": null,
              "lastName": null,
              "middleName": null,
              "prefixName": null,
              "suffixName": null
            },
            "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
            },
            "representative": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            }
          },
          "serviceRepresentative": {
            "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "name": {
              "firstName": null,
              "lastName": null,
              "middleName": null,
              "prefixName": null,
              "suffixName": null
            },
            "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
            },
            "representative": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            }
          },
          "sicCode": null,
          "specialHandling": null,
          "statusDescription": null,
          "subClientDescription": null,
          "subClientNumber": null,
          "terminationDate": null
        },
        "listBillIndicator": "",
        "majorMedicalWaiverCode": {
          "code": "",
          "description": null,
          "key": "",
          "name": "",
          "value": null
        },
        "memberId": null,
        "oldGroup": {
          "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "rpn": null,
              "state": null,
              "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
          },
          "agency": null,
          "anniversaryDate": null,
          "benefitSystem": null,
          "billDueDate": null,
          "billingAgencyCode": null,
          "billingAgentCode": null,
          "cancelCode": null,
          "cancelReasonCode": null,
          "clientContribution": null,
          "clientDescription": null,
          "clientNumber": null,
          "clientServiceCenterCode": null,
          "contactInformation": null,
          "contactName": null,
          "contractRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "contractTypes": null,
          "coverageEffectiveDate": null,
          "coverages": null,
          "dateBegin": null,
          "dateEnd": null,
          "departments": null,
          "drugOptionCode": null,
          "effectiveDate": null,
          "fax": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "groupCoverageBeginDate": null,
          "groupCoverageTermDate": null,
          "groupDescription": null,
          "groupLeader": null,
          "groupName": null,
          "groupNumberAmms": null,
          "groupNumberCes": null,
          "groupType": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "id": "036011101",
          "idCardType": null,
          "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "lastBillAmount": null,
          "lastBillDate": null,
          "maintenenceDate": null,
          "masterARNumber": null,
          "masterCoverageRateBegin": null,
          "masterCoverageRateEnd": null,
          "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
          },
          "outputRules": null,
          "paymentSummaryNumber": null,
          "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "probationaryPeriods": null,
          "productRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "ratingCounty": null,
          "rpn": null,
          "salesRepresentative": {
            "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "name": {
              "firstName": null,
              "lastName": null,
              "middleName": null,
              "prefixName": null,
              "suffixName": null
            },
            "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
            },
            "representative": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            }
          },
          "serviceRepresentative": {
            "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "name": {
              "firstName": null,
              "lastName": null,
              "middleName": null,
              "prefixName": null,
              "suffixName": null
            },
            "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
            },
            "representative": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            }
          },
          "sicCode": null,
          "specialHandling": null,
          "statusDescription": null,
          "subClientDescription": null,
          "subClientNumber": null,
          "terminationDate": null
        },
        "periods": null,
        "serviceCenter": "A01",
        "type": null
      },
      {
        "active": true,
        "benefitSystem": null,
        "coverageId": {
          "benefitLevel": "001",
          "coverageLevelCode": "C",
          "coverageNumber": "0000006",
          "productCode": "Products.MEDICAL"
        },
        "drugProcessingCode": {
          "code": "",
          "description": null,
          "key": "",
          "name": "",
          "value": null
        },
        "effectiveDate": "2002-06-01T00:00:00-0400",
        "group": {
          "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "rpn": null,
              "state": null,
              "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
          },
          "agency": null,
          "anniversaryDate": null,
          "benefitSystem": null,
          "billDueDate": null,
          "billingAgencyCode": null,
          "billingAgentCode": null,
          "cancelCode": null,
          "cancelReasonCode": null,
          "clientContribution": null,
          "clientDescription": null,
          "clientNumber": null,
          "clientServiceCenterCode": null,
          "contactInformation": null,
          "contactName": null,
          "contractRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "contractTypes": null,
          "coverageEffectiveDate": null,
          "coverages": null,
          "dateBegin": null,
          "dateEnd": null,
          "departments": null,
          "drugOptionCode": null,
          "effectiveDate": null,
          "fax": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "groupCoverageBeginDate": null,
          "groupCoverageTermDate": null,
          "groupDescription": null,
          "groupLeader": null,
          "groupName": null,
          "groupNumberAmms": null,
          "groupNumberCes": null,
          "groupType": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "id": "0000667",
          "idCardType": null,
          "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "lastBillAmount": null,
          "lastBillDate": null,
          "maintenenceDate": null,
          "masterARNumber": null,
          "masterCoverageRateBegin": null,
          "masterCoverageRateEnd": null,
          "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
          },
          "outputRules": null,
          "paymentSummaryNumber": null,
          "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "probationaryPeriods": null,
          "productRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "ratingCounty": null,
          "rpn": null,
          "salesRepresentative": {
            "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "name": {
              "firstName": null,
              "lastName": null,
              "middleName": null,
              "prefixName": null,
              "suffixName": null
            },
            "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
            },
            "representative": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            }
          },
          "serviceRepresentative": {
            "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "name": {
              "firstName": null,
              "lastName": null,
              "middleName": null,
              "prefixName": null,
              "suffixName": null
            },
            "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
            },
            "representative": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            }
          },
          "sicCode": null,
          "specialHandling": null,
          "statusDescription": null,
          "subClientDescription": null,
          "subClientNumber": null,
          "terminationDate": null
        },
        "listBillIndicator": "",
        "majorMedicalWaiverCode": {
          "code": "",
          "description": null,
          "key": "",
          "name": "",
          "value": null
        },
        "memberId": null,
        "oldGroup": {
          "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "rpn": null,
              "state": null,
              "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
          },
          "agency": null,
          "anniversaryDate": null,
          "benefitSystem": null,
          "billDueDate": null,
          "billingAgencyCode": null,
          "billingAgentCode": null,
          "cancelCode": null,
          "cancelReasonCode": null,
          "clientContribution": null,
          "clientDescription": null,
          "clientNumber": null,
          "clientServiceCenterCode": null,
          "contactInformation": null,
          "contactName": null,
          "contractRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "contractTypes": null,
          "coverageEffectiveDate": null,
          "coverages": null,
          "dateBegin": null,
          "dateEnd": null,
          "departments": null,
          "drugOptionCode": null,
          "effectiveDate": null,
          "fax": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "groupCoverageBeginDate": null,
          "groupCoverageTermDate": null,
          "groupDescription": null,
          "groupLeader": null,
          "groupName": null,
          "groupNumberAmms": null,
          "groupNumberCes": null,
          "groupType": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "id": "036011101",
          "idCardType": null,
          "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "lastBillAmount": null,
          "lastBillDate": null,
          "maintenenceDate": null,
          "masterARNumber": null,
          "masterCoverageRateBegin": null,
          "masterCoverageRateEnd": null,
          "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
          },
          "outputRules": null,
          "paymentSummaryNumber": null,
          "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "probationaryPeriods": null,
          "productRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "ratingCounty": null,
          "rpn": null,
          "salesRepresentative": {
            "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "name": {
              "firstName": null,
              "lastName": null,
              "middleName": null,
              "prefixName": null,
              "suffixName": null
            },
            "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
            },
            "representative": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            }
          },
          "serviceRepresentative": {
            "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "name": {
              "firstName": null,
              "lastName": null,
              "middleName": null,
              "prefixName": null,
              "suffixName": null
            },
            "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
            },
            "representative": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            }
          },
          "sicCode": null,
          "specialHandling": null,
          "statusDescription": null,
          "subClientDescription": null,
          "subClientNumber": null,
          "terminationDate": null
        },
        "periods": null,
        "serviceCenter": "B01",
        "type": null
      }
    ],
    "databaseNumber": "123456789",
    "dateOfBirth": "1958-10-01T00:00:00-0400",
    "drugIndicator": "Z",
    "employeeStatus": null,
    "engagementMemberRecords": null,
    "eobRecipient": "",
    "exceptionIndicator": false,
    "extraPhoneNumbers": [

    ],
    "fep": false,
    "formatNumber": null,
    "groupNumberCheckDigit": "",
    "groupPrefix": "GROUP - MAJOR",
    "hireDate": null,
    "id": "123456789",
    "idCardNumber": "065922516805",
    "idCode": {
      "code": null,
      "description": null,
      "key": null,
      "name": null,
      "value": null
    },
    "isMobileNotificationsEnabledForGroup": null,
    "lastIdCardDate": null,
    "lastIdCardIssueDate": "2018-05-10T00:00:00-0400",
    "latestCoverage": {
      "active": true,
      "benefitSystem": "OLD",
      "coverageId": {
        "benefitLevel": "001",
        "coverageLevelCode": "C",
        "coverageNumber": "0000006",
        "productCode": "Products.DENTAL"
      },
      "drugProcessingCode": {
        "code": "",
        "description": null,
        "key": "",
        "name": "",
        "value": null
      },
      "effectiveDate": "2003-01-01T00:00:00-0500",
      "group": {
        "address": {
          "address1": null,
          "address2": null,
          "address3": null,
          "address4": null,
          "address5": null,
          "city": null,
          "country": null,
          "county": null,
          "countyCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "rpn": null,
            "state": null,
            "value": null
          },
          "province": null,
          "region": null,
          "state": null,
          "stateCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "zipcode": null,
          "zipcodePostFix": null
        },
        "agency": null,
        "anniversaryDate": null,
        "benefitSystem": null,
        "billDueDate": null,
        "billingAgencyCode": null,
        "billingAgentCode": null,
        "cancelCode": null,
        "cancelReasonCode": null,
        "clientContribution": null,
        "clientDescription": null,
        "clientNumber": null,
        "clientServiceCenterCode": null,
        "contactInformation": null,
        "contactName": null,
        "contractRule": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        },
        "contractTypes": null,
        "coverageEffectiveDate": null,
        "coverages": null,
        "dateBegin": null,
        "dateEnd": null,
        "departments": null,
        "drugOptionCode": null,
        "effectiveDate": null,
        "fax": {
          "areaCode": null,
          "extension": null,
          "prefix": null,
          "suffix": null,
          "type": null
        },
        "groupCoverageBeginDate": null,
        "groupCoverageTermDate": null,
        "groupDescription": null,
        "groupLeader": null,
        "groupName": null,
        "groupNumberAmms": null,
        "groupNumberCes": null,
        "groupType": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        },
        "id": "0000667",
        "idCardType": null,
        "idCode": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        },
        "lastBillAmount": null,
        "lastBillDate": null,
        "maintenenceDate": null,
        "masterARNumber": null,
        "masterCoverageRateBegin": null,
        "masterCoverageRateEnd": null,
        "name": {
          "firstName": null,
          "lastName": null,
          "middleName": null,
          "prefixName": null,
          "suffixName": null
        },
        "outputRules": null,
        "paymentSummaryNumber": null,
        "phone": {
          "areaCode": null,
          "extension": null,
          "prefix": null,
          "suffix": null,
          "type": null
        },
        "probationaryPeriods": null,
        "productRule": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        },
        "ratingCounty": null,
        "rpn": null,
        "salesRepresentative": {
          "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "rpn": null,
              "state": null,
              "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
          },
          "id": null,
          "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
          },
          "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "representative": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          }
        },
        "serviceRepresentative": {
          "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "rpn": null,
              "state": null,
              "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
          },
          "id": null,
          "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
          },
          "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "representative": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          }
        },
        "sicCode": null,
        "specialHandling": null,
        "statusDescription": null,
        "subClientDescription": null,
        "subClientNumber": null,
        "terminationDate": null
      },
      "listBillIndicator": "",
      "majorMedicalWaiverCode": {
        "code": "",
        "description": null,
        "key": "",
        "name": "",
        "value": null
      },
      "memberId": null,
      "oldGroup": {
        "address": {
          "address1": null,
          "address2": null,
          "address3": null,
          "address4": null,
          "address5": null,
          "city": null,
          "country": null,
          "county": null,
          "countyCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "rpn": null,
            "state": null,
            "value": null
          },
          "province": null,
          "region": null,
          "state": null,
          "stateCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "zipcode": null,
          "zipcodePostFix": null
        },
        "agency": null,
        "anniversaryDate": null,
        "benefitSystem": null,
        "billDueDate": null,
        "billingAgencyCode": null,
        "billingAgentCode": null,
        "cancelCode": null,
        "cancelReasonCode": null,
        "clientContribution": null,
        "clientDescription": null,
        "clientNumber": null,
        "clientServiceCenterCode": null,
        "contactInformation": null,
        "contactName": null,
        "contractRule": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        },
        "contractTypes": null,
        "coverageEffectiveDate": null,
        "coverages": null,
        "dateBegin": null,
        "dateEnd": null,
        "departments": null,
        "drugOptionCode": null,
        "effectiveDate": null,
        "fax": {
          "areaCode": null,
          "extension": null,
          "prefix": null,
          "suffix": null,
          "type": null
        },
        "groupCoverageBeginDate": null,
        "groupCoverageTermDate": null,
        "groupDescription": null,
        "groupLeader": null,
        "groupName": null,
        "groupNumberAmms": null,
        "groupNumberCes": null,
        "groupType": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        },
        "id": "036011101",
        "idCardType": null,
        "idCode": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        },
        "lastBillAmount": null,
        "lastBillDate": null,
        "maintenenceDate": null,
        "masterARNumber": null,
        "masterCoverageRateBegin": null,
        "masterCoverageRateEnd": null,
        "name": {
          "firstName": null,
          "lastName": null,
          "middleName": null,
          "prefixName": null,
          "suffixName": null
        },
        "outputRules": null,
        "paymentSummaryNumber": null,
        "phone": {
          "areaCode": null,
          "extension": null,
          "prefix": null,
          "suffix": null,
          "type": null
        },
        "probationaryPeriods": null,
        "productRule": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        },
        "ratingCounty": null,
        "rpn": null,
        "salesRepresentative": {
          "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "rpn": null,
              "state": null,
              "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
          },
          "id": null,
          "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
          },
          "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "representative": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          }
        },
        "serviceRepresentative": {
          "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "rpn": null,
              "state": null,
              "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
          },
          "id": null,
          "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
          },
          "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "representative": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          }
        },
        "sicCode": null,
        "specialHandling": null,
        "statusDescription": null,
        "subClientDescription": null,
        "subClientNumber": null,
        "terminationDate": null
      },
      "periods": null,
      "serviceCenter": "A01",
      "type": null
    },
    "maintenanceDate": null,
    "memberId": null,
    "members": null,
    "name": {
      "firstName": "MICHAEL",
      "lastName": "TESTING",
      "middleName": "",
      "prefixName": null,
      "suffixName": null
    },
    "notes": null,
    "originalEffectiveDate": "2002-06-01T00:00:00-0400",
    "phone": {
      "areaCode": "803",
      "extension": null,
      "prefix": "456",
      "suffix": "4564",
      "type": null
    },
    "policyType": null,
    "relatedInformationIndicator": false,
    "relationshipCode": null,
    "relationshipName": null,
    "searchType": null,
    "selectedAMMSPatientId": null,
    "selectedPatientId": null,
    "serviceCenter": {
      "code": "B01",
      "description": "MOHASCO",
      "key": "B01",
      "location": null,
      "name": "B01",
      "value": "MOHASCO"
    },
    "sexCode": "M",
    "sexName": null,
    "socialSecurityNumber": "",
    "subscriberMember": null,
    "totl": false
  },
  "noDataFound": null,
  "phoneToolTipString": "home: (803) 456-4564\nwork: (803) 654-7894",
  "subscriber": {
    "PAI": false,
    "activeDate": null,
    "activelyCovered": null,
    "address": {
      "address1": "BRIDGE",
      "address2": "C/O DEANNA TROI",
      "address3": null,
      "address4": null,
      "address5": null,
      "city": "USS ENTERPRISE",
      "country": null,
      "county": "040",
      "countyCode": {
        "code": "005",
        "description": "FEDERATION SPACE",
        "key": "040",
        "name": "040",
        "rpn": null,
        "state": null,
        "value": "FEDERATION SPACE"
      },
      "province": null,
      "region": null,
      "state": "FEDERATION",
      "stateCode": {
        "code": "FEDERATION",
        "description": null,
        "key": "FEDERATION",
        "name": "FEDERATION",
        "value": null
      },
      "zipcode": "99999",
      "zipcodePostFix": "9557"
    },
    "alphaPrefix": "ZCZ",
    "ammsGroupNumber": "036011101",
    "bill": {
      "amountReceivable": null,
      "arHistoryIndicator": null,
      "balanceAmount": null,
      "billFormat": {
        "code": null,
        "description": null,
        "key": null,
        "name": null,
        "value": null
      },
      "billNumber": null,
      "billedDate": null,
      "billingFrequency": null,
      "clientNumber": null,
      "createARIndicator": null,
      "creationDate": null,
      "dueDate": null,
      "dueDay": null,
      "employeeListIndicator": null,
      "lastPaymentAmount": null,
      "lastPaymentDate": null,
      "listBillAccountNumber": "",
      "masterARNumber": null,
      "mode": {
        "code": null,
        "description": null,
        "key": null,
        "name": null,
        "value": null
      },
      "outputType": {
        "code": null,
        "description": null,
        "key": null,
        "name": null,
        "value": null
      },
      "paymentMethod": {
        "code": null,
        "description": null,
        "key": null,
        "name": null,
        "value": null
      },
      "paymentSummary": null,
      "providerId": null,
      "reasonCode": null,
      "recordCode": null,
      "renderTime": null,
      "serviceId": null,
      "sort": {
        "code": null,
        "description": null,
        "key": null,
        "name": null,
        "value": null
      },
      "supressBillIndicator": null,
      "viewStatementIndicator": null
    },
    "birthdate": "02\/01\/1985",
    "businessSector": "",
    "carrierName": "",
    "carrierRestricted": false,
    "ces": true,
    "cesExceptionIndicator": true,
    "cesGroupNumber": "0000667",
    "cisiRpn": null,
    "clientCode": {
      "code": "00006",
      "description": "TEST SPECIAL PROJECTS AREA",
      "key": "00006",
      "name": "00006",
      "value": "TEST SPECIAL PROJECTS AREA"
    },
    "coverage": null,
    "coverageContinuationTypeCode": {
      "code": "",
      "description": null,
      "key": "",
      "name": "",
      "value": null
    },
    "coverageItems": [
      {
        "active": true,
        "benefitSystem": "OLD",
        "coverageId": {
          "benefitLevel": "001",
          "coverageLevelCode": "C",
          "coverageNumber": "0000006",
          "productCode": "Products.DENTAL"
        },
        "drugProcessingCode": {
          "code": "",
          "description": null,
          "key": "",
          "name": "",
          "value": null
        },
        "effectiveDate": "2003-01-01T00:00:00-0500",
        "group": {
          "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "rpn": null,
              "state": null,
              "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
          },
          "agency": null,
          "anniversaryDate": null,
          "benefitSystem": null,
          "billDueDate": null,
          "billingAgencyCode": null,
          "billingAgentCode": null,
          "cancelCode": null,
          "cancelReasonCode": null,
          "clientContribution": null,
          "clientDescription": null,
          "clientNumber": null,
          "clientServiceCenterCode": null,
          "contactInformation": null,
          "contactName": null,
          "contractRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "contractTypes": null,
          "coverageEffectiveDate": null,
          "coverages": null,
          "dateBegin": null,
          "dateEnd": null,
          "departments": null,
          "drugOptionCode": null,
          "effectiveDate": null,
          "fax": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "groupCoverageBeginDate": null,
          "groupCoverageTermDate": null,
          "groupDescription": null,
          "groupLeader": null,
          "groupName": null,
          "groupNumberAmms": null,
          "groupNumberCes": null,
          "groupType": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "id": "0000667",
          "idCardType": null,
          "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "lastBillAmount": null,
          "lastBillDate": null,
          "maintenenceDate": null,
          "masterARNumber": null,
          "masterCoverageRateBegin": null,
          "masterCoverageRateEnd": null,
          "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
          },
          "outputRules": null,
          "paymentSummaryNumber": null,
          "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "probationaryPeriods": null,
          "productRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "ratingCounty": null,
          "rpn": null,
          "salesRepresentative": {
            "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "name": {
              "firstName": null,
              "lastName": null,
              "middleName": null,
              "prefixName": null,
              "suffixName": null
            },
            "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
            },
            "representative": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            }
          },
          "serviceRepresentative": {
            "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "name": {
              "firstName": null,
              "lastName": null,
              "middleName": null,
              "prefixName": null,
              "suffixName": null
            },
            "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
            },
            "representative": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            }
          },
          "sicCode": null,
          "specialHandling": null,
          "statusDescription": null,
          "subClientDescription": null,
          "subClientNumber": null,
          "terminationDate": null
        },
        "listBillIndicator": "",
        "majorMedicalWaiverCode": {
          "code": "",
          "description": null,
          "key": "",
          "name": "",
          "value": null
        },
        "memberId": null,
        "oldGroup": {
          "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "rpn": null,
              "state": null,
              "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
          },
          "agency": null,
          "anniversaryDate": null,
          "benefitSystem": null,
          "billDueDate": null,
          "billingAgencyCode": null,
          "billingAgentCode": null,
          "cancelCode": null,
          "cancelReasonCode": null,
          "clientContribution": null,
          "clientDescription": null,
          "clientNumber": null,
          "clientServiceCenterCode": null,
          "contactInformation": null,
          "contactName": null,
          "contractRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "contractTypes": null,
          "coverageEffectiveDate": null,
          "coverages": null,
          "dateBegin": null,
          "dateEnd": null,
          "departments": null,
          "drugOptionCode": null,
          "effectiveDate": null,
          "fax": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "groupCoverageBeginDate": null,
          "groupCoverageTermDate": null,
          "groupDescription": null,
          "groupLeader": null,
          "groupName": null,
          "groupNumberAmms": null,
          "groupNumberCes": null,
          "groupType": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "id": "036011101",
          "idCardType": null,
          "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "lastBillAmount": null,
          "lastBillDate": null,
          "maintenenceDate": null,
          "masterARNumber": null,
          "masterCoverageRateBegin": null,
          "masterCoverageRateEnd": null,
          "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
          },
          "outputRules": null,
          "paymentSummaryNumber": null,
          "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "probationaryPeriods": null,
          "productRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "ratingCounty": null,
          "rpn": null,
          "salesRepresentative": {
            "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "name": {
              "firstName": null,
              "lastName": null,
              "middleName": null,
              "prefixName": null,
              "suffixName": null
            },
            "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
            },
            "representative": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            }
          },
          "serviceRepresentative": {
            "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "name": {
              "firstName": null,
              "lastName": null,
              "middleName": null,
              "prefixName": null,
              "suffixName": null
            },
            "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
            },
            "representative": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            }
          },
          "sicCode": null,
          "specialHandling": null,
          "statusDescription": null,
          "subClientDescription": null,
          "subClientNumber": null,
          "terminationDate": null
        },
        "periods": null,
        "serviceCenter": "A01",
        "type": null
      },
      {
        "active": true,
        "benefitSystem": null,
        "coverageId": {
          "benefitLevel": "001",
          "coverageLevelCode": "C",
          "coverageNumber": "0000006",
          "productCode": "Products.MEDICAL"
        },
        "drugProcessingCode": {
          "code": "",
          "description": null,
          "key": "",
          "name": "",
          "value": null
        },
        "effectiveDate": "2002-06-01T00:00:00-0400",
        "group": {
          "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "rpn": null,
              "state": null,
              "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
          },
          "agency": null,
          "anniversaryDate": null,
          "benefitSystem": null,
          "billDueDate": null,
          "billingAgencyCode": null,
          "billingAgentCode": null,
          "cancelCode": null,
          "cancelReasonCode": null,
          "clientContribution": null,
          "clientDescription": null,
          "clientNumber": null,
          "clientServiceCenterCode": null,
          "contactInformation": null,
          "contactName": null,
          "contractRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "contractTypes": null,
          "coverageEffectiveDate": null,
          "coverages": null,
          "dateBegin": null,
          "dateEnd": null,
          "departments": null,
          "drugOptionCode": null,
          "effectiveDate": null,
          "fax": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "groupCoverageBeginDate": null,
          "groupCoverageTermDate": null,
          "groupDescription": null,
          "groupLeader": null,
          "groupName": null,
          "groupNumberAmms": null,
          "groupNumberCes": null,
          "groupType": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "id": "0000667",
          "idCardType": null,
          "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "lastBillAmount": null,
          "lastBillDate": null,
          "maintenenceDate": null,
          "masterARNumber": null,
          "masterCoverageRateBegin": null,
          "masterCoverageRateEnd": null,
          "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
          },
          "outputRules": null,
          "paymentSummaryNumber": null,
          "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "probationaryPeriods": null,
          "productRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "ratingCounty": null,
          "rpn": null,
          "salesRepresentative": {
            "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "name": {
              "firstName": null,
              "lastName": null,
              "middleName": null,
              "prefixName": null,
              "suffixName": null
            },
            "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
            },
            "representative": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            }
          },
          "serviceRepresentative": {
            "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "name": {
              "firstName": null,
              "lastName": null,
              "middleName": null,
              "prefixName": null,
              "suffixName": null
            },
            "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
            },
            "representative": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            }
          },
          "sicCode": null,
          "specialHandling": null,
          "statusDescription": null,
          "subClientDescription": null,
          "subClientNumber": null,
          "terminationDate": null
        },
        "listBillIndicator": "",
        "majorMedicalWaiverCode": {
          "code": "",
          "description": null,
          "key": "",
          "name": "",
          "value": null
        },
        "memberId": null,
        "oldGroup": {
          "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "rpn": null,
              "state": null,
              "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
          },
          "agency": null,
          "anniversaryDate": null,
          "benefitSystem": null,
          "billDueDate": null,
          "billingAgencyCode": null,
          "billingAgentCode": null,
          "cancelCode": null,
          "cancelReasonCode": null,
          "clientContribution": null,
          "clientDescription": null,
          "clientNumber": null,
          "clientServiceCenterCode": null,
          "contactInformation": null,
          "contactName": null,
          "contractRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "contractTypes": null,
          "coverageEffectiveDate": null,
          "coverages": null,
          "dateBegin": null,
          "dateEnd": null,
          "departments": null,
          "drugOptionCode": null,
          "effectiveDate": null,
          "fax": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "groupCoverageBeginDate": null,
          "groupCoverageTermDate": null,
          "groupDescription": null,
          "groupLeader": null,
          "groupName": null,
          "groupNumberAmms": null,
          "groupNumberCes": null,
          "groupType": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "id": "036011101",
          "idCardType": null,
          "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "lastBillAmount": null,
          "lastBillDate": null,
          "maintenenceDate": null,
          "masterARNumber": null,
          "masterCoverageRateBegin": null,
          "masterCoverageRateEnd": null,
          "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
          },
          "outputRules": null,
          "paymentSummaryNumber": null,
          "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "probationaryPeriods": null,
          "productRule": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "ratingCounty": null,
          "rpn": null,
          "salesRepresentative": {
            "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "name": {
              "firstName": null,
              "lastName": null,
              "middleName": null,
              "prefixName": null,
              "suffixName": null
            },
            "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
            },
            "representative": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            }
          },
          "serviceRepresentative": {
            "address": {
              "address1": null,
              "address2": null,
              "address3": null,
              "address4": null,
              "address5": null,
              "city": null,
              "country": null,
              "county": null,
              "countyCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "rpn": null,
                "state": null,
                "value": null
              },
              "province": null,
              "region": null,
              "state": null,
              "stateCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
              },
              "zipcode": null,
              "zipcodePostFix": null
            },
            "id": null,
            "idCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "name": {
              "firstName": null,
              "lastName": null,
              "middleName": null,
              "prefixName": null,
              "suffixName": null
            },
            "phone": {
              "areaCode": null,
              "extension": null,
              "prefix": null,
              "suffix": null,
              "type": null
            },
            "representative": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            }
          },
          "sicCode": null,
          "specialHandling": null,
          "statusDescription": null,
          "subClientDescription": null,
          "subClientNumber": null,
          "terminationDate": null
        },
        "periods": null,
        "serviceCenter": "B01",
        "type": null
      }
    ],
    "databaseNumber": "123456789",
    "dateOfBirth": "1958-10-01T00:00:00-0400",
    "drugIndicator": "Z",
    "employeeStatus": null,
    "engagementMemberRecords": null,
    "eobRecipient": "",
    "exceptionIndicator": false,
    "extraPhoneNumbers": [

    ],
    "fep": false,
    "formatNumber": null,
    "groupNumberCheckDigit": "",
    "groupPrefix": "GROUP - MAJOR",
    "hireDate": null,
    "id": "123456789",
    "idCardNumber": "065922516805",
    "idCode": {
      "code": null,
      "description": null,
      "key": null,
      "name": null,
      "value": null
    },
    "isMobileNotificationsEnabledForGroup": null,
    "lastIdCardDate": null,
    "lastIdCardIssueDate": "2018-05-10T00:00:00-0400",
    "latestCoverage": {
      "active": true,
      "benefitSystem": "OLD",
      "coverageId": {
        "benefitLevel": "001",
        "coverageLevelCode": "C",
        "coverageNumber": "0000006",
        "productCode": "Products.DENTAL"
      },
      "drugProcessingCode": {
        "code": "",
        "description": null,
        "key": "",
        "name": "",
        "value": null
      },
      "effectiveDate": "2003-01-01T00:00:00-0500",
      "group": {
        "address": {
          "address1": null,
          "address2": null,
          "address3": null,
          "address4": null,
          "address5": null,
          "city": null,
          "country": null,
          "county": null,
          "countyCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "rpn": null,
            "state": null,
            "value": null
          },
          "province": null,
          "region": null,
          "state": null,
          "stateCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "zipcode": null,
          "zipcodePostFix": null
        },
        "agency": null,
        "anniversaryDate": null,
        "benefitSystem": null,
        "billDueDate": null,
        "billingAgencyCode": null,
        "billingAgentCode": null,
        "cancelCode": null,
        "cancelReasonCode": null,
        "clientContribution": null,
        "clientDescription": null,
        "clientNumber": null,
        "clientServiceCenterCode": null,
        "contactInformation": null,
        "contactName": null,
        "contractRule": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        },
        "contractTypes": null,
        "coverageEffectiveDate": null,
        "coverages": null,
        "dateBegin": null,
        "dateEnd": null,
        "departments": null,
        "drugOptionCode": null,
        "effectiveDate": null,
        "fax": {
          "areaCode": null,
          "extension": null,
          "prefix": null,
          "suffix": null,
          "type": null
        },
        "groupCoverageBeginDate": null,
        "groupCoverageTermDate": null,
        "groupDescription": null,
        "groupLeader": null,
        "groupName": null,
        "groupNumberAmms": null,
        "groupNumberCes": null,
        "groupType": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        },
        "id": "0000667",
        "idCardType": null,
        "idCode": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        },
        "lastBillAmount": null,
        "lastBillDate": null,
        "maintenenceDate": null,
        "masterARNumber": null,
        "masterCoverageRateBegin": null,
        "masterCoverageRateEnd": null,
        "name": {
          "firstName": null,
          "lastName": null,
          "middleName": null,
          "prefixName": null,
          "suffixName": null
        },
        "outputRules": null,
        "paymentSummaryNumber": null,
        "phone": {
          "areaCode": null,
          "extension": null,
          "prefix": null,
          "suffix": null,
          "type": null
        },
        "probationaryPeriods": null,
        "productRule": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        },
        "ratingCounty": null,
        "rpn": null,
        "salesRepresentative": {
          "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "rpn": null,
              "state": null,
              "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
          },
          "id": null,
          "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
          },
          "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "representative": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          }
        },
        "serviceRepresentative": {
          "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "rpn": null,
              "state": null,
              "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
          },
          "id": null,
          "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
          },
          "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "representative": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          }
        },
        "sicCode": null,
        "specialHandling": null,
        "statusDescription": null,
        "subClientDescription": null,
        "subClientNumber": null,
        "terminationDate": null
      },
      "listBillIndicator": "",
      "majorMedicalWaiverCode": {
        "code": "",
        "description": null,
        "key": "",
        "name": "",
        "value": null
      },
      "memberId": null,
      "oldGroup": {
        "address": {
          "address1": null,
          "address2": null,
          "address3": null,
          "address4": null,
          "address5": null,
          "city": null,
          "country": null,
          "county": null,
          "countyCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "rpn": null,
            "state": null,
            "value": null
          },
          "province": null,
          "region": null,
          "state": null,
          "stateCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "zipcode": null,
          "zipcodePostFix": null
        },
        "agency": null,
        "anniversaryDate": null,
        "benefitSystem": null,
        "billDueDate": null,
        "billingAgencyCode": null,
        "billingAgentCode": null,
        "cancelCode": null,
        "cancelReasonCode": null,
        "clientContribution": null,
        "clientDescription": null,
        "clientNumber": null,
        "clientServiceCenterCode": null,
        "contactInformation": null,
        "contactName": null,
        "contractRule": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        },
        "contractTypes": null,
        "coverageEffectiveDate": null,
        "coverages": null,
        "dateBegin": null,
        "dateEnd": null,
        "departments": null,
        "drugOptionCode": null,
        "effectiveDate": null,
        "fax": {
          "areaCode": null,
          "extension": null,
          "prefix": null,
          "suffix": null,
          "type": null
        },
        "groupCoverageBeginDate": null,
        "groupCoverageTermDate": null,
        "groupDescription": null,
        "groupLeader": null,
        "groupName": null,
        "groupNumberAmms": null,
        "groupNumberCes": null,
        "groupType": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        },
        "id": "036011101",
        "idCardType": null,
        "idCode": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        },
        "lastBillAmount": null,
        "lastBillDate": null,
        "maintenenceDate": null,
        "masterARNumber": null,
        "masterCoverageRateBegin": null,
        "masterCoverageRateEnd": null,
        "name": {
          "firstName": null,
          "lastName": null,
          "middleName": null,
          "prefixName": null,
          "suffixName": null
        },
        "outputRules": null,
        "paymentSummaryNumber": null,
        "phone": {
          "areaCode": null,
          "extension": null,
          "prefix": null,
          "suffix": null,
          "type": null
        },
        "probationaryPeriods": null,
        "productRule": {
          "code": null,
          "description": null,
          "key": null,
          "name": null,
          "value": null
        },
        "ratingCounty": null,
        "rpn": null,
        "salesRepresentative": {
          "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "rpn": null,
              "state": null,
              "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
          },
          "id": null,
          "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
          },
          "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "representative": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          }
        },
        "serviceRepresentative": {
          "address": {
            "address1": null,
            "address2": null,
            "address3": null,
            "address4": null,
            "address5": null,
            "city": null,
            "country": null,
            "county": null,
            "countyCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "rpn": null,
              "state": null,
              "value": null
            },
            "province": null,
            "region": null,
            "state": null,
            "stateCode": {
              "code": null,
              "description": null,
              "key": null,
              "name": null,
              "value": null
            },
            "zipcode": null,
            "zipcodePostFix": null
          },
          "id": null,
          "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          },
          "name": {
            "firstName": null,
            "lastName": null,
            "middleName": null,
            "prefixName": null,
            "suffixName": null
          },
          "phone": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
          },
          "representative": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
          }
        },
        "sicCode": null,
        "specialHandling": null,
        "statusDescription": null,
        "subClientDescription": null,
        "subClientNumber": null,
        "terminationDate": null
      },
      "periods": null,
      "serviceCenter": "A01",
      "type": null
    },
    "maintenanceDate": null,
    "memberId": null,
    "members": null,
    "name": {
      "firstName": "WILLIAM",
      "lastName": "RIKER",
      "middleName": "THOMAS",
      "prefixName": null,
      "suffixName": null
    },
    "notes": null,
    "originalEffectiveDate": "2002-06-01T00:00:00-0400",
    "phone": {
      "areaCode": "803",
      "extension": null,
      "prefix": "456",
      "suffix": "4564",
      "type": null
    },
    "policyType": null,
    "relatedInformationIndicator": false,
    "relationshipCode": null,
    "relationshipName": null,
    "searchType": null,
    "selectedAMMSPatientId": null,
    "selectedPatientId": null,
    "serviceCenter": {
      "code": "B01",
      "description": "MOHASCO",
      "key": "B01",
      "location": null,
      "name": "B01",
      "value": "MOHASCO"
    },
    "sexCode": "M",
    "sexName": null,
    "socialSecurityNumber": "",
    "subscriberMember": null,
    "totl": false
  },
  "subscriberId": "123456789"
}
