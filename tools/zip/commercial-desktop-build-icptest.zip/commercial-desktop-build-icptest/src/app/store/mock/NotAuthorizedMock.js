export const mockNotAuthorized = {
    url: 'https://unit.api.bcbssc.com/customer-service/members/OTk5NTc0MzE3fDAwMQ%3D%3D/products/health/claims',
    ok: false,
    status: 403,
    statusText: 'M160: Unknown Error',
    headers: {
        map: {
            'content-type': [
                'application/json'
            ]
        }
    },
    body: {
        httpCode: '403',
        httpMessage: 'M160: Unknown Error',
        moreInformation: 'gtid:109335057'
    },
    bodyText: '{ "httpCode":"403", "httpMessage":"M160: Unknown Error", "moreInformation":"gtid:109335057" }'
};
