export const mockServiceError = {
    url: 'https://unit.api.bcbssc.com/customer-service/members/OTk5NTc0MzE3fDAwMQ%3D%3D/products/health/claims',
    ok: false,
    status: 500,
    statusText: 'Service Error',
    headers: {
        map: {
            'content-type': [
                'application/json'
            ]
        }
    },
    body: {
        httpCode: '500',
        httpMessage: 'Service Error',
        moreInformation: 'gtid:109335057'
    },
    bodyText: '{ "httpCode":"500", "httpMessage":"Service Error", "moreInformation":"gtid:109335057" }'
};
