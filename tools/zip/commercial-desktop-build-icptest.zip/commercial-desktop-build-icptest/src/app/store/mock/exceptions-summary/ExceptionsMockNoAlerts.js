/* eslint-disable */
export const mockExceptionsNoAlerts = [
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": true,
      "controlCode": {
        "code": "PE",
        "description": "Receive Electronic EOBs",
        "key": "PE",
        "name": "PE",
        "value": "Receive Electronic EOBs"
      },
      "controlDate": "2017-07-14T00:00:00-0400",
      "deferral": "",
      "exceptionDescription": "",
      "override": null,
      "patientID": "",
      "patientName": "CONTRACT",
      "priority": 1
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": true,
      "controlCode": {
        "code": "OCN",
        "description": "",
        "key": "OCN",
        "name": "OCN",
        "value": ""
      },
      "controlDate": "2018-05-24T00:00:00-0401",
      "deferral": "MISC INFO:",
      "exceptionDescription": "VERIFIED NO OTHER COVERAGE",
      "override": null,
      "patientID": "",
      "patientName": "CONTRACT",
      "priority": 2
    }
  ]
