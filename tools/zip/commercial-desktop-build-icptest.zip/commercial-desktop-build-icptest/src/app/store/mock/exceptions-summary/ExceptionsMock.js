/* eslint-disable */
export const mockExceptions = [
    {
      "alertExceptionIndicator": true,
      "contractLevelExceptionIndicator": true,
      "controlCode": {
        "code": "PE",
        "description": "Receive Electronic EOBs",
        "key": "PE",
        "name": "PE",
        "value": "Receive Electronic EOBs"
      },
      "controlDate": "2017-07-14T00:00:00-0400",
      "deferral": "",
      "exceptionDescription": "",
      "override": null,
      "patientID": "",
      "patientName": "CONTRACT",
      "priority": 1
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": true,
      "controlCode": {
        "code": "OCN",
        "description": "",
        "key": "OCN",
        "name": "OCN",
        "value": ""
      },
      "controlDate": "2018-05-24T00:00:00-0401",
      "deferral": "MISC INFO:",
      "exceptionDescription": "VERIFIED NO OTHER COVERAGE",
      "override": null,
      "patientID": "",
      "patientName": "CONTRACT",
      "priority": 2
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": true,
      "controlCode": {
        "code": "OCN",
        "description": "",
        "key": "OCN",
        "name": "OCN",
        "value": ""
      },
      "controlDate": "2018-05-02T00:00:00-0402",
      "deferral": "MISC INFO:",
      "exceptionDescription": "VERIFIED NO OTHER COVERAGE",
      "override": null,
      "patientID": "",
      "patientName": "CONTRACT",
      "priority": 3
    },
    {
      "alertExceptionIndicator": true,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "CM",
        "description": "Case Management",
        "key": "CM",
        "name": "CM",
        "value": "Case Management"
      },
      "controlDate": "2004-09-17T00:00:00-0403",
      "deferral": "",
      "exceptionDescription": "",
      "override": null,
      "patientID": "???",
      "patientName": "JOHN",
      "priority": 4
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "01",
        "description": "",
        "key": "01",
        "name": "01",
        "value": ""
      },
      "controlDate": "2004-09-17T00:00:00-0404",
      "deferral": "MISC INFO:",
      "exceptionDescription": "MED",
      "override": null,
      "patientID": "???",
      "patientName": "JOHN",
      "priority": 5
    },
    {
      "alertExceptionIndicator": true,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "CM",
        "description": "Case Management",
        "key": "CM",
        "name": "CM",
        "value": "Case Management"
      },
      "controlDate": "2005-03-11T00:00:00-0501",
      "deferral": "",
      "exceptionDescription": "",
      "override": null,
      "patientID": "001",
      "patientName": "MICHAEL",
      "priority": 6
    },
    {
      "alertExceptionIndicator": true,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "DB",
        "description": "Diabetes",
        "key": "DB",
        "name": "DB",
        "value": "Diabetes"
      },
      "controlDate": "2009-06-01T00:00:00-0401",
      "deferral": "",
      "exceptionDescription": "",
      "override": null,
      "patientID": "001",
      "patientName": "MICHAEL",
      "priority": 7
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "DF",
        "description": "",
        "key": "DF",
        "name": "DF",
        "value": ""
      },
      "controlDate": "2009-06-01T00:00:00-0402",
      "deferral": "MISC INFO:",
      "exceptionDescription": "GENERAL INFO: D5B84",
      "override": null,
      "patientID": "001",
      "patientName": "MICHAEL",
      "priority": 8
    },
    {
      "alertExceptionIndicator": true,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "CN",
        "description": "Processing Exception",
        "key": "CN",
        "name": "CN",
        "value": "Processing Exception"
      },
      "controlDate": "2012-09-01T00:00:00-0403",
      "deferral": "D5B84",
      "exceptionDescription": "Read processing exception on member\/family",
      "override": null,
      "patientID": "002",
      "patientName": "MARTHA",
      "priority": 9
    },
    {
      "alertExceptionIndicator": true,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "CM",
        "description": "Case Management",
        "key": "CM",
        "name": "CM",
        "value": "Case Management"
      },
      "controlDate": "2002-10-01T00:00:00-0404",
      "deferral": "",
      "exceptionDescription": "",
      "override": null,
      "patientID": "002",
      "patientName": "MARTHA",
      "priority": 10
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "DF",
        "description": "",
        "key": "DF",
        "name": "DF",
        "value": ""
      },
      "controlDate": "2012-09-01T00:00:00-0405",
      "deferral": "MISC INFO:",
      "exceptionDescription": "GENERAL INFO: D5B84",
      "override": null,
      "patientID": "002",
      "patientName": "MARTHA",
      "priority": 11
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "DP",
        "description": "",
        "key": "DP",
        "name": "DP",
        "value": ""
      },
      "controlDate": "2012-09-01T00:00:00-0406",
      "deferral": "MISC INFO:",
      "exceptionDescription": "GENERAL INFO: D5B84    K0001",
      "override": null,
      "patientID": "002",
      "patientName": "MARTHA",
      "priority": 12
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "DF",
        "description": "",
        "key": "DF",
        "name": "DF",
        "value": ""
      },
      "controlDate": "2012-09-01T00:00:00-0407",
      "deferral": "MISC INFO:",
      "exceptionDescription": "GENERAL INFO: D5B84",
      "override": null,
      "patientID": "002",
      "patientName": "MARTHA",
      "priority": 13
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "DP",
        "description": "",
        "key": "DP",
        "name": "DP",
        "value": ""
      },
      "controlDate": "2012-09-01T00:00:00-0408",
      "deferral": "MISC INFO:",
      "exceptionDescription": "GENERAL INFO: D5B84    E0601 E0601",
      "override": null,
      "patientID": "002",
      "patientName": "MARTHA",
      "priority": 14
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "DF",
        "description": "",
        "key": "DF",
        "name": "DF",
        "value": ""
      },
      "controlDate": "2012-09-01T00:00:00-0409",
      "deferral": "MISC INFO:",
      "exceptionDescription": "GENERAL INFO: D5B84",
      "override": null,
      "patientID": "002",
      "patientName": "MARTHA",
      "priority": 15
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "DP",
        "description": "",
        "key": "DP",
        "name": "DP",
        "value": ""
      },
      "controlDate": "2012-09-01T00:00:00-0410",
      "deferral": "MISC INFO:",
      "exceptionDescription": "GENERAL INFO: D5B84    E0562 E0562",
      "override": null,
      "patientID": "002",
      "patientName": "MARTHA",
      "priority": 16
    },
    {
      "alertExceptionIndicator": true,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "CN",
        "description": "Processing Exception",
        "key": "CN",
        "name": "CN",
        "value": "Processing Exception"
      },
      "controlDate": "2012-01-03T00:00:00-0501",
      "deferral": "D5B84",
      "exceptionDescription": "Read processing exception on member\/family",
      "override": null,
      "patientID": "003",
      "patientName": "TERRI",
      "priority": 17
    },
    {
      "alertExceptionIndicator": false,
      "contractLevelExceptionIndicator": false,
      "controlCode": {
        "code": "DF",
        "description": "",
        "key": "DF",
        "name": "DF",
        "value": ""
      },
      "controlDate": "2012-01-03T00:00:00-0502",
      "deferral": "MISC INFO:",
      "exceptionDescription": "GENERAL INFO: D5B84",
      "override": null,
      "patientID": "003",
      "patientName": "TERRI",
      "priority": 18
    }
  ]
