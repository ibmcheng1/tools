/* eslint-disable */
export const mockNavLinks = [  
    {  
       "altFunction":"",
       "category":"",
       "childLinks":[  
 
       ],
       "clientCode":"X",
       "comments":"GESU",
       "companyCode":"X",
       "departmentCode":"X",
       "divisionCode":"X",
       "functionId":"C00750",
       "functionType":"NAVLINK",
       "keyType":"",
       "keyValue":"",
       "linkAction":"H^GESU@E^GEMNEA",
       "linkDesc":"GROUP MAIN MENU (GESU)",
       "noteLine":"",
       "planCode":"",
       "regionId":"DVEST1",
       "regionType":"",
       "requestReason":"",
       "resolution":"",
       "rpn":"",
       "seq":1,
       "source":"",
       "subMenu":false,
       "subfunctionId":"L00396",
       "taskKey":"",
       "timestamp":""
    }
 ]