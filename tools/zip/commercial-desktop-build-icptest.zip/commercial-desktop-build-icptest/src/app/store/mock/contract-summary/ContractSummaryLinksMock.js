/* eslint-disable */
export const mockContractSummaryLinks = [
    {
        'name': 'coverage-period',
        'transaction-type': 'url',
        'transaction': 'http://lmgtfy.com'
    },
    {
        'name': 'display-service-center',
        'transaction-type': 'url',
        'transaction': 'http://google.com'
    },
    {
        'name': 'amms-group-lookup',
        'transaction-type': 'url',
        'transaction': 'http://google.com'
    },
    {
        'name': 'coordination-of-benefits',
        'transaction-type': 'url',
        'transaction': 'http://amazon.com'
    },
    {
        'name': 'memb-system',
        'transaction-type': 'url',
        'transaction': 'http://dogpile.com'
    },
    {
        'name': 'fep-member-info',
        'transaction-type': 'url',
        'transaction': 'http://yippy.com'
    },
    {
        'name': 'coverage-info',
        'transaction-type': 'url',
        'transaction': 'https://scholar.google.ca/'
    },
    {
        'name': 'benefit-period',
        'transaction-type': 'url',
        'transaction': 'https://www.webopedia.com/'
    }
]