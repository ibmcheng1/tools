/* eslint-disable */
export const mockNavLinkCategoriesMcs = 
{  
    "identifier":"id",
    "label":"description",
    "items":[  
       {  
          "id":"C00014-C00014",
          "type":"NAVCATEGORY",
          "description":"DOCUMENTS"
       },
       {  
          "id":"C00006-C00006",
          "type":"NAVCATEGORY",
          "description":"MAINTENANCE TRANSACTIONS"
       },
       {  
          "id":"C00036-C00036",
          "type":"NAVCATEGORY",
          "description":"OLD MEMBERSHIP SYSTEM"
       },
       {  
          "id":"C00016-C00016",
          "type":"NAVCATEGORY",
          "description":"RESEARCH HEALTH CLAIMS",
          "children":[  
             {  
                "id":"C00016-C00513",
                "type":"NAVCATEGORY",
                "description":"AMMS CLAIM SCREENS"
             }
          ]
       },
       {
          "id":"C00506-C00506",
          "type":"NAVCATEGORY",
          "description":"MANAGED CARE SYSTEM",
          "children":[  
             {  
                "id":"C00506-C00512",
                "type":"NAVCATEGORY",
                "description":"MEDICAL MANAGEMENT"
             }
          ]
       },
       {  
          "id":"C00503-C00503",
          "type":"NAVCATEGORY",
          "description":"INTERNAL REFERENCES"
       },
       {  
          "id":"C00504-C00504",
          "type":"NAVCATEGORY",
          "description":"WEB LINKS"
       },
       {  
          "id":"C00500-C00500",
          "type":"NAVCATEGORY",
          "description":"MEMBERSHIP & ELIGIBILITY"
       },
       {  
          "id":"C00035-C00035",
          "type":"NAVCATEGORY",
          "description":"BENEFITS"
       },
       {  
          "id":"C00009-C00009",
          "type":"NAVCATEGORY",
          "description":"PROVIDER DATA"
       },
       {  
          "id":"C00012-C00012",
          "type":"NAVCATEGORY",
          "description":"FEP"
       },
       {  
          "id":"C00505-C00505",
          "type":"NAVCATEGORY",
          "description":"LETTER GENERATION"
       },
       {  
          "id":"C00501-C00501",
          "type":"NAVCATEGORY",
          "description":"IMAGE RETRIEVAL"
       },
       {  
          "id":"C00509-C00509",
          "type":"NAVCATEGORY",
          "description":"PAI"
       },
       {  
          "id":"C00510-C00510",
          "type":"NAVCATEGORY",
          "description":"SECURITY"
       },
       {  
          "id":"C00034-C00034",
          "type":"NAVCATEGORY",
          "description":"SUBSCRIBER CROSS REFERENCE"
       },
       {  
          "id":"C00700-C00700",
          "type":"NAVCATEGORY",
          "description":"SUPPORT ACCESS"
       }
    ]
 }