/* eslint-disable */
export const mockSubscriberBillingSummary = {
    "billingInformation": {
        "abaRoutingNumber": "12345-6789",
        "accountsRecievableCreationDescription": "NO",
        "addressTypeCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "bankAccountName": "FIRST TEST BANK",
        "bankAccountNumber": "1234567890",
        "billFormatCode": {
            "code": "26",
            "description": "FULL BILL TO ALT STRUCTUR",
            "key": "26",
            "name": "26",
            "value": "FULL BILL TO ALT STRUCTUR"
        },
        "billModeCode": {
            "code": "03",
            "description": "SEMI ANNUALLY - 180 DAYS",
            "key": "03",
            "name": "03",
            "value": "SEMI ANNUALLY - 180 DAYS"
        },
        "billNumber": "036011100",
        "billingAgent": {
            "address": {
                "address1": null,
                "address2": null,
                "address3": null,
                "address4": null,
                "address5": null,
                "city": null,
                "country": null,
                "county": null,
                "countyCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "rpn": null,
                    "state": null,
                    "value": null
                },
                "province": null,
                "region": null,
                "state": null,
                "stateCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "zipcode": null,
                "zipcodePostFix": null
            },
            "agency": {
                "address": {
                    "address1": null,
                    "address2": null,
                    "address3": null,
                    "address4": null,
                    "address5": null,
                    "city": null,
                    "country": null,
                    "county": null,
                    "countyCode": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "rpn": null,
                        "state": null,
                        "value": null
                    },
                    "province": null,
                    "region": null,
                    "state": null,
                    "stateCode": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "zipcode": null,
                    "zipcodePostFix": null
                },
                "agent": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "id": null,
                "idCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "name": {
                    "firstName": null,
                    "lastName": null,
                    "middleName": null,
                    "prefixName": null,
                    "suffixName": null
                },
                "phone": {
                    "areaCode": null,
                    "extension": null,
                    "prefix": null,
                    "suffix": null,
                    "type": null
                }
            },
            "agentCode": null,
            "agentLookUpName": null,
            "agentLookupName": null,
            "authorizedForHSA": false,
            "id": null,
            "idCode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "individualHealthEffectiveDate": null,
            "individualHealthTermDate": null,
            "individualhealthStatus": null,
            "name": {
                "firstName": null,
                "lastName": null,
                "middleName": null,
                "prefixName": null,
                "suffixName": null
            },
            "phone": {
                "areaCode": null,
                "extension": null,
                "prefix": null,
                "suffix": null,
                "type": null
            }
        },
        "businessTypeCode": {
            "code": "ASO",
            "description": "ADMINISTRATIVE SERVICES O",
            "key": "ASO",
            "name": "ASO",
            "value": "ADMINISTRATIVE SERVICES O"
        },
        "clientNumber": "00006",
        "creditCardExpiration": "2008-10-01T00:00:00-0400",
        "creditCardNumber": "4013-1111-2222-3333",
        "currentBalance": 55.22,
        "delinquencyStatus": true,
        "dueDate": "2008-10-01T00:00:00-0400",
        "dueDay": "01",
        "groupName": "TEST SPECIAL PROJECTS AREA",
        "groupNumber": "0004352",
        "groupPolicy": true,
        "hasCoveragePeriods": true,
        "lastPayment": 34.56,
        "lastPaymentReceivedDate": "2008-10-01T00:00:00-0400",
        "listBillAccountNumber": 'ACC12345',
        "listBillContactName": "ACCOUNTS BILLTEST",
        "listBillName": 'BCBSSC',
        "listBillNumber": "000000000",
        "listBillPhoneNumber": {
            "areaCode": null,
            "extension": null,
            "prefix": null,
            "suffix": null,
            "type": null
        },
        "masterARNumber": "036011100",
        "outputTypeCode": {
            "code": "06",
            "description": "WEB & PAPER",
            "key": "06",
            "name": "06",
            "value": "WEB & PAPER"
        },
        "paymentMethodCode": {
            "code": "01",
            "description": "CHECK",
            "key": "01",
            "name": "01",
            "value": "CHECK"
        },
        "paymentSummaryNumber": "12345",
        "reportIdentifier": "PVTBBILL",
        "sortCode": {
            "code": null,
            "description": "SORT BY DEPARTMENTS IN AL",
            "key": null,
            "name": null,
            "value": "SORT BY DEPARTMENTS IN AL"
        },
        "statementCreatedDate": "2008-09-17T00:00:00-0400",
        "suppressDescription": "NO"
    },
    "billingInformationLoaded": true,
    "dynaSubscriber": {
        "PAI": false,
        "activeDate": null,
        "activelyCovered": false,
        "address": {
            "address1": "ANY TOWN",
            "address2": "",
            "address3": null,
            "address4": null,
            "address5": null,
            "city": "COLUMBIA",
            "country": null,
            "county": "999",
            "countyCode": {
                "code": "999",
                "description": null,
                "key": "999",
                "name": "999",
                "rpn": null,
                "state": null,
                "value": null
            },
            "province": null,
            "region": null,
            "state": "SC",
            "stateCode": {
                "code": "SC",
                "description": null,
                "key": "SC",
                "name": "SC",
                "value": null
            },
            "zipcode": "29223",
            "zipcodePostFix": "0000"
        },
        "alphaPrefix": "ZCA",
        "ammsGroupNumber": "036033500",
        "bill": {
            "amountReceivable": null,
            "arHistoryIndicator": null,
            "balanceAmount": null,
            "billFormat": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "billNumber": null,
            "billedDate": null,
            "billingFrequency": null,
            "clientNumber": null,
            "createARIndicator": null,
            "creationDate": null,
            "dueDate": null,
            "dueDay": null,
            "employeeListIndicator": null,
            "lastPaymentAmount": null,
            "lastPaymentDate": null,
            "listBillAccountNumber": null,
            "masterARNumber": null,
            "mode": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "outputType": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "paymentMethod": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "paymentSummary": null,
            "providerId": null,
            "reasonCode": null,
            "recordCode": null,
            "renderTime": null,
            "serviceId": null,
            "sort": {
                "code": null,
                "description": null,
                "key": null,
                "name": null,
                "value": null
            },
            "supressBillIndicator": null,
            "viewStatementIndicator": null
        },
        "birthdate": "10/01/1958",
        "businessSector": "xxx",
        "carrierName": "",
        "carrierRestricted": false,
        "ces": true,
        "cesExceptionIndicator": true,
        "cesGroupNumber": "0004352",
        "cisiRpn": "001",
        "clientCode": {
            "code": "00006",
            "description": "TEST SPECIAL PROJECTS AREA",
            "key": "00006",
            "name": "00006",
            "value": "TEST SPECIAL PROJECTS AREA"
        },
        "coverage": null,
        "coverageContinuationTypeCode": {
            "code": "",
            "description": null,
            "key": "",
            "name": "",
            "value": null
        },
        "coverageItems": [
            {
                "active": true,
                "benefitSystem": "OLD",
                "coverageId": {
                    "benefitLevel": "001",
                    "coverageLevelCode": "C",
                    "coverageNumber": "0000006",
                    "productCode": "Products.DENTAL"
                },
                "drugProcessingCode": {
                    "code": "",
                    "description": null,
                    "key": "",
                    "name": "",
                    "value": null
                },
                "effectiveDate": "2008-11-01T00:00:00-0400",
                "group": {
                    "address": {
                        "address1": null,
                        "address2": null,
                        "address3": null,
                        "address4": null,
                        "address5": null,
                        "city": null,
                        "country": null,
                        "county": null,
                        "countyCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "rpn": null,
                            "state": null,
                            "value": null
                        },
                        "province": null,
                        "region": null,
                        "state": null,
                        "stateCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "zipcode": null,
                        "zipcodePostFix": null
                    },
                    "agency": null,
                    "anniversaryDate": null,
                    "benefitSystem": null,
                    "billDueDate": null,
                    "billingAgencyCode": null,
                    "billingAgentCode": null,
                    "cancelCode": null,
                    "cancelReasonCode": null,
                    "clientContribution": null,
                    "clientDescription": null,
                    "clientNumber": null,
                    "clientServiceCenterCode": null,
                    "contactInformation": null,
                    "contactName": null,
                    "contractRule": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "contractTypes": null,
                    "coverageEffectiveDate": null,
                    "coverages": null,
                    "dateBegin": null,
                    "dateEnd": null,
                    "departments": null,
                    "drugOptionCode": null,
                    "effectiveDate": null,
                    "fax": {
                        "areaCode": null,
                        "extension": null,
                        "prefix": null,
                        "suffix": null,
                        "type": null
                    },
                    "groupCoverageBeginDate": null,
                    "groupCoverageTermDate": null,
                    "groupDescription": null,
                    "groupLeader": null,
                    "groupName": null,
                    "groupNumberAmms": null,
                    "groupNumberCes": null,
                    "groupType": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "id": "0004352",
                    "idCardType": null,
                    "idCode": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "lastBillAmount": null,
                    "lastBillDate": null,
                    "maintenenceDate": null,
                    "masterARNumber": null,
                    "masterCoverageRateBegin": null,
                    "masterCoverageRateEnd": null,
                    "name": {
                        "firstName": null,
                        "lastName": null,
                        "middleName": null,
                        "prefixName": null,
                        "suffixName": null
                    },
                    "outputRules": null,
                    "paymentSummaryNumber": null,
                    "phone": {
                        "areaCode": null,
                        "extension": null,
                        "prefix": null,
                        "suffix": null,
                        "type": null
                    },
                    "probationaryPeriods": null,
                    "productRule": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "ratingCounty": null,
                    "rpn": null,
                    "salesRepresentative": {
                        "address": {
                            "address1": null,
                            "address2": null,
                            "address3": null,
                            "address4": null,
                            "address5": null,
                            "city": null,
                            "country": null,
                            "county": null,
                            "countyCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "rpn": null,
                                "state": null,
                                "value": null
                            },
                            "province": null,
                            "region": null,
                            "state": null,
                            "stateCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "value": null
                            },
                            "zipcode": null,
                            "zipcodePostFix": null
                        },
                        "id": null,
                        "idCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "name": {
                            "firstName": null,
                            "lastName": null,
                            "middleName": null,
                            "prefixName": null,
                            "suffixName": null
                        },
                        "phone": {
                            "areaCode": null,
                            "extension": null,
                            "prefix": null,
                            "suffix": null,
                            "type": null
                        },
                        "representative": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        }
                    },
                    "serviceRepresentative": {
                        "address": {
                            "address1": null,
                            "address2": null,
                            "address3": null,
                            "address4": null,
                            "address5": null,
                            "city": null,
                            "country": null,
                            "county": null,
                            "countyCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "rpn": null,
                                "state": null,
                                "value": null
                            },
                            "province": null,
                            "region": null,
                            "state": null,
                            "stateCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "value": null
                            },
                            "zipcode": null,
                            "zipcodePostFix": null
                        },
                        "id": null,
                        "idCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "name": {
                            "firstName": null,
                            "lastName": null,
                            "middleName": null,
                            "prefixName": null,
                            "suffixName": null
                        },
                        "phone": {
                            "areaCode": null,
                            "extension": null,
                            "prefix": null,
                            "suffix": null,
                            "type": null
                        },
                        "representative": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        }
                    },
                    "sicCode": null,
                    "specialHandling": null,
                    "statusDescription": null,
                    "subClientDescription": null,
                    "subClientNumber": null,
                    "terminationDate": null
                },
                "listBillIndicator": "",
                "majorMedicalWaiverCode": {
                    "code": "",
                    "description": null,
                    "key": "",
                    "name": "",
                    "value": null
                },
                "memberId": null,
                "oldGroup": {
                    "address": {
                        "address1": null,
                        "address2": null,
                        "address3": null,
                        "address4": null,
                        "address5": null,
                        "city": null,
                        "country": null,
                        "county": null,
                        "countyCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "rpn": null,
                            "state": null,
                            "value": null
                        },
                        "province": null,
                        "region": null,
                        "state": null,
                        "stateCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "zipcode": null,
                        "zipcodePostFix": null
                    },
                    "agency": null,
                    "anniversaryDate": null,
                    "benefitSystem": null,
                    "billDueDate": null,
                    "billingAgencyCode": null,
                    "billingAgentCode": null,
                    "cancelCode": null,
                    "cancelReasonCode": null,
                    "clientContribution": null,
                    "clientDescription": null,
                    "clientNumber": null,
                    "clientServiceCenterCode": null,
                    "contactInformation": null,
                    "contactName": null,
                    "contractRule": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "contractTypes": null,
                    "coverageEffectiveDate": null,
                    "coverages": null,
                    "dateBegin": null,
                    "dateEnd": null,
                    "departments": null,
                    "drugOptionCode": null,
                    "effectiveDate": null,
                    "fax": {
                        "areaCode": null,
                        "extension": null,
                        "prefix": null,
                        "suffix": null,
                        "type": null
                    },
                    "groupCoverageBeginDate": null,
                    "groupCoverageTermDate": null,
                    "groupDescription": null,
                    "groupLeader": null,
                    "groupName": null,
                    "groupNumberAmms": null,
                    "groupNumberCes": null,
                    "groupType": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "id": "036033500",
                    "idCardType": null,
                    "idCode": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "lastBillAmount": null,
                    "lastBillDate": null,
                    "maintenenceDate": null,
                    "masterARNumber": null,
                    "masterCoverageRateBegin": null,
                    "masterCoverageRateEnd": null,
                    "name": {
                        "firstName": null,
                        "lastName": null,
                        "middleName": null,
                        "prefixName": null,
                        "suffixName": null
                    },
                    "outputRules": null,
                    "paymentSummaryNumber": null,
                    "phone": {
                        "areaCode": null,
                        "extension": null,
                        "prefix": null,
                        "suffix": null,
                        "type": null
                    },
                    "probationaryPeriods": null,
                    "productRule": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "ratingCounty": null,
                    "rpn": null,
                    "salesRepresentative": {
                        "address": {
                            "address1": null,
                            "address2": null,
                            "address3": null,
                            "address4": null,
                            "address5": null,
                            "city": null,
                            "country": null,
                            "county": null,
                            "countyCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "rpn": null,
                                "state": null,
                                "value": null
                            },
                            "province": null,
                            "region": null,
                            "state": null,
                            "stateCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "value": null
                            },
                            "zipcode": null,
                            "zipcodePostFix": null
                        },
                        "id": null,
                        "idCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "name": {
                            "firstName": null,
                            "lastName": null,
                            "middleName": null,
                            "prefixName": null,
                            "suffixName": null
                        },
                        "phone": {
                            "areaCode": null,
                            "extension": null,
                            "prefix": null,
                            "suffix": null,
                            "type": null
                        },
                        "representative": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        }
                    },
                    "serviceRepresentative": {
                        "address": {
                            "address1": null,
                            "address2": null,
                            "address3": null,
                            "address4": null,
                            "address5": null,
                            "city": null,
                            "country": null,
                            "county": null,
                            "countyCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "rpn": null,
                                "state": null,
                                "value": null
                            },
                            "province": null,
                            "region": null,
                            "state": null,
                            "stateCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "value": null
                            },
                            "zipcode": null,
                            "zipcodePostFix": null
                        },
                        "id": null,
                        "idCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "name": {
                            "firstName": null,
                            "lastName": null,
                            "middleName": null,
                            "prefixName": null,
                            "suffixName": null
                        },
                        "phone": {
                            "areaCode": null,
                            "extension": null,
                            "prefix": null,
                            "suffix": null,
                            "type": null
                        },
                        "representative": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        }
                    },
                    "sicCode": null,
                    "specialHandling": null,
                    "statusDescription": null,
                    "subClientDescription": null,
                    "subClientNumber": null,
                    "terminationDate": null
                },
                "periods": null,
                "serviceCenter": "AAA",
                "type": null
            },
            {
                "active": false,
                "benefitSystem": null,
                "coverageId": {
                    "benefitLevel": "001",
                    "coverageLevelCode": "C",
                    "coverageNumber": "0000006",
                    "productCode": "Products.MEDICAL"
                },
                "drugProcessingCode": {
                    "code": "",
                    "description": null,
                    "key": "",
                    "name": "",
                    "value": null
                },
                "effectiveDate": "2002-09-01T00:00:00-0400",
                "group": {
                    "address": {
                        "address1": null,
                        "address2": null,
                        "address3": null,
                        "address4": null,
                        "address5": null,
                        "city": null,
                        "country": null,
                        "county": null,
                        "countyCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "rpn": null,
                            "state": null,
                            "value": null
                        },
                        "province": null,
                        "region": null,
                        "state": null,
                        "stateCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "zipcode": null,
                        "zipcodePostFix": null
                    },
                    "agency": null,
                    "anniversaryDate": null,
                    "benefitSystem": null,
                    "billDueDate": null,
                    "billingAgencyCode": null,
                    "billingAgentCode": null,
                    "cancelCode": null,
                    "cancelReasonCode": null,
                    "clientContribution": null,
                    "clientDescription": null,
                    "clientNumber": null,
                    "clientServiceCenterCode": null,
                    "contactInformation": null,
                    "contactName": null,
                    "contractRule": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "contractTypes": null,
                    "coverageEffectiveDate": null,
                    "coverages": null,
                    "dateBegin": null,
                    "dateEnd": null,
                    "departments": null,
                    "drugOptionCode": null,
                    "effectiveDate": null,
                    "fax": {
                        "areaCode": null,
                        "extension": null,
                        "prefix": null,
                        "suffix": null,
                        "type": null
                    },
                    "groupCoverageBeginDate": null,
                    "groupCoverageTermDate": null,
                    "groupDescription": null,
                    "groupLeader": null,
                    "groupName": null,
                    "groupNumberAmms": null,
                    "groupNumberCes": null,
                    "groupType": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "id": "0000667",
                    "idCardType": null,
                    "idCode": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "lastBillAmount": null,
                    "lastBillDate": null,
                    "maintenenceDate": null,
                    "masterARNumber": null,
                    "masterCoverageRateBegin": null,
                    "masterCoverageRateEnd": null,
                    "name": {
                        "firstName": null,
                        "lastName": null,
                        "middleName": null,
                        "prefixName": null,
                        "suffixName": null
                    },
                    "outputRules": null,
                    "paymentSummaryNumber": null,
                    "phone": {
                        "areaCode": null,
                        "extension": null,
                        "prefix": null,
                        "suffix": null,
                        "type": null
                    },
                    "probationaryPeriods": null,
                    "productRule": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "ratingCounty": null,
                    "rpn": null,
                    "salesRepresentative": {
                        "address": {
                            "address1": null,
                            "address2": null,
                            "address3": null,
                            "address4": null,
                            "address5": null,
                            "city": null,
                            "country": null,
                            "county": null,
                            "countyCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "rpn": null,
                                "state": null,
                                "value": null
                            },
                            "province": null,
                            "region": null,
                            "state": null,
                            "stateCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "value": null
                            },
                            "zipcode": null,
                            "zipcodePostFix": null
                        },
                        "id": null,
                        "idCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "name": {
                            "firstName": null,
                            "lastName": null,
                            "middleName": null,
                            "prefixName": null,
                            "suffixName": null
                        },
                        "phone": {
                            "areaCode": null,
                            "extension": null,
                            "prefix": null,
                            "suffix": null,
                            "type": null
                        },
                        "representative": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        }
                    },
                    "serviceRepresentative": {
                        "address": {
                            "address1": null,
                            "address2": null,
                            "address3": null,
                            "address4": null,
                            "address5": null,
                            "city": null,
                            "country": null,
                            "county": null,
                            "countyCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "rpn": null,
                                "state": null,
                                "value": null
                            },
                            "province": null,
                            "region": null,
                            "state": null,
                            "stateCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "value": null
                            },
                            "zipcode": null,
                            "zipcodePostFix": null
                        },
                        "id": null,
                        "idCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "name": {
                            "firstName": null,
                            "lastName": null,
                            "middleName": null,
                            "prefixName": null,
                            "suffixName": null
                        },
                        "phone": {
                            "areaCode": null,
                            "extension": null,
                            "prefix": null,
                            "suffix": null,
                            "type": null
                        },
                        "representative": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        }
                    },
                    "sicCode": null,
                    "specialHandling": null,
                    "statusDescription": null,
                    "subClientDescription": null,
                    "subClientNumber": null,
                    "terminationDate": null
                },
                "listBillIndicator": "",
                "majorMedicalWaiverCode": {
                    "code": "",
                    "description": null,
                    "key": "",
                    "name": "",
                    "value": null
                },
                "memberId": null,
                "oldGroup": {
                    "address": {
                        "address1": null,
                        "address2": null,
                        "address3": null,
                        "address4": null,
                        "address5": null,
                        "city": null,
                        "country": null,
                        "county": null,
                        "countyCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "rpn": null,
                            "state": null,
                            "value": null
                        },
                        "province": null,
                        "region": null,
                        "state": null,
                        "stateCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "zipcode": null,
                        "zipcodePostFix": null
                    },
                    "agency": null,
                    "anniversaryDate": null,
                    "benefitSystem": null,
                    "billDueDate": null,
                    "billingAgencyCode": null,
                    "billingAgentCode": null,
                    "cancelCode": null,
                    "cancelReasonCode": null,
                    "clientContribution": null,
                    "clientDescription": null,
                    "clientNumber": null,
                    "clientServiceCenterCode": null,
                    "contactInformation": null,
                    "contactName": null,
                    "contractRule": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "contractTypes": null,
                    "coverageEffectiveDate": null,
                    "coverages": null,
                    "dateBegin": null,
                    "dateEnd": null,
                    "departments": null,
                    "drugOptionCode": null,
                    "effectiveDate": null,
                    "fax": {
                        "areaCode": null,
                        "extension": null,
                        "prefix": null,
                        "suffix": null,
                        "type": null
                    },
                    "groupCoverageBeginDate": null,
                    "groupCoverageTermDate": null,
                    "groupDescription": null,
                    "groupLeader": null,
                    "groupName": null,
                    "groupNumberAmms": null,
                    "groupNumberCes": null,
                    "groupType": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "id": "036011101",
                    "idCardType": null,
                    "idCode": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "lastBillAmount": null,
                    "lastBillDate": null,
                    "maintenenceDate": null,
                    "masterARNumber": null,
                    "masterCoverageRateBegin": null,
                    "masterCoverageRateEnd": null,
                    "name": {
                        "firstName": null,
                        "lastName": null,
                        "middleName": null,
                        "prefixName": null,
                        "suffixName": null
                    },
                    "outputRules": null,
                    "paymentSummaryNumber": null,
                    "phone": {
                        "areaCode": null,
                        "extension": null,
                        "prefix": null,
                        "suffix": null,
                        "type": null
                    },
                    "probationaryPeriods": null,
                    "productRule": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "ratingCounty": null,
                    "rpn": null,
                    "salesRepresentative": {
                        "address": {
                            "address1": null,
                            "address2": null,
                            "address3": null,
                            "address4": null,
                            "address5": null,
                            "city": null,
                            "country": null,
                            "county": null,
                            "countyCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "rpn": null,
                                "state": null,
                                "value": null
                            },
                            "province": null,
                            "region": null,
                            "state": null,
                            "stateCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "value": null
                            },
                            "zipcode": null,
                            "zipcodePostFix": null
                        },
                        "id": null,
                        "idCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "name": {
                            "firstName": null,
                            "lastName": null,
                            "middleName": null,
                            "prefixName": null,
                            "suffixName": null
                        },
                        "phone": {
                            "areaCode": null,
                            "extension": null,
                            "prefix": null,
                            "suffix": null,
                            "type": null
                        },
                        "representative": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        }
                    },
                    "serviceRepresentative": {
                        "address": {
                            "address1": null,
                            "address2": null,
                            "address3": null,
                            "address4": null,
                            "address5": null,
                            "city": null,
                            "country": null,
                            "county": null,
                            "countyCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "rpn": null,
                                "state": null,
                                "value": null
                            },
                            "province": null,
                            "region": null,
                            "state": null,
                            "stateCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "value": null
                            },
                            "zipcode": null,
                            "zipcodePostFix": null
                        },
                        "id": null,
                        "idCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "name": {
                            "firstName": null,
                            "lastName": null,
                            "middleName": null,
                            "prefixName": null,
                            "suffixName": null
                        },
                        "phone": {
                            "areaCode": null,
                            "extension": null,
                            "prefix": null,
                            "suffix": null,
                            "type": null
                        },
                        "representative": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        }
                    },
                    "sicCode": null,
                    "specialHandling": null,
                    "statusDescription": null,
                    "subClientDescription": null,
                    "subClientNumber": null,
                    "terminationDate": null
                },
                "periods": null,
                "serviceCenter": "B01",
                "type": null
            },
            {
                "active": false,
                "benefitSystem": null,
                "coverageId": {
                    "benefitLevel": "001",
                    "coverageLevelCode": "C",
                    "coverageNumber": "0000006",
                    "productCode": "Products.MEDICAL"
                },
                "drugProcessingCode": {
                    "code": "",
                    "description": null,
                    "key": "",
                    "name": "",
                    "value": null
                },
                "effectiveDate": "2002-08-01T00:00:00-0400",
                "group": {
                    "address": {
                        "address1": null,
                        "address2": null,
                        "address3": null,
                        "address4": null,
                        "address5": null,
                        "city": null,
                        "country": null,
                        "county": null,
                        "countyCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "rpn": null,
                            "state": null,
                            "value": null
                        },
                        "province": null,
                        "region": null,
                        "state": null,
                        "stateCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "zipcode": null,
                        "zipcodePostFix": null
                    },
                    "agency": null,
                    "anniversaryDate": null,
                    "benefitSystem": null,
                    "billDueDate": null,
                    "billingAgencyCode": null,
                    "billingAgentCode": null,
                    "cancelCode": null,
                    "cancelReasonCode": null,
                    "clientContribution": null,
                    "clientDescription": null,
                    "clientNumber": null,
                    "clientServiceCenterCode": null,
                    "contactInformation": null,
                    "contactName": null,
                    "contractRule": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "contractTypes": null,
                    "coverageEffectiveDate": null,
                    "coverages": null,
                    "dateBegin": null,
                    "dateEnd": null,
                    "departments": null,
                    "drugOptionCode": null,
                    "effectiveDate": null,
                    "fax": {
                        "areaCode": null,
                        "extension": null,
                        "prefix": null,
                        "suffix": null,
                        "type": null
                    },
                    "groupCoverageBeginDate": null,
                    "groupCoverageTermDate": null,
                    "groupDescription": null,
                    "groupLeader": null,
                    "groupName": null,
                    "groupNumberAmms": null,
                    "groupNumberCes": null,
                    "groupType": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "id": "0000667",
                    "idCardType": null,
                    "idCode": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "lastBillAmount": null,
                    "lastBillDate": null,
                    "maintenenceDate": null,
                    "masterARNumber": null,
                    "masterCoverageRateBegin": null,
                    "masterCoverageRateEnd": null,
                    "name": {
                        "firstName": null,
                        "lastName": null,
                        "middleName": null,
                        "prefixName": null,
                        "suffixName": null
                    },
                    "outputRules": null,
                    "paymentSummaryNumber": null,
                    "phone": {
                        "areaCode": null,
                        "extension": null,
                        "prefix": null,
                        "suffix": null,
                        "type": null
                    },
                    "probationaryPeriods": null,
                    "productRule": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "ratingCounty": null,
                    "rpn": null,
                    "salesRepresentative": {
                        "address": {
                            "address1": null,
                            "address2": null,
                            "address3": null,
                            "address4": null,
                            "address5": null,
                            "city": null,
                            "country": null,
                            "county": null,
                            "countyCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "rpn": null,
                                "state": null,
                                "value": null
                            },
                            "province": null,
                            "region": null,
                            "state": null,
                            "stateCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "value": null
                            },
                            "zipcode": null,
                            "zipcodePostFix": null
                        },
                        "id": null,
                        "idCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "name": {
                            "firstName": null,
                            "lastName": null,
                            "middleName": null,
                            "prefixName": null,
                            "suffixName": null
                        },
                        "phone": {
                            "areaCode": null,
                            "extension": null,
                            "prefix": null,
                            "suffix": null,
                            "type": null
                        },
                        "representative": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        }
                    },
                    "serviceRepresentative": {
                        "address": {
                            "address1": null,
                            "address2": null,
                            "address3": null,
                            "address4": null,
                            "address5": null,
                            "city": null,
                            "country": null,
                            "county": null,
                            "countyCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "rpn": null,
                                "state": null,
                                "value": null
                            },
                            "province": null,
                            "region": null,
                            "state": null,
                            "stateCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "value": null
                            },
                            "zipcode": null,
                            "zipcodePostFix": null
                        },
                        "id": null,
                        "idCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "name": {
                            "firstName": null,
                            "lastName": null,
                            "middleName": null,
                            "prefixName": null,
                            "suffixName": null
                        },
                        "phone": {
                            "areaCode": null,
                            "extension": null,
                            "prefix": null,
                            "suffix": null,
                            "type": null
                        },
                        "representative": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        }
                    },
                    "sicCode": null,
                    "specialHandling": null,
                    "statusDescription": null,
                    "subClientDescription": null,
                    "subClientNumber": null,
                    "terminationDate": null
                },
                "listBillIndicator": "",
                "majorMedicalWaiverCode": {
                    "code": "",
                    "description": null,
                    "key": "",
                    "name": "",
                    "value": null
                },
                "memberId": null,
                "oldGroup": {
                    "address": {
                        "address1": null,
                        "address2": null,
                        "address3": null,
                        "address4": null,
                        "address5": null,
                        "city": null,
                        "country": null,
                        "county": null,
                        "countyCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "rpn": null,
                            "state": null,
                            "value": null
                        },
                        "province": null,
                        "region": null,
                        "state": null,
                        "stateCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "zipcode": null,
                        "zipcodePostFix": null
                    },
                    "agency": null,
                    "anniversaryDate": null,
                    "benefitSystem": null,
                    "billDueDate": null,
                    "billingAgencyCode": null,
                    "billingAgentCode": null,
                    "cancelCode": null,
                    "cancelReasonCode": null,
                    "clientContribution": null,
                    "clientDescription": null,
                    "clientNumber": null,
                    "clientServiceCenterCode": null,
                    "contactInformation": null,
                    "contactName": null,
                    "contractRule": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "contractTypes": null,
                    "coverageEffectiveDate": null,
                    "coverages": null,
                    "dateBegin": null,
                    "dateEnd": null,
                    "departments": null,
                    "drugOptionCode": null,
                    "effectiveDate": null,
                    "fax": {
                        "areaCode": null,
                        "extension": null,
                        "prefix": null,
                        "suffix": null,
                        "type": null
                    },
                    "groupCoverageBeginDate": null,
                    "groupCoverageTermDate": null,
                    "groupDescription": null,
                    "groupLeader": null,
                    "groupName": null,
                    "groupNumberAmms": null,
                    "groupNumberCes": null,
                    "groupType": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "id": "036011101",
                    "idCardType": null,
                    "idCode": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "lastBillAmount": null,
                    "lastBillDate": null,
                    "maintenenceDate": null,
                    "masterARNumber": null,
                    "masterCoverageRateBegin": null,
                    "masterCoverageRateEnd": null,
                    "name": {
                        "firstName": null,
                        "lastName": null,
                        "middleName": null,
                        "prefixName": null,
                        "suffixName": null
                    },
                    "outputRules": null,
                    "paymentSummaryNumber": null,
                    "phone": {
                        "areaCode": null,
                        "extension": null,
                        "prefix": null,
                        "suffix": null,
                        "type": null
                    },
                    "probationaryPeriods": null,
                    "productRule": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "ratingCounty": null,
                    "rpn": null,
                    "salesRepresentative": {
                        "address": {
                            "address1": null,
                            "address2": null,
                            "address3": null,
                            "address4": null,
                            "address5": null,
                            "city": null,
                            "country": null,
                            "county": null,
                            "countyCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "rpn": null,
                                "state": null,
                                "value": null
                            },
                            "province": null,
                            "region": null,
                            "state": null,
                            "stateCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "value": null
                            },
                            "zipcode": null,
                            "zipcodePostFix": null
                        },
                        "id": null,
                        "idCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "name": {
                            "firstName": null,
                            "lastName": null,
                            "middleName": null,
                            "prefixName": null,
                            "suffixName": null
                        },
                        "phone": {
                            "areaCode": null,
                            "extension": null,
                            "prefix": null,
                            "suffix": null,
                            "type": null
                        },
                        "representative": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        }
                    },
                    "serviceRepresentative": {
                        "address": {
                            "address1": null,
                            "address2": null,
                            "address3": null,
                            "address4": null,
                            "address5": null,
                            "city": null,
                            "country": null,
                            "county": null,
                            "countyCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "rpn": null,
                                "state": null,
                                "value": null
                            },
                            "province": null,
                            "region": null,
                            "state": null,
                            "stateCode": {
                                "code": null,
                                "description": null,
                                "key": null,
                                "name": null,
                                "value": null
                            },
                            "zipcode": null,
                            "zipcodePostFix": null
                        },
                        "id": null,
                        "idCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "name": {
                            "firstName": null,
                            "lastName": null,
                            "middleName": null,
                            "prefixName": null,
                            "suffixName": null
                        },
                        "phone": {
                            "areaCode": null,
                            "extension": null,
                            "prefix": null,
                            "suffix": null,
                            "type": null
                        },
                        "representative": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        }
                    },
                    "sicCode": null,
                    "specialHandling": null,
                    "statusDescription": null,
                    "subClientDescription": null,
                    "subClientNumber": null,
                    "terminationDate": null
                },
                "periods": null,
                "serviceCenter": "B01",
                "type": null
            }
        ],
        "databaseNumber": "999574313",
        "dateOfBirth": "1958-10-01T00:00:00-0400",
        "drugIndicator": "",
        "employeeStatus": null,
        "engagementMemberRecords": null,
        "eobRecipient": "",
        "exceptionIndicator": false,
        "extraPhoneNumbers": [],
        "fep": false,
        "formatNumber": null,
        "groupNumberCheckDigit": "",
        "groupPrefix": "GROUP - MAJOR",
        "hireDate": null,
        "id": "999574313",
        "idCardNumber": "052407747116",
        "idCode": {
            "code": null,
            "description": null,
            "key": null,
            "name": null,
            "value": null
        },
        "isMobileNotificationsEnabledForGroup": null,
        "lastIdCardDate": null,
        "lastIdCardIssueDate": "2008-09-29T00:00:00-0400",
        "latestCoverage": {
            "active": true,
            "benefitSystem": "OLD",
            "coverageId": {
                "benefitLevel": "001",
                "coverageLevelCode": "C",
                "coverageNumber": "0000006",
                "productCode": "Products.DENTAL"
            },
            "drugProcessingCode": {
                "code": "",
                "description": null,
                "key": "",
                "name": "",
                "value": null
            },
            "effectiveDate": "2008-11-01T00:00:00-0400",
            "group": {
                "address": {
                    "address1": null,
                    "address2": null,
                    "address3": null,
                    "address4": null,
                    "address5": null,
                    "city": null,
                    "country": null,
                    "county": null,
                    "countyCode": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "rpn": null,
                        "state": null,
                        "value": null
                    },
                    "province": null,
                    "region": null,
                    "state": null,
                    "stateCode": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "zipcode": null,
                    "zipcodePostFix": null
                },
                "agency": null,
                "anniversaryDate": null,
                "benefitSystem": null,
                "billDueDate": null,
                "billingAgencyCode": null,
                "billingAgentCode": null,
                "cancelCode": null,
                "cancelReasonCode": null,
                "clientContribution": null,
                "clientDescription": null,
                "clientNumber": null,
                "clientServiceCenterCode": null,
                "contactInformation": null,
                "contactName": null,
                "contractRule": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "contractTypes": null,
                "coverageEffectiveDate": null,
                "coverages": null,
                "dateBegin": null,
                "dateEnd": null,
                "departments": null,
                "drugOptionCode": null,
                "effectiveDate": null,
                "fax": {
                    "areaCode": null,
                    "extension": null,
                    "prefix": null,
                    "suffix": null,
                    "type": null
                },
                "groupCoverageBeginDate": null,
                "groupCoverageTermDate": null,
                "groupDescription": null,
                "groupLeader": null,
                "groupName": null,
                "groupNumberAmms": null,
                "groupNumberCes": null,
                "groupType": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "id": "0004352",
                "idCardType": null,
                "idCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "lastBillAmount": null,
                "lastBillDate": null,
                "maintenenceDate": null,
                "masterARNumber": null,
                "masterCoverageRateBegin": null,
                "masterCoverageRateEnd": null,
                "name": {
                    "firstName": null,
                    "lastName": null,
                    "middleName": null,
                    "prefixName": null,
                    "suffixName": null
                },
                "outputRules": null,
                "paymentSummaryNumber": null,
                "phone": {
                    "areaCode": null,
                    "extension": null,
                    "prefix": null,
                    "suffix": null,
                    "type": null
                },
                "probationaryPeriods": null,
                "productRule": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "ratingCounty": null,
                "rpn": null,
                "salesRepresentative": {
                    "address": {
                        "address1": null,
                        "address2": null,
                        "address3": null,
                        "address4": null,
                        "address5": null,
                        "city": null,
                        "country": null,
                        "county": null,
                        "countyCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "rpn": null,
                            "state": null,
                            "value": null
                        },
                        "province": null,
                        "region": null,
                        "state": null,
                        "stateCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "zipcode": null,
                        "zipcodePostFix": null
                    },
                    "id": null,
                    "idCode": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "name": {
                        "firstName": null,
                        "lastName": null,
                        "middleName": null,
                        "prefixName": null,
                        "suffixName": null
                    },
                    "phone": {
                        "areaCode": null,
                        "extension": null,
                        "prefix": null,
                        "suffix": null,
                        "type": null
                    },
                    "representative": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    }
                },
                "serviceRepresentative": {
                    "address": {
                        "address1": null,
                        "address2": null,
                        "address3": null,
                        "address4": null,
                        "address5": null,
                        "city": null,
                        "country": null,
                        "county": null,
                        "countyCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "rpn": null,
                            "state": null,
                            "value": null
                        },
                        "province": null,
                        "region": null,
                        "state": null,
                        "stateCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "zipcode": null,
                        "zipcodePostFix": null
                    },
                    "id": null,
                    "idCode": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "name": {
                        "firstName": null,
                        "lastName": null,
                        "middleName": null,
                        "prefixName": null,
                        "suffixName": null
                    },
                    "phone": {
                        "areaCode": null,
                        "extension": null,
                        "prefix": null,
                        "suffix": null,
                        "type": null
                    },
                    "representative": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    }
                },
                "sicCode": null,
                "specialHandling": null,
                "statusDescription": null,
                "subClientDescription": null,
                "subClientNumber": null,
                "terminationDate": null
            },
            "listBillIndicator": "",
            "majorMedicalWaiverCode": {
                "code": "",
                "description": null,
                "key": "",
                "name": "",
                "value": null
            },
            "memberId": null,
            "oldGroup": {
                "address": {
                    "address1": null,
                    "address2": null,
                    "address3": null,
                    "address4": null,
                    "address5": null,
                    "city": null,
                    "country": null,
                    "county": null,
                    "countyCode": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "rpn": null,
                        "state": null,
                        "value": null
                    },
                    "province": null,
                    "region": null,
                    "state": null,
                    "stateCode": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "zipcode": null,
                    "zipcodePostFix": null
                },
                "agency": null,
                "anniversaryDate": null,
                "benefitSystem": null,
                "billDueDate": null,
                "billingAgencyCode": null,
                "billingAgentCode": null,
                "cancelCode": null,
                "cancelReasonCode": null,
                "clientContribution": null,
                "clientDescription": null,
                "clientNumber": null,
                "clientServiceCenterCode": null,
                "contactInformation": null,
                "contactName": null,
                "contractRule": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "contractTypes": null,
                "coverageEffectiveDate": null,
                "coverages": null,
                "dateBegin": null,
                "dateEnd": null,
                "departments": null,
                "drugOptionCode": null,
                "effectiveDate": null,
                "fax": {
                    "areaCode": null,
                    "extension": null,
                    "prefix": null,
                    "suffix": null,
                    "type": null
                },
                "groupCoverageBeginDate": null,
                "groupCoverageTermDate": null,
                "groupDescription": null,
                "groupLeader": null,
                "groupName": null,
                "groupNumberAmms": null,
                "groupNumberCes": null,
                "groupType": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "id": "036033500",
                "idCardType": null,
                "idCode": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "lastBillAmount": null,
                "lastBillDate": null,
                "maintenenceDate": null,
                "masterARNumber": null,
                "masterCoverageRateBegin": null,
                "masterCoverageRateEnd": null,
                "name": {
                    "firstName": null,
                    "lastName": null,
                    "middleName": null,
                    "prefixName": null,
                    "suffixName": null
                },
                "outputRules": null,
                "paymentSummaryNumber": null,
                "phone": {
                    "areaCode": null,
                    "extension": null,
                    "prefix": null,
                    "suffix": null,
                    "type": null
                },
                "probationaryPeriods": null,
                "productRule": {
                    "code": null,
                    "description": null,
                    "key": null,
                    "name": null,
                    "value": null
                },
                "ratingCounty": null,
                "rpn": null,
                "salesRepresentative": {
                    "address": {
                        "address1": null,
                        "address2": null,
                        "address3": null,
                        "address4": null,
                        "address5": null,
                        "city": null,
                        "country": null,
                        "county": null,
                        "countyCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "rpn": null,
                            "state": null,
                            "value": null
                        },
                        "province": null,
                        "region": null,
                        "state": null,
                        "stateCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "zipcode": null,
                        "zipcodePostFix": null
                    },
                    "id": null,
                    "idCode": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "name": {
                        "firstName": null,
                        "lastName": null,
                        "middleName": null,
                        "prefixName": null,
                        "suffixName": null
                    },
                    "phone": {
                        "areaCode": null,
                        "extension": null,
                        "prefix": null,
                        "suffix": null,
                        "type": null
                    },
                    "representative": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    }
                },
                "serviceRepresentative": {
                    "address": {
                        "address1": null,
                        "address2": null,
                        "address3": null,
                        "address4": null,
                        "address5": null,
                        "city": null,
                        "country": null,
                        "county": null,
                        "countyCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "rpn": null,
                            "state": null,
                            "value": null
                        },
                        "province": null,
                        "region": null,
                        "state": null,
                        "stateCode": {
                            "code": null,
                            "description": null,
                            "key": null,
                            "name": null,
                            "value": null
                        },
                        "zipcode": null,
                        "zipcodePostFix": null
                    },
                    "id": null,
                    "idCode": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    },
                    "name": {
                        "firstName": null,
                        "lastName": null,
                        "middleName": null,
                        "prefixName": null,
                        "suffixName": null
                    },
                    "phone": {
                        "areaCode": null,
                        "extension": null,
                        "prefix": null,
                        "suffix": null,
                        "type": null
                    },
                    "representative": {
                        "code": null,
                        "description": null,
                        "key": null,
                        "name": null,
                        "value": null
                    }
                },
                "sicCode": null,
                "specialHandling": null,
                "statusDescription": null,
                "subClientDescription": null,
                "subClientNumber": null,
                "terminationDate": null
            },
            "periods": null,
            "serviceCenter": "AAA",
            "type": null
        },
        "maintenanceDate": null,
        "memberId": null,
        "members": [],
        "name": {
            "firstName": "MICHAEL",
            "lastName": "TESTING",
            "middleName": "",
            "prefixName": null,
            "suffixName": null
        },
        "notes": null,
        "originalEffectiveDate": "2002-07-01T00:00:00-0400",
        "phone": {
            "areaCode": "",
            "extension": null,
            "prefix": "",
            "suffix": "",
            "type": null
        },
        "policyType": "GROUP",
        "relatedInformationIndicator": true,
        "relationshipCode": null,
        "relationshipName": null,
        "searchType": null,
        "selectedAMMSPatientId": null,
        "selectedPatientId": null,
        "serviceCenter": {
            "code": "AAA",
            "description": "HMO",
            "key": "AAA",
            "location": null,
            "name": "AAA",
            "value": "HMO"
        },
        "sexCode": "M",
        "sexName": null,
        "socialSecurityNumber": "",
        "subscriberMember": null,
        "totl": false
    },
    "groupName": "TEST SPECIAL PROJECTS AREA",
    "id": "999574313",
    "listBillPhoneNumber": "803-111-2222",
    "masterARNumber": "036011100",
    "policyTypeNotFound": false,
    "subscriberName": "MICHAEL&nbsp;TESTING",
    "subscriberNumber": null
}