package com.bcbssc.services.dao.statchat;


import com.bcbssc.services.model.common.DAOException;
import com.bcbssc.services.model.statchat.CallDataDTO;
/**
 * <p>CTICallDataStoreDAO interface.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public interface CTICallDataStoreDAO{

	/**
	 * <p>saveCallDataInformation.</p>
	 *
	 * @param callDataDTO a {@link com.bcbssc.services.model.statchat.CallDataDTO} object.
	 * @throws com.bcbssc.services.model.common.DAOException if any.
	 */
	public void saveCallDataInformation(CallDataDTO callDataDTO) throws DAOException;
	
}
