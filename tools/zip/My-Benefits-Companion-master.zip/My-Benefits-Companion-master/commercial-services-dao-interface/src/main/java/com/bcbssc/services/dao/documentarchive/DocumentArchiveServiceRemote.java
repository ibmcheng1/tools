package com.bcbssc.services.dao.documentarchive;

import java.util.Date;
import java.util.List;

import com.bcbssc.commapi.model.common.APIException;
import com.bcbssc.commapi.model.common.DocumentNotFoundException;
import com.bcbssc.commapi.model.common.GroupAdminId;
import com.bcbssc.commapi.model.common.ProviderId;
import com.bcbssc.commapi.model.common.SubscriberId;
import com.bcbssc.commapi.model.documentarchive.EDIGReport;
import com.bcbssc.commapi.model.documentarchive.GroupAdminBill;
import com.bcbssc.commapi.model.documentarchive.Remit;
import com.bcbssc.commapi.model.documentarchive.SummaryEOB;
import com.bcbssc.commapi.model.documentarchive.Document;
import com.bcbssc.commapi.model.documentarchive.dto.ImageFolder;


/**
 * <p>DocumentArchiveServiceRemote interface.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public interface DocumentArchiveServiceRemote {

	/**
	 * Get a document list based on the dates and subscriber information.
	 *
	 * @param subscriber a {@link com.bcbssc.commapi.model.common.SubscriberId} object.
	 * @param dateFrom a {@link java.util.Date} object.
	 * @param dateTo a {@link java.util.Date} object.
	 * @return list of {@link com.bcbssc.commapi.model.documentarchive.SummaryEOB} objects.
	 * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if any.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 */
	public List<SummaryEOB> getSummaryExplanationOfBenefitsList (SubscriberId subscriber, Date dateFrom, Date dateTo) throws
	DocumentNotFoundException, APIException;
	
	/**
	 * Get the requested Summary EOB document.
	 *
	 * @param summaryEOB a {@link com.bcbssc.commapi.model.documentarchive.SummaryEOB} object.
	 * @return Document
	 * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if any.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 */
	public Document getSummaryExplanationOfBenefits(SummaryEOB summaryEOB) throws 
	DocumentNotFoundException, APIException;
	
	/**
	 * Get the requested document based on the dates, subscriber information and claim number.
	 *
	 * @param subscriber a {@link com.bcbssc.commapi.model.common.SubscriberId} object.
	 * @param claimNumber a {@link java.lang.String} object.
	 * @param dateProcessed a {@link java.util.Date} object.
	 * @param dateFrom a {@link java.util.Date} object.
	 * @param dateTo a {@link java.util.Date} object.
	 * @return Document
	 * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if any.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 */
	public Document getExplanationOfBenefits(SubscriberId subscriber, String claimNumber, Date dateProcessed, Date dateFrom, Date dateTo) throws
	DocumentNotFoundException,APIException;
	
	/**
	 * Get the requested document based on the dates, subscriber information and claim number.
	 *
	 * @param subscriber a {@link com.bcbssc.commapi.model.common.SubscriberId} object.
	 * @param claimNumber a {@link java.lang.String} object.
	 * @param dateProcessed a {@link java.util.Date} object.
	 * @param dateFrom a {@link java.util.Date} object.
	 * @param dateTo a {@link java.util.Date} object.
	 * @return Document
	 * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if any.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 */
	public Document getDentalProviderLetter(SubscriberId subscriber, String claimNumber, Date dateProcessed, Date dateFrom, Date dateTo) throws
	DocumentNotFoundException,APIException;
	
	/**
	 * Get the requested document based on the dates, subscriber information and claim number.
	 *
	 * @param subscriber a {@link com.bcbssc.commapi.model.common.SubscriberId} object.
	 * @param claimNumber a {@link java.lang.String} object.
	 * @param dateProcessed a {@link java.util.Date} object.
	 * @param dateFrom a {@link java.util.Date} object.
	 * @param dateTo a {@link java.util.Date} object.
	 * @return Document
	 * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if any.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 */
	public Document getDentalSubscriberLetter(SubscriberId subscriber, String claimNumber, Date dateProcessed, Date dateFrom, Date dateTo) throws
	DocumentNotFoundException,APIException;
	
	/**
	 * Get the requested document based on the dates, provider, subscriber information and claim number.
	 *
	 * @param provider a {@link com.bcbssc.commapi.model.common.ProviderId} object.
	 * @param subscriber a {@link com.bcbssc.commapi.model.common.SubscriberId} object.
	 * @param claimNumber a {@link java.lang.String} object.
	 * @param postingDate a {@link java.lang.String} object.
	 * @param timestamp a {@link java.lang.String} object.
	 * @param dateFrom a {@link java.util.Date} object.
	 * @param dateTo a {@link java.util.Date} object.
	 * @return Document
	 * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if any.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 */
	public Document getCorrespondenceResponseDocument(ProviderId provider, SubscriberId subscriber,
			String claimNumber, String postingDate, String timestamp, Date dateFrom, Date dateTo) throws
	DocumentNotFoundException,APIException;
	
	/**
	 * Get a document list based on the dates, provider information and folder name.
	 *
	 * @param provider a {@link com.bcbssc.commapi.model.common.ProviderId} object.
	 * @param remitFolderName a {@link com.bcbssc.commapi.model.documentarchive.dto.ImageFolder} object.
	 * @param dateFrom a {@link java.util.Date} object.
	 * @param dateTo a {@link java.util.Date} object.
	 * @return returns a list of {@link com.bcbssc.commapi.model.documentarchive.Remit} objects.
	 * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if any.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 */
	public List<Remit> getRemitList(ProviderId provider, ImageFolder remitFolderName, Date dateFrom, Date dateTo) throws
	DocumentNotFoundException,APIException;
	
	/**
	 * Get the requested remit document.
	 *
	 * @param remit a {@link com.bcbssc.commapi.model.documentarchive.Remit} object.
	 * @return Document
	 * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if any.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 */
	public Document getRemit(Remit remit) throws 
	DocumentNotFoundException, APIException;
	
	/**
	 * Get a document list based on the dates, provider information and folder name.
	 *
	 * @param provider a {@link com.bcbssc.commapi.model.common.ProviderId} object.
	 * @param edigFolderName a {@link com.bcbssc.commapi.model.documentarchive.dto.ImageFolder} object.
	 * @param dateFrom a {@link java.util.Date} object.
	 * @param dateTo a {@link java.util.Date} object.
	 * @return returns a list of {@link com.bcbssc.commapi.model.documentarchive.EDIGReport} objects.
	 * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if any.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 */
	public List<EDIGReport> getEDIGReportList(ProviderId provider, ImageFolder edigFolderName, Date dateFrom, Date dateTo) throws
	DocumentNotFoundException,APIException;
	
	/**
	 * Get the requested edig report document.
	 *
	 * @param edigReport a {@link com.bcbssc.commapi.model.documentarchive.EDIGReport} object.
	 * @return Document
	 * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if any.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 */
	public Document getEDIGReport(EDIGReport edigReport) throws 
	DocumentNotFoundException, APIException;
	
	/**
	 * Get a document list based on the dates and group admin id.
	 *
	 * @param groupAdminId a {@link com.bcbssc.commapi.model.common.GroupAdminId} object.
	 * @param dateFrom a {@link java.util.Date} object.
	 * @param dateTo a {@link java.util.Date} object.
	 * @return returns a list of {@link com.bcbssc.commapi.model.documentarchive.GroupAdminBill} objects.
	 * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if any.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 */
	public List<GroupAdminBill> getGroupAdminBillList(GroupAdminId groupAdminId, Date dateFrom, Date dateTo) throws
	DocumentNotFoundException,APIException;
	
	/**
	 * Get the requested group admin bill document.
	 *
	 * @param groupAdminBill a {@link com.bcbssc.commapi.model.documentarchive.GroupAdminBill} object.
	 * @return Document
	 * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if any.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 */
	public Document getGroupAdminBill(GroupAdminBill groupAdminBill) throws 
	DocumentNotFoundException, APIException;
}
