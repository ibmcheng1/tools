/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2011 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 * ValidateSamlAssertionDAO.java
 *
 * Created on Sept 24, 2011
 *
 * @author X94S
 */

package com.bcbssc.services.dao.saml;

import com.bcbssc.services.model.saml.SamlAssertion;
import com.bcbssc.services.model.common.DAOException;
import com.bcbssc.services.model.common.SamlAssertionException;

/**
 * <p>ValidateSAMLAssertionDAO interface.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public interface ValidateSAMLAssertionDAO{

	/**
	 * <p>validateSamlAssertion.</p>
	 *
	 * @param samlAttributes a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.services.model.saml.SamlAssertion} object.
	 * @throws com.bcbssc.services.model.common.SamlAssertionException if any.
	 * @throws com.bcbssc.services.model.common.DAOException if any.
	 */
	public SamlAssertion validateSamlAssertion(String samlAttributes)
	       throws SamlAssertionException, DAOException;

}
