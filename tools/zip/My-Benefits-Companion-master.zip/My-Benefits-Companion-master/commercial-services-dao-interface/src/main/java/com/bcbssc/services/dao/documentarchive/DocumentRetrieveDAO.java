/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * DocumentRetrieveDAOLocal.java
 * Date: May 25, 2010
 */
package com.bcbssc.services.dao.documentarchive;

import java.util.List;

import com.bcbssc.commapi.model.common.DAOException;
import com.bcbssc.commapi.model.common.DocumentNotFoundException;
import com.bcbssc.commapi.model.documentarchive.Document;
import com.bcbssc.commapi.model.documentarchive.dto.DocumentDTO;
import com.bcbssc.commapi.model.documentarchive.dto.DocumentSearchCriteria;
import com.bcbssc.commapi.model.documentarchive.dto.ImageFolder;

/**
 *
 * Author: FF74
 *
 * @author jc33
 * @version $Id: $Id
 */
public interface DocumentRetrieveDAO {
	
	/**
	 * Get a document list based on the document search criteria.
	 *
	 * @param searchCriteria a {@link com.bcbssc.commapi.model.documentarchive.dto.DocumentSearchCriteria} object.
	 * @return returns a list of {@link com.bcbssc.commapi.model.documentarchive.dto.DocumentDTO} objects.
	 * @throws com.bcbssc.commapi.model.common.DAOException if any.
	 */
	public List<DocumentDTO> getDocumentList(DocumentSearchCriteria searchCriteria) throws DAOException;
	
	/**
	 * Get the requested document based on the folder name and document id.
	 *
	 * @param folderName a {@link com.bcbssc.commapi.model.documentarchive.dto.ImageFolder} object.
	 * @param docId a {@link java.lang.String} object.
	 * @return Document
	 * @throws com.bcbssc.commapi.model.common.DAOException if any.
	 * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if any.
	 */
	public Document getDocumentDetail(ImageFolder folderName, String docId)throws DAOException, DocumentNotFoundException;

}// End of interface DocumentRetrieveDAO
