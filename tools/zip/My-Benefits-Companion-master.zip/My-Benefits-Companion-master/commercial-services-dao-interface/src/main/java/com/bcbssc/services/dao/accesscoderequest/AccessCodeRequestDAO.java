/**
 * 
 */
package com.bcbssc.services.dao.accesscoderequest;

import java.util.HashMap;

import com.bcbssc.commapi.model.common.DAOException;


/**
 * <p>AccessCodeRequestDAO interface.</p>
 *
 * @author x94s
 * @version $Id: $Id
 */
public interface AccessCodeRequestDAO {
		
	/**
	 * <p>requestNewAccessCode.</p>
	 *
	 * @param userDTO a {@link java.util.HashMap} object.
	 * @return a {@link java.lang.String} object.
	 * @throws com.bcbssc.commapi.model.common.DAOException if any.
	 */
	public String requestNewAccessCode(HashMap<String, String> userDTO) throws DAOException;

}
