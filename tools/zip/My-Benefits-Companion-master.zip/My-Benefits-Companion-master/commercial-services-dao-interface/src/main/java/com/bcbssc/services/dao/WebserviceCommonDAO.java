/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * WebserviceCommonDAO.java
 * 
 * Created on Oct 12, 2009 by EN80

 */

package com.bcbssc.services.dao;

/**
 * WebServices Common DAO.
 *
 * <pre>
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-services-dao-interface/src/main/java/com/bcbssc/services/dao/WebserviceCommonDAO.java_v  $
 * $Workfile:   WebserviceCommonDAO.java  $
 * $Revision:   1.0  $
 * $Date:   Oct 20 2009 12:03:00  $
 * $Modtime:   Oct 16 2009 11:24:18  $
 * </pre>
 *
 * @author $Author:   EN80  $
 * @version $Id: $Id
 */
public interface WebserviceCommonDAO {

	//@TODO define common interface
}
