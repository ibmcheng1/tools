/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * RulesDataTypeMaintenanceDAO.java
 * 
 * Created on Oct 12, 2009 by EN80

 */

package com.bcbssc.services.dao.rules;

import com.bcbssc.services.dao.WebserviceCommonDAO;
import com.bcbssc.services.model.rules.RulesDatatypeMaintenance;
import com.bcbssc.services.model.rules.RulesDatatypeMaintenanceResult;

/**
 * DAO interface for RulesDataTypeMaintenance
 *
 * <pre>
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-services-dao-interface/src/main/java/com/bcbssc/services/dao/rules/RulesDataTypeMaintenanceDAO.java_v  $
 * $Workfile:   RulesDataTypeMaintenanceDAO.java  $
 * $Revision:   1.0  $
 * $Date:   Oct 20 2009 12:03:02  $
 * $Modtime:   Oct 19 2009 16:33:26  $
 * </pre>
 *
 * @author $Author:   EN80  $
 * @version $Id: $Id
 */
public interface RulesDataTypeMaintenanceDAO extends WebserviceCommonDAO {
	
	/**
	 * Operation to perform Rules Data Type maintenance like Add/Update/Void. Called should supply
	 * all data in Input model.
	 *
	 * @param input RulesDatatypeMaintenance object with all required data
	 * @return RulesDatatypeMaintenanceResult
	 * @throws java.lang.Exception if any.
	 */
	public RulesDatatypeMaintenanceResult performRulesDataTypeOperation(RulesDatatypeMaintenance input) throws Exception;
	
	
	/**
	 * Operation to perform Rules Data Type maintenance like Add/Update/Void. Called should supply
	 * all data in Input model. This will rollback the partial set of operations in case of error
	 *
	 * @param input RulesDatatypeMaintenance object with all required data
	 * @param rollbackOnError true/false to rollback the previous operations
	 * @return RulesDatatypeMaintenanceResult
	 * @throws java.lang.Exception if any.
	 */
	public RulesDatatypeMaintenanceResult performRulesDataTypeOperation(RulesDatatypeMaintenance input, boolean rollbackOnError) throws Exception;

}
