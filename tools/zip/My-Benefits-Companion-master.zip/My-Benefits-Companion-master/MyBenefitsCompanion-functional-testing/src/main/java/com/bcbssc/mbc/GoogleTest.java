package com.bcbssc.mbc;

import java.net.URL;
import java.util.List;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class GoogleTest {

	protected final Logger LOGGER = Logger.getLogger(GoogleTest.class.getName());
	
    @Test
    public void test() throws Exception{

    	WebDriver driver = null;
    			
        try {
	        LOGGER.info("Launching");
	        System.setProperty("webdriver.chrome.driver", "R:\\ISPortal_PUBLIC\\Grant\\selenium-2.45.0\\chromedriver.exe");
	        //ChromeOptions options = new ChromeOptions();
	        //options.addArguments("--disable-popup-blocking");
	        //options.addArguments("--disable-extensions");
	        DesiredCapabilities capabilities = DesiredCapabilities.htmlUnit();
	        //DesiredCapabilities capabilities = DesiredCapabilities.firefox();
	        capabilities.setCapability("cssSelectorsEnabled", false);
	        //DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
	        //capabilities.setCapability(CapabilityType.VERSION, "11");
	        //capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
	        //capabilities.setCapability(ChromeOptions.CAPABILITY, options);
	        //WebDriver driver = ThreadGuard.protect(new ChromeDriver(capabilities));
	        
	        //WebDriver driver = new RemoteWebDriver(new URL("http://172.17.0.1:4445"), capabilities);
	        driver = new RemoteWebDriver(new URL("http://10.142.193.206:4444/wd/hub"), capabilities);

	        LOGGER.info("Navigating to google.com");
	        driver.get("http://google.com");
	        //driver.get("http://pbzsgpadm2k3.bcbssc.com/cga_open/do/startRegistration");
	        
	        LOGGER.info("Finding input field");
	        WebElement input = driver.findElement(By.name("q"));

	        LOGGER.info("Entering search text [selenium jenkins]");
	        input.sendKeys("selenium jenkins");

	        LOGGER.info("Clicking Google Search link");
	        driver.findElement(By.name("btnK")).click();

	        (new WebDriverWait(driver, 10, 1000)).until(new ExpectedCondition<Boolean>() {
	            public Boolean apply(WebDriver drive) {
	    	        LOGGER.info("Waiting on search results");
	                return (drive.findElement(By.id("resultStats")) != null);
	            }            
	        });
	        
	        LOGGER.info("Search results:");
	        LOGGER.info(driver.findElement(By.id("resultStats")).getText());

	        List<WebElement> linkElements = driver.findElements(By.tagName("a"));
	        
	        for (WebElement link: linkElements) {
		        LOGGER.info("Link displayed: " + link.getText());
	        }

	        Thread.sleep(2000);

	        LOGGER.info("Success");

	        Thread.sleep(1000);

        } catch (Exception e) {
        	e.printStackTrace();
        } finally {
        	if (driver != null) {
    	        driver.close();
    	        driver.quit();
        	}
        }
    }
}
