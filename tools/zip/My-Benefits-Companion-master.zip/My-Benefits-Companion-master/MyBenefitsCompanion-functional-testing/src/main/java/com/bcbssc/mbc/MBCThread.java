package com.bcbssc.mbc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

public class MBCThread extends Thread {
	
	private XmlSuite suite;
	private TestNG testng;

	public MBCThread(String[] args) {
		
		this.suite = new XmlSuite();
		this.suite.setName("factoryTestSuite");
		
		XmlTest test = new XmlTest(this.suite);
		test.setName("mbcTest");
		List<XmlClass> classes = new ArrayList<XmlClass>();
		classes.add(new XmlClass("com.bcbssc.mbc.MBCFunctionalTest"));
		test.setXmlClasses(classes) ;

		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("searchValue", args[0]);
		
		this.suite.setParameters(parameters);
		test.setParameters(parameters);

		List<XmlSuite> suites = new ArrayList<XmlSuite>();
		suites.add(this.suite);
		this.testng = new TestNG();
		this.testng.setOutputDirectory(args[1]);
		this.testng.setXmlSuites(suites);
	}

    public void run() {
		this.testng.run();
		
		if(this.testng.hasFailure()) {
			System.exit(1);
		}
    }

    public static void main(String[] args) {
		System.setProperty("java.util.logging.SimpleFormatter.format","%2$s %5$s%6$s%n");
		new MBCThread(args).start();
	}

}
