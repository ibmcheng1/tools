package com.bcbssc.mbc; 

import java.net.URL;
import java.util.List;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class MBCFunctionalTest {

	protected final Logger LOGGER = Logger.getLogger(MBCFunctionalTest.class.getName());
	
	@Parameters({ "searchValue" })
	@Test
	public void test(String searchValue) throws Exception{

		LOGGER.info("searchValue: " + searchValue);
		
		WebDriver driver = null;
				
		try {
			LOGGER.info("Start");
			DesiredCapabilities capabilities = DesiredCapabilities.htmlUnit();
			capabilities.setCapability("cssSelectorsEnabled", false);
			
			LOGGER.info("Launching RemoteWebDriver");
			driver = new RemoteWebDriver(new URL("http://10.142.193.206:4444/wd/hub"), capabilities);

			LOGGER.info("Navigating to MBC");
			driver.get("https://unit-5.myhealthtoolkit.com/cga_open/do/startRegistration");
			
			LOGGER.info("Waiting for page load");
			(new WebDriverWait(driver, 10, 1000)).until(new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver drive) {
					LOGGER.info("Waiting on page load");
					return (drive.findElement(By.name("samAccountName")) != null);
				}			
			});
			LOGGER.info("Page is loaded");
			
			LOGGER.info("Entering username");
			driver.findElement(By.name("samAccountName")).sendKeys("allgrpad1");

			LOGGER.info("Entering password");
			driver.findElement(By.name("unicodePwd")).sendKeys("pass01a");

			LOGGER.info("Clicking Login button");
			driver.findElement(By.name("Submit")).click();

			LOGGER.info("Waiting for home page to load");
			(new WebDriverWait(driver, 30, 2000)).until(new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver drive) {
					LOGGER.info("Waiting on home page load");
					
					WebElement bodyElement = drive.findElement(By.tagName("body"));
					if (bodyElement != null) {
						LOGGER.info("bodyElement: " + bodyElement.getText());
					}
					
					return (drive.findElement(By.className("pagetitle")) != null);
				}			
			});
			LOGGER.info("Home page is loaded");
			
			LOGGER.info("Hovering over Insured Employee menu item");
			Actions builder = new Actions(driver);
			builder.moveToElement(driver.findElement(By.id("oCMenu_InsuredEmployee"))).perform();

			LOGGER.info("Waiting for Insured Employee menu item to appear");
			(new WebDriverWait(driver, 10, 1000)).until(new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver drive) {
					LOGGER.info("Waiting on Insured Employee menu item");
					return (drive.findElement(By.id("oCMenu_MaintainInsuredEmployee")) != null);
				}			
			});
			LOGGER.info("Clicking Maintain Insured Employee menu item");
			driver.findElement(By.id("oCMenu_MaintainInsuredEmployee")).click();
			
			LOGGER.info("Waiting for Insured Employee page to load");
			(new WebDriverWait(driver, 10, 1000)).until(new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver drive) {
					LOGGER.info("Waiting on Insured Employee page load");
					return (drive.findElement(By.xpath("//span[@class='pagetitle' and contains(text(),'Insured Employee')]")) != null);
				}			
			});
			LOGGER.info("Insured Employee page is loaded");

			Select group = new Select(driver.findElement(By.name("group")));
			Select emplStatus = new Select(driver.findElement(By.name("searchStatus")));
			WebElement searchLastName = driver.findElement(By.name("searchLastName"));
			WebElement submitButton = driver.findElement(By.xpath("//input[@type='submit']"));
			
			LOGGER.info("Selecting group");
			group.selectByIndex(1);

			LOGGER.info("Selecting employee status");
			emplStatus.selectByVisibleText("All");

			LOGGER.info("Entering search name");
			searchLastName.sendKeys("John");

			LOGGER.info("Clicking submit button");
			submitButton.click();

			LOGGER.info("Waiting for search results to display");
			(new WebDriverWait(driver, 30, 2000)).until(new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver drive) {
					LOGGER.info("Waiting on search results");
					return (drive.findElement(By.name("page")) != null);
				}			
			});
			LOGGER.info("Search results are displayed");

			List<WebElement> tableRowElements = driver.findElements(By.tagName("tr"));
			
			boolean matchFound = false;

			LOGGER.info("Looking for [" + searchValue + "] in page content");

			for (WebElement tableRowElement: tableRowElements) {
				LOGGER.info("TR: " + tableRowElement.getText());
				
				if (tableRowElement.getText().toUpperCase().contains(searchValue.toUpperCase())) {
					LOGGER.info("Found [" + searchValue + "] in page content");
					matchFound = true;
				}
			}

			Assert.assertTrue(matchFound);
			
			LOGGER.info("Success");

			Thread.sleep(1000);

		} catch (Exception e) {
			LOGGER.warning("encountered exception "+e.getClass().getName()+" with error "+e.getMessage());
			Assert.assertTrue(false);
			//e.printStackTrace();
		} finally {
			if (driver != null) {
				driver.close();
				driver.quit();
			}
		}
	}
}
