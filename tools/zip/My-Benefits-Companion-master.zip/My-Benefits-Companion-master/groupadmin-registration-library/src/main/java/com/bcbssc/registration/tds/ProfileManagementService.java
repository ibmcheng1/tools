package com.bcbssc.registration.tds;

import java.io.FileNotFoundException;
import java.util.Collection;
import java.util.Map;
import java.util.Properties;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.bcbssc.netsys.jndi.LdapException;
import com.bcbssc.netsys.jndi.LdapUser;
import com.bcbssc.netsys.jndi.MissingPropertyException;
import com.bcbssc.registration.common.Constants;
import com.bcbssc.registration.dto.UserDTO;

/**
 * <p>ProfileManagementService interface.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public interface ProfileManagementService {

	/**
	 * <p>addUser.</p>
	 *
	 * @param user a {@link com.bcbssc.registration.dto.UserDTO} object.
	 * @param password a {@link java.lang.String} object.
	 * @return a boolean.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 * @throws javax.naming.NamingException if any.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public boolean addUser(UserDTO user, String password)
			throws MissingPropertyException, NamingException,
			FileNotFoundException;

	/**
	 * <p>validateUser.</p>
	 *
	 * @param samAccountName a {@link java.lang.String} object.
	 * @param unicodePwd a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.registration.dto.UserDTO} object.
	 * @throws javax.naming.NamingException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 * @throws java.io.FileNotFoundException if any.
	 * @throws java.lang.Exception if any.
	 */
	public UserDTO validateUser(String samAccountName, String unicodePwd)
			throws NamingException, MissingPropertyException,
			FileNotFoundException, Exception;

	/**
	 * <p>getProfileCount.</p>
	 *
	 * @param last6SSN a {@link java.lang.String} object.
	 * @param dob a {@link java.lang.String} object.
	 * @return a int.
	 * @throws javax.naming.NamingException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public int getProfileCount(String last6SSN, String dob)
			throws NamingException, MissingPropertyException,
			FileNotFoundException;

	/**
	 * <p>updateProfile.</p>
	 *
	 * @param user a {@link com.bcbssc.registration.dto.UserDTO} object.
	 * @return a boolean.
	 * @throws javax.naming.NamingException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public boolean updateProfile(UserDTO user) throws NamingException,
			MissingPropertyException, FileNotFoundException;

	/**
	 * <p>updateRoles.</p>
	 *
	 * @param samAccountName a {@link java.lang.String} object.
	 * @param roles a {@link java.util.Collection} object.
	 * @throws javax.naming.NamingException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public void updateRoles(String samAccountName, Collection roles)
			throws NamingException, MissingPropertyException,
			FileNotFoundException;

	/**
	 * <p>resetPassword.</p>
	 *
	 * @param last6SSN a {@link java.lang.String} object.
	 * @param dob a {@link java.lang.String} object.
	 * @param samAccountName a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.registration.dto.UserDTO} object.
	 * @throws javax.naming.NamingException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public UserDTO resetPassword(String last6SSN, String dob,
			String samAccountName) throws NamingException,
			MissingPropertyException, FileNotFoundException;

	/**
	 * <p>profileExistsForUserIDorAccessCode.</p>
	 *
	 * @param attributeName a {@link java.lang.String} object.
	 * @param attributeValue a {@link java.lang.String} object.
	 * @return a boolean.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 * @throws javax.naming.NamingException if any.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public boolean profileExistsForUserIDorAccessCode(String attributeName,
			String attributeValue) throws MissingPropertyException,
			NamingException, FileNotFoundException;

	/**
	 * <p>getRoles.</p>
	 *
	 * @param samAccountName a {@link java.lang.String} object.
	 * @return a {@link java.lang.String} object.
	 * @throws java.io.FileNotFoundException if any.
	 * @throws javax.naming.NamingException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 */
	public String getRoles(String samAccountName) throws FileNotFoundException,
			NamingException, MissingPropertyException;

	/**
	 * <p>updateLastAccessTime.</p>
	 *
	 * @param samAccountName a {@link java.lang.String} object.
	 * @param attribute a {@link java.lang.String} object.
	 * @throws javax.naming.NamingException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public void updateLastAccessTime(String samAccountName, String attribute)
			throws NamingException, MissingPropertyException,
			FileNotFoundException;

	/**
	 * <p>updateLdapAttribute.</p>
	 *
	 * @param samAccountName a {@link java.lang.String} object.
	 * @param attribute a {@link java.lang.String} object.
	 * @param newValue a {@link java.lang.String} object.
	 * @throws javax.naming.NamingException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 * @throws java.io.FileNotFoundException if any.
	 * @throws com.bcbssc.netsys.jndi.LdapException if any.
	 */
	public void updateLdapAttribute(String samAccountName, String attribute,
			String newValue) throws NamingException, MissingPropertyException,
			FileNotFoundException, LdapException;

	/**
	 * <p>updatePassword.</p>
	 *
	 * @param samAccountName a {@link java.lang.String} object.
	 * @param newpassword a {@link java.lang.String} object.
	 * @return a boolean.
	 * @throws javax.naming.NamingException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public boolean updatePassword(String samAccountName, String newpassword)
			throws NamingException, MissingPropertyException,
			FileNotFoundException;

	/**
	 * <p>getUser.</p>
	 *
	 * @param samAccountName a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.registration.dto.UserDTO} object.
	 * @throws java.lang.Exception if any.
	 */
	public UserDTO getUser(String samAccountName) throws Exception;

	/**
	 * <p>getUserFromCookie.</p>
	 *
	 * @param sEncryptedCookie a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.registration.dto.UserDTO} object.
	 * @throws java.lang.Exception if any.
	 */
	public UserDTO getUserFromCookie(String sEncryptedCookie) throws Exception;

	/**
	 * <p>getUserFromCookies.</p>
	 *
	 * @param szOntCredCookie a {@link java.lang.String} object.
	 * @param racfCookie a {@link java.lang.String} object.
	 * @param suType a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.registration.dto.UserDTO} object.
	 * @throws java.lang.Exception if any.
	 */
	public UserDTO getUserFromCookies(String szOntCredCookie,
			String racfCookie, String suType) throws Exception;

	/**
	 * <p>getMatchingProfiles.</p>
	 *
	 * @param last6SSN a {@link java.lang.String} object.
	 * @param dob a {@link java.lang.String} object.
	 * @param lastName a {@link java.lang.String} object.
	 * @return an array of {@link java.lang.String} objects.
	 * @throws javax.naming.NamingException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public String[] getMatchingProfiles(String last6SSN, String dob,
			String lastName) throws NamingException, MissingPropertyException,
			FileNotFoundException;

	/**
	 * <p>getMatchingProfiles.</p>
	 *
	 * @param last6SSN a {@link java.lang.String} object.
	 * @param dob a {@link java.lang.String} object.
	 * @return an array of {@link java.lang.String} objects.
	 * @throws javax.naming.NamingException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public String[] getMatchingProfiles(String last6SSN, String dob)
			throws NamingException, MissingPropertyException,
			FileNotFoundException;

	/**
	 * <p>updateValues.</p>
	 *
	 * @param samAccountName a {@link java.lang.String} object.
	 * @param attributes a {@link java.util.Map} object.
	 * @throws javax.naming.NamingException if any.
	 * @throws java.io.FileNotFoundException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 */
	public void updateValues(String samAccountName, Map attributes)
			throws NamingException, FileNotFoundException,
			MissingPropertyException;

	/**
	 * <p>getDistinguishedRoleName.</p>
	 *
	 * @param roleParam a {@link java.lang.String} object.
	 * @return a {@link java.lang.String} object.
	 * @throws javax.naming.NamingException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public String getDistinguishedRoleName(String roleParam)
			throws NamingException, MissingPropertyException,
			FileNotFoundException;

	/**
	 * <p>writeCookie.</p>
	 *
	 * @param cookieName a {@link java.lang.String} object.
	 * @param cookieValue a {@link java.lang.String} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @param response a {@link javax.servlet.http.HttpServletResponse} object.
	 * @throws java.lang.Exception if any.
	 */
	public void writeCookie(String cookieName, String cookieValue,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception;

	/**
	 * <p>writeOntCredCookie.</p>
	 *
	 * @param samAccountName a {@link java.lang.String} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @param response a {@link javax.servlet.http.HttpServletResponse} object.
	 * @throws java.lang.Exception if any.
	 */
	public void writeOntCredCookie(String samAccountName,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception;

	/**
	 * <p>writeRACFCookie.</p>
	 *
	 * @param racfId a {@link java.lang.String} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @param response a {@link javax.servlet.http.HttpServletResponse} object.
	 * @throws java.lang.Exception if any.
	 */
	public void writeRACFCookie(String racfId, HttpServletRequest request,
			HttpServletResponse response) throws Exception;

	/**
	 * <p>getHolidayDowntimeMessage.</p>
	 *
	 * @param messageType a {@link java.lang.String} object.
	 * @return a {@link java.lang.String} object.
	 * @throws javax.naming.NamingException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public String getHolidayDowntimeMessage(String messageType)
			throws NamingException, MissingPropertyException,
			FileNotFoundException;

	/**
	 * Creates a <code>User</code> instance based on the highest role level
	 * associated with the profile of the desired user name.
	 * 
	 * @author X22A (B. Smith)
	 * @author CF90 (T. Zengerle)
	 * @version $Revision:   1.0  $
	 */
	public static final class Factory {
		/**
		 * logger for this class
		 */
		private static final Logger log = Logger.getLogger(Factory.class
				.getName());

		/**
		 * prevents an instance of this class from being created
		 */
		private Factory() {
		}

		/**
		 * @param distinguishedName a {@link java.lang.String} containing the fully distinguished username
		 * @param tdsIniFile a {@link java.lang.String} containing the TDS ini filename.
		 * @return a {@link com.bcbssc.netsys.jndi.LdapUser} object
		 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any
		 * @throws java.io.FileNotFoundException if any
		 * @throws javax.naming.NamingException if any
		 */
		public static LdapUser getLdapUserInstance(String distinguishedName,
				String tdsIniFile) throws NamingException,
				MissingPropertyException, FileNotFoundException {
			Properties properties = LdapConfig.getLdapConfig(tdsIniFile);
			
			LdapUser ldapObject = null;
			log.debug("distinguishedName is " + distinguishedName);
			log.debug("Properties file is " + properties.toString());
			try{
				ldapObject = new LdapUser(distinguishedName, properties);
		     }catch(Exception exp){
				 log.error("Caught exception while creating LdapUser in getLdapUserInstance, trying one more time: "+exp);
				 log.error("distinguishedName is" + distinguishedName);
				 log.error("Properties file is" + properties.elements().toString());
				 ldapObject = new LdapUser(distinguishedName, properties);
		     }

			return ldapObject;
		}

		public static String getHolidayDowntimeMessage(String baseDN,
				String searchDN, String userDN, String messageType,
				String tdsIniFile) throws FileNotFoundException,
				NamingException, MissingPropertyException {
			Properties properties = LdapConfig.getLdapConfig(tdsIniFile);
			String message = Constants.BLANK_STRING;
			Properties config = LdapConfig.getLdapConfig(tdsIniFile);
			config.remove(Constants.TDS_LDAP_BASE);
			config.remove(Constants.TDS_LDAP_SEARCH_BASE);
			config.put(Constants.TDS_LDAP_BASE, baseDN);
			config.put(Constants.TDS_LDAP_SEARCH_BASE, searchDN);

			LdapUser ldapObject = null;
			try{
			ldapObject = new LdapUser(userDN, properties);
		     }catch(Exception exp){
				 log.error("Caught exception while creating LdapUser, trying one more time: "+exp);
				 ldapObject = new LdapUser(userDN, properties);
		     }

			if (messageType.equalsIgnoreCase(Constants.TDS_DOWNTIME_TYPE)) {
				message = (String) ldapObject
						.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_DOWNTIME);

			} else if (messageType.equalsIgnoreCase(Constants.TDS_HOLIDAY_TYPE)) {
				message = (String) ldapObject
						.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_HOLIDAY);

			}

			return message;

		}

	}

}
