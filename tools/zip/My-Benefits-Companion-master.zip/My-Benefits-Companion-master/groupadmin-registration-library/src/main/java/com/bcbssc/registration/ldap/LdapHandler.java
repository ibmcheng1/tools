/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-registration/src/main/java/com/bcbssc/registration/ldap/LdapHandler.java_v  $
 * $Workfile:   LdapHandler.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:49:54  $
 * $Modtime:   May 14 2009 11:33:48  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-registration/src/main/java/com/bcbssc/registration/ldap/LdapHandler.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:49:54   EN80
 * Initial revision.
 * 
 *    Rev 1.2   Apr 28 2009 10:36:18   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.1   Feb 18 2005 14:26:04   rdq70
 * Added updateMultivaluedValue().
 *
 *    Rev 1.0   Feb 18 2005 12:03:34   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.registration.ldap;

import com.bcbssc.netsys.Config;
import com.bcbssc.netsys.dsmart.DSmartManager;
import com.bcbssc.netsys.dsmart.DSmartWrapper;
import com.bcbssc.registration.common.Constants;
import com.opennetwork.DSUtils.DSGeneralException;
import com.opennetwork.DSUtils.DSNoConnectionException;
import com.opennetwork.DSUtils.DSmart;
import com.opennetwork.DSUtils.IDSValList;

import java.io.FileNotFoundException;
import java.util.Collection;
import java.util.Iterator;
import java.util.StringTokenizer;

import javax.naming.NamingException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * This abstract class provides the most general LDAP operations.
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public abstract class LdapHandler {

	/** The log4j logger for this class. */
	private static Logger logger = Logger.getLogger(LdapHandler.class);

	/** The label of the DN element in the ONT Credentials cookie. */
	protected static final String ONT_CRED_COOKIE_DN = "dn";

	/** The main INI file path. */
	protected String iniFile;

	/** The SSL INI file path. */
	protected String sslIniFile;

	/**
	 * Class constructor
	 *
	 * @param iniFileName
	 *            INI file containing non-ssl LDAP connection info
	 * @param sslIniFileName
	 *            INI file containing ssl LDAP connection info
	 */
	public LdapHandler(String iniFileName, String sslIniFileName) {
		super();

		this.iniFile = iniFileName;
		this.sslIniFile = sslIniFileName;

		// This assumes that all users of this pool use this config file.
		// Since each app has a unique server instance, this is okay.
		DSmartManager.setConfigFile(this.iniFile);
	}

	/**
	 * Adds the credentials cookie to the response
	 *
	 * @param samAccountName
	 *            the qualifier.
	 * @param request
	 *            the servlet request.
	 * @param response
	 *            the servlet response.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	public void writeOntCredCookie(String samAccountName,
			HttpServletRequest request, HttpServletResponse response)
			throws DSGeneralException, DSPoolException {

		DSmartWrapper wrapper = null;
		DSmart dSmart = null;

		String sIPAddress = request.getRemoteAddr();
		String sEncryptedCookie;

		try {
			wrapper = this.checkOutConnection();
			dSmart = wrapper.getDSmart();

			String domain = Config.getPrivateProfileString(
					Constants.INI_COOKIE_SECTION,
					Constants.INI_AUTH_COOKIE_DOMAIN,
					com.bcbssc.struts.common.Constants.BLANK_STRING,
					this.iniFile);

			String cookieKey = Config.getPrivateProfileString(
					Constants.INI_COOKIE_SECTION,
					Constants.INI_AUTH_COOKIE_KEY,
					com.bcbssc.struts.common.Constants.BLANK_STRING,
					this.iniFile);

			String cookieIV = Config.getPrivateProfileString(
					Constants.INI_COOKIE_SECTION, Constants.INI_AUTH_COOKIE_IV,
					com.bcbssc.struts.common.Constants.BLANK_STRING,
					this.iniFile);

			String peopleBase = Config.getPrivateProfileString(
					Constants.INI_LOCAL_SECTION, Constants.INI_PEOPLE_BASE,
					com.bcbssc.struts.common.Constants.BLANK_STRING,
					this.iniFile);

			StringBuffer userDN = new StringBuffer(64);
			userDN.append(Constants.LDAP_CN_SEARCHBASE_PREFIX).append(
					samAccountName).append(",").append(peopleBase);

			if (LdapHandler.logger.isDebugEnabled()) {
				StringBuffer logMsg = new StringBuffer(256);
				logMsg.append("setting cookie... userDN: ").append(
						userDN.toString()).append(", samAccountName: ").append(
						samAccountName).append(", sIpAddress: ").append(
						sIPAddress).append(", domain: ").append(domain).append(
						", cookieKey: ").append(cookieKey).append(
						", cookieIV: ").append(cookieIV);
				LdapHandler.logger.debug(logMsg.toString());
			}

			sEncryptedCookie = dSmart.genAuthCookie(userDN.toString(),
					samAccountName, sIPAddress, domain, null, "", "BASIC",
					cookieKey.toCharArray(), cookieIV.toCharArray());

			// genAuthCookie returns the cookie in format
			// "ONTCred=abcdxyz;domain=.ont.com;expires=1800", but Java
			// doesn't like that format so I strip the encrypted value out and
			// set the preferences on the Cookie object

			// strip out the "ONTCred="
			StringTokenizer stCookieNameValue = new StringTokenizer(
					sEncryptedCookie, "=");
			sEncryptedCookie = stCookieNameValue.nextToken();
			sEncryptedCookie = stCookieNameValue.nextToken();

			// strip out domain, expiration, and other preferences
			StringTokenizer stCookieParts = new StringTokenizer(
					sEncryptedCookie, ";");
			sEncryptedCookie = stCookieParts.nextToken();

			Cookie encryptedCookie = com.bcbssc.struts.common.CommonUtils
					.writeCookie(Constants.COOKIE_ONT_CRED, sEncryptedCookie,
							domain, "/", -1);

			response.addCookie(encryptedCookie);

		} catch (DSGeneralException dsge) {
			LdapHandler.logger.error("Error:", dsge);
			NamingException nameEx = dsge.getNamingException();
			if (nameEx != null) {
				LdapHandler.logger.error("Root cause:", nameEx);
				LdapHandler.logger.error("Root cause:", nameEx.getRootCause());
			}

			throw dsge;
		} finally {
			this.checkInConnection(wrapper);
		}
	}

	/**
	 * Updates a single non-ssl value.
	 *
	 * @param name
	 *            attribute name
	 * @param value
	 *            new attribute value
	 * @param samAccountName
	 *            user name of profile to modify
	 * @return a boolean.
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	protected boolean updateSingleValue(String name, String value,
			String samAccountName) throws DSNoConnectionException,
			DSGeneralException, DSPoolException {

		boolean success = false;

		DSmartWrapper wrapper = null;
		DSmart dsConnection = null;

		try {
			wrapper = this.checkOutConnection();
			dsConnection = wrapper.getDSmart();

			String peopleBase = Config.getPrivateProfileString(
					Constants.INI_LOCAL_SECTION, Constants.INI_PEOPLE_BASE,
					com.bcbssc.struts.common.Constants.BLANK_STRING,
					this.iniFile);

			StringBuffer userDN = new StringBuffer(64);
			userDN.append(Constants.LDAP_CN_SEARCHBASE_PREFIX).append(
					samAccountName).append(",").append(peopleBase);

			IDSValList replaceList = dsConnection.getIDSValList();

			replaceList.addString(name, value, IDSValList.ACTION_REPLACE);

			if (dsConnection.modifyDirEntry(userDN.toString(), replaceList) == 0) {
				success = true;
			}

		} catch (DSGeneralException dsge) {
			LdapHandler.logger.error("Error:", dsge);
			NamingException nameEx = dsge.getNamingException();
			if (nameEx != null) {
				LdapHandler.logger.error("Root cause:", nameEx);
				LdapHandler.logger.error("Root cause:", nameEx.getRootCause());
			}

			throw dsge;
		} finally {
			this.checkInConnection(wrapper);
		}

		return success;
	}

	/**
	 * Updates a multivalued non-ssl value.
	 *
	 * @param name
	 *            attribute name
	 * @param values
	 *            new attribute values
	 * @param samAccountName
	 *            user name of profile to modify
	 * @return a boolean.
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	protected boolean updateMultivaluedValue(String name, Collection values,
			String samAccountName) throws DSNoConnectionException,
			DSGeneralException, DSPoolException {

		boolean success = false;

		DSmartWrapper wrapper = null;
		DSmart dsConnection = null;

		try {
			wrapper = this.checkOutConnection();
			dsConnection = wrapper.getDSmart();

			String peopleBase = Config.getPrivateProfileString(
					Constants.INI_LOCAL_SECTION, Constants.INI_PEOPLE_BASE,
					com.bcbssc.struts.common.Constants.BLANK_STRING,
					this.iniFile);

			StringBuffer userDN = new StringBuffer(64);
			userDN.append(Constants.LDAP_CN_SEARCHBASE_PREFIX).append(
					samAccountName).append(",").append(peopleBase);

			IDSValList replaceList = dsConnection.getIDSValList();

			for (Iterator i = values.iterator(); i.hasNext();) {
				replaceList.addString(name, (String) i.next(),
						IDSValList.ACTION_REPLACE);
			}

			if (dsConnection.modifyDirEntry(userDN.toString(), replaceList) == 0) {
				success = true;
			}

		} catch (DSGeneralException dsge) {
			LdapHandler.logger.error("Error:", dsge);
			NamingException nameEx = dsge.getNamingException();
			if (nameEx != null) {
				LdapHandler.logger.error("Root cause:", nameEx);
				LdapHandler.logger.error("Root cause:", nameEx.getRootCause());
			}

			throw dsge;
		} finally {
			this.checkInConnection(wrapper);
		}

		return success;
	}

	/**
	 * Adds a string to the specified IDSValList if the specified value is not
	 * empty.
	 *
	 * @param list
	 *            a list
	 * @param name
	 *            name of the string to be added
	 * @param value
	 *            value of the string to be added
	 * @param action
	 *            action associated with this list entry
	 */
	protected void addValListString(IDSValList list, String name, String value,
			int action) {
		if (value.length() > 0) {
			list.addString(name, value, action);
		}
	}

	/**
	 * Creates and returns a SSL Directory Smart connection.
	 *
	 * @return SSL Directory Smart connection
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws java.io.FileNotFoundException if any.
	 */
	protected DSmart getSslConnection() throws DSNoConnectionException,
			FileNotFoundException {
		String mgr = Config.getPrivateProfileString(
				Constants.INI_LOCAL_SECTION, Constants.INI_MGR_DN,
				com.bcbssc.struts.common.Constants.BLANK_STRING,
				this.sslIniFile);
		String mgrPwd = Config.getPrivateProfileString(
				Constants.INI_LOCAL_SECTION, Constants.INI_MGR_PW,
				com.bcbssc.struts.common.Constants.BLANK_STRING,
				this.sslIniFile);

		return new DSmart(mgr, mgrPwd, this.sslIniFile);
	}

	/**
	 * Checks out a connection.
	 *
	 * @return a DSmart wrapper object.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	protected DSmartWrapper checkOutConnection() throws DSPoolException {
		try {
			return DSmartManager.checkOutConnection();
		} catch (Exception e) {
			LdapHandler.logger.error("Error:", e);
			DSPoolException poolException = new DSPoolException(
					DSPoolException.CHECK_OUT);
			LdapHandler.logger.error(Constants.EXCEPTION_DSMART_CHECKOUT,
					poolException);
			throw poolException;
		}
	}

	/**
	 * Checks in a connection.
	 *
	 * @param wrapper -
	 *            the DSmart wrapper object returned by
	 *            <code>checkOutConnection()</code>.
	 * @see #checkOutConnection
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	protected void checkInConnection(DSmartWrapper wrapper)
			throws DSPoolException {
		try {
			DSmartManager.checkInConnection(wrapper);
		} catch (Exception e) {
			LdapHandler.logger.error("Error:", e);
			DSPoolException poolException = new DSPoolException(
					DSPoolException.CHECK_IN);
			LdapHandler.logger.error(Constants.EXCEPTION_DSMART_CHECKIN,
					poolException);
			throw poolException;
		}
	}
}
