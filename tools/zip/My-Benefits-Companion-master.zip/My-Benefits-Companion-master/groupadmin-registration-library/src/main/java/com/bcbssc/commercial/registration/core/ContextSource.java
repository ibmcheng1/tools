package com.bcbssc.commercial.registration.core;

import javax.naming.NamingException;
import javax.naming.directory.DirContext;

/**
 * <p>ContextSource interface.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public interface ContextSource {

	/**
	 * <p>getContext.</p>
	 *
	 * @return a {@link javax.naming.directory.DirContext} object.
	 * @throws javax.naming.NamingException if any.
	 */
	DirContext getContext() throws NamingException;	
}
