/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2009 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : ServerFailureException.java
 *
 * Created Date     : Oct 23, 2008
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Oct 23, 2008     Initial version for bcbssc-ldap
 */

package com.bcbssc.commercial.registration;

import com.bcbssc.netsys.LinkedException;

/**
 * <p>ServerFailureException class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class ServerFailureException extends LinkedException {

	private static final long serialVersionUID 			= 6349574396729290834L;	
	
    /**
     * Creates a new instance of ServerFailureException.
     */
    public ServerFailureException() {
        super();
    }

    /**
     * Creates a new instance of ServerFailureException with a descriptive message.
     *
     * @param message The exception message.
     */
    public ServerFailureException(String message) {
       super(message);
    }

    /**
     * Creates a new instance of ServerFailureException with a descriptive message
     * and a root cause.
     *
     * @param message The exception message.
     * @param rootCause The root cause of this exception.
     */
    public ServerFailureException(String message, Throwable rootCause) {
        super(message, rootCause);
    }

    /**
     * Creates a new instance of ServerFailureException with the given root cause.
     *
     * @param rootCause The root cause of this exception.
     */
    public ServerFailureException(Throwable rootCause) {
        super(rootCause);
    }
}
