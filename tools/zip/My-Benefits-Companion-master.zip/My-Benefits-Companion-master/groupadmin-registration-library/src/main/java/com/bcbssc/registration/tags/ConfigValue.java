/*
 * Created on May 17, 2005
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-registration/src/main/java/com/bcbssc/registration/tags/ConfigValue.java_v  $
 * $Workfile:   ConfigValue.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:50:06  $
 * $Modtime:   Jun 16 2009 13:45:26  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-registration/src/main/java/com/bcbssc/registration/tags/ConfigValue.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:50:06   EN80
 * Initial revision.
 * 
 *    Rev 1.1   Apr 28 2009 10:36:34   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.0   May 17 2005 13:52:46   rxr93
 * Initial revision.
 * 
 *    Rev 1.0   May 17 2005 10:19:12   rxr93
 * Initial revision.
 *
 */
package com.bcbssc.registration.tags;

import java.util.Properties;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;
import org.apache.struts.Globals;
import org.apache.struts.taglib.TagUtils;

import com.bcbssc.netsys.Config;
import com.bcbssc.registration.common.CommonUtils;

/**
 * <p>ConfigValue class.</p>
 *
 * @author XR93
 *
 * Load a value from the config file. Section and Key passed in the requesting
 * page.
 * @version $Id: $Id
 */
public class ConfigValue extends TagSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7740719480328929964L;

	/** log4j logger */
	private static final Logger log = Logger.getLogger(ConfigValue.class
			.getName());

	/** tag section in ini file */
	protected String section = null;

	/** tag key in ini file */
	protected String key = null;

	/**
	 * Returns the value from the ini file.
	 *
	 * @return page body evaluation specifier.
	 * @throws javax.servlet.jsp.JspException if any.
	 */
	public int doStartTag() throws JspException {
		final StringBuffer message = new StringBuffer(128);

		try {

			final String iniFile = CommonUtils.getIniFile(this.pageContext
					.getServletContext());

			// Retrieve the message string we are looking for
			TagUtils.getInstance().message(this.pageContext, Globals.MESSAGES_KEY,
					Globals.LOCALE_KEY, this.section);
			TagUtils.getInstance().message(this.pageContext, Globals.MESSAGES_KEY,
					Globals.LOCALE_KEY, this.key);

			Properties prop = Config.getConfigSection(this.section, iniFile);
			String value = (String) prop.get(this.key);
			if (ConfigValue.log.isDebugEnabled()) {
				ConfigValue.log.debug("section [" + this.section + "] "
						+ " key " + this.key + " = " + value);
			}
			message.append(value);
		} catch (Exception e) {
			ConfigValue.log.error("Error reading config value from inifile", e);
			message.append("<!-- Error reading config value from inifile: ")
					.append(e.getMessage()).append("-->");
		}

		// Print the retrieved message to our output writer
		TagUtils.getInstance().write(this.pageContext, message.toString());

		// Continue processing this page
		return Tag.SKIP_BODY;
	}

	/**
	 * Set key value
	 *
	 * @param string a {@link java.lang.String} object.
	 */
	public void setKey(String string) {
		this.key = string;
	}

	/**
	 * set section value
	 *
	 * @param string a {@link java.lang.String} object.
	 */
	public void setSection(String string) {
		this.section = string;
	}

}
