package com.bcbssc.commercial.registration.core;

/**
 * <p>ContextMapper interface.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public interface ContextMapper {

	/**
	 * <p>mapToContext.</p>
	 *
	 * @param objectToMap a {@link java.lang.Object} object.
	 * @return a {@link com.bcbssc.commercial.registration.core.DirContextOperations} object.
	 */
	public DirContextOperations mapToContext(Object objectToMap);
	
	/**
	 * <p>mapFromContext.</p>
	 *
	 * @param ctx a {@link com.bcbssc.commercial.registration.core.DirContextOperations} object.
	 * @return a {@link java.lang.Object} object.
	 */
	public Object mapFromContext(DirContextOperations ctx);	
}
