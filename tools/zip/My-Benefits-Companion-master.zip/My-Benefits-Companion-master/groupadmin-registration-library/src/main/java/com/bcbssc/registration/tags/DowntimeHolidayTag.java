/*
 * @(#)DowntimeHolidayTag.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.registration.tags;

import javax.servlet.ServletContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;
import org.apache.struts.Globals;
import org.apache.struts.taglib.TagUtils;
import com.bcbssc.netsys.Config;

import com.bcbssc.registration.common.Constants;
import com.bcbssc.registration.tds.ProfileManagementService;


/**
 * Shared Registration Downtime/Holiday Tag
 *
 * This class provides support for the downtime/holiday tag. Because the
 * downtime message is read from LDAP, this class must be extended by a class
 * providing a getIniFile method that returns an application-specific INI file
 * that contains the LDAP connection parameters. See the CgaDowntimeTag class
 * for an example.
 *
 * @author Rao Peddi X94S
 * @version $Revision:   1.0  $
 * @author jc33
 */
public abstract class DowntimeHolidayTag extends TagSupport {

	/**
	 *
	 */
	private static final long serialVersionUID = -1084564152563296781L;

	/** log4j logger */
	private static Logger log = Logger.getLogger(DowntimeTag.class);

	/** exception description */
	private static final String EXCEPTION_DOWNTIME = "Error getting downtime/holiday message";

	/** tag key value */
	protected String key = null;

	/**
	 * Returns the name of the application-specific INI file containing the LDAP
	 * connection parameters.
	 *
	 * @return name of the INI file
	 * @param context a {@link javax.servlet.ServletContext} object.
	 */
	protected abstract String getTDSIniFile(ServletContext context);
	/**
	 * <p>getIniFile.</p>
	 *
	 * @param context a {@link javax.servlet.ServletContext} object.
	 * @return a {@link java.lang.String} object.
	 */
	protected abstract String getIniFile(ServletContext context);

	/**
	 * Generates the holiday/downtime message based on the contents of the
	 * property specified by the key.
	 *
	 * @return page body evaluation specifier
	 * @throws javax.servlet.jsp.JspException if any.
	 */
	public int doStartTag() throws JspException {

		String message;

		// Retrieve the message string we are looking for
		String messagetype = TagUtils.getInstance().message(this.pageContext,
				Globals.MESSAGES_KEY, Globals.LOCALE_KEY, this.key);
		if (messagetype == null) {
			StringBuffer error = new StringBuffer(64);
			error.append("<!-- could not get message; invalid key: ").append(
					this.key).append("-->");
			message = error.toString();

		} else {
			String tdsInifile = this.getTDSIniFile(this.pageContext
					.getServletContext());
			String iniFile = this.getIniFile(this.pageContext
					.getServletContext());


			message = DowntimeHolidayTag.getMessage(messagetype,iniFile, tdsInifile);

			// Display commented out explanation if there is no message
			if ((message == null) || (message.length() == 0)) {
				StringBuffer error = new StringBuffer(64);
				error.append("<!-- no message or invalid messagetype: ")
						.append(messagetype).append("-->");
				message = error.toString();
			}
		}

		// Print the retrieved message to our output writer
		TagUtils.getInstance().write(this.pageContext, message);

		// Continue processing this page
		return Tag.SKIP_BODY;
	}

	/**
	 * Sets the key value
	 *
	 * @param value a {@link java.lang.String} object.
	 */
	public void setKey(String value) {
		this.key = value;
	}

	/**
	 * Gets the holiday/downtime message
	 *
	 * @param messageType
	 *            type of message ("holiday" or "downtime")
	 * @return holiday message or null if the message could not be read
	 * @param iniFile a {@link java.lang.String} object.
	 * @param tdsIniFile a {@link java.lang.String} object.
	 */
	public static String getMessage(String messageType,String iniFile, String tdsIniFile) {

		try {

			String searchDN = Config.getPrivateProfileString(
					Constants.INI_LOCAL_SECTION,
					Constants.INI_ROLE_BASE,
					com.bcbssc.struts.common.Constants.BLANK_STRING,
					iniFile);
			 String orgDN = "cn="+Constants.TDS_LDAP_ORG_ROLE+","+searchDN;
			String baseDN = Config.getPrivateProfileString(
					Constants.INI_LOCAL_SECTION,
					Constants.TDS_BASE,
					com.bcbssc.struts.common.Constants.BLANK_STRING,
					iniFile);

		return ProfileManagementService.Factory.getHolidayDowntimeMessage(baseDN, searchDN, orgDN, messageType, tdsIniFile);



		} catch (Exception e) {
			DowntimeHolidayTag.log.warn(DowntimeHolidayTag.EXCEPTION_DOWNTIME, e);

			// Not getting the downtime message is not the end of the world
			return null;
		}

	}
}
