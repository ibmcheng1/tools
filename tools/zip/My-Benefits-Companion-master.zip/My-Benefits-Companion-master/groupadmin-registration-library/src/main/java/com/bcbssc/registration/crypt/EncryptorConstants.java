/**
 * 
 */
package com.bcbssc.registration.crypt;

/**
 * The interface bcbsScEncryptor was not being implemented, and instead only
 *  was being used for its String definitions.  This Constants file contains
 *  the Strings originally in the interface, to avoid confusion of references to
 *  a dangling, unimplemented interface.
 *  The interface remains in MyBenefitsCompanion_1 and 2 with a D tag, if it needs
 *  to be resurrected in the future.
 *
 * @author mf36
 * @version $Id: $Id
 */
public class EncryptorConstants {

    /** Constant <code>DES="DES"</code> */
    public static final String DES = "DES";
    /** Constant <code>DES_CBC_NOPADDING="DES/CBC/NoPadding"</code> */
    public static final String DES_CBC_NOPADDING = "DES/CBC/NoPadding";
    /** Constant <code>DES_CBC_PKCS5PADDING="DES/CBC/PKCS5Padding"</code> */
    public static final String DES_CBC_PKCS5PADDING = "DES/CBC/PKCS5Padding";
    /** Constant <code>DES_CFB_NOPADDING="DES/CFB/NoPadding"</code> */
    public static final String DES_CFB_NOPADDING = "DES/CFB/NoPadding";
    /** Constant <code>DES_CFB_PKCS5PADDING="DES/CFB/PKCS5Padding"</code> */
    public static final String DES_CFB_PKCS5PADDING = "DES/CFB/PKCS5Padding";
    /** Constant <code>DES_ECB_NOPADDING="DES/ECB/NoPadding"</code> */
    public static final String DES_ECB_NOPADDING = "DES/ECB/NoPadding";
    /** Constant <code>DES_ECB_PKCS5PADDING="DES/ECB/PKCS5Padding"</code> */
    public static final String DES_ECB_PKCS5PADDING = "DES/ECB/PKCS5Padding";
    /** Constant <code>DES_OFB_NOPADDING="DES/OFB/NoPadding"</code> */
    public static final String DES_OFB_NOPADDING = "DES/OFB/NoPadding";
    /** Constant <code>DES_OFB_PKCS5PADDING="DES/OFB/PKCS5Padding"</code> */
    public static final String DES_OFB_PKCS5PADDING = "DES/OFB/PKCS5Padding";
    
    /** Constant <code>TRIPLEDES="DESede"</code> */
    public static final String TRIPLEDES = "DESede";
    /** Constant <code>TRIPLEDES_CBC_NOPADDING="DESede/CBC/NoPadding"</code> */
    public static final String TRIPLEDES_CBC_NOPADDING = "DESede/CBC/NoPadding";
    /** Constant <code>TRIPLEDES_CBC_PKCS5PADDING="DESede/CBC/PKCS5Padding"</code> */
    public static final String TRIPLEDES_CBC_PKCS5PADDING = "DESede/CBC/PKCS5Padding";
    /** Constant <code>TRIPLEDES_CFB_NOPADDING="DESede/CFB/NoPadding"</code> */
    public static final String TRIPLEDES_CFB_NOPADDING = "DESede/CFB/NoPadding";
    /** Constant <code>TRIPLEDES_CFB_PKCS5PADDING="DESede/CFB/PKCS5Padding"</code> */
    public static final String TRIPLEDES_CFB_PKCS5PADDING = "DESede/CFB/PKCS5Padding";
    /** Constant <code>TRIPLEDES_ECB_NOPADDING="DESede/ECB/NoPadding"</code> */
    public static final String TRIPLEDES_ECB_NOPADDING = "DESede/ECB/NoPadding";
    /** Constant <code>TRIPLEDES_ECB_PKCS5PADDING="DESede/ECB/PKCS5Padding"</code> */
    public static final String TRIPLEDES_ECB_PKCS5PADDING = "DESede/ECB/PKCS5Padding";
    /** Constant <code>TRIPLEDES_OFB_NOPADDING="DESede/OFB/NoPadding"</code> */
    public static final String TRIPLEDES_OFB_NOPADDING = "DESede/OFB/NoPadding";
    /** Constant <code>TRIPLEDES_OFB_PKCS5PADDING="DESede/OFB/PKCS5Padding"</code> */
    public static final String TRIPLEDES_OFB_PKCS5PADDING = "DESede/OFB/PKCS5Padding";
    
    /** Constant <code>BLOWFISH="Blowfish"</code> */
    public static final String BLOWFISH = "Blowfish";
    /** Constant <code>BLOWFISH_CBC_NOPADDING="Blowfish/CBC/NoPadding"</code> */
    public static final String BLOWFISH_CBC_NOPADDING = "Blowfish/CBC/NoPadding";
    /** Constant <code>BLOWFISH_CBC_PKCS5PADDING="Blowfish/CBC/PKCS5Padding"</code> */
    public static final String BLOWFISH_CBC_PKCS5PADDING = "Blowfish/CBC/PKCS5Padding";
    /** Constant <code>BLOWFISH_CFB_NOPADDING="Blowfish/CFB/NoPadding"</code> */
    public static final String BLOWFISH_CFB_NOPADDING = "Blowfish/CFB/NoPadding";
    /** Constant <code>BLOWFISH_CFB_PKCS5PADDING="Blowfish/CFB/PKCS5Padding"</code> */
    public static final String BLOWFISH_CFB_PKCS5PADDING = "Blowfish/CFB/PKCS5Padding";
    /** Constant <code>BLOWFISH_ECB_NOPADDING="Blowfish/ECB/NoPadding"</code> */
    public static final String BLOWFISH_ECB_NOPADDING = "Blowfish/ECB/NoPadding";
    /** Constant <code>BLOWFISH_ECB_PKCS5PADDING="Blowfish/ECB/PKCS5Padding"</code> */
    public static final String BLOWFISH_ECB_PKCS5PADDING = "Blowfish/ECB/PKCS5Padding";
    /** Constant <code>BLOWFISH_OFB_NOPADDING="Blowfish/OFB/NoPadding"</code> */
    public static final String BLOWFISH_OFB_NOPADDING = "Blowfish/OFB/NoPadding";
    /** Constant <code>BLOWFISH_OFB_PKCS5PADDING="Blowfish/OFB/PKCS5Padding"</code> */
    public static final String BLOWFISH_OFB_PKCS5PADDING = "Blowfish/OFB/PKCS5Padding";
}
