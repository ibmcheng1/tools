/*
 * @(#)SetPermissionsAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.registration.actions;

import com.bcbssc.registration.dto.UserDTO;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * Shared Registration Set Permissions Action
 *
 * This class provides the simplest extension of AbstractSecureAction. It should
 * be used when only the permissions setting of that class is required (for the
 * menu banner only without additional services).
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public abstract class SetPermissionsAction extends AbstractSecureAction {

	/** log4j logger */
	private static Logger logger = Logger.getLogger(SetPermissionsAction.class);

	/**
	 * {@inheritDoc}
	 *
	 *************************************************************************
	 * Process the specified HTTP request, and create the corresponding HTTP
	 * response (or forward to another web component that will create it).
	 * Return an <code>ActionForward</code> instance describing where and how
	 * control should be forwarded, or <code>null</code> if the response has
	 * already been completed.
	 * @exception Exception
	 *                if business logic throws an exception
	 */
	public ActionForward execute(UserDTO user, ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		if (SetPermissionsAction.logger.isDebugEnabled()) {
			SetPermissionsAction.logger
					.debug("Executing SetPermissionsAction.execute()");
		}

		return (mapping.findForward("success"));
	}
}
