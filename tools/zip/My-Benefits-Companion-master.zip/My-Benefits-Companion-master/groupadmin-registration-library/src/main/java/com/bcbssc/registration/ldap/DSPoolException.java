/*
 * @(#)DSPoolException.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.registration.ldap;

/**
 * Dsmart Pool Exception
 *
 * The netsys.dsmart classes return java.lang.Exception for many of the pooling
 * method calls. This class, when thrown on a catch of the general
 * java.lang.Exception on these methods, provides finer-grain information about
 * this exception.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class DSPoolException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2684527275415252546L;

	/** Constant <code>CHECK_OUT="check out"</code> */
	public static final String CHECK_OUT = "check out";

	/** Constant <code>CHECK_IN="check in"</code> */
	public static final String CHECK_IN = "check in";

	private String errorType;

	/**
	 * Class constructor
	 *
	 * @param errorType
	 *            specifies the type of pool exception
	 */
	public DSPoolException(String errorType) {
		this.errorType = errorType;
	}

	/**
	 * Returns a message describing the pool exception
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String toString() {
		StringBuffer msg = new StringBuffer(64);
		msg.append("DSPoolException occured during ").append(this.errorType);
		return (msg.toString());
	}
}
