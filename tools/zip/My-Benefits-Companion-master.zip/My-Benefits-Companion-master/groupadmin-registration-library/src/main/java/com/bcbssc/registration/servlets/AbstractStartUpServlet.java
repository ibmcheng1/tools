/*
 * @(#)AbstractStartUpServlet.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.registration.servlets;

import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.Logger;

/**
 * Base Abstract Initialization or Startup Servlet.
 *
 * This class provides an ancestor for all startup servlet type activities. It
 * adds the servlet arguments into the servlet context and provides hooks for
 * additional app-specific startup processing (e.g., log4j setup).
 *
 * This class was derived from the DeskManager abstraction startup servlet.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public abstract class AbstractStartUpServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * The log4j <CODE>Logger</CODE> for this class to be initialized in the
	 * preprocess method of a subclass.
	 */
	protected Logger log = null;

	/**
	 * {@inheritDoc}
	 *
	 * Called by the Web Container when a Servlet has been configured to be
	 * dynamically loaded by the Container at startup time.
	 */
	public void init(ServletConfig config) throws ServletException {
		super.init(config);

		// optional hook for a derived class to provide pre processing
		// capability
		this.preprocess();

		// Set InialArgs into servletContext
		this.initializeContext(config, config.getServletContext());

		// optional hook for a derived class to provide post processing
		// capability
		this.postprocess();
	}

	/**
	 * Read passed in name value pairs and store at application scope. Use the
	 * AppId name concatenated with .ini to read initialization files and store
	 * these in application context also.
	 *
	 * @param config
	 *            configuration value pairs passed by the web container
	 * @param context
	 *            servlet context passed by the web container
	 */
	protected void initializeContext(ServletConfig config,
			ServletContext context) {

		StringBuffer valuePairs = new StringBuffer(128);

		// set Servlet initial Arguments into ServletContext Example: strAppId
		// etc
		Enumeration e = config.getInitParameterNames();

		while (e.hasMoreElements()) {
			String arg = ((String) e.nextElement()).trim();
			String argValue = config.getInitParameter(arg);

			if ((arg != null) && (argValue != null)) {
				context.setAttribute(arg, argValue);
				if ((this.log != null) && this.log.isDebugEnabled()) {
					valuePairs.append(arg).append(" = ").append(argValue)
							.append(",");
				}
			}
		}

		if ((this.log != null) && this.log.isDebugEnabled()) {
			this.log
					.debug("Initial Config Params are " + valuePairs.toString());
		}
	}

	/**
	 * Hook to allow extension layers extended or new initialization
	 * capabilities
	 *
	 * @throws javax.servlet.ServletException if any.
	 */
	protected abstract void preprocess() throws ServletException;

	/**
	 * Hook to allow extension layers extended or new initialization
	 * capabilities
	 */
	protected void postprocess() {
		// Hook to allow extension layers extended or new initialization
		// capabilities
	}
}
