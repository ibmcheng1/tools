
package com.bcbssc.commercial.registration.core;

import javax.naming.directory.Attributes;

/**
 * Interface for DirContextAdapter.
 *
 * @author jc33
 * @version $Id: $Id
 */
public interface DirContextOperations {

	/**
	 * Get the value of a String attribute. If more than one attribute value
	 * exists for the specified attribute, only the first one will be returned.
	 *
	 * @param name name of the attribute.
	 * @return the value of the attribute.
	 * @throws java.lang.ClassCastException if the value of the entry is not a String.
	 */
	String getStringAttribute(String name);

	/**
	 * Get the value of an Object attribute. If more than one attribute value
	 * exists for the specified attribute, only the first one will be returned.
	 *
	 * @param name name of the attribute.
	 * @return the attribute value as an object if it exists, or
	 * <code>null</code> otherwise.
	 */
	Object getObjectAttribute(String name);

	/**
	 * Set the with the name <code>name</code> to the <code>value</code>.
	 *
	 * @param name name of the attribute.
	 * @param value value to set the attribute to.
	 */
	public void setAttributeValue(String name, Object value);

	/**
	 * Sets a multivalue attribute, disregarding the order of the values.
	 *
	 * If value is null or value.length == 0 then the attribute will be removed.
	 *
	 * If update mode, changes will be made only if the array has more or less
	 * objects or if one or more object has changed. Reordering the objects will
	 * not cause an update.
	 *
	 * @param name The id of the attribute.
	 * @param values Attribute values.
	 */
	void setAttributeValues(String name, Object[] values);

	/**
	 * Sets a multivalue attribute.
	 *
	 * If value is null or value.length == 0 then the attribute will be removed.
	 *
	 * If update mode, changes will be made if the array has more or less
	 * objects or if one or more string has changed.
	 *
	 * Reordering the objects will only cause an update if orderMatters is set
	 * to true.
	 *
	 * @param name The id of the attribute.
	 * @param values Attribute values.
	 * @param orderMatters If <code>true</code>, it will be changed even if data
	 * was just reordered.
	 */
	void setAttributeValues(String name, Object[] values, boolean orderMatters);

	/**
	 * Get all values of a String attribute.
	 *
	 * @param name name of the attribute.
	 * @return a (possibly empty) array containing all registered values of the
	 * attribute as Strings if the attribute is defined or <code>null</code>
	 * otherwise.
	 * @throws java.lang.ArrayStoreException if any of the attribute values is not a
	 * String.
	 */
	String[] getStringAttributes(String name);

	/**
	 * Get all values of an Object attribute.
	 *
	 * @param name name of the attribute.
	 * @return a (possibly empty) array containing all registered values of the
	 * attribute if the attribute is defined or <code>null</code> otherwise.
	 * @since 1.3
	 */
	Object[] getObjectAttributes(String name);

	/**
	 * Get all the Attributes.
	 *
	 * @return all the Attributes.
	 * @since 1.3
	 */
	Attributes getAttributes();
}
