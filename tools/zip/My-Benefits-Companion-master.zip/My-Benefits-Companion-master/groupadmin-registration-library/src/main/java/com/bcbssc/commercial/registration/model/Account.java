/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2009 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : Account.java
 *
 * Created Date     : Oct 23, 2008
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Oct 23, 2008     Initial version for bcbssc-ldap
 */

package com.bcbssc.commercial.registration.model;

import java.io.Serializable;

import com.bcbssc.netsys.web.SessionDataBean;

/**
 * <p>Account class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class Account extends SessionDataBean implements Serializable {
	
	private static final long serialVersionUID 			= 5238463286234876233L;
	
	private String username;
	
	private String password;
	
	private String bcbsgroup;
	
	private String commonName;
	
	private String dateOfAcceptance;
	
	private String challenge;
	
	private String challengeResponse;
	
	private String name;
	
	private String firstName;
	
	private String middleInitial;
	
	private String lastName;
	
	private String bcbsLastAccessTime;
	
	private String whenCreated;
	
	private String mail;
	
	private String company;
	
	private String profileExists;
	
	private String currentPasswordField;

	private String ontAccessStatus;
	
	private String ontBadLoginCount;
	
	private String ontEndDate;
	
	private String ontOrganizationDn;
	
	private String ontPasswordResetDate;
	
	private String ontPasswordStatus;
	
	private String[] ontRoleDn;
	
	private String ontStartDate;

	private String ontTimeout;
	
	private String ontValidObject;
	
	private String addressLineOne;
	
	private String addressLineTwo;
	
	private String distinguishedName;
	
	private String dentalNotificationCounter;
	
	private String notificationCounter;
	
	private String preferredMethodOfContact;
	
	private String suffix;
	
	private String[] objectClass;

	private String city;
	
	private String state;
	
	private String postalCode;
	
	private String userAccountControl;
		
	private String telephoneNumber;
	
	private String telephoneExtn;
	
	private String telephoneNumberAreaCode;
	
	private String telephoneNumberPrefix;
	
	private String telephoneNumberSuffix;
	
	private String facsimileTelephoneNumber;
	
	private String facsimileTelephoneExtn;
	
	private String faxAreaCode;
	
	private String faxPrefix;
	
	private String faxSuffix;

	/**
	 * <p>Getter for the field <code>username</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * <p>Setter for the field <code>username</code>.</p>
	 *
	 * @param username a {@link java.lang.String} object.
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * <p>Getter for the field <code>password</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * <p>Setter for the field <code>password</code>.</p>
	 *
	 * @param password a {@link java.lang.String} object.
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * <p>Getter for the field <code>bcbsgroup</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getBcbsgroup() {
		return bcbsgroup;
	}

	/**
	 * <p>Setter for the field <code>bcbsgroup</code>.</p>
	 *
	 * @param bcbsgroup a {@link java.lang.String} object.
	 */
	public void setBcbsgroup(String bcbsgroup) {
		this.bcbsgroup = bcbsgroup;
	}

	/**
	 * <p>Getter for the field <code>commonName</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getCommonName() {
		return commonName;
	}

	/**
	 * <p>Setter for the field <code>commonName</code>.</p>
	 *
	 * @param commonName a {@link java.lang.String} object.
	 */
	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}

	/**
	 * <p>Getter for the field <code>dateOfAcceptance</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getDateOfAcceptance() {
		return dateOfAcceptance;
	}

	/**
	 * <p>Setter for the field <code>dateOfAcceptance</code>.</p>
	 *
	 * @param dateOfAcceptance a {@link java.lang.String} object.
	 */
	public void setDateOfAcceptance(String dateOfAcceptance) {
		this.dateOfAcceptance = dateOfAcceptance;
	}

	/**
	 * <p>Getter for the field <code>challenge</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getChallenge() {
		return challenge;
	}

	/**
	 * <p>Setter for the field <code>challenge</code>.</p>
	 *
	 * @param challenge a {@link java.lang.String} object.
	 */
	public void setChallenge(String challenge) {
		this.challenge = challenge;
	}

	/**
	 * <p>Getter for the field <code>challengeResponse</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getChallengeResponse() {
		return challengeResponse;
	}

	/**
	 * <p>Setter for the field <code>challengeResponse</code>.</p>
	 *
	 * @param challengeResponse a {@link java.lang.String} object.
	 */
	public void setChallengeResponse(String challengeResponse) {
		this.challengeResponse = challengeResponse;
	}

	/**
	 * <p>Getter for the field <code>name</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getName() {
		return name;
	}

	/**
	 * <p>Setter for the field <code>name</code>.</p>
	 *
	 * @param name a {@link java.lang.String} object.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * <p>Getter for the field <code>firstName</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * <p>Setter for the field <code>firstName</code>.</p>
	 *
	 * @param firstName a {@link java.lang.String} object.
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * <p>Getter for the field <code>middleInitial</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getMiddleInitial() {
		return middleInitial;
	}

	/**
	 * <p>Setter for the field <code>middleInitial</code>.</p>
	 *
	 * @param middleInitial a {@link java.lang.String} object.
	 */
	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}

	/**
	 * <p>Getter for the field <code>lastName</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * <p>Setter for the field <code>lastName</code>.</p>
	 *
	 * @param lastName a {@link java.lang.String} object.
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * <p>Getter for the field <code>bcbsLastAccessTime</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getBcbsLastAccessTime() {
		return bcbsLastAccessTime;
	}

	/**
	 * <p>Setter for the field <code>bcbsLastAccessTime</code>.</p>
	 *
	 * @param bcbsLastAccessTime a {@link java.lang.String} object.
	 */
	public void setBcbsLastAccessTime(String bcbsLastAccessTime) {
		this.bcbsLastAccessTime = bcbsLastAccessTime;
	}

	/**
	 * <p>Getter for the field <code>whenCreated</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getWhenCreated() {
		return whenCreated;
	}

	/**
	 * <p>Setter for the field <code>whenCreated</code>.</p>
	 *
	 * @param whenCreated a {@link java.lang.String} object.
	 */
	public void setWhenCreated(String whenCreated) {
		this.whenCreated = whenCreated;
	}

	/**
	 * <p>Getter for the field <code>mail</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getMail() {
		return mail;
	}

	/**
	 * <p>Setter for the field <code>mail</code>.</p>
	 *
	 * @param mail a {@link java.lang.String} object.
	 */
	public void setMail(String mail) {
		this.mail = mail;
	}

	/**
	 * <p>Getter for the field <code>company</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getCompany() {
		return company;
	}

	/**
	 * <p>Setter for the field <code>company</code>.</p>
	 *
	 * @param company a {@link java.lang.String} object.
	 */
	public void setCompany(String company) {
		this.company = company;
	}

	/**
	 * <p>Getter for the field <code>profileExists</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getProfileExists() {
		return profileExists;
	}

	/**
	 * <p>Setter for the field <code>profileExists</code>.</p>
	 *
	 * @param profileExists a {@link java.lang.String} object.
	 */
	public void setProfileExists(String profileExists) {
		this.profileExists = profileExists;
	}

	/**
	 * <p>Getter for the field <code>currentPasswordField</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getCurrentPasswordField() {
		return currentPasswordField;
	}

	/**
	 * <p>Setter for the field <code>currentPasswordField</code>.</p>
	 *
	 * @param currentPasswordField a {@link java.lang.String} object.
	 */
	public void setCurrentPasswordField(String currentPasswordField) {
		this.currentPasswordField = currentPasswordField;
	}

	/**
	 * <p>Getter for the field <code>ontAccessStatus</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getOntAccessStatus() {
		return ontAccessStatus;
	}

	/**
	 * <p>Setter for the field <code>ontAccessStatus</code>.</p>
	 *
	 * @param ontAccessStatus a {@link java.lang.String} object.
	 */
	public void setOntAccessStatus(String ontAccessStatus) {
		this.ontAccessStatus = ontAccessStatus;
	}

	/**
	 * <p>Getter for the field <code>ontBadLoginCount</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getOntBadLoginCount() {
		return ontBadLoginCount;
	}

	/**
	 * <p>Setter for the field <code>ontBadLoginCount</code>.</p>
	 *
	 * @param ontBadLoginCount a {@link java.lang.String} object.
	 */
	public void setOntBadLoginCount(String ontBadLoginCount) {
		this.ontBadLoginCount = ontBadLoginCount;
	}

	/**
	 * <p>Getter for the field <code>ontEndDate</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getOntEndDate() {
		return ontEndDate;
	}

	/**
	 * <p>Setter for the field <code>ontEndDate</code>.</p>
	 *
	 * @param ontEndDate a {@link java.lang.String} object.
	 */
	public void setOntEndDate(String ontEndDate) {
		this.ontEndDate = ontEndDate;
	}

	/**
	 * <p>Getter for the field <code>ontOrganizationDn</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getOntOrganizationDn() {
		return ontOrganizationDn;
	}

	/**
	 * <p>Setter for the field <code>ontOrganizationDn</code>.</p>
	 *
	 * @param ontOrganizationDn a {@link java.lang.String} object.
	 */
	public void setOntOrganizationDn(String ontOrganizationDn) {
		this.ontOrganizationDn = ontOrganizationDn;
	}

	/**
	 * <p>Getter for the field <code>ontPasswordResetDate</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getOntPasswordResetDate() {
		return ontPasswordResetDate;
	}

	/**
	 * <p>Setter for the field <code>ontPasswordResetDate</code>.</p>
	 *
	 * @param ontPasswordResetDate a {@link java.lang.String} object.
	 */
	public void setOntPasswordResetDate(String ontPasswordResetDate) {
		this.ontPasswordResetDate = ontPasswordResetDate;
	}

	/**
	 * <p>Getter for the field <code>ontPasswordStatus</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getOntPasswordStatus() {
		return ontPasswordStatus;
	}

	/**
	 * <p>Setter for the field <code>ontPasswordStatus</code>.</p>
	 *
	 * @param ontPasswordStatus a {@link java.lang.String} object.
	 */
	public void setOntPasswordStatus(String ontPasswordStatus) {
		this.ontPasswordStatus = ontPasswordStatus;
	}

	/**
	 * <p>Getter for the field <code>ontRoleDn</code>.</p>
	 *
	 * @return an array of {@link java.lang.String} objects.
	 */
	public String[] getOntRoleDn() {
		return ontRoleDn;
	}

	/**
	 * <p>Setter for the field <code>ontRoleDn</code>.</p>
	 *
	 * @param ontRoleDn an array of {@link java.lang.String} objects.
	 */
	public void setOntRoleDn(String[] ontRoleDn) {
		this.ontRoleDn = ontRoleDn;
	}

	/**
	 * <p>Getter for the field <code>ontStartDate</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getOntStartDate() {
		return ontStartDate;
	}

	/**
	 * <p>Setter for the field <code>ontStartDate</code>.</p>
	 *
	 * @param ontStartDate a {@link java.lang.String} object.
	 */
	public void setOntStartDate(String ontStartDate) {
		this.ontStartDate = ontStartDate;
	}

	/**
	 * <p>Getter for the field <code>ontTimeout</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getOntTimeout() {
		return ontTimeout;
	}

	/**
	 * <p>Setter for the field <code>ontTimeout</code>.</p>
	 *
	 * @param ontTimeout a {@link java.lang.String} object.
	 */
	public void setOntTimeout(String ontTimeout) {
		this.ontTimeout = ontTimeout;
	}

	/**
	 * <p>Getter for the field <code>ontValidObject</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getOntValidObject() {
		return ontValidObject;
	}

	/**
	 * <p>Setter for the field <code>ontValidObject</code>.</p>
	 *
	 * @param ontValidObject a {@link java.lang.String} object.
	 */
	public void setOntValidObject(String ontValidObject) {
		this.ontValidObject = ontValidObject;
	}

	/**
	 * <p>Getter for the field <code>addressLineOne</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getAddressLineOne() {
		return addressLineOne;
	}

	/**
	 * <p>Setter for the field <code>addressLineOne</code>.</p>
	 *
	 * @param addressLineOne a {@link java.lang.String} object.
	 */
	public void setAddressLineOne(String addressLineOne) {
		this.addressLineOne = addressLineOne;
	}

	/**
	 * <p>Getter for the field <code>addressLineTwo</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getAddressLineTwo() {
		return addressLineTwo;
	}

	/**
	 * <p>Setter for the field <code>addressLineTwo</code>.</p>
	 *
	 * @param addressLineTwo a {@link java.lang.String} object.
	 */
	public void setAddressLineTwo(String addressLineTwo) {
		this.addressLineTwo = addressLineTwo;
	}

	/**
	 * <p>Getter for the field <code>distinguishedName</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getDistinguishedName() {
		return distinguishedName;
	}

	/**
	 * <p>Setter for the field <code>distinguishedName</code>.</p>
	 *
	 * @param distinguishedName a {@link java.lang.String} object.
	 */
	public void setDistinguishedName(String distinguishedName) {
		this.distinguishedName = distinguishedName;
	}

	/**
	 * <p>Getter for the field <code>dentalNotificationCounter</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getDentalNotificationCounter() {
		return dentalNotificationCounter;
	}

	/**
	 * <p>Setter for the field <code>dentalNotificationCounter</code>.</p>
	 *
	 * @param dentalNotificationCounter a {@link java.lang.String} object.
	 */
	public void setDentalNotificationCounter(String dentalNotificationCounter) {
		this.dentalNotificationCounter = dentalNotificationCounter;
	}

	/**
	 * <p>Getter for the field <code>notificationCounter</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getNotificationCounter() {
		return notificationCounter;
	}

	/**
	 * <p>Setter for the field <code>notificationCounter</code>.</p>
	 *
	 * @param notificationCounter a {@link java.lang.String} object.
	 */
	public void setNotificationCounter(String notificationCounter) {
		this.notificationCounter = notificationCounter;
	}

	/**
	 * <p>Getter for the field <code>preferredMethodOfContact</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getPreferredMethodOfContact() {
		return preferredMethodOfContact;
	}

	/**
	 * <p>Setter for the field <code>preferredMethodOfContact</code>.</p>
	 *
	 * @param preferredMethodOfContact a {@link java.lang.String} object.
	 */
	public void setPreferredMethodOfContact(String preferredMethodOfContact) {
		this.preferredMethodOfContact = preferredMethodOfContact;
	}

	/**
	 * <p>Getter for the field <code>suffix</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getSuffix() {
		return suffix;
	}

	/**
	 * <p>Setter for the field <code>suffix</code>.</p>
	 *
	 * @param suffix a {@link java.lang.String} object.
	 */
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	/**
	 * <p>Getter for the field <code>objectClass</code>.</p>
	 *
	 * @return an array of {@link java.lang.String} objects.
	 */
	public String[] getObjectClass() {
		return objectClass;
	}

	/**
	 * <p>Setter for the field <code>objectClass</code>.</p>
	 *
	 * @param objectClass an array of {@link java.lang.String} objects.
	 */
	public void setObjectClass(String[] objectClass) {
		this.objectClass = objectClass;
	}

	/**
	 * <p>Getter for the field <code>city</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getCity() {
		return city;
	}

	/**
	 * <p>Setter for the field <code>city</code>.</p>
	 *
	 * @param city a {@link java.lang.String} object.
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * <p>Getter for the field <code>state</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getState() {
		return state;
	}

	/**
	 * <p>Setter for the field <code>state</code>.</p>
	 *
	 * @param state a {@link java.lang.String} object.
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * <p>Getter for the field <code>postalCode</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * <p>Setter for the field <code>postalCode</code>.</p>
	 *
	 * @param postalCode a {@link java.lang.String} object.
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * <p>Getter for the field <code>userAccountControl</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getUserAccountControl() {
		return userAccountControl;
	}

	/**
	 * <p>Setter for the field <code>userAccountControl</code>.</p>
	 *
	 * @param userAccountControl a {@link java.lang.String} object.
	 */
	public void setUserAccountControl(String userAccountControl) {
		this.userAccountControl = userAccountControl;
	}

	/**
	 * <p>Getter for the field <code>telephoneNumber</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getTelephoneNumber() {
		return telephoneNumber;
	}

	/**
	 * <p>Setter for the field <code>telephoneNumber</code>.</p>
	 *
	 * @param telephoneNumber a {@link java.lang.String} object.
	 */
	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	/**
	 * <p>Getter for the field <code>telephoneExtn</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getTelephoneExtn() {
		return telephoneExtn;
	}

	/**
	 * <p>Setter for the field <code>telephoneExtn</code>.</p>
	 *
	 * @param telephoneExtn a {@link java.lang.String} object.
	 */
	public void setTelephoneExtn(String telephoneExtn) {
		this.telephoneExtn = telephoneExtn;
	}

	/**
	 * <p>Getter for the field <code>telephoneNumberAreaCode</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getTelephoneNumberAreaCode() {
		return telephoneNumberAreaCode;
	}

	/**
	 * <p>Setter for the field <code>telephoneNumberAreaCode</code>.</p>
	 *
	 * @param telephoneNumberAreaCode a {@link java.lang.String} object.
	 */
	public void setTelephoneNumberAreaCode(String telephoneNumberAreaCode) {
		this.telephoneNumberAreaCode = telephoneNumberAreaCode;
	}

	/**
	 * <p>Getter for the field <code>telephoneNumberPrefix</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getTelephoneNumberPrefix() {
		return telephoneNumberPrefix;
	}

	/**
	 * <p>Setter for the field <code>telephoneNumberPrefix</code>.</p>
	 *
	 * @param telephoneNumberPrefix a {@link java.lang.String} object.
	 */
	public void setTelephoneNumberPrefix(String telephoneNumberPrefix) {
		this.telephoneNumberPrefix = telephoneNumberPrefix;
	}

	/**
	 * <p>Getter for the field <code>telephoneNumberSuffix</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getTelephoneNumberSuffix() {
		return telephoneNumberSuffix;
	}

	/**
	 * <p>Setter for the field <code>telephoneNumberSuffix</code>.</p>
	 *
	 * @param telephoneNumberSuffix a {@link java.lang.String} object.
	 */
	public void setTelephoneNumberSuffix(String telephoneNumberSuffix) {
		this.telephoneNumberSuffix = telephoneNumberSuffix;
	}

	/**
	 * <p>Getter for the field <code>facsimileTelephoneNumber</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getFacsimileTelephoneNumber() {
		return facsimileTelephoneNumber;
	}

	/**
	 * <p>Setter for the field <code>facsimileTelephoneNumber</code>.</p>
	 *
	 * @param facsimileTelephoneNumber a {@link java.lang.String} object.
	 */
	public void setFacsimileTelephoneNumber(String facsimileTelephoneNumber) {
		this.facsimileTelephoneNumber = facsimileTelephoneNumber;
	}

	/**
	 * <p>Getter for the field <code>facsimileTelephoneExtn</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getFacsimileTelephoneExtn() {
		return facsimileTelephoneExtn;
	}

	/**
	 * <p>Setter for the field <code>facsimileTelephoneExtn</code>.</p>
	 *
	 * @param facsimileTelephoneExtn a {@link java.lang.String} object.
	 */
	public void setFacsimileTelephoneExtn(String facsimileTelephoneExtn) {
		this.facsimileTelephoneExtn = facsimileTelephoneExtn;
	}

	/**
	 * <p>Getter for the field <code>faxAreaCode</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getFaxAreaCode() {
		return faxAreaCode;
	}

	/**
	 * <p>Setter for the field <code>faxAreaCode</code>.</p>
	 *
	 * @param faxAreaCode a {@link java.lang.String} object.
	 */
	public void setFaxAreaCode(String faxAreaCode) {
		this.faxAreaCode = faxAreaCode;
	}

	/**
	 * <p>Getter for the field <code>faxPrefix</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getFaxPrefix() {
		return faxPrefix;
	}

	/**
	 * <p>Setter for the field <code>faxPrefix</code>.</p>
	 *
	 * @param faxPrefix a {@link java.lang.String} object.
	 */
	public void setFaxPrefix(String faxPrefix) {
		this.faxPrefix = faxPrefix;
	}

	/**
	 * <p>Getter for the field <code>faxSuffix</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getFaxSuffix() {
		return faxSuffix;
	}

	/**
	 * <p>Setter for the field <code>faxSuffix</code>.</p>
	 *
	 * @param faxSuffix a {@link java.lang.String} object.
	 */
	public void setFaxSuffix(String faxSuffix) {
		this.faxSuffix = faxSuffix;
	}
}
