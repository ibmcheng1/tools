/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUE CROSS AND BLUE SHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION, OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright (c) 2005 Blue Cross and Blue Shield of South Carolina.
 * All rights reserved.
 * An independent Licensee of the Blue Cross and Blue Shield Association.
 */
package com.bcbssc.registration.crypt;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.security.Security;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.apache.log4j.Logger;

/**
 * Creates an encryption object suitable for use in symmetric cryptography.
 */
public final class SymmetricCipher {

	/**
	 * constant indicating binary encoding
	 */
	public static final int BINARY_ENCODING = 0;

	/**
	 * constant indicating a big integer encoding **note this should not be used
	 * in any new development a issue occurs with negative numbers.
	 */
	public static final int BIG_INTEGER_ENCODING = 3;

	/**
	 * constant indicating hexadecimal encoding
	 */
	public static final int HEXADECIMAL_ENCODING = 1;

	/**
	 * constant representing Base64 encoding
	 */
	public static final int BASE64_ENCODING = 2;

	/**
	 * constant representing Raw or Default encoding
	 */
	public static final int DEFAULT_ENCODING = 3;

	/**
	 * key size required for DES encryption/decryption
	 */
	public static final int DES_KEY = 56;

	/**
	 * key size required for weak TripleDES encryption/decryption
	 */
	public static final int TRIPLEDES_KEY_WEAK = 112;

	/**
	 * key size required for strong TripleDES encryption/decryption
	 */
	public static final int TRIPLEDES_KEY_STRONG = 168;

	/**
	 * minimum key size for Blowfish encryption/decryption
	 */
	public static final int BLOWFISH_KEY_MIN = 32;

	/**
	 * maximum keysize for Blowfish encryption/decryption
	 */
	public static final int BLOWFISH_KEY_MAX = 448;

	/**
	 * logger for this class
	 */
	private static final Logger log = Logger.getLogger(SymmetricCipher.class);

	/**
	 * key value used for encryption in this SymmetricCipher
	 */
	private SecretKey key = null;

	/**
	 * initialization vector (if any) used for encryption in this
	 * SymmetricCipher
	 */
	private IvParameterSpec iv = null;

	/**
	 * symmetric cipher (algorithm) used for encryption in this SymmetricCipher
	 */
	private Cipher cipher = null;

	/**
	 * creates a new <code>SymmetricCipher</code> object
	 *
	 * @param key
	 *            <code>File</code> containing value used to construct the
	 *            <code>SecretKey</code> for this object
	 * @param encoding
	 *            encoding in which the key of this object has been stored
	 * @param algorithm
	 *            symmetric cipher algorithm used by this object
	 * @throws com.bcbssc.registration.crypt.BcbsScCipherException if any.
	 * @throws java.io.IOException if any.
	 */
	public SymmetricCipher(File key, int encoding, String algorithm)
			throws BcbsScCipherException, IOException {
		this(key, encoding, algorithm, null);
	}

	/**
	 * creates a new <code>SymmetricCipher</code> object
	 *
	 * @param key
	 *            <code>File</code> containing value used to construct the
	 *            <code>SecretKey</code> for this object
	 * @param encoding
	 *            encoding in which the key of this object has been stored
	 * @param algorithm
	 *            symmetric cipher algorithm used by this object
	 * @param provider
	 *            security provider providing an implementation of the symmetric
	 *            cipher used by this object
	 * @throws com.bcbssc.registration.crypt.BcbsScCipherException if any.
	 * @throws java.io.IOException if any.
	 */
	public SymmetricCipher(File key, int encoding, String algorithm,
			Provider provider) throws BcbsScCipherException, IOException {
		this(key, null, encoding, algorithm, provider);
	}

	/**
	 * creates a new <code>SymmetricCipher</code> object
	 *
	 * @param key
	 *            <code>File</code> containing value used to construct the
	 *            <code>SecretKey</code> for this object
	 * @param iv
	 *            <code>File</code> containing the initialization vector of
	 *            this object
	 * @param encoding
	 *            encoding in which the key and initialization vector of this
	 *            object have been stored
	 * @param algorithm
	 *            symmetric cipher algorithm used by this object
	 * @throws com.bcbssc.registration.crypt.BcbsScCipherException if any.
	 * @throws java.io.IOException if any.
	 */
	public SymmetricCipher(File key, File iv, int encoding, String algorithm)
			throws BcbsScCipherException, IOException {
		this(key, iv, encoding, algorithm, null);
	}

	/**
	 * creates a new <code>SymmetricCipher</code> object
	 *
	 * @param key
	 *            <code>File</code> containing value used to construct the
	 *            <code>SecretKey</code> for this object
	 * @param iv
	 *            <code>File</code> containing the initialization vector of
	 *            this object
	 * @param encoding
	 *            encoding in which the key and initialization vector of this
	 *            object have been stored
	 * @param algorithm
	 *            symmetric cipher algorithm used by this object
	 * @param provider
	 *            security provider providing an implementation of the symmetric
	 *            cipher used by this object
	 * @throws com.bcbssc.registration.crypt.BcbsScCipherException
	 *             if a cipher error occurs
	 * @throws java.io.IOException if any.
	 */
	public SymmetricCipher(File key, File iv, int encoding, String algorithm,
			Provider provider) throws BcbsScCipherException, IOException {
		byte[] keyBytes = this.readFile(key);
		byte[] ivBytes = null;
		if (iv != null) {
			ivBytes = this.readFile(iv);
		}
		this.init(keyBytes, ivBytes, encoding, algorithm, provider);
		if (SymmetricCipher.log.isDebugEnabled()) {
			SymmetricCipher.log.debug("Created SymmetricCipher object.");
		}
	}

	/**
	 * creates a new <code>SymmetricCipher</code> object
	 *
	 * @param key
	 *            value used to construct the <code>SecretKey</code> for this
	 *            object
	 * @param encoding
	 *            encoding in which the key and initialization vector of this
	 *            object have been stored
	 * @param algorithm
	 *            symmetric cipher algorithm used by this object
	 * @throws com.bcbssc.registration.crypt.BcbsScCipherException if any.
	 */
	public SymmetricCipher(String key, int encoding, String algorithm)
			throws BcbsScCipherException {
		this(key, encoding, algorithm, null);
	}

	/**
	 * creates a new <code>SymmetricCipher</code> object
	 *
	 * @param key
	 *            value used to construct the <code>SecretKey</code> for this
	 *            object
	 * @param encoding
	 *            encoding in which the key and initialization vector of this
	 *            object have been stored
	 * @param algorithm
	 *            symmetric cipher algorithm used by this object
	 * @param provider
	 *            security provider providing an implementation of the symmetric
	 *            cipher used by this object
	 * @throws com.bcbssc.registration.crypt.BcbsScCipherException if any.
	 */
	public SymmetricCipher(String key, int encoding, String algorithm,
			Provider provider) throws BcbsScCipherException {
		this(key, null, encoding, algorithm, provider);
	}

	/**
	 * creates a new <code>SymmetricCipher</code> object
	 *
	 * @param key
	 *            value used to construct the <code>SecretKey</code> for this
	 *            object
	 * @param iv
	 *            initialization vector of this object
	 * @param encoding
	 *            encoding in which the key and initialization vector of this
	 *            object have been stored
	 * @param algorithm
	 *            symmetric cipher algorithm used by this object
	 * @throws com.bcbssc.registration.crypt.BcbsScCipherException if any.
	 */
	public SymmetricCipher(String key, String iv, int encoding, String algorithm)
			throws BcbsScCipherException {
		this(key, iv, encoding, algorithm, null);
	}

	/**
	 * creates a new <code>SymmetricCipher</code> object
	 *
	 * @param key
	 *            value used to construct the <code>SecretKey</code> for this
	 *            object
	 * @param iv
	 *            initialization vector of this object
	 * @param encoding
	 *            encoding in which the key and initialization vector of this
	 *            object have been stored
	 * @param algorithm
	 *            symmetric cipher algorithm used by this object
	 * @param provider
	 *            security provider providing an implementation of the symmetric
	 *            cipher used by this object
	 * @throws com.bcbssc.registration.crypt.BcbsScCipherException if any.
	 */
	public SymmetricCipher(String key, String iv, int encoding,
			String algorithm, Provider provider) throws BcbsScCipherException {
		this.init(key.getBytes(), iv.getBytes(), encoding, algorithm, provider);
		if (SymmetricCipher.log.isDebugEnabled()) {
			SymmetricCipher.log.debug("Created SymmetricCipher object.");
		}
	}

	/**
	 * creates a new <code>SymmetricCipher</code> object
	 *
	 * @param key
	 *            value used to construct the <code>SecretKey</code> for this
	 *            object
	 * @param keyEncoding
	 *            encoding for Key in which the encoding for Key is stored
	 * @param keyEncoding
	 *            encoding for Key in which the encoding for Key is stored
	 * @param keyEncoding
	 *            encoding for Key in which the encoding for Key is stored
	 * @param keyEncoding
	 *            encoding for Key in which the encoding for Key is stored
	 * @param iv
	 *            initialization vector of this object
	 * @param ivEncoding
	 *            encoding for IV in which the encoding for initialization
	 *            vector is stored
	 * @param ivEncoding
	 *            encoding for IV in which the encoding for initialization
	 *            vector is stored
	 * @param ivEncoding
	 *            encoding for IV in which the encoding for initialization
	 *            vector is stored
	 * @param ivEncoding
	 *            encoding for IV in which the encoding for initialization
	 *            vector is stored
	 * @param keyEncoding
	 *            encoding for Key in which the encoding for Key is stored
	 * @param keyEncoding
	 *            encoding for Key in which the encoding for Key is stored
	 * @param ivEncoding
	 *            encoding for IV in which the encoding for initialization
	 *            vector is stored
	 * @param ivEncoding
	 *            encoding for IV in which the encoding for initialization
	 *            vector is stored
	 * @param algorithm
	 *            symmetric cipher algorithm used by this object
	 * @param provider
	 *            security provider providing an implementation of the symmetric
	 *            cipher used by this object
	 * @throws com.bcbssc.registration.crypt.BcbsScCipherException if any.
	 */
	public SymmetricCipher(byte[] key, byte[] iv, int keyEncoding,
			int ivEncoding, String algorithm, Provider provider)
			throws BcbsScCipherException {
		this.init(key, iv, keyEncoding, ivEncoding, algorithm, provider);
		if (SymmetricCipher.log.isDebugEnabled()) {
			SymmetricCipher.log.debug("Created SymmetricCipher object.");
		}
	}

	/**
	 * initialize the fields of this object
	 * 
	 * @param key
	 *            value used to construct the <code>SecretKey</code> for this
	 *            object
	 * @param iv
	 *            initialization vector of this object
	 * @param encoding
	 *            encoding in which the key and initialization vector of this
	 *            object have been stored
	 * @param algorithm
	 *            symmetric cipher algorithm used by this object
	 * @param provider
	 *            security provider providing an implementation of the symmetric
	 *            cipher used byt his object
	 * @throws com.bcbssc.crypt.BcbsScCipherException
	 *             if an error occurs during initialization
	 */
	private void init(byte[] key, byte[] iv, int encoding, String algorithm,
			Provider provider) throws BcbsScCipherException {
		this.init(key, iv, encoding, encoding, algorithm, provider);
	}

	/**
	 * initialize the fields of this object
	 * 
	 * @param key
	 *            value used to construct the <code>SecretKey</code> for this
	 *            object
	 * @param iv
	 *            initialization vector of this object
	 * @param keyEncoding
	 *            encoding for Key in which the encoding for Key is stored
	 * @param ivEncoding
	 *            encoding for IV in which the encoding for initialization
	 *            vector is stored
	 * @param algorithm
	 *            symmetric cipher algorithm used by this object
	 * @param provider
	 *            security provider providing an implementation of the symmetric
	 *            cipher used byt his object
	 * @throws com.bcbssc.crypt.BcbsScCipherException
	 *             if an error occurs during initialization
	 */
	private void init(byte[] key, byte[] iv, int keyEncoding, int ivEncoding,
			String algorithm, Provider provider) throws BcbsScCipherException {
		String tempAlgorithm = algorithm;
		try {
			if (iv != null) {
				this.iv = new IvParameterSpec(SymmetricCipher.decode(iv,
						ivEncoding));
			}

			if (provider != null) {
				Security.addProvider(provider);
			}

			this.cipher = Cipher.getInstance(tempAlgorithm);

			if (tempAlgorithm.indexOf("/") > 0) {
				tempAlgorithm = tempAlgorithm.substring(0, tempAlgorithm
						.indexOf("/"));
			}

			this.key = new SecretKeySpec(SymmetricCipher.decode(key,
					keyEncoding), tempAlgorithm);
		} catch (Exception e) {
			SymmetricCipher.log.error(e.getMessage());
			throw new BcbsScCipherException(e);
		}
	}

	/**
	 * read the file specified
	 * 
	 * @param file
	 *            file to be read
	 * @return raw data of the given file
	 * @throws java.io.IOException
	 *             if an error occurs while reading the file
	 */
	private byte[] readFile(File file) throws IOException {
		Long keySize = new Long(file.length());
		byte[] data = new byte[keySize.intValue()];
		BufferedInputStream input = new BufferedInputStream(
				new FileInputStream(file));
		input.read(data);
		input.close();
		return data;
	}

	/**
	 * generates a secret key for use with the supplied symmetric cipher
	 * algorithm
	 *
	 * @param algorithm
	 *            symmetric cipher algorithm to generate a key for
	 * @param keySize
	 *            size of the generated key in bits
	 * @return secret key for use with the supplied symmetric cipher
	 * @throws java.security.NoSuchAlgorithmException if any.
	 */
	public static SecretKey generateKey(String algorithm, int keySize)
			throws NoSuchAlgorithmException {
		String tempAlgorithm = algorithm;
		if (tempAlgorithm.indexOf("/") > 0) {
			tempAlgorithm = tempAlgorithm.substring(0, tempAlgorithm
					.indexOf("/"));
		}
		// Get a key generator for the supplied algorithm
		KeyGenerator keygen = KeyGenerator.getInstance(tempAlgorithm);

		// Initalize the key generator to produce a key of the given size
		keygen.init(keySize);

		// Generate a new key for the given algorithm
		return keygen.generateKey();
	}

	/**
	 * generates an initialization vector for the given algorithm and secret key
	 *
	 * @param key
	 *            <code>SecretKey</code> used to create initialization vector
	 * @param algorithm
	 *            symmetric cipher algorithm to generate an initialization
	 *            vector for
	 * @return an initialization vector for the given algorithm;
	 *         <code>null</code> if the given algorithm does not require an
	 *         initialization vector
	 * @throws java.security.NoSuchAlgorithmException if any.
	 * @throws javax.crypto.NoSuchPaddingException if any.
	 * @throws java.security.InvalidKeyException if any.
	 */
	public static byte[] generateIV(SecretKey key, String algorithm)
			throws NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException {
		Cipher cipher = Cipher.getInstance(algorithm);
		cipher.init(Cipher.ENCRYPT_MODE, key);
		return cipher.getIV();
	}

	/**
	 * creates or updates the file specified with a key constructed for the
	 * specified algorithm
	 *
	 * @param filename
	 *            file to be created/updated
	 * @param algorithm
	 *            symmetric cipher algorithm to generate a key for
	 * @param keySize
	 *            size of the secret key to be generated
	 * @param keyEncoding
	 *            encoding type used to output the key
	 * @return SecretKey key constructed for the specified algorithm
	 * @throws com.bcbssc.registration.crypt.BcbsScCipherException if any.
	 */
	public static SecretKey generateKeyFile(String filename, String algorithm,
			int keySize, int keyEncoding) throws BcbsScCipherException {
		try {
			SecretKey secretKey = null;
			secretKey = SymmetricCipher.generateKey(algorithm, keySize);

			SecretKeySpec keySpec = new SecretKeySpec(secretKey.getEncoded(),
					algorithm);
			byte[] encodedKey = SymmetricCipher.encode(keySpec.getEncoded(),
					keyEncoding);
			SymmetricCipher.writeFile(new File(filename), encodedKey);

			return secretKey;
		} catch (Exception ex) {
			SymmetricCipher.log.error(ex.getMessage());
			throw new BcbsScCipherException(ex);
		}
	}

	/**
	 * creates or updates the initialization vector for the specified algorithm
	 * and secret key
	 *
	 * @param filename
	 *            file to be created/updated
	 * @param algorithm
	 *            symmetric cipher algorithm to generate an initialization
	 *            vector for
	 * @param ivEncoding
	 *            encoding in which the initialization vector will be written
	 * @param key
	 *            <code>SecretKey</code> used to create initialization vector
	 * @return initialization vector for use with the given symmetric cipher and
	 *         secret key
	 * @throws com.bcbssc.registration.crypt.BcbsScCipherException if any.
	 */
	public static byte[] generateIVFile(String filename, String algorithm,
			int ivEncoding, SecretKey key) throws BcbsScCipherException {
		try {
			byte[] iv = SymmetricCipher.generateIV(key, algorithm);
			if (iv != null) {
				byte[] encodedIV = SymmetricCipher.encode(iv, ivEncoding);
				SymmetricCipher.writeFile(new File(filename), encodedIV);
			} else {
				File ivFile = new File(filename);
				if (ivFile.exists()) {
					ivFile.delete();
				}
			}
			return iv;
		} catch (Exception e) {
			SymmetricCipher.log.error(e.getMessage());
			throw new BcbsScCipherException(e);
		}
	}

	/**
	 * writes the given data to the specified file
	 *
	 * @param file
	 *            <code>File</code> to be written to filesystem
	 * @param data
	 *            data to be written to the given file
	 * @throws java.io.FileNotFoundException if any.
	 * @throws java.io.IOException if any.
	 */
	protected static void writeFile(File file, byte[] data)
			throws FileNotFoundException, IOException {
		if (file.exists()) {
			file.delete();
		}
		BufferedOutputStream out = new BufferedOutputStream(
				new FileOutputStream(file));
		out.write(data);
		out.flush();
		out.close();
	}

	/**
	 * encodes the given array of bytes into a string using the given encoding
	 *
	 * @param value
	 *            array of bytes to be encoded
	 * @param encoding
	 *            encoding type of output
	 * @return string derived from the given byte array and encoding
	 * @see BINARY_ENCODING
	 * @see BASE64_ENCODING
	 * @see HEXADECIMAL_ENCODING
	 */
	public static byte[] encode(byte[] value, int encoding) {
		byte[] encodedString = null;
		switch (encoding) {
		case SymmetricCipher.BASE64_ENCODING:
			encodedString = Base64.encodeBase64(value);
			break;
		case SymmetricCipher.HEXADECIMAL_ENCODING:
			char[] temp = Hex.encodeHex(value);
			encodedString = (new String(temp)).getBytes();
			if (SymmetricCipher.log.isDebugEnabled()) {
				SymmetricCipher.log.debug("Encoded Hex Value - "
						+ (new String(temp)));
			}
			break;
		case SymmetricCipher.DEFAULT_ENCODING:
			encodedString = value;
			break;
		default:
			encodedString = value;
			break;
		}
		return encodedString;
	}

	/**
	 * encodes the given array of bytes into a string using the given encoding
	 *
	 * @param value
	 *            array of bytes to be encoded
	 * @param encoding
	 *            encoding type of output
	 * @return string derived from the given byte array and encoding
	 * @see BIG_INTEGER_ENCODING
	 */
	public static String encodeAsString(byte[] value, int encoding) {
		String encodedString = null;
		switch (encoding) {
		case SymmetricCipher.BIG_INTEGER_ENCODING:
			BigInteger bi = new BigInteger(value);
			encodedString = bi.toString();
			break;
		default:
			encodedString = new String(value);
			break;
		}
		return encodedString;
	}

	/**
	 * decodes the given string into an array of bytes using the given encoding
	 *
	 * @param value
	 *            string to be decoded
	 * @param encoding
	 *            encoding type of input
	 * @return byte array derived from the given string and encoding
	 * @see BINARY_ENCODING
	 * @see BASE64_ENCODING
	 * @see HEXADECIMAL_ENCODING
	 * @throws org.apache.commons.codec.DecoderException if any.
	 */
	public static byte[] decode(byte[] value, int encoding)
			throws DecoderException {
		byte[] decodedBytes = null;
		switch (encoding) {
		case SymmetricCipher.BASE64_ENCODING:
			decodedBytes = Base64.decodeBase64(value);
			break;
		case SymmetricCipher.HEXADECIMAL_ENCODING:
			String temp = new String(value);
			decodedBytes = Hex.decodeHex(temp.toCharArray());
			break;
		case SymmetricCipher.DEFAULT_ENCODING:
			decodedBytes = value;
			break;
		default:
			decodedBytes = value;
			break;
		}

		return decodedBytes;
	}

	/**
	 * returns the encrypted cipher data calculated using the supplied plain
	 * data and encryption properties of this object
	 *
	 * @param plainData
	 *            data to be encrypted
	 * @return encrypted cipher data
	 * @throws com.bcbssc.registration.crypt.BcbsScCipherException if any.
	 */
	public byte[] encrypt(byte[] plainData) throws BcbsScCipherException {
		try {
			this.initCipher(Cipher.ENCRYPT_MODE);
			return this.cipher.doFinal(plainData);
		} catch (Exception ex) {
			SymmetricCipher.log.error(ex.getMessage());
			throw new BcbsScCipherException(ex);
		}
	}

	/**
	 * returns the decrypted plain data calculated using the supplied cipher
	 * data and decryption properties of this object.
	 *
	 * @param cipherData
	 *            data to be decrypted
	 * @return decrypted plain data
	 * @throws com.bcbssc.registration.crypt.BcbsScCipherException if any.
	 */
	public byte[] decrypt(byte[] cipherData) throws BcbsScCipherException {
		try {
			this.initCipher(Cipher.DECRYPT_MODE);
			return this.cipher.doFinal(cipherData);
		} catch (Exception ex) {
			SymmetricCipher.log.error(ex.getMessage());
			throw new BcbsScCipherException(ex);
		}
	}

	/**
	 * retrieves an <code>InputStream</code> in which bytes of data will be
	 * encrypted as they are read using the cipher of this object
	 *
	 * @param input
	 *            underlying <code>InputStream</code>
	 * @return an <code>InputStream</code> in which bytes of data will be
	 *         encrypted as they are read using the cipher of this object
	 * @throws java.security.InvalidKeyException if any.
	 * @throws java.security.InvalidAlgorithmParameterException if any.
	 */
	public CipherInputStream getEncryptedInputStream(InputStream input)
			throws InvalidKeyException, InvalidAlgorithmParameterException {
		this.initCipher(Cipher.ENCRYPT_MODE);
		return new CipherInputStream(input, this.cipher);
	}

	/**
	 * retrieves an <code>InputStream</code> in which bytes of data will be
	 * decrypted as they are read using the cipher of this object
	 *
	 * @param input
	 *            underlying <code>InputStream</code>
	 * @return an <code>InputStream</code> in which bytes of data will be
	 *         decrypted as they are read using the cipher of this object
	 * @throws java.security.InvalidKeyException if any.
	 * @throws java.security.InvalidAlgorithmParameterException if any.
	 */
	public CipherInputStream getDecryptedInputStream(InputStream input)
			throws InvalidKeyException, InvalidAlgorithmParameterException {
		this.initCipher(Cipher.DECRYPT_MODE);
		return new CipherInputStream(input, this.cipher);
	}

	/**
	 * retrieves an <code>OutputStream</code> in which bytes of data will be
	 * encrypted as they are written using the cipher of this object
	 *
	 * @param output
	 *            underlying <code>OutputStream</code>
	 * @return an <code>OutputStream</code> in which bytes of data will be
	 *         encrypted as they are written using the cipher of this object
	 * @throws java.security.InvalidKeyException if any.
	 * @throws java.security.InvalidAlgorithmParameterException if any.
	 */
	public CipherOutputStream getEncryptedOutputStream(OutputStream output)
			throws InvalidKeyException, InvalidAlgorithmParameterException {
		this.initCipher(Cipher.ENCRYPT_MODE);
		return new CipherOutputStream(output, this.cipher);
	}

	/**
	 * retrieves an <code>OutputStream</code> in which bytes of data will be
	 * decrypted as they are written using the cipher of this object
	 *
	 * @param output
	 *            underlying <code>OutputStream</code>
	 * @return an <code>OutputStream</code> in which bytes of data will be
	 *         decrypted as they are written using the cipher of this object
	 * @throws java.security.InvalidKeyException if any.
	 * @throws java.security.InvalidAlgorithmParameterException if any.
	 */
	public CipherOutputStream getDecryptedOutputStream(OutputStream output)
			throws InvalidKeyException, InvalidAlgorithmParameterException {
		this.initCipher(Cipher.DECRYPT_MODE);
		return new CipherOutputStream(output, this.cipher);
	}

	/**
	 * initializes the cipher of this object with the appropriate parameters and
	 * in the given <code>mode</code>
	 * 
	 * @param mode
	 *            mode in which to initalize the cipher of this object
	 * @throws java.security.InvalidKeyException
	 *             if the key of this object is not valid for the cipher of this
	 *             object
	 * @throws java.security.InvalidAlgorithmParameterException
	 *             if the initialization vector of this object is invalid or an
	 *             attempt is made to use an initialization vector in with a
	 *             cipher mode that does not support it
	 * @see javax.crypto.Cipher#DECRYPT_MODE
	 * @see javax.crypto.Cipher#ENCRYPT_MODE
	 * @see javax.crypto.Cipher#UNWRAP_MODE
	 * @see javax.crypto.Cipher#WRAP_MODE
	 */
	private void initCipher(int mode) throws InvalidKeyException,
			InvalidAlgorithmParameterException {
		if (this.iv != null) {
			this.cipher.init(mode, this.key, this.iv);
		} else {
			this.cipher.init(mode, this.key);
		}
	}
}
