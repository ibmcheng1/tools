/*
 *
 * @(#)Constants.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.registration.common;

/**
 * Common Registration Constants
 *
 * @author Jonathan Egger
 * @version $Revision:   1.1  $
 */
public class Constants extends com.bcbssc.struts.common.Constants {

	/**
	 * Constants constructor.
	 */
	public Constants() {
		super();
	}

	/**
	 * Log4j initialization Properties file name
	 */
	public static final String LOG4J_PROPERTIES_FILENAME = "log4j.xml";
	
	/**
	 * Name of global INI file servlet context parameter
	 */
	public static final String INI_PARAMETER_NAME = "iniFile";


	/**
	 * Name of global INI file servlet context attribute
	 */
	public static final String CONTEXT_ATTRIBUTE_INI = "INI";

	/**
	 * Name of INI local section in LDAP INI
	 */
	public static final String INI_LOCAL_SECTION = "Local";

	/** Constant <code>INI_COOKIE_SECTION="Cookie"</code> */
	public static final String INI_COOKIE_SECTION = "Cookie";

	/** Constant <code>INI_AUTH_COOKIE_DOMAIN="COOKIE_DOMAIN"</code> */
	public static final String INI_AUTH_COOKIE_DOMAIN = "COOKIE_DOMAIN";

	/** Constant <code>INI_AUTH_COOKIE_KEY="ONT_AUTH_COOKIE_KEY"</code> */
	public static final String INI_AUTH_COOKIE_KEY = "ONT_AUTH_COOKIE_KEY";

	/** Constant <code>INI_AUTH_COOKIE_IV="ONT_AUTH_COOKIE_IV"</code> */
	public static final String INI_AUTH_COOKIE_IV = "ONT_AUTH_COOKIE_IV";

	/**
	 * MGR_DN label in LDAP INI
	 */
	public static final String INI_MGR_DN = "MGR_DN";

	/**
	 * MGR_PW label in LDAP INI
	 */
	public static final String INI_MGR_PW = "MGR_PW";

	/**
	 * Organization Base label in LDAP INI
	 */
	public static final String INI_ORGANIZATION_BASE = "ORGANIZATION_BASE";

	/**
	 * Role Base label in LDAP INI
	 */
	public static final String INI_ROLE_BASE = "ROLE_BASE";

	/**
	 * Role Base label in LDAP INI
	 */
	public static final String INI_APP_ROLE = "APP_ROLE";

	/**
	 * People Base label in LDAP INI
	 */
	public static final String INI_PEOPLE_BASE = "PEOPLE_BASE";

	
	/** Constant <code>INI_READ_ONLY_ROLE="READ_ONLY_ROLE"</code> */
	public static final String INI_READ_ONLY_ROLE = "READ_ONLY_ROLE";
	/**
	 * LDAP filter for all items
	 */
	public static final String LDAP_FILTER_GET_ALL = "(objectclass=*)";

	/**
	 * LDAP prefix for commonname searchbases
	 */
	public static final String LDAP_CN_SEARCHBASE_PREFIX = "CN=";

	/**
	 * Downtime Message Type
	 */
	public static final String DOWNTIME_TYPE = "downtime";

	/**
	 * Holiday Message Type
	 */
	public static final String HOLIDAY_TYPE = "holiday";

	/**
	 * Downtime Message LDAP Attribute Name
	 */
	public static final String LDAP_DOWNTIME_ATTRIBUTE = "downTimeMessage";

	/**
	 * Holiday Message LDAP Attribute Name
	 */
	public static final String LDAP_HOLIDAY_ATTRIBUTE = "holidayMessage";

	/**
	 * User Profile LDAP Attribute Names
	 */
	public static final String LDAP_ATTRIBUTE_ACCESSCODE = "accesscode";

	/** Constant <code>LDAP_ATTRIBUTE_ACCESS_TIMESTAMP="bcbsLastAccessTime"</code> */
	public static final String LDAP_ATTRIBUTE_ACCESS_TIMESTAMP = "bcbsLastAccessTime";

	/** Constant <code>LDAP_ATTRIBUTE_GIVENNAME="givenname"</code> */
	public static final String LDAP_ATTRIBUTE_GIVENNAME = "givenname";

	/** Constant <code>LDAP_ATTRIBUTE_MIDDLEINI="middleini"</code> */
	public static final String LDAP_ATTRIBUTE_MIDDLEINI = "middleini";

	/** Constant <code>LDAP_ATTRIBUTE_SN="sn"</code> */
	public static final String LDAP_ATTRIBUTE_SN = "sn";

	/** Constant <code>LDAP_ATTRIBUTE_SUFFIX="suffix"</code> */
	public static final String LDAP_ATTRIBUTE_SUFFIX = "suffix";

	/** Constant <code>LDAP_ATTRIBUTE_COMMONNAME="commonname"</code> */
	public static final String LDAP_ATTRIBUTE_COMMONNAME = "commonname";

	/** Constant <code>LDAP_ATTRIBUTE_CHALLENGERESPONSE="challengeresponse"</code> */
	public static final String LDAP_ATTRIBUTE_CHALLENGERESPONSE = "challengeresponse";

	/** Constant <code>LDAP_ATTRIBUTE_CHALLENGE="challenge"</code> */
	public static final String LDAP_ATTRIBUTE_CHALLENGE = "challenge";

	/** Constant <code>LDAP_ATTRIBUTE_CN="cn"</code> */
	public static final String LDAP_ATTRIBUTE_CN = "cn";

	/** Constant <code>LDAP_ATTRIBUTE_SAMACCOUNTNAME="sAMAccountName"</code> */
	public static final String LDAP_ATTRIBUTE_SAMACCOUNTNAME = "sAMAccountName";

	/** Constant <code>LDAP_ATTRIBUTE_UID="uid"</code> */
	public static final String LDAP_ATTRIBUTE_UID = "uid";

	/** Constant <code>LDAP_ATTRIBUTE_UNICODEPWD="unicodePwd"</code> */
	public static final String LDAP_ATTRIBUTE_UNICODEPWD = "unicodePwd";

	/** Constant <code>LDAP_ATTRIBUTE_PASSWORD_STATUS="ont-passwordstatus"</code> */
	public static final String LDAP_ATTRIBUTE_PASSWORD_STATUS = "ont-passwordstatus";

	/** Constant <code>LDAP_ATTRIBUTE_PASSWORD_RESET_DATE="ont-passwordresetdate"</code> */
	public static final String LDAP_ATTRIBUTE_PASSWORD_RESET_DATE = "ont-passwordresetdate";

	/** Constant <code>LDAP_ATTRIBUTE_USER_ACCOUNT_CONTROL="userAccountControl"</code> */
	public static final String LDAP_ATTRIBUTE_USER_ACCOUNT_CONTROL = "userAccountControl";

	/** Constant <code>LDAP_ATTRIBUTE_ACCESS_STATUS="ont-accessstatus"</code> */
	public static final String LDAP_ATTRIBUTE_ACCESS_STATUS = "ont-accessstatus";

	/** Constant <code>LDAP_ATTRIBUTE_START_DATE="ont-startdate"</code> */
	public static final String LDAP_ATTRIBUTE_START_DATE = "ont-startdate";

	/** Constant <code>LDAP_ATTRIBUTE_END_DATE="ont-enddate"</code> */
	public static final String LDAP_ATTRIBUTE_END_DATE = "ont-enddate";

	/** Constant <code>LDAP_ATTRIBUTE_TIMEOUT="ont-timeout"</code> */
	public static final String LDAP_ATTRIBUTE_TIMEOUT = "ont-timeout";

	/** Constant <code>LDAP_ATTRIBUTE_DOA="dateofacceptance"</code> */
	public static final String LDAP_ATTRIBUTE_DOA = "dateofacceptance";

	/** Constant <code>LDAP_ATTRIBUTE_OBJECTCATEGORY="objectCategory"</code> */
	public static final String LDAP_ATTRIBUTE_OBJECTCATEGORY = "objectCategory";

	/** Constant <code>LDAP_ATTRIBUTE_VALIDOBJECT="ont-validobject"</code> */
	public static final String LDAP_ATTRIBUTE_VALIDOBJECT = "ont-validobject";

	/** Constant <code>LDAP_ATTRIBUTE_OBJECTCLASS="objectClass"</code> */
	public static final String LDAP_ATTRIBUTE_OBJECTCLASS = "objectClass";

	/** Constant <code>LDAP_ATTRIBUTE_SSN="ssn"</code> */
	public static final String LDAP_ATTRIBUTE_SSN = "ssn";

	/** Constant <code>LDAP_ATTRIBUTE_GROUPNAME="groupname"</code> */
	public static final String LDAP_ATTRIBUTE_GROUPNAME = "groupname";

	/** Constant <code>LDAP_ATTRIBUTE_DOB="dateofbirth"</code> */
	public static final String LDAP_ATTRIBUTE_DOB = "dateofbirth";

	/** Constant <code>LDAP_ATTRIBUTE_CITY="l"</code> */
	public static final String LDAP_ATTRIBUTE_CITY = "l";

	/** Constant <code>LDAP_ATTRIBUTE_MEMBERNUMBER="membernumber"</code> */
	public static final String LDAP_ATTRIBUTE_MEMBERNUMBER = "membernumber";

	/** Constant <code>LDAP_ATTRIBUTE_POSTALCODE="postalCode"</code> */
	public static final String LDAP_ATTRIBUTE_POSTALCODE = "postalCode";

	/** Constant <code>LDAP_ATTRIBUTE_STATE="st"</code> */
	public static final String LDAP_ATTRIBUTE_STATE = "st";

	/** Constant <code>LDAP_ATTRIBUTE_STREET="street"</code> */
	public static final String LDAP_ATTRIBUTE_STREET = "street";

	/** Constant <code>LDAP_ATTRIBUTE_STREET2="addressline2"</code> */
	public static final String LDAP_ATTRIBUTE_STREET2 = "addressline2";

	/** Constant <code>LDAP_ATTRIBUTE_EMAIL="mail"</code> */
	public static final String LDAP_ATTRIBUTE_EMAIL = "mail";

	/** Constant <code>LDAP_ATTRIBUTE_TELEPHONE="telephoneNumber"</code> */
	public static final String LDAP_ATTRIBUTE_TELEPHONE = "telephoneNumber";

	/** Constant <code>LDAP_ATTRIBUTE_TELEPHONE_EXT="telephoneext"</code> */
	public static final String LDAP_ATTRIBUTE_TELEPHONE_EXT = "telephoneext";

	/** Constant <code>LDAP_ATTRIBUTE_FAX="facsimileTelephoneNumber"</code> */
	public static final String LDAP_ATTRIBUTE_FAX = "facsimileTelephoneNumber";

	/** Constant <code>LDAP_ATTRIBUTE_GROUPNUMBER="groupnumber"</code> */
	public static final String LDAP_ATTRIBUTE_GROUPNUMBER = "groupnumber";

	/** Constant <code>LDAP_ATTRIBUTE_COUNTRY="c"</code> */
	public static final String LDAP_ATTRIBUTE_COUNTRY = "c";

	/** Constant <code>LDAP_VALUE_PASSWORD_STATUS="Active"</code> */
	public static final String LDAP_VALUE_PASSWORD_STATUS = "Active";

	/** Constant <code>LDAP_VALUE_PASSWORD_RESET_DATE="20350101"</code> */
	public static final String LDAP_VALUE_PASSWORD_RESET_DATE = "20350101";

	/** Constant <code>LDAP_VALUE_USER_ACCOUNT_CONTROL="66048"</code> */
	public static final String LDAP_VALUE_USER_ACCOUNT_CONTROL = "66048";

	/** Constant <code>LDAP_VALUE_ACCESS_STATUS="Active"</code> */
	public static final String LDAP_VALUE_ACCESS_STATUS = "Active";

	/** Constant <code>LDAP_VALUE_START_DATE="20010101"</code> */
	public static final String LDAP_VALUE_START_DATE = "20010101";

	/** Constant <code>LDAP_VALUE_END_DATE="20350101"</code> */
	public static final String LDAP_VALUE_END_DATE = "20350101";

	/** Constant <code>LDAP_VALUE_TIMEOUT="15"</code> */
	public static final String LDAP_VALUE_TIMEOUT = "15";

	/** Constant <code>LDAP_VALUE_VALIDOBJECT="Y"</code> */
	public static final String LDAP_VALUE_VALIDOBJECT = "Y";

	/** Constant <code>LDAP_VALUE_OBJECTCLASS="user"</code> */
	public static final String LDAP_VALUE_OBJECTCLASS = "user";

	/** Constant <code>LDAP_ORG_BASE="ont-organizationdn"</code> */
	public static final String LDAP_ORG_BASE = "ont-organizationdn";

	/** Constant <code>LDAP_ROLE_BASE="ont-roledn"</code> */
	public static final String LDAP_ROLE_BASE = "ont-roledn";
     
	/** Constant <code>LDAP_CONFIG="ldap_config"</code> */
	public static final String LDAP_CONFIG   ="ldap_config";
	/**
	 * DSmart Exception Messages
	 */
	public static final String DSMART_NAME_BOUND_EXCEPTION_MESSAGE = "Name Already Bound Exception";

	/** Constant <code>DSMART_INVALID_AUTHENTICATION_EXCEPTION_MESSAGE="Invalid Authentication"</code> */
	public static final String DSMART_INVALID_AUTHENTICATION_EXCEPTION_MESSAGE = "Invalid Authentication";

	/**
	 * Action Servlet Forward Types
	 */
	public static final String FORWARD_SUCCESS = "success";

	/** Constant <code>FORWARD_WELCOME="welcome"</code> */
	public static final String FORWARD_WELCOME = "welcome";

	/** Constant <code>FORWARD_WELCOME_ACTION="welcome_action"</code> */
	public static final String FORWARD_WELCOME_ACTION = "welcome_action";
	
	/** Constant <code>FORWARD_USER_EXISTS="user_exists"</code> */
	public static final String FORWARD_USER_EXISTS = "user_exists";

	/** Constant <code>FORWARD_FAILURE="failure"</code> */
	public static final String FORWARD_FAILURE = "failure";

	/** Constant <code>FORWARD_SECURITY_ERROR="security_error"</code> */
	public static final String FORWARD_SECURITY_ERROR = "security_error";
	
	/** Constant <code>FORWARD_SECURITY_ERROR_ACTION="security_error_action"</code> */
	public static final String FORWARD_SECURITY_ERROR_ACTION = "security_error_action";

	/** Constant <code>FORWARD_CANCEL="cancel"</code> */
	public static final String FORWARD_CANCEL = "cancel";

	/** Constant <code>FORWARD_BACK="back"</code> */
	public static final String FORWARD_BACK = "back";

	/**
	 * Form Button Property Name
	 */
	public static final String FORM_BUTTON_NAME = "button";

	/**
	 * Form Button Values
	 */
	public static final String FORM_BUTTON_CANCEL = "Cancel";

	/** Constant <code>FORM_BUTTON_BACK="Back"</code> */
	public static final String FORM_BUTTON_BACK = "Back";

	/**
	 * DOA Cookie Name
	 */
	public static final String COOKIE_DATE_OF_ACCEPTANCE = "dateOfAcceptance";

	/**
	 * ONTcred Cookie Name
	 */
	public static final String COOKIE_ONT_CRED = "ONTCred";

	/**
	 * SuperUser RACF cookie
	 */
	public static final String COOKIE_SUPERUSER_RACF = "RACF";

	/**
	 * SuperUser type cookie
	 */
	public static final String COOKIE_SUPERUSER_TYPE = "UserCLASS";

	/**
	 * Date format to be used with LDAP
	 */
	public static final String LDAP_DATE_FORMAT = "MM/dd/yyyy";

	/**
	 * Date format to be used for access timestamp
	 */
	public static final String ACCESS_TIMESTAMP_FORMAT = "MM-dd-yyyy HH:mm";

	/**
	 * Default delimiter used when joining strings
	 */
	public static final String DEFAULT_DELIMITER = "|";

	/** Constant <code>EMPTY_STRING=""</code> */
	public static final String EMPTY_STRING = "";
	/**
	 * Exception description strings
	 */
	public static final String EXCEPTION_DSMART_CHECKIN = "Error while checking in DSmart Connection";

	/** Constant <code>EXCEPTION_DSMART_CHECKOUT="Error while checking out DSmart Connect"{trunked}</code> */
	public static final String EXCEPTION_DSMART_CHECKOUT = "Error while checking out DSmart Connection";

	/** Constant <code>EXCEPTION_DSMART_GENERAL="Error in DSmart API call"</code> */
	public static final String EXCEPTION_DSMART_GENERAL = "Error in DSmart API call";

	/** Request userDTO parameter name */
	public static final String USER_DTO = "user";
	
	/**
     * TDS Changes
     */
	
	public static final String TDS_LDAP_SEARCH_FILTER = "com.bcbssc.jndi.searchFilter";
		
	/** Constant <code>TDS_LDAP_ATTRIBUTE_UID="uid"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_UID = "uid";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_ACCESSCODE="accessCode"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_ACCESSCODE = "accessCode";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_CHALLENGEQUESTION="challengeQuestion"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_CHALLENGEQUESTION = "challengeQuestion";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_CHALLENGERESPONSE="challengeResponse"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_CHALLENGERESPONSE = "challengeResponse";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_CITY="l"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_CITY = "l";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_COMMONNAME="cn"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_COMMONNAME = "cn";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_COUNTRY="c"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_COUNTRY = "c";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_DOA="dateOfAcceptance"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_DOA = "dateOfAcceptance";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_DOB="dateOfBirth"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_DOB = "dateOfBirth";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_EMAIL="mail"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_EMAIL = "mail";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_GIVENNAME="givenName"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_GIVENNAME = "givenName";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_GROUPNAME="groupName"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_GROUPNAME = "groupName";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_GROUPNUMBER="groupNumber"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_GROUPNUMBER = "groupNumber";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_SN="sn"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_SN = "sn";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_SSN="last6ssn"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_SSN = "last6ssn";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_STATE="st"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_STATE = "st";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_STREET="street"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_STREET = "street";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_STREET2="postalAddress2"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_STREET2 = "postalAddress2";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_TELEPHONE="telephoneNumber"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_TELEPHONE = "telephoneNumber";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_TELEPHONE_EXT="telephoneExtension"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_TELEPHONE_EXT = "telephoneExtension";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_UNICODEPWD="userPassword"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_UNICODEPWD = "userPassword";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_POSTALCODE="postalCode"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_POSTALCODE = "postalCode";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_ENABLED="enabled"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_ENABLED = "enabled";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_LASTACCESS="lastAccess"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_LASTACCESS = "lastAccess";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_MIDDLEINITIAL="middleInitial"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_MIDDLEINITIAL = "middleInitial";
	/** Constant <code>TDS_OBJECT_CLASS="objectClass"</code> */
	public static final String TDS_OBJECT_CLASS = "objectClass";
	/** Constant <code>TDS_LAST_ACCESS_DATE_FORMAT="MM-dd-yyyy HH:mm"</code> */
	public static final String TDS_LAST_ACCESS_DATE_FORMAT = "MM-dd-yyyy HH:mm";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_FAX="fax"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_FAX = "fax";
	/** Constant <code>TDS_LDAP_ATTRIBUTE_FAXEXTENSION="faxExtension"</code> */
	public static final String TDS_LDAP_ATTRIBUTE_FAXEXTENSION = "faxExtension";
    /** Constant <code>LDAP_USERTYPE="userType"</code> */
    public static final String LDAP_USERTYPE = "userType";
    /** Constant <code>TDS_LDAP_ATTRIBUTE_GENERATION_QUALIFIER="generationQualifier"</code> */
    public static final String TDS_LDAP_ATTRIBUTE_GENERATION_QUALIFIER = "generationQualifier";
    /** Constant <code>TDS_LDAP_ATTRIBUTE_WHENCREATED="whenCreated"</code> */
    public static final String TDS_LDAP_ATTRIBUTE_WHENCREATED = "whenCreated";
    /** Constant <code>TDS_LDAP_ATTRIBUTE_WHENCHANGED="whenChanged"</code> */
    public static final String TDS_LDAP_ATTRIBUTE_WHENCHANGED = "whenChanged";
    
	/**
	 * Downtime Message LDAP Attribute Name
	 */
	public static final String TDS_LDAP_ATTRIBUTE_DOWNTIME = "downtimeMessage";

	/**
	 * Holiday Message LDAP Attribute Name
	 */
	public static final String TDS_LDAP_ATTRIBUTE_HOLIDAY = "holidayMessage";
	
	
	/**
	 * Downtime Message Type
	 */
	public static final String TDS_DOWNTIME_TYPE = "downtime";

	/**
	 * Holiday Message Type
	 */
	public static final String TDS_HOLIDAY_TYPE = "holiday";
	
	/**
	 * TDS  
	 */
	
	public static final String TDS_LDAP_SEARCH_BASE = "com.bcbssc.jndi.searchBase";
	/** Constant <code>TDS_LDAP_BASE="com.bcbssc.jndi.base"</code> */
	public static final String TDS_LDAP_BASE = "com.bcbssc.jndi.base";
	/** Constant <code>TDS_LDAP_ORG_ROLE="MBC-GA-EU"</code> */
	public static final String TDS_LDAP_ORG_ROLE = "MBC-GA-EU";
	/** Constant <code>TDS_BASE="BASE"</code> */
	public static final String TDS_BASE = "BASE";
	/** Constant <code>TDS_SUPERUSER_BASE="SUPERUSER_BASE"</code> */
	public static final String TDS_SUPERUSER_BASE = "SUPERUSER_BASE";
	/** Constant <code>TDS_LDAP_SUPERUSER_SEARCH_BASE="com.bcbssc.jndi.searchBase"</code> */
	public static final String TDS_LDAP_SUPERUSER_SEARCH_BASE = "com.bcbssc.jndi.searchBase";
	/** Constant <code>TDS_LDAP_SUPERUSER_BASE="com.bcbssc.jndi.base"</code> */
	public static final String TDS_LDAP_SUPERUSER_BASE = "com.bcbssc.jndi.base";
	/** Constant <code>INI_SUPERUSER_ROLE_BASE="SUPERUSER_ROLE_BASE"</code> */
	public static final String INI_SUPERUSER_ROLE_BASE = "SUPERUSER_ROLE_BASE";
	/** Constant <code>INI_SUPERUSER_PEOPLE_BASE="SUPERUSER_PEOPLE_BASE"</code> */
	public static final String INI_SUPERUSER_PEOPLE_BASE = "SUPERUSER_PEOPLE_BASE";

	
	
	
	
	
	
	
	
}
