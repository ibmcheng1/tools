package com.bcbssc.commercial.registration.core.impl;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.naming.Binding;
import javax.naming.InvalidNameException;
import javax.naming.Name;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.LdapName;

import org.apache.log4j.Logger;

import com.bcbssc.commercial.registration.core.ContextMapper;
import com.bcbssc.commercial.registration.core.DirContextOperations;
import com.bcbssc.commercial.registration.core.LdapOperations;
import com.bcbssc.commercial.registration.model.Account;

/**
 * <p>AccountOperations class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class AccountOperations implements LdapOperations {
	
	private static final Logger log 				= Logger.getLogger(AccountOperations.class);
	
	private static final String[] ALL_ATTRIBUTES 	= null;
	
	private LdapContextSource contextSource;
	
	/**
	 * <p>Constructor for AccountOperations.</p>
	 *
	 * @param contextSource a {@link com.bcbssc.commercial.registration.core.impl.LdapContextSource} object.
	 */
	public AccountOperations(LdapContextSource contextSource) {
		this.contextSource	= contextSource;
	}
	
	/**
	 * <p>Getter for the field <code>contextSource</code>.</p>
	 *
	 * @return a {@link com.bcbssc.commercial.registration.core.impl.LdapContextSource} object.
	 */
	public LdapContextSource getContextSource() {
		return contextSource;
	}

	/**
	 * <p>Setter for the field <code>contextSource</code>.</p>
	 *
	 * @param contextSource a {@link com.bcbssc.commercial.registration.core.impl.LdapContextSource} object.
	 */
	public void setContextSource(LdapContextSource contextSource) {
		this.contextSource = contextSource;
	}

	/** {@inheritDoc} */
	public Object lookup(Name dn, String[] attributes, ContextMapper mapper) {

		Object returnObject						= null;
		DirContext dirContext					= null;  
		try {

			dn									= addBaseToDn(dn, contextSource.getBase());
			
			dirContext							= contextSource.getContext();
			
			Attributes filteredAttributes 		= dirContext.getAttributes(dn, attributes);
			DirContextAdapter contextAdapter 	= new DirContextAdapter(filteredAttributes, (LdapName) dn);
			returnObject						= mapper.mapFromContext(contextAdapter);
		}
		catch(NamingException namingException) {
			namingException.printStackTrace();
		}
		catch(Exception exception) {
			exception.printStackTrace();
		}
		finally {
			closeContext(dirContext);
		}
		
		
		return returnObject;
	}

	/** {@inheritDoc} */
	public DirContextOperations lookupContext(Name dn) {
		return (DirContextAdapter) lookup(dn);
	}

	/**
	 * <p>lookupContext.</p>
	 *
	 * @param dn a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.commercial.registration.core.DirContextOperations} object.
	 */
	public DirContextOperations lookupContext(String dn) {
		return (DirContextAdapter) lookup(dn);
	}

	/**
	 * <p>modifyAttributes.</p>
	 *
	 * @param dn a {@link javax.naming.Name} object.
	 * @param mods an array of {@link javax.naming.directory.ModificationItem} objects.
	 */
	public void modifyAttributes(Name dn, ModificationItem[] mods) {

		DirContext dirContext		= null;
		
		try {
			
			dn						= addBaseToDn(dn, contextSource.getBase());
			dirContext				= contextSource.getContext();
			dirContext.modifyAttributes(dn, mods);
		}
		catch(NamingException namingException) {
			namingException.printStackTrace();
		}
		catch(Exception exception) {
			exception.printStackTrace();
		}
		finally {
			closeContext(dirContext);
		}
	}

	/** {@inheritDoc} */
	public void bind(Name dn, Object obj, Attributes attributes) {
		
		DirContext dirContext		= null;
		
		try {

			dn						= addBaseToDn(dn, contextSource.getBase());
			dirContext				= contextSource.getContext();
			dirContext.bind(dn, obj, attributes);
		}
		catch(NamingException namingException) {
			namingException.printStackTrace();
		}
		catch(Exception exception) {
			exception.printStackTrace();
		}
		finally {
			closeContext(dirContext);
		}
	}
	
	/** {@inheritDoc} */
	public void rebind(Name dn, Object obj, Attributes attributes) {
		
		DirContext dirContext		= null; 
		
		try {
			dn						= addBaseToDn(dn, contextSource.getBase());
			dirContext				= contextSource.getContext();
			dirContext.rebind(dn, obj, attributes);
		}
		catch(NamingException namingException) {
			namingException.printStackTrace();
		}
		catch(Exception exception) {
			exception.printStackTrace();
		}
		finally {
			closeContext(dirContext);
		}		
	}

	/** {@inheritDoc} */
	public void unbind(Name dn) {

		DirContext dirContext		= null; 
		
		try {
			dn						= addBaseToDn(dn, contextSource.getBase());
			dirContext				= contextSource.getContext();
			dirContext.unbind(dn);
		}
		catch(NamingException namingException) {
			namingException.printStackTrace();
		}
		catch(Exception exception) {
			exception.printStackTrace();
		}
		finally {
			closeContext(dirContext);
		}
	}		

	/**
	 * <p>lookup.</p>
	 *
	 * @param dn a {@link javax.naming.Name} object.
	 * @return a {@link java.lang.Object} object.
	 */
	public Object lookup(Name dn) {
		
		Object returnObject			= null;
		DirContext dirContext		= null; 

		try {
			
			dn						= addBaseToDn(dn, contextSource.getBase());
			dirContext				= contextSource.getContext();
			returnObject 			= dirContext.lookup(dn);
		}
		catch(NamingException namingException) {
			namingException.printStackTrace();
		}
		catch(Exception exception) {
			exception.printStackTrace();
		}
		finally {
			closeContext(dirContext);
		}
		
		return returnObject;
	}
	
	/** {@inheritDoc} */
	public Object lookup(String dn) {

		Object returnObject			= null;
		DirContext dirContext		= null; 
		
		try {
			
			dn						= addBaseToDn(dn, contextSource.getBase());
			dirContext				= contextSource.getContext();
			returnObject 			= dirContext.lookup(dn);
		}
		catch(NamingException namingException) {
			namingException.printStackTrace();
		}
		catch(Exception exception) {
			exception.printStackTrace();
		}
		finally {
			closeContext(dirContext);
		}
		
		return returnObject;
	}	
	
	/** {@inheritDoc} */
	public Object lookup(Name dn, ContextMapper mapper) {
		
		Object returnObject			= null;
		DirContext dirContext		= null; 
			
		try {
			
			dn						= addBaseToDn(dn, contextSource.getBase());
			
			dirContext				= contextSource.getContext();			
			Object object 			= dirContext.lookup(dn);
			returnObject			= mapper.mapFromContext((DirContextOperations) object);
		}
		catch(NamingException namingException) {
			namingException.printStackTrace();
		}
		catch(Exception exception) {
			exception.printStackTrace();
		}
		finally {
			closeContext(dirContext);
		}
		
		return returnObject;
	}

	/** {@inheritDoc} */
	public List<Account> search(Name searchBase, String filter, int searchScope,  ContextMapper mapper) {
		
		NamingEnumeration<SearchResult> results 		= null;
		List<Account> accounts			= null;
		DirContext dirContext			= null;
		
		try {

			searchBase					= addBaseToDn(searchBase, contextSource.getBase());
			
			SearchControls searchControls = getDefaultSearchControls(searchScope, true, ALL_ATTRIBUTES);

			dirContext					= contextSource.getContext();
			
			results 					= dirContext.search(searchBase, filter, searchControls);
			accounts					= new ArrayList<Account>();

			while (results.hasMore()) {
				
				Object result 			= results.next();

				if (!(result instanceof Binding)) {
					throw new IllegalArgumentException("Parameter must be an instance of Binding");
				}

				Binding binding 		= (Binding) result;
		        Object object 			= binding.getObject();
		        if (object == null) {
		            throw new Exception("Binding did not contain any object.");
		        }
		        
		        accounts.add((Account) mapper.mapFromContext((DirContextOperations) object));
				
			}
		}
		catch(NamingException namingException) {
			namingException.printStackTrace();
		}
		catch(Exception exception) {
			exception.printStackTrace();
		}
		finally {
			closeContext(dirContext);
		}
		
		return accounts;
	}

	/** {@inheritDoc} */
	public void modifyAttributes(Name dn, DirContextOperations ctx) {
		
		Attributes modifiedAttributes			= ctx.getAttributes();
		ModificationItem[] modificationItems	= getModificationItems(modifiedAttributes);
		modifyAttributes(dn, modificationItems);
	}
	
	private Name addBaseToDn(final Name dn, String base) throws InvalidNameException {
		
		LdapName appendedName	= new LdapName(dn.toString());
		
		LdapName baseName		= new LdapName(base);
		for (int i = baseName.size() - 1; i >= 0; i--) {			
			appendedName.add(0, baseName.get(i));
        }
		
		return appendedName;
	}
	
	private String addBaseToDn(String dn, String base) throws InvalidNameException {
		
		StringBuffer sbName		= new StringBuffer();
		sbName.append(dn).append(",").append(base);
		return sbName.toString();
	}	
	
	/*
	 * getModificationItems()
	 */
	private ModificationItem[] getModificationItems(Attributes updatedAttrs) {

		List<ModificationItem> modificationList						= new LinkedList<ModificationItem>();
		NamingEnumeration<? extends Attribute> attributesEnumeration 	= null;
		
		try {
			attributesEnumeration 					= updatedAttrs.getAll();

			while (attributesEnumeration.hasMore()) {				
				Attribute attribute					= (Attribute) attributesEnumeration.next();
				modificationList.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE, attribute));
			}
		}
		catch (NamingException e) {
		}
		finally {
			try {
				if (attributesEnumeration != null) {
					attributesEnumeration.close();
				}
			}
			catch (NamingException e) {
				// Never mind this
			}
		}

		return (ModificationItem[]) modificationList.toArray(new ModificationItem[modificationList.size()]);
	}
	
	private SearchControls getDefaultSearchControls(int searchScope, boolean returningObjFlag, String[] attrs) {

		SearchControls controls = new SearchControls();
		controls.setSearchScope(searchScope);
		controls.setReturningObjFlag(returningObjFlag);
		controls.setReturningAttributes(attrs);
		return controls;
	}
	
	private void closeContext(DirContext dirContext) {
		
		try {
			dirContext.close();
		}
		catch(NamingException namingException) {
			log.warn("Unable to close dir context");
		}
	}
}
