/*
 * @(#)IRegistrationServices.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.registration.services;

/**
 * Registration Services
 *
 * This interface declares the methods that the shared registration actions
 * require from appliation-specific services.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public interface IRegistrationServices {

	/**
	 * Adds a user to the directory.
	 *
	 * @param dto
	 *            an application-specific form data object
	 * @return validation status
	 * @throws java.lang.Exception if any.
	 */
	public boolean addProfile(Object dto) throws Exception;

	/**
	 * Determines existance of a samAccountName in LDAP.
	 *
	 * @param dto
	 *            an application-specific form data object
	 * @return a boolean.
	 * @throws java.lang.Exception if any.
	 */
	public boolean usernameExists(Object dto) throws Exception;

	/**
	 * Submits a technical help request
	 *
	 * @param dto
	 *            an application-specific form object
	 * @throws java.lang.Exception if any.
	 */
	public void submitTechnicalHelpRequest(Object dto) throws Exception;
}
