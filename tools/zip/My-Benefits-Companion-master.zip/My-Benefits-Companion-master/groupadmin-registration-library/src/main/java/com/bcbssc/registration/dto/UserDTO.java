/*
 * @(#)UserDTO.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.registration.dto;

/**
 * User Data Transfer Object
 *
 * This bean contains generic user profile data. Applications requiring
 * additional data items extend this class.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class UserDTO extends com.bcbssc.netsys.web.SessionDataBean implements
		java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6297831255944156143L;

	/** user name */
	private String samAccountName = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** reauthenticate challenge */
	private String challenge = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** response to the reauthenticate challenge */
	private String challengeResponse = com.bcbssc.struts.common.Constants.BLANK_STRING;

	private String org = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** user roles, joined by Constants.DEFAULT_DELIMITER */
	private String roles = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property superUserType.
	 */
	private String superUserType = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Sets the user name
	 *
	 * @param value
	 *            user name
	 */
	public void setSamAccountName(String value) {
		this.samAccountName = value;
	}

	/**
	 * Gets the user name
	 *
	 * @return user name
	 */
	public String getSamAccountName() {
		return this.samAccountName;
	}

	/**
	 * Sets the reauthenticate challenge
	 *
	 * @param value
	 *            reauthenticate challenge
	 */
	public void setChallenge(String value) {
		this.challenge = value;
	}

	/**
	 * Gets the reauthenticate challenge
	 *
	 * @return reauthenticate challenge
	 */
	public String getChallenge() {
		return this.challenge;
	}

	/**
	 * Sets the response to the reauthenticate challenge
	 *
	 * @param value
	 *            response to the reauthenticate challenge
	 */
	public void setChallengeResponse(String value) {
		this.challengeResponse = value;
	}

	/**
	 * Gets the response to the reauthenticate challenge
	 *
	 * @return response to the reauthenticate challenge
	 */
	public String getChallengeResponse() {
		return this.challengeResponse;
	}

	/**
	 * Gets the user organization
	 *
	 * @return user organization
	 */
	public String getOrg() {
		return this.org;
	}

	/**
	 * Sets the user roles
	 *
	 * @param value
	 *            the user roles, joined by Constants.DEFAULT_DELIMITER
	 */
	public void setOrg(String value) {
		this.org = value;
	}

	/**
	 * Gets the user roles
	 *
	 * @return the user roles, joined by Constants.DEFAULT_DELIMITER
	 */
	public String getRoles() {
		return this.roles;
	}

	/**
	 * Sets the user roles
	 *
	 * @param value
	 *            the user roles, joined by Constants.DEFAULT_DELIMITER
	 */
	public void setRoles(String value) {
		this.roles = value;
	}

	/**
	 * Getter for property superUserType.
	 *
	 * @return Value of property superUserType.
	 */
	public String getSuperUserType() {
		return this.superUserType;
	}

	/**
	 * Setter for property superUserType.
	 *
	 * @param superUserType
	 *            New value of property superUserType.
	 */
	public void setSuperUserType(String superUserType) {
		this.superUserType = superUserType;
	}

}
