package com.bcbssc.commercial.registration.core;

import java.util.List;

import javax.naming.Name;
import javax.naming.directory.Attributes;
import javax.naming.directory.ModificationItem;

import com.bcbssc.commercial.registration.model.Account;

/**
 * <p>LdapOperations interface.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public interface LdapOperations {

	/**
	 * <p>lookup.</p>
	 *
	 * @param dn a {@link javax.naming.Name} object.
	 * @param attributes an array of {@link java.lang.String} objects.
	 * @param mapper a {@link com.bcbssc.commercial.registration.core.ContextMapper} object.
	 * @return a {@link java.lang.Object} object.
	 */
	public Object lookup(Name dn, String[] attributes, ContextMapper mapper);
	
	/**
	 * <p>lookup.</p>
	 *
	 * @param dn a {@link javax.naming.Name} object.
	 * @return a {@link java.lang.Object} object.
	 */
	public Object lookup(Name dn);
	
	/**
	 * <p>lookup.</p>
	 *
	 * @param dn a {@link java.lang.String} object.
	 * @return a {@link java.lang.Object} object.
	 */
	public Object lookup(String dn);
	
	/**
	 * <p>lookup.</p>
	 *
	 * @param dn a {@link javax.naming.Name} object.
	 * @param mapper a {@link com.bcbssc.commercial.registration.core.ContextMapper} object.
	 * @return a {@link java.lang.Object} object.
	 */
	public Object lookup(Name dn, ContextMapper mapper);
	
	/**
	 * <p>lookupContext.</p>
	 *
	 * @param dn a {@link javax.naming.Name} object.
	 * @return a {@link com.bcbssc.commercial.registration.core.DirContextOperations} object.
	 */
	public DirContextOperations lookupContext(Name dn);
	 
	/**
	 * <p>lookupContext.</p>
	 *
	 * @param dn a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.commercial.registration.core.DirContextOperations} object.
	 */
	public DirContextOperations lookupContext(String dn);
	 
	/**
	 * <p>search.</p>
	 *
	 * @param base a {@link javax.naming.Name} object.
	 * @param filter a {@link java.lang.String} object.
	 * @param searchScope a int.
	 * @param mapper a {@link com.bcbssc.commercial.registration.core.ContextMapper} object.
	 * @return a {@link java.util.List} object.
	 */
	public List<Account> search(Name base, String filter, int searchScope, ContextMapper mapper);
	 
	/**
	 * <p>modifyAttributes.</p>
	 *
	 * @param dn a {@link javax.naming.Name} object.
	 * @param mods an array of {@link javax.naming.directory.ModificationItem} objects.
	 */
	public void modifyAttributes(Name dn, ModificationItem[] mods);
	
	/**
	 * <p>bind.</p>
	 *
	 * @param dn a {@link javax.naming.Name} object.
	 * @param obj a {@link java.lang.Object} object.
	 * @param attributes a {@link javax.naming.directory.Attributes} object.
	 */
	public void bind(Name dn, Object obj, Attributes attributes);
	
	/**
	 * <p>rebind.</p>
	 *
	 * @param dn a {@link javax.naming.Name} object.
	 * @param obj a {@link java.lang.Object} object.
	 * @param attributes a {@link javax.naming.directory.Attributes} object.
	 */
	public void rebind(Name dn, Object obj, Attributes attributes);
	
	/**
	 * <p>unbind.</p>
	 *
	 * @param dn a {@link javax.naming.Name} object.
	 */
	public void unbind(Name dn);
	
	/**
	 * <p>modifyAttributes.</p>
	 *
	 * @param dn a {@link javax.naming.Name} object.
	 * @param ctx a {@link com.bcbssc.commercial.registration.core.DirContextOperations} object.
	 */
	public void modifyAttributes(Name dn, DirContextOperations ctx);
}
