/*
 * @(#)LdapUserHandler.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.registration.ldap;

import com.bcbssc.netsys.Config;
import com.bcbssc.netsys.dsmart.DSmartWrapper;
import com.bcbssc.registration.common.CommonUtils;
import com.bcbssc.registration.common.Constants;
import com.bcbssc.registration.dto.UserDTO;
import com.opennetwork.DSUtils.DSGeneralException;
import com.opennetwork.DSUtils.DSNoConnectionException;
import com.opennetwork.DSUtils.DSmart;
import com.opennetwork.DSUtils.IDSValList;

import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.naming.NamingException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * Common Registration User LDAP Handler
 *
 * This abstract class provides LDAP User support for add, authenticate,
 * reauthenticate, change password, modify and populate. It must be extended by
 * an application specific class providing implementation of methods that tie
 * the Directory Smart IDSValList to the UserDTO object. See the CLife Group
 * Administrator CgaLdapUserHandler for an example of such a subclass.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public abstract class LdapUserHandler extends LdapHandler {

	/** The log4j logger for this class. */
	private static Logger logger = Logger.getLogger(LdapUserHandler.class);

	/** Date format for access time */
	private final SimpleDateFormat accessTimestampFormat = new SimpleDateFormat(
			Constants.ACCESS_TIMESTAMP_FORMAT);

	/**
	 * Class constructor
	 *
	 * @param iniFileName
	 *            INI file containing non-ssl LDAP connection info
	 * @param sslIniFileName
	 *            INI file containing ssl LDAP connection info
	 */
	public LdapUserHandler(String iniFileName, String sslIniFileName) {
		super(iniFileName, sslIniFileName);
	}

	/**
	 * Determines if an LDAP profile exists for the specified access code
	 *
	 * @param accessCode
	 *            access code
	 * @return a boolean.
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	public boolean profileExistsForAccessCode(String accessCode)
			throws DSNoConnectionException, DSGeneralException, DSPoolException {
		StringBuffer filter = new StringBuffer(32);
		filter.append("(").append(Constants.LDAP_ATTRIBUTE_ACCESSCODE).append(
				"=").append(accessCode).append(")");
		return this.profileExists(filter.toString());
	}

	/**
	 * Determines if an LDAP profile exists for the specified user name
	 *
	 * @param samAccountName
	 *            user name
	 * @return a boolean.
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	public boolean profileExistsForUsername(String samAccountName)
			throws DSNoConnectionException, DSGeneralException, DSPoolException {
		StringBuffer filter = new StringBuffer(32);
		filter.append("(").append(Constants.LDAP_ATTRIBUTE_SAMACCOUNTNAME)
				.append("=").append(samAccountName).append(")");
		return this.profileExists(filter.toString());
	}

	/**
	 * Adds a new user to LDAP
	 *
	 * @param user
	 *            the user to add
	 * @param user
	 *            the password for the new user
	 * @param user
	 *            the user to add
	 * @param user
	 *            the password for the new user
	 * @param user
	 *            the user to add
	 * @param user
	 *            the password for the new user
	 * @param user
	 *            the user to add
	 * @param user
	 *            the password for the new user
	 * @param user
	 *            the user to add
	 * @param user
	 *            the password for the new user
	 * @param user
	 *            the user to add
	 * @param user
	 *            the password for the new user
	 * @param user
	 *            the user to add
	 * @param user
	 *            the password for the new user
	 * @param user
	 *            the user to add
	 * @param user
	 *            the password for the new user
	 * @param password a {@link java.lang.String} object.
	 * @return a boolean.
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws java.io.FileNotFoundException if any.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 */
	public boolean addUser(UserDTO user, String password)
			throws DSNoConnectionException, FileNotFoundException,
			DSGeneralException {
		boolean success = false;
		String sAMAccountName = user.getSamAccountName();

		// Holds A.D. Connection object.
		DSmart dsConnection = null;

		try {
			// Connecting...
			dsConnection = this.getSslConnection();

			String peopleBase = Config.getPrivateProfileString(
					Constants.INI_LOCAL_SECTION, Constants.INI_PEOPLE_BASE,
					com.bcbssc.struts.common.Constants.BLANK_STRING,
					this.iniFile);
			StringBuffer userDN = new StringBuffer(64);
			userDN.append(Constants.LDAP_CN_SEARCHBASE_PREFIX).append(
					sAMAccountName).append(",").append(peopleBase);

			IDSValList addList = dsConnection.getIDSValList();

			this.appendUserToValList(user, addList, IDSValList.ACTION_ADD);
			this.addOrgAndRole(addList, user);

			addList.addString(Constants.LDAP_ATTRIBUTE_VALIDOBJECT,
					Constants.LDAP_VALUE_VALIDOBJECT, IDSValList.ACTION_ADD);
			addList.addString(Constants.LDAP_ATTRIBUTE_OBJECTCLASS,
					Constants.LDAP_VALUE_OBJECTCLASS, IDSValList.ACTION_ADD);

			addList.addString(Constants.LDAP_ATTRIBUTE_UNICODEPWD, password
					.toUpperCase(), IDSValList.ACTION_ADD);

			if (dsConnection.addDirEntry(userDN.toString(), addList, true) == 0) {
				success = true;
			}

		} catch (DSGeneralException dsge) {
			String msg = dsge.getDetailMessage();
			if (msg.indexOf(Constants.DSMART_NAME_BOUND_EXCEPTION_MESSAGE) != -1) {
				// if this user already exists, just return false... the
				// controller
				// should handle returning the user back to the create profile
				// page
				success = false;
			} else {

				LdapUserHandler.logger.error("Error:", dsge);
				NamingException nameEx = dsge.getNamingException();
				if (nameEx != null) {
					LdapUserHandler.logger.error("Root cause:", nameEx);
					LdapUserHandler.logger.error("Root cause:", nameEx
							.getRootCause());
				}

				if (dsConnection != null) {
					// Got a connection, but add failed... print add debug info
					CommonUtils.printErrorUserCode(user);
				}
				throw dsge;
			}
		}
		return success;
	}

	/**
	 * Updates a user's LDAP profile
	 *
	 * @param user
	 *            the user to update
	 * @return a boolean.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 */
	public boolean updateProfile(UserDTO user) throws DSPoolException,
			DSNoConnectionException, DSGeneralException {

		boolean success = false;
		String sAMAccountName = user.getSamAccountName();

		DSmartWrapper wrapper = null;
		DSmart dsConnection = null;

		try {
			wrapper = this.checkOutConnection();
			dsConnection = wrapper.getDSmart();

			String peopleBase = Config.getPrivateProfileString(
					Constants.INI_LOCAL_SECTION, Constants.INI_PEOPLE_BASE,
					com.bcbssc.struts.common.Constants.BLANK_STRING,
					this.iniFile);
			StringBuffer userDN = new StringBuffer(64);
			userDN.append(Constants.LDAP_CN_SEARCHBASE_PREFIX).append(
					sAMAccountName).append(",").append(peopleBase);

			IDSValList modifyList = dsConnection.getIDSValList();

			this.appendUserToValList(user, modifyList,
					IDSValList.ACTION_REPLACE);

			if (dsConnection
					.modifyDirEntry(userDN.toString(), modifyList, true) == 0) {
				success = true;
			}

		} catch (DSGeneralException dsge) {
			LdapUserHandler.logger.error("Error:", dsge);
			NamingException nameEx = dsge.getNamingException();
			if (nameEx != null) {
				LdapUserHandler.logger.error("Root cause:", nameEx);
				LdapUserHandler.logger.error("Root cause:", nameEx
						.getRootCause());
			}

			if (dsConnection != null) {
				// Got a connection, but add failed... print add debug info
				CommonUtils.printErrorUserCode(user);
			}
			throw dsge;

		} finally {
			this.checkInConnection(wrapper);
		}

		return success;
	}

	/**
	 * Updates a user password
	 *
	 * @param samAccountName
	 *            user for which the password will be updated
	 * @param newpassword
	 *            the new password
	 * @return a boolean.
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws java.io.FileNotFoundException if any.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 */
	public boolean updatePassword(String samAccountName, String newpassword)
			throws DSNoConnectionException, FileNotFoundException,
			DSGeneralException {

		boolean success = false;

		// Holds A.D. Connection object
		DSmart dsConnection = this.getSslConnection();

		String peopleBase = Config.getPrivateProfileString(
				Constants.INI_LOCAL_SECTION, Constants.INI_PEOPLE_BASE,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		StringBuffer userDN = new StringBuffer(64);
		userDN.append(Constants.LDAP_CN_SEARCHBASE_PREFIX).append(
				samAccountName).append(",").append(peopleBase);

		IDSValList replaceList = dsConnection.getIDSValList();
		replaceList.addString(Constants.LDAP_ATTRIBUTE_UNICODEPWD, newpassword
				.toUpperCase(), IDSValList.ACTION_REPLACE);

		try {
			if (dsConnection.modifyDirEntry(userDN.toString(), replaceList) == 0) {
				success = true;
			}
		} catch (DSGeneralException dsge) {
			LdapUserHandler.logger.error("Error:", dsge);
			NamingException nameEx = dsge.getNamingException();
			if (nameEx != null) {
				LdapUserHandler.logger.error("Root cause:", nameEx);
				LdapUserHandler.logger.error("Root cause:", nameEx
						.getRootCause());
			}
			throw dsge;
		}

		return success;
	}

	/**
	 * Updates a user's last access timestamp
	 *
	 * @param samAccountName
	 *            user name of profile to modify
	 * @param attribute
	 *            name of the ldap timestamp attribute
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	public void updateLastAccessTime(String samAccountName, String attribute)
			throws DSNoConnectionException, DSGeneralException, DSPoolException {

		this.updateSingleValue(attribute, this.accessTimestampFormat
				.format(new Date()), samAccountName);
	}

	/**
	 * Updates an attribute for a user
	 *
	 * @param samAccountName
	 *            user name of profile to modify
	 * @param attribute
	 *            name of the ldap attribute
	 * @param newValue a {@link java.lang.String} object.
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	public void updateLdapAttribute(String samAccountName, String attribute,
			String newValue) throws DSNoConnectionException,
			DSGeneralException, DSPoolException {

		this.updateSingleValue(attribute, newValue, samAccountName);
	}

	/**
	 * Updates a user's groups.
	 *
	 * @param samAccountName
	 *            user name of profile to modify.
	 * @param groups
	 *            the set of groups for the user.
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	public void updateGroups(String samAccountName, Collection groups)
			throws DSNoConnectionException, DSGeneralException, DSPoolException {
		this.updateMultivaluedValue(Constants.LDAP_ROLE_BASE, groups,
				samAccountName);
	}

	/**
	 * Reauthenticates a user using the ssn and date of birth
	 *
	 * @param last6SSN
	 *            last 6 digits of the user's social security number
	 * @param dob
	 *            user's date of birth
	 * @param samAccountName
	 *            user's name, if entered by user (or just blank)
	 * @return the reauthenticated user or null if the user could not be
	 *         reauthenticated
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	public UserDTO reauthenticate(String last6SSN, String dob,
			String samAccountName) throws DSNoConnectionException,
			DSGeneralException, DSPoolException {
		DSmartWrapper wrapper = null;
		DSmart dsConnection = null;

		UserDTO user = null;

		try {
			wrapper = this.checkOutConnection();
			dsConnection = wrapper.getDSmart();

			String peopleBase = Config.getPrivateProfileString(
					Constants.INI_LOCAL_SECTION, Constants.INI_PEOPLE_BASE,
					com.bcbssc.struts.common.Constants.BLANK_STRING,
					this.iniFile);

			String orgBase = Config.getPrivateProfileString(
					Constants.INI_LOCAL_SECTION,
					Constants.INI_ORGANIZATION_BASE,
					com.bcbssc.struts.common.Constants.BLANK_STRING,
					this.iniFile);

			StringBuffer filter = new StringBuffer(128);
			filter.append("(&(").append(Constants.LDAP_ORG_BASE).append('=');
			filter.append(orgBase).append(")(").append(
					Constants.LDAP_ATTRIBUTE_SSN).append('=');
			filter.append(last6SSN).append(")(").append(
					Constants.LDAP_ATTRIBUTE_DOB);
			filter.append('=').append(dob).append(')');
			if (samAccountName.length() != 0) {
				filter.append('(').append(
						Constants.LDAP_ATTRIBUTE_SAMACCOUNTNAME);
				filter.append('=').append(samAccountName).append(')');
			}
			filter.append(')');

			if (LdapUserHandler.logger.isDebugEnabled()) {
				LdapUserHandler.logger.debug("reauth filter is: "
						+ filter.toString());
			}

			String[] matchingProfiles = dsConnection.listDirEntries(peopleBase,
					filter.toString(), true);

			if (matchingProfiles.length > 0) {
				String userdn = matchingProfiles[0];
				if (LdapUserHandler.logger.isDebugEnabled()) {
					StringBuffer logMsg = new StringBuffer(64);
					logMsg.append("user reauthenticated (").append(userdn)
							.append("); getting info");
					LdapUserHandler.logger.debug(logMsg.toString());
				}

				IDSValList userValList = dsConnection.readDirEntry(userdn);
				user = this.createUserFromValList(userValList);
			}

		} catch (DSGeneralException dsge) {
			String msg = dsge.getDetailMessage();
			if (msg
					.indexOf(Constants.DSMART_INVALID_AUTHENTICATION_EXCEPTION_MESSAGE) == -1) {
				LdapUserHandler.logger.error("Error:", dsge);
				NamingException nameEx = dsge.getNamingException();
				if (nameEx != null) {
					LdapUserHandler.logger.error("Root cause:", nameEx);
					LdapUserHandler.logger.error("Root cause:", nameEx
							.getRootCause());
				}

				throw dsge;
			}
		} finally {
			this.checkInConnection(wrapper);
		}

		return user;
	}

	/**
	 * Counts the number of profiles contining the specified parameters.
	 *
	 * @param last6SSN
	 *            last 6 digits of the user's social security number
	 * @param dob
	 *            user's date of birth
	 * @return the number of profiles containing the specified SSN and DOB
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	public int getProfileCount(String last6SSN, String dob)
			throws DSNoConnectionException, DSGeneralException, DSPoolException {

		return this.getMatchingProfiles(last6SSN, dob).length;
	}

	/**
	 * Returns an array of username matching the specified parameters.
	 *
	 * @param last6SSN
	 *            last 6 digits of the user's social security number
	 * @param dob
	 *            user's date of birth
	 * @return String array of usernames for profiles containing the specified
	 *         SSN and DOB
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	public String[] getMatchingProfiles(String last6SSN, String dob)
			throws DSNoConnectionException, DSGeneralException, DSPoolException {
		return this.getMatchingProfiles(last6SSN, dob, "");
	}

	/**
	 * Returns an array of username matching the specified parameters.
	 *
	 * @param last6SSN
	 *            last 6 digits of the user's social security number
	 * @param dob
	 *            user's date of birth
	 * @return String array of usernames for profiles containing the specified
	 *         SSN and DOB
	 * @param lastName a {@link java.lang.String} object.
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	public String[] getMatchingProfiles(String last6SSN, String dob,
			String lastName) throws DSNoConnectionException,
			DSGeneralException, DSPoolException {

		Hashtable<String, String> filters = new Hashtable<String, String>();
		filters.put(Constants.LDAP_ATTRIBUTE_SSN, last6SSN);
		filters.put(Constants.LDAP_ATTRIBUTE_DOB, dob);

		if (StringUtils.isNotBlank(lastName)) {
			filters.put(Constants.LDAP_ATTRIBUTE_SN, lastName);
		}
		return this.getMatchingProfiles(filters);
	}

	/**
	 * Returns an array of username matching the specified parameters.
	 *
	 * @return String array of usernames for profiles containing the specified
	 *         SSN and DOB
	 * @param filtersWithValues a {@link java.util.Hashtable} object.
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	public String[] getMatchingProfiles(Hashtable<String, String> filtersWithValues)
			throws DSNoConnectionException, DSGeneralException, DSPoolException {
		DSmartWrapper wrapper = null;
		DSmart dsConnection = null;

		String[] userNames = {};

		try {
			wrapper = this.checkOutConnection();
			dsConnection = wrapper.getDSmart();

			String peopleBase = Config.getPrivateProfileString(
					Constants.INI_LOCAL_SECTION, Constants.INI_PEOPLE_BASE,
					com.bcbssc.struts.common.Constants.BLANK_STRING,
					this.iniFile);

			String orgBase = Config.getPrivateProfileString(
					Constants.INI_LOCAL_SECTION,
					Constants.INI_ORGANIZATION_BASE,
					com.bcbssc.struts.common.Constants.BLANK_STRING,
					this.iniFile);
			StringBuffer filter = new StringBuffer(128);
			filter.append("(&(").append(Constants.LDAP_ORG_BASE).append('=');
			filter.append(orgBase).append(")");

			Enumeration<String> filterValues = filtersWithValues.keys();
			if (filterValues != null) {
				while (filterValues.hasMoreElements()) {
					String name = (String) filterValues.nextElement();
					String value = (String) filtersWithValues.get(name);
					filter.append("(").append(name).append('=').append(value)
							.append(")");
				}
			}
			filter.append(")");

			if (LdapUserHandler.logger.isDebugEnabled()) {
				LdapUserHandler.logger
						.debug("In getMatchingProfiles  the filter is: "
								+ filter.toString());
			}

			userNames = dsConnection.listDirEntries(peopleBase, filter
					.toString(), true);

		} catch (DSGeneralException dsge) {
			LdapUserHandler.logger.error("Error:", dsge);
			NamingException nameEx = dsge.getNamingException();
			if (nameEx != null) {
				LdapUserHandler.logger.error("Root cause:", nameEx);
				LdapUserHandler.logger.error("Root cause:", nameEx
						.getRootCause());
			}

			throw dsge;
		} finally {
			this.checkInConnection(wrapper);
		}

		return userNames;
	}

	/**
	 * Validates a user password
	 *
	 * @param samAccountName
	 *            user name
	 * @param unicodePwd
	 *            password
	 * @return the validated user or null if the user could not be validated
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	public UserDTO validateUser(String samAccountName, String unicodePwd)
			throws DSNoConnectionException, DSGeneralException, DSPoolException {

		DSmartWrapper wrapper = null;
		DSmart dsConnection = null;

		UserDTO user = null;

		try {
			wrapper = this.checkOutConnection();
			dsConnection = wrapper.getDSmart();

			String peopleBase = Config.getPrivateProfileString(
					Constants.INI_LOCAL_SECTION, Constants.INI_PEOPLE_BASE,
					com.bcbssc.struts.common.Constants.BLANK_STRING,
					this.iniFile);

			StringBuffer userDN = new StringBuffer(64);
			userDN.append(Constants.LDAP_CN_SEARCHBASE_PREFIX).append(
					samAccountName).append(",").append(peopleBase);

			if (LdapUserHandler.logger.isDebugEnabled()) {
				LdapUserHandler.logger.debug("validating user: " + userDN);
			}
			int success = dsConnection.validateUser(userDN.toString(),
					unicodePwd.toUpperCase());

			if (success == 0) {
				if (LdapUserHandler.logger.isDebugEnabled()) {
					LdapUserHandler.logger
							.debug("user validated; getting user object");
				}
				IDSValList userValList = dsConnection.readDirEntry(userDN
						.toString());
				user = this.createUserFromValList(userValList);

				if (user != null) {
					// verify the user's organization
					user = this.verifyUserOrg(user);
				}
			}

		} catch (DSGeneralException dsge) {
			String msg = dsge.getDetailMessage();
			if (msg
					.indexOf(Constants.DSMART_INVALID_AUTHENTICATION_EXCEPTION_MESSAGE) == -1) {
				LdapUserHandler.logger.error("Error:", dsge);
				NamingException nameEx = dsge.getNamingException();
				if (nameEx != null) {
					LdapUserHandler.logger.error("Root cause:", nameEx);
					LdapUserHandler.logger.error("Root cause:", nameEx
							.getRootCause());
				}

				throw dsge;
			}
		} finally {
			this.checkInConnection(wrapper);
		}

		return user;
	}

	/**
	 * Get a User
	 *
	 * @param nameOrDN
	 *            user samAccountName or userDN
	 * @return the user or null if the user does not exist
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	public UserDTO getUser(String nameOrDN) throws DSNoConnectionException,
			DSPoolException {
		DSmartWrapper wrapper = null;
		DSmart dsConnection = null;
		UserDTO user = null;

		try {
			wrapper = this.checkOutConnection();
			dsConnection = wrapper.getDSmart();

			user = this.getUser(nameOrDN, dsConnection);

		} finally {
			this.checkInConnection(wrapper);
		}

		return user;
	}

	/**
	 * Creates a user object describing the user defined in the encrypted ONT
	 * Credentials cookie
	 *
	 * @return the user defined in the cookie or null, if the cookie value isn't
	 *         valid
	 * @param sEncryptedCookie a {@link java.lang.String} object.
	 * @throws com.opennetwork.DSUtils.DSNoConnectionException if any.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	public UserDTO getUserFromCookie(String sEncryptedCookie)
			throws DSNoConnectionException, DSGeneralException, DSPoolException {

		DSmartWrapper wrapper = null;
		DSmart dSmart = null;
		UserDTO returnUserDTO = null;

		try {
			wrapper = this.checkOutConnection();
			dSmart = wrapper.getDSmart();

			String userDN = this.getUserDNFromCookie(sEncryptedCookie, dSmart);

			if (userDN != null) {
				returnUserDTO = this.getUser(userDN, dSmart);
			}

			return returnUserDTO;

		} finally {
			this.checkInConnection(wrapper);
		}
	}

	/**
	 * Gets a user described by the encrypted user cookie and the superuser
	 * cookies.
	 *
	 * @param racfCookie
	 *            racf cookie value
	 * @param suType
	 *            superuser type cookie value
	 * @return ldap user specified by the cookie
	 * @param szOntCredCookie a {@link java.lang.String} object.
	 * @throws java.lang.Exception if any.
	 */
	public UserDTO getUserFromCookies(String szOntCredCookie,
			String racfCookie, String suType) throws Exception {
		UserDTO user = this.getUserFromCookie(szOntCredCookie);
		if ((racfCookie != null) && (racfCookie.length() > 0)
				&& (suType != null)) {
			user.setSuperUserType(suType);
		}

		return user;
	}

	/**
	 * Gets the samAccountName from the encrypted cookie
	 *
	 * @return the samAccountName of the user defined in the cookie or null, if
	 *         the cookie value isn't valid
	 * @param sEncryptedCookie a {@link java.lang.String} object.
	 * @throws com.opennetwork.DSUtils.DSGeneralException if any.
	 * @throws com.bcbssc.registration.ldap.DSPoolException if any.
	 */
	public String getSamAccountNameFromCookie(String sEncryptedCookie)
			throws DSGeneralException, DSPoolException {
		String userDN = this.getUserDNFromCookie(sEncryptedCookie);
		String returnString = null;

		// Verify userDN has the form
		// CN=test0914,OU=registeredUsers,O=clifeGroupAdmin,DC=egger2k,DC=com
		if ((userDN != null)
				&& (userDN.indexOf(Constants.LDAP_CN_SEARCHBASE_PREFIX) == 0)
				&& (userDN.indexOf(',') != -1)) {
			returnString = userDN.substring(Constants.LDAP_CN_SEARCHBASE_PREFIX
					.length(), userDN.indexOf(','));
		}

		return returnString;

	}

	/**
	 * Gets the samAccountName from the DN
	 *
	 * @param distinguishedName
	 *            user DN
	 * @return the samAccountName contained in the DN
	 */
	public static String getSamAccountNameFromDN(String distinguishedName) {
		int startIndex = distinguishedName.indexOf('=') + 1;
		int endIndex = distinguishedName.indexOf(',');
		return distinguishedName.substring(startIndex, endIndex);
	}

	/**
	 * Returns the role DN for the specified role parameter.
	 *
	 * @param roleParam
	 *            the role parameter in the Local section of the INI file.
	 * @return the distinguished role name.
	 */
	public String getDistinguishedRoleName(String roleParam) {
		return LdapUserHandler
				.getDistinguishedRoleName(roleParam, this.iniFile);
	}

	/**
	 * Returns the role DN for the specified role parameter in the given INI
	 * file.
	 *
	 * @param roleParam
	 *            the role parameter in the Local section of the INI file.
	 * @param iniFile
	 *            the INI file to use.
	 * @return the distinguished role name.
	 */
	public static String getDistinguishedRoleName(String roleParam,
			String iniFile) {

		String roleBase = Config.getPrivateProfileString(
				Constants.INI_LOCAL_SECTION, Constants.INI_ROLE_BASE,
				com.bcbssc.struts.common.Constants.BLANK_STRING, iniFile);

		String role = Config.getPrivateProfileString(
				Constants.INI_LOCAL_SECTION, roleParam,
				com.bcbssc.struts.common.Constants.BLANK_STRING, iniFile);

		StringBuffer buf = new StringBuffer(128);
		buf.append(role).append(',');
		buf.append(roleBase);
		return buf.toString();
	}

	/**
	 * Adds a user to a DirectorySmart IDSValList
	 *
	 * @param user
	 *            a user
	 * @param addList
	 *            list to which the user will be added
	 * @param action a int.
	 */
	protected abstract void appendUserToValList(UserDTO user,
			IDSValList addList, int action);

	/**
	 * Creates a user from a DirectorySmart IDSValList
	 *
	 * @param valList
	 *            list containing user profile info
	 * @return user described by the valList
	 */
	protected abstract UserDTO createUserFromValList(IDSValList valList);

	/**
	 * Adds the organization and role for the specified user to a Directory
	 * Smart IDSValList
	 *
	 * @param addList
	 *            list to which the org and role will be added
	 * @param user
	 *            user whose data will determine the org and role to add
	 */
	protected abstract void addOrgAndRole(IDSValList addList, UserDTO user);

	/**
	 * Determines if an LDAP profile exists for the specified filter.
	 * 
	 * @param ldapFilter
	 *            ldap filter
	 * @return true, if filter matched one or more profiles; false otherwise
	 * @throws DSNoConnectionException -
	 *             if a DSmart connection could not be made
	 * @throws DSGeneralException -
	 *             if a general DSmart problem occured
	 * @throws DSPoolException -
	 *             if a Dsmart connection could not be checked into or out of
	 *             the pool.
	 */
	boolean profileExists(String ldapFilter) throws DSNoConnectionException,
			DSGeneralException, DSPoolException {
		DSmartWrapper wrapper = null;
		DSmart dsConnection = null;

		boolean retval = false;

		try {
			wrapper = this.checkOutConnection();
			dsConnection = wrapper.getDSmart();

			String peopleBase = Config.getPrivateProfileString(
					Constants.INI_LOCAL_SECTION, Constants.INI_PEOPLE_BASE,
					com.bcbssc.struts.common.Constants.BLANK_STRING,
					this.iniFile);
			String searchBase = peopleBase;
			String[] matchingProfiles = dsConnection.listDirEntries(searchBase,
					ldapFilter, true);

			if (matchingProfiles.length > 0) {
				retval = true;
			}

		} catch (DSGeneralException dsge) {
			LdapUserHandler.logger.error("Error:", dsge);
			NamingException nameEx = dsge.getNamingException();
			if (nameEx != null) {
				LdapUserHandler.logger.error("Root cause:", nameEx);
				LdapUserHandler.logger.error("Root cause:", nameEx
						.getRootCause());
			}

			throw dsge;
		} finally {
			this.checkInConnection(wrapper);
		}

		return retval;
	}

	/**
	 * Get a User
	 * 
	 * @param nameOrDN
	 *            user samAccountName or userDN
	 * @param dsConnection
	 *            DSmart connection to use for the LDAP read
	 * @return the user or null if the user does not exist
	 * @throws DSNoConnectionException
	 *             no DSmart connection could be created
	 * @throws DSPoolException -
	 *             if a Dsmart connection could not be checked into or out of
	 *             the pool.
	 */
	private UserDTO getUser(String nameOrDN, DSmart dsConnection)
			throws DSNoConnectionException {

		UserDTO user = null;

		StringBuffer userDN = new StringBuffer(64);

		try {

			// Create a userDN from the nameOrDN if it is a samAccountName
			// Note that usernames cannot include '=' so it's okay to filter
			// on "CN="
			if (nameOrDN.indexOf(Constants.LDAP_CN_SEARCHBASE_PREFIX) == -1) {
				String peopleBase = Config.getPrivateProfileString(
						Constants.INI_LOCAL_SECTION, Constants.INI_PEOPLE_BASE,
						com.bcbssc.struts.common.Constants.BLANK_STRING,
						this.iniFile);

				userDN.append(Constants.LDAP_CN_SEARCHBASE_PREFIX).append(
						nameOrDN).append(",").append(peopleBase);
			} else {
				// nameOrDN is already a DN
				userDN.append(nameOrDN);
			}

			IDSValList userValList = dsConnection.readDirEntry(userDN
					.toString());
			user = this.createUserFromValList(userValList);

			// Verify the user's organization
			user = this.verifyUserOrg(user);

		} catch (DSGeneralException e) {
			// User doesn't exist; okay to swallow exception and return null
			LdapUserHandler.logger.warn(Constants.EXCEPTION_DSMART_GENERAL, e);

			StringBuffer logMsg = new StringBuffer(64);
			logMsg.append("user").append(userDN).append(" does not exist");
			LdapUserHandler.logger.warn(logMsg.toString());
		}

		return user;
	}

	/**
	 * Gets the userDN from the encrypted cookie
	 * 
	 * @param sEncryptedCooke
	 *            value of the ONTCred cookie
	 * @return the userDN of the user defined in the cookie or null, if the
	 *         cookie value isn't valid
	 * @throws DSGeneralException -
	 *             if a general DSmart problem occured
	 * @throws DSPoolException -
	 *             if a Dsmart connection could not be checked into or out of
	 *             the pool.
	 */
	private String getUserDNFromCookie(String sEncryptedCookie)
			throws DSGeneralException, DSPoolException {
		DSmartWrapper wrapper = null;
		DSmart dSmart = null;

		try {
			wrapper = this.checkOutConnection();
			dSmart = wrapper.getDSmart();

			return this.getUserDNFromCookie(sEncryptedCookie, dSmart);

		} finally {
			this.checkInConnection(wrapper);
		}
	}

	/**
	 * Gets the userDN from the encrypted cookie
	 * 
	 * @param sEncryptedCooke
	 *            value of the ONTCred cookie
	 * @param dsConnection
	 *            DSmart connection to use for the LDAP read
	 * @return the userDN of the user defined in the cookie or null, if the
	 *         cookie value isn't valid
	 * @throws DSGeneralException -
	 *             if a general DSmart problem occured
	 */
	private String getUserDNFromCookie(String sEncryptedCookie,
			DSmart dsConnection) throws DSGeneralException {

		if ((sEncryptedCookie == null) || (sEncryptedCookie.length() == 0)) {
			return null;
		}

		String cookieKey = Config.getPrivateProfileString(
				Constants.INI_COOKIE_SECTION, Constants.INI_AUTH_COOKIE_KEY,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		String cookieIV = Config.getPrivateProfileString(
				Constants.INI_COOKIE_SECTION, Constants.INI_AUTH_COOKIE_IV,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		try {
			IDSValList list = dsConnection.getAllAuthData(sEncryptedCookie,
					cookieKey.toCharArray(), cookieIV.toCharArray());
			return com.bcbssc.struts.common.CommonUtils.getSingleValuedString(
					LdapHandler.ONT_CRED_COOKIE_DN, list);
		} catch (DSGeneralException dsge) {
			LdapUserHandler.logger.error("Error:", dsge);
			NamingException nameEx = dsge.getNamingException();
			if (nameEx != null) {
				LdapUserHandler.logger.error("Root cause:", nameEx);
				LdapUserHandler.logger.error("Root cause:", nameEx
						.getRootCause());
			}

			throw dsge;
		}
	}

	/**
	 * Verifies that a user's organization matches the org from the INI file
	 * 
	 * @param user
	 *            user create from LDAP info
	 * @return the specified user or null, if the user's org does not match the
	 *         INI org
	 */
	private UserDTO verifyUserOrg(UserDTO user) {
		UserDTO returnUserDTO = user;
		String orgBase = Config.getPrivateProfileString(
				Constants.INI_LOCAL_SECTION, Constants.INI_ORGANIZATION_BASE,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		if (!user.getOrg().equalsIgnoreCase(orgBase)) {
			if (LdapUserHandler.logger.isDebugEnabled()) {
				StringBuffer logMsg = new StringBuffer(128);
				logMsg.append("user org (").append(user.getOrg()).append(
						") does NOT match expected org (").append(orgBase)
						.append(").");
				LdapUserHandler.logger.debug(logMsg.toString());
			}
			returnUserDTO = null;
		}

		return returnUserDTO;
	}
}
