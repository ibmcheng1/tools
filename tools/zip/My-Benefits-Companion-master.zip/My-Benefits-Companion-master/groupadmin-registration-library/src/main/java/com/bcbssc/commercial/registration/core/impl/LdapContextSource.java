package com.bcbssc.commercial.registration.core.impl;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.ldap.InitialLdapContext;

import org.apache.commons.lang.StringUtils;

import com.bcbssc.commercial.registration.core.ContextSource;

/**
 * <p>LdapContextSource class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class LdapContextSource implements ContextSource {

	private String base			= "";
	
	private String userDn 		= "";

	private String password 	= "";

	private String url			= "";
	
	/**
	 * <p>Getter for the field <code>base</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getBase() {
		return base;
	}

	/**
	 * <p>Setter for the field <code>base</code>.</p>
	 *
	 * @param base a {@link java.lang.String} object.
	 */
	public void setBase(String base) {
		this.base = base;
	}

	/**
	 * <p>Getter for the field <code>userDn</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getUserDn() {
		return userDn;
	}

	/**
	 * <p>Setter for the field <code>userDn</code>.</p>
	 *
	 * @param userDn a {@link java.lang.String} object.
	 */
	public void setUserDn(String userDn) {
		this.userDn = userDn;
	}

	/**
	 * <p>Getter for the field <code>password</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * <p>Setter for the field <code>password</code>.</p>
	 *
	 * @param password a {@link java.lang.String} object.
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * <p>Getter for the field <code>url</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * <p>Setter for the field <code>url</code>.</p>
	 *
	 * @param url a {@link java.lang.String} object.
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * <p>afterPropertiesSet.</p>
	 *
	 * @throws java.lang.Exception if any.
	 */
	public void afterPropertiesSet() throws Exception {
		
		if (StringUtils.isBlank(url) || StringUtils.isBlank(userDn) || StringUtils.isBlank(password)) {
			throw new IllegalArgumentException("Required attributes missing");
		}
	}		
	
	/**
	 * <p>getEnvironment.</p>
	 *
	 * @return a {@link java.util.Hashtable} object.
	 */
	public Hashtable<String, String> getEnvironment() {

		Hashtable<String, String> environment 	= new Hashtable<String, String>();
		
		environment.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		environment.put(Context.SECURITY_AUTHENTICATION, "simple");
		environment.put(Context.SECURITY_PRINCIPAL, userDn);
		environment.put(Context.SECURITY_CREDENTIALS, password);
		environment.put(Context.PROVIDER_URL, url);
		environment.put(Context.OBJECT_FACTORIES, "com.bcbssc.commercial.registration.core.impl.DefaultDirObjectFactory");

		return environment;
	}
	
	/**
	 * <p>getContext.</p>
	 *
	 * @return a {@link javax.naming.directory.DirContext} object.
	 * @throws javax.naming.NamingException if any.
	 */
	public DirContext getContext() throws NamingException {
		
		Hashtable<String, String> environment	= getEnvironment();
		return getDirContextInstance(environment);
	}

    /**
     * <p>getDirContextInstance.</p>
     *
     * @param environment a {@link java.util.Hashtable} object.
     * @return a {@link javax.naming.directory.DirContext} object.
     * @throws javax.naming.NamingException if any.
     */
    protected DirContext getDirContextInstance(Hashtable<String, String> environment) throws NamingException {
        return new InitialLdapContext(environment, null);
    }	
}
