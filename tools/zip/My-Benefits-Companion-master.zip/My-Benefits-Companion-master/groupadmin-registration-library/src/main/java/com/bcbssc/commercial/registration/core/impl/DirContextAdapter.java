package com.bcbssc.commercial.registration.core.impl;

import java.util.Collection;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;

import javax.naming.Context;
import javax.naming.Name;
import javax.naming.NameNotFoundException;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.NoSuchAttributeException;
import javax.naming.directory.SearchControls;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapName;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;

import com.bcbssc.commercial.registration.core.DirContextOperations;

/**
 * <p>DirContextAdapter class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class DirContextAdapter extends InitialLdapContext implements DirContextOperations {

	private static final boolean ORDER_DOESNT_MATTER = false;
	
	private static final Logger log		= Logger.getLogger(DirContextAdapter.class.getName());

	private Attributes originalAttrs;

 	private LdapName dn;

 	private LdapName base;

	/**
	 * Create a new adapter from the supplied attributes, dn, base, and referral
	 * url.
	 *
	 * @throws javax.naming.NamingException if any.
	 */
	public DirContextAdapter() throws NamingException {
		this(null, null, null, null);
	}

	/**
	 * <p>Constructor for DirContextAdapter.</p>
	 *
	 * @param attrs a {@link javax.naming.directory.Attributes} object.
	 * @param dn a {@link javax.naming.ldap.LdapName} object.
	 * @throws javax.naming.NamingException if any.
	 */
	public DirContextAdapter(Attributes attrs, LdapName dn) throws NamingException {
		this(attrs, dn, null, null);
	}	
	
	/**
	 * <p>Constructor for DirContextAdapter.</p>
	 *
	 * @param attrs a {@link javax.naming.directory.Attributes} object.
	 * @param dn a {@link javax.naming.ldap.LdapName} object.
	 * @param base a {@link javax.naming.ldap.LdapName} object.
	 * @param referralUrl a {@link java.lang.String} object.
	 * @throws javax.naming.NamingException if any.
	 */
	public DirContextAdapter(Attributes attrs, LdapName dn, LdapName base, String referralUrl) throws NamingException {
		
		if (attrs != null) {
			this.originalAttrs 			= attrs;
		}
		else {
			this.originalAttrs 			= new BasicAttributes(true);
		}
		
		if (dn != null) {
			this.dn 					= dn;
		}
		else {
			this.dn 					= new LdapName("");
		}
		if (base != null) {
			this.base 					= base;
		}
		else {
			this.base 					= new LdapName("");
		}
		
		if(log.isDebugEnabled()) {
			log.debug("The dn is " + this.dn);
			log.debug("The base is " + this.base);
		}		
	}	
	
	/*
	 * @see
	 * org.springframework.ldap.support.DirContextOperations#getStringAttribute
	 * (java.lang.String)
	 */
	/** {@inheritDoc} */
	public String getStringAttribute(String name) {
		return (String) getObjectAttribute(name);
	}

	/*
	 * @see
	 * org.springframework.ldap.support.DirContextOperations#getObjectAttribute
	 * (java.lang.String)
	 */
	/** {@inheritDoc} */
	public Object getObjectAttribute(String name) {
		Attribute oneAttr = originalAttrs.get(name);
		if (oneAttr == null) {
			return null;
		}
		try {
			return oneAttr.get();
		}
		catch (NamingException namingException) {
			return null;
		}
	}

	/** {@inheritDoc} */
	public void setAttributeValue(String name, Object value) {

		// new entry
		if (value != null) {
			originalAttrs.put(name, value);
		}
	}

	/**
	 * <p>addAttributeValue.</p>
	 *
	 * @param name a {@link java.lang.String} object.
	 * @param value a {@link java.lang.Object} object.
	 */
	public void addAttributeValue(String name, Object value) {
		if (value != null) {
			Attribute attr = originalAttrs.get(name);
			if (attr == null) {
				originalAttrs.put(name, value);
			}
			else {
				attr.add(value);
			}
		}
	}

	/*
	 * @see
	 * org.springframework.ldap.support.DirContextOperations#setAttributeValues
	 * (java.lang.String, java.lang.Object[])
	 */
	/**
	 * <p>setAttributeValues.</p>
	 *
	 * @param name a {@link java.lang.String} object.
	 * @param values an array of {@link java.lang.Object} objects.
	 */
	public void setAttributeValues(String name, Object[] values) {
		setAttributeValues(name, values, ORDER_DOESNT_MATTER);
	}

	/*
	 * @see
	 * org.springframework.ldap.support.DirContextOperations#setAttributeValues
	 * (java.lang.String, java.lang.Object[], boolean)
	 */
	/** {@inheritDoc} */
	public void setAttributeValues(String name, Object[] values, boolean orderMatters) {
		Attribute a = new BasicAttribute(name, orderMatters);

		if(values != null && values.length > 0) {
		
			for (int i = 0; values != null && i < values.length; i++) {				
				a.add(values[i]);
			}
			
			originalAttrs.put(a);
		}
	}


	/*
	 * @see
	 * org.springframework.ldap.core.DirContextOperations#getStringAttributes
	 * (java.lang.String)
	 */
	/** {@inheritDoc} */
	@SuppressWarnings("unchecked")
	public String[] getStringAttributes(String name) {
		try {
			return (String[]) collectAttributeValuesAsList(name).toArray(new String[0]);
		}
		catch (NoSuchAttributeException e) {
			// The attribute does not exist - contract says to return null.
			return null;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.ldap.core.DirContextOperations#getObjectAttributes
	 * (java.lang.String)
	 */
	/** {@inheritDoc} */
	@SuppressWarnings("unchecked")
	public Object[] getObjectAttributes(String name) {
		try {
			return collectAttributeValuesAsList(name).toArray(new Object[0]);
		}
		catch (NoSuchAttributeException e) {
			// The attribute does not exist - contract says to return null.
			return null;
		}
	}

	private List collectAttributeValuesAsList(String name) throws NoSuchAttributeException {
		List list = new LinkedList();
		collectAttributeValues(originalAttrs, name, list);
		return list;
	}


	/**
	 * Set the supplied attribute.
	 *
	 * @param attribute the attribute to set.
	 */
	public void setAttribute(Attribute attribute) {
		originalAttrs.put(attribute);
	}

	/**
	 * Get all attributes.
	 *
	 * @return all attributes.
	 */
	public Attributes getAttributes() {
		return originalAttrs;
	}

	/** {@inheritDoc} */
	public Attributes getAttributes(Name name) throws NamingException {
		return getAttributes(name.toString());
	}

	/**
	 * <p>getAttributes.</p>
	 *
	 * @see javax.naming.directory.DirContext#getAttributes(String)
	 * @param name a {@link java.lang.String} object.
	 * @return a {@link javax.naming.directory.Attributes} object.
	 * @throws javax.naming.NamingException if any.
	 */
	public Attributes getAttributes(String name) throws NamingException {
		if (StringUtils.hasLength(name)) {
			throw new NameNotFoundException();
		}
		return (Attributes) originalAttrs.clone();
	}

	/**
	 * <p>getAttributes.</p>
	 *
	 * @see javax.naming.directory.DirContext#getAttributes(Name, String[])
	 * @param name a {@link javax.naming.Name} object.
	 * @param attrIds an array of {@link java.lang.String} objects.
	 * @return a {@link javax.naming.directory.Attributes} object.
	 * @throws javax.naming.NamingException if any.
	 */
	public Attributes getAttributes(Name name, String[] attrIds)
			throws NamingException {
		return getAttributes(name.toString(), attrIds);
	}

	/**
	 * <p>getAttributes.</p>
	 *
	 * @see javax.naming.directory.DirContext#getAttributes(String, String[])
	 * @param name a {@link java.lang.String} object.
	 * @param attrIds an array of {@link java.lang.String} objects.
	 * @return a {@link javax.naming.directory.Attributes} object.
	 * @throws javax.naming.NamingException if any.
	 */
	public Attributes getAttributes(String name, String[] attrIds)
			throws NamingException {
		if (StringUtils.hasLength(name)) {
			throw new NameNotFoundException();
		}

		Attributes a = new BasicAttributes(true);
		Attribute target;
		for (int i = 0; i < attrIds.length; i++) {
			target = originalAttrs.get(attrIds[i]);
			if (target != null) {
				a.put(target);
			}
		}

		return a;
	}

	/** {@inheritDoc} */
	public void modifyAttributes(Name name, int modOp, Attributes attrs)
			throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public void modifyAttributes(String name, int modOp, Attributes attrs)
			throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/**
	 * <p>modifyAttributes.</p>
	 *
	 * @see javax.naming.directory.DirContext#modifyAttributes(Name,
	 * ModificationItem[])
	 * @param name a {@link javax.naming.Name} object.
	 * @param mods an array of {@link javax.naming.directory.ModificationItem} objects.
	 * @throws javax.naming.NamingException if any.
	 */
	public void modifyAttributes(Name name, ModificationItem[] mods)
			throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/**
	 * <p>modifyAttributes.</p>
	 *
	 * @see javax.naming.directory.DirContext#modifyAttributes(String,
	 * ModificationItem[])
	 * @param name a {@link java.lang.String} object.
	 * @param mods an array of {@link javax.naming.directory.ModificationItem} objects.
	 * @throws javax.naming.NamingException if any.
	 */
	public void modifyAttributes(String name, ModificationItem[] mods)
			throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public void bind(Name name, Object obj, Attributes attrs)
			throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public void bind(String name, Object obj, Attributes attrs)
			throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public void rebind(Name name, Object obj, Attributes attrs)
			throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public void rebind(String name, Object obj, Attributes attrs)
			throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public DirContext createSubcontext(Name name, Attributes attrs)
			throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public DirContext createSubcontext(String name, Attributes attrs)
			throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public DirContext getSchema(Name name) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/**
	 * {@inheritDoc}
	 *
	 * <p>getSchema.</p>
	 * @see javax.naming.directory.DirContext#getSchema(String)
	 */
	public DirContext getSchema(String name) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/**
	 * {@inheritDoc}
	 *
	 * <p>getSchemaClassDefinition.</p>
	 * @see javax.naming.directory.DirContext#getSchemaClassDefinition(Name)
	 */
	public DirContext getSchemaClassDefinition(Name name)
			throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public DirContext getSchemaClassDefinition(String name)
			throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/**
	 * <p>search.</p>
	 *
	 * @see javax.naming.directory.DirContext#search(Name, Attributes, String[])
	 * @param name a {@link javax.naming.Name} object.
	 * @param matchingAttributes a {@link javax.naming.directory.Attributes} object.
	 * @param attributesToReturn an array of {@link java.lang.String} objects.
	 * @return a {@link javax.naming.NamingEnumeration} object.
	 * @throws javax.naming.NamingException if any.
	 */
	@SuppressWarnings("unchecked")
	public NamingEnumeration search(Name name, Attributes matchingAttributes,
			String[] attributesToReturn) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/**
	 * <p>search.</p>
	 *
	 * @see javax.naming.directory.DirContext#search(String, Attributes,
	 * String[])
	 * @param name a {@link java.lang.String} object.
	 * @param matchingAttributes a {@link javax.naming.directory.Attributes} object.
	 * @param attributesToReturn an array of {@link java.lang.String} objects.
	 * @return a {@link javax.naming.NamingEnumeration} object.
	 * @throws javax.naming.NamingException if any.
	 */
	@SuppressWarnings("unchecked")
	public NamingEnumeration search(String name, Attributes matchingAttributes,
			String[] attributesToReturn) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	@SuppressWarnings("unchecked")
	public NamingEnumeration search(Name name, Attributes matchingAttributes)
			throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	@SuppressWarnings("unchecked")
	public NamingEnumeration search(String name, Attributes matchingAttributes)
			throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/**
	 * <p>search.</p>
	 *
	 * @see javax.naming.directory.DirContext#search(Name, String,
	 * SearchControls)
	 * @param name a {@link javax.naming.Name} object.
	 * @param filter a {@link java.lang.String} object.
	 * @param cons a {@link javax.naming.directory.SearchControls} object.
	 * @return a {@link javax.naming.NamingEnumeration} object.
	 * @throws javax.naming.NamingException if any.
	 */
	@SuppressWarnings("unchecked")
	public NamingEnumeration search(Name name, String filter,
			SearchControls cons) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/**
	 * <p>search.</p>
	 *
	 * @see javax.naming.directory.DirContext#search(String, String,
	 * SearchControls)
	 * @param name a {@link java.lang.String} object.
	 * @param filter a {@link java.lang.String} object.
	 * @param cons a {@link javax.naming.directory.SearchControls} object.
	 * @return a {@link javax.naming.NamingEnumeration} object.
	 * @throws javax.naming.NamingException if any.
	 */
	@SuppressWarnings("unchecked")
	public NamingEnumeration search(String name, String filter,
			SearchControls cons) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	@SuppressWarnings("unchecked")
	public NamingEnumeration search(Name name, String filterExpr,
			Object[] filterArgs, SearchControls cons) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	@SuppressWarnings("unchecked")
	public NamingEnumeration search(String name, String filterExpr,
			Object[] filterArgs, SearchControls cons) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public Object lookup(Name name) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/**
	 * {@inheritDoc}
	 *
	 * <p>lookup.</p>
	 * @see javax.naming.Context#lookup(String)
	 */
	public Object lookup(String name) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public void bind(Name name, Object obj) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public void bind(String name, Object obj) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public void rebind(Name name, Object obj) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public void rebind(String name, Object obj) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/**
	 * <p>unbind.</p>
	 *
	 * @see javax.naming.Context#unbind(Name)
	 * @param name a {@link javax.naming.Name} object.
	 * @throws javax.naming.NamingException if any.
	 */
	public void unbind(Name name) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public void unbind(String name) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public void rename(Name oldName, Name newName) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/**
	 * <p>rename.</p>
	 *
	 * @see javax.naming.Context#rename(String, String)
	 * @param oldName a {@link java.lang.String} object.
	 * @param newName a {@link java.lang.String} object.
	 * @throws javax.naming.NamingException if any.
	 */
	public void rename(String oldName, String newName) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	@SuppressWarnings("unchecked")
	public NamingEnumeration list(Name name) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	@SuppressWarnings("unchecked")
	public NamingEnumeration list(String name) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	@SuppressWarnings("unchecked")
	public NamingEnumeration listBindings(Name name) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/**
	 * <p>listBindings.</p>
	 *
	 * @see javax.naming.Context#listBindings(String)
	 * @param name a {@link java.lang.String} object.
	 * @return a {@link javax.naming.NamingEnumeration} object.
	 * @throws javax.naming.NamingException if any.
	 */
	@SuppressWarnings("unchecked")
	public NamingEnumeration listBindings(String name) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/**
	 * {@inheritDoc}
	 *
	 * <p>destroySubcontext.</p>
	 * @see javax.naming.Context#destroySubcontext(Name)
	 */
	public void destroySubcontext(Name name) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public void destroySubcontext(String name) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public Context createSubcontext(Name name) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public Context createSubcontext(String name) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public Object lookupLink(Name name) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param name a {@link java.lang.String} object.
	 * @return a {@link java.lang.Object} object.
	 * @throws javax.naming.NamingException if any.
	 */
	public Object lookupLink(String name) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public NameParser getNameParser(Name name) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param name a {@link java.lang.String} object.
	 * @return a {@link javax.naming.NameParser} object.
	 * @throws javax.naming.NamingException if any.
	 */
	public NameParser getNameParser(String name) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public Name composeName(Name name, Name prefix) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public String composeName(String name, String prefix)
			throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public Object addToEnvironment(String propName, Object propVal)
			throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public Object removeFromEnvironment(String propName) throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/**
	 * <p>getEnvironment.</p>
	 *
	 * @see javax.naming.Context#getEnvironment()
	 * @return a {@link java.util.Hashtable} object.
	 * @throws javax.naming.NamingException if any.
	 */
	@SuppressWarnings("unchecked")
	public Hashtable getEnvironment() throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/**
	 * <p>close.</p>
	 *
	 * @see javax.naming.Context#close()
	 * @throws javax.naming.NamingException if any.
	 */
	public void close() throws NamingException {
		throw new UnsupportedOperationException("Not implemented.");
	}

	/** {@inheritDoc} */
	public boolean equals(Object obj) {
		// A subclass with identical values should NOT be considered equal.
		// EqualsBuilder in commons-lang cannot handle subclasses correctly.
		if (obj == null || obj.getClass() != this.getClass()) {
			return false;
		}
		return EqualsBuilder.reflectionEquals(this, obj);
	}

	/**
	 * <p>hashCode.</p>
	 *
	 * @see Object#hashCode()
	 * @return a int.
	 */
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	/**
	 * Collect all the values of a the specified attribute from the supplied
	 * Attributes.
	 *
	 * @param attributes The Attributes; not <code>null</code>.
	 * @param name The name of the Attribute to get values for.
	 * @param collection the collection to collect the values in.
	 * @since 1.3
	 * @throws javax.naming.directory.NoSuchAttributeException if any.
	 */
	public static void collectAttributeValues(Attributes attributes, String name, Collection collection) throws NoSuchAttributeException {

		Attribute attribute = attributes.get(name);
		if (attribute == null) {
			throw new NoSuchAttributeException("No attribute with name '" + name + "'");
		}

		iterateAttributeValues(attribute, new CollectingAttributeValueCallbackHandler(collection));
	}

	/**
	 * Iterate through all the values of the specified Attribute calling back to
	 * the specified callbackHandler.
	 *
	 * @param attribute the Attribute to work with; not <code>null</code>.
	 * @param callbackHandler the callbackHandler; not <code>null</code>.
	 * @since 1.3
	 */
	public static void iterateAttributeValues(Attribute attribute, CollectingAttributeValueCallbackHandler callbackHandler) {

		for (int i = 0; i < attribute.size(); i++) {
			try {
				callbackHandler.handleAttributeValue(attribute.getID(), attribute.get(i), i);
			}
			catch (NamingException e) {
			}
		}
	}

	/**
	 * An {@link AttributeValueCallbackHandler} to collect values in a supplied
	 * collection.
	 * 
	 * @author Mattias Hellborg Arthursson
	 */
	private final static class CollectingAttributeValueCallbackHandler {
		
		private final Collection collection;

		public CollectingAttributeValueCallbackHandler(Collection collection) {
			this.collection = collection;
		}

		@SuppressWarnings("unchecked")
		public final void handleAttributeValue(String attributeName, Object attributeValue, int index) {
			collection.add(attributeValue);
		}
	}	
	
}
