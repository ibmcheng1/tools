package com.bcbssc.registration.dto;

/**
 * <p>BcbsPersonDTO class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class BcbsPersonDTO extends UserDTO {

	/**
	 * @author X94S
	 */

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * county name
	 */
	public String country = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * common name
	 */
	public String commonName = com.bcbssc.struts.common.Constants.BLANK_STRING;
	/**
	 * date of acceptance
	 */
	public String dateOfAcceptance = com.bcbssc.struts.common.Constants.BLANK_STRING;
	/**
	 * date of birth
	 */
	public String dateOfBirth = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * enabled flag used for purge process
	 */
	public String enabled = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * fax number
	 */
	public String fax = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * gender
	 */
	public String gender = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * generation qualifier Mr. etc
	 */
	public String generationQualifier = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * given name
	 */
	public String givenName = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * city
	 */
	public String city = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * home phone number
	 */
	public String homePhone = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * last access time of the application
	 */
	public String lastAccess = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * email address
	 */
	public String mail = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * middle initial
	 */
	public String middleIni = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * mobile phone number
	 */
	public String mobile = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * address line2
	 */
	public String addressLine2 = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * zip code
	 */
	public String postalCode = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * preferred delivery method
	 */
	public String preferredDeliveryMethod = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * last name
	 */
	public String lastName = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * state
	 */
	public String state = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * street
	 */
	public String street = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * telephone extension
	 */
	public String telephoneExt = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * telephone number
	 */
	public String telephoneNumber = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * telephone number type
	 */
	public String telephoneNumberType = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * when changed
	 */
	public String whenChanged = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * when created
	 */
	public String whenCreated = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * fax entension
	 */
	public String faxExtension = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * suffix
	 */
	public String suffix = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * <p>Getter for the field <code>suffix</code>.</p>
	 *
	 * @return the suffix
	 */
	public String getSuffix() {
		return suffix;
	}

	/**
	 * <p>Setter for the field <code>suffix</code>.</p>
	 *
	 * @param suffix
	 *            the suffix to set
	 */
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	/**
	 * Holds value of property superUserType.
	 */
	public String superUserType = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * <p>Getter for the field <code>superUserType</code>.</p>
	 *
	 * @return the superUserType
	 */
	public String getSuperUserType() {
		return superUserType;
	}

	/** {@inheritDoc} */
	public void setSuperUserType(String superUserType) {
		this.superUserType = superUserType;
	}

	/**
	 * <p>Getter for the field <code>country</code>.</p>
	 *
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * <p>Setter for the field <code>country</code>.</p>
	 *
	 * @param country
	 *            the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * <p>Getter for the field <code>commonName</code>.</p>
	 *
	 * @return the commonName
	 */
	public String getCommonName() {
		return commonName;
	}

	/**
	 * <p>Setter for the field <code>commonName</code>.</p>
	 *
	 * @param commonName
	 *            the commonName to set
	 */
	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}

	/**
	 * <p>Getter for the field <code>dateOfBirth</code>.</p>
	 *
	 * @return the dateOfBirth
	 */
	public String getDateOfBirth() {
		return dateOfBirth;
	}

	/**
	 * <p>Setter for the field <code>dateOfBirth</code>.</p>
	 *
	 * @param dateOfBirth
	 *            the dateOfBirth to set
	 */
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	/**
	 * <p>Getter for the field <code>dateOfAcceptance</code>.</p>
	 *
	 * @return the dateOfAcceptance
	 */
	public String getDateOfAcceptance() {
		return dateOfAcceptance;
	}

	/**
	 * <p>Setter for the field <code>dateOfAcceptance</code>.</p>
	 *
	 * @param dateOfAcceptance
	 *            the dateOfAcceptance to set
	 */
	public void setDateOfAcceptance(String dateOfAcceptance) {
		this.dateOfAcceptance = dateOfAcceptance;
	}

	/**
	 * <p>Getter for the field <code>middleIni</code>.</p>
	 *
	 * @return the middleIni
	 */
	public String getMiddleIni() {
		return middleIni;
	}

	/**
	 * <p>Setter for the field <code>middleIni</code>.</p>
	 *
	 * @param middleIni
	 *            the middleIni to set
	 */
	public void setMiddleIni(String middleIni) {
		this.middleIni = middleIni;
	}

	/**
	 * <p>Getter for the field <code>addressLine2</code>.</p>
	 *
	 * @return the addressLine2
	 */
	public String getAddressLine2() {
		return addressLine2;
	}

	/**
	 * <p>Setter for the field <code>addressLine2</code>.</p>
	 *
	 * @param addressLine2
	 *            the addressLine2 to set
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	/**
	 * <p>Getter for the field <code>telephoneExt</code>.</p>
	 *
	 * @return the telephoneExt
	 */
	public String getTelephoneExt() {
		return telephoneExt;
	}

	/**
	 * <p>Setter for the field <code>telephoneExt</code>.</p>
	 *
	 * @param telephoneExt
	 *            the telephoneExt to set
	 */
	public void setTelephoneExt(String telephoneExt) {
		this.telephoneExt = telephoneExt;
	}

	/**
	 * <p>Getter for the field <code>enabled</code>.</p>
	 *
	 * @return the enabled
	 */
	public String getEnabled() {
		return enabled;
	}

	/**
	 * <p>Setter for the field <code>enabled</code>.</p>
	 *
	 * @param enabled
	 *            the enabled to set
	 */
	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}

	/**
	 * <p>Getter for the field <code>fax</code>.</p>
	 *
	 * @return the fax
	 */
	public String getFax() {
		return fax;
	}

	/**
	 * <p>Setter for the field <code>fax</code>.</p>
	 *
	 * @param fax
	 *            the fax to set
	 */
	public void setFax(String fax) {
		this.fax = fax;
	}

	/**
	 * <p>Getter for the field <code>gender</code>.</p>
	 *
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * <p>Setter for the field <code>gender</code>.</p>
	 *
	 * @param gender
	 *            the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * <p>Getter for the field <code>generationQualifier</code>.</p>
	 *
	 * @return the generationQualifier
	 */
	public String getGenerationQualifier() {
		return generationQualifier;
	}

	/**
	 * <p>Setter for the field <code>generationQualifier</code>.</p>
	 *
	 * @param generationQualifier
	 *            the generationQualifier to set
	 */
	public void setGenerationQualifier(String generationQualifier) {
		this.generationQualifier = generationQualifier;
	}

	/**
	 * <p>Getter for the field <code>givenName</code>.</p>
	 *
	 * @return the givenName
	 */
	public String getGivenName() {
		return givenName;
	}

	/**
	 * <p>Setter for the field <code>givenName</code>.</p>
	 *
	 * @param givenName
	 *            the givenName to set
	 */
	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	/**
	 * <p>Getter for the field <code>city</code>.</p>
	 *
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * <p>Setter for the field <code>city</code>.</p>
	 *
	 * @param city
	 *            the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * <p>Getter for the field <code>homePhone</code>.</p>
	 *
	 * @return the homePhone
	 */
	public String getHomePhone() {
		return homePhone;
	}

	/**
	 * <p>Setter for the field <code>homePhone</code>.</p>
	 *
	 * @param homePhone
	 *            the homePhone to set
	 */
	public void setHomePhone(String homePhone) {
		this.homePhone = homePhone;
	}

	/**
	 * <p>Getter for the field <code>lastAccess</code>.</p>
	 *
	 * @return the lastAccess
	 */
	public String getLastAccess() {
		return lastAccess;
	}

	/**
	 * <p>Setter for the field <code>lastAccess</code>.</p>
	 *
	 * @param lastAccess
	 *            the lastAccess to set
	 */
	public void setLastAccess(String lastAccess) {
		this.lastAccess = lastAccess;
	}

	/**
	 * <p>Getter for the field <code>mail</code>.</p>
	 *
	 * @return the mail
	 */
	public String getMail() {
		return mail;
	}

	/**
	 * <p>Setter for the field <code>mail</code>.</p>
	 *
	 * @param mail
	 *            the mail to set
	 */
	public void setMail(String mail) {
		this.mail = mail;
	}

	/**
	 * <p>Getter for the field <code>mobile</code>.</p>
	 *
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * <p>Setter for the field <code>mobile</code>.</p>
	 *
	 * @param mobile
	 *            the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 * <p>Getter for the field <code>postalCode</code>.</p>
	 *
	 * @return the postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * <p>Setter for the field <code>postalCode</code>.</p>
	 *
	 * @param postalCode
	 *            the postalCode to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * <p>Getter for the field <code>preferredDeliveryMethod</code>.</p>
	 *
	 * @return the preferredDeliveryMethod
	 */
	public String getPreferredDeliveryMethod() {
		return preferredDeliveryMethod;
	}

	/**
	 * <p>Setter for the field <code>preferredDeliveryMethod</code>.</p>
	 *
	 * @param preferredDeliveryMethod
	 *            the preferredDeliveryMethod to set
	 */
	public void setPreferredDeliveryMethod(String preferredDeliveryMethod) {
		this.preferredDeliveryMethod = preferredDeliveryMethod;
	}

	/**
	 * <p>Getter for the field <code>lastName</code>.</p>
	 *
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * <p>Setter for the field <code>lastName</code>.</p>
	 *
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * <p>Getter for the field <code>state</code>.</p>
	 *
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * <p>Setter for the field <code>state</code>.</p>
	 *
	 * @param state
	 *            the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * <p>Getter for the field <code>street</code>.</p>
	 *
	 * @return the street
	 */
	public String getStreet() {
		return street;
	}

	/**
	 * <p>Setter for the field <code>street</code>.</p>
	 *
	 * @param street
	 *            the street to set
	 */
	public void setStreet(String street) {
		this.street = street;
	}

	/**
	 * <p>Getter for the field <code>telephoneNumber</code>.</p>
	 *
	 * @return the telephoneNumber
	 */
	public String getTelephoneNumber() {
		return telephoneNumber;
	}

	/**
	 * <p>Setter for the field <code>telephoneNumber</code>.</p>
	 *
	 * @param telephoneNumber
	 *            the telephoneNumber to set
	 */
	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	/**
	 * <p>Getter for the field <code>telephoneNumberType</code>.</p>
	 *
	 * @return the telephoneNumberType
	 */
	public String getTelephoneNumberType() {
		return telephoneNumberType;
	}

	/**
	 * <p>Setter for the field <code>telephoneNumberType</code>.</p>
	 *
	 * @param telephoneNumberType
	 *            the telephoneNumberType to set
	 */
	public void setTelephoneNumberType(String telephoneNumberType) {
		this.telephoneNumberType = telephoneNumberType;
	}

	/**
	 * <p>Getter for the field <code>whenChanged</code>.</p>
	 *
	 * @return the whenChanged
	 */
	public String getWhenChanged() {
		return whenChanged;
	}

	/**
	 * <p>Setter for the field <code>whenChanged</code>.</p>
	 *
	 * @param whenChanged
	 *            the whenChanged to set
	 */
	public void setWhenChanged(String whenChanged) {
		this.whenChanged = whenChanged;
	}

	/**
	 * <p>Getter for the field <code>whenCreated</code>.</p>
	 *
	 * @return the whenCreated
	 */
	public String getWhenCreated() {
		return whenCreated;
	}

	/**
	 * <p>Setter for the field <code>whenCreated</code>.</p>
	 *
	 * @param whenCreated
	 *            the whenCreated to set
	 */
	public void setWhenCreated(String whenCreated) {
		this.whenCreated = whenCreated;
	}

	/**
	 * <p>Getter for the field <code>faxExtension</code>.</p>
	 *
	 * @return the faxExtension
	 */
	public String getFaxExtension() {
		return faxExtension;
	}

	/**
	 * <p>Setter for the field <code>faxExtension</code>.</p>
	 *
	 * @param faxExtension
	 *            the faxExtension to set
	 */
	public void setFaxExtension(String faxExtension) {
		this.faxExtension = faxExtension;
	}

}
