/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2009 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : SecureLdapContextSource.java
 *
 * Created Date     : Oct 23, 2008
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Oct 23, 2008    Initial version for bcbssc-ldap
 */

package com.bcbssc.commercial.registration.core.impl;

import javax.naming.NamingException;
import javax.naming.directory.DirContext;

/**
 * <p>SecureLdapContextSource class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class SecureLdapContextSource extends LdapContextSource {
    
    private static final String KEYSTORE 			= "javax.net.ssl.keyStore";

    private static final String KEYSTORETYPE 		= "javax.net.ssl.keyStoreType";

    private static final String KEYSTOREPASSWORD 	= "javax.net.ssl.keyStorePassword";

    private static final String TRUSTSTORE 			= "javax.net.ssl.trustStore";

    private static final String TRUSTSTORETYPE 		= "javax.net.ssl.trustStoreType";

    private static final String TRUSTSTOREPASSWORD 	= "javax.net.ssl.trustStorePassword";
  	
    private String keyStore;

    private String keyStoreType;

    private String keyStorePassword;

    private String trustStore;

    private String trustStoreType;

    private String trustStorePassword;

	/**
	 * <p>Getter for the field <code>keyStore</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getKeyStore() {
		return keyStore;
	}

	/**
	 * <p>Setter for the field <code>keyStore</code>.</p>
	 *
	 * @param keyStore a {@link java.lang.String} object.
	 */
	public void setKeyStore(String keyStore) {
		this.keyStore = keyStore;
	}

	/**
	 * <p>Getter for the field <code>keyStorePassword</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getKeyStorePassword() {
		return keyStorePassword;
	}

	/**
	 * <p>Setter for the field <code>keyStorePassword</code>.</p>
	 *
	 * @param keyStorePassword a {@link java.lang.String} object.
	 */
	public void setKeyStorePassword(String keyStorePassword) {
		this.keyStorePassword = keyStorePassword;
	}

	/**
	 * <p>Getter for the field <code>keyStoreType</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getKeyStoreType() {
		return keyStoreType;
	}

	/**
	 * <p>Setter for the field <code>keyStoreType</code>.</p>
	 *
	 * @param keyStoreType a {@link java.lang.String} object.
	 */
	public void setKeyStoreType(String keyStoreType) {
		this.keyStoreType = keyStoreType;
	}

	/**
	 * <p>Getter for the field <code>trustStore</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getTrustStore() {
		return trustStore;
	}

	/**
	 * <p>Setter for the field <code>trustStore</code>.</p>
	 *
	 * @param trustStore a {@link java.lang.String} object.
	 */
	public void setTrustStore(String trustStore) {
		this.trustStore = trustStore;
	}

	/**
	 * <p>Getter for the field <code>trustStorePassword</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getTrustStorePassword() {
		return trustStorePassword;
	}

	/**
	 * <p>Setter for the field <code>trustStorePassword</code>.</p>
	 *
	 * @param trustStorePassword a {@link java.lang.String} object.
	 */
	public void setTrustStorePassword(String trustStorePassword) {
		this.trustStorePassword = trustStorePassword;
	}

	/**
	 * <p>Getter for the field <code>trustStoreType</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getTrustStoreType() {
		return trustStoreType;
	}

	/**
	 * <p>Setter for the field <code>trustStoreType</code>.</p>
	 *
	 * @param trustStoreType a {@link java.lang.String} object.
	 */
	public void setTrustStoreType(String trustStoreType) {
		this.trustStoreType = trustStoreType;
	}
	
	/**
	 * <p>getContext.</p>
	 *
	 * @return a {@link javax.naming.directory.DirContext} object.
	 * @throws javax.naming.NamingException if any.
	 */
	public DirContext getContext() throws NamingException {

        // Setup keyStore system properties.
        System.setProperty(KEYSTORE, this.keyStore);
        System.setProperty(KEYSTOREPASSWORD, this.keyStorePassword);
        System.setProperty(KEYSTORETYPE, this.keyStoreType);

        // Setup trustStore system properties.
        System.setProperty(TRUSTSTORE, this.trustStore);
        System.setProperty(TRUSTSTOREPASSWORD, this.trustStorePassword);
        System.setProperty(TRUSTSTORETYPE, this.trustStoreType);		

        return super.getContext();
	}
}
