/*
 * @(#)CustomValidator.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.registration.validator;

import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.validator.Field;
import org.apache.commons.validator.GenericValidator;
import org.apache.commons.validator.ValidatorAction;
import org.apache.commons.validator.util.ValidatorUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.validator.Resources;

import com.bcbssc.struts.common.CommonUtils;

/**
 * Shared Registration Custom Validator
 *
 * This class provides extensions to the struts Validator package for specialized
 * shared registration validations.  It currently supports the following
 * validations:
 *
 *      validateAlphanumeric
 *          description: verifies all characters are alphanumeric
 *          required validator.rules.xml entry:
 *              &lt;validator name="alphanumeric"
 *                  classname="com.bcbssc.sharedreg.validator.CustomValidator"
 *                  method="validateAlphanumeric"
 *                  methodParams="java.lang.Object,
 *                      org.apache.commons.validator.ValidatorAction,
 *                      org.apache.commons.validator.Field,
 *                      org.apache.struts.action.ActionErrors,
 *                      javax.servlet.http.HttpServletRequest"
 *                  msg="errors.alphanumeric"&gt;
 *              &lt;/validator&gt;
 *          example validator.xml rule:
 *              &lt;field property="accessCode" depends="required, alphanumeric"/&gt;
 *
 *      validateLengthRange
 *          description: provides combined min/max length checking
 *          required validator.rules.xml entry:
 *              &lt;validator name="lengthrange"
 *                  classname="com.bcbssc.registration.validator.CustomValidator"
 *                  method="validateLengthRange"
 *                  methodParams="java.lang.Object,
 *                      org.apache.commons.validator.ValidatorAction,
 *                      org.apache.commons.validator.Field,
 *                      org.apache.struts.action.ActionErrors,
 *                      javax.servlet.http.HttpServletRequest"
 *                  msg="errors.lengthrange"&gt;
 *              &lt;/validator&gt;
 *          example validator.xml rule:
 *              &lt;field property="unicodePwd" depends="required,lengthrange"&gt;
 *                  &lt;arg0 key="characters" resource="false"/&gt;
 *                  &lt;arg1 key="${var:minlength}" resource="false"/&gt;
 *                  &lt;arg2 key="${var:maxlength}" resource="false"/&gt;
 *                  &lt;var&gt;
 *                      &lt;var-name&gt;minlength&lt;/var-name&gt;
 *                      &lt;var-value&gt;6&lt;/var-value&gt;
 *                  &lt;/var&gt;
 *                  &lt;var&gt;
 *                      &lt;var-name&gt;maxlength&lt;/var-name&gt;
 *                      &lt;var-value&gt;11&lt;/var-value&gt;
 *                  &lt;/var&gt;
 *              &lt;/field&gt;
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class CustomValidator implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -7678186420627200015L;
	/** log4j logger */
	private static Logger logger = Logger.getLogger(CustomValidator.class);

    private CustomValidator() {
		super();
		if(CustomValidator.logger.isDebugEnabled()) {
			CustomValidator.logger.debug("Created CustomValidator object.");
		}
	}

    /**
     * Checks if the field is alphanumeric.
     *
     * @param bean  The bean validation is being performed on.
     * @param va  The ValidatorAction that is currently being performed.
     * @param field  The Field object associated with the current field being validated
     * @param errors  The ActionMessages object to add errors to if any validation errors occur
     * @param request  Current request object
     * @return true if valid, false otherwise
     */
    public static boolean validateAlphanumeric(Object bean, ValidatorAction va,
                                               Field field, ActionErrors errors,
                                               HttpServletRequest request) {

        String value = ValidatorUtils.getValueAsString(bean, field.getProperty());

        // If value is blank, count on one of the required validators to generate
        // the error
        if (GenericValidator.isBlankOrNull(value)) {
            return true;
        }
        
		if (!CommonUtils.isAlphaNumeric(value)) {
			errors.add(field.getKey(), Resources.getActionMessage(request, va, field));
		}

		return errors.isEmpty();
    }

    /**
     * Checks if the field is within a range.
     *
     * @param bean  The bean validation is being performed on.
     * @param va  The ValidatorAction that is currently being performed.
     * @param field  The Field object associated with the current field being validated
     * @param errors  The ActionMessages object to add errors to if any validation errors occur
     * @param request  Current request object
     * @return true if valid, false otherwise
     */
    public static boolean validateLengthRange (Object bean, ValidatorAction va,
                                               Field field, ActionErrors errors,
                                               HttpServletRequest request) {

        String value = ValidatorUtils.getValueAsString(bean, field.getProperty());
        int min = Integer.parseInt(field.getVarValue("minlength"));
        int max = Integer.parseInt(field.getVarValue("maxlength"));

        // If value is blank, count on one of the required validators to generate
        // the error
        if (GenericValidator.isBlankOrNull(value)) {
            return true;
        }
        
		if (value.length() < min || value.length() > max) {
			errors.add(field.getKey(), Resources.getActionMessage(request, va, field));
		}

		return errors.isEmpty();
    }
}
