/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2009 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : AccountDAO.java
 *
 * Created Date     : Oct 23, 2008
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Oct 23, 2008    Initial version for bcbssc-ldap
 */

package com.bcbssc.commercial.registration.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.naming.AuthenticationException;

import com.bcbssc.commercial.registration.NoSuchAccountException;
import com.bcbssc.commercial.registration.ServerFailureException;
import com.bcbssc.commercial.registration.model.Account;

/**
 * <p>AccountDAO interface.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public interface AccountDAO {

	/**
	 * <p>authenticateAccount.</p>
	 *
	 * @param username a {@link java.lang.String} object.
	 * @param password a {@link java.lang.String} object.
	 * @return a boolean.
	 * @throws javax.naming.AuthenticationException if any.
	 * @throws com.bcbssc.commercial.registration.ServerFailureException if any.
	 */
	public boolean authenticateAccount(String username, String password) throws AuthenticationException, ServerFailureException;
	
	/**
	 * <p>accountExists.</p>
	 *
	 * @param username a {@link java.lang.String} object.
	 * @return a boolean.
	 * @throws com.bcbssc.commercial.registration.ServerFailureException if any.
	 */
	public boolean accountExists(String username) throws ServerFailureException;
	
	/**
	 * <p>createAccount.</p>
	 *
	 * @param account a {@link com.bcbssc.commercial.registration.model.Account} object.
	 * @throws com.bcbssc.commercial.registration.ServerFailureException if any.
	 */
	public void createAccount(Account account) throws ServerFailureException;
	
	/**
	 * <p>deleteAccount.</p>
	 *
	 * @param userName a {@link java.lang.String} object.
	 * @throws com.bcbssc.commercial.registration.ServerFailureException if any.
	 */
	public void deleteAccount(String userName) throws ServerFailureException;
	
	/**
	 * <p>modifyAccount.</p>
	 *
	 * @param account a {@link com.bcbssc.commercial.registration.model.Account} object.
	 * @throws com.bcbssc.commercial.registration.ServerFailureException if any.
	 */
	public void modifyAccount(Account account) throws ServerFailureException;

	/**
	 * <p>getAccount.</p>
	 *
	 * @param username a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.commercial.registration.model.Account} object.
	 * @throws com.bcbssc.commercial.registration.NoSuchAccountException if any.
	 * @throws com.bcbssc.commercial.registration.ServerFailureException if any.
	 */
	public Account getAccount(String username) throws NoSuchAccountException, ServerFailureException;
	
	/**
	 * <p>getAccount.</p>
	 *
	 * @param username a {@link java.lang.String} object.
	 * @param accountAttributes an array of {@link java.lang.String} objects.
	 * @return a {@link com.bcbssc.commercial.registration.model.Account} object.
	 * @throws com.bcbssc.commercial.registration.NoSuchAccountException if any.
	 * @throws com.bcbssc.commercial.registration.ServerFailureException if any.
	 */
	public Account getAccount(String username, String[] accountAttributes) throws NoSuchAccountException, ServerFailureException;
	
	/**
	 * <p>getAccounts.</p>
	 *
	 * @param criteria a {@link java.lang.String} object.
	 * @return a {@link java.util.ArrayList} object.
	 * @throws com.bcbssc.commercial.registration.NoSuchAccountException if any.
	 * @throws com.bcbssc.commercial.registration.ServerFailureException if any.
	 */
	public ArrayList<Account> getAccounts(String criteria) throws NoSuchAccountException, ServerFailureException;
	
	/**
	 * <p>getAccountAttribute.</p>
	 *
	 * @param username a {@link java.lang.String} object.
	 * @param attributeName a {@link java.lang.String} object.
	 * @return a {@link java.lang.String} object.
	 * @throws com.bcbssc.commercial.registration.NoSuchAccountException if any.
	 * @throws com.bcbssc.commercial.registration.ServerFailureException if any.
	 */
	public String getAccountAttribute(String username, String attributeName) throws NoSuchAccountException, ServerFailureException;
	
	/**
	 * <p>getAccountAttributes.</p>
	 *
	 * @param username a {@link java.lang.String} object.
	 * @param accountAttributes an array of {@link java.lang.String} objects.
	 * @return a {@link java.util.HashMap} object.
	 * @throws com.bcbssc.commercial.registration.NoSuchAccountException if any.
	 * @throws com.bcbssc.commercial.registration.ServerFailureException if any.
	 */
	public HashMap<String, Object> getAccountAttributes(String username, String[] accountAttributes) throws NoSuchAccountException, ServerFailureException;

	/**
	 * <p>setAccountAttribute.</p>
	 *
	 * @param username a {@link java.lang.String} object.
	 * @param attributeName a {@link java.lang.String} object.
	 * @param attributeValue a {@link java.lang.Object} object.
	 * @throws com.bcbssc.commercial.registration.NoSuchAccountException if any.
	 * @throws com.bcbssc.commercial.registration.ServerFailureException if any.
	 */
	public void setAccountAttribute(String username, String attributeName, Object attributeValue) throws NoSuchAccountException, ServerFailureException;
	
	/**
	 * <p>setAccountAttributes.</p>
	 *
	 * @param username a {@link java.lang.String} object.
	 * @param attributes a {@link java.util.HashMap} object.
	 * @throws com.bcbssc.commercial.registration.NoSuchAccountException if any.
	 * @throws com.bcbssc.commercial.registration.ServerFailureException if any.
	 */
	public void setAccountAttributes(String username, HashMap<String, Object> attributes) throws NoSuchAccountException, ServerFailureException;
	
	/**
	 * <p>updateAccount.</p>
	 *
	 * @param account a {@link com.bcbssc.commercial.registration.model.Account} object.
	 * @throws com.bcbssc.commercial.registration.NoSuchAccountException if any.
	 * @throws com.bcbssc.commercial.registration.ServerFailureException if any.
	 */
	public void updateAccount(Account account) throws NoSuchAccountException, ServerFailureException;
	
	/**
	 * <p>getAccountRoles.</p>
	 *
	 * @param username a {@link java.lang.String} object.
	 * @return a {@link java.util.List} object.
	 * @throws com.bcbssc.commercial.registration.NoSuchAccountException if any.
	 * @throws com.bcbssc.commercial.registration.ServerFailureException if any.
	 */
	public List<String> getAccountRoles(String username) throws NoSuchAccountException, ServerFailureException;
}
