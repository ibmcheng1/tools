/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUE CROSS AND BLUE SHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION, OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright (c) 2005 Blue Cross and Blue Shield of South Carolina.
 * All rights reserved.
 * An independent Licensee of the Blue Cross and Blue Shield Association.
 *
 * BcbsScCipherException.java
 * $Header:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-singlesignon/src/main/java/com/bcbssc/crypt/BcbsScCipherException.java_v   1.0   Jun 26 2009 15:54:14   EN80  $
 * Last Modified: $Modtime:   May 14 2009 11:33:52  $
 *
 * History
 * ---------------------------
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-singlesignon/src/main/java/com/bcbssc/crypt/BcbsScCipherException.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:54:14   EN80
 * Initial revision.
 * 
 *    Rev 1.5   Apr 28 2009 09:38:34   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.4   Mar 19 2009 12:35:06   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.3   Oct 18 2006 10:02:12   rdq70
 * Include stack trace of cause in stack trace.
 *
 *    Rev 1.2   Oct 18 2006 09:46:40   rdq70
 * Removed extraneous debug log. Allow the caller to determine when to log and at what level.
 *
 *    Rev 1.1   Aug 16 2005 19:06:06   rx22a
 * BlueHammur required changes
 */
package com.bcbssc.registration.crypt;

import java.io.PrintStream;

import org.apache.log4j.Logger;

/**
 * Encapsulates encryption exceptions
 *
 * @author Brad D. Smith (X22A)
 * @version $Revision:   1.0  $
 */
public class BcbsScCipherException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6037863797124249839L;

	/**
	 * The Log4J <code>Logger</code> named
	 * <code>SingleSignOn.src.com.bcbssc.crypt.BcbsScCipherException</code>
	 */
	private static final Logger log = Logger
			.getLogger(BcbsScCipherException.class);

	/**
	 * The underlying cause of this exception.
	 */
	private Throwable cause = null;

	/**
	 * Construct a new exception with <code>null</code> as its detail message.
	 */
	public BcbsScCipherException() {
		super();
		if (BcbsScCipherException.log.isDebugEnabled()) {
			BcbsScCipherException.log
					.debug("Created BcbsScCipherException object.");
		}
	}

	/**
	 * Construct a new exception with the specified detail message.
	 *
	 * @param message
	 *            The detail message
	 */
	public BcbsScCipherException(String message) {
		super(message);
		if (BcbsScCipherException.log.isDebugEnabled()) {
			BcbsScCipherException.log
					.debug("Created BcbsScCipherException object.");
		}
	}

	/**
	 * Construct a new exception with the specified cause and a derived detail
	 * message.
	 *
	 * @param cause
	 *            The underlying cause
	 */
	public BcbsScCipherException(Throwable cause) {
		super();
		this.cause = cause;
		if (BcbsScCipherException.log.isDebugEnabled()) {
			BcbsScCipherException.log
					.debug("Created BcbsScCipherException object.");
		}
	}

	/**
	 * Construct a new exception with the specified detail message and cause.
	 *
	 * @param message
	 *            The detail message
	 * @param cause
	 *            The underlying cause
	 */
	public BcbsScCipherException(String message, Throwable cause) {
		super(message);
		this.cause = cause;
		if (BcbsScCipherException.log.isDebugEnabled()) {
			BcbsScCipherException.log
					.debug("Created BcbsScCipherException object.");
		}
	}

	/**
	 * Return the underlying cause of this exception (if any).
	 *
	 * @return Throwable the underlying cause of this exception
	 */
	public Throwable getCause() {
		return (this.cause);
	}

	/**
	 * Prints this exception and its backtrace to <code>System.err</code>.
	 */
	public void printStackTrace() {
		this.printStackTrace(System.err);
	}

	/**
	 * Prints this exception and its backtrace to the specified print stream.
	 *
	 * @param s a {@link java.io.PrintStream} object.
	 */
	public void printStackTrace(PrintStream s) {
		super.printStackTrace(s);
		s.println("Root cause:");
		this.cause.printStackTrace(s);
	}
}
