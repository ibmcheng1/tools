/*
 * @(#)SimplePermissionsAdapter.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.registration.permissions;

import com.bcbssc.registration.dto.UserDTO;
import com.bcbssc.struts.common.CommonUtils;

import java.util.ArrayList;

import net.sf.navigator.menu.MenuComponent;
import net.sf.navigator.menu.PermissionsAdapter;

import org.apache.log4j.Logger;

/**
 * Shared Registration Role Permissions Adapter
 *
 * This class implements PermissionsAdapter, providing menu permissions. It
 * determines permissions based on the user role. If any of the roles specified
 * for a menu item is a subset of any of the user's roles, that menu item will
 * be allowed.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class RolePermissionsAdapter implements PermissionsAdapter {

	/** log4j logger */
	private static Logger logger = Logger
			.getLogger(RolePermissionsAdapter.class);

	/** roles of the user */
	private String userRoles = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** super user type, if any, of the user */
	private String superUserType = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * <p>Constructor for RolePermissionsAdapter.</p>
	 *
	 * @param user a {@link com.bcbssc.registration.dto.UserDTO} object.
	 */
	public RolePermissionsAdapter(UserDTO user) {
		this.userRoles = user.getRoles();
		this.superUserType = user.getSuperUserType();
	}

	/**
	 * <p>Constructor for RolePermissionsAdapter.</p>
	 *
	 * @param roles a {@link java.lang.String} object.
	 * @param superType a {@link java.lang.String} object.
	 */
	public RolePermissionsAdapter(String roles, String superType) {
		this.userRoles = roles;
		this.superUserType = superType;
	}

	private static final char ROLE_NOT_CHAR = '!';

	/**
	 * {@inheritDoc}
	 *
	 * If the menu is allowed, this should return true.
	 */
	public boolean isAllowed(MenuComponent menu) {
		ArrayList menuItemRoles = CommonUtils
				.splitString(menu.getRoles(), ",");

		if (RolePermissionsAdapter.logger.isDebugEnabled()) {
			RolePermissionsAdapter.logger
					.debug("Executing RolePermissionsAdapter.isAllowed()");
		}

		boolean allowed = false;

		if (menuItemRoles.size() == 0) {
			allowed = true;
		} else {
			for (int j = 0; j < menuItemRoles.size(); j++) {
				String role = (String) menuItemRoles.get(j);

				// If menu !role is a subset of user role or superuser type,
				// do not allow, even if already allowed
				if (role.indexOf(RolePermissionsAdapter.ROLE_NOT_CHAR) == 0) {
					role = role.substring(1);
					if ((this.userRoles.indexOf(role) != -1)
							|| (this.superUserType.indexOf(role) != -1)) {
						allowed = false;
						break;
					}
				} else if ((this.userRoles.indexOf(role) != -1)
						|| (this.superUserType.indexOf(role) != -1)) {
					// If menu role is a subset of user role or superuser
					// type, allow (may still be disallowed by a !role
					allowed = true;
				}
			}
		}
		return allowed;
	}
}
