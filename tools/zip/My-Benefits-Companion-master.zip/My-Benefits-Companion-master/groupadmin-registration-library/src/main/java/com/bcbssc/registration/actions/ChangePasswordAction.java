/*
 * @(#)ChangePasswordAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.registration.actions;

import com.bcbssc.registration.common.Constants;
import com.bcbssc.registration.dto.UserDTO;
import com.bcbssc.registration.services.ISecureServices;
import com.bcbssc.struts.action.BaseAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * Shared Registration Change Password Action
 *
 * This class provides control processing for the change password action It
 * should be extended by an application-specific class that creates a business
 * logic services object and converts the input data into an
 * application-specific form bean
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public abstract class ChangePasswordAction extends BaseAction {

	/** log4j logger */
	private static Logger logger = Logger.getLogger(ChangePasswordAction.class);

	/** modify profile action type: display populated form name */
	private static final String POPULATE = "populate";

	/**
	 * Processes the specified HTTP request, and create sthe corresponding HTTP
	 * response.
	 *
	 * @param service
	 *            an application-specific service class providing needed
	 *            business logic
	 * @param formDTO
	 *            an application-specific data transfer object to be used by the
	 *            services
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @param buttonValue a {@link java.lang.String} object.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward execute(ISecureServices service, Object formDTO,
			String buttonValue, ActionMapping mapping,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		if (ChangePasswordAction.logger.isDebugEnabled()) {
			ChangePasswordAction.logger
					.debug("Executing ChangePasswordAction.execute()");
		}

		String actiontype = mapping.getParameter();
		String forward;

		UserDTO user = (UserDTO) request.getAttribute("user");

		if (actiontype.equals(ChangePasswordAction.POPULATE)) {
			service.populateForm(formDTO, user);
			request.setAttribute("changePasswordForm", formDTO);
			forward = Constants.FORWARD_SUCCESS;
		} else {

			if (buttonValue.equals(Constants.FORM_BUTTON_CANCEL)) {
				forward = Constants.FORWARD_CANCEL;
			} else if (service.changePassword(formDTO, user)) {
				// Change password and Modify profile use a common confirm page,
				// so return the formDTO using modifyProfileForm instead of
				// changePasswordForm.
				request.setAttribute("modifyProfileForm", formDTO);
				forward = Constants.FORWARD_SUCCESS;
			} else {
				forward = Constants.FORWARD_SECURITY_ERROR;
			}
		}

		return mapping.findForward(forward);
	}
}
