/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2009 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : NoSuchAccountException.java
 *
 * Created Date     : Oct 23, 2008
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Oct 23, 2008     Initial version for bcbssc-ldap
 */

package com.bcbssc.commercial.registration;

import com.bcbssc.netsys.LinkedException;

/**
 * <p>NoSuchAccountException class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class NoSuchAccountException extends LinkedException {

	private static final long serialVersionUID 			= 9027824678675442224L;	
	
    /**
     * Creates a new instance of NoSuchAccountException.
     */
    public NoSuchAccountException() {
        super();
    }

    /**
     * Creates a new instance of NoSuchAccountException with a descriptive message.
     *
     * @param message The exception message.
     */
    public NoSuchAccountException(String message) {
       super(message);
    }

    /**
     * Creates a new instance of NoSuchAccountException with a descriptive message
     * and a root cause.
     *
     * @param message The exception message.
     * @param rootCause The root cause of this exception.
     */
    public NoSuchAccountException(String message, Throwable rootCause) {
        super(message, rootCause);
    }

    /**
     * Creates a new instance of NoSuchAccountException with the given root cause.
     *
     * @param rootCause The root cause of this exception.
     */
    public NoSuchAccountException(Throwable rootCause) {
        super(rootCause);
    }
}
