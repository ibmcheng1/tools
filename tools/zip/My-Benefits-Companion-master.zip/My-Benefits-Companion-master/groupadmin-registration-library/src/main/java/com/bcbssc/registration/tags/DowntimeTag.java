/*
 * @(#)DowntimeTag.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.registration.tags;

import javax.servlet.ServletContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;
import org.apache.struts.Globals;
import org.apache.struts.taglib.TagUtils;

import com.bcbssc.netsys.Config;
import com.bcbssc.netsys.dsmart.DSmartManager;
import com.bcbssc.netsys.dsmart.DSmartWrapper;
import com.bcbssc.registration.common.Constants;
import com.opennetwork.DSUtils.DSmart;
import com.opennetwork.DSUtils.IDSValList;

/**
 * Shared Registration Downtime/Holiday Tag
 *
 * This class provides support for the downtime/holiday tag. Because the
 * downtime message is read from LDAP, this class must be extended by a class
 * providing a getIniFile method that returns an application-specific INI file
 * that contains the LDAP connection parameters. See the CgaDowntimeTag class
 * for an example.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public abstract class DowntimeTag extends TagSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1084564152563296781L;

	/** log4j logger */
	private static Logger log = Logger.getLogger(DowntimeTag.class);

	/** exception description */
	private static final String EXCEPTION_DOWNTIME = "Error getting downtime/holiday message";

	/** tag key value */
	protected String key = null;

	/**
	 * Returns the name of the application-specific INI file containing the LDAP
	 * connection parameters.
	 *
	 * @return name of the INI file
	 * @param context a {@link javax.servlet.ServletContext} object.
	 */
	protected abstract String getIniFile(ServletContext context);

	/**
	 * Generates the holiday/downtime message based on the contents of the
	 * property specified by the key.
	 *
	 * @return page body evaluation specifier
	 * @throws javax.servlet.jsp.JspException if any.
	 */
	public int doStartTag() throws JspException {

		String message;

		// Retrieve the message string we are looking for
		String messagetype = TagUtils.getInstance().message(this.pageContext,
				Globals.MESSAGES_KEY, Globals.LOCALE_KEY, this.key);
		if (messagetype == null) {
			StringBuffer error = new StringBuffer(64);
			error.append("<!-- could not get message; invalid key: ").append(
					this.key).append("-->");
			message = error.toString();

		} else {
			String inifile = this.getIniFile(this.pageContext
					.getServletContext());

			message = DowntimeTag.getMessage(messagetype, inifile);

			// Display commented out explanation if there is no message
			if ((message == null) || (message.length() == 0)) {
				StringBuffer error = new StringBuffer(64);
				error.append("<!-- no message or invalid messagetype: ")
						.append(messagetype).append("-->");
				message = error.toString();
			}
		}

		// Print the retrieved message to our output writer
		TagUtils.getInstance().write(this.pageContext, message);

		// Continue processing this page
		return Tag.SKIP_BODY;
	}

	/**
	 * Sets the key value
	 *
	 * @param value a {@link java.lang.String} object.
	 */
	public void setKey(String value) {
		this.key = value;
	}

	/**
	 * Gets the holiday/downtime message
	 *
	 * @param messageType
	 *            type of messsage ("holiday" or "downtime")
	 * @return holiday message or null if the message could not be read
	 * @param iniFile a {@link java.lang.String} object.
	 */
	public static String getMessage(String messageType, String iniFile) {
		DSmartWrapper wrapper = null;
		DSmart dsConnection = null;
		String returnString = null;
		String[] returnValue = null;
		try {
			DSmartManager.setConfigFile(iniFile);
			wrapper = DSmartManager.checkOutConnection();
			dsConnection = wrapper.getDSmart();
			String orgBase = Config.getPrivateProfileString(
					Constants.INI_LOCAL_SECTION,
					Constants.INI_ORGANIZATION_BASE,
					com.bcbssc.struts.common.Constants.BLANK_STRING, iniFile);
			String searchBase = orgBase;

			if (DowntimeTag.log.isDebugEnabled()) {
				StringBuffer logMsg = new StringBuffer(128);
				logMsg.append("searching for ").append(messageType).append(
						" message using a searchbase of ").append(searchBase);
				DowntimeTag.log.debug(logMsg.toString());
			}

			String filter = Constants.LDAP_FILTER_GET_ALL;
			String[] dnArray = dsConnection.listDirEntries(searchBase, filter,
					true);
			if (messageType.equalsIgnoreCase(Constants.DOWNTIME_TYPE)) {
				IDSValList values = dsConnection.readDirEntry(dnArray[0],
						new String[] { Constants.LDAP_DOWNTIME_ATTRIBUTE });
				if (values != null) {
					returnValue = values
							.getValueStringArray(Constants.LDAP_DOWNTIME_ATTRIBUTE);
				}
			} else if (messageType.equalsIgnoreCase(Constants.HOLIDAY_TYPE)) {
				IDSValList values = dsConnection.readDirEntry(dnArray[0],
						new String[] { Constants.LDAP_HOLIDAY_ATTRIBUTE });
				if (values != null) {
					returnValue = values
							.getValueStringArray(Constants.LDAP_HOLIDAY_ATTRIBUTE);
				}
			}
			if ((returnValue != null) && (returnValue.length > 0)) {
				returnString = returnValue[0];
			}

			return returnString;

		} catch (Exception e) {
			DowntimeTag.log.warn(DowntimeTag.EXCEPTION_DOWNTIME, e);

			// Not getting the downtime message is not the end of the world
			return null;
		} finally {
			try {
				DSmartManager.checkInConnection(wrapper);
			} catch (Exception e) {
				DowntimeTag.log.warn(Constants.EXCEPTION_DSMART_CHECKIN, e);
			}
		}
	}
}
