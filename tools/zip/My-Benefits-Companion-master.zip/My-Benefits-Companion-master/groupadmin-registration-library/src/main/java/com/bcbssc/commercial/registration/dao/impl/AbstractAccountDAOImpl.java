/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2009 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : DefaultAccountDAOImpl.java
 *
 * Created Date     : Oct 23, 2008
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Oct 23, 2008    Initial version for bcbssc-ldap
 */

package com.bcbssc.commercial.registration.dao.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.naming.AuthenticationException;
import javax.naming.Name;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.bcbssc.commercial.registration.NoSuchAccountException;
import com.bcbssc.commercial.registration.ServerFailureException;
import com.bcbssc.commercial.registration.core.ContextMapper;
import com.bcbssc.commercial.registration.core.DirContextOperations;
import com.bcbssc.commercial.registration.core.impl.AccountOperations;
import com.bcbssc.commercial.registration.core.impl.DirContextAdapter;
import com.bcbssc.commercial.registration.core.impl.LdapContextSource;
import com.bcbssc.commercial.registration.dao.AccountDAO;
import com.bcbssc.commercial.registration.model.Account;
import com.bcbssc.netsys.jndi.LdapUser;

/**
 * <p>Abstract AbstractAccountDAOImpl class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public abstract class AbstractAccountDAOImpl implements AccountDAO {

	private static final Logger log 						= Logger.getLogger(AbstractAccountDAOImpl.class.getName()); 
	
	private AccountOperations accountOperations;
	
	private ContextMapper contextMapper;
	
	/**
	 * <p>buildDN.</p>
	 *
	 * @param account a {@link com.bcbssc.commercial.registration.model.Account} object.
	 * @return a {@link javax.naming.Name} object.
	 */
	public abstract Name buildDN(Account account);
	
	/**
	 * <p>buildDN.</p>
	 *
	 * @param username a {@link java.lang.String} object.
	 * @return a {@link javax.naming.Name} object.
	 */
	public abstract Name buildDN(String username);
	
	/**
	 * <p>getSearchBase.</p>
	 *
	 * @return a {@link javax.naming.Name} object.
	 */
	public abstract Name getSearchBase();
	
	/**
	 * <p>getRoleAttribute.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public abstract String getRoleAttribute();
	
	/** {@inheritDoc} */
	public boolean accountExists(String username) throws ServerFailureException {
		
		Account	account							= null;
		boolean exists							= false;
		
		try {
			account 							= getAccount(username);
			
			if(account != null) {
				exists							= true;
			}
		}
		catch(NoSuchAccountException noSuchAccountException) {
			exists								= false;
		}
		catch(ServerFailureException serverFailureException) {
			throw serverFailureException;
		}
		
		return exists;
	}

	/** {@inheritDoc} */
	public boolean authenticateAccount(String username, String password) throws AuthenticationException, ServerFailureException {
	
		Name userDN						= (Name) buildDN(username);
		
		LdapContextSource ctxSource 	= new LdapContextSource();
		
		String url						= ((LdapContextSource)accountOperations.getContextSource()).getUrl(); 
		String baseDN					= ((LdapContextSource)accountOperations.getContextSource()).getBase();
		
		ctxSource.setUrl(url);
		ctxSource.setUserDn(userDN.toString() + "," + baseDN);
		ctxSource.setPassword(password);
		
		try {
		    ctxSource.afterPropertiesSet();
		    ctxSource.getContext();
		    return true;
		}
		catch(Exception e) {
			e.printStackTrace();
		    return false;
		}
	}

	// do not use
	/** {@inheritDoc} */
	public void createAccount(Account account) throws ServerFailureException {
		
		Name dn							= buildDN(account);
		DirContext dirContext			= (DirContext) contextMapper.mapToContext(account);
		
		try {
			accountOperations.bind(dn, dirContext, null);
		}
		catch(Exception exception) {
			throw new ServerFailureException(exception);
		}
	}
	
	/** {@inheritDoc} */
	public void deleteAccount(String userName) throws ServerFailureException {
		
		Name userDN						= (Name) buildDN(userName);
		
		try {
			accountOperations.unbind(userDN);
		}
		catch(Exception exception) {
			throw new ServerFailureException(exception);
		}		
	}

	/** {@inheritDoc} */
	public void modifyAccount(Account account) throws ServerFailureException {

		Name dn							= buildDN(account);
		DirContext dirContext			= (DirContext) contextMapper.mapToContext(account);
		
		try {
			accountOperations.rebind(dn, dirContext, null);
		}
		catch(Exception exception) {
			throw new ServerFailureException(exception);
		}
	}	

	/** {@inheritDoc} */
	public Account getAccount(String username) throws NoSuchAccountException, ServerFailureException {
		
		Name dn							= buildDN(username);
		Account	account					= null;
		
		try {
			
			account 					= (Account) accountOperations.lookup(dn, contextMapper);
			
			if(account == null) {
				throw new NoSuchAccountException("No account for found for the criteria");
			}
		}
		catch(NoSuchAccountException noSuchAccountException) {
			throw noSuchAccountException;
		}
		catch(Exception exception) {
			throw new ServerFailureException(exception);
		}
		
		return account;
	}
	
	/**
	 * <p>getAccount.</p>
	 *
	 * @param username a {@link java.lang.String} object.
	 * @param accountAttributes an array of {@link java.lang.String} objects.
	 * @return a {@link com.bcbssc.commercial.registration.model.Account} object.
	 * @throws com.bcbssc.commercial.registration.NoSuchAccountException if any.
	 * @throws com.bcbssc.commercial.registration.ServerFailureException if any.
	 */
	public Account getAccount(String username, String[] accountAttributes) throws NoSuchAccountException, ServerFailureException {

		Name dn							= buildDN(username);
		Account	account					= null;
		
		try {
			
			account 					= (Account) accountOperations.lookup(dn, accountAttributes, contextMapper);
			
			if(account == null) {
				throw new NoSuchAccountException("No account for found for the criteria");
			}
		}
		catch(NoSuchAccountException noSuchAccountException) {
			throw noSuchAccountException;
		}
		catch(Exception exception) {
			throw new ServerFailureException(exception);
		}
		
		return account;		
	}

	/** {@inheritDoc} */
	public String getAccountAttribute(String username, String attributeName) throws NoSuchAccountException, ServerFailureException {

		Name dn							= buildDN(username);
		DirContextAdapter adapter		= null;
		
		try {
			
			adapter 					= (DirContextAdapter) accountOperations.lookupContext(dn);
			
			if(adapter == null) {
				throw new NoSuchAccountException("No account for found for the criteria");
			}
		}
		catch(NoSuchAccountException noSuchAccountException) {
			throw noSuchAccountException;
		}
		catch(Exception exception) {
			throw new ServerFailureException(exception);
		}
		
		return adapter.getStringAttribute(attributeName);		
	}

	/** {@inheritDoc} */
	public List<String> getAccountRoles(String username) throws NoSuchAccountException, ServerFailureException {
		
		String roleAttribute			= getRoleAttribute();
		Name dn							= buildDN(username);
		DirContextAdapter adapter		= null;
		
		List<String> alRoleList			= null;
		
		try {
			
			adapter 					= (DirContextAdapter) accountOperations.lookupContext(dn);
			
			if(adapter == null) {
				throw new NoSuchAccountException("No account for found for the criteria");
			}
			
			String[] roles				= adapter.getStringAttributes(roleAttribute);
			alRoleList					= Arrays.asList(roles);
		}
		catch(NoSuchAccountException noSuchAccountException) {
			throw noSuchAccountException;
		}
		catch(Exception exception) {
			throw new ServerFailureException(exception);
		}
		
		return alRoleList;
	}

	/** {@inheritDoc} */
	public ArrayList<Account> getAccounts(String criteria) throws NoSuchAccountException, ServerFailureException {

		Name searchBase					= getSearchBase();
		ArrayList<Account> accounts		= null;
		
		try {
			
			accounts 					= (ArrayList<Account>) accountOperations.search(searchBase, criteria, SearchControls.SUBTREE_SCOPE, contextMapper);
			
			if(accounts == null || accounts.size() == 0) {
				throw new NoSuchAccountException("No accounts found for the criteria");
			}
		}
		catch(NoSuchAccountException noSuchAccountException) {
			throw noSuchAccountException;
		}
		catch(Exception exception) {
			throw new ServerFailureException(exception);
		}
		
		return accounts;				
	}

	/** {@inheritDoc} */
	public void setAccountAttribute(String username, String attributeName, Object attributeValue) throws NoSuchAccountException, ServerFailureException {
		
		Name dn							= buildDN(username);
		Attribute attribute				= null;
		ModificationItem item			= null;
		
		try {

			attribute					= new BasicAttribute(attributeName, attributeValue);
			item						= new ModificationItem(DirContext.REPLACE_ATTRIBUTE, attribute);
			accountOperations.modifyAttributes(dn, new ModificationItem[] {item});
		}
		catch(Exception exception) {
			throw new ServerFailureException(exception);
		}
	}

	/** {@inheritDoc} */
	public void updateAccount(Account account) throws NoSuchAccountException, ServerFailureException {
		
		Name dn								= buildDN(account);
		DirContextOperations dirContext		= null;
		
		try {
			
			dirContext						= accountOperations.lookupContext(dn);
			
			if(dirContext == null) {
				throw new NoSuchAccountException("No account for found for the criteria");
			}
			
			dirContext						= contextMapper.mapToContext(account);
			accountOperations.modifyAttributes(dn, dirContext);
		}
		catch(NoSuchAccountException noSuchAccountException) {
			throw noSuchAccountException;
		}		
		catch(Exception exception) {
			throw new ServerFailureException(exception);
		}
		
	}
	
	/**
	 * <p>getAccountAttributes.</p>
	 *
	 * @param username a {@link java.lang.String} object.
	 * @param accountAttributes an array of {@link java.lang.String} objects.
	 * @return a {@link java.util.HashMap} object.
	 * @throws com.bcbssc.commercial.registration.NoSuchAccountException if any.
	 * @throws com.bcbssc.commercial.registration.ServerFailureException if any.
	 */
	public HashMap<String, Object> getAccountAttributes(String username, String[] accountAttributes) throws NoSuchAccountException, ServerFailureException {
		
		Name dn									= buildDN(username);
		
		DirContextAdapter adapter				= null;
		Attributes attributes					= null;
		
		HashMap<String, Object> attributeMap	= null;
		int iLoopIndex							= -1;
		int iListSize							= accountAttributes.length;
		String attributeName					= null;
		
		try {
			
			adapter 							= (DirContextAdapter) accountOperations.lookupContext(dn);
			
			if(adapter == null) {
				throw new NoSuchAccountException("No account for found for the criteria");
			}
			
			attributes							= adapter.getAttributes();
			attributeMap						= new HashMap<String, Object>();
			
			for(iLoopIndex = 0; iLoopIndex < iListSize; iLoopIndex++) {
			
				attributeName					= accountAttributes[iLoopIndex];
				if(attributes.get(attributeName) != null) {
					attributeMap.put(attributeName, attributes.get(attributeName).get());
				}
			}
		}
		catch(NoSuchAccountException noSuchAccountException) {
			throw noSuchAccountException;
		}
		catch(Exception exception) {
			throw new ServerFailureException(exception);
		}
		
		return attributeMap;
	}
 
	/** {@inheritDoc} */
	public void setAccountAttributes(String username, HashMap<String, Object> attributes) throws NoSuchAccountException, ServerFailureException {
		
		Name dn									= buildDN(username);
		Attribute attribute						= null;
		ModificationItem item					= null;
		ModificationItem[] modificationItems	= null;
		ArrayList<ModificationItem> items		= null;

		String attributeName					= null;
		Object attributeValue					= null;

		int iLoopIndex							= -1;
		int iListSize							= -1;
		
		try {

			Iterator<String> iterator			= attributes.keySet().iterator();
			items								= new ArrayList<ModificationItem>();
			
			while(iterator.hasNext()) {
				
				attributeName					= (String) iterator.next();
				attributeValue					= attributes.get(attributeName);
				
				if(attributeValue.getClass().isArray() && ! StringUtils.equalsIgnoreCase(attributeName, LdapUser.PASSWORD)) {
				
					Object[] values				= (Object[]) attributeValue;
					attribute 					= new BasicAttribute(attributeName, false);

					if(values != null && values.length > 0) {
						
						for (int i = 0; values != null && i < values.length; i++) {				
							attribute.add(values[i]);
						}
					}					
				}
				else {
					attribute					= new BasicAttribute(attributeName, attributeValue);
				}
				item							= new ModificationItem(DirContext.REPLACE_ATTRIBUTE, attribute);
				items.add(item);
			}
			
			iListSize							= items.size();
			modificationItems					= new ModificationItem[iListSize];
			
			for(iLoopIndex = 0; iLoopIndex < iListSize; iLoopIndex++) {
				
				modificationItems[iLoopIndex]	= (ModificationItem) items.get(iLoopIndex);					
			}
			
			accountOperations.modifyAttributes(dn, modificationItems);
		}
		catch(Exception exception) {
			throw new ServerFailureException(exception);
		}
		
	}
	
	/**
	 * <p>Getter for the field <code>contextMapper</code>.</p>
	 *
	 * @return a {@link com.bcbssc.commercial.registration.core.ContextMapper} object.
	 */
	public ContextMapper getContextMapper() {
		return contextMapper;
	}

	/**
	 * <p>Setter for the field <code>contextMapper</code>.</p>
	 *
	 * @param contextMapper a {@link com.bcbssc.commercial.registration.core.ContextMapper} object.
	 */
	public void setContextMapper(ContextMapper contextMapper) {
		this.contextMapper = contextMapper;
	}

	/**
	 * <p>Getter for the field <code>accountOperations</code>.</p>
	 *
	 * @return a {@link com.bcbssc.commercial.registration.core.impl.AccountOperations} object.
	 */
	public AccountOperations getAccountOperations() {
		return accountOperations;
	}

	/**
	 * <p>Setter for the field <code>accountOperations</code>.</p>
	 *
	 * @param accountOperations a {@link com.bcbssc.commercial.registration.core.impl.AccountOperations} object.
	 */
	public void setAccountOperations(AccountOperations accountOperations) {
		this.accountOperations = accountOperations;
	}	
}
