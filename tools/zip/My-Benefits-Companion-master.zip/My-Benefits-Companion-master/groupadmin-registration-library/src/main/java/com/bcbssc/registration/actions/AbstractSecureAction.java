/*
 * @(#)AbstractSecureAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.registration.actions;

import com.bcbssc.registration.common.Constants;
import com.bcbssc.registration.dto.UserDTO;
import com.bcbssc.registration.permissions.RolePermissionsAdapter;
import com.bcbssc.registration.services.ISecureServices;
import com.bcbssc.struts.action.BaseAction;
import com.bcbssc.struts.common.CommonUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.navigator.menu.PermissionsAdapter;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * Shared Registration Abstract Secure Action
 *
 * This abstract class provides user creation based on the encrypted cookie
 * value. Additionally, it will set the menu permissions based on the user's
 * role. All secure-side action requiring user data should extend this class.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public abstract class AbstractSecureAction extends BaseAction {

	/** log4j logger */
	private static Logger logger = Logger.getLogger(AbstractSecureAction.class);

	/** to enable validation, a subclass must call enableValidation() */
	private boolean validationEnabled = false;

	/**
	 * Creates an application-specific services object
	 *
	 * @return services object
	 */
	protected abstract ISecureServices getServices();

	/**
	 * Enables validation after security checking
	 */
	protected void enableValidation() {
		this.validationEnabled = true;
	}

	/**
	 *************************************************************************
	 * Process the specified HTTP request, and create the corresponding HTTP
	 * response (or forward to another web component that will create it).
	 * Return an <code>ActionForward</code> instance describing where and how
	 * control should be forwarded, or <code>null</code> if the response has
	 * already been completed.
	 *
	 * @param user
	 *            the user described by the encrypted cookie
	 * @param mapping
	 *            The ActionMapping used to select this instance
	 * @param request
	 *            The HTTP request we are processing
	 * @param response
	 *            The HTTP response we are creating
	 * @exception Exception
	 *                if business logic throws an exception
	 * @param form a {@link org.apache.struts.action.ActionForm} object.
	 * @return a {@link org.apache.struts.action.ActionForward} object.
	 * @throws java.lang.Exception if any.
	 */
	protected abstract ActionForward execute(UserDTO user,
			ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception;

	/**
	 *************************************************************************
	 * Process the specified HTTP request, and create the corresponding HTTP
	 * response (or forward to another web component that will create it).
	 * Return an <code>ActionForward</code> instance describing where and how
	 * control should be forwarded, or <code>null</code> if the response has
	 * already been completed.
	 *
	 * @param mapping
	 *            The ActionMapping used to select this instance
	 * @param request
	 *            The HTTP request we are processing
	 * @param response
	 *            The HTTP response we are creating
	 * @exception Exception
	 *                if business logic throws an exception
	 * @param form a {@link org.apache.struts.action.ActionForm} object.
	 * @return a {@link org.apache.struts.action.ActionForward} object.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		if (AbstractSecureAction.logger.isDebugEnabled()) {
			AbstractSecureAction.logger.debug("Checking cookie info.");
		}

		String szontcred = CommonUtils.readCookie(Constants.COOKIE_ONT_CRED,
				request);
		ISecureServices services = this.getServices();
		UserDTO user = services.getUserFromCookie(szontcred);
		ActionForward returnActionForward = new ActionForward();

		if (user != null) {
			// Cookie is valid, set permissions adapter and user data
			PermissionsAdapter permissions = new RolePermissionsAdapter(user);
			request.setAttribute("permissionsAdapter", permissions);
			request.setAttribute("user", user);

			if (this.validationEnabled) {
				// Now that adapter is set, perform form validation
				ActionErrors ae = form.validate(mapping, request);
				if (!ae.isEmpty()) {
					this.saveErrors(request, ae);
					returnActionForward = mapping.getInputForward();
				}
			}

			// Validation skipped or passed, continue execution
			returnActionForward = this.execute(user, mapping, form, request,
					response);

		} else {
			// Cookie is invalid; security error
			returnActionForward = mapping
					.findForward(Constants.FORWARD_SECURITY_ERROR);
		}

		return returnActionForward;
	}
}
