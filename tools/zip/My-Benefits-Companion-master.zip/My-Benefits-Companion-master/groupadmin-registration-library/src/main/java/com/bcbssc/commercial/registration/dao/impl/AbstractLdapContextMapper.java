/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2009 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : AbstractLdapContextMapper.java
 *
 * Created Date     : Oct 23, 2008
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Oct 23, 2008     Initial version for bcbssc-ldap
 */

package com.bcbssc.commercial.registration.dao.impl;

import java.io.UnsupportedEncodingException;
import java.text.MessageFormat;

import com.bcbssc.commercial.registration.core.ContextMapper;
import com.bcbssc.commercial.registration.core.DirContextOperations;
import com.bcbssc.commercial.registration.model.Account;

/**
 * <p>Abstract AbstractLdapContextMapper class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public abstract class AbstractLdapContextMapper implements ContextMapper {

	/**
	 * <p>mapCommonPropertiesToContext.</p>
	 *
	 * @param account a {@link com.bcbssc.commercial.registration.model.Account} object.
	 * @param context a {@link com.bcbssc.commercial.registration.core.DirContextOperations} object.
	 */
	protected void mapCommonPropertiesToContext(Account account, DirContextOperations context) {
		
		context.setAttributeValue("cn", account.getUsername());
		context.setAttributeValue("bcbsgroup", account.getBcbsgroup());
		context.setAttributeValue("commonname", account.getCommonName());
		context.setAttributeValue("dateofacceptance", account.getDateOfAcceptance());
		context.setAttributeValue("challenge", account.getChallenge());
		context.setAttributeValue("challengeresponse", account.getChallengeResponse());
		context.setAttributeValue("name", account.getName());
		
		context.setAttributeValue("mail", account.getMail());
		context.setAttributeValue("whenCreated", account.getWhenCreated());
		context.setAttributeValue("bcbsLastAccessTime", account.getBcbsLastAccessTime());
		context.setAttributeValue("givenName", account.getFirstName());
		context.setAttributeValue("sn", account.getLastName());
		
		context.setAttributeValue("street", account.getAddressLineOne());
		context.setAttributeValue("addressline2", account.getAddressLineTwo());
		context.setAttributeValue("l", account.getCity());
		context.setAttributeValue("company", account.getCompany());
		context.setAttributeValue("currentpasswordfield", account.getCurrentPasswordField());
		context.setAttributeValue("facsimiletelephoneext", account.getFacsimileTelephoneExtn());
		context.setAttributeValue("facsimileTelephoneNumber", account.getFacsimileTelephoneNumber());
		context.setAttributeValue("faxareacode", account.getFaxAreaCode());
		context.setAttributeValue("faxprefix", account.getFaxPrefix());
		context.setAttributeValue("faxsuffix", account.getFaxPrefix());
		context.setAttributeValue("middleini", account.getMiddleInitial());

		context.setAttributeValue("postalCode", account.getPostalCode());
		context.setAttributeValue("profileexists", account.getProfileExists());
		context.setAttributeValue("st", account.getState());
		context.setAttributeValue("telephoneext", account.getTelephoneExtn());
		context.setAttributeValue("telephoneNumber", account.getTelephoneNumber());
		context.setAttributeValue("telephonenumberareacode", account.getTelephoneNumberAreaCode());
		context.setAttributeValue("telephonenumberprefix", account.getTelephoneNumberPrefix());
		context.setAttributeValue("telephonenumbersuffix", account.getTelephoneNumberSuffix());
		context.setAttributeValue("sAMAccountName", account.getUsername());
		context.setAttributeValue("uid", account.getUsername());		

		context.setAttributeValue("ont-accessstatus", account.getOntAccessStatus());
		context.setAttributeValue("ont-badlogincount", account.getOntBadLoginCount());
		context.setAttributeValue("ont-enddate", account.getOntEndDate());
		context.setAttributeValue("ont-organizationdn", account.getOntOrganizationDn());
		context.setAttributeValue("ont-passwordresetdate", account.getOntPasswordResetDate());
		context.setAttributeValue("ont-passwordstatus", account.getOntPasswordStatus());
		context.setAttributeValues("ont-roledn", account.getOntRoleDn());
		context.setAttributeValue("ont-startdate", account.getOntStartDate());
		context.setAttributeValue("ont-timeout", account.getOntTimeout());
		context.setAttributeValue("ont-validobject", account.getOntValidObject());		
		context.setAttributeValue("userAccountControl", account.getUserAccountControl());
		
		context.setAttributeValues("objectClass", account.getObjectClass());

		String newQuotedPassword 	= MessageFormat.format("\"{0}\"", new Object[] {"thiagu"});
		try {
			byte[] newUnicodePassword 	= newQuotedPassword.getBytes("UTF-16LE");
			context.setAttributeValue("unicodePwd", newUnicodePassword);
		}
		catch (UnsupportedEncodingException unsupportedEncodingException) {
		}
		
		context.setAttributeValue("distinguishedName", account.getDistinguishedName());
		context.setAttributeValue("dentalnotificationcounter", account.getDentalNotificationCounter());
		context.setAttributeValue("notificationcounter", account.getNotificationCounter());
		context.setAttributeValue("preferredmethodofcontact", account.getPreferredMethodOfContact());
		context.setAttributeValue("suffix", account.getSuffix());
		
		
		/*
		context.setAttributeValue("dn", account.getDistinguishedName());
		context.setAttributeValue("badPasswordTime", account.getBadPasswordTime());
		context.setAttributeValue("badPwdCount", account.getBadPasswordCount());
		context.setAttributeValue("distinguishedName", account.getDistinguishedName());
		
		context.setAttributeValue("accountExpires", "9223372036854775807");
		context.setAttributeValue("codePage", "0");
		context.setAttributeValue("countryCode", "0");
		context.setAttributeValue("instanceType", "4");
		
		context.setAttributeValue("objectCategory", "CN=Person,CN=Schema,CN=Configuration,DC=privbunit,DC=ad");
		
		
		context.setAttributeValue("primaryGroupID", "513");
		context.setAttributeValue("sAMAccountType", "805306368");

		context.setAttributeValue("lastLogoff", "0");
		context.setAttributeValue("lastLogon", "0");
		context.setAttributeValue("logonCount", "0");
		
		context.setAttributeValue("objectGUID", "76  51  42  E1  04  56  8B  41  B4  93  66  90  4B  2C  DC  C0");
		context.setAttributeValue("objectSid", "01  05  00  00  00  00  00  05  15  00  00  00  11  72  58  8E");
		context.setAttributeValue("ont-badlogincount", "0");
		context.setAttributeValue("ont-passwordresetdate", "20350101");
		context.setAttributeValue("preferredmethodofcontact", "Email");
		context.setAttributeValue("pwdLastSet", "128982073419733750");
		*/
	}
	
	/**
	 * <p>mapCommonPropertiesFromContext.</p>
	 *
	 * @param context a {@link com.bcbssc.commercial.registration.core.DirContextOperations} object.
	 * @param account a {@link com.bcbssc.commercial.registration.model.Account} object.
	 */
	protected void mapCommonPropertiesFromContext(DirContextOperations context, Account account) {

		account.setUsername(context.getStringAttribute("cn"));
		account.setBcbsgroup(context.getStringAttribute("bcbsgroup"));
		account.setCommonName(context.getStringAttribute("commonname"));
		account.setDateOfAcceptance(context.getStringAttribute("dateofacceptance"));
		account.setChallenge(context.getStringAttribute("challenge"));
		account.setChallengeResponse(context.getStringAttribute("challengeresponse"));
		account.setName(context.getStringAttribute("name"));
		
		account.setMail(context.getStringAttribute("mail"));
		account.setWhenCreated(context.getStringAttribute("whenCreated"));
		account.setBcbsLastAccessTime(context.getStringAttribute("bcbsLastAccessTime"));
		account.setFirstName(context.getStringAttribute("givenName"));
		account.setLastName(context.getStringAttribute("sn"));
		
		account.setAddressLineOne(context.getStringAttribute("street"));
		account.setAddressLineTwo(context.getStringAttribute("addressline2"));
		account.setCity(context.getStringAttribute("l"));
		account.setCompany(context.getStringAttribute("company"));
		account.setCurrentPasswordField(context.getStringAttribute("currentpasswordfield"));
		account.setFacsimileTelephoneExtn(context.getStringAttribute("facsimiletelephoneext"));
		account.setFacsimileTelephoneNumber(context.getStringAttribute("facsimileTelephoneNumber"));
		account.setFaxAreaCode(context.getStringAttribute("faxareacode"));
		account.setFaxPrefix(context.getStringAttribute("faxprefix"));
		account.setMiddleInitial(context.getStringAttribute("middleini"));
		account.setOntAccessStatus(context.getStringAttribute("ont-accessstatus"));
		account.setOntBadLoginCount(context.getStringAttribute("ont-badlogincount"));
		account.setOntEndDate(context.getStringAttribute("ont-enddate"));
		account.setOntOrganizationDn(context.getStringAttribute("ont-organizationdn"));
		account.setOntPasswordResetDate(context.getStringAttribute("ont-passwordregetdate"));
		account.setOntPasswordStatus(context.getStringAttribute("ont-passwordstatus"));
		account.setOntRoleDn(context.getStringAttributes("ont-roledn"));
		account.setOntStartDate(context.getStringAttribute("ont-startdate"));
		account.setOntTimeout(context.getStringAttribute("ont-timeout"));
		account.setOntValidObject(context.getStringAttribute("ont-validobject"));
		account.setPostalCode(context.getStringAttribute("postalCode"));
		account.setProfileExists(context.getStringAttribute("profileexists"));
		account.setState(context.getStringAttribute("st"));
		account.setTelephoneExtn(context.getStringAttribute("telephoneext"));
		account.setTelephoneNumber(context.getStringAttribute("telephoneNumber"));
		account.setTelephoneNumberAreaCode(context.getStringAttribute("telephonenumberareacode"));
		account.setTelephoneNumberPrefix(context.getStringAttribute("telephonenumberprefix"));
		account.setTelephoneNumberSuffix(context.getStringAttribute("telephonenumbersuffix"));
		account.setUserAccountControl(context.getStringAttribute("userAccountControl"));		

		account.setDistinguishedName(context.getStringAttribute("distinguishedName"));
		
		account.setDentalNotificationCounter(context.getStringAttribute("dentalnotificationcounter"));
		account.setNotificationCounter(context.getStringAttribute("notificationcounter"));
		account.setPreferredMethodOfContact(context.getStringAttribute("preferredmethodofcontact"));
		account.setSuffix(context.getStringAttribute("suffix"));		
		account.setObjectClass(context.getStringAttributes("objectClass"));
	}
}
