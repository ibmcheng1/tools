/**
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.registration.tds.impl;

import java.io.FileNotFoundException;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import javax.naming.AuthenticationException;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.AttributeInUseException;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.ModificationItem;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.bcbssc.netsys.Config;
import com.bcbssc.netsys.jndi.DirectoryObject;
import com.bcbssc.netsys.jndi.DirectorySearchFilter;
import com.bcbssc.netsys.jndi.LdapException;
import com.bcbssc.netsys.jndi.LdapUser;
import com.bcbssc.netsys.jndi.MissingPropertyException;
import com.bcbssc.registration.common.Constants;
import com.bcbssc.registration.common.CookieUtil;
import com.bcbssc.registration.dto.UserDTO;
import com.bcbssc.registration.tds.LdapConfig;
import com.bcbssc.registration.tds.ProfileManagementService;

/**
 * <p>Abstract AbstractProfileManagementService class.</p>
 *
 * @author X94S(Rao Peddi)
 * @version $Id: $Id
 */
public abstract class AbstractProfileManagementService implements
		com.bcbssc.registration.tds.ProfileManagementService {

	/** The log4j logger for this class. */
	private static Logger logger = Logger
			.getLogger(AbstractProfileManagementService.class);

	private static final int ADDPROFILE = 1;

	protected String iniFile;

	protected String tdsIniFile;
	
	private boolean uppercasePassword = true;

	/**
	 * <p>Constructor for AbstractProfileManagementService.</p>
	 *
	 * @param _iniFile
	 *            which contains information related to racf/mq information
	 * @param _tdsIniFile
	 *            whcih contans ldap connection information
	 */
	public AbstractProfileManagementService(String _iniFile, String _tdsIniFile) {
		this.iniFile = _iniFile;
		this.tdsIniFile = _tdsIniFile;
	}

	/**
	 * {@inheritDoc}
	 *
	 * Creates profile in LDAP
	 */
	public boolean addUser(UserDTO user, String password)
			throws MissingPropertyException, NamingException,
			FileNotFoundException {

		if (logger.isDebugEnabled()) {
			logger.debug("AbstractProfileManagementService.addUser");
		}
		boolean userAdded = false;

		HashMap<String, Object> addList = new HashMap<String, Object>();

		this.appendUserToValMap(user, addList, ADDPROFILE);

		addList.put(Constants.TDS_LDAP_ATTRIBUTE_UNICODEPWD, password
				.toUpperCase());

		final Attribute oc = new BasicAttribute(Constants.TDS_OBJECT_CLASS);

		oc.add("inetOrgPerson");
		oc.add("bcbsPerson");
		oc.add("mimGroupAdmin");

		addList.put(Constants.TDS_OBJECT_CLASS, oc);
		addList.put(Constants.TDS_LDAP_ATTRIBUTE_ENABLED, "true");

		final String samAccountName = user.getSamAccountName();

		try {
			final Object[] dnParams = {
					samAccountName,
					LdapConfig.getLdapConfig(tdsIniFile).getProperty(
							Constants.TDS_LDAP_SEARCH_BASE) };

			final String dn = MessageFormat.format("uid={0},{1}", dnParams);

			DirectoryObject.create(LdapConfig.getLdapConfig(tdsIniFile), dn,
					addList);
			userAdded = true;

		} catch (Exception ex) {
			userAdded = false;
			logger
					.error("AbstractProfileManagementService.addUser Profile creation failed for user "
							+ samAccountName);
			logger.error("Error: ", ex);
		}
		return userAdded;
	}

	/**
	 * {@inheritDoc}
	 *
	 * Returns role name
	 */
	public String getDistinguishedRoleName(String roleParam)
			throws NamingException, MissingPropertyException,
			FileNotFoundException {

		String role = Config.getPrivateProfileString(
				Constants.INI_LOCAL_SECTION, roleParam,
				com.bcbssc.struts.common.Constants.BLANK_STRING, iniFile);

		if (logger.isDebugEnabled()) {
			logger
					.debug("AbstractProfileManagementService.getDistinguishedRoleName role = "
							+ role);
		}

		return role;
	}

	/**
	 * {@inheritDoc}
	 *
	 * This method returns holiday or downtime message
	 */
	public String getHolidayDowntimeMessage(String messageType)
			throws NamingException, MissingPropertyException,
			FileNotFoundException {

		String searchDN = Config.getPrivateProfileString(
				Constants.INI_LOCAL_SECTION, Constants.INI_ROLE_BASE,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		String orgDN = "cn=" + Constants.TDS_LDAP_ORG_ROLE + "," + searchDN;

		String baseDN = Config.getPrivateProfileString(
				Constants.INI_LOCAL_SECTION, Constants.TDS_BASE,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		return ProfileManagementService.Factory.getHolidayDowntimeMessage(
				baseDN, searchDN, orgDN, messageType, tdsIniFile);
	}

	/**
	 * {@inheritDoc}
	 *
	 * This method returns matching userids based on last6SSN, dob and lastName.
	 */
	public String[] getMatchingProfiles(String last6SSN, String dob,
			String lastName) throws NamingException, MissingPropertyException,
			FileNotFoundException {
		if (logger.isDebugEnabled()) {
			logger
					.debug("AbstractProfileManagementService.getMatchingProfiles lastName="
							+ lastName);
		}
		Properties config = LdapConfig.getLdapConfig(tdsIniFile);

		Object[] params1 = { lastName, dob, last6SSN };
		String searchFilter1 = MessageFormat.format(
				"(&(sn={0})(dateOfBirth={1})(last6ssn={2}))", params1);

		Object[] params2 = { dob, last6SSN };

		String searchFilter2 = MessageFormat.format(
				"(&(dateOfBirth={0})(last6ssn={1}))", params2);

		if (StringUtils.isBlank(lastName)) {
			config.put(DirectorySearchFilter.SEARCH_FILTER, searchFilter2);
		} else {
			config.put(DirectorySearchFilter.SEARCH_FILTER, searchFilter1);
		}
		DirectorySearchFilter filter = new DirectorySearchFilter(config);

		Collection users = DirectoryObject.search(config, filter);

		if (logger.isDebugEnabled()) {
			logger
					.debug("AbstractProfileManagementService.getMatchingProfiles matching profiles count = "
							+ users.size());
		}
		ArrayList<String> listUserDns = new ArrayList<String>();

		Iterator itr = users.iterator();

		while (itr.hasNext()) {

			DirectoryObject dirObject = (DirectoryObject) itr.next();
			listUserDns.add(dirObject.getDistinguishedName());
		}

		String[] userDistinguishedNames = (String[]) listUserDns
				.toArray(new String[listUserDns.size()]);

		return userDistinguishedNames;
	}

	/**
	 * {@inheritDoc}
	 *
	 * This method returns matching userids based on last6SSN and dob
	 */
	public String[] getMatchingProfiles(String last6SSN, String dob)
			throws NamingException, MissingPropertyException,
			FileNotFoundException {

		return getMatchingProfiles(last6SSN, dob, "");
	}

	/**
	 * {@inheritDoc}
	 *
	 * This method returns profile count to see if user has more profile based
	 * on last6SSN and dob
	 */
	public int getProfileCount(String last6SSN, String dob)
			throws NamingException, MissingPropertyException,
			FileNotFoundException {

		return getMatchingProfiles(last6SSN, dob, "").length;

	}

	/**
	 * {@inheritDoc}
	 *
	 * This methods returns UserDTO object which contains user information based
	 * on the samAccountName. The uid in ldap corresponds to samAccountName
	 */
	public UserDTO getUser(String samAccountName) throws Exception {

		if (logger.isDebugEnabled()) {
			logger.debug("AbstractProfileManagementService.getUser samAccountName="
					+ samAccountName);
		}

		String userDN = "uid="
				+ samAccountName
				+ ","
				+ Config.getPrivateProfileString(Constants.INI_LOCAL_SECTION,
						Constants.INI_PEOPLE_BASE,
						com.bcbssc.struts.common.Constants.BLANK_STRING,
						this.iniFile);

		LdapUser ldapObject = ProfileManagementService.Factory
				.getLdapUserInstance(userDN, tdsIniFile);

		UserDTO user = this.createUserFromLdapAttributes(ldapObject);

		return user;
	}

	/**
	 * {@inheritDoc}
	 *
	 * This method makes ldap call to get the profile data using the userid from
	 * the encryptedCookie
	 */
	public UserDTO getUserFromCookie(String encryptedCookie) throws Exception {

		if (logger.isDebugEnabled()) {
			logger
					.debug("AbstractProfileManagementService.getUserFromCookie encryptedCookie="
							+ encryptedCookie);
		}
		String domain = Config.getPrivateProfileString(
				Constants.INI_COOKIE_SECTION, Constants.INI_AUTH_COOKIE_DOMAIN,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		String cookieKey = Config.getPrivateProfileString(
				Constants.INI_COOKIE_SECTION, Constants.INI_AUTH_COOKIE_KEY,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		String cookieIV = Config.getPrivateProfileString(
				Constants.INI_COOKIE_SECTION, Constants.INI_AUTH_COOKIE_IV,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		CookieUtil cookieObject = new CookieUtil(cookieKey, cookieIV, domain,
				"/");
		String userName = cookieObject
				.getUserNameFromCredentialCookie(encryptedCookie);

		return getUser(userName);
	}

	/**
	 * {@inheritDoc}
	 *
	 * This method returns UserDTO object which has user information
	 */
	public UserDTO getUserFromCookies(String szOntCredCookie,
			String racfCookie, String suType) throws Exception {
		UserDTO user = this.getUserFromCookie(szOntCredCookie);
		if ((racfCookie != null) && (racfCookie.length() > 0)
				&& (suType != null)) {
			user.setSuperUserType(suType);
		}

		return user;
	}

	/**
	 * {@inheritDoc}
	 *
	 * This mehtod verifies for the profile existance in ldap based on userid or
	 * accesscode
	 */
	public boolean profileExistsForUserIDorAccessCode(String attributeName,
			String attributeValue) throws MissingPropertyException,
			NamingException, FileNotFoundException {
		if (logger.isDebugEnabled()) {
			logger
					.debug("AbstractProfileManagementService.profileExistsForUserIDorAccessCode "
							+ attributeName + "=" + attributeValue);
		}
		boolean profileExists = false;
		Properties config = LdapConfig.getLdapConfig(tdsIniFile);
		Object[] params = { attributeName, attributeValue };
		String searchStr = MessageFormat.format("(&({0}={1}))", params);
		config.put(DirectorySearchFilter.SEARCH_FILTER, searchStr);
		DirectorySearchFilter filter = new DirectorySearchFilter(config);

		Collection results = DirectoryObject.search(config, filter);

		if (results != null && results.size() > 0) {
			profileExists = true;
		}

		return profileExists;
	}

	/**
	 * {@inheritDoc}
	 *
	 * This method re-authenticates user when he visits Password Help for
	 * resetting password
	 */
	public UserDTO resetPassword(String last6SSN, String dob,
			String samAccountName) throws NamingException,
			MissingPropertyException, FileNotFoundException {
		if (logger.isDebugEnabled()) {

			logger
					.debug("AbstractProfileManagementService.resetPassword samAccountName="
							+ samAccountName);
		}
		UserDTO user = null;
		Properties config = LdapConfig.getLdapConfig(tdsIniFile);

		Object[] params1 = { samAccountName, dob, last6SSN };
		String searchFilter1 = MessageFormat.format(
				"(&(uid={0})(dateOfBirth={1})(last6ssn={2}))", params1);

		Object[] params2 = { dob, last6SSN };
		String searchFilter2 = MessageFormat.format(
				"(&(dateOfBirth={0})(last6ssn={1}))", params2);

		if (StringUtils.isBlank(samAccountName)) {
			config.put(DirectorySearchFilter.SEARCH_FILTER, searchFilter2);

		} else {

			config.put(DirectorySearchFilter.SEARCH_FILTER, searchFilter1);
		}

		DirectorySearchFilter filter = new DirectorySearchFilter(config);

		Collection users = DirectoryObject.search(config, filter);
		DirectoryObject[] matchingProfiles = (DirectoryObject[]) users
				.toArray(new DirectoryObject[users.size()]);

		if (matchingProfiles.length > 0) {
			String userdn = matchingProfiles[0].getDistinguishedName();
			LdapUser ldapObject = ProfileManagementService.Factory
					.getLdapUserInstance(userdn, tdsIniFile);
			if (logger.isDebugEnabled()) {
				StringBuffer logMsg = new StringBuffer(64);
				logMsg.append("user reauthenticated (").append(userdn).append(
						"); getting info");
				logger.debug(logMsg.toString());
			}

			try {
				user = this.createUserFromLdapAttributes(ldapObject);
			} catch (Exception e) {
				logger.error("Error: " + e);

				throw new NamingException(e.getMessage());
			}
		}

		return user;
	}

	/**
	 * {@inheritDoc}
	 *
	 * This method updates roles in ldap when the user login
	 */
	public void updateRoles(String samAccountName, Collection roles)
			throws NamingException, MissingPropertyException,
			FileNotFoundException {

	
		
		if (logger.isDebugEnabled()) {
			logger.debug("AbstractProfileManagementService.updateRoles roles=" + roles);
		}
		
		/**
		 * delete existing roles from LDAP before updating with new roles
		 */
		deleteRoles(samAccountName);
		
		Iterator rolesItr = roles.iterator();

		while (rolesItr.hasNext()) {
			String roleName = (String) rolesItr.next();

			String roleBaseDN = "cn="
					+ roleName
					+ ","
					+ Config.getPrivateProfileString(
							Constants.INI_LOCAL_SECTION,
							Constants.INI_ROLE_BASE,
							com.bcbssc.struts.common.Constants.BLANK_STRING,
							this.iniFile);
		
			String searchBase = Config.getPrivateProfileString(
					Constants.INI_LOCAL_SECTION,
					Constants.TDS_LDAP_SEARCH_BASE,
					com.bcbssc.struts.common.Constants.BLANK_STRING,
					this.tdsIniFile);
		
			LdapUser ldapObject = ProfileManagementService.Factory
					.getLdapUserInstance(roleBaseDN, tdsIniFile);
			ModificationItem[] modItem = new ModificationItem[1];

			String userDN = "uid=" + samAccountName + "," + searchBase;
			try {
				modItem[0] = ldapObject.addAttribute("member", userDN);

				ldapObject.commit(modItem);
			} catch (AttributeInUseException aie) {
				// ignore this exception since the role already exists
			}
		}

	}

	
	private void deleteRoles(String samAccountName)
			throws FileNotFoundException, MissingPropertyException,
			NamingException {

		if (logger.isDebugEnabled()) {
			logger
					.debug("AbstractProfileManagementService deleteRoles samAccountName="
							+ samAccountName
							+ ",iniFile="
							+ iniFile
							+ ",tdsIniFile=" + tdsIniFile);
		}

		String userRoleDN = "uid="
				+ samAccountName
				+ ","
				+ Config.getPrivateProfileString(Constants.INI_LOCAL_SECTION,
						Constants.INI_PEOPLE_BASE,
						com.bcbssc.struts.common.Constants.BLANK_STRING,
						this.iniFile);

		String roleBaseDN = Config.getPrivateProfileString(
				Constants.INI_LOCAL_SECTION, Constants.INI_ROLE_BASE,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		String baseDN = Config.getPrivateProfileString(
				Constants.INI_LOCAL_SECTION, Constants.TDS_BASE,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		Properties config = LdapConfig.getLdapConfig(tdsIniFile);
		config.remove(Constants.TDS_LDAP_BASE);
		config.remove(Constants.TDS_LDAP_SEARCH_BASE);
		config.put(Constants.TDS_LDAP_BASE, baseDN);
		config.put(Constants.TDS_LDAP_SEARCH_BASE, roleBaseDN);

		Object[] params = { "member", userRoleDN };
		String searchStr = MessageFormat.format("(&({0}={1}))", params);
		config.put(DirectorySearchFilter.SEARCH_FILTER, searchStr);
		DirectorySearchFilter filter = new DirectorySearchFilter(config);

		Collection results = DirectoryObject.search(config, filter);

		Iterator itr = results.iterator();
		while (itr.hasNext()) {
			DirectoryObject ob1 = (DirectoryObject) itr.next();
			ModificationItem[] modItem = new ModificationItem[1];
			modItem[0] = ob1.removeAttribute("member", userRoleDN);
			ob1.commit(modItem);

		}

	}
	
	/**
	 * {@inheritDoc}
	 *
	 * This method updates lastAccessTime in ldap when the user login
	 */
	public void updateLastAccessTime(String samAccountName, String attribute)
			throws NamingException, MissingPropertyException,
			FileNotFoundException {
		if (logger.isDebugEnabled()) {
			logger.debug("updateLastAccessTime samAccountName="
					+ samAccountName);
		}
		String userDN = "uid="
				+ samAccountName
				+ ","
				+ Config.getPrivateProfileString(Constants.INI_LOCAL_SECTION,
						Constants.INI_PEOPLE_BASE,
						com.bcbssc.struts.common.Constants.BLANK_STRING,
						this.iniFile);

		LdapUser ldapObject = ProfileManagementService.Factory
				.getLdapUserInstance(userDN, tdsIniFile);
		SimpleDateFormat lastAccessFormat = new SimpleDateFormat(
				Constants.TDS_LAST_ACCESS_DATE_FORMAT);
		ModificationItem[] modItem = new ModificationItem[1];

		modItem[0] = ldapObject.updateAttribute(attribute, lastAccessFormat
				.format(new Date()));
		ldapObject.commit(modItem);

	}

	/**
	 * {@inheritDoc}
	 *
	 * This method updates ldap attribute with the given value
	 */
	public void updateLdapAttribute(String samAccountName, String attribute,
			String newValue) throws NamingException, MissingPropertyException,
			FileNotFoundException, LdapException {

		if (logger.isDebugEnabled()) {
			logger
					.debug("AbstractProfileManagementService.updateLdapAttribute samAccountName="
							+ samAccountName);
		}
		String userDN = "uid="
				+ samAccountName
				+ ","
				+ LdapConfig.getLdapConfig(tdsIniFile).getProperty(
						Constants.TDS_LDAP_SEARCH_BASE);

		try {
			LdapUser ldapObject = ProfileManagementService.Factory
					.getLdapUserInstance(userDN, tdsIniFile);
			ModificationItem[] mods = new ModificationItem[1];

			mods[0] = ldapObject.updateAttribute(attribute, newValue);
			ldapObject.commit(mods);

		} catch (MissingPropertyException e) {
			logger.error("Error: " + e);

			throw e;
		}

	}

	/**
	 * {@inheritDoc}
	 *
	 * This method updates user password
	 */
	public boolean updatePassword(String samAccountName, String newpassword)
			throws NamingException, MissingPropertyException,
			FileNotFoundException {

		if (logger.isDebugEnabled()) {
			logger
					.debug("AbstractProfileManagementService.updatePassword samAccountName="
							+ samAccountName);
		}

		String userDN = "uid="
				+ samAccountName
				+ ","
				+ LdapConfig.getLdapConfig(tdsIniFile).getProperty(
						Constants.TDS_LDAP_SEARCH_BASE);
		boolean passwordUpdated = false;
		try {
			LdapUser ldapObject = ProfileManagementService.Factory
					.getLdapUserInstance(userDN, tdsIniFile);
			String unicodePwd = newpassword.toUpperCase();
			ldapObject.resetPassword(unicodePwd);
			passwordUpdated = true;
		} catch (Exception ex) {
			logger.error("Error:" + ex);
			throw new NamingException(ex.getMessage());

		}

		return passwordUpdated;
	}

	/**
	 * {@inheritDoc}
	 *
	 * This method updates user information in ldap
	 */
	public boolean updateProfile(UserDTO user) throws NamingException,
			MissingPropertyException, FileNotFoundException {
		if (logger.isDebugEnabled()) {
			logger
					.debug("AbstractProfileManagementService.updateProfile() UserDTO="
							+ user);
		}
		boolean updated = false;

		Map attributesMap = new HashMap();
		try {
			appendUserToValMap(user, attributesMap, 2);
			this.updateValues(user.getSamAccountName(), attributesMap);
			updated = true;
		} catch (Exception ex) {
			logger.error("Error: " + ex);
			throw new NamingException(ex.getMessage());
		}

		return updated;
	}

	/**
	 * Abstract method used to prepare the UserDTO object from the implementaion
	 * class
	 *
	 * @param user a {@link com.bcbssc.registration.dto.UserDTO} object.
	 * @param attributesMap a {@link java.util.Map} object.
	 * @param action
	 *            this indicates whether the UserDTO is prepared for creating
	 *            profile or modify profile
	 */
	protected abstract void appendUserToValMap(UserDTO user, Map attributesMap,
			int action);

	/**
	 * {@inheritDoc}
	 *
	 * This method authenticates user with userid and password
	 */
	public UserDTO validateUser(String samAccountName, String unicodePwd)
			throws NamingException, MissingPropertyException,
			FileNotFoundException, Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("AbstractProfileManagementService.validateUser tdsIniFile="
					+ tdsIniFile + "samAccountName=" + samAccountName);
		}

		UserDTO user = null;
		String searchBase = Config.getPrivateProfileString(
				Constants.INI_LOCAL_SECTION, Constants.TDS_LDAP_SEARCH_BASE,
				com.bcbssc.struts.common.Constants.BLANK_STRING,
				this.tdsIniFile);

		logger.debug("TDS Ini File is: " + this.tdsIniFile);
		String userDN = "uid=" + samAccountName + "," + searchBase;
		logger.debug("userDN: "+userDN);
		try {
			LdapUser ldapObject = ProfileManagementService.Factory
					.getLdapUserInstance(userDN, tdsIniFile);
			logger.debug("ldapObject.getDistinguishedName: "+ ldapObject.getDistinguishedName());
			
			if(ldapObject.getAttribute("enabled").equals("true")){	
				    if(uppercasePassword){
				    	logger.debug("Trying with all upper case password for the user: "+samAccountName);
			         ldapObject.authenticate(unicodePwd.toUpperCase());
				    }else{
				    	logger.debug("Ttying with typed password for user: "+samAccountName);
				     ldapObject.authenticate(unicodePwd);
				    }
			}else {
				
				
				if (logger.isDebugEnabled()) {
					logger.debug("User "+samAccountName+" enabled: " + ldapObject.getAttribute("enabled"));
				}
				return user;
			}
			if (logger.isDebugEnabled()) {
				logger.debug("User " + samAccountName
						+ " authenticated successfully.....");
			}

			user = createUserFromLdapAttributes(ldapObject);

		}catch(AuthenticationException aue){
			
			if(uppercasePassword){
			// if  authentication failed using an
            // all uppercase password, re-try authentication with typed password
			logger.debug("Trying authentication with typed password...");
			uppercasePassword = false;
			user = validateUser(samAccountName, unicodePwd);
			}else{
				logger.error("Error:"+aue);
			}
		}catch(LdapException le){
			if(uppercasePassword){
			// if  authentication failed using an
            // all uppercase password, re-try authentication with typed password
			logger.debug("Trying authentication with typed password...");
			uppercasePassword = false;
			
			user = validateUser(samAccountName, unicodePwd);
			}else{
				logger.error("Error:"+le);
			}
		}
		catch (NamingException ne) {
             
			logger.error("Error: user authentication unsuccessfull,caught NamingException"
					+ ne.getMessage());

		} catch (Exception exp) {
			logger.error("Root cause:", exp);
			throw exp;

		}
		return user;
	}

	
	/**
	 * This method authenticates user with userid and password
	 *
	 * @param samAccountName
	 *            userid of the person
	 * @param unicodePwd a {@link java.lang.String} object.
	 * @return a boolean.
	 * @throws javax.naming.NamingException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 * @throws java.io.FileNotFoundException if any.
	 * @throws java.lang.Exception if any.
	 */
	public boolean validateSuperUser(String samAccountName, String unicodePwd)
			throws NamingException, MissingPropertyException,
			FileNotFoundException, Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("AbstractProfileManagementService.validateSuperUser tdsIniFile="
					+ tdsIniFile + "samAccountName=" + samAccountName);
		}
        boolean superUserValidated = false;
		String searchBase = null;

		searchBase = Config.getPrivateProfileString(
					Constants.INI_LOCAL_SECTION, Constants.TDS_LDAP_SUPERUSER_SEARCH_BASE,
					com.bcbssc.struts.common.Constants.BLANK_STRING,
					this.tdsIniFile);
	
		String userDN = "uid=" + samAccountName + "," + searchBase;
		try {
			LdapUser ldapObject = ProfileManagementService.Factory
					.getLdapUserInstance(userDN, tdsIniFile);
			logger.debug("ldapObject: "+ldapObject);	
			
			
			ldapObject.authenticate(unicodePwd);
			
			superUserValidated = true;
			
		}catch(AuthenticationException aue){
			superUserValidated = false;
			logger.error("Error:"+aue);
		}catch(LdapException le){
			superUserValidated = false;
			logger.error("Error:"+le);
		}
		catch (NamingException ne) {
			superUserValidated = false;
			logger.error("Error: user authentication unsuccessfull,caught NamingException"
					+ ne.getMessage());
			
		} catch (Exception exp) {
			superUserValidated = false;
			logger.error("Root cause:", exp);

		}
		return superUserValidated;
	}

	
	
	
	
	
	
	/**
	 * {@inheritDoc}
	 *
	 * updates multiple attributes from this user's profile
	 * @see com.bcbssc.netsys.jndi.DirectoryObject#updateAttribute(String,Object)
	 * @see com.bcbssc.netsys.jndi.DirectoryObject#commit(ModificationItem[])
	 * @see com.bcbssc.netsys.jndi.DirectoryObject#updateAttribute(String,Object)
	 * @see com.bcbssc.netsys.jndi.DirectoryObject#commit(ModificationItem[])
	 * @see com.bcbssc.netsys.jndi.DirectoryObject#updateAttribute(String,Object)
	 * @see com.bcbssc.netsys.jndi.DirectoryObject#commit(ModificationItem[])
	 * @see com.bcbssc.netsys.jndi.DirectoryObject#updateAttribute(String,Object)
	 * @see com.bcbssc.netsys.jndi.DirectoryObject#commit(ModificationItem[])
	 * @see com.bcbssc.netsys.jndi.DirectoryObject#updateAttribute(String,Object)
	 * @see com.bcbssc.netsys.jndi.DirectoryObject#commit(ModificationItem[])
	 * @see com.bcbssc.netsys.jndi.DirectoryObject#updateAttribute(String,Object)
	 * @see com.bcbssc.netsys.jndi.DirectoryObject#commit(ModificationItem[])
	 * @see com.bcbssc.netsys.jndi.DirectoryObject#updateAttribute(String,Object)
	 * @see com.bcbssc.netsys.jndi.DirectoryObject#commit(ModificationItem[])
	 * @see com.bcbssc.netsys.jndi.DirectoryObject#updateAttribute(String,Object)
	 * @see com.bcbssc.netsys.jndi.DirectoryObject#commit(ModificationItem[])
	 */
	public void updateValues(String samAccountName, Map attributes)
			throws NamingException, FileNotFoundException,
			MissingPropertyException {
		if (logger.isDebugEnabled()) {
			logger
					.debug("AbstractProfileManagementService.updateValues attributes="
							+ attributes);
		}

		ModificationItem[] mods = new ModificationItem[attributes.size()];
		Iterator attrs = attributes.keySet().iterator();
		String userDN = "uid="
				+ samAccountName
				+ ","
				+ Config.getPrivateProfileString(Constants.INI_LOCAL_SECTION,
						Constants.INI_PEOPLE_BASE,
						com.bcbssc.struts.common.Constants.BLANK_STRING,
						this.iniFile);

		LdapUser ldapObject = ProfileManagementService.Factory
				.getLdapUserInstance(userDN, tdsIniFile);

		int i = 0;
		while (attrs.hasNext()) {
			String key = (String) attrs.next();
			mods[i++] = ldapObject.updateAttribute(key, attributes.get(key));

		}
		ldapObject.commit(mods);
	}

	/**
	 * This method creates UserDTO object from ldap attributes
	 *
	 * @param userAttributes
	 *            LdapUser object which contains ldap attributes for that user
	 * @return UserDTO
	 * @throws java.lang.Exception if any.
	 */
	protected abstract UserDTO createUserFromLdapAttributes(
			LdapUser userAttributes) throws Exception;

	/**
	 * {@inheritDoc}
	 *
	 * This method creates ONTCred cookie
	 */
	public void writeOntCredCookie(String samAccountName,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		if (logger.isDebugEnabled()) {
			logger
					.debug("AbstractProfileManagementService.writeOntCredCookie samAccountName="
							+ samAccountName);
		}

		// delete RACF and ONTCred cookies

		deleteCookies(request, response);

		UserDTO user = null;
		String userDN = "uid="
				+ samAccountName
				+ ","
				+ Config.getPrivateProfileString(Constants.INI_LOCAL_SECTION,
						Constants.TDS_LDAP_SEARCH_BASE,
						com.bcbssc.struts.common.Constants.BLANK_STRING,
						this.tdsIniFile);

		String domain = Config.getPrivateProfileString(
				Constants.INI_COOKIE_SECTION, Constants.INI_AUTH_COOKIE_DOMAIN,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		String cookieKey = Config.getPrivateProfileString(
				Constants.INI_COOKIE_SECTION, Constants.INI_AUTH_COOKIE_KEY,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		String cookieIV = Config.getPrivateProfileString(
				Constants.INI_COOKIE_SECTION, Constants.INI_AUTH_COOKIE_IV,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		LdapUser ldapObject = ProfileManagementService.Factory
				.getLdapUserInstance(userDN, tdsIniFile);

		user = this.createUserFromLdapAttributes(ldapObject);

		CookieUtil cookieObject = new CookieUtil(cookieKey, cookieIV, domain,
				"/");

		cookieObject.setCredentialCookie(request, response, user);

	}

	/**
	 * {@inheritDoc}
	 *
	 * This method creates RACF cookie
	 */
	public void writeRACFCookie(String racfId, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		if (logger.isDebugEnabled()) {
			logger.debug("AbstractProfileManagementService.writeOntCredCookie racfId="
					+ racfId);
		}

		String domain = Config.getPrivateProfileString(
				Constants.INI_COOKIE_SECTION, Constants.INI_AUTH_COOKIE_DOMAIN,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		String cookieKey = Config.getPrivateProfileString(
				Constants.INI_COOKIE_SECTION, Constants.INI_AUTH_COOKIE_KEY,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		String cookieIV = Config.getPrivateProfileString(
				Constants.INI_COOKIE_SECTION, Constants.INI_AUTH_COOKIE_IV,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		CookieUtil cookieObject = new CookieUtil(cookieKey, cookieIV, domain,
				"/");

		cookieObject.setRACFCookie(request, response, racfId);

	}

	/**
	 * {@inheritDoc}
	 *
	 * This method creates a cookie
	 */
	public void writeCookie(String cookieName, String cookieValue,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		if (logger.isDebugEnabled()) {
			logger.debug("AbstractProfileManagementService.writeCookie cookieName "
					+ cookieName + ",cookieValue=" + cookieValue);
		}

		String domain = Config.getPrivateProfileString(
				Constants.INI_COOKIE_SECTION, Constants.INI_AUTH_COOKIE_DOMAIN,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		String cookieKey = Config.getPrivateProfileString(
				Constants.INI_COOKIE_SECTION, Constants.INI_AUTH_COOKIE_KEY,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		String cookieIV = Config.getPrivateProfileString(
				Constants.INI_COOKIE_SECTION, Constants.INI_AUTH_COOKIE_IV,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		CookieUtil cookieObject = new CookieUtil(cookieKey, cookieIV, domain,
				"/");

		cookieObject.setCookie(response, cookieName, cookieValue, null);

	}

	/**
	 * This mehtod deletes RACF cookie and ONTCred cookies before createing new
	 * RACF or ONTCred cookies
	 */

	private void deleteCookies(HttpServletRequest request,
			HttpServletResponse response) {
		if (logger.isDebugEnabled()) {
			logger.debug("AbstractProfileManagementService.deleteCookie");
		}
		String domain = Config.getPrivateProfileString(
				Constants.INI_COOKIE_SECTION, Constants.INI_AUTH_COOKIE_DOMAIN,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		String cookieKey = Config.getPrivateProfileString(
				Constants.INI_COOKIE_SECTION, Constants.INI_AUTH_COOKIE_KEY,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		String cookieIV = Config.getPrivateProfileString(
				Constants.INI_COOKIE_SECTION, Constants.INI_AUTH_COOKIE_IV,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		CookieUtil cookieObject = new CookieUtil(cookieKey, cookieIV, domain,
				"/");

		cookieObject.deleteCookie(request, response,
				Constants.COOKIE_SUPERUSER_RACF);
		cookieObject.deleteCookie(request, response, Constants.COOKIE_ONT_CRED);
	}

	/**
	 * {@inheritDoc}
	 *
	 * This method returns roles for the user to build the Top nav
	 */
	public String getRoles(String samAccountName) throws FileNotFoundException,
			NamingException, MissingPropertyException {

		if (logger.isDebugEnabled()) {
			logger
					.debug("AbstractProfileManagementService getRoles samAccountName="
							+ samAccountName
							+ ",iniFile="
							+ iniFile
							+ ",tdsIniFile=" + tdsIniFile);
		}

		String userRoleDN = "uid="
				+ samAccountName
				+ ","
				+ Config.getPrivateProfileString(Constants.INI_LOCAL_SECTION,
						Constants.INI_PEOPLE_BASE,
						com.bcbssc.struts.common.Constants.BLANK_STRING,
						this.iniFile);

		String roleBaseDN = Config.getPrivateProfileString(
				Constants.INI_LOCAL_SECTION, Constants.INI_ROLE_BASE,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		String baseDN = Config.getPrivateProfileString(
				Constants.INI_LOCAL_SECTION, Constants.TDS_BASE,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		Properties config = LdapConfig.getLdapConfig(tdsIniFile);
		config.remove(Constants.TDS_LDAP_BASE);
		config.remove(Constants.TDS_LDAP_SEARCH_BASE);
		config.put(Constants.TDS_LDAP_BASE, baseDN);
		config.put(Constants.TDS_LDAP_SEARCH_BASE, roleBaseDN);

		Object[] params = { "member", userRoleDN };
		String searchStr = MessageFormat.format("(&({0}={1}))", params);
		config.put(DirectorySearchFilter.SEARCH_FILTER, searchStr);
		DirectorySearchFilter filter = new DirectorySearchFilter(config);

		Collection results = DirectoryObject.search(config, filter);

		Iterator itr = results.iterator();
		StringBuffer sbRoles = new StringBuffer();
		
		while (itr.hasNext()) {
			DirectoryObject ob1 = (DirectoryObject) itr.next();
		    String role = (String) ob1.getAttribute("cn");
			sbRoles.append(role);
			sbRoles.append("|");

		}
       
		return sbRoles.toString();

	}
	
	
	/**
	 * This method returns roles for the user to build the Top nav
	 *
	 * @param samAccountName a {@link java.lang.String} object.
	 * @return String containing roles
	 * @throws java.io.FileNotFoundException if any.
	 * @throws javax.naming.NamingException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 */
	public String getSuperUserRoles(String samAccountName) throws FileNotFoundException,
			NamingException, MissingPropertyException {

		if (logger.isDebugEnabled()) {
			logger
					.debug("AbstractProfileManagementService getRoles samAccountName="
							+ samAccountName
							+ ",iniFile="
							+ iniFile
							+ ",tdsIniFile=" + tdsIniFile);
		}

		
		
		
		String userRoleDN = "uid="
				+ samAccountName
				+ ","
				+ Config.getPrivateProfileString(Constants.INI_LOCAL_SECTION,
						Constants.INI_SUPERUSER_PEOPLE_BASE,
						com.bcbssc.struts.common.Constants.BLANK_STRING,
						this.iniFile);
		
		String roleBaseDN = Config.getPrivateProfileString(
				Constants.INI_LOCAL_SECTION, Constants.INI_SUPERUSER_ROLE_BASE,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);
		
		String baseDN = Config.getPrivateProfileString(
				Constants.INI_LOCAL_SECTION, Constants.TDS_SUPERUSER_BASE,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);
		
		Properties config = LdapConfig.getLdapConfig(tdsIniFile);
		config.remove(Constants.TDS_LDAP_SUPERUSER_BASE);
		config.remove(Constants.TDS_LDAP_SUPERUSER_SEARCH_BASE);
		config.put(Constants.TDS_LDAP_SUPERUSER_BASE, baseDN);
		config.put(Constants.TDS_LDAP_SUPERUSER_SEARCH_BASE, roleBaseDN);

		Object[] params = { "member", userRoleDN };
		String searchStr = MessageFormat.format("(&({0}={1}))", params);
		config.put(DirectorySearchFilter.SEARCH_FILTER, searchStr);
		DirectorySearchFilter filter = new DirectorySearchFilter(config);

		Collection results = DirectoryObject.search(config, filter);

		Iterator itr = results.iterator();
		StringBuffer sbRoles = new StringBuffer();
		
		while (itr.hasNext()) {
			DirectoryObject ob1 = (DirectoryObject) itr.next();
		    String role = (String) ob1.getAttribute("cn");
		    sbRoles.append(role);
			sbRoles.append("|");

		}
       
		return sbRoles.toString();

	}

	/**
	 * Gets the samAccountName from the DN
	 *
	 * @param distinguishedName
	 *            user DN
	 * @return the samAccountName contained in the DN
	 */
	public static String getSamAccountNameFromDN(String distinguishedName) {
		int startIndex = distinguishedName.indexOf('=') + 1;
		int endIndex = distinguishedName.indexOf(',');
		return distinguishedName.substring(startIndex, endIndex);
	}

}
