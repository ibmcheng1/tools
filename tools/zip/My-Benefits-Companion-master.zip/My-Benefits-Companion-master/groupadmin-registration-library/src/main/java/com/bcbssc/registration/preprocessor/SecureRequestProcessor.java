/*
 * @(#)SecureRequestProcessor.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.registration.preprocessor;

import com.bcbssc.registration.common.Constants;
import com.bcbssc.registration.dto.UserDTO;
import com.bcbssc.registration.permissions.RolePermissionsAdapter;
import com.bcbssc.registration.services.ISecureServices;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.navigator.menu.PermissionsAdapter;

import org.apache.log4j.Logger;
import org.apache.struts.action.RequestProcessor;
import org.apache.struts.config.ForwardConfig;

/**
 * Shared Registration Abstract Secure Request Processor
 *
 * This abstract class provides user creation based on the encrypted cookie
 * value. Additionally, it will set the menu permissions based on the user's
 * role. Secure-side request processors should extend this class.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public abstract class SecureRequestProcessor extends RequestProcessor {

	/** log4j logger */
	private static Logger logger = Logger
			.getLogger(SecureRequestProcessor.class);

	/**
	 * Creates an application-specific services object
	 *
	 * @return services object
	 */
	protected abstract ISecureServices getServices();

	/** {@inheritDoc} */
	protected boolean processPreprocess(HttpServletRequest request,
			HttpServletResponse response) {

		if (SecureRequestProcessor.logger.isDebugEnabled()) {
			SecureRequestProcessor.logger
					.debug("Executing SecureRequestProcessor.processPreprocess()");
		}

		boolean continueProcessing = true;

		HttpSession session = request.getSession();
		if (SecureRequestProcessor.logger.isDebugEnabled()) {
			SecureRequestProcessor.logger.debug("processPreprocess() "
					+ session.getId());
		}

		boolean readUserInfo = false;
		UserDTO user = null;

		Object userObject = session.getAttribute(Constants.USER_DTO);
		if ((userObject != null) && (userObject instanceof UserDTO)) {
			// use the object from the session
			SecureRequestProcessor.logger.debug("user dto = " + userObject);
			user = (UserDTO) userObject;
		}
		if (user == null) {
			readUserInfo = true;

			String szontcred = com.bcbssc.struts.common.CommonUtils.readCookie(
					Constants.COOKIE_ONT_CRED, request);
			String superuserracf = com.bcbssc.struts.common.CommonUtils
					.readCookie(Constants.COOKIE_SUPERUSER_RACF, request);
			String superusertype = com.bcbssc.struts.common.CommonUtils
					.readCookie(Constants.COOKIE_SUPERUSER_TYPE, request);
			ISecureServices services = this.getServices();

			try {
				user = services.getUserFromCookies(szontcred, superuserracf,
						superusertype);
			} catch (Exception ex) {
				SecureRequestProcessor.logger.error(
						"Unable to create user from cookie", ex);
			}
		}

		if (user != null) {
			SecureRequestProcessor.logger
					.debug("In PermissionsRequestProcessor; user is: "
							+ user.getSamAccountName());
			// Cookie is valid, set permissions adapter and user data
			PermissionsAdapter permissions = new RolePermissionsAdapter(user);
			request.setAttribute("permissionsAdapter", permissions);
			request.setAttribute(Constants.USER_DTO, user);

			if (readUserInfo) {
				session.setAttribute(Constants.USER_DTO, user);
			}

		} else {
			// Cookie is invalid; security error
			continueProcessing = false;

			SecureRequestProcessor.logger
					.error("securityforward: "
							+ this.moduleConfig
									.findForwardConfig(Constants.FORWARD_SECURITY_ERROR));

			ForwardConfig config = this.moduleConfig
					.findForwardConfig(Constants.FORWARD_SECURITY_ERROR);
			try {
				response.sendRedirect(config.getPath());
			} catch (Exception ex) {
				SecureRequestProcessor.logger
						.error(
								"Problem sending security error redirect from processPreprocess()",
								ex);
			}
		}

		return continueProcessing;
	}
}
