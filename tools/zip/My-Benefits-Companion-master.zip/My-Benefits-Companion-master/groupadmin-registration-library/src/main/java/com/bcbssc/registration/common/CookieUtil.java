/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUE CROSS AND BLUE SHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION, OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright (c) 2005 Blue Cross and Blue Shield of South Carolina.
 * All rights reserved.
 * An independent Licensee of the Blue Cross and Blue Shield Association.
 *
 * CookieUtil.java
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-registration/src/main/java/com/bcbssc/registration/common/CookieUtil.java_v  $
 * $Workfile:   CookieUtil.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 29 2010 08:58:04  $
 * $Modtime:   Jun 24 2010 17:32:50  $
 */
package com.bcbssc.registration.common;

import java.text.MessageFormat;
import java.util.Calendar;
import java.util.TimeZone;

import javax.naming.NamingException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.bcbssc.registration.crypt.BcbsScCipherException;
import com.bcbssc.registration.crypt.EncryptorConstants;
import com.bcbssc.registration.crypt.SymmetricCipher;
import com.bcbssc.netsys.jndi.MissingPropertyException;
import com.bcbssc.registration.dto.UserDTO;

/**
 * Manipulates HTTP cookies and the authentication credential cookie required by
 * the Enrollment site.
 *
 * @author CF90 (T. Zengerle)
 * @author X22A (B. Smith)
 * @author X94S (Rao Peddi)
 * @version $Revision:   1.0  $
 */
public class CookieUtil {
	private static final Logger log = Logger.getLogger(CookieUtil.class);

	/**
	 * The name of the credential cookie
	 */
	public static final String CREDENTIAL_COOKIE = "ONTCred";

	/** Constant <code>COOKIE_SUPERUSER_RACF="RACF"</code> */
	public static final String COOKIE_SUPERUSER_RACF = "RACF";

	private String key;
	private String initVector;
	private String domain;
	private String path;

	/**
	 * Creates a new <code>CookieUtil</code> object.
	 *
	 * @param key
	 *            the cipher key
	 * @param initVector
	 *            the initialization vector
	 * @param domain
	 *            the cookie domain
	 * @param path
	 *            the cookie path
	 */
	public CookieUtil(String key, String initVector, String domain, String path) {
		this.key = key;
		this.initVector = initVector;
		this.domain = domain;
		this.path = path;

	}

	/**
	 * Retrieves the cipher key for this <code>CookieUtil</code>.
	 *
	 * @return the cipher key for this <code>CookieUtil</code>
	 */
	public String getCookieKey() {
		return key;
	}

	/**
	 * Retrieves the initialization vector for this <code>CookieUtil</code>.
	 *
	 * @return the initialization vector for this <code>CookieUtil</code>
	 */
	public String getCookieIV() {
		return initVector;
	}

	/**
	 * Retrieves the domain for this <code>CookieUtil</code>.
	 *
	 * @return the domain for this <code>CookieUtil</code>
	 */
	public String getCookieDomain() {
		return domain;
	}

	/**
	 * Retrieves the path for this <code>CookieUtil</code>.
	 *
	 * @return the path for this <code>CookieUtil</code>
	 */
	public String getCookiePath() {
		return path;
	}

	/**
	 * Creates a cookie with the given name, value, and expiration and stores it
	 * in the given response.
	 *
	 * @param response
	 *            <code>HttpServletResponse</code> to which output will be
	 *            directed
	 * @param name
	 *            name of the cookie being created
	 * @param value
	 *            value of the cookie being created
	 * @param expires
	 *            expiration time of the cookie being created
	 * @return the created {@link javax.servlet.http.Cookie}
	 */
	public Cookie setCookie(HttpServletResponse response, String name,
			String value, Integer expires) {
		if (log.isDebugEnabled()) {
			final Object[] params = { value,
					expires == null ? null : expires.toString(),
					this.getCookieDomain(), this.getCookiePath() };
			StringBuffer msg = new StringBuffer(150);
			msg.append("[Cookie Settings]\n");
			msg.append("\tValue [{0}]\n");
			msg.append("\tExpiration [{1}]\n");
			msg.append("\tDomain [{2}]\n");
			msg.append("\tPath [{3}]\n");
			log.debug(MessageFormat.format(msg.toString(), params));
		}

		Cookie cookie = new Cookie(name, value);
		cookie.setPath(this.getCookiePath());
		cookie.setDomain(this.getCookieDomain());

		if (expires != null) {
			cookie.setMaxAge(expires.intValue());
		}

		response.addCookie(cookie);
		return cookie;
	}

	/**
	 * Creates the credential cookie and places it in the response.
	 *
	 * @param request
	 *            an <code>HttpServletRequest</code> object that contains the
	 *            request the client has made of the servlet
	 * @param response
	 *            <code>HttpServletResponse</code> to which output will be
	 *            directed
	 * @param user
	 *            <code>User</code> to create a credential cookie for
	 * @return the created credential cookie
	 * @see #setCookie
	 * @throws com.bcbssc.registration.crypt.BcbsScCipherException if any.
	 * @throws javax.naming.NamingException if any.
	 */
	public Cookie setCredentialCookie(HttpServletRequest request,
			HttpServletResponse response, UserDTO user)
			throws BcbsScCipherException, NamingException {
		final String delimiter = "\t";
		StringBuffer plainTextCookie = new StringBuffer(100);
		String encryptedCookie = null;

		if (log.isDebugEnabled()) {
			final Object[] params = { user.getSamAccountName(),
					request.getRemoteAddr(), this.getCookieDomain(),
					new String(this.getCookieKey()),
					new String(this.getCookieIV()) };
			StringBuffer msg = new StringBuffer(256);
			msg.append("[Credential Cookie Parameters]\n");
			msg.append("\tUser ID [{0}]\n");
			msg.append("\tIP Address [{1}]\n");
			msg.append("\tCookie Domain [{2}]\n");
			msg.append("\tCookie Key [{3}]\n");
			msg.append("\tCookie IV [{4}]\n");
			log.debug(MessageFormat.format(msg.toString(), params));
		}

		Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
		plainTextCookie.append(user.getSamAccountName());
		plainTextCookie.append(delimiter);
		plainTextCookie.append(request.getRemoteAddr());
		plainTextCookie.append(delimiter);
		plainTextCookie.append(cal.getTime().getTime() / 1000);
		plainTextCookie.append(delimiter);
		plainTextCookie.append(Constants.EMPTY_STRING);
		plainTextCookie.append(delimiter);
		plainTextCookie.append("BASIC");

		try {
			SymmetricCipher cipher = new SymmetricCipher(this.getCookieKey(),
					this.getCookieIV(), SymmetricCipher.HEXADECIMAL_ENCODING,
					EncryptorConstants.BLOWFISH_CBC_PKCS5PADDING);
			byte[] encryptedBytes = cipher.encrypt(plainTextCookie.toString()
					.getBytes());

			encryptedCookie = new String(SymmetricCipher.encode(encryptedBytes,
					SymmetricCipher.HEXADECIMAL_ENCODING));

			if (log.isDebugEnabled()) {
				log.debug("Encrypted Cookie [" + encryptedCookie + "]");
			}
		} catch (ExceptionInInitializerError err) {
			log.error("Error", err.getException());
			throw err;
		} catch (Exception usee) {
			throw new BcbsScCipherException(usee);
		}

		return this.setCookie(response, Constants.COOKIE_ONT_CRED,
				encryptedCookie, null);
	}

	/**
	 * <p>setRACFCookie.</p>
	 *
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @param response a {@link javax.servlet.http.HttpServletResponse} object.
	 * @param racfId a {@link java.lang.String} object.
	 * @return a {@link javax.servlet.http.Cookie} object.
	 * @throws com.bcbssc.registration.crypt.BcbsScCipherException if any.
	 * @throws javax.naming.NamingException if any.
	 */
	public Cookie setRACFCookie(HttpServletRequest request,
			HttpServletResponse response, String racfId)
			throws BcbsScCipherException, NamingException {

		final String delimiter = "\t";
		StringBuffer plainTextCookie = new StringBuffer(100);
		String encryptedCookie = null;

		if (log.isDebugEnabled()) {
			final Object[] params = { racfId, request.getRemoteAddr(),
					this.getCookieDomain(), new String(this.getCookieKey()),
					new String(this.getCookieIV()) };
			StringBuffer msg = new StringBuffer(256);
			msg.append("[Credential Cookie Parameters]\n");
			msg.append("\tUser ID [{0}]\n");
			msg.append("\tIP Address [{1}]\n");
			msg.append("\tCookie Domain [{2}]\n");
			msg.append("\tCookie Key [{3}]\n");
			msg.append("\tCookie IV [{4}]\n");
			log.debug(MessageFormat.format(msg.toString(), params));
		}

		Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
		plainTextCookie.append(racfId);
		plainTextCookie.append(delimiter);
		plainTextCookie.append(request.getRemoteAddr());
		plainTextCookie.append(delimiter);
		plainTextCookie.append(cal.getTime().getTime() / 1000);
		plainTextCookie.append(delimiter);
		plainTextCookie.append(Constants.EMPTY_STRING);
		plainTextCookie.append(delimiter);
		plainTextCookie.append("BASIC");

		try {
			SymmetricCipher cipher = new SymmetricCipher(this.getCookieKey(),
					this.getCookieIV(), SymmetricCipher.HEXADECIMAL_ENCODING,
					EncryptorConstants.BLOWFISH_CBC_PKCS5PADDING);
			byte[] encryptedBytes = cipher.encrypt(plainTextCookie.toString()
					.getBytes());

			encryptedCookie = new String(SymmetricCipher.encode(encryptedBytes,
					SymmetricCipher.HEXADECIMAL_ENCODING));

			if (log.isDebugEnabled()) {
				log.debug("Encrypted Cookie [" + encryptedCookie + "]");
			}
		} catch (ExceptionInInitializerError err) {
			log.error("Error", err.getException());
			throw err;
		} catch (Exception usee) {
			throw new BcbsScCipherException(usee);
		}

		return this.setCookie(response, Constants.COOKIE_SUPERUSER_RACF,
				encryptedCookie, null);

	}

	/**
	 * Removes the given cookie from the given request.
	 *
	 * @param request
	 *            an <code>HttpServletRequest</code> object that contains the
	 *            request the client has made of the servlet
	 * @param response
	 *            <code>HttpServletResponse</code> to which output will be
	 *            directed
	 * @param name
	 *            name of the cookie being deleted
	 */
	public void deleteCookie(HttpServletRequest request,
			HttpServletResponse response, String name) {
		Cookie cookie = getCookie(request, name);
		if (cookie != null) {
			this.setCookie(response, name, cookie.getValue(), new Integer(0));
		}
		if (log.isDebugEnabled()) {
			log.debug("Removed cookie [" + name + "].");
		}
	}

	/**
	 * Removes the credential cookie from the given request.
	 *
	 * @param request
	 *            an <code>HttpServletRequest</code> object that contains the
	 *            request the client has made of the servlet
	 * @param response
	 *            <code>HttpServletResponse</code> to which output will be
	 *            directed
	 */
	public void deleteCredentialCookie(HttpServletRequest request,
			HttpServletResponse response) {
		this.deleteCookie(request, response, CREDENTIAL_COOKIE);
	}

	/**
	 * Retrieves a <code>User</code> from the credential cookie in the
	 * given request.
	 *
	 * @param request
	 *            an <code>HttpServletRequest</code> object that contains the
	 *            request the client has made of the servlet
	 * @return a <code>User</code> from the credential cookie in the
	 *         given request; <code>null</code> if no credential cookie exists
	 *         in the given request or if the cookie could not be properly
	 *         decrypted
	 * @throws com.bcbssc.registration.crypt.BcbsScCipherException if any.
	 * @throws javax.naming.NamingException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 */
	public String getUserNameFromCredentialCookie(HttpServletRequest request)
			throws BcbsScCipherException, NamingException,
			MissingPropertyException {
		// UserDTO user = null;
		String samAccountName = null;
		try {

			Cookie cookie = getCredentialCookie(request);

			if (cookie != null) {
				log.debug("Found credential cookie.");
				byte[] decodedBytes = null;

				decodedBytes = SymmetricCipher.decode(cookie.getValue()
						.getBytes(), SymmetricCipher.HEXADECIMAL_ENCODING);
				SymmetricCipher cipher = new SymmetricCipher(this
						.getCookieKey(), this.getCookieIV(),
						SymmetricCipher.HEXADECIMAL_ENCODING,
						EncryptorConstants.BLOWFISH_CBC_PKCS5PADDING);
				String dn = new String(cipher.decrypt(decodedBytes));

				if (log.isDebugEnabled()) {
					log.debug("Decrypted value [" + dn + "]");
				}

				dn = dn.substring(0, dn.indexOf('\t'));

				if (log.isDebugEnabled()) {
					log.debug("Found distinguished name [" + dn
							+ "] in credential cookie.");
				}

				samAccountName = StringUtils.substringBetween(dn, "uid=", ",");
				final String userType = StringUtils.substringBetween(dn, "ou=",
						",");

				if (log.isDebugEnabled()) {
					log.debug("Retrieved UserID [" + samAccountName
							+ "] from distinguished name.");
					log.debug("Retrieved userType [" + userType
							+ "] from distinguished name.");
				}
				// user = ProfileManagementService.Factory.getInstance("", "");
			}

		} catch (DecoderException de) {
			throw new BcbsScCipherException(de);
		} catch (Exception usee) {
				throw new BcbsScCipherException(usee);
		} 		

		return samAccountName;
	}

	/**
	 * <p>getUserNameFromCredentialCookie.</p>
	 *
	 * @param encryptedCookie a {@link java.lang.String} object.
	 * @return a {@link java.lang.String} object.
	 * @throws com.bcbssc.registration.crypt.BcbsScCipherException if any.
	 * @throws javax.naming.NamingException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 */
	public String getUserNameFromCredentialCookie(String encryptedCookie)
			throws BcbsScCipherException, NamingException,
			MissingPropertyException {
		String samAccountName = null;
		try {

			byte[] decodedBytes = null;

			decodedBytes = SymmetricCipher.decode(encryptedCookie.getBytes(),
					SymmetricCipher.HEXADECIMAL_ENCODING);
			SymmetricCipher cipher = new SymmetricCipher(this.getCookieKey(),
					this.getCookieIV(), SymmetricCipher.HEXADECIMAL_ENCODING,
					EncryptorConstants.BLOWFISH_CBC_PKCS5PADDING);
			samAccountName = new String(cipher.decrypt(decodedBytes));

			if (log.isDebugEnabled()) {
				log.debug("Decrypted value [" + samAccountName + "]");
			}

			samAccountName = samAccountName.substring(0, samAccountName
					.indexOf('\t'));

			if (log.isDebugEnabled()) {
				log.debug("Found distinguished name [" + samAccountName
						+ "] in credential cookie.");
			}

			if (log.isDebugEnabled()) {
				log.debug("Retrieved UserID [" + samAccountName);

			}
			
		}  catch (DecoderException de) {
			throw new BcbsScCipherException(de);
		}
		catch (Exception usee) {
				throw new BcbsScCipherException(usee);
		}

		return samAccountName;
	}

	/**
	 * Retrieves the specified cookie from the given request.
	 *
	 * @param request
	 *            an <code>HttpServletRequest</code> object that contains the
	 *            request the client has made of the servlet
	 * @param name
	 *            name of the cookie to retrieve
	 * @return the specified cookie from the given request; <code>null</code> if
	 *         no cookie with the specified name exists in the given request
	 */
	public static Cookie getCookie(HttpServletRequest request, String name) {
		Cookie cookie = null;
		Cookie[] cookies = request.getCookies();

		if (cookies != null) {

			for (int i = 0; i < cookies.length; i++) {
				if (cookies[i].getName().equalsIgnoreCase(name)) {
					cookie = cookies[i];
					break;
				}
			}
		}

		return cookie;
	}

	/**
	 * Retrieves the credential cookie from the given request.
	 *
	 * @param request
	 *            an <code>HttpServletRequest</code> object that contains the
	 *            request the client has made of the servlet
	 * @return the credential cookie from the given request; <code>null</code>
	 *         if no credential cookie exists in the given request
	 */
	public static Cookie getCredentialCookie(HttpServletRequest request) {
		return getCookie(request, CREDENTIAL_COOKIE);
	}
}
