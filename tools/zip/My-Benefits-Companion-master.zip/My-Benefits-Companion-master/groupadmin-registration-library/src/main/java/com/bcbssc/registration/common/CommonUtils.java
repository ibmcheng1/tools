/*
 *
 * @(#)CommonUtils.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.registration.common;

import com.bcbssc.registration.dto.UserDTO;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletContext;

import org.apache.commons.beanutils.BeanUtils;

/**
 * Common Registration Utilities
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class CommonUtils extends com.bcbssc.struts.common.CommonUtils {

	/** logger object is instantiated by the super class * */

	/**
	 * Gets the applications INI file
	 *
	 * @return INI file name
	 * @param context a {@link javax.servlet.ServletContext} object.
	 */
	public static String getIniFile(ServletContext context) {
		return (String) context.getAttribute(Constants.INI_PARAMETER_NAME);
	}

	/**
	 * Generates Java code in the log file that can be used to debug user
	 * errors.
	 *
	 * @param user
	 *            user
	 */
	public static void printErrorUserCode(UserDTO user) {
		Map map;
		try {
			map = BeanUtils.describe(user);
		} catch (Exception e) {
			com.bcbssc.struts.common.CommonUtils.logger.error("Unable to describe failed user.");
			return;
		}

		com.bcbssc.struts.common.CommonUtils.logger.error("Use this code to create the failed user: ");
		Set set = map.keySet();
		Iterator iter = set.iterator();
		while (iter.hasNext()) {
			String name = (String) iter.next();
			String value = (String) map.get(name);
			if (!"class".equalsIgnoreCase(name)) {
				StringBuffer errMsg = new StringBuffer(64);
				errMsg.append("user.set").append(
						name.substring(0, 1).toUpperCase());
				errMsg.append(name.substring(1)).append("(\"").append(value)
						.append("\");");
				com.bcbssc.struts.common.CommonUtils.logger.error(errMsg.toString());
			}
		}
	}

	/**
	 * Filter out special DB2 dates and return a blank string as necessary
	 *
	 * @param dateValue a {@link java.lang.String} object.
	 * @return a {@link java.lang.String} object.
	 */
	public static String filterDB2Date(String dateValue) {
		String returnString = null;
		// check for special date values from DB2 that should not be displayed
		if ("01/01/0001".equals(dateValue)) {
			returnString = com.bcbssc.struts.common.Constants.BLANK_STRING;
		} else {
			returnString = dateValue;
		}
		return returnString;
	}
}
