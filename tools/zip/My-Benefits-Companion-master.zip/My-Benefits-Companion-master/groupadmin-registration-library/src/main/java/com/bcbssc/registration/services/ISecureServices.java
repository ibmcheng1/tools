/*
 * @(#)ISecureServices.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.registration.services;

import com.bcbssc.registration.dto.UserDTO;

/**
 * Secure Services
 *
 * This interface declares the methods that the shared secure-side actions
 * require from appliation-specific services.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public interface ISecureServices {

    /**
     * Gets a user described by a encrypted user cookie
     *
     * @param szontcred encrypted user cookie
     * @return ldap user specified by the cookie
     * @throws java.lang.Exception if any.
     */
    public UserDTO getUserFromCookie(String szontcred) throws Exception;

    /**
     * Gets a user described by the encrypted user cookie and the superuser
     * cookies.
     *
     * @param szontcred encrypted user cookie
     * @param racfCookie racf cookie value
     * @param suType superuser type cookie value
     * @return ldap user specified by the cookie
     * @throws java.lang.Exception if any.
     */
    public UserDTO getUserFromCookies(String szontcred, String racfCookie, 
                                      String suType) 
        throws Exception;    
    
	/**
	 * Populates the form DTO based on the ONTCred cookie value
	 *
	 * @param dto  an application-specific form object
	 * @param user  the user described by the encrypted cookie
	 * @throws java.lang.Exception if any.
	 */
	public void populateForm(Object dto, UserDTO user) throws Exception;  
    
	/**
	 * Change the password for the user described by the ONTCred cookie value
	 *
	 * @param dto  an application-specific form object
	 * @param user  the user described by the encrypted cookie
	 * @return a boolean.
	 * @throws java.lang.Exception if any.
	 */
	public boolean changePassword(Object dto, UserDTO user) throws Exception;      
}
