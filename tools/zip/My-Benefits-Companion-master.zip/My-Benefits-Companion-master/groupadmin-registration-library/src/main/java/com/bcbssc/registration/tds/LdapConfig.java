package com.bcbssc.registration.tds;

import java.io.FileNotFoundException;
import java.util.Properties;
import java.util.Map;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import org.apache.log4j.Logger;
import com.bcbssc.netsys.Config;
import com.bcbssc.netsys.jndi.DirectoryObject;
import com.bcbssc.registration.common.Constants;
import com.bcbssc.netsys.jndi.MissingPropertyException;



/**
 * <p>LdapConfig class.</p>
 *
 * @author X94S
 *This class reads TDS.ini file which has ldap connection information and populates in Properties object.
 * @version $Id: $Id
 */
public class LdapConfig {


	private static Logger log = Logger
			.getLogger(LdapConfig.class);

	/** Constant <code>INI_LOCAL_SECTION="Constants.INI_LOCAL_SECTION"</code> */
	public static final String INI_LOCAL_SECTION = Constants.INI_LOCAL_SECTION;
	/**
	* constant value representing the key for retrieving the directory base from
	* configuration properties
	*/
    public static final String CONTEXT_BASE = "com.bcbssc.jndi.base";
	/**
	* constant value representing the key for retrieving an SSL connection URL
	* from configuration properties
	*/
    public static final String PROVIDER_URL_SSL = Context.PROVIDER_URL + ".ssl";

	/**
	 * <p>getLdapConfig.</p>
	 *
	 * @param tdsIniFile a {@link java.lang.String} object.
	 * @return a {@link java.util.Properties} object.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public static Properties getLdapConfig(String tdsIniFile)throws FileNotFoundException{
	final Properties config = new Properties();
	config.putAll(Config.getConfigSection(INI_LOCAL_SECTION, tdsIniFile));
	return config;
	}


	/**
	 * <p>loadSecureLdapConfig.</p>
	 *
	 * @param tdsIniFile a {@link java.lang.String} object.
	 * @throws java.io.FileNotFoundException if any.
	 * @throws javax.naming.NamingException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	 */
	public static void loadSecureLdapConfig(String tdsIniFile) throws FileNotFoundException,NamingException,MissingPropertyException{

		 Properties config = LdapConfig.getLdapConfig(tdsIniFile);
		 validateConfig(config);
         checkProperty(PROVIDER_URL_SSL, config);





		 Properties configuration = new Properties();
		        configuration.putAll(config);

		        if(log.isDebugEnabled()){
		            log.debug("Admin User [" + configuration.get(Context.SECURITY_PRINCIPAL) + "]");
		            if(configuration.get(Context.SECURITY_CREDENTIALS) != null){
		                log.debug("Admin password not shown.");
		            }else{
		                log.warn("No admin password retrieved!");
		            }
		            if(log.isDebugEnabled()){
		                log.debug("Initial Context Factory [" + configuration.get(Context.INITIAL_CONTEXT_FACTORY) + "]");
		            }
		        }

		        if(configuration.getProperty(DirectoryObject.SSL_TRUST_STORE) != null){
		            if(log.isDebugEnabled()){
		                log.debug("Keystore [" + configuration.get(DirectoryObject.SSL_TRUST_STORE) + "]");
		            }
		            // Set the Java trust store
		            System.setProperty(DirectoryObject.SSL_TRUST_STORE, configuration.getProperty(DirectoryObject.SSL_TRUST_STORE));
		        }

		        // Set the SSL LDAP URL
		        configuration.put(Context.PROVIDER_URL, configuration.get(DirectoryObject.PROVIDER_URL_SSL));

		        if(log.isDebugEnabled()){
		            log.debug(Context.PROVIDER_URL + " [" + configuration.get(Context.PROVIDER_URL) + "]");
		        }

		        // Set the security protocol to use SSL
		        configuration.put(Context.SECURITY_PROTOCOL, "ssl");
		        if(log.isDebugEnabled()){
		            log.debug(Context.SECURITY_PROTOCOL + "[" + configuration.get(Context.SECURITY_PROTOCOL) + "]");
		        }

		        DirContext ctx = null;
		        try{
		            ctx = DirectoryObject.getDirContext(configuration);


		        } catch(NamingException ex){
		            ex.printStackTrace();
		            throw ex;
		        }finally{
		            closeConnection(ctx);

                }




	}

	    /**
	     * attemts to close the given Context if it is not <code>null</code>
	     *
	     * @param ctx <code>{@link javax.naming.Context}</code> to close
	     * @throws javax.naming.NamingException if any.
	     */
	    protected static void closeConnection(Context ctx) throws NamingException{
	        if(ctx != null){
	            ctx.close();
	        }
	    }

	    /**
	     * checks for the existence of the given property in the given configuration
	     *
	     * @param property name of the parameter to check
	     * @param config configuration to check for the given property
	     * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	     */
	    protected static void checkProperty(String property, Map config) throws MissingPropertyException{
	        if((config.get(property) == null) || "".equals(config.get(property))){
	            throw new MissingPropertyException(property);
	        }
	    }

	    /**
	     * validates a configuration to insure it contains the required properties
	     * necessary for creating and manipulating a directory context
	     *
	     * @param config configuration to valid for required properties
	     * @throws com.bcbssc.netsys.jndi.MissingPropertyException if any.
	     */
	    protected static void validateConfig(Map config) throws MissingPropertyException{
	        checkProperty(Context.INITIAL_CONTEXT_FACTORY, config);
	        checkProperty(Context.SECURITY_PRINCIPAL, config);
	        checkProperty(Context.SECURITY_CREDENTIALS, config);
	        checkProperty(Context.PROVIDER_URL, config);
	        checkProperty(PROVIDER_URL_SSL, config);
	        checkProperty(CONTEXT_BASE, config);
    }

}
