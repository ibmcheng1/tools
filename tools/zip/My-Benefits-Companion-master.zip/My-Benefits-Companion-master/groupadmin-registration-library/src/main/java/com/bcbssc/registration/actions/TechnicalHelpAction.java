/*
 * @(#)TechnicalHelpAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.registration.actions;

import com.bcbssc.registration.common.Constants;
import com.bcbssc.registration.services.IRegistrationServices;
import com.bcbssc.struts.action.BaseAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * Shared Registration Technical Help
 *
 * This class provides control processing for the technical help action It
 * should be extended by an application-specific class that creates a business
 * logic services object and converts the input data into an
 * application-specific form bean
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public abstract class TechnicalHelpAction extends BaseAction {

	/** log4j logger */
	private static Logger logger = Logger.getLogger(TechnicalHelpAction.class);

	/**
	 * Processes the specified HTTP request, and creates the corresponding HTTP
	 * response.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public abstract ActionForward execute(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception;

	/**
	 * Processes the specified HTTP request, and creates the corresponding HTTP
	 * response.
	 *
	 * @param service
	 *            an application-specific service class providing needed
	 *            business logic
	 * @param formDTO
	 *            an application-specific data transfer object to be used by the
	 *            services
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward execute(IRegistrationServices service, Object formDTO,
			ActionMapping mapping, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		if (TechnicalHelpAction.logger.isDebugEnabled()) {
			TechnicalHelpAction.logger
					.debug("Executing TechnicalHelpAction.execute()");
		}

		// Submit the help request
		service.submitTechnicalHelpRequest(formDTO);
		request.setAttribute("technicalHelpForm", formDTO);
		return (mapping.findForward(Constants.FORWARD_SUCCESS));
	}
}
