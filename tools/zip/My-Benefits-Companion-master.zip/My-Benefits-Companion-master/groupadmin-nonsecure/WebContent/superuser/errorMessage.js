/*
 * @(#)errorMessage.js
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * JavaScript for processing the error message returned fronm MF
 *
 * @author      Mark Lujan
 * @version     $Revision:   1.0  $ - $Date:   Jul 31 2009 15:00:24  $
 * @since       1.0
 *
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyBenefitsCompanion/mbc-web-nonsecure/WebContent/superuser/errorMessage.js_v  $

   Rev 1.0   Jul 31 2009 15:00:24   EN80
Initial revision.

   Rev 1.0   Apr 14 2005 19:04:54   rxr93
Initial revision.
 *
 */


// messages
var notFoundMsg = "USERID not on Customer Database - Call the Technology Support Center";
var passwordMsg = "Password invalid - Enter a valid Password";

// flags - user was not found or password error
var notFound = false;
var passwordErr = false;

// return the displayable error message
function getErrorMessage(in_errorMsg) {

        var str = in_errorMsg;

        // check it first 
        if(str.indexOf("NOT ON CUSTOMER DATABASE") != -1) {
                notFound = true;
        } else if(str.indexOf("USERID IS UNKNOWN TO THE ESM") != -1) {
                notFound = true;
        } else if (str.indexOf("PASSWORD INVALID - ENTER A VALID PASSWORD") != -1) {
                passwordErr = true;
        }

        // return appropriate message
        if(str.indexOf("<!--") != -1) {
                str = "";
        } else if (passwordErr == true) {
                str = passwordMsg;
    } else if(notFound == true) {
        str = notFoundMsg;
    }
	return str;
}

// user not found accessor
function isNotFound() { 
	return notFound;
}

// password error accessor
function isPassworErr() {
	return passwordErr;
}

