/*
 * @(#)submit_button.js
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * JavaScript for loading and manipulating submit button gifs
 *
 * @author      Mark Lujan
 * @version     $Revision:   1.0  $ - $Date:   Jul 31 2009 15:00:40  $
 * @since       1.0
 *
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyBenefitsCompanion/mbc-web-nonsecure/WebContent/superuser/submit_button.js_v  $

   Rev 1.0   Jul 31 2009 15:00:40   EN80
Initial revision.

   Rev 1.0   Apr 14 2005 19:05:04   rxr93
Initial revision.
 *
 */

function newImage(arg) {
    if (document.images) {
        rslt = new Image();
        rslt.src = arg;
        return rslt;
    }
}

function changeImages() {
    if (document.images && (preloadFlag == true)) {
        for (var i=0; i<changeImages.arguments.length; i+=2) {
            document[changeImages.arguments[i]].src = changeImages.arguments[i+1];
        }
    }
}

var preloadFlag = false;
function preloadImages() {
    if (document.images) {
        submit_butt_over = newImage("images/submit_butt-over.gif");
        submit_butt_down = newImage("images/submit_butt-down.gif");
        preloadFlag = true; 
    }
}

