/*
 *
 * @(#)RL45M17.js
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

/**
 * Javascript Webpack code for Rules screen RL45M17.
 *
 * @author      Jonathan Egger
 * @version     $Revision:   1.0  $
 * @since       1.0
 *
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/mim-web/WebContent/csds/GroupAdmin/Rules/RL45M17.js_v  $

   Rev 1.0   Jun 26 2009 16:31:04   EN80
Initial revision.

   Rev 1.0   Sep 23 2004 14:31:54   rxg97
Initial revision.
 */

include("Framework\\pageUtils.js");

/**
 *	Adds a RULEs entry in order to get an access code
 */		
function getAccessCode() {
    if (thisPage == "RL45M17") {
        f.action.value = "A";
        
        f.addressLine1.value = myTask.getValue("addressLine1");
        f.addressLine2.value = myTask.getValue("addressLine2");
        f.applicationId.value = myTask.getValue("applicationId");
        f.city.value = myTask.getValue("city");
        f.countryCode.value = myTask.getValue("countryCode");
        f.dob.value = myTask.getValue("dob");
        f.extension.value = myTask.getValue("extension");
        f.faxNumber.value = myTask.getValue("faxNumber");
        f.firstName.value = myTask.getValue("firstName");
        f.groupName.value = myTask.getValue("groupName");
        f.groupNumber.value = myTask.getValue("groupNumber");
        f.lastName.value = myTask.getValue("lastName");
        f.middleIni.value = myTask.getValue("middleIni");
        f.phoneNumber.value = myTask.getValue("phoneNumber");
        f.ssn.value = myTask.getValue("ssn");
        f.state.value = myTask.getValue("state");
        f.suffix.value = myTask.getValue("suffix");
        f.zip4.value = myTask.getValue("zip4");
        f.zip5.value = myTask.getValue("zip5");
        
        myTask.setScriptToRun("getAccessCodeComplete()");
    
        CBGenKey("H:@E");   
    } else {
        generateErrorCondition(thisPage + " ,Unexpected page.  Was expecting page RL45M17.", -2);
    }
}

/**
 *	Returns the access code after the form has been filled and submitted
 */
function getAccessCodeComplete() {

	var message = f.eesm.value.Trim();
	var utl = getPageUtils();
    if (thisPage == "RL45M17") {
		if (message == "RECORD ADDED SUCCESSFULLY") {
            var param = utl.getRootParam();
            param.add("accessCode", new RPCString(f.accessCode.value));
            utl.complete("SUCCESS", message);

            CBGenKey("H:@C");
		}
		else {
            ONTDebug("RL45M17", "EVENT", message);
			utl.complete("FAILURE", message);
			CBGenKey("H:@C");
		}
	} else {
        generateErrorCondition(thisPage + " ,Unexpected page.  Was expecting page RL45M17.", -2);
    }
}
