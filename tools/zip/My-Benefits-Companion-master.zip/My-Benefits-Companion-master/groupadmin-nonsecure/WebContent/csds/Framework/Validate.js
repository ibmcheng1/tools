/*
 * Copyright (c) 2004 BlueCross BlueShield of South Carolina. All rights reserved.
 *
 * $Author:   EN80  $
 * $Workfile:   Validate.js  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 16:31:00  $
 */

/*
*   function: validateOnly()
*   parameters: none
*   return:     none
*   remarks:
*           This function just handles validation and never kicks
*           off a transaction.
*/
function validateOnly()
{
    ONTDebug("Validate Only Handler", "START", "VALIDATE: Validate Only");
    var screenContents = new String(r.screenrecord);
    var screenErrorLine = new String(r.errorLine);

    if (screenContents.IsBlank() || (screenContents.Contain("SIGN-ON IS COMPLETE"))) {
        var myTask = getTask();
        var newPassword = myTask.getValue("newPassword");
        if (myTask.isNewRegion() || !newPassword.IsBlank()) {
            CBGenkey("H:off@E");
        } else if (myTask.isNewUser()) {
            runCESN(myTask);
        } else {
            CBGenkey("H:@C");
        }
    } else {
        CBGenkey("H:@C");
    }

    setCurrentRegion(myTask.region,myTask.racfid,myTask.racfpassword);
}
