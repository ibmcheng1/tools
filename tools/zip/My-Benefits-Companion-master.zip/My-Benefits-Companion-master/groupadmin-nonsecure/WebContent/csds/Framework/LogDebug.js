/*
 * Copyright (c) 2004 BlueCross BlueShield of South Carolina. All rights reserved.
 *
 * $Author:   EN80  $
 * $Workfile:   LogDebug.js  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 16:30:42  $
 */

//*****************************************************************************************
// Function:    ONTDebug (dType, dMsg)
// Purpose:     Write trace/debug information to appropriate place(s)
// Arguments:   dType - type of message being debugged
//              dMsg - contet of message being debugged
// Created:     03.05.2002
// Modifications:
//              (08-11)/2002 - various modifications for inclusion into .NetSys CSD Framework.
//
//****************************************************************************************/

var __stacktrace = "";  // used to keep a stack trace of debug calls.  only written on occasion of a System Error

//              11.07.2002 : rvp : added stack trace output for the current screen handler
function ONTDebug (task, dType, dMsg){
    if (c.commonFields.ONTDebug == 0)
    {
        dType = dType.toUpperCase();

        if ( dType == "START" )
        {
            logStart ( task );
        }

        // else put together debug line and write to trace file
        dLine = getLogPrefix( "TRACE", task ) + dMsg;

        // send debug message to CBWeb
        var parms = new Array(c.CBWSesHand, "Debug", dLine);
        CBSend("CBWeb", parms);

        // if trace enabled
        if ( ! c.commonFields.traceLogFile.IsBlank() )
        {
            if ( dType == "END" ){
                // if end of function, call logEnd
                logEnd ( dMsg );
            }else{
                // if not end of function, write out trace line
                writeLogEntry ( "TRACE", dLine  + "\n");
            }
        }

    }

    //taken care of in LogSystemError, no need to double up
    if(dType != "ERROR")
        writeRemoteLog("DEBUG", task + ":" + dMsg);

    __stacktrace += getLogPrefix( "ERROR TRACE", task ) + dMsg + "\n";

    return(0);
}

//*****************************************************************************************
// Function:    LogSystemError ( msg )
// Purpose:     Log system error
// Arguments:   msg - error message
// Created:     04.18.2002
// Modifications:
//              11.07.2002 : rvp : added stack trace output for the current screen handler
//****************************************************************************************/

function LogSystemError (task, msg)
{

    var re = /\r/g;
    var screen = wrap(r.screenrecord, 80);

    decoratedMsg = "\n*******************************************************************************************************************\n";
    decoratedMsg += "*  SYSTEM ERROR BEGIN\n";
    decoratedMsg += "*  " + getLogPrefix( "ERROR", task );
    decoratedMsg += "\n\nStatus Line:" + c.statusline;
    decoratedMsg += "\n\n" + msg + "\n";
    decoratedMsg += "\n[SCREENRECORD]\n" + screen;


try{
    if(myTask != null)
    {
        decoratedMsg += "\n\n[PARAMETERS]\n" + myTask.params;
    }
}catch(e)
{
}

    decoratedMsg += "\n\n[ERROR TRACE INFORMATION BEGIN]\n";
    decoratedMsg += __stacktrace;
    decoratedMsg += "[ERROR TRACE INFORMATION END]\n";
    decoratedMsg += "\n*\n*  SYSTEM ERROR END\n";
    decoratedMsg += "*******************************************************************************************************************\n\n";

   decoratedMsg = filterPassword(decoratedMsg);

    // Send the error to debug console
    ONTDebug("System Error", "ERROR", decoratedMsg);

    // log the error to error file
    writeLogEntry ("ERROR", decoratedMsg);

    writeRemoteLog("ERROR", decoratedMsg);



    __stacktrace = "";
}

function wrap(text, width)
{
    var output = "";
    for(i=0;i<text.length;i++)
    {
        output += text.charAt(i);
        if( (i % width) == 0)
            output += "\n";
    }

    return output;
}


/******************************************************************************************
 * Function:        logStart ( fTask )
 * Purpose:         Write start of task to Access log & write parameters to trace log if present
 * Arguments:       fTask - function being started
 * Created:         11.07.2002 from previous methods
 * Modifications:
 *****************************************************************************************/

function logStart ( fTask ){
    logAccess("FUNCTION_START", fTask);
}


/******************************************************************************************
 * Function:        logEnd ( fTask )
 * Purpose:         Write end of task to trace log if present
 * Arguments:       fTask - function being started
 * Created:         11.07.2002 from previous methods
 * Modifications:
 *****************************************************************************************/

function logEnd ( fTask ){
    logAccess("FUNCTION_END  ", fTask);
}

/******************************************************************************************
 * Function:        logAccess ( accessType, fTask )
 * Purpose:         Write task to Access log
 * Arguments:       fTask - function being started
 * Created:         11.07.2002 from previous methods
 * Modifications:
 *****************************************************************************************/

function logAccess (accessType, fTask ){

    writeRemoteLog("INFO", accessType+ ":" + fTask);


    /* Get prefix for access log line */
    accessLine =  getLogPrefix ( "ACCESS",  accessType + " " + fTask ) +"\n";

    /* Write access line to access log */
    writeLogEntry ( "ACCESS", accessLine );

    /* If trace is enabled, write parameters to trace log */
    var CR = String.fromCharCode(13);

    if ( !c.commonFields.traceLogFile.IsBlank() ){
        functionMsg = getLogPrefix ( accessType, fTask ) + "\n";
        writeLogEntry ( "TRACE", functionMsg );
    }

    __stacktrace += accessLine;
}


/******************************************************************************************
 * Function:        getLogPrefix ( mType, fWhere )
 * Purpose:         Assemble prefix of a log string
 * Arguments:       mType - message type prefix being retrieved for
 *                  fWhere - function debug being issued from
 * Return:          logPrefix returned to calling function
 * Created:         03.05.2002
 * Modifications:
 *
 *****************************************************************************************/

function getLogPrefix ( mType, fWhere ){

    /* if user is a member, give userID their subscriber number */
    if(fWhere == "SYSTEM INIT" || fWhere == "LOGON"){
        /* if error during system init */
        userClass = "";
        userID = "SYSTEM INIT";
        userPatID = "";
    } else {
       /* else it must be a DEBUG error */
        userClass = "";
        userID = "DEBUG";
        userPatID = "";
    }

    /* if user is a super user, prepend this to the userClass */
    if(c.commonFields.superUserID != ""){
        userClass = "SUPER USER " + c.commonFields.superUserID + " ACTING AS " + userClass;
    }

    /* get current date/time for log */

    var tempDate = new Date();

    cTime = tempDate.getFullYear() + "-" +
        zeroPad(tempDate.getMonth() + 1) + "-" +
        zeroPad(tempDate.getDate()) + "." +
        zeroPad(tempDate.getHours()) + "." +
        zeroPad(tempDate.getMinutes()) + "." +
        zeroPad(tempDate.getSeconds());

    /* put together logPrefix to return */
    if ( mType == "FUNCTION_START" ){
        /* for function start, put START time and function name */
        logPrefix = "[START " + fWhere + ": " + cTime + "]";
    } else if ( mType == "FUNCTION_END" ){
        /* for function end, put END time and and function name */
        logPrefix = "[END " + fWhere + ": " + cTime + "]\n";
    } else {
        /* for normal events, put ID, message type and function name */
        logPrefix = cTime + " " + userClass + userID + userPatID + ": " + mType + " during " + fWhere + ": ";
    }

    return(logPrefix);
}

function zeroPad(val){
    return((val < 10) ? ("0" + val) : val);
}

/******************************************************************************************
 * Function:        writeLogEntry (logType,logEntry)
 * Purpose:         write logEntry to logType
 * Arguments:       logType: write to ACCESS or TRACE log
 *                  logEntry: data to write to the appropriate log
 * Outputs:         0 if successfuly write to file
 *                  -1 if failure
 * Created:         03.05.2002
 * Modifications:
 *
 *****************************************************************************************/

function writeLogEntry (logType,logEntry){

    //--- assume failure ----------------------------------
    retVal = -1;

    //--- determine log file to write to ------------------
    if(logType == "ACCESS"){
        logFile = c.commonFields.accessLogFile;
    } else if (logType == "ERROR"){
        logFile = c.commonFields.systemErrorLogFile;
    }else {
        if ( ! c.commonFields.traceLogFile.IsBlank() ){
            logFile = c.commonFields.traceLogFile;
        }
    }

    if ( ! logFile.IsBlank() ){
        //--- if logFile is non-existant file, initialize first ---
        if(! IsFileExist(logFile)){
            WriteFile(logFile, "", "append");
        }

        //--- write logEntry to logFile --
        WriteFile(logFile, logEntry, "append");
        retVal = 0;

    }

    return(retVal);
}

/********************************************************************************
 * FUNCTION:        prepareLogFiles()
 * PURPOSE:         Grab path application is running from, strip off file name
 *                  and put on pref. file name designate a log file:
 *                  <current scripts path>\logs\<current date>.<current app name>.txt
 *                  this code grabs the current appname
 * CREATED:         03.05.2002
 * MODIFICATIONS:
 *
 ********************************************************************************/
function prepareLogFiles( )
{
    // c.commonFields.currentApp = c.CBWAppID;
        // set log files
    inFile = c.commonFields.cgipath + "trace\\" + c.commonFields.currentApp + ".in";


    if (!IsFileExist(inFile))
    {
        inFile = c.commonFields.cgipath + "logs\\" + c.commonFields.currentApp + ".in";

        if(!IsFileExist(inFile))
            c.commonFields.traceLogFile             = "";       // no trace
        else
            c.commonFields.traceLogFile = c.commonFields.cgipath + "logs\\" + c.commonFields.currentApp + "." + c.commonFields.currentDate + "." + "TRACE.txt";
    }
    else
        c.commonFields.traceLogFile = c.commonFields.cgipath + "trace\\" + c.commonFields.currentApp + "." + c.commonFields.currentDate + "." + "TRACE.txt";
    c.commonFields.systemErrorLogFile       =   c.commonFields.cgipath + "logs\\" + c.commonFields.currentApp + "." + c.commonFields.currentDate + "." + "SYSTEM_ERROR.txt";
    c.commonFields.accessLogFile            =   c.commonFields.cgipath + "logs\\" + c.commonFields.currentApp + "." + c.commonFields.currentDate + "." + "ACCESS.txt";
}

/*
*   function:   logErrorAndParms()
*   parameters: none
*   return:     none
*   remarks:
*           Create a new RPCMethodResponse and populate it with the status, page, and message
*           send the response back to the calling page
*           This function assumes there is an r.screenrecord defined for the entire screen
*/
function logErrorAndParms()
{
    // Since the current screen isn't the correct screen, generate an error condition and end the task
    var rpc = new RPCMethodResponse();
    var param = rpc.addParameter(new RPCStruct());
    param.add("Status", new RPCString("FAILURE"));
    param.add("Page", new RPCString(thisPage));
    var msg = new String(r.screenrecord);
    param.add("Message", new RPCString(msg));
    var errorMessage = new String(r.screenrecord);
    var logMessage = "\n\nFailure with " + thisPage + ", screen message: " + errorMessage;
    LogSystemError (myTask.process, logMessage);
    var webpackParms = new String(myTask.params)
    LogSystemError (myTask.process, webpackParms);
    SetReturnData(rpc.toString());
    myTask.setComplete();

}


function writeRemoteLog(messageType, message) {
    //if the prefs file hasnt been loaded yet when ONTDebug is called (eg during init_prefs() ),
    //bypass enhanced log4j logging.  logEnhanced will not have been set (and will default to false)
    //until the file has actually been loaded.
    //debugger;
    if (c.commonFields.logEnhanced == "true"){

        var dataToSend;
        dataToSend = "Level=" + messageType + "&Message=" + escape(message);
        dataToSend += "&Category=csd." + c.commonFields.currentApp;;
        var tmp = eval("typeof(myTask)");
        //debugger;
        if (tmp != "undefined"){
            //debugger;
            if (myTask.ndcMdc != ""){
                dataToSend += "&NDCMDC=" + escape(myTask.ndcMdc);
            }
        }
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        xmlhttp.open("POST", c.commonFields.logUrl, true);
        xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xmlhttp.send(dataToSend);
    }
}

/*
*   function:   filterPassword()
*   return:     filtered message
*   remarks:
*
*   hides the Password in a given string that contains a
*   pattern of RACFPassword.
*/

function filterPassword(decoratedMsg){
   try{
      return(decoratedMsg.replace(/RACFPassword\s*=\s*[\w\d$#@]+/g, ""));
   }catch(ex){}
}

