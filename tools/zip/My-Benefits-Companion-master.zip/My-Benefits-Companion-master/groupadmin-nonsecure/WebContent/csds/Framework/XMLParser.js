/*
 * Copyright (c) 2004 BlueCross BlueShield of South Carolina. All rights reserved.
 *
 * $Author:   EN80  $
 * $Workfile:   XMLParser.js  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 16:31:02  $
 */

@if(
   @XMLParser_Include != 1
)

@set @XMLParser_Include = 1

/*
*  constructor:Node()
*  parameters: <string> name  : the name of the node
*           <string> value : the value of the node
*  return:     a new Node object with it's member variables set to those sent in the contructor
*  remarks:
*        An object used to hold named values.
*/
function Node(name,value) {
    this.nodeName=name;
    this.nodeValue=value;
}

/*
*  function:   subTree()
*  parameters: none
*  return:     none
*  remarks:
*        Part of the MinXMLDocument used to generate the tree for the document
*/
function subTree() {
    var nodeList=new Object();
    var i=0;
    while (this.cursor<=this.source.length) {
        var start=this.cursor;
        var tagStart=this.source.indexOf('<',this.cursor);
        if (tagStart==-1) return nodeList;
        var tagEnd=this.source.indexOf('>',tagStart);
        this.cursor=tagEnd+1;
        var tag=this.source.substr(tagStart+1,tagEnd-tagStart-1);
        if (tag.charAt(0)=='/') // found end tag
            if (i==0) // no child-elements, there was chardata
                return this.textnodeParser(this.source.substr(start,tagStart-start));
            else
                return nodeList;
        else if (tag.charAt(tag.length-1)=='/') // found empty tag
            nodeList[i++]=new Node(tag.substr(0,tag.length-1),'');
        else // found start tag, parse childnodes
            nodeList[i++]=new Node(tag,this.subTree());
    }
}

/*
*  constructor:MinXMLDocument()
*  parameters: source <string> : the source for the xml document
*           textnodeParser <function> : the parset for the xml document
*  return:     a new MinXMLDocument object
*  remarks:
*        T.B.D.
*/
function MinXMLDocument(source,textnodeParser) {
    if (!textnodeParser) this.textnodeParser=new Function('x','return x');
    else this.textnodeParser=textnodeParser;

    this.subTree=subTree;
    this.source=source;
    this.cursor=0;
    this.documents=this.subTree();
}

/*
*  function:   parseCharRefs()
*  parameters: input <string> : the string to parse
*  return:     <string>       : the parsed input
*  remarks:
*        parses and cleans the input of certain characters that shouldn't be in the document.
*/
function parseCharRefs(input) {
    var i=-1;var s=''+input;
    while ((i=s.indexOf('&',i+1))!=-1) {
        var i2=s.indexOf(';',i);
        var ch=String.fromCharCode(s.substr(i+2,i2-i-2));
        s=s.substr(0,i)+ch+s.substr(i2+1);
    }
    return s;
}

/*
*  function:   escapeXML()
*  parameters: strTemp <string>  : the string for which to escape the values.
*  return:     <string>       : the escaped string.
*  remarks:
*        replaces certain string values with escaped characters.
*/
function escapeXML(strTemp){
   // Not exactly efficient solution
   var regExpGt = />/g;
   var regExpLt = /</g;
   var regExpAmp = /&/g;

    strTemp = strTemp + "";

   var ret = strTemp.replace(regExpAmp, "&#38;");
   ret = ret.replace(regExpGt, "&#62;");
   ret = ret.replace(regExpLt, "&#60;");

   return(ret);
}

@end