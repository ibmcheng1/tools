/*
 * Copyright (c) 2004 BlueCross BlueShield of South Carolina. All rights reserved.
 *
 * $Author:   EN80  $
 * $Workfile:   Blank.js  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 16:30:30  $
 */

include("Framework\\region.js");

/*
*   function: BlankScreen()
*   parameters: none
*   return:     none
*   remarks:
*           This function handles all the error handling for the blank screen.
*           It also dispatches the current task's CICS transaction
*/

function BlankScreen()
{
    ONTDebug("Blank Screen Handler", "START", "BLANK: Start Blank Screen");
    var screenContents = new String(r.screenrecord);
    var screenErrorLine = new String(r.errorLine);
    var toGenkey = false;
    var cmd = "";
        if (screenContents.IsBlank() )
    {
        ONTDebug("Blank Task", "EVENT","BLANK: Normal blank screen." );
        if(isReady())
        {
          var myTask = getTask();
                  if (myTask.getValue("validateOnly") != "") {
                    myTask.setComplete("SUCCESS", "Login complete");
                    TaskEnd();
                  } else if (myTask.CurrentContext.exists("cesnComplete")) {
                    setCurrentRegion(getCurrentRegion(),myTask.racfid,myTask.racfpassword);
                    if (! myTask.isComplete()) {
                        myTask.goToProcess();
                    } else
                    {
                     TaskEnd();
                    }
                  } else {
            if(! myTask.isComplete() )
            {
              myTask.goToProcess();
                    } else
                    {
                     TaskEnd();
                    }
          }
        }
        else if (c.CurrentRegion == null)
        {
           TaskEnd();
           defaultRegion();
        } else
                {
            var parms = new Array("SubTaskEnd", "", "", "", "");
            CBSmartCode("CBWExecute", parms);
            var parms = new Array("AppReady", "", "", "", "");
            CBSmartCode("CBWExecute", parms);
        }
    }
    else if ( screenContents.Contain("PLEASE HIT ENTER TO CONTINUE") )
    {
        ONTDebug("Blank Task", "EVENT","BLANK: Hit Enter to Continue found, hitting enter." );
        toGenkey = true;
        cmd = "H:@E";
    }
    else if (( screenContents.Contain("TERMID")) && (screenContents.Contain("NETNAME")) )
    {
        ONTDebug("Blank Task", "EVENT","BLANK: Term was typed on screen, hitting clear." );
        toGenkey = true;
        cmd = "H:@C";
    }
    else if (( screenContents.Contain("TERMID")) && (screenContents.Contain("ERROR")) )
    {
        badMsg = "BLANK: Termid and Error found on screen.";
        throwException(badMsg);
        toGenkey = true;
        cmd = "H:@C";
    }
    else if(screenErrorLine.indexOf("Transaction") < screenErrorLine.indexOf("not recognized") )
    {
        badMsg = "BLANK: Exception - Transaction not recognized.  Error: \"" + screenErrorLine + "\", was returned.";
        throwException(badMsg);
        toGenkey = true;
        cmd = "H:@C";
    }
    else if(screenErrorLine.indexOf("Transaction") < screenErrorLine.indexOf("failed with abend") )
    {
        badMsg = "BLANK: Exception - Transaction failed with abend.  Error: \"" + screenErrorLine + "\", was returned.";
        throwException(badMsg);
        toGenkey = true;
        cmd = "H:@C";
    }
    else if(screenErrorLine.indexOf("Transaction") < screenErrorLine.indexOf("disabled") )
    {
        badMsg = "BLANK: Exception - Transaction disabled message.  Error: \"" + screenErrorLine + "\", was returned.";
        throwException(badMsg);
        toGenkey = true;
        cmd = "H:@C";
    }
    else if ( screenContents.Contain("PROGRAM ERROR") )
    {
      badMsg = "BLANK: PROGRAM ERROR found, clearing screen.";
      throwException(badMsg);
      toGenkey = true;
      cmd = "H:@C";
    }
    else if ( screenContents.Contain("not authorized to use") )
    {
        badMsg = "BLANK: SECURITY VIOLATION-UNAUTHORIZED ACCESS.";
        throwException(badMsg);
        toGenkey = true;
        cmd = "H:@C";
    }
    else if ( screenContents.Contain("SECURITY VIOLATION-UNAUTHORIZED ACCESS") )
    {
        badMsg = "BLANK: SECURITY VIOLATION-UNAUTHORIZED ACCESS.";
        throwException(badMsg);
        toGenkey = true;
        cmd = "H:@C";
    }
    else if ( screenContents.Contain("UNRECOGNIZED") )
    {
        badMsg = "BLANK: COMMAND UNRECOGNIZED.";
        throwException(badMsg);
        toGenkey = true;
        cmd = "H:@C";
    }
        else if ( screenContents.Contain("SIGN-ON IS COMPLETE") )
        {
          ONTDebug( "Blank Task", "EVENT", "SIGN-ON IS COMPLETE.  Clearing screen.");
          toGenkey = true;
          cmd = "H:@C";
        }

    if ( (toGenkey == true) && (! cmd.IsBlank()) )
    {
          ONTDebug("EVENT", "Blank: generating command " + cmd);
          CBGenkey(cmd);
        }


        ONTDebug("Blank Screen Handler", "END", "BLANK: END Blank Screen");
}
/*
*   function:   throwException()
*   parameters: badMsg <string> the string representing the error message to throw
*   return:     none
*   remarks:
*           logs the exception using ONTDebug
*           generates a TCException and sets the current task to complete
*           so the error can be cleared and the task released
*/
function throwException(badMsg)
{
    ONTDebug("Blank Task", "EVENT", badMsg);
    var ex = new TCException(100, badMsg);
    SetReturnData(ex.toXMLRPCFault());
    if(isReady())
    {
        var myTask = getTask();
        myTask.setComplete();
    }
    else
    {
        TaskEnd();
    }
}

