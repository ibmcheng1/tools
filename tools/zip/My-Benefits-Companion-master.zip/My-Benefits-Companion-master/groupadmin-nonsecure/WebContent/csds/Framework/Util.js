/*
 * Copyright (c) 2004 BlueCross BlueShield of South Carolina. All rights reserved.
 *
 * $Author:   rx24c  $
 * $Workfile:   Util.js  $
 * $Revision:   1.1  $
 * $Date:   Dec 01 2009 17:51:40  $
 */

include("Framework\\JSPak.js");
include("Framework\\config.js");
include("Framework\\LogDebug.js");
include("Framework\\resetState.js");

//this defines the minimum scripting engine version.  If the Scripting engine
//used by the CSD is less than this number, PBEntry and PBStatus will log a
//system error reporting the fact during initialization
MIN_SCRIPTING_ENGINE_VER = 5.6

/*
*   function:   GetNameValue()
*   parameters: parameters <array>  : holds the named value pairs
*               name <string>       : the key to lookup to return the proper value
*   return:     <string>: the value associated with the key name passed
*   remarks:
*           Gets the value of a named member of the passed parameters.
*           Makes use of the existing SmartCode implementation.
*/
function GetNameValue(parameters, name)
{
    parms = new Array(parameters, "", name);
    return CBSmartCode("GetNameValue", parms);
}

/*
*   function:   SetReturnData()
*   parameters: data <string>: the data to return. usually an RPCMethodResponse
*   return:     none
*   remarks:
*           Sets the return data value to return to the WebpackAdapter when the task is complete.
*/
function SetReturnData(data)
{
    var parameters = new Array("SetReturnData", "", data, "", "");
    CBSmartCode("CBWExecute", parameters);
    ONTDebug("Setting Return Data", "EVENT", data);
}

/*
*   function:   SubTaskEnd()
*   parameters: none
*   return:     none
*   remarks:
*           A javascript -> smartcode pass-through function
*/
function SubTaskEnd()
{
    var parameters = new Array("SubTaskEnd", "", "", "", "");
    CBSmartCode("CBWExecute", parameters);
}

/*
*   function:   TaskEnd()
*   parameters: none
*   return:     none
*   remarks:
*           A javascript -> smartcode pass-through function
*/
function TaskEnd()
{
    var parameters = new Array("TaskEnd", "", "", "", "");
    CBSmartCode("CBWExecute", parameters);
}


// *******************************************************************************
// * FUNCTION: isErrorCodes(eesm)
// * PURPOSE: Given an eesm error line, attempts to validate the line contains only
// *          error codes
// *******************************************************************************/
function isErrorCodes(peesm)
{
    result = true;

    var eesm = new String(peesm);
    exp = new RegExp(" {2,}", "g");
    errorLine = eesm.Trim();
    if(errorLine.length > 0) {
      errorLine = errorLine.replace(exp, " "); // removed extra embedded spaces
      codes = errorLine.split(" ");

      for ( i = 0; i < codes.length; i++)
      {
        if ( 3 != codes[i].length )
        {
          result = false;
          break;
        }
      }
    }

  return result;
}

// *******************************************************************************
// * FUNCTION: checkScriptEngineVersion(processName)
// * PURPOSE: Checks the scripting engine version, and logs an error if it is
// *          less than MIN_SCRIPTING_ENGINE_VER
// *          ***NOTE**** This will NOT work with MS Scripting Host prior to
// *          Version 5.0.  If the version < 4, the engine will report code error
// * PARAM: processName - the name of the caller process; used for log output
// *******************************************************************************/
function checkScriptEngineVersion(processName)
{
   var fullStr, major, minor, build, majDotMin, errMsg, isInvalidVersion;

   //NOTE: if the following line errors, it is because the scripting engine is
   //LESS than MIN_SCRIPTING_ENGINE_VER
   try {
       major = ScriptEngineMajorVersion();
       minor = ScriptEngineMinorVersion();
       build = ScriptEngineBuildVersion();
       majDotMin = major + "." + minor;
       //represent this as a double and compare to MIN_SCRIPTING_ENGINE_VER
       if (majDotMin < MIN_SCRIPTING_ENGINE_VER)
       {
            fullStr = ""; // Build string with full engine info.
            fullStr += ScriptEngine() + " Version ";
            fullStr += major + ".";
            fullStr += minor + ".";
            fullStr += build;
            errMsg = "Scripting host version does not meet application requirements: requires " + MIN_SCRIPTING_ENGINE_VER + "; found: \"" + fullStr + "\"";
            isInvalidVersion = true;
       }
    }
    catch (e){
        errMsg = "Cannot determine scripting engine version; most likely < 5.0! (Required: " + MIN_SCRIPTING_ENGINE_VER + ")";
        isInvalidVersion = true;
    }

    if (isInvalidVersion == true){
        LogSystemError(processName, errMsg);
    }
}

/**
    Function: checkAbend
    Purpose: checks for ' abend ' on the current screen record. If found, generateErrorCondition() is called
             and the task is set as complete.
    Returns true if an abend occurred, false otherwise.

*/
function checkAbend(){
    var screenrecord = new String(r.screenrecord).toLowerCase();
    var abendOccurred = false;
    if((screenrecord.indexOf(" abend ") != -1) && (screenrecord.indexOf("DFH") != -1)) {
        generateErrorCondition(myTask.process, "abend occurred.");
        abendOccurred = true;
    }

    return abendOccurred;
}

/*
*   function:   sendKeystroke()
*   parameters: hllapi, a string hllapi sequence
*   return:     none
*   remarks:
*           a wrapper around CBGenKey so (if we want) we can do other things too, like logging, etc.
*/
function sendKeystroke(hllapi){
    CBGenKey(hllapi);
}

/*
*   function:   sendEnterKey()
*   parameters: none
*   return:     none
*   remarks:
*           sends enter. that's it.
*/
function sendEnterKey(){
    sendKeystroke("H:@E");
}

/*
*   function:   getScreenName()
*   parameters: none
*   return:     the current screen name, if recognized.
*   remarks:
*           convenience wrapper around CBGet()
*/
function getScreenName(){
    return CBGet("cb.app.host.screenName");
}

/*
*   function:   isOnScreen()
*   parameters: screenName - the expected screen
*               doLogError - boolean, whether or not to log and generate an error condition if
                the current screen name is NOT equal to the expected screen name
*   return:     true if the current screen is equal to the expected screen
                false if not.  If doLogError is not passed in (or is true) then a system error is logged
                and an error condition is generated.
*/
function isOnScreen(screenName, doLogError){
    var screenFound = getScreenName();
    if (screenFound == screenName) {
        return true;
    } else {
        if (( arguments.length < 2) || (doLogError)) {
            var msg = "Unexpected screen.  Was expecting [" + screenName + "] but got [" + screenFound + "]";
            LogSystemError(myTask, msg);
            generateErrorCondition(c.commonFields.currentApp, msg, -2);
        }
        return false;
    }
}

/*
*   function:   currentScreenOK()
*   parameters: screenName - the expected screen name
*   return:     true if no abend is found and the current screen name is the same as the expected screen name.
*   remarks:
*           convenience wrapper around checkAbend() and isOnScreen()
*/
function currentScreenOK(screenName){
    if ( (checkAbend() == true) || ( ! isOnScreen(screenName)) ) return false;
    else return true;
}

// *******************************************************************************
// * FUNCTION: generateErrorCondition
// * PURPOSE: Logs system error along with parameters, ends the task and clears the
// *          screen.
// * PARAM:   shortname - short name for the process
// *          message   - message to log with the failure
// *          number    - error number (if you have one
// *******************************************************************************
function generateErrorCondition(shortname, message, number) {
    generateException(shortname, message, number, "ERROR")
}

// *******************************************************************************
// * FUNCTION: generateException
// * PURPOSE: Logs the exception with the debug level passed as input param(debugLevel).
// *          Also logs the screen record if "withScreenRecord" is true
// * PARAM:   shortname - short name for the process
// *          message   - message to log with the failure
// *          number    - error number (if you have one)
// *          debugLevel - debug level to be used for remote logging
// *          withScreenRecord - boolean,
// *                             if its value is true, it logs with screen record
// *******************************************************************************

function generateException(shortname, message, number, debugLevel, withScreenRecord) {
    switch (arguments.length) {
        case 0 :
            shortname   = "Unknown error";
        case 1 :
            message     = "No information for this error is available.";
        case 2 :
            number      = -1;
        case 3 :
            debugLevel  = "WARN";
        case 4 :
            withScreenRecord  = false;
    }
    // log to debug screen
    ONTDebug(myTask.process, "EVENT", shortname + " failure on page " + thisPage + "\n\tMessage: " + message
        + "\n\tNumber: " + number);
    if (debugLevel == "ERROR") {
        LogSystemError(myTask.process, myTask.params);// log the screen and parameters to error log
    } else {
        writeRemoteLog(debugLevel, shortname + " failure on page " + thisPage + "\n\tMessage: " + message
        + "\n\tNumber: " + number);
        if (withScreenRecord) {
            logScreenRecord(debugLevel);
        }
    }
    // throw an exception back to the calling process
    myTask.throwException(shortname, message, number);
    // clear the screen
    CBGenKey("H:@C");
}

/*
*   function:   logScreenRecord()
*   parameters: none
*   return:     none
*   remarks:
*           logs the screen record.
*/
function logScreenRecord(debugLevel) {
    var screen = wrap(r.screenrecord, 80);

    decoratedMsg = "\n*******************************************************************************************************************\n";
    decoratedMsg += "\n[SCREENRECORD]\n" + screen;
    decoratedMsg += "*******************************************************************************************************************\n\n";

    writeRemoteLog(debugLevel, decoratedMsg);
}


/*
*   function:   clearScreen()
*   parameters: none
*   return:     none
*   remarks:
*           clears the screen.  That's it
*/
function clearScreen() {
    sendKeystroke("H:@C");
}

/*
*   function:   sendInvalidResponse
*   parameters: shortname   - process or whatever (i.e. AMXV, DNXV, etc.)
*               status      - error message to return (i.e. INVALID SEARCH, SUCCESS, FAILURE)
*               pagemessage - field message from cics screen r.message, f.message.value, etc.
*               description - more descriptive text for error log
*   return:     none
*   remarks:
*/
function sendInvalidResponse(shortname, status, pagemessage, description) {
    if(description == null) {
        description = pagemessage;
    }
    ONTDebug(shortname, "EVENT", description);
    myTask.setComplete(status, pagemessage);
    clearScreen();
}

/*
   FUNCTION:    getDateDifference
   PURPOSE:     calculate the difference between 2 dates in CCYYMMDD format, in days.
   INPUTS:      2 dates in CCYYMMDD format - assumes date and it's format is pre-edited.
   OUTPUTS:     difference in days
   AUTHOR:      .Net Systems
*/
function getDateDifference(fromDate, toDate)
{
    var tempMonth   = parseInt(fromDate.substr(4,2),10) - 1;    // 0 based array for the month, so subtract 1.
    var firstDate   = new Date(fromDate.substr(0,4), tempMonth, fromDate.substr(6,2));
    tempMonth       = parseInt(toDate.substr(4,2),10) - 1;
    var secondDate  = new Date(toDate.substr(0,4), tempMonth, toDate.substr(6,2));
    var daysDiff = (secondDate.getTime() - firstDate.getTime());
    daysDiff = Math.floor(Math.abs((((daysDiff  / 1000) / 60) / 60) / 24));
    return daysDiff;
}

function logHtml() {
    var logOn = false;
    if(logOn) {
        var prefix = "\n<html>\n<head>\n<style>\nbody {background-color:black;}\ninput {border:solid 1px black;font-size:10px;color:#00FF00;background-color:black;}\n</style>\n</head>\n<body>\n<PRE>";
        var postfix = "\n</body>\n</html>";
        ONTDebug("", "EVENT", prefix + CBGet("cb.app.host.html") + postfix);
    }
}

/*
     PURPOSE:     checks the equivalency of a specified value against one
                  or more values specified in an .ini file entry.
     INPUTS:      value1, section of list of matching values, prop key of
           matching values and default matching values list
     OUTPUTS:     returns true if value1 matches any of the values in the
                matching value list
     AUTHOR:      .Net Systems
*/
function determineIniValueMatch (value1,sect,prop,def)
{
      var ar = getINIValue(c.commonFields.prefFile,sect,prop,def);
      ar = ar.split(",");
      for (i=0;i<ar.length;i++) {
        ar[i] = ar[i].Trim();
        if (value1 == ar[i]) {
     return true;
        }
      }

      return false;
}

/**
 * Given a date string of 6 bytes (mmddyy), determine the century and return as YYYYMMDD.
 */
function implantCentury(dateString) {
   var newDateStringMonth = "";
   if (dateString.length == 6) {
       var dateStringMonth = dateString.substr(0,2);
       var dateStringDay = dateString.substr(2,2);
       var dateStringYear = dateString.substr(4);
       if (dateStringYear < "30") {
           dateStringYear = "20" + dateStringYear;
       } else {
           dateStringYear = "19" + dateStringYear;
       }
      newDateStringMonth = dateStringYear + dateStringMonth + dateStringDay;
   } else {
      newDateStringMonth = dateString;
   }
   return newDateStringMonth;
}