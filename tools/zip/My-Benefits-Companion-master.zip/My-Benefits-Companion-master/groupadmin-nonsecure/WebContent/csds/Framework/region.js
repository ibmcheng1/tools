/**
 * Copyright (c) 2004 BlueCross BlueShield of South Carolina. All rights reserved.
 *
 * @author    $Author:   EN80  $
 * @workfile  $Workfile:   region.js  $
 * @version   $Revision:   1.0  $
 * @date      $Date:   Jun 26 2009 16:30:50  $
 */


/*
 *  function:   changeRegion()
 *  parameters: none
 *  return:     none
 *  remarks:
 *        Function reads the region from the preferences file and sets the screen's value for the region with it.
 *        It then sends enter to go to the login screen.
 */
function changeRegion() {
    var screenContents = new String(r.screenrecord);
    if (myTask.region == "") {
       myTask.region = getRegion();
    }
    ONTDebug("region.js:changeRegion()", "EVENT", "changeRegion(): Entered...region = " + myTask.region +
    	", regionSelectsExceeded = " + c.commonFields.regionSelectsExceeded);
    
	if ( c.commonFields.regionSelectsExceeded ) {
		ONTDebug("region.js:changeRegion()", "EVENT", "regionSelectsExceeded previously, issueing LOGOFF");
		c.commonFields.regionSelectsExceeded = 0;
		myTask.setComplete("FAIL", "catch all");
		TaskEnd();
    } else if (screenContents.Contain("CONTROL PASSED TO APPLICATION")) {
       ONTDebug("region.js:changeRegion()", "EVENT", "Waiting for login to appear");
    } else if (regionErrors() > 1) {
       handleUnableToEstablish();
    } else {
       r.region = myTask.region;
       CBGenkey("H:@E");
       saveTask(myTask);
       setCurrentRegion(myTask.region,myTask.racfid,myTask.racfpassword);
    }
}

/*
 *
 *  function:   defaultRegion()
 *  parameters: none
 *  return:     none
 *  remarks:
 *        Function reads the region from the preferences file and sets the screen's value for the region with it.
 *        It then sends enter to go to the login screen.
 */
function defaultRegion() {
   if (c.commonFields.prefFile == null) {
       resetState();
   }
   var screenContents = new String(r.screenrecord);

   c.CurrentRegion = getRegion();
	if ( c.commonFields.regionSelectsExceeded ) {
		c.commonFields.regionSelectsExceeded = 0;
       pageUtil.complete("FAIL", "regionSelectsExceeded unable to connect to region.", -2);

   } else if ( screenContents.Contain("UNABLE TO ESTABLISH")) {
   		// empty catch to prevent the CSD from continuing to loop
   		// If this condition is removed the enter key continues to be pressed and we end up with 8Mb error files.
   } else if (screenContents.Contain("COMMAND UNRECOGNIZED")) {
   		// empty catch to prevent the CSD from continuing to loop
   		// If this condition is removed the enter key continues to be pressed and we end up with 8Mb error files.
   } else if (screenContents.Contain("CONTROL PASSED TO APPLICATION")) {
       ONTDebug("REGION", "EVENT", "Waiting for login to appear");
   } else {
       r.region = c.CurrentRegion;
       CBGenkey("H:@E");
   }
}

/*
 * function:   handleUnableToEstablish()
 * parameters: none
 * return:     none
 * remarks:
 *       Function bumps region to next when a region has
 *                       been detected as being offline, if singletonRun is
 *                       has been set then region rollover is not done.
 */
function handleUnableToEstablish() {
   ONTDebug( "region.js:handleUnableToEstablish", "EVENT", "REGION: UNABLE TO ESTABLISH.");
   var cmd = "";
   var rc = true;

   if ( c.commonFields.connectionAttempts < (c.commonFields.maxConnectionAttempts - 1)
     && c.commonFields.singletonRun == 0 ) {
       ONTDebug("REGION_SELECT", "EVENT", "REGION: Attempt #\"" + c.commonFields.connectionAttempts + "\" for "+c.CurrentRegion+", to log onto region.");
       if ( bumpCurrentRegion() ) {
           setCurrentRegion(getRegion(),c.commonFields.racfid,c.commonFields.racfpassword);
       } else {
           c.commonFields.connectionAttempts = c.commonFields.connectionAttempts + 1;
       }
       var myTask = getTask();
       if (myTask!=null) {
           myTask.region = getRegion();
           saveTask(myTask);
       }
       cmd = "H:" + getRegion() + "@E";
       ONTDebug ("REGION_SELECT", "EVENT", "REGION: [change region] cmd is " + cmd);
       CBGenkey(cmd);
   } else {
       // at least try max# attempts
       if (c.commonFields.singletonRun == 1) {
           if (c.commonFields.connectionAttempts < c.commonFields.maxConnectionAttempts - 1) {
               c.commonFields.connectionAttempts = c.commonFields.connectionAttempts + 1;
               var myTask = getTask();
               if (myTask!=null) {
                   cmd = "H:" + myTask.region + "@E";
                   CBGenkey(cmd);
                   return rc;
               }
           }
       }
       c.commonFields.connectionAttempts = 0;
       c.commonFields.regionSelectsExceeded = 1;
       // logoff to get a new login screen with the screen recognition line "BC/BS ENTER REQUEST"
       CBGenKey("H:LOGOFF@E");

       LogSystemError("REGION_SELECT", "Region selection has been attempted the maximum number of times = "+c.commonFields.maxConnectionAttempts+".\nRegion:" + c.CurrentRegion);
       var myTask = getTask();
       if (myTask != null) {
           myTask.setComplete("FAILURE", "CSD Failure, unable to establish a region connection. "+ getRegion());
           saveTask(myTask);
       }
       rc = false;
       TaskEnd();
   }
   return rc;
}

/*
 *
 *  function:   getCurrentRegion()
 *  parameters:     none
 *  return:     current region
 *  remarks:
 *        extracts region from c.CurrentRegion
 */
function getCurrentRegion() {
  var arrRegion = c.CurrentRegion.split("|");
  return arrRegion.length > 0 ? arrRegion[0] : "";
}

/*
 *
 *  function:   getCurrentRacfPassword()
 *  parameters:     none
 *  return:     current region password
 *  remarks:
 *        extracts password from c.CurrentRegion
 */
function getCurrentRacfPassword() {
  var arrRegion = c.CurrentRegion.split("|");
  return arrRegion.length > 2 ? arrRegion[2] : "";
}

/*
 *
 *  function:   getCurrentRacf()
 *  parameters:     none
 *  return:     current region userid
 *  remarks:
 *        extracts userid from c.CurrentRegion
 */
function getCurrentRacf() {
  var arrRegion = c.CurrentRegion.split("|");
  return arrRegion.length > 1 ? arrRegion[1] : "";
}

/*
 *
 *  function:   setCurrentRegion()
 *  parameters:     cicsregion,userid and password
 *  return:     nothing
 *  remarks:
 *        extracts region from c.CurrentRegion
 */
function setCurrentRegion(cicsregion,racf,racfpassword) {
  c.CurrentRegion = cicsregion + "|" + racf + "|" + racfpassword;
}


function regionErrors()
{
    var errorCount = 0;
    errorCount += r.screenrecord.MatchCount("COMMAND UNRECOGNIZED");
    errorCount += r.screenrecord.MatchCount("UNABLE TO ESTABLISH");
    errorCount += r.screenrecord.MatchCount("UNSUPPORTED FUNCTION");
    errorCount += r.screenrecord.MatchCount("PARAMETER EXTRANEOUS");

	// New error message discovered during CICS outage on 7/12/2007
    errorCount += r.screenrecord.MatchCount("LOGMODE PARAMETER VALUE NOT VALID");

    return errorCount;
}
