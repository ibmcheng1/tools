/*
 * Copyright (c) 2004 BlueCross BlueShield of South Carolina. All rights reserved.
 *
 * $Author:   EN80  $
 * $Workfile:   login.js  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 16:30:44  $
 */

include("Framework\\region.js");

/*
*   function:   login()
*   parameters: none
*   return:     none
*   remarks:
*           Function reads the preference file for the username and password values,
*           sets those values on the screen, and sends enter to perform the login.
*/
function login()
{
    var prefFile = c.commonFields.prefFile;
    var screenContents = new String(r.screenrecord);

	// set the current region now that we have made it to the login screen
    setCurrentRegion (myTask.region,"", "");

    var possibleError = checkLoginErrors();
    if (possibleError.IsBlank()) {
        // login seems to be OK so go ahead
        if(myTask.racfid == "")
            myTask.racfid = getINIValue(prefFile, "WebPack", "RACF", "");
        if(myTask.racfpassword == "")
            myTask.racfpassword     = getINIValue(prefFile, "WebPack", "RACF_PW", "");

        if(myTask.racfid == "" || myTask.racfpassword == "")
        {
            var errormessage = "Login: RACFID and or RACFPassword are blank.\nracfid:" + myTask.racfid + "\npass:" + myTask.racfpassword;
            myTask.setComplete("LOGIN_FAILURE", errormessage);

            LogSystemError("Login", errormessage);
        }
        else
        {
            if (myTask.CurrentContext.enteredOnce == "true")
                myTask.setComplete("SUCCESS", "Validation successfully completed.");
        }
        ONTDebug("LOGIN", "EVENT", "Logging in with user:" + myTask.racfid );

        f.userid            = myTask.racfid;
        f.password          = myTask.racfpassword;
        try {
            if (f.newPassword != undefined && f.verifyPassword != undefined) {
                f.newPassword = myTask.getValue("newPassword");
                f.verifyPassword = myTask.getValue("verifyPassword");
            }
        } catch (e) {
            // Don't do anything
        }

        setCurrentRegion (getCurrentRegion(),f.userid,f.password);

        myTask.CurrentContext.enteredOnce = "true";
        CBGenkey("H:@E");
    } else if (myTask.getValue("newPassword") != undefined  &&
               myTask.getValue("newPassword") != "" &&
               possibleError.IsBlank()) {
        // Set the new password
        try {
            if (f.newPassword != undefined && f.verifyPassword != undefined) {
                f.newPassword = myTask.getValue("newPassword");
                f.verifyPassword = myTask.getValue("verifyPassword");
            }
        } catch (e) {
            // Don't do anything
        }

        setCurrentRegion (getCurrentRegion(),f.userid,f.newPassword);
        myTask.CurrentContext.enteredOnce = "true";

        CBGenkey("H:@E");
    } else {
        // apparently there was some login error
        failLogin(possibleError);
    }
}

/*
*
*   function:   defaultLogin()
*   parameters: none
*   return:     none
*   remarks:
*           Function reads the preference file for the username and password values,
*           sets those values on the screen, and sends enter to perform the login.
*/
function defaultLogin()
{
    val = resetState();
    var prefFile    = c.commonFields.prefFile;
    var racfid      = getINIValue(prefFile, "WebPack", "RACF", "");
    var racfpassword    = getINIValue(prefFile, "WebPack", "RACF_PW", "");
    var possibleError   = checkLoginErrors();

    if (possibleError.IsBlank()) {

      if(racfid == "" || racfpassword == "")
    LogSystemError("Login", "Default Login: RACFID and or RACFPassword are blank.\nracfid:" + racfid + "\npass:" + racfpassword);

      ONTDebug("LOGIN", "EVENT", "Logging in with user:" + racfid);

      f.userid    = racfid;
      f.password  = racfpassword;

      setCurrentRegion (getCurrentRegion(),f.userid,f.password);

      CBGenkey("H:@E");
    } else {
        // apparently there was some login error
        failLogin(possibleError)
    }
}

/*
*
*   function:   extractMessage()
*   parameters: none
*   return:     none
*   remarks:        temp function such that csd's don't have to have
*                       new fields added for login
*/
function extractMessage(line, col) {
  var text = new String(r.screenrecord);

  var start = (line * 80) + col;
  var finish = ((line + 1) * 80) - 1;

  var theMessage = text.substring(start, finish);

  return theMessage;
}

/*
*   function:   checkLoginErrors()
*   parameters: none
*   return:     error message
*   remarks:        Checks possible error messages and returns them if any are found.
*/
function checkLoginErrors() {
    var retval = "";

    if (isReady()) {
        var useridMessage = "";
        var passwordMessage = "";
        var copyrightMessage = "";
        var passwordChangeMessage = "";
        var warningMessage = "";

        try {
            if (f.useridMessage == undefined) {
                useridMessage = extractMessage(4,34);
            } else {
                useridMessage = (new String(f.useridMessage)).Trim();
            }
        } catch (x) {
            useridMessage = extractMessage(4,34);
        }
        if (useridMessage.Contain("USERID CANNOT BE BLANKS OR NULLS")) {
            ONTDebug("LOGIN", "EVENT", "Got message: USERID CANNOT BE BLANKS OR NULLS");
            useridMessage = "";
        }

        try {
            if (f.passwordMessage == undefined) {
                passwordMessage = extractMessage(5,34);
            } else {
                passwordMessage = (new String(f.passwordMessage)).Trim();
            }
        } catch (x) {
            passwordMessage = extractMessage(5,34);
        }

        try {
            if (f.copyrightMessage == undefined) {
                copyrightMessage = extractMessage(12,0);
            } else {
                copyrightMessage = (new String(f.copyrightMessage)).Trim();
            }
        } catch (x) {
            copyrightMessage = extractMessage(12,0);
        }

        try {
            if (f.badPasswordMessage == undefined) {
                passwordChangeMessage += extractMessage(8,34);
            } else {
                passwordChangeMessage = f.badPasswordMessage;
            }
            if (f.copyrightMessage == undefined) {
                passwordChangeMessage += extractMessage(9,34);
            } else {
                passwordChangeMessage += (new String(f.passwordChangeMessage)).Trim();
            }
        } catch (x) {
            passwordChangeMessage += extractMessage(8,34);
            passwordChangeMessage += extractMessage(9,34);
        }

        try {
            if (f.copyrightMessage2 != undefined) {
                var message2 = (new String(f.copyrightMessage2)).Trim();
                if (message2 != "") {
                    if (r.LOGIN_warningMessage != undefined) {
                        warningMessage = (new String(r.LOGIN_warningMessage)).Trim();
                    }
                }
            }
        } catch (e) {
        }

        if (! useridMessage.IsBlank()) retval = useridMessage;
        else if (! passwordMessage.IsBlank()) retval = passwordMessage;
        else if (! passwordChangeMessage.IsBlank()) retval = passwordChangeMessage;
        else if (! warningMessage.IsBlank()) retval = warningMessage;
        else if ((! copyrightMessage.Contain("COPYRIGHT")) && (! copyrightMessage.IsBlank())) retval = copyrightMessage;
    }

    return(retval);
}

/*
*   function:   failLogin()
*   parameters: errorMsg - the error message to return
*   return:     none
*   remarks:
*           Do whatever is necessary if the login was a failure.
*/
function failLogin(errorMsg) {
    setCurrentRegion (getCurrentRegion(),"bad","user");
    myTask.setComplete("LOGIN_FAILURE", errorMsg);
    resetState();
    CBGenkey("H:@3");
}
