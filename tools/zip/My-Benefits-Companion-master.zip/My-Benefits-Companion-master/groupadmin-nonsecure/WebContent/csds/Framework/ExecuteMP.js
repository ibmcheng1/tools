/*
 * Copyright (c) 2004 BlueCross BlueShield of South Carolina. All rights reserved.
 *
 * $Author:   EN80  $
 * $Workfile:   ExecuteMP.js  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 16:30:36  $
 */

//Language=JavaScript
include("Framework\\TaskProcessor.js");
include("Framework\\Util.js");
include("Framework\\Blank.js");
include("Framework\\Validate.js");

/*  This is the generic message processor for the entry csd. */

var processId   = GetNameValue(params[0], "ProcessID");
var scriptToRun = GetNameValue(params[0], "ScriptToRun");
var region  = GetNameValue(params[0], "Region");
var racfid  = GetNameValue(params[0], "RACFID");
var racfpassword= GetNameValue(params[0], "RACFPassword");
var ndcMdc      = GetNameValue(params[0], "NDCMDC");

resetState();

ONTDebug(processId + ":" + scriptToRun, "EVENT", "Creating new TaskProcessor");

var myTask = new TaskProcessor(processId, scriptToRun);
myTask.params = params[0];

myTask.region = region != "" ? region : getRegion();
myTask.racfid = racfid != "" ? racfid : c.commonFields.racfid;
myTask.racfpassword = racfpassword != "" ? racfpassword : c.commonFields.racfpassword;
myTask.ndcMdc = ndcMdc;

@if( @saveParamsInContainer == true)
    eval("c." + c.commonFields.paramsContainer + "=params[0]");
    myTask.params = undefined;
@end

c.TaskProcessor = (new Persistable()).persistToXML(myTask);

c.commonFields.singletonRun = 0;
if ( region!="" && racfid!="" && racfpassword!="" ) {
  if ( region!=getRegion() || racfid!=c.commonFields.racfid || racfpassword!=c.commonFields.racfpassword )
    c.commonFields.singletonRun = 1;
}
c.commonFields.connectionAttempts = 0;

if(r.screenrecord.Contain("ENTER REQUEST ==>")) {
  if( regionErrors() > 8) {
    CBSetCursor( 3, 1 );
    CBGenKey("H:@F");
    CBGenKey("H:"+myTask.region+"@E");
  } else {
    CBGenKey("H:@E");
  }
} else {
    if (r.screenrecord.IsBlank() || (r.screenrecord.Contain("SIGN-ON IS COMPLETE"))) {
        var thisPage = "BLANK";
        if (myTask.getValue("validateOnly") != "") {
            validateOnly();
        } else {
            BlankScreen();
        }
    } else {
        CBGenKey("H:@C");
    }
}

function regionErrors()
{
    var errorCount = 0;
    errorCount += r.screenrecord.MatchCount("COMMAND UNRECOGNIZED");
    errorCount += r.screenrecord.MatchCount("UNABLE TO ESTABLISH");
    errorCount += r.screenrecord.MatchCount("UNSUPPORTED FUNCTION");

    return errorCount;
}
