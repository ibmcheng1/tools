/*
 * Copyright (c) 2004 BlueCross BlueShield of South Carolina. All rights reserved.
 *
 * $Author:   EN80  $
 * $Workfile:   pageUtils.js  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 16:30:48  $
 */

include("Framework\\Util.js");

pageUtils.prototype.m_recordsAsVectors;     // when data is returned, convert records to vectors
pageUtils.prototype.m_lastPage;             // this is the last page to be scraped.  Return when done scraping
pageUtils.prototype.m_multiplePages;        // split each page scraped into it's own parameter
pageUtils.prototype.m_hasVectors;           // internally used to note there are vectors to convert
pageUtils.prototype.rec_delim;              // internally used to denoted records to "vectorize"
pageUtils.prototype.getContext              = pageUtils_getContext;             // get the rpc object
pageUtils.prototype.getParam                = pageUtils_getParam;               // get the rpc param
pageUtils.prototype.getRootParam            = pageUtils_getRootParam;           // get the root rpc param
pageUtils.prototype.scrapePage              = pageUtils_scrapePage;             // scrape a page
pageUtils.prototype.setRecordsAsVectors     = pageUtils_setRecordsAsVectors;    // toggle converting records to vectors
pageUtils.prototype.setLastPage             = pageUtils_setLastPage;            // toggle last page to scrape
pageUtils.prototype.setMultiplePages        = pageUtils_setMultiplePages;       // toggle split each page into it's own parameter
pageUtils.prototype.getReturnData           = pageUtils_getReturnData;          // perform final processing and return rpc.toString()
pageUtils.prototype.screenFieldsToXML       = pageUtils_screenFieldsToXML       // internally used by scrape page
pageUtils.prototype.paramsToScreenFields    = pageUtils_paramsToScreenFields    // pass all parameters onto the current page
pageUtils.prototype.scrapePage              = pageUtils_scrapePage              // scrape the current page into the rpc object
pageUtils.prototype.addScreenRecordsToXML   = pageUtils_addScreenRecordsToXML   // add records from the current screen into the rpc object
pageUtils.prototype.getArrayObject          = pageUtils_getArrayObject          // internally used
pageUtils.prototype.convertRecordsToVector  = pageUtils_convertRecordsToVector  // internally used
pageUtils.prototype.vectorizeParams         = pageUtils_vectorizeParams         // internally used
pageUtils.prototype.vectorizeObject         = pageUtils_vectorizeObject         // internally used
pageUtils.prototype.splitVector             = pageUtils_splitVector             // internally used
pageUtils.prototype.setStatus               = pageUtils_setStatus               // set return status in root parameter
pageUtils.prototype.complete                = pageUtils_complete                // set return status and complete

var g_REC_DELIM = "rec---";

/*
*  function:   pageUtils()
*  parameters: none
*  return:     constructed pageUtils object
*  remarks:
*
*/
function pageUtils() {
    this.setRecordsAsVectors(true);
    this.setLastPage(true);
    this.setMultiplePages(false);
    this.m_hasVectors = new Boolean(false);
    return this;
}

/*
*  function:   getContext()
*  parameters: none
*  return:     a valid rpc object
*  remarks:
*/
function pageUtils_getContext() {
    var rpc;
    try {
        if(myTask.CurrentContext.rpc == null) {
         rpc = myTask.CurrentContext.rpc = new RPCMethodResponse();
        } else {
         rpc = myTask.CurrentContext.rpc;
        }
    }
    catch(e) {
        // only here because there is no myTask.CurrentContext
        generateErrorCondition(myTask.process, e.message, e.number);
    }
    return rpc;
}

/*
*  function:   getParam()
*  parameters: none
*  return:     rpc parameter valid for the current context
*  remarks:
*
*/
function pageUtils_getParam() {
    var param;
    var rpc = this.getContext();
    try {
        if((this.m_multiplePages == true) && ((rpc.params.length > 0) || (this.m_lastPage == false))) {
            var pparam;
            if(rpc.params.length == 0) {
                  pparam = rpc.addParameter(new RPCStruct());
            } else {
                pparam = rpc.params[0].parameter;
            }
            param = new RPCStruct();
            pparam.add(thisPage, param);
        } else {
            param = rpc.addParameter(new RPCStruct());
        }
    }
    catch(e) {
    }
    return param;
}

/*
*  function:   getParam()
*  parameters: none
*  return:     rpc parameter valid for the current context
*  remarks:
*
*/
function pageUtils_getRootParam() {
    var param;
    var rpc = this.getContext();
    if(rpc.params.length == 0) {
        param = rpc.addParameter(new RPCStruct());
    } else {
          param = rpc.params[0].parameter;
    }
    return param;
}

/*
*  function:   getpageUtils()
*  parameters: none
*  return:     constructed pageUtils object
*  remarks:
*
*/
function getPageUtils() {
    var utl;

    if(myTask.CurrentContext.pageUtils == null) {
        utl = new pageUtils();
        myTask.CurrentContext.pageUtils = utl;
    } else {
        utl = myTask.CurrentContext.pageUtils;
    }
    return utl;
}

/*
*  function:   setRecordsAsVectors()
*  parameters: boolean to indicate whether the records should be converted to vectors
*  return:     none
*  remarks:
*
*/
function pageUtils_setRecordsAsVectors(b) {
    this.m_recordsAsVectors = new Boolean(b);
    if(b == true) {
        this.rec_delim = g_REC_DELIM;
    } else {
        this.rec_delim = "";
    }
}

/*
*  function:   setLastPage()
*  parameters: boolean to indicate this is the last page
*  return:     none
*  remarks:
*
*/
function pageUtils_setLastPage(b) {
    this.m_lastPage = new Boolean(b);
}

/*
*  function:   setMultiplePages()
*  parameters: boolean indicating to store each scraped page into it's own parameter
*  return:     none
*  remarks:
*
*/
function pageUtils_setMultiplePages(b) {
    this.m_multiplePages = new Boolean(b);
}

/*
*  function:   screenFieldsToXML()
*  parameters: param - rpc parameter where the data will be added to
*               arrayFields - list of field names to grab off the screen
*               rec - boolean value denoting if this is a record (versus being a field)
*  return:     none
*  remarks:    Routine grabs from the current screen every field listed in the array
*               and adds the data to the rpc parameter.
*/
function pageUtils_screenFieldsToXML(param, arrayFields, rec) {
    var bRecs = (rec == null) ? false : rec;

    if((param == null) || (arrayFields == null)) {
        ONTDebug(myTask.process, "EVENT", "screenFieldsToXML parameter error.");
    } else {
        for(var i = 0; i < arrayFields.length; i++) {
            try {
                if(bRecs) {
                    if(this.m_recordsAsVectors == true) {
                        this.m_hasVectors = new Boolean(true);
                    }
                    param.add(this.rec_delim + arrayFields[i], new RPCString(r[arrayFields[i]]));
                } else {
                    param.add(arrayFields[i], new RPCString(f[arrayFields[i]]));
                }
            }
            catch(e) {
                // log exception.  IT's because a field is not on the page.
                LogSystemError(myTask.process, "field " + arrayFields[i] + " not present on page " + thisPage);
            }
        }
    }
}

/*
*  function:   paramsToScreenFields()
*  parameters: arrayFields - list of field names to map from the request to the screen
*  return:     none
*  remarks:    Routine grabs the params passed in from the jsp and for every one listed
*               in the list of arrays (arrayFields), it copies the data to the screen.
*/
function pageUtils_paramsToScreenFields(arrayFields, arrayRecords) {
    if(arrayFields == null) {
        ONTDebug(myTask.process, "EVENT", "paramsToScreenFields parameter error.");
    } else {
        for(var i = 0; i < arrayFields.length; i++) {
            var data = myTask.getValue(arrayFields[i]);
            if((data != null) && (data.Trim() != "")) {
                f[arrayFields[i]] = data;
            }
        }
    }
    if(arrayRecords != null) {
        for(var i = 0; i < arrayRecords.length; i++) {
            var data = myTask.getValue(arrayRecords[i]);
            if((data != null) && (data.Trim() != "")) {
                r[arrayFields[i]] = data;
            }
        }
    }
}

/*
*  function:   scrapePage()
*  parameters: pageName - The page name as defined in auto screen handler
*               shortPageName - page name used for logging errors i.e. DNXV, RMID, etc.
*               arrayFields - array of field names to retrieve off the page
*               arrayRecords = array of record names to retrieve off the page
*               subscrape - boolean indicating whether this is part of a multiple "scrape" process
*                   if it is, this iteration won't end task.
*               onlyOne = boolean indicating there is only one page returned.
*  return:     none
*  remarks:
*        Returns all data on the page if page matches pageName or logs an unexpected page error
*/
function pageUtils_scrapePage(pageName, shortPageName, arrFields, arrRecords /*, subscrape, onlyOne*/) {
    var rpc;
    var param;
    var pparam;

    var msg = new String(r.message);
    msg = msg.Trim().toUpperCase();
    if(msg.indexOf("ABEND") != -1) {
        generateErrorCondition(shortPageName, "abend occurred.", -3);
        return;
    }
   if(thisPage == pageName) {
        rpc = this.getContext();
        param = this.getParam();
        this.screenFieldsToXML(param, arrFields, false);
        if(arrRecords != null) {
            this.screenFieldsToXML(param, arrRecords, true);
        }
        if(this.m_lastPage == true) {
            var message;
            if(typeof(f.eesm) != "unknown") {
                message = f.eesm.value.Trim();
            } else if(typeof(f.message) != "unknown") {
                message = f.message.value.Trim();
            } else {
                message = r.message.Trim();
            }
            this.complete("SUCCESS", message);
        } else {

        }
   } else {
      generateErrorCondition(shortPageName, "Was expecting page " + pageName, -2);
   }
    // reset last page
    this.m_lastPage = new Boolean(true);
}

/*
*  function:   addScreenRecordsToXML()
*  parameters: param - rpc parameter where the data will be added to
*               arrayFields - list of field names to grab off the screen
*  return:     none
*  remarks:    Routine grabs from the current screen every field listed in the array
*               and adds the data to the rpc parameter.
*/
function pageUtils_addScreenRecordsToXML(param, arrayFields) {
    if((param == null) || (arrayFields == null)) {
        ONTDebug(myTask.process, "EVENT", "addScreenRecordsToXML parameter error.");
    } else {
        for(var i = 0; i < arrayFields.length; i++) {
            try {
                if(this.m_recordsAsVectors == true) {
                    this.m_hasVectors = new Boolean(true);
                }
                var elem = this.getArrayObject(this.rec_delim + arrayFields[i], param);
                if(elem != null) {
                    elem.value += r[arrayFields[i]];
                }
            }
            catch(e) {
                // log exception.  IT's because a field is not on the page.
                LogSystemError(myTask.process, "field " + arrayFields[i] + " not present on page " + thisPage);
            }
        }
    }
}


/*
*  function:   getArrayObject()
*  parameters: aryName - name of the rpc array to find
*               param - rpc parameter where the rpc array object is in
*  return:     rpc array object with matching name
*  remarks:    This routine searches for an rpc array object inside the rpc
*               parameter passed
*/
function pageUtils_getArrayObject(aryName, param) {
    var elem = null;

    if(param.members != undefined) {
        for(var i = 0; i < param.members.length; i++) {
            var name = param.members[i].memberid;
            if(name == aryName){
                elem = param.members[i].valueObject;
                break;
            }
        }
    }
    return elem;
}


/*
*  function:   convertRecordsToVector()
*  parameters: none
*  return:     none
*  remarks:    This routine searches the rpc array object for records (items with a name beginning
*               with rec_delim and splits the contents into an rpc array
*/
function pageUtils_convertRecordsToVector() {
    if(this.m_hasVectors == true) {
        var rpc = myTask.CurrentContext.rpc;
        if(rpc != null) {
            for(var i = 0; i < rpc.params.length; i++) {    // really there should only be one here
                var param = rpc.params[i].parameter;
                if(param != null) {
                    this.vectorizeParams(param); // recursive function to handle strings, rpcstructs or rpcarrays
                }
            }
        }
    }
}

/*
*  function:   vectorizeParams()
*  parameters: param - RPCParam
*  return:     none
*  remarks:    This routine traverses the rpc param for records needing conversion to an array
*               Used internally by convertRecordsToVector()
*/
function pageUtils_vectorizeParams(param) {
    if(param != null) {
        if(param.members != undefined) {
            // rpcstruct or array
            for(var i = 0; i < param.members.length; i++) {
                var elem = param.members[i];
                this.vectorizeObject(elem);
            }
        } else {
            // possibly string, check for record indicator
            if((param.memberid != undefined) && (param.memberid.indexOf(this.rec_delim) == 0)) {
                this.splitVector(param);
            }
        }
    }
}

/*
*  function:   vectorizeObject()
*  parameters: param - object
*  return:     none
*  remarks:    This routine traverses the object (if contains members) for records needing
*               conversion to an array
*               Used internally by convertRecordsToVector()
*/
function pageUtils_vectorizeObject(param) {
    if(param != null) {
        if((param.valueObject != undefined) && (param.valueObject.members != undefined)) {
            for(var i = 0; i < param.valueObject.members.length; i++) {
                var obj = param.valueObject.members[i];
                this.vectorizeObject(obj);
            }
        } else {
            if((param.memberid != undefined) && (param.memberid.indexOf(this.rec_delim) == 0)) {
                this.splitVector(param);
            }
        }
    }
}

/*
*  function:   splitVector()
*  parameters: elem - object
*  return:     none
*  remarks:    This routine converts the string object into an rpc array
*               Used internally by convertRecordsToVector()
*/
function pageUtils_splitVector(elem) {
    var rpcary = new RPCArray();
    var arr = elem.valueObject.value.split("\r");
    for(var j = 0; j < arr.length; j++) {
        rpcary.add(new RPCString(arr[j]));
    }
    elem.valueObject = rpcary;
    elem.memberid = elem.memberid.substring(this.rec_delim.length, elem.memberid.length);
}

/*
*  function:   getReturnData()
*  parameters: none
*  return:     completed rpc object (to String)
*  remarks:
*
*/
function pageUtils_getReturnData() {
    var rpc = this.getContext();
    if(this.m_hasVectors == true) {
        this.convertRecordsToVector();
    }
    return rpc.toString();
}

/*
*  function:   setStatus()
*  parameters: status code     - (SUCCESS or FAILURE)
*               message         - EESM message or other custom message
*  return:     none
*  remarks:    sets the status in the root parameter for app to check
*/
function pageUtils_setStatus(status, message) {
    var param = this.getRootParam();
    param.add("Status", new RPCString(status));
    param.add("Page", new RPCString(thisPage));
    param.add("Message", new RPCString(message));
}

/*
*  function:   complete()
*  parameters: status code     - (SUCCESS or FAILURE)
*               message         - EESM message or other custom message
*  return:     none
*  remarks:    sets the status in the root parameter for app to check,
*               ends the task and clears the screen
*/
function pageUtils_complete(status, message) {
    this.setStatus(status, message);
   SetReturnData(this.getReturnData());
   myTask.setComplete();
   CBGenKey("H:@C");
}