/*
 * Copyright (c) 2004 BlueCross BlueShield of South Carolina. All rights reserved.
 *
 * $Author:   EN80  $
 * $Workfile:   config.js  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 16:30:32  $
 */

include("Framework\\region.js");

INIFilePath = "D:\\CommercialWeb\\WEB-INF\\classes\\ini\\pbentry_config.ini";
try
{
    var path = new String(c.prefFile);
    if(path.length > 0) {
        INIFilePath = path;
    }
}
catch(e)
{
}

/*
*   function:   commonFields()
*   parameters: none
*   return:     a commonFields instance object if new operator is used.
*   remarks:    Object used to hold certain common configuration variables.
*
*   [10/29/2002 RVP]    Update currentApp to use the c.CBWAppID
*/

function commonFields()
{
    this.prefFile               = "";
    this.prefsArray             = "";
    this.prefsLastModified      = "";
    this.cgipath                = "";
    this.currentApp             = c.CBWAppID;
    this.debug                  = "";
    this.racfid                 = "";
    this.racfpassword           = "";
    this.region                 = [];
    this.currentRegionNdx       = 0;
    this.noEOBPrefixes          = "";
    this.eobExists              = "0";
    this.eobStatus              = "";
    this.logEntry               = "";
    this.logAccess              = "";
    this.logSystemError         = "";
    this.systemErrorLogFile     = "";
    this.accessLogFile          = "";
    this.traceLogFile           = "";
    this.currentDate            = "";
    this.superUserID            = "";
    this.ONTDebug               = "0";
    this.maxConnectionAttempts  = 3;
    this.connectionAttempts     = 0;
    this.curRegionNum           = "";
    this.cmd                    = "";
    this.logEnhanced            = "";
    this.logUrl                 = "";
    this.singletonRun           = 0;
    this.autoRetryAbend         = "";
    this.regionSelectsExceeded= 0;
@if( @saveParamsInContainer == true)
    this.paramsContainer        = "";
@end
}

function init_commonFields()
{
    this.prefFile               = INIFilePath;
    this.prefsArray             = getINIContents(this.prefFile);
    this.prefsLastModified      = c.commonFields.prefsLastModified;
    this.cgipath                = getINIValue(this.prefFile, "Local", "CGIPATH", "D:\\logs\\commercialweb\\");
    this.currentApp             = c.CBWAppID;
    this.debug                  = getINIValue(this.prefFile, "WebPack", "DEBUG", 0);

    if (c.commonFields.currentRegionNdx == undefined)
     this.currentRegionNdx      = 0;
    else
     this.currentRegionNdx      = c.commonFields.currentRegionNdx

    if (c.commonFields.racfid == undefined)
     this.racfid                = getINIValue(this.prefFile, "WebPack", "RACF", "NOUSER");
    else
     this.racfid                = c.commonFields.racfid;

    if (c.commonFields.racfpassword == undefined)
      this.racfpassword           = getINIValue(this.prefFile, "WebPack", "RACF_PW", "NOPASS");
    else
      this.racfpassword           = c.commonFields.racfpassword;

    this.region                   = this.setRegions("WebPack","MF_REGION","CICSO");

    if (this.currentApp.Contain("PBStatus"))
    {
        this.noEOBPrefixes      = getINIValue(this.prefFile, "WebPack", "NO_EOB_PREFIXES", "");
        this.eobStatus          = getINIValue(this.prefFile, "EOBS", "EOB_STATUS", "");
    }
    else
    {
        this.noEOBPrefixes      = "";
        this.eobStatus          = "";
    }

    this.logEntry               = "";
    this.logAccess              = "";
    this.logSystemError         = "";
    this.systemErrorLogFile     = "";
    this.accessLogFile          = "";
    this.traceLogFile           = "";
    this.currentDate            = "";
    this.superUserID            = "";
    this.ONTDebug               = "0";
    this.eobExists              = "0";
    this.maxConnectionAttempts  = parseInt(getINIValue(this.prefFile, "WebPack", "maxConnectionAttempts", "3"));
    if(isNaN(this.maxConnectionAttempts))
        this.maxConnectionAttempts = 3;
    this.connectionAttempts     = 0;
    this.curRegionNum           = getINIValue(this.prefFile, "WebPack", "NO_EOB_PREFIXES", "");
    this.cmd                    = "";
    this.logEnhanced            = getINIValue(this.prefFile, "WebPack", "LOG_ENHANCED", "false");
    this.logUrl                 = getINIValue(this.prefFile, "WebPack", "LOG_ENHANCED_URL", "http://localhost/log");
    this.singletonRun           = 0;
    this.autoRetryAbend         = getINIValue(this.prefFile, "WebPack", "AUTO_RETRY_ABEND", "_notused_");

@if( @saveParamsInContainer == true)
    this.paramsContainer        = getINIValue(this.prefFile, "WebPack", "PARAMS_CONTAINER", "");
@end

}


commonFields.prototype.init = init_commonFields;
commonFields.prototype.setRegions = setRegions;
commonFields.prototype.prefFile;
commonFields.prototype.prefsArray;
commonFields.prototype.prefsLastModified;
commonFields.prototype.cgipath;
commonFields.prototype.currentApp;
commonFields.prototype.debug;
commonFields.prototype.racfid;
commonFields.prototype.racfpassword;
commonFields.prototype.region;
commonFields.prototype.currentRegionNdx;
commonFields.prototype.noEOBPrefixes;
commonFields.prototype.eobStatus;
commonFields.prototype.eobExists;
commonFields.prototype.logEntry;
commonFields.prototype.logAccess;
commonFields.prototype.logSystemError;
commonFields.prototype.systemErrorLogFile;
commonFields.prototype.accessLogFile;
commonFields.prototype.traceLogFile;
commonFields.prototype.currentDate;
commonFields.prototype.superUserID;
commonFields.prototype.ONTDebug;
commonFields.prototype.maxConnectionAttempts;
commonFields.prototype.connectionAttempts;
commonFields.prototype.curRegionNum;
commonFields.prototype.cmd;
commonFields.prototype.logEnhanced;
commonFields.prototype.logUrl;
commonFields.prototype.singletonRun;
commonFields.prototype.autoRetryAbend;

@if( @saveParamsInContainer == true)
commonFields.prototype.paramsContainer;
@end

/*
*   function:   getINIValue()
*   parameters: path <string>           : the file system path to the ini file
                header <string>         : the section of the ini file to look for the key
                key <string>            : the name of the value to look for
                defaultValue <string>   : the default value to return in case the key, header, or file isn't found
*   return:     <string> : the value found in the inifile or the default value
*   remarks:
*           Function will open a FileSystemObject instance to check the existence of the specified ini file.
*           If the file is found, it will read through the ini file to find the proper header, then find the specified
*           key.  When the key is found, it will then read the value and return that value.
*           If any part of the process fails, it will return the default value passed.
*/
function getINIValue(path, header, key, defaultValue) {
    var bFound = false, i = -1, out = defaultValue, s = "", t;
    header = "\[" + header.toLowerCase() + "\]";
    try
    {
        var arrIniFile = getINIContents(path);
        for(j = 0; j < arrIniFile.length; j++)
        {
            s = arrIniFile[j];
            if (s.indexOf(";") == 0)
            {
                //comment
            }
            else
            {
                if (s.toLowerCase() == header)
                {
                    // found header
                    bFound = true;
                }
                else if(bFound && s.charAt(0) == '\[')
                {
                    break;
                }
                if (bFound)
                {
                    //look for the key name and if
                    //found, grab the value of the key
                    i = s.indexOf("=");
                    if (i > -1)
                    {
                        t = s.substring(0, i);
                        if (key.toLowerCase() == t.toLowerCase())
                        {
                            out = s.substring(i + 1, s.length);
                            break;
                        }
                    }
                }
            }
        }
    }
    catch(e)
    {
        out = defaultValue;
        LogSystemError("Config::getINIValue", "\nThere has been an exception in getINIValue.\nException:" + e.description + "\nDefault value has been returned.");
    }

    return out;
}
/*
  FUNCTION: getINIContents
  PURPOSE:  retrieves the ini file contents from either the file system or the stored contents depending on
            whether the ini file has been updated.
  INPUT:    file system path to ini file
  OUTPUT:   array of ini file lines
 */
function getINIContents(path)
{
    var bFound = false;
    var arrOut = new Array();
    var fso;
    var f;

    fso = jspakObjs.getFileSysObj();
    f = fso.GetFile(path);

    if( (c.commonFields.prefsLastModified == null) || (f.DateLastModified > c.commonFields.prefsLastModified)
        || (c.commonFields.prefsArray == null) )
    {
        ONTDebug("Config::getINIContents()", "EVENT", "Refresh Initialization Values\nLoading INI File:" + path + "\nFile Modified " + f.DateLastModified);

        c.commonFields.prefsLastModified = f.DateLastModified;
        f = fso.opentextfile(path, 1, false);
        while (!f.AtEndOfStream)
        {
            arrOut[arrOut.length] = f.readline();
        }
        f.close();
        c.commonFields.prefsArray = arrOut;
    }
    else
    {
        arrOut = c.commonFields.prefsArray;
    }
    f = null;
    fso = null;

    return arrOut;
}


/*
  FUNCTION: changeDateFormat
  PURPOSE:  convert a date in various formats
  INPUT:    date: mm/dd/yy format (SSNO/NGAR/RMHI/RMHF/RMCL(1) screens)
                  mmddyy (RMVP, RMHS, RMCS)
  OUTPUT:   date in mm/dd/yyyy format
 */
function changeDateFormat (datePassed)
{
    var date = new String(datePassed);
    var newDate = "";
    if (date == "")
    {
        newDate = "          ";  // just return 8 spaces.
    }
    else if (date.length == 10)  // already formatted correctly, including '/'.
    {
        newDate = date;
    }
    else if (date.length > 6 && date.charAt(2) == "/")   // 0 based.    01/01/02
    {
        month   = date.substr(0,2);
        day     = date.substr(3,2);
        year    = date.substr(6);
        year    = formatCentury(year);
    }
    else if (date.length == 8 && date.charAt(2) != "/")   // just needs slashes.  20020101
    {
        month   = date.substr(0,2);
        day     = date.substr(2,2);
        year    = date.substr(4);
        year    = formatCentury(year);
    }
    else if (date.length == 6 && date.charAt(2) != "/")   // needs century and slashes.  010102
    {
        month   = date.substr(0,2);
        day     = date.substr(2,2);
        year    = date.substr(4);
        year    = formatCentury(year);
    }

    newDate = month + "/" + day + "/" + year;

    return newDate;
}

/*
*   function:   formatCentury()
*   parameters: year <string> : The two-digit year to format into a four-digit year.
*   return:     <string> the four-digit year
*   remarks:
*           Function will check for a two-digit year and determine whether the century should be
*           2000 or 1900.  It will then return the year with the proper century attached.
*/
function formatCentury(year)
{
    /* window year at 30 */
    if (year.length < 4)         // stick in the century.
    {
        if (year < "30")
            year = "20" + year;
        else
            year = "19" + year;
    }
    return year;
}


/*
   FUNCTION:    dateDiff
   PURPOSE:     calculate the difference between 2 dates in CCYYMMDD format, in days.
   INPUTS:      2 dates in CCYYMMDD format - assumes date and it's format is pre-edited.
   OUTPUTS:     difference in days
   AUTHOR:      .Net Systems
*/
function dateDiff(fromDate, toDate)
{
    var firstDate   = new Date(fromDate.substr(0,4), fromDate.substr(4,2), fromDate.substr(6,2));
    var secondDate  = new Date(toDate.substr(0,4), toDate.substr(4,2), toDate.substr(6,2));
    var daysDiff = (secondDate.valueOf() - firstDate.valueOf());
    daysDiff = Math.floor(Math.abs((((daysDiff  / 1000) / 60) / 60) / 24));
    return daysDiff;
}

/*
     PURPOSE:     extract comma separated property values
     INPUTS:      section, prop key and default
     OUTPUTS:     array of string values
     AUTHOR:      .Net Systems
*/
function setRegions (sect,prop,def)
{
      var cregion = getCurrentRegion();
      this.currentRegionNdx = 0;
      var ar = getINIValue(this.prefFile,sect,prop,def);
      ar = ar.split(",");
      for (i=0;i<ar.length;i++) {
        ar[i] = ar[i].Trim();
        if (cregion == ar[i]) {
          this.currentRegionNdx = i;
          break;
        }
      }

      return ar;
}

/*
   PURPOSE:     accessor for cics region
   INPUTS:      none
   OUTPUTS:     returns region
   AUTHOR:      .Net Systems
*/
function getRegion()
{
  return c.commonFields.region.length > 0 ? c.commonFields.region[c.commonFields.currentRegionNdx] : "";
}


/*
   PURPOSE:     bumps region ndx or wraps back to 0
   INPUTS:      none
   OUTPUTS:     true bumped to next region
                  or false when it wraps around
   AUTHOR:      .Net Systems

*/
function bumpCurrentRegion()
{
   var rc = true;
   c.commonFields.currentRegionNdx++;
   if (c.commonFields.currentRegionNdx+1 > c.commonFields.region.length) {
     c.commonFields.currentRegionNdx = 0;
     rc = false;
   }
   return rc;
}
