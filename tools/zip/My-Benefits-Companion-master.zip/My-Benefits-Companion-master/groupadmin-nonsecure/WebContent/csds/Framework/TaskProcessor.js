/*
 * Copyright (c) 2004 BlueCross BlueShield of South Carolina. All rights reserved.
 *
 * $Author:   EN80  $
 * $Workfile:   TaskProcessor.js  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 16:30:54  $
 */

include("Framework\\ObjectPersistence.js");
include("Framework\\XMLRPC.js");
include("Framework\\Util.js");
include("Framework\\pageUtils.js");
include("Framework\\region.js");

/*
    TaskProcessor is used to provide support for the execution of a specified task.
    Functions and objects are provided to affect the program flow, data access, and data storage.
*/
TaskProcessor.prototype.execute         = TaskProcessor_execute;
TaskProcessor.prototype.getValue        = TaskProcessor_getValue;
TaskProcessor.prototype.goToProcess     = TaskProcessor_goToProcess;
TaskProcessor.prototype.isComplete      = TaskProcessor_isComplete;
TaskProcessor.prototype.isNewRegion     = TaskProcessor_isNewRegion;
TaskProcessor.prototype.isNewUser       = TaskProcessor_isNewUser;
TaskProcessor.prototype.setComplete     = TaskProcessor_setComplete;
TaskProcessor.prototype.setProcessId    = TaskProcessor_setProcessId;
TaskProcessor.prototype.setScriptToRun  = TaskProcessor_setScriptToRun;
TaskProcessor.prototype.setOriginalScriptToRun  = TaskProcessor_setOriginalScriptToRun;
TaskProcessor.prototype.throwException  = TaskProcessor_throwException;


/*
*   constructor:TaskProcessor()
*   parameters: processId <string>  : cics transaction to go to from the blank screen
*               scriptToRun <string>: javascript function to execute upon enterring the specified transaction
*               params <array>      : named value parameters passed from through the webpack adapter in JSP
*   return:     <TaskProcessor> : new TaskProcessor object
*   remarks:
*           intializes a new TaskProcessor object.
*/
function TaskProcessor(processId, scriptToRun, params)
{
    this.process = processId;
    this.scriptToRun = scriptToRun;
    this.complete = false;
    this.params = params;
    this.region = "";
    this.racfid = "";
    this.racfpassword = "";
    this.ndcMdc = "";
    this.originalScriptToRun = "";
    this.processCalled = false;

    this.execute        = TaskProcessor_execute;
    this.getValue       = TaskProcessor_getValue;
    this.goToProcess    = TaskProcessor_goToProcess;
    this.isComplete     = TaskProcessor_isComplete;
    this.isNewRegion    = TaskProcessor_isNewRegion;
    this.isNewUser      = TaskProcessor_isNewUser;
    this.setComplete    = TaskProcessor_setComplete;
    this.setProcessId   = TaskProcessor_setProcessId;
    this.setScriptToRun = TaskProcessor_setScriptToRun;
    this.throwException = TaskProcessor_throwException;
    this.setOriginalScriptToRun = TaskProcessor_setOriginalScriptToRun;

    this.CurrentContext = new Context();

}

/*
*   function:   TaskProcessor_execute()
*   parameters: none
*   return:     none
*   remarks:
*           executes the TaskProcessors specified "scriptToRun"
*           provides error handling if that script fails
*           if there is an exception or script error, the function will generate a
*           RPCMethodResponse and return the error message thrown to the web page.
*           It will then call setComplete() on the current TaskProcessor and clear the screen
*/
function TaskProcessor_execute()
{
    if(this.isNewRegion())
    {
        CBGenkey("H:off@E");
        ONTDebug("TaskProcessor::execute()", "EVENT", "The region has changed.  Log off.");
    }
    else if (this.isNewUser())
    {
        runCESN(this);
    }
    else
    {
        try{
            var script = this.scriptToRun;
            if(script.indexOf("(") != -1) {
                script = script.slice(0, script.indexOf("("));
                if(eval("typeof " + script) != "undefined") {
                    ONTDebug("TaskProcessor::execute()", "EVENT", "Executing script:" + this.scriptToRun + ".");
                    this.processCalled = false;
                    eval(this.scriptToRun);
                } else {
                    ONTDebug("TaskProcessor::execute()", "EVENT", "Script:" + this.scriptToRun + "not found on page " + thisPage + ".");
                    var e = new Error();
                    e.number = -1;
                    e.message = this.scriptToRun + "not found on page " + thisPage + ".";
                    e.name = "Logical error";
                    throw e;
                }
            } else {
                ONTDebug("TaskProcessor::execute()", "EVENT", "Script:" + this.scriptToRun + "does not appear to be a valid script.");
                var e = new Error();
                e.number = -1;
                e.message = this.scriptToRun + "not found on page " + thisPage + ".";
                e.name = "Logical error";
                throw e;
            }
        }
        catch(e)
        {   // If there is an unhandled error executing the script, then generate a method response
            // to send back to the calling web page.
            var errormessage = "\nThere has been a JavaScript Scripting Error running the script for " + this.process + "::" + this.scriptToRun + "\n" + e.name + ":" + e.number + "\n" + e.message;

            LogSystemError(this.process + ":" + this.scriptToRun, "\nCSD SCRIPT ERROR" + errormessage + "\n\n[Parameters]\n" + this.params + "\n");
            var scriptexception = new TCException(1, "\nCSD SCRIPT ERROR", errormessage + "\nPlease see the CSD trace file and error log for more information.\n");
            SetReturnData(scriptexception.toXMLRPCFault());

            this.setComplete();
            CBGenKey("H:@C");
        }
    }
}

/*
*   function:   TaskProcessor_getValue()
*   parameters: key <string>: string containing the key name for a given value
*   return:     <string> :  value specified by the key name passed.
*   remarks:
*           Will search the params array for the value for the specified key
*           if there is no value corresponding to the passed key name,
*           then an empty string is returned.
*/
function TaskProcessor_getValue(key)
{
    return GetNameValue(this.params, key);
}

/*
*   function:   TaskProcessor_setComplete()
*   parameters: status <string> (optional): the status value to return
                message <string> (optional): the message if any, to return
*   return:     none
*   remarks:
*           sets the complete setting to true, clears the TaskProcessor container, and calls TaskEnd()
*           if status is passed, generates an rpc method response with the passed status and message.
*/
function TaskProcessor_setComplete(status, message)
{
    if(status != null)
    {
        var rpc = new RPCMethodResponse();
        var param = rpc.addParameter(new RPCStruct());
        param.add("Status", new RPCString(status));

        if(thisPage != null)
            param.add("Page", new RPCString(thisPage));

        if(message != null)
            param.add("Message", new RPCString(message));

        SetReturnData(rpc.toString());
    }

    this.complete = true;
    c.TaskProcessor = "";
    ONTDebug(this.process + ":" + this.scriptToRun, "EVENT", "Set Task Complete");
}

function TaskProcessor_throwException(shortname, description, number)
{
    if(number == null)
        number = 1;
    var scriptexception = new TCException(number, shortname, description);
    SetReturnData(scriptexception.toXMLRPCFault());
    this.setComplete();
}
/*
*   function:   TaskProcessor_setProcessId()
*   parameters: processId <string> : value representing the transaction to execute at the blank screen
*   return:     none
*   remarks:
*           sets the processid to go to at the blank screen.
*/
function TaskProcessor_setProcessId(processId)
{
    this.process = processId;
}

/*
*   function:   TaskProcessor_setScriptToRun()
*   parameters: scriptToRun <string>: value representing the javascript function to execute
*   return:     none
*   remarks:
*           sets the function for the TaskProcessor to execute next.
*/
function TaskProcessor_setScriptToRun(scriptToRun)
{
    this.scriptToRun = scriptToRun;
    this.setOriginalScriptToRun("enterClaim()");
}

/*
*   function:   TaskProcessor_setOriginalScriptToRun()
*   parameters: scriptToRun <string>: value representing the javascript function to execute
*   return:     none
*   remarks:
*           sets the function for the TaskProcessor to execute next.
*/
function TaskProcessor_setOriginalScriptToRun(scriptToRun)
{
    this.originalScriptToRun = scriptToRun;
}

/*
*   function:   TaskProcessor_goToProcess()
*   parameters: none
*   return:     none
*   remarks:
*           checks to see if the region needs changing, if it doesn't,
*           then generate a key sequence to go to the specified process
*/
function TaskProcessor_goToProcess()
{
    if(this.processCalled == true || this.processCalled == "true") {
      ONTDebug("TaskProcessor::goToProcess()", "EVENT", "Process has already been called");
        return;
    }

    if(this.isNewRegion())
    {
        ONTDebug("TaskProcessor::goToProcess()", "EVENT", "The region and/or racf credentials have changed.  Log off.");
        CBGenkey("H:off@E");
    }
    else if (this.isNewUser() || (GetNameValue(this.params, "validateOnly") != ""))
    {
        runCESN(this);
    }
    else if(this.process != null && this.process.length > 0)
    {
        if( this.getValue("preProcess") != "" && (!this.CurrentContext.exists("preProcessCompleted"))) {
            cmd = "H:" + this.getValue("preProcess") + "@E";
            this.CurrentContext.setVar("preProcessCompleted", "true");
            CBGenkey(cmd);
            saveTask(this);
            ONTDebug("TaskProcessor::goToProcess()", "EVENT", "Go to process:" + this.getValue("preProcess") + ".");
        } else {
            CBGenKey("H:" + this.process + "@E");
            this.processCalled = true;
            saveTask(this);
            ONTDebug("TaskProcessor::goToProcess()", "EVENT", "Go to process:" + this.process + ".");
        }

    }
}

/*
*   function:   TaskProcessor_isComplete()
*   parameters: none
*   return:     <boolean>: whether or not the task has been completed.
*   remarks:
*           specifies whether a task has been completed or not
*/
function TaskProcessor_isComplete()
{
    if(this.complete == null)
        this.complete = false;

    if (this.complete == "false")
        return false;
    else
        return true;
}

/*
*   function:   TaskProcessor_isNewRegion()
*   parameters: none
*   return:     <boolean>: whether or not the region needs changing.
*   remarks:
*           [under development] checks to see if the region needs changing
*/
function TaskProcessor_isNewRegion()
{
    if(thisPage != "REGION")
    {
      return (this.region != getCurrentRegion());
    }
    else
      return false;
}

/*
*   function:   TaskProcessor_isNewUser()
*   parameters: none
*   return:     <boolean>: whether or not the login needs changing.
*   remarks:
*           [under development] checks to see if the login needs changing
*/
function TaskProcessor_isNewUser()
{
    if(thisPage != "REGION")
    {
        return (this.racfid != getCurrentRacf() || this.racfpassword != getCurrentRacfPassword());
    }
    else
        return false;
}

/*
*   function:   runCESN()
*   parameters: none
*   return:     none
*   remarks:
*               runs CESN and sets the task to preProcessor mode
*               RTE 08.06.2003  Added code to check and handle a password containing "@"
*/
function runCESN(myTask) {
    ONTDebug("TaskProcessor::execute()", "EVENT", "The racf credentials have changed.  Use CESN.");

    // escape each occurance of "@" with "@@" in the password.
   var pword = myTask.racfpassword.ReplaceAll("@", "@@", 0);
    if (pword == 0)
    {
        pword = myTask.racfpassword;
    }
    // run CESN to switch users
    var cmd = "H:CESN USERID=" + myTask.racfid + ",PS=" + pword + "@E";

    myTask.CurrentContext.setVar("cesnComplete", "true");
    saveTask(myTask);
    CBGenkey(cmd);

}

/* ------------------------------- Functions enabling the TaskProcessor -------------------*/

/*
*   function:   getTask()
*   parameters: none
*   return:     <TaskProcessor>: the current TaskProcessor instance.
*   remarks:
*           retrieves the current TaskProcessor instance from it's stored text representation in c.TaskProcessor
*/
function getTask()
{
    if (c.TaskProcessor == null || c.TaskProcessor == "")
          return null;

    theTask = (new Persistable()).persistFromXML(c.TaskProcessor);
    @if( @saveParamsInContainer == true)
        eval("theTask.params=c." + c.commonFields.paramsContainer);
    @end

    return theTask;
}


/*
*   function:   saveTask()
*   parameters: theTask <TaskProcessor>: the taks to persist
*   return:     none
*   remarks:
*           serializes the current TaskProcessor and stores it in the c.TaskProcessor container.
*/
function saveTask(theTask)
{
    @if( @saveParamsInContainer == true)
        eval("c." + c.commonFields.paramsContainer + "=theTask.params");
        theTask.params = undefined;
    @end
    c.TaskProcessor = (new Persistable()).persistToXML(theTask);
}

/*
*   function:   isReady()
*   parameters: none
*   return:     <boolean>: whether or not there is a current TaskProcessor instance available
*   remarks:
*           checks to see if there is a current TaskProcessor instance.
*/
function isReady()
{
    if (c.TaskProcessor.indexOf("<undefined>") == -1 && c.TaskProcessor.indexOf("</undefined>") == -1)
    {
        if(typeof(c.TaskProcessor) == "string" && c.TaskProcessor.length > 0)
            return true;
        else
            return false;
    }
    else
    {
        return false;
    }
}


/* ------------------------------- The Context Object --------------------------*/
/*
    This object can be used for storage of variables that need to be persisted between screens.
    This object and it's functions are provided as a convenience, as they need not be used

    Usage is as follows.

    var myArray = new Array();
    myArray[0] = "One";

    myTask.CurrentContext.setVar("TheArray", myArray);
    --- Screen Change ---

    if(myTask.CurrentContext.exists("TheArray"))
        var myArray = myTask.CurrentContext.getVar("TheArray");

*/
Context.prototype.setVar = Context_setVar;
Context.prototype.getVar = Context_getVar;
Context.prototype.exists = Context_exists;
function Context()
{
    this.setVar = Context_setVar;
    this.getVar = Context_getVar;
    this.exists = Context_exists;
}

function Context_setVar(theVar, theVal)
{
    this[theVar] = theVal;
}

function Context_getVar(theVar)
{
    return this[theVar];
}

function Context_exists(theVar)
{
    theVar = this[theVar];
    return (theVar != null);
}
