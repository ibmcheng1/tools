/**
 * Copyright Notice     (c) 1999, 2004 BlueCross BlueShield of South Carolina. All rights reserved.
 *
 * This function handles all the error handling for the unexpected screen.
 *
 * @author    $Author:   EN80  $
 * @workfile  $Workfile:   UnexpectedScreenHandler.js  $
 * @version   $Revision:   1.0  $
 * @date      $Date:   Jun 26 2009 16:30:56  $
 */

var myTask = getTask();

function UnexpectedScreenHandler()
{
    var screenContents = new String(r.screenrecord);
    /* Per help, the screen is contained in params[0] when unexpected. */
    var message = "\n****\n\nUnexpected screen handler invoked, offending screen:\n\n" + screenContents + "\n\n****\n\nNote: screenrecord below reflects screen prior to the unexpected screen.\n\n";

    if(isReady()) {

        // c.commonFields.autoRetryAbend is from the ini file and contains the CICS abend upon which when received
        // we are to retry the process.
        if ( myTask.originalScriptToRun > "" && screenContents.Contain(c.commonFields.autoRetryAbend) ) {
            message = "\n****\n\nIMS Database Lockout:\n\n" + screenContents + "\n\n****\n\nNote: screenrecord below reflects screen prior to the unexpected screen.\n\n";
            LogSystemError(myTask.process + ":" + myTask.scriptToRun, message + "\n[Parameters]\n" + myTask.params + "\n");
            LogSystemError(myTask.process + ":" + " setting scriptToRun back to " + myTask.originalScriptToRun);
            myTask.setScriptToRun(myTask.originalScriptToRun);
            saveTask(myTask);
            ONTDebug(myTask.process, "EVENT", "myTask.setScriptToRun( \"" + myTask.originalScriptToRun + "\" )" );
            LogSystemError(myTask.process + ":" + " scriptToRun is now " + myTask.scriptToRun);
        } else {

            var errorMsg = "Error Screen: UNEXPECTED SCREEN ENCOUNTERED WHEN RUNNING TRANSACTION." + myTask.process;

            // check for transaction access errors
            if (   (screenContents.indexOf(" NO ") != -1  && screenContents.indexOf(" ACCESS ") != -1)
                || (screenContents.indexOf(" NOT ALLOWED ") != -1) || (screenContents.indexOf(" not authorized ") != -1)
                || (screenContents.indexOf("DOES NOT HAVE ACCESS") != -1)
                || (screenContents.indexOf("DOES NOT HAVE AUTHORITY") != -1)
                || (screenContents.indexOf("SECURITY VIOLATION - RACF") != -1)
                ||((screenContents.indexOf("DOES NOT HAVE") != -1) && (screenContents.indexOf("SECURITY") != -1))
                || (screenContents.indexOf(" RACF-ID NOT DEFINED ") != -1) ) {

                var pageUtil = getPageUtils();
                pageUtil.complete("NOTAUTH", "OPERATOR IS NOT AUTHORIZED TO USE TRANSACTION "+ myTask.process+ " IN REGION "+myTask.region);

            }else if(screenContents.indexOf("failed with abend") != -1){
                var msg = screenContents.replace(/\s+/g," ");
                generateErrorCondition("ABEND",msg,-1);
            } else if (screenContents.indexOf("SECURITY VIOLATION") != -1) {
                // *NOT* a RACF one (above) but an app specific message (comes from SEVF sometimes)
                var pageUtil = getPageUtils();
                pageUtil.complete("NOTAUTH", "SECURITY VIOLATION - OPERATOR IS NOT AUTHORIZED TO USE TRANSACTION "+ myTask.process+ " IN REGION "+myTask.region);
            }else{
                myTask.setScriptToRun("generateErrorCondition('ERROR', '"+ errorMsg + "', -2);");
            }
            if(!myTask.isComplete()) {
                myTask.execute();
                saveTask(myTask);
            }

        }
    } else {

        LogSystemError("Unexpected screen handler", message);
        var screenContents = new String(r.screenrecord);

        if (screenContents.Contain("UNABLE TO ESTABLISH"))
        {
            c.CurrentRegion         = null;     // force logging in if stuck on the blank screen
            c.commonFields.prefFile = null;     // force resetstate() in defaultregion() to execute.
        }
    }

    if (screenContents.Contain("UNABLE TO ESTABLISH"))
    {
        // logoff to get a new login screen with the screen recognition line "BC/BS ENTER REQUEST"
        CBGenKey("H:LOGOFF@E");
    } else {
        CBGenKey("H:@C");
    }

}
