/*
 * Copyright (c) 2004 BlueCross BlueShield of South Carolina. All rights reserved.
 *
 * $Author:   EN80  $
 * $Workfile:   Exception.js  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 16:30:34  $
 */

@if(
   @Exception_Include != 1
)

@set @Exception_Include = 1
/*
*  function:   TCException()
*  parameters: none
*  return:     A generated TCException object if new operator is used.
*  remarks:
*        This function will populate a prototyped exception class for use in returning errors to calling web pages.
*/
function TCException(){
   this.errNumber = -1;
   this.errShortDesc = "Generic Exception";
   this.errLongDesc = "Unspecified";
   this.stateInformation = "";
   this.urlHandler = "";

   switch(arguments.length){
      case 5:
         this.urlHandler = arguments[4];
      case 4:
         this.stateInformation = arguments[3];
      case 3:
         this.errLongDesc = arguments[2];
      case 2:
         this.errShortDesc = arguments[1];
      case 1:
         this.errNumber = arguments[0];
      default:
      case 0:
         break;
   }
   // If in debugging mode, throw and exception
   @if(
      @debug == 1
   )
      debugger;
   @end
}

/*
*  function:   getErrorNumber()
*  parameters: none
*  return:     <number> : the TCException instance's error number
*  remarks:
*        This is an accessor function.
*/
TCException.prototype.getErrorNumber = function(){
   return(this.errNumber);
}

/*
*  function:   getShortDescription()
*  parameters: none
*  return:     <string> : the TCException instance's short description
*  remarks:
*        This is an accessor function.
*/
TCException.prototype.getShortDescription = function(){
   return(this.errShortDesc);
}

/*
*  function:   getLongDescription()
*  parameters: none
*  return:     <string> : the TCException instance's long description
*  remarks:
*        This is an accessor function.
*/
TCException.prototype.getLongDescription = function(){
   return(this.errLongDesc);
}

/*
*  function:   getStateInformation()
*  parameters: none
*  return:     <string> : the TCException instance's state information
*  remarks:
*        This is an accessor function.
*/
TCException.prototype.getStateInformation = function(){
   return(this.stateInformation);
}

/*
*  function:   getURLHandler()
*  parameters: none
*  return:     <string> : the TCException instance's url handler
*  remarks:
*        This is an accessor function.
*/
TCException.prototype.getURLHandler = function(){
   return(this.urlHandler);
}

/*
*  function:   toString()
*  parameters: none
*  return:     <string> : the string representation of the TCException instance
*  remarks:
*        This provides a standard format for the display of the exception for logging, etc...
*/
TCException.prototype.toString = function(){
   return("TCException:\n" +
      "\t" + this.errNumber + "\n" +
      "\t" + this.errShortDesc + "\n" +
      "\t" + this.errLongDesc + "\n" +
      "\t" + this.stateInformation + "\n" +
      "\t" + this.urlHandler + "\n");
}

/*
*  function:   toXMLRPCFault()
*  parameters: none
*  return:     <string> : the XML RPC representation of the TCException instance
*  remarks:
*        This function provides a means of sending the exception back to the web server
*/
TCException.prototype.toXMLRPCFault = function(){
   return(methodResponseFault(
      struct(
         member("faultCode", integer(this.errNumber)) +
         member("faultString", string(this.errShortDesc + " : " + this.errLongDesc))
      )
   ));
}

@end