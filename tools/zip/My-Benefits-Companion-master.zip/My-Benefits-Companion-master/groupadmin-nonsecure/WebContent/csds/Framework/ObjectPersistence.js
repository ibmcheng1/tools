/*
 * Copyright (c) 2004 BlueCross BlueShield of South Carolina. All rights reserved.
 *
 * $Author:   EN80  $
 * $Workfile:   ObjectPersistence.js  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 16:30:46  $
 */

@if(
   @ObjectPersistence != 1
)

@set @ObjectPersistence = 1

include("Framework\\XMLParser.js");

/*
   Persitable object is used to convert between objects and an xml representation of those objects.
   persistToXML converts a JSObject to XML serializing objects and their values.
   persistFromXML converts from XML to a JSObject hierarchy maintaining object values.
*/
function Persistable(){
      //debugger;
      this.persistToXML = function(obj){
        // find this class and retrieve name from the object registrar
        var className = "";

        switch((typeof obj).toUpperCase()){
            case "OBJECT":
               className = this.getType(obj);
                 break;
            default:
                className = typeof obj;
                break;
        }

        // start generating the xml using the classname for the root element name
        var xml = STag(className);
      var val;
        var index;

        // iterate over each instance property and generate xml
        // if a member is of type object, then recursively call self

        switch(className.toUpperCase()){
        case "ARRAY":
            for(index in obj){
               if(((typeof obj[index]).toUpperCase()) != "FUNCTION"){
                   xml += STag("index") + this.persistToXML(obj[index]) + ETag("index");
               }
            }
            break;
        case "STRING":
        case "BOOLEAN":
        case "DATE":
        case "NUMBER":
            xml += escapeXML(obj);
            break;
        default:
            for(val in obj){
                switch((typeof obj[val]).toUpperCase()){
                    case "OBJECT":
                        xml += STag(val) + this.persistToXML(obj[val]) + ETag(val);
                        break;
                    case "FUNCTION":
                        break;
                    default:
                        xml += STag(val) + escapeXML(obj[val]) + ETag(val);
                        break;
               }
            }
            break;
        }
        xml += ETag(className);
        return(xml);
    }

    this.persistFromXML = function(xml){
        var parser;
        var dom;

        // Check to see if we got XML or a DOM
        if((typeof xml).toUpperCase() == "STRING"){
            parser = new MinXMLDocument(xml, parseCharRefs);
            dom = parser.documents;
        } else {
            dom = xml;
        }

      eval("var obj = new " + dom[0].nodeName + "();");

        var i = 0;

        // Special case handling here for arrays
        if(dom[0].nodeName == "Array"){
            var index;
            switch((typeof dom[0].nodeValue).toUpperCase()){
               case "OBJECT":
               for(index in dom[0].nodeValue){
                  switch((typeof dom[0].nodeValue[index].nodeValue[0].nodeValue).toUpperCase()){
                     case "OBJECT":
                     obj.push(this.persistFromXML(dom[0].nodeValue[index].nodeValue));
                     break;
                  default:
                     obj.push(dom[0].nodeValue[index].nodeValue[0].nodeValue);
                     break;
                  }
               }
               break;
               default:
               // Empty arrays cause an empty string value here which will break the mechanism
               break;
            }
      } else if (dom[0].nodeName == "String"){
            obj = new String(dom[0].nodeValue);
      } else if (dom[0].nodeName == "Boolean"){
          obj = new Boolean(dom[0].nodeValue == "true");
        } else if (dom[0].nodeName == "Date"){
            obj = new Date(dom[0].nodeValue);
        } else if (dom[0].nodeName == "Number"){
            obj = new Number(dom[0].nodeValue);
        }else {

            // Iterate over all members and set according to xml values.  If value is an object,
            // call self recursively
            while((typeof dom[0].nodeValue[i]).toUpperCase() == "OBJECT"){
                if((typeof dom[0].nodeValue[i].nodeValue).toUpperCase() != "OBJECT"){
                    obj[dom[0].nodeValue[i].nodeName] = dom[0].nodeValue[i].nodeValue;
                } else {
                    obj[dom[0].nodeValue[i].nodeName] = this.persistFromXML(dom[0].nodeValue[i].nodeValue);
                }
                i++;
            }
        }

        return(obj);
    }

    this.funcRegExp = new RegExp("^\\s*function\\s+([^\\s(]+)", "");

    this.getType = function(obj){
      this.funcRegExp.exec(obj.constructor.valueOf());

      return(RegExp.$1);
   }
}

// End of persistance classes

function STag(str){ return("<" + str + ">");}
function ETag(str){ return("</" + str + ">");}

@end