/*
 * Copyright (c) 2004 BlueCross BlueShield of South Carolina. All rights reserved.
 *
 * $Author:   EN80  $
 * $Workfile:   AutoScreenHandler.js  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 16:30:28  $
 */

include("Framework\\TaskProcessor.js");

var thisPage;
var myTask;

function handleScreen(screenName){

    thisPage = new String(screenName);
    myTask = getTask();

    if (myTask != null) {

        if(!myTask.isComplete())
        {
            myTask.execute();
            saveTask(myTask);
        }
    } else {
        clearScreen();
    }
}
