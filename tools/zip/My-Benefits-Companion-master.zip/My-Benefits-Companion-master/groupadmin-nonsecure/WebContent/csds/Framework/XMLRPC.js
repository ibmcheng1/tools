include("Framework\\Exception.js");
include("Framework\\XMLParser.js");

@if(
    @XMLRPC_Include != 1
)

@set @XMLRPC_Include = 1

/*
*   XMLRPC

    The following objects and functions are used to generate valid XML-RPC Method Response objects for
    communication back to the remote calling web server.
    
    
    RPCMethodResponse       : The top most parent object in the method response.
    RPCMethodResponseFault  : A pre-defined variant of the method response for transmitting faults.
    RPCMember               : A member variable containing a name and a value.
    RPCParam                : A parameter.  Usually contained within an array of parameters in the method response.
    RPCArray                : A numerically indexed array that can contain valid members.
    RPCStruct               : A structure similar to a hashtable.  Contains named members which can be arrays, structs, or member types.
    RPCInt                  : An integer value object for use in an RPCMember object
    RPCBool                 : A boolean value object for use in an RPCMember object
    RPCString               : A string value object for use in an RPCMember object
    RPCDouble               : A double value object for use in an RPCMember object
    RPCDateTime             : A date time value object for use in an RPCMember object
    RPCBase64               : A base 64 value object for use in an RPCMember object
    
    ###
    Typical Usage:
    
    var rpc = new RPCMethodResponse();

    var newArray = rpc.addParameter(new RPCArray());
    newArray.add(new RPCInt(5));
    newArray.add(new RPCInt(6));

    var newStruct = rpc.addParameter(new RPCStruct());
    newStruct.add("val1", new RPCInt(1));
    newStruct.add("val2", new RPCBool(1));
    newStruct.add("val3", new RPCString("whatever"));
    newStruct.add("val4", new RPCDouble(1.567));
    newStruct.add("val5", new RPCString("another string"));
    newStruct.add("val6", new RPCDouble(Math.PI));

    var responseXML = rpc.toString();

*/

// Declare Objects and their methods
RPCMethodResponse.prototype.addParameter  = RPCMethodResponse_addParameter;
RPCMethodResponse.prototype.toString      = RPCMethodResponse_toString;
RPCMethodResponse.prototype.size          = RPCMethodResponse_size;
RPCMethodResponseFault.prototype.toString = RPCMethodResponseFault_toString;
RPCMember.prototype.toString              = RPCMember_toString;
RPCParam.prototype.toString               = RPCParam_toString;
RPCArray.prototype.add                    = RPCArray_add;
RPCArray.prototype.toString               = RPCArray_toString;
RPCStruct.prototype.add                   = RPCStruct_add;
RPCStruct.prototype.size                  = RPCStruct_size;
RPCStruct.prototype.toString              = RPCStruct_toString;
RPCStruct.prototype.toElementArray        = RPCStruct_toElementArray;
RPCInt.prototype.toString                 = RPCInt_toString;
RPCBool.prototype.toString                = RPCBool_toString;
RPCString.prototype.toString              = RPCString_toString;
RPCBase64.prototype.toString              = RPCBase64_toString;
RPCDateTime.prototype.toString            = RPCDateTime_toString;
RPCDouble.prototype.toString              = RPCDouble_toString;

function RPCMethodResponse()
{
    this.params = new Array();
}
function RPCMethodResponseFault()
{
    this.fault = new RPCStruct();
    return this.fault;
}
function RPCMember(memberid, valueObject)
{
    this.memberid = memberid;
    this.valueObject = valueObject;
}
function RPCParam(parameter)
{
    this.parameter = parameter;
}
function RPCArray()
{
    this.members = new Array();
}

function RPCStruct()
{
    this.members = new Array();
}

function RPCInt(value)
{
    this.value = value;
}

function RPCBool(value)
{
    var tmp = new Boolean(value);
    this.value = (tmp == true) ? "1" : "0";
}


function RPCString(value)
{
    this.value = new String(value);
}

function RPCDouble(value)
{
    this.value = new Number(value);
}
function RPCDateTime(value)
{
    this.value = new String(value);
}

function RPCBase64(value)
{
    this.value = value;
}

// .add() functions

function RPCMethodResponse_addParameter(parameter)
{
    this.params[this.params.length] = new RPCParam(parameter);
    return this.params[this.params.length - 1].parameter;
}

function RPCArray_add(memberObject)
{
    this.members[this.members.length] = memberObject;
}

function RPCStruct_add(memberid, memberObject)
{
    this.members[this.members.length] = new RPCMember(memberid, memberObject);
}

// .size() function
function RPCMethodResponse_size()
{
    try{
        return this.members.length;
    }catch(Exception){
        return 0;
    }
    
}
function RPCStruct_size()
{
    try{
        return this.members.length;
    }catch(Exception){
        return 0;
    }
    
}
// .toString() functions
function RPCMethodResponse_toString()
{
    var response = "";
    var i = 0;
    for(i=0;i<this.params.length;i++)
    {
        response += this.params[i].parameter.toString();
    }
    return methodResponse(response);
}

function RPCMethodResponseFault_toString()
{
    return methodResponseFault(this.fault);
}

function RPCArray_toString()
{
    var response = "";
    var i = 0;
    for(i=0;i<this.members.length;i++)
    {
        response += this.members[i].toString();
    }
    return array(response);
}

function RPCStruct_toString()
{
    var response = "";
    var i = 0;
    for(i=0;i<this.members.length;i++)
    {
        response += this.members[i].toString();
    }
    return struct(response);
}

function RPCParam_toString()
{
    return param(this.parameter.toString());
}

function RPCMember_toString()
{
    return member(this.memberid, this.valueObject.toString());
}

function RPCInt_toString()
{
    return integer(this.value);
}

function RPCBool_toString()
{
    return boolean(this.value);
}


function RPCStruct_toElementArray()
{
    return this.members;
}


// 08/05/2004 - JBH
// matches all characters outside the normal 0-127 ASCII character codes
var escapeRegExp = /([\x80-\xFF])/g;

// 08/05/2004 - JBH
// provide an XML escape sequence for 1 character of 2nd parameter.  
// This function signature is compatible with the requirements of the String.replace method.
function escapeCharXML(match, submatch1) {
    return("&#" + submatch1.charCodeAt(0) + ";");
}

function RPCString_toString()
{
    // 08/05/2004 - JBH
    // escape ASCII values in the range of 0x80-0xFF.
    // The escapeCharXML function is ONLY called for characters which match the regular expression.
    return(string(this.value.replace(escapeRegExp, escapeCharXML )));    
}

function RPCDouble_toString()
{
    return double(this.value);
}

function RPCDateTime_toString()
{
    return dateTime(this.value);
}

function RPCBase64_toString()
{
    return base64(this.value);
}

/*  Object -> String conversion */

function methodResponse(msg){
    return("<methodResponse><params>" + msg + "</params></methodResponse>");
}

function methodResponseFault(msg){
    return("<methodResponse><fault>" + msg + "</fault></methodResponse>");
}

function param(msg){
    return("<param>" + msg + "</param>");
}

function array(msg){
    return("<value><array><data>" + msg + "</data></array></value>");
}

function struct(msg){
    return("<value><struct>" + msg + "</struct></value>");
}

function member(name, value){
    return("<member><name>" + escapeXML(name) + "</name>" + value + "</member>");
}

function integer(val){
    return("<value><i4>" + val + "</i4></value>");
}

function boolean(val){
    return("<value><boolean>" + val + "</boolean></value>");
}

function string(val){
    return("<value><string>" + escapeXML(val) + "</string></value>");
}

function double(val){
    return("<value><double>" + val + "</double></value>");
}

function dateTime(val){
    return("<value><dateTime.iso8601>" + val + "</dateTime.iso8601></value>");
}

function base64(val){
    return("<value><base64>" + val + "</base64></value>");
}

function parseValue(xml){
    var tempNode;
    var i;
    var retObj;

    // Check to see if we got XML or a DOM
    if((typeof xml).toUpperCase() == "STRING"){
        parser = new MinXMLDocument(xml, parseCharRefs);
        dom = parser.documents;
        dom = dom[0];
    } else {
        dom = xml;
    }
    
    //Verify the value tag
    if(dom.nodeName != "value"){
        throw(new TCException(-1, "Invalid value XML specified"));
    }
    
    // only 1 immediate child possible under a value
    switch(dom.nodeValue[0].nodeName){
        case "i4":
        case "int":
        return(parseInt(dom.nodeValue[0].nodeValue));
        break;
        
        case "boolean":
        return((dom.nodeValue[0].nodeValue == "1")?true:false);
        break;
        
        case "string":
        return(dom.nodeValue[0].nodeValue);
        break;
        
        case "double":
        return(parseFloat(dom.nodeValue[0].nodeValue));
        break;
        
        case "struct":
        var memberName;
        var memberValue;
        
        retObj = new Object();
        
        tempNode = dom.nodeValue[0].nodeValue;
        for(i in tempNode){
            memberName = tempNode[i].nodeValue[0].nodeValue;
            memberValue = parseValue(tempNode[i].nodeValue[1]);
            
            retObj[memberName] = memberValue;
        }
        
        return(retObj);
        break;
        
        case "array":
        retObj = new Array();
        tempNode = dom.nodeValue[0].nodeValue[0];

        // This condition handles the possiblity of an empty array
        if((typeof tempNode.nodeValue) != "string"){        
            for(i in tempNode.nodeValue){
                retObj[retObj.length] = parseValue(tempNode.nodeValue[i]);
            }
        }
        
        return(retObj);
        break;
        
        default:
        throw(new TCException(-1, "Unknown or unhandled type sepecified"));
        break;
    }
    
}

@end