/*
 * Copyright (c) 2004 BlueCross BlueShield of South Carolina. All rights reserved.
 *
 * $Author:   EN80  $
 * $Workfile:   resetState.js  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 16:30:52  $
 */

/*
   FUNCTION NAME: resetState
   PURPOSE:    reset state variables, read in prefs file,
                                 end session & return page to user
   INPUTS:        ???
   OUTPUTS:    none

   Modifications:
   Chg.
   Sht.  Pgmr.    Date     Descr.
   P19940   C. Fowler   10/01/2002  Initial creation for entry.
*/

function resetState()
{
   dt    = new Date();   //Gets today's date right now (to the millisecond).
   month    = dt.getMonth() + 1;
   monthString = month.toString();
   if (monthString.length == 1)
     monthString = "0" + monthString;
   day   = dt.getDate();
   dayString = day.toString();
   if (dayString.length == 1)
     dayString = "0" + dayString;
   year  = dt.getFullYear();
   yearString = year.toString();

        var tmp = new commonFields(); // create temp
        tmp.init();                   // uses c.commonFields
        c.commonFields = tmp;         // replace it now

   c.commonFields.currentDate = yearString + monthString + dayString;
   prepareLogFiles();
   return(1);
}

/*
*  function:   getFullYear()
*  parameters: none
*  return:     the full four-digit year
*  remarks:
*        function returns the full four digit year if necessary
*/
function getFullYear()
{
      var year = this.getYear();
      if(year < 1000)
         year += 1900;
      return year;
}



