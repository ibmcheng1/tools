/*
 * @(#)dynamicDivs.js
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * Commerical Website Shared Registration
 * JavaScript Dynamic div functions
 *
 * This is a shared file.  Please see the following file for information
 * regarding the use of Shared Registration JSPs:
 *   D:/Netscape/Shared/registration/shared_readme.txt
 *
 * @author      Jonathan Egger
 * @version     $Revision:   1.0  $ - $Date:   Jul 31 2009 15:06:32  $
 * @since       1.0
 *
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-web-webpages/common/common/dynamicDivs.js_v  $

   Rev 1.0   Jul 31 2009 15:06:32   EN80
Initial revision.

   Rev 1.3   Jun 03 2008 17:02:38   rx29e
C15021 : Clife MBC changes - Fixed the issue with the menus when there are no submenus. Created a new division than modifying the old division as these are common files.

   Rev 1.2   May 20 2008 22:29:50   rx29e
Fixed the issue with the menus when there are no submenus.

   Rev 1.1   Dec 17 2004 15:53:52   rxg97
Added browserSniffer(), whatBrows() and showLayer().

   Rev 1.0   Sep 23 2004 09:59:08   rxg97
Initial revision.
 */

var type = "IE";    //Variable used to hold the browser name
browserSniffer();

/**
 * Detects the capabilities of the browser
 */
function browserSniffer() {
    if (navigator.userAgent.indexOf("Opera")!=-1 && document.getElementById) type="OP"; //Opera
    else if (document.all) type="IE";                                                   //Internet Explorer e.g. IE4 upwards
    else if (document.layers) type="NN";                                                //Netscape Communicator 4
    else if (!document.all && document.getElementById) type="MO";                       //Mozila e.g. Netscape 6 upwards
    else type = "IE";       //I assume it will not get here
}

/**
 * Alerts the brower type
 */
function whatBrows() {
    window.alert("Browser is : " + type);
}

/**
 * Show or hide a layer (div).
 *
 * @param id  the name of the layer
 * @param action  either hidden or visible
 */
function showLayer(id, action){
    if (type=="IE") eval("document.all." + id + ".style.visibility='" + action + "'");
    if (type=="NN") eval("document." + id + ".visibility='" + action + "'");
    if (type=="MO" || type=="OP") eval("document.getElementById('" + id + "').style.visibility='" + action + "'");
}

/**
 * Sets the divs (banner, content and button) that make up a scroll button
 * style page.  Only forces the buttons to the bottom of the page if the 
 * content will require scrolling.
 *
 * @param bannerheight  the height of the banner.
 * @param contentheight  the height of the content.
 * @param buttonheight  the height of the buttons.
 */
function autoSetScrollButtonDivs(bannerheight, contentheight, buttonheight) {

    windowheight = getHeight();
    
    windowcontentheight = windowheight - bannerheight - buttonheight;

    if (windowcontentheight < contentheight) {
        contentheight = windowcontentheight;
    }
    
    // Layer height setting is browser-specific
    if(type=="NN") {
        if(document.BannerDivison) {
            document.BannerDivison.height = bannerheight;
        }
        else {
            document.bannerDiv.height = bannerheight;
        }
        document.contentDiv.height = contentheight;
    } 
    
    if(type=="IE") {
        if(document.all.BannerDivison) {
            document.all.BannerDivison.style.height = bannerheight;
        }
        else {
            document.all.bannerDiv.style.height = bannerheight;
        }
        document.all.contentDiv.style.height = contentheight;
    } 
    
    if (type=="MO" || type=="OP") {
        if(document.getElementById("BannerDivison")) {
            document.getElementById("BannerDivison").style.height = bannerheight;
        }
        else {
            document.getElementById("bannerDiv").style.height = bannerheight;
        }
        document.getElementById("contentDiv").style.height = contentheight;
    }
}

/**
 * Sets the divs (banner, content and button) that make up a scroll button
 * style page.  Forces the buttons to the bottom of the page bottom of the 
 * page if the content will require scrolling.
 */
function setScrollButtonDivs(bannerheight, buttonheight) {
    autoSetScrollButtonDivs(bannerheight, 10000, buttonheight);
}

/**
 * Sets the divs (banner and content) that make up a scroll style page.
 * No buttons will be forced to the bottom.
 */
function setScrollDivs(bannerheight) {
    autoSetScrollButtonDivs(bannerheight, 10000, 0);
}

/**
 * Performs browser-specific calls to get the window height
 */
function getHeight() {
    var myHeight = 0;
    if( typeof( window.innerHeight ) == 'number' ) {
        myHeight = window.innerHeight;
    } else if( document.documentElement && ( document.documentElement.clientHeight ) ) {
        myHeight = document.documentElement.clientHeight;
    } else if( document.body && ( document.body.clientHeight ) ) {
        myHeight = document.body.clientHeight;
    }
    
    return myHeight;
}