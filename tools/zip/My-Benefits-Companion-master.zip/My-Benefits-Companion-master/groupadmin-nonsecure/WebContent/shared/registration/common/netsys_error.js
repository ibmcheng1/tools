// Error and validation code.

var ERROR_HIGHLIGHT_COLOR_ON = "pink";
var ERROR_HIGHLIGHT_COLOR_OFF = "white";
var ERROR_HIGHLIGHT_BACKGROUND_ON = "BodyTextError";
var ERROR_HIGHLIGHT_BACKGROUND_OFF = "BodyText";
var ERROR_HIGHLIGHT_IMAGE_ON = "/images/redpixel.gif";
var ERROR_HIGHLIGHT_IMAGE_OFF = "/images/clearpixel.gif";
var USE_STYLESHEET_ERRORS = true;

var currentFormName = "theForm";

//stores the validation errors array
var arrErr = new Array();

//stores the server side errors array
var arrServerErrors = new Array();

//stores the dialog window reference
var errorDialog=null;

// Since links in Internet Explorer 4 can't be disabled, preserve IE link onclick 
// event handlers while they're "disabled." Restore when reenabling the main window.
var IELinkClicks=null; 

//used to enable browser specific dialog code
var isNS = ((navigator.appName == "Netscape"));
var isIE4 = ((navigator.appName.indexOf("Microsoft")>=0)&&(navigator.appVersion.indexOf("MSIE 4.") >= 0));


/****
    focusAndSelectField( string )
    Utility function to focus on a specified field when coming back from a page post.
*/
function focusAndSelectField(strFieldName)
{
    var theForm = getForm();
    var field = null;

    if(strFieldName != "")
        field = eval("theForm." + strFieldName);

    if( field != null )
    {
        field.focus();
        if(strFieldName.indexOf("txt") >= 0)
        {
            field.select();
        }
    }
}


/**
 *  FORM VALIDATION CODE
 *
 *
 */

/**
 * since IE and NN4 cannot disable onclick events, this function is used to change links to reload our modal window
 * note - this function is not used if window.showModalDialog is supported
 */
function redirectToWindow() { 
   if ((errorDialog)&&(!errorDialog.closed)){
      handleWindow();
      return false;
   }
}
 

/** 
 * Disable form elements and links in all frames for IE4, saving all link locations in IELinkClicks array
 * all links will now call redirectToWindow()
 * note - this function is not used if window.showModalDialog is supported 
 */
function disableForms() {
   IELinkClicks = new Array();   
   for (var h = 0; h < top.frames.length; h++) {
      for (var i = 0; i < top.frames[h].document.forms.length; i++) {
         for (var j = 0; j < top.frames[h].document.forms[i].elements.length; j++) {
            top.frames[h].document.forms[i].elements[j].disabled = true;
         }
      }
      IELinkClicks[h] = new Array();
      for (i = 0; i < top.frames[h].document.links.length; i++) {
         IELinkClicks[h][i] = top.frames[h].document.links[i].onclick;
         top.frames[h].document.links[i].onclick = redirectToWindow;
      }
   }
}

/**
 * Restore IE4 form elements and links to normal behavior.
 * note - this function is not used if window.showModalDialog is supported
 */
function enableForms() {
   for (var h = 0; h < top.frames.length; h++) {
      for (var i = 0; i < top.frames[h].document.forms.length; i++) {
         for (var j = 0; j < top.frames[h].document.forms[i].elements.length; j++) {
            top.frames[h].document.forms[i].elements[j].disabled = false;
         }
      }
      for (i = 0; i < top.frames[h].document.links.length; i++) {
         top.frames[h].document.links[i].onclick = IELinkClicks[h][i];
      }
   }
}

/**
 * disable the current browser window including framesets (get lock)
 * note - this function is not used if window.showModalDialog is supported 
 */
function disableWindow(){
         if (isNS){
             //needed for NN to disable main page
             //override the default event model to refocus the modal dialog 
            for(var i=0;i<top.frames.length;i++){
                top.frames[i].captureEvents(Event.CLICK | Event.MOUSEDOWN | Event.MOUSEUP | Event.FOCUS);
                top.frames[i].onclick=redirectToWindow;
                top.frames[i].onfocus=handleWindow;
            }
         
             
         }else{
             //IE does not allow event locking, so disable all of the form elements in each of the frames
             disableForms();             
         }//end if NN
    
}

/**
 * enable the current browser window including framesets (release lock)
 * note - this function is not used if window.showModalDialog is supported 
 */
function enableWindow(){
        if (isNS){
             //restore the default event model
            for(var i=0;i<top.frames.length;i++){
                top.frames[i].releaseEvents(Event.CLICK | Event.MOUSEDOWN | Event.MOUSEUP | Event.FOCUS);
                top.frames[i].onclick=null;
                top.frames[i].onfocus=null;
            }
                                            
        }else{
             //IE does not allow event model locking, so re-enable all of the form elements we disabled
             enableForms();
        }//end if NN    
}


/**
 * display errors in a modal browser pop-up window, (equivalent of alertErrors() function)
 * the error array is parsed and sent as a comma delimited string as a POST to
 * the specified url.  
 *
 * @param blankURL location of an empty page, used by browsers that dont support showModalDialog
 * @param dialogURL location of the page used to parse and display the errors
 * @param maxErrors the maximum number of errors to display
 * @param windowWidth the width of the pop-up window (in pixels)
 * @param baseWindowHeight the base height of the pop-up window (in pixels)
 * @param maxWindowHeight the maximum height of the pop-up window (in pixels)
 * @param lineHeight the line height used in computing the window height (lineHeight*numErrors+baseWindowHeight)
 */
function displayErrorsDialog(blankURL,dialogURL,maxErrors,windowWidth,baseWindowHeight,maxWindowHeight,lineHeight){
    var strErrors = "";                        
    var numErrors=0;
    var SEPARATOR_STRING="!el;";

    //first count the non-null entries in our array
    if (arrErr.length>0){
        for(i=0;i<arrErr.length;i++)
        {
            if((arrErr[i].name.length > 0)){
                numErrors++
                
                //now limit our error display to a reasonable size
                if (numErrors==maxErrors){                    
                    break;
                }                                     
            }    
        }
    }    
    
    //now load in our 'load' page, to populate with POST data and submit to get our error dialog
    
    //set default (small) dialog size    
    var windowHeight = baseWindowHeight; 
    
    //now dynamically grow the window height based on the number of errors displayed
    windowHeight=windowHeight+(lineHeight*numErrors);

    if (windowHeight>maxWindowHeight) windowHeight=maxWindowHeight;
       
   
    //now center the dialog on the main window
    var windowX = (window.screen.width-windowWidth)/2;
    var windowY = (window.screen.height-windowHeight)/2;    
    
    var windowFeatures="";
    if (!window.showModalDialog||isIE4){
        //declare standard window.open features
        windowFeatures="height="+windowHeight+",width="+windowWidth+",status=no,toolbar=no,menubar=no,location=no,top="+windowY+",left="+windowX;
    }else{    
        //declare IE-specific window.showModalDialog features
        windowFeatures="dialogHeight: " + windowHeight + "px; dialogWidth: " + windowWidth + "px; dialogTop: " + windowY + "px;  center: yes; help: no; resizable: no; status: no;";
    }        
    
    var errorWindow=null;
 
    if (!window.showModalDialog||isIE4){        
        errorWindow=window.open(blankURL,"errorWindow",windowFeatures);    
    }
    var errCount=0;
    if(numErrors > 0)
    {
        var focusedElement=null;                                
        var focused = false;
        for(i=0;i<arrErr.length;i++)
        {
            //only append to the error string if the entry is non-null and we are under our limit
            if((arrErr[i].name.length > 0)&&(errCount<maxErrors)){
                errCount++;
                strErrors += SEPARATOR_STRING + arrErr[i].name;                 
            }

            //if the specified field is null (ie. span tag specifiers, as per checkRadio), do not attempt to highlight
            if (arrErr[i].field){
                setErrorHighlight(arrErr[i].field, arrErr[i].imgName);
                //check that the field has a focus property before attempting to set it
                if (!focused && !arrErr[i].field.disabled&&arrErr[i].field.focus) {
                    arrErr[i].field.focus();
                    focusedElement=arrErr[i].field;
                    focused = true;
                }

            }
        }
        
         //strip off the first (spurious) delimiter
         strErrors=strErrors.substr(SEPARATOR_STRING.length);         
         
         var errorDataPage="";                  
         //encode the error data to prevent problems with separator/carriage return characters                 
         strErrors=escape(strErrors);
         if (!window.showModalDialog||isIE4){
            var c=0;
            while (errorWindow==null){
                //wait until the window has been instantiated before continuing
                //windowHandle will equal null until that has happened
                c++;
            } 
               
            //create a form submit page and write a form to POST to the new window
            errorDataPage ="<html><body>";         
            errorDataPage+="<form name=\"frmError\" action=\""+dialogURL+"\" method=\"POST\">";
            errorDataPage+="<input type=\"hidden\" name=\"errors\" value=\""+strErrors+"\">";                           
            errorDataPage+="</form></body></html>";
                  
            errorWindow.document.write(errorDataPage);
            errorWindow.document.close();           
            errorWindow.focus(); 
            errorWindow.document.frmError.submit();         
                                  
            //copy our window handle for use after the function has terminated
            errorDialog=errorWindow;
            //override the default onfocus event for the main window
            window.onfocus=handleWindow;           
            //make sure if the user somehow leaves the current page or closes the main window
            //that our pop-up gets closed
            window.onunload = function(){errorDialog.close();}
            //disable the current browser window
            disableWindow();
         }else{
             //open our modal dialog, after creating an object container for our data
             var dataObject = new Object();
             dataObject.errors=strErrors;
             errorWindow=window.showModalDialog(dialogURL,dataObject,windowFeatures);
             if (null != focusedElement) {
                focusedElement.focus();    
             }
         }
    }//end if errors>0    
     
}//end function


/**
 * default focusWindow function, to be overridden if window specific focusing methods are desired
 */
function focusWindow(){    
    errorDialog.focus();
}

/**
 * default focusButton function, to be overridden to focus a specific button
 */
function focusButton(){
    return true;
}
/**
 * overrides the main windows onfocus handler to provide for a modal html pop-up
 * note - this function is not used if window.showModalDialog is supported
 */ 
function handleWindow(){    
    if ((errorDialog)&&(!errorDialog.closed)){
        //focus the dialog window
        focusWindow();        
        //if our frame has loaded, focus the ok button, otherwise
        //leave the frameset window focused and prepare to retry
        var success=focusButton();
        if (success){
            //kludge to prevent IE4 from losing focus when the user clicks into other frames
            if (!isNS) setTimeout("handleWindow()","1000");
        }else{
            //frameset isnt fully loaded, so re-fire the event              
            setTimeout("handleWindow()","1000");          
        }                                    
        
    }else{
        //reset window to its default handler if our handle is expired/window is closed
        window.onfocus = null        
        //restore the current browser window
        enableWindow();
    }//end if handleExists
}//end function

/***
 *  alertErrors()
 *  Loop through the error array and build up an alert box dialog to tell the user what error were found.
 *
 */
function alertErrors()
{
    var strErrors = "";
    var MAX_ERRORS=25;

    if(alertErrors.arguments.length > 0)
        strErrors += alertErrors.arguments[0];

    var numErrors=arrErr.length;
    
    if(numErrors > 0)
    {
        //limit the number of errors displayed to prevent vertical dialog clipping
        if (numErrors>MAX_ERRORS) numErrors=MAX_ERRORS;
        var focused = false;
        for(i=0;i<arrErr.length;i++)
        {
            if((arrErr[i].name.length > 0)&&(i<numErrors))
                strErrors += "\n" + arrErr[i].name;

            //if the specified field is null (ie. span tag specifiers, as per checkRadio), do not attempt to highlight
            if (arrErr[i].field){
                setErrorHighlight(arrErr[i].field, arrErr[i].imgName);
                //check that the field has a focus property before attempting to set it
                if (!focused && !arrErr[i].field.disabled&&arrErr[i].field.focus) {
                    arrErr[i].field.focus();
                    focused = true;
                }

            }
        }
        alert(strErrors);
    }

}

function clearErrors() {
    if(arrErr != null && (arrErr.length > 0)) {
        for(i=0; i<arrErr.length;i++) {
            clearErrorHighlight(arrErr[i].field, arrErr[i].imgName);
        }
    }
}

function clearServerErrors() {
    if(arrServerErrors != null && (arrServerErrors.length > 0)) {
        for(i=0; i<arrServerErrors.length;i++) {
            clearErrorHighlight(arrServerErrors[i].field, arrServerErrors[i].imgName);
        }
    }
}

/***
 *  checkValidDate(string, string, string, int, string, string, blank)
 *  inputs:
 *  theDayField (string)    : the name of the day field to check
 *  theMonthField (string)  : the name of the month field to check
 *  theYearField (string)   : the name of the year field to check
 *  theLine (int)           : the line number of the fields to check
 *  strFriendlyName (string): the friendly error message to display in the alert box
 *  imgName (string)        : the name of the image to turn on if an error occurs. (Netscape Only)
 *  blank (boolean)         : are blanks okay
 *
 *  Check that the date comprised of the passed date fields is a valid date (including leap year)
 *  and that the date is not in the future
 */
function checkValidDate(theDayField, theMonthField, theYearField, strFriendlyName, imgName, blank)
{
    var bResult = true;

    theDayField = fieldForName(theDayField);
    theMonthField = fieldForName(theMonthField);
    theYearField = fieldForName(theYearField);

    clearErrorHighlight(theDayField, imgName);
    clearErrorHighlight(theMonthField, imgName);
    clearErrorHighlight(theYearField, imgName);

    if( (blank == true) && (theDayField.value.length == 0) && (theMonthField.value.length == 0) &&
        (theYearField.value.length == 0) ) {
        return true;
    }

    if(theMonthField.value.charAt(0) == 0)
        theMonthField.value = theMonthField.value.charAt(1);
    if(theDayField.value.charAt(0) == 0)
        theDayField.value = theDayField.value.charAt(1);


    var today = new Date();
    var dateToCheck = (new Date(theYearField.value, parseInt(theMonthField.value,10) - 1, theDayField.value));

    if( !isDate(theYearField.value, theMonthField.value, theDayField.value) || dateToCheck > today )
    {
        createNewError(theMonthField, "", imgName);
        createNewError(theDayField, "", imgName);
        createNewError(theYearField, strFriendlyName, imgName);
        bResult = false;
    } else if (theYearField.value < "1881") {
        createNewError(theYearField, strFriendlyName, imgName);
        bResult = false;
    } 

    if(theMonthField.value.length == 1)
        theMonthField.value = "0" + theMonthField.value;

    if(theDayField.value.length == 1)
        theDayField.value = "0" + theDayField.value;
    return bResult;
}


/***
 *  checkFutureOrPastDate(string, string, string, int, string, string, blank)
 *  inputs:
 *  theDayField (string)    : the name of the day field to check
 *  theMonthField (string)  : the name of the month field to check
 *  theYearField (string)   : the name of the year field to check
 *  theLine (int)           : the line number of the fields to check
 *  strFriendlyName (string): the friendly error message to display in the alert box
 *  imgName (string)        : the name of the image to turn on if an error occurs. (Netscape Only)
 *  blank (boolean)         : are blanks okay
 *
 *  Check that the date comprised of the passed date fields is a valid date (including leap year)
 *  and that the date is not in the future
 */
function checkFutureOrPastDate(theDayField, theMonthField, theYearField, strFriendlyName, imgName, blank)
{
    var bResult = true;

    theDayField = fieldForName(theDayField);
    theMonthField = fieldForName(theMonthField);
    theYearField = fieldForName(theYearField);

    clearErrorHighlight(theDayField, imgName);
    clearErrorHighlight(theMonthField, imgName);
    clearErrorHighlight(theYearField, imgName);

    if( (blank == true) && (theDayField.value.length == 0) && (theMonthField.value.length == 0) &&
        (theYearField.value.length == 0) ) {
        return true;
    }

    if(theMonthField.value.charAt(0) == 0)
        theMonthField.value = theMonthField.value.charAt(1);
    if(theDayField.value.charAt(0) == 0)
        theDayField.value = theDayField.value.charAt(1);

    if( !isDate(theYearField.value, theMonthField.value, theDayField.value))
    {
        createNewError(theMonthField, "", imgName);
        createNewError(theDayField, "", imgName);
        createNewError(theYearField, strFriendlyName, imgName);
        bResult = false;
    }

    if(theMonthField.value.length == 1)
        theMonthField.value = "0" + theMonthField.value;

    if(theDayField.value.length == 1)
        theDayField.value = "0" + theDayField.value;
    return bResult;
}



/***
 *  compareDate(string, string, string, string, string, string, int, string, string, blank)
 *  inputs:
 *  theDayField (string)    : the name of the day field to check
 *  theMonthField (string)  : the name of the month field to check
 *  theYearField (string)   : the name of the year field to check
 *  anotherDayField (string)    : the name of the day field to be checked against
 *  anotherMonthField (string)  : the name of the month field to be checked against
 *  anotherYearField (string)   : the name of the year field to be checked against
 *  strFriendlyName (string): the friendly error message to display in the alert box
 *  imgName (string)        : the name of the image to turn on if an error occurs. (Netscape Only)
 *  blank (boolean)         : are blanks okay
 *
 *  Check that the date comprised of the passed date fields is a valid date (including leap year)
 *  and that the date is not in the future
 */
function compareDate(theDayField, theMonthField, theYearField, anotherDayField, anotherMonthField, anotherYearField, strFriendlyName, imgName, blank)
{
    var bResult = true;

    theDayField = fieldForName(theDayField);
    theMonthField = fieldForName(theMonthField);
    theYearField = fieldForName(theYearField);

    clearErrorHighlight(theDayField, imgName);
    clearErrorHighlight(theMonthField, imgName);
    clearErrorHighlight(theYearField, imgName);

    if( (blank == true) && (theDayField.value.length == 0) && (theMonthField.value.length == 0) &&
        (theYearField.value.length == 0) ) {
        return true;
    }

    if(theMonthField.value.charAt(0) == 0)
        theMonthField.value = theMonthField.value.charAt(1);
    if(theDayField.value.charAt(0) == 0)
        theDayField.value = theDayField.value.charAt(1);


    anotherDayField = fieldForName(anotherDayField);
    anotherMonthField = fieldForName(anotherMonthField);
    anotherYearField = fieldForName(anotherYearField);

    if(anotherMonthField.value.charAt(0) == 0)
        anotherMonthField.value = anotherMonthField.value.charAt(1);
    if(anotherDayField.value.charAt(0) == 0)
        anotherDayField.value = anotherDayField.value.charAt(1);

    var today = new Date();
    var dateToCheck = (new Date(anotherYearField.value, anotherMonthField.value, anotherDayField.value));
    var serviceDate = (new Date(theYearField.value, theMonthField.value, theDayField.value));

    if( !isDate(theYearField.value, theMonthField.value, theDayField.value) || dateToCheck > serviceDate )
    {
        createNewError(anotherMonthField, "", imgName);
        createNewError(anotherDayField, "", imgName);
        createNewError(anotherYearField, strFriendlyName, imgName);
        bResult = false;
    }

    if(theMonthField.value.length == 1)
        theMonthField.value = "0" + theMonthField.value;

    if(theDayField.value.length == 1)
        theDayField.value = "0" + theDayField.value;

    if(anotherMonthField.value.length == 1)
        anotherMonthField.value = "0" + anotherMonthField.value;

    if(anotherDayField.value.length == 1)
        anotherDayField.value = "0" + anotherDayField.value;
    return bResult;
}



/***
 *  compareEndDate(string, string, string, string, string, string, int, string, string, blank)
 *  inputs:
 *  theDayField (string)    : the name of the day field to check
 *  theMonthField (string)  : the name of the month field to check
 *  theYearField (string)   : the name of the year field to check
 *  anotherDayField (string)    : the name of the day field to be checked against
 *  anotherMonthField (string)  : the name of the month field to be checked against
 *  anotherYearField (string)   : the name of the year field to be checked against
 *  strFriendlyName (string): the friendly error message to display in the alert box
 *  imgName (string)        : the name of the image to turn on if an error occurs. (Netscape Only)
 *  blank (boolean)         : are blanks okay
 *
 *  Same as compareDate, except this function highlights the end date rather than the start date.
 *  Check that the date comprised of the passed date fields is a valid date (including leap year)
 *  and that the date is not in the future
 */
function compareEndDate(theDayField, theMonthField, theYearField, anotherDayField, anotherMonthField, anotherYearField, strFriendlyName, imgName, blank)
{
    var bResult = true;

    theDayField = fieldForName(theDayField);
    theMonthField = fieldForName(theMonthField);
    theYearField = fieldForName(theYearField);

    clearErrorHighlight(theDayField, imgName);
    clearErrorHighlight(theMonthField, imgName);
    clearErrorHighlight(theYearField, imgName);

    if( (blank == true) && (theDayField.value.length == 0) && (theMonthField.value.length == 0) &&
        (theYearField.value.length == 0) ) {
        return true;
    }

    if(theMonthField.value.charAt(0) == 0)
        theMonthField.value = theMonthField.value.charAt(1);
    if(theDayField.value.charAt(0) == 0)
        theDayField.value = theDayField.value.charAt(1);


    anotherDayField = fieldForName(anotherDayField);
    anotherMonthField = fieldForName(anotherMonthField);
    anotherYearField = fieldForName(anotherYearField);

    if(anotherMonthField.value.charAt(0) == 0)
        anotherMonthField.value = anotherMonthField.value.charAt(1);
    if(anotherDayField.value.charAt(0) == 0)
        anotherDayField.value = anotherDayField.value.charAt(1);

    var today = new Date();
    var dateToCheck = (new Date(anotherYearField.value, anotherMonthField.value, anotherDayField.value));
    var serviceDate = (new Date(theYearField.value, theMonthField.value, theDayField.value));

    if( !isDate(theYearField.value, theMonthField.value, theDayField.value) || dateToCheck > serviceDate )
    {
        createNewError(theMonthField, "", imgName);
        createNewError(theDayField, "", imgName);
        createNewError(theYearField, strFriendlyName, imgName);
        bResult = false;
    }

    if(theMonthField.value.length == 1)
        theMonthField.value = "0" + theMonthField.value;

    if(theDayField.value.length == 1)
        theDayField.value = "0" + theDayField.value;

    if(anotherMonthField.value.length == 1)
        anotherMonthField.value = "0" + anotherMonthField.value;

    if(anotherDayField.value.length == 1)
        anotherDayField.value = "0" + anotherDayField.value;
    return bResult;
}

/***
 *  checkValidDatewithMinMax(string, string, string, string, string, int, int, blank)
 *  inputs:
 *  theDayField (string)    : the name of the day field to check
 *  theMonthField (string)  : the name of the month field to check
 *  theYearField (string)   : the name of the year field to check
 *  strFriendlyName (string): the friendly error message to display in the alert box
 *  imgName (string)        : the name of the image to turn on if an error occurs. (Netscape Only)
 *  min (int)               ; the minimum valid year
 *  max (int)               ; the maximum valid year
 *  blank (boolean)         : are blanks okay
 *
 *  Check that the date comprised of the passed date fields is a valid date (including leap year)
 *  and that the date is not in the future
 */
function checkValidDatewithMinMax() {
    var minyear = arguments[5];
    var maxyear = arguments[6];
    var blank;
    var len = arrErr.length;
    var minyr = (minyear != null) ? minyear : 0;
    var today = new Date();
    var maxyr = (maxyear != null) ? maxyear : today.getFullYear();

    if(arguments.length > 7) {
        blank = arguments[7];
    } else {
        blank = false;
    }

    checkValidDate(arguments[0], arguments[1], arguments[2], arguments[3], arguments[4], blank);
    if(len == arrErr.length) {
        var fld = fieldForName(arguments[2]).value;
        if(blank && (fld.length == 0)) {
            return true;
        }
        var year = parseInt(fld);
        if( (year >= minyr) && (year <= maxyr)) {
            // passed
        }
        else {
            createNewError(fieldForName(arguments[2]), arguments[3], arguments[4]);
        }
    }
}

/*
 *  checkAgeOfDateInDays(string, string, int, string, string)
 *  INPUTS:
 *  dateToTestDay (string)  : Numeric day.
 *  dateToTestMonth (string): Numeric month.
 *  dateToTestYear (string) : Numeric CCYY.
 *  strFriendlyName (string): the friendly error message to display in the alert box
 *  imgName (string)        : the name of the image to turn on if an error occurs. (Netscape Only)
 *  beforeOrAfter (string)  : Is the date to be before or after the current date?
 *  targetInDays (int)      : Number of days of which the date cannot outside of range.
 *
 *  PURPOSE:     Edit the passed date to see if it falls within the targeted time in days.
 *  OUTPUTS:     difference in days and error accordingly if necessary
 *  AUTHOR:      .Net Systems
 */
function checkAgeOfDateInDays(dateToTestDay, dateToTestMonth, dateToTestYear, strFriendlyName, imgName, beforeOrAfter, targetInDays) {
    var today = new Date();
    dateToTestDay = fieldForName(dateToTestDay);
    dateToTestMonth = fieldForName(dateToTestMonth);
    dateToTestYear = fieldForName(dateToTestYear);

    if (dateToTestDay.value < "01" || dateToTestDay.value > "31" || dateToTestMonth.value < "01" || dateToTestMonth.value > "12" || isNaN(dateToTestYear.value)) {
        createNewError(dateToTestMonth, "", imgName);
        createNewError(dateToTestDay, "", imgName);
        createNewError(dateToTestYear, strFriendlyName, imgName);
    } else {
        var tempMonth   = parseInt(dateToTestMonth.value,10) - 1;    // 0 based array for the month, so subtract 1.
        var formattedDate   = new Date(dateToTestYear.value, tempMonth, dateToTestDay.value);
        var daysDiff = 0;
        if (beforeOrAfter == "B") {
            daysDiff = (today.getTime() - formattedDate.getTime());
        } else {
            daysDiff = (formattedDate.getTime() - today.getTime());
        }
        daysDiff = Math.floor((((daysDiff  / 1000) / 60) / 60) / 24);
        if (daysDiff > targetInDays || daysDiff < 0) {
            createNewError(dateToTestMonth, "", imgName);
            createNewError(dateToTestDay, "", imgName);
            createNewError(dateToTestYear, strFriendlyName, imgName);
        } else {
            return true;
        }
    }
}

/*
 *  checkFutureDateInDays(string, string, int, string, string)
 *  INPUTS:
 *  dateToTestDay (string)  : Numeric day.
 *  dateToTestMonth (string): Numeric month.
 *  dateToTestYear (string) : Numeric CCYY.
 *  strFriendlyName (string): the friendly error message to display in the alert box
 *  imgName (string)        : the name of the image to turn on if an error occurs. (Netscape Only)
 *  beforeOrAfter (string)  : Is the date to be before or after the current date?
 *  targetInDays (int)      : Number of days of which the date cannot outside of range.
 *
 *  PURPOSE:     Edit the passed date to see if it falls within the targeted time in days.
 *  OUTPUTS:     difference in days and error accordingly if necessary
 *  AUTHOR:      .Net Systems
 */
function checkFutureDateInDays(dateToTestDay, dateToTestMonth, dateToTestYear, strFriendlyName, imgName, targetInDays)
{
    var today = new Date();
    dateToTestDay = fieldForName(dateToTestDay);
    dateToTestMonth = fieldForName(dateToTestMonth);
    dateToTestYear = fieldForName(dateToTestYear);

    if (dateToTestDay.value < "01" || dateToTestDay.value > "31" || dateToTestMonth.value < "01" || dateToTestMonth.value > "12" || isNaN(dateToTestYear.value)) {
        createNewError(dateToTestMonth, "", imgName);
        createNewError(dateToTestDay, "", imgName);
        createNewError(dateToTestYear, strFriendlyName, imgName);
    } else {
        var tempMonth   = parseInt(dateToTestMonth.value,10) - 1;    // 0 based array for the month, so subtract 1.
        var formattedDate   = new Date(dateToTestYear.value, tempMonth, dateToTestDay.value);
        var daysDiff = 0;
        daysDiff = (formattedDate.getTime() - today.getTime());
        daysDiff = Math.floor((((daysDiff  / 1000) / 60) / 60) / 24);
        if (daysDiff > targetInDays) {
            createNewError(dateToTestMonth, "", imgName);
            createNewError(dateToTestDay, "", imgName);
            createNewError(dateToTestYear, strFriendlyName, imgName);
        } else {
            return true;
        }
    }
}

/*
 *  checkPastDateInDays(string, string, int, string, string)
 *  INPUTS:
 *  dateToTestDay (string)  : Numeric day.
 *  dateToTestMonth (string): Numeric month.
 *  dateToTestYear (string) : Numeric CCYY.
 *  strFriendlyName (string): the friendly error message to display in the alert box
 *  imgName (string)        : the name of the image to turn on if an error occurs. (Netscape Only)
 *  beforeOrAfter (string)  : Is the date to be before or after the current date?
 *  targetInDays (int)      : Number of days of which the date cannot outside of range.
 *
 *  PURPOSE:     Edit the passed date to see if it falls within the targeted time in days.
 *  OUTPUTS:     difference in days and error accordingly if necessary
 *  AUTHOR:      .Net Systems
 */
function checkPastDateInDays(dateToTestDay, dateToTestMonth, dateToTestYear, strFriendlyName, imgName, targetInDays)
{
    var today = new Date();
    dateToTestDay = fieldForName(dateToTestDay);
    dateToTestMonth = fieldForName(dateToTestMonth);
    dateToTestYear = fieldForName(dateToTestYear);

    if (dateToTestDay.value < "01" || dateToTestDay.value > "31" || dateToTestMonth.value < "01" || dateToTestMonth.value > "12" || isNaN(dateToTestYear.value)) {
        createNewError(dateToTestMonth, "", imgName);
        createNewError(dateToTestDay, "", imgName);
        createNewError(dateToTestYear, strFriendlyName, imgName);
    } else {
        var tempMonth   = parseInt(dateToTestMonth.value,10) - 1;    // 0 based array for the month, so subtract 1.
        var formattedDate   = new Date(dateToTestYear.value, tempMonth, dateToTestDay.value);
        var daysDiff = 0;
        daysDiff = (today.getTime() - formattedDate.getTime());
        
        daysDiff = Math.floor((((daysDiff  / 1000) / 60) / 60) / 24);
        if (daysDiff > targetInDays) {
            createNewError(dateToTestMonth, "", imgName);
            createNewError(dateToTestDay, "", imgName);
            createNewError(dateToTestYear, strFriendlyName, imgName);
        } else {
        return true;
        }
    }
}

/*
 *  checkDateRange(string, string, string, string, string, int)
 *  INPUTS:
 *  dateToTestDay (string)  : Numeric day.
 *  dateToTestMonth (string): Numeric month.
 *  dateToTestYear (string) : Numeric CCYY.
 *  strFriendlyName (string): the friendly error message to display in the alert box
 *  imgName (string)        : the name of the image to turn on if an error occurs. (Netscape Only)
 *  targetInDays (int)      : Number of days of which the date cannot outside of range.
 *
 *  PURPOSE:     Edit the passed date to see if it falls within the targeted time in days.
 *  OUTPUTS:     difference in days and error accordingly if necessary
 *  AUTHOR:      .Net Systems
 */
function checkDateRange(dateToTestDay, dateToTestMonth, dateToTestYear, strFriendlyName, imgName, targetInDays)
{
    var today = new Date();
    dateToTestDay = fieldForName(dateToTestDay);
    dateToTestMonth = fieldForName(dateToTestMonth);
    dateToTestYear = fieldForName(dateToTestYear);

    if (dateToTestDay.value < "01" || dateToTestDay.value > "31" || dateToTestMonth.value < "01" || dateToTestMonth.value > "12" || isNaN(dateToTestYear.value)) {
        createNewError(dateToTestMonth, "", imgName);
        createNewError(dateToTestDay, "", imgName);
        createNewError(dateToTestYear, strFriendlyName, imgName);
    } else {
        var tempMonth   = parseInt(dateToTestMonth.value,10) - 1;    // 0 based array for the month, so subtract 1.
        var formattedDate   = new Date(dateToTestYear.value, tempMonth, dateToTestDay.value);

        var daysDiff = 0;
        daysDiff = (today.getTime() - formattedDate.getTime());
        daysDiff = Math.floor((((daysDiff  / 1000) / 60) / 60) / 24);

        if (daysDiff > targetInDays || daysDiff < (0-targetInDays)) {
            createNewError(dateToTestMonth, "", imgName);
            createNewError(dateToTestDay, "", imgName);
            createNewError(dateToTestYear, strFriendlyName, imgName);
        } else {
            return true;
        }
    }
}

/**
 * @return true if the field is a select field
 */
function isSelectValue(theFieldName){
    var field=fieldForName(theFieldName);
    var fieldType=field.type;    
    if (fieldType.indexOf("select")>-1) return true;
    return false; 
}

/**
 * checks whether the field is empty, using getSelectValue() for 
 * select fields, and field.value for all other types
 * @return true if the field contains non-whitespace characters(input fields) or has a nonwhitespace selection(select fields)
 * @version 1.1 pre-10/27/03 version used field.value for all fields (NN4 compatability issue)   
 */
function isFieldEmpty(theFieldName){ 
    var field=fieldForName(theFieldName);
    
    //sanity check the field, to make sure it refers to a valid form object
    if (field==undefined) {                
        return true;
    } 
     
    var fieldVal="";
    if (isSelectValue(theFieldName)){                
        fieldVal=getSelectValue(theFieldName);        
    }else{
        fieldVal=field.value; 
    }    
        
    return isWhitespace(fieldVal);

}

/*  Compare to see if one of the passed fields does not contain a value.  If all do not contain a value, that's ok.
    You should always have at least 2 fields.  (That would be a "duh").
    
    @version 1.1 - pre-10/27/03 version used field.value exclusively, now select fields are also checked (for NN4 compatability)
*/

function checkRelationalFields()
{    
    var strFriendlyName = arguments[0];
    var imgName = arguments[1];
    var valuePresent = false;

    arrFields = new Array();
    i = 0;
    j = 0;
    for (i = 2; i < arguments.length; i++)
    {
        j = arrFields.length;

        arrFields[j] = fieldForName(arguments[i]);
        //if (arrFields[j].value > " ")
        if (!isFieldEmpty(arrFields[j].name))
            valuePresent = true;

    }
    // clear all the error highlighting first so as not to clear, later, an error that happens to use the same image.
    for (j = 0; j < arrFields.length; j++) {
        clearErrorHighlight(arrFields[j], imgName);
    }

    if (valuePresent == true)
    {
        for (j = 0; j < arrFields.length; j++)
        {
            //if (arrFields[j].value <= " ")
            if (isFieldEmpty(arrFields[j].name))
            {
                createNewError(arrFields[j],strFriendlyName,imgName);
                strFriendlyName = "";
            }
        }
    }

}

/*  Compare to see if one of the passed fields does not contain a value.
    You should always have at least 2 fields.
*/

function checkOneOrBothFields()
{
    var strFriendlyName = arguments[0];
    var imgName = arguments[1];
    var valuePresent = false;

    arrFields = new Array();
    i = 0;
    j = 0;
    for (i = 2; i < arguments.length; i++)
    {
        j = arrFields.length;
        arrFields[j] = fieldForName(arguments[i]);
        if (arrFields[j].type == "select-one" || arrFields[j].type == "select-multiple")
        {
            if (arrFields[j].selectedIndex > 0)
                valuePresent = true;
        }
        else
        {
            if (arrFields[j].value > " ")
                valuePresent = true;
        }
    }
    // clear all the error highlighting first so as not to clear, later, an error that happens to use the same image.
    for (j = 0; j < arrFields.length; j++) {
        clearErrorHighlight(arrFields[j], imgName);
    }
    if (valuePresent != true)
    {
        for (j = 0; j < arrFields.length; j++)
        {
            if (arrFields[j].value <= " ")
            {
                createNewError(arrFields[j],strFriendlyName,imgName);
                strFriendlyName = "";
            }
        }
    }
}
/*
*   function:   checkMoney()
*   parameters: dollarsField <string> : field containing the dollar value
                centsField <string> : field containing the cents value
                strFriendlyName <string> : the friendly message to display to the user if the check fails
                imgName <string> : the name of the image to switch on if there is an error
                isRequired <string> : is the money value required? if not, then empty values are valid, otherwise they are not
                isZeroOkay <optional string> : optional value specifying if a money value of zero is okay.  the default value is true
*   return:     <none>
*   remarks:
*           checks that the passed dollar and cent fields form a valid money value
*/
function checkMoney(dollarsField, centsField, strFriendlyName, imgName, isRequired) //, isZeroOkay : default=true
{
    dollarsField = fieldForName(dollarsField);
    centsField = fieldForName(centsField);

    clearErrorHighlight(dollarsField, imgName);
    clearErrorHighlight(centsField, imgName);

    if(!isRequired)
    {
        if(isWhitespace(dollarsField.value) && isWhitespace(centsField.value))
            return true;
    }

    if(centsField.value.length != 2)
    {
        createNewError(dollarsField, strFriendlyName, imgName);
        createNewError(centsField, "", imgName);
        return false;
    }

    if(isInteger(dollarsField.value, false) && isInteger(centsField.value, false))
    {
        var total = new Number(dollarsField.value + centsField.value);
        var isZeroOkay = true;
        if(arguments.length > 5)
            isZeroOkay = arguments[5];
        if(total == 0 && !isZeroOkay)
        {
            createNewError(dollarsField, strFriendlyName, imgName);
            createNewError(centsField, "", imgName);
        }
    }
    else
    {
        createNewError(dollarsField, strFriendlyName, imgName);
        createNewError(centsField, "", imgName);
    }
}

/***
 *  checkNumber(string, string, string)
 *  inputs:
 *  theFieldName (string)   : the name of the field to check
 *  strFriendlyName (string): the friendly error message to display in the alert box
 *  imgName (string)        : the name of the image to turn on if an error occurs. (Netscape Only)
 *
 *  Check that the field passed contains a valid integer.  If the field value is invalid,
 *  create a new error
 */
function checkNumber(theFieldName, strFriendlyName, imgName)
{
    var emptyIsOk = false;
    var theField = fieldForName(theFieldName);

    clearErrorHighlight(theField, imgName);
    if(checkNumber.arguments.length > 4)
        emptyIsOk = checkNumber.arguments[4];

    if( !isInteger(theField.value, emptyIsOk) )
        createNewError(theField, strFriendlyName, imgName);
}


/***
 *  checkNumberOptional(string, string, string)
 *  inputs:
 *  theFieldName (string)   : the name of the field to check
 *  strFriendlyName (string): the friendly error message to display in the alert box
 *  imgName (string)        : the name of the image to turn on if an error occurs. (Netscape Only)
 *
 *  Check that the field passed contains a valid integer.  If the field value is invalid,
 *  create a new error, will allow for the field to be empty.
 */
function checkNumberOptional(theFieldName, strFriendlyName, imgName)
{
    var emptyIsOk = false;
    var theField = fieldForName(theFieldName);

    clearErrorHighlight(theField, imgName);
    if(checkNumberOptional.arguments.length > 3)
        emptyIsOk = checkNumberOptional.arguments[3];

    if( !isInteger(theField.value, emptyIsOk) )
        createNewError(theField, strFriendlyName, imgName);
}

/***
 *  checkDecimal(string, string, string[, boolean])
 *  inputs:
 *  theFieldName (string)   : the name of the field to check
 *  strFriendlyName (string): the friendly error message to display in the alert box
 *  imgName (string)        : the name of the image to turn on if an error occurs.
 *  emptyIsOk (boolean)     : empty is OK (optional)
 *
 *  Check that the field passed contains a valid integer.  If the field value is invalid,
 *  create a new error, will allow for the field to be empty.
 */
function checkDecimal(theFieldName, strFriendlyName, imgName)
{
    var emptyIsOk = false;
    var theField = fieldForName(theFieldName);

    clearErrorHighlight(theField, imgName);
    if(checkDecimal.arguments.length > 3)
        emptyIsOk = checkDecimal.arguments[3];

    if( !isFloat(theField.value, emptyIsOk) )
        createNewError(theField, strFriendlyName, imgName);
}

/***
 *  checkNumber(string, string, string)
 *  inputs:
 *  theFieldName (string)   : the name of the field to check
 *  strFriendlyName (string): the friendly error message to display in the alert box
 *  intMin (number)         : the minumum value for the number
 *  intMax (number)         : the maximum value for the number
 *  imgName (string)        : the name of the image to turn on if an error occurs. (Netscape Only)
 *  isRequired (boolean)    : is the number a required field?
 *
 *  Check that the field passed contains a valid integer and that it falls within the specified range.
 *  If the field value is invalid, create a new error
 */
function checkNumberRange(theFieldName, strFriendlyName, intMin, intMax, imgName, isRequired)
{
    var emptyIsOk = !isRequired;
    var theField = fieldForName(theFieldName);

    clearErrorHighlight(theField, imgName);

    if(!isInteger(theField.value, emptyIsOk))
    {
        createNewError(theField, strFriendlyName, imgName);
    }
    else
    {
        var num = parseInt(theField.value,10);
        if(num < intMin || num > intMax)
        {
            createNewError(theField, strFriendlyName, imgName);
        }
    }
}


/***
 *  checkNumberLength(string, string, int, string)
 *  inputs:
 *  theFieldName (string)   : the name of the field to check
 *  strFriendlyName (string): the friendly error message to display in the alert box
 *  minLength (int)         : the minimum length of the value of the field passed
 *  imgName (string)        : the name of the image to turn on if an error occurs. (Netscape Only)
 *
 *  Check that the field passed contains a valid integer of at least the specified length.
 *  If the field value is invalid, create a new error.
 */
function checkNumberLength(theFieldName, strFriendlyName, minLength, imgName)
{
    var theField = fieldForName(theFieldName);

    clearErrorHighlight(theField, imgName);

    if( !isInteger(theField.value) )
        createNewError(theField, strFriendlyName, imgName);
    else if(theField.value.length < minLength)
        createNewError(theField, strFriendlyName, imgName);
}

function checkLength(theFieldName, strFriendlyName, minLength, imgName, whitespaceNotAllowed)
{
    var theField = fieldForName(theFieldName);
    var theFieldValue = theField.value;

    clearErrorHighlight(theField, imgName);

    if(whitespaceNotAllowed) {
        theFieldValue = stripBothEndsOfWhitespace(theFieldValue);
    }

    if(theFieldValue.length < minLength)
        createNewError(theField, strFriendlyName, imgName);
}

function checkRequired(theFieldName, strFriendlyName, imgName)
{
    var theField = fieldForName(theFieldName);

    clearErrorHighlight(theField, imgName);

    if( isWhitespace(theField.value) )
        createNewError(theField, strFriendlyName, imgName);
}

function checkSelect(theFieldName, strFriendlyName, imgName)
{
    var theField = fieldForName(theFieldName);

    clearErrorHighlight(theField, imgName);

    if (theField.selectedIndex == 0)
        createNewError(theField, strFriendlyName, imgName);
}

function checkListBox(theFieldName, strFriendlyName, imgName) {
    var theField = fieldForName(theFieldName);

    clearErrorHighlight(theField, imgName);

    if (theField.selectedIndex < 0){
        createNewError(theField, strFriendlyName, imgName);
    }
}

function checkRadio(theFieldName, strFriendlyName, spanId, imgName)
{
    var theField = fieldForName(theFieldName);
    var fieldChecked = false;

    clearErrorHighlight(spanId, imgName);

    for (i = 0; i < theField.length; i++)
    {
        if (theField[i].checked)
        {
            fieldChecked = true;
            break;
        }
    }

    if(!fieldChecked)
        createNewError(spanId, strFriendlyName, imgName);
}

/*  Compare to see if one or the other fields has data, but not both.
    You should always have at least 2 fields.  (That would be a "duh").
*/
function checkExclusiveFields()
{
    var strFriendlyName = arguments[0];
    var imgName = arguments[1];
    var valuePresent = false;
    var i;
    var j;

    arrFields = new Array();
    // clear all the error highlighting first so as not to clear, later, an error that happens to use the same image.
    for (i = 2; i < arguments.length; i++) {
        clearErrorHighlight(fieldForName(arguments[i]), imgName);
    }
    for (i = 2; i < arguments.length; i++)
    {
        var fld = fieldForName(arguments[i]);
        if(!fld) {
            continue;
        }
        if (fld.value.length > 0) {
            if(valuePresent == true) {
                j = arrFields.length;
                arrFields[j] = fld;
            } else {
                valuePresent = true;
            }
        }
    }
    if (valuePresent == true)
    {
        for (j = 0; j < arrFields.length; j++)
        {
            createNewError(arrFields[j],strFriendlyName,imgName);
            strFriendlyName = "";
        }
    }
}

/***
 *  checkAlphanumeric(string, string, string [, boolean [, int, int]])
 *  inputs:
 *  theFieldName (string)     : the name of the field to check
 *  strFriendlyPrefix (string): the prefix to the friendly error message to display in the alert box
 *  imgName (string)          : the name of the image to turn on if an error occurs. (Netscape Only)
 *  isRequired (boolean)      : true if the field is required
 *  intMin (int)              : the minimum length of the value of the field passed
 *  intMax (int)              : the maximum length of the value of the field passed
 *
 *  Perform several checks on alphanumeric fields and create an appropriate
 *  error if the field value is invalid.
 *
 * NOTE! This method has verbiage and should be moved into a project directory.
 */
function checkAlphanumeric(theFieldName, strFriendlyPrefix, imgName, isRequired, intMin, intMax) {
    var theField = fieldForName(theFieldName);

    if (!isAlphanumeric(theField.value, true)) {
        createNewError(theField, strFriendlyPrefix + "\tYou must use only letters and/or numbers in this field.", imgName);
    }
    else if ((isRequired || !isEmpty(theField.value)) && intMin && intMax) {
        var msg;
        if (intMin == intMax) {
          msg = strFriendlyPrefix + "\tThis field requires " + intMin + " characters."
        }
        else {
          msg = strFriendlyPrefix + "\tThis field requires between " + intMin + " and " + intMax + " characters."
        }
        checkLength(theFieldName, msg, intMin, imgName);
    }
    else if (isRequired) {
        checkRequired(theFieldName, strFriendlyPrefix + "\tThis field is required.", imgName);
    }
}


/***
 *  checkNumeric(string, string, string [, boolean [, int, int]])
 *  inputs:
 *  theFieldName (string)     : the name of the field to check
 *  strFriendlyPrefix (string): the prefix to the friendly error message to display in the alert box
 *  imgName (string)          : the name of the image to turn on if an error occurs. (Netscape Only)
 *  isRequired (boolean)      : true if the field is required
 *  intMin (int)              : the minimum length of the value of the field passed
 *  intMax (int)              : the maximum length of the value of the field passed
 *
 *  Perform several checks on numeric fields and create an appropriate
 *  error if the field value is invalid.
 *
 * NOTE! This method has verbiage and should be moved into a project directory.
 */
function checkNumeric(theFieldName, strFriendlyPrefix, imgName, isRequired, intMin, intMax) {
    var theField = fieldForName(theFieldName);

    if (!isInteger(theField.value, true)) {
        createNewError(theField, strFriendlyPrefix + "\tYou must use only numbers in this field.", imgName);
    }
    else if ((isRequired || !isEmpty(theField.value)) && intMin && intMax) {
        var msg;
        if (intMin == intMax) {
          msg = strFriendlyPrefix + "\tThis field requires " + intMin + " characters."
        }
        else {
          msg = strFriendlyPrefix + "\tThis field requires between " + intMin + " and " + intMax + " characters."
        }
        checkLength(theFieldName, msg, intMin, imgName);
    }
    else if (isRequired) {
        checkRequired(theFieldName, strFriendlyPrefix + "\tThis field is required.", imgName);
    }
}

/***
 *  checkAddressable(string, string, string [, boolean [, int, int]])
 *  inputs:
 *  theFieldName (string)     : the name of the field to check
 *  strFriendlyPrefix (string): the prefix to the friendly error message to display in the alert box
 *  imgName (string)          : the name of the image to turn on if an error occurs. (Netscape Only)
 *  isRequired (boolean)      : true if the field is required
 *  intMin (int)              : the minimum length of the value of the field passed
 *  intMax (int)              : the maximum length of the value of the field passed
 *
 *  Perform several checks on incoming strings and create an appropriate
 *  error if the field value is invalid.
 *
 * NOTE! This method has verbiage and should be moved into a project directory.
 */
function checkAddressable(theFieldName, strFriendlyPrefix, imgName, isRequired, intMin, intMax) {
    var theField = fieldForName(theFieldName);
    if (!isAddressable(theField.value, true)) {
        createNewError(theField, strFriendlyPrefix + "\tInvalid characters entered.", imgName);
    }
    else if ((isRequired || !isEmpty(theField.value)) && intMin && intMax) {
        var msg;
        if (intMin == intMax) {
          msg = strFriendlyPrefix + "\tThis field requires " + intMin + " characters."
        }
        else {
          msg = strFriendlyPrefix + "\tThis field requires between " + intMin + " and " + intMax + " characters."
        }
        checkLength(theFieldName, msg, intMin, imgName);
    }
    else if (isRequired) {
        checkRequired(theFieldName, strFriendlyPrefix + "\tThis field is required.", imgName);
    }
}


/***
 *  checkLetterFirstAddressable(string, string, string [, boolean [, int, int]])
 *  inputs:
 *  theFieldName (string)     : the name of the field to check
 *  strFriendlyPrefix (string): the prefix to the friendly error message to display in the alert box
 *  imgName (string)          : the name of the image to turn on if an error occurs. (Netscape Only)
 *  isRequired (boolean)      : true if the field is required
 *  intMin (int)              : the minimum length of the value of the field passed
 *  intMax (int)              : the maximum length of the value of the field passed
 *
 *  Perform several checks on incoming strings and create an appropriate
 *  error if the field value is invalid.
 *
 * NOTE! This method has verbiage and should be moved into a project directory.
 */
function checkLetterFirstAddressable(theFieldName, strFriendlyPrefix, imgName, isRequired, intMin, intMax) {
    var theField = fieldForName(theFieldName);
    if((!isEmpty(theField.value)) && ( !isLetter(theField.value.charAt(0)))) {
        createNewError(theField, strFriendlyPrefix + "\tThis field must start with a letter.", imgName);
    } else if (!isAddressable(theField.value, true)) {
        createNewError(theField, strFriendlyPrefix + "\tYou have entered an invalid character. Please try again.", imgName);
    } else if ((isRequired || !isEmpty(theField.value)) && intMin && intMax) {
        var msg;
        if (intMin == intMax) {
          msg = strFriendlyPrefix + "\tThis field requires " + intMin + " characters."
        } else {
          msg = strFriendlyPrefix + "\tThis field requires between " + intMin + " and " + intMax + " characters."
        }
        checkLength(theFieldName, msg, intMin, imgName);
    } else if (isRequired) {
        checkRequired(theFieldName, strFriendlyPrefix + "\tThis field is required.", imgName);
    }
}

/***
 *  checkAlpha(string, string, string [, boolean [, int, int]])
 *  inputs:
 *  theFieldName (string)     : the name of the field to check
 *  strFriendlyPrefix (string): the prefix to the friendly error message to display in the alert box
 *  imgName (string)          : the name of the image to turn on if an error occurs. (Netscape Only)
 *  isRequired (boolean)      : true if the field is required
 *  intMin (int)              : the minimum length of the value of the field passed
 *  intMax (int)              : the maximum length of the value of the field passed
 *
 *  Perform several checks on alpha fields and create an appropriate
 *  error if the field value is invalid.
 *
 * NOTE! This method has verbiage and should be moved into a project directory.
 */
function checkAlpha(theFieldName, strFriendlyPrefix, imgName, isRequired, intMin, intMax) {
    var theField = fieldForName(theFieldName);

    if (!isAlphabetic(theField.value, true)) {
        createNewError(theField, strFriendlyPrefix + "\tYou must use only letters in this field.", imgName);
    }
    else if ((isRequired || !isEmpty(theField.value)) && intMin && intMax) {
        var msg;
        if (intMin == intMax) {
          msg = strFriendlyPrefix + "\tThis field requires " + intMin + " characters."
        }
        else {
          msg = strFriendlyPrefix + "\tThis field requires between " + intMin + " and " + intMax + " characters."
        }
        checkLength(theFieldName, msg, intMin, imgName);
    }
    else if (isRequired) {
        checkRequired(theFieldName, strFriendlyPrefix + "\tThis field is required.", imgName);
    }
}

/***
 *  checkAlpha(string, string, string [, boolean [, int, int]])
 *  inputs:
 *  theFieldName (string)     : the name of the field to check
 *  strFriendlyPrefix (string): the prefix to the friendly error message to display in the alert box
 *  imgName (string)          : the name of the image to turn on if an error occurs. (Netscape Only)
 *  isRequired (boolean)      : true if the field is required
 *  intMin (int)              : the minimum length of the value of the field passed
 *  intMax (int)              : the maximum length of the value of the field passed
 *
 *  Perform several checks on alpha fields and create an appropriate
 *  error if the field value is invalid.
 *
 * NOTE! This method has verbiage and should be moved into a project directory.
 */
function checkYorN(theFieldName, strFriendlyPrefix, imgName, isRequired) {
    var theField = fieldForName(theFieldName);

    if( (isRequired) && (!(theField.value == 'Y' || theField.value == 'N')) ) {
        createNewError(theField, strFriendlyPrefix + "\tYou must use only 'Y' or 'N' in this field.", imgName);
    } else if(isRequired) {
        checkRequired(theFieldName, strFriendlyPrefix + "\tThis field is required.", imgName);
    }
}

function createNewError(theField, strError, imgName)
{
    var error = new Object();
    error.field = theField;
    error.name = strError;
    error.imgName = imgName;
    arrErr[arrErr.length] = error;
}

function createNewServerError(theField, strError, imgName)
{
    var error = new Object();
    error.field = theField;
    error.name = strError;
    error.imgName = imgName;
    arrServerErrors[arrServerErrors.length] = error;
}

function addServerErrorsToErrArray() {
    for( var i = 0; i < arrServerErrors.length; i++) {
        arrErr[arrErr.length] = arrServerErrors[i];
    }
}


function clearErrorHighlight(theField, imgName)
{
    if(!isNN && USE_STYLESHEET_ERRORS)
    {
        theField.style.backgroundColor = ERROR_HIGHLIGHT_COLOR_OFF;
    }
    else
    {
        switchImage(imgName, ERROR_HIGHLIGHT_IMAGE_OFF);
        switchFieldClass(imgName, ERROR_HIGHLIGHT_BACKGROUND_OFF);
    }
}

function setErrorHighlight(theField, imgName)
{
    if(!isNN && USE_STYLESHEET_ERRORS) {
        theField.style.backgroundColor = ERROR_HIGHLIGHT_COLOR_ON;
    }
    else {
        switchImage(imgName, ERROR_HIGHLIGHT_IMAGE_ON);
        switchFieldClass(imgName, ERROR_HIGHLIGHT_BACKGROUND_ON);
    }
}
/*
    ------------------------------------------      GENERIC HELPER FUNCTIONS        ---------------------------------
*/

/*
function fieldForName(theFieldName)
{
    return window.document.theForm[theFieldName];
}
*/
function fieldForName(theFieldName)
{
    return getForm()[theFieldName];
}

function getForm()
{
    return window.document.forms[currentFormName];
}

function switchImage(imageID, imageSrc)
{
    if(document.images[imageID] != null)
        document.images[imageID].src = imageSrc;
    else
        imageID.src = imageSrc;
}

function switchFieldClass(imgName, theClassName)
{
    var textElementName = "";    
    if(document.images[imgName] != null) {
        textElementName = "spanError" + imgName.substring(3);
    } else {
        textElementName = imgName.name;
        if (textElementName != undefined ) {
            textElementName = "spanError" + textElementName.substring(3);
        } else {
          return;
        }
    }
    var theTextElement = document.getElementById(textElementName);
    if(theTextElement != null) {
        theTextElement.className = theClassName;
    }
}

function getSelectValue(theSelectName) {
    return fieldForName(theSelectName).options[fieldForName(theSelectName).selectedIndex].value;
}



/* 
 *  This Function is used to check for the valid characters defined below.
 *  Checks for [A-Z], [a-z], [0-9] , hyphen, underscore,apostrophe, dot and spaces  
 *  Also checks for the length depending on the parameters passed. 
 */
function checkValidName(theFieldName,strFriendlyPrefix,imgName,isRequired, intMin, intMax ) {
  var theField = fieldForName(theFieldName);  
  var theFieldValue = stripWhitespace(theField.value);
  var validName = /^[\w\s\-'\.]+$/;

  if ( isEmpty(theFieldValue) ) {
     msg = strFriendlyPrefix + "\tThis field requires between " + intMin + " and " + intMax + " characters."
     checkLength(theFieldName, msg, intMin, imgName);
  } else {
    if (!validName.test(theFieldValue)) {
        createNewError(theField, strFriendlyPrefix + "\tYou have entered an invalid character. Please try again.", imgName);
    }
    else if ((isRequired || !isEmpty(theFieldValue)) && intMin && intMax) {
        var msg;
        if (intMin == intMax) {
          msg = strFriendlyPrefix + "\tThis field requires " + intMin + " characters."
        }
        else {
          msg = strFriendlyPrefix + "\tThis field requires between " + intMin + " and " + intMax + " characters."
        }
        checkLength(theFieldName, msg, intMin, imgName);
    }
    else if (isRequired) {
        checkRequired(theFieldName, strFriendlyPrefix + "\tThis field is required.", imgName);
    }
  }  
}
