//if not gecko browser OR IE, then treat as NS4
var isNN = ( (navigator.userAgent.toUpperCase().indexOf("GECKO") < 0) && (navigator.userAgent.toUpperCase().indexOf("MSIE") < 0) );

var hiddenFieldsHaveFocus = false;

if(isNN) {
  	document.captureEvents(Event.KEYPRESS);
}


function getIndex(input) {
    var index = -1;
    var i = 0;

    while ((i < input.form.length) && (index == -1)) {
        if (input.form[i] == input) {
            index = i;
		} else {
            i++;
		}
    }

    return index;
}

function containsElement(arr, ele) {
    var found = false;
    var index = 0;

    while(!found && index < arr.length) {
	    if(arr[index] == ele) {
	        found = true;
		} else {
	        index++;
	    }
	}

    return found;
}


/*
   FUNCTION:    autoTab(input,len, e)
   PURPOSE:     Auto tab conditionally to next field.
   INPUTS:      element, max length of element, event.
   OUTPUTS:     tab to next field.
   Author:      .Net Systems (2001)
*/
function autoTab(input,len, e) {

    if(!hiddenFieldsHaveFocus) {
        addFocusToHiddenFields();
    }

    var isNN = (navigator.appName.indexOf("Netscape")!=-1);
    var keyCode = (isNN) ? e.which : e.keyCode;
    var filter = (isNN) ? [0,8,9] : [0,8,9,16,17,18,37,38,39,40,46];
    //if (input.value.length == 2)
        //alert("value is " + input.value + ", keycode is " + keyCode + ", filter is " + filter + ", len is " + input.value.length);

    if((input.value.length >= len) && (!containsElement(filter,keyCode))) {
        input.value = input.value.slice(0, len);
        var nextIndex = (getIndex(input)+1) % input.form.length;
        while (nextIndex < input.form.length && input.form[nextIndex].disabled) nextIndex++;
        if (input.form[nextIndex].disabled) {
			return true;
		}
        input.form[nextIndex].focus(nextIndex);
    }
    return true;
}

function addFocusToHiddenFields() {
    var i = 0;
    var theForm = window.document.theForm;
    for(i=0;i<theForm.elements.length;i++) {
        var input = theForm.elements[i];
        if(input.type == "hidden") {
            input.focus = hiddenfocus;
        }
    }
    hiddenFieldsHaveFocus = true;
}

function hiddenfocus(nextIndex) {
    var theForm = window.document.theForm;
    nextIndex = ((nextIndex+1) % theForm.length);
    if(nextIndex == 0) {
        return;
    }

    // Avoid recursion because IE has a stack overflow
    while (theForm[nextIndex].type == "hidden" && ++nextIndex < theForm.length);
    if (nextIndex < theForm.length) {
        theForm[nextIndex].focus(nextIndex);
    }
}

/*
   FUNCTION:    quickTab(formField, e , nextGroupField)
   PURPOSE:     Tab to the next group if the current field is empty.
   INPUTS:      current field, event, the field representing the beginning of the next group.
   Author:      rvp.Net Systems (2002)
*/
function quickTab(formField, e, nextGroupField) {
    if(formField.value == "") {
        var isNetscape = (navigator.appName.indexOf("Netscape")!=-1);
        var keyCode = (isNetscape) ? e.which : e.keyCode;
        if(keyCode == 9 && (!e.shiftKey)) {
            nextGroupField.focus();
            e.returnValue = false;
            e.cancelBubble = true;
            e = null;
            return false;
        }
    }
    return true;
}

function tabTo(toField, e) {
    var isNetscape = (navigator.appName.indexOf("Netscape")!=-1);
    var keyCode = (isNetscape) ? e.which : e.keyCode;
	// is the key a "TAB" key, if so, then perform the tab.
    if(keyCode == 9 && !e.shiftKey) {
        toField.focus();
        e.returnValue = false;
        e.cancelBubble = true;
        e = null;
        return false;
    }
    return true;
}

// function to focus the passed field.  Field is passed by string name.
// if the field is a radio input control, the first element in the radio
// input control will be focused.
function focusField(strFieldName) {
    var theForm = getForm();
    var field = null;

    if(strFieldName != "") {
        field = theForm[strFieldName];
	}

    if(field != null) {
        //check to see if the field is a radio button
        if( typeof(field) == "object" && (new String(field.type)) == "undefined") {
            field[0].focus();
        } else {
            field.focus();
        }
    }
}

// Prefills tabbed to cents values to "00" if the corresponding dollars field
// has a value.
function prefillCents(theField, suffix) {
    if(!isWhitespace(theField.value)) {
        return;
    }

    var centsFieldName = theField.name;
    var dollarsFieldName = "";

    var re = /Cents/

    if(centsFieldName.indexOf("Cents") >= 0) {
        dollarsFieldName = centsFieldName.replace(re, "Dollars");
    }

    if(suffix != null) {
        dollarsFieldName += suffix;
    }

    var dollarsField = fieldForName(dollarsFieldName);
    if(dollarsField != null && !isWhitespace(dollarsField.value)) {
        theField.value = "00";
        theField.select();
    }
}


/*
   FUNCTION:    setSelectOption
   PURPOSE:     select the option item based on a value (not index)
   INPUTS:      selectBox - the select element, usually document.forms[0].name
                                selectValue - the value to be matched
   OUTPUTS:     none
   EFFECT:              the option(s) have been selected
*/
function setSelectOption(selectBox, selectValue) {

    // deselect all options in select box
    selectBox.selectedIndex = -1;

    // cycle through all options in select box
    for (var i = 0; i < selectBox.length; i++) {
        if (selectBox.options[i].value == selectValue) {
            // set the selected index to the first selected item
            if (selectBox.selectedIndex == -1) {
                selectBox.selectedIndex = i;
            }
            // allow multiple options to be selected
            selectBox.options[i].selected = true;
        }
    }

    // if none are selected,
    // select the first item to prevent a blank line from being displayed
    if ((selectBox.selectedIndex == -1) && (selectBox.type == "select-one")) {
        selectBox.selectedIndex = 0;
    }

}       /* end of function setSelectOption */

/*
   FUNCTION:    setSelectChecked
   PURPOSE:     select the option item based on a value (not index)
   INPUTS:      radioButton - the select element, usually document.forms[0].name
                                selectValue - the value to be matched
   OUTPUTS:     none
   EFFECT:              the option(s) have been selected
*/
function setSelectChecked(radioButton, selectValue) {
    // cycle through all options in radio button or check box
    for (var i = 0; i < radioButton.length; i++) {
        if (radioButton[i].value == selectValue) {
            //alert("setting checked");
            // set the selected index to the first selected item
            radioButton[i].checked = true;
            break;
        }
    }
}       /* end of function setSelectChecked */

function doCancel() {
    if(confirm("Are you sure you want to cancel this entire claim?")) {
        top.content.location.replace('/im/bcbs_pro_content.html');
	}
}

/*
   FUNCTION:    removeLessThanAndGreaterThanChars
   PURPOSE:     select the option item based on a value (not index)
   INPUTS:      selectBox - the select element, usually document.forms[0].name
                                selectValue - the value to be matched
   OUTPUTS:     field with < and > removed.
   EFFECT:      the option(s) have been selected
*/
function removeLessThanAndGreaterThanChars(field) {
    var testField = field.value;
    while (testField.charAt(0) == "<" || testField.charAt(0) == ">") {
        if(testField.charAt(0) == "<") {
            testField = "less than" + testField.substring(1);
        } else if (testField.charAt(0) == ">") {
            testField = "greater than" + testField.substring(1);
        }
    }
    var indexOfBadJunk = 0;
    while (testField.indexOf("<") > 0 || testField.indexOf(">") > 0) {
        var savedNote = "";
        indexOfBadJunk = testField.indexOf("<");
        if (indexOfBadJunk > 0) {
            savedNote   = testField;
            testField     = testField.substring(0,indexOfBadJunk);
            testField     = testField + "less than" + savedNote.substring(indexOfBadJunk+1);
        }
        indexOfBadJunk = testField.indexOf(">");
        if (indexOfBadJunk > 0) {
            savedNote   = testField;
            testField     = testField.substring(0,indexOfBadJunk);
            testField     = testField + "greater than" + savedNote.substring(indexOfBadJunk+1);
        }
    }
    field.value = testField;
}