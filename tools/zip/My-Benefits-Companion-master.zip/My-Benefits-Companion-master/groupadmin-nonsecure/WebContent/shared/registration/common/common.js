/*
 * @(#)common.js
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * Commerical Website Shared Registration
 * JavaScript miscellaneous common functions
 *
 * This is a shared file.  Please see the following file for information
 * regarding the use of Shared Registration JSPs:
 *   D:/Netscape/Shared/registration/shared_readme.txt
 *
 * @author      Jonathan Egger
 * @version     $Revision:   1.0  $ - $Date:   Jul 31 2009 15:06:18  $
 * @since       1.0
 *
 */

/**
 * Formats the date of birth
 *
 * @param month  month value field object
 * @param day  day value field object
 * @param year  year value field object
 * @return formatted date of birth
 */
function formatDateOfBirth(month, day, year) {
    if (day.value.length == 1) {
        day.value = "0" + day.value;
    }

    if (month.value.length == 1) {
        month.value = "0" + month.value;
    }
    
    var dob = month.value + "/" + day.value + "/" + year.value;
    if (dob == "//") {
        dob = "";
    }
    return dob;
}

/**
 * Updates an option dropdown with the appropriate values based on the selected values of another dropdown.
 * Requires three arrays to be set before calling:
 *     optionsGroups[] containing the group value associated with each option.  When this group is selected
 *                     in the cboBox dropdown, this option will be included in the idCboBoxToChange options.
 *     optionValues[]  containing the values for each option.
 *     optionLabels[]  containing the labels for each option.
 * the option value to the currently selected option
 *
 * @param cboBox the dropdown whose selection defines the group value
 * @param idCboBoxToChange the dropdown that will be defined by the current group and options arrays
 * @param selectedValue the default value of the idCboBoxToChange options box
 */
function setGroupedOptions(cboBox, idCboBoxToChange, selectedValue, labelName) {
    cboBoxToChange = new Object();
    if (isNaN(idCboBoxToChange)) {
        cboBoxToChange = eval("document." + cboBox.form.name + "." + idCboBoxToChange + ";");
    } else {
        cboBoxToChange = eval("document." + cboBox.form.name + "." + cboBox.name + "[" + idCboBoxToChange + "];");
    }

    cboBoxToChange.length = 1;
    for (var i = 0; i < cboBoxToChange.length; i++) {
        cboBoxToChange.options[i] = new Option("");
        cboBoxToChange.options[i].value = "";
        cboBoxToChange.options[i].name  = "";
    }
 
    var j = 1;
    for (var i = 0; i < optionValues.length; i++) {
        if ( cboBox.value == optionGroups[i] ) {
            cboBoxToChange.options[j] = new Option(optionLabels[i]);
            cboBoxToChange.options[j].value = optionValues[i];
            cboBoxToChange.options[j].name = optionLabels[i];
            if (selectedValue != null && selectedValue == optionValues[i]) {
                if (setGroupedOptions.arguments.length > 3) {
                   eval(labelName).value = cboBoxToChange.options[j].name;
                }            
                cboBoxToChange.options[j].selected = true;
            }
            j++;
        }
    }
}

/**
 * Displays the cancel popup
 *
 * @param cancelPage link to the cancel page
 */
function displayCancelWarning(cancelPage) {
    cancelwindow = window.open(cancelPage,"cancelwindow","width=400,height=150,resizable=no,scrollbars=no");
    cancelwindow.focus();
}
/**
 * Submits the page for an alternate action
 *
 * @param refForm  the form to be submitted
 * @param newActionPath the path of the action to be performed on submission
 * @return true
 */
function actionSubmit(refForm, newActionPath) {
    refForm.action = newActionPath;
    refForm.submit();
    return true;
}
/**
 * Checks page for duplicate submission

 * @return true, if page should submit; false, otherwise
 */
var submitcount=0;
function checkSubmit() {
    if (submitcount == 0) {
        submitcount++;
        return true;
    } else {
        return false;
    }
}
/**
 * Updates a bean.changed flag
 *
 * @param inputName name of input, containing beanname
 */
function updateChangedFlag(inputName) {
    var nameEnd = inputName.indexOf('.');
    if (nameEnd != -1) {
        document.getElementsByName(inputName.substr(0,nameEnd) + ".changed").item(0).value = true;
    }
}

/*
   FUNCTION:    autoTab(input,len, e)
   PURPOSE:     Auto tab conditionally to next field.
   INPUTS:      element, max length of element, event.
   OUTPUTS:     tab to next field.
   Author:      .Net Systems (2001)
*/
function autoTab(input,len, e) {
    var isNN = (navigator.appName.indexOf("Netscape")!=-1);
    var keyCode = (isNN) ? e.which : e.keyCode; 
    var filter = (isNN) ? [0,8,9] : [0,8,9,16,17,18,37,38,39,40,46];
    //if (input.value.length == 2)
        //alert("value is " + input.value + ", keycode is " + keyCode + ", filter is " + filter + ", len is " + input.value.length);
        
    if((input.value.length >= len) && (!containsElement(filter,keyCode))) {
        input.value = input.value.slice(0, len);
        var contrl = input.form[(getIndex(input)+1) % input.form.length];
        if( contrl.type != "hidden") {
            contrl.focus();
        } else {
            // try 1 more 
            contrl = input.form[(getIndex(input)+2) % input.form.length];       
            if( contrl.type != "hidden") {
                contrl.focus();
            }
        }
    }
    return true;
}

    function containsElement(arr, ele) {
        var found = false;
        var index = 0;
        while(!found && index < arr.length) {
            if(arr[index] == ele)
                found = true;
            else
                index++;
        }
        return found;
    }

    function getIndex(input) {
        var index = -1;
        var i = 0;
        while (i < input.form.length && index == -1) {
            if (input.form[i] == input)
                index = i;
            else 
                i++;
        }
        return index;
    }
    /*
       FUNCTION:    highlightErrors(formName)
       PURPOSE:     To high light the error fields to pink.
       INPUTS:      The name of the form.
       OUTPUTS:     The Error filed has a pink back ground.
       Author:      Surendra.V.Poranki
    */
    function highlightErrors(refForm){
        for (i = 0; i<refForm.elements.length; i++) { 
            var fieldName = refForm.elements[i].name; 
            try{ 
            if (eval(refForm.elements[i].name) == "error" ) {
            refForm.elements[i].style.background = "pink"; 
            }
               } catch ( e ) {  }
       }
    } 
    
    
    /*
       This function is used to display the error messages in a web page standards format.
    */
    
    function displayMessages() {
        arrErr = new Array();    
        var i=0;
        for(i=0;i < strutsErrors.length;i++) {
            createNewError(fieldForName(strutsErrors[i].fieldName), strutsErrors[i].fieldMessage, strutsErrors[i].fieldImage );
        }
    
        displayErrorsArray();
    }