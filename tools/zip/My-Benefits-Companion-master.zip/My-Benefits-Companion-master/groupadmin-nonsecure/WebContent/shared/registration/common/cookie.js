/*
 * @(#)cookie.js
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * Commerical Website Shared Registration
 * JavaScript common cookie manipulation functions
 *
 * This is a shared file.  Please see the following file for information
 * regarding the use of Shared Registration JSPs:
 *   D:/Netscape/Shared/registration/shared_readme.txt
 *
 * @author      Jonathan Egger
 * @version     $Revision:   1.0  $ - $Date:   Jul 31 2009 15:06:22  $
 * @since       1.0
 *
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-web-webpages/common/common/cookie.js_v  $

   Rev 1.0   Jul 31 2009 15:06:22   EN80
Initial revision.

   Rev 1.1   Mar 22 2005 14:19:14   rxg97
Added clearCookies() and setReferPageCookie().

   Rev 1.0   Sep 23 2004 09:59:08   rxg97
Initial revision.
 */

/**
 * Gets the server domain name
 * @return server domain name
 */
function getDomain() {
    var myDomain = document.domain;
    var noPortDomain = myDomain.split(":");

    splitDomain = noPortDomain[0].split(".");
    returnDomain = "." + splitDomain[1] + "." + splitDomain[2];

    return returnDomain;
}

/**
 * Gets the cookie data
 * @param label  cookie name
 * @return cookie value
 */
function getCookieData(label) {
    var key = label.replace(/([^=]*)=?$/, "$1");
    var cookies = document.cookie.split(";");
    for (var i=0; i < cookies.length; i++) {
        pair = cookies[i].split("=");
        if (pair.length == 2) {
            pair[0] = pair[0].replace(/^\s*(.*)\s*$/, "$1");
            if (pair[0] == key)
                return unescape(pair[1]);
        }
    }
    return "";
}

/**
 * Deletes cookie data
 * @param name  cookie name
 * @param path  path cookie applies on
 * @param domain  domain cookie applies in
 */
function DeleteCookie (name,path,domain) {
    var expiration = new Date();
    expiration.setMonth(1);
    expiration.setDate(1);
    expiration.setYear(1970);
    expiration.setHours(0);
    expiration.setMinutes(0);
    expiration.setSeconds(1);

    if (getCookieData(name)) {
        document.cookie = name + "=" 
            + ((path) ? "; path=" + path : "")
            + ((domain) ? "; domain=" + domain : "")
            + "; expires=" + expiration.toGMTString();
    }
}

/**
 * Deletes the ONTCred cookie.
 */
function deleteCredCookie() {
    DeleteCookie("ONTCred","/",getDomain());
}

/*
   FUNCTION:    setReferPageCookie()
   PURPOSE:     set a session cookie with the location the user came from
                set company cookie with appropriate company
   INPUTS:      none
   OUTPUTS:     sets "company" cookie to:
                        0 for BCBS
                        1 for CHC
                        2 for HMOB
   AUTHOR:      Harry Sauers & Alexander Winner, OpenNetwork Technologies, (c)1999
*/
function setReferPageCookie() {
    var referPage = document.referrer;

    if ( document.refForm.referringPage )
        document.refForm.referringPage.value = referPage;

    // *** Set Referring Page cookie
    if (getCookieData("referringPage=") == "")
        if (referPage != "")
            document.cookie = "referringPage=" + referPage + ";";
        else
            document.cookie = "referringPage=http://www.bcbssc.com";

} // end function setReferPageCookie()

/*
   FUNCTION:    clearCookies()
   PURPOSE:     clears all cookie information for IM
   INPUTS:      none
   OUTPUTS:     sets "DNCookie", "dateOfAcceptance", "referringPage" and "RACF" cookies to nothing
   AUTHOR:      Alexander Winner, OpenNetwork Technologies, (c)1999
*/
function clearCookies() {
    var myDomain = document.domain;
    splitDomain = myDomain.split(".");
    returnDomain = "." + splitDomain[1] + "." + splitDomain[2];
//  alert("Before: " + document.cookie);
    DeleteCookie("ONTCred","/",returnDomain);
    DeleteCookie("DNCookie","/",returnDomain);
    DeleteCookie("dateOfAcceptance","/",getDomain());
    DeleteCookie("referringPage","/",getDomain());
//    DeleteCookie("RACF","",returnDomain);
    DeleteCookie("UserCLASS","/",getDomain());
    DeleteCookie("RACF","/", getDomain());
    //document.cookie = "RACF='';domain=.opennetwork.com;";
//  alert("After: " + document.cookie);
} // end function clearCookies()