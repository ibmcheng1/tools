/*****************************************************************************
**
** Filename : common_script_tools.js
**
** Description : JavaScript file for scripting for most JSP files
**
** Notes :
**
** Revision History :  1st revision 05/27/2004
** Modifications:
** Chg.Sht. Pgmr.       Date        Descr.
**
**
*****************************************************************************/
ERROR_HIGHLIGHT_IMAGE_ON = "../images/error.gif";
ERROR_HIGHLIGHT_IMAGE_OFF = "../images/error_no.gif";
//USE_STYLESHEET_ERRORS = false;

var lock = false;

/**
 * isCanada checks to see if the user has selected CANADA, 
 * this is used for conditional field validation in many claims entry pages
 *
 * @param the name of a country select form field 
 * @return true if the field's selection is either CANADA, false otherwise
 */
function isCanada(fieldName){
                
    var COUNTRY_CANADA="CN ";   //CANADA
    var COUNTRY_CANADA2="CA";   //CANADA from the new country table.
            
    var fieldVal=getSelectValue(fieldName);
            
    if ((fieldVal==COUNTRY_CANADA2)||
        (fieldVal==COUNTRY_CANADA)){                
            return true;
    }
    
    return false;            
}

/**
 * isUSA checks to see if the user has selected USA, 
 * this is used for conditional field validation in many claims entry pages
 *
 * @param the name of a country select form field 
 * @return true if the field's selection is either USA, false otherwise
 */
function isUSA(fieldName){
                
    var COUNTRY_USA_0="";       //BLANK = UNITED STATES
    var COUNTRY_USA_1="UM ";    //UNITED STATES MINOR OUTLYING ISLANDS
    var COUNTRY_USA_2="BQ ";    //UNITED STATES MISC CARRIBEAN ISLANDS
    var COUNTRY_USA_3="IF ";    //UNITED STATES MISC PACIFIC ISLANDS
    var COUNTRY_USA_4="USA";    //UNITED STATES 
    var COUNTRY_USA_5="US";     //UNITED STATES from the new country table.
            
    var fieldVal=getSelectValue(fieldName);
            
    if ((fieldVal==COUNTRY_USA_0)||
        (fieldVal==COUNTRY_USA_1)||
        (fieldVal==COUNTRY_USA_2)||
        (fieldVal==COUNTRY_USA_3)||
        (fieldVal==COUNTRY_USA_4)||
        (fieldVal==COUNTRY_USA_5)){                
            return true;
    }
    
    return false;            
}

/**
 * isUSAorCanada checks to see if the user has selected USA or CANADA, 
 * this is used for conditional field validation in many claims entry pages
 *
 * @param the name of a country select form field 
 * @return true if the field's selection is either USA or CANADA, false otherwise
 */
function isUSAorCanada(fieldName){
                
    var COUNTRY_USA_0="";       //BLANK = UNITED STATES
    var COUNTRY_USA_1="UM ";    //UNITED STATES MINOR OUTLYING ISLANDS
    var COUNTRY_USA_2="BQ ";    //UNITED STATES MISC CARRIBEAN ISLANDS
    var COUNTRY_USA_3="IF ";    //UNITED STATES MISC PACIFIC ISLANDS
    var COUNTRY_USA_4="USA";    //UNITED STATES 
    var COUNTRY_USA_5="US";     //UNITED STATES from the new country table.
    var COUNTRY_CANADA="CN ";   //CANADA
    var COUNTRY_CANADA2="CA";   //CANADA from the new country table.
            
    var fieldVal=getSelectValue(fieldName);
            
    if ((fieldVal==COUNTRY_USA_0)||
        (fieldVal==COUNTRY_USA_1)||
        (fieldVal==COUNTRY_USA_2)||
        (fieldVal==COUNTRY_USA_3)||
        (fieldVal==COUNTRY_USA_4)||
        (fieldVal==COUNTRY_USA_5)||
        (fieldVal==COUNTRY_CANADA2)||
        (fieldVal==COUNTRY_CANADA)){                
            return true;
    }
    
    return false;            
}
/**
 * override the default focusButton() function in common/netsys_errors.js
 * to focus on our named button
 * note - this function is not used if window.showModalDialog is supported
 * @return true if the focus succeeded, false otherwise
 */
function focusButton(){
     
    if (errorDialog!=null){    
        if ((errorDialog.frames.length==2)&&(errorDialog.frames["buttonFrame"].document.forms.length>0)){            
            errorDialog.frames["buttonFrame"].document.frmButtons.okButton.focus();
            return true;
        }
    }            
    return false;
            
}

/** 
 * override the default focusWindow() function in common/netsys_errors.js
 * to enable specific dialog features
 * note - this function is not used if window.showModalDialog is supported
 */
 
function focusWindow(){    
    //if our window handle is still valid, focus the window 
    if (errorDialog!=null){
            //if its NN or our frames arent loaded, just focus the window and be done with it
        if ((isNS)||(errorDialog.frames.length<2)||(errorDialog.frames["buttonFrame"].document.forms.length==0)){
            errorDialog.focus();        
        }else{
            //otherwise check to see if the window is already focused before refocusing
            if (!((errorDialog.frames["buttonFrame"].document.hasFocus())||(errorDialog.frames["errorFrame"].document.hasFocus()))){
                errorDialog.focus();                     
            }        
        }
    }
    
}

/**
 * override the default alertErrors() function in common/netsys_errors.js
 * to enable html error dialogs for the Patient Directory application
 */


function alertErrors()
{
    var MAX_ERRORS=25;
    var MAX_WINDOW_HEIGHT=400;        
    var BASE_WINDOW_HEIGHT=120;    
    var WINDOW_WIDTH=500;
    var LINE_HEIGHT=20;
    var FRAMESET_URL="/common/commonErrorFrameset.jsp";    
    var BLANK_URL="/blankFrame.html";
    
    displayErrorsDialog(BLANK_URL,FRAMESET_URL,MAX_ERRORS,WINDOW_WIDTH,BASE_WINDOW_HEIGHT,MAX_WINDOW_HEIGHT,LINE_HEIGHT);
}
   
function removePanel(chkboxGroup, panelName, thisMap, currentAction){
    var currElement;
    for(i=0;i<window.document.theForm.elements.length;i++) {
        currElement = window.document.theForm.elements[i];
        if ( (currElement.name == chkboxGroup) && (currElement.value == panelName) ){
            discardElement(currElement);
        } else if (currElement.name == panelName) {
            currElement.value = "";
        }
    }

    reloadPage(thisMap, currentAction);
}

function discardElement(element){
    element.name="discarded";
}

function reloadPage(thisMap, thisAction){
    performSubmit(thisMap, thisAction);
}


function toggleValue(fieldName){
    var modifier = "checked";
    var theField = fieldForName(fieldName);
    if (theField.value == "checked"){
        modifier = "";
    }
    theField.value = modifier;
}

/*
 *    Assumes usage of /common/netsys_error.js (fieldForName())
 */
function clearFields(fieldNames){
    var fieldObjects = new Array(fieldNames.length);
    for (var i=0; i<fieldNames.length; i++){
        fieldObjects[i] = fieldForName(fieldNames[i]);
    }

    clearFieldObjects(fieldObjects);
}

/**
 * preserveSelectValues is optional; default is false
 */
function clearFieldObjects(fieldObjects, preserveSelectValues){
    clearErrors();
    var currField, currType;
    for(var i=0; i<fieldObjects.length; i++){
        currField = fieldObjects[i];
        currType = currField.type;
        if (currType == "select-one"){
            if (!preserveSelectValues) {
                currField.options[currField.selectedIndex].value="";
            }
            currField.selectedIndex = 0;
        } else if ( (currType == "text") || (currType == "textarea" ) || (currType == "hidden") ) {
            currField.value = "";
        } else if (currType == "checkbox" || currType == "radio"){
            currField.checked = false;
        }
    }
}

/**
* doClearForm, non-default args method, presents a clear form dialog
* @param setFocus - sets the form focus to the first field in the panel, if set to true
*/
function doClearFormDialog(setFocus){    
    var cw = new ConfirmationWindow("WARNING", 
            "You are about to erase all of the information that you have entered on this page!", 
            "commitClearForm("+setFocus+")", " OK ", "Cancel", 400, 200);
    cw.open();    
}

/**
 * doClearForm, default args method, presents a clear form dialog
 */
function doClearForm(){
    doClearFormDialog(true);
    
}

/**
 * commitClearForm - clears the form 'theForm', resets all non-hidden elements
 * @param setFocus - sets the form focus to the first field in the form, if set to true 
 */
function commitClearForm(setFocus) {
    var formElements = window.document.theForm.elements;
    var count = 0;
    for(var i=0; i<formElements.length; i++) {
        if (formElements[i].type != "hidden") {
            count++;
        }
    }
    var fieldObjects = new Array(count);
    count = 0
    for(var i=0; i<formElements.length; i++) {
        if (formElements[i].type != "hidden") {
            fieldObjects[count++] = formElements[i];
        }
    }
    clearFieldObjects(fieldObjects, true);

    if (typeof(doOnClear) == "function" ) { // does doOnClear() exist for the page?
        doOnClear();
    }
    if (typeof(removeQuestions) == "function" ) { // does removeQuestions() exist for the page?
            removeQuestions();
    }
    //only set the focus if setFocus is specified 
    //needed for clear with Delete/Submit events, to prevent focusing prior to submit
    if (setFocus)  focusFirstField();
}

function isMoneyEmpty(fieldName, suffix) {
    if (!suffix) suffix = "";
    return isEmpty(fieldForName(fieldName+"Dollars"+suffix).value) &&
           isEmpty(fieldForName(fieldName+"Cents"+suffix).value);
}

function isDateEmpty(fieldName, suffix) {
    if (!suffix) suffix = "";
    return isEmpty(fieldForName(fieldName+"Month"+suffix).value) &&
           isEmpty(fieldForName(fieldName+"Day"+suffix).value) &&
           isEmpty(fieldForName(fieldName+"Year"+suffix).value);
}

function isDateAfter(referenceDate, questionableDate, suffix) {
    if (!suffix) suffix = "";
    var refMonth = parseInt(fieldForName(referenceDate+"Month"+suffix).value);
    var refDay = parseInt(fieldForName(referenceDate+"Day"+suffix).value);
    var refYear = parseInt(fieldForName(referenceDate+"Year"+suffix).value);
    var qMonth = parseInt(fieldForName(questionableDate+"Month"+suffix).value);
    var qDay = parseInt(fieldForName(questionableDate+"Day"+suffix).value);
    var qYear = parseInt(fieldForName(questionableDate+"Year"+suffix).value);

    if (qYear < refYear) return false;
    if (qYear > refYear) return true;

    // Years are equal
    if (qMonth < refMonth) return false;
    if (qMonth > refMonth) return true;

    // Months are equal
    return (qDay > refDay);
}

/**
 * function: capitalize()
 *     capitalizes the first letter of the fieldanames passed as paramters
 *     to this function.
 */
function capitalize(fieldNames){
    for (var i=0; i<fieldNames.length; i++){
        var temp = fieldForName(fieldNames[i]).value;
        temp = temp.substring(0,1).toUpperCase()+temp.substring(1,temp.length);
        fieldForName(fieldNames[i]).value = temp;
    }
}

/**
 * function: convertToUpperCase()
 *     Calls toUpperCase on each field in the input array.
 */
function convertToUpperCase(fieldNames){
    for (var i=0; i<fieldNames.length; i++) {
        fieldForName(fieldNames[i]).value = fieldForName(fieldNames[i]).value.toUpperCase();
    }
}

/**
 * function: checkEnabled()
 *     Checks the disabled attribute of the given element and
 *     blurs the element if disabled. This is needed only for NN.
 */
function checkEnabled(theField) {
    if (theField.disabled) theField.blur();
}

/**
 * function: focusFirstField()
 *      Focuses the first enabled non-hidden field.
 */
function focusFirstField() {
    var theForm = getForm();
    var i = 0;

    for(i = 0; i < theForm.elements.length; i++) {
        var theField = theForm.elements[i];
        if(theField.type != "hidden" && !theField.disabled) {
            theField.focus();
            return;
        }
    }
}

/**
 * function: normalizeSpace()
 *      Removes spaces from the value of the field parameter, similar to xpath's
 *          normalize-space() function.
 *      Requires use of /common/formcheck.js (stripCharsInBag())
 */
function normalizeSpace(theField) {
    if (theField) {
        theField.value = stripCharsInBag(theField.value, " ");
    }
}
