/*
 * @(#)GroupAdminAuthenticateAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.actions;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.groupadmin.shared.dto.RegistrationFormDTO;
import com.bcbssc.groupadmin.shared.services.GroupAdminRegistrationServices;
import com.bcbssc.struts.action.BaseAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;

/**
 * Group Admin Authenticate Action
 *
 * This class provides control processing the authenticate action. Because
 * control for authentication is specific to group admin registration, this
 * class does not subclass a shared action.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.1  $
 */
public class GroupAdminAuthenticateAction extends BaseAction {

	/** log4j logger */
	private static final Logger log = Logger
			.getLogger(GroupAdminAuthenticateAction.class.getName());

	/**
	 * <p>Constructor for GroupAdminAuthenticateAction.</p>
	 */
	public GroupAdminAuthenticateAction() {
		super();
		if (GroupAdminAuthenticateAction.log.isDebugEnabled()) {
			GroupAdminAuthenticateAction.log
					.debug("Created GroupAdminAuthenticateAction object.");
		}
	}

	/**
	 * Processes the specified HTTP request, and create sthe corresponding HTTP
	 * response.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		int status = 0;

		DynaValidatorForm df = (DynaValidatorForm) form;

		String iniFile = CommonUtils.getIniFile(this.getServlet());

		String tdsIniFile = CommonUtils.getTDSIniFile(this.getServlet());
		GroupAdminRegistrationServices service = new GroupAdminRegistrationServices(
		iniFile, tdsIniFile);

		RegistrationFormDTO formDTO = new RegistrationFormDTO();
		BeanUtils.copyProperties(formDTO, df);
		
		status = service.authenticateUser(formDTO);
		
		String forwardname;

		switch (status) {
		case Constants.SERVICE_VALID:
			forwardname = com.bcbssc.registration.common.Constants.FORWARD_WELCOME;
			GroupAdminAuthenticateAction.log.debug("forwarding to: "
					+ forwardname);
			service.setEncryptedCookie(formDTO.getSamAccountName(), request,
					response);
			break;
		case Constants.INVALID_ANSWER:
			forwardname = Constants.FORWARD_INVALID_ANSWER;
			request.setAttribute("populatedHelpForm", formDTO);
			break;
		case Constants.ACCESS_REVOKED:
			forwardname = Constants.FORWARD_ACCESS_REVOKED;
			request.setAttribute("populatedHelpForm", formDTO);
			break;
		default:
			forwardname = Constants.FORWARD_INVALID_CREDENTIALS;
			request.setAttribute("authenticationForm", formDTO);
			break;
		}
		
		return mapping.findForward(forwardname);
	}
}
