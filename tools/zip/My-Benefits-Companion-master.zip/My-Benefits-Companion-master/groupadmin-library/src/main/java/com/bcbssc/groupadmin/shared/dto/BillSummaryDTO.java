/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dto/BillSummaryDTO.java_v  $
 * $Workfile:   BillSummaryDTO.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:34  $
 * $Modtime:   May 14 2009 11:33:30  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dto/BillSummaryDTO.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:14:34   EN80
 * Initial revision.
 * 
 *    Rev 1.3   Apr 28 2009 10:18:24   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.2   May 09 2006 10:33:16   rx08e
 * Changes for Vision Coverage.	
 *
 *    Rev 1.1   Mar 01 2005 15:39:26   rxr93
 * add formatted get methods for web display
 *
 *    Rev 1.0   Feb 11 2005 11:12:38   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.dto;

import com.bcbssc.groupadmin.shared.common.CommonUtils;

/**
 * This bean represents a bill summary item.
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class BillSummaryDTO {

	/**
	 * Holds value of property coverage.
	 */
	private String coverage = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property numberLives.
	 */
	private String numberLives = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property volume.
	 */
	private String volume = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property billed.
	 */
	private String billed = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property adjusted.
	 */
	private String adjusted = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property totalPremium.
	 */
	private String totalPremium = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property coverage type.
	 */
	private String coverageType = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Getter for property coverage.
	 *
	 * @return Value of property coverage.
	 */
	public String getCoverage() {
		return this.coverage;
	}

	/**
	 * Setter for property coverage.
	 *
	 * @param coverage
	 *            New value of property coverage.
	 */
	public void setCoverage(String coverage) {
		this.coverage = coverage;
	}

	/**
	 * Getter for property numberLives.
	 *
	 * @return Value of property numberLives.
	 */
	public String getNumberLives() {
		return this.numberLives;
	}

	/**
	 * Setter for property numberLives.
	 *
	 * @param numberLives
	 *            New value of property numberLives.
	 */
	public void setNumberLives(String numberLives) {
		this.numberLives = numberLives;
	}

	/**
	 * Getter for property volume.
	 *
	 * @return Value of property volume.
	 */
	public String getVolume() {
		return this.volume;
	}

	/**
	 * Gets the formatted volume
	 *
	 * @return currency formatted volume
	 */
	public String getVolumeFormatted() {
		// covert to integer to remove the decimal portion
		Float value = Float.valueOf(this.volume);
		return CommonUtils.formatDollarCurrency(value.intValue());
	}

	/**
	 * Setter for property volume.
	 *
	 * @param volume
	 *            New value of property volume.
	 */
	public void setVolume(String volume) {
		this.volume = volume;
	}

	/**
	 * Getter for property billed.
	 *
	 * @return Value of property billed.
	 */
	public String getBilled() {
		return this.billed;
	}

	/**
	 * Gets the formatted property billed
	 *
	 * @return currency formatted property billed
	 */
	public String getBilledFormatted() {
		return CommonUtils.formatDecimalCurrency(this.billed);
	}

	/**
	 * Setter for property billed.
	 *
	 * @param billed
	 *            New value of property billed.
	 */
	public void setBilled(String billed) {
		this.billed = billed;
	}

	/**
	 * Getter for property adjusted.
	 *
	 * @return Value of property adjusted.
	 */
	public String getAdjusted() {
		return this.adjusted;
	}

	/**
	 * Gets the formatted property adjusted
	 *
	 * @return currency formatted propertu adjusted
	 */
	public String getAdjustedFormatted() {
		String returnString = null;
		Float value = Float.valueOf(this.adjusted);
		if (value.floatValue() == 0.0) {
			// don't return $0.00, just return blank string
			returnString = com.bcbssc.struts.common.Constants.BLANK_STRING;
		} else {
			returnString = CommonUtils.formatDecimalCurrency(this.adjusted);
		}
		return returnString;
	}

	/**
	 * Setter for property adjusted.
	 *
	 * @param adjusted
	 *            New value of property adjusted.
	 */
	public void setAdjusted(String adjusted) {
		this.adjusted = adjusted;
	}

	/**
	 * Getter for property totalPremium.
	 *
	 * @return Value of property totalPremium.
	 */
	public String getTotalPremium() {
		return this.totalPremium;
	}

	/**
	 * Gets the formatted total premium
	 *
	 * @return currency formatted total premium
	 */
	public String getTotalPremiumFormatted() {
		return CommonUtils.formatDecimalCurrency(this.totalPremium);
	}

	/**
	 * Setter for property totalPremium.
	 *
	 * @param totalPremium
	 *            New value of property totalPremium.
	 */
	public void setTotalPremium(String totalPremium) {
		this.totalPremium = totalPremium;
	}

	/**
	 * Getter for property coverageType.
	 *
	 * @return Value of property coverageType.
	 */
	public String getCoverageType() {
		return this.coverageType;
	}

	/**
	 * Setter for property coverageType.
	 *
	 * @param coverageType
	 *            New value of property coverageType.
	 */
	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}
}
