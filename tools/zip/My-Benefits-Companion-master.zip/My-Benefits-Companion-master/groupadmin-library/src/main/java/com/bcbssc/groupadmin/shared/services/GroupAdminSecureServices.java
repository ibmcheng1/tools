/*
 * @(#)GroupAdminSecureServices.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.services;

import java.io.FileNotFoundException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

import javax.naming.NamingException;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;

import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.groupadmin.shared.dto.RegistrationFormDTO;
import com.bcbssc.groupadmin.shared.ldap.GroupAdminLdapUserHandler;
import com.bcbssc.netsys.jndi.MissingPropertyException;
import com.bcbssc.registration.dto.UserDTO;
import com.bcbssc.registration.services.ISecureServices;
import com.bcbssc.struts.common.CommonUtils;

/**
 * Group Administrator Registration Services
 *
 * This class provides the business logic for the shared group administrator
 * secure services.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.1  $
 */
public class GroupAdminSecureServices implements ISecureServices {

	/** log4j logger */
	protected static Logger log = Logger
			.getLogger(GroupAdminSecureServices.class);

	/** the ini file containing service processing parameters */
	protected String iniFile = null;

	/** the ini file containing ssl connection parameters */
	protected String tdsIniFile = null;

	/**
	 * Constructs class, setting the servlet ini files
	 *
	 * @param _iniFile
	 *            the ini file containing service processing parameters
	 * @param _tdsIniFile
	 *            the ini file containing ssl connection parameters
	 */
	public GroupAdminSecureServices(String _iniFile, String _tdsIniFile) {
		this.iniFile = _iniFile;
		this.tdsIniFile = _tdsIniFile;
	}

	/**
	 * Returns an LDAP user handler
	 *
	 * @return the LDAP user handler contructed using the classes ini files
	 */
	protected GroupAdminLdapUserHandler getLdapUserHandler() {
		return new GroupAdminLdapUserHandler(this.iniFile,this.tdsIniFile);
	}

	/**
	 * {@inheritDoc}
	 *
	 * Populates the form DTO based on the ONTCred cookie value
	 */
	public void populateForm(Object dto, UserDTO user)
			throws IllegalAccessException, InvocationTargetException {
		RegistrationFormDTO form = (RegistrationFormDTO) dto;

		GroupAdminUserDTO gauser = (GroupAdminUserDTO) user;

		this.copyProperties(form, gauser);

		// Set the form properties that don't come directly from the directory

		// Confirm E-mail
		form.setConfirmMail(gauser.getMail());

		// Date of Birth elements (month/day/year)
		ArrayList splitDate = CommonUtils.splitString(
				gauser.getDateOfBirth(), "/");
		if (splitDate.size() == 3) {
			form.setDobMonth((String) splitDate.get(0));
			form.setDobDay((String) splitDate.get(1));
			form.setDobYear((String) splitDate.get(2));
		}
	}

	/**
	 * Modifies a user's profile information
	 *
	 * @param dto
	 *            an application-specific form data object
	 * @param user
	 *            the user described by the encrypted cookie
	 * @throws java.lang.IllegalAccessException -
	 *             exceptions thrown by LdapUserHandler
	 * @throws java.lang.reflect.InvocationTargetException
	 *             if an error occurs when copying the form to the user bean.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException
	 *             when any ldap confing property is missed in ini files
	 * @throws javax.naming.NamingException
	 *             when communication exception or ldap operation failure
	 *             scenarios
	 * @throws java.io.FileNotFoundException
	 *             when ini file not found
	 * @return a boolean.
	 */
	public boolean modifyProfile(Object dto, UserDTO user)
			throws IllegalAccessException, InvocationTargetException,
			 FileNotFoundException, NamingException, MissingPropertyException {

		boolean returnBoolean;
		RegistrationFormDTO form = (RegistrationFormDTO) dto;
		GroupAdminUserDTO formuser = new GroupAdminUserDTO();
		GroupAdminLdapUserHandler luh = this.getLdapUserHandler();

		String userID = user.getSamAccountName();

		// Create a user from the form data by copying the beans
		this.copyProperties(formuser, form);

		if ((userID != null)
				&& formuser.getSamAccountName().equals(userID)) {

			// Create a user from the form data by copying the beans
			this.copyProperties(formuser, form);
			luh.updateProfile(formuser);

			// copy the latest profile changes into the UserDTO Bean
			GroupAdminUserDTO gauser = (GroupAdminUserDTO) user;
			this.copyProperties(gauser, form);

			returnBoolean = true;
		} else {
			StringBuffer error = new StringBuffer(256);
			error.append("User described by ONTCred cookie (").append(
					userID);
			error
					.append(") is not the same as user defined in modify profile form (");
			error.append(formuser.getSamAccountName()).append(").");
			GroupAdminSecureServices.log.error(error.toString());
			returnBoolean = false;
		}
		return returnBoolean;
	}

	/**
	 * {@inheritDoc}
	 *
	 * Change the password for the user described by the ONTCred cookie value
	 */
	public boolean changePassword(Object dto, UserDTO user)
			throws 	FileNotFoundException,MissingPropertyException,NamingException {
		RegistrationFormDTO form = (RegistrationFormDTO) dto;
		String newpassword = form.getUnicodePwd();
		String samAccountName = user.getSamAccountName();

		GroupAdminLdapUserHandler luh = this.getLdapUserHandler();

		// The form needs this to display the confirmation
		form.setSamAccountName(samAccountName);

		if (GroupAdminSecureServices.log.isDebugEnabled()) {
			StringBuffer msg = new StringBuffer(128);
			msg.append("Updating password for ").append(samAccountName);
			msg.append(" (password length: ").append(newpassword.length());
			msg.append(").");
			GroupAdminSecureServices.log.debug(msg.toString());
		}

		// Update the password
		if (luh.updatePassword(samAccountName, newpassword)) {
			return true;
		}

		return false;
	}

	/**
	 * Provides a wrapper for BeanUtils.copyProperties that includes exception
	 * logging.
	 *
	 * @param toBean
	 *            the bean to which the properties will be copied.
	 * @param fromBean
	 *            the bean from which the properties will be copied.
	 * @throws IllegalAccessException
	 *             if an error occurs when copying the form to the user bean.
	 * @throws InvocationTargetException
	 *             if an error occurs when copying the form to the user bean.
	 */
	private void copyProperties(Object toBean, Object fromBean)
			throws IllegalAccessException, InvocationTargetException {

		try {
			BeanUtils.copyProperties(toBean, fromBean);
		} catch (InvocationTargetException ite) {
			GroupAdminSecureServices.log.error("Reflection exception:", ite);
			GroupAdminSecureServices.log.error("Root cause:", ite
					.getTargetException());
			throw ite;
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * Gets a user described by a encrypted user cookie
	 */
	public UserDTO getUserFromCookie(String szOntCredCookie) throws Exception {
		GroupAdminLdapUserHandler luh = this.getLdapUserHandler();

		UserDTO user = luh.getUserFromCookie(szOntCredCookie);
		return user;
	}

	/**
	 * {@inheritDoc}
	 *
	 * Gets a user described by the encrypted user cookie and the superuser
	 * cookies.
	 */
	public UserDTO getUserFromCookies(String szOntCredCookie,
			String racfCookie, String suType) throws Exception {

		GroupAdminLdapUserHandler luh = this.getLdapUserHandler();

		UserDTO user = luh.getUserFromCookies(szOntCredCookie, racfCookie,
				suType);
        return user;
		
	}
}
