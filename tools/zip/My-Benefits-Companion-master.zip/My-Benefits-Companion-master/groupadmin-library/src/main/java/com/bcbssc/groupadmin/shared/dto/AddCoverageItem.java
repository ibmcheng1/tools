/*
 * @(#)AddCoverageItem.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.dto;

import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.bcbssc.groupadmin.shared.forms.AddCoverageForm;

/**
 * <p>AddCoverageItem class.</p>
 *
 * @author XR93
 *
 * Implement logic specific to adding coverage
 * @version $Id: $Id
 */
public class AddCoverageItem {

	/** log4j logger */
	private static Logger logger = Logger.getLogger(AddCoverageItem.class);

	/**
	 * apply special rules for accept/decline and protect
	 *
	 * @param insuredDatasource		Insureds Information
	 * @param itemList				Coverages
	 */
	public static void checkSpecialConditions(IInsuredDatasource insuredDatasource, ArrayList<CoverageItem> itemList) {

		boolean userWantsDental = ((AddCoverageForm)insuredDatasource).getDentalCoverage();
		boolean userWantsVision	= ((AddCoverageForm)insuredDatasource).getVisionCoverage();

		CoverageItem item = null;
		int len = itemList.size();

		for(int idx = 0 ; idx < len; idx++ ) {
			item = (CoverageItem) itemList.get(idx);

			// for each coverage check for special circumstances where we would
			// accept of decline coverage for them

			if ( item.getCoverageIsDental() && !userWantsDental && ! item.getCoverageIsVision()) {
				// If the user said no to the dental question, then decline dental coverage
				// must be 1st rule processed - if no to dental then must be declined
				if( logger.isDebugEnabled()) {
					logger.debug("No to dental question: " + item.getCode() + " decline coverage");
				}
				item.setAction(CoverageItem.ACTION_DECLINED);
				item.setActionProtected( true);

			}else if(item.getCoverageIsDentalTax() && !userWantsDental){
				// If the user said no to the vision question, then decline vision coverage
				// must be 1st rule processed - if no to dental then must be declined
				if( logger.isDebugEnabled()) {
					logger.debug("No to dental question: " + item.getCode() + " decline dental tax coverage");
				}
				item.setAction(CoverageItem.ACTION_DECLINED);
				item.setActionProtected( true);
			}else if(item.getCoverageIsVisionTax() && !userWantsVision){
				// If the user said no to the vision question, then decline vision coverage
				// must be 1st rule processed - if no to dental then must be declined
				if( logger.isDebugEnabled()) {
					logger.debug("No to vision question: " + item.getCode() + " decline vision tax coverage");
				}
				item.setAction(CoverageItem.ACTION_DECLINED);
				item.setActionProtected( true);
			}
			else if(item.getCoverageIsVision() && ! userWantsVision){
				// If the user said no to the vision question, then decline vision coverage
				// must be 1st rule processed - if no to dental then must be declined
				if( logger.isDebugEnabled()) {
					logger.debug("No to vision question: " + item.getCode() + " decline coverage");
				}
				item.setAction(CoverageItem.ACTION_DECLINED);
				item.setActionProtected( true);
			}

			else if (!insuredDatasource.getSpouseExists() && item.isCoverageSpouseRelated()) {
				// If the user selected 'No' for the spouse question on the "Add Insured
				// Employee" page, set the action to 'Declined' for all spouse related
				// coverage.
				logger.debug("decline spouse coverage - no spouse " + item.getCode());
				item.setAction(CoverageItem.ACTION_DECLINED);
				item.setActionProtected( true);

			} else if (!item.getWaitingPeriodDay().equals(insuredDatasource.getMinWaitingPeriodDay())) {
				// When there is a mixture of waiting period days, decline all
				// coverage's where the waiting period days is not equal to the
				// smallest value.
				if( logger.isDebugEnabled()) {
					logger.debug("mixed wait period - decline, " + item.getCode() + ", days = " + item.getWaitingPeriodDay());
				}
				item.setAction(CoverageItem.ACTION_DECLINED);
				item.setActionProtected( true);

			} else if (!item.getCoverageIsDental() && ! item.getCoverageIsVision() &&
						(item.getNoEvidenceMaxVolume() == 0) ) {
				// When NO_EVIDENCE_MAX is equal zero (0), decline the coverage.
				// This does not apply to dental
				logger.debug("NEM = 0, decline " + item.getCode());
				item.setAction(CoverageItem.ACTION_DECLINED);
				item.setActionProtected( true);

			} else if (item.getEmployerPercentInsurance() == 100) {
				// If the 'Employer % Insurance' = 1.00, protect the 'Accepted' action.
				// Do not allow the user to decline the coverage.
				logger.debug("100% emp paid, accept " + item.getCode());
				item.setAction(CoverageItem.ACTION_ACCEPTED);
				item.setActionProtected( true);

			} else {
				// no special reason to have the field protected
				item.setActionProtected(false);
			}
		}
	}

}
