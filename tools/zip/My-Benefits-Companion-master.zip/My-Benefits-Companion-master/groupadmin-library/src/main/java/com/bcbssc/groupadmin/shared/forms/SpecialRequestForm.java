/*
 * @(#)SpecialRequestForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.forms;

/**
 * GroupAdmin IDCard Form
 *
 * This bean provides data transport and validation for the IDCard form.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class SpecialRequestForm extends InsuredSearchForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final String DEFAULT_IDCARD_OPTION = "NYDN";

	/**
	 * Holds value of property requestOption.
	 */
	private String requestOption = SpecialRequestForm.DEFAULT_IDCARD_OPTION;

	/**
	 * Holds value of property requestDentalCard.
	 */

	private String requestDentalCard;

	/**
	 * Holds value of property requestDentalCardAndCert.
	 */

	private String requestDentalCardAndCert;

	/**
	 * Holds value of property requestVision.
	 */

	private String requestVision;

	/**
	 * Holds value of property requestOtherCert.
	 */

	private String requestOtherCert;

	/**
	 * Holds value of property multipleSelected.
	 */

	private String multipleSelected = "N";

	/**
	 * Holds value of property dentalCardMessage.
	 */

	private String dentalCardMessage;

	/**
	 * Holds value of property dentalCardAndCertMessage.
	 */

	private String dentalCardAndCertMessage;

	/**
	 * Holds value of property otherCertMessage.
	 */

	private String otherCertMessage;

	/**
	 * Holds value of property visionMessage.
	 */

	private String visionMessage;

	/**
	 * Holds value of property optionsCount.
	 */

	private int optionsCount;

	/**
	 * Getter for property requestOption.
	 *
	 * @return Value of property requestOption.
	 */
	public String getRequestOption() {
		return this.requestOption;
	}

	/**
	 * Setter for property requestOption.
	 *
	 * @param requestOption
	 *            New value of property requestOption.
	 */
	public void setRequestOption(String requestOption) {
		this.requestOption = requestOption;
	}

	/**
	 * Getter for property requestDentalCard.
	 *
	 * @return Value of property requestDentalCard.
	 */
	public String getRequestDentalCard() {
		return this.requestDentalCard;
	}

	/**
	 * Setter for property requestDentalCard.
	 *
	 * @param requestDentalCard
	 *            New value of property requestDentalCard.
	 */
	public void setRequestDentalCard(String requestDentalCard) {
		this.requestDentalCard = requestDentalCard;
	}

	/**
	 * Getter for property requestDentalCardAndCert.
	 *
	 * @return Value of property requestDentalCardAndCert.
	 */
	public String getRequestDentalCardAndCert() {
		return this.requestDentalCardAndCert;
	}

	/**
	 * Setter for property requestDentalCardAndCert.
	 *
	 * @param requestDentalCardAndCert
	 *            New value of property requestDentalCardAndCert.
	 */
	public void setRequestDentalCardAndCert(String requestDentalCardAndCert) {
		this.requestDentalCardAndCert = requestDentalCardAndCert;
	}

	/**
	 * Getter for property requestOtherCert.
	 *
	 * @return Value of property requestOtherCert.
	 */
	public String getRequestOtherCert() {
		return this.requestOtherCert;
	}

	/**
	 * Setter for property requestOtherCert.
	 *
	 * @param requestOtherCert
	 *            New value of property requestOtherCert.
	 */
	public void setRequestOtherCert(String requestOtherCert) {
		this.requestOtherCert = requestOtherCert;
	}

	/**
	 * Getter for property requestVision.
	 *
	 * @return Value of property requestVision.
	 */
	public String getRequestVision() {
		return this.requestVision;
	}

	/**
	 * Setter for property requestVision.
	 *
	 * @param requestVision
	 *            New value of property requestVision.
	 */
	public void setRequestVision(String requestVision) {
		this.requestVision = requestVision;
	}

	/**
	 * Getter for property multipleSelected.
	 *
	 * @return Value of property multipleSelected.
	 */
	public String getMultipleSelected() {
		if (this.optionsCount > 1) {
			this.multipleSelected = "Y";
		}
		return this.multipleSelected;
	}

	/**
	 * Setter for property multipleSelected.
	 *
	 * @param multipleSelected
	 *            New value of property multipleSelected.
	 */
	public void setMultipleSelected(String multipleSelected) {
		this.multipleSelected = multipleSelected;
	}

	/**
	 * Getter for property dentalCardMessage.
	 *
	 * @return Value of property dentalCardMessage.
	 */
	public String getDentalCardMessage() {
		return this.dentalCardMessage;
	}

	/**
	 * Setter for property dentalCardMessage.
	 *
	 * @param dentalCardMessage
	 *            New value of property dentalCardMessage.
	 */
	public void setDentalCardMessage(String dentalCardMessage) {
		this.dentalCardMessage = dentalCardMessage;
	}

	/**
	 * Getter for property dentalCardAndCertMessage.
	 *
	 * @return Value of property dentalCardAndCertMessage.
	 */
	public String getDentalCardAndCertMessage() {
		return this.dentalCardAndCertMessage;
	}

	/**
	 * Setter for property dentalCardAndCertMessage.
	 *
	 * @param dentalCardAndCertMessage
	 *            New value of property dentalCardAndCertMessage.
	 */
	public void setDentalCardAndCertMessage(String dentalCardAndCertMessage) {
		this.dentalCardAndCertMessage = dentalCardAndCertMessage;
	}

	/**
	 * Getter for property otherCertMessage.
	 *
	 * @return Value of property otherCertMessage.
	 */
	public String getOtherCertMessage() {
		return this.otherCertMessage;
	}

	/**
	 * Setter for property otherCertMessage.
	 *
	 * @param otherCertMessage
	 *            New value of property otherCertMessage.
	 */
	public void setOtherCertMessage(String otherCertMessage) {
		this.otherCertMessage = otherCertMessage;
	}

	/**
	 * Getter for property visionMessage.
	 *
	 * @return Value of property visionMessage.
	 */
	public String getVisionMessage() {
		return this.visionMessage;
	}

	/**
	 * Setter for property visionMessage.
	 *
	 * @param visionMessage
	 *            New value of property visionMessage.
	 */
	public void setVisionMessage(String visionMessage) {
		this.visionMessage = visionMessage;
	}

	/**
	 * Getter for property optionsCount.
	 *
	 * @return Value of property optionsCount.
	 */
	public int getOptionsCount() {
		return this.optionsCount;
	}

	/**
	 * Setter for property optionsCount.
	 *
	 * @param optionsCount
	 *            New value of property optionsCount.
	 */
	public void setOptionsCount(int optionsCount) {
		this.optionsCount = optionsCount;
	}

}
