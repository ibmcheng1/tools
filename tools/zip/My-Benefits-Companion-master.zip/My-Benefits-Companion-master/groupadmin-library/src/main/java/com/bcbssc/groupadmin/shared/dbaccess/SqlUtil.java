/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/SqlUtil.java_v  $
 * $Workfile:   SqlUtil.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:28  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/SqlUtil.java_v  $
 * 
 * 	  Rev 1.4 	Feb 06 2015 09:07:00   MF36
 * changed DB connection for WebSphere environment.
 *    Rev 1.0   Jun 26 2009 15:14:28   EN80
 * Initial revision.
 * 
 *    Rev 1.3   Apr 28 2009 10:18:18   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.2   Jan 26 2005 10:03:16   rdq70
 * BlueHammur changes.
 *
 *    Rev 1.1   Jan 26 2005 09:28:24   rdq70
 * Cleaned up imports.
 *
 *    Rev 1.0   Sep 12 2004 15:17:26   rxg97
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.dbaccess;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.springframework.beans.BeansException;

/**
 * Utility class to read database configuration parameters from an INI file and
 * create database connections.
 *
 * This class was originally written by D. Allen for Enrollment.
 *
 * @author rxg97 (Jonathan Egger)
 * @version $Id: $Id
 */
public class SqlUtil {
	
	/**
	 * Disallows instantiation.
	 */
	private SqlUtil() {
		// Do nothing.
	}
	
	/**
	 * Creates a new database connection based on the configuration parameters.
	 * <code>readConfig()</code> must be called once before calling this
	 * method.
	 *
	 * @return the newly created database connection.
	 * @throws BeansException if the jdbc.datasource bean cannot be found in the XML file.
	 * @throws java.sql.SQLException
	 *             if an error occurs opening the connection.
	 * @throws javax.naming.NamingException if any.
	 */
	public static final Connection getConnection() throws SQLException, NamingException{
		
		Context initCon = new InitialContext(); 
		DataSource ds = (DataSource) initCon.lookup("java:comp/env/jdbc/db");

		return ((ds !=null)? ds.getConnection() : null);
	}
	
}
