/*
 *
 * @(#)StartUpServlet.java
 *
 * Copyright Notice 2004 Blue Cross Blue Shield.
 * All rights reserved.
 *
 * This material is the confidential, proprietary and trade secret product
 * of Bluecross Blueshield Of South Carolina. Any unauthorized use,
 * reproduction or transfer of these materials is strictly prohibited.
 *
 * This Servlet is responsible for retrieving the configuration information from
 * the INI files (puts it in the ServletContext)
 * Initializes log4j api for logging.
 */
package com.bcbssc.groupadmin.shared.servlets;

import com.bcbssc.registration.servlets.AbstractStartUpServlet;

import javax.servlet.ServletException;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import com.bcbssc.registration.tds.LdapConfig;


/**
 * Initialization or Startup Servlet. Startup Servlets are generally configured
 * and launched at the Web Container level and are executed on WebServer start
 * up. Extend the defined base abstract startup servlet class and add the
 * initialization of the log4j logging api using the predefined preprocess()
 * hook.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class StartUpServlet extends AbstractStartUpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8363536197827184586L;

	/**
	 * Initializes log4j logging api
	 *
	 * @exception ServletException -
	 *                if the request for the TRACE cannot be handled
	 * @throws javax.servlet.ServletException if any.
	 */
	protected void preprocess() throws ServletException {
		try {
			
			/*Project:CX1730
			 * For view bills we call the ImagegatewayRetriever web service and we use websphere thin client jar as the runtime. When viewing 
			 * the bills Websphere thinn client is loading the SSL related files in the class loaded and that is preventing loading the SunOne 
			 * SSL files when create profile or change password functions are called. To prevent that while server startup we are loading the 
			 * SunOne SSL files explicitly by calling the below method.
			*/
			try{
				String tdsIniFile = this.getServletConfig().getInitParameter(
				"TDS_INI_FILE");
			    LdapConfig.loadSecureLdapConfig(tdsIniFile);  
			}catch(Exception exp){
				
				exp.printStackTrace();
			}
			
			
			
			String log4jPath = this.getServletConfig().getInitParameter(
					"LOG4J_PATH");

			String logPropertyFileResource = log4jPath
					+ com.bcbssc.registration.common.Constants.LOG4J_PROPERTIES_FILENAME;

			DOMConfigurator.configure(logPropertyFileResource);

			this.log = Logger.getLogger(StartUpServlet.class.getName());
		} catch (Exception eException) {
			// Throw an Exception indicating that LOG4J was not correctly
			// initialized.
			// If the Property configurator fails use the BasicConfigurator this
			// will log to the Console
			BasicConfigurator.configure();
			this.log = Logger.getLogger(StartUpServlet.class);

			String strErrorMessage = "Error initializing log4j. Exception: "
					+ eException.toString();

			this.log.error(strErrorMessage, eException);
			throw new ServletException(strErrorMessage);
		}
		this.log.info("Log4j has been initialized.");
	}

	/*
	 * Clean up when the Webserver releases this object
	 */
	/**
	 * <p>destroy.</p>
	 */
	public void destroy() {
		this.log.info(new StringBuffer(64).append(
				"destroy() method being called on <<<").append(
				this.getClass().getName()).append(">>> Servlet."));
	}
}
