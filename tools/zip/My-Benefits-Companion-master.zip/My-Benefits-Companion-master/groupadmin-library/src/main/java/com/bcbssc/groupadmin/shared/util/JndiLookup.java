/**THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2015 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.groupadmin.shared.util;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;

/**
 * Unified location for JNDI lookups.
 *
 * @author mf36
 * @version $Id: $Id
 */
public class JndiLookup {
    private static final Logger log = Logger.getLogger(JndiLookup.class);
    private final String scope = "cell/persistent/";
    // Unit/System=dcsds56so10000kbqf52m4vj5_1q6l
    // Qual/Prod=dcsqxh2n700000s5js8e790k5_9g8d
    public final String mbcWebTrendsId = "MBC.WEBTRENDS.DCS_ID";
    public final String mbcGoogleTagManager = "MBC.GOOGLE.TAGMANAGER";
    //MBC.WEBTRENDS.DOMAIN=ssdcext.bcbssc.com
    public final String mbdWebTrendsDomain = "MBC.WEBTRENDS.DOMAIN";
    
    private HttpSession session = null;

    /**
     * <p>Constructor for JndiLookup.</p>
     *
     * @param session a {@link javax.servlet.http.HttpSession} object.
     */
    public JndiLookup(HttpSession session){
        this.session = session;
    }

    /**
     * Takes a JNDI name and does a lookup on it. Will check and populate the session with the values found. This cuts
     * down on multiple JNDI lookup hits.
     *
     * @param variable a {@link java.lang.String} object.
     * @return a {@link java.lang.String} object.
     */
    public String lookup(String variable){
        if (log.isDebugEnabled()) {
            log.debug("JndiLookup:lookup:"+variable+" ENTRY");
        }
        //Find JNDI value in session.  If not in session, continue with lookup
        String sessionVar = (String) session.getAttribute(variable);
        if(StringUtils.isNotEmpty(sessionVar)){
            if (log.isDebugEnabled()) {
                log.debug("JndiLookup:sessionVar:Return:"+sessionVar);
            }
            return sessionVar;
        }
        try{
            //Per best practice conventions
            //We want to lookup everything at CELL scope.
            String scopedVar = scope+variable;
            if (log.isDebugEnabled()) {
                log.debug("JndiLookup:lookup:scopedVar:"+scopedVar);
            }
            Context context = new InitialContext();
            String result = (String) context.lookup(scopedVar);
            //Set value into session.
            session.setAttribute(variable, result);
            if (log.isDebugEnabled()) {
                log.debug("JndiLookup:lookup Var:Return " + scopedVar + ":" + result);
            }
            return result;
        }catch(NamingException e){
            log.error("JndiLookup:lookup NamingException occurred on lookup of"+variable, e);
            return StringUtils.EMPTY;
        }
    }
}
