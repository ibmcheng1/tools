/*
 * @(#)SuperUserAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.actions;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.util.LabelValueBean;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.groupadmin.shared.dto.SuperUserDTO;
import com.bcbssc.groupadmin.shared.forms.SuperUserForm;
import com.bcbssc.groupadmin.shared.services.GroupAdminRegistrationServices;
import com.bcbssc.groupadmin.shared.services.SuperUserServices;
import com.bcbssc.struts.action.SimpleDispatchAction;

/**
 * Group Admin Super User Action
 *
 * This class provides control processing for super user logon.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.1  $
 */
public class SuperUserAction extends SimpleDispatchAction {

	/** log4j logger */
	private static final Logger log = Logger.getLogger(SuperUserAction.class
			.getName());

	/** Forward for user list page */
	private static final String USER_LIST_FORWARD = "list";

	/**
	 * Displays the user selection form.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward displayUserSelection(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
     	
		SuperUserForm superUserForm = (SuperUserForm) form;
	    String userClass = request.getParameter("userClass");
		superUserForm.setUserClass(userClass);
		request.setAttribute("superUserForm", superUserForm);
		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}

	/**
	 * Processes user selection.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward findUser(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		SuperUserForm superUserForm = (SuperUserForm) form;
		String iniFile = CommonUtils.getIniFile(this.getServlet());
		String tdsIniFile = CommonUtils.getTDSIniFile(this.getServlet());
		String natliniFile = CommonUtils.getNationalIniFile(this.getServlet());
		String natlsslIniFile = CommonUtils.getNationalSslIniFile(this
				.getServlet());
		String applicationId = superUserForm.getAppId();
		

		if ("NATLGRPAD".equalsIgnoreCase(applicationId)) {
			iniFile = natliniFile;
			tdsIniFile = natlsslIniFile;
		}

		SuperUserServices services = new SuperUserServices(iniFile, tdsIniFile);
		SuperUserDTO superUserDTO = new SuperUserDTO();
		BeanUtils.copyProperties(superUserDTO, superUserForm);
		List<LabelValueBean> userList = services.getMatchingUsers(superUserDTO);

		ActionForward forward = null;
		SuperUserAction.log.debug("function type = "
				+ superUserForm.getFunctionType());
		if (userList.size() == 0) {
			String funcType = (superUserForm.getFunctionType()).toUpperCase();
			SuperUserAction.log.debug("FunctionType :" + funcType);
			if ((funcType.indexOf("PRIVBUS") != -1)
					|| (funcType.indexOf("HDESK") != -1)) {
				forward = mapping.findForward(Constants.FORWARD_NOTFOUND);
			} else {
				// Add global error
				this.addGlobalRequestMessage(request,
						"errors.superuser.no.matches");
				forward = mapping.getInputForward();

			}
		} else if (userList.size() > 1) {
			request.setAttribute("userList", userList);
			forward = mapping.findForward(SuperUserAction.USER_LIST_FORWARD);
		} else {
			LabelValueBean userSelectBean = (LabelValueBean) userList.get(0);
			superUserForm.setUserName(userSelectBean.getValue());
			return this.selectUser(mapping, form, request, response);
		}
		return forward;
	}

	/**
	 * Processes user selection.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward selectUser(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		ActionForward forward = null;
		SuperUserForm superUserForm = (SuperUserForm) form;
		String iniFile = CommonUtils.getIniFile(this.getServlet());
		String tdsIniFile = CommonUtils.getTDSIniFile(this.getServlet());

		String natliniFile = CommonUtils.getNationalIniFile(this.getServlet());
		String natlsslIniFile = CommonUtils.getNationalSslIniFile(this
				.getServlet());
		String applicationId = superUserForm.getAppId();


		if ("NATLGRPAD".equalsIgnoreCase(applicationId)) {
			iniFile = natliniFile;
			tdsIniFile = natlsslIniFile;
		}

		SuperUserServices services = new SuperUserServices(iniFile, tdsIniFile);

		SuperUserDTO superUserDTO = new SuperUserDTO();
		BeanUtils.copyProperties(superUserDTO, superUserForm);

		int statusCode = services.verifyUserStatus(superUserDTO);
		String funcType = (superUserForm.getFunctionType()).toUpperCase();

		if (statusCode == Constants.SERVICE_VALID) {
			GroupAdminRegistrationServices registrationServices = new GroupAdminRegistrationServices(
					iniFile, tdsIniFile);

			registrationServices.setEncryptedCookie(superUserDTO.getUserName(),
					request, response);
			
			//setting RACF cookie
			registrationServices.setEncryptedRACFCookie(request.getParameter("racfId"), request, response);
			//setting super user type cookie
			registrationServices.setCookie(Constants.COOKIE_SUPERUSER_TYPE, request.getParameter("userClass"), request, response);
			
			forward = mapping
					.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
		} else {
			if ((funcType.indexOf("PRIVBUS") != -1)
					|| (funcType.indexOf("HDESK") != -1)) {
				forward = mapping.findForward(Constants.FORWARD_NOTFOUND);
			} else {
				this.addGlobalRequestMessage(request, "errors.invalid");
				List<LabelValueBean> userList = services.getMatchingUsers(superUserDTO);
				request.setAttribute("userList", userList);
				forward = mapping.getInputForward();
			}
		}

		return forward;
	}

	/**
	 * Processes user cancel.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward cancel(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		SuperUserForm superUserForm = (SuperUserForm) form;

		SuperUserAction.log
				.debug("user type = " + superUserForm.getUserClass());
		return mapping.findForward(superUserForm.getUserClass());
	}

	/**
	 * Forwards to the welcome page
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward forwardWelcome(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		HttpSession session = request.getSession();
		session
				.removeAttribute(com.bcbssc.registration.common.Constants.USER_DTO);

		ActionForward actionForward = mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_WELCOME);
		StringBuffer sbCurrentPath = new StringBuffer(actionForward.getPath());
		sbCurrentPath.append("?ts=").append(System.currentTimeMillis());

		if (SuperUserAction.log.isDebugEnabled()) {
			SuperUserAction.log
					.debug("************ forwardWelcome The new path is "
							+ sbCurrentPath.toString());
		}

		ActionForward returnForward = new ActionForward();
		BeanUtils.copyProperties(returnForward, actionForward);
		returnForward.setPath(sbCurrentPath.toString());

		// actionForward.setPath(sbCurrentPath.toString());
		return returnForward;
	}

}
