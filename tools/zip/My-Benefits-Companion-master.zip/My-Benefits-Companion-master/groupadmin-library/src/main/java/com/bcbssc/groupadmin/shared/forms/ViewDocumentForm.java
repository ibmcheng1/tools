/*
 * @(#)ViewBillForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.forms;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.bcbssc.struts.common.FormDate;

/**
 * <p>ViewDocumentForm class.</p>
 *
 * @author XR93
 *
 * Container for data needed to view a bill
 * @version $Id: $Id
 */
public class ViewDocumentForm extends InsuredSearchForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// user who is viewing the bill
	private String user;

	// url of image server
	private String imageServer;

	// key
	private String groupNumber;

	// date for search
	private String effectiveDate;

	// date for search formatted for od390 call
	private String formattedEffectiveDate;

	// date for search formatted for od390 call
	private String formattedFromDate;
	
	//Todate add for CX1730
	private String formattedToDate;
	
	private String coverateCode;
	
	private String reportId;
	
	private String folderName;
	
	private String dentalCardReportId;
	
	private String alternateID;

	/**
	 * <p>Constructor for ViewDocumentForm.</p>
	 */
	public ViewDocumentForm() {
		super();
	}

	/**
	 * <p>Getter for the field <code>groupNumber</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getGroupNumber() {
		return this.groupNumber;
	}

	/** {@inheritDoc} */
	public void setGroupNumber(String string) {
		this.groupNumber = string;
	}

	/**
	 * <p>Getter for the field <code>effectiveDate</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getEffectiveDate() {
		return this.effectiveDate;
	}

	
	/**
	 * <p>Getter for the field <code>formattedToDate</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getFormattedToDate() {
		
		Calendar toDate = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		this.formattedToDate = formatter.format(toDate.getTime());
		return this.formattedToDate;
	}
	
	
	
	
	
	/**
	 * date formatted as yyyy-mm-yy
	 *
	 * @return Selected Bill Date formatted for OD390
	 */
	public String getFormattedEffectiveDate() {
		return this.formattedEffectiveDate;
	}

	/**
	 * date formatted as yyyy-mm-yy
	 *
	 * @return From Date for search formatted for OD390
	 */
	public String getFormattedFromDate() {
	 return this.formattedFromDate;
	}
	
	/**
	 * <p>Setter for the field <code>formattedFromDate</code>.</p>
	 *
	 * @param fromDate a {@link java.lang.String} object.
	 */
	public void setFormattedFromDate(String fromDate) {
		this.formattedFromDate =fromDate;
	}

	/**
	 * <p>Setter for the field <code>effectiveDate</code>.</p>
	 *
	 * @param string a {@link java.lang.String} object.
	 */
	public void setEffectiveDate(String string) {
		this.effectiveDate = string;

		// and reformat
		FormDate dt = FormDate.blank();
		dt.parse(this.effectiveDate);

		// reformat for image viewinf servlet
		StringBuffer retVal = new StringBuffer(12);
		retVal.append(dt.getYear()).append("-");
		retVal.append(dt.getMonth()).append("-");
		retVal.append(dt.getDay());

		// save formatted date
		this.formattedEffectiveDate = retVal.toString();

		// figure a from date
		Calendar fromDate = Calendar.getInstance();
		fromDate.set(Integer.parseInt(dt.getYear()), Integer.parseInt(dt
				.getMonth()) - 1, Integer.parseInt(dt.getDay()));

		// subtract 1 month to determine a from date
		fromDate.add(Calendar.YEAR, -1);

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		this.formattedFromDate = formatter.format(fromDate.getTime());
	}

	/**
	 * <p>Getter for the field <code>user</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getUser() {
		return this.user;
	}

	/**
	 * <p>Setter for the field <code>user</code>.</p>
	 *
	 * @param string a {@link java.lang.String} object.
	 */
	public void setUser(String string) {
		this.user = string;
	}

	/**
	 * <p>Getter for the field <code>imageServer</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getImageServer() {
		return this.imageServer;
	}

	/**
	 * <p>Setter for the field <code>imageServer</code>.</p>
	 *
	 * @param string a {@link java.lang.String} object.
	 */
	public void setImageServer(String string) {
		this.imageServer = string;
	}
	
	
	/**
	 * <p>setCoverageCode.</p>
	 *
	 * @param cvgCode a {@link java.lang.String} object.
	 */
	public void setCoverageCode(String cvgCode){
		
		this.coverateCode = cvgCode;
		
	}
	
	/**
	 * <p>getCoverageCode.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getCoverageCode(){
		
		return this.coverateCode;
	}
	
	
	/**
	 * <p>Setter for the field <code>reportId</code>.</p>
	 *
	 * @param rptId a {@link java.lang.String} object.
	 */
	public void setReportId(String rptId){
		this.reportId = rptId;
	}
	
	/**
	 * <p>Getter for the field <code>reportId</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getReportId(){
		return this.reportId;
	}
	
	
	/**
	 * <p>Setter for the field <code>folderName</code>.</p>
	 *
	 * @param fName a {@link java.lang.String} object.
	 */
	public void setFolderName(String fName){
		this.folderName = fName;
	}
	
	/**
	 * <p>Getter for the field <code>folderName</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getFolderName(){
		return this.folderName;
	}
	
	/**
	 * <p>Setter for the field <code>dentalCardReportId</code>.</p>
	 *
	 * @param dentalCardReportId a {@link java.lang.String} object.
	 */
	public void setDentalCardReportId(String dentalCardReportId){
		
		this.dentalCardReportId = dentalCardReportId;
	}
	
	/**
	 * <p>Getter for the field <code>dentalCardReportId</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getDentalCardReportId(){
		
		return this.dentalCardReportId;
	}
	
	
	/**
	 * <p>Getter for the field <code>alternateID</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getAlternateID(){
	
	         return this.alternateID;
	}
	
	/** {@inheritDoc} */
	public void setAlternateID(String altID){
	
		this.alternateID = altID;
	}
	
	/**
	 * convenience method to display container data
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String toString() {
		StringBuffer s = new StringBuffer(100);
		s.append("GroupNumber ").append(this.groupNumber).append(",");
		s.append("       reportId ").append(this.reportId);
		s.append("       this.alternateID ").append(this.alternateID);
		return s.toString();
	}

}
