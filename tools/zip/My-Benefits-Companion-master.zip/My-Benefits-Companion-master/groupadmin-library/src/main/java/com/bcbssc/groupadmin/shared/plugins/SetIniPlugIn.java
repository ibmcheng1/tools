/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2003 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * SetIniPlugIn.java
 *
 * Created on November 6, 2004, 10:35 AM
 *
 */

package com.bcbssc.groupadmin.shared.plugins;

import org.apache.log4j.Logger;
import org.apache.struts.action.PlugIn;

import com.bcbssc.groupadmin.shared.common.Constants;

/**
 * Sets the iniFile names, specified in the struts-config.xml file, in the
 * Servlet Context.
 */
public class SetIniPlugIn implements PlugIn {

	/** log4j logger */
	protected static Logger log = Logger.getLogger(SetIniPlugIn.class);

	/** Name of the application log file */
	private String iniFile = com.bcbssc.struts.common.Constants.BLANK_STRING;

	
	/** Name of the application GCOM log file */
	private String gcomIniFile = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** Name of the application GCOM log file */
	private String nationalIniFile = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** Name of the application GCOM log file */
	private String nationalSslIniFile = com.bcbssc.struts.common.Constants.BLANK_STRING;

	private String tdsIniFile = com.bcbssc.struts.common.Constants.BLANK_STRING;
	
	private String tdsSuperUserIniFile = com.bcbssc.struts.common.Constants.BLANK_STRING;

	
	

	/**
	 * Sets the name of the TDS.ini file which has secure and non secure ldap connection parameters
	 *
	 * @param tdsIniFile the tdsIniFile to set
	 */
	public void setTdsIniFile(String tdsIniFile) {
		this.tdsIniFile = tdsIniFile;
	}

	
	/**
	 * <p>Setter for the field <code>tdsSuperUserIniFile</code>.</p>
	 *
	 * @param tdsSuperUserIniFile a {@link java.lang.String} object.
	 */
	public void setTdsSuperUserIniFile(String tdsSuperUserIniFile) {
		this.tdsSuperUserIniFile = tdsSuperUserIniFile;
	}
	/**
	 * Sets the name of the application log file
	 *
	 * @param value
	 *            name of the application log file
	 */
	public void setIniFile(String value) {
		this.iniFile = value;
	}

	

	/**
	 * Sets the name of the application log file
	 *
	 * @param value
	 *            name of the application log file
	 */
	public void setNationalIniFile(String value) {
		this.nationalIniFile = value;
	}

	/**
	 * Sets the name of the application SSL log file
	 *
	 * @param value
	 *            name of the application SSL log file
	 */
	public void setNationalSslIniFile(String value) {
		this.nationalSslIniFile = value;
	}

	/**
	 * Sets the name of the application GCOM log file
	 *
	 * @param value
	 *            name of the application GCOM log file
	 */
	public void setGcomIniFile(String value) {
		this.gcomIniFile = value;
	}

	
	/**
	 * {@inheritDoc}
	 *
	 * Performs the plug-in initialization by setting the names of the
	 * application log files in the servlet context.
	 */
	public void init(org.apache.struts.action.ActionServlet actionServlet,
			org.apache.struts.config.ModuleConfig moduleConfig) {
		actionServlet.getServletContext().setAttribute(
				Constants.INIFILE_PARAMETER_NAME, this.iniFile);
		actionServlet.getServletContext().setAttribute(
				Constants.GCOM_INI_PARAMETER_NAME, this.gcomIniFile);
		actionServlet.getServletContext().setAttribute(
				Constants.NATL_INI_PARAMETER_NAME, this.nationalIniFile);
		actionServlet.getServletContext().setAttribute(
				Constants.NATL_SSL_INI_PARAMETER_NAME, this.nationalSslIniFile);
		
		actionServlet.getServletContext().setAttribute(
				Constants.TDS_INIFILE_PARAMETER_NAME, this.tdsIniFile);
		
		actionServlet.getServletContext().setAttribute(
				Constants.TDS_SU_INIFILE_PARAMETER_NAME, this.tdsSuperUserIniFile);
		
	}

	/**
	 * Interface-required method. Since we didn't create any resources, there is
	 * nothing to do here.
	 */
	public void destroy() {
		// do nothing
	}
}
