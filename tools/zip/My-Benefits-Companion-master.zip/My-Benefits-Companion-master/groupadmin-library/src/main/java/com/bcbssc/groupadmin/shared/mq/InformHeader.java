/*
 * 
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * ClosedInformHeader.java
 * 
 * Created on Feb 11, 2005
 *
 */
package com.bcbssc.groupadmin.shared.mq;

import java.util.Date;

/**
 * <p>InformHeader class.</p>
 *
 * @author XR93
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 * @version $Id: $Id
 */
public class InformHeader extends com.bcbssc.netsys.inform.InformHeader {

	private String requestCode;

	/**
	 * <p>Constructor for InformHeader.</p>
	 */
	public InformHeader() {
		super();
	}

	/**
	 * <p>Constructor for InformHeader.</p>
	 *
	 * @param arg0 a {@link java.util.Date} object.
	 */
	public InformHeader(Date arg0) {
		super(arg0);
	}

	/**
	 * <p>Getter for the field <code>requestCode</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getRequestCode() {
		return this.requestCode;
	}

	/**
	 * <p>Setter for the field <code>requestCode</code>.</p>
	 *
	 * @param string a {@link java.lang.String} object.
	 */
	public void setRequestCode(String string) {
		this.requestCode = string;
	}

}
