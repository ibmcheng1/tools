/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2013 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * GroupBillsDateComparator.java
 * 
 */



package com.bcbssc.groupadmin.shared.common;

import java.util.Comparator;
import com.bcbssc.commapi.model.documentarchive.GroupAdminBill;
import org.apache.log4j.Logger;

/**
 * <p>GroupBillsDateComparator class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class GroupBillsDateComparator implements Comparator {

	/** The log4j logger for this class */
	private static Logger log = Logger
			.getLogger(GroupBillsDateComparator.class);

	/**
	 * Creates a new instance of GroupBillsDateComparator
	 */
	public GroupBillsDateComparator() {
		if (GroupBillsDateComparator.log.isDebugEnabled()) {
			GroupBillsDateComparator.log
					.debug("Created GroupBillsDateComparator object.");
		}
	}

	/** {@inheritDoc} */
	public int compare(Object gaBillOne, Object gaBillTwo) {
		GroupAdminBill billOne = (GroupAdminBill) gaBillOne;
		GroupAdminBill billTwo = (GroupAdminBill) gaBillTwo;

		return (billOne.getPostingDate().compareTo(billTwo.getPostingDate()));

	}
}
