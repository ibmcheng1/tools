/*
 * @(#)CoverageItemList.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.dto;

import com.bcbssc.struts.common.DateBean;

import java.util.ArrayList;
import java.util.Calendar;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * GroupAdmin Coverage Item List
 *
 * This class represents a strictly ordered list of coverage items.
 *
 * @author Jonathan Egger
 * @version $Revision: 1.0 $
 */
public class CoverageItemList extends StrictlyOrderedArrayList {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1841195750265174936L;

	/** log4j logger */
	private static Logger logger = Logger.getLogger(Dependent.class);

	/* Holds the datasource that provides info about the insured */
	private IInsuredDatasource insuredDatasource;

	/* The calculated minimum waiting period day value */
	private String minWaitingPeriodDay;

	/* True, if mixed waitingPeriods exist */
	private boolean mixedWaitingPeriods = false;

	/* Error message property used for mixed waiting periods */
	/** Constant <code>ERROR_MIXED_WAITING_PERIODS="errors.waiting.periods"</code> */
	public static final String ERROR_MIXED_WAITING_PERIODS = "errors.waiting.periods";

	/**
	 * Creates a blank object of the correct class for the specific list.
	 *
	 * @return a new blank object
	 */
	protected Object createArrayObject() {
		return new CoverageItem(this.insuredDatasource);
	}

	/**
	 * Constructor; creates an empty CoverageItemList
	 *
	 * @param insuredDatasource a {@link com.bcbssc.groupadmin.shared.dto.IInsuredDatasource} object.
	 */
	public CoverageItemList(IInsuredDatasource insuredDatasource) {
		super();
		this.insuredDatasource = insuredDatasource;
	}

	/**
	 * Constructor; creates a CoverageItemList with data
	 *
	 * @param insuredDatasource a {@link com.bcbssc.groupadmin.shared.dto.IInsuredDatasource} object.
	 * @param list a {@link java.util.ArrayList} object.
	 */
	public CoverageItemList(IInsuredDatasource insuredDatasource, ArrayList list) {
		super(list);
		this.insuredDatasource = insuredDatasource;
	}

	/**
	 * Gets a coverage item from the CoverageItemList, creating intermediate
	 * objects if needed
	 *
	 * @param index
	 *            index of the item to get
	 * @return item at the specified index
	 */
	public CoverageItem getCoverageItem(int index) {
		return (CoverageItem) super.get(index);
	}

	/**
	 * Gets a the first effective date in the coverage item list
	 *
	 * @return first effective date
	 */
	public DateBean getFirstEffectiveDate() {
		final DateBean retVal;
		if (CoverageItemList.logger.isDebugEnabled()) {
			CoverageItemList.logger
					.debug("Start of getFirstEffectiveDate() in CoverageItemList.java");
		}

		if ((this.insuredDatasource.isInsuredPageUpdated()
				|| this.insuredDatasource.isCoveragePageUpdated() || this.insuredDatasource
				.isDependentPageUpdated())
				&& !com.bcbssc.struts.common.Constants.BLANK_STRING
						.equals(this.insuredDatasource
								.getChangeEffectiveDateAsDateBean().getYear())) {

			retVal = this.insuredDatasource.getChangeEffectiveDateAsDateBean();

			if (CoverageItemList.logger.isDebugEnabled()) {
				CoverageItemList.logger.debug("In the if, retVal is"
						+ retVal.toString());
			}
		} else {
			ArrayList effectiveDates = new ArrayList();

			for (int i = 0; i < this.size(); i++) {
				CoverageItem item = (CoverageItem) this.get(i);
				effectiveDates.add(item.getEffectiveDate());

				if (CoverageItemList.logger.isDebugEnabled()) {
					CoverageItemList.logger.debug("In the for "
							+ item.getEffectiveDate());
				}
			}

			retVal = this.getFirstDate(effectiveDates);

			if (CoverageItemList.logger.isDebugEnabled()) {
				CoverageItemList.logger.debug("In the else, retVal is"
						+ retVal.toString());
			}
		}

		if (CoverageItemList.logger.isDebugEnabled()) {
			CoverageItemList.logger
					.debug("End of getFirstEffectiveDate() in CoverageItemList.java");
		}

		return retVal;
	}

	/**
	 * Gets the first effective date in a date list
	 * 
	 * @return first date from the list
	 */
	private DateBean getFirstDate(ArrayList dateBeanList) {
		DateBean returnDateBean = null;
		Calendar minDate = null;
		DateBean minDateBean = null;
		if (CoverageItemList.logger.isDebugEnabled()) {
			CoverageItemList.logger
					.debug("Start of getFirstDate() in CoverageItemList.java");
			CoverageItemList.logger.debug("dateBeanList.size() is"
					+ dateBeanList.size());
		}

		for (int i = 0; i < dateBeanList.size(); i++) {
			if (CoverageItemList.logger.isDebugEnabled()) {
				CoverageItemList.logger.debug("In the for loop, i is" + i);
			}

			Calendar currentDate = Calendar.getInstance();
			DateBean currentDateBean = (DateBean) dateBeanList.get(i);
			if (CoverageItemList.logger.isDebugEnabled()) {
				CoverageItemList.logger.debug("currentDate is" + currentDate);
				CoverageItemList.logger.debug("currentDateBean is"
						+ currentDateBean);
			}

			try {

				if (StringUtils.isNotBlank(currentDateBean.getYear())
						&& StringUtils.isNotBlank(currentDateBean.getMonth())
						&& StringUtils.isNotBlank(currentDateBean.getDay())) {

					currentDate.set(
							Integer.parseInt(currentDateBean.getYear()),
							Integer.parseInt(currentDateBean.getMonth()),
							Integer.parseInt(currentDateBean.getDay()));
					if (CoverageItemList.logger.isDebugEnabled()) {
						CoverageItemList.logger
								.debug("currentDate in the try is"
										+ currentDate);
					}
					if ((minDate == null) || currentDate.before(minDate)) {
						minDate = currentDate;
						minDateBean = currentDateBean;
					}
					if (CoverageItemList.logger.isDebugEnabled()) {
						CoverageItemList.logger.debug("minDate in the try is"
								+ minDate);
						CoverageItemList.logger
								.debug("minDateBean in the try is"
										+ minDateBean);
					}
				}
			} catch (NumberFormatException e) {
				// Log error, then skip this one and go onto next
				CoverageItemList.logger.error("Date parse error", e);
			}
		}

		if (minDateBean == null) {
			if (CoverageItemList.logger.isDebugEnabled()) {
				CoverageItemList.logger
						.debug("End of getFirstDate() in CoverageItemList.java. In the if, return value is"
								+ new DateBean());
			}
			returnDateBean = new DateBean();
		} else {
			if (CoverageItemList.logger.isDebugEnabled()) {
				CoverageItemList.logger
						.debug("End of getFirstDate() in CoverageItemList.java. In the else, return value is"
								+ minDateBean);
			}
			returnDateBean = minDateBean;
		}
		return returnDateBean;
	}

	/**
	 * Calculates the total premium for all coverage items
	 *
	 * @return first effective date
	 */
	public int getPremiumTotal() {
		int total = 0;

		for (int i = 0; i < this.size(); i++) {
			CoverageItem item = (CoverageItem) this.get(i);
			if (item.getActive()) {
				total += item.getPremium();
			}
		}
		return total;
	}

	/**
	 * Determines the dental premium
	 *
	 * @return dental premium
	 */
	public int getDentalPremium() {
		int dentalPremium = 0;
		int basicDentalFederalFee = 0;
		int voluntaryDentalFederalFee = 0;
		int dentalTaxTypeTA = 0;
		int totalDentalPremium = 0;

		for (int i = 0; i < this.size(); i++) {
			CoverageItem item = (CoverageItem) this.get(i);
			if (item.getCoverageIsDental()) {
				dentalPremium = item.getPremium();
				break;
				
			} 
		}
		
		
		
		for (int i = 0; i < this.size(); i++) {
			CoverageItem item = (CoverageItem) this.get(i);
			 if (item.getCoverageIsDentalTax()) {
				dentalTaxTypeTA = item.getPremium();
				break;
			}
		}
		
		for (int i = 0; i < this.size(); i++) {
			CoverageItem item = (CoverageItem) this.get(i);
			 if (item.getCoverageIsBasicDentalFederalFee()) {
				basicDentalFederalFee = item.getPremium();
				break;
			} 
		}
		
		
		for (int i = 0; i < this.size(); i++) {
			CoverageItem item = (CoverageItem) this.get(i);
			 if (item.getCoverageIsVoluntaryDentalFederalFee()) {
				voluntaryDentalFederalFee = item.getPremium();
				break;
			}
		}
		
		
		
		
		totalDentalPremium = dentalPremium + dentalTaxTypeTA
				+ basicDentalFederalFee + voluntaryDentalFederalFee;
		return totalDentalPremium;
	}

	/**
	 * Determines the dental premium
	 *
	 * @return dental premium
	 */
	public int getVisionPremium() {
		int visionPremium = 0;
		int visionTaxTypeTA = 0;
		int basicVisionFederalFee = 0;
		int voluntaryVisionFederalFee = 0;

		int totalVisionPremium = 0;

		for (int i = 0; i < this.size(); i++) {
			CoverageItem item = (CoverageItem) this.get(i);
			if (item.getCoverageIsVision()) {
				visionPremium = item.getPremium();
				break;
			} 
		}
		
		for (int i = 0; i < this.size(); i++) {
			CoverageItem item = (CoverageItem) this.get(i);
			if (item.getCoverageIsVisionTax()) {
				visionTaxTypeTA = item.getPremium();
				break;
			}
		}
		
		for (int i = 0; i < this.size(); i++) {
			CoverageItem item = (CoverageItem) this.get(i);
			if (item.getCoverageIsBasicVisionFederalFee()) {
				basicVisionFederalFee = item.getPremium();
				break;
			}
		}
		
		
		for (int i = 0; i < this.size(); i++) {
			CoverageItem item = (CoverageItem) this.get(i);
			if (item.getCoverageIsVoluntaryVisionFederalFee()) {
				voluntaryVisionFederalFee = item.getPremium();
				break;
			}
		}

		totalVisionPremium = visionPremium + visionTaxTypeTA
				+ basicVisionFederalFee + voluntaryVisionFederalFee;
		return totalVisionPremium;
	}

	/**
	 * Determines the minimum waiting period day
	 *
	 * @return minimum waiting period day
	 */
	public String getMinWaitingPeriodDay() {
		if (CoverageItemList.logger.isDebugEnabled()) {
			CoverageItemList.logger
					.debug("Start of getMinWaitingPeriodDay() in CoverageItemList.java");
		}

		if (this.minWaitingPeriodDay == null) {
			int minVal = -1;
			String szMinVal = null;

			for (int i = 0; i < this.size(); i++) {
				CoverageItem item = (CoverageItem) this.get(i);
				String szCurrentVal = item.getWaitingPeriodDay();

				if (!com.bcbssc.struts.common.Constants.BLANK_STRING
						.equals(szCurrentVal)) {
					int currentVal = Integer.parseInt(szCurrentVal);

					if ((minVal != -1) && (currentVal != minVal)) {
						this.mixedWaitingPeriods = true;
					}

					if ((minVal == -1) || (currentVal < minVal)) {
						szMinVal = szCurrentVal;
						minVal = currentVal;
					}
				}
			}

			if (minVal != -1) {
				this.minWaitingPeriodDay = szMinVal;
			}
		}

		if (CoverageItemList.logger.isDebugEnabled()) {
			CoverageItemList.logger
					.debug("End of getMinWaitingPeriodDay() in CoverageItemList.java, minWaitingPeriodDay value is"
							+ this.minWaitingPeriodDay);
		}

		return this.minWaitingPeriodDay;
	}

	/**
	 * Determines the presence of a mixed waiting period error
	 *
	 * @return mixed waiting period error property key, or null if no error
	 */
	public String getMinWaitingPeriodErr() {
		String err = null;

		// getMinWaitingPeriodDay() also determines existence of error;
		// make sure it has run
		if (this.minWaitingPeriodDay == null) {
			this.getMinWaitingPeriodDay();
		}

		if (this.mixedWaitingPeriods) {
			err = CoverageItemList.ERROR_MIXED_WAITING_PERIODS;
		}

		return err == null ? com.bcbssc.struts.common.Constants.BLANK_STRING
				: err;
	}

	/**
	 * Getter for insuredDatasource.
	 *
	 * @return value of insuredDatasource
	 */
	public IInsuredDatasource getInsuredDatasource() {
		return this.insuredDatasource;
	}

	/**
	 * Determines if a coverage item has changed
	 *
	 * @return true if a dependnet has changed, false otherwise
	 */
	public boolean coverageItemChanged() {
		boolean changed = false;

		for (int i = 0; i < this.size(); i++) {
			CoverageItem item = (CoverageItem) this.get(i);
			if (item.getChanged()) {
				changed = true;
				break;
			}
		}

		return changed;
	}
}
