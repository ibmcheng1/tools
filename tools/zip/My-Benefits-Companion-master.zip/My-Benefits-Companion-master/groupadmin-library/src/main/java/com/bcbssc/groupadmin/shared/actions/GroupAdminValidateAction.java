/*
 * @(#)GroupAdminValidateAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.actions;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.groupadmin.shared.dto.RegistrationFormDTO;
import com.bcbssc.groupadmin.shared.forms.ProfileActionForm;
import com.bcbssc.groupadmin.shared.services.GroupAdminRegistrationServices;
import com.bcbssc.struts.action.BaseAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;

/**
 * CLife Validate User Action
 *
 * This class provides control processing the validation action. Because control
 * for validation is highly application specific, this class does not subclass a
 * shared action.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.1  $
 */
public class GroupAdminValidateAction extends BaseAction {

	/** log4j logger */
	private static final Logger logger = Logger
			.getLogger(GroupAdminValidateAction.class.getName());

	/**
	 * Verifies that two fields match. Adds an error to the specified field if
	 * they don't match, but only if this field doesn't already have an error.
	 *
	 * @param mapping a {@link org.apache.struts.action.ActionMapping} object.
	 * @param form a {@link org.apache.struts.action.ActionForm} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @param response a {@link javax.servlet.http.HttpServletResponse} object.
	 * @return a {@link org.apache.struts.action.ActionForward} object.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		int status = 0;

		if (GroupAdminValidateAction.logger.isDebugEnabled()) {
			GroupAdminValidateAction.logger.debug("Peforming validate action.");
		}

		DynaValidatorForm df = (DynaValidatorForm) form;

		String iniFile = CommonUtils.getIniFile(this.getServlet());
		String tdsIniFile = CommonUtils.getTDSIniFile(this.getServlet());
		GroupAdminRegistrationServices service = new GroupAdminRegistrationServices(
				iniFile, tdsIniFile);

		RegistrationFormDTO formDTO = new RegistrationFormDTO();
		BeanUtils.copyProperties(formDTO, df);

		status = service.validateUser(formDTO);

		switch (status) {
		case Constants.SERVICE_VALID:
			// the createProfileForm bean requires some dropdown data
			// that isn't included in formDTO (i.e., data that wasn't
			// passed in with the form or set during validation). create
			// a profileForm to handle these dropdowns.
			ProfileActionForm profileForm = (ProfileActionForm) this.getForm(
					"createProfileForm", "/createProfile", request);

			BeanUtils.copyProperties(profileForm, formDTO);

			return mapping
					.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);

		case Constants.ACCOUNT_EXISTS:
			this.addGlobalRequestMessage(request, "validate.exists");
			return mapping
					.findForward(com.bcbssc.registration.common.Constants.FORWARD_USER_EXISTS);

		case Constants.ACCOUNT_EXPIRED:
			this.addGlobalRequestMessage(request, "validate.expired");
			break;
		default:
			// case Constants.SERVICE_INVALID:
			this.addGlobalRequestMessage(request, "validate.invalid");
			break;
		}

		request.setAttribute("validationForm", formDTO);
		return new ActionForward(mapping.getInput());
	}

}
