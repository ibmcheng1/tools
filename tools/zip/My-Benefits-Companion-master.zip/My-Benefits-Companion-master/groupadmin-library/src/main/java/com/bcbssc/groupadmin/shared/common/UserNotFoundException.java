/*
 *
 * Created on Sep 6, 2006 
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.common;

import com.bcbssc.netsys.LinkedException;

/**
 * <p>UserNotFoundException class.</p>
 *
 * @author X08E
 * @version $Id: $Id
 */
public class UserNotFoundException extends LinkedException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1143746162273968377L;

	/**
	 * Creates a new instance of UserNotFoundException.
	 */
	public UserNotFoundException() {
		super();
	}

	/**
	 * Creates a new instance of UserNotFoundException with a descriptive
	 * message.
	 *
	 * @param message
	 *            The exception message.
	 */
	public UserNotFoundException(String message) {
		super(message);
	}

	/**
	 * Creates a new instance of UserNotFoundException with a descriptive
	 * message and a root cause.
	 *
	 * @param message
	 *            The exception message.
	 * @param rootCause
	 *            The root cause of this exception.
	 */
	public UserNotFoundException(String message, Throwable rootCause) {
		super(message, rootCause);
	}

	/**
	 * Creates a new instance of UserNotFoundException with the given root
	 * cause.
	 *
	 * @param rootCause
	 *            The root cause of this exception.
	 */
	public UserNotFoundException(Throwable rootCause) {
		super(rootCause);
	}

}
