/*
 * @(#)CoverageClass.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.dto;

/**
 * GroupAdmin Coverage Class
 *
 * This bean represents a coverage class.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class CoverageClass {

	/**
	 * Holds value of property code.
	 */
	private String code = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property description.
	 */
	private String description = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property ageChangeCode.
	 */
	private String ageChangeCode = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property issueCertType.
	 */
	private String issueCertType = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property walletCardType.
	 */
	private String walletCardType = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property sicCode.
	 */
	private String sicCode = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property maintenanceIndicator.
	 */
	private String maintenanceIndicator = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Creates a new instance of CoverageClass
	 */
	public CoverageClass() {
		// Do nothing, this is an empty bean to start.
	}

	/**
	 * Getter for property code.
	 *
	 * @return Value of property code.
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Setter for property code.
	 *
	 * @param code
	 *            New value of property code.
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * Getter for property description.
	 *
	 * @return Value of property description.
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 * Formattec getter for property description.
	 *
	 * @return Formatted value of property description.
	 */
	public String getDescriptionFormatted() {
		StringBuffer formattedDescription = new StringBuffer(32);
		formattedDescription.append(this.code).append(' ').append(
				this.description);
		return formattedDescription.toString();
	}

	/**
	 * Setter for property description.
	 *
	 * @param description
	 *            New value of property description.
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Getter for property ageChangeCode.
	 *
	 * @return Value of property ageChangeCode.
	 */
	public String getAgeChangeCode() {
		return this.ageChangeCode;
	}

	/**
	 * Setter for property ageChangeCode.
	 *
	 * @param ageChangeCode
	 *            New value of property ageChangeCode.
	 */
	public void setAgeChangeCode(String ageChangeCode) {
		this.ageChangeCode = ageChangeCode;
	}

	/**
	 * Getter for property issueCertType.
	 *
	 * @return Value of property issueCertType.
	 */
	public String getIssueCertType() {
		return this.issueCertType;
	}

	/**
	 * Setter for property issueCertType.
	 *
	 * @param issueCertType
	 *            New value of property issueCertType.
	 */
	public void setIssueCertType(String issueCertType) {
		this.issueCertType = issueCertType;
	}

	/**
	 * Getter for property walletCardType.
	 *
	 * @return Value of property walletCardType.
	 */
	public String getWalletCardType() {
		return this.walletCardType;
	}

	/**
	 * Setter for property walletCardType.
	 *
	 * @param walletCardType
	 *            New value of property walletCardType.
	 */
	public void setWalletCardType(String walletCardType) {
		this.walletCardType = walletCardType;
	}

	/**
	 * Getter for property sicCode.
	 *
	 * @return Value of property sicCode.
	 */
	public String getSicCode() {
		return this.sicCode;
	}

	/**
	 * Setter for property sicCode.
	 *
	 * @param sicCode
	 *            New value of property sicCode.
	 */
	public void setSicCode(String sicCode) {
		this.sicCode = sicCode;
	}

	/**
	 * Getter for property maintenanceIndicator.
	 *
	 * @return Value of property maintenanceIndicator.
	 */
	public String getMaintenanceIndicator() {
		return this.maintenanceIndicator;
	}

	/**
	 * Setter for property maintenanceIndicator.
	 *
	 * @param maintenanceIndicator
	 *            New value of property maintenanceIndicator.
	 */
	public void setMaintenanceIndicator(String maintenanceIndicator) {
		this.maintenanceIndicator = maintenanceIndicator;
	}
}
