/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/SpouseDetailsQuery.java_v  $
 * $Workfile:   SpouseDetailsQuery.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:26  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/SpouseDetailsQuery.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:14:26   EN80
 * Initial revision.
 * 
 *    Rev 1.7   Apr 28 2009 10:18:16   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.6   Feb 23 2005 17:25:00   rdq70
 * Added effective date.
 *
 *    Rev 1.5   Feb 16 2005 09:37:58   rdq70
 * Incorporated revised SQL.
 *
 *    Rev 1.4   Feb 15 2005 16:15:22   rdq70
 * Removed formatting of gender, status, student and smoker.
 *
 *    Rev 1.3   Feb 15 2005 11:17:52   rdq70
 * Removed SSN formatting built into SQL.
 *
 *    Rev 1.2   Feb 09 2005 09:58:42   rdq70
 * Use ASSIGNED_NAME_ID instead of NAME_ID.
 *
 *    Rev 1.1   Feb 07 2005 17:31:28   rdq70
 * Moved spouse properties to Dependent bean.
 *
 *    Rev 1.0   Feb 03 2005 14:32:12   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.dbaccess;

import com.bcbssc.groupadmin.shared.dto.Dependent;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;

/**
 * This query retrieves the details of the insured employee's spouse.<br>
 *
 * <pre>
 *     QMF NAME: RX13U.WEB_SQL_5_B
 *     TSO NAME: WEBSQL5B
 * </pre>
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class SpouseDetailsQuery extends AbstractDBSearch {

	/** The data object being populated. */
	InsuredDataDTO insuredData;

	/**
	 * Creates an <code>SpouseDetailsQuery</code> and configures it with an
	 * INI file.
	 *
	 * @param iniFile
	 *            file path of the configuration INI file.
	 */
	public SpouseDetailsQuery(String iniFile) {
		super(iniFile, "GCOM_TABLE");
	}

	/**
	 * Retrieves the details of the insured employee's spouse.<br>
	 *
	 * <pre>
	 *     QMF NAME: RX13U.WEB_SQL_5_B
	 *     TSO NAME: WEBSQL5B
	 * </pre>
	 *
	 * @param insuredData
	 *            the bean containing data for the search. It needs only the
	 *            groupNumber and identificationNumber properties set.
	 * @return the input bean populated with the search results.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 */
	public InsuredDataDTO performSearch(InsuredDataDTO insuredData)
			throws SQLException {
		this.checkInit(); // Necessary since we need the _dbSchema before the
							// query creation
		this.insuredData = insuredData;

		final StringBuffer sql = new StringBuffer(1500);

		sql
				.append(
						"SELECT LAST_NAME"
								+ "  , FIRST_NAME"
								+ "  , INITIAL"
								+ "  , CHAR(DOB,USA) \"SPOUSE'S DOB\""
								+ "  , SEX"
								+ "  , SSN"
								+ "  , CASE BENE_RELATION"
								+ "      WHEN 'HUS' THEN 'SPS'"
								+ "      WHEN 'WIF' THEN 'SPS'"
								+ "      WHEN 'FTR' THEN 'PRT'"
								+ "      WHEN 'MTH' THEN 'PRT'"
								+ "      WHEN 'CLH' THEN 'CHL'"
								+ "      WHEN 'DTR' THEN 'CHL'"
								+ "      WHEN 'SON' THEN 'CHL'"
								+ "      ELSE BENE_RELATION"
								+ "    END \"RELATIONSHIP\""
								+ "  , STUDENT_IND"
								+ "  , CHAR(COV_EFF_DATE,USA) \"SPOUSE_EFF DATE\""
								+ "  , NAME_ID" + "  , ASSIGNED_NAME_ID"
								+ " FROM ")
				.append(this._dbSchema)
				.append(
						".VCRTDPDZ" + " WHERE COMPANY_CODE = ?"
								+ "   AND GROUP_PREFIX = ?"
								+ "   AND GROUP_NUMBER = ?"
								+ "   AND DIVISION_ID = ?"
								+ "   AND CERTIFICATE_ID = ?"
								+ "   AND BENE_RELATION IN ('SPS','WIF','HUS')");

		final String[] params = { insuredData.getCompany(),
				insuredData.getGroupPrefix(), insuredData.getGroupBase(),
				insuredData.getDivisionCode(),
				insuredData.getIdentificationNumber() };

		this.performSearch(sql.toString(), params, Collections.EMPTY_LIST);
		return insuredData;
	}

	/**
	 * {@inheritDoc}
	 *
	 * Populates the data object from the given result set.
	 */
	protected void addSearchItem(ResultSet data, Object obj)
			throws SQLException {
		final Dependent spouse = this.insuredData.getSpouse();
		spouse.setLastName(data.getString("LAST_NAME").trim());
		spouse.setGivenName(data.getString("FIRST_NAME").trim());
		spouse.setMiddleIni(data.getString("INITIAL"));
		spouse.setDateOfBirth(DatabaseProxy.getDateBean(data
				.getString("SPOUSE'S DOB")));
		spouse.setGender(data.getString("SEX"));
		spouse.setSsn(data.getString("SSN").trim());
		spouse.setRelationship(data.getString("RELATIONSHIP").trim());
		spouse.setStudent(data.getString("STUDENT_IND"));
		spouse.setEffectiveDate(DatabaseProxy.getDateBean(data
				.getString("SPOUSE_EFF DATE")));
		// spouse.setNameId(data.getString("NAME_ID").trim());
		spouse.setNameId(data.getString("ASSIGNED_NAME_ID").trim());
	}
}
