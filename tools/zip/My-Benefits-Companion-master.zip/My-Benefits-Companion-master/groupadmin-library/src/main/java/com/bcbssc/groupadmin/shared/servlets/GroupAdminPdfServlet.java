/**
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 * Created on Aug 12, 2010
 */
package com.bcbssc.groupadmin.shared.servlets;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.bcbssc.commapi.model.documentarchive.dto.ImageFolder;
import org.apache.log4j.Logger;
import com.bcbssc.commapi.model.common.DocumentNotFoundException;
import com.bcbssc.groupadmin.shared.common.GroupAdminHelper;
import org.apache.commons.lang.StringUtils;
/**
 * <p>GroupAdminPdfServlet class.</p>
 *
 * @author X94S
 * @version $Id: $Id
 */
public class GroupAdminPdfServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** The log4j logger for this class */
	private static Logger log = Logger.getLogger(GroupAdminPdfServlet.class);

	/**
	 * Creates a new instance of RemitPdfServlet
	 */
	public GroupAdminPdfServlet() {
		if (GroupAdminPdfServlet.log.isDebugEnabled()) {
			GroupAdminPdfServlet.log
					.debug("Created GroupAdminPdfServlet object.");
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * Gets PDF document.
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		this.doPost(request, response);
	}

	/**
	 * {@inheritDoc}
	 *
	 * Gets PDF document.
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException {

		String folderName = request.getParameter("folder");
		
		if(log.isDebugEnabled()){
			log.debug("GroupAdminPDFServlet folderName="+folderName);
		}

		if (StringUtils.equalsIgnoreCase(folderName,ImageFolder.GROUP_ADMIN_POLICY.getFolderName())) {

			displayPolicyImage(request, response);

		} else if (StringUtils.equalsIgnoreCase(folderName,	ImageFolder.GROUP_ADMIN_CERT.getFolderName())) {

			displayCertificateImage(request, response);

		} else if (StringUtils.equalsIgnoreCase(folderName,	ImageFolder.GROUP_ADMIN_BILL.getFolderName())) {

			displayBillImage(request, response);

		}else if (StringUtils.equalsIgnoreCase(folderName,	ImageFolder.GROUP_ADMIN_DENTAL_CARD.getFolderName())) {

			displayDentalCardImage(request, response);

		}

	}

	private void displayBillImage(HttpServletRequest request,
			HttpServletResponse response)throws IOException {

		String groupNumber = request.getParameter("groupNumber");
		String selectedBillDate = request.getParameter("selectedBillDate");
		String dateFrom = request.getParameter("fromdate");
		String dateTo = request.getParameter("todate");
	
		GroupAdminHelper grpAdminHelper = new GroupAdminHelper();
		byte[] bytes = null;
		try {
			bytes = grpAdminHelper.getGroupAdminBillViewDocument(groupNumber,
					dateFrom, dateTo, selectedBillDate);
			if (bytes != null) {
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				baos.write(bytes);
				response.setHeader("Expires", "0");
				response.setHeader("Cache-Control",
						"must-revalidate, post-check=0,pre-check=0");
				response.setHeader("Pragma", "public");
				response.setContentType("application/pdf");
				response.setContentLength(bytes.length);
				response.setBufferSize(bytes.length);
				ServletOutputStream out = response.getOutputStream();
				baos.writeTo(out);
				out.flush();
				out.close();
			} else {
				log.debug("GroupAdminPdfServlet image length: 0 bytes. bytes object was null.");
			}

			log.debug("GroupAdminPdfServlet after flushing data");
		} catch (DocumentNotFoundException doe) {
			showMessage(doe, bytes, response);

		} catch (Exception e) {
			showMessage(e, bytes, response);
		}

	}

	private void displayPolicyImage(HttpServletRequest request,
			HttpServletResponse response)throws IOException {

		String groupNumber = request.getParameter("groupNumber");
		String dateFrom = request.getParameter("fromdate");
		String dateTo = request.getParameter("todate");
		String selectedReportId = request.getParameter("reportId");
		GroupAdminHelper grpAdminHelper = new GroupAdminHelper();
		byte[] bytes = null;
		try {
			bytes = grpAdminHelper.getGroupAdminPolicyDocument(groupNumber,
					dateFrom, dateTo,selectedReportId);
			if (bytes != null) {
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				baos.write(bytes);
				response.setHeader("Expires", "0");
				response.setHeader("Cache-Control",
						"must-revalidate, post-check=0,pre-check=0");
				response.setHeader("Pragma", "public");
				response.setContentType("application/pdf");
				response.setContentLength(bytes.length);
				response.setBufferSize(bytes.length);
				ServletOutputStream out = response.getOutputStream();
				baos.writeTo(out);
				out.flush();
				out.close();
			} else {
				log.debug("GroupAdminPdfServlet image length: 0 bytes. bytes object was null.");
			}

			log.debug("GroupAdminPdfServlet after flushing data");
		} catch (DocumentNotFoundException doe) {
			showMessage(doe, bytes, response);

		} catch (Exception e) {
			showMessage(e, bytes, response);
		}

	}
	
	
	private void displayDentalCardImage(HttpServletRequest request,
			HttpServletResponse response)throws IOException {

		String groupNumber = request.getParameter("groupNumber");
		String dateFrom = request.getParameter("fromdate");
		String dateTo = request.getParameter("todate");
		String dentalCardId = request.getParameter("certId");
		String selectedReportId = request.getParameter("reportId");
	
		GroupAdminHelper grpAdminHelper = new GroupAdminHelper();
		byte[] bytes = null;
		try {
			bytes = grpAdminHelper.getGroupAdminDentalCard(groupNumber,
					dateFrom, dateTo,selectedReportId,dentalCardId);
			if (bytes != null) {
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				baos.write(bytes);
				response.setHeader("Expires", "0");
				response.setHeader("Cache-Control",
						"must-revalidate, post-check=0,pre-check=0");
				response.setHeader("Pragma", "public");
				response.setContentType("application/pdf");
				response.setContentLength(bytes.length);
				response.setBufferSize(bytes.length);
				ServletOutputStream out = response.getOutputStream();
				baos.writeTo(out);
				out.flush();
				out.close();
			} else {
				log.debug("GroupAdminPdfServlet image length: 0 bytes. bytes object was null.");
			}

			log.debug("GroupAdminPdfServlet after flushing data");
		} catch (DocumentNotFoundException doe) {
			showMessage(doe, bytes, response);

		} catch (Exception e) {
			showMessage(e, bytes, response);
		}

	}

	private void displayCertificateImage(HttpServletRequest request,
			HttpServletResponse response)throws IOException {

		String groupNumber = request.getParameter("groupNumber");
		String certId = request.getParameter("certId");
		String dateFrom = request.getParameter("fromdate");
		String dateTo = request.getParameter("todate");
		String selectedReportId = request.getParameter("reportId");
		GroupAdminHelper grpAdminHelper = new GroupAdminHelper();
		byte[] bytes = null;
		try {
			bytes = grpAdminHelper.getGroupAdminCertificateDocument(groupNumber,dateFrom, dateTo,selectedReportId,certId);
			if (bytes != null) {
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				baos.write(bytes);
				response.setHeader("Expires", "0");
				response.setHeader("Cache-Control",
						"must-revalidate, post-check=0,pre-check=0");
				response.setHeader("Pragma", "public");
				response.setContentType("application/pdf");
				response.setContentLength(bytes.length);
				response.setBufferSize(bytes.length);
				ServletOutputStream out = response.getOutputStream();
				baos.writeTo(out);
				out.flush();
				out.close();
			} else {
				log.debug("GroupAdminPdfServlet image length: 0 bytes. bytes object was null.");
			}

			log.debug("GroupAdminPdfServlet after flushing data");
		} catch (DocumentNotFoundException doe) {
			showMessage(doe, bytes, response);

		} catch (Exception e) {
			showMessage(e, bytes, response);
		}

	}

	private void showMessage(Exception e, byte[] bytes,
			HttpServletResponse response) throws IOException {
		log.error("GroupAdminPdfServlet caught Exception:" + e);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		bytes = "The requested document not found.".getBytes();
		baos.write(bytes);
		response.setHeader("Expires", "0");
		response.setHeader("Cache-Control",
				"must-revalidate, post-check=0,pre-check=0");
		response.setHeader("Pragma", "public");
		response.setContentType("text/html");
		response.setContentLength(bytes.length);
		response.setBufferSize(bytes.length);
		ServletOutputStream out = response.getOutputStream();
		baos.writeTo(out);
		out.flush();
		out.close();
	}
}
