/*
 * @(#)InsuredDataDTO.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.dto;

import com.bcbssc.struts.common.DateBean;

import java.util.ArrayList;
import java.util.Iterator;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * GroupAdmin Insured Data Data Transfer Object
 *
 * This bean contains the insured employee, spouse, dependent and coverage data.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class InsuredDataDTO extends Object implements IInsuredDatasource {

	/** log4j logger */
	private static final Logger log = Logger.getLogger(InsuredDataDTO.class);

	/**
	 * Holds the String value of the property dentalCoverage.
	 */
	private String dentalCoverageStr;

	/**
	 * Holds the String value of the property visionCoverage.
	 */
	private String visionCoverageStr;

	/**
	 * <p>Getter for the field <code>dentalCoverageStr</code>.</p>
	 *
	 * @return Returns the dentalCoverageStr.
	 */
	public String getDentalCoverageStr() {
		return this.dentalCoverageStr;
	}

	/**
	 * <p>Setter for the field <code>dentalCoverageStr</code>.</p>
	 *
	 * @param dentalCoverageStr
	 *            The dentalCoverageStr to set.
	 */
	public void setDentalCoverageStr(String dentalCoverageStr) {
		this.dentalCoverageStr = dentalCoverageStr;
	}

	/**
	 * <p>Getter for the field <code>visionCoverageStr</code>.</p>
	 *
	 * @return Returns the visionCoverageStr.
	 */
	public String getVisionCoverageStr() {
		return this.visionCoverageStr;
	}

	/**
	 * <p>Setter for the field <code>visionCoverageStr</code>.</p>
	 *
	 * @param visionCoverageStr
	 *            The visionCoverageStr to set.
	 */
	public void setVisionCoverageStr(String visionCoverageStr) {
		this.visionCoverageStr = visionCoverageStr;
	}

	/** employee group number */
	private String groupNumber = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** employee division name */
	private String divisionName = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** annual salary */
	private String annualSalary = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** annual salary dollars */
	private String annualSalaryDollars = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** annual salary cents */
	private String annualSalaryCents = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** spouse coverage indicator */
	private boolean spouseExists;

	/** coverage class */
	private CoverageClass coverageClass = new CoverageClass();

	/** total premium */
	private String premium;

	/** other dental indicator */
	private boolean otherDental;

	/** spouse dental indicator */
	private String spouseDental = "N";

	private boolean visionCoverage;

	private boolean dentalCoverage;

	/** list of coverage items associated with the selected class */
	private CoverageItemList coverageItems = new CoverageItemList(this);

	/** list of dependents */
	private DependentList dependents = new DependentList();

	/** The number of dependents from the database. */
	private int databaseDependentsCount;

	/** insured first name */
	private String givenName = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** insured last name */
	private String lastName = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** insured middle initial */
	private String middleIni = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** insured date of birth */
	private DateBean dateOfBirth = new DateBean();

	/** insured date of hire */
	private DateBean hireDate = new DateBean();

	/** insured original effective date */
	private DateBean originalEffectiveDate = new DateBean();

	/** division original effective date */
	private DateBean divisionOriginalEffectiveDate = new DateBean();

	/** effective date of change */
	private DateBean changeEffectiveDate = new DateBean();

	/** salary effective date of change */
	protected DateBean salaryChangeEffectiveDate = new DateBean();

	/** insured last processed date */
	private DateBean lastProcessedDate = new DateBean();

	/** insured termination date */
	private DateBean terminationDate = new DateBean();

	/** last bill date */
	private DateBean lastBillDate = new DateBean();

	/** bill due date */
	private DateBean billDueDate = new DateBean();

	/**
	 * Holds value of property identificationNumber.
	 */
	private String identificationNumber = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** insured gender */
	private String gender = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** insured ssn */
	private String ssn = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property addressLine1.
	 */
	private String addressLine1 = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property addressLine2.
	 */
	private String addressLine2 = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property city.
	 */
	private String city = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property state.
	 */
	private String state = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property zip.
	 */
	private String zip = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** telephone number */
	private String telephoneNumber = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property department.
	 */
	private String department = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property payrollOfficeIdentifier.
	 */
	private String payrollOfficeIdentifier = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property occupation.
	 */
	private String occupation = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property cobra.
	 */
	private String cobra = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property smoker.
	 */
	private String smoker = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** list of dependents */
	private Dependent spouse = new Dependent();

	/**
	 * Holds value of property averageHoursWorked.
	 */
	private String averageHoursWorked = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property dental DependentCount
	 */
	private int dentalDependentCount;

	/**
	 * Holds value of property terminationReason.
	 */
	private String terminationReason = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property alternateID.
	 */
	private String alternateID = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property member status.
	 */
	private String status = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property employeeStatus.
	 */
	private String employeeStatus = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property addNewGroup.
	 */
	private boolean addNewGroup;

	/**
	 * Holds value of property rateBasisCode.
	 */
	private String rateBasisCode;

	/**
	 * Holds value of property spouseIndicator (not marital status).
	 */
	private String spouseIndicator;

	/** Insured-related coverage items */
	CoverageItemList insuredCoverageItems = null;

	/** Spouse-related coverage items */
	CoverageItemList spouseCoverageItems = null;

	/** Dependent-related coverage items */
	CoverageItemList dependentCoverageItems = null;

	/**
	 * Holds value of property nemIndicator.
	 */
	private boolean nemIndicator;

	/**
	 * Default constructor
	 */
	public InsuredDataDTO() {
		super();
	}

	/**
	 * Gets the group number
	 *
	 * @return group number
	 */
	public String getGroupNumber() {
		return this.groupNumber;
	}

	/**
	 * Sets the group number
	 *
	 * @param value
	 *            group number
	 */
	public void setGroupNumber(String value) {
		this.groupNumber = value;
	}

	/**
	 * Gets the company, which is the first three characters of groupNumber
	 *
	 * @return company
	 */
	public String getCompany() {
		return this.getPaddedGroupNumber().substring(0, 3);
	}

	/**
	 * Gets the groupPrefix, which is characters 4 and 5 of groupNumber
	 *
	 * @return group prefix
	 */
	public String getGroupPrefix() {
		return this.getPaddedGroupNumber().substring(3, 5);
	}

	/**
	 * Gets the groupBase, which is characters 6 through 10 of groupNumber
	 *
	 * @return group base
	 */
	public String getGroupBase() {
		return this.getPaddedGroupNumber().substring(5, 10);
	}

	/**
	 * Gets the divisionCode, which is characters 11 through 13 of groupNumber
	 *
	 * @return division code
	 */
	public String getDivisionCode() {
		return this.getPaddedGroupNumber().substring(10);
	}

	/**
	 * Gets the groupNumber, padded to 13 characters
	 * 
	 * @return padded group number
	 */
	private String getPaddedGroupNumber() {
		StringBuffer grpNbr = new StringBuffer(16);
		grpNbr.append(this.groupNumber);

		// Pad out the group number with spaces so we don't get indexing errors
		for (int i = this.groupNumber.length(); i < 13; i++) {
			grpNbr.append(' ');
		}

		return grpNbr.toString();
	}

	// public static void main(String[] inArgs) {
	// InsuredDataDTO dto = new InsuredDataDTO();
	// dto.setGroupNumber("0123456789ab");
	// System.out.println(dto.getGroupNumber());
	// System.out.println(dto.getCompany());
	// System.out.println(dto.getGroupPrefix());
	// System.out.println(dto.getGroupBase());
	// System.out.println(dto.getDivisionCode());
	// System.out.println(dto.getGroupNumber());
	// }

	/**
	 * Gets the division name
	 *
	 * @return division name
	 */
	public String getDivisionName() {
		return this.divisionName;
	}

	/**
	 * Sets the division name
	 *
	 * @param value
	 *            division name
	 */
	public void setDivisionName(String value) {
		this.divisionName = value;
	}

	/**
	 * Adds a coverage item to the end of the coverage item list, creating the
	 * list if necessary.
	 *
	 * @param newItem
	 *            coverage item to add to the list
	 */
	public void addCoverageItem(CoverageItem newItem) {
		this.dependentCoverageItems = null;
		this.spouseCoverageItems = null;
		this.insuredCoverageItems = null;

		this.coverageItems.add(newItem);
	}

	/**
	 * Adds a dependent to the end of the dependent list, creating the list if
	 * necessary.
	 *
	 * @param newDependent
	 *            dependent to add to the list
	 */
	public void addDependent(Dependent newDependent) {
		newDependent.setAdded(true);
		this.dependents.add(newDependent);
	}

	/**
	 * Adds an item at the specifed index of the list, creating the list and
	 * creating placeholders for other items prior to the specified index if
	 * necessary.
	 *
	 * @param index
	 *            index at which point the item will be added
	 * @param newItem
	 *            coverage item to add to the list
	 */
	public void addCoverageItem(int index, CoverageItem newItem) {
		this.dependentCoverageItems = null;
		this.spouseCoverageItems = null;
		this.insuredCoverageItems = null;

		this.coverageItems.add(index, newItem);
	}

	/**
	 * Adds a dependent at the specifed index of the list, creating the list and
	 * creating placeholders for other items prior to the specified index if
	 * necessary.
	 *
	 * @param index
	 *            index at which point the item will be added
	 * @param newDependent a {@link com.bcbssc.groupadmin.shared.dto.Dependent} object.
	 */
	public void addDependent(int index, Dependent newDependent) {
		this.dependents.add(index, newDependent);
	}

	/**
	 * Gets the coverage items
	 *
	 * @return coverage items associated with the selected class
	 */
	public ArrayList getCoverageItems() {
		return this.coverageItems;
	}

	/**
	 * Gets the coverage items associated with the insured
	 *
	 * @return coverage items associated with the insured
	 */
	public ArrayList getInsuredCoverageItems() {
		if (this.insuredCoverageItems == null) {
			this.insuredCoverageItems = this
					.getRelationshipCoverageItems(CoverageItem.RELATIONSHIP_INSURED);
		}

		return this.insuredCoverageItems;
	}

	/**
	 * Gets the coverage items associated with the spouse
	 *
	 * @return coverage items associated with the spouse
	 */
	public ArrayList getSpouseCoverageItems() {
		if (this.spouseCoverageItems == null) {
			this.spouseCoverageItems = this
					.getRelationshipCoverageItems(CoverageItem.RELATIONSHIP_SPOUSE);
		}

		return this.spouseCoverageItems;
	}

	/**
	 * Gets the coverage items associated with dependents
	 *
	 * @return coverage items associated with dependents
	 */
	public ArrayList getDependentCoverageItems() {
		if (this.dependentCoverageItems == null) {
			this.dependentCoverageItems = this
					.getRelationshipCoverageItems(CoverageItem.RELATIONSHIP_DEPENDENT);
		}

		return this.dependentCoverageItems;
	}

	/**
	 * Gets the coverage items associated with a particular relationship type
	 * 
	 * @param the
	 *            relationship type
	 * @return coverage items associated with dependents
	 */
	private CoverageItemList getRelationshipCoverageItems(String relationship) {
		CoverageItemList relationshipItems = new CoverageItemList(this);
		Iterator itemIterator = this.coverageItems.iterator();
		while (itemIterator.hasNext()) {
			CoverageItem item = (CoverageItem) itemIterator.next();
			if (item.getRelationshipType().equalsIgnoreCase(relationship)) {
				relationshipItems.add(item);
			}
		}
		return relationshipItems;
	}

	/**
	 * Returns the number of coverage items
	 *
	 * @return coverage item count
	 */
	public int getCoverageItemsCount() {
		return this.coverageItems.size();
	}

	/**
	 * Gets the dependents
	 *
	 * @return dependents
	 */
	public ArrayList getDependents() {
		InsuredDataDTO.log.debug("getting dependents: " + this.dependents);
		return this.dependents;
	}

	/**
	 * Returns the number of dependents
	 *
	 * @return dependents
	 */
	public int getDependentsCount() {
		return this.dependents.size();
	}

	/**
	 * Returns the number of dependents from the database.
	 *
	 * @return the number of dependents from the database.
	 */
	public int getDatabaseDependentsCount() {
		return this.databaseDependentsCount;
	}

	/**
	 * Sets the number of dependents from the database.
	 *
	 * @param value the number of dependents from the database.
	 */
	public void setDatabaseDependentsCount(int value) {
		this.databaseDependentsCount = value;
	}

	/**
	 * This method gets dependent list with spouse.
	 *
	 * @return dependent list with spouse (if there) in front
	 */
	public ArrayList getAllDependents() {
		ArrayList returnArrayList = null;
		if (this.spouseExists) {
			ArrayList allDependents = new ArrayList();
			allDependents.add(this.spouse);
			allDependents.addAll(this.dependents);
			returnArrayList = allDependents;
		} else {
			returnArrayList = this.dependents;
		}
		return returnArrayList;
	}

	/**
	 * Sets the coverage items
	 *
	 * @param coverageItemList
	 *            list of the coverage items associated with the selected class
	 */
	public void setCoverageItems(ArrayList coverageItemList) {
		this.dependentCoverageItems = null;
		this.spouseCoverageItems = null;
		this.insuredCoverageItems = null;

		InsuredDataDTO.log.debug("setting coverage items");
		this.coverageItems = new CoverageItemList(this, coverageItemList);
	}

	/**
	 * Sets the dependents
	 *
	 * @param dependentList
	 *            list of dependents
	 */
	public void setDependents(ArrayList dependentList) {
		this.dependents = new DependentList(dependentList);
	}

	/**
	 * Gets a coverage item from the form ArrayList
	 *
	 * @param index
	 *            index of the item to get
	 * @return coverage item at the specified index
	 */
	public CoverageItem getCoverageItem(int index) {
		return this.coverageItems.getCoverageItem(index);
	}

	/**
	 * Gets a dependent from the form ArrayList
	 *
	 * @param index
	 *            index of the dependent to get
	 * @return dependent at the specified index
	 */
	public Dependent getDependent(int index) {
		return this.dependents.getDependent(index);
	}

	/**
	 * Sets the spouse coverage indicator
	 *
	 * @param value
	 *            spouse coverage indicator
	 */
	public void setSpouseExists(boolean value) {
		InsuredDataDTO.log.debug("setting spouse coverage to: " + value);
		this.spouseExists = value;
	}

	/**
	 * Gets the spouse exists indicator
	 *
	 * @return spouse exists indicator
	 */
	public boolean getSpouseExists() {
		return this.spouseExists;
	}

	/**
	 * Sets the annual salary (dollars and cents concatenated)
	 *
	 * @param value
	 *            annual salary
	 */
	public void setAnnualSalary(String value) {
		this.annualSalary = value;
	}

	/**
	 * Gets the annual salary (dollars and cents concatenated)
	 *
	 * @return annual salary
	 */
	public String getAnnualSalary() {
		return this.annualSalary;
	}

	/**
	 * Sets the annual salary cents
	 *
	 * @param value
	 *            annual salary cents
	 */
	public void setAnnualSalaryCents(String value) {
		this.annualSalaryCents = value;
	}

	/**
	 * Gets the annual salary cents
	 *
	 * @return annual salary cents
	 */
	public String getAnnualSalaryCents() {
		return this.annualSalaryCents;
	}

	/**
	 * Sets the annual salary dollars
	 *
	 * @param value
	 *            annual salary
	 */
	public void setAnnualSalaryDollars(String value) {
		this.annualSalaryDollars = value;
	}

	/**
	 * Gets the annual salary dollars
	 *
	 * @return annual salary dollars
	 */
	public String getAnnualSalaryDollars() {
		return this.annualSalaryDollars;
	}

	/**
	 * Gets the coverage class
	 *
	 * @return coverage class
	 */
	public CoverageClass getCoverageClass() {
		return this.coverageClass;
	}

	/**
	 * Sets the coverage class
	 *
	 * @param bean
	 *            coverage class
	 */
	public void setCoverageClass(CoverageClass bean) {
		this.coverageClass = bean;
	}

	/**
	 * Gets the total premium.
	 *
	 * @return total premium.
	 */
	public String getPremium() {
		return this.premium;
	}

	/**
	 * Sets the total premium.
	 *
	 * @param value
	 *            total premium.
	 */
	public void setPremium(String value) {
		this.premium = value;
	}

	/**
	 * Gets the dental premium
	 *
	 * @return dental premium
	 */
	public int getDentalPremium() {
		return this.coverageItems.getDentalPremium();
	}

	/**
	 * Gets the other dental indicator
	 *
	 * @return other dental indicator
	 */
	public boolean getOtherDental() {
		return this.otherDental;
	}

	/**
	 * Sets the other dental indicator
	 *
	 * @param value
	 *            other dental indicator
	 */
	public void setOtherDental(boolean value) {
		this.otherDental = value;
	}

	/**
	 * Gets the spouse dental indicator
	 *
	 * @return spouse dental indicator or false if there is no spouse coverage
	 */
	public String getSpouseDental() {
		return this.spouseExists ? this.spouseDental : "N";
	}

	/**
	 * Sets the spouse dental indicator
	 *
	 * @param value
	 *            spouse dental indicator
	 */
	public void setSpouseDental(String value) {
		this.spouseDental = value;
	}

	/**
	 * Gets the dental coverage indicator
	 *
	 * @return dental coverage indicator
	 */
	public boolean getClassHasDentalCoverage() {
		Iterator items = this.coverageItems.iterator();
		while (items.hasNext()) {
			CoverageItem item = (CoverageItem) items.next();
			if (item.getCoverageIsDental()) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Gets the annual salary indicator
	 *
	 * @return annual salary indicator
	 */
	public boolean getClassRequiresAnnualSalary() {
		Iterator items = this.coverageItems.iterator();
		while (items.hasNext()) {
			CoverageItem item = (CoverageItem) items.next();
			if (item.getClassRequiresAnnualSalary()) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Determines the minimum waiting period day
	 *
	 * @return minimum waiting period day
	 */
	public String getMinWaitingPeriodDay() {
		return this.coverageItems.getMinWaitingPeriodDay();
	}

	/**
	 * Getter for property givenName.
	 *
	 * @return Value of property givenName.
	 */
	public String getGivenName() {
		return this.givenName;
	}

	/**
	 * Setter for property givenName.
	 *
	 * @param value a {@link java.lang.String} object.
	 */
	public void setGivenName(String value) {
		this.givenName = value;
	}

	/**
	 * Getter for property lastName.
	 *
	 * @return Value of property lastName.
	 */
	public String getLastName() {
		return this.lastName;
	}

	/**
	 * Setter for property lastName.
	 *
	 * @param value a {@link java.lang.String} object.
	 */
	public void setLastName(String value) {
		this.lastName = value;
	}

	/**
	 * Getter for property middleIni.
	 *
	 * @return Value of property middleIni.
	 */
	public String getMiddleIni() {
		return this.middleIni;
	}

	/**
	 * Setter for property middleIni.
	 *
	 * @param value
	 *            New value of property middleIni.
	 */
	public void setMiddleIni(String value) {
		this.middleIni = value;
	}

	/**
	 * Getter for property dateOfBirth.
	 *
	 * @return Value of property dateOfBirth.
	 */
	public DateBean getDateOfBirth() {
		return this.dateOfBirth;
	}

	/**
	 * Setter for property dateOfBirth.
	 *
	 * @param value
	 *            New value of property dateOfBirth.
	 */
	public void setDateOfBirth(DateBean value) {
		this.dateOfBirth = value;
	}

	/**
	 * Getter for property identificationNumber.
	 *
	 * @return Value of property identificationNumber.
	 */
	public String getIdentificationNumber() {
		return this.identificationNumber;
	}

	/**
	 * Setter for property identificationNumber.
	 *
	 * @param value
	 *            New value of property identificationNumber.
	 */
	public void setIdentificationNumber(String value) {
		this.identificationNumber = value;
	}

	/**
	 * Getter for property gender.
	 *
	 * @return Value of property gender.
	 */
	public String getGender() {
		return this.gender;
	}

	/**
	 * Setter for property gender.
	 *
	 * @param value
	 *            New value of property gender.
	 */
	public void setGender(String value) {
		this.gender = value;
	}

	/**
	 * Getter for property ssn.
	 *
	 * @return Value of property ssn.
	 */
	public String getSsn() {
		return this.ssn;
	}

	/**
	 * Setter for property ssn.
	 *
	 * @param value
	 *            New value of property ssn.
	 */
	public void setSsn(String value) {
		this.ssn = value;
	}

	/**
	 * Getter for property addressLine1.
	 *
	 * @return Value of property addressLine1.
	 */
	public String getAddressLine1() {
		return this.addressLine1;
	}

	/**
	 * Setter for property addressLine1.
	 *
	 * @param addressLine1
	 *            New value of property addressLine1.
	 */
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	/**
	 * Getter for property addressLine2.
	 *
	 * @return Value of property addressLine2.
	 */
	public String getAddressLine2() {
		return this.addressLine2;
	}

	/**
	 * Setter for property addressLine2.
	 *
	 * @param addressLine2
	 *            New value of property addressLine2.
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	/**
	 * Getter for property city.
	 *
	 * @return Value of property city.
	 */
	public String getCity() {
		return this.city;
	}

	/**
	 * Setter for property city.
	 *
	 * @param city
	 *            New value of property city.
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * Getter for property state.
	 *
	 * @return Value of property state.
	 */
	public String getState() {
		return this.state;
	}

	/**
	 * Setter for property state.
	 *
	 * @param state
	 *            New value of property state.
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * Getter for property zip.
	 *
	 * @return Value of property zip.
	 */
	public String getZip() {
		return this.zip;
	}

	/**
	 * Setter for property zip.
	 *
	 * @param zip
	 *            New value of property zip.
	 */
	public void setZip(String zip) {
		this.zip = zip;
	}

	/**
	 * Gets the telephone number
	 *
	 * @return telephone number
	 */
	public String getTelephoneNumber() {
		return this.telephoneNumber;
	}

	/**
	 * Sets the telephone number
	 *
	 * @param value
	 *            telephone number
	 */
	public void setTelephoneNumber(String value) {
		this.telephoneNumber = value;
	}

	/**
	 * Getter for property hireDate.
	 *
	 * @return Value of property hireDate.
	 */
	public DateBean getHireDate() {
		return this.hireDate;
	}

	/**
	 * Setter for property hireDate.
	 *
	 * @param value
	 *            New value of property hireDate.
	 */
	public void setHireDate(DateBean value) {
		this.hireDate = value;
	}

	/**
	 * Getter for property originalEffectiveDate.
	 *
	 * @return Value of property originalEffectiveDate.
	 */
	public DateBean getOriginalEffectiveDate() {
		return this.originalEffectiveDate;
	}

	/**
	 * Setter for property originalEffectiveDate.
	 *
	 * @param value
	 *            New value of property originalEffectiveDate.
	 */
	public void setOriginalEffectiveDate(DateBean value) {
		this.originalEffectiveDate = value;
	}

	/**
	 * Getter for property divisionOriginalEffectiveDate.
	 *
	 * @return Value of property divisionOriginalEffectiveDate.
	 */
	public DateBean getDivisionOriginalEffectiveDate() {
		return this.divisionOriginalEffectiveDate;
	}

	/**
	 * Setter for property divisionOriginalEffectiveDate.
	 *
	 * @param value
	 *            New value of property divisionOriginalEffectiveDate.
	 */
	public void setDivisionOriginalEffectiveDate(DateBean value) {
		this.divisionOriginalEffectiveDate = value;
	}

	/**
	 * Getter for property changeEffectiveDate.
	 *
	 * @return Value of property changeEffectiveDate.
	 */
	public DateBean getChangeEffectiveDate() {
		return this.changeEffectiveDate;
	}

	/**
	 * Returns changeEffectiveDate as a DateBean.
	 *
	 * @return changeEffectiveDate as a DateBean.
	 */
	public DateBean getChangeEffectiveDateAsDateBean() {
		if (InsuredDataDTO.log.isDebugEnabled()) {
			InsuredDataDTO.log
					.debug("In InsuredDataDTO.java - getChangeEffectiveDateAsDateBean(), changeEffectiveDate is"
							+ this.changeEffectiveDate);
		}
		return this.changeEffectiveDate;
	}

	/**
	 * Setter for property changeEffectiveDate.
	 *
	 * @param value
	 *            New value of property changeEffectiveDate.
	 */
	public void setChangeEffectiveDate(DateBean value) {
		this.changeEffectiveDate = value;
	}

	/**
	 * Getter for property salaryChangeEffectiveDate.
	 *
	 * @return Value of property salaryChangeEffectiveDate.
	 */
	public DateBean getSalaryChangeEffectiveDate() {
		return this.salaryChangeEffectiveDate;
	}

	/**
	 * Returns salaryChangeEffectiveDate as a DateBean.
	 *
	 * @return salaryChangeEffectiveDate as a DateBean.
	 */
	public DateBean getSalaryChangeEffectiveDateAsDateBean() {
		if (InsuredDataDTO.log.isDebugEnabled()) {
			InsuredDataDTO.log
					.debug("In InsuredDataDTO.java - getSalaryChangeEffectiveDateAsDateBean(), salaryChangeEffectiveDate is"
							+ this.salaryChangeEffectiveDate);
		}
		return this.salaryChangeEffectiveDate;
	}

	/**
	 * Setter for property salaryChangeEffectiveDate.
	 *
	 * @param value
	 *            New value of property salaryChangeEffectiveDate.
	 */
	public void setSalaryChangeEffectiveDate(DateBean value) {
		this.salaryChangeEffectiveDate = value;
	}

	/**
	 * Getter for property lastProcessedDate.
	 *
	 * @return Value of property lastProcessedDate.
	 */
	public DateBean getLastProcessedDate() {
		return this.lastProcessedDate;
	}

	/**
	 * Setter for property lastProcessedDate.
	 *
	 * @param value
	 *            New value of property lastProcessedDate.
	 */
	public void setLastProcessedDate(DateBean value) {
		this.lastProcessedDate = value;
	}

	/**
	 * Getter for property terminationDate.
	 *
	 * @return Value of property terminationDate.
	 */
	public DateBean getTerminationDate() {
		return this.terminationDate;
	}

	/**
	 * Setter for property terminationDate.
	 *
	 * @param value
	 *            New value of property terminationDate.
	 */
	public void setTerminationDate(DateBean value) {
		this.terminationDate = value;
	}

	/**
	 * Getter for property lastBillDate.
	 *
	 * @return Value of property lastBillDate.
	 */
	public DateBean getLastBillDate() {
		return this.lastBillDate;
	}

	/**
	 * Setter for property lastBillDate.
	 *
	 * @param value
	 *            New value of property lastBillDate.
	 */
	public void setLastBillDate(DateBean value) {
		this.lastBillDate = value;
	}

	/**
	 * Getter for property department.
	 *
	 * @return Value of property department.
	 */
	public String getDepartment() {
		return this.department;
	}

	/**
	 * Setter for property department.
	 *
	 * @param value
	 *            New value of property department.
	 */
	public void setDepartment(String value) {
		this.department = value;
	}

	/**
	 * Getter for property payrollOfficeIdentifier.
	 *
	 * @return Value of property payrollOfficeIdentifier.
	 */
	public String getPayrollOfficeIdentifier() {
		return this.payrollOfficeIdentifier;
	}

	/**
	 * Setter for property payrollOfficeIdentifier.
	 *
	 * @param payrollOfficeIdentifier
	 *            New value of property payrollOfficeIdentifier.
	 */
	public void setPayrollOfficeIdentifier(String payrollOfficeIdentifier) {
		this.payrollOfficeIdentifier = payrollOfficeIdentifier;
	}

	/**
	 * Getter for property occupation.
	 *
	 * @return Value of property occupation.
	 */
	public String getOccupation() {
		return this.occupation;
	}

	/**
	 * Setter for property occupation.
	 *
	 * @param occupation
	 *            New value of property occupation.
	 */
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	/**
	 * Getter for property cobra.
	 *
	 * @return Value of property cobra.
	 */
	public String getCobra() {
		return this.cobra;
	}

	/**
	 * Setter for property cobra.
	 *
	 * @param value
	 *            New value of property cobra.
	 */
	public void setCobra(String value) {
		this.cobra = value;
	}

	/**
	 * Getter for property smoker.
	 *
	 * @return Value of property smoker.
	 */
	public String getSmoker() {
		return this.smoker;
	}

	/**
	 * Setter for property smoker.
	 *
	 * @param smoker
	 *            New value of property smoker.
	 */
	public void setSmoker(String smoker) {
		this.smoker = smoker;
	}

	/**
	 * Getter for property spouse
	 *
	 * @return Value of property spouse or an empty Dependent if no spouse
	 *         coverage.
	 */
	public Dependent getSpouse() {
		return this.spouseExists ? this.spouse : new Dependent();
	}

	/**
	 * Setter for property spouse.
	 *
	 * @param bean
	 *            New value of property spouse
	 */
	public void setSpouse(Dependent bean) {
		bean.setRelationship(Dependent.RELATIONSHIP_SPOUSE);
		this.spouse = bean;
	}

	/**
	 * Getter for property averageHoursWorked.
	 *
	 * @return Value of property averageHoursWorked.
	 */
	public String getAverageHoursWorked() {
		return this.averageHoursWorked;
	}

	/**
	 * Setter for property averageHoursWorked.
	 *
	 * @param averageHoursWorked
	 *            New value of property averageHoursWorked.
	 */
	public void setAverageHoursWorked(String averageHoursWorked) {
		this.averageHoursWorked = averageHoursWorked;
	}

	/**
	 * Getter for property dentalDependentCount.
	 *
	 * @return Value of property dentalDependentCount.
	 */
	public int getDentalDependentCount() {
		return this.dentalDependentCount;
	}

	/**
	 * Setter for property dentalDependentCount.
	 *
	 * @param dentalDependentCount
	 *            New value of property dentalDependentCount.
	 */
	public void setDentalDependentCount(int dentalDependentCount) {
		this.dentalDependentCount = dentalDependentCount;
	}

	/**
	 * Gets a the first effective date in the coverage item list
	 *
	 * @return first effective date in coverage item list
	 */
	public DateBean getFirstEffectiveDate() {
		return this.coverageItems.getFirstEffectiveDate();
	}

	/**
	 * Gets a the first effective date in the coverage item list
	 *
	 * @return first effective date in coverage item list
	 */
	public String getFirstEffectiveYear() {
		DateBean effectiveDate = this.coverageItems.getFirstEffectiveDate();
		return StringUtils.substring(effectiveDate.getYear(), 2, 4);
	}

	/**
	 * Returns a String representation of the object.
	 *
	 * @return description of the object contents
	 */
	public String toString() {
		StringBuffer str = new StringBuffer(256);
		str.append("CoverageForm info:");
		str.append("\nspouseExists: ").append(this.spouseExists);

		if (this.coverageItems != null) {
			str.append("\nnumber of CoverageItem objects: ").append(
					this.coverageItems.size());
			for (int i = 0; i < this.coverageItems.size(); i++) {
				str.append("\n  CoverageItem #").append(i);
				str.append(((CoverageItem) this.coverageItems.get(i))
						.toString());
			}
		}

		return str.toString();
	}

	/**
	 * Getter for property terminationReason.
	 *
	 * @return Value of property terminationReason.
	 */
	public String getTerminationReason() {
		return this.terminationReason;
	}

	/**
	 * Setter for property terminationReason.
	 *
	 * @param terminationReason
	 *            New value of property terminationReason.
	 */
	public void setTerminationReason(String terminationReason) {
		this.terminationReason = terminationReason;
	}

	/**
	 * Getter for property alternateID.
	 *
	 * @return Value of property alternateID.
	 */
	public String getAlternateID() {
		return this.alternateID;
	}

	/**
	 * Setter for property alternateID.
	 *
	 * @param alternateID
	 *            New value of property alternateID.
	 */
	public void setAlternateID(String alternateID) {
		this.alternateID = alternateID;
	}

	/**
	 * Getter for property member status.
	 *
	 * @return Value of property status.
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * Setter for property member status.
	 *
	 * @param status
	 *            New value of property member status.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Getter for property employeeStatus.
	 *
	 * @return Value of property employeeStatus.
	 */
	public String getEmployeeStatus() {
		return this.employeeStatus;
	}

	/**
	 * Setter for property employeeStatus.
	 *
	 * @param employeeStatus
	 *            New value of property member employeeStatus.
	 */
	public void setEmployeeStatus(String employeeStatus) {
		this.employeeStatus = employeeStatus;
	}

	/**
	 * Getter for property addNewGroup.
	 *
	 * @return Value of property addNewGroup.
	 */
	public boolean isAddNewGroup() {
		return this.addNewGroup;
	}

	/**
	 * Setter for property addNewGroup.
	 *
	 * @param addNewGroup
	 *            New value of property addNewGroup.
	 */
	public void setAddNewGroup(boolean addNewGroup) {
		this.addNewGroup = addNewGroup;
	}

	/**
	 * Getter for property rateBasisCode.
	 *
	 * @return Value of property rateBasisCode.
	 */
	public String getRateBasisCode() {
		return this.rateBasisCode;
	}

	/**
	 * Setter for property rateBasisCode.
	 *
	 * @param rateBasisCode
	 *            New value of property rateBasisCode.
	 */
	public void setRateBasisCode(String rateBasisCode) {
		this.rateBasisCode = rateBasisCode;
	}

	/**
	 * Getter for property spouseIndicator.
	 *
	 * @return Value of property spouseIndicator.
	 */
	public String getSpouseIndicator() {
		return this.spouseIndicator;
	}

	/**
	 * Setter for property spouseIndicator.
	 *
	 * @param spouseIndicator
	 *            New value of property spouseIndicator.
	 */
	public void setSpouseIndicator(String spouseIndicator) {
		this.spouseIndicator = spouseIndicator;
	}

	/**
	 * Getter for property nemIndicator.
	 *
	 * @return Value of property nemIndicator.
	 */
	public boolean getNemIndicator() {
		return this.nemIndicator;
	}

	/**
	 * Setter for property nemIndicator.
	 *
	 * @param nemIndicator
	 *            New value of property nemIndicator.
	 */
	public void setNemIndicator(boolean nemIndicator) {
		this.nemIndicator = nemIndicator;
	}

	/**
	 * Getter for property insuredPageUpdated.
	 *
	 * @return Value of property insuredPageUpdated.
	 */
	public boolean isInsuredPageUpdated() {
		return false;
	}

	/**
	 * Getter for property coveragePageUpdated.
	 *
	 * @return Value of property coveragePageUpdated.
	 */
	public boolean isCoveragePageUpdated() {
		return false;
	}

	/**
	 * Getter for property dependentPageUpdated.
	 *
	 * @return Value of property dependentPageUpdated.
	 */
	public boolean isDependentPageUpdated() {
		return false;
	}

	/**
	 * Getter for property salaryPageUpdated.
	 *
	 * @return Value of property salaryPageUpdated.
	 */
	public boolean isSalaryPageUpdated() {
		return false;
	}

	/**
	 * <p>Getter for the field <code>billDueDate</code>.</p>
	 *
	 * @return a {@link com.bcbssc.struts.common.DateBean} object.
	 */
	public DateBean getBillDueDate() {
		return this.billDueDate;
	}

	/**
	 * <p>Setter for the field <code>billDueDate</code>.</p>
	 *
	 * @param bean a {@link com.bcbssc.struts.common.DateBean} object.
	 */
	public void setBillDueDate(DateBean bean) {
		this.billDueDate = bean;
	}

	/**
	 * <p>Getter for the field <code>visionCoverage</code>.</p>
	 *
	 * @return Returns the visionCoverage.
	 */
	public boolean getVisionCoverage() {
		return this.visionCoverage;
	}

	/**
	 * <p>Setter for the field <code>visionCoverage</code>.</p>
	 *
	 * @param visionCoverage
	 *            The visionCoverage to set.
	 */
	public void setVisionCoverage(boolean visionCoverage) {
		this.visionCoverage = visionCoverage;
	}

	/**
	 * <p>getVisionPremium.</p>
	 *
	 * @return Returns the visionPremium.
	 */
	public int getVisionPremium() {
		return this.coverageItems.getVisionPremium();
	}

	/**
	 * <p>Getter for the field <code>dentalCoverage</code>.</p>
	 *
	 * @return Returns the dentalCoverage.
	 */
	public boolean getDentalCoverage() {
		return this.dentalCoverage;
	}

	/**
	 * <p>Setter for the field <code>dentalCoverage</code>.</p>
	 *
	 * @param dentalCoverage
	 *            The dentalCoverage to set.
	 */
	public void setDentalCoverage(boolean dentalCoverage) {
		this.dentalCoverage = dentalCoverage;
	}
}
