/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/BillQuery.java_v  $
 * $Workfile:   BillQuery.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:06  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/BillQuery.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:14:06   EN80
 * Initial revision.
 * 
 *    Rev 1.9   Apr 28 2009 10:17:48   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.8   Jul 10 2006 14:11:30   rx22r
 * Modified Bill History SQL to eliminate the rows with payment status "X".
 * 
 *    Rev 1.7   May 09 2006 10:33:14   rx08e
 * Changes for Vision Coverage.	
 *
 *    Rev 1.6   Apr 05 2005 16:47:32   rxr93
 * add division to summary query
 *
 *    Rev 1.5   Apr 04 2005 12:42:34   rxr93
 * sql fixed for number of lives and administrative fee
 *
 *    Rev 1.4   Apr 04 2005 09:44:28   rxr93
 * total payment dues amount corrected (sql adjusted)
 *
 *    Rev 1.3   Feb 16 2005 09:50:38   rdq70
 * Removed SQL formatting of status.
 *
 *    Rev 1.2   Feb 15 2005 11:40:06   rdq70
 * Fixed syntax error and reduced whitespace.
 *
 *    Rev 1.1   Feb 11 2005 11:25:56   rdq70
 * Added mappings into beans.
 *
 *    Rev 1.0   Feb 11 2005 10:58:58   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.dbaccess;

import com.bcbssc.groupadmin.shared.dto.BillHistoryDTO;
import com.bcbssc.groupadmin.shared.dto.BillSummaryDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

/**
 * Queries bill history and bill summary.
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class BillQuery extends AbstractDBSearch {

	/** <code>true</code> if this is a bill summary query. */
	private boolean summary;

	/**
	 * Creates an <code>BillQuery</code> and configures it with an INI file.
	 *
	 * @param iniFile
	 *            file path of the configuration INI file.
	 */
	public BillQuery(String iniFile) {
		super(iniFile, "GCOM_TABLE");
	}

	/**
	 * Creates a list of the six most current bills generated for a group.<br>
	 *
	 * <pre>
	 *     QMF NAME: RX13U.WEB_SQL_6
	 *     TSO NAME: WEBSQL6
	 * </pre>
	 *
	 * @param insuredData
	 *            the bean containing data for the search. It needs only the
	 *            groupNumber property set.
	 * @return a collection populated with the search results.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 */
	public Collection performSearch(InsuredDataDTO insuredData)
			throws SQLException {
		this.checkInit(); // Necessary since we need the _dbSchema before the
							// query creation
		this.summary = false;

		final String company = insuredData.getCompany();
		final String prefix = insuredData.getGroupPrefix();
		final String group = insuredData.getGroupBase();
		final String division = insuredData.getDivisionCode();

		final String[] params = { company, prefix, group, division, company,
				prefix, group, division, company, prefix, group, division };

		return this.performSearch(this.getHistorySql(), params);
	}

	/**
	 * Retrieves summary information for a bill.<br>
	 *
	 * <pre>
	 *     QMF NAME: RX13U.WEB_SQL_7
	 *     TSO NAME: WEBSQL7
	 * </pre>
	 *
	 * @param insuredData
	 *            the bean containing data for the search. It needs only the
	 *            groupNumber property set.
	 * @param dueDate
	 *            the due date for the bill summary of the form MM/dd/yyyy.
	 * @return a collection populated with the search results.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 */
	public Collection performSearch(InsuredDataDTO insuredData, String dueDate)
			throws SQLException {

		this.checkInit(); // Necessary since we need the _dbSchema before the
							// query creation
		this.summary = true;

		final String[] params = { insuredData.getCompany(),
				insuredData.getGroupPrefix(), insuredData.getGroupBase(),
				insuredData.getDivisionCode(), dueDate,
				insuredData.getCompany(), insuredData.getGroupPrefix(),
				insuredData.getGroupBase(), insuredData.getDivisionCode(),
				dueDate };

		return this.performSearch(this.getSummarySql(), params);
	}

	/**
	 * {@inheritDoc}
	 *
	 * Adds data from the given result set to the target collection.
	 */
	protected void addSearchItem(ResultSet data, Object obj)
			throws SQLException {
		final Collection list = (Collection) obj;
		final Object bean;

		if (this.summary) {
			bean = this.createBillSummary(data);
		} else {
			bean = this.createBillHistory(data);
		}

		list.add(bean);
	}

	/**
	 * Returns the SQL for a bill history query.
	 * 
	 * @return the SQL for a bill history query.
	 */
	private String getHistorySql() {
		return new StringBuffer(1700)
				.append(
						"SELECT CHAR(A.BLLNG_DUE_DT,USA) \"DUE DATE\""
								+ "     , A.TTL_BILLD_AMT +"
								+ "       A.TTL_ADJ_AMT +"
								+ "       A.ADM_FEE_RCVB_TTL +"
								+ "       A.BILL_FEE_RCVB_TTL \"BILLED AMT\""
								+ "     , A.PAYM_AMT_CRED \"PREMIUM PAID\""
								+ "     , CHAR(A.LST_PAYM_DT,USA) \"PAYMENT DATE\""
								+ "     , A.PAYM_STAT"
								+ "     , A.BAL_DUE_AMT \"REMAINING_AMOUNT\""
								+ "     , (A.BAL_DUE_AMT + A.TTL_PREM_ANNZD_HLT) \"TOTAL DUE\""
								+ " FROM ")
				.append(this._dbSchema)
				.append(
						".VBILHSTZ A"
								+ " WHERE A.COMP_CD = ?"
								+ "   AND A.GROUP_PRFX = ?"
								+ "   AND A.GROUP_NO = ?"
								+ "   AND A.DIV_ID = ?"
								+ "   AND A.PAYM_STAT != 'X'"
								+ "   AND A.BLLNG_DUE_DT <= (SELECT MAX(BLLNG_DUE_DT)"
								+ "                          FROM ")
				.append(this._dbSchema)
				.append(
						".VBILHSTZ"
								+ "                          WHERE COMP_CD = ?"
								+ "                            AND GROUP_PRFX = ?"
								+ "                            AND GROUP_NO = ?"
								+ "                            AND DIV_ID = ?)"
								+ "   AND A.BLLNG_DUE_DT >= (SELECT MAX(BLLNG_DUE_DT) - 5 MONTH"
								+ "                          FROM ")
				.append(this._dbSchema)
				.append(
						".VBILHSTZ"
								+ "                          WHERE COMP_CD = ?"
								+ "                            AND GROUP_PRFX = ?"
								+ "                            AND GROUP_NO = ?"
								+ "                            AND DIV_ID = ?)")
				.toString();
	}

	/**
	 * Creates a bill history bean from the given result set.
	 * 
	 * @param data
	 *            the result set whose cursor is on a row containing the data to
	 *            use.
	 * 
	 * @return a new bill history bean.
	 * 
	 * @throws SQLException
	 *             if an error occurs while accessing the result set.
	 */
	private Object createBillHistory(ResultSet data) throws SQLException {
		final BillHistoryDTO bean = new BillHistoryDTO();
		bean.setDueDate(data.getString("DUE DATE"));
		// bean.(data.getString("TTL_BILLD_AMT"));
		// bean.(data.getString("TTL_ADJ_AMT"));
		// bean.(data.getString("ADM_FEE_RCVB_TTL"));
		bean.setBilledAmount(data.getString("BILLED AMT"));
		bean.setPremiumPaid(data.getString("PREMIUM PAID"));
		bean.setPaymentDate(data.getString("PAYMENT DATE"));
		bean.setStatus(data.getString("PAYM_STAT"));
		bean.setRemainingAmount(data.getString("REMAINING_AMOUNT"));
		// bean.(data.getString("BAL_DUE_AMT"));
		bean.setTotalDue(data.getString("TOTAL DUE"));
		return bean;
	}

	/**
	 * Returns the SQL for a bill summary query.
	 * 
	 * @return the SQL for a bill summary query.
	 */
	private String getSummarySql() {
		return new StringBuffer(1100).append(
				"SELECT A.CVG_DESC " + "   , A.CVG_TYP "
						+ "   , SUM(C.NO_BILLD_INSD +"
						+ "        C.NO_BILLD_SP +"
						+ "        C.NO_BILLD_DEP) \"NUMBER_LIVES\" "
						+ "   , SUM(C.BILL_VOL_INSD +"
						+ "        C.BILL_VOL_SP +"
						+ "        C.BILL_VOL_DEP) \"VOLUME\""
						+ "   , C.BILL_PREM_TTL \"BILLED\""
						+ "   , C.ADJ_PREM_TTL" + "   , SUM(C.BILL_PREM_TTL +"
						+ "        C.ADJ_PREM_TTL) \"TOTAL_PREMIUM\""
						+ "   , 0 as ordx " + " FROM ").append(this._dbSchema)
				.append(".VRTVCVGZ A" + "    , ").append(this._dbSchema)
				.append(
						".VBILCVGZ C" + " WHERE C.COMP_CD = ?"
								+ "   AND C.GROUP_PRFX = ?"
								+ "   AND C.GROUP_NO = ?" + "   AND DIV_ID = ?"
								+ "   AND A.CVG||A.SUB_CVG = C.CVG||C.SUB_CVG"
								+ "   AND C.BLLNG_DUE_DT = ?"
								+ " GROUP BY A.CVG_DESC"
								+ "        , C.NO_BILLD_INSD"
								+ "        , C.NO_BILLD_SP"
								+ "        , C.NO_BILLD_DEP"
								+ "        , C.BILL_VOL_INSD"
								+ "        , C.BILL_VOL_SP"
								+ "        , C.BILL_VOL_DEP"
								+ "        , C.BILL_PREM_TTL"
								+ "        , C.ADJ_PREM_TTL"
								+ "        , C.BILL_PREM_TTL"
								+ "        , C.ADJ_PREM_TTL"
								+ "        , A.CVG_TYP" + " UNION "
								+ " SELECT 'ADMINISTRATIVE FEE' "
								+ "       ,'0'  " + "       ,0 " + "       ,0 "
								+ // lives, volume
								"       , BILL_FEE_RCVB_TTL" + // billed
								"       ,0.0 " + // adj prem amt
								"       , BILL_FEE_RCVB_TTL" + // total
								"       , 99 as ordx " + "  FROM ").append(
						this._dbSchema).append(
						".VBILHSTZ " + "  WHERE COMP_CD = ?"
								+ "   AND GROUP_PRFX = ?"
								+ "   AND GROUP_NO = ?" + "   AND DIV_ID = ?"
								+ "   AND BLLNG_DUE_DT = ?"
								+ "   AND BILL_FEE_RCVB_TTL > 0"
								+ " ORDER BY ordx " + "").toString();
	}

	/**
	 * Creates a bill summary bean from the given result set.
	 * 
	 * @param data
	 *            the result set whose cursor is on a row containing the data to
	 *            use.
	 * 
	 * @return a new bill summary bean.
	 * 
	 * @throws SQLException
	 *             if an error occurs while accessing the result set.
	 */
	private Object createBillSummary(ResultSet data) throws SQLException {
		final BillSummaryDTO bean = new BillSummaryDTO();
		bean.setCoverage(data.getString("CVG_DESC"));
		bean.setNumberLives(data.getString("NUMBER_LIVES"));
		bean.setVolume(data.getString("VOLUME"));
		bean.setBilled(data.getString("BILLED"));
		bean.setAdjusted(data.getString("ADJ_PREM_TTL"));
		bean.setTotalPremium(data.getString("TOTAL_PREMIUM"));
		bean.setCoverageType(data.getString("CVG_TYP"));
		return bean;
	}

}
