/*
 * @(#)SessionAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/actions/SessionAction.java_v  $
 * $Workfile:   SessionAction.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:13:46  $
 * $Modtime:   May 14 2009 11:33:28  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/actions/SessionAction.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:13:46   EN80
 * Initial revision.
 * 
 *    Rev 1.2   Apr 28 2009 10:17:22   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.1   Oct 06 2006 16:38:24   rx29e
 * Added timestamp to the forward, to resolve the caching issue.
 * 
 *    Rev 1.0   May 04 2005 19:58:24   rxr93
 * Initial revision.
 * 
 */

package com.bcbssc.groupadmin.shared.actions;

import com.bcbssc.struts.action.SimpleDispatchAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * Session managment access points (start and logoff)
 *
 * @author Mark Lujan
 * @version $Revision:   1.0  $
 */
public class SessionAction extends SimpleDispatchAction {

	/** log4j logger */
	private static final Logger log = Logger.getLogger(SessionAction.class
			.getName());

	/**
	 * <p>Constructor for SessionAction.</p>
	 */
	public SessionAction() {
		super();
	}

	/**
	 * Processes the specified HTTP request, and creates the corresponding HTTP
	 * response.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward startSession(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		HttpSession session = request.getSession();
		SessionAction.log.debug("remove objects from " + session.getId());

		session
				.removeAttribute(com.bcbssc.registration.common.Constants.USER_DTO);

		ActionForward actionForward = mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
		StringBuffer sbCurrentPath = new StringBuffer(actionForward.getPath());
		sbCurrentPath.append("?ts=").append(System.currentTimeMillis());

		if (SessionAction.log.isDebugEnabled()) {
			SessionAction.log
					.debug("************ startSession The new path is "
							+ sbCurrentPath.toString());
		}

		ActionForward returnForward = new ActionForward();
		BeanUtils.copyProperties(returnForward, actionForward);
		returnForward.setPath(sbCurrentPath.toString());

		return returnForward;
	}

	/**
	 * Processes the specified HTTP request, and creates the corresponding HTTP
	 * response.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward logoff(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		HttpSession session = request.getSession();
		SessionAction.log.debug("logoff " + session.getId());

		session.invalidate();

		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}

}
