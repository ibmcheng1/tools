/*
 *
 * @(#)InsuredDataForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.forms;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.dto.CoverageClass;
import com.bcbssc.groupadmin.shared.dto.CoverageItem;
import com.bcbssc.groupadmin.shared.dto.CoverageItemList;
import com.bcbssc.groupadmin.shared.dto.Dependent;
import com.bcbssc.groupadmin.shared.dto.DependentList;
import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.groupadmin.shared.dto.IInsuredDatasource;
import com.bcbssc.groupadmin.shared.services.InsuredServices;
import com.bcbssc.struts.common.DateBean;
import com.bcbssc.struts.common.FormDate;
import com.bcbssc.struts.common.PhoneNumber;
import com.bcbssc.struts.common.SocialSecurityNumber;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.regexp.RE;
import org.apache.regexp.RESyntaxException;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.ValidatorForm;

/**
 * GroupAdmin Insured Data Form
 *
 * This abstract bean is used to transport insured employee data. It is extended
 * by form classes that implement validate and clear methods specific to the
 * individual forms.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public abstract class InsuredDataForm extends
        ValidatorForm implements
        IInsuredDatasource, IClearableForm {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** log4j logger */
    private static final Logger log = Logger.getLogger(InsuredDataForm.class);

    /**
     * Holds the String value of the property dentalCoverage.
     */
    protected String dentalCoverageStr;

    /**
     * Holds the String value of the property visionCoverage.
     */
    protected String visionCoverageStr;

    /** concatenated employee group data */
    private String groupData = null;

    /** group options */
    private Collection groupOptions;

    /** employee group number */
    private String groupNumber = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** employee division name */
    private String divisionName = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** group last bill date */
    private FormDate lastBillDate = FormDate.blank();

    /** group bill due date */
    private FormDate billDueDate = FormDate.blank();

    /** spouse coverage indicator */
    private boolean spouseExists = false;

    /** annual salary (dollars) */
    protected String annualSalaryDollars = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** annual salary (cents) */
    protected String annualSalaryCents = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** coverage class */
    protected CoverageClass coverageClass = new CoverageClass();

    /** dental premium */
    private int dentalPremium;

    private int visionPremium;

    /** other dental indicator */
    protected String otherDental;

    /** spouse dental indicator */
    protected String spouseDental = "N";

    /** dental dependent count */
    protected int dentalDependentCount;

    /** list of coverage items associated with the selected class */
    protected CoverageItemList coverageItems = new CoverageItemList(this);

    /** list of dependents */
    protected DependentList dependents = new DependentList();

    /** The number of dependents from the database. */
    private int databaseDependentsCount;

    /** insured first name */
    protected String givenName;

    /** insured last name */
    protected String lastName;

    /** insured middle initial */
    protected String middleIni;

    /** insured date of birth */
    protected FormDate dateOfBirth = FormDate.blank();

    /** insured date of hire */
    protected FormDate hireDate = FormDate.blank();

    /** effective date of change */
    protected FormDate changeEffectiveDate = FormDate.today();

    /** salary effective date of change */
    protected FormDate salaryChangeEffectiveDate = FormDate.blank();

    /** insured effective date */
    private FormDate effectiveDate = FormDate.blank();

    /** division original effective date */
    private FormDate divisionOriginalEffectiveDate = FormDate.blank();

    /** insured last processed date */
    private FormDate lastProcessedDate = FormDate.blank();

    /** insured date of hire */
    private FormDate terminationDate = FormDate.blank();

    /**
     * Holds value of property identificationNumber.
     */
    protected String identificationNumber;

    /** insured gender */
    protected String gender;

    /** insured ssn */
    private SocialSecurityNumber ssn = SocialSecurityNumber.blank();

    /**
     * Holds value of property addressLine1.
     */
    protected String addressLine1;

    /**
     * Holds value of property addressLine2.
     */
    protected String addressLine2;

    /**
     * Holds value of property city.
     */
    protected String city;

    /**
     * Holds value of property state.
     */
    protected String state;

    /**
     * Holds value of property zip.
     */
    protected String zip;

    /** telephone number */
    protected PhoneNumber telephoneNumber = PhoneNumber.blank();

    /**
     * Holds value of property department.
     */
    protected String department;

    /**
     * Holds value of property payrollOfficeIdentifier.
     */
    protected String payrollOfficeIdentifier;

    /**
     * Holds value of property occupation.
     */
    protected String occupation;

    /**
     * Holds value of property cobra.
     */
    protected String cobra;

    /**
     * Holds value of property smoker.
     */
    protected String smoker;

    /** spouse ssn */
    private Dependent spouse = new Dependent();

    /**
     * Holds value of property averageHoursWorked.
     */
    protected String averageHoursWorked;

    /**
     * Holds value of property terminationReason.
     */
    private String terminationReason;

    /**
     * Holds value of property alternateID.
     */
    private String alternateID;

    /**
     * Holds value of property status.
     */
    private String status;

    /**
     * The services object used for business logic and backend processing
     */
    private InsuredServices insuredServices;

    /**
     * Holds value of property addNewGroup.
     */
    private boolean addNewGroup;

    /**
     * Holds value of property nemIndicator.
     */
    private boolean nemIndicator;

    /**
     * Holds value of property employeeStatus.
     */
    private String employeeStatus;

    /**
     * Holds value of property rateBasisCode.
     */
    private String rateBasisCode;

    /**
     * Holds value of property spouseIndicator.
     */
    private String spouseIndicator;

    /**
     * Holds value of userDTO.
     */
    private GroupAdminUserDTO userDTO;

    /**
     * Holds the vision coverage status
     */
    private boolean visionCoverage = false;

    /**
     * Holds the dental coverage status
     */
    private boolean dentalCoverage = false;

    /**
     * Clears the user-editable data fields for this form
     */
    public abstract void clear();

    /**
     * Default constructor; calls parent constructor. Called when form object is
     * needed during normal Structs processing.
     */
    public InsuredDataForm() {
        super();
    }

    /**
     * Returns the unique instance of the Options class.
     *
     * @return the Options instance
     */
    public Options getOptions() {
        return Options.getGroupAdminInstance();
    }

    /**
     * Adds a coverage item to the end of the coverage item list, creating the
     * list if necessary.
     *
     * @param newItem
     *            coverage item to add to the list
     */
    public void addCoverageItem(CoverageItem newItem) {
        this.coverageItems.add(newItem);
    }

    /**
     * <p>updateCoverageItemList.</p>
     */
    public void updateCoverageItemList() {
        if (this.coverageItems != null) {
            for (int i = 0; i < this.coverageItems.size(); i++) {
                CoverageItem coverageItem = (CoverageItem) this.coverageItems
                        .get(i);
                String action = String.valueOf(coverageItem.getAction());
                if (coverageItem.getCode().equalsIgnoreCase("LIFE")
                        && action.equalsIgnoreCase("R")) {
                    this.setCoverageItemAction("DEPE");
                }
                if (coverageItem.getCode().equalsIgnoreCase("VLIF")
                        && action.equalsIgnoreCase("R")) {
                    this.setCoverageItemAction("VSPS");
                    this.setCoverageItemAction("VSPF");
                    this.setCoverageItemAction("VSPM");
                    this.setCoverageItemAction("VCHI");
                }
            }
        }
    }

    /**
     * <p>setCoverageItemAction.</p>
     *
     * @param coverageCode a {@link java.lang.String} object.
     */
    public void setCoverageItemAction(String coverageCode) {
        Iterator itemIterator = this.coverageItems.iterator();
        while (itemIterator.hasNext()) {
            CoverageItem item = (CoverageItem) itemIterator.next();
            if (item.getCode().equalsIgnoreCase(coverageCode)) {
                item.setAction('R');
            }
        }
    }

    /**
     * Adds a dependent to the end of the dependent list, creating the list if
     * necessary.
     *
     * @param newDependent
     *            dependent to add to the list
     */
    public void addDependent(Dependent newDependent) {
        this.dependents.add(newDependent);
    }

    /**
     * Returns the number of dependents from the database.
     *
     * @return the number of dependents from the database.
     */
    public int getDatabaseDependentsCount() {
        return this.databaseDependentsCount;
    }

    /**
     * Sets the number of dependents from the database.
     *
     * @param value the number of dependents from the database.
     */
    public void setDatabaseDependentsCount(int value) {
        this.databaseDependentsCount = value;
    }

    /**
     * Adds an item at the specifed index of the list, creating the list and
     * creating placeholders for other items prior to the specified index if
     * necessary.
     *
     * @param index
     *            index at which point the item will be added
     * @param newItem
     *            coverage item to add to the list
     */
    public void addCoverageItem(int index, CoverageItem newItem) {
        this.coverageItems.add(index, newItem);
    }

    /**
     * <p>addDependent.</p>
     *
     * @param index a int.
     * @param newDependent a {@link com.bcbssc.groupadmin.shared.dto.Dependent} object.
     */
    public void addDependent(int index, Dependent newDependent) {
        this.dependents.add(index, newDependent);
    }

    /**
     * Gets the coverage items
     *
     * @return coverage items associated with the selected class
     */
    public ArrayList<CoverageItem> getCoverageItems() {
        return this.coverageItems;
    }

    /**
     * Gets the dependents
     *
     * @return dependents
     */
    public ArrayList getDependents() {
        return this.dependents;
    }

    /**
     * Gets the coverage item empty indicator
     *
     * @return a boolean.
     */
    public boolean getCoverageItemsEmpty() {
        return this.coverageItems.isEmpty();
    }

    /**
     * Gets the dependent list empty indicator
     *
     * @return a boolean.
     */
    public boolean getDependentListEmpty() {
        return this.dependents.isEmpty();
    }

    /**
     * Sets the coverage items
     *
     * @param coverageItemList
     *            list of the coverage items associated with the selected class
     */
    public void setCoverageItems(ArrayList coverageItemList) {
        this.coverageItems = new CoverageItemList(this, coverageItemList);
    }

    /**
     * Sets the dependents
     *
     * @param dependentList
     *            list of dependents
     */
    public void setDependents(ArrayList dependentList) {
        this.dependents = new DependentList(dependentList);
    }

    /**
     * Gets a coverage item from the form ArrayList
     *
     * @param index
     *            index of the item to get
     * @return coverage item at the specified index
     */
    public CoverageItem getCoverageItem(int index) {
        return this.coverageItems.getCoverageItem(index);
    }

    /**
     * Gets a dependent from the form ArrayList
     *
     * @param index
     *            index of the dependent to get
     * @return dependent at the specified index
     */
    public Dependent getDependent(int index) {
        return this.dependents.getDependent(index);
    }

    /**
     * Sets the spouse coverage indicator
     *
     * @param value
     *            spouse coverage indicator
     */
    public void setSpouseExists(boolean value) {
        this.spouseExists = value;
    }

    /**
     * Gets the spouse coverage indicator
     *
     * @return spouse coverage indicator
     */
    public boolean getSpouseExists() {
        return this.spouseExists;
    }

    /**
     * Gets the annual salary dollars amount
     *
     * @return annual salary dollars amount
     */
    public String getAnnualSalaryDollars() {
        return this.annualSalaryDollars;
    }

    /**
     * Gets the annual salary cents amount
     *
     * @return annual salary cents amount
     */
    public String getAnnualSalaryCents() {
        return this.annualSalaryCents;
    }

    /**
     * Gets the annual salary (dollars and cents concatenated)
     *
     * @return annual salary
     */
    public String getAnnualSalary() {
        return this.annualSalaryDollars + this.annualSalaryCents;
    }

    /**
     * Gets the formatted dental premium
     *
     * @return formatted dental premium
     */
    public String getAnnualSalaryFormatted() {
        return CommonUtils.formatCurrency(this.getAnnualSalary());
    }

    /**
     * Sets the annual salary amount
     *
     * @param value
     *            concatenated (dollars and cents) annual salary amount
     */
    public void setAnnualSalary(String value) {
        if ((value != null) && (value.length() != 0)) {
            if (value.length() <= 2) {
                this.annualSalaryDollars = "0";
                this.annualSalaryCents = value;
            } else {
                this.annualSalaryDollars = value.substring(0,
                        value.length() - 2);
                this.annualSalaryCents = value.substring(value.length() - 2);
            }
        }
    }

    /**
     * Returns a String representation of the object.
     *
     * @return description of the object contents
     */
    public String toString() {
        StringBuffer str = new StringBuffer(256);
        str.append("CoverageForm info:");
        str.append("\nspouseExists: ").append(this.spouseExists);

        if (this.coverageItems != null) {
            str.append("\nnumber of CoverageItem objects: ").append(
                    this.coverageItems.size());
            for (int i = 0; i < this.coverageItems.size(); i++) {
                str.append("\n  CoverageItem #").append(i);
                str.append(((CoverageItem) this.coverageItems.get(i))
                        .toString());
            }
        }

        return str.toString();
    }

    /**
     * Gets the coverage class
     *
     * @return coverage class
     */
    public CoverageClass getCoverageClass() {
        return this.coverageClass;
    }

    /**
     * Sets the coverage class
     *
     * @param bean
     *            coverage class
     */
    public void setCoverageClass(CoverageClass bean) {
        this.coverageClass = bean;
    }

    /**
     * Gets the dental premium
     *
     * @return dental premium
     */
    public int getDentalPremium() {
        return this.dentalPremium;
    }

    /**
     * Gets the formatted dental premium
     *
     * @return formatted dental premium
     */
    public String getDentalPremiumFormatted() {
        return CommonUtils.formatCurrency(this.dentalPremium, 4);
    }

    /**
     * Sets the dental premium
     *
     * @param value
     *            dental premium
     */
    public void setDentalPremium(int value) {
        this.dentalPremium = value;
    }

    /**
     * Gets the other dental indicator
     *
     * @return other dental indicator
     */
    public String getOtherDental() {
        return this.otherDental;
    }

    /**
     * Sets the other dental indicator
     *
     * @param value
     *            other dental indicator
     */
    public void setOtherDental(String value) {
        this.otherDental = value;
    }

    /**
     * Gets the spouse dental indicator
     *
     * @return spouse dental indicator or false if there is no spouse coverage
     */
    public String getSpouseDental() {
        return this.spouseExists ? this.spouseDental : "N";
    }

    /**
     * Sets the spouse dental indicator
     *
     * @param value
     *            spouse dental indicator
     */
    public void setSpouseDental(String value) {
        this.spouseDental = value;
    }

    /**
     * Gets the dental dependent count
     *
     * @return dental dependent count
     */
    public int getDentalDependentCount() {
        return this.dentalDependentCount;
    }

    /**
     * Sets the dental dependent count
     *
     * @param dentalDependentCount a int.
     */
    public void setDentalDependentCount(int dentalDependentCount) {
        this.dentalDependentCount = dentalDependentCount;
    }

    /**
     * Gets the dental coverage indicator
     *
     * @return dental coverage indicator
     */
    public boolean getClassHasDentalCoverage() {
        boolean dentalCoverage = false;

        Iterator items = this.coverageItems.iterator();
        while (!dentalCoverage && items.hasNext()) {
            CoverageItem item = (CoverageItem) items.next();
            if (item.getCoverageIsDental()) {
                dentalCoverage = true;
            }
        }

        return dentalCoverage;
    }

    /**
     * Gets the dental coverage indicator
     *
     * @return dental coverage indicator
     */
    public boolean getDentalCoverageAccepted() {
        boolean dentalCoverageAccepted = false;

        Iterator items = this.coverageItems.iterator();
        while (!dentalCoverageAccepted && items.hasNext()) {
            CoverageItem item = (CoverageItem) items.next();
            if (item.getCoverageIsDental() && (item.getAction() == 'S')) {
                dentalCoverageAccepted = true;
            }
        }

        return dentalCoverageAccepted;
    }

    /**
     * Gets the vision coverage indicator
     *
     * @return vision coverage indicator
     */
    public boolean getClassHasVisionCoverage() {
        boolean visionCoverage = false;

        Iterator items = this.coverageItems.iterator();
        while (!visionCoverage && items.hasNext()) {
            CoverageItem item = (CoverageItem) items.next();
            if (item.getCoverageIsVision()) {
                visionCoverage = true;
            }
        }
        return visionCoverage;
    }

    /**
     * Gets the dental coverage indicator
     *
     * @return dental coverage indicator
     */
    public boolean getClassHasAcceptedDentalCoverage() {
        boolean dentalCoverage = false;

        Iterator items = this.coverageItems.iterator();
        while (!dentalCoverage && items.hasNext()) {
            CoverageItem item = (CoverageItem) items.next();
            if (item.getCoverageIsDental() && (item.getAction() == 'S')) {
                dentalCoverage = true;
            }
        }

        return dentalCoverage;
    }

    /**
     * Gets the vision coverage indicator
     *
     * @return vision coverage indicator
     */
    public boolean getClassHasAcceptedVisionCoverage() {
        boolean visionCoverage = false;

        Iterator items = this.coverageItems.iterator();
        while (!visionCoverage && items.hasNext()) {
            CoverageItem item = (CoverageItem) items.next();
            if (item.getCoverageIsVision() && (item.getAction() == 'S')) {
                visionCoverage = true;
            }
        }
        return visionCoverage;
    }

    /**
     * Gets the vision coverage indicator
     *
     * @return vision coverage indicator
     */
    public boolean isVisionCovered() {
        boolean visionCoverage = false;

        Iterator items = this.coverageItems.iterator();
        while (!visionCoverage && items.hasNext()) {
            CoverageItem item = (CoverageItem) items.next();
            if (item.getType().equalsIgnoreCase("26")) {
                visionCoverage = true;
            }
        }

        return visionCoverage;
    }

    /**
     * Gets the annual salary indicator
     *
     * @return annual salary indicator
     */
    public boolean getClassRequiresAnnualSalary() {
        Iterator items = this.coverageItems.iterator();
        while (items.hasNext()) {
            CoverageItem item = (CoverageItem) items.next();
            if (item.getClassRequiresAnnualSalary()
                    && (item.getAction() == CoverageItem.ACTION_ACCEPTED)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Determines the minimum waiting period day
     *
     * @return minimum waiting period day
     */
    public String getMinWaitingPeriodDay() {
        return this.coverageItems.getMinWaitingPeriodDay();
    }

    /**
     * Getter for property givenName.
     *
     * @return Value of property givenName.
     */
    public String getGivenName() {
        return this.givenName;
    }

    /**
     * Setter for property givenName.
     *
     * @param value a {@link java.lang.String} object.
     */
    public void setGivenName(String value) {
        this.givenName = value;
    }

    /**
     * Getter for property lastName.
     *
     * @return Value of property lastName.
     */
    public String getLastName() {
        return this.lastName;
    }

    /**
     * Setter for property lastName.
     *
     * @param value a {@link java.lang.String} object.
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Getter for property middleIni.
     *
     * @return Value of property middleIni.
     */
    public String getMiddleIni() {
        return this.middleIni;
    }

    /**
     * Setter for property middleIni.
     *
     * @param value
     *            New value of property middleIni.
     */
    public void setMiddleIni(String value) {
        this.middleIni = value;
    }

    /**
     * Getter for property dateOfBirth.
     *
     * @return Value of property dateOfBirth.
     */
    public String getDateOfBirthFormatted() {
        return this.dateOfBirth.toString();
    }

    /**
     * Getter for property dateOfBirth.
     *
     * @return Value of property dateOfBirth.
     */
    public DateBean getDateOfBirth() {
        return this.dateOfBirth;
    }

    /**
     * Setter for property dateOfBirth.
     *
     * @param value
     *            New value of property dateOfBirth.
     */
    public void setDateOfBirthFormatted(String value) {
        this.dateOfBirth.parse(value);
    }

    /**
     * Setter for property dateOfBirth.
     *
     * @param bean
     *            New value of property dateOfBirth.
     */
    public void setDateOfBirth(DateBean bean) {
        this.dateOfBirth.setDate(bean);
    }

    /**
     * Getter for property identificationNumber.
     *
     * @return Value of property identificationNumber.
     */
    public String getIdentificationNumber() {
        return this.identificationNumber;
    }

    /**
     * Setter for property identificationNumber.
     *
     * @param value
     *            New value of property identificationNumber.
     */
    public void setIdentificationNumber(String value) {
        this.identificationNumber = value;
    }

    /**
     * Getter for property gender.
     *
     * @return Value of property gender.
     */
    public String getGender() {
        return this.gender;
    }

    /**
     * Getter for the formatted gender label.
     *
     * @return label associated with the value of property gender.
     */
    public String getGenderFormatted() {
        return com.bcbssc.struts.forms.Options.getLabelFromValue(this
                .getOptions().getGenderOptions(), this.gender);
    }

    /**
     * Setter for property gender.
     *
     * @param value
     *            New value of property gender.
     */
    public void setGender(String value) {
        this.gender = value;
    }

    /**
     * Getter for property ssn.
     *
     * @return Value of property ssn.
     */
    public String getSsn() {
        return this.ssn.getValue();
    }

    /**
     * Getter for formatted property ssn.
     *
     * @return Formatted value of property ssn.
     */
    public String getFormattedSsn() {
        return this.ssn.format();
    }

    /**
     * Setter for property ssn.
     *
     * @param value
     *            New value of property ssn.
     */
    public void setSsn(String value) {
        this.ssn.setValue(value);
    }

    /**
     * Getter for property addressLine1.
     *
     * @return Value of property addressLine1.
     */
    public String getAddressLine1() {
        return this.addressLine1;
    }

    /**
     * Setter for property addressLine1.
     *
     * @param addressLine1
     *            New value of property addressLine1.
     */
    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    /**
     * Getter for property addressLine2.
     *
     * @return Value of property addressLine2.
     */
    public String getAddressLine2() {
        return this.addressLine2;
    }

    /**
     * Setter for property addressLine2.
     *
     * @param addressLine2
     *            New value of property addressLine2.
     */
    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    /**
     * Getter for property city.
     *
     * @return Value of property city.
     */
    public String getCity() {
        return this.city;
    }

    /**
     * Setter for property city.
     *
     * @param city
     *            New value of property city.
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * Getter for property state.
     *
     * @return Value of property state.
     */
    public String getState() {
        return this.state;
    }

    /**
     * Getter for the formatted state label.
     *
     * @return label associated with the value of property state.
     */
    public String getFormattedState() {
        return com.bcbssc.struts.forms.Options.getLabelFromValue((List) this
                .getOptions().getUnitedStatesOptions(), this.state);
    }

    /**
     * Setter for property state.
     *
     * @param state
     *            New value of property state.
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * Getter for property zip.
     *
     * @return Value of property zip.
     */
    public String getZip() {
        return this.zip;
    }

    /**
     * Setter for property zip.
     *
     * @param zip
     *            New value of property zip.
     */
    public void setZip(String zip) {
        this.zip = zip;
    }

    /**
     * Gets the telephone number
     *
     * @return telephone number
     */
    public String getTelephoneNumber() {
        return this.telephoneNumber.toString();
    }

    /**
     * Gets the formatted telephone number
     *
     * @return formatted telephone number
     */
    public String getFormattedTelephoneNumber() {
        return this.telephoneNumber.format();
    }

    /**
     * Sets the telephone number
     *
     * @param value
     *            telephone number
     */
    public void setTelephoneNumber(String value) {
        this.telephoneNumber.parse(value);
    }

    /**
     * Getter for property hireDate.
     *
     * @return Value of property hireDate.
     */
    public String getHireDateFormatted() {
        if (InsuredDataForm.log.isDebugEnabled()) {
            InsuredDataForm.log
                    .debug("getHireDateFormatted(), hireDate value is"
                            + this.hireDate.toString());
        }
        return this.hireDate.toString();
    }

    /**
     * Getter for property hireDate.
     *
     * @return Value of property hireDate.
     */
    public DateBean getHireDate() {
        if (InsuredDataForm.log.isDebugEnabled()) {
            InsuredDataForm.log.debug("getHireDate(), hireDate value is"
                    + this.hireDate);
        }
        return this.hireDate;
    }

    /**
     * Setter for property hireDate.
     *
     * @param value
     *            New value of property hireDate.
     */
    public void setHireDateFormatted(String value) {
        this.hireDate.parse(value);
    }

    /**
     * Setter for property hireDate.
     *
     * @param bean
     *            New value of property hireDate.
     */
    public void setHireDate(DateBean bean) {
        this.hireDate.setDate(bean);
    }

    /**
     * Getter for property changeEffectiveDate.
     *
     * @return Value of property changeEffective.
     */
    public DateBean getChangeEffectiveDate() {
        if (InsuredDataForm.log.isDebugEnabled()) {
            InsuredDataForm.log
                    .debug("getChangeEffectiveDate(), changeEffectiveDate value is"
                            + this.changeEffectiveDate);
        }
        return this.changeEffectiveDate;
    }

    /**
     * Returns changeEffectiveDate as a DateBean.
     *
     * @return changeEffectiveDate as a DateBean.
     */
    public DateBean getChangeEffectiveDateAsDateBean() {
        if (InsuredDataForm.log.isDebugEnabled()) {
            InsuredDataForm.log
                    .debug("getChangeEffectiveDateAsDateBean(), changeEffectiveDate value is"
                            + this.changeEffectiveDate);
        }
        return this.changeEffectiveDate;
    }

    /**
     * Setter for property changeEffectiveDate.
     *
     * @param value
     *            New value of property changeEffective.
     */
    public void setChangeEffectiveDate(FormDate value) {
        this.changeEffectiveDate = value;
    }

    /**
     * Returns changeEffectiveDate as a String.
     *
     * @return changeEffectiveDate as a String.
     */
    public String getChangeEffectiveDateFormatted() {
        if (InsuredDataForm.log.isDebugEnabled()) {
            InsuredDataForm.log
                    .debug("getChangeEffectiveDateFormatted(), changeEffectiveDate value is"
                            + this.changeEffectiveDate.toString());
        }
        return this.changeEffectiveDate.toString();
    }

    /**
     * Setter for property changeEffectiveDateFormatted.
     *
     * @param value
     *            New value of property changeEffective.
     */
    public void setChangeEffectiveDateFormatted(String value) {
        this.changeEffectiveDate.parse(value);
    }

    /**
     * Getter for property salaryChangeEffectiveDate.
     *
     * @return Value of property salaryChangeEffectiveDate.
     */
    public DateBean getSalaryChangeEffectiveDate() {
        if (InsuredDataForm.log.isDebugEnabled()) {
            InsuredDataForm.log
                    .debug("getSalaryChangeEffectiveDate(), salaryChangeEffectiveDate value is"
                            + this.salaryChangeEffectiveDate);
        }
        return this.salaryChangeEffectiveDate;
    }

    /**
     * Returns salaryChangeEffectiveDate as a DateBean.
     *
     * @return salaryChangeEffectiveDate as a DateBean.
     */
    public DateBean getSalaryChangeEffectiveDateAsDateBean() {
        if (InsuredDataForm.log.isDebugEnabled()) {
            InsuredDataForm.log
                    .debug("getSalaryChangeEffectiveDateAsDateBean(), salaryChangeEffectiveDate value is"
                            + this.salaryChangeEffectiveDate);
        }
        return this.salaryChangeEffectiveDate;
    }

    /**
     * Setter for property salaryChangeEffectiveDate.
     *
     * @param value
     *            New value of property salaryChangeEffectiveDate.
     */
    public void setSalaryChangeEffectiveDate(FormDate value) {
        this.salaryChangeEffectiveDate = value;
    }

    /**
     * Returns salaryChangeEffectiveDate as a String.
     *
     * @return salaryChangeEffectiveDate as a String.
     */
    public String getSalaryChangeEffectiveDateFormatted() {
        if (InsuredDataForm.log.isDebugEnabled()) {
            InsuredDataForm.log
                    .debug("getSalaryChangeEffectiveDateFormatted(), salaryChangeEffectiveDate value is"
                            + this.salaryChangeEffectiveDate.toString());
        }
        return this.salaryChangeEffectiveDate.toString();
    }

    /**
     * Setter for property salaryChangeEffectiveDateFormatted.
     *
     * @param value
     *            New value of property salaryChangeEffective.
     */
    public void setSalaryChangeEffectiveDateFormatted(String value) {
        this.salaryChangeEffectiveDate.parse(value);
    }

    /**
     * Formatted getter for property effectiveDate.
     *
     * @return Value of property effectiveDate.
     */
    public String getOriginalEffectiveDateFormatted() {
        if (InsuredDataForm.log.isDebugEnabled()) {
            InsuredDataForm.log
                    .debug("getOriginalEffectiveDateFormatted(), effectiveDate value is"
                            + this.effectiveDate.toString());
        }
        return this.effectiveDate.toString();
    }

    /**
     * Getter for property effectiveDate.
     *
     * @return Value of property effectiveDate.
     */
    public DateBean getOriginalEffectiveDate() {
        if (InsuredDataForm.log.isDebugEnabled()) {
            InsuredDataForm.log
                    .debug("getOriginalEffectiveDate(), effectiveDate value is"
                            + this.effectiveDate);
        }
        return this.effectiveDate;
    }

    /**
     * Formatted setter for property effectiveDate.
     *
     * @param value
     *            New value of property effectiveDate.
     */
    public void setOriginalEffectiveDateFormatted(String value) {
        this.effectiveDate.parse(value);
    }

    /**
     * Setter for property effectiveDate.
     *
     * @param bean
     *            New value of property effectiveDate.
     */
    public void setOriginalEffectiveDate(DateBean bean) {
        this.effectiveDate.setDate(bean);
    }

    /**
     * Formatted getter for property divisionOriginalEffectiveDate.
     *
     * @return Value of property divisionOriginalEffectiveDate.
     */
    public String getDivisionOriginalEffectiveDateFormatted() {
        if (InsuredDataForm.log.isDebugEnabled()) {
            InsuredDataForm.log
                    .debug("getDivisionOriginalEffectiveDateFormatted(), divisionOriginalEffectiveDate is"
                            + this.divisionOriginalEffectiveDate.toString());
        }
        return this.divisionOriginalEffectiveDate.toString();
    }

    /**
     * Getter for property divisionOriginalEffectiveDate.
     *
     * @return Value of property divisionOriginalEffectiveDate.
     */
    public DateBean getDivisionOriginalEffectiveDate() {
        if (InsuredDataForm.log.isDebugEnabled()) {
            InsuredDataForm.log
                    .debug("getDivisionOriginalEffectiveDate(), divisionOriginalEffectiveDate is"
                            + this.divisionOriginalEffectiveDate);
        }
        return this.divisionOriginalEffectiveDate;
    }

    /**
     * Formatted setter for property divisionOriginalEffectiveDate.
     *
     * @param value
     *            New value of property divisionOriginalEffectiveDate.
     */
    public void setDivisionOriginalEffectiveDateFormatted(String value) {
        this.divisionOriginalEffectiveDate.parse(value);
    }

    /**
     * Setter for property divisionOriginalEffectiveDate.
     *
     * @param bean
     *            New value of property divisionOriginalEffectiveDate.
     */
    public void setDivisionOriginalEffectiveDate(DateBean bean) {
        this.divisionOriginalEffectiveDate.setDate(bean);
    }

    /**
     * Formatted getter for property lastProcessedDate.
     *
     * @return Value of property lastProcessedDate.
     */
    public String getLastProcessedDateFormatted() {
        if (InsuredDataForm.log.isDebugEnabled()) {
            InsuredDataForm.log
                    .debug("getLastProcessedDateFormatted(), lastProcessedDate value is"
                            + this.lastProcessedDate.toString());
        }
        return this.lastProcessedDate.toString();
    }

    /**
     * Getter for property lastProcessedDate.
     *
     * @return Value of property lastProcessedDate.
     */
    public DateBean getLastProcessedDate() {
        if (InsuredDataForm.log.isDebugEnabled()) {
            InsuredDataForm.log
                    .debug("getLastProcessedDate(), lastProcessedDate value is"
                            + this.lastProcessedDate);
        }
        return this.lastProcessedDate;
    }

    /**
     * Formatted setter for property lastProcessedDate.
     *
     * @param value
     *            New value of property lastProcessedDate.
     */
    public void setLastProcessedDateFormatted(String value) {
        this.lastProcessedDate.parse(value);
    }

    /**
     * Setter for property lastProcessedDate.
     *
     * @param value
     *            New value of property lastProcessedDate.
     */
    public void setLastProcessedDate(DateBean value) {
        this.lastProcessedDate.setDate(value);
    }

    /**
     * Formatted getter for property terminationDate.
     *
     * @return Value of property terminationDate.
     */
    public String getTerminationDateFormatted() {
        if (InsuredDataForm.log.isDebugEnabled()) {
            InsuredDataForm.log
                    .debug("getTerminationDateFormatted(), terminationDate value is"
                            + this.terminationDate.toString());
        }
        return this.terminationDate.toString();
    }

    /**
     * Getter for property terminationDate.
     *
     * @return Value of property terminationDate.
     */
    public DateBean getTerminationDate() {
        if (InsuredDataForm.log.isDebugEnabled()) {
            InsuredDataForm.log
                    .debug("getTerminationDate(), terminationDate value is"
                            + this.terminationDate);
        }
        return this.terminationDate;
    }

    /**
     * Formatted setter for property terminationDate.
     *
     * @param value
     *            New value of property terminationDate.
     */
    public void setTerminationDateFormatted(String value) {
        this.terminationDate.parse(value);
    }

    /**
     * Setter for property terminationDate.
     *
     * @param value
     *            New value of property terminationDate.
     */
    public void setTerminationDate(DateBean value) {
        this.terminationDate.setDate(value);
    }

    /**
     * Getter for property department.
     *
     * @return Value of property department.
     */
    public String getDepartment() {
        return this.department;
    }

    /**
     * Setter for property department.
     *
     * @param value
     *            New value of property department.
     */
    public void setDepartment(String value) {
        this.department = value;
    }

    /**
     * Getter for property payrollOfficeIdentifier.
     *
     * @return Value of property payrollOfficeIdentifier.
     */
    public String getPayrollOfficeIdentifier() {
        return this.payrollOfficeIdentifier;
    }

    /**
     * Setter for property payrollOfficeIdentifier.
     *
     * @param payrollOfficeIdentifier
     *            New value of property payrollOfficeIdentifier.
     */
    public void setPayrollOfficeIdentifier(String payrollOfficeIdentifier) {
        this.payrollOfficeIdentifier = payrollOfficeIdentifier;
    }

    /**
     * Getter for property occupation.
     *
     * @return Value of property occupation.
     */
    public String getOccupation() {
        return this.occupation;
    }

    /**
     * Setter for property occupation.
     *
     * @param occupation
     *            New value of property occupation.
     */
    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    /**
     * Getter for property cobra.
     *
     * @return Value of property cobra.
     */
    public String getCobra() {
        return this.cobra;
    }

    /**
     * Getter for the formatted cobra label.
     *
     * @return label associated with the value of property cobra.
     */
    public String getFormattedCobra() {
        return com.bcbssc.struts.forms.Options.getLabelFromValue(this
                .getOptions().getNoYesOptions(), this.cobra);
    }

    /**
     * Setter for property cobra.
     *
     * @param value
     *            New value of property cobra.
     */
    public void setCobra(String value) {
        this.cobra = value;
    }

    /**
     * Getter for property smoker.
     *
     * @return Value of property smoker.
     */
    public String getSmoker() {
        return this.smoker;
    }

    /**
     * Getter for the formatted smoker label.
     *
     * @return label associated with the value of property smoker.
     */
    public String getFormattedSmoker() {
        return com.bcbssc.struts.forms.Options.getLabelFromValue(this
                .getOptions().getSmokerOptions(), this.smoker);
    }

    /**
     * Setter for property smoker.
     *
     * @param smoker
     *            New value of property smoker.
     */
    public void setSmoker(String smoker) {
        this.smoker = smoker;
    }

    /**
     * Getter for spouse.
     *
     * @return spouse
     */
    public Dependent getSpouse() {
        return this.spouse;
    }

    /**
     * Setter for spouse.
     *
     * @param bean
     *            spouse
     */
    public void setSpouse(Dependent bean) {
        this.spouse = bean;
    }

    /**
     * Getter for property averageHoursWorked.
     *
     * @return Value of property averageHoursWorked.
     */
    public String getAverageHoursWorked() {
        return this.averageHoursWorked;
    }

    /**
     * Gets a the first effective date in the coverage item list
     *
     * @return first effective date in coverage item list
     */
    public String getFirstEffectiveDateFormatted() {
        FormDate firstDate = new FormDate();
        firstDate.setDate(this.coverageItems.getFirstEffectiveDate());
        return firstDate.toString();
    }

    /**
     * Setter for property averageHoursWorked.
     *
     * @param averageHoursWorked
     *            New value of property averageHoursWorked.
     */
    public void setAverageHoursWorked(String averageHoursWorked) {
        this.averageHoursWorked = averageHoursWorked;
    }

    /**
     * Getter for property terminationReason.
     *
     * @return Value of property terminationReason.
     */
    public String getTerminationReason() {
        return this.terminationReason;
    }

    /**
     * Getter for formatted property terminationReason.
     *
     * @return Formatted value of property terminationReason.
     */
    public String getTerminationReasonFormatted() {
        return com.bcbssc.struts.forms.Options.getLabelFromValue(this
                .getOptions().getTerminationReasonOptions(),
                this.terminationReason);
    }

    /**
     * Setter for property terminationReason.
     *
     * @param terminationReason
     *            New value of property terminationReason.
     */
    public void setTerminationReason(String terminationReason) {
        this.terminationReason = terminationReason;
    }

    /**
     * Getter for property alternateID.
     *
     * @return Value of property alternateID.
     */
    public String getAlternateID() {
        return this.alternateID;
    }

    /**
     * Setter for property alternateID.
     *
     * @param alternateID
     *            New value of property alternateID.
     */
    public void setAlternateID(String alternateID) {
        this.alternateID = alternateID;
    }

    /**
     * Getter for property status.
     *
     * @return Value of property status.
     */
    public String getStatus() {
        return this.status;
    }

    /**
     * Gets the formatted status value
     *
     * @return formatted status value
     */
    public String getStatusFormatted() {
        return com.bcbssc.struts.forms.Options.getLabelFromValue(this
                .getOptions().getStatusOptions(), this.status);
    }

    /**
     * Setter for property status.
     *
     * @param status
     *            New value of property status.
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Creates (if necessary) and gets the object-common InsuredServices object
     *
     * @return an InsuredServices object
     */
    protected InsuredServices getInsuredServices() {
        if (this.insuredServices == null) {
            String iniFile = CommonUtils.getIniFile(this.getServlet());
            String gcomIniFile = CommonUtils.getGcomIniFile(this.getServlet());
            this.insuredServices = new InsuredServices(iniFile, gcomIniFile,
                    null);
        }
        return this.insuredServices;
    }

    /**
     * Getter for property addNewGroup.
     *
     * @return Value of property addNewGroup.
     */
    public boolean isAddNewGroup() {
        return this.addNewGroup;
    }

    /**
     * Setter for property addNewGroup.
     *
     * @param addNewGroup
     *            New value of property addNewGroup.
     */
    public void setAddNewGroup(boolean addNewGroup) {
        this.addNewGroup = addNewGroup;
    }

    /**
     * Gets the group number
     *
     * @return group number
     */
    public String getGroupNumber() {
        return this.groupNumber;
    }

    /**
     * get the group number nicely formatted ex. cccppgggggddd = ccc pp ggggg
     * ddd 3 5 10 (indexes)
     *
     * @return a {@link java.lang.String} object.
     */
    public String getGroupNumberFormatted() {
        String returnString = null;
        if (this.groupNumber == null) {
            returnString = com.bcbssc.struts.common.Constants.BLANK_STRING;
        } else {
            StringBuffer retVal = new StringBuffer(20);
            retVal.append(this.groupNumber);
            int len = this.groupNumber.length();
            // accomodate 13, 10, 5 or 3 length numbers
            // without tossing an exception
            if (len > 10) {
                retVal.insert(10, " ");
            }
            if (len > 10) {
                retVal.insert(5, " ");
            }
            if (len > 10) {
                retVal.insert(3, " ");
            }
            returnString = retVal.toString();
        }
        return returnString;
    }

    /**
     * Sets the group number
     *
     * @param value
     *            group number
     */
    public void setGroupNumber(String value) {
        this.groupNumber = value;
    }

    /**
     * Gets the division name
     *
     * @return division name
     */
    public String getDivisionName() {
        return this.divisionName;
    }

    /**
     * Sets the division name
     *
     * @param value
     *            division name
     */
    public void setDivisionName(String value) {
        this.divisionName = value;
    }

    /**
     * Getter for property terminationDate.
     *
     * @return Value of property terminationDate.
     */
    public DateBean getLastBillDate() {
        return this.lastBillDate;
    }

    /**
     * Formatted getter for property lastBillDate.
     *
     * @return Value of property lastBillDate.
     */
    public String getLastBillDateFormatted() {
        return this.lastBillDate.toString();
    }

    /**
     * Formatted setter for property lastBillDate.
     *
     * @param value
     *            New value of property lastBillDate.
     */
    public void setLastBillDateFormatted(String value) {
        this.lastBillDate.parse(value);
    }

    /**
     * Setter for property lastBillDate.
     *
     * @param value
     *            New value of property lastBillDate.
     */
    public void setLastBillDate(DateBean value) {
        this.lastBillDate.setDate(value);
    }

    /**
     * Getter for property bill due date.
     *
     * @return Value of property bill due date.
     */
    public DateBean getBillDueDate() {
        return this.billDueDate;
    }

    /**
     * Formatted getter for property billDueDate.
     *
     * @return Value of property billDueDate.
     */
    public String getBillDueDateFormatted() {
        return this.billDueDate.toString();
    }

    /**
     * Formatted setter for property billDueDate.
     *
     * @param value
     *            New value of property billDueDate.
     */
    public void setBillDueDateFormatted(String value) {
        this.billDueDate.parse(value);
    }

    /**
     * Setter for property billDueDate date.
     *
     * @param value
     *            New value of property billDueDate date.
     */
    public void setBillDueDate(DateBean value) {
        this.billDueDate.setDate(value);
    }

    /**
     * Sets the groupNumber and divsionName based on a groupNumber|divisionName
     * value.
     *
     * @param value a {@link java.lang.String} object.
     */
    public void setGroup(String value) {
        this.groupData = value;

        RE regexp = null;
        try {
            regexp = new RE("\\|");
        } catch (RESyntaxException rese) {
            InsuredDataForm.log.error("error creating regex for group split",
                    rese);
            // Let the ensuing nullpointerexception deal initiate flow
            // interruption
        }
        if (regexp != null) {
            String[] tokens = regexp.split(value);
            switch (tokens.length) {
            case 5:
                this.setBillDueDateFormatted(tokens[4]);
            case 4:
                this.setDivisionOriginalEffectiveDateFormatted(tokens[3]);
            case 3:
                this.setLastBillDateFormatted(tokens[2]);
            case 2:
                this.divisionName = tokens[1];
            case 1:
                this.groupNumber = tokens[0];
                break;
            default:
                // do nothing
                break;
            }
        }
    }

    /**
     * Gets the group number|division for the selected or default group
     *
     * @return group number|division for the selected or default group
     */
    public String getGroup() {
        if (this.groupData != null) {
            return this.groupData;
        } else if (this.groupNumber.length() > 0) {
            StringBuffer group = new StringBuffer(64);
            group.append(this.groupNumber).append(
                    com.bcbssc.struts.common.Constants.PIPE_SEPARATOR);
            group.append(this.divisionName).append(
                    com.bcbssc.struts.common.Constants.PIPE_SEPARATOR);
            group.append(this.getLastBillDateFormatted()).append(
                    com.bcbssc.struts.common.Constants.PIPE_SEPARATOR);
            group.append(this.getDivisionOriginalEffectiveDateFormatted())
                    .append(com.bcbssc.struts.common.Constants.PIPE_SEPARATOR);
            group.append(this.getBillDueDateFormatted());
            return group.toString();
        } else {
            this.setGroup(this.getDefaultGroupOption());
            return this.groupData;
        }
    }

    /**
     * Gets the group options list from ODBC
     *
     * @return group options list
     * @throws java.lang.Exception
     *             if error occurs during group option query
     */
    public Collection getGroupOptions() throws Exception {
        if ((this.groupOptions == null) && (this.getServlet() != null)) {
            String iniFile = CommonUtils.getIniFile(this.getServlet());
            String gcomIniFile = CommonUtils.getGcomIniFile(this.getServlet());
            InsuredServices insuredServices = new InsuredServices(iniFile,
                    gcomIniFile, this.userDTO);
            this.groupOptions = insuredServices.getGroupOptions(this.userDTO);
        }

        return this.groupOptions;
    }

    /**
     * Gets the default group option
     *
     * @return default group option
     */
    protected String getDefaultGroupOption() {
        if (this.groupOptions == null) {
            try {
                this.getGroupOptions();
            } catch (Exception e) {
                InsuredDataForm.log.error(e.toString());
                // This exception will be reported when the form creates the
                // dropdown
                return com.bcbssc.struts.common.Constants.BLANK_STRING;
            }
        }
        return com.bcbssc.struts.common.CommonUtils
                .getDefaultOption(this.groupOptions);
    }

    /**
     * Getter for property nemIndicator.
     *
     * @return Value of property nemIndicator.
     */
    public boolean getNemIndicator() {
        return this.nemIndicator;
    }

    /**
     * Setter for property nemIndicator.
     *
     * @param nemIndicator
     *            New value of property nemIndicator.
     */
    public void setNemIndicator(boolean nemIndicator) {
        this.nemIndicator = nemIndicator;
    }

    /**
     * Getter for property employeeStatus.
     *
     * @return Value of property employeeStatus.
     */
    public String getEmployeeStatus() {
        return this.employeeStatus;
    }

    /**
     * Setter for property employeeStatus.
     *
     * @param employeeStatus
     *            New value of property employeeStatus.
     */
    public void setEmployeeStatus(String employeeStatus) {
        this.employeeStatus = employeeStatus;
    }

    /**
     * Getter for property rateBasisCode.
     *
     * @return Value of property rateBasisCode.
     */
    public String getRateBasisCode() {
        return this.rateBasisCode;
    }

    /**
     * Setter for property rateBasisCode.
     *
     * @param rateBasisCode
     *            New value of property rateBasisCode.
     */
    public void setRateBasisCode(String rateBasisCode) {
        this.rateBasisCode = rateBasisCode;
    }

    /**
     * Getter for property spouseIndicator.
     *
     * @return Value of property spouseIndicator.
     */
    public String getSpouseIndicator() {
        return this.spouseIndicator;
    }

    /**
     * Setter for property spouseIndicator.
     *
     * @param spouseIndicator
     *            New value of property spouseIndicator.
     */
    public void setSpouseIndicator(String spouseIndicator) {
        this.spouseIndicator = spouseIndicator;
    }

    /**
     * Getter for property dentalCoverage.
     *
     * @return Value of property dentalCoverage.
     */
    public boolean getDentalCoverage() {
        return this.dentalCoverage;
    }

    /**
     * Getter for property insuredPageUpdated.
     *
     * @return Value of property insuredPageUpdated.
     */
    public boolean isInsuredPageUpdated() {
        return false;
    }

    /**
     * Getter for property coveragePageUpdated.
     *
     * @return Value of property coveragePageUpdated.
     */
    public boolean isCoveragePageUpdated() {
        return false;
    }

    /**
     * Getter for property dependentPageUpdated.
     *
     * @return Value of property dependentPageUpdated.
     */
    public boolean isDependentPageUpdated() {
        return false;
    }

    /**
     * Getter for property salaryPageUpdated.
     *
     * @return Value of property salaryPageUpdated.
     */
    public boolean isSalaryPageUpdated() {
        return false;
    }

    /**
     * Setter for userDTO
     *
     * @param userDTO
     *            New value of property userDTO.
     */
    public void setUserDTO(GroupAdminUserDTO userDTO) {
        this.userDTO = userDTO;
    }

    /**
     * Getter for userDTO
     *
     * @return a {@link com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO} object.
     */
    public GroupAdminUserDTO getUserDTO() {
        return this.userDTO;
    }

    /**
     * {@inheritDoc}
     *
     * Validates the form using the validator support provided by the parent.
     * Also verifies that the passwords match.
     */
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {

        this.userDTO = (GroupAdminUserDTO) request
                .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO);

        ActionErrors retVal = super.validate(mapping, request);
        // createSummary was removed because it was creating duplicate
        // action errors.

        // ActionSummary.createSummary(retVal);

        return retVal;
    }

    /**
     * <p>Getter for the field <code>visionPremium</code>.</p>
     *
     * @return Returns the visionPremium.
     */
    public int getVisionPremium() {
        return this.visionPremium;
    }

    /**
     * <p>Setter for the field <code>visionPremium</code>.</p>
     *
     * @param visionPremium
     *            The visionPremium to set.
     */
    public void setVisionPremium(int visionPremium) {
        this.visionPremium = visionPremium;
    }

    /**
     * Gets the formatted dental premium
     *
     * @return formatted dental premium
     */
    public String getVisionPremiumFormatted() {
        return CommonUtils.formatCurrency(this.visionPremium, 4);
    }

    /**
     * <p>Getter for the field <code>visionCoverage</code>.</p>
     *
     * @return Returns the visionCoverage.
     */
    public boolean getVisionCoverage() {
        return this.visionCoverage;
    }

    /**
     * <p>Setter for the field <code>visionCoverage</code>.</p>
     *
     * @param visionCoverage
     *            The visionCoverage to set.
     */
    public void setVisionCoverage(boolean visionCoverage) {
        this.visionCoverage = visionCoverage;
    }

    /**
     * <p>Getter for the field <code>dentalCoverageStr</code>.</p>
     *
     * @return Returns the dentalCoverageStr.
     */
    public String getDentalCoverageStr() {
        return this.dentalCoverageStr;
    }

    /**
     * <p>Setter for the field <code>dentalCoverageStr</code>.</p>
     *
     * @param dentalCoverageStr
     *            The dentalCoverageStr to set.
     */
    public void setDentalCoverageStr(String dentalCoverageStr) {
        this.dentalCoverage = Boolean.valueOf(dentalCoverageStr).booleanValue();
        this.dentalCoverageStr = dentalCoverageStr;
        InsuredDataForm.log.debug("dentalCoverageStr=" + dentalCoverageStr);
    }

    /**
     * <p>Getter for the field <code>visionCoverageStr</code>.</p>
     *
     * @return Returns the visionCoverageStr.
     */
    public String getVisionCoverageStr() {
        return this.visionCoverageStr;
    }

    /**
     * <p>Setter for the field <code>visionCoverageStr</code>.</p>
     *
     * @param visionCoverageStr
     *            The visionCoverageStr to set.
     */
    public void setVisionCoverageStr(String visionCoverageStr) {
        this.visionCoverage = Boolean.valueOf(visionCoverageStr).booleanValue();
        this.visionCoverageStr = visionCoverageStr;
        InsuredDataForm.log.debug("visionCoverageStr=" + visionCoverageStr);
    }

    /**
     * <p>Setter for the field <code>dentalCoverage</code>.</p>
     *
     * @param dentalCoverage
     *            The dentalCoverage to set.
     */
    public void setDentalCoverage(boolean dentalCoverage) {
        this.dentalCoverage = dentalCoverage;
    }

}
