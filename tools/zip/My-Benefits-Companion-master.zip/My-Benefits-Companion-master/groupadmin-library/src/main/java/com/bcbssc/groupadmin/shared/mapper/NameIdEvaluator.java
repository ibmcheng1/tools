/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mapper/NameIdEvaluator.java_v  $
 * $Workfile:   NameIdEvaluator.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:15:54  $
 * $Modtime:   May 14 2009 11:33:30  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mapper/NameIdEvaluator.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:15:54   EN80
 * Initial revision.
 * 
 *    Rev 1.0   May 04 2005 09:28:34   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.mapper;

import java.text.DecimalFormat;

import com.bcbssc.netsys.web.AbstractValueEvaluator;
import org.apache.log4j.Logger;

/**
 * Evaluates the Name ID for a dependent.
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class NameIdEvaluator extends AbstractValueEvaluator {

    /** The Log4J <code>Logger</code> for this class. */
    private static final Logger log = Logger.getLogger(NameIdEvaluator.class);

    /**
     * Implements the actual evaluation.
     *
     * @return the evaluation output.
     */
    protected Object doEvaluate() {
        final String transaction = getParameterValue("transaction");
        final String index = getParameterValue("index");
        final String nameId = getParameterValue("nameId");

        if (log.isDebugEnabled()) {
            log.debug("transaction=" + transaction);
            log.debug("index=" + index);
            log.debug("nameId=" + nameId);
        }

        String returnString;

        if ("205".equals(transaction)) {
            returnString = new DecimalFormat("000").format(Integer.parseInt(index));
        } else {
            returnString = nameId;
        }

        return returnString;
    }
}
