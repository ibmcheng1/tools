/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/CoveragesQuery.java_v  $
 * $Workfile:   CoveragesQuery.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:08  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/CoveragesQuery.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:14:08   EN80
 * Initial revision.
 * 
 *    Rev 1.19   Apr 28 2009 10:17:52   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.18   Oct 10 2007 21:09:18   rx29e
 * 20 Day Waiting period changes. Configurable waiting period codes based on the calculation category.
 * 
 *    Rev 1.17   May 16 2006 16:33:12   rx08e
 * Changed to include the vision coverages to be retrieved.
 *
 *    Rev 1.16   Apr 27 2006 10:26:36   rx08e
 * Changes to not get the vision information. This would be removed once the vision changes are implemented.
 *
 *    Rev 1.15   Apr 11 2006 14:45:06   r8981
 * C09312 - 0610152874
 * correct waiting period code that generates the coverage effective date for groupadmin
 *
 *    Rev 1.14   Oct 20 2005 13:42:02   rcf57
 * C03785 : Added additional logging.
 *
 *    Rev 1.13   Mar 10 2005 10:05:38   rdq70
 * Added coverageEvidence. Restored premium to match QualifiedCoveragesQuery.
 *
 *    Rev 1.12   Mar 09 2005 13:52:12   rdq70
 * Restored single performSearch(). Set coverageStatus.
 *
 *    Rev 1.11   Mar 09 2005 11:36:58   rdq70
 * Corrected premium.
 *
 *    Rev 1.10   Mar 07 2005 17:08:12   rdq70
 * Split performSearch() into performViewSearch() and performChangeSearch().
 *
 *    Rev 1.9   Mar 03 2005 12:51:02   rdq70
 * Added ceaseReason.
 *
 *    Rev 1.8   Mar 02 2005 14:40:54   rxr93
 * padd wait period code to 3
 *
 *    Rev 1.7   Feb 16 2005 09:41:56   rdq70
 * Removed SQL formatting of action.
 *
 *    Rev 1.6   Feb 14 2005 11:31:22   rdq70
 * Added premium.
 *
 *    Rev 1.5   Feb 10 2005 16:03:58   rdq70
 * Shift percent salary 4 places instead of 2 since it has 4 decimals in the database and in the MQ.
 *
 *    Rev 1.4   Feb 07 2005 13:50:38   rdq70
 * Incorporated SQL revisions.
 *
 *    Rev 1.3   Feb 04 2005 17:24:54   rdq70
 * Incorporated SQL updates.
 *
 *    Rev 1.2   Feb 03 2005 13:30:24   rdq70
 * Javadoc correction.
 *
 *    Rev 1.1   Feb 03 2005 10:49:52   rdq70
 * Renamed MQ_TABLE to GCOM_TABLE.
 *
 *    Rev 1.0   Feb 02 2005 14:54:50   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.dbaccess;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.dto.CoverageItem;
import com.bcbssc.groupadmin.shared.dto.CoverageItemList;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

import org.apache.log4j.Logger;

/**
 * This query retrieves the coverage information for the insured employee.<br>
 *
 * <pre>
 *     QMF NAME: RX13U.WEB_SQL_5_C
 *     TSO NAME: WEBSQL5C
 * </pre>
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class CoveragesQuery extends AbstractDBSearch {

	/** The log4j logger for this class. */
	private static final Logger log = Logger.getLogger(CoveragesQuery.class);

	/**
	 * Creates an <code>CoveragesQuery</code> and configures it with an INI
	 * file.
	 *
	 * @param iniFile
	 *            file path of the configuration INI file.
	 */
	public CoveragesQuery(String iniFile) {
		super(iniFile, "GCOM_TABLE");
	}

	/**
	 * Retrieves the coverage information for the insured employee and adds it
	 * to the given parent bean.<br>
	 *
	 * <pre>
	 *     QMF NAME: RX13U.WEB_SQL_5_C
	 *     TSO NAME: WEBSQL5C
	 * </pre>
	 *
	 * @param insuredData
	 *            the bean containing data for the search. It needs only the
	 *            groupNumber, identificationNumber and coverageClass properties
	 *            set.
	 * @return the <code>CoverageItemList</code> of the the given
	 *         <code>insuredData</code> populated with the search results.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 * @see com.bcbssc.groupadmin.shared.dto.CoverageItemList
	 */
	public Collection performSearch(InsuredDataDTO insuredData)
			throws SQLException {
		this.checkInit(); // Necessary since we need the _dbSchema before the
							// query creation

		final String division = insuredData.getDivisionCode();

		final String[] params = { insuredData.getCompany(),
				insuredData.getGroupPrefix(), insuredData.getGroupBase(),
				division, insuredData.getIdentificationNumber(),
				insuredData.getCoverageClass().getCode() };

		return this.performSearch(this.getSql(division), params, insuredData
				.getCoverageItems());
	}

	/**
	 * {@inheritDoc}
	 *
	 * Adds data from the given result set to the target collection.
	 * @see com.bcbssc.groupadmin.shared.dto.CoverageItemList
	 */
	protected void addSearchItem(ResultSet data, Object obj)
			throws SQLException {
		final CoverageItemList list = (CoverageItemList) obj;
		final CoverageItem item = new CoverageItem(list.getInsuredDatasource());

		item.setAction(data.getString("CC_CVG_RFSD").charAt(0));
		item.setName(data.getString("CVG_DESC").trim());
		item.setPercentSalary(data.getBigDecimal("VOLM_FCTR").multiply(
				BigDecimal.valueOf(10000L)).intValue());
		item.setVolume(data.getBigDecimal("CC_VOL_CVRD").intValue());
		item.setMinimumVolume(data.getInt("MIN_VOLM"));
		item.setMaximumVolume(data.getInt("MAX_VOLM"));
		item.setPremium(data.getBigDecimal("BILL_PREM_MO_UNIT").multiply(
				BigDecimal.valueOf(10000L)).intValue());
		item.setWaitingPeriod(Integer.parseInt(data.getString(
				"WAIT_PERIOD_DAYS").trim()));

		item.setWaitPeriodCalculationCategory(data.getString(
				"WAIT_PERIOD_CALC_C").trim());

		if (CoveragesQuery.log.isDebugEnabled()) {
			CoveragesQuery.log
					.debug("addSearchItem() - waiting period value in coverage item"
							+ item.getWaitingPeriod());
		}
		item.setEffectiveDateFormatted(data.getString("EFFECTIVE_DATE"));
		if (CoveragesQuery.log.isDebugEnabled()) {
			CoveragesQuery.log
					.debug("addSearchItem() - effectiveDate value in the coverage item"
							+ item.getEffectiveDateFormatted());
		}
		item.setCeaseReason(data.getString("CC_CEASE_REAS").charAt(0));
		item.setCoverageStatus(data.getString("CC_CVG_STAT"));
		item.setCode(data.getString("COVERAGE").trim());
		item.setEmployerPercentInsurance(data
				.getBigDecimal("EMPLR_CONTRIB_PCT").multiply(
						BigDecimal.valueOf(100L)).intValue());
		item.setSubstandardFactor(data.getBigDecimal("SUBSTD_FCTR")
				.doubleValue());
		item.setLineOfBusiness(data.getString("LINE_OF_BUS").trim());
		item.setCoverageEvidence(data.getString("CC_CVG_EVID"));
		item.setVolumeBasis(Integer.parseInt(data.getString("VOLM_BAS_CD")));
		item.setNoEvidenceMaxVolume(data.getInt("NO_EVDNC_MAX_VOLM"));
		item.setRoundCode(data.getString("RNDG_CNTL_CD"));
		item.setRoundVolume(data.getInt("RNDG_VOLM_AMT"));
		item.setWaitingPeriodForMq(data.getInt("WAIT_PERD"));
		item.setWaitingPeriodCode(CommonUtils.padValue(data
				.getString("WAIT_PERD"), '0', 3));
		item.setWaitingPeriodDay(data.getString("FRST_DAY_MTH"));
		// item.(data.getInt("FLAT_UNIT_VOLM"));
		item.setRelationshipType(data.getString("ALLW_PARTICP"));
		item.setUnitFactor(data.getInt("UNIT_FCTR"));
		item.setBaseUnit(data.getBigDecimal("BASE_UNIT").doubleValue());
		item.setType(data.getString("CVG_TYP").trim());
		// item.(data.getString("DIV EFF DT"));

		list.add(item);
	}

	private String getSql(String division) {
		final StringBuffer sql = new StringBuffer(2500);

		sql.append(
				"SELECT A.CC_CVG_RFSD" + "  , B.CVG_DESC" + "  , C.VOLM_FCTR"
						+ "  , A.CC_VOL_CVRD" + "  , C.MIN_VOLM"
						+ "  , C.MAX_VOLM" + "  , A.BILL_PREM_MO_UNIT"
						+ "  , F.WAIT_PERIOD_DAYS" + "  , F.WAIT_PERIOD_CALC_C"
						+ "  , CHAR(A.CC_EFF_DT,USA) \"EFFECTIVE_DATE\""
						+ "  , A.CC_CEASE_REAS" + "  , A.CC_CVG_STAT"
						+ "  , A.CVG||A.SUB_CVG \"COVERAGE\""
						+ "  , A.EMPLR_CONTRIB_PCT" + "  , A.SUBSTD_FCTR"
						+ "  , A.LINE_OF_BUS" + "  , A.CC_CVG_EVID"
						+ "  , C.VOLM_BAS_CD" + "  , C.NO_EVDNC_MAX_VOLM"
						+ "  , C.RNDG_CNTL_CD" + "  , C.RNDG_VOLM_AMT"
						+ "  , C.WAIT_PERD" + "  , C.WAIT_PERD_CD"
						+ "  , C.FRST_DAY_MTH" + "  , C.FLAT_UNIT_VOLM"
						+ "  , B.ALLW_PARTICP" + "  , B.UNIT_FCTR"
						+ "  , B.BASE_UNIT" + "  , B.CVG_TYP"
						+ "  , CHAR(E.ORIG_EFF_DATE,USA) \"DIV EFF DT\""
						+ " FROM ").append(this._dbSchema).append(
				".VCERTCVZ A" + "  , ").append(this._dbSchema).append(
				".VRTVCVGZ B" + "  , ").append(this._dbSchema).append(
				".VPLCYCVZ C" + "  , ").append(this._dbSchema).append(
				".VPLCYGRZ D" + "  , ").append(this._dbSchema).append(
				".VPLCYDVZ E" + "  , ").append(this._dbSchema).append(
				".VWAITPDZ F" + " WHERE A.COMP_CD = ?"
						+ "  AND A.COMP_CD = C.COMP_CD"
						+ "  AND C.COMP_CD = D.COMP_CD"
						+ "  AND D.COMP_CD = E.COMP_CD"
						+ "  AND A.GROUP_PRFX = ?"
						+ "  AND A.GROUP_PRFX = C.GRP_PRFX"
						+ "  AND C.GRP_PRFX = D.GRP_PRFX"
						+ "  AND D.GRP_PRFX = E.GRP_PRFX"
						+ "  AND A.GROUP_NO = ?"
						+ "  AND A.GROUP_NO = C.GRP_BASE"
						+ "  AND C.GRP_BASE = D.GRP_BASE"
						+ "  AND D.GRP_BASE = E.GRP_BASE"
						+ "  AND A.DIV_ID = ?" + "  AND A.DIV_ID = E.DIV_CODE"
						+ "  AND C.DIV_CODE = CASE WHEN D.DIV_LVL_CD = '5'"
						+ "                     THEN '").append(division)
				.append(
						"'" + "                     ELSE ' ' END"
								+ "  AND A.CERT_ID = ?"
								+ "  AND A.CVG||A.SUB_CVG = B.CVG||B.SUB_CVG"
								+ "  AND C.COV_CODE = A.CVG||A.SUB_CVG"
								+ "  AND C.CLAS_CODE = ?"
								+ "  AND C.WAIT_PERD = DEC(F.WAIT_PERIOD_CODE)"
								+ " ORDER BY A.CVG||A.SUB_CVG"
								+ "        , A.CC_EFF_DT DESC");

		return sql.toString();
	}
}
