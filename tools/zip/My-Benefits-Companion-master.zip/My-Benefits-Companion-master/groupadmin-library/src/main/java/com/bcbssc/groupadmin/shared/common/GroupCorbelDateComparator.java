/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2013 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * GroupBillsDateComparator.java
 * 
 */



package com.bcbssc.groupadmin.shared.common;

import java.util.Comparator;
import com.bcbssc.commapi.model.documentarchive.GroupAdminCorbelDocument;
import org.apache.log4j.Logger;

/**
 * <p>GroupCorbelDateComparator class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class GroupCorbelDateComparator implements Comparator {

	/** The log4j logger for this class */
	private static Logger log = Logger
			.getLogger(GroupCorbelDateComparator.class);

	/**
	 * Creates a new instance of GroupCorbelDateComparator
	 */
	public GroupCorbelDateComparator() {
		if (GroupCorbelDateComparator.log.isDebugEnabled()) {
			GroupCorbelDateComparator.log
					.debug("Created GroupCorbelDateComparator object.");
		}
	}

	/** {@inheritDoc} */
	public int compare(Object gaCorbelOne, Object gaCorbelTwo) {
		GroupAdminCorbelDocument docOne = (GroupAdminCorbelDocument) gaCorbelOne;
		GroupAdminCorbelDocument docTwo = (GroupAdminCorbelDocument) gaCorbelTwo;

		return (docOne.getPostingDate().compareTo(docTwo.getPostingDate()));

	}
}
