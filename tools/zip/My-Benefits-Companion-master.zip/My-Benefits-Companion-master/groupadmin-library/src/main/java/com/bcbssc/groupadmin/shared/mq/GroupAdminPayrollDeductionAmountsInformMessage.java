/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUE CROSS BLUE SHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION, OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright (c) 2005 Blue Cross Blue Shield of South Carolina.
 * All rights reserved.
 * An independent Licensee of the Blue Cross and Blue Shield Association.
 *
 * GroupAdminPayrollDeductionAmountsInformMessage.java
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mq/GroupAdminPayrollDeductionAmountsInformMessage.java_v  $
 * $Workfile:   GroupAdminPayrollDeductionAmountsInformMessage.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:16:02  $
 * $Modtime:   May 14 2009 11:33:32  $
 */

package com.bcbssc.groupadmin.shared.mq;

/**
 * Encapsulates an INFOrm message for a Group Administrator Payroll Deduction
 * Amounts calculation.
 */
public class GroupAdminPayrollDeductionAmountsInformMessage extends com.bcbssc.netsys.inform.AbstractInformMessage {

    private static final String FILE_INFORM = "GroupAdminPayrollDeductionAmountsInforms.xml";

    private static final String MAPPER_KEY = "GroupAdminPayrollDeductionAmountsInforms";

    private static final String TASK_PREFIX = "GroupAdminPayrollDeductionAmounts.";

    private String applicationName = "GroupAdminPayrollDeductionAmounts";

    /**
     * creates a new instance of GroupAdminPayrollDeductionAmountsInformMessage
     */
    public GroupAdminPayrollDeductionAmountsInformMessage(){
        super();
    }
    
    /**
     * Convenience constructor for setting the application upon instantiation.
     *
     * @param applicationName The name of the application submitting the INFOrm
     */
    public GroupAdminPayrollDeductionAmountsInformMessage(String applicationName) {
        super();
        this.setApplicationName(applicationName);
    }
    
    /**
     * Gets the task prefix for the INFOrm message.
     *
     * @return The task prefix for the INFOrm message.
     */
    public String getTaskPrefix() {
        return GroupAdminPayrollDeductionAmountsInformMessage.TASK_PREFIX;
    }

    /**
     * Gets the key name for the INFOrm message.
     *
     * @return The key name for the INFOrm message.
     */
    public String getMapperKey() {
        return GroupAdminPayrollDeductionAmountsInformMessage.MAPPER_KEY;
    }

    /**
     * Gets the file path of the mappings file used to map INFOrm data.
     *
     * @return The file path used for mapping INFOrm data.
     */
    public String getInformMapFile() {
       return GroupAdminPayrollDeductionAmountsInformMessage.FILE_INFORM; 
    }

    /**
     * Gets the application name for the INFOrm message.
     * to get the proper Mapper instance.
     *
     * @return The application name for the current instance.
     */
    public String getApplicationName() {
        return this.applicationName;
    }
    
    /**
     * Gets the application name for the INFOrm message.
     * to get the proper Mapper instance.
     *
     * @param applicationName application name for the current instance.
     */
    public void setApplicationName(String applicationName){
        this.applicationName = applicationName;
    }
}
