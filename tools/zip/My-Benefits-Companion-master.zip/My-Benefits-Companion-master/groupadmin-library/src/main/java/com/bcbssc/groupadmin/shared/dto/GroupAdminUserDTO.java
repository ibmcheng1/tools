/*
 * @(#)GroupAdminUserDTO.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.dto;

import com.bcbssc.registration.dto.BcbsPersonDTO;

/**
 * User Data Transfer Object for Group Administrators
 *
 * This bean contains user profile data
 *
 * @author Jonathan Egger
 * @version $Revision:   1.1  $
 */
public class GroupAdminUserDTO extends BcbsPersonDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * AccessCode
	 */
	public String accessCode = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * GroupName
	 */
	public String groupName = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * GroupNumber
	 */
	public String groupNumber = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * GroupNumberPrefix
	 */
	public String groupNumberPrefix = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Last 6 digits of SSN
	 */
	public String last6SSN = com.bcbssc.struts.common.Constants.BLANK_STRING;

	
	public String rpn = com.bcbssc.struts.common.Constants.BLANK_STRING;
	
	public String applicationID = com.bcbssc.struts.common.Constants.BLANK_STRING;
	
	
	/**
	 * <p>serRpn.</p>
	 *
	 * @param rpn a {@link java.lang.String} object.
	 */
	public void serRpn(String rpn){
		
		this.rpn = rpn;
	}
	
	
	/**
	 * <p>Getter for the field <code>rpn</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getRpn(){
		
		return this.rpn;
	}
	
	
	/**
	 * <p>Setter for the field <code>applicationID</code>.</p>
	 *
	 * @param applicationID a {@link java.lang.String} object.
	 */
	public void setApplicationID(String applicationID){
		
		this.applicationID = applicationID;
	}
	
	
	/**
	 * <p>Getter for the field <code>applicationID</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getApplicationID(){
		
		return this.applicationID;
	}
	
	/**
	 * <p>Getter for the field <code>last6SSN</code>.</p>
	 *
	 * @return the last6SSN
	 */
	public String getLast6SSN() {
		return last6SSN;
	}

	/**
	 * <p>Setter for the field <code>last6SSN</code>.</p>
	 *
	 * @param last6SSN the last6SSN to set
	 */
	public void setLast6SSN(String last6SSN) {
		this.last6SSN = last6SSN;
	}

	/** boolean to determine if this use has read only access */
	private boolean readOnly;
	
	/**
	 * <p>Getter for the field <code>accessCode</code>.</p>
	 *
	 * @return the accessCode
	 */
	public String getAccessCode() {
		return accessCode;
	}

	
	
	/**
	 * <p>Setter for the field <code>accessCode</code>.</p>
	 *
	 * @param accessCode
	 *            the accessCode to set
	 */
	public void setAccessCode(String accessCode) {
		this.accessCode = accessCode;
	}

	/**
	 * <p>Getter for the field <code>groupName</code>.</p>
	 *
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}

	/**
	 * <p>Setter for the field <code>groupName</code>.</p>
	 *
	 * @param groupName
	 *            the groupName to set
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	/**
	 * <p>Getter for the field <code>groupNumber</code>.</p>
	 *
	 * @return the groupNumber
	 */
	public String getGroupNumber() {
		return groupNumber;
	}

	/**
	 * <p>Setter for the field <code>groupNumber</code>.</p>
	 *
	 * @param groupNumber
	 *            the groupNumber to set
	 */
	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}

	/**
	 * <p>Getter for the field <code>groupNumberPrefix</code>.</p>
	 *
	 * @return the groupNumberPrefix
	 */
	public String getGroupNumberPrefix() {
		return groupNumberPrefix;
	}

	/**
	 * <p>Setter for the field <code>groupNumberPrefix</code>.</p>
	 *
	 * @param groupNumberPrefix
	 *            the groupNumberPrefix to set
	 */
	public void setGroupNumberPrefix(String groupNumberPrefix) {
		this.groupNumberPrefix = groupNumberPrefix;
	}




	
	/**
	 * gets the read only flag
	 *
	 * @return boolean
	 */
	public boolean getReadOnly() {
		return this.readOnly;
	}

	/**
	 * gets the read only flag
	 *
	 * @return boolean
	 */
	public boolean isReadOnly() {
		return this.readOnly;
	}

	/**
	 * sets the read only flag
	 *
	 * @param b a boolean.
	 */
	public void setReadOnly(boolean b) {
		this.readOnly = b;
	}

	/**
	 * Gets the group number
	 *
	 * @return group number stripped of dashes
	 */
	public String getGroupNumberStripped() {
		StringBuffer grpNbr = new StringBuffer();
		int start = 0;

		int index = this.groupNumber.indexOf('-');
		while (index != -1) {
			grpNbr = grpNbr.append(this.groupNumber.substring(start, index));
			start = index + 1;
			index = this.groupNumber.indexOf('-', start);
		}
		grpNbr = grpNbr.append(this.groupNumber.substring(start));

		return grpNbr.toString();
	}
}
