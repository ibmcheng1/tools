/*
 * @(#)WebpackException.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.webpack;

/**
 * Group Administration Webpack
 *
 * Thrown when webpack encounters an error.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class WebpackException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2512012140112219500L;

	/**
	 * Class constructor
	 *
	 * @param error
	 *            The error message returned from webpack
	 */
	public WebpackException(String error) {
		super(error);
	}
}
