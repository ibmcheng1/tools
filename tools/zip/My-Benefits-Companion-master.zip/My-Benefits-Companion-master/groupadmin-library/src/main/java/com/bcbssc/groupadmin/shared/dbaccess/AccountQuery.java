/**
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.groupadmin.shared.dbaccess;

import com.bcbssc.groupadmin.shared.dto.BankInformationDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;

import org.apache.log4j.Logger;

/**
 * Using for Insured Bank Account related queries.
 */
public class AccountQuery extends AbstractDBSearch {

	/** The log4j logger for this class. */
	private static final Logger log = Logger.getLogger(AccountQuery.class);

	/**
	 * Configures it with an INI file.
	 *
	 * @param iniFile
	 *            file path of the configuration INI file.
	 */
	public AccountQuery(String iniFile) {
		super(iniFile, "GCOM_TABLE");
	}

	/**
	 * Get the insured bank account detials.
	 *
	 * @throws java.sql.SQLException if any.
	 * @param insuredDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredDataDTO} object.
	 * @return a {@link com.bcbssc.groupadmin.shared.dto.BankInformationDTO} object.
	 */
	public BankInformationDTO performSearch(InsuredDataDTO insuredDTO)
			throws SQLException {
		AccountQuery.log.debug("In performSearch() for bank details query");
		/*
		 * Get the database schema before query creation.
		 */
		this.checkInit();

		/*
		 * Get the parameters out of insured data object for the SQL prepared
		 * statement. NOte: need check how the query will be.
		 */
		final String company = insuredDTO.getCompany();
		final String prefix = insuredDTO.getGroupPrefix();
		final String group = insuredDTO.getGroupBase();
		final String division = insuredDTO.getDivisionCode();
		if (AccountQuery.log.isDebugEnabled()) {
			AccountQuery.log.debug("company = " + company);
			AccountQuery.log.debug("prefix = " + prefix);
			AccountQuery.log.debug("group = " + group);
			AccountQuery.log.debug("division = " + division);
		}
		final String[] params = { company, prefix, group, division, };
		BankInformationDTO bankInfoDTO = new BankInformationDTO();

		/*
		 * This collection size of bankDetails(results) should always be 1. That
		 * means we should not get more then 1 bank details for each group.
		 */
		Collection bankDetails = this.performSearch(
				this.getAccountDetailsSql(), params);
		AccountQuery.log.debug("bankDetails size = " + bankDetails.size());
		if (bankDetails.size() <= 1) {
			Iterator iter = bankDetails.iterator();
			while (iter.hasNext()) {
				bankInfoDTO = (BankInformationDTO) iter.next();
			}
		} else {
			AccountQuery.log
					.debug("A group can not have more than 1 Bank Information");
			throw new SQLException(
					"A group can not have more than 1 Bank Information");
		}

		return bankInfoDTO;
	}

	/**
	 * @return the SQL for an group bank account details.
	 */
	private String getAccountDetailsSql() {
		StringBuffer accountQuerySB = new StringBuffer(1500);
		accountQuerySB
				.append(
						"SELECT BANK_EFFECTIVE_DT, "
								+ "BANK_WEB_PMNT_STAT, "
								+ "CASE WHEN BANK_WEB_PMNT_STAT = '1' THEN DIGITS(BANK_ROUTING_NUM) WHEN BANK_WEB_PMNT_STAT = '9' THEN DIGITS(BANK_ROUTING_NUM) ELSE '         ' END \"BANK_ROUTING_NUM\", "
								+ "BANK_ACCOUNT_NUM, " + "BANK_PAYOR_NAME, "
								+ "BANK_NAME, " + "BANK_TYPE, "
								+ "BANK_SOURCE, " + "CONFIRMATION_NUM "
								+ "FROM ").append(this._dbSchema).append(
						".VPLCYBRZ " + "WHERE COMP_CD = ? "
								+ "AND GRP_PRFX  = ? " + "AND GRP_BASE  = ? "
								+ "AND DIV_CODE  = ?");

		AccountQuery.log.debug("bank account Query="
				+ accountQuerySB.toString());
		return accountQuerySB.toString();
	}

	/**
	 * {@inheritDoc}
	 *
	 * Adds data from the given result set to the target object.
	 */
	protected void addSearchItem(ResultSet resultSet, Object obj)
			throws SQLException {

		final Collection<BankInformationDTO> list = (Collection) obj;
		final BankInformationDTO bean;
		bean = this.createBankAcctDetails(resultSet);
		list.add(bean);
	}

	/**
	 * Creates a bank account bean from the given result set.
	 * 
	 * @param data
	 *            the result set whose cursor is on a row containing the data to
	 *            use.
	 * @return a new bank account details bean.
	 * @throws SQLException
	 *             if an error occurs while accessing the result set.
	 */
	private BankInformationDTO createBankAcctDetails(ResultSet resultSet)
			throws SQLException {

		final BankInformationDTO bean = new BankInformationDTO();
		bean
				.setAccountHolderName(resultSet.getString("BANK_PAYOR_NAME")
						.trim());
		bean.setBankAccountNumber(resultSet.getString("BANK_ACCOUNT_NUM")
				.trim());
		bean.setBankName(resultSet.getString("BANK_NAME").trim());
		bean.setBankRoutingNumber(resultSet.getString("BANK_ROUTING_NUM")
				.trim());
		bean.setBankStatus(resultSet.getString("BANK_WEB_PMNT_STAT").trim());
		return bean;
	}

}
