/*
 * @(#)BillHistoryForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 * 
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/forms/BillHistoryForm.java_v  $
 * $Workfile:   BillHistoryForm.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:15:08  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/forms/BillHistoryForm.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:15:08   EN80
 * Initial revision.
 * 
 *    Rev 1.3   Apr 28 2009 10:19:04   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.2   Mar 07 2005 13:13:20   rxr93
 * issm change
 * 
 *    Rev 1.1   Mar 04 2005 11:38:42   rxr93
 * add viewBill setting
 * 
 *    Rev 1.0   Mar 01 2005 10:08:56   rxr93
 * Initial revision.
 * 
 */
package com.bcbssc.groupadmin.shared.forms;

import java.util.Collection;

/**
 * Bean for processing bill history/summary web data
 *
 * @author XR93
 * @version $Id: $Id
 */
public class BillHistoryForm extends InsuredSearchForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** bill selected for summary view */
	private String selectedBillDate;

	/** summary search results */
	private Collection summary;

	/** view bill indicator */
	private String viewBill;

	/**
	 * Clears the user-editable data fields for this form
	 */
	public void clear() {
		// view form with buttons, no data to clear
	}

	/**
	 * <p>Getter for the field <code>selectedBillDate</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getSelectedBillDate() {
		return this.selectedBillDate;
	}

	/**
	 * <p>Setter for the field <code>selectedBillDate</code>.</p>
	 *
	 * @param string a {@link java.lang.String} object.
	 */
	public void setSelectedBillDate(String string) {
		this.selectedBillDate = string;
	}

	/**
	 * <p>Getter for the field <code>summary</code>.</p>
	 *
	 * @return a {@link java.util.Collection} object.
	 */
	public Collection getSummary() {
		return this.summary;
	}

	/**
	 * <p>Setter for the field <code>summary</code>.</p>
	 *
	 * @param collection a {@link java.util.Collection} object.
	 */
	public void setSummary(Collection collection) {
		this.summary = collection;
	}

	/**
	 * <p>Getter for the field <code>viewBill</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getViewBill() {
		return this.viewBill;
	}

	/**
	 * <p>Setter for the field <code>viewBill</code>.</p>
	 *
	 * @param string a {@link java.lang.String} object.
	 */
	public void setViewBill(String string) {
		this.viewBill = string;
	}

}
