/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 * 
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/services/BillServices.java_v  $
 * $Workfile:   BillServices.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:16:28  $
 * $Modtime:   May 14 2009 11:33:30  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/services/BillServices.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:16:28   EN80
 * Initial revision.
 * 
 *    Rev 1.3   Apr 28 2009 10:20:38   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.2   Apr 27 2006 15:47:12   rx24c
 * C08201 - changed the default label for the bill date
 * 
 *    Rev 1.1   Mar 01 2005 10:06:52   rxr93
 * add bill history and summary accessors
 * 
 */
package com.bcbssc.groupadmin.shared.services;

import com.bcbssc.groupadmin.shared.dbaccess.BillQuery;
import com.bcbssc.groupadmin.shared.dto.BillHistoryDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.apache.struts.util.LabelValueBean;

/**
 * Utility class for accessing bill related values in DB2
 *
 * @author XR93
 * @version $Id: $Id
 */
public class BillServices {
	/** log4j logger */
	protected static Logger log = Logger.getLogger(BillServices.class);

	/** the ini file containing service processing parameters */
	protected String iniFile = null;

	/**
	 * Constructs class, setting the servlet ini files
	 *
	 * @param iniFile
	 *            the ini file containing service processing parameters
	 */
	public BillServices(String iniFile) {
		this.iniFile = iniFile;
	}

	/**
	 * get bill info for the last 6 bill
	 *
	 * @param dataDTO
	 *            Reference object for group number
	 * @return collection of BillHistoryDTO object
	 * @throws java.sql.SQLException
	 *             Unexpected Exception
	 */
	public Collection getbillHistory(InsuredDataDTO dataDTO)
			throws SQLException {
		try {
			BillQuery billQuery = new BillQuery(this.iniFile);
			return billQuery.performSearch(dataDTO);
		} catch (SQLException sqlEx) {
			BillServices.log.error("Error during bill history query", sqlEx);
			throw sqlEx;
		}
	}

	/**
	 * get bill Summary
	 *
	 * @param dataDTO
	 *            Reference object for group number
	 * @return collection of BillHistoryDTO object
	 * @throws java.sql.SQLException
	 *             Unexpected Exception
	 * @param dueDate a {@link java.lang.String} object.
	 */
	public Collection getbillSummary(InsuredDataDTO dataDTO, String dueDate)
			throws SQLException {
		try {
			BillQuery billQuery = new BillQuery(this.iniFile);
			return billQuery.performSearch(dataDTO, dueDate);
		} catch (SQLException sqlEx) {
			BillServices.log.error("Error during bill history query", sqlEx);
			throw sqlEx;
		}
	}

	/**
	 * get a list of bill dates (for use in a dropdown on web)
	 *
	 * @param dataDTO
	 *            Reference object for group number
	 * @return collection of LabelValueBean objects
	 * @throws java.sql.SQLException
	 *             Unexpected Exception
	 */
	public Collection getbillOptions(InsuredDataDTO dataDTO)
			throws SQLException {
		try {
			Collection billHistory = this.getbillHistory(dataDTO);
			return this.makeBillOptions(billHistory);
		} catch (SQLException sqlEx) {
			BillServices.log.error("Error during group query", sqlEx);
			throw sqlEx;
		}
	}

	/**
	 * Convert Collection of BillHistoryDTO objects to a collection of
	 * LabelValueBeans
	 * 
	 * @param bills
	 *            Collection of BillHistoryDTO objects
	 * 
	 * @return Collection of LabelValueBean objects
	 */
	private Collection<LabelValueBean> makeBillOptions(Collection<BillHistoryDTO> bills) {
		Collection<LabelValueBean> dateOptions = new ArrayList<LabelValueBean>();
		BillHistoryDTO billDTO = null;
		Iterator<BillHistoryDTO> it = bills.iterator();

		dateOptions.add(new LabelValueBean("-- Please Choose One --", ""));

		while (it.hasNext()) {
			billDTO = (BillHistoryDTO) it.next();
			dateOptions.add(new LabelValueBean(billDTO.getDueDate(), billDTO
					.getDueDate()));
		}

		return dateOptions;
	}
}
