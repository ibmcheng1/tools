/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * Created on Feb 14, 2005
 *
 */
package com.bcbssc.groupadmin.shared.mq;

import com.bcbssc.groupadmin.shared.dto.BankInformationDTO;
import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;
import com.bcbssc.groupadmin.shared.forms.BillHistoryForm;
import com.bcbssc.groupadmin.shared.forms.RequestBillForm;

import java.io.FileNotFoundException;

/**
 * <p>InformFactory class.</p>
 *
 * @author XR93
 *
 * Object providing infrastructure for sending closed inform for CLife Group
 * Administrator
 * @version $Id: $Id
 */
public class InformFactory {
	/** Key for reading BankInformation XML section */
	private static final String BANK_INFO_KEY = "BankInformation";

	/** Key for reading PaymentInformation XML section */
	private static final String PAY_INFO_KEY = "PaymentInformation";

	/** Key for reading AddInsured XML section */
	private static final String ADD_EMP_KEY = "AddInsured";

	/** Key for reading InsuredDetails XML section */
	private static final String EMP_DETAIL_KEY = "InsuredDetails";

	/** Key for reading ChangeInsured XML section */
	private static final String CHANGE_EMP_KEY = "ChangeInsured";

	/** Key for reading TerminateInsured XML section */
	private static final String TERM_EMP_KEY = "TerminateInsured";

	/** Key for reading RequestInformation XML section */
	private static final String REQUEST_INFO_KEY = "RequestInformation";

	/** Key for reading ViewInsuredDetails XML section */
	private static final String VIEW_EMP_KEY = "ViewInsuredDetails";

	/** Key for reading BillSummary XML section */
	private static final String BILL_SUMMARY_KEY = "BillSummary";

	/** Key for reading BillImage XML section */
	private static final String BILL_IMAGE_KEY = "BillImage";

	/** Key for reading RequestBill XML section */
	private static final String REQUEST_BILL_KEY = "RequestBill";

	/**
	 * private constructor, Factory objects are not meant to be instantiated
	 */
	private InformFactory() {
		super();
	}

	/**
	 * Record an inform to reflect that bank information is added.
	 *
	 * @param iniFile
	 *            containing appropriate settings
	 * @param bankInfoDTO a {@link com.bcbssc.groupadmin.shared.dto.BankInformationDTO} object.
	 * @param groupAdmin a {@link com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO} object.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public static void sendBankInformationInform(String iniFile,
			GroupAdminUserDTO groupAdmin, BankInformationDTO bankInfoDTO)
			throws FileNotFoundException {
		InformHandler cih = new InformHandler(iniFile,
				InformFactory.BANK_INFO_KEY, bankInfoDTO, bankInfoDTO
						.isClosedInform());
		// send the KeyID and AltKeyID.
		cih.sendInform(bankInfoDTO.getGroupNumber(), bankInfoDTO
				.getTrackingNumber());
	}

	/**
	 * Record an inform to reflect that payment information is added to the host
	 * que.
	 *
	 * @param iniFile
	 *            containing appropriate settings
	 * @param bankInfoDTO a {@link com.bcbssc.groupadmin.shared.dto.BankInformationDTO} object.
	 * @param groupAdmin a {@link com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO} object.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public static void sendPaymentInformationInform(String iniFile,
			GroupAdminUserDTO groupAdmin, BankInformationDTO bankInfoDTO)
			throws FileNotFoundException {
		InformHandler cih = new InformHandler(iniFile,
				InformFactory.PAY_INFO_KEY, bankInfoDTO);
		// send the KeyID and AltKeyID.
		cih.sendInform(bankInfoDTO.getGroupNumber(), bankInfoDTO
				.getTrackingNumber());
	}

	/**
	 * Record an inform to reflect that an employee was added
	 *
	 * @param iniFile
	 *            containing appropriate settings
	 * @param employee a {@link com.bcbssc.groupadmin.shared.dto.InsuredDataDTO} object.
	 * @param groupAdmin a {@link com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO} object.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public static void sendEmployeeAddInform(String iniFile,
			GroupAdminUserDTO groupAdmin, InsuredDataDTO employee)
			throws FileNotFoundException {
		InformHandler cih = new InformHandler(iniFile,
				InformFactory.ADD_EMP_KEY, employee);
		cih.sendInform(employee.getIdentificationNumber(), groupAdmin
				.getAccessCode());
	}

	/**
	 * Record an inform to reflect that an employee was changed
	 *
	 * @param iniFile
	 *            containing appropriate settings
	 * @param employee a {@link com.bcbssc.groupadmin.shared.dto.InsuredDataDTO} object.
	 * @param groupAdmin a {@link com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO} object.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public static void sendEmployeeChangeInform(String iniFile,
			GroupAdminUserDTO groupAdmin, InsuredDataDTO employee)
			throws FileNotFoundException {
		InformHandler cih = new InformHandler(iniFile,
				InformFactory.CHANGE_EMP_KEY, employee);
		cih.sendInform(employee.getIdentificationNumber(), groupAdmin
				.getAccessCode());
	}

	/**
	 * Record an inform to reflect that an employee was accessed
	 *
	 * @param iniFile
	 *            containing appropriate settings
	 * @param employee a {@link com.bcbssc.groupadmin.shared.dto.InsuredDataDTO} object.
	 * @param groupAdmin a {@link com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO} object.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public static void sendEmployeeViewInform(String iniFile,
			GroupAdminUserDTO groupAdmin, InsuredDataDTO employee)
			throws FileNotFoundException {
		InformHandler cih = new InformHandler(iniFile,
				InformFactory.VIEW_EMP_KEY, employee);
		cih.sendInform(employee.getIdentificationNumber(), groupAdmin
				.getAccessCode());
	}

	/**
	 * Record an inform to reflect that an employee was terminated
	 *
	 * @param iniFile
	 *            containing appropriate settings
	 * @param employee a {@link com.bcbssc.groupadmin.shared.dto.InsuredDataDTO} object.
	 * @param groupAdmin a {@link com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO} object.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public static void sendEmployeeTerminateInform(String iniFile,
			GroupAdminUserDTO groupAdmin, InsuredDataDTO employee)
			throws FileNotFoundException {
		InformHandler cih = new InformHandler(iniFile,
				InformFactory.TERM_EMP_KEY, employee);
		cih.sendInform(employee.getIdentificationNumber(), groupAdmin
				.getAccessCode());
	}

	/**
	 * Record an inform to reflect that employee details were accessed
	 *
	 * @param iniFile
	 *            containing appropriate settings
	 * @param employee a {@link com.bcbssc.groupadmin.shared.dto.InsuredDataDTO} object.
	 * @param groupAdmin a {@link com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO} object.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public static void sendEmployeeDetailsInform(String iniFile,
			GroupAdminUserDTO groupAdmin, InsuredDataDTO employee)
			throws FileNotFoundException {
		InformHandler cih = new InformHandler(iniFile,
				InformFactory.EMP_DETAIL_KEY, employee);
		cih.sendInform(employee.getIdentificationNumber(), groupAdmin
				.getAccessCode());
	}

	/**
	 * Record an inform to reflect that an ID card or certificate was requested.
	 *
	 * @param iniFile
	 *            containing appropriate settings
	 * @param employee a {@link com.bcbssc.groupadmin.shared.dto.InsuredDataDTO} object.
	 * @param groupAdmin a {@link com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO} object.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public static void sendRequestInformationInform(String iniFile,
			GroupAdminUserDTO groupAdmin, InsuredDataDTO employee)
			throws FileNotFoundException {

		InformHandler cih = new InformHandler(iniFile,
				InformFactory.REQUEST_INFO_KEY, employee);
		cih.sendInform(employee.getIdentificationNumber(), groupAdmin
				.getAccessCode());
	}

	/**
	 * Record an inform to reflect that a bill was requested
	 *
	 * @param iniFile
	 *            containing appropriate settings
	 * @param groupAdmin a {@link com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO} object.
	 * @param billForm a {@link com.bcbssc.groupadmin.shared.forms.RequestBillForm} object.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public static void sendRequestBillInform(String iniFile,
			GroupAdminUserDTO groupAdmin, RequestBillForm billForm)
			throws FileNotFoundException {

		InformHandler cih = new InformHandler(iniFile,
				InformFactory.REQUEST_BILL_KEY, billForm);
		cih.sendInform(billForm.getGroupNumber(), groupAdmin.getAccessCode());
	}

	/**
	 * Record an inform to reflect that a bill summary was accessed
	 *
	 * @param iniFile
	 *            containing appropriate settings
	 * @param groupAdmin a {@link com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO} object.
	 * @param billForm a {@link com.bcbssc.groupadmin.shared.forms.BillHistoryForm} object.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public static void sendBillSummary(String iniFile,
			GroupAdminUserDTO groupAdmin, BillHistoryForm billForm)
			throws FileNotFoundException {

		InformHandler cih = new InformHandler(iniFile,
				InformFactory.BILL_SUMMARY_KEY, billForm);
		cih.sendInform(billForm.getGroupNumber(), groupAdmin.getAccessCode());
	}

	/**
	 * Record an inform to reflect that a bill image was accessed
	 *
	 * @param iniFile
	 *            containing appropriate settings
	 * @param groupAdmin a {@link com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO} object.
	 * @param billForm a {@link com.bcbssc.groupadmin.shared.forms.BillHistoryForm} object.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public static void sendBillImage(String iniFile,
			GroupAdminUserDTO groupAdmin, BillHistoryForm billForm)
			throws FileNotFoundException {

		InformHandler cih = new InformHandler(iniFile,
				InformFactory.BILL_IMAGE_KEY, billForm);
		cih.sendInform(billForm.getGroupNumber(), groupAdmin.getAccessCode());
	}
}
