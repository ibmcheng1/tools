/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mapper/DependentEffectiveDateEvaluator.java_v  $
 * $Workfile:   DependentEffectiveDateEvaluator.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:15:52  $
 * $Modtime:   May 14 2009 11:33:30  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mapper/DependentEffectiveDateEvaluator.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:15:52   EN80
 * Initial revision.
 * 
 *    Rev 1.4   Apr 28 2009 10:19:54   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.3   Feb 18 2005 13:29:18   rdq70
 * Missing bean properties added.
 *
 *    Rev 1.2   Feb 11 2005 15:27:08   rdq70
 * Corrected transaction number.
 *
 *    Rev 1.1   Feb 11 2005 12:54:52   rdq70
 * Corrected package.
 *
 *    Rev 1.0   Feb 10 2005 15:20:30   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.mapper;

import com.bcbssc.groupadmin.shared.dto.InsuredSearchDTO;
import com.bcbssc.netsys.web.AbstractValueEvaluator;

/**
 * Evaluates the effective date for a dependent.
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class DependentEffectiveDateEvaluator extends AbstractValueEvaluator {

	/**
	 * Implements the actual evaluation.
	 *
	 * @return the evaluation output.
	 */
	protected Object doEvaluate() {
		final InsuredSearchDTO bean = (InsuredSearchDTO) this.valueObject;
		final String transaction = this.getParameterValue("transaction");
		final String relationship = this.getParameterValue("relationship");
		final String fieldValue = this.getParameterValue("fieldValue");

		String returnString = "";

		if ("SPO".equals(relationship)) {
			if ("203".equals(transaction)) {
				if (bean.getSpouseExists()
						|| (bean.getSpouseCoverageItems().size() > 0)) {
					returnString = fieldValue;
				}
			} else if (bean.getSpouse().isChanged()) {
				returnString = fieldValue;
			}
		} else {
			if ("203".equals(transaction)) {
				if (bean.getDependentCoverageItems().size() > 0) {
					returnString = fieldValue;
				}
			} else if (bean.isDependentChanged()) {
				returnString = fieldValue;
			}
		}

		return returnString;
	}
}
