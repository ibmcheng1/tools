/*
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/actions/RequestBillAction.java_v  $
 * $Workfile:   RequestBillAction.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:13:44  $
 * $Modtime:   May 14 2009 11:33:28  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/actions/RequestBillAction.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:13:44   EN80
 * Initial revision.
 * 
 *    Rev 1.7   Apr 28 2009 10:17:18   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.6   Apr 28 2005 11:17:48   rxr93
 * set userdto into form so group list can be loaded correclty
 * 
 *    Rev 1.5   Apr 25 2005 16:52:58   rxg97
 * Set the user when creating forms that require the user.
 * 
 *    Rev 1.4   Mar 03 2005 16:31:12   rxr93
 * set request type based on what page requested the bill
 * 
 *    Rev 1.3   Mar 02 2005 13:15:36   rxr93
 * modify field name for consitency 
 * 
 *    Rev 1.2   Mar 01 2005 10:10:44   rxr93
 * add method to process request from BillHistory
 */

package com.bcbssc.groupadmin.shared.actions;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.groupadmin.shared.forms.BillHistoryForm;
import com.bcbssc.groupadmin.shared.forms.RequestBillForm;
import com.bcbssc.groupadmin.shared.mq.InformFactory;
import com.bcbssc.struts.action.SimpleDispatchAction;

import java.io.FileNotFoundException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * Group Admin Request Bill Action
 *
 * This class provides control processing the request a bill action.
 *
 * @author Mark Lujan
 * @version $Revision:   1.0  $
 */
public class RequestBillAction extends SimpleDispatchAction {

	/** log4j logger */
	private static final Logger log = Logger.getLogger(RequestBillAction.class
			.getName());

	/**
	 * <p>Constructor for RequestBillAction.</p>
	 */
	public RequestBillAction() {
		super();
		if (RequestBillAction.log.isDebugEnabled()) {
			RequestBillAction.log.debug("Created RequestBillAction object.");
		}
	}

	/**
	 * Processes the specified HTTP request, and creates the corresponding HTTP
	 * response.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward requestBill(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// no action required prior to loading 1st form
		RequestBillForm billForm = (RequestBillForm) form;

		// set user so that group drop down can be loaded
		billForm
				.setUserDTO((GroupAdminUserDTO) request
						.getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));

		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}

	/**
	 * User has selected a bill, send inform (which will drive the bill being
	 * mailed)
	 *
	 * @param mapping a {@link org.apache.struts.action.ActionMapping} object.
	 * @param form a {@link org.apache.struts.action.ActionForm} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @param response a {@link javax.servlet.http.HttpServletResponse} object.
	 * @throws java.lang.Exception if any.
	 * @return a {@link org.apache.struts.action.ActionForward} object.
	 */
	public ActionForward requestBillConfirm(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		GroupAdminUserDTO user = (GroupAdminUserDTO) request
				.getAttribute("user");

		RequestBillForm requestBillForm = (RequestBillForm) form;

		// send the open inform
		InformFactory.sendRequestBillInform(CommonUtils.getIniFile(this
				.getServlet()), user, requestBillForm);

		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}

	/**
	 * User has request a bill from the BillSummary path, we need to create a
	 * RequestBillForm, populate it for processing, and send the inform.
	 *
	 * @param mapping a {@link org.apache.struts.action.ActionMapping} object.
	 * @param form a {@link org.apache.struts.action.ActionForm} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @param response a {@link javax.servlet.http.HttpServletResponse} object.
	 * @throws java.lang.Exception if any.
	 * @return a {@link org.apache.struts.action.ActionForward} object.
	 */
	public ActionForward billSummaryRequest(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		BillHistoryForm billHistoryForm = (BillHistoryForm) form;
		this.setupBillRequestForm(billHistoryForm, request, "summary");

		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}

	/**
	 * User has request a bill from the BillHistory path, we need to create a
	 * RequestBillForm, populate it for processing, and send the inform.
	 *
	 * @param mapping a {@link org.apache.struts.action.ActionMapping} object.
	 * @param form a {@link org.apache.struts.action.ActionForm} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @param response a {@link javax.servlet.http.HttpServletResponse} object.
	 * @throws java.lang.Exception if any.
	 * @return a {@link org.apache.struts.action.ActionForward} object.
	 */
	public ActionForward billHistoryRequest(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		BillHistoryForm billHistoryForm = (BillHistoryForm) form;
		this.setupBillRequestForm(billHistoryForm, request, "history");

		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}

	/**
	 * make and populate a request bill form send an inform for the request
	 * 
	 */
	private RequestBillForm setupBillRequestForm(
			BillHistoryForm billHistoryForm, HttpServletRequest request,
			String requestType) throws FileNotFoundException {

		GroupAdminUserDTO user = (GroupAdminUserDTO) request
				.getAttribute("user");

		// create RequestBillForm from the BillHistoryForm
		RequestBillForm requestBillForm = (RequestBillForm) this.getForm(
				"requestBillForm", "/requestBillConfirm", request);
		requestBillForm.setGroupNumber(billHistoryForm.getGroupNumber());
		requestBillForm.setDivisionName(billHistoryForm.getDivisionName());
		requestBillForm.setSelectedBillDate(billHistoryForm
				.getSelectedBillDate());
		requestBillForm.setRequestType(requestType);
		requestBillForm.setUserDTO(user);

		// send the open inform
		InformFactory.sendRequestBillInform(CommonUtils.getIniFile(this
				.getServlet()), user, requestBillForm);

		return requestBillForm;
	}
}
