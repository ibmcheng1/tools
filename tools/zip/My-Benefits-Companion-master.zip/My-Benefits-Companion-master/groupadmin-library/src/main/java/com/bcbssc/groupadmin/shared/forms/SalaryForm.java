/*
 * @(#)SalaryForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.forms;

import com.bcbssc.groupadmin.shared.services.EffectiveDateCalculator;
import com.bcbssc.struts.common.DateBean;
import com.bcbssc.struts.common.FormDate;

import java.util.Calendar;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.validator.GenericValidator;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

/**
 * GroupAdmin Salary Form
 *
 * This bean extends the InsuredSearchForm by providing validation specific to
 * the Salary form.
 *
 * @author Neena Musti
 * @version $Revision:   1.0  $
 */
public abstract class SalaryForm extends InsuredSearchForm {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

    /**
     * {@inheritDoc}
     *
     * Validates the form.
     */
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {
        ActionErrors errors = super.validate(mapping, request);

        String month = (this.getSalaryChangeEffectiveDate().getMonth())
                .toString();
        String day = (this.getSalaryChangeEffectiveDate().getDay()).toString();
        String year = (this.getSalaryChangeEffectiveDate().getYear())
                .toString();

        // check for effective date error already recorded
        Iterator effDtMessages = errors
                .get("salaryChangeEffectiveDateFormatted");

        boolean effDtError = effDtMessages.hasNext();

        if (!effDtError) {

            if ((GenericValidator.isInt(month))
                    && (GenericValidator.isInt(day))
                    && (GenericValidator.isInt(year))) {

                // get the Current sysdate + 30 days
                DateBean maxDateDB = EffectiveDateCalculator
                        .getDefaultChangeDate(FormDate.today(), +30);
                Calendar maxDate = FormDate.makeCalendar(maxDateDB);

                // get the Current sysdate - 90 days
                DateBean minDateDB = EffectiveDateCalculator
                        .getDefaultChangeDate(FormDate.today(), -90);
                Calendar minDate = FormDate.makeCalendar(minDateDB);

                Calendar changeDate = FormDate.makeCalendar(this
                        .getSalaryChangeEffectiveDate());

                if (changeDate.before(minDate) || changeDate.after(maxDate)) {
                    // add error message
                    errors
                            .add(
                                    "salaryChangeEffectiveDateFormatted",
                                    new ActionMessage(
                                            "error.pageselection.salEffDate.daterange"));
                }
            }
        }

        return errors;
    }

}
