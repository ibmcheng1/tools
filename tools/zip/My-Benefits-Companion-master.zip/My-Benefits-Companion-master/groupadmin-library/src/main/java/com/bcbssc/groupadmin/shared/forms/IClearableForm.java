/*
 * IClearableForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * Created on December 8, 2004, 11:47 AM
 */

package com.bcbssc.groupadmin.shared.forms;

/**
 * <p>IClearableForm interface.</p>
 *
 * @author  jegger
 * @version $Id: $Id
 */
public interface IClearableForm {
    /**
     * <p>clear.</p>
     */
    public void clear();
}
