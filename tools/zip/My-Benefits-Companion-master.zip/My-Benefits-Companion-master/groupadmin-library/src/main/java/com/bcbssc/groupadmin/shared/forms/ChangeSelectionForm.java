/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/forms/ChangeSelectionForm.java_v  $
 * $Workfile:   ChangeSelectionForm.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:15:12  $
 * $Modtime:   Jun 17 2009 12:50:06  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/forms/ChangeSelectionForm.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:15:12   EN80
 * Initial revision.
 *
 *    Rev 1.12   Apr 28 2009 10:19:08   rff74
 * Java6 Upgrade
 *
 *    Rev 1.11   Jun 23 2008 15:18:20   rcf57
 * C15021 : Fix for system problem log issue #s 5 and 6 in the customer spreadsheet. Effective date does not need a date range check.
 *
 *    Rev 1.10   Jun 13 2008 13:31:14   rcf57
 * C15021 : checked in comments inadvertendly.
 *
 *    Rev 1.9   Jun 12 2008 16:24:48   rcf57
 * C15021 : Fix for system problem log issue #s 5 and 6 in the customer spreadsheet. Effective date does not need a date range check.
 *
 *    Rev 1.8   Jun 05 2008 18:19:04   rcf57
 * C15021 : jsp field name renamed.
 *
 *    Rev 1.7   May 30 2008 17:20:16   rcf57
 * C15021 : Moved the change effective date and salary change effective date validation logic to the validation xml from the javas.
 *
 *    Rev 1.6   May 29 2008 17:17:02   rcf57
 * C15021 : Clife MBC changes, more validation added to ensure the errors don't get displayed as duplicates.
 *
 *    Rev 1.5   May 27 2008 16:03:38   rcf57
 * C15021 : CLife MBC changes. Added further error validation logic.
 *
 *    Rev 1.4   May 26 2008 16:17:30   rcf57
 * C15021 : CLife MBC changes. Added error validation logic.
 *
 *    Rev 1.3   Oct 11 2006 10:59:06   rx29e
 * GroupAdmin : C09312:Fixed the ticket 0610540225.
 *
 *    Rev 1.2   Apr 28 2005 14:27:10   rxr93
 * make variable name issm compliant
 *
 *    Rev 1.1   Apr 27 2005 14:40:16   rxr93
 * get default date of change from effective date calculator
 * add validation
 *
 *    Rev 1.0   Mar 22 2005 16:25:28   rdq70
 * Initial revision.
 */
package com.bcbssc.groupadmin.shared.forms;

import com.bcbssc.groupadmin.shared.services.EffectiveDateCalculator;
import com.bcbssc.struts.common.DateBean;

import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.util.LabelValueBean;

/**
 * This form is used by the Change Selection page.
 *
 * @author dq70 (D. Allen)
 * @version $Revision:   1.0  $
 */
public class ChangeSelectionForm extends InsuredSearchForm {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /** log4j logger */
    private static final Logger log = Logger
            .getLogger(ChangeSelectionForm.class);

    /**
     * Default the change effective date
     */
    public void defaultChangeEffectiveDate() {

        // default the change effective date
        DateBean defaultDate = EffectiveDateCalculator
                .getDefaultChangeDate(this.getLastBillDate());

        ChangeSelectionForm.log.debug("default_date = "
                + defaultDate.toString());

        // set to the dafult date for a change
        this.changeEffectiveDate.setDay(defaultDate.getDay());
        this.changeEffectiveDate.setMonth(defaultDate.getMonth());
        this.changeEffectiveDate.setYear(defaultDate.getYear());
    }

    /**
     * Clears the user-editable data fields for this form.
     */
    public void clear() {

        this.defaultChangeEffectiveDate();

    }

    /**
     * Returns a collection of resettable name/value pairs.
     *
     * @return Collection of LabelValueBean objects, each containing the name
     *         and value of a resettable property.
     */
    public Collection getResettables() {
        ArrayList resettables = new ArrayList();

        resettables.add(new LabelValueBean("changeEffectiveDateMonth", this
                .getChangeEffectiveDate().getMonth()));
        resettables.add(new LabelValueBean("changeEffectiveDateDay", this
                .getChangeEffectiveDate().getDay()));
        resettables.add(new LabelValueBean("changeEffectiveDateYear", this
                .getChangeEffectiveDate().getYear()));

        return resettables;
    }

    /**
     * {@inheritDoc}
     *
     * Validates the form using the validator support provided by the parent.
     * Also verifies that the passwords match.
     */
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {

        ActionErrors errors = super.validate(mapping, request);

        if (this.getSelectedPathItemsArrayList().size() < 1) {
            errors.add("selectedPathItemsSection", new ActionMessage(
                    "error.pageselection.checkbox.required"));
        }

        return errors;

    }
}
