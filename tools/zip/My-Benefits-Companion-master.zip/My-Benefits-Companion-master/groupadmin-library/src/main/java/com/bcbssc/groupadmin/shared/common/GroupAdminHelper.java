/**
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 * Created on Aug 12, 2010
 */
package com.bcbssc.groupadmin.shared.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.bcbssc.commapi.model.common.APIException;
import com.bcbssc.commapi.model.common.DocumentNotFoundException;
import com.bcbssc.commapi.model.common.GroupAdminId;
import com.bcbssc.commapi.model.documentarchive.Document;
import com.bcbssc.commapi.model.documentarchive.GroupAdminBill;
import com.bcbssc.commapi.model.documentarchive.GroupAdminCorbelDocument;
import com.bcbssc.services.daoimpl.documentarchive.DocumentArchiveServiceRemoteBean;

/**
 * <p>GroupAdminHelper class.</p>
 *
 * @author X94S
 * @version $Id: $Id
 */
public class GroupAdminHelper {

	private static final String PATTERN_DATE_FORMAT = "yyyy-MM-dd";

	private static final String PATTERN_BILLING_DATE_FORMAT = "MM/dd/yy";

	private static final Logger log = Logger.getLogger(GroupAdminHelper.class);

	/**
	 * <p>getGroupAdminBillViewDocument.</p>
	 *
	 * @param groupNumber a {@link java.lang.String} object.
	 * @param dateFrom a {@link java.lang.String} object.
	 * @param dateTo a {@link java.lang.String} object.
	 * @param selectedBillDate a {@link java.lang.String} object.
	 * @return an array of {@link byte} objects.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 * @throws java.text.ParseException if any.
	 */
	public byte[] getGroupAdminBillViewDocument(String groupNumber,
			String dateFrom, String dateTo, String selectedBillDate)
			throws APIException, ParseException {

		SimpleDateFormat maskedDateFmt = new SimpleDateFormat(
				GroupAdminHelper.PATTERN_DATE_FORMAT);
		byte[] output = null;
		Document doc = null;
		try {
			Date fromDate = maskedDateFmt.parse(dateFrom);
			Date toDate = maskedDateFmt.parse(dateTo);

			SimpleDateFormat maskedBillingDateFmt = new SimpleDateFormat(
					GroupAdminHelper.PATTERN_BILLING_DATE_FORMAT);
			Date postingDate = maskedBillingDateFmt.parse(selectedBillDate);

			String postingBillDate = (maskedBillingDateFmt.format(postingDate))
					.replace("/", "-");

			GroupAdminHelper.log.debug("groupNumber: " + groupNumber
					+ " dateFrom:" + dateFrom + " dateTo:" + dateTo
					+ " selectedBillDate:" + selectedBillDate
					+ " postingBillDate:" + postingBillDate);
			DocumentArchiveServiceRemoteBean docArcBean = new DocumentArchiveServiceRemoteBean();
			GroupAdminId groupAdminId = new GroupAdminId();
			groupAdminId.setGroupAdminIdentifier(groupNumber);
			List<GroupAdminBill> groupBills = docArcBean.getGroupAdminBillList(groupAdminId,
					fromDate, toDate);
			GroupAdminHelper.log.debug("No of documents retrieved:"
					+ groupBills.size());

			Collections.sort(groupBills, new GroupBillsDateComparator());

			boolean documentFound = false;
			Collections.reverse(groupBills);
			for (int i = 0; i < groupBills.size(); i++) {
				GroupAdminBill grpBill = (GroupAdminBill) groupBills.get(i);
				if (grpBill.getDate().equals(postingBillDate)) {
					doc = docArcBean.getGroupAdminBill(grpBill);
					output = doc.getContent();
					documentFound = true;
					break;
				} else {

					continue;
				}

			}

			if (!documentFound) {

				throw new DocumentNotFoundException(
						"The requested document not found");

			}

		} catch (DocumentNotFoundException docEx) {
			GroupAdminHelper.log.error("Error: " + docEx);

			throw new APIException("The requested document not found.", docEx);
		} catch (Exception e) {
			GroupAdminHelper.log.error("Error: " + e);
			e.printStackTrace();
			throw new APIException(
					"Error getting document list from ImageGatewayRetriever Service",
					e);
		}

		return output;
	}

	/**
	 * <p>getGroupAdminCertificateList.</p>
	 *
	 * @param groupNumber a {@link java.lang.String} object.
	 * @param dateFrom a {@link java.lang.String} object.
	 * @param dateTo a {@link java.lang.String} object.
	 * @param certId a {@link java.lang.String} object.
	 * @return a {@link java.util.List} object.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 * @throws java.text.ParseException if any.
	 */
	public List<GroupAdminCorbelDocument> getGroupAdminCertificateList(String groupNumber,
			String dateFrom, String dateTo, String certId) throws APIException,
			ParseException {

		SimpleDateFormat maskedDateFmt = new SimpleDateFormat(
				GroupAdminHelper.PATTERN_DATE_FORMAT);
		List<GroupAdminCorbelDocument> groupCerts = null;

		List<GroupAdminCorbelDocument> latestCert = new ArrayList<GroupAdminCorbelDocument>();

		try {
			Date fromDate = maskedDateFmt.parse(dateFrom);
			Date toDate = maskedDateFmt.parse(dateTo);


			GroupAdminHelper.log.debug("groupNumber: " + groupNumber
					+ " dateFrom:" + dateFrom + " dateTo:" + dateTo+ " certId="+certId);
			DocumentArchiveServiceRemoteBean docArcBean = new DocumentArchiveServiceRemoteBean();
			GroupAdminId groupAdminId = new GroupAdminId();
			groupAdminId.setGroupAdminIdentifier(groupNumber);
			groupAdminId.setCertId(certId);
			groupCerts = docArcBean.getGroupAdminCertList(groupAdminId,
					fromDate, toDate);
			GroupAdminHelper.log.debug("No of documents retrieved:"
					+ groupCerts.size());



			Collections.sort(groupCerts, new GroupCorbelDateComparator());

			String reportIdAdded = null;
			Collections.reverse(groupCerts);
			for (int i = 0; i < groupCerts.size(); i++) {
				GroupAdminCorbelDocument grpCert = (GroupAdminCorbelDocument) groupCerts
						.get(i);

				if(!StringUtils.equals(reportIdAdded,grpCert.getReportId())){
					latestCert.add(grpCert);
					reportIdAdded = grpCert.getReportId();
				}
			}

		} catch (Exception e) {
			GroupAdminHelper.log.error("Error: " + e);
			e.printStackTrace();
			throw new APIException(
					"Error getting document list from ImageGatewayRetriever Service",
					e);
		}

		return latestCert;
	}

	/**
	 * <p>getGroupAdminDentalCardList.</p>
	 *
	 * @param groupNumber a {@link java.lang.String} object.
	 * @param dateFrom a {@link java.lang.String} object.
	 * @param dateTo a {@link java.lang.String} object.
	 * @param dentalCardId a {@link java.lang.String} object.
	 * @return a {@link java.util.List} object.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 * @throws java.text.ParseException if any.
	 */
	public List<GroupAdminCorbelDocument> getGroupAdminDentalCardList(String groupNumber,
			String dateFrom, String dateTo, String dentalCardId)
			throws APIException, ParseException {

		SimpleDateFormat maskedDateFmt = new SimpleDateFormat(
				GroupAdminHelper.PATTERN_DATE_FORMAT);
		List<GroupAdminCorbelDocument> groupDentalCards = null;

		List<GroupAdminCorbelDocument> latestDentalCards = new ArrayList<GroupAdminCorbelDocument>();

		try {
			Date fromDate = maskedDateFmt.parse(dateFrom);
			Date toDate = maskedDateFmt.parse(dateTo);

			GroupAdminHelper.log.debug("groupNumber: " + groupNumber
					+ " dateFrom:" + dateFrom + " dateTo:" + dateTo+ "dentalCardId ="+dentalCardId);
			DocumentArchiveServiceRemoteBean docArcBean = new DocumentArchiveServiceRemoteBean();
			GroupAdminId groupAdminId = new GroupAdminId();
			groupAdminId.setGroupAdminIdentifier(groupNumber);
			groupAdminId.setDentalCardId(dentalCardId);
			groupDentalCards = docArcBean.getGroupAdminDentalCardList(groupAdminId,
					fromDate, toDate);
			GroupAdminHelper.log.debug("No. of documents retrieved:"
					+ groupDentalCards.size());


			Collections.sort(groupDentalCards, new GroupCorbelDateComparator());

			Collections.reverse(groupDentalCards);
			//TODO WHAT IS THIS?!
			for (int i = 0; i < groupDentalCards.size(); i++) {
				GroupAdminCorbelDocument grDentalCard = (GroupAdminCorbelDocument) groupDentalCards
						.get(i);
				latestDentalCards.add(grDentalCard);

				break;


			}

		} catch (Exception e) {
			GroupAdminHelper.log.error("Error: " + e);
			e.printStackTrace();
			throw new APIException(
					"Error getting document list from ImageGatewayRetriever Service",
					e);
		}

		return latestDentalCards;
	}

	/**
	 * <p>getGroupAdminCertificateDocument.</p>
	 *
	 * @param groupNumber a {@link java.lang.String} object.
	 * @param dateFrom a {@link java.lang.String} object.
	 * @param dateTo a {@link java.lang.String} object.
	 * @param reportId a {@link java.lang.String} object.
	 * @param certId a {@link java.lang.String} object.
	 * @return an array of {@link byte} objects.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 * @throws java.text.ParseException if any.
	 */
	public byte[] getGroupAdminCertificateDocument(String groupNumber,
			String dateFrom, String dateTo,String reportId, String certId)
			throws APIException, ParseException {

		SimpleDateFormat maskedDateFmt = new SimpleDateFormat(
				GroupAdminHelper.PATTERN_DATE_FORMAT);
		byte[] output = null;
		Document doc = null;
		try {
			Date fromDate = maskedDateFmt.parse(dateFrom);
			Date toDate = maskedDateFmt.parse(dateTo);


			GroupAdminHelper.log.debug("groupNumber: " + groupNumber
					+ " dateFrom:" + dateFrom + " dateTo:" + dateTo+" certid="+certId);
			DocumentArchiveServiceRemoteBean docArcBean = new DocumentArchiveServiceRemoteBean();
			GroupAdminId groupAdminId = new GroupAdminId();
			groupAdminId.setGroupAdminIdentifier(groupNumber);
			groupAdminId.setCertId(certId);
			List<GroupAdminCorbelDocument> groupCerts = docArcBean.getGroupAdminCertList(groupAdminId,
					fromDate, toDate);
			GroupAdminHelper.log.debug("No of documents retrieved:"
					+ groupCerts.size());
			Collections.sort(groupCerts, new GroupCorbelDateComparator());

			boolean documentFound = false;
			Collections.reverse(groupCerts);
			for (int i = 0; i < groupCerts.size(); i++) {
				GroupAdminCorbelDocument grpCertificate = (GroupAdminCorbelDocument) groupCerts
						.get(i);

				if (reportId.equals(grpCertificate.getReportId())) {
					doc = docArcBean.getGroupAdminCert(grpCertificate);
					output = doc.getContent();
					documentFound = true;
					break;
				}

			}

			if (!documentFound) {

				throw new DocumentNotFoundException(
						"The requested document not found");

			}

		} catch (DocumentNotFoundException docEx) {
			GroupAdminHelper.log.error("Error: " + docEx);

			throw new APIException("The requested document not found.", docEx);
		} catch (Exception e) {
			GroupAdminHelper.log.error("Error: " + e);
			e.printStackTrace();
			throw new APIException(
					"Error getting document list from ImageGatewayRetriever Service",
					e);
		}

		return output;
	}

	/**
	 * <p>getGroupAdminPolicyDocument.</p>
	 *
	 * @param groupNumber a {@link java.lang.String} object.
	 * @param dateFrom a {@link java.lang.String} object.
	 * @param dateTo a {@link java.lang.String} object.
	 * @param reportId a {@link java.lang.String} object.
	 * @return an array of {@link byte} objects.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 * @throws java.text.ParseException if any.
	 */
	public byte[] getGroupAdminPolicyDocument(String groupNumber,
			String dateFrom, String dateTo, String reportId)
			throws APIException, ParseException {

		SimpleDateFormat maskedDateFmt = new SimpleDateFormat(
				GroupAdminHelper.PATTERN_DATE_FORMAT);
		byte[] output = null;
		Document doc = null;
		try {
			Date fromDate = maskedDateFmt.parse(dateFrom);
			Date toDate = maskedDateFmt.parse(dateTo);


			GroupAdminHelper.log.debug("groupNumber: " + groupNumber
					+ " dateFrom:" + dateFrom + " dateTo:" + dateTo);
			DocumentArchiveServiceRemoteBean docArcBean = new DocumentArchiveServiceRemoteBean();
			GroupAdminId groupAdminId = new GroupAdminId();
			groupAdminId.setGroupAdminIdentifier(groupNumber);
			List<GroupAdminCorbelDocument> groupPolicies = docArcBean.getGroupAdminPolicyList(
					groupAdminId, fromDate, toDate);
			GroupAdminHelper.log.debug("No of documents retrieved:"
					+ groupPolicies.size());

			Collections.sort(groupPolicies, new GroupCorbelDateComparator());

			boolean documentFound = false;
			Collections.reverse(groupPolicies);
			for (int i = 0; i < groupPolicies.size(); i++) {
				GroupAdminCorbelDocument grpPolicy = (GroupAdminCorbelDocument) groupPolicies
						.get(i);

				if (reportId.equals(grpPolicy.getReportId())) {
					doc = docArcBean.getGroupAdminPolicy(grpPolicy);
					output = doc.getContent();
					documentFound = true;
					break;
				}

			}

			if (!documentFound) {

				throw new DocumentNotFoundException(
						"The requested document not found");

			}

		} catch (DocumentNotFoundException docEx) {
			GroupAdminHelper.log.error("Error: " + docEx);

			throw new APIException("The requested document not found.", docEx);
		} catch (Exception e) {
			GroupAdminHelper.log.error("Error: " + e);
			e.printStackTrace();
			throw new APIException(
					"Error getting document list from ImageGatewayRetriever Service",
					e);
		}

		return output;
	}



	/**
	 * <p>getGroupAdminDentalCard.</p>
	 *
	 * @param groupNumber a {@link java.lang.String} object.
	 * @param dateFrom a {@link java.lang.String} object.
	 * @param dateTo a {@link java.lang.String} object.
	 * @param reportId a {@link java.lang.String} object.
	 * @param dentalCardId a {@link java.lang.String} object.
	 * @return an array of {@link byte} objects.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 * @throws java.text.ParseException if any.
	 */
	public byte[] getGroupAdminDentalCard(String groupNumber,
			String dateFrom, String dateTo, String reportId,String dentalCardId)
			throws APIException, ParseException {

		SimpleDateFormat maskedDateFmt = new SimpleDateFormat(
				GroupAdminHelper.PATTERN_DATE_FORMAT);
		byte[] output = null;
		Document doc = null;
		try {
			Date fromDate = maskedDateFmt.parse(dateFrom);
			Date toDate = maskedDateFmt.parse(dateTo);


			GroupAdminHelper.log.debug("groupNumber: " + groupNumber
					+ " dateFrom:" + dateFrom + " dateTo:" + dateTo+" dentalCardId="+dentalCardId);
			DocumentArchiveServiceRemoteBean docArcBean = new DocumentArchiveServiceRemoteBean();
			GroupAdminId groupAdminId = new GroupAdminId();
			groupAdminId.setGroupAdminIdentifier(groupNumber);
			groupAdminId.setDentalCardId(dentalCardId);
			List<GroupAdminCorbelDocument> dentalCards = docArcBean.getGroupAdminDentalCardList(
					groupAdminId, fromDate, toDate);
			GroupAdminHelper.log.debug("No of documents retrieved:"
					+ dentalCards.size());

			Collections.sort(dentalCards, new GroupCorbelDateComparator());

			boolean documentFound = false;
			Collections.reverse(dentalCards);
			for (int i = 0; i < dentalCards.size(); i++) {
				GroupAdminCorbelDocument dentalCard = (GroupAdminCorbelDocument) dentalCards
						.get(i);

				if (reportId.equals(dentalCard.getReportId())) {
					doc = docArcBean.getGroupAdminPolicy(dentalCard);
					output = doc.getContent();
					documentFound = true;
					break;
				}

			}

			if (!documentFound) {

				throw new DocumentNotFoundException(
						"The requested document not found");

			}

		} catch (DocumentNotFoundException docEx) {
			GroupAdminHelper.log.error("Error: " + docEx);

			throw new APIException("The requested document not found.", docEx);
		} catch (Exception e) {
			GroupAdminHelper.log.error("Error: " + e);
			e.printStackTrace();
			throw new APIException(
					"Error getting document list from ImageGatewayRetriever Service",
					e);
		}

		return output;
	}


	/**
	 * Show only 1 latest policy document per reportid from web collection folder.
	 *
	 * @param groupNumber a {@link java.lang.String} object.
	 * @param dateFrom a {@link java.lang.String} object.
	 * @param dateTo a {@link java.lang.String} object.
	 * @return a {@link java.util.ArrayList} object.
	 */
	public ArrayList<GroupAdminCorbelDocument> getGroupAdminPolicyDocumentList(String groupNumber,
			String dateFrom, String dateTo){
		GroupAdminHelper.log.debug("GroupAdminHelper getGroupAdminPolicyDocumentList:dateFrom="
						+ dateFrom + " dateTo=" + dateTo);
		SimpleDateFormat maskedDateFmt = new SimpleDateFormat(
				GroupAdminHelper.PATTERN_DATE_FORMAT);
		ArrayList<GroupAdminCorbelDocument> groupPolicies = new ArrayList<GroupAdminCorbelDocument>();

		ArrayList<GroupAdminCorbelDocument> latestPolicy = new ArrayList<GroupAdminCorbelDocument>();

		try {
			Date fromDate = maskedDateFmt.parse(dateFrom);
			Date toDate = maskedDateFmt.parse(dateTo);

			GroupAdminHelper.log.debug("groupNumber: " + groupNumber
					+ " fromDate:" + fromDate + " toDate:" + toDate);
			DocumentArchiveServiceRemoteBean docArcBean = new DocumentArchiveServiceRemoteBean();
			GroupAdminId groupAdminId = new GroupAdminId();
			groupAdminId.setGroupAdminIdentifier(groupNumber);
			groupPolicies = docArcBean.getGroupAdminPolicyList(groupAdminId,
					fromDate, toDate);
			GroupAdminHelper.log.debug("No of documents retrieved:"
					+ groupPolicies.size());

			Collections.sort(groupPolicies, new GroupCorbelDateComparator());

			String reportIdsAdded = null;

			Collections.reverse(groupPolicies);
			for (int i = 0; i < groupPolicies.size(); i++) {
				GroupAdminCorbelDocument grpPolicy = groupPolicies
						.get(i);


					if(latestPolicy.size() >0){
						for(int j = 0; j<latestPolicy.size(); j++){

							if(StringUtils.equals(grpPolicy.getReportId(),latestPolicy.get(j).getReportId())){

						   		reportIdsAdded = reportIdsAdded+"|"+latestPolicy.get(j).getReportId();

							}
						}

					}


					if(reportIdsAdded == null){

						reportIdsAdded = reportIdsAdded +"|" + grpPolicy.getReportId();

						latestPolicy.add(grpPolicy);


					}else if(reportIdsAdded.indexOf(grpPolicy.getReportId()) == -1){
                      reportIdsAdded = reportIdsAdded +"|" + grpPolicy.getReportId();

					  latestPolicy.add(grpPolicy);

				   }




			}

		} catch (Exception e) {
			GroupAdminHelper.log.error("Error: " + e);
			e.printStackTrace();
			GroupAdminHelper.log.error("Error getting document list from ImageGatewayRetriever Service",e);
		}

		return latestPolicy;
	}


}
