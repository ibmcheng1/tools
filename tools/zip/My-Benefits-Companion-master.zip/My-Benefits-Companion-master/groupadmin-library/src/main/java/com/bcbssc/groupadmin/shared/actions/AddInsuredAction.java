/*
 * @(#)AddInsuredAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.actions;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.dto.AddCoverageItem;
import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;
import com.bcbssc.groupadmin.shared.forms.AddCoverageForm;
import com.bcbssc.groupadmin.shared.forms.AddInsuredDetailsForm;
import com.bcbssc.groupadmin.shared.forms.InsuredDataForm;
import com.bcbssc.groupadmin.shared.services.InsuredServices;
import com.bcbssc.struts.action.SimpleDispatchAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * Group Admin Add Insured Action
 *
 * This class provides control processing the add insured action.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class AddInsuredAction extends SimpleDispatchAction {

    /** log4j logger */
    private static final Logger log = Logger.getLogger(AddInsuredAction.class
            .getName());

    /**
     * <p>Constructor for AddInsuredAction.</p>
     */
    public AddInsuredAction() {
        super();
        if (AddInsuredAction.log.isDebugEnabled()) {
            AddInsuredAction.log.debug("Created AddInsuredAction object.");
        }
    }

    /**
     * Displays the intial add insured form.
     *
     * @param mapping
     *            the ActionMapping used to select this instance
     * @param form
     *            the optional bean for this request (if any)
     * @param request
     *            the HTTP request we are processing
     * @param response
     *            the HTTP request we are creating
     * @return describes where and how control should be forwarded, or null if
     *         the response has already been completed.
     * @throws java.lang.Exception if any.
     */
    public ActionForward displayForm(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        return this.displayForm(false, mapping, form, request, response);
    }

    /**
     * Displays the intial add insured form with addNewGroup set to true
     *
     * @param mapping
     *            the ActionMapping used to select this instance
     * @param form
     *            the optional bean for this request (if any)
     * @param request
     *            the HTTP request we are processing
     * @param response
     *            the HTTP request we are creating
     * @return describes where and how control should be forwarded, or null if
     *         the response has already been completed.
     * @throws java.lang.Exception if any.
     */
    public ActionForward displayAddGroupForm(ActionMapping mapping,
            ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        // Call displayForm with addNewGroup = true
        return this.displayForm(true, mapping, form, request, response);
    }

    /**
     * Displays the intial add insured form with addNewGroup set to true
     *
     * @param addNewGroup
     *            value of addNewGroup in the form
     * @param mapping
     *            the ActionMapping used to select this instance
     * @param form
     *            the optional bean for this request (if any)
     * @param request
     *            the HTTP request we are processing
     * @param response
     *            the HTTP request we are creating
     * @return describes where and how control should be forwarded, or null if
     *         the response has already been completed.
     * @throws java.lang.Exception if any.
     */
    public ActionForward displayForm(boolean addNewGroup,
            ActionMapping mapping, ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        AddInsuredDetailsForm addInsuredDetailsForm = (AddInsuredDetailsForm) this
                .getForm("addInsuredDetailsForm", "/addInsuredDetails", request);
        addInsuredDetailsForm.setAddNewGroup(addNewGroup);
        addInsuredDetailsForm
                .setUserDTO((GroupAdminUserDTO) request
                        .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
        request.setAttribute("addInsuredDetailsForm", addInsuredDetailsForm);
        return mapping
                .findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
    }

    /**
     * Processes the specified HTTP request, and creates the corresponding HTTP
     * response.
     *
     * @param mapping
     *            the ActionMapping used to select this instance
     * @param form
     *            the optional bean for this request (if any)
     * @param request
     *            the HTTP request we are processing
     * @param response
     *            the HTTP request we are creating
     * @return describes where and how control should be forwarded, or null if
     *         the response has already been completed.
     * @throws java.lang.Exception if any.
     */
    public ActionForward addInsured(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        ActionForward returnActionForward = null;
        AddInsuredDetailsForm insuredForm = (AddInsuredDetailsForm) form;

        InsuredDataDTO insuredDataDTO = new InsuredDataDTO();
        BeanUtils.copyProperties(insuredDataDTO, insuredForm);
        InsuredServices insuredServices = new InsuredServices(
                CommonUtils.getIniFile(this.getServlet()),
                CommonUtils.getGcomIniFile(this.getServlet()),
                (GroupAdminUserDTO) request
                        .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
        String error = insuredServices.processAddDetails(insuredDataDTO,
                insuredForm.getDentalCoverage());
        if (error != null) {
            ActionErrors errors = new ActionErrors();
            errors.add("ssn", new ActionMessage("errors.duplicate.id"));
            this.saveErrors(request, errors);
            this.addGlobalRequestMessage(request, error);
            returnActionForward = mapping.getInputForward();
        } else {

            AddCoverageForm coverageForm = (AddCoverageForm) this.getForm(
                    "addCoverageForm", "/addCoverage", request);
            BeanUtils.copyProperties(coverageForm, insuredDataDTO);

            if (insuredForm.getGroupChanged()) {
                AddInsuredAction.log.debug(" group changed = "
                        + coverageForm.getGroup());
                // if group was changed, clear coverage class & coverages
                coverageForm.clear();
            } else {
                // this is for an add insured employee path only
                AddCoverageItem.checkSpecialConditions(coverageForm,
                        coverageForm.getCoverageItems());
            }
            request.setAttribute("addCoverageForm", coverageForm);
            returnActionForward = mapping
                    .findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
        }
        return returnActionForward;
    }

    /**
     * Forwards to the add insured form, copying data from the input form.
     *
     * @param mapping
     *            the ActionMapping used to select this instance
     * @param form
     *            the optional bean for this request (if any)
     * @param request
     *            the HTTP request we are processing
     * @param response
     *            the HTTP request we are creating
     * @return describes where and how control should be forwarded, or null if
     *         the response has already been completed.
     * @throws java.lang.Exception if any.
     */
    public ActionForward breadcrumbForward(ActionMapping mapping,
            ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        InsuredDataForm insuredDataForm = (InsuredDataForm) form;
        AddInsuredDetailsForm addInsuredDetailsForm = (AddInsuredDetailsForm) this
                .getForm("addInsuredDetailsForm", "/addInsuredDetails", request);
        BeanUtils.copyProperties(addInsuredDetailsForm, insuredDataForm);
        addInsuredDetailsForm
                .setUserDTO((GroupAdminUserDTO) request
                        .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
        request.setAttribute("addInsuredDetailsForm", addInsuredDetailsForm);
        return mapping
                .findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
    }
}
