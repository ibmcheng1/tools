/**
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.groupadmin.shared.forms;

/**
 * The purpose of this class is to load any session related variables for
 * further use. So we need to put this into session. This class will be used to
 * load the initial bank details for a perticular group, based on the CGA choice
 * or assigned group, to compare if CGA changed a bank details or adding new
 * bank details. And also it can be use any other session related variables.
 *
 * @author X22R (Srini Gandu)
 * @version 1.0 Date 04/12/2006
 */
public class CGAUtilityBean extends com.bcbssc.netsys.web.SessionDataBean
		implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4177809994165035482L;

	/**
	 * <p>Constructor for CGAUtilityBean.</p>
	 */
	public CGAUtilityBean() {
		super();
	}

	/** name of the bank */
	private String bankName;

	/** bank routing number */
	private String bankRoutingNumber;

	/** bank account number */
	private String bankAccountNumber;

	/** account holder's name */
	private String accountHolderName;

	/** holds the total number of group count */
	private String groupCount;

	/**
	 * <p>Getter for the field <code>accountHolderName</code>.</p>
	 *
	 * @return Returns the accountHolderName.
	 */
	public String getAccountHolderName() {
		return this.accountHolderName;
	}

	/**
	 * <p>Setter for the field <code>accountHolderName</code>.</p>
	 *
	 * @param accountHolderName
	 *            The accountHolderName to set.
	 */
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	/**
	 * <p>Getter for the field <code>bankAccountNumber</code>.</p>
	 *
	 * @return Returns the bankAccountNumber.
	 */
	public String getBankAccountNumber() {
		return this.bankAccountNumber;
	}

	/**
	 * <p>Setter for the field <code>bankAccountNumber</code>.</p>
	 *
	 * @param bankAccountNumber
	 *            The bankAccountNumber to set.
	 */
	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	/**
	 * <p>Getter for the field <code>bankName</code>.</p>
	 *
	 * @return Returns the bankName.
	 */
	public String getBankName() {
		return this.bankName;
	}

	/**
	 * <p>Setter for the field <code>bankName</code>.</p>
	 *
	 * @param bankName
	 *            The bankName to set.
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * <p>Getter for the field <code>bankRoutingNumber</code>.</p>
	 *
	 * @return Returns the bankRoutingNumber.
	 */
	public String getBankRoutingNumber() {
		return this.bankRoutingNumber;
	}

	/**
	 * <p>Setter for the field <code>bankRoutingNumber</code>.</p>
	 *
	 * @param bankRoutingNumber
	 *            The bankRoutingNumber to set.
	 */
	public void setBankRoutingNumber(String bankRoutingNumber) {
		this.bankRoutingNumber = bankRoutingNumber;
	}

	/**
	 * <p>Getter for the field <code>groupCount</code>.</p>
	 *
	 * @return Returns the groupCount.
	 */
	public String getGroupCount() {
		return this.groupCount;
	}

	/**
	 * <p>Setter for the field <code>groupCount</code>.</p>
	 *
	 * @param groupCount
	 *            The groupCount to set.
	 */
	public void setGroupCount(String groupCount) {
		this.groupCount = groupCount;
	}

}
