/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mq/GcomTransaction.java_v  $
 * $Workfile:   GcomTransaction.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:15:58  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mq/GcomTransaction.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:15:58   EN80
 * Initial revision.
 * 
 *    Rev 1.21   Apr 28 2009 10:20:00   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.20   Jun 23 2008 15:17:16   rcf57
 * C15021 : Not sending the conditional 204,2055,206 and 806 transactions for a salary modification update anymore.This was done per GCOM group recommendation.
 *
 *    Rev 1.19   May 22 2008 11:53:38   rcf57
 * C15021 : Starting to pass the header record also for the new Salary change 202 transaction.
 *
 *    Rev 1.18   May 20 2008 17:54:46   rcf57
 * C15021 : Added a new function to send the new Salary change MQ.
 *
 *    Rev 1.17   Apr 27 2006 09:19:16   rx22r
 * LI1040 Changes: Added new methods for bank information and payment information to send those transactions to que by using W841, W183 copy libraries.
 *
 *    Rev 1.16   May 04 2005 09:26:54   rdq70
 * Start new dependent Namd IDs after last existing one.
 *
 *    Rev 1.15   Apr 27 2005 17:01:12   rdq70
 * Distinguish Division Original Effective Date from Original Effective Date.
 *
 *    Rev 1.14   Apr 20 2005 15:28:28   rdq70
 * Send 204 if there are dependent coverages instead of only if they changed.
 *
 *    Rev 1.13   Mar 23 2005 14:51:30   rxr93
 * CLGRPW029 check addressAdded flag on 806
 *
 *    Rev 1.12   Mar 09 2005 14:31:10   rdq70
 * Remove superceded coverages before sending Change.
 *
 *    Rev 1.11   Feb 18 2005 15:54:52   rdq70
 * Fixed change dependent logic.
 *
 *    Rev 1.10   Feb 16 2005 14:57:24   rdq70
 * Stop throwing error on send message since there is now retry logic.
 *
 *    Rev 1.9   Feb 15 2005 18:52:44   rdq70
 * Made createMessenger() public.
 *
 *    Rev 1.8   Feb 14 2005 14:37:16   rdq70
 * Corrected conditions for Change transactions.
 *
 *    Rev 1.7   Feb 11 2005 14:40:54   rdq70
 * Removed debug logging of entire message since it is now logged separately.
 *
 *    Rev 1.6   Feb 11 2005 11:52:42   rdq70
 * Send activityCode instead of transactionNumber for 806.
 *
 *    Rev 1.5   Feb 10 2005 18:19:06   rdq70
 * Added sendSpecialRequest.
 *
 *    Rev 1.4   Feb 09 2005 18:00:44   rdq70
 * Corrected padding for all dependents.
 *
 *    Rev 1.3   Feb 07 2005 17:35:36   rdq70
 * Send 205/206 for spouse.
 *
 *    Rev 1.2   Feb 07 2005 15:34:42   rdq70
 * Added logging of entire message.
 *
 *    Rev 1.1   Feb 03 2005 10:46:00   rdq70
 * Use InsuredSearchDTO instead of InsuredDataDTO.
 *
 *    Rev 1.0   Feb 01 2005 16:19:02   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.mq; 

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;

import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.dom4j.DocumentException;

import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.groupadmin.shared.dto.BankInformationDTO;
import com.bcbssc.groupadmin.shared.dto.CoverageItem;
import com.bcbssc.groupadmin.shared.dto.Dependent;
import com.bcbssc.groupadmin.shared.dto.InsuredSearchDTO;
import com.bcbssc.groupadmin.shared.dto.SpecialRequestDTO;
import com.bcbssc.groupadmin.shared.mapper.BeanMapper;
import com.bcbssc.netsys.Config;
import com.bcbssc.netsys.LinkedException;
import com.bcbssc.netsys.web.mapper.CopybookMapper;
import com.bcbssc.netsys.web.mapper.MapperManager;
import com.bcbssc.struts.common.DateBean;

/**
 * The unit-of-work class for adding or changing insured employees. It uses
 * mappers to retrieve data from a base bean and populate fixed-width copybook
 * records. Then it sends these copybooks as MQ messages.
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class GcomTransaction {

	/** The Log4J <code>Logger</code> for this class. */
	private static final Logger log = Logger.getLogger(GcomTransaction.class);

	/** The number of dependent repeats in the copybook. */
	private static final int DEPENDENT_REPEATS = 7;

	/** The INI section which will be parsed for configuration settings. */
	private static final String INI_SECTION = "DESTINATIONS";

	/**
	 * The INI section which will be parsed for custom headers for outbound
	 * messages.
	 */
	private static final String JMS_HEADERS_SECTION = "JMS_HEADERS";

	/** The configuration INI file for this transaction. */
	private final String iniFile;

	/** The JSM messenger for this transaciton. */
	private GcomMessenger messenger;

	/**
	 * Creates a new GcomTransaction based on the given configuration file.
	 *
	 * @param iniFile -
	 *            the configuration INI file for this transaction.
	 */
	public GcomTransaction(String iniFile) {
		this.iniFile = iniFile;
	}

	/**
	 * This will send the W841 WEB Banking Transaction via MQ
	 *
	 * @param bankInfoDTO a {@link com.bcbssc.groupadmin.shared.dto.BankInformationDTO} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @throws com.bcbssc.netsys.LinkedException if any.
	 */
	public void sendBankInformation(BankInformationDTO bankInfoDTO,
			HttpServletRequest request) throws LinkedException {
		// Create the messanger.
		this.messenger = this.createMessenger();

		// Use this string to format the message.
		final StringBuffer message = new StringBuffer(5120);

		// set the transaction number into request object.
		request.setAttribute("transactionNumber", "841");

		// append the bean mapped string.
		message.append(this.buildBankInfoCopybook("BankingInformation",
				bankInfoDTO, request));

		// Send all messages together
		try {
			this.sendMessage(message.toString(), "BankInfo");
		} finally {
			// close the session no matter what
			if (this.messenger != null) {
				this.messenger.complete();
			}
		}
	}

	/**
	 * This will send the W183 WEB Payment Transaction via MQ
	 *
	 * @param bankInfoDTO a {@link com.bcbssc.groupadmin.shared.dto.BankInformationDTO} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @throws com.bcbssc.netsys.LinkedException if any.
	 */
	public void sendPaymentInformation(BankInformationDTO bankInfoDTO,
			HttpServletRequest request) throws LinkedException {
		// Create the messanger.
		this.messenger = this.createMessenger();

		// Use this string to format the message.
		final StringBuffer message = new StringBuffer(5120);

		// set the transaction number into request object.
		request.setAttribute("transactionNumber", "183");

		// append the bean mapped string.
		message.append(this.buildBankInfoCopybook("PaymentInformation",
				bankInfoDTO, request));

		// Send all messages together
		try {
			this.sendMessage(message.toString(), "Payment Information");
		} finally {
			// close the session no matter what
			if (this.messenger != null) {
				this.messenger.complete();
			}
		}
	}

	/**
	 * Sends the following MQ messages to add an insured employee: T001, T201,
	 * T203, T205, T806.
	 *
	 * @param dataBean -
	 *            the bean containing the data for the message.
	 * @param request -
	 *            the HTTP servlet request.
	 * @throws com.bcbssc.netsys.LinkedException
	 *             if an error occurs.
	 */
	public void addInsuredEmployee(InsuredSearchDTO dataBean,
			HttpServletRequest request)

	throws LinkedException {

		this.messenger = this.createMessenger();

		if ("".equals(dataBean.getOriginalEffectiveDate().getYear())) {
			dataBean.setOriginalEffectiveDate(dataBean.getFirstEffectiveDate());
		}

		final StringBuffer message = new StringBuffer(5120);

		// T001
		request.setAttribute("transactionNumber", "001");
		message.append(this.buildGcomCopybook("MiscelleanousCoverage",
				dataBean, request));

		// T201
		request.setAttribute("transactionNumber", "201");
		message.append(this.buildGcomCopybook("Cert", dataBean, request));

		// T203
		if ((dataBean.getSpouseCoverageItems().size() > 0)
				|| (dataBean.getDependentCoverageItems().size() > 0)) {

			request.setAttribute("transactionNumber", "203");
			message.append(this.buildGcomCopybook("CoverageItem", dataBean,
					request));
		}

		// T205
		request.setAttribute("transactionNumber", "205");
		message.append(this.buildDependentCopybooks(dataBean, request));

		// T806 is only needed if the Address exists
		if (!"".equals(dataBean.getAddressLine1())) {
			request.setAttribute("activityCode", "A");
			message.append(this.buildGcomCopybook("NameAddressTrailer",
					dataBean, request));
		}

		// Send all messages together
		try {
			this.sendMessage(message.toString(), "Add");
		} finally {
			// close the session no matter what
			if (this.messenger != null) {
				this.messenger.complete();
			}
		}
	}

	/**
	 * Sends the following MQ messages to change an insured employee: T002,
	 * T202, T204, T206, T806.
	 *
	 * @param dataBean -
	 *            the bean containing the data for the message.
	 * @param request -
	 *            the HTTP servlet request.
	 * @throws com.bcbssc.netsys.LinkedException
	 *             if an error occurs.
	 */
	public void changeSalary(InsuredSearchDTO dataBean,
			HttpServletRequest request) throws LinkedException {

		this.messenger = this.createMessenger();
		final StringBuffer message = new StringBuffer(5120);
		GcomTransaction.removeSupersededCoverages(dataBean);

		// T002
		request.setAttribute("transactionNumber", "002");
		message.append(this.buildGcomCopybook("MiscelleanousCoverage",
				dataBean, request));

		// T202
		request.setAttribute("transactionNumber", "202");
		message.append(this.buildGcomCopybook("Salary", dataBean, request));

		// Send all messages together
		try {
			this.sendMessage(message.toString(), "Change");
		} finally {
			// close the session no matter what
			if (this.messenger != null) {
				this.messenger.complete();
			}
		}
	}

	/**
	 * Sends the following MQ messages to change an insured employee: T002,
	 * T202, T204, T206, T806.
	 *
	 * @param dataBean -
	 *            the bean containing the data for the message.
	 * @param request -
	 *            the HTTP servlet request.
	 * @throws com.bcbssc.netsys.LinkedException
	 *             if an error occurs.
	 */
	public void changeInsuredEmployee(InsuredSearchDTO dataBean,
			HttpServletRequest request) throws LinkedException {

		this.messenger = this.createMessenger();
		final StringBuffer message = new StringBuffer(5120);
		GcomTransaction.removeSupersededCoverages(dataBean);

		// T002
		request.setAttribute("transactionNumber", "002");
		message.append(this.buildGcomCopybook("MiscelleanousCoverage",
				dataBean, request));

		// T202
		request.setAttribute("transactionNumber", "202");
		message.append(this.buildGcomCopybook("Cert", dataBean, request));

		// T204
		if ((dataBean.getSpouseCoverageItems().size() > 0)
				|| (dataBean.getDependentCoverageItems().size() > 0)) {

			request.setAttribute("transactionNumber", "204");
			message.append(this.buildGcomCopybook("CoverageItem", dataBean,
					request));
		}

		// T205
		request.setAttribute("transactionNumber", "205");
		message.append(this.buildDependentCopybooks(dataBean, request));

		// T206
		request.setAttribute("transactionNumber", "206");
		message.append(this.buildDependentCopybooks(dataBean, request));

		// T806
		if (dataBean.isAddressUpdated()) {
			if (dataBean.isAddressAdded()) {
				request.setAttribute("activityCode", "A");
			} else {
				request.setAttribute("activityCode", "U");
			}
			message.append(this.buildGcomCopybook("NameAddressTrailer",
					dataBean, request));
		}

		// Send all messages together
		try {
			this.sendMessage(message.toString(), "Change");
		} finally {
			// close the session no matter what
			if (this.messenger != null) {
				this.messenger.complete();
			}
		}
	}

	/**
	 * Sends the T217 MQ messages.
	 *
	 * @param dataBean -
	 *            the bean containing the data for the message.
	 * @param request -
	 *            the HTTP servlet request.
	 * @throws com.bcbssc.netsys.LinkedException
	 *             if an error occurs.
	 */
	public void sendSpecialRequest(SpecialRequestDTO dataBean,
			HttpServletRequest request) throws LinkedException {

		this.messenger = this.createMessenger();
		final String copybook = this.buildGcomCopybook("SpecialRequest",
				dataBean, request);

		try {
			this.sendMessage(copybook, "SpecialRequest");
		} finally {
			// close the session no matter what
			if (this.messenger != null) {
				this.messenger.complete();
			}
		}
	}

	/**
	 * Creates a <code>GcomMessenger</code> with the values from this
	 * transaction's configuration file.
	 *
	 * @return a {@link com.bcbssc.groupadmin.shared.mq.GcomMessenger} object.
	 */
	public GcomMessenger createMessenger() {
		GcomMessenger messenger = null;
		try {
			messenger = new GcomMessenger(new InitialContext(), Constants.CONNECTION_FACTORY);

			messenger.setConnectionName("GCOM");
			messenger.setJndiMode(true);
			messenger.setConfigFile(this.iniFile);
			messenger.setDestinationName(Constants.GCOM_QUEUE);
			messenger.setOutboundMessageHeaders(Config.getConfigSection(
					GcomTransaction.JMS_HEADERS_SECTION, this.iniFile));
		} catch (Exception e) {
			GcomTransaction.log.error("Error attempting to create Messenger ", e);
		}
		return messenger;
	}

	/**
	 * Builds a copybook for the bank information and payment information data.
	 * 
	 * @param name -
	 *            the name of the copybook.
	 * @param dataBean -
	 *            the bean containing the data for the message.
	 * @param request -
	 *            the HTTP servlet request.
	 * @return the generated copybook.
	 * @throws LinkedException
	 *             if an error occurs.
	 */
	private String buildBankInfoCopybook(String name,
			BankInformationDTO bankInfoDTO, HttpServletRequest request)
			throws LinkedException {

		final Hashtable data = this.buildBankInfoTaskData("send" + name,
				bankInfoDTO, request);

		if (GcomTransaction.log.isDebugEnabled()) {
			GcomTransaction.log.debug("Task send" + name
					+ " successful. Table data:\n" + data);
		}

		final String copybookData = this.buildCopybook(name, data);

		if (GcomTransaction.log.isDebugEnabled()) {
			GcomTransaction.log.debug("Generated copybook record:\n"
					+ copybookData);
		}

		return copybookData;
	}

	/**
	 * Builds a copybook that is part of a CGOM transaction.
	 * 
	 * @param name -
	 *            the name of the copybook.
	 * @param dataBean -
	 *            the bean containing the data for the message.
	 * @param request -
	 *            the HTTP servlet request.
	 * 
	 * @return the generated copybook.
	 * 
	 * @throws LinkedException
	 *             if an error occurs.
	 */
	private String buildGcomCopybook(String name, InsuredSearchDTO dataBean,
			HttpServletRequest request) throws LinkedException {

		final Hashtable data = this.buildTaskData("send" + name, dataBean,
				request);

		if (GcomTransaction.log.isDebugEnabled()) {
			GcomTransaction.log.debug("Task send" + name
					+ " successful. Table data:\n" + data);
		}

		final String copybookData = this.buildCopybook(name, data);

		if (GcomTransaction.log.isDebugEnabled()) {
			GcomTransaction.log.debug("Generated copybook record:\n"
					+ copybookData);
		}

		return copybookData;
	}

	/**
	 * Sends a message for the given copybook.
	 * 
	 * @param message -
	 *            the message body in text form.
	 * @param name -
	 *            a name for logging only.
	 */
	private void sendMessage(String message, String name) {
		try {
			String id = this.messenger.sendMessage(message);
			if (GcomTransaction.log.isDebugEnabled()) {
				GcomTransaction.log.debug("Successfully sent " + name
						+ " message with ID: " + id);
			}
		} catch (Exception e) {
			GcomTransaction.log.error("Error attempting to send message: "
					+ name, e);
		}
	}

	/**
	 * Builds an intermediary map of data for use in the copybook generation
	 * process.
	 * 
	 * @param taskName
	 *            The name of the 'task' or xml rules for building the map.
	 * @param dataBean -
	 *            the bean containing the data for the message.
	 * @return a populated <code>Map</code> suitable for generating a copybook
	 *         record.
	 * @throws LinkedException
	 *             if an error occurs.
	 */
	private Hashtable buildBankInfoTaskData(String taskName,
			BankInformationDTO bankInfoDTO, HttpServletRequest request)
			throws LinkedException {
		GcomTransaction.log.debug("buildBankInfoTaskData:company code="
				+ bankInfoDTO.getCompany());
		GcomTransaction.log.debug("buildBankInfoTaskData:group number ="
				+ bankInfoDTO.getGroupNumber());
		BeanMapper dataMapper = null;

		try {
			dataMapper = (BeanMapper) MapperManager.getMapperForApp("GCOM",
					this.iniFile, BeanMapper.class);
		} catch (IllegalArgumentException iae) {
			GcomTransaction.log
					.error("Error getting BeanMapper for retrieving task data for "
							+ taskName);
			throw iae;
		}

		Hashtable taskData = null;

		try {
			taskData = dataMapper.getTaskData(taskName, bankInfoDTO, request);
		} catch (DocumentException exception) {
			GcomTransaction.log
					.error("Error occured in creating task data hash table.");
			throw new LinkedException(
					"Error attempting to build data table for mapping ",
					exception);
		}

		return taskData;
	}

	/**
	 * Builds an intermediary map of data for use in the copybook generation
	 * process.
	 * 
	 * @param taskName
	 *            The name of the 'task' or xml rules for building the map.
	 * @param dataBean -
	 *            the bean containing the data for the message.
	 * 
	 * @return a populated <code>Map</code> suitable for generating a copybook
	 *         record.
	 * 
	 * @throws LinkedException
	 *             if an error occurs.
	 */
	private Hashtable buildTaskData(String taskName, InsuredSearchDTO dataBean,
			HttpServletRequest request) throws LinkedException {

		BeanMapper dataMapper = null;

		try {
			dataMapper = (BeanMapper) MapperManager.getMapperForApp("GCOM",
					this.iniFile, BeanMapper.class);
		} catch (IllegalArgumentException iae) {
			GcomTransaction.log
					.error("Error getting BeanMapper for retrieving task data for "
							+ taskName);
			throw iae;
		}

		Hashtable taskData = null;

		try {
			taskData = dataMapper.getTaskData(taskName, dataBean, request);
		} catch (DocumentException exception) {
			GcomTransaction.log
					.error("Error occured whlie creating task data hash table.");
			throw new LinkedException(
					"Error attempting to build data table for mapping ",
					exception);
		}

		return taskData;
	}

	/**
	 * Uses a <code>CopybookMapper</code> to build a fixed-width copybook
	 * record.
	 * 
	 * @param mapperKey -
	 *            the name of the mapper object to request from
	 *            <code>MapperManager</code>.
	 * @param dataMap -
	 *            the intermediary map of data whose keys are copybook element
	 *            names, used in the copybook generation process.
	 * 
	 * @return a fixed-width copybook record.
	 */
	private String buildCopybook(String mapperKey, Hashtable dataMap) {
		CopybookMapper copybookMapper = null;

		try {
			copybookMapper = (CopybookMapper) MapperManager.getMapperForApp(
					mapperKey, this.iniFile, CopybookMapper.class);
		} catch (IllegalArgumentException iae) {
			GcomTransaction.log.error("Error creating CopybookMapper named "
					+ mapperKey);
			throw iae;
		}

		return copybookMapper.generateCopybook(dataMap);
	}

	/**
	 * Builds the dependent copybooks.
	 * 
	 * @param dataBean -
	 *            the bean containing the data for the message.
	 * @param request -
	 *            the HTTP servlet request.
	 * 
	 * @return the dependent copybooks.
	 * 
	 * @throws LinkedException
	 *             if an error occurs.
	 */
	private String buildDependentCopybooks(InsuredSearchDTO dataBean,
			HttpServletRequest request) throws LinkedException {

		final StringBuffer buf = new StringBuffer(1024);
		int lastNameId = 0;

		// Use all dependents (including spouse)
		final ArrayList origList = dataBean.getDependents();
		final ArrayList dependents = dataBean.getAllDependents();

		// Remove non-added dependents for Add or non-changed dependents for
		// Change
		final boolean adding = "205".equals(request
				.getAttribute("transactionNumber"));

		if (GcomTransaction.log.isDebugEnabled()) {
			GcomTransaction.log.debug("spouse exists="
					+ dataBean.getSpouseExists());
			GcomTransaction.log
					.debug("origList size before=" + origList.size());
			GcomTransaction.log.debug("size before removing="
					+ dependents.size());
		}

		for (Iterator i = dependents.iterator(); i.hasNext();) {
			final Dependent dependent = (Dependent) i.next();
			final String nameId = dependent.getNameId();

			if (GcomTransaction.log.isDebugEnabled()) {
				GcomTransaction.log.debug("dependent "
						+ dependent.getGivenName() + " changed: "
						+ dependent.isChanged());
			}

			if (StringUtils.isNotEmpty(nameId) && StringUtils.isNumeric(nameId)) {
				lastNameId = Math.max(lastNameId, Integer.parseInt(nameId));
			}

			if ((adding && !dependent.isAdded())
					|| (!adding && (!dependent.isChanged() || dependent
							.isAdded()))) {

				i.remove();
			}
		}

		if (GcomTransaction.log.isDebugEnabled()) {
			GcomTransaction.log.debug("adding=" + adding);
			GcomTransaction.log.debug("size before pad=" + dependents.size());
		}

		// Pad with empty dependents if necessary
		Dependent pad = null;

		while (dependents.size() % GcomTransaction.DEPENDENT_REPEATS > 0) {
			if (pad == null) {
				pad = new Dependent();
				DateBean dob = new DateBean();
				dob.setMonth("00");
				dob.setDay("00");
				dob.setYear("0000");
				pad.setDateOfBirth(dob);
			}
			dependents.add(pad);
		}

		dataBean.setDependents(dependents);

		if (GcomTransaction.log.isDebugEnabled()) {
			GcomTransaction.log.debug("size after pad=" + dependents.size());
			GcomTransaction.log.debug("loop control=" + dependents.size()
					/ GcomTransaction.DEPENDENT_REPEATS);
			GcomTransaction.log.debug("lastNameId=" + lastNameId);
		}

		// Create copybooks
		request.setAttribute("lastNameId", String.valueOf(lastNameId));

		for (int i = 0; i < dependents.size()
				/ GcomTransaction.DEPENDENT_REPEATS; i++) {
			request.setAttribute("startIndex", String.valueOf(i
					* GcomTransaction.DEPENDENT_REPEATS));
			buf.append(this.buildGcomCopybook("Dependent", dataBean, request));
		}

		if (GcomTransaction.log.isDebugEnabled()) {
			GcomTransaction.log.debug("origList size after=" + origList.size());
		}

		// Restore original dependents
		dataBean.setDependents(origList);

		return buf.toString();
	}

	/**
	 * Remvoes the superseded coverages from the insured.
	 * 
	 * @param dataBean -
	 *            the target insured.
	 */
	private static void removeSupersededCoverages(InsuredSearchDTO dataBean) {
		for (Iterator i = dataBean.getCoverageItems().iterator(); i.hasNext();) {
			final CoverageItem item = (CoverageItem) i.next();
			if (item.getSuperseded()) {
				i.remove();
			}
		}
	}
}
