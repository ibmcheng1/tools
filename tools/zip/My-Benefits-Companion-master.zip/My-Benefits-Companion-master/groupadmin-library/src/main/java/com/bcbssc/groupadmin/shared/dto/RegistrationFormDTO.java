/*
 * @(#)RegistrationFormDTO.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.dto;

import com.bcbssc.registration.common.Constants;
import com.bcbssc.struts.common.PhoneNumber;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

/**
 * Form Data Transfer Object for Group Administrator Registration
 *
 * This bean transports data between registration actions and services. The
 * attributes of this form correspond directly to the form-beans defined in the
 * struts-config.xml file.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class RegistrationFormDTO {

	/** log4j logger */
	protected static Logger log = Logger.getLogger(RegistrationFormDTO.class);

	/** format used for getDate (instantiated in that method) */
	private static SimpleDateFormat dateFormat = null;

	/** access code */
	private String accessCode = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** second line of address */
	private String addressLine2 = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** reauthenticate challenge */
	private String challenge = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** response to the reauthenticate challenge */
	private String challengeResponse = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** city name */
	private String city = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** email confirmation */
	private String confirmMail = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** password confirmation */
	private String confUnicodePwd = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** country code */
	private String country = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** legal cookie date of acceptance */
	private String dateOfAcceptance = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** date of birth */
	private String dateOfBirth = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** day of dob */
	private String dobDay = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** month of dob */
	private String dobMonth = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** year of dob */
	private String dobYear = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** fax number */
	private PhoneNumber fax = PhoneNumber.blank();

	/** first name */
	private String givenName = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** group name */
	private String groupName = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** group number parts */
	private String groupNumberParts[] = {
			com.bcbssc.struts.common.Constants.BLANK_STRING,
			com.bcbssc.struts.common.Constants.BLANK_STRING,
			com.bcbssc.struts.common.Constants.BLANK_STRING,
			com.bcbssc.struts.common.Constants.BLANK_STRING };

	/** group number */
	private String groupNumber = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** last 6 digits of social security number */
	private String last6SSN = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** last name */
	private String lastName = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** email address */
	private String mail = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** middle initial */
	private String middleIni = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** postal code */
	private String postalCode = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** roles */
	private String roles = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** user name */
	private String samAccountName = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** state name */
	private String state = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** selectedState name */
	private String selectedState = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** selectedState name */
	private String selectedCountry = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** first line of address */
	private String street = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** suffix of name */
	private String suffix = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** telephone extension */
	private String telephoneExt = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** telephone number */
	private PhoneNumber telephoneNumber = PhoneNumber.blank();

	/** user password */
	private String unicodePwd = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** number of failed reauthenticate challenge attempts */
	private int challengeAttempts = 0;

	/** application id */
	private String applicationId = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** actionFlag to store the page details from where the request came from */
	private String actionFlag = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** group number parts */
	private String groupNumberParts0 = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** group number parts */
	private String groupNumberParts1 = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** group number parts */
	private String groupNumberParts2 = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** group number parts */
	private String groupNumberParts3 = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Sets the number of failed reauthenticate challenge attempts
	 *
	 * @param value
	 *            number of failed reauthenticate challenge attempts
	 */
	public void setChallengeAttempts(int value) {
		this.challengeAttempts = value;
	}

	/**
	 * Gets the number of failed reauthenticate challenge attempts
	 *
	 * @return number of failed reauthenticate challenge attempts
	 */
	public int getChallengeAttempts() {
		return this.challengeAttempts;
	}

	/**
	 * Sets the access code
	 *
	 * @param value
	 *            access code
	 */
	public void setAccessCode(String value) {
		this.accessCode = value;
	}

	/**
	 * Gets the access code
	 *
	 * @return access code
	 */
	public String getAccessCode() {
		return this.accessCode;
	}

	/**
	 * Sets the last 6 digits of social security number
	 *
	 * @param value
	 *            last 6 digits of social security number
	 */
	public void setLast6SSN(String value) {
		this.last6SSN = value;
	}

	/**
	 * Gets the last 6 digits of social security number
	 *
	 * @return last 6 digits of social security number
	 */
	public String getLast6SSN() {
		return this.last6SSN;
	}

	/**
	 * Sets the legal cookie date of acceptance
	 *
	 * @param value
	 *            legal cookie date of acceptance
	 */
	public void setDateOfAcceptance(String value) {
		this.dateOfAcceptance = value;
	}

	/**
	 * Gets the legal cookie date of acceptance
	 *
	 * @return legal cookie date of acceptance
	 */
	public String getDateOfAcceptance() {
		return this.dateOfAcceptance;
	}

	/**
	 * Sets the last name
	 *
	 * @param value
	 *            last name
	 */
	public void setLastName(String value) {
		this.lastName = value.trim();
	}

	/**
	 * Gets the last name
	 *
	 * @return last name
	 */
	public String getLastName() {
		return this.lastName.trim();
	}

	/**
	 * Sets the group name
	 *
	 * @param value
	 *            group name
	 */
	public void setGroupName(String value) {
		this.groupName = value;
	}

	/**
	 * Gets the group name
	 *
	 * @return group name
	 */
	public String getGroupName() {
		return this.groupName;
	}

	/**
	 * <p>Getter for the field <code>groupNumberParts</code>.</p>
	 *
	 * @return an array of {@link java.lang.String} objects.
	 */
	public String[] getGroupNumberParts() {
		return this.groupNumberParts;
	}

	/**
	 * <p>Setter for the field <code>groupNumberParts</code>.</p>
	 *
	 * @param value an array of {@link java.lang.String} objects.
	 */
	public void setGroupNumberParts(String[] value) {
		this.groupNumberParts = value;
	}

	/**
	 * Gets a part of the group number
	 *
	 * @param index
	 *            part of the group number (0-3)
	 * @return specified group number part
	 */
	public String getGroupNumberParts(int index) {
		return this.groupNumberParts[index];
	}

	/**
	 * Sets a part of the group number
	 *
	 * @param index
	 *            part of the group number (0-3)
	 * @param value
	 *            group number part value
	 */
	public void setGroupNumberParts(int index, String value) {
		this.groupNumberParts[index] = value;
	}

	/**
	 * Gets the group number
	 *
	 * @return group number
	 */
	public String getGroupNumber() {
		return this.groupNumber;
	}

	/**
	 * Sets the group number
	 *
	 * @param value
	 *            group number
	 */
	public void setGroupNumber(String value) {
		this.groupNumber = value;
	}

	/**
	 * Sets the user name
	 *
	 * @param value
	 *            user name
	 */
	public void setSamAccountName(String value) {
		this.samAccountName = value;
	}

	/**
	 * Gets the user name
	 *
	 * @return user name
	 */
	public String getSamAccountName() {
		return this.samAccountName;
	}

	/**
	 * Sets the user password
	 *
	 * @param value
	 *            user password
	 */
	public void setUnicodePwd(String value) {
		this.unicodePwd = value;
	}

	/**
	 * Gets the user password
	 *
	 * @return user password
	 */
	public String getUnicodePwd() {
		return this.unicodePwd;
	}

	/**
	 * Sets the password confirmation
	 *
	 * @param value
	 *            password confirmation
	 */
	public void setConfUnicodePwd(String value) {
		this.confUnicodePwd = value;
	}

	/**
	 * Gets the password confirmation
	 *
	 * @return password confirmation
	 */
	public String getConfUnicodePwd() {
		return this.confUnicodePwd;
	}

	/**
	 * Sets the response to the reauthenticate challenge
	 *
	 * @param value
	 *            response to the reauthenticate challenge
	 */
	public void setChallengeResponse(String value) {
		this.challengeResponse = value;
	}

	/**
	 * Gets the response to the reauthenticate challenge
	 *
	 * @return response to the reauthenticate challenge
	 */
	public String getChallengeResponse() {
		return this.challengeResponse;
	}

	/**
	 * Sets the reauthenticate challenge
	 *
	 * @param value
	 *            reauthenticate challenge
	 */
	public void setChallenge(String value) {
		this.challenge = value;
	}

	/**
	 * Gets the reauthenticate challenge
	 *
	 * @return reauthenticate challenge
	 */
	public String getChallenge() {
		return this.challenge;
	}

	/**
	 * Sets the first name
	 *
	 * @return first name
	 */
	public String getGivenName() {
		return this.givenName;
	}

	/**
	 * Gets the first name
	 *
	 * @param value
	 *            first name
	 */
	public void setGivenName(String value) {
		this.givenName = value;
	}

	/**
	 * Sets the middle initial
	 *
	 * @param value
	 *            middle initial
	 */
	public void setMiddleIni(String value) {
		this.middleIni = value;
	}

	/**
	 * Gets the middle initial
	 *
	 * @return middle initial
	 */
	public String getMiddleIni() {
		return this.middleIni;
	}

	/**
	 * Sets the suffix of name
	 *
	 * @param value
	 *            suffix of name
	 */
	public void setSuffix(String value) {
		this.suffix = value;
	}

	/**
	 * Gets the suffix of name
	 *
	 * @return suffix of name
	 */
	public String getSuffix() {
		return this.suffix;
	}

	/**
	 * Sets the month of dob
	 *
	 * @param value
	 *            month of dob
	 */
	public void setDobMonth(String value) {
		this.dobMonth = value;
	}

	/**
	 * Gets the month of dob
	 *
	 * @return month of dob
	 */
	public String getDobMonth() {
		return this.dobMonth;
	}

	/**
	 * Gets the day of dob
	 *
	 * @return day of dob
	 */
	public String getDobDay() {
		return this.dobDay;
	}

	/**
	 * Sets the day of dob
	 *
	 * @param value
	 *            day of dob
	 */
	public void setDobDay(String value) {
		this.dobDay = value;
	}

	/**
	 * Gets the year of dob
	 *
	 * @return year of dob
	 */
	public String getDobYear() {
		return this.dobYear;
	}

	/**
	 * Sets the year of dob
	 *
	 * @param value
	 *            year of dob
	 */
	public void setDobYear(String value) {
		this.dobYear = value;
	}

	/**
	 * Gets the date of birth
	 *
	 * @return date of birth
	 */
	public String getDateOfBirth() {
		return this.dateOfBirth;
	}

	/**
	 * Sets the date of birth
	 *
	 * @param value
	 *            date of birth
	 */
	public void setDateOfBirth(String value) {
		this.dateOfBirth = value;
	}

	/**
	 * Gets the first line of address
	 *
	 * @return first line of address
	 */
	public String getStreet() {
		return this.street;
	}

	/**
	 * Sets the first line of address
	 *
	 * @param value
	 *            first line of address
	 */
	public void setStreet(String value) {
		this.street = value;
	}

	/**
	 * Gets the second line of address
	 *
	 * @return second line of address
	 */
	public String getAddressLine2() {
		return this.addressLine2;
	}

	/**
	 * Sets the second line of address
	 *
	 * @param value
	 *            second line of address
	 */
	public void setAddressLine2(String value) {
		this.addressLine2 = value;
	}

	/**
	 * Gets the city name
	 *
	 * @return city name
	 */
	public String getCity() {
		return this.city;
	}

	/**
	 * Gets the city name
	 *
	 * @param value
	 *            city name
	 */
	public void setCity(String value) {
		this.city = value;
	}

	/**
	 * Gets the state name
	 *
	 * @return state name
	 */
	public String getState() {
		return this.state;
	}

	/**
	 * Sets the state name
	 *
	 * @param value
	 *            state name
	 */
	public void setState(String value) {
		this.state = value;
	}

	/**
	 * Gets the selected state name
	 *
	 * @return selected state name
	 */
	public String getSelectedState() {
		return this.selectedState;
	}

	/**
	 * Sets the selected state name
	 *
	 * @param value
	 *            selected state name
	 */
	public void setSelectedState(String value) {
		this.selectedState = value;
	}

	/**
	 * Gets the postal code
	 *
	 * @return postal code
	 */
	public String getPostalCode() {
		return this.postalCode;
	}

	/**
	 * Sets the postal code
	 *
	 * @param value
	 *            postal code
	 */
	public void setPostalCode(String value) {
		this.postalCode = value;
	}

	/**
	 * Gets the email address
	 *
	 * @return email address
	 */
	public String getMail() {
		return this.mail;
	}

	/**
	 * Sets the email address
	 *
	 * @param value
	 *            email address
	 */
	public void setMail(String value) {
		this.mail = value;
	}

	/**
	 * Gets the email confirmation
	 *
	 * @return email confirmation
	 */
	public String getConfirmMail() {
		return this.confirmMail;
	}

	/**
	 * Sets the email confirmation
	 *
	 * @param value
	 *            email confirmation
	 */
	public void setConfirmMail(String value) {
		this.confirmMail = value;
	}

	/**
	 * Gets the telephone area code
	 *
	 * @return telephone area code
	 */
	public String getTelephoneNumberAreacode() {
		return this.telephoneNumber.getAreacode();
	}

	/**
	 * Gets the telephone number prefix
	 *
	 * @return telephone number prefix
	 */
	public String getTelephoneNumberPrefix() {
		return this.telephoneNumber.getPrefix();
	}

	/**
	 * Gets the telephone number suffix
	 *
	 * @return telephone number suffix
	 */
	public String getTelephoneNumberSuffix() {
		return this.telephoneNumber.getSuffix();
	}

	/**
	 * Gets the telephone extension
	 *
	 * @return telephone extension
	 */
	public String getTelephoneExt() {
		return this.telephoneExt;
	}

	/**
	 * Sets the telephone extension
	 *
	 * @param value
	 *            telephone extension
	 */
	public void setTelephoneExt(String value) {
		this.telephoneExt = value;
	}

	/**
	 * Gets the area code of fax number
	 *
	 * @return area code of fax number
	 */
	public String getFaxAreacode() {
		return this.fax.getAreacode();
	}

	/**
	 * Gets the prefix of fax number
	 *
	 * @return prefix of fax number
	 */
	public String getFaxPrefix() {
		return this.fax.getPrefix();
	}

	/**
	 * Gets the suffix of fax number
	 *
	 * @return suffix of fax number
	 */
	public String getFaxSuffix() {
		return this.fax.getSuffix();
	}

	/**
	 * Gets the telephone number
	 *
	 * @return telephone number
	 */
	public String getTelephoneNumber() {
		return this.telephoneNumber.toString();
	}

	/**
	 * Sets the telephone number
	 *
	 * @param value
	 *            telephone number
	 */
	public void setTelephoneNumber(String value) {
		this.telephoneNumber.parse(value);
	}

	/**
	 * Gets the fax number
	 *
	 * @return fax number
	 */
	public String getFax() {
		return this.fax.toString();
	}

	/**
	 * Sets the fax number
	 *
	 * @param value
	 *            fax number
	 */
	public void setFax(String value) {
		this.fax.parse(value);
	}

	/**
	 * Gets the country code
	 *
	 * @return country code
	 */
	public String getCountry() {
		return this.country;
	}

	/**
	 * Sets the selected country code
	 *
	 * @param value
	 *            selected country code
	 */
	public void setSelectedCountry(String value) {
		this.selectedCountry = value;
	}

	/**
	 * Gets the selected country code
	 *
	 * @return selected country code
	 */
	public String getSelectedCountry() {
		return this.selectedCountry;
	}

	/**
	 * Sets the country code
	 *
	 * @param value
	 *            country code
	 */
	public void setCountry(String value) {
		this.country = value;
	}

	/**
	 * Gets today's date in mm/dd/yyyy format
	 *
	 * @return country options
	 */
	public String getDate() {
		if (RegistrationFormDTO.dateFormat == null) {
			RegistrationFormDTO.dateFormat = new SimpleDateFormat(
					Constants.LDAP_DATE_FORMAT);
		}

		return RegistrationFormDTO.dateFormat.format(new Date());
	}

	/**
	 * Gets the user roles
	 *
	 * @return the user roles, joined by Constants.DEFAULT_DELIMITER
	 */
	public String getRoles() {
		return this.roles;
	}

	/**
	 * Sets the user roles
	 *
	 * @param value
	 *            the user roles, joined by Constants.DEFAULT_DELIMITER
	 */
	public void setRoles(String value) {
		this.roles = value;
	}

	/**
	 * Gets the application id
	 *
	 * @return application id
	 */
	public String getApplicationId() {
		return this.applicationId;
	}

	/**
	 * Sets the application id
	 *
	 * @param value
	 *            application id
	 */
	public void setApplicationId(String value) {
		this.applicationId = value;
	}

	/**
	 * Gets the actionFlag
	 *
	 * @return actionFlag
	 */
	public String getActionFlag() {
		return this.actionFlag;
	}

	/**
	 * Sets the actionFlag
	 *
	 * @param value
	 *            actionFlag
	 */
	public void setActionFlag(String value) {
		this.actionFlag = value;
	}

	/**
	 * Gets the group number part 0
	 *
	 * @return group number
	 */
	public String getGroupNumberParts0() {
		return this.groupNumberParts0;
	}

	/**
	 * Sets the group number part 0
	 *
	 * @param value
	 *            group number
	 */
	public void setGroupNumberParts0(String value) {
		this.groupNumberParts0 = value;
	}

	/**
	 * Gets the group number part 0
	 *
	 * @return group number
	 */
	public String getGroupNumberParts1() {
		return this.groupNumberParts1;
	}

	/**
	 * Sets the group number part 1
	 *
	 * @param value
	 *            group number
	 */
	public void setGroupNumberParts1(String value) {
		this.groupNumberParts1 = value;
	}

	/**
	 * Gets the group number part 2
	 *
	 * @return group number
	 */
	public String getGroupNumberParts2() {
		return this.groupNumberParts2;
	}

	/**
	 * Sets the group number part 2
	 *
	 * @param value
	 *            group number
	 */
	public void setGroupNumberParts2(String value) {
		this.groupNumberParts2 = value;
	}

	/**
	 * Gets the group number part 3
	 *
	 * @return group number
	 */
	public String getGroupNumberParts3() {
		return this.groupNumberParts3;
	}

	/**
	 * Sets the group number part 3
	 *
	 * @param value
	 *            group number
	 */
	public void setGroupNumberParts3(String value) {
		this.groupNumberParts3 = value;
	}

}
