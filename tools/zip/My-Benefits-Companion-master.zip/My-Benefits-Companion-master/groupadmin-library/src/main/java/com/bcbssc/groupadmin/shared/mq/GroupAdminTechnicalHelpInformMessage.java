/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2003 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * GroupAdminTechnicalHelpInformMessage.java
 *
 * Created on September 13, 2004, 4:41 PM
 *
 */

package com.bcbssc.groupadmin.shared.mq;

import com.bcbssc.netsys.inform.AbstractInformMessage;

/**
 * Encapsulates an INFOrm message for Group Admin Technical Help
 */
public class GroupAdminTechnicalHelpInformMessage extends
		com.bcbssc.netsys.inform.AbstractInformMessage {

	public static final String VERSION = "$Revision:   1.0  $";

	private static final String FILE_INFORM = "TechnicalHelpInforms.xml";

	private static final String MAPPER_KEY = "TechnicalHelpInforms";

	private static final String TASK_PREFIX = "TechnicalHelp.";

	private String applicationName = "TechnicalHelp";

	/**
	 * Creates a new instance of TechnicalHelpInformMessage
	 */
	public GroupAdminTechnicalHelpInformMessage() {
		super();
	}

	/**
	 * Convenience constructor for setting the application upon instantiation.
	 *
	 * @param appName
	 *            The name of the application submitting the INFOrm
	 */
	public GroupAdminTechnicalHelpInformMessage(String appName) {
		super();
		this.setApplicationName(appName);
	}

	/**
	 * Gets the application name for the INFOrm message. Used by
	 * {@link com.bcbssc.netsys.inform.AbstractInformMessage} to get the proper Mapper instance.
	 *
	 * @return The application name for the current instance.
	 */
	public String getApplicationName() {
		return this.applicationName;
	}

	/**
	 * Gets the application name for the INFOrm message. Used by
	 * {@link com.bcbssc.netsys.inform.AbstractInformMessage} to get the proper Mapper instance.
	 *
	 * @param value a {@link java.lang.String} object.
	 */
	public void setApplicationName(String value) {
		this.applicationName = value;
	}

	/**
	 * Gets the file path of the mappings file used to map INFOrm data.
	 *
	 * @return The file path used for mapping INFOrm data.
	 */
	public String getInformMapFile() {
		return GroupAdminTechnicalHelpInformMessage.FILE_INFORM;
	}

	/**
	 * Gets the key name for the INFOrm message.
	 *
	 * @return The key name for the INFOrm message.
	 */
	public String getMapperKey() {
		return GroupAdminTechnicalHelpInformMessage.MAPPER_KEY;
	}

	/**
	 * Gets the task prefix for the INFOrm message.
	 *
	 * @return The task prefix for the INFOrm message.
	 */
	public String getTaskPrefix() {
		return GroupAdminTechnicalHelpInformMessage.TASK_PREFIX;
	}
}
