/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2003 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * GroupAdminInformMessage.java
 *
 * Created on September 7, 2004, 10:35 AM
 *
 */

package com.bcbssc.groupadmin.shared.mq;

import com.bcbssc.netsys.inform.AbstractInformMessage;

/**
 * Encapsulates an INFOrm message for a Group Administrator User Update.
 *
 * @author XR93 (M Lujan)
 * @version $Id: $Id
 */
public class InformMessage extends
		AbstractInformMessage {

	/** the source-control revision of this class * */
	/** Constant <code>VERSION="$Revision:   1.0  $"</code> */
	public static final String VERSION = "$Revision:   1.0  $";

	private static final String FILE_INFORM = "GroupAdminInforms.xml";

	private static final String MAPPER_KEY = "GroupAdmin";

	private static final String TASK_PREFIX = "GroupAdmin.";

	private String applicationName = "GroupAdmin";

	/**
	 * Creates a new instance of ClosedInformMessage
	 */
	public InformMessage() {
		super();
	}

	/**
	 * Convenience constructor for setting the application upon instantiation.
	 *
	 * @param applicationName
	 *            The name of the application submitting the INFOrm
	 */
	public InformMessage(String applicationName) {
		super();
		this.setApplicationName(applicationName);
	}

	/**
	 * Gets the application name for the INFOrm message. Used by
	 * {@link com.bcbssc.netsys.inform.AbstractInformMessage} to get the proper Mapper instance.
	 *
	 * @return The application name for the current instance.
	 */
	public String getApplicationName() {
		return this.applicationName;
	}

	/**
	 * Gets the application name for the INFOrm message. Used by
	 * {@link com.bcbssc.netsys.inform.AbstractInformMessage} to get the proper Mapper instance.
	 *
	 * @param value
	 *            The application name for the current instance.
	 */
	public void setApplicationName(String value) {
		this.applicationName = value;
	}

	/**
	 * Gets the file path of the mappings file used to map INFOrm data.
	 *
	 * @return The file path used for mapping INFOrm data.
	 */
	public String getInformMapFile() {
		return InformMessage.FILE_INFORM;
	}

	/**
	 * Gets the key name for the INFOrm message.
	 *
	 * @return The key name for the INFOrm message.
	 */
	public String getMapperKey() {
		// logger.debug(InformMessage.MAPPER_KEY);
		return InformMessage.MAPPER_KEY;
	}

	/**
	 * Gets the task prefix for the INFOrm message.
	 *
	 * @return The task prefix for the INFOrm message.
	 */
	public String getTaskPrefix() {
		// logger.debug(InformMessage.TASK_PREFIX);
		return InformMessage.TASK_PREFIX;
	}

}
