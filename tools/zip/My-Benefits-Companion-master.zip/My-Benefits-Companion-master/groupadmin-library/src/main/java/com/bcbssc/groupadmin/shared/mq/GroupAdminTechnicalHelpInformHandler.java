/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mq/GroupAdminTechnicalHelpInformHandler.java_v  $
 * $Workfile:   GroupAdminTechnicalHelpInformHandler.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:16:04  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mq/GroupAdminTechnicalHelpInformHandler.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:16:04   EN80
 * Initial revision.
 * 
 *    Rev 1.10   Apr 28 2009 10:20:06   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.9   Jun 21 2006 10:44:56   rx35d
 * c03784 - Dead Letter Queqe Issue where a MQ record with a length > 2124 x 200.
 * 
 *    Rev 1.8   Dec 15 2004 15:30:38   rxg97
 * Fixed StringBuffer.append useage.
 * 
 *    Rev 1.7   Dec 15 2004 12:13:54   rxg97
 * Added appName and appType support.
 * 
 *    Rev 1.6   Nov 18 2004 13:52:02   rxg97
 * Parameterized company code, department code, division code and employee ID.  Hammurapi updates.
 * 
 *    Rev 1.5   Nov 16 2004 10:05:44   rxg97
 * Added support for groupNumber keyID and accessCode altKeyID.
 * 
 *    Rev 1.4   Oct 22 2004 14:25:42   rxg97
 * Added verbiage to inform to support new password help page details.
 * 
 *    Rev 1.3   Sep 30 2004 14:36:14   rxg97
 * Fixed logger message spelling.
 * 
 *    Rev 1.2   Sep 29 2004 14:39:38   rxg97
 * CommonInformUtils.sendMessage
 * 
 *    Rev 1.1   Sep 24 2004 14:36:34   rxg97
 * Enabled sending of messages and moved MQ sending internals to CommonInformUtils.
 * 
 *    Rev 1.0   Sep 22 2004 10:18:40   rxg97
 * Initial revision.
 * 
 */

package com.bcbssc.groupadmin.shared.mq;

import com.bcbssc.groupadmin.shared.dto.TechnicalHelpFormDTO;
import com.bcbssc.netsys.Config;
import com.bcbssc.netsys.inform.InformEndLine;
import com.bcbssc.netsys.inform.InformInquiryLine;
import com.bcbssc.netsys.inform.InformUtil;
import com.bcbssc.registration.common.Constants;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 * Handles Group Admin INFOrm messaging for technical help.
 *
 * @author rxg97 (Jonathan Egger)
 * @version $Id: $Id
 */
public class GroupAdminTechnicalHelpInformHandler {

	/** log4j logger */
	private static final Logger logger = Logger
			.getLogger(GroupAdminTechnicalHelpInformHandler.class);

	/** the application-specific INI file */
	private String iniFile;

	/** the application-specific RPN value */
	private String rpn;

	/** the company code value */
	private String companyCode;

	/** the corporate code value */
	private String corporateCode;

	/** the deparment code value */
	private String departmentCode;

	/** the division code value */
	private String divisionCode;

	/** the employee ID */
	private String employeeId;

	/** the application-specific name */
	private String appName;

	/** the application type */
	private String appType;

	/**
	 * Creates a new instance of GroupAdminTechnicalHelpInformHandler, setting
	 * the application-specific INFOrm parameters based on the specified ini
	 * file.
	 *
	 * @param iniFileName
	 *            file containing the application-specific parameters
	 */
	public GroupAdminTechnicalHelpInformHandler(String iniFileName) {
		super();
		this.iniFile = iniFileName;
		this.rpn = Config.getPrivateProfileString("MISC", "RPN", "",
				this.iniFile);

		this.companyCode = Config.getPrivateProfileString("MISC",
				"TECH_HELP_COMPANY_CODE", "", this.iniFile);

		this.corporateCode = Config.getPrivateProfileString("MISC",
				"TECH_HELP_CORPORATE_CODE", "", this.iniFile);

		this.departmentCode = Config.getPrivateProfileString("MISC",
				"TECH_HELP_DEPARTMENT_CODE", "", this.iniFile);

		this.divisionCode = Config.getPrivateProfileString("MISC",
				"TECH_HELP_DIVISION_CODE", "", this.iniFile);

		this.employeeId = Config.getPrivateProfileString("MISC",
				"TECH_HELP_EMP_ID", "", this.iniFile);

		this.appName = Config.getPrivateProfileString("MISC", "APP_NAME", "",
				this.iniFile);

		this.appType = Config.getPrivateProfileString("MISC", "APP_TYPE", "",
				this.iniFile);
	}

	/**
	 * Creates and sends a profile completed INFOrm for the specified user.
	 *
	 * @param helpDTO a {@link com.bcbssc.groupadmin.shared.dto.TechnicalHelpFormDTO} object.
	 */
	public void sendTechnicalHelpInform(TechnicalHelpFormDTO helpDTO) {

		GroupAdminTechnicalHelpInformHandler.logger
				.debug("Creating technical help inform message");
		GroupAdminTechnicalHelpInformMessage gaim = new GroupAdminTechnicalHelpInformMessage();

		GroupAdminTechnicalHelpInformHandler.logger
				.debug("Creating InformHeaderBean");
		GroupAdminTechnicalHelpInformHeader ihb = new GroupAdminTechnicalHelpInformHeader();
		ihb.setInfoType("INFO");
		ihb.setKeyId(helpDTO.getGroupNumber());
		ihb.setAltKeyId(helpDTO.getAccessCode());

		ihb.setRpn(this.rpn);
		ihb.setCompanyCode(this.companyCode);
		ihb.setCorporateCode(this.corporateCode);
		ihb.setDepartmentCode(this.departmentCode);
		ihb.setDivisionCode(this.divisionCode);
		ihb.setEmployeeId(this.employeeId);

		ihb.setCatCode("ACC");

		// ClaimNumber is an unused field we can use for appName
		StringBuffer corrspName = new StringBuffer(32);
		corrspName.append(this.appType).append(": ").append(this.appName);
		ihb.setClaimNumber(corrspName.toString());

		gaim.setHeader(ihb);

		gaim.addLine(new InformInquiryLine());

		StringBuffer verbiage = new StringBuffer(500);
		verbiage.append(this.appType).append(":REQUEST FOR TECHNICAL HELP\n");
		verbiage.append("Reason: ").append(helpDTO.getReason()).append("\n");
		verbiage.append("First Name: ").append(helpDTO.getGivenName()).append(
				"\n");
		verbiage.append("Last Name: ").append(helpDTO.getLastName()).append(
				"\n");
		verbiage.append("Middle Ini: ").append(helpDTO.getMiddleIni()).append(
				"\n");
		verbiage.append("Suffix: ").append(helpDTO.getSuffix()).append("\n");
		verbiage.append("Date of Birth: ").append(helpDTO.getDateOfBirth())
				.append("\n");
		verbiage.append("Last 6 SSN: ").append(helpDTO.getLast6SSN()).append(
				"\n");
		verbiage.append("Address: ").append(helpDTO.getStreet()).append("\n");
		verbiage.append("Address Line 2: ").append(helpDTO.getAddressLine2())
				.append("\n");
		verbiage.append("City: ").append(helpDTO.getCity()).append("\n");
		verbiage.append("State: ").append(helpDTO.getState()).append("\n");
		verbiage.append("ZIP Code: ").append(helpDTO.getPostalCode()).append(
				"\n");
		verbiage.append("Country: ").append(helpDTO.getCountry()).append("\n");
		verbiage.append("Phone: ").append(helpDTO.getTelephoneNumber());
		verbiage.append(" Extension: ").append(helpDTO.getTelephoneExt())
				.append("\n");
		verbiage.append("Fax: ").append(helpDTO.getFax()).append("\n");
		verbiage.append("E-mail Address: ").append(helpDTO.getMail()).append(
				"\n");
		String question = helpDTO.getHelpQuestion();

		int i = 0;
		while (i < question.length()) {
			int j = i + 69; // 79 - "Question: ".length();
			if (j >= question.length()) {
				j = question.length();
			}

			verbiage.append("Question: ").append(question.substring(i, j))
					.append("\n");
			i = j;
		}

		InformUtil.addRequestLines(gaim, verbiage.toString());
		gaim.addLine(new InformEndLine());

		CommonInformUtils.sendMessage(gaim, "TECHNICALHELP", this.iniFile);
	}

	/**
	 * General test method for this class
	 *
	 * @param inArgs
	 *            command-line arguments
	 */
	public static void main(String[] inArgs) {
		String configPath = "D:\\Netscape\\GroupAdmin\\Clife\\config\\";
		String strAppIni = "D:\\Netscape\\GroupAdmin\\Clife\\config\\CGA.ini";

		/*
		 * Load and configure log4j using the log4j properties file. This also
		 * tests that we have the classpath setup to include ETKS/config
		 */
		String logPropertyFileResource = configPath
				+ Constants.LOG4J_PROPERTIES_FILENAME;

		DOMConfigurator.configure(logPropertyFileResource);

		try {
			GroupAdminTechnicalHelpInformHandler gaih = new GroupAdminTechnicalHelpInformHandler(
					strAppIni);

			TechnicalHelpFormDTO helpDTO = new TechnicalHelpFormDTO();
			helpDTO.setGroupNumber("mygroupnumber");
			helpDTO.setAccessCode("myaccesscode");

			helpDTO.setReason("A REASON.  A GOOD ONE.");
			helpDTO.setGivenName("TEST01");
			helpDTO.setPostalCode("23456");
			helpDTO.setState("TX");
			helpDTO.setMail("test@test.com");
			helpDTO.setLastName("TESTING01");
			helpDTO.setTelephoneNumber("8031234567");
			helpDTO.setStreet("TESTING LANE");
			helpDTO.setCountry("AL");
			helpDTO.setCity("COLUMBIA");
			helpDTO.setSamAccountName("test0902");
			helpDTO.setHelpQuestion("01234567890abcdefghijklmnopqrstuvwxyz012");

			gaih.sendTechnicalHelpInform(helpDTO);

		} catch (Exception eException) {
			GroupAdminTechnicalHelpInformHandler.logger.error(
					"Error occured while trying to test technical inform: ",
					eException);
			eException.printStackTrace();
		}
	}
}
