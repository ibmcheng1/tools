/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/DatabaseDropdowns.java_v  $
 * $Workfile:   DatabaseDropdowns.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:10  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/DatabaseDropdowns.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:14:10   EN80
 * Initial revision.
 * 
 *    Rev 1.3   Apr 28 2009 10:17:54   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.2   Sep 28 2004 10:23:02   rxg97
 * Moved DB internals to AbstractDBSearch.
 * 
 *    Rev 1.1   Sep 22 2004 09:58:50   rxg97
 * Now subclassing AbstractCollectionSearch.  Moved db call internals to that class.
 * 
 *    Rev 1.0   Sep 12 2004 15:17:26   rxg97
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.dbaccess;

import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.netsys.Config;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.struts.util.LabelValueBean;

/**
 * Determines values for SQL-driven dropdown options.
 *
 * @author rxg97 (Jonathan Egger)
 * @version $Id: $Id
 */
public class DatabaseDropdowns extends AbstractDBSearch {

	/** The log4j logger for this class. */
	protected static Logger log = Logger.getLogger(DatabaseDropdowns.class);

	/** The line of business number. */
	private final String rpn;

	/** The date format used by the database. */
	final SimpleDateFormat dateFormat = new SimpleDateFormat(
			Constants.SQL_DATE_FORMAT);

	/**
	 * Creates an <code>RulesQuery</code> and configures it with an INI file.
	 *
	 * @param iniFile
	 *            file path of the configuration INI file.
	 */
	public DatabaseDropdowns(String iniFile) {
		super(iniFile, "COUNTRY_TABLE");
		this.rpn = Config.getPrivateProfileString("MISC", "RPN",
				com.bcbssc.struts.common.Constants.BLANK_STRING, iniFile);
	}

	/**
	 * Performs an SQL country query and returns the results as a Collection of
	 * LabelValueBeans suitable for a dropdown.
	 *
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 * @return a {@link java.util.Collection} object.
	 */
	public Collection getCountryOptions() throws SQLException {

		Collection options = new ArrayList();

		final String serviceDate = this.dateFormat.format(new Date());
		final StringBuffer sql = new StringBuffer(500);

		this.checkInit(); // Necessary since we need the _dbSchema before the
							// query creation

		sql.append(" SELECT KEY_FLD_1, KEY_DESC FROM ").append(this._dbSchema)
				.append(".DT_TYP_GEN_KEY_DS2 WHERE RP_NO = '").append(this.rpn)
				.append("' AND PLAN_CD = '885' AND DATA_TYP = 'CNTRYCDE'")
				.append(" AND SYS_VOID_STS_IND = 'N' AND DT_TYP_BEG <= '")
				.append(serviceDate).append("' AND DT_TYP_TRM >= '").append(
						serviceDate).append("' ORDER BY KEY_FLD_3");

		if (DatabaseDropdowns.log.isDebugEnabled()) {
			DatabaseDropdowns.log
					.debug("SQL statement to get country dropdowns: ");
			DatabaseDropdowns.log.debug(sql.toString());
		}

		options = (Collection) this.performSearch(sql.toString(), options);
		if (options == null) {
			options = new ArrayList();
		}

		return options;
	}

	/**
	 * {@inheritDoc}
	 *
	 * Adds a dropdown option item to a collection with a row value from the
	 * result set.
	 */
	protected void addSearchItem(ResultSet data, Object obj)
			throws SQLException {

		Collection options = (Collection) obj;

		String key_desc = data.getString("KEY_DESC").trim();
		String key_fld_1 = data.getString("KEY_FLD_1").trim();
		options.add(new LabelValueBean(key_desc, key_fld_1));
	}
}
