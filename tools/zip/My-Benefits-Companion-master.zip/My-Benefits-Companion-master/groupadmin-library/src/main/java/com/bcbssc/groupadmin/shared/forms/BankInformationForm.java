/**
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.groupadmin.shared.forms;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.log4j.Logger;

/**
 * Bean for processing bank information.
 */
public class BankInformationForm extends BillHistoryForm {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /** log4j logger */
    private static final Logger log = Logger
            .getLogger(BankInformationForm.class);

    /** status of the bank account, invalid(9) or valid (not 9) */
    private String bankStatus;

    /** name of the bank */
    private String bankName;

    /** bank routing number */
    private String bankRoutingNumber;

    /** confirmation of bank routing nubmer */
    private String bankRoutingNumberConfirm;

    /** bank account number */
    private String bankAccountNumber;

    /** confirm bank account number */
    private String bankAccountNumberConfirm;

    /** account holder's name */
    private String accountHolderName;

    /**
     * holds the tracking number when CGA sends bank or payment information to
     * MQ and Inform.
     */
    private String trackingNumber;

    /**
     * holds the account activity mode whether we are updating bank account
     * information or inserting a new bank information
     */
    private String activityCode;

    /** holds the total balance due dollars only */
    private String totalBalanceDueDollars = "0".intern();

    /** holds the total balance due cents only */
    private String totalBalanceDueCents = "00".intern();

    /** holds the other paid total balance due dollars only */
    private String otherBalanceDueDollars = "";

    /** holds the other paid balance due cents only */
    private String otherBalanceDueCents = "00".intern();

    /** holds the radio button information using for balance due paid amount */
    private boolean balanceDueRadio = true;

    /** holds the bank info or payment entry date */
    private String entryDate;

    /** holds the bank info or payment entry time */
    private String entryTime;

    /** holds the bank info or payment entry date time */
    private String entryDateTime;

    /** holds the name of the form from which it is being set. */
    private String formName;

    /** holds the name of the form from which it is being set. */
    private boolean bankAccountAvailableFlag = true;

    /**
     * <p>toString.</p>
     *
     * @return a {@link java.lang.String} object.
     */
    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(" Group Number: " + this.getGroupNumber());
        stringBuffer.append(" Group: " + this.getGroup());
        stringBuffer.append(" Bank Name: " + this.bankName);
        stringBuffer.append(" Bank Routing Number: " + this.bankRoutingNumber);
        stringBuffer.append(" Bank Routing Number Confirm: "
                + this.bankRoutingNumberConfirm);
        return stringBuffer.toString();
    }

    /**
     * <p>Getter for the field <code>formName</code>.</p>
     *
     * @return Returns the formName.
     */
    public String getFormName() {
        return this.formName;
    }

    /**
     * <p>Setter for the field <code>formName</code>.</p>
     *
     * @param formName
     *            The formName to set.
     */
    public void setFormName(String formName) {
        this.formName = formName;
    }

    /**
     * Clears the user-editable data fields for this form
     */
    public void clear() {
        this.setGroup(this.getDefaultGroupOption());
        this.bankStatus = "";
        this.bankRoutingNumber = "";
        this.bankRoutingNumberConfirm = "";
        this.bankAccountNumber = "";
        this.bankAccountNumberConfirm = "";
        this.accountHolderName = "";
        this.bankName = "";
    }

    /**
     * <p>Getter for the field <code>trackingNumber</code>.</p>
     *
     * @return Returns the trackingNumber.
     */
    public String getTrackingNumber() {
        return this.trackingNumber;
    }

    /**
     * <p>Setter for the field <code>trackingNumber</code>.</p>
     *
     * @param trackingNumber
     *            The trackingNumber to set.
     */
    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    /**
     * <p>Getter for the field <code>otherBalanceDueCents</code>.</p>
     *
     * @return Returns the otherBalanceDueCents.
     */
    public String getOtherBalanceDueCents() {
        return this.otherBalanceDueCents;
    }

    /**
     * <p>Setter for the field <code>otherBalanceDueCents</code>.</p>
     *
     * @param otherBalanceDueCents
     *            The otherBalanceDueCents to set.
     */
    public void setOtherBalanceDueCents(String otherBalanceDueCents) {
        this.otherBalanceDueCents = otherBalanceDueCents;
    }

    /**
     * <p>Getter for the field <code>otherBalanceDueDollars</code>.</p>
     *
     * @return Returns the otherBalanceDueDollars.
     */
    public String getOtherBalanceDueDollars() {
        return StringEscapeUtils.escapeJavaScript(this.otherBalanceDueDollars);
    }

    /**
     * <p>Setter for the field <code>otherBalanceDueDollars</code>.</p>
     *
     * @param otherBalanceDueDollars
     *            The otherBalanceDueDollars to set.
     */
    public void setOtherBalanceDueDollars(String otherBalanceDueDollars) {
        this.otherBalanceDueDollars = otherBalanceDueDollars;
    }

    /**
     * Gets the total balance due (dollars and cents concatenated)
     *
     * @return a {@link java.lang.String} object.
     */
    public String getTotalBalanceDue() {
        String returnString = null;
        if (this.balanceDueRadio) {

            BankInformationForm.log.debug("The escaped value is 1"
                    + StringEscapeUtils
                            .escapeJavaScript(this.totalBalanceDueDollars + "."
                                    + this.totalBalanceDueCents));
            returnString = StringEscapeUtils
                    .escapeJavaScript(this.totalBalanceDueDollars + "."
                            + this.totalBalanceDueCents);
        } else {
            BankInformationForm.log.debug("The escaped value is 2"
                    + StringEscapeUtils
                            .escapeJavaScript(this.otherBalanceDueDollars + "."
                                    + this.otherBalanceDueCents));
            returnString = StringEscapeUtils
                    .escapeJavaScript(this.otherBalanceDueDollars + "."
                            + this.otherBalanceDueCents);
        }
        return returnString;
    }

    /**
     * set's balance due total into cents and dollars properties ex:
     * value=1222.12 dollars=1222 cents=12
     *
     * @param value a {@link java.lang.String} object.
     */
    public void setTotalBalanceDue(String value) {
        BankInformationForm.log
                .debug("Balance due to be set into dollars and cents properties="
                        + value);
        BankInformationForm.log.debug("Balance Due or Other Payment Flag="
                + this.balanceDueRadio);
        if ((value != null) && (value.length() > 0)) {
            if (value.length() <= 2) {
                if (this.balanceDueRadio) {
                    this.totalBalanceDueCents = value;
                } else {
                    this.otherBalanceDueCents = value;
                }

            } else {
                if (this.balanceDueRadio) {
                    this.totalBalanceDueDollars = value.substring(0, value
                            .length() - 3);
                    this.totalBalanceDueCents = value
                            .substring(value.length() - 2);
                } else {
                    this.otherBalanceDueDollars = value.substring(0, value
                            .length() - 3);
                    this.otherBalanceDueCents = value
                            .substring(value.length() - 2);
                }

            }
        }
    }

    /**
     * <p>Getter for the field <code>totalBalanceDueCents</code>.</p>
     *
     * @return Returns the totalBalanceDueCents.
     */
    public String getTotalBalanceDueCents() {
        return this.totalBalanceDueCents;
    }

    /**
     * <p>Setter for the field <code>totalBalanceDueCents</code>.</p>
     *
     * @param totalBalanceDueCents
     *            The totalBalanceDueCents to set.
     */
    public void setTotalBalanceDueCents(String totalBalanceDueCents) {
        this.totalBalanceDueCents = totalBalanceDueCents;
    }

    /**
     * <p>Getter for the field <code>totalBalanceDueDollars</code>.</p>
     *
     * @return Returns the totalBalanceDueDollars.
     */
    public String getTotalBalanceDueDollars() {
        return this.totalBalanceDueDollars;
    }

    /**
     * <p>Setter for the field <code>totalBalanceDueDollars</code>.</p>
     *
     * @param totalBalanceDueDollars
     *            The totalBalanceDueDollars to set.
     */
    public void setTotalBalanceDueDollars(String totalBalanceDueDollars) {
        this.totalBalanceDueDollars = totalBalanceDueDollars;
    }

    /**
     * <p>isBalanceDueRadio.</p>
     *
     * @return Returns the balanceDueRadio.
     */
    public boolean isBalanceDueRadio() {
        return this.balanceDueRadio;
    }

    /**
     * <p>Setter for the field <code>balanceDueRadio</code>.</p>
     *
     * @param balanceDueRadio
     *            The balanceDueRadio to set.
     */
    public void setBalanceDueRadio(boolean balanceDueRadio) {
        this.balanceDueRadio = balanceDueRadio;
	/*
        if (this.balanceDueRadio) {

            if(StringUtils.isNotBlank(this.otherBalanceDueDollars)
                && ! StringUtils.equals(this.otherBalanceDueDollars, "0")
                && ! StringUtils.equals(this.otherBalanceDueCents, "00")) {

                this.totalBalanceDueDollars = this.otherBalanceDueDollars;
                this.totalBalanceDueCents   = this.otherBalanceDueCents;
            }
        }
        else {
            this.otherBalanceDueDollars = this.totalBalanceDueDollars;
            this.otherBalanceDueCents   = this.totalBalanceDueCents;
        } */
    }

    /**
     * getter for account holder's name
     *
     * @return a {@link java.lang.String} object.
     */
    public String getAccountHolderName() {
        return this.accountHolderName;
    }

    /**
     * setter for account holder's name
     *
     * @param accountHolderName a {@link java.lang.String} object.
     */
    public void setAccountHolderName(String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    /**
     * getter for bank account number
     *
     * @return a {@link java.lang.String} object.
     */
    public String getBankAccountNumber() {
        return this.bankAccountNumber;
    }

    /**
     * setter for bank account number
     *
     * @param bankAccountNumber a {@link java.lang.String} object.
     */
    public void setBankAccountNumber(String bankAccountNumber) {
        this.bankAccountNumber = bankAccountNumber;
    }

    /**
     * getter for bank account confirm number
     *
     * @return a {@link java.lang.String} object.
     */
    public String getBankAccountNumberConfirm() {
        return this.bankAccountNumberConfirm;
    }

    /**
     * setter for bank account confirm number
     *
     * @param bankAccountNumberConfirm a {@link java.lang.String} object.
     */
    public void setBankAccountNumberConfirm(String bankAccountNumberConfirm) {
        this.bankAccountNumberConfirm = bankAccountNumberConfirm;
    }

    /**
     * getter for bank name
     *
     * @return a {@link java.lang.String} object.
     */
    public String getBankName() {
        return this.bankName;
    }

    /**
     * setter for bank name
     *
     * @param bankName a {@link java.lang.String} object.
     */
    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    /**
     * getter for bank routing number
     *
     * @return a {@link java.lang.String} object.
     */
    public String getBankRoutingNumber() {
        return this.bankRoutingNumber;
    }

    /**
     * setter for bank routing number
     *
     * @param bankRoutingNumber a {@link java.lang.String} object.
     */
    public void setBankRoutingNumber(String bankRoutingNumber) {
        this.bankRoutingNumber = bankRoutingNumber;
    }

    /**
     * getter for bank routing number
     *
     * @return a {@link java.lang.String} object.
     */
    public String getBankRoutingNumberConfirm() {
        return this.bankRoutingNumberConfirm;
    }

    /**
     * setter for bank routing confirm number
     *
     * @param bankRoutingNumberConfirm a {@link java.lang.String} object.
     */
    public void setBankRoutingNumberConfirm(String bankRoutingNumberConfirm) {
        this.bankRoutingNumberConfirm = bankRoutingNumberConfirm;
    }

    /**
     * getter for bank status
     *
     * @return a {@link java.lang.String} object.
     */
    public String getBankStatus() {
        return this.bankStatus;
    }

    /**
     * setter for bank status number
     *
     * @param bankStatus a {@link java.lang.String} object.
     */
    public void setBankStatus(String bankStatus) {
        this.bankStatus = bankStatus;
    }

    /**
     * <p>Getter for the field <code>activityCode</code>.</p>
     *
     * @return Returns the activityCode.
     */
    public String getActivityCode() {
        return this.activityCode;
    }

    /**
     * <p>Setter for the field <code>activityCode</code>.</p>
     *
     * @param activityCode
     *            The activityCode to set.
     */
    public void setActivityCode(String activityCode) {
        this.activityCode = activityCode;
    }

    /**
     * <p>Getter for the field <code>entryDate</code>.</p>
     *
     * @return Returns the entryDate.
     */
    public String getEntryDate() {
        return this.entryDate;
    }

    /**
     * <p>Setter for the field <code>entryDate</code>.</p>
     *
     * @param entryDate
     *            The entryDate to set.
     */
    public void setEntryDate(String entryDate) {
        this.entryDate = entryDate;
    }

    /**
     * <p>Getter for the field <code>entryTime</code>.</p>
     *
     * @return Returns the entryTime.
     */
    public String getEntryTime() {
        return this.entryTime;
    }

    /**
     * <p>Setter for the field <code>entryTime</code>.</p>
     *
     * @param entryTime
     *            The entryTime to set.
     */
    public void setEntryTime(String entryTime) {
        this.entryTime = entryTime;
    }

    /**
     * <p>Getter for the field <code>entryDateTime</code>.</p>
     *
     * @return Returns the entryDateTime.
     */
    public String getEntryDateTime() {
        return this.entryDateTime;
    }

    /**
     * <p>Setter for the field <code>entryDateTime</code>.</p>
     *
     * @param entryDateTime
     *            The entryDateTime to set.
     */
    public void setEntryDateTime(String entryDateTime) {
        this.entryDateTime = entryDateTime;
    }

    /**
     * <p>Getter for the field <code>bankAccountAvailableFlag</code>.</p>
     *
     * @return Returns the isBankInfoAvailable.
     */
    public boolean getBankAccountAvailableFlag() {
        return this.bankAccountAvailableFlag;
    }

    /**
     * <p>Setter for the field <code>bankAccountAvailableFlag</code>.</p>
     *
     * @param bankAccountAvailableFlag
     *            The bankAccountAvailableFlag to set.
     */
    public void setBankAccountAvailableFlag(boolean bankAccountAvailableFlag) {
        this.bankAccountAvailableFlag = bankAccountAvailableFlag;
    }

}
