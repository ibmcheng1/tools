/**THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2015 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.struts.action.BaseAction;

/**
 * This action is designed to solve the cross-context problem.
 * 	In Struts, the forward path must have the full URL defined if it is switching contexts.
 * 	The welcome forward switches the user from cga_open to cga_secure.
 * 	Currently SST is incapable of doing a string replace of a token inside a file in a WAR in an EAR.
 * 	As such, we are inspecting the HTTP request to obtain the URL of the server.
 * 	This allows us to change based on environment.
 * 	If, in the future, SST becomes capable of this.  It is recommended to remove this action and
 * 	use the string replace on the struts-config.xml of the two WARs.
 *
 * @author mf36
 * @version $Id: $Id
 */
public class WelcomeAction extends BaseAction{
	
	private static final Logger log = Logger.getLogger(WelcomeAction.class);
	
	/**
	 * <p>Constructor for WelcomeAction.</p>
	 */
	public WelcomeAction(){
		super();
	}
	
	/**
	 * <p>execute.</p>
	 *
	 * @param mapping a {@link org.apache.struts.action.ActionMapping} object.
	 * @param form a {@link org.apache.struts.action.ActionForm} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @param response a {@link javax.servlet.http.HttpServletResponse} object.
	 * @return a {@link org.apache.struts.action.ActionForward} object.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		String forwardName = com.bcbssc.registration.common.Constants.FORWARD_WELCOME_ACTION; 
		String hostname = CommonUtils.getServerHostName(request);
		String forwardPath = mapping.findForward(forwardName).getPath();
		boolean redirect = mapping.findForward(forwardName).getRedirect();
		if(log.isDebugEnabled()){
			log.debug("WelcomeAction:hostName:"+hostname);
			log.debug("WelcomeAction:forwardPath:"+forwardPath);
		}
		return new ActionForward(hostname + forwardPath, redirect);
	}

}
