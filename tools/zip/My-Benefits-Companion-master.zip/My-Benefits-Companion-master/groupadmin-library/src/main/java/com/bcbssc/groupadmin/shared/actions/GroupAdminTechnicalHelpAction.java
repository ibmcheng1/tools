/*
 * @(#)CHCTechnicalHelpAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.actions;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.dto.TechnicalHelpFormDTO;
import com.bcbssc.groupadmin.shared.forms.TechnicalHelpForm;
import com.bcbssc.groupadmin.shared.services.GroupAdminRegistrationServices;
import com.bcbssc.registration.actions.TechnicalHelpAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * Group Admin Technical Help Action
 *
 * This class provides control processing the technical help action. Because
 * technical help control is fairly generic, this class extends the shared
 * registration technical help action.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.1  $
 */
public class GroupAdminTechnicalHelpAction extends TechnicalHelpAction {

	/** log4j logger */
	private static Logger logger = Logger
			.getLogger(GroupAdminTechnicalHelpAction.class);

	/**
	 * {@inheritDoc}
	 *
	 * Processes the specified HTTP request, and creates the corresponding HTTP
	 * response.
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		TechnicalHelpForm df = (TechnicalHelpForm) form;

		if (GroupAdminTechnicalHelpAction.logger.isDebugEnabled()) {
			GroupAdminTechnicalHelpAction.logger
					.debug("Performing technical help action");
		}

		String iniFile = CommonUtils.getIniFile(this.getServlet());
		String tdsIniFile = CommonUtils.getTDSIniFile(this.getServlet());

		// Create application-specific validation service and perform
		// application-specific form to DTO translation
		GroupAdminRegistrationServices service = new GroupAdminRegistrationServices(
				iniFile, tdsIniFile);

		TechnicalHelpFormDTO formDTO = new TechnicalHelpFormDTO();
		BeanUtils.copyProperties(formDTO, df);

		// Call shared validation action logic from parent
		return this.execute(service, formDTO, mapping, request, response);
	}
}
