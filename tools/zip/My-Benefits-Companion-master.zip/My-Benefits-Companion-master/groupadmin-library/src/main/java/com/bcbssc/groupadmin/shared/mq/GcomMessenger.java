/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mq/GcomMessenger.java_v  $
 * $Workfile:   GcomMessenger.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:15:56  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mq/GcomMessenger.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:15:56   EN80
 * Initial revision.
 * 
 *    Rev 1.4   Apr 28 2009 10:19:58   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.3   Feb 15 2005 18:52:24   rdq70
 * Added overloaded sendMessage() with the option to supress logging.
 *
 *    Rev 1.2   Feb 11 2005 14:41:10   rdq70
 * Added audit logging.
 *
 *    Rev 1.1   Feb 04 2005 14:21:08   rdq70
 * Added commit session on send.
 *
 *    Rev 1.0   Feb 01 2005 16:19:42   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.mq;

import com.bcbssc.netsys.ConfigurationException;
import com.bcbssc.netsys.LinkedException;
import com.bcbssc.netsys.jms.JMSMessenger;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

/**
 * A JMS messenger for GCOM transactions.
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class GcomMessenger extends JMSMessenger {

	/** The Log4J <code>Logger</code> for this class. */
	private static final Logger log = Logger.getLogger(GcomMessenger.class);

	/** The queue name of the destination queue. */
	private String destinationName = null;

    /**
     * <p>Constructor for GcomMessenger.</p>
     *
     * @param ctx a {@link javax.naming.InitialContext} object.
     * @param connectionFactoryName a {@link java.lang.String} object.
     * @throws javax.naming.NamingException if any.
     * @throws javax.jms.JMSException if any.
     */
      // JBH
    public GcomMessenger(InitialContext ctx, String connectionFactoryName) throws NamingException, JMSException {
        super(ctx, connectionFactoryName);
    }

	/**
	 * Sends the given message to the destination queue.
	 *
	 * @param messageBody
	 *            the message body.
	 * @return the message correlation ID.
	 * @throws com.bcbssc.netsys.LinkedException
	 *             if an error occurs.
	 */
	public String sendMessage(String messageBody) throws LinkedException {
		return this.sendMessage(messageBody, false);
	}

	/**
	 * Sends the given message to the destination queue.
	 *
	 * @param messageBody
	 *            the message body.
	 * @param suppressLogs
	 *            suppresses logs if <code>true</code>.
	 * @return the message correlation ID.
	 * @throws com.bcbssc.netsys.LinkedException
	 *             if an error occurs.
	 */
	public String sendMessage(String messageBody, boolean suppressLogs)
			throws LinkedException {
		String messageId = null;

		try {
			Message message = this.createMessage(messageBody);
			message.setJMSExpiration(0L);
			messageId = this.sendMessage(this.destinationName, message);
			this.commitSession();
			if (!suppressLogs) {
				GcomMessenger.log.info(messageBody);
			}
		} catch (JMSException jmse) {
			if (!suppressLogs) {
				GcomMessenger.log.error(messageBody);
			}
			throw new LinkedException(jmse);
		}

		return messageId;
	}

	/**
	 * Returns the destination queue name.
	 *
	 * @return the destination queue name.
	 */
	public String getDestinationName() {
		return this.destinationName;
	}

	/**
	 * Sets the destination queue name.
	 *
	 * @param destinationName -
	 *            the new queue name.
	 */
	public void setDestinationName(String destinationName) {
		this.destinationName = destinationName;
	}

	/**
	 * Creates a message object for the given text message body.
	 * 
	 * @param messageBody -
	 *            the message body in text form.
	 * @return a message object.
	 */
	private Message createMessage(String messageBody) throws JMSException,
			ConfigurationException {

		this.checkSession();
		Message message = this.session.createTextMessage(messageBody);
		return message;
	}
}
