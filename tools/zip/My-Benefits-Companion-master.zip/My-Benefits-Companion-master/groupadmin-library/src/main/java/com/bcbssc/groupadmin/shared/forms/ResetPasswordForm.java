/*
 * @(#)ResetPasswordForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.forms;

import com.bcbssc.registration.common.Constants;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

/**
 * Group Administrator Reset Password Form
 *
 * This bean is used to transport data for the reset AND change password forms.
 * We use a specialized class instead of the DynaValidatorForm class because we
 * need to perform additional special validation (password/confpassword) which
 * is not easily supported by Validator.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class ResetPasswordForm extends
        org.apache.struts.validator.DynaValidatorForm {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /** Name of the unicodePwd bean property */
    private static final String UNICODE_PWD = "unicodePwd";

    /** Confirmation Unicodepassword propery name */
    private static final String CONF_UNICODE_PWD = "confUnicodePwd";

    // /** Roles property name */
    // private static final String ROLES = "roles";

    /**
     * {@inheritDoc}
     *
     * Validates the form using the validator support provided by the parent.
     * Also verifies that the passwords match.
     */
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {
        ActionErrors errors = null;
        String buttonval = null;

        try {
            buttonval = (String) this.get(Constants.FORM_BUTTON_NAME);
        } catch (IllegalArgumentException e) {
            // No "button" property, so just set value to null
            buttonval = null;
        }

        if ((buttonval == null)
                || (!buttonval.equals(Constants.FORM_BUTTON_CANCEL))) {
            errors = super.validate(mapping, request);

            String unicodepwd = (String) this.get("unicodePwd");
            String confunicodepwd = (String) this
                    .get(ResetPasswordForm.CONF_UNICODE_PWD);
            String samaccountname = (String) this.get("samAccountName");

            if (!errors.get(ResetPasswordForm.UNICODE_PWD).hasNext()) {
                if (unicodepwd.equalsIgnoreCase(samaccountname)) {
                    errors.add(ResetPasswordForm.UNICODE_PWD, new ActionMessage(
                            "errors.unicodepwd.usernamematch"));
                    errors
                            .add(
                                    ResetPasswordForm.CONF_UNICODE_PWD,
                                    new ActionMessage(
                                            "error.changePasswordForm.confirmpwd.required"));
                }
            }
            com.bcbssc.struts.common.CommonUtils.validateMatchingIfErrorless(
                    errors, unicodepwd, confunicodepwd,
                    ResetPasswordForm.CONF_UNICODE_PWD,
                    "errors.newpasswordmatch");

        }

        return errors;
    }
}
