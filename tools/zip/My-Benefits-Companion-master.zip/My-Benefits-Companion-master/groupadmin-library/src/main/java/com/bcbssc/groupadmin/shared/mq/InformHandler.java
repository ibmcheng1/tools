/*
 * ClosedInformHandler.java
 * 
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.mq;

import com.bcbssc.netsys.Config;
import com.bcbssc.netsys.inform.InformEndLine;
import com.bcbssc.netsys.inform.InformInquiryLine;
import com.bcbssc.netsys.inform.InformUtil;

import java.io.FileNotFoundException;

import org.apache.log4j.Logger;

/**
 * Handles Group Admin INFOrm messaging for user events.
 *
 * @author rxg97 (Jonathan Egger)
 * @version $Id: $Id
 */
public class InformHandler {

	/** log4j logger */
	private static final Logger logger = Logger.getLogger(InformHandler.class);

	/** the application-specific INI file */
	private String iniFile;

	/** the application-specific RPN value */
	private String rpn;

	/** the application-specific company code value */
	private String companyCode;

	/** the application-specific corporate code value */
	private String corporateCode;

	/** the application-specific deparment code value */
	private String departmentCode;

	/** the application-specific division code value */
	private String divisionCode;

	/** the application-specific employee ID */
	private String employeeId;

	/** the application-specific INFO TYPE */
	private String infoType;

	/** the application-specific Id */
	private String appId;

	/** function related: corrspName */
	String corrspName;

	/** function related: */
	private String requestCode;

	/** Closed / Open inform */
	boolean closedInform;

	/** function related content */
	private String requestLines;

	/**
	 * Creates a new instance of GroupAdminUserInformHandler, setting the
	 * application-specific INFOrm parameters based on the specified ini file.
	 *
	 * @param iniFileName a {@link java.lang.String} object.
	 * @param task a {@link java.lang.String} object.
	 * @param dataObject a {@link java.lang.Object} object.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public InformHandler(String iniFileName, String task, Object dataObject)
			throws FileNotFoundException {
		this(iniFileName, task, dataObject, false);
	}

	/**
	 * Creates a new instance of GroupAdminUserInformHandler, setting the
	 * application-specific INFOrm parameters based on the specified ini file.
	 *
	 * @param iniFileName
	 *            file containing the application-specific parameters
	 * @param task a {@link java.lang.String} object.
	 * @param dataObject a {@link java.lang.Object} object.
	 * @param informType a boolean.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public InformHandler(String iniFileName, String task, Object dataObject,
			boolean informType) throws FileNotFoundException {
		super();

		this.iniFile = iniFileName;
		this.rpn = Config.getPrivateProfileString("MISC", "RPN", "",
				this.iniFile);
		this.companyCode = Config.getPrivateProfileString("MISC",
				"APP_INFO_COMPANY_CODE", "", this.iniFile);
		this.corporateCode = Config.getPrivateProfileString("MISC",
				"APP_INFO_CORPORATE_CODE", "", this.iniFile);
		this.departmentCode = Config.getPrivateProfileString("MISC",
				"APP_INFO_DEPARTMENT_CODE", "", this.iniFile);
		this.divisionCode = Config.getPrivateProfileString("MISC",
				"APP_INFO_DIVISION_CODE", "", this.iniFile);
		/*
		 * Check the task name based on it we will set the employeeId variable.
		 */
		if ("BankInformation".equals(task) || "PaymentInformation".equals(task)) {
			this.employeeId = Config.getPrivateProfileString("MISC",
					"APP_INFO_PAY_ID", "", this.iniFile);
		} else if ("RequestBill".equals(task)) {
			this.employeeId = Config.getPrivateProfileString("MISC",
					"APP_INFO_BILL_ID", "", this.iniFile);
		} else {
			this.employeeId = Config.getPrivateProfileString("MISC",
					"APP_INFO_EMP_ID", "", this.iniFile);
		}

		this.infoType = Config.getPrivateProfileString("MISC",
				"USER_INFO_TYPE", "", this.iniFile);
		this.appId = Config.getPrivateProfileString("MISC", "APP_ID", "",
				this.iniFile);
		// object used to get the inform attributes and request lines
		InformRequestFormat irf = null;

		String inFile = Config.getPrivateProfileString("MISC",
				"INFO_REQUEST_FILE", "", this.iniFile);
		InformHandler.logger.debug("Request lines defined in: " + inFile);

		if (inFile.length() > 0) {
			irf = new InformRequestFormat(inFile);
			irf.processLines(task, dataObject);

			// get function specific values
			this.corrspName = irf.getCorrspName();
			this.requestCode = irf.getRequestCode();

			/*
			 * Check for "task", if it is "BankInformation" then use the
			 * "informType" boolean. This 'informType' flag is derived from the
			 * bank account web payment status If it is '9', inform is "open"
			 * else "closed". Otherwise the inform flag will be calculated from
			 * xml element.
			 */
			if ("BankInformation".equals(task)) {
				this.closedInform = informType;
			} else {
				this.closedInform = irf.isClosedInform();
			}
			InformHandler.logger.debug("Is inform closed:" + this.closedInform);

			// get output for the requestlines
			this.requestLines = irf.getFormattedOutput();
		} else {
			InformHandler.logger
					.error("Unable to fine INI file to send INForm");
			throw new FileNotFoundException(
					"Unable to find INI file to send INForm");
		}
	}

	/**
	 * Creates and sends a profile completed INFOrm for the specified user.
	 *
	 * @param keyId a {@link java.lang.String} object.
	 * @param altKey a {@link java.lang.String} object.
	 */
	public void sendInform(String keyId, String altKey) {

		// make header
		InformHeader ihb = new InformHeader();
		ihb.setInfoType(this.infoType);
		ihb.setKeyId(keyId);
		ihb.setAltKeyId(altKey);
		ihb.setRpn(this.rpn);
		ihb.setCompanyCode(this.companyCode);
		ihb.setCorporateCode(this.corporateCode);
		ihb.setDepartmentCode(this.departmentCode);
		ihb.setDivisionCode(this.divisionCode);
		ihb.setEmployeeId(this.employeeId);

		ihb.setAction("A");

		if ("CLIFEGRPAD".equalsIgnoreCase(this.appId)) {
			if (this.closedInform) {
				// make it a CLOSED inform
				ihb.setStatusCode("2");
				ihb.setStatusType("cl");
			} else {
				// make it an open inform
				ihb.setStatusCode("1");
				ihb.setStatusType("OP");
			}
		} else {

			if (this.closedInform) {
				// make it a CLOSED inform
				ihb.setStatusCode("1");
				ihb.setStatusType("cl");
			} else {
				// make it an open inform
				ihb.setStatusCode("2");
				ihb.setStatusType("OP");
			}
		}
		ihb.setRequestCode(this.requestCode);
		InformHandler.logger
				.debug("Creating ClifeInformMessage for profile created");
		InformMessage cim = new InformMessage();

		// ClaimNumber is an unused field we can use for appName
		ihb.setClaimNumber("WEB" + this.corrspName);

		cim.setHeader(ihb);
		cim.addLine(new InformInquiryLine());

		StringBuffer verbiage = new StringBuffer(512);
		verbiage.append(this.corrspName);
		verbiage.append("\n").append(this.requestLines);

		InformUtil.addRequestLines(cim, this.requestLines);
		cim.addLine(new InformEndLine());
		CommonInformUtils.sendMessage(cim, "GroupAdmin", this.iniFile);
	}

}
