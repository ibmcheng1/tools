/*
 * @(#)CoverageForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.forms;

import java.util.Iterator;

import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.groupadmin.shared.dto.CoverageItem;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

/**
 * GroupAdmin Coverage Form
 *
 * This bean extends the InsuredSearchForm by providing validation specific to
 * the Coverage form.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public abstract class CoverageForm extends InsuredSearchForm {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** log4j logger */
    private static Logger log = Logger.getLogger(CoverageForm.class);

    private static final String DEFAULT_CENTS = "00";

    /**
     * Gets the annual salary (dollars and cents concatenated)
     *
     * @return annual salary
     */
    public String getAnnualSalary() {
        String annualSalary;

        if ((this.annualSalaryCents.length() == 0)
                && (this.annualSalaryDollars.length() > 0)) {
            annualSalary = this.annualSalaryDollars
                    + CoverageForm.DEFAULT_CENTS;
        } else {
            annualSalary = this.annualSalaryDollars + this.annualSalaryCents;
        }

        return annualSalary;
    }

    /**
     * {@inheritDoc}
     *
     * Validates the form.
     */
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {
        ActionErrors errors = super.validate(mapping, request);
        int coverageItemCount = (this.coverageItems != null) ? this.coverageItems
                .size()
                : 0;

        // check for salary error already recorded
        Iterator salMessages = errors.get("annualSalary");
        boolean salError = salMessages.hasNext();

        if (!salError && this.getClassRequiresAnnualSalary()) {
            try {
                if (Double.parseDouble(this.getAnnualSalary()) <= 0.0) {
                    errors.add("annualSalary", new ActionMessage(
                            "error.coverage.annualSalary.required"));
                }
            } catch (NumberFormatException nfe) {
                // generate a validation error to the page
                errors.add("annualSalary", new ActionMessage(
                        "error.coverage.annualSalary.numeric"));
            }
        }

        boolean dependentError = false; // True if dependent error
        
        /* Check for invalid coverage selections. To put it simply, do not
		 * allow the user to select a Dependent Life coverage(DEPE) if the
		 * Basic Life (LIFE) coverage is available, yet has been declined. 
		 * The samegoes for the Voluntary Dependent Life coverages 
		 * (VSPS, VSPF, VSPM, VCHI) and Voluntary Employee Life (VLIF) */
        for (int i = 0; i < coverageItemCount; i++) {
            CoverageItem item = this.getCoverageItem(i);
            String coverageCode = item.getCode();
			//see if the current coverage item is LIFE or VLIF
            boolean basicLife = Constants.COVERAGE_LIFE.equals(coverageCode);
            boolean volLife = Constants.COVERAGE_LIFE_VOLUNTARY.equals(coverageCode);
            //If the coverage can be selected, is declined, and is either Basic Life or Voluntary Life
            if(!item.getActionProtected() 
            		&& (CoverageItem.ACTION_DECLINED == item.getAction())
            		&& (basicLife || volLife)){
					// Iterate again for dependent check
					for (int i2 = 0; i2 < coverageItemCount; i2++) {
						CoverageItem item2 = this.getCoverageItem(i2);
						if((CoverageItem.ACTION_ACCEPTED == item2.getAction())){
							if ((basicLife 
									&& Constants.COVERAGE_LIFE_DEPENDENT.equals(item2.getCode()))
									|| (volLife
											&& (Constants.COVERAGE_LIFE_VOLUNTARY_SPOUSE.equals(item2.getCode())
											|| Constants.COVERAGE_LIFE_VOLUNTARY_SPOUSE_FEMALE.equals(item2.getCode())
											|| Constants.COVERAGE_LIFE_VOLUNTARY_SPOUSE_MALE.equals(item2.getCode()) 
											|| Constants.COVERAGE_LIFE_VOLUNTARY_CHILD.equals(item2.getCode())))) {
								/* If there is an error, add it.
								 * If the error has already been added, do not add it again.
								 * This will display the basic message once. */
		                        if (!dependentError) {
		                            CoverageForm.log.debug("Adding new action error for property 'action'.");
		                            errors.add("coverageItem[" + i + "].action",
		                                    new ActionMessage("error.coverage.dependent",
		                                            "coverageItem[" + i + "].action"));
		                            dependentError = true;
		                        }
		                        // Add an error for the dependent fields,
		                        // but do not display a message for each one.
		                        errors.add("coverageItem[" + i2 + "].action",
		                                new ActionMessage("error.coverage.nomessage",
		                                        "coverageItem[" + i2 + "].action"));
		                    }
						}
	                }
				}
        }

        int lifeEmployeeVolume = 0; // Life employee volume
        int addEmployeeVolume = 0; // AD&D employee volume

        for (int i = 0; i < coverageItemCount; i++) {
            CoverageItem item = this.getCoverageItem(i);
            String coverageCode = item.getCode();
            if (!item.getVolumeDisabled() && item.getVolumeEditable()
                    && (item.getAction() != CoverageItem.ACTION_DECLINED)
                    && (!"modify".equalsIgnoreCase(this.getSearchType()))) {
                long itemVolume = item.getVolume();

                if (itemVolume == 0) {
                    errors.add("coverageItem[" + i + "].volume",
                            new ActionMessage("error.coverage.volume.numeric",
                                    "coverageItem[" + i + "].volume"));
                    break;
                } else if (item.isVolumeUnits()) {
                    long itemUnits = (long) item.getGroupBaseUnit();

                    // if 0 then use coverage default base unit
                    if (itemUnits == 0) {
                        itemUnits = (long) item.getBaseUnit();
                    }
                    if (itemVolume % itemUnits != 0) {
                        errors.add("coverageItem[" + i + "].volume",
                                new ActionMessage(
                                        "error.coverage.volume.multiples",
                                        "coverageItem[" + i + "].volume", 
                                        Long.toString(itemUnits)));
                        break;
                    }
                    int minVolume = item.getMinimumVolume();
                    int maxVolume = item.getMaximumVolume();
                    if ((minVolume > 0) && (itemVolume < minVolume)) {
                        errors.add("coverageItem[" + i + "].volume",
                                new ActionMessage("error.coverage.volume.min",
                                        "coverageItem[" + i + "].volume"));
                        break;
                    }
                    if ((maxVolume > 0) && (itemVolume > maxVolume)) {
                        errors.add("coverageItem[" + i + "].volume",
                                new ActionMessage("error.coverage.volume.max",
                                        "coverageItem[" + i + "].volume"));
                        break;
                    }

                    // If volume of dependent life coverage is greater than 50%
                    // of employee coverage volume, add an error.
                    boolean basicLife = Constants.COVERAGE_LIFE.equals(coverageCode);
                    boolean volLife = Constants.COVERAGE_LIFE_VOLUNTARY.equals(coverageCode);
                    if (basicLife || volLife) {

                        // Set the life employee volume
                        lifeEmployeeVolume = item.getVolume();

                        // Iterate again for dependent check
                        if(lifeEmployeeVolume > 0){
	                        for (int i2 = 0; i2 < coverageItemCount; i2++) {
	                        	
	                            CoverageItem item2 = this.getCoverageItem(i2);
	                            String coverageCode2 = item2.getCode();
	                            int lifeDependentVolume = item2.getVolume();  // Life dependent volume
                                String name = item2.getName();
                                
	                            if((CoverageItem.ACTION_ACCEPTED == item2.getAction())
	                            		&&((basicLife 
	                            				&& Constants.COVERAGE_LIFE_DEPENDENT.equals(coverageCode2))
	                            		||(volLife 
	                            				&& (Constants.COVERAGE_LIFE_VOLUNTARY_SPOUSE.equals(coverageCode2)
	                            				|| Constants.COVERAGE_LIFE_VOLUNTARY_SPOUSE_FEMALE.equals(coverageCode2)
	                            				|| Constants.COVERAGE_LIFE_VOLUNTARY_SPOUSE_MALE.equals(coverageCode2) 
	                            				|| Constants.COVERAGE_LIFE_VOLUNTARY_CHILD.equals(coverageCode2))))){

	                               if(name.contains("SPOUSE")){
	                            	   if ((lifeDependentVolume > 0)
	                                        && (lifeDependentVolume > (lifeEmployeeVolume / 2))) {
	                            		   	
	                            		   errors.add("coverageItem[" + i + "].volume",
	                                                    new ActionMessage(
	                                                            "error.coverage.volume.spouse",
	                                                            "coverageItem[" + i2 + "].volume"));
	                            		   CoverageForm.log.debug("Error on coverage volume.");
	                            		   break;
	                                	}
	                                }
	                            }
	                        }
                        }
                    }

                    // If volume of dependent AD&D coverage is greater than 50%
                    // of employee coverage volume, add an error.
                    if (Constants.COVERAGE_AD_D.equals(coverageCode)
                            || Constants.COVERAGE_AD_D_CL.equals(coverageCode)
                            || Constants.COVERAGE_AD_D_VOLUNTARY
                                    .equals(coverageCode)
                            || Constants.COVERAGE_AD_D_SU.equals(coverageCode)) {

                        // Set the life employee volume
                        addEmployeeVolume = item.getVolume();

                        // Iterate again for dependent check
                        for (int i2 = 0; i2 < coverageItemCount; i2++) {
                            CoverageItem item2 = this.getCoverageItem(i2);
                            String coverageCode2 = item2.getCode();
                            int addDependentVolume = 0; // AD&D dependent volume

                            if ((Constants.COVERAGE_AD_D_SU_FEMALE
                                    .equals(coverageCode2)
                                    || Constants.COVERAGE_AD_D_SU_MALE
                                            .equals(coverageCode2)
                                    || Constants.COVERAGE_AD_D_VOLUNTARY_FEMALE
                                            .equals(coverageCode2)
                                    || Constants.COVERAGE_AD_D_VOLUNTARY_MALE
                                            .equals(coverageCode2) || Constants.COVERAGE_AD_D_VOLUNTARY_SPOUSE
                                    .equals(coverageCode2))
                                    && (CoverageItem.ACTION_ACCEPTED == item2.getAction())
                                    && (addEmployeeVolume > 0)) {

                                addDependentVolume = item2.getVolume();

                                if ((addDependentVolume > 0)
                                        && (addDependentVolume > (addEmployeeVolume / 2))) {
                                    errors
                                            .add(
                                                    "coverageItem[" + i
                                                            + "].volume",
                                                    new ActionMessage(
                                                            "error.coverage.volume.spouse.add",
                                                            "coverageItem["
                                                                    + i2
                                                                    + "].volume"));
                                    CoverageForm.log
                                            .debug("Error on coverage volume.");
                                    break;
                                }
                            }
                        }
                    }

                }
            }
        }

        return errors;
    }
}
