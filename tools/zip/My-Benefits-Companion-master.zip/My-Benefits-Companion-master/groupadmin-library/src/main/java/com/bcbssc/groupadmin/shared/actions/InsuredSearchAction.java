/*
 * @(#)InsuredSearchAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.actions;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.bcbssc.commapi.model.documentarchive.GroupAdminCorbelDocument;
import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.groupadmin.shared.common.GroupAdminHelper;
import com.bcbssc.groupadmin.shared.dto.CoverageItem;
import com.bcbssc.groupadmin.shared.dto.CoverageItemList;
import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredSearchDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredSearchResult;
import com.bcbssc.groupadmin.shared.dto.PayrollDeductionAmountsDTO;
import com.bcbssc.groupadmin.shared.forms.ChangeSelectionForm;
import com.bcbssc.groupadmin.shared.forms.InsuredSearchForm;
import com.bcbssc.groupadmin.shared.forms.SpecialRequestForm;
import com.bcbssc.groupadmin.shared.forms.TerminateForm;
import com.bcbssc.groupadmin.shared.mq.GroupAdminPayrollDeductionAmountsInformHandler;
import com.bcbssc.groupadmin.shared.services.InsuredServices;
import com.bcbssc.netsys.Config;
import com.bcbssc.struts.action.SimpleDispatchAction;
/**
 * Group Admin Insured Search Action
 *
 * This class provides control processing for the insured search pages.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class InsuredSearchAction extends SimpleDispatchAction {

	/** log4j logger */
	private static final Logger log = Logger
			.getLogger(InsuredSearchAction.class.getName());

	/** Search types */
	public static final String SEARCH_TYPE_MODIFY_REFRESH = "modify_refresh";

	private static final String SEARCH_TYPE_MODIFY = "modify";

	private static final String SEARCH_TYPE_VIEW = "view";

	private static final String SEARCH_TYPE_TERMINATE = "terminate";

	private static final String SEARCH_TYPE_IDCARD = "idcard";

	private static final String SEARCH_TYPE_REQUEST_A_CHANGE = "changerequest";

	private static final String DENTAL_FILLER = " ";

	private static final String DENTAL_COVERAGE = "DENTAL";

	/**
	 * Displays the intial search criteria form.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward displayModifyForm(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		return this.displaySearchForm(InsuredSearchAction.SEARCH_TYPE_MODIFY,
				mapping, form, request, response,
				com.bcbssc.struts.common.Constants.BLANK_STRING);
	}

	/**
	 * Displays the intial search criteria form.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward displayTerminateForm(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		return this.displaySearchForm(
				InsuredSearchAction.SEARCH_TYPE_TERMINATE, mapping, form,
				request, response, Constants.STATUS_ACTIVE);
	}

	/**
	 * Displays the intial search criteria form.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward displayIDCardForm(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		return this.displaySearchForm(InsuredSearchAction.SEARCH_TYPE_IDCARD,
				mapping, form, request, response, Constants.STATUS_ACTIVE);
	}

	/**
	 * Displays the intial search criteria form for insured view.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward displayViewForm(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		return this.displaySearchForm(InsuredSearchAction.SEARCH_TYPE_VIEW,
				mapping, form, request, response,
				com.bcbssc.struts.common.Constants.BLANK_STRING);
	}




		/**
		 * Displays the intial search criteria form for insured view.
		 *
		 * @param mapping
		 *            the ActionMapping used to select this instance
		 * @param form
		 *            the optional bean for this request (if any)
		 * @param request
		 *            the HTTP request we are processing
		 * @param response
		 *            the HTTP request we are creating
		 * @return describes where and how control should be forwarded, or null if
		 *         the response has already been completed.
		 * @throws java.lang.Exception if any.
		 */
		public ActionForward displayChangeRequestForm(ActionMapping mapping,
				ActionForm form, HttpServletRequest request,
				HttpServletResponse response) throws Exception {

			return this.displaySearchForm(InsuredSearchAction.SEARCH_TYPE_REQUEST_A_CHANGE,
					mapping, form, request, response,
					com.bcbssc.struts.common.Constants.BLANK_STRING);
	   }






	/**
	 * Performs insured search
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward insuredSearch(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		InsuredSearchForm insuredSearchForm = (InsuredSearchForm) form;

		InsuredSearchDTO insuredSearchDTO = new InsuredSearchDTO();
		BeanUtils.copyProperties(insuredSearchDTO, insuredSearchForm);

		String iniFile = CommonUtils.getIniFile(getServlet());
		String fromDaysBack = Config.getPrivateProfileString("MISC", "PDF_FROM_DATE_DAYS", "", iniFile);

		if(log.isDebugEnabled()){
			log.debug("Today - From date  = " + fromDaysBack);
		}

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

		Calendar fromDateTemp = Calendar.getInstance();

		int daysPast = Integer.parseInt(fromDaysBack);

		fromDateTemp.add(6, -daysPast);

		String fromDate = formatter.format(fromDateTemp.getTime());

		if(log.isDebugEnabled()){
			log.debug("InsuredSearchAction formattedFromDate=" + fromDate);
			log.debug("InsuredSearchAction toDate=" + insuredSearchForm.getDate());
		}

		SimpleDateFormat toDateformatter = new SimpleDateFormat("MM/dd/yyyy");

		Date toDateTemp = toDateformatter.parse(insuredSearchForm.getDate());

		String toDate = formatter.format(Long.valueOf(toDateTemp.getTime()));
		if(log.isDebugEnabled()){
		log.debug("InsuredSearchAction toDate=" + toDate);
		}

		InsuredServices insuredServices = new InsuredServices(
				CommonUtils.getIniFile(this.getServlet()),
				CommonUtils.getGcomIniFile(this.getServlet()),
				(GroupAdminUserDTO) request
						.getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
		insuredServices.searchForEmployees(insuredSearchDTO);

		GroupAdminHelper gHelper = new GroupAdminHelper();

		ArrayList policyList = gHelper.getGroupAdminPolicyDocumentList(insuredSearchDTO.getGroupNumber(), fromDate, toDate);

		insuredSearchForm.setPolicyList(policyList);

		BeanUtils.copyProperties(insuredSearchForm, insuredSearchDTO);

		int resultCount = insuredSearchDTO.getSearchResultsCount();
		String productSelected = insuredSearchForm.getProductSelected();
		String periodSelected = insuredSearchForm.getPayPeriod();

		if((resultCount > 0) && (productSelected != null)
				&& (periodSelected != null)) {

			for (int i = 0; i < insuredSearchDTO.getSearchResults().size(); i++) {
				InsuredSearchResult insuredSearchResult = (InsuredSearchResult) insuredSearchDTO
						.getSearchResults().get(i);

				if (productSelected.equals(Constants.PRODUCT_DENTAL)) {

					/**
					 * Add the TA to the payroll deduction amount for VOLUNTARY
					 * DENTAL Project:LI1190
					 */
					String dentalPDA = calculateDentalPayrollDeductionAmountwithTA(
							insuredSearchResult, insuredServices,
							periodSelected, insuredSearchDTO);

					if (StringUtils.isBlank(dentalPDA)) {
						insuredSearchResult
								.setPayrollDeductionAmt(insuredSearchResult
										.getDentalPremiumPayPeriod());
					} else {

						insuredSearchResult.setPayrollDeductionAmt(dentalPDA);
					}


				}
				if (productSelected.equals(Constants.PRODUCT_VISION)) {

					/**
					 * Add the TA to the payroll deduction amount for VOLUNTARY
					 * VISION Project:LI1190
					 */

					String visionPDA = calculateVisionPayrollDeductionAmountwithTA(
							insuredSearchResult, insuredServices,
							periodSelected, insuredSearchDTO);

					 if(StringUtils.isBlank(visionPDA)){

						insuredSearchResult
								.setPayrollDeductionAmt(insuredSearchResult
										.getVisionPremiumPayPeriod());
					} else {

						insuredSearchResult.setPayrollDeductionAmt(visionPDA);
					  }
				}
				if (productSelected.equals(Constants.PRODUCT_LIFE)) {
					insuredSearchResult
							.setPayrollDeductionAmt(insuredSearchResult
									.getLifePremiumPayPeriod());
				}
				if (productSelected.equals(Constants.PRODUCT_LTD)) {
					insuredSearchResult
							.setPayrollDeductionAmt(insuredSearchResult
									.getLtdPremiumPayPeriod());
				}
				if (productSelected.equals(Constants.PRODUCT_STD)) {
					insuredSearchResult
							.setPayrollDeductionAmt(insuredSearchResult
									.getStdPremiumPayPeriod());
				}
				if (productSelected.equals(Constants.PRODUCT_VOLUNTARY)) {
					insuredSearchResult
							.setPayrollDeductionAmt(insuredSearchResult
									.getTotalPremiumPayPeriod());
				}
			}
		}

		if (resultCount == 0) {
			this.addGlobalRequestMessage(request,
					"errors.insured.search.failed");
			return mapping.getInputForward();
		} else if (resultCount == 1) {
			// If only 1 insured employee is returned, display the 'Insured
			// Employee
			// Details' page
			String idNumber = ((InsuredSearchResult) insuredSearchDTO
					.getSearchResults().get(0)).getIdentificationNumber();
			InsuredSearchAction.log.debug("idNumber is: " + idNumber);
			insuredSearchForm.setSelectedID(idNumber);
			return this.selectEmployee(mapping, insuredSearchForm, request,
					response);
		} else {
			BeanUtils.copyProperties(insuredSearchForm, insuredSearchDTO);
			request.setAttribute("searchForm", insuredSearchForm);

			// Display the Insured Employee List page
			return mapping.findForward("list");
		}
	}

	private String calculateDentalPayrollDeductionAmountwithTA(
			InsuredSearchResult insuredSearchResult,
			InsuredServices insuredServices, String periodSelected,
			InsuredSearchDTO insuredSearchDTO) throws Exception {

		String selectedID = insuredSearchResult.getIdentificationNumber();

		String dentalPremiumPDA = "";

		String payrollDeductionAmount = "";

		String dentalPremiumDollar = "";

		String premiumTypeTA = "";

		double premiumTypeTADouble = 0.00;

		String premiumTypeVoluntaryFederalFee = "";

		double premiumTypeVoluntaryFederalFeeDouble = 0.00;
		int selectedPeriod = Integer.parseInt(periodSelected);

		if(log.isDebugEnabled()){
			log.debug("selectedPeriod="+selectedPeriod);
		}

		DecimalFormat formatter = new DecimalFormat("##0.00");
		insuredServices.getEmployeeCoverageDetailsForTA(insuredSearchDTO,
				selectedID);
		CoverageItemList itemsList1 = (CoverageItemList) insuredSearchDTO
				.getCoverageItems();
		boolean voluntaryDental = false;

		// search for VOLUNTARY DENTAL from the coverage items and if found mark
		// it as voluntaryDental
		for (int j = 0; j < itemsList1.size(); j++) {

			com.bcbssc.groupadmin.shared.dto.CoverageItem item = itemsList1
					.getCoverageItem(j);

			String name = item.getName();

			if (StringUtils.equals("VOLUNTARY DENTAL", name)) {

				voluntaryDental = true;

				dentalPremiumDollar = item.getPremiumFormatted();

				break;
			}

		}

		if (voluntaryDental) {
			for (int k = 0; k < itemsList1.size(); k++) {

				com.bcbssc.groupadmin.shared.dto.CoverageItem item = itemsList1
						.getCoverageItem(k);

				String type = item.getType();
				String code = item.getCode();

				if (StringUtils.equals("TA", type)
						&& StringUtils.equals("DNTX", code)) {
					premiumTypeTA = item.getPremiumFormatted();
					break;

				}

			}

			for (int m = 0; m < itemsList1.size(); m++) {

				com.bcbssc.groupadmin.shared.dto.CoverageItem item = itemsList1
						.getCoverageItem(m);

				String type = item.getType();
				String code = item.getCode();

				if (StringUtils.equals("25", type)
						&& StringUtils.equals("DNF1", code)) {
					premiumTypeVoluntaryFederalFee = item.getPremiumFormatted();
					break;

				}

			}

			if (StringUtils.isNotBlank(premiumTypeTA)) {

				String premiumTypeTANoDollar = premiumTypeTA.replace("$", "");

				premiumTypeTADouble = ((Double.parseDouble(premiumTypeTANoDollar)) * 12)/ selectedPeriod;

			}

			if (StringUtils.isNotBlank(premiumTypeVoluntaryFederalFee)) {

				String premiumTypeVoluntaryFederalFeeNoDollar = premiumTypeVoluntaryFederalFee.replace("$", "");

				premiumTypeVoluntaryFederalFeeDouble = ((Double.parseDouble(premiumTypeVoluntaryFederalFeeNoDollar)) * 12)/ selectedPeriod;

			}

			if (StringUtils.isNotBlank(dentalPremiumDollar)) {

				if(log.isDebugEnabled()){
					log.debug("dentalPremiumDollar = "+dentalPremiumDollar);
				}

				String dentalPremiumPayPeriodNoDollar = dentalPremiumDollar.replace("$", "");
				double dentalPremiumPayPeriod = ((Double.parseDouble(dentalPremiumPayPeriodNoDollar)) * 12)/ selectedPeriod;

				if(log.isDebugEnabled()){
					log.debug("dentalPremiumPayPeriod = "+dentalPremiumPayPeriod);
				}
				double tempDentalPremiumPDA = dentalPremiumPayPeriod + premiumTypeTADouble + premiumTypeVoluntaryFederalFeeDouble;
				dentalPremiumPDA = formatter.format(tempDentalPremiumPDA);

				payrollDeductionAmount = "$" + dentalPremiumPDA;
			} else {

				double tempDentalPremiumPDA = premiumTypeTADouble
						+ premiumTypeVoluntaryFederalFeeDouble;
				dentalPremiumPDA = formatter.format(tempDentalPremiumPDA);
				payrollDeductionAmount = "$" + dentalPremiumPDA;
			}

		}

		if(log.isDebugEnabled()){
			log.debug("payrollDeductionAmount = "+payrollDeductionAmount);
		}

		return payrollDeductionAmount;

	}

	private String calculateVisionPayrollDeductionAmountwithTA(
			InsuredSearchResult insuredSearchResult,
			InsuredServices insuredServices, String periodSelected,
			InsuredSearchDTO insuredSearchDTO) throws Exception {

		String selectedID = insuredSearchResult.getIdentificationNumber();
		String visionPremiumPDA = "";
		String payrollDeductionAmount = "";

		String premiumTypeTA = "";
		double premiumTypeTADouble = 0.00;

        String visionPremiumDollar = "";
		String premiumTypeVoluntaryFederalFee = "";

		double premiumTypeVoluntaryFederalFeeDouble = 0.00;

		int selectedPeriod = Integer.parseInt(periodSelected);
		if(log.isDebugEnabled()){
			log.debug("vision selectedPeriod ="+selectedPeriod);
		}

		DecimalFormat formatter = new DecimalFormat("##0.00");

		insuredServices.getEmployeeCoverageDetailsForTA(insuredSearchDTO,
				selectedID);

		CoverageItemList itemsList1 = (CoverageItemList) insuredSearchDTO
				.getCoverageItems();

		boolean voluntaryVision = false;

		// check for VOLUNTARY VISION in coverage items list

		for (int j = 0; j < itemsList1.size(); j++) {

			com.bcbssc.groupadmin.shared.dto.CoverageItem item = itemsList1
					.getCoverageItem(j);

			String name = item.getName();

			if (StringUtils.equals("VOLUNTARY VISION", name)) {

				voluntaryVision = true;
			    visionPremiumDollar = item.getPremiumFormatted();
				break;
			}

		}

		if (voluntaryVision) {

			for (int k = 0; k < itemsList1.size(); k++) {

				com.bcbssc.groupadmin.shared.dto.CoverageItem item = itemsList1
						.getCoverageItem(k);

				String type = item.getType();
				String code = item.getCode();

				if (StringUtils.equals("TA", type)
						&& StringUtils.equals("VITX", code)) {
					premiumTypeTA = item.getPremiumFormatted();

					break;

				}
			}

			for (int k = 0; k < itemsList1.size(); k++) {

				com.bcbssc.groupadmin.shared.dto.CoverageItem item = itemsList1
						.getCoverageItem(k);

				String type = item.getType();
				String code = item.getCode();

				if (StringUtils.equals("26", type)
						&& StringUtils.equals("VIF1", code)) {
					premiumTypeVoluntaryFederalFee = item.getPremiumFormatted();

					break;

				}
			}

			if (StringUtils.isNotBlank(premiumTypeTA)) {

				String premiumTypeTANoDollar = premiumTypeTA.replace("$", "");

				premiumTypeTADouble = ((Double.parseDouble(premiumTypeTANoDollar)) * 12)/ selectedPeriod;

			}

			if (StringUtils.isNotBlank(premiumTypeVoluntaryFederalFee)) {

				String premiumTypeVoluntaryFederalFeeNoDollar = premiumTypeVoluntaryFederalFee.replace("$", "");

				premiumTypeVoluntaryFederalFeeDouble = ((Double.parseDouble(premiumTypeVoluntaryFederalFeeNoDollar)) * 12)/ selectedPeriod;
						}

			if (StringUtils.isNotBlank(visionPremiumDollar)) {

				if(log.isDebugEnabled()){
					log.debug("visionPremiumDollar="+visionPremiumDollar);
				}

				String visionPremiumPayPeriodNoDollar = visionPremiumDollar.replace("$", "");
				double visionPremiumPayPeriod = ((Double.parseDouble(visionPremiumPayPeriodNoDollar)) * 12)/ selectedPeriod;

				if(log.isDebugEnabled()){
					log.debug("visionPremiumPayPeriod="+visionPremiumPayPeriod);
				}
				double tempVisionPremiumPDA = visionPremiumPayPeriod + premiumTypeTADouble 	+ premiumTypeVoluntaryFederalFeeDouble;
				visionPremiumPDA = formatter.format(tempVisionPremiumPDA);

				payrollDeductionAmount = "$" + visionPremiumPDA;
			} else {

				double tempVisionPremiumPDA = premiumTypeTADouble+ premiumTypeVoluntaryFederalFeeDouble;
				visionPremiumPDA = formatter.format(tempVisionPremiumPDA);
				payrollDeductionAmount = "$" + visionPremiumPDA;
			}

		}
		if(log.isDebugEnabled()){
			log.debug("vision payrollDeductionAmount="+payrollDeductionAmount);
		}
		return payrollDeductionAmount;

	}

	/**
	 * <p>insuredRequestaChangeSearch.</p>
	 *
	 * @param mapping a {@link org.apache.struts.action.ActionMapping} object.
	 * @param form a {@link org.apache.struts.action.ActionForm} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @param response a {@link javax.servlet.http.HttpServletResponse} object.
	 * @return a {@link org.apache.struts.action.ActionForward} object.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward insuredRequestaChangeSearch(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

			InsuredSearchForm insuredSearchForm = (InsuredSearchForm) form;

			InsuredSearchDTO insuredSearchDTO = new InsuredSearchDTO();
			BeanUtils.copyProperties(insuredSearchDTO, insuredSearchForm);

			InsuredServices insuredServices = new InsuredServices(
					CommonUtils.getIniFile(this.getServlet()),
					CommonUtils.getGcomIniFile(this.getServlet()),
					(GroupAdminUserDTO) request
							.getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
			insuredServices.searchForEmployees(insuredSearchDTO);
			BeanUtils.copyProperties(insuredSearchForm, insuredSearchDTO);

			int resultCount = insuredSearchDTO.getSearchResultsCount();
			String productSelected = insuredSearchForm.getProductSelected();
			String periodSelected = insuredSearchForm.getPayPeriod();

			if ((resultCount > 0) && (productSelected != null)
					&& (periodSelected != null)) {

				for (int i = 0; i < insuredSearchDTO.getSearchResults().size(); i++) {
					InsuredSearchResult insuredSearchResult = (InsuredSearchResult) insuredSearchDTO
							.getSearchResults().get(i);
					if (productSelected.equals(Constants.PRODUCT_DENTAL)) {

						insuredSearchResult
							.setPayrollDeductionAmt(calculateDentalPayrollDeductionAmountwithTA(
									insuredSearchResult, insuredServices,
									periodSelected, insuredSearchDTO));
					}
					if (productSelected.equals(Constants.PRODUCT_VISION)) {
						insuredSearchResult
							.setPayrollDeductionAmt(calculateVisionPayrollDeductionAmountwithTA(
									insuredSearchResult, insuredServices,
									periodSelected, insuredSearchDTO));
					}
					if (productSelected.equals(Constants.PRODUCT_LIFE)) {
						insuredSearchResult
								.setPayrollDeductionAmt(insuredSearchResult
										.getLifePremiumPayPeriod());
					}
					if (productSelected.equals(Constants.PRODUCT_LTD)) {
						insuredSearchResult
								.setPayrollDeductionAmt(insuredSearchResult
										.getLtdPremiumPayPeriod());
					}
					if (productSelected.equals(Constants.PRODUCT_STD)) {
						insuredSearchResult
								.setPayrollDeductionAmt(insuredSearchResult
										.getStdPremiumPayPeriod());
					}
					if (productSelected.equals(Constants.PRODUCT_VOLUNTARY)) {
						insuredSearchResult
								.setPayrollDeductionAmt(insuredSearchResult
										.getTotalPremiumPayPeriod());
					}
				}
			}

			if (resultCount == 0) {
				this.addGlobalRequestMessage(request,
						"errors.insured.search.failed");
				return mapping.getInputForward();
			} else if (resultCount == 1) {
				// If only 1 insured employee is returned, display the 'Insured
				// Employee
				// Details' page
				String idNumber = ((InsuredSearchResult) insuredSearchDTO
						.getSearchResults().get(0)).getIdentificationNumber();
				InsuredSearchAction.log.debug("idNumber is: " + idNumber);
				insuredSearchForm.setSelectedID(idNumber);
				return this.selectEmployee(mapping, insuredSearchForm, request,
						response);
			} else {
				BeanUtils.copyProperties(insuredSearchForm, insuredSearchDTO);
				request.setAttribute("searchForm", insuredSearchForm);

				// Display the Insured Employee List page
				return mapping.findForward("list");
			}
	}

	/**
	 * Performs insured search, sorting by name
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward insuredSearchSortByName(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		InsuredSearchForm insuredSearchForm = (InsuredSearchForm) form;

		int sortOrder = insuredSearchForm.getSortOrder();
		if (sortOrder == InsuredSearchDTO.SORT_BY_NAME_ASCENDING) {
			insuredSearchForm
					.setSortOrder(InsuredSearchDTO.SORT_BY_NAME_DESCENDING);
		} else {
			insuredSearchForm
					.setSortOrder(InsuredSearchDTO.SORT_BY_NAME_ASCENDING);
		}

		return this
				.insuredSearch(mapping, insuredSearchForm, request, response);
	}

	/**
	 * Performs insured search, sorting by identification number
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward insuredSearchSortByNumber(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		InsuredSearchForm insuredSearchForm = (InsuredSearchForm) form;

		int sortOrder = insuredSearchForm.getSortOrder();
		if (sortOrder == InsuredSearchDTO.SORT_BY_NUMBER_ASCENDING) {
			insuredSearchForm
					.setSortOrder(InsuredSearchDTO.SORT_BY_NUMBER_DESCENDING);
		} else {
			insuredSearchForm
					.setSortOrder(InsuredSearchDTO.SORT_BY_NUMBER_ASCENDING);
		}

		return this
				.insuredSearch(mapping, insuredSearchForm, request, response);
	}

	/**
	 * Performs the calculation of the payroll deduction amount depending on the
	 * selections made on the screen.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward calculatePayrollDeduction(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		InsuredSearchForm insuredSearchForm = (InsuredSearchForm) form;
		this.insuredSearch(mapping, insuredSearchForm, request, response);
		insuredSearchForm = (InsuredSearchForm) request
				.getAttribute("searchForm");
		GroupAdminUserDTO user = (GroupAdminUserDTO) request
				.getAttribute(com.bcbssc.registration.common.Constants.USER_DTO);
		PayrollDeductionAmountsDTO pdaDto = new PayrollDeductionAmountsDTO();
		BeanUtils.copyProperties(pdaDto, insuredSearchForm);
		pdaDto.setAccessCode(user.getAccessCode());
		GroupAdminPayrollDeductionAmountsInformHandler gapdaih = new GroupAdminPayrollDeductionAmountsInformHandler(
				CommonUtils.getIniFile(this.getServlet()));
		pdaDto.setUserDTO(user);

		gapdaih.sendCalculatePayrollDeductionInform(pdaDto);
		return this
				.insuredSearch(mapping, insuredSearchForm, request, response);
	}

	/**
	 * Performs the search again for modify to refresh the data
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward refreshModify(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// pass true for refresh
		return this.selectEmployee(mapping, form, request, response, true);
	}

	/**
	 * Processess selection of a particular employee
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward selectEmployee(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// pass false for no refresh
		return this.selectEmployee(mapping, form, request, response, false);
	}

	/**
	 * Internal process to load employee info
	 *
	 * @param user
	 *            the user described by the encrypted cookie
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception
	 *             if the application business logic throws an exception
	 */
	private ActionForward selectEmployee(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response, boolean isRefreshModify)
			throws Exception {


		boolean dentalLargeCertAdded = false;
		boolean dentalCardAdded = false;
		boolean dentlSmallCertAdded = false;
		boolean dentalVoluntaryCertAdded = false;
		boolean largeLifeCertAdded = false;
		boolean smalLifeCertAdded = false;
		boolean voluntaryLifeCertAdded = false;
		boolean lTDLargeCertAdded = false;
		boolean sTDVoluntaryCertAdded = false;
		boolean sTDCertAdded = false;
		boolean visionCertAdded = false;

		InsuredSearchForm insuredSearchForm = (InsuredSearchForm) form;
		InsuredSearchDTO insuredSearchDTO = new InsuredSearchDTO();
		String selectedID = insuredSearchForm.getSelectedID();
		List certificateList = null;
		List dentalCardIdList = null;
		BeanUtils.copyProperties(insuredSearchDTO, insuredSearchForm);
		// LI1240
		String iniFile = CommonUtils.getIniFile(getServlet());
		String fromDaysBack = Config.getPrivateProfileString("MISC",
				"PDF_FROM_DATE_DAYS", "", iniFile);
		if(log.isDebugEnabled()){
			log.debug("Today - From date  = " + fromDaysBack);
		}

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

		Calendar fromDateTemp = Calendar.getInstance();

    	int daysPast = Integer.parseInt(fromDaysBack);

    	fromDateTemp.add(6, -daysPast);

    	String fromDate = formatter.format(fromDateTemp.getTime());
    	if(log.isDebugEnabled()){
    		log.debug("InsuredSearchAction formattedFromDate=" + fromDate);
    		log.debug("InsuredSearchAction toDate=" + insuredSearchForm.getDate());
    	}

    	SimpleDateFormat toDateformatter = new SimpleDateFormat("MM/dd/yyyy");

    	Date toDateTemp = toDateformatter.parse(insuredSearchForm.getDate());

    	String toDate = formatter.format(Long.valueOf(toDateTemp.getTime()));
    	if(log.isDebugEnabled()){
    	log.debug("InsuredSearchAction toDate=" + toDate);
    	}
		InsuredServices insuredServices = new InsuredServices(
				CommonUtils.getIniFile(this.getServlet()),
				CommonUtils.getGcomIniFile(this.getServlet()),
				(GroupAdminUserDTO) request
						.getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
		insuredServices.getEmployee(insuredSearchDTO, selectedID);

		ArrayList coverageItems = insuredSearchDTO.getCoverageItems();
		GroupAdminHelper gHelper = new GroupAdminHelper();
		try{
			if(log.isDebugEnabled()){
				log.debug("InsuredSearchAction selected certid="+insuredSearchDTO.getSelectedID()+" alternateId="+insuredSearchDTO.getAlternateID());
			}

			certificateList = gHelper.getGroupAdminCertificateList(insuredSearchDTO.getGroupNumber(), fromDate, toDate, insuredSearchDTO.getAlternateID());
		}catch (Exception exp){
			log.error("Error getting certificate list");
			exp.printStackTrace();
		}

		try{
        	dentalCardIdList = gHelper.getGroupAdminDentalCardList(insuredSearchDTO.getGroupNumber(), fromDate, toDate, insuredSearchDTO.getAlternateID());
		}catch (Exception exp){
			log.error("Error getting dental card list");
			exp.printStackTrace();
		}

		for (int i = 0; i < coverageItems.size(); i++){

			CoverageItem item = (CoverageItem)coverageItems.get(i);
			String itemName = item.getName();


			if(null != certificateList){
				for(int j = 0; j < certificateList.size(); j++) {
					GroupAdminCorbelDocument cert = (GroupAdminCorbelDocument)certificateList.get(j);
					String desc = cert.getReportIdDesc().toUpperCase();
					if(log.isDebugEnabled()){
						log.debug("InsuredSearchAction report desc=" + desc);
					}
          if ((itemName.indexOf("TAX") == -1) && (item.getAction() == 'S'))
          {
            if ((desc.indexOf("DENTAL LARGE CERTIFICATE") != -1) && (item.getName().indexOf(DENTAL_FILLER+DENTAL_COVERAGE) != -1) && !dentalLargeCertAdded) {
            	item.setReportId(cert.getReportId());
            	dentalLargeCertAdded = true;
            }

            if ((desc.indexOf("DENTAL SMALL CERTIFICATE") != -1) && (item.getName().indexOf(DENTAL_FILLER+DENTAL_COVERAGE) != -1) && !dentlSmallCertAdded) {
                item.setReportId(cert.getReportId());
                dentlSmallCertAdded = true;
              }

            if ((desc.indexOf("DENTAL VOLUNTARY CERTIFICATE") != -1) && (item.getName().indexOf(DENTAL_FILLER+DENTAL_COVERAGE) != -1) && !dentalVoluntaryCertAdded) {
            	item.setReportId(cert.getReportId());
            	dentalVoluntaryCertAdded = true;
             }

            if ((desc.indexOf("LARGE LIFE CERTIFICATE") != -1) && (item.getName().indexOf("LIFE") != -1) && !largeLifeCertAdded ) {

              item.setReportId(cert.getReportId());
              largeLifeCertAdded = true;
            }

            if ((desc.indexOf("SMALL LIFE CERTIFICATE") != -1) && (item.getName().indexOf("LIFE") != -1) && !smalLifeCertAdded) {
            	item.setReportId(cert.getReportId());
            	smalLifeCertAdded =  true;
              }

            if ((desc.indexOf("VOLUNTARY LIFE CERTIFICATE") != -1) && (item.getName().indexOf("LIFE") != -1) && !voluntaryLifeCertAdded) {
            	item.setReportId(cert.getReportId());
            	voluntaryLifeCertAdded = true;
              }

            if ((desc.indexOf("LTD LARGE CERTIFICATE") != -1) && (item.getName().indexOf("LTD") != -1) && !lTDLargeCertAdded) {
            	item.setReportId( cert.getReportId());
            	lTDLargeCertAdded = true;
            }

            if ((desc.indexOf("STD VOLUNTARY CERTIFICATE") != -1) && (item.getName().indexOf("STD") != -1) && !sTDVoluntaryCertAdded) {
            	item.setReportId(cert.getReportId());
            	sTDVoluntaryCertAdded = true;
            }

            if ((desc.indexOf("STD CERTIFICATE") != -1) && (item.getName().indexOf("STD") != -1) && !sTDCertAdded) {
            	item.setReportId(cert.getReportId());
            	sTDCertAdded = true;
              }

            if ((desc.indexOf("VISION CERTIFICATE") != -1) && (item.getName().indexOf("VISION") != -1) && !visionCertAdded) {
               item.setReportId(cert.getReportId());
               visionCertAdded = true;
            }
          }
        }
       }
       if(null != dentalCardIdList){
        for (int k = 0; k < dentalCardIdList.size(); k++) {
          GroupAdminCorbelDocument dentalCard = (GroupAdminCorbelDocument)dentalCardIdList.get(k);
          String desc = dentalCard.getReportIdDesc().toUpperCase();

          if ((desc.indexOf("DENTAL CARD") != -1) && (item.getName().indexOf(DENTAL_FILLER+DENTAL_COVERAGE) != -1) && !dentalCardAdded   && (item.getAction() == 'S')) {
              item.setDentalCardReportId(dentalCard.getReportId());
              dentalCardAdded = true;
          }

        }
       }
      }


		String searchType = insuredSearchForm.getSearchType();
		if (isRefreshModify) {
			// For this special case, ignore the searchType and just forward
			// directly into modify
			ChangeSelectionForm changeSelectionForm = (ChangeSelectionForm) this
					.getForm("changeSelectionForm", "/modifySelectionEntered",
							request);
			BeanUtils.copyProperties(changeSelectionForm, insuredSearchDTO);
			changeSelectionForm.setCurrentPage(InsuredModifyAction.SELECT_PATH);
			request.setAttribute("changeSelectionForm", changeSelectionForm);

						return mapping.findForward("select_path");
		} else if (searchType.equals(InsuredSearchAction.SEARCH_TYPE_TERMINATE)) {
			TerminateForm terminateForm = (TerminateForm) this.getForm(
					"terminateForm", "/terminateDetailsEntered", request);
			BeanUtils.copyProperties(terminateForm, insuredSearchDTO);

			// set default date
			terminateForm.defaultTerminationDate();

			request.setAttribute("terminateForm", terminateForm);
			return mapping.findForward("terminate");
		} else if (searchType.equals(InsuredSearchAction.SEARCH_TYPE_IDCARD)) {
			SpecialRequestForm specialRequestForm = (SpecialRequestForm) this
					.getForm("idCardForm", "/idCardDetailsEntered", request);
			BeanUtils.copyProperties(specialRequestForm, insuredSearchDTO);
			request.setAttribute("idCardForm", specialRequestForm);
			return mapping.findForward("idcard");
		} else {
			if (searchType.equals(InsuredSearchAction.SEARCH_TYPE_MODIFY)) {
				insuredSearchDTO
						.setUserDTO((GroupAdminUserDTO) request
								.getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
				insuredServices.sendInsuredDetailsInform(insuredSearchDTO);
			} else {
				// View
				insuredSearchDTO
						.setUserDTO((GroupAdminUserDTO) request
								.getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
				insuredServices.sendViewInsuredDetailsInform(insuredSearchDTO);
			}
			BeanUtils.copyProperties(insuredSearchForm, insuredSearchDTO);

			request.setAttribute("searchForm", insuredSearchForm);
			return mapping.findForward("view");
		}
	}

	/**
	 * Goes back from the search list page
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward searchListBack(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		InsuredSearchForm insuredSearchForm = (InsuredSearchForm) form;
		insuredSearchForm
				.setUserDTO((GroupAdminUserDTO) request
						.getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
		request.setAttribute("searchForm", insuredSearchForm);
		return mapping.findForward("back");
	}

	/**
	 * Goes back from the search view page
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward searchViewBack(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		ActionForward returnActionForward = null;
		InsuredSearchForm insuredSearchForm = (InsuredSearchForm) form;
		InsuredSearchDTO insuredSearchDTO = new InsuredSearchDTO();
		BeanUtils.copyProperties(insuredSearchDTO, insuredSearchForm);
		insuredSearchForm
				.setUserDTO((GroupAdminUserDTO) request
						.getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
		request.setAttribute("searchForm", insuredSearchForm);
		if (insuredSearchDTO.getSearchResultsCount() <= 1) {
			// Return directly to search criteria page
			returnActionForward = mapping.findForward("criteria");
		} else {
			// Perform search again
			returnActionForward = this.insuredSearch(mapping, form, request,
					response);
		}
		return returnActionForward;
	}

	/**
	 * Restarts the search
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward newSearch(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		InsuredSearchForm insuredSearchForm = (InsuredSearchForm) form;
		return this.displaySearchForm(insuredSearchForm.getSearchType(),
				mapping, form, request, response,
				com.bcbssc.struts.common.Constants.BLANK_STRING);
	}

	/**
	 * Displays the intial search criteria form.
	 *
	 * @param searchType
	 *            the type of search being performed
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @param status
	 *            default status for search to use
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception
	 *             if the application business logic throws an exception
	 */
	private ActionForward displaySearchForm(String searchType,
			ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response, String status) throws Exception {

		InsuredSearchForm insuredSearchForm = (InsuredSearchForm) this.getForm(
				"insuredSearchForm", "/insuredSearch", request);
		insuredSearchForm.setSearchType(searchType);
		boolean isVision = insuredSearchForm.isVisionCovered();
		InsuredSearchAction.log.debug(" The vision coverage is " + isVision);
		insuredSearchForm.setStatus(status);
		insuredSearchForm
				.setUserDTO((GroupAdminUserDTO) request
						.getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
		request.setAttribute("searchForm", insuredSearchForm);
		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}
}
