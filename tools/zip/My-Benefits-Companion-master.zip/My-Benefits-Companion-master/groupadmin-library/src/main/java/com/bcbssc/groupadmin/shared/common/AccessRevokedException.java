/*
 *
 * Created on Sep 6, 2006 
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.common;

import com.bcbssc.netsys.LinkedException;

/**
 * <p>AccessRevokedException class.</p>
 *
 * @author X08E
 * @version $Id: $Id
 */
public class AccessRevokedException extends LinkedException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2349422515340042163L;

	/**
	 * Creates a new instance of AccessRevokedException.
	 */
	public AccessRevokedException() {
		super();
	}

	/**
	 * Creates a new instance of AccessRevokedException with a descriptive
	 * message.
	 *
	 * @param message
	 *            The exception message.
	 */
	public AccessRevokedException(String message) {
		super(message);
	}

	/**
	 * Creates a new instance of AccessRevokedException with a descriptive
	 * message and a root cause.
	 *
	 * @param message
	 *            The exception message.
	 * @param rootCause
	 *            The root cause of this exception.
	 */
	public AccessRevokedException(String message, Throwable rootCause) {
		super(message, rootCause);
	}

	/**
	 * Creates a new instance of AccessRevokedException with the given root
	 * cause.
	 *
	 * @param rootCause
	 *            The root cause of this exception.
	 */
	public AccessRevokedException(Throwable rootCause) {
		super(rootCause);
	}

}
