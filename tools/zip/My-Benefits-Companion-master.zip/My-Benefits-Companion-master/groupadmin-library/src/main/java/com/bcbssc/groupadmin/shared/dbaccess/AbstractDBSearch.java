/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/AbstractDBSearch.java_v  $
 * $Workfile:   AbstractDBSearch.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:00  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/AbstractDBSearch.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:14:00   EN80
 * Initial revision.
 * 
 *    Rev 1.5   Apr 28 2009 10:17:40   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.4   Jan 26 2005 12:01:04   rdq70
 * Added overloaded performSearch() with SQL parameters that takes the collection to populate.
 *
 *    Rev 1.3   Jan 26 2005 10:03:14   rdq70
 * BlueHammur changes.
 *
 *    Rev 1.2   Jan 25 2005 15:45:28   rdq70
 * Added overloaded performSearch() with SQL parameters.
 *
 *    Rev 1.1   Sep 28 2004 16:28:50   rxg97
 * Switched if to while for the search.
 *
 *    Rev 1.0   Sep 28 2004 10:24:14   rxg97
 * Initial revision.
 */

package com.bcbssc.groupadmin.shared.dbaccess;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * Provides a base implementation for database searching for Group
 * Administrator.
 *
 * @author rxg97 (Jonathan Egger)
 * @version $Id: $Id
 */
public abstract class AbstractDBSearch extends DatabaseProxy {
	
	private static final Logger log = Logger.getLogger(AbstractDBSearch.class);
	/**
	 * Creates an <code>AbstractUserSearch</code> and configures it with an
	 * INI file.
	 *
	 * @param iniFile
	 *            file path of the configuration INI file.
	 * @param qualParam
	 *            the name of the qualifier parameter in the INI file.
	 */
	public AbstractDBSearch(String iniFile, String qualParam) {
		super(iniFile, qualParam);
	}

	/**
	 * Performs a row check on an SQL query.
	 *
	 * @param searchSql
	 *            the SQL query to search on.
	 * @return true if a row is found; false otherwise
	 * @throws java.sql.SQLException
	 *             if there is an error with the connection or at any point in
	 *             executing the query and retrieving results.
	 */
	public boolean performCheck(String searchSql) throws SQLException {

		this.checkInit();

		try {
			ResultSet rs = null;
			try {
				rs = this.getResultSet(searchSql);

				if (rs.next()) {
					return true;
				}
			} finally {
				this.cleanUp(rs);
				rs = null;
			}
		} finally {
			this.disconnect();
		}

		return false;
	}

	/**
	 * Performs a generic SQL search.
	 *
	 * @param searchSql
	 *            the SQL query to search on.
	 * @param obj
	 *            the object to populate with database data.
	 * @return an object populated with the search result, or <code>null</code>
	 *         if none was found.
	 * @throws java.sql.SQLException
	 *             if there is an error with the connection or at any point in
	 *             executing the query and retrieving results.
	 */
	public Object performSearch(String searchSql, Object obj)
			throws SQLException {

		Object returnObject = null;
		boolean resultfound = false;

		this.checkInit();

		try {
			ResultSet rs = null;
			try {
				rs = this.getResultSet(searchSql);

				while (rs.next()) {
					resultfound = true;
					this.addSearchItem(rs, obj);
				}

			} finally {
				this.cleanUp(rs);
				rs = null;
			}

		} finally {
			this.disconnect();
		}

		if (resultfound) {
			return obj;
		}
		return returnObject;
	}

	/**
	 * Performs an SQL search with parameters.
	 *
	 * @param searchSql
	 *            the SQL query to search on.
	 * @param params
	 *            an array of search parameters.
	 * @return a collection populated with the search results.
	 * @throws java.sql.SQLException
	 *             if there is an error with the connection or at any point in
	 *             executing the query and retrieving results.
	 */
	public Collection performSearch(String searchSql, String[] params)
			throws SQLException {
		return this.performSearch(searchSql, params, new ArrayList());
	}

	/**
	 * Performs an SQL search with parameters.
	 *
	 * @param searchSql
	 *            the SQL query to search on.
	 * @param params
	 *            an array of search parameters.
	 * @param collection
	 *            the collection to populate.
	 * @return the input collection populated with the search results.
	 * @throws java.sql.SQLException
	 *             if there is an error with the connection or at any point in
	 *             executing the query and retrieving results.
	 */
	public Collection performSearch(String searchSql, String[] params,
			Collection collection) throws SQLException {

		this.checkInit();

		try {
			ResultSet rs = null;
			try {
				rs = this.getResultSet(searchSql, params);
				while (rs.next()) {
					this.addSearchItem(rs, collection);
				}
			} finally {
				this.cleanUp(rs);
				rs = null;
			}

			return collection;

		} finally {
			this.disconnect();
		}
	}

	/**
	 * Adds a search data item to an object.
	 *
	 * @param data
	 *            item returned from the search
	 * @param obj
	 *            data object that will be updated using this item.
	 * @throws java.sql.SQLException
	 *             if an error occurs while accessing the result set.
	 */
	protected abstract void addSearchItem(ResultSet data, Object obj)
			throws SQLException;
}
