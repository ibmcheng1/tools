/*
 * Created on Apr 27, 2005
 *
 * @(#)InsuredSearchForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.forms;

import com.bcbssc.groupadmin.shared.services.EffectiveDateCalculator;
import com.bcbssc.struts.action.ActionSummary;
import com.bcbssc.struts.common.DateBean;
import com.bcbssc.struts.common.FormDate;

import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

/**
 * GroupAdmin Insured Search Form
 *
 * This bean is used to transport insured employee data for a termination.
 *
 * @author Mark Lujan
 * @version $Revision:   1.0  $
 */
public class TerminateForm extends InsuredSearchForm {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /** log4j logger */
    private static Logger log = Logger.getLogger(TerminateForm.class);

    /**
     * Default the change effective date
     */
    public void defaultTerminationDate() {

        // default the change effective date
        DateBean defaultDate = EffectiveDateCalculator
                .getDefaultChangeDate(this.getLastBillDate());

        TerminateForm.log.debug("defaultDate = " + defaultDate.toString());

        // object is mutable
        DateBean terminationDate = this.getTerminationDate();

        // set to the dafult date for a the termination
        terminationDate.setDay(defaultDate.getDay());
        terminationDate.setMonth(defaultDate.getMonth());
        terminationDate.setYear(defaultDate.getYear());
    }

    /**
     * {@inheritDoc}
     *
     * Validates the form using the validator support provided by the parent.
     * Also verifies that the passwords match.
     */
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {

        ActionErrors errors = super.validate(mapping, request);
        String fieldName = "terminationDateFormatted";
        String fieldDesc = "Termination Date";

        // Changes by Thiagu for Production Ticket 0610540225. The Error message
        // is shown
        // based on the Group Billing instead of today. Changed next statement
        // from this.getLastBillDate()
        // to FormDate.today();

        // get the Current sysdate - 90 days
        DateBean minDateDB = EffectiveDateCalculator.getDefaultChangeDate(
                FormDate.today(), -90);

        // get smart date objects that can be compared
        Calendar minDate = FormDate.makeCalendar(minDateDB);
        Calendar termDate = FormDate.makeCalendar(this.getTerminationDate());
        Calendar origEffDate = FormDate.makeCalendar(this
                .getOriginalEffectiveDate());
        try {
            if (termDate.before(origEffDate)) {
                // add error message
                errors.add("SUMMARY", new ActionMessage(
                        "errors.changeEffectiveDate.cert", fieldDesc));
                errors.add(fieldName, new ActionMessage(
                        "errors.changeEffectiveDate.cert", fieldDesc));

            } else if (termDate.before(minDate)) {
                // add error message
                errors.add("SUMMARY", new ActionMessage(
                        "errors.changeEffectiveDate", fieldDesc, "90"));
                errors.add(fieldName, new ActionMessage(
                        "errors.changeEffectiveDate.cert", fieldDesc));
            }
        } catch (Exception e) {
            TerminateForm.log.error(" There is an exception " + e);
        }
        ActionSummary.createSummary(errors);
        return errors;

    }
}
