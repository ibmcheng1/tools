/*
 * @(#)ViewBillForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.forms;

import com.bcbssc.struts.common.FormDate;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.struts.validator.ValidatorForm;

/**
 * <p>ViewBillForm class.</p>
 *
 * @author XR93
 *
 * Container for data needed to view a bill
 * @version $Id: $Id
 */
public class ViewBillForm extends ValidatorForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// user who is viewing the bill
	private String user;

	// url of image server
	private String imageServer;

	// key
	private String groupNumber;

	// date for search
	private String selectedBillDate;

	// date for search formatted for od390 call
	private String formattedBillDate;

	// date for search formatted for od390 call
	private String formattedFromDate;
	
	//Todate add for CX1730
	private String formattedToDate;

	/**
	 * <p>Constructor for ViewBillForm.</p>
	 */
	public ViewBillForm() {
		super();
	}

	/**
	 * <p>Getter for the field <code>groupNumber</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getGroupNumber() {
		return this.groupNumber;
	}

	/**
	 * <p>Setter for the field <code>groupNumber</code>.</p>
	 *
	 * @param string a {@link java.lang.String} object.
	 */
	public void setGroupNumber(String string) {
		this.groupNumber = string;
	}

	/**
	 * <p>Getter for the field <code>selectedBillDate</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getSelectedBillDate() {
		return this.selectedBillDate;
	}

	
	/**
	 * <p>Getter for the field <code>formattedToDate</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getFormattedToDate() {
		
		Calendar toDate = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		this.formattedToDate = formatter.format(toDate.getTime());
		return this.formattedToDate;
	}
	
	
	
	
	
	/**
	 * date formatted as yyyy-mm-yy
	 *
	 * @return Selected Bill Date formatted for OD390
	 */
	public String getFormattedBillDate() {
		return this.formattedBillDate;
	}

	/**
	 * date formatted as yyyy-mm-yy
	 *
	 * @return From Date for search formatted for OD390
	 */
	public String getFormattedFromDate() {
		return this.formattedFromDate;
	}

	/**
	 * <p>Setter for the field <code>selectedBillDate</code>.</p>
	 *
	 * @param string a {@link java.lang.String} object.
	 */
	public void setSelectedBillDate(String string) {
		this.selectedBillDate = string;

		// and reformat
		FormDate dt = FormDate.blank();
		dt.parse(this.selectedBillDate);

		// reformat for image viewinf servlet
		StringBuffer retVal = new StringBuffer(12);
		retVal.append(dt.getYear()).append("-");
		retVal.append(dt.getMonth()).append("-");
		retVal.append(dt.getDay());

		// save formatted date
		this.formattedBillDate = retVal.toString();

		// figure a from date
		Calendar fromDate = Calendar.getInstance();
		fromDate.set(Integer.parseInt(dt.getYear()), Integer.parseInt(dt
				.getMonth()) - 1, Integer.parseInt(dt.getDay()));

		// subtract 1 month to determine a from date
		fromDate.add(Calendar.MONTH, -1);

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		this.formattedFromDate = formatter.format(fromDate.getTime());
	}

	/**
	 * <p>Getter for the field <code>user</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getUser() {
		return this.user;
	}

	/**
	 * <p>Setter for the field <code>user</code>.</p>
	 *
	 * @param string a {@link java.lang.String} object.
	 */
	public void setUser(String string) {
		this.user = string;
	}

	/**
	 * <p>Getter for the field <code>imageServer</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getImageServer() {
		return this.imageServer;
	}

	/**
	 * <p>Setter for the field <code>imageServer</code>.</p>
	 *
	 * @param string a {@link java.lang.String} object.
	 */
	public void setImageServer(String string) {
		this.imageServer = string;
	}

	/**
	 * convenience method to display container data
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String toString() {
		StringBuffer s = new StringBuffer(100);
		s.append("GroupNumber ").append(this.groupNumber).append(",");
		s.append("       Date ").append(this.selectedBillDate);
		return s.toString();
	}

}
