package com.bcbssc.groupadmin.shared.dto;

import com.bcbssc.struts.common.DateBean;

import com.bcbssc.groupadmin.shared.forms.Options;

/**
 * <p>InsuredRequestChangeSearchDTO class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class InsuredRequestChangeSearchDTO extends InsuredSearchDTO {

	  	private String requestType;

	  	private String reasonForRequest;

	    private DateBean reHireDate = new DateBean();

	    private DateBean reqChangeTerminationDate = new DateBean();
	    private DateBean effectiveTerminationDate =new DateBean();
	    private DateBean coverageEffectiveDate = new DateBean();

		private DateBean dependentDOB = new DateBean();

	    private String chooseDependent;

	    private String chooseTerminateDependent;

	    private String dependentLastName;

	    private String dependentGivenName;

	    private String dependentMiddleIni;

	    private String dependentSSN;

	    private String dependentGender;

	    private String dependentRelation;

	    private String dependentIsStudent;

		/**
		 * <p>Getter for the field <code>requestType</code>.</p>
		 *
		 * @return the requestType
		 */
		public String getRequestType() {
			return requestType;
		}

		/**
		 * <p>Setter for the field <code>requestType</code>.</p>
		 *
		 * @param requestType the requestType to set
		 */
		public void setRequestType(String requestType) {
			this.requestType = requestType;
		}

		/**
		 * <p>Getter for the field <code>reasonForRequest</code>.</p>
		 *
		 * @return the reasonForRequest
		 */
		public String getReasonForRequest() {
			return reasonForRequest;
		}

		/**
		 * <p>Setter for the field <code>reasonForRequest</code>.</p>
		 *
		 * @param reasonForRequest the reasonForRequest to set
		 */
		public void setReasonForRequest(String reasonForRequest) {
			this.reasonForRequest = reasonForRequest;
		}

		/**
		 * <p>Getter for the field <code>reHireDate</code>.</p>
		 *
		 * @return the reHireDate
		 */
		public DateBean getReHireDate() {
			return reHireDate;
		}

		/**
		 * <p>Setter for the field <code>reHireDate</code>.</p>
		 *
		 * @param reHireDate the reHireDate to set
		 */
		public void setReHireDate(DateBean reHireDate) {
			this.reHireDate = reHireDate;
		}

		/**
		 * <p>Getter for the field <code>dependentDOB</code>.</p>
		 *
		 * @return the dependentDOB
		 */
		public DateBean getDependentDOB() {
			return dependentDOB;
		}

		/**
		 * <p>Setter for the field <code>dependentDOB</code>.</p>
		 *
		 * @param dependentDOB the dependentDOB to set
		 */
		public void setDependentDOB(DateBean dependentDOB) {
			this.dependentDOB = dependentDOB;
		}

		/**
		 * <p>Getter for the field <code>chooseDependent</code>.</p>
		 *
		 * @return the chooseDependent
		 */
		public String getChooseDependent() {
			return chooseDependent;
		}

		/**
		 * <p>Setter for the field <code>chooseDependent</code>.</p>
		 *
		 * @param chooseDependent the chooseDependent to set
		 */
		public void setChooseDependent(String chooseDependent) {
			this.chooseDependent = chooseDependent;
		}

		/**
		 * <p>Getter for the field <code>chooseTerminateDependent</code>.</p>
		 *
		 * @return the chooseTerminateDependent
		 */
		public String getChooseTerminateDependent() {
			return chooseTerminateDependent;
		}

		/**
		 * <p>Setter for the field <code>chooseTerminateDependent</code>.</p>
		 *
		 * @param chooseTerminateDependent the chooseTerminateDependent to set
		 */
		public void setChooseTerminateDependent(String chooseTerminateDependent) {
			this.chooseTerminateDependent = chooseTerminateDependent;
		}

		/**
		 * <p>Getter for the field <code>dependentLastName</code>.</p>
		 *
		 * @return the dependentLastName
		 */
		public String getDependentLastName() {
			return dependentLastName;
		}

		/**
		 * <p>Setter for the field <code>dependentLastName</code>.</p>
		 *
		 * @param dependentLastName the dependentLastName to set
		 */
		public void setDependentLastName(String dependentLastName) {
			this.dependentLastName = dependentLastName;
		}

		/**
		 * <p>Getter for the field <code>dependentGivenName</code>.</p>
		 *
		 * @return the dependentGivenName
		 */
		public String getDependentGivenName() {
			return dependentGivenName;
		}

		/**
		 * <p>Setter for the field <code>dependentGivenName</code>.</p>
		 *
		 * @param dependentGivenName the dependentGivenName to set
		 */
		public void setDependentGivenName(String dependentGivenName) {
			this.dependentGivenName = dependentGivenName;
		}

		/**
		 * <p>Getter for the field <code>dependentMiddleIni</code>.</p>
		 *
		 * @return the dependentMiddleIni
		 */
		public String getDependentMiddleIni() {
			return dependentMiddleIni;
		}

		/**
		 * <p>Setter for the field <code>dependentMiddleIni</code>.</p>
		 *
		 * @param dependentMiddleIni the dependentMiddleIni to set
		 */
		public void setDependentMiddleIni(String dependentMiddleIni) {
			this.dependentMiddleIni = dependentMiddleIni;
		}

		/**
		 * <p>Getter for the field <code>dependentSSN</code>.</p>
		 *
		 * @return the dependentSSN
		 */
		public String getDependentSSN() {
			return dependentSSN;
		}

		/**
		 * <p>Setter for the field <code>dependentSSN</code>.</p>
		 *
		 * @param dependentSSN the dependentSSN to set
		 */
		public void setDependentSSN(String dependentSSN) {
			this.dependentSSN = dependentSSN;
		}

		/**
		 * <p>Getter for the field <code>dependentGender</code>.</p>
		 *
		 * @return the dependentGender
		 */
		public String getDependentGender() {
			return dependentGender;
		}

		/**
		 * <p>Setter for the field <code>dependentGender</code>.</p>
		 *
		 * @param dependentGender the dependentGender to set
		 */
		public void setDependentGender(String dependentGender) {
			this.dependentGender = dependentGender;
		}

		/**
		 * <p>Getter for the field <code>dependentRelation</code>.</p>
		 *
		 * @return the dependentRelation
		 */
		public String getDependentRelation() {
			return dependentRelation;
		}

		/**
		 * <p>Setter for the field <code>dependentRelation</code>.</p>
		 *
		 * @param dependentRelation the dependentRelation to set
		 */
		public void setDependentRelation(String dependentRelation) {
			this.dependentRelation = dependentRelation;
		}

		/**
		 * <p>Getter for the field <code>dependentIsStudent</code>.</p>
		 *
		 * @return the dependentIsStudent
		 */
		public String getDependentIsStudent() {
			return dependentIsStudent;
		}

		/**
		 * <p>Setter for the field <code>dependentIsStudent</code>.</p>
		 *
		 * @param dependentIsStudent the dependentIsStudent to set
		 */
		public void setDependentIsStudent(String dependentIsStudent) {
			this.dependentIsStudent = dependentIsStudent;
		}

		/**
		 * <p>getFormattedRequestType.</p>
		 *
		 * @return a {@link java.lang.String} object.
		 */
		public String getFormattedRequestType(){

			return Options.getLabelFromValue(Options.getGroupAdminInstance().getRequestaChangeOptions(), this.requestType);

		}

		/**
		 * <p>getFormattedDependentRelation.</p>
		 *
		 * @return a {@link java.lang.String} object.
		 */
		public String getFormattedDependentRelation(){

			return Options.getLabelFromValue(Options.getGroupAdminInstance().getRelationshipOptions(), this.dependentRelation);

		}

		/**
		 * <p>getFormattedDependetIsStudent.</p>
		 *
		 * @return a {@link java.lang.String} object.
		 */
		public String getFormattedDependetIsStudent(){

			return Options.getLabelFromValue(Options.getGroupAdminInstance().getPleaseChooseOneNoYesOptions(),this.dependentIsStudent);

		}

		/**
		 * <p>Getter for the field <code>reqChangeTerminationDate</code>.</p>
		 *
		 * @return the reqChangeTerminationDate
		 */
		public DateBean getReqChangeTerminationDate() {
			return reqChangeTerminationDate;
		}
		/**
		 * <p>Setter for the field <code>reqChangeTerminationDate</code>.</p>
		 *
		 * @param reqChangeTerminationDate the reqChangeTerminationDate to set
		 */
		public void setReqChangeTerminationDate(DateBean reqChangeTerminationDate) {
			this.reqChangeTerminationDate = reqChangeTerminationDate;
		}
		/**
		 * <p>Getter for the field <code>effectiveTerminationDate</code>.</p>
		 *
		 * @return the effectiveTerminationDate
		 */
		public DateBean getEffectiveTerminationDate() {
			return effectiveTerminationDate;
		}
		/**
		 * <p>Setter for the field <code>effectiveTerminationDate</code>.</p>
		 *
		 * @param value a {@link com.bcbssc.struts.common.DateBean} object.
		 */
		public void setEffectiveTerminationDate(DateBean value) {
			this.effectiveTerminationDate = value;
		}
		/**
		 * <p>Getter for the field <code>coverageEffectiveDate</code>.</p>
		 *
		 * @return the reqChangeDepCovEffectiveDate
		 */
		public DateBean getCoverageEffectiveDate() {
			return coverageEffectiveDate;
		}
		/**
		 * <p>Setter for the field <code>coverageEffectiveDate</code>.</p>
		 *
		 * @param value a {@link com.bcbssc.struts.common.DateBean} object.
		 */
		public void setCoverageEffectiveDate(
				DateBean value) {
			this.coverageEffectiveDate = value;
	}

}
