/*
 * @(#)CommonInformUtils.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.mq;

import javax.jms.JMSException;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.netsys.inform.AbstractInformMessage;
import com.bcbssc.netsys.inform.InformException;
import com.bcbssc.netsys.inform.InformMessenger;
import com.bcbssc.netsys.inform.InformTransaction;

/**
 * Common INFORm Utilities
 *
 * This class provides a container for inform-related utility methods.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.1  $
 */
public class CommonInformUtils {
	
	//Informmessage unexpiration length
    private static final Long INFORM_UNEXPIRATION_LENGTH = new Long(0L);

	/**
	 * The log4j <CODE>Logger</CODE> for this class.
	 */
	private static final Logger log = Logger.getLogger(CommonInformUtils.class);
	/**
	 * Sends an MQ message, logging on failure or if debug is enabled.
	 *
	 * @param gaim
	 *            message to send
	 * @param messageType
	 *            type of message, corresponding to INI file DESTINATIONS entry
	 * @param iniFile
	 *            INI file containing the JMS and DESTINATIONS sections
	 */
	public static void sendMessage(AbstractInformMessage gaim,
			String messageType, String iniFile) {
		if (CommonInformUtils.log.isDebugEnabled()) {
			CommonInformUtils.log.debug("Inform message layout: "
					+ gaim.toString());

			String informMessage = "";
			try {
				informMessage = gaim.getMessage();
			} catch (com.bcbssc.netsys.ConfigurationException cex) {
				CommonInformUtils.log.error(
						"A configuration error occured during message build",
						cex);
			}

			CommonInformUtils.log.debug("Sending INFOrm:" + informMessage);
		}

		InformTransaction informTransaction = new InformTransaction(iniFile,
				messageType);
		InformMessenger messenger = null;
		
		try {
			messenger = new InformMessenger(new InitialContext(),Constants.CONNECTION_FACTORY);
			messenger.setJndiMode(true);
			messenger.setInformDestinationName(Constants.INFORM_QUEUE);
			informTransaction.setInformMessenger(messenger);
			informTransaction.sendInformMessage(gaim, INFORM_UNEXPIRATION_LENGTH);
		}catch (NamingException e) {
			CommonInformUtils.log.error("NamingException trying to create InformMessenger with connectionFactory:"+Constants.CONNECTION_FACTORY);
		}catch (JMSException e) {
			CommonInformUtils.log.error("JMSException trying to create InformMessenger with connectionFactory:"+Constants.CONNECTION_FACTORY);
		}catch (InformException iex) {

			CommonInformUtils.log.error("An error occured during send", iex);

			if (!CommonInformUtils.log.isDebugEnabled()) {
				// If debug isn't enabled, we didn't write the message to the
				// log file. Since the send failed, do so now as an error
				CommonInformUtils.log.error("Failed Inform message layout: "
						+ gaim.toString());

				String informMessage = "";
				try {
					informMessage = gaim.getMessage();
				} catch (com.bcbssc.netsys.ConfigurationException cex) {
					CommonInformUtils.log
							.error(
									"A configuration error occured during message build",
									cex);
				}

				CommonInformUtils.log.error("Failed Inform message: "
						+ informMessage);
			}

		}
		if (CommonInformUtils.log.isDebugEnabled()) {
			CommonInformUtils.log.debug("Done.");
		}
	}
}
