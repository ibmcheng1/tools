/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/QualifiedCoveragesQuery.java_v  $
 * $Workfile:   QualifiedCoveragesQuery.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:22  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/QualifiedCoveragesQuery.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:14:22   EN80
 * Initial revision.
 * 
 *    Rev 1.18   Apr 28 2009 10:18:10   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.17   Oct 10 2007 21:09:18   rx29e
 * 20 Day Waiting period changes. Configurable waiting period codes based on the calculation category.
 * 
 *    Rev 1.16   May 16 2006 16:33:10   rx08e
 * Changed to include the vision coverages to be retrieved.
 *
 *    Rev 1.15   Apr 27 2006 10:26:40   rx08e
 * Changes to not get the vision information. This would be removed once the vision changes are implemented.
 *
 *    Rev 1.14   Apr 11 2006 14:45:26   r8981
 * C09312 - 0610152874
 * correct waiting period code that generates the coverage effective date for groupadmin
 *
 *    Rev 1.13   Oct 20 2005 13:42:20   rcf57
 * C03785 : Added additional logging.
 *
 *    Rev 1.12   Apr 29 2005 17:20:34   rxr93
 * check groupBaseUnit when validate volume
 *
 *    Rev 1.11   Apr 20 2005 14:19:38   rxr93
 * revert back to CoverageItem class
 *
 *    Rev 1.10   Apr 18 2005 10:18:36   rxr93
 * moved add coverage logic from CoverageItem to AddCoverageItem
 *
 *    Rev 1.9   Mar 02 2005 14:42:52   rxr93
 * padd wait period to 3
 *
 *    Rev 1.8   Feb 18 2005 12:24:12   rdq70
 * Moved Original Effective Date into GroupQuery.
 *
 *    Rev 1.7   Feb 11 2005 09:23:18   rdq70
 * Added dental premium.
 *
 *    Rev 1.6   Feb 10 2005 16:03:58   rdq70
 * Shift percent salary 4 places instead of 2 since it has 4 decimals in the database and in the MQ.
 *
 *    Rev 1.5   Feb 04 2005 16:45:02   rdq70
 * Reduced SQL whitespace.
 *
 *    Rev 1.4   Feb 03 2005 13:30:22   rdq70
 * Javadoc correction.
 *
 *    Rev 1.3   Feb 03 2005 10:49:52   rdq70
 * Renamed MQ_TABLE to GCOM_TABLE.
 *
 *    Rev 1.2   Feb 02 2005 14:31:38   rdq70
 * Changed floats to doubles.
 *
 *    Rev 1.1   Feb 02 2005 10:05:12   rdq70
 * Improved Javadocs.
 *
 *    Rev 1.0   Feb 02 2005 09:55:10   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.dbaccess;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.dto.CoverageItem;
import com.bcbssc.groupadmin.shared.dto.CoverageItemList;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

import org.apache.log4j.Logger;

/**
 * This query creates the list of coverages a new certificate is qualified for.
 * <br>
 *
 * <pre>
 *     QMF NAME: RX13U.WEB_SQL_3_B
 *     TSO NAME: WEBSQL3B
 * </pre>
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class QualifiedCoveragesQuery extends AbstractDBSearch {

	/** The log4j logger for this class. */
	private static final Logger log = Logger
			.getLogger(QualifiedCoveragesQuery.class);

	/**
	 * Creates an <code>QualifiedCoveragesQuery</code> and configures it with
	 * an INI file.
	 *
	 * @param iniFile
	 *            file path of the configuration INI file.
	 */
	public QualifiedCoveragesQuery(String iniFile) {
		super(iniFile, "GCOM_TABLE");
	}

	/**
	 * Creates the list of coverages a new certificate is qualified for and adds
	 * them to the given parent bean.<br>
	 *
	 * <pre>
	 *     QMF NAME: RX13U.WEB_SQL_3_B
	 *     TSO NAME: WEBSQL3B
	 * </pre>
	 *
	 * @param insuredData
	 *            the bean containing data for the search. It needs only the
	 *            groupNumber and coverageClass properties set.
	 * @return the <code>CoverageItemList</code> of the the given
	 *         <code>insuredData</code> populated with the search results.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 * @see com.bcbssc.groupadmin.shared.dto.CoverageItemList
	 */
	public Collection performSearch(InsuredDataDTO insuredData)
			throws SQLException {
		this.checkInit(); // Necessary since we need the _dbSchema before the
							// query creation

		final String division = insuredData.getDivisionCode();
		final StringBuffer sql = new StringBuffer(2000);

		sql
				.append(
						"SELECT A.COV_CODE"
								+ "     , C.CVG_DESC"
								+ "     , A.VOLM_FCTR"
								+ "     , A.FLAT_UNIT_VOLM"
								+ "     , A.MIN_VOLM"
								+ "     , A.MAX_VOLM"
								+ "     , E.WAIT_PERIOD_DAYS"
								+ "     , E.WAIT_PERIOD_CALC_C"
								+ "     , CHAR(A.COV_EFF_DATE,USA) \"COV EFF DATE\""
								+ "     , A.EMPLR_PER_INSUR"
								+ "     , A.SUBSTD_FCTR"
								+ "     , A.VOLM_BAS_CD"
								+ "     , A.NO_EVDNC_MAX_VOLM"
								+ "     , A.RNDG_CNTL_CD"
								+ "     , A.RNDG_VOLM_AMT"
								+ "     , A.WAIT_PERD"
								+ "     , A.WAIT_PERD_CD"
								+ "     , A.FRST_DAY_MTH"
								+ "     , C.ALLW_PARTICP"
								+ "     , C.UNIT_FCTR" + "     , C.BASE_UNIT"
								+ "     , C.LOB_CD" + "     , C.CVG_TYP"
								+ "     , A.AVG_RTE_INSRD" + " FROM ")
				.append(this._dbSchema)
				.append(".VPLCYCVZ A" + "    , ")
				.append(this._dbSchema)
				.append(".VPLCYGRZ B" + "    , ")
				.append(this._dbSchema)
				.append(".VRTVCVGZ C" + "    , ")
				.append(this._dbSchema)
				.append(".VPLCYDVZ D" + "    , ")
				.append(this._dbSchema)
				.append(
						".VWAITPDZ E"
								+ " WHERE A.COMP_CD = ?"
								+ "   AND A.COMP_CD = B.COMP_CD"
								+ "   AND B.COMP_CD = D.COMP_CD"
								+ "   AND A.GRP_PRFX = ?"
								+ "   AND A.GRP_PRFX = B.GRP_PRFX"
								+ "   AND B.GRP_PRFX = D.GRP_PRFX"
								+ "   AND A.GRP_BASE = ?"
								+ "   AND A.GRP_BASE = B.GRP_BASE"
								+ "   AND B.GRP_BASE = D.GRP_BASE"
								+ "   AND A.DIV_CODE = CASE WHEN B.DIV_LVL_CD = '5'"
								+ "                         THEN '")
				.append(division)
				.append(
						"'"
								+ "                         ELSE ' ' END"
								+ "   AND D.DIV_CODE = ?"
								+ "   AND A.CLAS_CODE = ?"
								+ "   AND A.COV_CODE = (C.CVG||C.SUB_CVG)"
								+ "   AND A.WAIT_PERD = DEC(E.WAIT_PERIOD_CODE)");

		final String[] params = { insuredData.getCompany(),
				insuredData.getGroupPrefix(), insuredData.getGroupBase(),
				division, insuredData.getCoverageClass().getCode() };

		return this.performSearch(sql.toString(), params, insuredData
				.getCoverageItems());
	}

	/**
	 * {@inheritDoc}
	 *
	 * Adds data from the given result set to the target collection.
	 * @see com.bcbssc.groupadmin.shared.dto.CoverageItemList
	 */
	protected void addSearchItem(ResultSet data, Object obj)
			throws SQLException {
		final CoverageItemList list = (CoverageItemList) obj;
		final CoverageItem item = new CoverageItem(list.getInsuredDatasource());

		item.setCode(data.getString("COV_CODE").trim());
		item.setName(data.getString("CVG_DESC").trim());
		item.setPercentSalary(data.getBigDecimal("VOLM_FCTR").multiply(
				BigDecimal.valueOf(10000L)).intValue());
		item.setVolume(data.getInt("FLAT_UNIT_VOLM"));
		item.setMinimumVolume(data.getInt("MIN_VOLM"));
		item.setMaximumVolume(data.getInt("MAX_VOLM"));
		item.setWaitingPeriod(Integer.parseInt(data.getString(
				"WAIT_PERIOD_DAYS").trim()));

		item.setWaitPeriodCalculationCategory(data.getString(
				"WAIT_PERIOD_CALC_C").trim());

		if (QualifiedCoveragesQuery.log.isDebugEnabled()) {
			QualifiedCoveragesQuery.log
					.debug("addSearchItem() - waiting period value in coverage item"
							+ item.getWaitingPeriod());
		}
		item.setEffectiveDateFormatted(data.getString("COV EFF DATE"));
		if (QualifiedCoveragesQuery.log.isDebugEnabled()) {
			QualifiedCoveragesQuery.log
					.debug("addSearchItem() - formatted Effective date in coverage item"
							+ item.getEffectiveDateFormatted());
		}
		item.setEmployerPercentInsurance(data.getBigDecimal("EMPLR_PER_INSUR")
				.multiply(BigDecimal.valueOf(100L)).intValue());
		item.setSubstandardFactor(data.getBigDecimal("SUBSTD_FCTR")
				.doubleValue());
		item.setVolumeBasis(Integer.parseInt(data.getString("VOLM_BAS_CD")));
		item.setNoEvidenceMaxVolume(data.getInt("NO_EVDNC_MAX_VOLM"));
		item.setRoundCode(data.getString("RNDG_CNTL_CD"));
		item.setRoundVolume(data.getInt("RNDG_VOLM_AMT"));
		item.setWaitingPeriodForMq(data.getInt("WAIT_PERD"));
		item.setWaitingPeriodCode(CommonUtils.padValue(data
				.getString("WAIT_PERD"), '0', 3));
		item.setWaitingPeriodDay(data.getString("FRST_DAY_MTH"));
		item.setRelationshipType(data.getString("ALLW_PARTICP"));
		item.setUnitFactor(data.getInt("UNIT_FCTR"));
		item.setBaseUnit(data.getBigDecimal("BASE_UNIT").doubleValue());
		item.setGroupBaseUnit(item.getVolume());
		item.setLineOfBusiness(data.getString("LOB_CD").trim());
		item.setType(data.getString("CVG_TYP").trim());
		item.setPremium(data.getBigDecimal("AVG_RTE_INSRD").multiply(
				BigDecimal.valueOf(10000L)).intValue());

		list.add(item);
	}
}
