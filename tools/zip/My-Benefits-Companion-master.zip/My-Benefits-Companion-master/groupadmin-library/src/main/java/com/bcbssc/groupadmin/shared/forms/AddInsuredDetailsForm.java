/*
 * @(#)AddInsuredDetailsForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.forms;

import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import com.bcbssc.groupadmin.shared.dto.Dependent;
import com.bcbssc.struts.common.Constants;
import com.bcbssc.struts.common.FormDate;

/**
 * GroupAdmin Add Insured Details Form
 *
 * This bean extends the insured details form by providing an add-specific clear
 * method.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class AddInsuredDetailsForm extends InsuredDetailsForm {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /**
     * Group Changes indicator
     */
    private boolean groupChanged;

    /**
     * Clears the user-editable data fields for this form
     */
    public void clear() {
        this.setGroup(this.getDefaultGroupOption());
        this.givenName = Constants.BLANK_STRING;
        this.lastName = Constants.BLANK_STRING;
        this.middleIni = Constants.BLANK_STRING;
        this.dateOfBirth = new FormDate();
        this.hireDate = new FormDate();
        this.identificationNumber = Constants.BLANK_STRING;
        this.gender = Constants.BLANK_STRING;
        this.setSsn(Constants.BLANK_STRING);
        this.addressLine1 = Constants.BLANK_STRING;
        this.addressLine2 = Constants.BLANK_STRING;
        this.city = Constants.BLANK_STRING;
        this.state = Constants.BLANK_STRING;
        this.zip = Constants.BLANK_STRING;
        this.department = Constants.BLANK_STRING;
        this.payrollOfficeIdentifier = Constants.BLANK_STRING;
        this.occupation = Constants.BLANK_STRING;
        this.cobra = Constants.BLANK_STRING;
        this.smoker = Constants.BLANK_STRING;
        this.setSpouse(new Dependent());
        this.dentalCoverageStr = Constants.BLANK_STRING;
        this.visionCoverageStr = Constants.BLANK_STRING;
    }

    /**
     * Getter for property groupChanged
     *
     * @return value of property groupChanged.
     */
    public boolean getGroupChanged() {
        return this.groupChanged;
    }

    /**
     * Setter for property groupChanged
     *
     * @param b a boolean.
     */
    public void setGroupChanged(boolean b) {
        this.groupChanged = b;
    }

    /**
     * {@inheritDoc}
     *
     * Validates the form.
     */
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {
        ActionErrors errors = super.validate(mapping, request);

        // check for zip error already recorded
        Iterator zipMessages = errors.get("zip");
        boolean zipError = zipMessages.hasNext();

        if (!zipError) {
            if (((this.getZip().length() > 0) && (this.getZip().length() < 5))
                    || ((this.getZip().length() > 5) && (this.getZip().length() < 9))) {
                errors
                        .add("zip", new ActionMessage(
                                "error.addGroup.zip.numeric"));
            }
        }

        // check for dental radio button error already recorded
        Iterator dentalMessages = errors.get("dentalRadio");
        boolean dentalError = dentalMessages.hasNext();

        if (!dentalError) {
            if (this.getDentalCoverageStr() == null) {
                dentalError = true;
            }
        }

        // check for vision radio button error already recorded
        Iterator visionMessages = errors.get("visionRadio");
        boolean visionError = visionMessages.hasNext();

        if (!visionError) {
            if (this.getVisionCoverageStr() == null) {
                visionError = true;
            }
        }

        if (dentalError && visionError) {
            errors.add("dentalRadio", new ActionMessage(
                    "error.addGroup.dentalRadio.required"));
            errors.add("visionRadio", new ActionMessage(
                    "error.addGroup.visionRadio.empty"));
        } else if (!dentalError && visionError) {
            errors.add("visionRadio", new ActionMessage(
                    "error.addGroup.visionRadio.required"));
        } else if (dentalError && !visionError) {
            errors.add("dentalRadio", new ActionMessage(
                    "error.addGroup.dentalRadio.required"));
        }

        return errors;
    }

}
