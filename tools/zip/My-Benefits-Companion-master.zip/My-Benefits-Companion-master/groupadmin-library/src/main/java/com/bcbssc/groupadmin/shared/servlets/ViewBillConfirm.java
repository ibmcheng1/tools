/*
 *
 * @(#)ViewBillConfirm.java
 *
 * Copyright Notice 2005 Blue Cross Blue Shield.
 * All rights reserved.
 *
 * This material is the confidential, proprietary and trade secret product
 * of Bluecross Blueshield Of South Carolina. Any unauthorized use,
 * reproduction or transfer of these materials is strictly prohibited.
 *
 * This Servlet is responsible for creating a closed inform to signify that 
 * a bill has been viewed.
 * 
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/servlets/ViewBillConfirm.java_v  $
 * $Workfile:   ViewBillConfirm.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:16:38  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/servlets/ViewBillConfirm.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:16:38   EN80
 * Initial revision.
 * 
 *    Rev 1.1   Apr 28 2009 10:20:54   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.0   Mar 17 2005 17:29:14   rxr93
 * Initial revision.
 *   
 */
package com.bcbssc.groupadmin.shared.servlets;

import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.groupadmin.shared.forms.BillHistoryForm;
import com.bcbssc.groupadmin.shared.mq.InformFactory;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * <p>ViewBillConfirm class.</p>
 *
 * @author XR93
 *
 * Create a closed inform (this servlet is invoked after a bill is viewed)
 * @version $Id: $Id
 */
public class ViewBillConfirm extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5102791699538059206L;

	private static Logger logger = Logger.getLogger(ViewBillConfirm.class);

	/**
	 * {@inheritDoc}
	 *
	 * Initializes the servlet.
	 */
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
	}

	/**
	 * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
	 * methods.
	 *
	 * @param request
	 *            servlet request
	 * @param response
	 *            servlet response
	 * @throws java.io.IOException if any.
	 */
	protected void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws java.io.IOException {

		String iniFile = this.getServletConfig().getInitParameter("INI_FILE");
		if (iniFile == null) {
			this.generateOutput(response, "INI_FILE not found");
		} else {
			// create a form to hold our data
			BillHistoryForm billForm = new BillHistoryForm();

			// set data from the servlet request
			String groupNumber = request.getParameter("groupNumber");
			String userAccessCode = request.getParameter("user");
			String billDate = request.getParameter("selectedBillDate");

			ViewBillConfirm.logger.debug("user = " + userAccessCode);
			ViewBillConfirm.logger.debug("group = " + groupNumber);
			ViewBillConfirm.logger.debug("billDate = " + billDate);

			GroupAdminUserDTO user = new GroupAdminUserDTO();
			user.setAccessCode(userAccessCode);

			billForm.setGroupNumber(groupNumber);
			billForm.setSelectedBillDate(billDate);

			ViewBillConfirm.logger.debug("send inform");
			InformFactory.sendBillImage(iniFile, user, billForm);

			StringBuffer sb = new StringBuffer(100);
			sb.append("group ").append(groupNumber).append("<br>");
			sb.append("user ").append(userAccessCode).append("<br>");
			sb.append("billDate ").append(billDate).append("<br>");

			this.generateOutput(response, "inform sent <br><br>"
					+ sb.toString());
		}
	}

	/**
	 * generate output to the return page
	 * 
	 * @param response
	 * @param outputStr
	 * @throws IOException
	 */
	private void generateOutput(HttpServletResponse response, String outputStr)
			throws IOException {
		// generate some output
		OutputStream out = response.getOutputStream();
		PrintStream ps = new PrintStream(out);

		ps.println(outputStr);
		out.close();

	}

	/**
	 * {@inheritDoc}
	 *
	 * Handles the HTTP <code>GET</code> method.
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws java.io.IOException {
		this.processRequest(request, response);
	}

	/**
	 * {@inheritDoc}
	 *
	 * Handles the HTTP <code>POST</code> method.
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws java.io.IOException {
		this.processRequest(request, response);
	}

}
