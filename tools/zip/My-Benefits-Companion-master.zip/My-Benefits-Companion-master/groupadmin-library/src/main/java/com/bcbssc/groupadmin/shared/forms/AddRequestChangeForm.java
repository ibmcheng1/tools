/*
 * @(#)DependentForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.forms;


/**
 * <p>AddRequestChangeForm class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class AddRequestChangeForm extends InsuredDetailsForm {

 private String reasonForRequest;


    private static final long serialVersionUID = 1L;

    /**
     * Clears the user-editable data fields for this form
     */
    public void clear() {
        // Resets page back to one blank dependent
        this.reasonForRequest="";

    }


	/**
	 * <p>Setter for the field <code>reasonForRequest</code>.</p>
	 *
	 * @param value a {@link java.lang.String} object.
	 */
	public void setReasonForRequest(String value){

		this.reasonForRequest = value;
	}


	/**
	 * <p>Getter for the field <code>reasonForRequest</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getReasonForRequest(){

		return this.reasonForRequest;
	}


}
