/*
 * @(#)GroupAdminTechnicalHelpInformHeader.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.mq;

import com.bcbssc.netsys.inform.InformHeader;

/**
 * Extends the InformHeader class with a few properties needed for the technical
 * help INFOrm
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class GroupAdminTechnicalHelpInformHeader extends InformHeader {

	/**
	 * severity code
	 */
	private String severityCode = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * cat code
	 */
	private String catCode = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Sets the severity code
	 *
	 * @param value
	 *            severity code
	 */
	public void setSeverityCode(String value) {
		this.severityCode = value;
	}

	/**
	 * Gets the severity code
	 *
	 * @return severity code
	 */
	public String getSeverityCode() {
		return this.severityCode;
	}

	/**
	 * Sets the cat code
	 *
	 * @param value
	 *            cat code
	 */
	public void setCatCode(String value) {
		this.catCode = value;
	}

	/**
	 * Gets the cat code
	 *
	 * @return cat code
	 */
	public String getCatCode() {
		return this.catCode;
	}
}
