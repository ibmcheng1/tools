/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
*/
package com.bcbssc.groupadmin.shared.forms;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.util.LabelValueBean;

import com.bcbssc.groupadmin.shared.dto.CoverageItem;
import com.bcbssc.groupadmin.shared.dto.Dependent;
import com.bcbssc.groupadmin.shared.services.EffectiveDateCalculator;
import com.bcbssc.struts.common.DateBean;
import com.bcbssc.struts.common.FormDate;

/**
 * <p>RequestChangeSelectionForm class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class RequestChangeSelectionForm extends InsuredDetailsForm {


    private static final long serialVersionUID = 1L;

    private String requestType;
    private String reasonForRequest;

     /** insured date of hire */
    private FormDate reHireDate = FormDate.blank();
    private FormDate reHireDateFormatted = FormDate.blank();



    private FormDate reqChangeTerminationDate = FormDate.blank();
    private FormDate reqChangeTerminationDateFormatted = FormDate.blank();

    private FormDate effectiveTerminationDate = FormDate.blank();
	private FormDate effectiveTerminationDateFormatted = FormDate.blank();

	private FormDate coverageEffectiveDate = FormDate.blank();
	private FormDate coverageEffectiveDateFormatted = FormDate.blank();


    private FormDate dependentDOB = FormDate.blank();
    private FormDate dependentDOBFormatted = FormDate.blank();
    private Collection dependentOptions;

    private String chooseDependent;

    private String chooseTerminateDependent;

    private String dependentLastName;

    private String dependentGivenName;

    private String dependentMiddleIni;

    private String dependentSSN;

    private String dependentGender;

    private String dependentGenderFormatted;

    private String dependentRelation;

    private String dependentIsStudent;

    /** log4j logger */
    private static final Logger log = Logger
            .getLogger(RequestChangeSelectionForm.class);


    // Employee Termination date
	/**
	 * <p>Getter for the field <code>reqChangeTerminationDateFormatted</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getReqChangeTerminationDateFormatted() {
		if (RequestChangeSelectionForm.log.isDebugEnabled()) {
		RequestChangeSelectionForm.log.debug("RequestChangeSelectionForm(), reqChangeTerminationDate value is"+ this.reqChangeTerminationDate.toString());
		}

		return this.reqChangeTerminationDate.toString();

	}


	/**
	 * <p>Setter for the field <code>reqChangeTerminationDateFormatted</code>.</p>
	 *
	 * @param value a {@link java.lang.String} object.
	 */
	public void setReqChangeTerminationDateFormatted(String value) {
		this.reqChangeTerminationDate.parse(value);
	}



	/**
	 * <p>Setter for the field <code>reqChangeTerminationDate</code>.</p>
	 *
	 * @param value a {@link com.bcbssc.struts.common.FormDate} object.
	 */
	public void setReqChangeTerminationDate(FormDate value){

		this.reqChangeTerminationDate = value;

	}

	/**
	 * <p>Getter for the field <code>reqChangeTerminationDate</code>.</p>
	 *
	 * @return a {@link com.bcbssc.struts.common.FormDate} object.
	 */
	public FormDate getReqChangeTerminationDate(){

		return this.reqChangeTerminationDate;
	}


	/**
	 * <p>defaultReqChangeTerminationDate.</p>
	 */
	public void defaultReqChangeTerminationDate() {

		// default the change effective date
		DateBean defaultDate = EffectiveDateCalculator.getDefaultChangeDate(this.getLastBillDate());

		RequestChangeSelectionForm.log.debug("defaultDate = " + defaultDate.toString());
		// set to the dafult date for a the termination
		this.reqChangeTerminationDate.setDay(defaultDate.getDay());
		this.reqChangeTerminationDate.setMonth(defaultDate.getMonth());
		this.reqChangeTerminationDate.setYear(defaultDate.getYear());
	}



    //Rehire Date
	/**
	 * <p>Getter for the field <code>reHireDateFormatted</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getReHireDateFormatted() {
		if (RequestChangeSelectionForm.log.isDebugEnabled()) {
			RequestChangeSelectionForm.log.debug("RequestChangeSelectionForm(), ReHireDate value is"+ this.reHireDate.toString());
		}

		return this.reHireDate.toString();
	}


	/**
	 * <p>Setter for the field <code>reHireDateFormatted</code>.</p>
	 *
	 * @param value a {@link java.lang.String} object.
	 */
	public void setReHireDateFormatted(String value) {
		this.reHireDate.parse(value);
	}



	/**
	 * <p>Getter for the field <code>reHireDate</code>.</p>
	 *
	 * @return a {@link com.bcbssc.struts.common.FormDate} object.
	 */
	public FormDate getReHireDate() {
		return this.reHireDate;
	}


	/**
	 * <p>Setter for the field <code>reHireDate</code>.</p>
	 *
	 * @param value a {@link com.bcbssc.struts.common.FormDate} object.
	 */
	public void setReHireDate(FormDate value) {
		this.reHireDate = value;
	}


	/**
	 * <p>defaultReHireDate.</p>
	 */
	public void defaultReHireDate(){


		// default the change effective date
		DateBean defaultDate = EffectiveDateCalculator.getDefaultChangeDate(this.getLastBillDate());

		RequestChangeSelectionForm.log.debug("default_date = "+ defaultDate.toString());

		// set to the dafult date for a change
		this.reHireDate.setDay(defaultDate.getDay());
		this.reHireDate.setMonth(defaultDate.getMonth());
		this.reHireDate.setYear(defaultDate.getYear());


	}



	/**
	 * <p>Setter for the field <code>chooseTerminateDependent</code>.</p>
	 *
	 * @param value a {@link java.lang.String} object.
	 */
	public void setChooseTerminateDependent(String value){

		this.chooseTerminateDependent = value;

	}


	/**
	 * <p>Getter for the field <code>chooseTerminateDependent</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getChooseTerminateDependent(){

		return this.chooseTerminateDependent;
	}

    /**
     * <p>Setter for the field <code>requestType</code>.</p>
     *
     * @param reqTyp a {@link java.lang.String} object.
     */
    public void setRequestType(String reqTyp){

		requestType = reqTyp;

	}

	/**
	 * <p>Getter for the field <code>requestType</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getRequestType(){

	    return requestType;

	}

	/**
	 * <p>Setter for the field <code>chooseDependent</code>.</p>
	 *
	 * @param value a {@link java.lang.String} object.
	 */
	public void setChooseDependent(String value){

		this.chooseDependent = value;
	}

	/**
	 * <p>Getter for the field <code>chooseDependent</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getChooseDependent(){

		return this.chooseDependent;
	}


	/**
	 * <p>Setter for the field <code>reasonForRequest</code>.</p>
	 *
	 * @param reaForReq a {@link java.lang.String} object.
	 */
	public void setReasonForRequest(String reaForReq){



		reasonForRequest = reaForReq;


	}


	/**
	 * <p>Getter for the field <code>reasonForRequest</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getReasonForRequest(){

	   return reasonForRequest;

	}





	//Dependent coverage effective date


	/**
	 * <p>Setter for the field <code>coverageEffectiveDate</code>.</p>
	 *
	 * @param value a {@link com.bcbssc.struts.common.FormDate} object.
	 */
	public void setCoverageEffectiveDate(FormDate value){

		this.coverageEffectiveDate = value;

	}

	/**
	 * <p>Getter for the field <code>coverageEffectiveDate</code>.</p>
	 *
	 * @return a {@link com.bcbssc.struts.common.FormDate} object.
	 */
	public FormDate getCoverageEffectiveDate(){

		return this.coverageEffectiveDate;
	}

	/**
	 * <p>defaultCoverageEffectiveDate.</p>
	 */
	public void defaultCoverageEffectiveDate() {

		DateBean defaultDate = EffectiveDateCalculator.getDefaultChangeDate(this.getLastBillDate());

		RequestChangeSelectionForm.log.debug("default_date = "+ defaultDate.toString());

		this.coverageEffectiveDate.setDay(defaultDate.getDay());
		this.coverageEffectiveDate.setMonth(defaultDate.getMonth());
		this.coverageEffectiveDate.setYear(defaultDate.getYear());
	}

	/**
	 * <p>Setter for the field <code>coverageEffectiveDateFormatted</code>.</p>
	 *
	 * @param value a {@link java.lang.String} object.
	 */
	public void setCoverageEffectiveDateFormatted(String value) {
		this.coverageEffectiveDate.parse(value);
	}



	/**
	 * <p>Getter for the field <code>coverageEffectiveDateFormatted</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getCoverageEffectiveDateFormatted() {
		if (RequestChangeSelectionForm.log.isDebugEnabled()) {
		RequestChangeSelectionForm.log.debug("RequestChangeSelectionForm(), coverageEffectiveDate value is"+ this.coverageEffectiveDate.toString());
		}

		return this.coverageEffectiveDate.toString();
	}



	//Dependent termination date



	/**
	 * <p>Setter for the field <code>effectiveTerminationDate</code>.</p>
	 *
	 * @param value a {@link com.bcbssc.struts.common.FormDate} object.
	 */
	public void setEffectiveTerminationDate(FormDate value){

		this.effectiveTerminationDate = value;

	}

	/**
	 * <p>Getter for the field <code>effectiveTerminationDate</code>.</p>
	 *
	 * @return a {@link com.bcbssc.struts.common.FormDate} object.
	 */
	public FormDate getEffectiveTerminationDate(){

		return this.effectiveTerminationDate;
	}


	/**
	 * <p>defaultEffectiveTerminationDate.</p>
	 */
	public void defaultEffectiveTerminationDate() {

		// default the change effective date
		DateBean defaultDate = EffectiveDateCalculator.getDefaultChangeDate(this.getLastBillDate());

		RequestChangeSelectionForm.log.debug("default_date = "+ defaultDate.toString());

		// set to the dafult date for a change
		this.effectiveTerminationDate.setDay(defaultDate.getDay());
		this.effectiveTerminationDate.setMonth(defaultDate.getMonth());
		this.effectiveTerminationDate.setYear(defaultDate.getYear());
	}



	/**
	 * <p>Setter for the field <code>effectiveTerminationDateFormatted</code>.</p>
	 *
	 * @param value a {@link java.lang.String} object.
	 */
	public void setEffectiveTerminationDateFormatted(String value) {
		this.effectiveTerminationDateFormatted.parse(value);
	}



	/**
	 * <p>Getter for the field <code>effectiveTerminationDateFormatted</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getEffectiveTerminationDateFormatted() {
		if (RequestChangeSelectionForm.log.isDebugEnabled()) {
		RequestChangeSelectionForm.log.debug("RequestChangeSelectionForm(), effectiveTerminationDate value is"+ this.effectiveTerminationDate.toString());
		}

		return this.effectiveTerminationDate.toString();
	}





	    /**
	     * Default  change effective date
	     */
	    public void defaultChangeEffectiveDate() {

	        // default the change effective date
	        DateBean defaultDate = EffectiveDateCalculator
	                .getDefaultChangeDate(this.getLastBillDate());

	        RequestChangeSelectionForm.log.debug("default_date = "
	                + defaultDate.toString());

	        // set to the dafult date for a change
	        this.changeEffectiveDate.setDay(defaultDate.getDay());
	        this.changeEffectiveDate.setMonth(defaultDate.getMonth());
	        this.changeEffectiveDate.setYear(defaultDate.getYear());
    }









	/**
	 * <p>Getter for the field <code>dependentOptions</code>.</p>
	 *
	 * @return a {@link java.util.Collection} object.
	 * @throws java.lang.Exception if any.
	 */
	public Collection getDependentOptions() throws Exception {
		ArrayList tempDependentsOptions = new ArrayList();
		tempDependentsOptions.add(new LabelValueBean("-- Please Choose One --", ""));
		ArrayList dependents = (ArrayList)this.getDependents();

		Iterator itr = dependents.iterator();

		while(itr.hasNext()){
			Dependent d = (Dependent)itr.next();
			tempDependentsOptions.add(new LabelValueBean((d.getLastName()+","+d.getGivenName()+"("+d.getDateOfBirthFormatted()+")"), (d.getLastName()+","+d.getGivenName()+","+d.getMiddleIni()+","+d.getSsn()+","+d.getDobMonth()+","+d.getDobDay()+","+d.getDobYear()+","+d.getStudent()+","+d.getRelationship()+","+d.getGender()+","+d.getNameId()+",")));
		}


	   //Get Spouse

	   if(this.getSpouseExists()){


		   Dependent spouse = this.getSpouse();

		   if(StringUtils.isNotBlank(spouse.getLastName())){

		   		tempDependentsOptions.add(new LabelValueBean((spouse.getLastName()+","+spouse.getGivenName()+"("+spouse.getDateOfBirthFormatted()+")"), (spouse.getLastName()+","+spouse.getGivenName()+","+spouse.getMiddleIni()+","+spouse.getSsn()+","+spouse.getDobMonth()+","+spouse.getDobDay()+","+spouse.getDobYear()+","+spouse.getStudent()+","+"SPS"+","+spouse.getGender()+","+spouse.getNameId()+",")));
              if(dependents == null){
	   			dependents = new ArrayList();
			   }
	   			dependents.add(spouse);
	   			this.setDependents(dependents);



	   		}
	   }

			dependentOptions = tempDependentsOptions;
			return this.dependentOptions;
	}

	/**
	 * <p>Getter for the field <code>dependentLastName</code>.</p>
	 *
	 * @return the dependentLastName
	 */
	public String getDependentLastName() {
		return dependentLastName;
	}

	/**
	 * <p>Setter for the field <code>dependentLastName</code>.</p>
	 *
	 * @param dependentLastName the dependentLastName to set
	 */
	public void setDependentLastName(String dependentLastName) {
		this.dependentLastName = dependentLastName;
	}

	/**
	 * <p>Getter for the field <code>dependentGivenName</code>.</p>
	 *
	 * @return the dependentGivenName
	 */
	public String getDependentGivenName() {
		return dependentGivenName;
	}

	/**
	 * <p>Setter for the field <code>dependentGivenName</code>.</p>
	 *
	 * @param dependentGivenName the dependentGivenName to set
	 */
	public void setDependentGivenName(String dependentGivenName) {
		this.dependentGivenName = dependentGivenName;
	}

	/**
	 * <p>Getter for the field <code>dependentMiddleIni</code>.</p>
	 *
	 * @return the dependentMiddleIni
	 */
	public String getDependentMiddleIni() {
		return dependentMiddleIni;
	}

	/**
	 * <p>Setter for the field <code>dependentMiddleIni</code>.</p>
	 *
	 * @param dependentMiddleIni the dependentMiddleIni to set
	 */
	public void setDependentMiddleIni(String dependentMiddleIni) {
		this.dependentMiddleIni = dependentMiddleIni;
	}

	/**
	 * <p>Getter for the field <code>dependentSSN</code>.</p>
	 *
	 * @return the dependentSSN
	 */
	public String getDependentSSN() {
		return dependentSSN;
	}

	/**
	 * <p>Setter for the field <code>dependentSSN</code>.</p>
	 *
	 * @param dependentSSN the dependentSSN to set
	 */
	public void setDependentSSN(String dependentSSN) {
		this.dependentSSN = dependentSSN;
	}

	/**
	 * <p>Getter for the field <code>dependentDOBFormatted</code>.</p>
	 *
	 * @return the dependentFormattedDateDateOfBirth
	 */
	public String getDependentDOBFormatted() {
		if (RequestChangeSelectionForm.log.isDebugEnabled()) {
				            RequestChangeSelectionForm.log
				                    .debug("RequestChangeSelectionForm(), dependentDateOfBirth value is"
		                            + this.dependentDOB.toString());
		        }
		return this.dependentDOB.toString();
	}



	/**
	 * <p>Setter for the field <code>dependentDOBFormatted</code>.</p>
	 *
	 * @param value a {@link java.lang.String} object.
	 */
	public void setDependentDOBFormatted(String value) {
		this.dependentDOB.parse(value);
	}


	/**
	 * <p>Setter for the field <code>dependentDOB</code>.</p>
	 *
	 * @param value a {@link com.bcbssc.struts.common.FormDate} object.
	 */
	public void setDependentDOB(FormDate value){

		this.dependentDOB = value;
	}

	/**
	 * <p>Getter for the field <code>dependentDOB</code>.</p>
	 *
	 * @return a {@link com.bcbssc.struts.common.FormDate} object.
	 */
	public FormDate getDependentDOB(){

	    return this.dependentDOB;
	}

	/**
	 * <p>Getter for the field <code>dependentGender</code>.</p>
	 *
	 * @return the dependentGender
	 */
	public String getDependentGender() {
		return dependentGender;
	}

	/**
	 * <p>Setter for the field <code>dependentGender</code>.</p>
	 *
	 * @param dependentGender the dependentGender to set
	 */
	public void setDependentGender(String dependentGender) {
		this.dependentGender = dependentGender;
	}

	/**
	 * <p>Getter for the field <code>dependentRelation</code>.</p>
	 *
	 * @return the dependentRelation
	 */
	public String getDependentRelation() {
		return dependentRelation;
	}

	/**
	 * <p>Setter for the field <code>dependentRelation</code>.</p>
	 *
	 * @param dependentRelation the dependentRelation to set
	 */
	public void setDependentRelation(String dependentRelation) {
		this.dependentRelation = dependentRelation;
	}

	/**
	 * <p>Getter for the field <code>dependentIsStudent</code>.</p>
	 *
	 * @return the dependentIsStudent
	 */
	public String getDependentIsStudent() {
		return dependentIsStudent;
	}

	/**
	 * <p>Setter for the field <code>dependentIsStudent</code>.</p>
	 *
	 * @param dependentIsStudent the dependentIsStudent to set
	 */
	public void setDependentIsStudent(String dependentIsStudent) {
		this.dependentIsStudent = dependentIsStudent;
	}

	/**
	 * <p>getFormattedRequestType.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getFormattedRequestType() {

		return Options.getLabelFromValue(Options.getGroupAdminInstance()
				.getRequestaAllOptions(), this.requestType);

	}

	/**
	 * <p>Getter for the field <code>dependentGenderFormatted</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getDependentGenderFormatted() {
	        return com.bcbssc.struts.forms.Options.getLabelFromValue(this
	                .getOptions().getGenderOptions(), this.dependentGender);
    }

	/**
	 * <p>getFormattedDependentRelation.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getFormattedDependentRelation() {

		return Options.getLabelFromValue(Options.getGroupAdminInstance()
				.getRelationshipOptions(), this.dependentRelation);

	}

	/**
	 * <p>getFormattedDependetIsStudent.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getFormattedDependetIsStudent() {

		return Options.getLabelFromValue(Options.getGroupAdminInstance()
				.getPleaseChooseOneNoYesOptions(), this.dependentIsStudent);

	}

		/**
		 * Clears the user-editable data fields for this form
		 */
		public void clear() {
			this.reasonForRequest = com.bcbssc.struts.common.Constants.BLANK_STRING;
			this.requestType = com.bcbssc.struts.common.Constants.BLANK_STRING;

	}


	 /** {@inheritDoc} */
	 public ActionErrors validate(ActionMapping mapping,
	            HttpServletRequest request) {

	        ActionErrors errors = super.validate(mapping, request);


			String selectedRequestType = this.requestType;

			if(selectedRequestType.equals("change-mem-coverage") || selectedRequestType.equals("change-dep-cov") || selectedRequestType.equals("reinstate-mem")){
	        boolean coverageItemSelected = false;
	        ArrayList coverageItemsList = this.getCoverageItems();

	        for(int i=0;i<coverageItemsList.size();i++){

				CoverageItem item = (CoverageItem)coverageItemsList.get(i);
                String coverage = ""+item.getAction();

				if(coverage !=null){
					if(coverage.trim().equals("S")){
						coverageItemSelected = true;
						break;
					}
				}

			}

	        if (!coverageItemSelected) {
	            errors.add("selectedCoverageSectionDiv", new ActionMessage(
	                    "error.requestachange.coverageselection.checkbox.required"));
	        }

		}

	        return errors;

    }



}
