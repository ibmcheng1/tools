/*
 * @(#)BillHistoryAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/actions/BillHistoryAction.java_v  $
 * $Workfile:   BillHistoryAction.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:13:08  $
 * $Modtime:   May 14 2009 11:33:28  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/actions/BillHistoryAction.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:13:08   EN80
 * Initial revision.
 * 
 *    Rev 1.5   Apr 28 2009 10:16:38   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.4   May 09 2006 10:33:02   rx08e
 * Changes for Vision Coverage.	
 *
 *    Rev 1.3   Apr 28 2005 11:17:48   rxr93
 * set userdto into form so group list can be loaded correclty
 *
 *    Rev 1.2   Mar 15 2005 14:24:40   rxr93
 * issm change
 *
 *    Rev 1.1   Mar 02 2005 13:15:16   rxr93
 * add inform generation
 *
 *    Rev 1.0   Mar 01 2005 10:12:10   rxr93
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.actions;

import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;
import com.bcbssc.groupadmin.shared.forms.BillHistoryForm;
import com.bcbssc.groupadmin.shared.mq.InformFactory;
import com.bcbssc.groupadmin.shared.services.BillServices;
import com.bcbssc.struts.action.SimpleDispatchAction;

/**
 * Group Admin View Bill Histiry Action
 *
 * This class provides control processing the view Bill History action. NOTE:
 * this also include show a particular bill's summary.
 *
 * @author Mark Lujan
 * @version $Revision:   1.0  $
 */
public class BillHistoryAction extends SimpleDispatchAction {

	/** log4j logger */
	private static final Logger log = Logger.getLogger(BillHistoryAction.class
			.getName());

	/**
	 * <p>Constructor for BillHistoryAction.</p>
	 */
	public BillHistoryAction() {
		super();
		if (BillHistoryAction.log.isDebugEnabled()) {
			BillHistoryAction.log.debug("Created BillHistoryAction object.");
		}
	}

	/**
	 * Processes the specified HTTP request, and creates the corresponding HTTP
	 * response.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward displayBillSearch(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		BillHistoryForm billForm = (BillHistoryForm) form;

		// set user in form
		billForm
				.setUserDTO((GroupAdminUserDTO) request
						.getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}

	/**
	 * Use group selected to view the bill history
	 *
	 * @param mapping a {@link org.apache.struts.action.ActionMapping} object.
	 * @param form a {@link org.apache.struts.action.ActionForm} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @param response a {@link javax.servlet.http.HttpServletResponse} object.
	 * @return a {@link org.apache.struts.action.ActionForward} object.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward billHistory(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		BillHistoryForm billHistoryForm = (BillHistoryForm) form;

		// load the search results
		this.loadSearchResults(billHistoryForm);

		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}

	/**
	 * Use group selected to view the bill history
	 *
	 * @param mapping a {@link org.apache.struts.action.ActionMapping} object.
	 * @param form a {@link org.apache.struts.action.ActionForm} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @param response a {@link javax.servlet.http.HttpServletResponse} object.
	 * @return a {@link org.apache.struts.action.ActionForward} object.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward billSummary(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		String iniFile = CommonUtils.getIniFile(this.getServlet());
		BillHistoryForm billHistoryForm = (BillHistoryForm) form;

		// make a DTO with the currently selected group number
		InsuredDataDTO dataDTO = new InsuredDataDTO();
		dataDTO.setGroupNumber(billHistoryForm.getGroupNumber());

		// get bill history
		BillServices billServices = new BillServices(iniFile);
		Collection summary = billServices.getbillSummary(dataDTO,
				billHistoryForm.getSelectedBillDate());
		if (BillHistoryAction.log.isDebugEnabled()) {
			BillHistoryAction.log
					.debug("" + summary.size() + " items returned");
		}
		billHistoryForm.setSummary(summary);

		// get user, create a closed inform
		GroupAdminUserDTO user = (GroupAdminUserDTO) request
				.getAttribute(com.bcbssc.registration.common.Constants.USER_DTO);
		BillHistoryAction.log.debug("send inform");
		InformFactory.sendBillSummary(iniFile, user, billHistoryForm);

		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}

	/**
	 * load search results into BillHistoryForm
	 * 
	 * @param user
	 *            BillHistoryForm
	 * 
	 */
	private void loadSearchResults(BillHistoryForm billHistoryForm)
			throws Exception {

		// make a DTO with the currently selected group number
		InsuredDataDTO dataDTO = new InsuredDataDTO();
		dataDTO.setGroupNumber(billHistoryForm.getGroupNumber());

		// get bill history
		BillServices billServices = new BillServices(CommonUtils
				.getIniFile(this.getServlet()));
		Collection searchResults = billServices.getbillHistory(dataDTO);
		if (BillHistoryAction.log.isDebugEnabled()) {
			BillHistoryAction.log.debug("" + searchResults.size()
					+ " items returned");
		}
		billHistoryForm.setSearchResults(searchResults);
	}
}
