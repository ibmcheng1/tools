/*
 * IInsuredDatasource.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * Created on December 8, 2004, 11:47 AM
 */

package com.bcbssc.groupadmin.shared.dto;

import com.bcbssc.struts.common.DateBean;

/**
 * <p>IInsuredDatasource interface.</p>
 *
 * @author jegger
 *
 * datasource providing an implementation of getSpouseExists() and getHireDate()
 * that will provide the spouse coverage and hire dates associated with this
 * coverage item
 * @version $Id: $Id
 */
public interface IInsuredDatasource {

	/**
	 * Gets the spouse exists indicator
	 *
	 * @return spouse exists indicator
	 */
	public boolean getSpouseExists();

	/**
	 * Getter for property hireDate.
	 *
	 * @return Value of property hireDate.
	 */
	public DateBean getHireDate();

	/**
	 * Determines the minimum waiting period day
	 *
	 * @return minimum waiting period day
	 */
	public String getMinWaitingPeriodDay();

	/**
	 * Getter for property insuredPageUpdated.
	 *
	 * @return Value of property insuredPageUpdated.
	 */
	public boolean isInsuredPageUpdated();

	/**
	 * Getter for property coveragePageUpdated.
	 *
	 * @return Value of property coveragePageUpdated.
	 */
	public boolean isCoveragePageUpdated();

	/**
	 * Getter for property dependentPageUpdated.
	 *
	 * @return Value of property dependentPageUpdated.
	 */
	public boolean isDependentPageUpdated();

	/**
	 * Getter for property salaryPageUpdated.
	 *
	 * @return Value of property salaryPageUpdated.
	 */
	public boolean isSalaryPageUpdated();

	/**
	 * Returns changeEffectiveDate as a DateBean.
	 *
	 * @return changeEffectiveDate as a DateBean.
	 */
	public DateBean getChangeEffectiveDateAsDateBean();

	/**
	 * Returns salaryChangeEffectiveDate as a DateBean.
	 *
	 * @return salaryChangeEffectiveDate as a DateBean.
	 */
	public DateBean getSalaryChangeEffectiveDateAsDateBean();

	/**
	 * Returns indentification number.
	 *
	 * @return identification number.
	 */
	public String getIdentificationNumber();
}
