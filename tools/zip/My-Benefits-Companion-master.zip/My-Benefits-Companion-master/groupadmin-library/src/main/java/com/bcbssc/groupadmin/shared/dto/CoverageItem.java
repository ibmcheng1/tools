/*
 * @(#)CoverageItem.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.dto;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.forms.Options;
import com.bcbssc.struts.common.DateBean;
import com.bcbssc.struts.common.FormDate;

import org.apache.log4j.Logger;

/**
 * GroupAdmin Coverage Item
 *
 * This bean represents a coverage item. In addition to the coverage item data
 * properties, it contains logic to determine the display protections for the
 * item.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class CoverageItem extends Object {

	/** log4j logger */
	private static Logger logger = Logger.getLogger(CoverageItem.class);

	/** Number of digits in premium cents value */
	public static final int PREMIUM_CENTS_DIGITS = 4;

	/** Coverage statuses */
	public static final String COVERAGE_STATUS_SUPERSEDED = "1";

	/** Constant <code>COVERAGE_STATUS_TERMINATED="9"</code> */
	public static final String COVERAGE_STATUS_TERMINATED = "9";

	/** Relationship types */
	public static final String RELATIONSHIP_INSURED = "01";

	/** Constant <code>RELATIONSHIP_SPOUSE="02"</code> */
	public static final String RELATIONSHIP_SPOUSE = "02";

	/** Constant <code>RELATIONSHIP_DEPENDENT="04"</code> */
	public static final String RELATIONSHIP_DEPENDENT = "04";

	/** Dental volume basis */
	public static final int DENTAL_VOLUME_BASIS = 0;

	/** Dental volume basis */
	public static final int VISION_VOLUME_BASIS = 0;

	/** Annual salary volume bases */
	public static final int[] ANNUAL_SALARY_BASES = { 2, 5 };

	/** action values */
	public static final char ACTION_ACCEPTED = 'S';

	/** Constant <code>ACTION_DECLINED='R'</code> */
	public static final char ACTION_DECLINED = 'R';

	// Enterable field combinations (X is enterable)
	// VOL % MIN MAX WAITING
	// BASIS SALARY VOLUME VOLUME VOLUME PERIOD
	// 1 X X
	// 2 X X X X
	// 3 X X X X
	// 5 X X X X X
	private static final int PERCENT_SALARY_INDEX = 0;

	private static final int VOLUME_INDEX = 1;

	private static final int MIN_VOLUME_INDEX = 2;

	private static final int MAX_VOLUME_INDEX = 3;

	private static final int WAITING_PERIOD_INDEX = 4;

	private static final int VOL_UNIT_BASED = 0;

	private static final int VOL_FLAT = 1;

	private static final int VOL_OTHER = 2;

	private static final boolean[][] APPLICABLE_FIELDS = {
			{ false, false, false, false, false }, // VOL_BASIS = 0 (unused)
			{ false, true, false, false, true }, // VOL_BASIS = 1
			{ true, false, true, true, true }, // VOL_BASIS = 2
			{ false, true, true, true, true }, // VOL_BASIS = 3
			{ false, false, false, false, false }, // VOL_BASIS = 4 (unused)
			{ true, true, true, true, true } }; // VOL_BASIS = 5

	/** editable volume coverage bases */
	private static final int[] EDITABLE_VOLUME_COVERAGES = { 3, 5 };

	/** valid volume basis settings */
	private static final int[] VOLUME_UNITS = /* 5 volume basis */
	{ CoverageItem.VOL_OTHER, CoverageItem.VOL_FLAT, CoverageItem.VOL_OTHER,
			CoverageItem.VOL_UNIT_BASED, CoverageItem.VOL_OTHER,
			CoverageItem.VOL_FLAT };

	/** spouse-related coverage codes */
	private static final String[] SPOUSE_RELATED_COVERAGES = { "SPSF", // Supplemental
																		// Spouse
																		// (Female)
			"SPSM", // Supplemental Spouse (Male)
			"SUPF", // Dependent Supplemental (Female)
			"SUPM", // Dependent Supplemental (Male)
			"SUPS", // Dependent Supplemental (Spouse)
			"VADF", // Voluntary AD&D (Female)
			"VADM", // Voluntary AD&D (Male)
			"VADS", // Voluntary AD&D (Spouse)
			"VSPF", // Voluntary Life (Female)
			"VSPM", // Voluntary Life (Male)
			"VSPS" }; // Voluntary Life (Spouse)

	/**
	 * datasource providing an implementation of getSpouseExists() and
	 * getHireDate() that will provide the spouse coverage and hire dates
	 * associated with this coverage item
	 */
	protected IInsuredDatasource insuredDatasource;

	/** action */
	private char action;

	/** is coverage protected (no selection allowed) */
	private boolean isProtected;

	/** display name */
	private String name;

	/** employer % insurance */
	private int employerPercentInsurance;

	/** code */
	private String code;

	/** volume basis */
	private int volumeBasis;

	/** volume */
	private int volume;

	/** minimum volume */
	private int minimumVolume;

	/** maximum volume */
	private int maximumVolume;

	/** waiting period */
	private int waitingPeriod;

	/** waiting period (a code for the MQ message) */
	private int waitingPeriodForMq;

	/** waiting period code */
	private String waitingPeriodCode = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** waiting period day */
	private String waitingPeriodDay = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** unit factor */
	private int unitFactor;

	/** default base unit */
	private double baseUnit;

	/** group base unit */
	private double groupBaseUnit;

	/** effective date */
	private FormDate effectiveDate = FormDate.blank();

	/**
	 * Holds value of property relationshipType.
	 */
	private String relationshipType;

	/**
	 * Holds value of property premium.
	 */
	private int premium;

	/** Percent Salary */
	private int percentSalary;

	/** Substandard Factor */
	private double substandardFactor;

	/** No Evidence Max Volume */
	private int noEvidenceMaxVolume;

	/** Round Code */
	private String roundCode = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** Round Volume */
	private int roundVolume;

	/** Line Of Business */
	private String lineOfBusiness = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** Coverage type */
	private String type = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property changed.
	 */
	private boolean changed;

	/**
	 * Holds value of property ceaseReason.
	 */
	private char ceaseReason;

	/**
	 * Holds value of property coverageStatus.
	 */
	private String coverageStatus = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property coverageEvidence.
	 */
	private String coverageEvidence;

	/**
	 * Holds value of property waitPeriodCalculationCategory.
	 */
	private String waitPeriodCalculationCategory = com.bcbssc.struts.common.Constants.BLANK_STRING;

	
	private String reportId;
	
	private String dentalCardReportId;
	
	/**
	 * Constructor; creates an empty CoverageItem
	 *
	 * @param insuredDatasource a {@link com.bcbssc.groupadmin.shared.dto.IInsuredDatasource} object.
	 */
	public CoverageItem(IInsuredDatasource insuredDatasource) {
		super();
		this.insuredDatasource = insuredDatasource;
	}

	/**
	 * Gets the coverage action
	 *
	 * @return coverage action
	 */
	public char getAction() {
		char retVal = this.action;

		if (this.getSuperseded()) {
			retVal = ' ';
		} else if (this.getTerminated()) {
			if (this.action != CoverageItem.ACTION_DECLINED) {
				CoverageItem.logger.debug("coverage terminated: "
						+ this.getCode());
				retVal = ' ';
			}
		}
		return retVal;
	}

	/**
	 * Gets the action label
	 *
	 * @return coverage action label
	 */
	public String getActionFormatted() {
		String strAction = String.valueOf(this.getAction());
		return com.bcbssc.struts.forms.Options.getLabelFromValue(Options
				.getGroupAdminInstance().getClassActionOptions(), strAction);
	}

	/**
	 * Gets the action protected indicator
	 *
	 * @return volume disabled indicator
	 */
	public boolean getActionProtected() {

		boolean returnBoolean;

		if (this.getEmployerPercentInsurance() == 100) {
			// 100% employer paid is always protected
			returnBoolean = true;
		} else {
			returnBoolean = this.isProtected;
		}
		return returnBoolean;
	}

	/**
	 * Sets the action protected indicator
	 *
	 * @param bool a boolean.
	 */
	public void setActionProtected(boolean bool) {
		this.isProtected = bool;
	}

	/**
	 * Sets the coverage action
	 *
	 * @param value
	 *            coverage action
	 */
	public void setAction(char value) {
		this.action = value;
	}

	/**
	 * Gets the display name
	 *
	 * @return display name
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * Sets the display name
	 *
	 * @param value
	 *            display name
	 */
	public void setName(String value) {
		this.name = value;
	}

	/**
	 * Gets the coverage volume
	 *
	 * @return coverage volume
	 */
	public int getVolume() {
		return this.getCoverageIsDental() ? 0 : this.volume;
	}

	/**
	 * Gets the formatted coverage volume
	 *
	 * @return currency formatted coverage volume
	 */
	public String getVolumeFormatted() {
		return CommonUtils.formatDollarCurrency(this.getVolume());
	}

	/**
	 * Gets the displayed coverage volume
	 *
	 * @return currency formatted coverage volume
	 */
	public String getVolumeToDisplay() {
		String returnString = null;
		if (this.volume > this.noEvidenceMaxVolume) {
			returnString = CommonUtils
					.formatDollarCurrency(this.noEvidenceMaxVolume);
		} else {
			returnString = CommonUtils.formatDollarCurrency(this.volume);
		}
		return returnString;
	}

	/**
	 * Gets the volume disabled indicator
	 *
	 * @return volume disabled indicator
	 */
	public boolean getVolumeDisabled() {
		// logger.debug("getting volumeDisabled for volume basis " + volumeBasis
		// + ": " + !applicableFields[volumeBasis][VOLUME_INDEX]);
		return !CoverageItem.APPLICABLE_FIELDS[this.volumeBasis][CoverageItem.VOLUME_INDEX];
	}

	/**
	 * Gets the volume editable indicator
	 *
	 * @return volume editable indicator
	 */
	public boolean getVolumeEditable() {

		boolean isEditable = false;

		// If the user selected 'No' for the spouse question on the "Add Insured
		// Employee" page... Protect any related enterable volume field.
		if (!this.isCoverageSpouseRelated()
				|| this.insuredDatasource.getSpouseExists()) {
			for (int i = 0; i < CoverageItem.EDITABLE_VOLUME_COVERAGES.length; i++) {
				if (CoverageItem.EDITABLE_VOLUME_COVERAGES[i] == this.volumeBasis) {
					isEditable = true;
				}
			}
		}

		return isEditable;
	}

	/**
	 * Sets the coverage volume
	 *
	 * @param value
	 *            coverage volume
	 */
	public void setVolume(int value) {
		this.volume = value;
	}

	/**
	 * Gets the coverage minimum volume
	 *
	 * @return coverage minimum volume
	 */
	public int getMinimumVolume() {
		return this.minimumVolume;
	}

	/**
	 * Gets the formatted coverage minimum volume
	 *
	 * @return currency formatted coverage minimum volume
	 */
	public String getMinimumVolumeFormatted() {
		return CommonUtils.formatDollarCurrency(this.minimumVolume);
	}

	/**
	 * Gets the minimum volume disabled indicator
	 *
	 * @return minimum volume disabled indicator
	 */
	public boolean getMinimumVolumeDisabled() {
		// logger.debug("getting minimumVolumeDisabled for volume basis " +
		// volumeBasis + ": " +
		// !applicableFields[volumeBasis][MIN_VOLUME_INDEX]);
		return !CoverageItem.APPLICABLE_FIELDS[this.volumeBasis][CoverageItem.MIN_VOLUME_INDEX];
	}

	// public boolean getMinimumVolumeEditable() {
	// boolean isEditable = false;
	//
	// // See business logic comment in spouseExists()
	// if (spouseExists()
	// && fieldProtections[volumeBasis][MIN_VOLUME_INDEX] == EDITABLE) {
	// isEditable = true;
	// }
	//
	// return isEditable;
	// }

	/**
	 * Sets the coverage minimum volume
	 *
	 * @param value
	 *            coverage minimum volume
	 */
	public void setMinimumVolume(int value) {
		this.minimumVolume = value;
	}

	/**
	 * Gets the coverage maximum volume
	 *
	 * @return coverage maximum volume
	 */
	public int getMaximumVolume() {
		return this.maximumVolume;
	}

	/**
	 * Gets the formatted coverage maximum volume
	 *
	 * @return currency formatted coverage maximum volume
	 */
	public String getMaximumVolumeFormatted() {
		return CommonUtils.formatDollarCurrency(this.maximumVolume);
	}

	/**
	 * Gets the maximum volume disabled indicator
	 *
	 * @return maximum volume disabled indicator
	 */
	public boolean getMaximumVolumeDisabled() {
		// logger.debug("getting maximumVolumeDisabled for volume basis " +
		// volumeBasis + ": " +
		// !applicableFields[volumeBasis][MAX_VOLUME_INDEX]);
		return !CoverageItem.APPLICABLE_FIELDS[this.volumeBasis][CoverageItem.MAX_VOLUME_INDEX];
	}

	// public boolean getMaximumVolumeEditable() {
	// boolean isEditable = false;
	//
	// // See business logic comment in spouseExists()
	// if (spouseExists()
	// && fieldProtections[volumeBasis][MAX_VOLUME_INDEX] == EDITABLE) {
	// isEditable = true;
	// }
	//
	// logger.debug("getting maximumVolumeEditable for volume basis " +
	// volumeBasis + ": " + isEditable);
	// return isEditable;
	// }

	/**
	 * Sets the coverage maximum volume
	 *
	 * @param value
	 *            coverage maximum volume
	 */
	public void setMaximumVolume(int value) {
		this.maximumVolume = value;
	}

	/**
	 * Gets the coverage waiting period
	 *
	 * @return coverage waiting period
	 */
	public int getWaitingPeriod() {
		return this.waitingPeriod;
	}

	/**
	 * Gets the waiting period disabled indicator
	 *
	 * @return waiting period disabled indicator
	 */
	public boolean getWaitingPeriodDisabled() {
		// logger.debug("getting waitingPeriodDisabled for volume basis " +
		// volumeBasis + ": " +
		// !applicableFields[volumeBasis][WAITING_PERIOD_INDEX]);
		return !CoverageItem.APPLICABLE_FIELDS[this.volumeBasis][CoverageItem.WAITING_PERIOD_INDEX];
	}

	// public boolean getWaitingPeriodEditable() {
	// boolean isEditable = false;
	//
	// // See business logic comment in spouseExists()
	// if (spouseExists()
	// && fieldProtections[volumeBasis][WAITING_PERIOD_INDEX] == EDITABLE) {
	// isEditable = true;
	// }
	// logger.debug("getting waitingPeriodEditable for volume basis " +
	// volumeBasis + ": " + isEditable);
	// return isEditable;
	// }

	/**
	 * Sets the coverage waiting period
	 *
	 * @param value
	 *            coverage waiting period
	 */
	public void setWaitingPeriod(int value) {
		this.waitingPeriod = value;
	}

	/**
	 * Gets the coverage waiting period for the MQ message.
	 *
	 * @return coverage waiting period for the MQ message.
	 */
	public int getWaitingPeriodForMq() {
		return this.waitingPeriodForMq;
	}

	/**
	 * Sets the coverage waiting period for the MQ message.
	 *
	 * @param value
	 *            coverage waiting period for the MQ message.
	 */
	public void setWaitingPeriodForMq(int value) {
		this.waitingPeriodForMq = value;
	}

	/**
	 * Gets the coverage waiting period code.
	 *
	 * @return coverage waiting period code.
	 */
	public String getWaitingPeriodCode() {
		return this.waitingPeriodCode;
	}

	/**
	 * Sets the coverage waiting period code.
	 *
	 * @param value
	 *            coverage waiting period code.
	 */
	public void setWaitingPeriodCode(String value) {
		this.waitingPeriodCode = value;
	}

	/**
	 * Gets the coverage waiting period day.
	 *
	 * @return coverage waiting period day.
	 */
	public String getWaitingPeriodDay() {
		return this.waitingPeriodDay;
	}

	/**
	 * Sets the coverage waiting period day.
	 *
	 * @param value
	 *            coverage waiting period day.
	 */
	public void setWaitingPeriodDay(String value) {
		this.waitingPeriodDay = value;
	}

	// /**
	// * Determines if this is a spouse coverage and if the user declined spouse
	// * coverages.
	// *
	// * @return true, if this is a declined spouse coverage; false otherwise
	// */
	// private boolean spouseExists() {
	// // If the user selected 'No' for the spouse question on the "Add Insured
	// // Employee" page, set the action to 'Declined' for all spouse related
	// // coverage. Protect the 'Declined' action and any related enterable
	// // volume field (see getVolumeProtected()).
	// if (insuredDatasource.getSpouseExists() && isCoverageSpouseRelated()) {
	// return true;
	// } else {
	// return false;
	// }
	// }

	/**
	 * Determines if this is a spouse-related coverage.
	 *
	 * @return a boolean.
	 */
	protected boolean isCoverageSpouseRelated() {
		for (int i = 0; i < CoverageItem.SPOUSE_RELATED_COVERAGES.length; i++) {
			if (CoverageItem.SPOUSE_RELATED_COVERAGES[i].equals(this.code)) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Used for debug
	 *
	 * @return a boolean.
	 */
	public boolean getCoverageSpouseRelated() {
		return this.isCoverageSpouseRelated();
	}

	/**
	 * Determines if this is a dental coverage.
	 *
	 * @return a boolean.
	 */
	public boolean getCoverageIsDental() {
		boolean isDentalCoverage = false;
		if((!this.getCode().equalsIgnoreCase("DNF1") && !this.getCode().equalsIgnoreCase("DNF0") ) && (this.getType().equalsIgnoreCase("25")) ){
			isDentalCoverage = true;
	    }
	
	return isDentalCoverage;
	}

	/**
	 * <p>getCoverageIsDentalTax.</p>
	 *
	 * @return a boolean.
	 */
	public boolean getCoverageIsDentalTax(){
		return this.getCode().equalsIgnoreCase("DNTX");
	}
	
	/**
	 * <p>getCoverageIsBasicDentalFederalFee.</p>
	 *
	 * @return a boolean.
	 */
	public boolean getCoverageIsBasicDentalFederalFee(){
		return this.getCode().equalsIgnoreCase("DNF0");
	}
	
	/**
	 * <p>getCoverageIsVoluntaryDentalFederalFee.</p>
	 *
	 * @return a boolean.
	 */
	public boolean getCoverageIsVoluntaryDentalFederalFee(){
		return this.getCode().equalsIgnoreCase("DNF1");
	}
	
	/**
	 * Determines if this is a vision coverage.
	 *
	 * @return a boolean.
	 */
	public boolean getCoverageIsVision() {
		
		boolean isVisionCoverage = false;
		if((!this.getCode().equalsIgnoreCase("VIF1") && !this.getCode().equalsIgnoreCase("VIF0") ) && (this.getType().equalsIgnoreCase("26")) ){
			isVisionCoverage = true;
	    }
	
	   return isVisionCoverage;
		
	}

	/**
	 * <p>getCoverageIsVisionTax.</p>
	 *
	 * @return a boolean.
	 */
	public boolean getCoverageIsVisionTax(){
		return this.getCode().equalsIgnoreCase("VITX");
	}
	
	/**
	 * <p>getCoverageIsBasicVisionFederalFee.</p>
	 *
	 * @return a boolean.
	 */
	public boolean getCoverageIsBasicVisionFederalFee(){
		return this.getCode().equalsIgnoreCase("VIF0");
	}
	/**
	 * <p>getCoverageIsVoluntaryVisionFederalFee.</p>
	 *
	 * @return a boolean.
	 */
	public boolean getCoverageIsVoluntaryVisionFederalFee(){
		return this.getCode().equalsIgnoreCase("VIF1");
	}
	
	
	/**
	 * Determines if this class requires annual salary
	 *
	 * @return a boolean.
	 */
	public boolean getClassRequiresAnnualSalary() {
		for (int i = 0; i < CoverageItem.ANNUAL_SALARY_BASES.length; i++) {
			if (CoverageItem.ANNUAL_SALARY_BASES[i] == this.volumeBasis) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Gets the spouse coverage indicator
	 *
	 * @return spouse coverage indicator
	 */
	public boolean getSpouseExists() {
		return this.insuredDatasource.getSpouseExists();
	}

	/**
	 * Gets the coverage code
	 *
	 * @return coverage code
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Sets the coverage code
	 *
	 * @param value
	 *            coverage code
	 */
	public void setCode(String value) {
		this.code = value;
	}

	/**
	 * Gets the coverage volume basis
	 *
	 * @return coverage volume basis
	 */
	public int getVolumeBasis() {
		return this.volumeBasis;
	}

	/**
	 * Sets the coverage volume basis
	 *
	 * @param value
	 *            coverage volume basis
	 */
	public void setVolumeBasis(int value) {
		this.volumeBasis = value;
	}

	/**
	 * Gets the employer % insurance
	 *
	 * @return employer % insurance
	 */
	public int getEmployerPercentInsurance() {
		return this.employerPercentInsurance;
	}

	/**
	 * Sets the employer % insurance
	 *
	 * @param value
	 *            employer % insurance
	 */
	public void setEmployerPercentInsurance(int value) {
		this.employerPercentInsurance = value;
	}

	/**
	 * Gets the unit factor.
	 *
	 * @return unit factor.
	 */
	public int getUnitFactor() {
		return this.unitFactor;
	}

	/**
	 * Sets the unit factor.
	 *
	 * @param value
	 *            unit factor.
	 */
	public void setUnitFactor(int value) {
		this.unitFactor = value;
	}

	/**
	 * Gets the default base unit.
	 *
	 * @return base unit.
	 */
	public double getBaseUnit() {
		return this.baseUnit;
	}

	/**
	 * Sets the default base unit.
	 *
	 * @param value
	 *            base unit.
	 */
	public void setBaseUnit(double value) {
		this.baseUnit = value;
	}

	/**
	 * Gets the group's base unit.
	 *
	 * @return base unit.
	 */
	public double getGroupBaseUnit() {
		return this.groupBaseUnit;
	}

	/**
	 * Sets the group's base unit.
	 *
	 * @param value
	 *            base unit.
	 */
	public void setGroupBaseUnit(double value) {
		this.groupBaseUnit = value;
	}

	/**
	 * Gets the formatted effective date
	 *
	 * @return formatted effective date
	 */
	public String getEffectiveDateFormatted() {
		if (CoverageItem.logger.isDebugEnabled()) {
			CoverageItem.logger
					.debug("getEffectiveDateFormatted(), effectiveDate is"
							+ this.effectiveDate.toString());
		}
		return this.effectiveDate.toString();
	}

	/**
	 * Gets the effective date
	 *
	 * @return effective date
	 */
	public DateBean getEffectiveDate() {
		if (CoverageItem.logger.isDebugEnabled()) {
			CoverageItem.logger.debug("getEffectiveDate(), effectiveDate is"
					+ this.effectiveDate);
		}
		return this.effectiveDate;
	}

	/**
	 * Sets the effective date
	 *
	 * @param bean a {@link com.bcbssc.struts.common.DateBean} object.
	 */
	public void setEffectiveDate(DateBean bean) {
		this.effectiveDate.setDate(bean);
	}

	/**
	 * Setter for property dateOfBirth.
	 *
	 * @param value
	 *            New value of property dateOfBirth.
	 */
	public void setEffectiveDateFormatted(String value) {
		this.effectiveDate.parse(value);
	}

	/**
	 * Returns a String representation of the object.
	 *
	 * @return description of the object contents
	 */
	public String toString() {
		StringBuffer str = new StringBuffer(128);

		str.append("\n    action: ").append(this.getAction());
		str.append("\n    actionProtected: ").append(this.getActionProtected());
		str.append("\n    code: ").append(this.getCode());
		str.append("\n    name: ").append(this.getName());
		str.append("\n    percentSalary: ").append(this.getPercentSalary());
		str.append("\n    percentSalaryDisabled: ").append(
				this.getPercentSalaryDisabled());
		str.append("\n    spouseExists: ").append(this.getSpouseExists());

		return str.toString();
	}

	/**
	 * Getter for property relationshipType.
	 *
	 * @return Value of property relationshipType.
	 */
	public String getRelationshipType() {
		return this.relationshipType;
	}

	/**
	 * Setter for property relationshipType.
	 *
	 * @param relationshipType
	 *            New value of property relationshipType.
	 */
	public void setRelationshipType(String relationshipType) {
		this.relationshipType = relationshipType;
	}

	/**
	 * Getter for property premium.
	 *
	 * @return Value of property premium.
	 */
	public int getPremium() {
		return this.premium;
	}

	/**
	 * Setter for property premium.
	 *
	 * @param value
	 *            New value of property premium.
	 */
	public void setPremium(int value) {
		this.premium = value;
	}

	/**
	 * Gets the formatted premium volume
	 *
	 * @return currency formatted premium volume
	 */
	public String getPremiumFormatted() {
		String returnString = null;
		if (this.getSuperseded() || this.getTerminated()) {
			returnString = com.bcbssc.struts.common.Constants.BLANK_STRING;
		} else {
			returnString = CommonUtils.formatCurrency(this.premium,
					CoverageItem.PREMIUM_CENTS_DIGITS);
		}
		return returnString;
	}

	/**
	 * Getter for property substandardFactor.
	 *
	 * @return Value of property substandardFactor.
	 */
	public double getSubstandardFactor() {
		return this.substandardFactor;
	}

	/**
	 * Setter for property substandardFactor.
	 *
	 * @param value
	 *            New value of property substandardFactor.
	 */
	public void setSubstandardFactor(double value) {
		this.substandardFactor = value;
	}

	/**
	 * Getter for property percentSalary.
	 *
	 * @return Value of property percentSalary.
	 */
	public int getPercentSalary() {
		return this.percentSalary;
	}

	/**
	 * Gets the percentSalary disabled indicator
	 *
	 * @return percentSalary disabled indicator
	 */
	public boolean getPercentSalaryDisabled() {
		// logger.debug("getting percentSalaryDisabled for volume basis " +
		// volumeBasis + ": " +
		// !applicableFields[volumeBasis][PERCENT_SALARY_INDEX]);
		return !CoverageItem.APPLICABLE_FIELDS[this.volumeBasis][CoverageItem.PERCENT_SALARY_INDEX];
	}

	/**
	 * Gets the formatted percentSalary
	 *
	 * @return currency formatted percentSalary
	 */
	public String getPercentSalaryFormatted() {
		StringBuffer fps = new StringBuffer(8);
		fps.append(this.percentSalary);
		while (fps.length() < 5) {
			fps.insert(0, '0');
		}
		fps.insert(fps.length() - 2, '.');

		// Get rid of leading zeros
		while (fps.charAt(0) == '0') {
			fps.deleteCharAt(0);
		}

		// Add one leading zero if the value is only fractional
		if (fps.charAt(0) == '.') {
			fps.insert(0, '0');
		}
		return fps.toString();
	}

	/**
	 * Setter for property percentSalary.
	 *
	 * @param value
	 *            New value of property percentSalary.
	 */
	public void setPercentSalary(int value) {
		this.percentSalary = value;
	}

	/**
	 * Getter for property noEvidenceMaxVolume.
	 *
	 * @return Value of property noEvidenceMaxVolume.
	 */
	public int getNoEvidenceMaxVolume() {
		return this.noEvidenceMaxVolume;
	}

	/**
	 * Setter for property noEvidenceMaxVolume.
	 *
	 * @param value
	 *            New value of property noEvidenceMaxVolume.
	 */
	public void setNoEvidenceMaxVolume(int value) {
		this.noEvidenceMaxVolume = value;
	}

	/**
	 * Getter for property roundCode.
	 *
	 * @return Value of property roundCode.
	 */
	public String getRoundCode() {
		return this.roundCode;
	}

	/**
	 * Setter for property roundCode.
	 *
	 * @param value
	 *            New value of property roundCode.
	 */
	public void setRoundCode(String value) {
		this.roundCode = value;
	}

	/**
	 * Getter for property roundVolume.
	 *
	 * @return Value of property roundVolume.
	 */
	public int getRoundVolume() {
		return this.roundVolume;
	}

	/**
	 * Setter for property roundVolume.
	 *
	 * @param value
	 *            New value of property roundVolume.
	 */
	public void setRoundVolume(int value) {
		this.roundVolume = value;
	}

	/**
	 * Getter for property lineOfBusiness.
	 *
	 * @return Value of property lineOfBusiness.
	 */
	public String getLineOfBusiness() {
		return this.lineOfBusiness;
	}

	/**
	 * Setter for property lineOfBusiness.
	 *
	 * @param value
	 *            New value of property lineOfBusiness.
	 */
	public void setLineOfBusiness(String value) {
		this.lineOfBusiness = value;
	}

	/**
	 * Getter for property type.
	 *
	 * @return Value of property type.
	 */
	public String getType() {
		return this.type;
	}

	/**
	 * Setter for property type.
	 *
	 * @param value
	 *            New value of property type.
	 */
	public void setType(String value) {
		this.type = value;
	}

	/**
	 * Getter for property changed.
	 *
	 * @return Value of property changed.
	 */
	public boolean getChanged() {
		return this.changed;
	}

	/**
	 * Setter for property changed.
	 *
	 * @param changed
	 *            New value of property changed.
	 */
	public void setChanged(boolean changed) {
		this.changed = changed;
	}

	/**
	 * Getter for property ceaseReason.
	 *
	 * @return Value of property ceaseReason.
	 */
	public char getCeaseReason() {
		return this.ceaseReason;
	}

	/**
	 * Setter for property ceaseReason.
	 *
	 * @param ceaseReason
	 *            New value of property ceaseReason.
	 */
	public void setCeaseReason(char ceaseReason) {
		this.ceaseReason = ceaseReason;
	}

	/**
	 * Returns true if the coverage item is superseded
	 *
	 * @return a boolean.
	 */
	public boolean getSuperseded() {
		// CC_CVG_STAT = '1' and CC_CEASE_REAS not spaces)
		return this.coverageStatus
				.equals(CoverageItem.COVERAGE_STATUS_SUPERSEDED)
				&& (this.ceaseReason != ' ');
	}

	/**
	 * Returns true if the coverage item is terminated
	 *
	 * @return a boolean.
	 */
	public boolean getTerminated() {
		return this.coverageStatus
				.equals(CoverageItem.COVERAGE_STATUS_TERMINATED);
	}

	/**
	 * Returns true if the coverage item is active
	 *
	 * @return a boolean.
	 */
	public boolean getActive() {
		return !this.getSuperseded() && !this.getTerminated();
	}

	/**
	 * Getter for property coverageStatus.
	 *
	 * @return Value of property coverageStatus.
	 */
	public String getCoverageStatus() {
		return this.coverageStatus;
	}

	/**
	 * Setter for property coverageStatus.
	 *
	 * @param coverageStatus
	 *            New value of property coverageStatus.
	 */
	public void setCoverageStatus(String coverageStatus) {
		this.coverageStatus = coverageStatus;
	}

	/**
	 * Getter for property coverageEvidence.
	 *
	 * @return Value of property coverageEvidence.
	 */
	public String getCoverageEvidence() {
		return this.coverageEvidence;
	}

	/**
	 * Setter for property coverageEvidence.
	 *
	 * @param coverageEvidence
	 *            New value of property coverageEvidence.
	 */
	public void setCoverageEvidence(String coverageEvidence) {
		this.coverageEvidence = coverageEvidence;
	}

	/**
	 * Is the coverage a flat amount
	 *
	 * @return boolean
	 */
	public boolean isVolumeFlat() {
		return (CoverageItem.VOLUME_UNITS[this.volumeBasis] == CoverageItem.VOL_FLAT);
	}

	/**
	 * Is the coverage a flat amount
	 *
	 * @return boolean
	 */
	public boolean getVolumeFlat() {
		return this.isVolumeFlat();
	}

	/**
	 * Is the coverage based on units
	 *
	 * @return boolean
	 */
	public boolean isVolumeUnits() {
		return (CoverageItem.VOLUME_UNITS[this.volumeBasis] == CoverageItem.VOL_UNIT_BASED);
	}

	/**
	 * Is the coverage a based on units
	 *
	 * @return boolean
	 */
	public boolean getVolumeUnits() {
		return this.isVolumeUnits();
	}

	/**
	 * <p>getDentalOrVisionCovered.</p>
	 *
	 * @return a boolean.
	 */
	public boolean getDentalOrVisionCovered() {
		return this.getCoverageIsDental() || this.getCoverageIsVision();
	}

	/**
	 * Retreives the value of waitPeriodCalculationCategory.
	 *
	 * @return Returns the waitPeriodCalculationCategory.
	 */
	public String getWaitPeriodCalculationCategory() {
		return this.waitPeriodCalculationCategory;
	}

	/**
	 * Sets the value of waitPeriodCalculationCategory.
	 *
	 * @param waitPeriodCalculationCategory
	 *            The waitPeriodCalculationCategory to set.
	 */
	public void setWaitPeriodCalculationCategory(
			String waitPeriodCalculationCategory) {
		this.waitPeriodCalculationCategory = waitPeriodCalculationCategory;
	}
	
	
	/**
	 * <p>Setter for the field <code>reportId</code>.</p>
	 *
	 * @param id a {@link java.lang.String} object.
	 */
	public void setReportId(String id){
		
		this.reportId = id;
	}
	
	/**
	 * <p>Getter for the field <code>reportId</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getReportId(){
		
		return this.reportId;
	}
	
	/**
	 * <p>Setter for the field <code>dentalCardReportId</code>.</p>
	 *
	 * @param dentalCardReportId a {@link java.lang.String} object.
	 */
	public void setDentalCardReportId(String dentalCardReportId){
	
		this.dentalCardReportId = dentalCardReportId;
	
	}
	
	/**
	 * <p>Getter for the field <code>dentalCardReportId</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getDentalCardReportId(){
		
		return this.dentalCardReportId;
	}
}
