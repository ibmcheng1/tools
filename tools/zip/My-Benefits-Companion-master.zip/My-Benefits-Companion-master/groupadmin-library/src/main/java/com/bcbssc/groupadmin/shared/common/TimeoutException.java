/*
 *
 * Created on Sep 6, 2006 
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.common;

import com.bcbssc.netsys.LinkedException;

/**
 * <p>TimeoutException class.</p>
 *
 * @author X08E
 * @version $Id: $Id
 */
public class TimeoutException extends LinkedException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1730839852240165532L;

	/**
	 * Creates a new instance of TimeoutException.
	 */
	public TimeoutException() {
		super();
	}

	/**
	 * Creates a new instance of TimeoutException with a descriptive message.
	 *
	 * @param message
	 *            The exception message.
	 */
	public TimeoutException(String message) {
		super(message);
	}

	/**
	 * Creates a new instance of TimeoutException with a descriptive message and
	 * a root cause.
	 *
	 * @param message
	 *            The exception message.
	 * @param rootCause
	 *            The root cause of this exception.
	 */
	public TimeoutException(String message, Throwable rootCause) {
		super(message, rootCause);
	}

	/**
	 * Creates a new instance of TimeoutException with the given root cause.
	 *
	 * @param rootCause
	 *            The root cause of this exception.
	 */
	public TimeoutException(Throwable rootCause) {
		super(rootCause);
	}

}
