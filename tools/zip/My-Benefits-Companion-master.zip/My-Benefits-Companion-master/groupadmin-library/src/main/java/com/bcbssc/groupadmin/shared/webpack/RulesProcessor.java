/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/webpack/RulesProcessor.java_v  $
 * $Workfile:   RulesProcessor.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:16:44  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/webpack/RulesProcessor.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:16:44   EN80
 * Initial revision.
 * 
 *    Rev 1.7   Apr 28 2009 10:21:00   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.6   Jan 25 2005 11:00:04   rxg50
 * updated to remove dashes from group #
 *
 *    Rev 1.5   Nov 18 2004 14:04:00   rxg97
 * Hammurapi updates.
 *
 *    Rev 1.4   Oct 22 2004 14:29:04   rxg97
 * Removed accountLocked from test method.
 *
 *    Rev 1.3   Sep 27 2004 15:32:26   rxg97
 * Now throws WebpackException if webpack returns an error.
 *
 *    Rev 1.2   Sep 22 2004 17:02:12   rxg97
 * Removed notifyflag references.
 *
 *    Rev 1.1   Sep 22 2004 10:25:10   rxg97
 * Added mainframe formatting for the user dob.
 *
 *    Rev 1.0   Sep 12 2004 15:27:24   rxg97
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.webpack;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import com.bcbssc.commapi.model.common.DAOException;
import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.netsys.Config;
import com.bcbssc.services.daoimpl.accesscoderequest.ServicesAccessCodeRequestDAOImpl;
//import com.bcbssc.netsys.webpack.WebpackRequest;

/**
 * Performs rules updates on 3270.
 *
 * @author rxg97 (Jonathan Egger)
 * @version $Id: $Id
 */
public class RulesProcessor {

	/** The log4j logger for this class */
	private static Logger logger = Logger.getLogger(RulesProcessor.class);

	/** Webpack INI file section name */
	//private static final String WEBPACK_SECTION_NAME = "WebPack";
	/** Miscellaneous INI file section name */
	private static final String MISC_SECTION_NAME = "MISC";
	/** The line of business RPN number */
	private String rpn;

	/** The line of business application ID */
	private String applicationID;

	/**
	 * <p>Constructor for RulesProcessor.</p>
	 *
	 * @param iniFile a {@link java.lang.String} object.
	 */
	public RulesProcessor(String iniFile) {
		super();
//webpack references, no longer needed.
//		this.appServerHost = Config.getPrivateProfileString(
//				RulesProcessor.WEBPACK_SECTION_NAME, "APPSERVER_HOST",
//				com.bcbssc.struts.common.Constants.BLANK_STRING, iniFile);
//
//		String appServerPort = Config.getPrivateProfileString(
//				RulesProcessor.WEBPACK_SECTION_NAME, "APPSERVER_PORT",
//				com.bcbssc.struts.common.Constants.BLANK_STRING, iniFile);
//		this.appServerPortInt = Integer.parseInt(appServerPort);
//
//		this.racfID = Config.getPrivateProfileString(
//				RulesProcessor.WEBPACK_SECTION_NAME, "RACF",
//				com.bcbssc.struts.common.Constants.BLANK_STRING, iniFile);
//
//		this.racfPassword = Config.getPrivateProfileString(
//				RulesProcessor.WEBPACK_SECTION_NAME, "RACF_PW",
//				com.bcbssc.struts.common.Constants.BLANK_STRING, iniFile);
//
//		this.region = Config.getPrivateProfileString(
//				RulesProcessor.WEBPACK_SECTION_NAME, "MF_REGION",
//				com.bcbssc.struts.common.Constants.BLANK_STRING, iniFile);

		this.rpn = Config.getPrivateProfileString(
				RulesProcessor.MISC_SECTION_NAME, "RPN",
				com.bcbssc.struts.common.Constants.BLANK_STRING, iniFile);

		this.applicationID = Config.getPrivateProfileString(
				RulesProcessor.MISC_SECTION_NAME, "APP_ID",
				com.bcbssc.struts.common.Constants.BLANK_STRING, iniFile);
	}

	/**
	 * <p>requestNewAccessCode.</p>
	 *
	 * @param user a {@link com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO} object.
	 * @return a {@link java.lang.String} object.
	 * @throws java.text.ParseException if any.
	 * @throws com.bcbssc.commapi.model.common.DAOException if any.
	 */
	public String requestNewAccessCode(GroupAdminUserDTO user)
			throws ParseException, DAOException {
		String accessCode = null;
		
		
		
		String USER_LDAP_DOB_DATE_FORMAT = "MM/dd/yyyy";
		 
        SimpleDateFormat maskedBillingDateFmt = new SimpleDateFormat(USER_LDAP_DOB_DATE_FORMAT);
	
		
		
		String ACCESSCODE_DOB_DATE_FORMAT = "yyyy-MM-dd";
		 
        SimpleDateFormat accessCodeDateFmt = new SimpleDateFormat(ACCESSCODE_DOB_DATE_FORMAT);
	
        Date userDOB = maskedBillingDateFmt.parse(user.getDateOfBirth());
        	
        	
        String accessCodeDOB = accessCodeDateFmt.format(userDOB);
    	
		HashMap<String, String> groupAdminUser = new HashMap<String, String>();
		
		groupAdminUser.put("STREET", user.getStreet());
		
		groupAdminUser.put("RPN",this.rpn);
		
		groupAdminUser.put("APPLICATIONID",this.applicationID);
		
		
		groupAdminUser.put("ADDRESSLINE2", user.getAddressLine2());
		
		groupAdminUser.put("CITY", user.getCity());
		
		groupAdminUser.put("COUNTRY", user.getCountry());
				
		groupAdminUser.put("DATEOFBIRTH", accessCodeDOB);
		
	
		groupAdminUser.put("TELEPHONEEXT", user.getTelephoneExt());
		
		groupAdminUser.put("FAX", user.getFax());
		
		
		groupAdminUser.put("GIVENNAME", user.getGivenName());
		
		
		groupAdminUser.put("GROUPNAME", user.getGroupName());
		
		
		groupAdminUser.put("GROUPNUMBERSTRIPPED", user.getGroupNumberStripped());
		
		
		groupAdminUser.put("LASTNAME", user.getLastName());
		
		
		groupAdminUser.put("MIDDLEINI", user.getMiddleIni());
		
		
		groupAdminUser.put("TELEPHONENUMBER", user.getTelephoneNumber());
		
		
		groupAdminUser.put("LAST6SSN", user.getLast6SSN());
		
		
		groupAdminUser.put("STATE", user.getState());
		
		
		groupAdminUser.put("SUFFIX", user.getSuffix());
		
		
		groupAdminUser.put("CITY", user.getCity());
		
		groupAdminUser.put("COUNTRY", user.getCountry());
		
		
		groupAdminUser.put("STREET", user.getStreet());
		
		groupAdminUser.put("ADDRESSLINE2", user.getAddressLine2());
		
		groupAdminUser.put("POSTALCODE", user.getPostalCode());
			
		
		ServicesAccessCodeRequestDAOImpl accessCodeRequest = new ServicesAccessCodeRequestDAOImpl();
		accessCode = accessCodeRequest.requestNewAccessCode(groupAdminUser);
	
		return accessCode;
	}

	/**
	 * This sets the parameters that are sent to Webpack for adding a user to
	 * RULEs.
	 * 
	 * @param user
	 *            the user to be added to rules
	 * @throws ParseException
	 *             if the passed date of birth is not in the expected format
	 *             (mm/dd/yyyy).
	 */
	//OLD AND NOT USED
//	private WebpackRequest getAccessCodeRequest(GroupAdminUserDTO user)
//			throws ParseException {
//
//		WebpackRequest wpRequest = new WebpackRequest(this.appServerHost,
//				this.appServerPortInt);
//
//		Hashtable requestParams = new Hashtable();
//
//		requestParams.put("addressLine1", user.getStreet());
//		requestParams.put("addressLine2", user.getAddressLine2());
//		requestParams.put("applicationId", this.applicationID);
//		requestParams.put("city", user.getCity());
//		requestParams.put("countryCode", user.getCountry());
//
//		Date dob = this.appDateFormat.parse(user.getDateOfBirth());
//		requestParams.put("dob", this.mfDateFormat.format(dob));
//
//		requestParams.put("extension", user.getTelephoneExt());
//		requestParams.put("faxNumber", user.getFax());
//		requestParams.put("firstName", user.getGivenName());
//		requestParams.put("groupName", user.getGroupName());
//		requestParams.put("groupNumber", user.getGroupNumberStripped());
//		requestParams.put("lastName", user.getLastName());
//		requestParams.put("middleIni", user.getMiddleIni());
//		requestParams.put("phoneNumber", user.getTelephoneNumber());
//		requestParams.put("ssn", user.getLast6SSN());
//		requestParams.put("state", user.getState());
//		requestParams.put("suffix", user.getSuffix());
//
//		String postalCode = user.getPostalCode();
//		if (postalCode.length() <= 5) {
//			requestParams.put("zip5", postalCode);
//			requestParams.put("zip4", "");
//		} else {
//			requestParams.put("zip5", postalCode.substring(0, 5));
//			requestParams.put("zip4", postalCode.substring(5));
//		}
//
//		if (this.racfID != null) {
//			requestParams.put("RACFID", this.racfID);
//		}
//		if (this.racfPassword != null) {
//			requestParams.put("RACFPassword", this.racfPassword);
//		}
//		if (this.region != null) {
//			requestParams.put("Region", this.region);
//		}
//
//		wpRequest.setParams(requestParams);
//
//		StringBuffer processId = new StringBuffer(32);
//		processId.append("RDAT/").append(this.rpn).append("/885/ACCESSID/D");
//		wpRequest.setRequiredArguments(RulesProcessor.TASKNAME,
//				processId.toString(), "getAccessCode()");
//
//		return wpRequest;
//	}
/*
	private String getErrorMessage(Hashtable result) {
		String returnString = null;
		String generalErrorMessage = "A general error occurred, most likely a timeout on the Enterprise Server. Try again later or contact help desk.";

		if (result == null) {
			RulesProcessor.logger
					.error("Result to analyze (from webpack) is NULL.");
			returnString = generalErrorMessage;
		} else {
			String status = (String) result.get("Status");
			// Check for the NOT SUCCESS status in the result obtained from
			// webpack.
			if (com.bcbssc.struts.common.CommonUtils
					.isNotNullAndNotEmpty(status)
					&& !"SUCCESS".equals(status)) {
				String eesmMessage = (String) result.get("Message");
				RulesProcessor.logger
						.error("eesm Message from the Enterprise server: "
								+ eesmMessage);
				if (com.bcbssc.struts.common.CommonUtils
						.isNotNullAndNotEmpty(eesmMessage)) {
					returnString = eesmMessage;
				} else {
					returnString = generalErrorMessage;
				}
			} else {
				Exception ex = (Exception) result.get(Constants.EXCEPTION);
				// check for exception caught when running the request and this
				// conditions becomes true when error condition is generated
				// from webpack.
				if (ex != null) {
					RulesProcessor.logger
							.error("Result in analyzeWebpackResult()::getErrorMessage()::result: "
									+ result);
					RulesProcessor.logger
							.error(
									"Exception in analyzeWebpackResult()::getErrorMessage()::ex: ",
									ex);

					// from WebpackTaskManager.java - convert Exception thrown
					// trying to parse Webpack timeout response:
					// java.lang.Exception: Error Occurred while parsing return
					// XML: Content is not allowed in prolog.
					// XML: ExecIP=
					// Status=ExecExpired
					// TaskID=s9ee1835
					// OutHTML=
					// OutMsg=There is a problem with the host connection while
					// processing the brow
					String errorMessage = ex.getMessage();
					RulesProcessor.logger
							.error("ErrorMessage in analyzeWebpackResult()::getErrorMessage()::errorMessage: "
									+ errorMessage);

					if (com.bcbssc.struts.common.CommonUtils
							.isNotNullAndNotEmpty(errorMessage)) {
						if ((errorMessage.indexOf("ExecIP") != -1)
								&& (errorMessage.indexOf("Status") != -1)) {
							returnString = generalErrorMessage;
						} else if (errorMessage
								.indexOf("the root element must be well-formed") != -1) {
							returnString = "CICS Region may be down or may be a timeout on the Enterprise Server. Try again later or contact help desk.";
						} else {
							returnString = errorMessage;
						}
					} else {
						String developerErrorMessage = (String) result
								.get("Message");
						RulesProcessor.logger.error("developerErrorMessage : "
								+ developerErrorMessage);
						if (com.bcbssc.struts.common.CommonUtils
								.isNotNullAndNotEmpty(developerErrorMessage)) {
							returnString = developerErrorMessage;
						} else {
							returnString = generalErrorMessage;
						}
					}
				}
			}
		}
		return returnString;
	}
	*/
	/**
	 * General test method for this class
	 *
	 * @param inArgs
	 *            command-line arguments
	 */
	public static void main(String[] inArgs) {
		String configPath = "D:\\Netscape\\GroupAdmin\\Clife\\config\\";
		String strAppIni = "D:\\Netscape\\GroupAdmin\\Clife\\config\\CGA.ini";

		/*
		 * Load and configure log4j using the log4j properties file. This also
		 * tests that we have the classpath setup to include ETKS/config
		 */
		String logPropertyFileResource = configPath
				+ com.bcbssc.registration.common.Constants.LOG4J_PROPERTIES_FILENAME;

		DOMConfigurator.configure(logPropertyFileResource);

		try {
			RulesProcessor rulesProcessor = new RulesProcessor(strAppIni);
			
			GroupAdminUserDTO user = new GroupAdminUserDTO();
			user.setMiddleIni("");
			user.setGivenName("TEST01");
			user.setSuffix("");
			user.setTelephoneExt("");
			user.setGroupNumber("1234567890");
			user.setPostalCode("23456");
			user.setState("TX");
			user.setGroupName("TESTING NAME");
			user.setMail("t@t.com");
			user.setLastName("TESTING01");
			user.setDateOfBirth("01/01/1998");
			user.setTelephoneNumber("8031234567");
			user.setStreet("TESTING LANE");
			user.setCountry("AL");
			user.setCity("COLUMBIA");
			user.setAddressLine2("");
			user.setLast6SSN("222222");
			user.setFax("");
			user.setSamAccountName("test0902");
			user.setDateOfAcceptance("Wed, 01 Sep 2004 22:09:04 GMT");
			user
					.setChallenge("What is the name of the elementary school you attended?");
			user.setChallengeResponse("mom");

			rulesProcessor.requestNewAccessCode(user);
			
			

		} catch (Exception eException) {
			RulesProcessor.logger.error(
					"Error occured while trying to test webpack rules add: ",
					eException);
			eException.printStackTrace();
		}
	}
}
