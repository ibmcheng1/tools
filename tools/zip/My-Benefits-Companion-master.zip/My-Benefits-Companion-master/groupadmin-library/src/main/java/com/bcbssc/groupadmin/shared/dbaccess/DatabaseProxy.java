/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/DatabaseProxy.java_v  $
 * $Workfile:   DatabaseProxy.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:12  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/DatabaseProxy.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:14:12   EN80
 * Initial revision.
 * 
 *    Rev 1.7   Apr 28 2009 10:17:56   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.6   Feb 15 2005 15:10:22   rxg97
 * Moved getDateBean logic into CommonUtils.
 * 
 *    Rev 1.5   Jan 31 2005 16:17:24   rdq70
 * Added dbFormat.
 *
 *    Rev 1.4   Jan 27 2005 09:41:30   rdq70
 * Added bounds checking to getDateBan().
 *
 *    Rev 1.3   Jan 26 2005 18:22:58   rdq70
 * Added getDateBean().
 *
 *    Rev 1.2   Jan 26 2005 10:03:14   rdq70
 * BlueHammur changes.
 *
 *    Rev 1.1   Jan 26 2005 09:25:34   rdq70
 * Removed extraneous imports.
 *
 *    Rev 1.0   Sep 12 2004 15:17:26   rxg97
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.dbaccess;

import java.sql.SQLException;
import java.text.SimpleDateFormat;

import javax.naming.NamingException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.netsys.Config;
import com.bcbssc.netsys.util.AbstractDatabaseProxy;
import com.bcbssc.struts.common.DateBean;

/**
 * An abstract database proxy which can be configured with an INI file, using
 * the <code>SqlUtil</code> class.
 *
 * @author rxg97 (Jonathan Egger)
 * @see com.bcbssc.groupadmin.shared.dbaccess.SqlUtil
 * @version $Id: $Id
 */
public abstract class DatabaseProxy extends AbstractDatabaseProxy {

	/** The log4j logger for this class. */
	private static final Logger log = Logger.getLogger(DatabaseProxy.class);

	/** The date format used by the database. */
	protected final SimpleDateFormat dbFormat = new SimpleDateFormat(
			"yyyy-MM-dd");

	/** The iniFile from which to configure this proxy. */
	protected String iniFile;

	/** The name of the INI parameter that specifies the database schema name. */
	protected String qualParam;

	/** Flag indicating if we have initialized the connection before. */
	protected boolean initialized = false;

	/**
	 * Creates a new DatabaseProxy using the specified INI file.
	 *
	 * @param iniFile
	 *            path to the INI file with which this proxy will be configured.
	 * @param qualParam
	 *            the name of the qualifier parameter in the INI file.
	 */
	public DatabaseProxy(String iniFile, String qualParam) {
		this.iniFile = iniFile;
		this.qualParam = qualParam;
	}

	/**
	 * Creates a connection using data specified in the INI file.
	 *
	 * @throws BeansException if SqlUtil cannot find bean.
	 * @throws java.sql.SQLException
	 *             if an error occurs opening the connection.
	 */
	protected void initConnection() throws SQLException {
		//SqlUtil.readConfig(this.iniFile);
		this._dbSchema = Config.getPrivateProfileString("SQL", this.qualParam,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);
		DatabaseProxy.log.debug("Opening connection to " + this._dbSchema);
		try {
			this._conn = SqlUtil.getConnection();
		} catch (NamingException e) {
			if(log.isTraceEnabled()){
				log.log(Level.TRACE, e.getClass() + e.getMessage());
				throw new SQLException(e.getMessage());
			}
		}
		this.initialized = true;
	}

	/**
	 * Closes the database connection.
	 */
	public void disconnect() {
		this.initialized = false;
		super.disconnect();
	}

	/**
	 * Calls <code>initConnection()</code> but traps the
	 * <code>ClassNotFoundException</code>.
	 *
	 * @throws java.sql.SQLException
	 *             if <code>initConnection()</code> cannot load the driver or
	 *             if it throws an <code>java.sql.SQLException</code> itself.
	 */
	protected void selfInit() throws SQLException {
		try {
			this.initConnection();
		} catch (BeansException be) {
			throw new SQLException(
					"Unable to connect, jdbc.datasource bean not read from XML file: "
							+ be.toString());
		}
	}

	/**
	 * Checks to see if already initialized and, if not, calls
	 * <code>selfInit()</code>.
	 *
	 * @throws java.sql.SQLException
	 *             if <code>selfInit()</code> throws one.
	 * @see #selfInit
	 */
	protected void checkInit() throws SQLException {
		if (!this.initialized) {
			this.selfInit();
		}
	}

	/**
	 * Creates a date bean from a string.
	 *
	 * @param dateStr
	 *            a string of the form MM.dd.yyyy, where '.' is any character.
	 *            If less than 10 characters, no fields will be set on the bean.
	 *            Characters after the 10th position are ignored.
	 * @return a new date bean.
	 */
	protected static final DateBean getDateBean(String dateStr) {
		return CommonUtils.getDateBean(dateStr);
	}
}
