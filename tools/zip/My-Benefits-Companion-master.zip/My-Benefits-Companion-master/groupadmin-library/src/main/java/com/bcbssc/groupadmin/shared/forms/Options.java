/*
 * Options.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * Created on January 11, 2005, 1:50 PM
 */

package com.bcbssc.groupadmin.shared.forms;

import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.groupadmin.shared.dto.Dependent;

import java.util.List;
import java.util.ArrayList;
import org.apache.struts.util.LabelValueBean;

/**
 * <p>Options class.</p>
 *
 * @author  jegger
 * @version $Id: $Id
 */
public class Options extends com.bcbssc.struts.forms.Options {

    private static Options uniqueInstance = new Options();

    /** Constant <code>RELATIONSHIP_OPTIONS</code> */
    public static final String [][] RELATIONSHIP_OPTIONS =
        {{"-- Please Choose One --",""},
         {"Child",           Dependent.RELATIONSHIP_CHILD},
         {"Spouse",          Dependent.RELATIONSHIP_SPOUSE},
         {"Domestic Partner",Dependent.RELATIONSHIP_PARTNER},
         {"Other",           Dependent.RELATIONSHIP_OTHER}};

    /** Constant <code>STATUS_OPTIONS</code> */
    public static final String [][] STATUS_OPTIONS = {
        {"",                 ""},
        {"Active",           Constants.STATUS_ACTIVE},
        {"Conversion",       Constants.STATUS_CONVERSION},
        {"Pended",           Constants.STATUS_PENDED},
        {"Terminated",       Constants.STATUS_INACTIVE}
        };

    /** employee search status labels and values */
    public static final String [] STATUS_ACTIVE     = {"Active",
                                                       Constants.STATUS_ACTIVE};
    /** Constant <code>STATUS_TERMINATED</code> */
    public static final String [] STATUS_TERMINATED = {"Terminated",
                                                       Constants.STATUS_INACTIVE};
    /** Constant <code>STATUS_ALL</code> */
    public static final String [] STATUS_ALL        = {"All",
                                                       Constants.STATUS_ALL};

    /** yes/no option labels and values */
    private static final String [] YES_OPTION = {"Yes","S"};
    private static final String [] NO_OPTION  = {"No","N"};


    /** termination reason labels and values */
    private static final String [] TERM_CANCELLED = {"Cancelled","X"};
    private static final String [] TERM_DEATH     = {"Death","D"};
    private static final String [] TERM_ENDED     = {"Employment Ended","E"};
    private static final String [] TERM_LAPSE     = {"Policy Lapse", "L"};

    /** billed status */
    public static final String [] BILL_BILLED     = {"Billed", Constants.BILL_BILLED};
    /** Constant <code>BILL_PARTIAL</code> */
    public static final String [] BILL_PARTIAL     = {"Partial", Constants.BILL_PARTIAL};
    /** Constant <code>BILL_NOT_CLEARED</code> */
    public static final String [] BILL_NOT_CLEARED     = {"Not Cleared", Constants.BILL_NOT_CLEARED};
    /** Constant <code>BILL_PAID</code> */
    public static final String [] BILL_PAID     = {"Paid", Constants.BILL_PAID};


        /** Pay Period labels and values **/
    private static final String [] PAY_WEEKLY =  {"Weekly", Constants.PAY_PERIOD_WEEKLY};
    private static final String [] PAY_BI_WEEKLY     = {"Bi-Weekly", Constants.PAY_PERIOD_BI_WEEKLY};
    private static final String [] PAY_SEMI_MONTHLY     = {"Semi-Monthly", Constants.PAY_PERIOD_SEMI_MONTHLY};
    private static final String [] PAY_MONTHLY     = {"Monthly", Constants.PAY_PERIOD_MONTHLY};


        /** Product Labels and Values **/
    private static final String [] PRDT_LIFE     = {"Voluntary Life", Constants.PRODUCT_LIFE};
    private static final String [] PRDT_DENTAL     = {"Voluntary Dental", Constants.PRODUCT_DENTAL};
    private static final String [] PRDT_VISION     = {"Voluntary Vision", Constants.PRODUCT_VISION};
    private static final String [] PRDT_STD     = {"Voluntary Short Term Disability", Constants.PRODUCT_STD};
    private static final String [] PRDT_LTD     = {"Voluntary Long Term Disability", Constants.PRODUCT_LTD};
    private static final String [] PRDT_VOLUNTARY     = {"Total Voluntary Products", Constants.PRODUCT_VOLUNTARY};


        /** Product Labels and Values **/
    private static final String [] BILL_CURRENT     = {"Current Bill", "C"};
    private static final String [] BILL_REBILL     = {"Re-Bill", "R"};
    private static final String [] BILL_NEXTBILL     = {"Next Bill", "N"};

	/** Request a change options **/
    private static final String[] CHANGE_COVERAGE_OPTION = {"Change Coverage","change-mem-coverage"};
	private static final String[] TERMINATE_MEMBER_OPTION = {"Terminate Member","term-mem"};
	private static final String[] CHANGE_DEPENDENT_COVERAGE = {"Change Dependent Coverage","change-dep-cov"};
	private static final String[] CHANGE_DEPENDENT_INFO = {"Change Dependent Information","change-dep-info"};
	private static final String[] TERMINATE_DEPENDENT = {"Terminate Dependent","term-dep"};
	private static final String[] REINSTATE_MEMBER = {"Reinstate Member","reinstate-mem"};




    /**
     * <p>getGroupAdminInstance.</p>
     *
     * @return a {@link com.bcbssc.groupadmin.shared.forms.Options} object.
     */
    public static Options getGroupAdminInstance() {
        return uniqueInstance;
    }

    /**
     * Creates a relationship options list
     *
     * @return relationship options list
     */
    public List getRelationshipOptions() {
        ArrayList relationshipOptionsList = new ArrayList();

        for (int i = 0; i < RELATIONSHIP_OPTIONS.length; i++) {
            relationshipOptionsList.add(new LabelValueBean(RELATIONSHIP_OPTIONS[i][LABEL_INDEX],
                                                           RELATIONSHIP_OPTIONS[i][VALUE_INDEX]));
        }

        return relationshipOptionsList;
    }

    /**
     * Creates a status options list
     *
     * @return relationship options list
     */
    public List getStatusOptions() {
        ArrayList statusOptionsList = new ArrayList();

        for (int i = 0; i < STATUS_OPTIONS.length; i++) {
            statusOptionsList.add(new LabelValueBean(STATUS_OPTIONS[i][LABEL_INDEX],
                                                           STATUS_OPTIONS[i][VALUE_INDEX]));
        }

        return statusOptionsList;
    }



	/**
	 * <p>getRequestaChangeOptions.</p>
	 *
	 * @return a {@link java.util.List} object.
	 */
	public List getRequestaChangeOptions() {

		ArrayList requestaChangeOptions = new ArrayList();
		requestaChangeOptions.add(new LabelValueBean("--Please Choose One--",
				Constants.BLANK_STRING));
		requestaChangeOptions.add(new LabelValueBean(
				Options.CHANGE_COVERAGE_OPTION[Options.LABEL_INDEX],
				Options.CHANGE_COVERAGE_OPTION[Options.VALUE_INDEX]));

		requestaChangeOptions.add(new LabelValueBean(
				Options.TERMINATE_MEMBER_OPTION[Options.LABEL_INDEX],
				Options.TERMINATE_MEMBER_OPTION[Options.VALUE_INDEX]));
		return requestaChangeOptions;

	}
	
	
	/**
	 * <p>getRequestaChangeWithDependentOptions.</p>
	 *
	 * @return a {@link java.util.List} object.
	 */
	public List getRequestaChangeWithDependentOptions() {

		ArrayList requestaChangeWithDependentOptions = new ArrayList();
		requestaChangeWithDependentOptions.add(new LabelValueBean("--Please Choose One--",
				Constants.BLANK_STRING));
		requestaChangeWithDependentOptions.add(new LabelValueBean(
				Options.CHANGE_COVERAGE_OPTION[Options.LABEL_INDEX],
				Options.CHANGE_COVERAGE_OPTION[Options.VALUE_INDEX]));

		requestaChangeWithDependentOptions.add(new LabelValueBean(
				Options.TERMINATE_MEMBER_OPTION[Options.LABEL_INDEX],
				Options.TERMINATE_MEMBER_OPTION[Options.VALUE_INDEX]));

		requestaChangeWithDependentOptions.add(new LabelValueBean(
				Options.CHANGE_DEPENDENT_COVERAGE[Options.LABEL_INDEX],
				Options.CHANGE_DEPENDENT_COVERAGE[Options.VALUE_INDEX]));

		requestaChangeWithDependentOptions.add(new LabelValueBean(
				Options.CHANGE_DEPENDENT_INFO[Options.LABEL_INDEX],
				Options.CHANGE_DEPENDENT_INFO[Options.VALUE_INDEX]));

		requestaChangeWithDependentOptions.add(new LabelValueBean(
				Options.TERMINATE_DEPENDENT[Options.LABEL_INDEX],
				Options.TERMINATE_DEPENDENT[Options.VALUE_INDEX]));

		return requestaChangeWithDependentOptions;

	}
	
	
	
	
	/**
	 * <p>getRequestaAllOptions.</p>
	 *
	 * @return a {@link java.util.List} object.
	 */
	public List getRequestaAllOptions() {

		ArrayList requestaAllOptions = new ArrayList();
		requestaAllOptions.add(new LabelValueBean("--Please Choose One--",
				Constants.BLANK_STRING));
		requestaAllOptions.add(new LabelValueBean(
				Options.CHANGE_COVERAGE_OPTION[Options.LABEL_INDEX],
				Options.CHANGE_COVERAGE_OPTION[Options.VALUE_INDEX]));

		requestaAllOptions.add(new LabelValueBean(
				Options.TERMINATE_MEMBER_OPTION[Options.LABEL_INDEX],
				Options.TERMINATE_MEMBER_OPTION[Options.VALUE_INDEX]));

		requestaAllOptions.add(new LabelValueBean(
				Options.CHANGE_DEPENDENT_COVERAGE[Options.LABEL_INDEX],
				Options.CHANGE_DEPENDENT_COVERAGE[Options.VALUE_INDEX]));

		requestaAllOptions.add(new LabelValueBean(
				Options.CHANGE_DEPENDENT_INFO[Options.LABEL_INDEX],
				Options.CHANGE_DEPENDENT_INFO[Options.VALUE_INDEX]));

		requestaAllOptions.add(new LabelValueBean(
				Options.TERMINATE_DEPENDENT[Options.LABEL_INDEX],
				Options.TERMINATE_DEPENDENT[Options.VALUE_INDEX]));
	    requestaAllOptions.add(new LabelValueBean(
				Options.REINSTATE_MEMBER[Options.LABEL_INDEX],
				Options.REINSTATE_MEMBER[Options.VALUE_INDEX]));

		return requestaAllOptions;

	}
	
	
	
	
	
	/**
	 * <p>getRequestaChangeReinstateOptions.</p>
	 *
	 * @return a {@link java.util.List} object.
	 */
	public List getRequestaChangeReinstateOptions() {

		ArrayList requestaChangeReinstateOptions = new ArrayList();
		requestaChangeReinstateOptions.add(new LabelValueBean("--Please Choose One--",
				Constants.BLANK_STRING));
		requestaChangeReinstateOptions.add(new LabelValueBean(
				Options.REINSTATE_MEMBER[Options.LABEL_INDEX],
				Options.REINSTATE_MEMBER[Options.VALUE_INDEX]));

		return requestaChangeReinstateOptions;

	}




    /**
     * Creates employee search status options
     *
     * @return List of employee search status options
     */
    public List getEmployeeStatusOptions() {
        ArrayList statusOptions = new ArrayList();
        statusOptions.add(new LabelValueBean(STATUS_ACTIVE[LABEL_INDEX],
                                             STATUS_ACTIVE[VALUE_INDEX]));
        statusOptions.add(new LabelValueBean(STATUS_TERMINATED[LABEL_INDEX],
                                             STATUS_TERMINATED[VALUE_INDEX]));
        statusOptions.add(new LabelValueBean(STATUS_ALL[LABEL_INDEX],
                                             STATUS_ALL[VALUE_INDEX]));
        return statusOptions;
    }

    /**
     * Creates termination reason options
     *
     * @return List of termination reason options
     */
    public List getTerminationReasonOptions() {
        ArrayList reasonOptions = new ArrayList();
        reasonOptions.add(new LabelValueBean(TERM_CANCELLED[LABEL_INDEX],
                                             TERM_CANCELLED[VALUE_INDEX]));
        reasonOptions.add(new LabelValueBean(TERM_DEATH[LABEL_INDEX],
                                             TERM_DEATH[VALUE_INDEX]));
        reasonOptions.add(new LabelValueBean(TERM_ENDED[LABEL_INDEX],
                                             TERM_ENDED[VALUE_INDEX]));
        reasonOptions.add(new LabelValueBean(TERM_LAPSE[LABEL_INDEX],
                                             TERM_LAPSE[VALUE_INDEX]));
        return reasonOptions;
    }

    /**
     * Creates bill status options
     *
     * @return List of bill status options
     */
    public List getBillStatusOptions() {
        ArrayList reasonOptions = new ArrayList();
        reasonOptions.add(new LabelValueBean(BILL_BILLED[LABEL_INDEX],
                                             BILL_BILLED[VALUE_INDEX]));
        reasonOptions.add(new LabelValueBean(BILL_PARTIAL[LABEL_INDEX],
                                             BILL_PARTIAL[VALUE_INDEX]));
        reasonOptions.add(new LabelValueBean(BILL_NOT_CLEARED[LABEL_INDEX],
                                             BILL_NOT_CLEARED[VALUE_INDEX]));
        reasonOptions.add(new LabelValueBean(BILL_PAID[LABEL_INDEX],
                                             BILL_PAID[VALUE_INDEX]));
        return reasonOptions;
    }

    /**
     * Creates Pay Period Options
     *
     * @return List of pay period options
     */
    public List getPayPeriodOptions() {
        ArrayList payPeriodOptions = new ArrayList();
        payPeriodOptions.add(new LabelValueBean(PAY_WEEKLY[LABEL_INDEX],
                                             PAY_WEEKLY[VALUE_INDEX]));
        payPeriodOptions.add(new LabelValueBean(PAY_BI_WEEKLY[LABEL_INDEX],
                                             PAY_BI_WEEKLY[VALUE_INDEX]));
        payPeriodOptions.add(new LabelValueBean(PAY_SEMI_MONTHLY[LABEL_INDEX],
                                             PAY_SEMI_MONTHLY[VALUE_INDEX]));
        payPeriodOptions.add(new LabelValueBean(PAY_MONTHLY[LABEL_INDEX],
                                             PAY_MONTHLY[VALUE_INDEX]));
        return payPeriodOptions;
    }

    /**
     * Creates Options for the Product
     *
     * @return List of Product options
     */
    public List getProductOptions() {
        ArrayList productOptions = new ArrayList();
        productOptions.add(new LabelValueBean(PRDT_LIFE[LABEL_INDEX],
                                             PRDT_LIFE[VALUE_INDEX]));
        productOptions.add(new LabelValueBean(PRDT_DENTAL[LABEL_INDEX],
                                             PRDT_DENTAL[VALUE_INDEX]));
        productOptions.add(new LabelValueBean(PRDT_VISION[LABEL_INDEX],
                                             PRDT_VISION[VALUE_INDEX]));
        productOptions.add(new LabelValueBean(PRDT_STD[LABEL_INDEX],
                                             PRDT_STD[VALUE_INDEX]));
        productOptions.add(new LabelValueBean(PRDT_LTD[LABEL_INDEX],
                                             PRDT_LTD[VALUE_INDEX]));
        productOptions.add(new LabelValueBean(PRDT_VOLUNTARY[LABEL_INDEX],
                                             PRDT_VOLUNTARY[VALUE_INDEX]));
        return productOptions;
    }

    /**
     * Creates Options for the Bill Type
     *
     * @return List of Bill Type options
     */
    public List getBillTypeOptions() {
        ArrayList billTypeOptions = new ArrayList();
        billTypeOptions.add(new LabelValueBean("-- Please Choose One --",
                                             ""));
        billTypeOptions.add(new LabelValueBean(BILL_CURRENT[LABEL_INDEX],
                                             BILL_CURRENT[VALUE_INDEX]));
        billTypeOptions.add(new LabelValueBean(BILL_REBILL[LABEL_INDEX],
                                             BILL_REBILL[VALUE_INDEX]));
        billTypeOptions.add(new LabelValueBean(BILL_NEXTBILL[LABEL_INDEX],
                                             BILL_NEXTBILL[VALUE_INDEX]));
        return billTypeOptions;
    }

    /**
     * Creates a simple blank/no/yes options list
     *
     * @return yes/no options list
     */
    public List getPleaseChooseOneNoYesOptions() {
        ArrayList yesNoOptions = new ArrayList();
        yesNoOptions.add(new LabelValueBean("-- Please Choose One --", ""));
        yesNoOptions.add(new LabelValueBean(NO_OPTION[LABEL_INDEX], NO_OPTION[VALUE_INDEX]));
        yesNoOptions.add(new LabelValueBean(YES_OPTION[LABEL_INDEX], YES_OPTION[VALUE_INDEX]));
        return yesNoOptions;
    }

}
