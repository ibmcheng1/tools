/*
 * @(#)CodeRequestForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.forms;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.dbaccess.DatabaseDropdowns;
import com.bcbssc.netsys.Config;
import com.bcbssc.struts.common.PhoneNumber;
import com.bcbssc.struts.forms.Options;

import java.sql.SQLException;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;

/**
 * Group Administrator Access Code Request Form
 *
 * This bean is used to transport data for the access code request form. This
 * class is used in place of the DynaValidatorForm because it provides the
 * dynamic dropdown (country list) on the form requires a traditional bean get
 * method which the DynaValidatorForm won't support.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class CodeRequestForm extends org.apache.struts.validator.ValidatorForm {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /** second line of address */
    private String addressLine2 = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** city name */
    private String city = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** country name */
    private String country = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** date of birth */
    private String dateOfBirth = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** day of dob */
    private String dobDay = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** month of dob */
    private String dobMonth = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** year of dob */
    private String dobYear = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** fax number */
    private PhoneNumber fax = PhoneNumber.blank();

    /** first name */
    private String givenName = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** group name */
    private String groupName = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** group number parts */
    private String groupNumberParts0 = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** group number parts */
    private String groupNumberParts1 = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** group number parts */
    private String groupNumberParts2 = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** group number parts */
    private String groupNumberParts3 = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** group number, complete */
    private String groupNumber = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** last 6 digits of social security number */
    private String last6SSN = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** last name */
    private String lastName = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** middle initial */
    private String middleIni = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** postal code */
    private String postalCode = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** state name */
    private String state = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** first line of address */
    private String street = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** suffix of name */
    private String suffix = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** telephone extension */
    private String telephoneExt = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** telephone number */
    private PhoneNumber telephoneNumber = PhoneNumber.blank();

    /** selectedState name */
    private String selectedState = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** selectedCountry name */
    private String selectedCountry = com.bcbssc.struts.common.Constants.BLANK_STRING;

    private String mail            = com.bcbssc.struts.common.Constants.BLANK_STRING;

    /** selectedApplication name */
    private String applicationId;

    /**
     * Default constructor; calls parent constructor. Called when form object is
     * needed during normal Structs processing.
     */
    public CodeRequestForm() {
        super();
    }

    /**
     * Special constructor. Called by action classes that explicitly require an
     * object of this type. This object must be passed the servlet object of the
     * calling action so that the servlet context will be available when needed.
     *
     * @param servlet
     *            servlet associated with this object
     */
    public CodeRequestForm(ActionServlet servlet) {
        this.setServlet(servlet);
    }

    /**
     * Sets the last 6 digits of social security number
     *
     * @param value
     *            last 6 digits of social security number
     */
    public void setLast6SSN(String value) {
        this.last6SSN = value;
    }

    /**
     * Gets the last 6 digits of social security number
     *
     * @return last 6 digits of social security number
     */
    public String getLast6SSN() {
        return this.last6SSN;
    }

    /**
     * Sets the last name
     *
     * @param value a {@link java.lang.String} object.
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Gets the last name
     *
     * @return last name
     */
    public String getLastName() {
        return this.lastName;
    }

    /**
     * Sets the group name
     *
     * @param value
     *            group name
     */
    public void setGroupName(String value) {
        this.groupName = value;
    }

    /**
     * Gets the group name
     *
     * @return group name
     */
    public String getGroupName() {
        return this.groupName;
    }

    /**
     * Gets the group number
     *
     * @return group number
     */
    public String getGroupNumber() {
        return this.groupNumber;
    }

    /**
     * Sets the group number
     *
     * @param value
     *            group number
     */
    public void setGroupNumber(String value) {
        this.groupNumber = value;
    }

    /**
     * Sets the first name
     *
     * @return first name
     */
    public String getGivenName() {
        return this.givenName;
    }

    /**
     * Gets the first name
     *
     * @param value
     *            first name
     */
    public void setGivenName(String value) {
        this.givenName = value;
    }

    /**
     * Sets the middle initial
     *
     * @param value
     *            middle initial
     */
    public void setMiddleIni(String value) {
        this.middleIni = value;
    }

    /**
     * Gets the middle initial
     *
     * @return middle initial
     */
    public String getMiddleIni() {
        return this.middleIni;
    }

    /**
     * Sets the suffix of name
     *
     * @param value
     *            suffix of name
     */
    public void setSuffix(String value) {
        this.suffix = value;
    }

    /**
     * Gets the suffix of name
     *
     * @return suffix of name
     */
    public String getSuffix() {
        return this.suffix;
    }

    /**
     * Sets the month of dob
     *
     * @param value
     *            month of dob
     */
    public void setDobMonth(String value) {
        this.dobMonth = value;
    }

    /**
     * Gets the month of dob
     *
     * @return month of dob
     */
    public String getDobMonth() {
        return this.dobMonth;
    }

    /**
     * Gets the day of dob
     *
     * @return day of dob
     */
    public String getDobDay() {
        return this.dobDay;
    }

    /**
     * Sets the day of dob
     *
     * @param value
     *            day of dob
     */
    public void setDobDay(String value) {
        this.dobDay = value;
    }

    /**
     * Gets the year of dob
     *
     * @return year of dob
     */
    public String getDobYear() {
        return this.dobYear;
    }

    /**
     * Sets the year of dob
     *
     * @param value
     *            year of dob
     */
    public void setDobYear(String value) {
        this.dobYear = value;
    }

    /**
     * Gets the date of birth
     *
     * @return date of birth
     */
    public String getDateOfBirth() {
        return this.dateOfBirth;
    }

    /**
     * Sets the date of birth
     *
     * @param value
     *            date of birth
     */
    public void setDateOfBirth(String value) {
        this.dateOfBirth = value;
    }

    /**
     * Gets the first line of address
     *
     * @return first line of address
     */
    public String getStreet() {
        return this.street;
    }

    /**
     * Sets the first line of address
     *
     * @param value
     *            first line of address
     */
    public void setStreet(String value) {
        this.street = value;
    }

    /**
     * Gets the second line of address
     *
     * @return second line of address
     */
    public String getAddressLine2() {
        return this.addressLine2;
    }

    /**
     * Sets the second line of address
     *
     * @param value
     *            second line of address
     */
    public void setAddressLine2(String value) {
        this.addressLine2 = value;
    }

    /**
     * Gets the city name
     *
     * @return city name
     */
    public String getCity() {
        return this.city;
    }

    /**
     * Gets the city name
     *
     * @param value
     *            city name
     */
    public void setCity(String value) {
        this.city = value;
    }

    /**
     * Gets the state name
     *
     * @return state name
     */
    public String getState() {
        return this.state;
    }

    /**
     * Sets the state name
     *
     * @param value
     *            state name
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Gets the postal code
     *
     * @return postal code
     */
    public String getPostalCode() {
        return this.postalCode;
    }

    /**
     * Sets the postal code
     *
     * @param value
     *            postal code
     */
    public void setPostalCode(String value) {
        this.postalCode = value;
    }

    /**
     * Gets the telephone area code
     *
     * @return telephone area code
     */
    public String getTelephoneNumberAreacode() {
        return this.telephoneNumber.getAreacode();
    }

    /**
     * Gets the telephone number prefix
     *
     * @return telephone number prefix
     */
    public String getTelephoneNumberPrefix() {
        return this.telephoneNumber.getPrefix();
    }

    /**
     * Gets the telephone number suffix
     *
     * @return telephone number suffix
     */
    public String getTelephoneNumberSuffix() {
        return this.telephoneNumber.getSuffix();
    }

    /**
     * Gets the telephone extension
     *
     * @return telephone extension
     */
    public String getTelephoneExt() {
        return this.telephoneExt;
    }

    /**
     * Sets the telephone extension
     *
     * @param value
     *            telephone extension
     */
    public void setTelephoneExt(String value) {
        this.telephoneExt = value;
    }

    /**
     * Gets the area code of fax number
     *
     * @return area code of fax number
     */
    public String getFaxAreacode() {
        return this.fax.getAreacode();
    }

    /**
     * Gets the prefix of fax number
     *
     * @return prefix of fax number
     */
    public String getFaxPrefix() {
        return this.fax.getPrefix();
    }

    /**
     * Gets the suffix of fax number
     *
     * @return suffix of fax number
     */
    public String getFaxSuffix() {
        return this.fax.getSuffix();
    }

    /**
     * Gets the telephone number
     *
     * @return telephone number
     */
    public String getTelephoneNumber() {
        return this.telephoneNumber.toString();
    }

    /**
     * Sets the telephone number
     *
     * @param value
     *            telephone number
     */
    public void setTelephoneNumber(String value) {
        this.telephoneNumber.parse(value);
    }

    /**
     * Sets the telephone number area code directly
     *
     * @param value
     *            telephone number area code
     */
    public void setTelephoneNumberAreacode(String value) {
        this.telephoneNumber.setAreacode(value);
    }

    /**
     * Sets the telephone number prefix directly
     *
     * @param value
     *            telephone number prefix
     */
    public void setTelephoneNumberPrefix(String value) {
        this.telephoneNumber.setPrefix(value);
    }

    /**
     * Sets the telephone number suffix directly
     *
     * @param value
     *            telephone number suffix
     */
    public void setTelephoneNumberSuffix(String value) {
        this.telephoneNumber.setSuffix(value);
    }

    /**
     * Gets the fax number
     *
     * @return fax number
     */
    public String getFax() {
        return this.fax.toString();
    }

    /**
     * Sets the fax number
     *
     * @param value
     *            fax number
     */
    public void setFax(String value) {
        this.fax.parse(value);
    }

    /**
     * Sets the fax area code directly
     *
     * @param value
     *            fax area code
     */
    public void setFaxAreacode(String value) {
        this.fax.setAreacode(value);
    }

    /**
     * Sets the fax prefix directly
     *
     * @param value
     *            fax prefix
     */
    public void setFaxPrefix(String value) {
        this.fax.setPrefix(value);
    }

    /**
     * Sets the fax suffix directly
     *
     * @param value
     *            fax suffix
     */
    public void setFaxSuffix(String value) {
        this.fax.setSuffix(value);
    }

    /**
     * Gets the country name
     *
     * @return country name
     */
    public String getCountry() {
        return this.country;
    }

    /**
     * Sets the country name
     *
     * @param value
     *            country name
     */
    public void setCountry(String value) {
        this.country = value;
    }

    /**
     * Gets the countryOptions
     *
     * @return country options
     * @throws java.sql.SQLException if any.
     */
    public Collection getCountryOptions() throws SQLException {

        String iniFile = CommonUtils.getIniFile(this.getServlet()
                .getServletContext());
        DatabaseDropdowns dropdowns = new DatabaseDropdowns(iniFile);
        return dropdowns.getCountryOptions();
    }

    /**
     * Gets the selected state name
     *
     * @return selected state name
     */
    public String getSelectedState() {
        return this.selectedState;
    }

    /**
     * Sets the selected state name
     *
     * @param value
     *            selected state name
     */
    public void setSelectedState(String value) {
        this.selectedState = value;
    }



    /**
     * <p>Getter for the field <code>mail</code>.</p>
     *
     * @return a {@link java.lang.String} object.
     */
    public String getMail() {
        return this.mail;
    }

    /**
     * Sets the selected state name
     *
     * @param value
     *            selected state name
     */
    public void setMail(String value) {
        this.mail = value;
    }

    /**
     * Sets the selected country code
     *
     * @param value
     *            selected country code
     */
    public void setSelectedCountry(String value) {
        this.selectedCountry = value;
    }

    /**
     * Gets the selected country code
     *
     * @return selected country code
     */
    public String getSelectedCountry() {
        return this.selectedCountry;
    }

    /**
     * Returns the unique instance of the Options class.
     *
     * @return the Options instance
     */
    public Options getOptions() {
        return Options.getInstance();
    }

    /**
     * Gets the group number part 0
     *
     * @return group number
     */
    public String getGroupNumberParts0() {
        return this.groupNumberParts0;
    }

    /**
     * Sets the group number part 0
     *
     * @param value
     *            group number
     */
    public void setGroupNumberParts0(String value) {
        this.groupNumberParts0 = value;
    }

    /**
     * Gets the group number part 0
     *
     * @return group number
     */
    public String getGroupNumberParts1() {
        return this.groupNumberParts1;
    }

    /**
     * Sets the group number part 1
     *
     * @param value
     *            group number
     */
    public void setGroupNumberParts1(String value) {
        this.groupNumberParts1 = value;
    }

    /**
     * Gets the group number part 2
     *
     * @return group number
     */
    public String getGroupNumberParts2() {
        return this.groupNumberParts2;
    }

    /**
     * Sets the group number part 2
     *
     * @param value
     *            group number
     */
    public void setGroupNumberParts2(String value) {
        this.groupNumberParts2 = value;
    }

    /**
     * Gets the group number part 3
     *
     * @return group number
     */
    public String getGroupNumberParts3() {
        return this.groupNumberParts3;
    }

    /**
     * Sets the group number part 3
     *
     * @param value
     *            group number
     */
    public void setGroupNumberParts3(String value) {
        this.groupNumberParts3 = value;
    }

    /**
     * Gets the application name
     *
     * @return application name
     */
    public String getApplicationId() {
        String iniFile = CommonUtils.getIniFile(this.getServlet()
                .getServletContext());
        this.applicationId = Config.getPrivateProfileString("MISC", "APP_ID",
                com.bcbssc.struts.common.Constants.BLANK_STRING, iniFile);
        return this.applicationId;
    }

    /**
     * Gets the application name
     *
     * @param value
     *            application name
     */
    public void setApplicationId(String value) {
        this.applicationId = value;
    }

    /**
     * {@inheritDoc}
     *
     * Validates the form using the validator support provided by the parent.
     * Also calls the specialized postalCode validation.
     */
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {
        ActionErrors errors = super.validate(mapping, request);
        String iniFile = CommonUtils.getIniFile(this.getServlet()
                .getServletContext());

        if (errors.size() == 0) {
            String excludeGroupPrefixes = Config.getPrivateProfileString(
                    "MISC", "EXCLUDED_GROUP_PREFIX",
                    com.bcbssc.struts.common.Constants.BLANK_STRING, iniFile);

            String groupnumberprefix = null;
            if (this.getGroupNumber().length() >= 2) {
                groupnumberprefix = this.getGroupNumber().substring(0, 2);
            }

            // Check invalid prefix list
            if ((groupnumberprefix != null)
                    && (excludeGroupPrefixes.indexOf(groupnumberprefix) != -1)) {
                // display sc state heath plan message
                errors.add("groupprefix", new ActionMessage(
                        "errors.excludedprefix"));
            } else {
                // Check valid prefix list
                boolean validprefix = true;
                String allowedGroupPrefixes = Config.getPrivateProfileString(
                        "MISC", "ALLOWED_GROUP_PREFIX",
                        com.bcbssc.struts.common.Constants.BLANK_STRING,
                        iniFile);

                // If no allowed group prefix list exists, allow all
                if (allowedGroupPrefixes.length() > 0) {
                    if (groupnumberprefix == null) {
                        validprefix = false;
                    } else if (allowedGroupPrefixes.indexOf(groupnumberprefix) == -1) {
                        validprefix = false;
                    }
                }

                if (!validprefix) {
                    errors.add("groupprefix", new ActionMessage(
                            "errors.invalidprefix"));
                }
            }
        }

        return errors;
    }
}
