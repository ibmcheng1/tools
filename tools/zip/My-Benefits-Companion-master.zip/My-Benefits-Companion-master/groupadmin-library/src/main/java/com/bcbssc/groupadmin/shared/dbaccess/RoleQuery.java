/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/RoleQuery.java_v  $
 * $Workfile:   RoleQuery.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:22  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/RoleQuery.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:14:22   EN80
 * Initial revision.
 * 
 *    Rev 1.3   Apr 28 2009 10:18:12   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.2   Oct 10 2005 18:24:08   rx08e
 * Changes to support the benefits coordinator
 * 
 *    Rev 1.1   Feb 18 2005 10:33:12   rdq70
 * Replaced new INI parameter with one that already existed.
 *
 *    Rev 1.0   Feb 17 2005 10:31:32   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.dbaccess;

import com.bcbssc.netsys.Config;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Date;

import org.apache.log4j.Logger;

/**
 * This query retrieves a user's role.
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class RoleQuery extends AbstractDBSearch {
	/** The log4j logger for this class. */
	private static final Logger log = Logger.getLogger(RoleQuery.class);

	/** The 10-byte application ID in Rules. */
	private final String applicationId;

	/** The user's role. */
	private String role;

	/** Table name for the query from the ini file */
	private String tableName;

	/** Role code for the table from the Ini file */
	private String webRole;

	/**
	 * Creates an <code>RoleQuery</code> and configures it with an INI file.
	 *
	 * @param iniFile
	 *            file path of the configuration INI file.
	 */
	public RoleQuery(String iniFile) {
		super(iniFile, "RULES_TABLE");

		this.applicationId = Config.getPrivateProfileString("MISC", "APP_ID",
				com.bcbssc.struts.common.Constants.BLANK_STRING, iniFile);

		this.tableName = Config.getPrivateProfileString("SQL",
				"WEB_ROLES_TABLE", "DT_TYP_WEB_ROLES", iniFile);
		this.webRole = Config.getPrivateProfileString("SQL", "WEB_ROLES",
				"WEBROLES", iniFile);

		if (RoleQuery.log.isDebugEnabled()) {
			RoleQuery.log.debug("applicationId=" + this.applicationId);
		}
	}

	/**
	 * Retrieves the role of the specified user.
	 *
	 * @param accessId
	 *            the user's access ID.
	 * @return the user's role.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 */
	public String performSearch(String accessId) throws SQLException {
		this.checkInit(); // Necessary since we need the _dbSchema before the
		// query creation
		if (RoleQuery.log.isDebugEnabled()) {
			RoleQuery.log.debug("accessId=" + accessId);
			RoleQuery.log.debug("applicationId=" + this.applicationId);
		}
		final String date = this.dbFormat.format(new Date());
		final StringBuffer sql = new StringBuffer(256);

		sql.append("SELECT ROLE_CD, WEB_ACCESS_IND FROM ").append(
				this._dbSchema).append(".").append(this.tableName);
		sql.append(" WHERE RP_NO = '001' AND PLAN_CD = '885' AND DATA_TYP = "
				+ "'" + this.webRole + "'");
		sql.append(" AND ACCESS_CD = ? AND APPLICATION_ID = ?");
		sql
				.append(" AND SYS_VOID_STS_IND = 'N' AND DT_TYP_BEG <= ? AND DT_TYP_TRM >= ?");

		final String[] params = { accessId, this.applicationId, date, date };
		RoleQuery.log.debug(sql.toString());
		this.performSearch(sql.toString(), params, Collections.EMPTY_LIST);
		return this.role;
	}

	/**
	 * {@inheritDoc}
	 *
	 * Populates the data object from the given result set.
	 */
	protected void addSearchItem(ResultSet data, Object obj)
			throws SQLException {
		StringBuffer resultData = new StringBuffer();
		String accessInd = data.getString("WEB_ACCESS_IND").trim();
		if (("".equals(accessInd)) || (accessInd == null)) {
			accessInd = "N";
		}
		this.role = data.getString("ROLE_CD").trim();
		resultData = resultData.append(this.role).append(":").append(accessInd)
				.append(";");
		while (data.next()) {
			this.role = data.getString("ROLE_CD").trim();
			accessInd = data.getString("WEB_ACCESS_IND").trim();
			resultData = resultData.append(this.role).append(":").append(
					accessInd).append(";");
		}
		this.role = resultData.toString();
	}

}
