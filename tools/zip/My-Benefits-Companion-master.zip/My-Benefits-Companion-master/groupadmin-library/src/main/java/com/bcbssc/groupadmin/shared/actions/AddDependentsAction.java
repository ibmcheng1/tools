/*
 * @(#)GroupAdminChangePasswordAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.actions;

import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;
import com.bcbssc.groupadmin.shared.forms.AddCoverageForm;
import com.bcbssc.groupadmin.shared.forms.DependentForm;
import com.bcbssc.groupadmin.shared.forms.InsuredDataForm;
import com.bcbssc.groupadmin.shared.services.EffectiveDateCalculator;
import com.bcbssc.groupadmin.shared.services.InsuredServices;
import com.bcbssc.struts.action.SimpleDispatchAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import com.bcbssc.groupadmin.shared.forms.AddRequestChangeForm;

/**
 * Group Admin Change Password Action
 *
 * This class provides control processing the change password action. Because
 * change password control is fairly generic, this class extends the shared
 * registration modify profile action.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class AddDependentsAction extends SimpleDispatchAction {

	/** log4j logger */
	private static final Logger log = Logger
			.getLogger(AddDependentsAction.class.getName());

    private static final String FORWARD_REQUEST_A_CHANGE = "requestachange";

    private static final String FORWARD_CONFIRM = "success";

	/**
	 * <p>Constructor for AddDependentsAction.</p>
	 */
	public AddDependentsAction() {
		super();
		if (AddDependentsAction.log.isDebugEnabled()) {
			AddDependentsAction.log
					.debug("Created AddDependentsAction object.");
		}
	}

	/**
	 * Adds another dependent to the dependent list.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward addNextDependent(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		DependentForm dependentForm = (DependentForm) form;

		InsuredDataDTO insuredDataDTO = new InsuredDataDTO();
		BeanUtils.copyProperties(insuredDataDTO, dependentForm);
		InsuredServices.addNextDependent(insuredDataDTO);

		DependentForm newForm = (DependentForm) this.getForm("dependentForm",
				"/addDependent", request);
		BeanUtils.copyProperties(newForm, insuredDataDTO);

		request.setAttribute("dependentForm", newForm);
		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}

	/**
	 * Handles submission of the dependents form.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward addDependents(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		ActionForward forward = null;

		InsuredDataForm insuredForm = (InsuredDataForm) form;

		InsuredDataDTO insuredDTO = new InsuredDataDTO();
		BeanUtils.copyProperties(insuredDTO, insuredForm);
		String error = EffectiveDateCalculator.getErrorMessage(insuredDTO
				.getCoverageItems());
		if (error != null) {
			this.addGlobalRequestMessage(request, error);
		}

		BeanUtils.copyProperties(insuredForm, insuredDTO);
		request.setAttribute("insuredForm", insuredForm);



		if(error !=null){

			AddRequestChangeForm addRequestChangeForm = (AddRequestChangeForm) this.getForm("addRequestChangeForm", "/confirmInsuredRequestaChange",request);

			BeanUtils.copyProperties(addRequestChangeForm, form);
			forward = mapping.findForward(AddDependentsAction.FORWARD_REQUEST_A_CHANGE);
		}else{

			forward = mapping.findForward(AddDependentsAction.FORWARD_CONFIRM);
		}




		return forward;
	}

	/**
	 * Navigates back from the dependent form
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward goBack(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		InsuredDataForm insuredDataForm = (InsuredDataForm) form;
		insuredDataForm.setDentalDependentCount(insuredDataForm.getDependents()
				.size());
		InsuredDataDTO insuredDTO = new InsuredDataDTO();
		BeanUtils.copyProperties(insuredDTO, insuredDataForm);
		AddCoverageForm addCoverageForm = (AddCoverageForm) this.getForm(
				"coverageForm", "/addCoverage", request);
		BeanUtils.copyProperties(addCoverageForm, insuredDTO);
		request.setAttribute("coverageForm", addCoverageForm);
		return mapping.findForward("back");
	}

	/**
	 * Forwards to the add dependent form, copying data from the input form.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward breadcrumbForward(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		InsuredDataForm insuredDataForm = (InsuredDataForm) form;
		DependentForm dependentForm = (DependentForm) this.getForm(
				"dependentForm", "/addDependents", request);
		BeanUtils.copyProperties(dependentForm, insuredDataForm);
		request.setAttribute("dependentForm", dependentForm);
		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}
}
