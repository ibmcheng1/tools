/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/EmployeeDetailsQuery.java_v  $
 * $Workfile:   EmployeeDetailsQuery.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:14  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/EmployeeDetailsQuery.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:14:14   EN80
 * Initial revision.
 * 
 *    Rev 1.21   Apr 28 2009 10:18:00   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.20   Jun 29 2007 16:41:10   rx08e
 * Changes to support the SQL fix
 * 
 *    Rev 1.19   Jun 21 2007 16:36:04   rx08e
 * Changed to update the query for a performance issue, identified by host - host request to update the query.
 * 
 *    Rev 1.18   Apr 21 2005 10:51:26   rdq70
 * Use number of dependents from database.
 *
 *    Rev 1.17   Feb 28 2005 10:35:40   rdq70
 * Added spouseIndicator.
 *
 *    Rev 1.16   Feb 22 2005 15:43:42   rdq70
 * Added rate basis code and fixed salary format.
 *
 *    Rev 1.15   Feb 18 2005 13:22:04   rdq70
 * Added Hire Date.
 *
 *    Rev 1.14   Feb 16 2005 09:16:52   rdq70
 * Removed labels to match revised SQL.
 *
 *    Rev 1.13   Feb 15 2005 16:15:22   rdq70
 * Removed formatting of gender, status, student and smoker.
 *
 *    Rev 1.12   Feb 15 2005 11:17:52   rdq70
 * Removed SSN formatting built into SQL.
 *
 *    Rev 1.11   Feb 09 2005 12:08:04   rdq70
 * Added marital status.
 *
 *    Rev 1.10   Feb 09 2005 10:12:50   rdq70
 * Added alternate ID and employee status.
 *
 *    Rev 1.9   Feb 07 2005 14:34:36   rdq70
 * Removed duplicates from GROUP BY sections.
 *
 *    Rev 1.8   Feb 07 2005 14:00:56   rdq70
 * Incorporated revised SQL.
 *
 *    Rev 1.7   Feb 07 2005 13:28:24   rdq70
 * Incorporated revised SQL.
 *
 *    Rev 1.6   Feb 04 2005 09:18:36   rdq70
 * Added checkDuplicate().
 *
 *    Rev 1.5   Feb 03 2005 13:30:24   rdq70
 * Javadoc correction.
 *
 *    Rev 1.4   Feb 03 2005 12:14:42   rdq70
 * Incorporated revised SQL.
 *
 *    Rev 1.3   Feb 02 2005 09:39:44   rdq70
 * Revised Javadocs based on provided SQL descriptions.
 *
 *    Rev 1.2   Jan 27 2005 14:20:52   rdq70
 * Trim possibly long columns.
 *
 *    Rev 1.1   Jan 27 2005 13:02:56   rdq70
 * Corrected qualifier and column references.
 *
 *    Rev 1.0   Jan 27 2005 10:28:34   rdq70
 * Initial revision.
 *
 *    Rev 1.1   Jan 26 2005 17:16:56   rdq70
 * Populate the right kind of bean.
 *
 *    Rev 1.0   Jan 26 2005 11:26:00   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.dbaccess;

import com.bcbssc.groupadmin.shared.dto.CoverageClass;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;

import org.apache.log4j.Logger;

/**
 * This query retrieves the details of the insured employee, annual salary and
 * the coverage class and description. It will also check for duplicate
 * certificate IDs.
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class EmployeeDetailsQuery extends AbstractDBSearch {
	/** Single marital status. */
	public static final String SINGLE_STATUS = "1";

	/** Married marital status. */
	public static final String MARRIED_STATUS = "2";

	/** The log4j logger for this class. */
	private static final Logger log = Logger
			.getLogger(EmployeeDetailsQuery.class);

	/** The data object being populated. */
	private InsuredDataDTO insuredData;

	/** The count when checking for duplicate. */
	private int count;

	/**
	 * Creates an <code>EmployeeDetailsQuery</code> and configures it with an
	 * INI file.
	 *
	 * @param iniFile
	 *            file path of the configuration INI file.
	 */
	public EmployeeDetailsQuery(String iniFile) {
		super(iniFile, "GCOM_TABLE");
	}

	/**
	 * Retrieves the details of the insured employee, annual salary and the
	 * coverage class and description, and adds them to the given bean.<br>
	 *
	 * <pre>
	 *     QMF NAME: RX13U.WEB_SQL_5_A
	 *     TSO NAME: WEBSQL5A
	 * </pre>
	 *
	 * @param insuredData
	 *            the bean containing data for the search. It needs only the
	 *            groupNumber and identificationNumber properties set.
	 * @return the input bean populated with the search results.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 */
	public InsuredDataDTO performSearch(InsuredDataDTO insuredData)
			throws SQLException {
		this.checkInit(); // Necessary since we need the _dbSchema before the
							// query creation
		this.insuredData = insuredData;
		final String company = insuredData.getCompany();
		final String prefix = insuredData.getGroupPrefix();
		final String group = insuredData.getGroupBase();
		final String division = insuredData.getDivisionCode();
		final String idNo = insuredData.getIdentificationNumber();

		final String[] params = { company, prefix, group, division, idNo,
				company, prefix, group, company, prefix, group, division, idNo,
				company, prefix, group };

		this.performSearch(this.getSql(division), params,
				Collections.EMPTY_LIST);
		return insuredData;
	}

	/**
	 * Determines if the certificate ID assigned to add a new insured employee
	 * is a duplicate.
	 *
	 * @param insuredData
	 *            the bean containing data for the search. It needs only the
	 *            groupNumber and identificationNumber properties set.
	 * @return <code>true</code> if the ID is a duplicate.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 */
	public boolean checkDuplicate(InsuredDataDTO insuredData)
			throws SQLException {
		this.checkInit(); // Necessary since we need the _dbSchema before the
							// query creation

		final StringBuffer sql = new StringBuffer(128);

		sql
				.append("SELECT COUNT(*) FROM ")
				.append(this._dbSchema)
				.append(
						".VCERTMSZ"
								+ "  WHERE COMP_CD = ? AND GROUP_PRFX = ? AND GROUP_NO = ?"
								+ "    AND DIV_ID = ? AND CERT_ID = ?");

		final String[] params = { insuredData.getCompany(),
				insuredData.getGroupPrefix(), insuredData.getGroupBase(),
				insuredData.getDivisionCode(),
				insuredData.getIdentificationNumber() };

		this.performSearch(sql.toString(), params, null);
		return this.count == 0;
	}

	/**
	 * {@inheritDoc}
	 *
	 * Populates the data object from the given result set.
	 */
	protected void addSearchItem(ResultSet data, Object obj)
			throws SQLException {
		if (obj == null) {
			this.count = data.getInt(1);
		} else {
			final CoverageClass clazz = this.insuredData.getCoverageClass();
			// insuredData.(data.getString("EFFECTIVE_DATE"));
			this.insuredData.setOriginalEffectiveDate(DatabaseProxy
					.getDateBean(data.getString("ORIGINAL_EFF DATE")));
			this.insuredData.setLastProcessedDate(DatabaseProxy
					.getDateBean(data.getString("LST_PROCESSED_DT")));
			this.insuredData.setSsn(data.getString("CERT_SSN").trim());
			this.insuredData.setLastName(data.getString("CN_LST_NME").trim());
			this.insuredData.setGivenName(data.getString("CN_FRST_NME").trim());
			this.insuredData.setMiddleIni(data.getString("CN_INIT"));
			this.insuredData.setDateOfBirth(DatabaseProxy.getDateBean(data
					.getString("DOB")));
			this.insuredData.setGender(data.getString("CN_SEX_ID"));
			this.insuredData.setAddressLine1(data.getString("CA_ADDR_LN_1")
					.trim());
			this.insuredData.setAddressLine2(data.getString("CA_ADDR_LN_2")
					.trim());
			this.insuredData.setCity(data.getString("CA_CTY_ADR").trim());
			this.insuredData.setState(data.getString("CA_ST_ADR").trim());
			this.insuredData.setZip(data.getString("CA_ZIP_ADR").trim());
			this.insuredData.setTelephoneNumber(data.getString("CA_PHONE_NO")
					.trim());
			this.insuredData.setDepartment(data.getString("CERT_DEPT").trim());
			this.insuredData.setPayrollOfficeIdentifier(data.getString(
					"CERT_PAY_OFFC_NO").trim());
			this.insuredData.setCobra(data.getString("CERT_COBRA_CD").trim());
			this.insuredData.setSmoker(data.getString("CERT_SMOKER_TYP"));
			this.insuredData.setOccupation(data.getString("CN_OCCUPN_NME")
					.trim());
			this.insuredData.setAlternateID(data.getString("CERT_MICROFICHE")
					.trim());
			this.insuredData.setStatus(data.getString("CERT_MBR_STAT"));
			this.insuredData.setTerminationDate(DatabaseProxy.getDateBean(data
					.getString("TERM_DATE")));
			this.insuredData.setTerminationReason(data.getString(
					"CERT_TRM_REAS_INS").trim());
			this.insuredData.setAverageHoursWorked(data
					.getString("AVERAGE_HOURS_WORK"));
			this.insuredData.setAnnualSalary(EmployeeDetailsQuery
					.formatSalary(data.getBigDecimal("CB_SLRY_AMT")));
			this.insuredData.setDatabaseDependentsCount(data
					.getInt("CB_NO_DEP"));
			this.insuredData
					.setEmployeeStatus(data.getString("CN_EMPLOY_STAT"));
			this.insuredData
					.setSpouseExists(EmployeeDetailsQuery.MARRIED_STATUS
							.equals(data.getString("INSD_MARITAL_STAT")));
			this.insuredData.setHireDate(DatabaseProxy.getDateBean(data
					.getString("HIRE DATE")));
			this.insuredData.setRateBasisCode(data.getString("RAT_BAS_CD"));
			this.insuredData.setSpouseIndicator(data.getString("CERT_SP_IND"));

			clazz.setCode(data.getString("EMPLY_CLASS").trim());
			clazz.setDescription(data.getString("EMP_CLASS_DESC"));
			clazz.setSicCode(data.getString("CERT_SIC_CD").trim());
			clazz.setMaintenanceIndicator(data.getString("CERT_MAINT_INDC"));
			clazz.setAgeChangeCode(data.getString("AGE_CHNG_CD"));
			clazz.setIssueCertType(data.getString("CERT_TYP"));
			clazz.setWalletCardType(data.getString("WLT_CRD_TYP"));
		}
	}

	/**
	 * Returns the 5A SQL for this query.
	 * 
	 * @param division
	 *            the group division code for this query.
	 * @return the 5A SQL for this query.
	 */
	private String getSql(final String division) {
		return new StringBuffer(12000)
				.append(
						"SELECT CHAR(A.CERT_EFF_DT,USA) \"EFFECTIVE_DATE\""
								+ "   , CHAR(A.CERT_ORIG_EFF_DT,USA) \"ORIGINAL_EFF DATE\""
								+ "   , CHAR(A.LST_MISC_TRANS_DT,USA) \"LST_PROCESSED_DT\""
								+ "   , A.CERT_SSN"
								+ "   , B.CN_LST_NME"
								+ "   , B.CN_FRST_NME"
								+ "   , B.CN_INIT"
								+ "   , CHAR(B.CN_DOB,USA) \"DOB\""
								+ "   , B.CN_SEX_ID"
								+ "   , B.CA_ADDR_LN_1"
								+ "   , B.CA_ADDR_LN_2"
								+ "   , B.CA_CTY_ADR"
								+ "   , B.CA_ST_ADR"
								+ "   , B.CA_ZIP_ADR"
								+ "   , B.CA_PHONE_NO"
								+ "   , A.CERT_DEPT"
								+ "   , A.CERT_PAY_OFFC_NO"
								+ "   , A.CERT_COBRA_CD"
								+ "   , A.CERT_SMOKER_TYP"
								+ "   , B.CN_OCCUPN_NME"
								+ "   , A.CERT_MICROFICHE"
								+ "   , A.CERT_MBR_STAT"
								+ "   , CASE A.CERT_MBR_STAT"
								+ "       WHEN '9' THEN CHAR(A.CERT_EFF_DT,USA)"
								+ "       ELSE ' '" + "     END \"TERM_DATE\""
								+ "   , A.CERT_TRM_REAS_INS"
								+ "   , A.AVERAGE_HOURS_WORK"
								+ "   , C.CB_SLRY_AMT" + "   , C.EMPLY_CLASS"
								+ "   , D.EMP_CLASS_DESC" + "   , A.CERT_DEPT"
								+ "   , A.CERT_SIC_CD" + "   , C.CB_NO_DEP"
								+ "   , E.CERT_MAINT_INDC"
								+ "   , E.AGE_CHNG_CD" + "   , E.CERT_TYP"
								+ "   , E.WLT_CRD_TYP"
								+ "   , B.CN_EMPLOY_STAT"
								+ "   , C.INSD_MARITAL_STAT"
								+ "   , CHAR(B.CN_EMPLOY_DT,USA) \"HIRE DATE\""
								+ "   , C.RAT_BAS_CD" + "   , A.CERT_SP_IND"
								+ "  FROM ")
				.append(this._dbSchema)
				.append(".VCERTMSZ A" + "     , ")
				.append(this._dbSchema)
				.append(".VCERTNMZ B" + "     , ")
				.append(this._dbSchema)
				.append(".VCERTBDZ C" + "     , ")
				.append(this._dbSchema)
				.append(".VCLSDSCZ D" + "     , ")
				.append(this._dbSchema)
				.append(
						".VPLCYGRZ E"
								+ " WHERE A.COMP_CD = ?"
								+ "   AND A.COMP_CD = B.COMP_CD"
								+ "   AND B.COMP_CD = C.COMP_CD"
								+ "   AND C.COMP_CD = D.COMPANY_CODE"
								+ "   AND D.COMPANY_CODE = E.COMP_CD"
								+ "   AND A.GROUP_PRFX = ?"
								+ "   AND A.GROUP_PRFX = B.GROUP_PRFX"
								+ "   AND B.GROUP_PRFX = C.GROUP_PRFX"
								+ "   AND C.GROUP_PRFX = D.GROUP_PREFIX"
								+ "   AND D.GROUP_PREFIX = E.GRP_PRFX"
								+ "   AND A.GROUP_NO = ?"
								+ "   AND A.GROUP_NO = B.GROUP_NO"
								+ "   AND B.GROUP_NO = C.GROUP_NO"
								+ "   AND C.GROUP_NO = D.GROUP_NUMBER"
								+ "   AND D.GROUP_NUMBER = E.GRP_BASE"
								+ "   AND A.DIV_ID = ?"
								+ "   AND A.DIV_ID = B.DIV_ID"
								+ "   AND B.DIV_ID = C.DIV_ID"
								+ "   AND D.DIVISION_ID = CASE WHEN E.DIV_LVL_CD = '5'"
								+ "                           THEN '")
				.append(division)
				.append(
						"'"
								+ "                           ELSE ' ' END"
								+ "   AND A.CERT_ID = ?"
								+ "   AND A.CERT_ID = B.CERT_ID"
								+ "   AND B.CERT_ID = C.CERT_ID"
								+ "   AND C.EMPLY_CLASS = D.EMP_CLASS_ID"
								+ " GROUP BY A.CERT_EFF_DT"
								+ "  , A.CERT_ORIG_EFF_DT"
								+ "  , A.LST_MISC_TRANS_DT"
								+ "  , A.CERT_SSN"
								+ "  , B.CN_LST_NME"
								+ "  , B.CN_FRST_NME"
								+ "  , B.CN_INIT"
								+ "  , B.CN_DOB"
								+ "  , B.CN_SEX_ID"
								+ "  , B.CA_ADDR_LN_1"
								+ "  , B.CA_ADDR_LN_2"
								+ "  , B.CA_CTY_ADR"
								+ "  , B.CA_ST_ADR"
								+ "  , B.CA_ZIP_ADR"
								+ "  , B.CA_PHONE_NO"
								+ "  , A.CERT_DEPT"
								+ "  , A.CERT_PAY_OFFC_NO"
								+ "  , A.CERT_COBRA_CD"
								+ "  , A.CERT_SMOKER_TYP"
								+ "  , B.CN_OCCUPN_NME"
								+ "  , A.CERT_MICROFICHE"
								+ "  , A.CERT_MBR_STAT"
								+ "  , A.CERT_TRM_REAS_INS"
								+ "  , A.AVERAGE_HOURS_WORK"
								+ "  , C.CB_SLRY_AMT"
								+ "  , C.EMPLY_CLASS"
								+ "  , D.EMP_CLASS_DESC"
								+ "  , A.CERT_DEPT"
								+ "  , A.CERT_SIC_CD"
								+ "  , C.CB_NO_DEP"
								+ "  , E.CERT_MAINT_INDC"
								+ "  , E.AGE_CHNG_CD"
								+ "  , E.CERT_TYP"
								+ "  , E.WLT_CRD_TYP"
								+ "  , B.CN_EMPLOY_STAT"
								+ "  , C.INSD_MARITAL_STAT"
								+ "  , B.CN_EMPLOY_DT"
								+ "  , C.RAT_BAS_CD"
								+ "  , A.CERT_SP_IND"
								+ " HAVING EXISTS (SELECT DISTINCT (A.CLAS_CODE)"
								+ "     , C.EMP_CLASS_DESC" + "   FROM ")
				.append(this._dbSchema)
				.append(".VPLCYCVZ A" + "     , ")
				.append(this._dbSchema)
				.append(".VPLCYGRZ B" + "     , ")
				.append(this._dbSchema)
				.append(
						".VCLSDSCZ C"
								+ "   WHERE A.COMP_CD = ?"
								+ "     AND A.COMP_CD = B.COMP_CD"
								+ "     AND B.COMP_CD = C.COMPANY_CODE"
								+ "     AND A.GRP_PRFX = ?"
								+ "     AND A.GRP_PRFX = B.GRP_PRFX"
								+ "     AND B.GRP_PRFX = C.GROUP_PREFIX"
								+ "     AND A.GRP_BASE = ?"
								+ "     AND A.GRP_BASE = B.GRP_BASE"
								+ "     AND B.GRP_BASE = C.GROUP_NUMBER"
								+ "     AND A.COV_STAT_CD = '1'"
								+ "     AND A.CLAS_CODE = C.EMP_CLASS_ID"
								+ "     AND A.DIV_CODE = CASE WHEN B.DIV_LVL_CD = '5'"
								+ "                           THEN '")
				.append(division)
				.append(
						"'"
								+ "                           ELSE ' ' END"
								+ "     AND C.DIVISION_ID = CASE WHEN B.DIV_LVL_CD = '5'"
								+ "                              THEN '")
				.append(division)
				.append(
						"'"
								+ "                              ELSE ' ' END)"
								+ " UNION"
								+ " SELECT CHAR(A.CERT_EFF_DT,USA) \"EFFECTIVE_DATE\""
								+ "   , CHAR(A.CERT_ORIG_EFF_DT,USA) \"ORIGINAL_EFF DATE\""
								+ "   , CHAR(A.LST_MISC_TRANS_DT,USA) \"LST_PROCESSED_DT\""
								+ "   , A.CERT_SSN"
								+ "   , B.CN_LST_NME"
								+ "   , B.CN_FRST_NME"
								+ "   , B.CN_INIT"
								+ "   , CHAR(B.CN_DOB,USA) \"DOB\""
								+ "   , B.CN_SEX_ID"
								+ "   , B.CA_ADDR_LN_1"
								+ "   , B.CA_ADDR_LN_2"
								+ "   , B.CA_CTY_ADR"
								+ "   , B.CA_ST_ADR"
								+ "   , B.CA_ZIP_ADR"
								+ "   , B.CA_PHONE_NO"
								+ "   , A.CERT_DEPT"
								+ "   , A.CERT_PAY_OFFC_NO"
								+ "   , A.CERT_COBRA_CD"
								+ "   , A.CERT_SMOKER_TYP"
								+ "   , B.CN_OCCUPN_NME"
								+ "   , A.CERT_MICROFICHE"
								+ "   , A.CERT_MBR_STAT"
								+ "   , CASE A.CERT_MBR_STAT"
								+ "       WHEN '9' THEN CHAR(A.CERT_EFF_DT,USA)"
								+ "       ELSE ' '" + "     END \"TERM_DATE\""
								+ "   , A.CERT_TRM_REAS_INS"
								+ "   , A.AVERAGE_HOURS_WORK"
								+ "   , C.CB_SLRY_AMT" + "   , C.EMPLY_CLASS"
								+ "   , 'NOT FOUND' \"EMP_CLASS_DESC\""
								+ "   , A.CERT_DEPT" + "   , A.CERT_SIC_CD"
								+ "   , C.CB_NO_DEP" + "   , D.CERT_MAINT_INDC"
								+ "   , D.AGE_CHNG_CD" + "   , D.CERT_TYP"
								+ "   , D.WLT_CRD_TYP"
								+ "   , B.CN_EMPLOY_STAT"
								+ "   , C.INSD_MARITAL_STAT"
								+ "   , CHAR(B.CN_EMPLOY_DT,USA) \"HIRE DATE\""
								+ "   , C.RAT_BAS_CD" + "   , A.CERT_SP_IND"
								+ " FROM ")
				.append(this._dbSchema)
				.append(".VCERTMSZ A" + "   , ")
				.append(this._dbSchema)
				.append(".VCERTNMZ B" + "   , ")
				.append(this._dbSchema)
				.append(".VCERTBDZ C" + "     , ")
				.append(this._dbSchema)
				.append(
						".VPLCYGRZ D"
								+ " WHERE A.COMP_CD = ?"
								+ "   AND A.COMP_CD = B.COMP_CD"
								+ "   AND B.COMP_CD = C.COMP_CD"
								+ "   AND C.COMP_CD = D.COMP_CD"
								+ "   AND A.GROUP_PRFX = ?"
								+ "   AND A.GROUP_PRFX = B.GROUP_PRFX"
								+ "   AND B.GROUP_PRFX = C.GROUP_PRFX"
								+ "   AND C.GROUP_PRFX = D.GRP_PRFX"
								+ "   AND A.GROUP_NO = ?"
								+ "   AND A.GROUP_NO = B.GROUP_NO"
								+ "   AND B.GROUP_NO = C.GROUP_NO"
								+ "   AND C.GROUP_NO = D.GRP_BASE"
								+ "   AND A.DIV_ID = ?"
								+ "   AND A.DIV_ID = B.DIV_ID"
								+ "   AND B.DIV_ID = C.DIV_ID"
								+ "   AND A.CERT_ID = ?"
								+ "   AND A.CERT_ID = B.CERT_ID"
								+ "   AND B.CERT_ID = C.CERT_ID"
								+ " GROUP BY A.CERT_EFF_DT"
								+ "   , A.CERT_ORIG_EFF_DT"
								+ "   , A.LST_MISC_TRANS_DT"
								+ "   , A.CERT_SSN"
								+ "   , B.CN_LST_NME"
								+ "   , B.CN_FRST_NME"
								+ "   , B.CN_INIT"
								+ "   , B.CN_DOB"
								+ "   , B.CN_SEX_ID"
								+ "   , B.CA_ADDR_LN_1"
								+ "   , B.CA_ADDR_LN_2"
								+ "   , B.CA_CTY_ADR"
								+ "   , B.CA_ST_ADR"
								+ "   , B.CA_ZIP_ADR"
								+ "   , B.CA_PHONE_NO"
								+ "   , A.CERT_DEPT"
								+ "   , A.CERT_PAY_OFFC_NO"
								+ "   , A.CERT_COBRA_CD"
								+ "   , A.CERT_SMOKER_TYP"
								+ "   , B.CN_OCCUPN_NME"
								+ "   , A.CERT_MICROFICHE"
								+ "   , A.CERT_MBR_STAT"
								+ "   , A.CERT_TRM_REAS_INS"
								+ "   , A.AVERAGE_HOURS_WORK"
								+ "   , C.CB_SLRY_AMT"
								+ "   , C.EMPLY_CLASS"
								+ "   , A.CERT_DEPT"
								+ "   , A.CERT_SIC_CD"
								+ "   , C.CB_NO_DEP"
								+ "   , D.CERT_MAINT_INDC"
								+ "   , D.AGE_CHNG_CD"
								+ "   , D.CERT_TYP"
								+ "   , D.WLT_CRD_TYP"
								+ "   , B.CN_EMPLOY_STAT"
								+ "   , C.INSD_MARITAL_STAT"
								+ "   , B.CN_EMPLOY_DT"
								+ "   , C.RAT_BAS_CD"
								+ "   , A.CERT_SP_IND"
								+ " HAVING NOT EXISTS (SELECT DISTINCT (A.CLAS_CODE)"
								+ "     , C.EMP_CLASS_DESC" + "   FROM ")
				.append(this._dbSchema)
				.append(".VPLCYCVZ A" + "     , ")
				.append(this._dbSchema)
				.append(".VPLCYGRZ B" + "     , ")
				.append(this._dbSchema)
				.append(
						".VCLSDSCZ C"
								+ "   WHERE A.COMP_CD = ?"
								+ "     AND A.COMP_CD = B.COMP_CD"
								+ "     AND B.COMP_CD = C.COMPANY_CODE"
								+ "     AND A.GRP_PRFX = ?"
								+ "     AND A.GRP_PRFX = B.GRP_PRFX"
								+ "     AND B.GRP_PRFX = C.GROUP_PREFIX"
								+ "     AND A.GRP_BASE = ?"
								+ "     AND A.GRP_BASE = B.GRP_BASE"
								+ "     AND B.GRP_BASE = C.GROUP_NUMBER"
								+ "     AND A.COV_STAT_CD = '1'"
								+ "     AND A.CLAS_CODE = C.EMP_CLASS_ID"
								+ "     AND A.DIV_CODE = CASE WHEN B.DIV_LVL_CD = '5'"
								+ "                           THEN '")
				.append(division)
				.append(
						"'"
								+ "                           ELSE ' ' END"
								+ "     AND C.DIVISION_ID = CASE WHEN B.DIV_LVL_CD = '5'"
								+ "                              THEN '")
				.append(division).append(
						"'" + "                              ELSE ' ' END)")
				.toString();
	}

	/**
	 * Converts the salary format from the database to that expected in the
	 * bean.
	 * 
	 * @param dbSaraly
	 *            the salary from the database.
	 * @return the salaray for the bean.
	 */
	private static String formatSalary(BigDecimal dbSalary) {
		String salary = dbSalary.multiply(BigDecimal.valueOf(100L))
				.toBigInteger().toString();
		EmployeeDetailsQuery.log.debug("salary=" + salary);
		return salary;
	}
}
