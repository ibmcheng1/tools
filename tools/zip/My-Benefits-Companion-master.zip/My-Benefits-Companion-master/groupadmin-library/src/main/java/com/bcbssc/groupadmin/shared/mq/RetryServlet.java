/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mq/RetryServlet.java_v  $
 * $Workfile:   RetryServlet.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:16:20  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mq/RetryServlet.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:16:20   EN80
 * Initial revision.
 * 
 *    Rev 1.5   Apr 28 2009 10:20:28   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.4   Mar 04 2005 14:41:12   rdq70
 * Added retries for INFOrms.
 *
 *    Rev 1.3   Mar 04 2005 10:55:48   rdq70
 * Split out retry logic into RetrySender.
 *
 *    Rev 1.2   Feb 16 2005 12:09:46   rdq70
 * Added archive logic.
 *
 *    Rev 1.1   Feb 15 2005 18:59:22   rdq70
 * First working version; still needs archive logic.
 *
 *    Rev 1.0   Feb 15 2005 18:13:12   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.mq;

import javax.naming.InitialContext;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.RollingFileAppender;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.netsys.Config;

/**
 * Attempts to re-send failed MQ messages.
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class RetryServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = -9066486148952231487L;

	/** The log4j logger for this class. */
	private static final Logger log = Logger.getLogger(RetryServlet.class);

	/** The transaction used to create messegers. */
	private GcomTransaction transaction;

	/** The log4j appender that handles GCOM MQ message errors. */
	private RollingFileAppender gcomAppender;

	/** The log4j appender that handles INFOrm message errors. */
	private RollingFileAppender infoAppender;

	/** The INI file for INFOrms. */
	private String infoIniFile;

	/**
	 * {@inheritDoc}
	 *
	 * Called by the Container to initialize this servlet.
	 */
	public void init(ServletConfig config) throws ServletException {
		super.init(config);

		Logger logger = Logger
				.getLogger("com.bcbssc.groupadmin.shared.mq.GcomMessenger");
		this.gcomAppender = (RollingFileAppender) logger.getAppender("mqError");
		final String gcomIniFile = CommonUtils.getGcomIniFile(config
				.getServletContext());
		this.transaction = new GcomTransaction(gcomIniFile);

		logger = Logger
				.getLogger("com.bcbssc.commercial.inform.InformTransaction.ERROR");
		this.infoAppender = (RollingFileAppender) logger
				.getAppender("infoError");
		this.infoIniFile = CommonUtils.getIniFile(config.getServletContext());

		if (RetryServlet.log.isDebugEnabled()) {
			RetryServlet.log.debug("gcomIniFile = " + gcomIniFile);
			RetryServlet.log.debug("infoIniFile = " + this.infoIniFile);
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * Handles the HTTP <code>GET</code> method.
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) {
		this.processRequest();
	}

	/**
	 * {@inheritDoc}
	 *
	 * Handles the HTTP <code>POST</code> method.
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) {
		this.processRequest();
	}

	/**
	 * Attempts to re-send failed MQ messages.
	 * 
	 * @param request
	 *            the servlet request.
	 * @param response
	 *            the servlet response.
	 */
	private void processRequest() {
		GcomMessenger messenger = null;

		// First, retry GCOM MQs
		try {
			messenger = this.transaction.createMessenger();
			new RetrySender(messenger, this.gcomAppender).resendFiles();
		} catch (Exception e) {
			RetryServlet.log.error("Error trying to re-send GCOM MQs:", e);
		} finally {
			if (messenger != null) {
				messenger.complete();
				messenger = null;
			}
		}

		// Second, retry INFOrms
		try {
			messenger = new GcomMessenger(new InitialContext(), Constants.CONNECTION_FACTORY);
			messenger.setConnectionName("CLifeINFOrm");
			messenger.setConfigFile(this.infoIniFile);

			messenger.setDestinationName(Config.getPrivateProfileString(
					"DESTINATIONS", "GroupAdmin_INFORM", "", this.infoIniFile));

			messenger.setOutboundMessageHeaders(Config.getConfigSection(
					"JMS_HEADERS", this.infoIniFile));

			new RetrySender(messenger, this.infoAppender).resendFiles();
		} catch (Exception e) {
			RetryServlet.log.error("Error trying to re-send INFOrms:", e);
		} finally {
			if (messenger != null) {
				messenger.complete();
				messenger = null;
			}
		}
	}
}
