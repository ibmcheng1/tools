/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.groupadmin.shared.mq;

import com.bcbssc.netsys.inform.AbstractInformMessage;


/**
 * <p>GroupAdminRegInformMessage class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class GroupAdminRegInformMessage extends
		com.bcbssc.netsys.inform.AbstractInformMessage {

	/** the source-control revision of this class * */
	/** Constant <code>VERSION="$Revision:   1.0  $"</code> */
	public static final String VERSION = "$Revision:   1.0  $";

	private static final String FILE_INFORM = "GroupAdminUserRegistrationInform.xml";

	private static final String MAPPER_KEY = "GroupAdminUserUpdateInforms";

	private static final String TASK_PREFIX = "GroupAdminUserUpdate.";

	private String applicationName = "GroupAdminUserUpdate";

	/**
	 * Creates a new instance of GroupAdminInformMessage
	 */
	public GroupAdminRegInformMessage() {
		super();
	}

	/**
	 * Convenience constructor for setting the application upon instantiation.
	 *
	 * @param applicationName
	 *            The name of the application submitting the INFOrm
	 */
	public GroupAdminRegInformMessage(String applicationName) {
		super();
		this.setApplicationName(applicationName);
	}

	/**
	 * Gets the application name for the INFOrm message. Used by
	 * {@link com.bcbssc.netsys.inform.AbstractInformMessage} to get the proper Mapper instance.
	 *
	 * @return The application name for the current instance.
	 */
	public String getApplicationName() {
		return this.applicationName;
	}

	/**
	 * Gets the application name for the INFOrm message. Used by
	 * {@link com.bcbssc.netsys.inform.AbstractInformMessage} to get the proper Mapper instance.
	 *
	 * @param value
	 *            The application name for the current instance.
	 */
	public void setApplicationName(String value) {
		this.applicationName = value;
	}

	/**
	 * Gets the file path of the mappings file used to map INFOrm data.
	 *
	 * @return The file path used for mapping INFOrm data.
	 */
	public String getInformMapFile() {
		return GroupAdminRegInformMessage.FILE_INFORM;
	}

	/**
	 * Gets the key name for the INFOrm message.
	 *
	 * @return The key name for the INFOrm message.
	 */
	public String getMapperKey() {
		return GroupAdminRegInformMessage.MAPPER_KEY;
	}

	/**
	 * Gets the task prefix for the INFOrm message.
	 *
	 * @return The task prefix for the INFOrm message.
	 */
	public String getTaskPrefix() {
		return GroupAdminRegInformMessage.TASK_PREFIX;
	}

}
