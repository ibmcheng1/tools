/*
 * @(#)CoverageItem.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.dto;

import com.bcbssc.groupadmin.shared.forms.Options;
import com.bcbssc.struts.common.DateBean;
import com.bcbssc.struts.common.FormDate;
import com.bcbssc.struts.common.SocialSecurityNumber;

/**
 * GroupAdmin Coverage Item
 *
 * This bean represents a coverage item. In addition to the coverage item data
 * properties, it contains logic to determine the display protections for the
 * item.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class Dependent extends Object {

	/** Dependent relationship codes */
	public static final String RELATIONSHIP_SPOUSE = "SPS";

	/** Constant <code>RELATIONSHIP_CHILD="CHL"</code> */
	public static final String RELATIONSHIP_CHILD = "CHL";

	/** Constant <code>RELATIONSHIP_PARTNER="DOM"</code> */
	public static final String RELATIONSHIP_PARTNER = "DOM";

	/** Constant <code>RELATIONSHIP_OTHER="OTH"</code> */
	public static final String RELATIONSHIP_OTHER = "OTH";

	/**
	 * Holds value of property lastName.
	 */
	private String lastName = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property givenName.
	 */
	private String givenName = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property middleIni.
	 */
	private String middleIni = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property gender.
	 */
	private String gender = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property ssn.
	 */
	private SocialSecurityNumber ssn = SocialSecurityNumber.blank();

	/**
	 * Holds dependent date of birth.
	 */
	private FormDate dateOfBirth = FormDate.blank();

	/**
	 * Holds value of property student.
	 */
	private String student = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property relationship.
	 */
	private String relationship = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property nameId.
	 */
	private String nameId = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Holds value of property added.
	 */
	private boolean added;

	/**
	 * Holds value of property changed.
	 */
	private boolean changed;

	/**
	 * Holds effective date (spouse only).
	 */
	private FormDate effectiveDate = FormDate.blank();

	/**
	 * Getter for property lastName.
	 *
	 * @return Value of property lastName.
	 */
	public String getLastName() {
		return this.lastName;
	}

	/**
	 * Setter for property lastName.
	 *
	 * @param lastName
	 *            New value of property lastName.
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Getter for property givenName.
	 *
	 * @return Value of property givenName.
	 */
	public String getGivenName() {
		return this.givenName;
	}

	/**
	 * Setter for property givenName.
	 *
	 * @param givenName
	 *            New value of property givenName.
	 */
	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	/**
	 * Getter for property middleIni.
	 *
	 * @return Value of property middleIni.
	 */
	public String getMiddleIni() {
		return this.middleIni;
	}

	/**
	 * Setter for property middleIni.
	 *
	 * @param middleIni
	 *            New value of property middleIni.
	 */
	public void setMiddleIni(String middleIni) {
		this.middleIni = middleIni;
	}

	/**
	 * Getter for property gender.
	 *
	 * @return Value of property gender.
	 */
	public String getGender() {
		return this.gender;
	}

	/**
	 * Getter for the formatted gender label.
	 *
	 * @return label associated with the value of property gender.
	 */
	public String getGenderFormatted() {
		return com.bcbssc.struts.forms.Options.getLabelFromValue(Options
				.getGroupAdminInstance().getGenderOptions(), this.gender);
	}

	/**
	 * Setter for property gender.
	 *
	 * @param gender
	 *            New value of property gender.
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * Getter for property ssn.
	 *
	 * @return Value of property ssn.
	 */
	public String getSsn() {
		return this.ssn.getValue();
	}

	/**
	 * Getter for formatted ssn value.
	 *
	 * @return formatted value of property ssn.
	 */
	public String getSsnFormatted() {
		return this.ssn.format();
	}

	/**
	 * Setter for property ssn.
	 *
	 * @param value
	 *            New value of property ssn.
	 */
	public void setSsn(String value) {
		this.ssn.setValue(value);
	}

	/**
	 * Getter for property dateOfBirth.
	 *
	 * @return Value of property dateOfBirth.
	 */
	public DateBean getDateOfBirth() {
		return this.dateOfBirth;
	}

	/**
	 * Setter for property dateOfBirth.
	 *
	 * @param bean
	 *            New value of property dateOfBirth.
	 */
	public void setDateOfBirth(DateBean bean) {
		this.dateOfBirth.setDate(bean);
	}

	/**
	 * Getter for property dateOfBirth.
	 *
	 * @return Value of property dateOfBirth.
	 */
	public String getDateOfBirthFormatted() {
		return this.dateOfBirth.toString();
	}

	/**
	 * Setter for property dateOfBirth.
	 *
	 * @param value
	 *            New value of property dateOfBirth.
	 */
	public void setDateOfBirthFormatted(String value) {
		this.dateOfBirth.parse(value);
	}

	/**
	 * Getter for property dobMonth.
	 *
	 * @return Value of property dobMonth.
	 */
	public String getDobMonth() {
		return this.dateOfBirth.getMonth();
	}

	/**
	 * Getter for property dobDay.
	 *
	 * @return Value of property dobDay.
	 */
	public String getDobDay() {
		return this.dateOfBirth.getDay();
	}

	/**
	 * Getter for property dobYear.
	 *
	 * @return Value of property dobYear.
	 */
	public String getDobYear() {
		return this.dateOfBirth.getYear();
	}

	/**
	 * Setter for property dobMonth.
	 *
	 * @param value
	 *            New value of property dobMonth.
	 */
	public void setDobMonth(String value) {
		this.dateOfBirth.setMonth(value);
	}

	/**
	 * Setter for property dobDay.
	 *
	 * @param value
	 *            New value of property dobDay.
	 */
	public void setDobDay(String value) {
		this.dateOfBirth.setDay(value);
	}

	/**
	 * Setter for property dobYear.
	 *
	 * @param value
	 *            New value of property dobYear.
	 */
	public void setDobYear(String value) {
		this.dateOfBirth.setYear(value);
	}

	/**
	 * Getter for property student.
	 *
	 * @return Value of property student.
	 */
	public String getStudent() {
		return this.student;
	}

	/**
	 * Getter for the formatted student label.
	 *
	 * @return label associated with the value of property student.
	 */
	public String getStudentFormatted() {
		return com.bcbssc.struts.forms.Options.getLabelFromValue(Options
				.getGroupAdminInstance().getPleaseChooseOneNoYesOptions(),
				this.student);
	}

	/**
	 * Setter for property student.
	 *
	 * @param value
	 *            New value of property student.
	 */
	public void setStudent(String value) {
		this.student = value;
	}

	/**
	 * Getter for property relationship.
	 *
	 * @return Value of property relationship.
	 */
	public String getRelationship() {
		return this.relationship;
	}

	/**
	 * Getter for the formatted relationship label.
	 *
	 * @return label associated with the value of property relationship.
	 */
	public String getRelationshipFormatted() {
		return com.bcbssc.struts.forms.Options.getLabelFromValue(Options
				.getGroupAdminInstance().getRelationshipOptions(),
				this.relationship);
	}

	/**
	 * Setter for property relationship.
	 *
	 * @param relationship
	 *            New value of property relationship.
	 */
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	/**
	 * Getter for property nameId.
	 *
	 * @return Value of property nameId.
	 */
	public String getNameId() {
		return this.nameId;
	}

	/**
	 * Setter for property nameId.
	 *
	 * @param nameId
	 *            New value of property nameId.
	 */
	public void setNameId(String nameId) {
		this.nameId = nameId;
	}

	/**
	 * Getter for property added.
	 *
	 * @return Value of property added.
	 */
	public boolean isAdded() {
		return this.added;
	}

	/**
	 * Getter for property added.
	 *
	 * @return Value of property added.
	 */
	public boolean getAdded() {
		return this.added;
	}

	/**
	 * Setter for property added.
	 *
	 * @param added
	 *            New value of property added.
	 */
	public void setAdded(boolean added) {
		this.added = added;
	}

	/**
	 * Getter for property changed.
	 *
	 * @return Value of property changed.
	 */
	public boolean isChanged() {
		return this.changed;
	}

	/**
	 * Getter for property changed.
	 *
	 * @return Value of property changed.
	 */
	public boolean getChanged() {
		return this.changed;
	}

	/**
	 * Setter for property changed.
	 *
	 * @param changed
	 *            New value of property changed.
	 */
	public void setChanged(boolean changed) {
		this.changed = changed;
	}

	/**
	 * Getter for property effectiveDate.
	 *
	 * @return Value of property effectiveDate.
	 */
	public DateBean getEffectiveDate() {
		return this.effectiveDate;
	}

	/**
	 * Setter for property effectiveDate.
	 *
	 * @param bean
	 *            New value of property effectiveDate.
	 */
	public void setEffectiveDate(DateBean bean) {
		this.effectiveDate.setDate(bean);
	}
}
