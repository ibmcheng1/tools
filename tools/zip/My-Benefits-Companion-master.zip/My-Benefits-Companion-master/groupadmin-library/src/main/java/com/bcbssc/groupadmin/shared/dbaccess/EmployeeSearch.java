/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/EmployeeSearch.java_v  $
 * $Workfile:   EmployeeSearch.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:16  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/EmployeeSearch.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:14:16   EN80
 * Initial revision.
 * 
 *    Rev 1.12   Apr 28 2009 10:18:02   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.11   Oct 03 2006 16:33:24   rx22r
 * Updated the employee search query to handle the payroll deduction amount display as part of the DB2 upgrade.
 * 
 *    Rev 1.10   May 09 2006 10:33:14   rx08e
 * Changes for Vision Coverage.	
 *
 *    Rev 1.9   Feb 16 2006 09:33:26   rx24c
 * Old SQL for maintain Insured Employee replaced with the new query
 *
 *    Rev 1.8   Jan 05 2006 17:28:14   rx08e
 * Fixed the query for the rounding error.
 *
 *    Rev 1.7   Dec 14 2005 17:35:54   rx08e
 * Changed the query to calculate the premium amts correctly
 *
 *    Rev 1.6   Sep 29 2005 15:20:22   rx08e
 * Changed the SQL to get the details about payroll amt
 *
 *    Rev 1.5   Mar 17 2005 17:12:22   rxg97
 * Added descending search support.
 *
 *    Rev 1.4   Feb 18 2005 09:39:00   rxg97
 * Set idNumber to uppercase before search.
 *
 *    Rev 1.3   Feb 16 2005 09:54:50   rdq70
 * Removed SQL formatting of gender and status. Fixed incorrect usage of empty collection.
 *
 *    Rev 1.2   Feb 15 2005 15:09:34   rxg97
 * Now returns a Collection for search by ID.
 *
 *    Rev 1.1   Feb 10 2005 12:05:14   rdq70
 * Added sort order options.
 *
 *    Rev 1.0   Feb 10 2005 11:43:32   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.dbaccess;

import com.bcbssc.groupadmin.shared.dto.InsuredSearchDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredSearchResult;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

import org.apache.log4j.Logger;

/**
 * Searches for employees based on given criteria.
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class EmployeeSearch extends AbstractDBSearch {

	/** The log4j logger for this class. */
	private static final Logger log = Logger.getLogger(EmployeeSearch.class);

	/** <code>true</code> if searching for active employees. */
	private boolean activeSearch;

	/** <code>true</code> if searching for terminated employees. */
	private boolean terminatedSearch;

	/** The ORDER BY expression for the SQL. */
	private String orderBy;

	/** The action - ADD/MODIFY insured employee performed */
	private String actionType;

	/** The action - period selected in maintain insured employee */
	private String periodSelected;

	/**
	 * Creates an <code>EmployeeSearch</code> and configures it with an INI
	 * file.
	 *
	 * @param iniFile
	 *            file path of the configuration INI file.
	 */
	public EmployeeSearch(String iniFile) {
		super(iniFile, "GCOM_TABLE");
	}

	/**
	 * Creates a list of active and/or terminated employees for a group.<br>
	 *
	 * <pre>
	 *     QMF NAME: RX13U.WEB_SQL_4_A
	 *     TSO NAME: WEBSQL4A
	 * </pre>
	 *
	 * @param searchData
	 *            the bean containing criteria for the search.
	 * @return a collection populated with the search results.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 */
	public Collection performSearch(InsuredSearchDTO searchData)
			throws SQLException {
		this.checkInit(); // Necessary since we need the _dbSchema before the
		// query creation

		final String company = searchData.getCompany();
		final String prefix = searchData.getGroupPrefix();
		final String groupNo = searchData.getGroupBase();
		final String division = searchData.getDivisionCode();

		EmployeeSearch.log.debug("company: " + company + " prefix: " + prefix
				+ " groupNo: " + groupNo + " division: " + division);

		this.actionType = searchData.getActionType();
		this.periodSelected = searchData.getPayPeriod();

		if ("".equals(this.periodSelected) || (this.periodSelected == null)) {
			this.periodSelected = "1";
		}

		this.setSearchStatus(searchData);

		final String[] params;

		params = new String[] { company, prefix, groupNo, division };

		return this.performSearch(this.get4aSql(), params);
	}

	/**
	 * Retrieves an active or terminated employee for a group by their
	 * certificate ID.<br>
	 *
	 * <pre>
	 *     QMF NAME: RX13U.RX13U.WEB_SQL_4_B
	 *     TSO NAME: WEBSQL4B
	 * </pre>
	 *
	 * @return .
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 * @param searchData a {@link com.bcbssc.groupadmin.shared.dto.InsuredSearchDTO} object.
	 */
	public Collection performSearchById(InsuredSearchDTO searchData)
			throws SQLException {
		this.checkInit(); // Necessary since we need the _dbSchema before the
		// query creation

		final String company = searchData.getCompany();
		final String prefix = searchData.getGroupPrefix();
		final String groupNo = searchData.getGroupBase();
		final String division = searchData.getDivisionCode();
		final String idNo = searchData.getSearchIdentificationNumber()
				.toUpperCase();

		this.actionType = searchData.getActionType();
		this.periodSelected = searchData.getPayPeriod();

		if ("".equals(this.periodSelected) || (this.periodSelected == null)) {
			this.periodSelected = "1";
		}

		this.setSearchStatus(searchData);

		final String[] params;

		params = new String[] { company, prefix, groupNo, division, idNo };

		return this.performSearch(this.get4bSql(), params);
	}

	/**
	 * Creates a list of active and/or terminated employees for a group by their
	 * full or partial last name.<br>
	 *
	 * <pre>
	 *     QMF NAME: RX13U.WEB_SQL_4_C
	 *     TSO NAME: WEBSQL4C
	 * </pre>
	 *
	 * @param searchData
	 *            the bean containing criteria for the search.
	 * @return a collection populated with the search results.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 */
	public Collection performSearchByName(InsuredSearchDTO searchData)
			throws SQLException {
		this.checkInit(); // Necessary since we need the _dbSchema before the
		// query creation

		final String company = searchData.getCompany();
		final String prefix = searchData.getGroupPrefix();
		final String groupNo = searchData.getGroupBase();
		final String division = searchData.getDivisionCode();
		final String lastName = searchData.getSearchLastName().toUpperCase()
				+ "%";

		this.actionType = searchData.getActionType();
		this.periodSelected = searchData.getPayPeriod();

		if ("".equals(this.periodSelected) || (this.periodSelected == null)) {
			this.periodSelected = "1";
		}

		this.setSearchStatus(searchData);

		final String[] params;

		params = new String[] { company, prefix, groupNo, division, lastName };

		return this.performSearch(this.get4cSql(), params);
	}

	/**
	 * {@inheritDoc}
	 *
	 * Adds data from the given result set to the search results.
	 */
	protected void addSearchItem(ResultSet data, Object obj)
			throws SQLException {
		final InsuredSearchResult employee;

		employee = new InsuredSearchResult();
		((Collection) obj).add(employee);

		employee.setIdentificationNumber(data.getString("CERT_ID").trim());
		employee.setLastName(data.getString("CN_LST_NME").trim());
		employee.setGivenName(data.getString("CN_FRST_NME").trim());
		employee.setMiddleIni(data.getString("CN_INIT").trim());
		employee.setDateOfBirth(DatabaseProxy
				.getDateBean(data.getString("DOB")));
		employee.setGender(data.getString("CN_SEX_ID"));
		employee.setStatus(data.getString("CERT_MBR_STAT"));
		employee.setCoverageClassDescription(data.getString("EMPLY_CLASS")
				.trim()); // ???
		employee.setPremium(data.getString("PREMIUM"));
		employee.setLastProcessedDate(DatabaseProxy.getDateBean(data
				.getString("LAST_PROCESSED_DT")));

		if ("MODIFY".equals(this.actionType)) {
			employee.setLifePremium(data.getString("VOL_LIFE_PREM"));
			employee.setLifePremiumPayPeriod(data
					.getString("VOL_LIFE_PREM_PDA"));

			employee.setDentalPremium(data.getString("VOL_DNTL_PREM"));
			employee.setDentalPremiumPayPeriod(data
					.getString("VOL_DNTL_PREM_PDA"));

			employee.setVisionPremium(data.getString("VOL_VISN_PREM"));
			employee.setVisionPremiumPayPeriod(data
					.getString("VOL_VISN_PREM_PDA"));

			employee.setStdPremium(data.getString("VOL_STD_PREM"));
			employee.setStdPremiumPayPeriod(data.getString("VOL_STD_PREM_PDA"));

			employee.setLtdPremium(data.getString("VOL_LTD_PREM"));
			employee.setLtdPremiumPayPeriod(data.getString("VOL_LTD_PREM_PDA"));

			employee.setTotalPremium(data.getString("VOL_ALL_PREM"));
			employee.setTotalPremiumPayPeriod(data
					.getString("VOL_ALL_PREM_PDA"));
		}
	}

	/**
	 * Returns the SQL for a 4A query.
	 * 
	 * @return the SQL for this query.
	 */
	private String get4aSql() {
		final StringBuffer sql = new StringBuffer(5000);

		this.appendSelectClause(sql);
		this.appendWhereClause(sql);
		sql.append("   AND A.CERT_ID = B.CERT_ID"
				+ "   AND B.CERT_ID = C.CERT_ID"
				+ "   AND C.CERT_ID = D.CERT_ID"
				+ "   AND D.CC_CVG_STAT = (CASE A.CERT_MBR_STAT"
				+ "          WHEN '1' THEN '1'" + "          WHEN '9' THEN '9'"
				+ "          END)"
				+ "   AND D.CC_CEASE_REAS = (CASE A.CERT_MBR_STAT"
				+ "            WHEN '1' THEN ' '"
				+ "           WHEN '9' THEN D.CC_CEASE_REAS"
				+ "           END)");
		this.appendGroupByClause(sql);
		sql.append(" ORDER BY ").append(this.orderBy);
		EmployeeSearch.log.debug("SQL: employee list by group="
				+ sql.toString());
		return sql.toString();
	}

	/**
	 * Returns the SQL for a 4B query.
	 * 
	 * @return the SQL for this query.
	 */
	private String get4bSql() {
		final StringBuffer sql = new StringBuffer(5000);

		this.appendSelectClause(sql);
		this.appendWhereClause(sql);
		sql.append("   AND A.CERT_ID = ?" + "   AND A.CERT_ID = B.CERT_ID"
				+ "   AND B.CERT_ID = C.CERT_ID"
				+ "   AND C.CERT_ID = D.CERT_ID"
				+ "   AND D.CC_CVG_STAT = (CASE A.CERT_MBR_STAT"
				+ "          WHEN '1' THEN '1'" + "          WHEN '9' THEN '9'"
				+ "          END)"
				+ "   AND D.CC_CEASE_REAS = (CASE A.CERT_MBR_STAT"
				+ "            WHEN '1' THEN ' '"
				+ "           WHEN '9' THEN D.CC_CEASE_REAS"
				+ "           END)");

		this.appendGroupByClause(sql);
		sql.append(" ORDER BY ").append(this.orderBy);
		EmployeeSearch.log.debug("SQL: employee list by ID=" + sql.toString());
		return sql.toString();
	}

	/**
	 * Returns the SQL for a 4C query.
	 * 
	 * @return the SQL for this query.
	 */
	private String get4cSql() {
		final StringBuffer sql = new StringBuffer(5000);

		this.appendSelectClause(sql);
		this.appendWhereClause(sql);
		sql.append("   AND A.CERT_ID = B.CERT_ID"
				+ "   AND B.CERT_ID = C.CERT_ID"
				+ "   AND C.CERT_ID = D.CERT_ID" + "   AND B.CN_LST_NME LIKE ?"
				+ "   AND D.CC_CVG_STAT = (CASE A.CERT_MBR_STAT"
				+ "          WHEN '1' THEN '1'" + "          WHEN '9' THEN '9'"
				+ "          END)"
				+ "   AND D.CC_CEASE_REAS = (CASE A.CERT_MBR_STAT"
				+ "            WHEN '1' THEN ' '"
				+ "           WHEN '9' THEN D.CC_CEASE_REAS"
				+ "           END)");
		this.appendGroupByClause(sql);
		sql.append(" ORDER BY ").append(this.orderBy);
		EmployeeSearch.log.debug("SQL:employee list by name=" + sql.toString());
		return sql.toString();
	}

	/**
	 * Appends the common SELECT clause to the given string buffer.
	 * 
	 * @param buf
	 *            the target string buffer.
	 */
	private void appendSelectClause(final StringBuffer buf) {

		if ("ADD".equals(this.actionType)) {
			buf
					.append(
							" SELECT A.CERT_ID"
									+ "    , B.CN_LST_NME"
									+ "    , B.CN_FRST_NME"
									+ "    , B.CN_INIT"
									+ "    , CHAR(B.CN_DOB,USA) \"DOB\""
									+ "    , B.CN_SEX_ID"
									+ "    , A.CERT_MBR_STAT"
									+ "    , C.EMPLY_CLASS"
									+ "    , SUM(D.BILL_PREM_MO_UNIT) \"PREMIUM\""
									+ "    , CHAR(A.LST_MISC_TRANS_DT,USA) \"LAST_PROCESSED_DT\""
									+ " FROM ").append(this._dbSchema).append(
							".VCERTMSZ A" + "    , ").append(this._dbSchema)
					.append(".VCERTNMZ B" + "    , ").append(this._dbSchema)
					.append(".VCERTBDZ C" + "    , ").append(this._dbSchema)
					.append(".VCERTCVZ D");
		} else if ("MODIFY".equals(this.actionType)) {
			buf
					.append(
							"       SELECT A.CERT_ID "
									+ "       , B.CN_LST_NME "
									+ "      , B.CN_FRST_NME "
									+ "       , B.CN_INIT "
									+ "       , CHAR(B.CN_DOB,USA) \"DOB\" "
									+ "       , B.CN_SEX_ID "
									+ "       , A.CERT_MBR_STAT "
									+ "       , C.EMPLY_CLASS "
									+ "       , SUM(D.BILL_PREM_MO_UNIT) \"PREMIUM\" "
									+

									// --** CALCULATE PAYROLL DEDUCTION AMOUNTS
									// FOR VOLUNTARY LIFE **
									"       , SUM(CASE "
									+ "             WHEN D.MEDC_TYP_CD BETWEEN '01' AND '05' "
									+ "             THEN (CASE D.LINE_OF_BUS "
									+ "                   WHEN '01' "
									+ "                   THEN DECIMAL(ROUND(((D.BILL_PREM_MO_UNIT*12.0)/"
									+ this.periodSelected
									+ "),2),16,2)"
									+ "                   ELSE 0 END) "
									+ "             ELSE 0 END) \"VOL_LIFE_PREM_PDA\" "
									+ "       , SUM(CASE "
									+ "             WHEN D.MEDC_TYP_CD BETWEEN '01' AND '05' "
									+ "             THEN (CASE D.LINE_OF_BUS "
									+ "                   WHEN '01' "
									+ "                   THEN D.BILL_PREM_MO_UNIT "
									+ "                   ELSE 0 END) "
									+ "             ELSE 0 END) \"VOL_LIFE_PREM\" "
									+
									// --** CALCULATE PAYROLL DEDUCTION AMOUNTS
									// FOR VOLUNTARY DENTAL **
									"       , SUM(CASE D.MEDC_TYP_CD "
									+ "             WHEN '25' "
									+ "             THEN (CASE D.LINE_OF_BUS "
									+ "                   WHEN '01' "
									+ "                   THEN DECIMAL(ROUND(((D.BILL_PREM_MO_UNIT*12.0)/"
									+ this.periodSelected
									+ "),2),16,2)"
									+ "                   ELSE 0 END) "
									+ "             ELSE 0 END) \"VOL_DNTL_PREM_PDA\" "
									+ "       , SUM(CASE D.MEDC_TYP_CD "
									+ "             WHEN '25' "
									+ "             THEN (CASE D.LINE_OF_BUS "
									+ "                   WHEN '01' "
									+ "                   THEN D.BILL_PREM_MO_UNIT "
									+ "                   ELSE 0 END) "
									+ "             ELSE 0 END) \"VOL_DNTL_PREM\" "
									+
									// --** CALCULATE PAYROLL DEDUCTION AMOUNTS
									// FOR VOLUNTARY VISION **
									"       , SUM(CASE D.MEDC_TYP_CD "
									+ "             WHEN '26' "
									+ "             THEN (CASE D.LINE_OF_BUS "
									+ "                   WHEN '01' "
									+ "                   THEN DECIMAL(ROUND(((D.BILL_PREM_MO_UNIT*12.0)/"
									+ this.periodSelected
									+ "),2),16,2)"
									+ "                   ELSE 0 END) "
									+ "             ELSE 0 END) \"VOL_VISN_PREM_PDA\" "
									+ "       , SUM(CASE D.MEDC_TYP_CD "
									+ "             WHEN '26' "
									+ "             THEN (CASE D.LINE_OF_BUS "
									+ "                   WHEN '01' "
									+ "                   THEN D.BILL_PREM_MO_UNIT "
									+ "                   ELSE 0 END) "
									+ "             ELSE 0 END) \"VOL_VISN_PREM\" "
									+
									// --** CALCULATE PAYROLL DEDUCTION AMOUNTS
									// FOR VOLUNTARY STD **
									"       , SUM(CASE D.MEDC_TYP_CD "
									+ "             WHEN '21' "
									+ "             THEN (CASE D.LINE_OF_BUS "
									+ "                   WHEN '01' "
									+ "                   THEN DECIMAL(ROUND(((D.BILL_PREM_MO_UNIT*12.0)/"
									+ this.periodSelected
									+ "),2),16,2)"
									+ "                   ELSE 0 END) "
									+ "             ELSE 0 END) \"VOL_STD_PREM_PDA\" "
									+ "       , SUM(CASE D.MEDC_TYP_CD "
									+ "             WHEN '21' "
									+ "             THEN (CASE D.LINE_OF_BUS"
									+ "                   WHEN '01' "
									+ "                   THEN D.BILL_PREM_MO_UNIT  "
									+ "                   ELSE 0 END) "
									+ "             ELSE 0 END) \"VOL_STD_PREM\" "
									+
									// --** CALCULATE PAYROLL DEDUCTION AMOUNTS
									// FOR VOLUNTARY LTD **
									"       , SUM(CASE D.MEDC_TYP_CD "
									+ "             WHEN '22' "
									+ "             THEN (CASE D.LINE_OF_BUS "
									+ "                   WHEN '01' "
									+ "                   THEN DECIMAL(ROUND(((D.BILL_PREM_MO_UNIT*12.0)/"
									+ this.periodSelected
									+ "),2),16,2)"
									+ "                   ELSE 0 END) "
									+ "             ELSE 0 END) \"VOL_LTD_PREM_PDA\" "
									+ "       , SUM(CASE D.MEDC_TYP_CD "
									+ "             WHEN '22' "
									+ "             THEN (CASE D.LINE_OF_BUS "
									+ "                   WHEN '01' "
									+ "                   THEN D.BILL_PREM_MO_UNIT "
									+ "                   ELSE 0 END) "
									+ "             ELSE 0 END) \"VOL_LTD_PREM\" "
									+
									// --** CALCULATE PAYROLL DEDUCTION AMOUNTS
									// FOR ALL VOLUNTARY PRODUCTS **
									"       , SUM(CASE "
									+ "             WHEN D.MEDC_TYP_CD BETWEEN '01' AND '05' "
									+ "             THEN (CASE D.LINE_OF_BUS "
									+ "                   WHEN '01' "
									+ "                   THEN DECIMAL(ROUND(((D.BILL_PREM_MO_UNIT*12.0)/"
									+ this.periodSelected
									+ "),2),16,2)"
									+ "                   ELSE 0 END) "
									+ "             WHEN D.MEDC_TYP_CD BETWEEN '21' AND '22' "
									+ "             THEN (CASE D.LINE_OF_BUS "
									+ "                   WHEN '01' "
									+ "                   THEN DECIMAL(ROUND(((D.BILL_PREM_MO_UNIT*12.0)/"
									+ this.periodSelected
									+ "),2),16,2)"
									+ "                   ELSE 0 END) "
									+ "             WHEN D.MEDC_TYP_CD = '25' "
									+ "             THEN (CASE D.LINE_OF_BUS "
									+ "                   WHEN '01' "
									+ "                   THEN DECIMAL(ROUND(((D.BILL_PREM_MO_UNIT*12.0)/"
									+ this.periodSelected
									+ "),2),16,2)"
									+ "                   ELSE 0 END) "
									+ "             WHEN D.MEDC_TYP_CD = '26' "
									+ "             THEN (CASE D.LINE_OF_BUS "
									+ "                   WHEN '01' "
									+ "                   THEN DECIMAL(ROUND(((D.BILL_PREM_MO_UNIT*12.0)/"
									+ this.periodSelected
									+ "),2),16,2)"
									+ "                   ELSE 0 END) "
									+ "             ELSE 0 END) \"VOL_ALL_PREM_PDA\" "
									+ "       , SUM(CASE "
									+ "             WHEN D.MEDC_TYP_CD BETWEEN '01' AND '05' "
									+ "             THEN (CASE D.LINE_OF_BUS "
									+ "                   WHEN '01' "
									+ "                   THEN D.BILL_PREM_MO_UNIT "
									+ "                   ELSE 0 END) "
									+ "             WHEN D.MEDC_TYP_CD BETWEEN '21' AND '22' "
									+ "             THEN (CASE D.LINE_OF_BUS "
									+ "                   WHEN '01' "
									+ "                   THEN D.BILL_PREM_MO_UNIT "
									+ "                  ELSE 0 END)  "
									+ "             WHEN D.MEDC_TYP_CD = '25' "
									+ "             THEN (CASE D.LINE_OF_BUS "
									+ "                  WHEN '01' "
									+ "                  THEN D.BILL_PREM_MO_UNIT "
									+ "                   ELSE 0 END) "
									+ "             WHEN D.MEDC_TYP_CD = '26' "
									+ "             THEN (CASE D.LINE_OF_BUS "
									+ "                  WHEN '01' "
									+ "                  THEN D.BILL_PREM_MO_UNIT "
									+ "                   ELSE 0 END) "
									+ "             ELSE 0 END) \"VOL_ALL_PREM\" "
									+ "       , CHAR(A.LST_MISC_TRANS_DT,USA) \"LAST_PROCESSED_DT\" "
									+

									" FROM ").append(this._dbSchema).append(
							".VCERTMSZ A" + "    , ").append(this._dbSchema)
					.append(".VCERTNMZ B" + "    , ").append(this._dbSchema)
					.append(".VCERTBDZ C" + "    , ").append(this._dbSchema)
					.append(".VCERTCVZ D");
		}
	}

	/**
	 * Appends the common WHERE clause to the given string buffer.
	 * 
	 * @param buf
	 *            the target string buffer.
	 */
	private void appendWhereClause(final StringBuffer buf) {
		String memberStatus = "";
		if (this.activeSearch) {
			memberStatus = "'1'";
		}

		if (this.terminatedSearch) {
			if (this.activeSearch) {
				memberStatus += ",'9'";
			} else {
				memberStatus = "'9'";
			}
		}

		buf.append(" WHERE A.COMP_CD = ?" + "   AND A.COMP_CD = B.COMP_CD"
				+ "   AND B.COMP_CD = C.COMP_CD"
				+ "   AND C.COMP_CD = D.COMP_CD" + "   AND A.GROUP_PRFX = ?"
				+ "   AND A.GROUP_PRFX = B.GROUP_PRFX"
				+ "   AND B.GROUP_PRFX = C.GROUP_PRFX"
				+ "   AND C.GROUP_PRFX = D.GROUP_PRFX"
				+ "   AND A.GROUP_NO = ?" + "   AND A.GROUP_NO = B.GROUP_NO"
				+ "   AND B.GROUP_NO = C.GROUP_NO"
				+ "   AND C.GROUP_NO = D.GROUP_NO" + "   AND A.DIV_ID = ?"
				+ "   AND A.DIV_ID = B.DIV_ID" + "   AND B.DIV_ID = C.DIV_ID"
				+ "   AND C.DIV_ID = D.DIV_ID" + "   AND A.CERT_ID = B.CERT_ID"
				+ "   AND A.CERT_ID = C.CERT_ID"
				+ "   AND A.CERT_ID = D.CERT_ID"
				+ "   AND A.CERT_MBR_STAT IN (" + memberStatus + ")");

	}

	/**
	 * Appends the common GROUP BY clause to the given string buffer.
	 * 
	 * @param buf
	 *            the target string buffer.
	 */
	private void appendGroupByClause(final StringBuffer buf) {
		buf.append(" GROUP BY A.CERT_ID" + "        , B.CN_LST_NME"
				+ "        , B.CN_FRST_NME" + "        , B.CN_INIT"
				+ "        , B.CN_DOB" + "        , B.CN_SEX_ID"
				+ "        , A.CERT_MBR_STAT" + "        , C.EMPLY_CLASS"
				+ "        , A.LST_MISC_TRANS_DT");
	}

	/**
	 * Sets the properties of this search (active, terminated or both, and
	 * order) based on the given criteria.
	 * 
	 * @param searchData
	 *            the bean containing criteria for the search.
	 */
	private void setSearchStatus(InsuredSearchDTO searchData) {
		final String status = searchData.getSearchStatus();
		this.activeSearch = status.indexOf("1") >= 0;
		this.terminatedSearch = status.indexOf("9") >= 0;

		int sortOrder = searchData.getSortOrder();

		if (sortOrder == InsuredSearchDTO.SORT_BY_NAME_DESCENDING) {
			this.orderBy = "2 DESC, 3 DESC, 4 DESC";
		} else if (sortOrder == InsuredSearchDTO.SORT_BY_NAME_ASCENDING) {
			this.orderBy = "2, 3, 4";
		} else if (sortOrder == InsuredSearchDTO.SORT_BY_NUMBER_DESCENDING) {
			this.orderBy = "1 DESC";
		} else {
			this.orderBy = "1";
		}
	}
}
