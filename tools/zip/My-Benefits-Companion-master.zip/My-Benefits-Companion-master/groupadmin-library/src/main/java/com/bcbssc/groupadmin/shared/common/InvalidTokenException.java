/*
 *
 * Created on Sep 6, 2006 
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.common;

import com.bcbssc.netsys.LinkedException;

/**
 * <p>InvalidTokenException class.</p>
 *
 * @author X08E
 * @version $Id: $Id
 */
public class InvalidTokenException extends LinkedException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4309166735324641466L;

	/**
	 * Creates a new instance of InvalidTokenException.
	 */
	public InvalidTokenException() {
		super();
	}

	/**
	 * Creates a new instance of InvalidTokenException with a descriptive
	 * message.
	 *
	 * @param message
	 *            The exception message.
	 */
	public InvalidTokenException(String message) {
		super(message);
	}

	/**
	 * Creates a new instance of InvalidTokenException with a descriptive
	 * message and a root cause.
	 *
	 * @param message
	 *            The exception message.
	 * @param rootCause
	 *            The root cause of this exception.
	 */
	public InvalidTokenException(String message, Throwable rootCause) {
		super(message, rootCause);
	}

	/**
	 * Creates a new instance of InvalidTokenException with the given root
	 * cause.
	 *
	 * @param rootCause
	 *            The root cause of this exception.
	 */
	public InvalidTokenException(Throwable rootCause) {
		super(rootCause);
	}

}
