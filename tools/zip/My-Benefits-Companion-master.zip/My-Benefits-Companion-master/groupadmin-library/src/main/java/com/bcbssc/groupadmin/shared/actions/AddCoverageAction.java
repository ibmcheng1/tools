/*
 * @(#)GroupAdminChangePasswordAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.actions;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;
import com.bcbssc.groupadmin.shared.forms.AddInsuredDetailsForm;
import com.bcbssc.groupadmin.shared.forms.AddRequestChangeForm;
import com.bcbssc.groupadmin.shared.forms.CoverageForm;
import com.bcbssc.groupadmin.shared.forms.DependentForm;
import com.bcbssc.groupadmin.shared.forms.InsuredDataForm;
import com.bcbssc.groupadmin.shared.services.EffectiveDateCalculator;
import com.bcbssc.groupadmin.shared.services.InsuredServices;
import com.bcbssc.struts.action.SimpleDispatchAction;

/**
 * Group Admin Add Coverage Action
 *
 * This class provides control processing for the add insured coverage action.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class AddCoverageAction extends SimpleDispatchAction {

	/** log4j logger */
	private static final Logger log = Logger.getLogger(AddCoverageAction.class
			.getName());

	/** forward names */
	private static final String FORWARD_BACK = "back";

	private static final String FORWARD_CONFIRM = "confirm";

	private static final String FORWARD_DEPENDENTS = "add_dependents";

	private static final String FORWARD_REQUEST_A_CHANGE = "requestachange";

	/**
	 * <p>Constructor for AddCoverageAction.</p>
	 */
	public AddCoverageAction() {
		super();
		if (AddCoverageAction.log.isDebugEnabled()) {
			AddCoverageAction.log.debug("Created AddCoverageAction object.");
		}
	}

	/**
	 * Adds the coverageForm data, forwarding to the next page.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward addCoverage(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		ActionForward forward = null;
		InsuredDataForm insuredDataForm = (InsuredDataForm) form;

		insuredDataForm.updateCoverageItemList();

		// get desired dependent count and actual count
		int desiredDepCount = insuredDataForm.getDentalDependentCount();
		int depExists = insuredDataForm.getDependents().size();
		AddCoverageAction.log.debug("DEP: desired = " + desiredDepCount
				+ ", existing = " + depExists);

		InsuredDataDTO insuredDTO = new InsuredDataDTO();
		BeanUtils.copyProperties(insuredDTO, insuredDataForm);
		InsuredServices.updateNemIndicator(insuredDTO);

		// update the coverages as needed
		InsuredServices.updateCoverageDetails(insuredDTO);

		// The dependent count is also navigation flag.
		if (desiredDepCount > 0) {
			if (desiredDepCount > depExists) {
				for (int j = depExists; j < desiredDepCount; j++) {
					// add as many dependents as they requested
					InsuredServices.addNextDependent(insuredDTO);
				}
			} else {
				InsuredServices.removeDependents(insuredDTO, depExists
						- desiredDepCount);
			}
			DependentForm dependentForm = (DependentForm) this.getForm(
					"dependentForm", "/addDependents", request);
			BeanUtils.copyProperties(dependentForm, insuredDTO);

			request.setAttribute("dependentForm", dependentForm);
			forward = mapping.findForward(AddCoverageAction.FORWARD_DEPENDENTS);
		} else {
			if (depExists > 0) {
				// they don't want any dependents
				insuredDTO.setDependents(new ArrayList());
				AddCoverageAction.log.debug("clear " + depExists
						+ " dependents");
			}
			InsuredServices.removeBlankDependents(insuredDTO);
			BeanUtils.copyProperties(insuredDataForm, insuredDTO);
			String error = EffectiveDateCalculator.getErrorMessage(insuredDTO
					.getCoverageItems());
			if (error != null) {
				this.addGlobalRequestMessage(request, error);
			}

             request.setAttribute("insuredForm", insuredDataForm);
			if(error !=null){




		   			AddRequestChangeForm addRequestChangeForm = (AddRequestChangeForm) this
		   					.getForm("addRequestChangeForm", "/confirmInsuredRequestaChange",
		   							request);
		   			BeanUtils.copyProperties(addRequestChangeForm, form);


				forward = mapping.findForward(AddCoverageAction.FORWARD_REQUEST_A_CHANGE);
			}else{

			forward = mapping.findForward(AddCoverageAction.FORWARD_CONFIRM);
		    }
		}

		return forward;
	}

	/**
	 * Navigates back from the coverage form
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward goBack(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		InsuredDataForm insuredDataForm = (InsuredDataForm) form;
		AddInsuredDetailsForm addInsuredDetailsForm = (AddInsuredDetailsForm) this
				.getForm("addInsuredDetailsForm", "/addInsuredDetails", request);
		BeanUtils.copyProperties(addInsuredDetailsForm, insuredDataForm);
		addInsuredDetailsForm
				.setUserDTO((GroupAdminUserDTO) request
						.getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
		request.setAttribute("addInsuredForm", addInsuredDetailsForm);
		return mapping.findForward(AddCoverageAction.FORWARD_BACK);
	}

	/**
	 * Forwards to the add coverage form, copying data from the input form.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward breadcrumbForward(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		InsuredDataForm insuredDataForm = (InsuredDataForm) form;
		CoverageForm coverageForm = (CoverageForm) this.getForm(
				"addCoverageForm", "/addCoverage", request);
		BeanUtils.copyProperties(coverageForm, insuredDataForm);
		request.setAttribute("addCoverageForm", coverageForm);
		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}
}
