/*
 * @(#)ModifySalaryForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.forms;

import java.util.ArrayList;
import java.util.Collection;

import org.apache.struts.util.LabelValueBean;

/**
 * GroupAdmin Modify Salary Form
 *
 * This bean extends the DependentForm by providing getResettable methods
 * specific to the modify dependent form.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class ModifySalaryForm extends SalaryForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Default the salary change effective date
	 */
	public void copyChangeEffectiveDateToSalaryChangeEffectiveDate() {
		if ("".equals(this.salaryChangeEffectiveDate.getDay())) {
			this.salaryChangeEffectiveDate.setDay(this.changeEffectiveDate
					.getDay());
			this.salaryChangeEffectiveDate.setMonth(this.changeEffectiveDate
					.getMonth());
			this.salaryChangeEffectiveDate.setYear(this.changeEffectiveDate
					.getYear());
		} else if ((this.salaryChangeEffectiveDate.getDay() != this.changeEffectiveDate
				.getDay())
				|| (this.salaryChangeEffectiveDate.getMonth() != this.changeEffectiveDate
						.getMonth())
				|| (this.salaryChangeEffectiveDate.getYear() != this.changeEffectiveDate
						.getYear())) {
			this.salaryChangeEffectiveDate.setDay(this.changeEffectiveDate
					.getDay());
			this.salaryChangeEffectiveDate.setMonth(this.changeEffectiveDate
					.getMonth());
			this.salaryChangeEffectiveDate.setYear(this.changeEffectiveDate
					.getYear());
		}

	}

	/**
	 * Returns a collection of resettable name/value pairs. @ return Collection
	 * of LabelValueBean objects, each containing the name and value of a
	 * resettable property.
	 *
	 * @return a {@link java.util.Collection} object.
	 */
	public Collection getResettables() {
		ArrayList resettables = new ArrayList();

		resettables.add(new LabelValueBean("annualSalaryCents", this
				.getAnnualSalaryCents()));
		resettables.add(new LabelValueBean("annualSalaryDollars", this
				.getAnnualSalaryDollars()));

		return resettables;
	}

	/**
	 * Returns a collection of resettable properties that are referenced by bean @ return
	 * Collection of LabelValueBean objects, each containing the name and value
	 * of a bean-referenced arrayed resettable property.
	 *
	 * @return a {@link java.util.Collection} object.
	 */
	public Collection getBeanResettables() {
		ArrayList resettables = new ArrayList();

		resettables.add(new LabelValueBean("salaryChangeEffectiveDate.month",
				this.getSalaryChangeEffectiveDate().getMonth()));
		resettables.add(new LabelValueBean("salaryChangeEffectiveDate.day",
				this.getSalaryChangeEffectiveDate().getDay()));
		resettables.add(new LabelValueBean("salaryChangeEffectiveDate.year",
				this.getSalaryChangeEffectiveDate().getYear()));

		return resettables;
	}

}
