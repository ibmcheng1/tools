/*
 * @(#)DependentForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.forms;

import com.bcbssc.struts.action.ActionSummary;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

/**
 * GroupAdmin Dependent Form
 *
 * This bean is used to transport data for the add dependent form.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class DependentForm extends InsuredSearchForm {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /**
     * Clears the user-editable data fields for this form
     */
    public void clear() {
        // Resets page back to one blank dependent
        this.setDentalDependentCount(0);
        this.setDependents(new ArrayList());
        // this.addDependent(new Dependent());
    }

    /**
     * {@inheritDoc}
     *
     * Validates the form using the validator support provided by the parent.
     * Also verifies that the passwords match.
     */
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {

        ActionErrors retVal = super.validate(mapping, request);
        ActionSummary.createSummary(retVal);

        return retVal;
    }
}
