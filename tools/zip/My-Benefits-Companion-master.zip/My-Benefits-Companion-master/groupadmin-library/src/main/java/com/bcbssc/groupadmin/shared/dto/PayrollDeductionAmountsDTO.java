/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUE CROSS BLUE SHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION, OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright (c) 2005 Blue Cross Blue Shield of South Carolina.
 * All rights reserved.
 * An independent Licensee of the Blue Cross and Blue Shield Association.
 *
 * PayrollDeductionAmountsDTO.java
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dto/PayrollDeductionAmountsDTO.java_v  $
 * $Workfile:   PayrollDeductionAmountsDTO.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:52  $
 * $Modtime:   May 14 2009 11:33:30  $
 */

package com.bcbssc.groupadmin.shared.dto;

import com.bcbssc.groupadmin.shared.forms.InsuredSearchForm;

/**
 * User Data Transfer Object for Group Administrators
 *
 * This bean contains user profile data
 *
 * @author X22A (B. Smith)
 * @version $Revision:   1.0  $
 */
public class PayrollDeductionAmountsDTO extends InsuredSearchForm {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * access code
	 */
	private String accessCode = null;

	/**
	 * retrieves the access code for this DTO
	 *
	 * @return access code for this DTO
	 */
	public String getAccessCode() {
		return this.accessCode;
	}

	/**
	 * sets the access code for this DTO
	 *
	 * @param accessCode
	 *            access code for this DTO
	 */
	public void setAccessCode(String accessCode) {
		this.accessCode = accessCode;
	}
}
