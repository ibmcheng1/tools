/*
 * @(#)InsuredSearchDTO.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.dto;

import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.struts.common.DateBean;

import java.util.ArrayList;
import java.util.Iterator;

import org.apache.commons.beanutils.BeanUtils;

/**
 * GroupAdmin Insured Data Data Transfer Object
 *
 * This bean contains the insured employee, spouse, dependent and coverage data.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class InsuredSearchDTO extends InsuredDataDTO {

	/** sort order constants */
	public static final int SORT_BY_NAME_ASCENDING = 0;

	/** Constant <code>SORT_BY_NAME_DESCENDING=1</code> */
	public static final int SORT_BY_NAME_DESCENDING = 1;

	/** Constant <code>SORT_BY_NUMBER_ASCENDING=2</code> */
	public static final int SORT_BY_NUMBER_ASCENDING = 2;

	/** Constant <code>SORT_BY_NUMBER_DESCENDING=3</code> */
	public static final int SORT_BY_NUMBER_DESCENDING = 3;

	/**
	 * Holds value of property searchIdentificationNumber.
	 */
	private String searchIdentificationNumber;

	/**
	 * Holds value of property searchLastName.
	 */
	private String searchLastName;

	/**
	 * Holds value of property searchStatus.
	 */
	private String searchStatus;

	/**
	 * Holds value of property searchType.
	 */
	private String searchType;

	/**
	 * Holds value of property selectedID.
	 */
	private String selectedID;

	/**
	 * Holds value of property searchResultsCount.
	 */
	private int searchResultsCount;

	/**
	 * Holds value of property searchResults.
	 */
	private ArrayList searchResults;

	/**
	 * Holds value of property sortOrder.
	 */
	private int sortOrder = InsuredSearchDTO.SORT_BY_NAME_ASCENDING;

	/**
	 * Holds value of property insuredPageUpdated.
	 */
	private boolean insuredPageUpdated;

	/**
	 * Holds value of property coveragePageUpdated.
	 */
	private boolean coveragePageUpdated;

	/**
	 * Holds value of property dependentPageUpdated.
	 */
	private boolean dependentPageUpdated;

	/**
	 * Holds value of property addressUpdated.
	 */
	private boolean addressUpdated;

	/**
	 * Holds value of property addressAdded.
	 */
	private boolean addressAdded;

	/**
	 * Holds value of property termReinstateFlag.
	 */
	private char termReinstateFlag = ' ';

	/**
	 * Holds value of property actionType.
	 */
	private String actionType;

	/**
	 * Holds value of property payPeriod.
	 */
	private String payPeriod;

	/**
	 * Holds value of property productSelected.
	 */
	private String productSelected;

	/**
	 * Holds value of userDTO.
	 */
	private GroupAdminUserDTO userDTO;

	/**
	 * Setter for userDTO
	 *
	 * @param userDTO
	 *            New value of property userDTO.
	 */
	public void setUserDTO(GroupAdminUserDTO userDTO) {
		this.userDTO = userDTO;
	}

	/**
	 * Getter for userDTO
	 *
	 * @return a {@link com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO} object.
	 */
	public GroupAdminUserDTO getUserDTO() {
		return this.userDTO;
	}

	/**
	 * Getter for property identificationNumber.
	 *
	 * @return Value of property identificationNumber.
	 */
	public String getSearchIdentificationNumber() {
		return this.searchIdentificationNumber;
	}

	/**
	 * Setter for property identificationNumber.
	 *
	 * @param searchIdentificationNumber a {@link java.lang.String} object.
	 */
	public void setSearchIdentificationNumber(String searchIdentificationNumber) {
		this.searchIdentificationNumber = searchIdentificationNumber;
	}

	/**
	 * Getter for property lastName.
	 *
	 * @return Value of property lastName.
	 */
	public String getSearchLastName() {
		return this.searchLastName;
	}

	/**
	 * Setter for property lastName.
	 *
	 * @param searchLastName a {@link java.lang.String} object.
	 */
	public void setSearchLastName(String searchLastName) {
		this.searchLastName = searchLastName;
	}

	/**
	 * Getter for property searchStatus.
	 *
	 * @return Value of property searchStatus.
	 */
	public String getSearchStatus() {
		return this.searchStatus;
	}

	/**
	 * Setter for property searchStatus.
	 *
	 * @param searchStatus
	 *            New value of property searchStatus.
	 */
	public void setSearchStatus(String searchStatus) {
		this.searchStatus = searchStatus;
	}

	/**
	 * Getter for property searchType.
	 *
	 * @return Value of property searchType.
	 */
	public String getSearchType() {
		return this.searchType;
	}

	/**
	 * Setter for property searchType.
	 *
	 * @param searchType
	 *            New value of property searchType.
	 */
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}

	/**
	 * Getter for property searchType.
	 *
	 * @return Value of property searchType.
	 */
	public int getSearchResultsCount() {
		return this.searchResultsCount;
	}

	/**
	 * Setter for property searchResultsCount.
	 *
	 * @param value
	 *            New value of property searchResultsCount.
	 */
	public void setSearchResultsCount(int value) {
		this.searchResultsCount = value;
	}

	/**
	 * Getter for property activeCount.
	 *
	 * @return Value of property activeCount.
	 */
	public int getActiveCount() {
		int count = 0;
		if (this.searchResults != null) {
			Iterator employeeIterator = this.searchResults.iterator();
			while (employeeIterator.hasNext()) {
				InsuredSearchResult employee = (InsuredSearchResult) employeeIterator
						.next();
				if (employee.getStatus().equals(Constants.STATUS_ACTIVE)) {
					count++;
				}
			}
		}

		return count;
	}

	/**
	 * Getter for property selectedID.
	 *
	 * @return Value of property selectedID.
	 */
	public String getSelectedID() {
		return this.selectedID;
	}

	/**
	 * Setter for property selectedID.
	 *
	 * @param selectedID
	 *            New value of property selectedID.
	 */
	public void setSelectedID(String selectedID) {
		this.selectedID = selectedID;
	}

	/**
	 * Getter for property searchResults.
	 *
	 * @return Value of property searchResults.
	 */
	public ArrayList getSearchResults() {
		return this.searchResults;
	}

	/**
	 * Setter for property searchResults.
	 *
	 * @param searchResults
	 *            New value of property searchResults.
	 */
	public void setSearchResults(ArrayList searchResults) {
		this.searchResults = searchResults;
	}

	/**
	 * Getter for property sortOrder.
	 *
	 * @return Value of property sortOrder.
	 */
	public int getSortOrder() {
		return this.sortOrder;
	}

	/**
	 * Setter for property sortOrder.
	 *
	 * @param sortOrder
	 *            New value of property sortOrder.
	 */
	public void setSortOrder(int sortOrder) {
		this.sortOrder = sortOrder;
	}

	/**
	 * Getter for property insuredPageUpdated.
	 *
	 * @return Value of property insuredPageUpdated.
	 */
	public boolean isInsuredPageUpdated() {
		return this.insuredPageUpdated;
	}

	/**
	 * Setter for property insuredPageUpdated.
	 *
	 * @param insuredPageUpdated
	 *            New value of property insuredPageUpdated.
	 */
	public void setInsuredPageUpdated(boolean insuredPageUpdated) {
		this.insuredPageUpdated = insuredPageUpdated;
	}

	/**
	 * Getter for property coveragePageUpdated.
	 *
	 * @return Value of property coveragePageUpdated.
	 */
	public boolean isCoveragePageUpdated() {
		return this.coveragePageUpdated;
	}

	/**
	 * Setter for property coveragePageUpdated.
	 *
	 * @param coveragePageUpdated
	 *            New value of property coveragePageUpdated.
	 */
	public void setCoveragePageUpdated(boolean coveragePageUpdated) {
		this.coveragePageUpdated = coveragePageUpdated;
	}

	/**
	 * Getter for property dependentPageUpdated.
	 *
	 * @return Value of property dependentPageUpdated.
	 */
	public boolean isDependentPageUpdated() {
		return this.dependentPageUpdated;
	}

	/**
	 * Setter for property dependentPageUpdated.
	 *
	 * @param dependentPageUpdated
	 *            New value of property dependentPageUpdated.
	 */
	public void setDependentPageUpdated(boolean dependentPageUpdated) {
		this.dependentPageUpdated = dependentPageUpdated;
	}

	/**
	 * Getter for property dependentCoverageChanged.
	 *
	 * @return Value of property dependentCoverageChanged.
	 */
	public boolean isDependentCoverageChanged() {
		CoverageItemList dcl = (CoverageItemList) this
				.getDependentCoverageItems();
		return dcl.coverageItemChanged();
	}

	/**
	 * Getter for property addressUpdated.
	 *
	 * @return Value of property addressUpdated.
	 */
	public boolean isAddressUpdated() {
		return this.addressUpdated;
	}

	/**
	 * Getter for property addressUpdated.
	 *
	 * @return Value of property addressUpdated.
	 */
	public boolean getAddressUpdated() {
		return this.addressUpdated;
	}

	/**
	 * Setter for property addressUpdated.
	 *
	 * @param addressUpdated
	 *            New value of property addressUpdated.
	 */
	public void setAddressUpdated(boolean addressUpdated) {
		this.addressUpdated = addressUpdated;
	}

	/**
	 * Getter for property addressUpdated.
	 *
	 * @return Value of property addressUpdated.
	 */
	public boolean isAddressAdded() {
		return this.addressAdded;
	}

	/**
	 * Getter for property addressUpdated.
	 *
	 * @return Value of property addressUpdated.
	 */
	public boolean getAddressAdded() {
		return this.addressAdded;
	}

	/**
	 * Setter for property addressUpdated.
	 *
	 * @param addressAdded a boolean.
	 */
	public void setAddressAdded(boolean addressAdded) {
		this.addressAdded = addressAdded;
	}

	/**
	 * Getter for property dependentsChanged.
	 *
	 * @return a boolean.
	 */
	public boolean isDependentChanged() {
		DependentList dl = (DependentList) this.getDependents();
		return dl.dependentChanged();
	}

	/**
	 * Getter for property termReinstateFlag.
	 *
	 * @return Value of property termReinstateFlag.
	 */
	public char getTermReinstateFlag() {
		return this.termReinstateFlag;
	}

	/**
	 * Setter for property termReinstateFlag.
	 *
	 * @param termReinstateFlag
	 *            New value of property termReinstateFlag.
	 */
	public void setTermReinstateFlag(char termReinstateFlag) {
		this.termReinstateFlag = termReinstateFlag;
	}

	/**
	 * Getter for property actionType.
	 *
	 * @return Value of property actionType.
	 */
	public String getActionType() {
		return this.actionType;
	}

	/**
	 * Setter for property actionType.
	 *
	 * @param actionType a {@link java.lang.String} object.
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	/**
	 * Getter for property payPeriod
	 *
	 * @return Value of property payPeriod .
	 */
	public String getPayPeriod() {
		return this.payPeriod;
	}

	/**
	 * Setter for property payPeriod.
	 *
	 * @param payPeriod
	 *            New value of property payPeriod.
	 */
	public void setPayPeriod(String payPeriod) {
		this.payPeriod = payPeriod;
	}

	/**
	 * Getter for property productSelected
	 *
	 * @return Value of property productSelected .
	 */
	public String getProductSelected() {
		return this.productSelected;
	}

	/**
	 * Setter for property productSelected.
	 *
	 * @param productSelected
	 *            New value of property productSelected.
	 */
	public void setProductSelected(String productSelected) {
		this.productSelected = productSelected;
	}

	/**
	 * Clears non search values (values form parent class, not including the
	 * group number).
	 *
	 * @throws java.lang.Exception
	 *             If BeanUtils throws an exception
	 */
	public void clearNonSearchData() throws Exception {

		// The group-related data items, though contained in parent class, are
		// needed for search.
		String groupNum = this.getGroupNumber();
		String divName = this.getDivisionName();
		DateBean lastBill = this.getLastBillDate();
		DateBean divEffDate = this.getDivisionOriginalEffectiveDate();
		DateBean billDue = this.getBillDueDate();

		InsuredDataDTO blankDataDTO = new InsuredDataDTO();
		BeanUtils.copyProperties(this, blankDataDTO);

		this.setGroupNumber(groupNum);
		this.setDivisionName(divName);
		this.setLastBillDate(lastBill);
		this.setDivisionOriginalEffectiveDate(divEffDate);
		this.setBillDueDate(billDue);
	}
}
