/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dto/BillHistoryDTO.java_v  $
 * $Workfile:   BillHistoryDTO.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:32  $
 * $Modtime:   May 14 2009 11:33:30  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dto/BillHistoryDTO.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:14:32   EN80
 * Initial revision.
 * 
 *    Rev 1.4   Apr 28 2009 10:18:22   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.3   Apr 01 2005 11:15:22   rxr93
 * filter out diplay of fuinky DB2 dates
 * 
 *    Rev 1.2   Mar 04 2005 09:58:32   rxr93
 * add getStatusFormatted
 * 
 *    Rev 1.1   Mar 01 2005 16:20:22   rxr93
 * add formated get methods
 * 
 *    Rev 1.0   Feb 11 2005 11:07:16   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.dto;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.forms.Options;
import com.bcbssc.struts.common.Constants;

/**
 * This bean represents a bill history item.
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class BillHistoryDTO {

	/**
	 * Holds value of property dueDate.
	 */
	private String dueDate = Constants.BLANK_STRING;

	/**
	 * Holds value of property billedAmount.
	 */
	private String billedAmount = Constants.BLANK_STRING;

	/**
	 * Holds value of property premiumPaid.
	 */
	private String premiumPaid = Constants.BLANK_STRING;

	/**
	 * Holds value of property paymentDate.
	 */
	private String paymentDate = Constants.BLANK_STRING;

	/**
	 * Holds value of property status.
	 */
	private String status = Constants.BLANK_STRING;

	/**
	 * Holds value of property remainingAmount.
	 */
	private String remainingAmount = Constants.BLANK_STRING;

	/**
	 * Holds value of property totalDue.
	 */
	private String totalDue = Constants.BLANK_STRING;

	/**
	 * Getter for property dueDate.
	 *
	 * @return Value of property dueDate.
	 */
	public String getDueDate() {
		return this.dueDate;
	}

	/**
	 * Setter for property dueDate.
	 *
	 * @param dueDate
	 *            New value of property dueDate.
	 */
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	/**
	 * Getter for property billedAmount.
	 *
	 * @return Value of property billedAmount.
	 */
	public String getBilledAmount() {
		return this.billedAmount;
	}

	/**
	 * Gets the formatted billedAmount
	 *
	 * @return currency formatted billed amount
	 */
	public String getBilledAmountFormatted() {
		return CommonUtils.formatDecimalCurrency(this.billedAmount);
	}

	/**
	 * Setter for property billedAmount.
	 *
	 * @param billedAmount
	 *            New value of property billedAmount.
	 */
	public void setBilledAmount(String billedAmount) {
		this.billedAmount = billedAmount;
	}

	/**
	 * Getter for property premiumPaid.
	 *
	 * @return Value of property premiumPaid.
	 */
	public String getPremiumPaid() {
		return this.premiumPaid;
	}

	/**
	 * Gets the formatted premiumPaid
	 *
	 * @return currency formatted premiumPaid
	 */
	public String getPremiumPaidFormatted() {
		return CommonUtils.formatDecimalCurrency(this.premiumPaid);
	}

	/**
	 * Setter for property premiumPaid.
	 *
	 * @param premiumPaid
	 *            New value of property premiumPaid.
	 */
	public void setPremiumPaid(String premiumPaid) {
		this.premiumPaid = premiumPaid;
	}

	/**
	 * Getter for property paymentDate.
	 *
	 * @return Value of property paymentDate.
	 */
	public String getPaymentDate() {
		return this.paymentDate;
	}

	/**
	 * Getter for property paymentDate.
	 *
	 * @return Value of property paymentDate.
	 */
	public String getPaymentDateFormatted() {
		return com.bcbssc.registration.common.CommonUtils
				.filterDB2Date(this.paymentDate);
	}

	/**
	 * Setter for property paymentDate.
	 *
	 * @param paymentDate
	 *            New value of property paymentDate.
	 */
	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	/**
	 * Getter for property status.
	 *
	 * @return Value of property status.
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * Getter for property status (formatted as String).
	 *
	 * @return Value of property status.
	 */
	public String getStatusFormatted() {
		Options options = Options.getGroupAdminInstance();
		String value = com.bcbssc.struts.forms.Options.getLabelFromValue(
				options.getBillStatusOptions(), this.status);
		return value;
	}

	/**
	 * Setter for property status.
	 *
	 * @param status
	 *            New value of property status.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Getter for property remainingAmount.
	 *
	 * @return Value of property remainingAmount.
	 */
	public String getRemainingAmount() {
		return this.remainingAmount;
	}

	/**
	 * Gets the formatted remaining amount
	 *
	 * @return currency formatted remaining amount
	 */
	public String getRemainingAmountFormatted() {
		return CommonUtils.formatDecimalCurrency(this.remainingAmount);
	}

	/**
	 * Setter for property remainingAmount.
	 *
	 * @param remainingAmount
	 *            New value of property remainingAmount.
	 */
	public void setRemainingAmount(String remainingAmount) {
		this.remainingAmount = remainingAmount;
	}

	/**
	 * Getter for property totalDue.
	 *
	 * @return Value of property totalDue.
	 */
	public String getTotalDue() {
		return this.totalDue;
	}

	/**
	 * Gets the formatted total due
	 *
	 * @return currency formatted total due
	 */
	public String getTotalDueFormatted() {
		return CommonUtils.formatDecimalCurrency(this.totalDue);
	}

	/**
	 * Setter for property totalDue.
	 *
	 * @param totalDue
	 *            New value of property totalDue.
	 */
	public void setTotalDue(String totalDue) {
		this.totalDue = totalDue;
	}
}
