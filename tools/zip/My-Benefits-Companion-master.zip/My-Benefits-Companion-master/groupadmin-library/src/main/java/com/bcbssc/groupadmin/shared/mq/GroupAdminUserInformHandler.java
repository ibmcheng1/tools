/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mq/GroupAdminUserInformHandler.java_v  $
 * $Workfile:   GroupAdminUserInformHandler.java  $
 * $Revision:   1.1  $
 * $Date:   Sep 08 2010 09:37:26  $
 * $Modtime:   Jul 26 2010 10:40:52  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mq/GroupAdminUserInformHandler.java_v  $
 *
 *    Rev 1.1   Sep 08 2010 09:37:26   x94s
 * RD188C Creating closed inform when user registers his profile
 *
 *    Rev 1.0   Jun 26 2009 15:16:10   EN80
 * Initial revision.
 *
 *    Rev 1.15   Apr 28 2009 10:20:12   rff74
 * Java6 Upgrade
 *
 *    Rev 1.14   Jun 21 2006 10:44:58   rx35d
 * c03784 - Dead Letter Queqe Issue where a MQ record with a length > 2124 x 200.
 *
 *    Rev 1.13   Nov 30 2005 14:44:18   rcf57
 * C03785 : Removed the change made in the previous version.
 *
 *    Rev 1.12   Nov 07 2005 14:27:02   rcf57
 * C03785 : Fix to remove the request lines from update informs generated when a user creates a profile.
 *
 *    Rev 1.11   Jan 25 2005 10:58:02   rxg50
 * updated to remove dashes from group #
 *
 *    Rev 1.10   Dec 15 2004 15:30:38   rxg97
 * Fixed StringBuffer.append useage.
 *
 *    Rev 1.9   Dec 15 2004 12:13:54   rxg97
 * Added appName and appType support.
 *
 *    Rev 1.8   Nov 23 2004 15:51:06   rxg97
 * Fixed lastname/ssn display in INFOrm.
 *
 *    Rev 1.7   Nov 18 2004 13:53:18   rxg97
 * Hammurapi updates.
 *
 *    Rev 1.6   Nov 15 2004 10:40:48   rxg97
 * Added support for using USER_INFO_TYPE from config file.
 *
 *    Rev 1.5   Oct 22 2004 14:26:34   rxg97
 * Removed accountLocked from test method.
 *
 *    Rev 1.4   Sep 29 2004 14:39:40   rxg97
 * CommonInformUtils.sendMessage
 *
 *    Rev 1.3   Sep 28 2004 13:31:22   rxg97
 * Added size to StringBuffer constructor.
 *
 *    Rev 1.2   Sep 24 2004 14:36:34   rxg97
 * Enabled sending of messages and moved MQ sending internals to CommonInformUtils.
 *
 *    Rev 1.1   Sep 22 2004 17:01:48   rxg97
 * Removed notifyflag references.
 *
 *    Rev 1.0   Sep 22 2004 10:18:34   rxg97
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.mq;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import com.bcbssc.groupadmin.shared.dto.CoverageItem;
import com.bcbssc.groupadmin.shared.dto.CoverageItemList;
import com.bcbssc.groupadmin.shared.dto.Dependent;
import com.bcbssc.groupadmin.shared.dto.DependentList;
import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredRequestChangeSearchDTO;
import com.bcbssc.netsys.Config;
import com.bcbssc.netsys.inform.InformEndLine;
import com.bcbssc.netsys.inform.InformInquiryLine;
import com.bcbssc.netsys.inform.InformUtil;

/**
 * Handles Group Admin INFOrm messaging for user events.
 *
 * @author rxg97 (Jonathan Egger)
 * @version $Id: $Id
 */
public class GroupAdminUserInformHandler {

	/** log4j logger */
	private static final Logger logger = Logger
			.getLogger(GroupAdminUserInformHandler.class);

	/** the application-specific INI file */
	private String iniFile;

	/** the application-specific RPN value */
	private String rpn;

	/** the application-specific company code value */
	private String companyCode;

	/** the application-specific corporate code value */
	private String corporateCode;

	/** the application-specific deparment code value */
	private String departmentCode;

	/** the application-specific division code value */
	private String divisionCode;

	/** the application-specific code request employee ID */
	private String codeRequestEmployeeId;

	/** the application-specific profile created employee ID */
	private String profileCreatedEmployeeId;

	/** the application-specific INFO TYPE */
	private String infoType;

	/** the application-specific name */
	private String appName;

	/** the application-specific name */
	private String appType;

	private String CHANGE_COVERAGE_MEMBER = "change-mem-coverage";

	private String TERMINATE_MEMBER ="term-mem";

	private String REINSTATE_MEMBER ="reinstate-mem";

	private String CHANGE_DEPENDENT_COVERAGE = "change-dep-cov";

	private String CHANGE_DEPENDENT_INFO = "change-dep-info";

	private String TERMINATE_DEPENDENT = "term-dep";

	private String requestaChangeEmployeeId;
    /** function related: corrspName */
	String corrspName;
	/** function related: */
	private String requestCode;
	/** function related content */
	private String requestLines;

	private  String inFile;

	private String FILLER_EMPTY = "                                                                          ";



	/**
	 * Creates a new instance of GroupAdminUserInformHandler, setting the
	 * application-specific INFOrm parameters based on the specified ini file.
	 *
	 * @param iniFileName
	 *            file containing the application-specific parameters
	 */
	public GroupAdminUserInformHandler(String iniFileName) {
		super();

		this.iniFile = iniFileName;
		this.rpn = Config.getPrivateProfileString("MISC", "RPN", "",
				this.iniFile);
		this.companyCode = Config.getPrivateProfileString("MISC",
				"COMPANY_CODE", "", this.iniFile);
		this.corporateCode = Config.getPrivateProfileString("MISC",
				"CORPORATE_CODE", "", this.iniFile);
		this.departmentCode = Config.getPrivateProfileString("MISC",
				"DEPARTMENT_CODE", "", this.iniFile);
		this.divisionCode = Config.getPrivateProfileString("MISC",
				"DIVISION_CODE", "", this.iniFile);
		this.codeRequestEmployeeId = Config.getPrivateProfileString("MISC",
				"CODE_REQUEST_EMP_ID", "", this.iniFile);
		this.profileCreatedEmployeeId = Config.getPrivateProfileString("MISC",
				"PROFILE_CREATED_EMP_ID", "", this.iniFile);
		this.infoType = Config.getPrivateProfileString("MISC",
				"USER_INFO_TYPE", "", this.iniFile);
		this.appName = Config.getPrivateProfileString("MISC", "APP_NAME", "",
				this.iniFile);
		this.appType = Config.getPrivateProfileString("MISC", "APP_TYPE", "",
				this.iniFile);

	    this.requestaChangeEmployeeId = Config.getPrivateProfileString("MISC",
				"REQUEST_A_CHANGE_EMP_ID", "", this.iniFile);

        this.inFile = Config.getPrivateProfileString("MISC",
				"INFO_REQUEST_FILE", "", this.iniFile);
	}

	/**
	 * Creates and sends a profile completed INFOrm for the specified user.
	 *
	 * @param user
	 *            user for which the INFOrm will be sent.
	 */
	public void sendProfileCreatedInform(GroupAdminUserDTO user) {

		GroupAdminUserInformHandler.logger
				.debug("Creating ClifeInformMessage for profile created");
		GroupAdminRegInformMessage gaim = new GroupAdminRegInformMessage();
		// CssbInformMessage cim = new CssbInformMessage();

		GroupAdminUserInformHandler.logger.debug("Creating InformHeaderBean");
		InformHeader ihb = new InformHeader();
		ihb.setInfoType(this.infoType);
		ihb.setKeyId(user.getGroupNumberStripped());
		ihb.setAltKeyId(user.getAccessCode());
		ihb.setRpn(this.rpn);
		ihb.setCompanyCode(this.companyCode);
		ihb.setCorporateCode(this.corporateCode);
		ihb.setDepartmentCode(this.departmentCode);
		ihb.setDivisionCode(this.divisionCode);
		ihb.setEmployeeId(this.profileCreatedEmployeeId);

		ihb.setAction("A");
		ihb.setStatusCode("1");
		ihb.setStatusType("CL");

		// ClaimNumber is an unused field we can use for appName
		StringBuffer corrspName = new StringBuffer(32);
		corrspName.append(this.appType).append(": ").append(this.appName);
		ihb.setClaimNumber(corrspName.toString());

		gaim.setHeader(ihb);

		gaim.addLine(new InformInquiryLine());

		StringBuffer verbiage = new StringBuffer(512);
		verbiage.append(this.appType).append(":REGISTRATION SUCCESSFUL\n");
		this.addUserInfoVerbiage(verbiage, user);
		InformUtil.addRequestLines(gaim, verbiage.toString());
		gaim.addLine(new InformEndLine());

		CommonInformUtils.sendMessage(gaim, "PROFILECREATED", this.iniFile);
	}

	/**
	 * Creates and sends an access code request INFOrm for the specified user.
	 *
	 * @param user
	 *            user for which the INFOrm will be sent.
	 */
	public void sendCodeRequestInform(GroupAdminUserDTO user) {

		GroupAdminInformMessage gaim = new GroupAdminInformMessage();
		// CssbInformMessage cim = new CssbInformMessage();

		InformHeader ihb = new InformHeader();
		ihb.setInfoType(this.infoType);
		ihb.setKeyId(user.getGroupNumberStripped());
		ihb.setAltKeyId(user.getAccessCode());
		ihb.setRpn(this.rpn);
		ihb.setCompanyCode(this.companyCode);
		ihb.setCorporateCode(this.corporateCode);
		ihb.setDepartmentCode(this.departmentCode);
		ihb.setDivisionCode(this.divisionCode);
		ihb.setEmployeeId(this.codeRequestEmployeeId);

		ihb.setAction("A");
		ihb.setStatusCode("2");
		ihb.setStatusType("OP");
		// ihb.setStatusType("CL");

		// ClaimNumber is an unused field we can use for appName
		StringBuffer corrspName = new StringBuffer(32);
		corrspName.append("WEB").append(this.appType).append(": ").append(
				this.appName);
		ihb.setClaimNumber(corrspName.toString());

		gaim.setHeader(ihb);

		gaim.addLine(new InformInquiryLine());

		StringBuffer verbiage = new StringBuffer(512);
		verbiage.append(this.appType).append(":REQUEST ACCESS CODE\n");
		this.addUserInfoVerbiage(verbiage, user);
		InformUtil.addRequestLines(gaim, verbiage.toString());
		gaim.addLine(new InformEndLine());

		CommonInformUtils.sendMessage(gaim, "CODEREQUEST", this.iniFile);
	}

	/**
	 * Adds the verbiage common to the Group Admin User INFOrm messages to the
	 * specified StringBuffer.
	 *
	 * @param verbiage
	 *            StringBuffer that contains the INFOrm verbiage
	 * @param user
	 *            user information to add to the buffer
	 */
	private void addUserInfoVerbiage(StringBuffer verbiage,
			GroupAdminUserDTO user) {
		verbiage.append("First Name: ").append(user.getGivenName())
				.append("\n");
		verbiage.append("Last Name: ").append(user.getLastName()).append("\n");
		verbiage.append("Middle Initial: ").append(user.getMiddleIni()).append(
				" Suffix: ").append(user.getSuffix()).append("\n");
		verbiage.append("Last 6 SSN: ").append(user.getLast6SSN()).append("\n");
		verbiage.append("Date of Birth: ").append(user.getDateOfBirth())
				.append("\n");
		verbiage.append("Address Line 1: ").append(user.getStreet()).append(
				"\n");
		verbiage.append("Address Line 2: ").append(user.getAddressLine2())
				.append("\n");
		verbiage.append("City: ").append(user.getCity()).append("\n");
		verbiage.append("State: ").append(user.getState()).append("\n");
		verbiage.append("ZIP Code: ").append(user.getPostalCode()).append("\n");
		verbiage.append("Country: ").append(user.getCountry()).append("\n");
		verbiage.append("Group Number ").append(user.getGroupNumberStripped())
				.append("\n");
		verbiage.append("Group Name: ").append(user.getGroupName())
				.append("\n");
		verbiage.append("E-mail: ").append(user.getMail()).append(
				"\n");
		verbiage.append("Phone: ").append(user.getTelephoneNumber()).append(
				"\n");
		verbiage.append("Extension: ").append(user.getTelephoneExt()).append(
				"\n");
		verbiage.append("Fax: ").append(user.getFax()).append("\n");
	}


	/**
	 * <p>sendChangeRequestInform.</p>
	 *
	 * @param insuredDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredRequestChangeSearchDTO} object.
	 */
	public void sendChangeRequestInform(InsuredRequestChangeSearchDTO insuredDTO){

			GroupAdminInformMessage gaim = new GroupAdminInformMessage();
			InformHeader ihb = new InformHeader();
			ihb.setInfoType(this.infoType);
			ihb.setKeyId(insuredDTO.getGroupNumber());
			ihb.setAltKeyId(insuredDTO.getIdentificationNumber());
			ihb.setRpn(this.rpn);
			ihb.setCompanyCode(this.companyCode);
			ihb.setCorporateCode(this.corporateCode);
			ihb.setDepartmentCode(this.departmentCode);
			ihb.setDivisionCode(this.divisionCode);
			ihb.setEmployeeId(this.requestaChangeEmployeeId);

			ihb.setAction("A");
			ihb.setStatusCode("2");
			ihb.setStatusType("OP");
			// ihb.setStatusType("CL");

			// ClaimNumber is an unused field we can use for appName
			StringBuffer corrspName = new StringBuffer(32);
			corrspName.append("WEB").append(this.appType).append(": ").append(
					this.appName);
			ihb.setClaimNumber(corrspName.toString());

			gaim.setHeader(ihb);

			gaim.addLine(new InformInquiryLine());

			StringBuffer verbiage = new StringBuffer(512);
			verbiage.append(this.appType).append(":REQUEST A CHANGE\n");
			this.addInsuredUserInfoVerbiage(verbiage, insuredDTO);
			InformUtil.addRequestLines(gaim, verbiage.toString());
			gaim.addLine(new InformEndLine());

			CommonInformUtils.sendMessage(gaim, "CHANGE_REQUEST", this.iniFile);

	}




	/**
	 * <p>sendAddInsuredRequestChangeInform.</p>
	 *
	 * @param insuredDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredRequestChangeSearchDTO} object.
	 * @throws java.io.FileNotFoundException if any.
	 */
	public void sendAddInsuredRequestChangeInform(InsuredRequestChangeSearchDTO insuredDTO)throws FileNotFoundException {


			InformRequestFormat irf = null;

				   	irf = new InformRequestFormat(inFile);
				   	irf.processLines("AddInsuredRequestChange", insuredDTO);

			// get function specific values
			this.corrspName = irf.getCorrspName();
			this.requestCode = irf.getRequestCode();
			this.requestLines = irf.getFormattedOutput();

			// make header
			GroupAdminUserDTO user =  insuredDTO.getUserDTO();
            logger.debug("sendAddInsuredRequestChangeInform:user "+user+" username="+user.getSamAccountName());
			InformHeader ihb = new InformHeader();
			ihb.setInfoType(this.infoType);
			ihb.setKeyId(insuredDTO.getGroupNumber());
			ihb.setAltKeyId(insuredDTO.getIdentificationNumber());
			ihb.setRpn(this.rpn);
			ihb.setCompanyCode(this.companyCode);
			ihb.setCorporateCode(this.corporateCode);
			ihb.setDepartmentCode(this.departmentCode);
			ihb.setDivisionCode(this.divisionCode);
			ihb.setEmployeeId(this.requestaChangeEmployeeId);

			ihb.setAction("A");
			ihb.setStatusCode("1");
	   	    ihb.setStatusType("OP");

			ihb.setRequestCode(this.requestCode);

			InformMessage cim = new InformMessage();

			// ClaimNumber is an unused field we can use for appName
			ihb.setClaimNumber("WEB" + this.corrspName);

			cim.setHeader(ihb);

			cim.addLine(new InformInquiryLine());

			StringBuffer verbiage = new StringBuffer(512);

			InformUtil.addRequestLines(cim, verbiage.toString());
			verbiage.append("\n").append(this.requestLines);
			//verbiage.append("\n").append(insuredDTO.getReasonForRequest());
			this.prepareReasonForRequest(verbiage,"REASON FOR REQUEST: "+insuredDTO.getReasonForRequest());
			InformUtil.addRequestLines(cim, verbiage.toString());
			cim.addLine(new InformEndLine());

			CommonInformUtils.sendMessage(cim, "GroupAdmin", this.iniFile);

			logger.debug("sendAddInsuredRequestChangeInform: INFOrm sent successfully");
	}




   	private void prepareReasonForRequest(StringBuffer verbiage, String reasonForRequest){

	   int stringLength = 76;

            reasonForRequest = reasonForRequest.replaceAll("\r", "");
            reasonForRequest = reasonForRequest.replaceAll("\n", "");
	   	    String[] tokens = reasonForRequest.split("(?<=\\G.{" + stringLength + "})");
	   	    for(String t : tokens) {
	   	    	verbiage.append("\n").append(t);
	    }
   }


    private void addInsuredUserInfoVerbiage(StringBuffer verbiage,
   				InsuredRequestChangeSearchDTO insuredDTO) {

   	        verbiage.append("GROUP NUMBER: ").append(insuredDTO.getGroupNumber()).append("\n");
   			verbiage.append("DIVISION NAME: ").append(insuredDTO.getDivisionName()).append("\n");
   			verbiage.append("IDENTIFICATION NUMBER:").append(insuredDTO.getIdentificationNumber()).append("\n");
   			verbiage.append("EFFECTIVE DATE: ").append(((CoverageItemList)insuredDTO.getCoverageItems()).getFirstEffectiveDate()).append("\n");
   			verbiage.append("ORIGINAL EFFECTIVE DATE: ").append(insuredDTO.getDivisionOriginalEffectiveDate()).append("\n");
   			verbiage.append("LAST PROCESSED DATE: ").append(insuredDTO.getLastProcessedDate()).append("\n");
   			verbiage.append("\n");
            verbiage.append(FILLER_EMPTY+"\n");
   			verbiage.append("EMPLOYEE LAST NAME:").append(insuredDTO.getLastName()).append("\n");
   			verbiage.append("EMPLOYEE FIRST NAME: ").append(insuredDTO.getGivenName()).append("\n");
   			verbiage.append("EMPLOYEE MI: ").append(insuredDTO.getMiddleIni()).append("\n");
   			verbiage.append("EMPLOYEE DATE OF BIRTH: ").append(insuredDTO.getDateOfBirth()).append("\n");
   			verbiage.append("EMPLOYEE GENDER: ").append(insuredDTO.getGender()).append("\n");

           if (StringUtils.equals(CHANGE_COVERAGE_MEMBER,insuredDTO.getRequestType())){
               verbiage.append("\n");
			   verbiage.append("REQUEST TYPE:CHANGE COVERAGE").append("\n");
		   }

		    if (StringUtils.equals(REINSTATE_MEMBER,insuredDTO.getRequestType())){
               verbiage.append("\n");
		   	   verbiage.append("REQUEST TYPE: REINSTATE MEMBER").append("\n");
		   }

           if(StringUtils.equals(CHANGE_COVERAGE_MEMBER,insuredDTO.getRequestType())){

            verbiage.append("\n");
            verbiage.append(FILLER_EMPTY+"\n");
   			ArrayList coverageItems = 	insuredDTO.getCoverageItems();
   			//Add coverage items
   			for(int i=0;i<coverageItems.size();i++){

   			CoverageItem coverageItem = (CoverageItem)coverageItems.get(i);
            String coverageChanged = ""+coverageItem.getAction();
   			if(StringUtils.equals("S",coverageChanged.trim())){
   			verbiage.append("REQUEST A CHANGE: YES").append("\n");
   			verbiage.append("COVERAGE: ").append(coverageItem.getName()).append("\n");
   			verbiage.append("PREMIUM: ").append(coverageItem.getPremiumFormatted()).append("\n");
   			verbiage.append("% SALARY: ").append(coverageItem.getPercentSalaryFormatted()).append("\n");
   			verbiage.append("MINIMUM VOLUME: ").append(coverageItem.getMinimumVolumeFormatted()).append("\n");
   			verbiage.append("MAXIMUM VOLUME: ").append(coverageItem.getMaximumVolumeFormatted()).append("\n");
   			verbiage.append("WAITING PERIOD: ").append(coverageItem.getWaitingPeriod()).append("\n");
   			verbiage.append("EFFECTIVE DATE OF CHANGE:").append(insuredDTO.getChangeEffectiveDate()).append("\n");

   			 }
   			}

	      }

	       if(StringUtils.equals(REINSTATE_MEMBER,insuredDTO.getRequestType())){

		              verbiage.append("\n");
		              verbiage.append(FILLER_EMPTY+"\n");
		     			ArrayList coverageItems = 	insuredDTO.getCoverageItems();
		     			//Add coverage items
		     			for(int i=0;i<coverageItems.size();i++){

		     			CoverageItem coverageItem = (CoverageItem)coverageItems.get(i);

		     			verbiage.append("REQUEST A CHANGE: YES").append("\n");
		     			verbiage.append("COVERAGE: ").append(coverageItem.getName()).append("\n");
		     			verbiage.append("PREMIUM: ").append(coverageItem.getPremiumFormatted()).append("\n");
		     			verbiage.append("% SALARY: ").append(coverageItem.getPercentSalaryFormatted()).append("\n");
		     			verbiage.append("MINIMUM VOLUME: ").append(coverageItem.getMinimumVolumeFormatted()).append("\n");
		     			verbiage.append("MAXIMUM VOLUME: ").append(coverageItem.getMaximumVolumeFormatted()).append("\n");
		     			verbiage.append("WAITING PERIOD: ").append(coverageItem.getWaitingPeriod()).append("\n");
		     			verbiage.append("EFFECTIVE DATE OF CHANGE:").append(insuredDTO.getChangeEffectiveDate()).append("\n");
		     			verbiage.append("\n");
		                verbiage.append(FILLER_EMPTY+"\n");

		     			}

	      }

	      if (StringUtils.equals(TERMINATE_MEMBER,insuredDTO.getRequestType())){
			  verbiage.append("\n");
			  verbiage.append(FILLER_EMPTY+"\n");
              verbiage.append("REQUEST TYPE:TERMINATE MEMBER").append("\n");
              verbiage.append("REASON FOR REQUEST:").append(insuredDTO.getReasonForRequest()).append("\n");
			  verbiage.append("TERMINATION DATE:").append(insuredDTO.getChangeEffectiveDate()).append("\n");
		  }




		  if (StringUtils.equals(REINSTATE_MEMBER,insuredDTO.getRequestType())){
			  verbiage.append("\n");
			  verbiage.append(FILLER_EMPTY+"\n");
              verbiage.append("REHIRE  DATE:").append(insuredDTO.getReHireDate()).append("\n");
			  verbiage.append("COVERAGE EFFECTIVE DATE:").append(insuredDTO.getCoverageEffectiveDate()).append("\n");
		  }



		  if (StringUtils.equals(CHANGE_DEPENDENT_INFO,insuredDTO.getRequestType())){
			    verbiage.append("\n");
			    verbiage.append(FILLER_EMPTY+"\n");
				verbiage.append("REQUEST TYPE: CHANGE DEPENDENT INFORMATION").append("\n");
				verbiage.append("DEPENDENT LAST NAME: ").append(insuredDTO.getDependentLastName()).append("\n");
				verbiage.append("DEPENDENT FIRST NAME: ").append(insuredDTO.getDependentGivenName()).append("\n");
				verbiage.append("DEPENDENT MI: ").append(insuredDTO.getDependentMiddleIni()).append("\n");
				verbiage.append("DEPENDENT DATE OF BIRTH:  ").append(insuredDTO.getDependentDOB()).append("\n");

				verbiage.append("DEPENDENT GENDER: "+insuredDTO.getDependentGender()).append("\n");
				verbiage.append("DEPENDENT SOCIAL SECURITY NUMBER: "+insuredDTO.getDependentSSN()).append("\n");
				verbiage.append("DEPENDENT RELATIONSHIP: "+insuredDTO.getFormattedDependentRelation()).append("\n");
				verbiage.append("DEPENDENT STUDENT: "+insuredDTO.getFormattedDependetIsStudent()).append("\n");


		  }


		  if ((StringUtils.equals(TERMINATE_DEPENDENT,insuredDTO.getRequestType())) || (StringUtils.equals(CHANGE_DEPENDENT_COVERAGE,insuredDTO.getRequestType()))){

			verbiage.append("\n");
			verbiage.append(FILLER_EMPTY+"\n");
			if(StringUtils.equals(TERMINATE_DEPENDENT,insuredDTO.getRequestType())){
			verbiage.append("REQUEST TYPE: TERMINATE DEPENDENT").append("\n");
			}else if(StringUtils.equals(CHANGE_DEPENDENT_COVERAGE,insuredDTO.getRequestType())){

				verbiage.append("REQUEST TYPE: CHANGE DEPENDENT COVERAGE").append("\n");

				 verbiage.append("\n");
	              verbiage.append(FILLER_EMPTY+"\n");
	     			ArrayList coverageItems = 	insuredDTO.getCoverageItems();
	     			//Add coverage items
	     			for(int i=0;i<coverageItems.size();i++){

	     			CoverageItem coverageItem = (CoverageItem)coverageItems.get(i);

	     			verbiage.append("REQUEST A CHANGE: YES").append("\n");
	     			verbiage.append("COVERAGE: ").append(coverageItem.getName()).append("\n");
	     			verbiage.append("PREMIUM: ").append(coverageItem.getPremiumFormatted()).append("\n");
	     			verbiage.append("% SALARY: ").append(coverageItem.getPercentSalaryFormatted()).append("\n");
	     			verbiage.append("MINIMUM VOLUME: ").append(coverageItem.getMinimumVolumeFormatted()).append("\n");
	     			verbiage.append("MAXIMUM VOLUME: ").append(coverageItem.getMaximumVolumeFormatted()).append("\n");
	     			verbiage.append("WAITING PERIOD: ").append(coverageItem.getWaitingPeriod()).append("\n");
	     			verbiage.append("EFFECTIVE DATE OF CHANGE:").append(insuredDTO.getChangeEffectiveDate()).append("\n");
	     			verbiage.append("\n");
	                verbiage.append(FILLER_EMPTY+"\n");

	     			}
			}

			String dependentInfo = insuredDTO.getChooseTerminateDependent();



			if(dependentInfo.equals("ALL")){

				DependentList dpList = (DependentList)insuredDTO.getDependents();

					for(int i=0;i<dpList.size();i++){

							Dependent dp = (Dependent)dpList.get(i);

							verbiage.append("DEPENDENT LAST NAME: ").append(dp.getLastName()).append("\n");
							verbiage.append("DEPENDENT FIRST NAME: ").append(dp.getGivenName()).append("\n");
							verbiage.append("DEPENDENT MI: ").append(dp.getMiddleIni()).append("\n");
							verbiage.append("DEPENDENT DATE OF BIRTH: ").append(dp.getDateOfBirthFormatted()).append("\n");
							verbiage.append("DEPENDENT GENDER: ").append(dp.getGenderFormatted()).append("\n");
							verbiage.append("DEPENDENT SOCIAL SECURITY NUMBER: ").append(dp.getSsnFormatted()).append("\n");
							verbiage.append("DEPENDENT RELATIONSHIP: ").append(dp.getRelationshipFormatted()).append("\n");
							verbiage.append("DEPENDENT STUDENT: ").append(dp.getStudentFormatted()).append("\n");
					}

                Dependent spouse = insuredDTO.getSpouse();

                if(StringUtils.isNotBlank(spouse.getLastName())){

						verbiage.append("DEPENDENT LAST NAME: ").append(spouse.getLastName()).append("\n");
						verbiage.append("DEPENDENT FIRST NAME: ").append(spouse.getGivenName()).append("\n");
						verbiage.append("DEPENDENT MI: ").append(spouse.getMiddleIni()).append("\n");
						verbiage.append("DEPENDENT DATE OF BIRTH: ").append(spouse.getDateOfBirthFormatted()).append("\n");
						verbiage.append("DEPENDENT GENDER: ").append(spouse.getGenderFormatted()).append("\n");
						verbiage.append("DEPENDENT SOCIAL SECURITY NUMBER: ").append(spouse.getSsnFormatted()).append("\n");
						verbiage.append("DEPENDENT RELATIONSHIP: ").append(spouse.getRelationshipFormatted()).append("\n");
						verbiage.append("DEPENDENT STUDENT: ").append(spouse.getStudentFormatted()).append("\n");
				}

			}else {

							String[] dependentDetails = dependentInfo.split(",");
							GroupAdminUserInformHandler.logger.debug("dependentDetails: "+dependentDetails);
                           	String dependentDob = dependentDetails[4]+"/"+dependentDetails[5]+"/"+dependentDetails[6];

                           	verbiage.append("DEPENDENT LAST NAME: ").append(dependentDetails[0]).append("\n");
							verbiage.append("DEPENDENT FIRST NAME: ").append(dependentDetails[1]).append("\n");
							verbiage.append("DEPENDENT MI: ").append(dependentDetails[2]).append("\n");
							verbiage.append("DEPENDENT DATE OF BIRTH: ").append(dependentDob).append("\n");
							verbiage.append("DEPENDENT GENDER: ").append(dependentDetails[9]).append("\n");
							verbiage.append("DEPENDENT SOCIAL SECURITY NUMBER: ").append(dependentDetails[3]).append("\n");
							verbiage.append("DEPENDENT RELATIONSHIP: ").append(dependentDetails[8]).append("\n");
							verbiage.append("DEPENDENT STUDENT: ").append(dependentDetails[7]).append("\n");
			 }


			if(StringUtils.equals(TERMINATE_DEPENDENT,insuredDTO.getRequestType())){
				 verbiage.append(FILLER_EMPTY+"\n");
				verbiage.append("TERMINATION DATE:").append(insuredDTO.getEffectiveTerminationDate()).append("\n");
			}else if(StringUtils.equals(CHANGE_DEPENDENT_COVERAGE,insuredDTO.getRequestType())){
				verbiage.append(FILLER_EMPTY+"\n");
				verbiage.append("EFFECTIVE DATE OF CHANGE:").append(insuredDTO.getChangeEffectiveDate()).append("\n");
			}

 			}

		  GroupAdminUserDTO userDTO =  insuredDTO.getUserDTO();
		  verbiage.append("\n");
          verbiage.append(FILLER_EMPTY+"\n");
          prepareReasonForRequest(verbiage,"REASON FOR REQUEST:"+insuredDTO.getReasonForRequest());

          if(null !=userDTO){
				verbiage.append("\n");
				verbiage.append(FILLER_EMPTY+"\n");
				loginUserInfo(verbiage,userDTO);
	  		}

   	}

	private void loginUserInfo(StringBuffer verbiage, GroupAdminUserDTO userDTO){

		  verbiage.append("USERNAME: "+userDTO.getSamAccountName()+" - "+userDTO.getGivenName()+" "+userDTO.getLastName());
   }

	/**
	 * General test method for this class
	 *
	 * @param inArgs
	 *            command-line arguments
	 */
	public static void main(String[] inArgs) {
		String configPath = "D:\\Netscape\\GroupAdmin\\Clife\\config\\";
		String strAppIni = "D:\\Netscape\\GroupAdmin\\Clife\\config\\CGA.ini";

		/*
		 * Load and configure log4j using the log4j properties file. This also
		 * tests that we have the classpath setup to include ETKS/config
		 */
		String logPropertyFileResource = configPath
				+ com.bcbssc.registration.common.Constants.LOG4J_PROPERTIES_FILENAME;

		DOMConfigurator.configure(logPropertyFileResource);

		try {
			GroupAdminUserInformHandler gaih = new GroupAdminUserInformHandler(
					strAppIni);

			GroupAdminUserDTO user = new GroupAdminUserDTO();
			user.setMiddleIni("M");
			user.setGivenName("TEST01");
			user.setSuffix("JR.");
			user.setTelephoneExt("12345");
			user.setGroupName("THE GROUP NAME");
			user.setGroupNumber("1234567890");
			user.setPostalCode("23456");
			user.setState("TX");
			user.setGroupName("TESTING NAME");
			user.setMail("t@t.com");
			user.setLastName("TESTING01");
			user.setDateOfBirth("01/01/1998");
			user.setTelephoneNumber("8031234567");
			user.setStreet("TESTING LANE");
			user.setCountry("AL");
			user.setCity("COLUMBIA");
			user.setAddressLine2("");
			user.setLast6SSN("222222");
			user.setFax("1236547890");
			user.setSamAccountName("test0902");
			user.setDateOfAcceptance("Wed, 01 Sep 2004 22:09:04 GMT");
			user
					.setChallenge("What is the name of the elementary school you attended?");
			user.setChallengeResponse("mom");

			// gaih.sendCodeRequestInform(user);
			gaih.sendProfileCreatedInform(user);

		} catch (Exception eException) {
			GroupAdminUserInformHandler.logger.error(
					"Error occured while trying to test webpack rules add: ",
					eException);
			eException.printStackTrace();
		}
	}

}
