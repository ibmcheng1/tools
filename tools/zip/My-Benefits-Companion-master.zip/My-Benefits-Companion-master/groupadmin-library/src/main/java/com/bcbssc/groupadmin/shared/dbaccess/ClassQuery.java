/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/ClassQuery.java_v  $
 * $Workfile:   ClassQuery.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:06  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/ClassQuery.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:14:06   EN80
 * Initial revision.
 * 
 *    Rev 1.14   Apr 28 2009 10:17:50   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.13   Feb 08 2005 17:38:34   rdq70
 * Fixed a column name.
 *
 *    Rev 1.12   Feb 04 2005 16:38:00   rdq70
 * Added CERT_MAINT_INDC.
 *
 *    Rev 1.11   Feb 04 2005 15:59:36   rdq70
 * Reduced SQL whitespace.
 *
 *    Rev 1.10   Feb 03 2005 13:30:24   rdq70
 * Javadoc correction.
 *
 *    Rev 1.9   Feb 03 2005 10:49:52   rdq70
 * Renamed MQ_TABLE to GCOM_TABLE.
 *
 *    Rev 1.8   Feb 02 2005 09:37:36   rdq70
 * Revised Javadocs based on provided SQL descriptions.
 *
 *    Rev 1.7   Feb 01 2005 11:42:56   rdq70
 * Incorporated revised SQL.
 *
 *    Rev 1.6   Jan 27 2005 16:55:44   rdq70
 * Create CoverageClass beans instead of LabelValueBeans.
 *
 *    Rev 1.5   Jan 27 2005 12:52:24   rdq70
 * Corrected qualifier.
 *
 *    Rev 1.4   Jan 26 2005 17:43:02   rdq70
 * Removed unused imports.
 *
 *    Rev 1.3   Jan 26 2005 14:11:18   rdq70
 * Replaced mutiple parameters with bean containing values.
 *
 *    Rev 1.2   Jan 26 2005 10:38:04   rdq70
 * Replaced hard-coded qualifier with parameter.
 *
 *    Rev 1.1   Jan 26 2005 10:03:14   rdq70
 * BlueHammur changes.
 *
 *    Rev 1.0   Jan 25 2005 17:18:20   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.dbaccess;

import com.bcbssc.groupadmin.shared.dto.CoverageClass;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

/**
 * This query creates a list of coverage classes and descriptions for a group
 * for the dropdown box. If a group does not have a class description in the db2
 * table, then the sql will return the results with the term 'NOT FOUND' as the
 * class description.<br>
 *
 * <pre>
 *     QMF NAME: RX13U.WEB_SQL_3_A
 *     TSO NAME: WEBSQL3A
 * </pre>
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class ClassQuery extends AbstractDBSearch {

	/**
	 * Creates an <code>ClassQuery</code> and configures it with an INI file.
	 *
	 * @param iniFile
	 *            file path of the configuration INI file.
	 */
	public ClassQuery(String iniFile) {
		super(iniFile, "GCOM_TABLE");
	}

	/**
	 * Creates a list of coverage classes and descriptions for a group for the
	 * dropdown box. If a group does not have a class description in the db2
	 * table, then the sql will return the results with the term 'NOT FOUND' as
	 * the class description.<br>
	 *
	 * <pre>
	 *     QMF NAME: RX13U.WEB_SQL_3_A
	 *     TSO NAME: WEBSQL3A
	 * </pre>
	 *
	 * @param insuredData
	 *            the bean containing data for the search. It needs only the
	 *            groupNumber property set.
	 * @return a collection populated with the search results.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 */
	public Collection performSearch(InsuredDataDTO insuredData)
			throws SQLException {
		this.checkInit(); // Necessary since we need the _dbSchema before the
							// query creation

		final String[] params = { insuredData.getCompany(),
				insuredData.getGroupPrefix(), insuredData.getGroupBase(),
				insuredData.getCompany(), insuredData.getGroupPrefix(),
				insuredData.getGroupBase(), insuredData.getCompany(),
				insuredData.getGroupPrefix(), insuredData.getGroupBase(),
				insuredData.getCompany(), insuredData.getGroupPrefix(),
				insuredData.getGroupBase() };

		return this.performSearch(this.getSql(insuredData.getDivisionCode()),
				params);
	}

	/**
	 * {@inheritDoc}
	 *
	 * Adds data from the given result set to the target collection.
	 */
	protected void addSearchItem(ResultSet data, Object obj)
			throws SQLException {
		final Collection options = (Collection) obj;
		final CoverageClass clazz = new CoverageClass();

		clazz.setCode(data.getString("CLAS_CODE").trim());
		clazz.setDescription(data.getString("EMP_CLASS_DESC").trim());
		clazz.setAgeChangeCode(data.getString("AGE_CHNG_CD").trim());
		clazz.setIssueCertType(data.getString("CERT_TYP").trim());
		clazz.setWalletCardType(data.getString("WLT_CRD_TYP").trim());
		clazz.setSicCode(data.getString("SIC_CD").trim());
		clazz.setMaintenanceIndicator(data.getString("CERT_MAINT_INDC").trim());

		options.add(clazz);
	}

	/**
	 * Returns the SQL for this query.
	 * 
	 * @param division
	 *            the division for this query.
	 * @return the SQL for this query.
	 */
	private String getSql(String division) {
		return new StringBuffer(5000)
				.append(
						"SELECT DISTINCT (A.CLAS_CODE)"
								+ "    , C.EMP_CLASS_DESC"
								+ "    , B.AGE_CHNG_CD" + "    , B.CERT_TYP"
								+ "    , B.WLT_CRD_TYP" + "    , B.SIC_CD"
								+ "    , B.CERT_MAINT_INDC" + "  FROM ")
				.append(this._dbSchema)
				.append(".VPLCYCVZ A" + "     , ")
				.append(this._dbSchema)
				.append(".VPLCYGRZ B" + "     , ")
				.append(this._dbSchema)
				.append(
						".VCLSDSCZ C"
								+ "  WHERE A.COMP_CD = ?"
								+ "    AND A.COMP_CD = B.COMP_CD"
								+ "    AND B.COMP_CD = C.COMPANY_CODE"
								+ "    AND A.GRP_PRFX = ?"
								+ "    AND A.GRP_PRFX = B.GRP_PRFX"
								+ "    AND B.GRP_PRFX = C.GROUP_PREFIX"
								+ "    AND A.GRP_BASE = ?"
								+ "    AND A.GRP_BASE = B.GRP_BASE"
								+ "    AND B.GRP_BASE = C.GROUP_NUMBER "
								+ "    AND A.COV_STAT_CD = '1'"
								+ "    AND A.CLAS_CODE = C.EMP_CLASS_ID"
								+ "    AND A.DIV_CODE = CASE WHEN B.DIV_LVL_CD = '5'"
								+ "                          THEN '")
				.append(division)
				.append(
						"'"
								+ "                          ELSE ' ' END"
								+ "    AND C.DIVISION_ID = CASE WHEN B.DIV_LVL_CD = '5'"
								+ "                          THEN '")
				.append(division)
				.append(
						"'"
								+ "                          ELSE ' ' END"
								+ " GROUP BY A.CLAS_CODE"
								+ "        , C.EMP_CLASS_DESC"
								+ "        , B.AGE_CHNG_CD"
								+ "        , B.CERT_TYP"
								+ "        , B.WLT_CRD_TYP"
								+ "        , B.SIC_CD"
								+ "        , B.CERT_MAINT_INDC"
								+ "  HAVING EXISTS (SELECT DISTINCT (A.CLAS_CODE)"
								+ "        , C.EMP_CLASS_DESC" + "      FROM ")
				.append(this._dbSchema)
				.append(".VPLCYCVZ A" + "         , ")
				.append(this._dbSchema)
				.append(".VPLCYGRZ B" + "         , ")
				.append(this._dbSchema)
				.append(
						".VCLSDSCZ C"
								+ "      WHERE A.COMP_CD = ?"
								+ "        AND A.COMP_CD = B.COMP_CD"
								+ "        AND B.COMP_CD = C.COMPANY_CODE"
								+ "        AND A.GRP_PRFX = ?"
								+ "        AND A.GRP_PRFX = B.GRP_PRFX"
								+ "        AND B.GRP_PRFX = C.GROUP_PREFIX"
								+ "        AND A.GRP_BASE = ?"
								+ "        AND A.GRP_BASE = B.GRP_BASE"
								+ "        AND B.GRP_BASE = C.GROUP_NUMBER"
								+ "        AND A.COV_STAT_CD = '1'"
								+ "        AND A.CLAS_CODE = C.EMP_CLASS_ID"
								+ "        AND A.DIV_CODE = CASE WHEN B.DIV_LVL_CD = '5'"
								+ "                           THEN '")
				.append(division)
				.append(
						"'"
								+ "                           ELSE ' ' END"
								+ "        AND C.DIVISION_ID = CASE WHEN B.DIV_LVL_CD = '5'"
								+ "                              THEN '")
				.append(division)
				.append(
						"'" + "                              ELSE ' ' END)"
								+ "  UNION" + "  SELECT DISTINCT (A.CLAS_CODE)"
								+ "       , 'NOT FOUND' \"EMP_CLASS_DESC\""
								+ "       , B.AGE_CHNG_CD"
								+ "       , B.CERT_TYP"
								+ "       , B.WLT_CRD_TYP"
								+ "       , B.SIC_CD"
								+ "       , B.CERT_MAINT_INDC" + "    FROM ")
				.append(this._dbSchema)
				.append(".VPLCYCVZ A" + "       , ")
				.append(this._dbSchema)
				.append(
						".VPLCYGRZ B"
								+ "   WHERE A.COMP_CD = ?"
								+ "     AND A.COMP_CD = B.COMP_CD"
								+ "     AND A.GRP_PRFX = ?"
								+ "     AND A.GRP_PRFX = B.GRP_PRFX"
								+ "     AND A.GRP_BASE = ?"
								+ "     AND A.GRP_BASE = B.GRP_BASE"
								+ "     AND A.COV_STAT_CD = '1'"
								+ "     AND A.DIV_CODE = CASE WHEN B.DIV_LVL_CD = '5'"
								+ "                           THEN '")
				.append(division)
				.append(
						"'"
								+ "                           ELSE ' ' END"
								+ "  GROUP BY A.CLAS_CODE"
								+ "         , B.AGE_CHNG_CD"
								+ "         , B.CERT_TYP"
								+ "         , B.WLT_CRD_TYP"
								+ "         , B.SIC_CD"
								+ "         , B.CERT_MAINT_INDC"
								+ "  HAVING NOT EXISTS (SELECT DISTINCT (A.CLAS_CODE)"
								+ "        , C.EMP_CLASS_DESC" + "      FROM ")
				.append(this._dbSchema)
				.append(".VPLCYCVZ A" + "         , ")
				.append(this._dbSchema)
				.append(".VPLCYGRZ B" + "         , ")
				.append(this._dbSchema)
				.append(
						".VCLSDSCZ C"
								+ "      WHERE A.COMP_CD = ?"
								+ "        AND A.COMP_CD = B.COMP_CD"
								+ "        AND B.COMP_CD = C.COMPANY_CODE"
								+ "        AND A.GRP_PRFX = ?"
								+ "        AND A.GRP_PRFX = B.GRP_PRFX"
								+ "        AND B.GRP_PRFX = C.GROUP_PREFIX"
								+ "        AND A.GRP_BASE = ?"
								+ "        AND A.GRP_BASE = B.GRP_BASE"
								+ "        AND B.GRP_BASE = C.GROUP_NUMBER"
								+ "        AND A.COV_STAT_CD = '1'"
								+ "        AND A.CLAS_CODE = C.EMP_CLASS_ID"
								+ "        AND A.DIV_CODE = CASE WHEN B.DIV_LVL_CD = '5'"
								+ "                              THEN '")
				.append(division)
				.append(
						"'"
								+ "                              ELSE ' ' END"
								+ "        AND C.DIVISION_ID = CASE WHEN B.DIV_LVL_CD = '5'"
								+ "                                 THEN '")
				.append(division).append(
						"'" + "                                 ELSE ' ' END)")
				.toString();
	}
}
