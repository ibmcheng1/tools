/*
 * @(#)ModifyCoverageForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.forms;

import com.bcbssc.groupadmin.shared.dto.CoverageItem;

import java.util.ArrayList;
import java.util.Collection;

import org.apache.struts.util.LabelValueBean;

/**
 * GroupAdmin Modify Coverage Form
 *
 * This bean extends the InsuredSearchForm by providing clear and getResettable
 * methods specific to the modify coverage form.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class ModifyCoverageForm extends CoverageForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Returns a collection of resettable name/value pairs. @ return Collection
	 * of LabelValueBean objects, each containing the name and value of a
	 * resettable property.
	 *
	 * @return a {@link java.util.Collection} object.
	 */
	public Collection getResettables() {
		ArrayList resettables = new ArrayList();

		if (this.getClassHasDentalCoverage()) {
			if (this.getSpouseExists()) {
				resettables.add(new LabelValueBean("spouseDental", String
						.valueOf(this.getSpouseDental())));
			}

			if (this.getDentalCoverageAccepted()) {
				resettables.add(new LabelValueBean("otherDental", String
						.valueOf(this.getOtherDental())));
			}
		}

		return resettables;
	}

	/**
	 * Returns a collection of resettable properties that are referenced by bean @ return
	 * Collection of LabelValueBean objects, each containing the name and value
	 * of a bean-referenced arrayed resettable property.
	 *
	 * @return a {@link java.util.Collection} object.
	 */
	public Collection getBeanResettables() {
		ArrayList resettables = new ArrayList();

		int coverageItemCount = (this.coverageItems != null) ? this.coverageItems
				.size()
				: 0;
		for (int i = 0; i < coverageItemCount; i++) {
			CoverageItem item = this.getCoverageItem(i);

			StringBuffer itemLabel = new StringBuffer(32);
			itemLabel.append("coverageItem[").append(i).append("].");

			StringBuffer propertyName = new StringBuffer(itemLabel.toString());
			propertyName.append("changed");
			resettables.add(new LabelValueBean(propertyName.toString(), String
					.valueOf(false)));

			propertyName = new StringBuffer(itemLabel.toString());
			propertyName.append("action");
			resettables.add(new LabelValueBean(propertyName.toString(), String
					.valueOf(item.getAction())));

			propertyName = new StringBuffer(itemLabel.toString());
			propertyName.append("volume");
			resettables.add(new LabelValueBean(propertyName.toString(), String
					.valueOf(item.getVolume())));
		}

		return resettables;
	}

    /**
     * <p>getCoverageItemsCount.</p>
     *
     * @return a int.
     * @throws java.lang.Exception if any.
     */
    public int getCoverageItemsCount() throws Exception{
   		return this.coverageItems.size();
	}
	/**
	 * <p>getClassPresent.</p>
	 *
	 * @return a boolean.
	 */
	public boolean getClassPresent() {
		return this.getClassHasAcceptedDentalCoverage()
				|| this.getClassHasAcceptedVisionCoverage();
	}

	/**
	 * <p>getDentalAndVisionSelected.</p>
	 *
	 * @return a boolean.
	 */
	public boolean getDentalAndVisionSelected() {
		return this.getClassHasAcceptedDentalCoverage()
				&& this.getClassHasAcceptedVisionCoverage();
	}

	/**
	 * <p>getDisplayVision.</p>
	 *
	 * @return a boolean.
	 */
	public boolean getDisplayVision() {
		return this.getClassHasAcceptedVisionCoverage();
	}

	/**
	 * <p>getDisplayDental.</p>
	 *
	 * @return a boolean.
	 */
	public boolean getDisplayDental() {
		return this.getClassHasAcceptedDentalCoverage();
	}
}
