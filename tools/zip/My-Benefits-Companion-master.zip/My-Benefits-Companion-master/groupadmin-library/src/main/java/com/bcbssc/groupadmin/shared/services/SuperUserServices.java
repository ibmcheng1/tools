/*
 * @(#)GroupAdminRegistrationServices.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.services;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import org.apache.log4j.Logger;
import org.apache.struts.util.LabelValueBean;

import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.groupadmin.shared.dbaccess.RulesQuery;
import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.groupadmin.shared.dto.SuperUserDTO;
import com.bcbssc.groupadmin.shared.ldap.GroupAdminLdapUserHandler;
import com.bcbssc.netsys.jndi.MissingPropertyException;
import com.bcbssc.registration.tds.impl.AbstractProfileManagementService;

/**
 * Group Administrator Registration Services
 *
 * This class provides the business logic for group administrator registration.
 * It is called from the action classes responsible for add, authenticate,
 * validate, reauthenticate, modify and change password.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.1  $
 */
public class SuperUserServices {

	/** log4j logger */
	protected static Logger log = Logger.getLogger(SuperUserServices.class);

	/** the ini file containing service processing parameters */
	protected String iniFile = null;

	/** the ini file containing ssl connection parameters */
	protected String tdsIniFile = null;
	
	

	/**
	 * Constructs class, setting the servlet ini files
	 *
	 * @param _iniFile
	 *            the ini file containing service processing parameters
	 * @param _tdsIniFile a {@link java.lang.String} object.
	 */
	public SuperUserServices(String _iniFile, String _tdsIniFile) {
		this.iniFile = _iniFile;
		this.tdsIniFile = _tdsIniFile;
	}

	/**
	 * Returns an LDAP user handler
	 *
	 * @return the LDAP user handler contructed using the classes ini files
	 */
	protected GroupAdminLdapUserHandler getLdapUserHandler() {
		if (SuperUserServices.log.isDebugEnabled()) {
			SuperUserServices.log.debug("getting GroupAdminLdapUserHandler");
			SuperUserServices.log.debug("ini is: " + this.iniFile);
			SuperUserServices.log.debug("tds ini is: " + this.tdsIniFile);
		}
		return new GroupAdminLdapUserHandler(this.iniFile,this.tdsIniFile);
	}

	/**
	 * Returns a list of users matching the ssn/dto/name combination specified
	 * by the superuser.
	 *
	 * @return Collection of LabelValueBean objects that can be used to populate
	 *         a dropdown of users.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException
	 *             when any ldap confing property is missed in ini files
	 * @throws javax.naming.NamingException
	 *             when communication exception or ldap operation failure
	 *             scenarios
	 * @throws java.io.FileNotFoundException
	 *             when ini file not found
	 * @param superUserDTO a {@link com.bcbssc.groupadmin.shared.dto.SuperUserDTO} object.
	 */
	public List<LabelValueBean> getMatchingUsers(SuperUserDTO superUserDTO)
			throws  FileNotFoundException, NamingException, MissingPropertyException {

		List<LabelValueBean> returnList = null;
		// Validate username and password against LDAP
		String last6SSN = superUserDTO.getSsn();
		String dob = superUserDTO.getDateOfBirth().toString();
		String lastName = superUserDTO.getLastName();
		GroupAdminLdapUserHandler luh = null;
		if ((last6SSN.length() != 0) && (dob.length() != 0)) {
			luh = this.getLdapUserHandler();
			String[] userDNs;
			if ((lastName != null) && (lastName.length() != 0)) {
				userDNs = luh.getMatchingProfiles(last6SSN, dob, lastName);
			} else {
				userDNs = luh.getMatchingProfiles(last6SSN, dob);
			}
			if (SuperUserServices.log.isDebugEnabled()) {
				SuperUserServices.log.debug(" the user userDNs are "
						+ userDNs.length);
			}
			ArrayList<LabelValueBean> userOptions = new ArrayList<LabelValueBean>();
			for (int i = 0; i < userDNs.length; i++) {
				String userName = AbstractProfileManagementService.getSamAccountNameFromDN(userDNs[i]);
				if (SuperUserServices.log.isDebugEnabled()) {
					SuperUserServices.log.debug(" The userName is " + userName);
				}
				userOptions.add(new LabelValueBean(userName, userName));
			}
			returnList = userOptions;
		}
		return returnList;
	}

	/**
	 * <p>verifyUserStatus.</p>
	 *
	 * @param superUserDTO a {@link com.bcbssc.groupadmin.shared.dto.SuperUserDTO} object.
	 * @return a int.
	 * @throws java.lang.Exception if any.
	 */
	public int verifyUserStatus(SuperUserDTO superUserDTO)
			throws  Exception {

		int returnInt;
		GroupAdminLdapUserHandler luh = this.getLdapUserHandler();
		GroupAdminUserDTO user = (GroupAdminUserDTO) luh.getUser(superUserDTO
				.getUserName());
		RulesQuery rules = new RulesQuery(this.iniFile);
		boolean verified = rules.verifyUserStatus(user.getAccessCode());

		if (SuperUserServices.log.isDebugEnabled()) {
			SuperUserServices.log.debug("SUPERUSER, USER AUTHENTICATE: "
					+ verified);
		}

		if (verified) {
			returnInt = Constants.SERVICE_VALID;
		} else {
			returnInt = Constants.ACCESS_REVOKED;
		}
		return returnInt;
	}
}
