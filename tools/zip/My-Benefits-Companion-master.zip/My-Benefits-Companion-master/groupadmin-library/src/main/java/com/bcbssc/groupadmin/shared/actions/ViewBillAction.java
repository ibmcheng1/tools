/*
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/actions/ViewBillAction.java_v  $
 * $Workfile:   ViewBillAction.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:13:48  $
 * $Modtime:   May 14 2009 11:33:28  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/actions/ViewBillAction.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:13:48   EN80
 * Initial revision.
 * 
 *    Rev 1.3   Apr 28 2009 10:17:26   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.2   Mar 18 2005 14:00:20   rxr93
 * get image server url from ini file
 * remove unused methods
 * 
 *    Rev 1.1   Mar 16 2005 19:22:12   rxr93
 * remove commented out code, cleanup code
 * 
 *    Rev 1.0   Mar 16 2005 19:12:44   rxr93
 * Initial revision.
 * 
 */

package com.bcbssc.groupadmin.shared.actions;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.groupadmin.shared.forms.BillHistoryForm;
import com.bcbssc.groupadmin.shared.forms.ViewBillForm;
import com.bcbssc.netsys.Config;
import com.bcbssc.struts.action.SimpleDispatchAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * Group Admin View Bill Action
 *
 * This class provides control processing the request a bill action.
 *
 * @author Mark Lujan
 * @version $Revision:   1.0  $
 */
public class ViewBillAction extends SimpleDispatchAction {

	/** log4j logger */
	private static final Logger log = Logger.getLogger(ViewBillAction.class
			.getName());

	/**
	 * <p>Constructor for ViewBillAction.</p>
	 */
	public ViewBillAction() {
		super();
	}

	/**
	 * load jsp page for viewing the bill
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward viewBill(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// no action required prior to loading 1st form

		ViewBillForm viewBillForm = (ViewBillForm) form;
		if (ViewBillAction.log.isDebugEnabled()) {
			ViewBillAction.log.debug("key = " + viewBillForm.getGroupNumber());
			ViewBillAction.log.debug("date = "
					+ viewBillForm.getSelectedBillDate());
		}
		// get the url for the image server
		String iniFile = CommonUtils.getIniFile(this.getServlet());
		String imageServerUrl = Config.getPrivateProfileString("SERVLETS",
				"PDF_IMAGE_SERVLET", "", iniFile);
		ViewBillAction.log.debug("image server = " + imageServerUrl);

		viewBillForm.setImageServer(imageServerUrl);

		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}

	/**
	 * load frameset for viewing the bill
	 *
	 * @param mapping a {@link org.apache.struts.action.ActionMapping} object.
	 * @param form a {@link org.apache.struts.action.ActionForm} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @param response a {@link javax.servlet.http.HttpServletResponse} object.
	 * @throws java.lang.Exception if any.
	 * @return a {@link org.apache.struts.action.ActionForward} object.
	 */
	public ActionForward viewBillFrame(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		BillHistoryForm billHistoryForm = (BillHistoryForm) form;

		if (ViewBillAction.log.isDebugEnabled()) {
			ViewBillAction.log.debug("groupNumber: "
					+ billHistoryForm.getGroupNumber());
			ViewBillAction.log.debug("date "
					+ billHistoryForm.getSelectedBillDate());
		}

		// make container for subsequent functions
		ViewBillForm viewBillForm = (ViewBillForm) this.getForm("viewBillForm",
				"/viewBill", request);

		// fill the new container
		viewBillForm.setGroupNumber(billHistoryForm.getGroupNumber());
		viewBillForm.setSelectedBillDate(billHistoryForm.getSelectedBillDate());

		GroupAdminUserDTO user = (GroupAdminUserDTO) request
				.getAttribute("user");
		ViewBillAction.log.debug("user = " + user.getAccessCode());
		viewBillForm.setUser(user.getAccessCode());

		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}
}
