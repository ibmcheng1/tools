/*
 * @(#)GroupAdminDowntimeTag.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.tags;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.registration.tags.DowntimeHolidayTag;

import javax.servlet.ServletContext;

/**
 * Group Administrator Downtime Tag
 *
 * This class extends the abstract shared DowntimeTag by providing getIniFile
 * which returns the application-specific INI file to be used for the LDAP
 * downtime message lookup.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.1  $
 */
public class GroupAdminDowntimeTag extends DowntimeHolidayTag {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1282619531560755075L;

	/**
	 * {@inheritDoc}
	 *
	 * Gets the application-specific INI file
	 */
	protected String getTDSIniFile(ServletContext context) {
		return CommonUtils.getTDSIniFile(context);
	}
	/** {@inheritDoc} */
	protected String getIniFile(ServletContext context) {
		return CommonUtils.getIniFile(context);
	}
}
