/*
 * @(#)InsuredServices.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.services;

import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.groupadmin.shared.dbaccess.ClassQuery;
import com.bcbssc.groupadmin.shared.dbaccess.CoveragesQuery;
import com.bcbssc.groupadmin.shared.dbaccess.DependentsQuery;
import com.bcbssc.groupadmin.shared.dbaccess.EmployeeDetailsQuery;
import com.bcbssc.groupadmin.shared.dbaccess.EmployeeSearch;
import com.bcbssc.groupadmin.shared.dbaccess.GroupQuery;
import com.bcbssc.groupadmin.shared.dbaccess.LastUpdateQuery;
import com.bcbssc.groupadmin.shared.dbaccess.QualifiedCoveragesQuery;
import com.bcbssc.groupadmin.shared.dbaccess.SpouseDetailsQuery;
import com.bcbssc.groupadmin.shared.dto.BankInformationDTO;
import com.bcbssc.groupadmin.shared.dto.CoverageClass;
import com.bcbssc.groupadmin.shared.dto.CoverageItem;
import com.bcbssc.groupadmin.shared.dto.Dependent;
import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredSearchDTO;
import com.bcbssc.groupadmin.shared.dto.SpecialRequestDTO;
import com.bcbssc.groupadmin.shared.mq.GcomTransaction;
import com.bcbssc.groupadmin.shared.mq.InformFactory;
import com.bcbssc.groupadmin.shared.mq.GroupAdminUserInformHandler;
import com.bcbssc.netsys.LinkedException;
import com.bcbssc.struts.common.DateBean;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts.util.LabelValueBean;
import com.bcbssc.groupadmin.shared.dto.InsuredRequestChangeSearchDTO;


/**
 * Group Administrator Insured User Services
 *
 * This class provides the business logic for the group administrator insured
 * user services
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class InsuredServices extends Object {

	/** log4j logger */
	protected static final Logger log = Logger.getLogger(InsuredServices.class);

	/** Duplicate ID error key */
	public static final String ERRORS_ADD_DUPLICATE_ID = "errors.duplicate.id";

	/** the ini file containing service processing parameters */
	protected String iniFile = null;

	/** the gcom ini file containing gcom service processing parameters */
	protected String gcomIniFile = null;

	/** the user requesting the service */
	protected GroupAdminUserDTO user;

	/**
	 * Constructs class, setting the servlet ini files
	 *
	 * @param iniFile
	 *            the ini file containing service processing parameters
	 * @param gcomIniFile a {@link java.lang.String} object.
	 * @param user a {@link com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO} object.
	 */
	public InsuredServices(String iniFile, String gcomIniFile,
			GroupAdminUserDTO user) {
		this.iniFile = iniFile;
		this.gcomIniFile = gcomIniFile;
		this.user = user;
	}

	/**
	 * Sets the coverageClass property and coverageItems list in an
	 * InsuredDataDTO as appropriate for the coverageClass.code specified in the
	 * DTO. Gets the coverageClass properties (besides code) from the
	 * code-matching class in the coverages array.
	 *
	 * @param coverages
	 *            a list of fully-specified CoverageClass beans
	 * @throws java.lang.Exception
	 *             if BeanUtils.copyProperties fails
	 * @param insuredData a {@link com.bcbssc.groupadmin.shared.dto.InsuredDataDTO} object.
	 */
	public void getCoverageDetails(InsuredDataDTO insuredData,
			ArrayList coverages) throws Exception {

		CoverageClass selectedClass = insuredData.getCoverageClass();

		// Only the coverageClass.code is set at this point. Use the coverages
		// list to populte the other coverage values.
		Iterator iter = coverages.iterator();
		boolean coverageSet = false;
		while (!coverageSet && iter.hasNext()) {
			CoverageClass currentClass = (CoverageClass) iter.next();
			if (selectedClass.getCode().equals(currentClass.getCode())) {
				BeanUtils.copyProperties(selectedClass, currentClass);
				coverageSet = true;
			}
		}
		if (!coverageSet) {
			// Reset the coverage values
			selectedClass = new CoverageClass();
		}
		// Set the updated coverageClass in the bean
		insuredData.setCoverageClass(selectedClass);

		// Reset the coverageClassItems before performing query
		insuredData.setCoverageItems(new ArrayList());

		if (coverageSet) {
			try {
				QualifiedCoveragesQuery qualifiedCoveragesQuery = new QualifiedCoveragesQuery(
						this.iniFile);
				Collection col = qualifiedCoveragesQuery
						.performSearch(insuredData);

				insuredData.setCoverageItems(new ArrayList(col));

				InsuredServices.updateCoverageDetails(insuredData);

			} catch (SQLException sqlEx) {
				InsuredServices.log.error("Error during group query", sqlEx);
				throw sqlEx;
			}
		}
	}

	/**
	 * Updates the effective date for the coverages items.
	 *
	 * @throws java.lang.Exception
	 *             if BeanUtils.copyProperties fails
	 * @param insuredData a {@link com.bcbssc.groupadmin.shared.dto.InsuredDataDTO} object.
	 */
	public static void updateCoverageDetails(InsuredDataDTO insuredData)
			throws Exception {
		DateBean effectiveDate = null;
		CoverageItem item = null;
		if (InsuredServices.log.isDebugEnabled()) {
			InsuredServices.log
					.debug("Start of updateCoverageDetails()in InsuredServices.java");
		}

		Iterator i = insuredData.getCoverageItems().iterator();

		while (i.hasNext()) {

			item = (CoverageItem) i.next();

			// When "Add New Group" is selected from top nav. Bar, the
			// 'Effective Date' of the coverage's is the effective date
			// of the Division. Set the new group indicator to "Y".
			if (insuredData.isAddNewGroup()) {
				effectiveDate = insuredData.getDivisionOriginalEffectiveDate();

				} else {
				if (!"Declined".equalsIgnoreCase(item.getActionFormatted())) {

					effectiveDate = EffectiveDateCalculator.getEffectiveDate(
							insuredData.getHireDate(), item
									.getWaitingPeriodCode(), item
									.getWaitingPeriod(), insuredData
									.getLastBillDate(), item
									.getWaitPeriodCalculationCategory());

			} else {

					effectiveDate = new DateBean();

				}
			}
			if (InsuredServices.log.isDebugEnabled()) {
				InsuredServices.log
						.debug("End of updateCoverageDetails() in InsuredServices.java, calculated effective date is: "
								+ effectiveDate.toString());
			}

			item.setEffectiveDate(effectiveDate);
		}
	}

	/**
	 * Gets the group option dropdown items for a user
	 *
	 * @param userDTO
	 *            user for which the group options will be retrieved.
	 * @return Collection of group option LabelValueBean items
	 * @throws java.sql.SQLException
	 *             if an exception occurs group option retrieval
	 */
	public Collection getGroupOptions(GroupAdminUserDTO userDTO)
			throws SQLException {

		try {
			// TBD: Get group number from performSearch???

			GroupQuery groupQuery = new GroupQuery(this.iniFile);
			ArrayList groupOptions = new ArrayList();
			groupOptions.add(new LabelValueBean("-- Please Choose One --", ""));
			groupOptions.addAll(groupQuery.performSearch(userDTO
					.getAccessCode()));
			return groupOptions;
		} catch (SQLException sqlEx) {
			InsuredServices.log.error("Error during group query", sqlEx);
			throw sqlEx;
		}
	}

	/**
	 * Gets the coverage classes for an insured
	 *
	 * @throws java.sql.SQLException
	 *             if an exception occurs during employee search
	 * @param insuredDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredDataDTO} object.
	 * @return a {@link java.util.Collection} object.
	 */
	public Collection getCoverageClasses(InsuredDataDTO insuredDTO)
			throws SQLException {

		try {
			ClassQuery query = new ClassQuery(this.iniFile);
			Collection col = query.performSearch(insuredDTO);
			return col;
		} catch (SQLException sqlEx) {
			InsuredServices.log.error("Error during coverage class query",
					sqlEx);
			throw sqlEx;
		}
	}

	/**
	 * Adds a new dependent to the dependent list
	 *
	 * @param insuredDataDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredDataDTO} object.
	 */
	public static void addNextDependent(InsuredDataDTO insuredDataDTO) {
		insuredDataDTO.addDependent(new Dependent());
	}

	/**
	 * Removes blank dependents from the InsuredDataDTO dependent list
	 *
	 * @param insuredDataDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredDataDTO} object.
	 */
	public static void removeBlankDependents(InsuredDataDTO insuredDataDTO) {
		// If the dependent's name is blank, remove the dependent from the list
		ArrayList dependents = insuredDataDTO.getDependents();

		if (dependents != null) {
			int i = 0;
			while (i < dependents.size()) {
				Dependent dependent = (Dependent) dependents.get(i);
				if ((dependent.getGivenName().trim().length() == 0)
						&& (dependent.getLastName().trim().length() == 0)) {
					dependents.remove(i);
				} else {
					i++;
				}
			}
		}

		insuredDataDTO.setDependents(dependents);
	}

	/**
	 * Removes the last n number of dependents depending on the passed parameter
	 *
	 * @param insuredDataDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredDataDTO} object.
	 * @param toBeDeletedDependentCount a int.
	 */
	public static void removeDependents(InsuredDataDTO insuredDataDTO,
			int toBeDeletedDependentCount) {
		ArrayList dependents = insuredDataDTO.getDependents();
		// Removes the dependents from the bottom.. so that the last ones are
		// deleted.
		if (dependents != null) {
			int totalCount = dependents.size();
			int i = 0;
			int j = totalCount - 1;
			while (i < toBeDeletedDependentCount) {
				dependents.remove(j);
				j--;
				i++;
			}
		}

	}

	/**
	 * Searches for employees and gets the lastBillDate
	 *
	 * @throws java.sql.SQLException
	 *             if an exception occurs during employee search
	 * @param insuredSearchDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredSearchDTO} object.
	 */
	public void searchForEmployees(InsuredSearchDTO insuredSearchDTO)
			throws SQLException {
		try {
			LastUpdateQuery lastUpdateQuery = new LastUpdateQuery(this.iniFile);
			insuredSearchDTO.setLastBillDate(lastUpdateQuery.performSearch());
			insuredSearchDTO.setActionType("MODIFY");
			EmployeeSearch search = new EmployeeSearch(this.iniFile);
			Collection searchResults;
			if (insuredSearchDTO.getSearchLastName().length() > 0) {
				InsuredServices.log.debug("Employee search by name");
				searchResults = search.performSearchByName(insuredSearchDTO);
			} else if (insuredSearchDTO.getSearchIdentificationNumber()
					.length() > 0) {
				InsuredServices.log.debug("Employee search by ID");
				searchResults = search.performSearchById(insuredSearchDTO);
			} else {
				InsuredServices.log.debug("Employee search with by group");
				searchResults = search.performSearch(insuredSearchDTO);
			}

			int resultsCount = searchResults.size();
			InsuredServices.log.debug("setting search count to: "
					+ resultsCount);
			insuredSearchDTO.setSearchResultsCount(resultsCount);

			if (resultsCount > 0) {
				insuredSearchDTO.setSearchResults((ArrayList) searchResults);
			}
		} catch (SQLException sqlEx) {
			InsuredServices.log.error("Error during employee search", sqlEx);
			throw sqlEx;
		}
	}

	/**
	 * Retrieves all data about a stored employee
	 *
	 * @param selectedID
	 *            ID of the employee to retrieve
	 * @throws java.sql.SQLException
	 *             if an SQL error occurs
	 * @throws java.sql.SQLException
	 *             if data clear fails
	 * @param insuredSearchDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredSearchDTO} object.
	 */
	public void getEmployee(InsuredSearchDTO insuredSearchDTO, String selectedID)
			throws SQLException, Exception {

		insuredSearchDTO.clearNonSearchData();
		insuredSearchDTO.setIdentificationNumber(selectedID);

		EmployeeDetailsQuery detailsQuery = new EmployeeDetailsQuery(
				this.iniFile);
		detailsQuery.performSearch(insuredSearchDTO);

		CoveragesQuery coveragesQuery = new CoveragesQuery(this.iniFile);
		coveragesQuery.performSearch(insuredSearchDTO);

		SpouseDetailsQuery spouseQuery = new SpouseDetailsQuery(this.iniFile);
		spouseQuery.performSearch(insuredSearchDTO);

		DependentsQuery dependentsQuery = new DependentsQuery(this.iniFile);
		dependentsQuery.performSearch(insuredSearchDTO);

	}





	/**
	 * <p>getEmployeeCoverageDetailsForTA.</p>
	 *
	 * @param insuredSearchDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredSearchDTO} object.
	 * @param selectedID a {@link java.lang.String} object.
	 * @throws java.sql.SQLException if any.
	 * @throws java.lang.Exception if any.
	 */
	public void getEmployeeCoverageDetailsForTA(InsuredSearchDTO insuredSearchDTO, String selectedID)
				throws SQLException, Exception {

			insuredSearchDTO.clearNonSearchData();
			insuredSearchDTO.setIdentificationNumber(selectedID);

			EmployeeDetailsQuery detailsQuery = new EmployeeDetailsQuery(
					this.iniFile);
			detailsQuery.performSearch(insuredSearchDTO);

			CoveragesQuery coveragesQuery = new CoveragesQuery(this.iniFile);
			coveragesQuery.performSearch(insuredSearchDTO);


	}




	/**
	 * Sends the InsuredDetails INFOrm.
	 *
	 * @param insuredDTO
	 *            the DTO that contains data for the new insured
	 * @throws java.io.FileNotFoundException
	 *             if the INFOrm XML file could not be found.
	 */
	public void sendInsuredDetailsInform(InsuredSearchDTO insuredDTO)
			throws FileNotFoundException {
		InformFactory.sendEmployeeDetailsInform(this.iniFile, this.user,
				insuredDTO);
	}

	/**
	 * Sends the ViewInsuredDetails INFOrm.
	 *
	 * @param insuredDTO
	 *            the DTO that contains data for the new insured
	 * @throws java.io.FileNotFoundException
	 *             if the INFOrm XML file could not be found.
	 */
	public void sendViewInsuredDetailsInform(InsuredSearchDTO insuredDTO)
			throws FileNotFoundException {
		InformFactory.sendEmployeeViewInform(this.iniFile, this.user,
				insuredDTO);
	}

	/**
	 * This method will help us to send the W841 WEB Banking MQ Transaction and
	 * Inform MQ trasaction.
	 *
	 * @param bankInfoDTO a {@link com.bcbssc.groupadmin.shared.dto.BankInformationDTO} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @throws com.bcbssc.netsys.LinkedException if any.
	 */
	public void sendBankInformation(BankInformationDTO bankInfoDTO,
			HttpServletRequest request) throws LinkedException {

		InsuredServices.log
				.debug("In InsuredServices.java - sendBankInformation()");
		try {
			GcomTransaction bankInfoTransaction = new GcomTransaction(
					this.gcomIniFile);
			bankInfoTransaction.sendBankInformation(bankInfoDTO, request);
			bankInfoDTO.setUserDTO(this.user);
			InformFactory.sendBankInformationInform(this.iniFile, this.user,
					bankInfoDTO);
		} catch (LinkedException e) {
			InsuredServices.log
					.error("Error creating banking information MQ Transaction or INForm Transaction");
			throw new LinkedException(
					"Error creating banking information MQ Transaction and INForm Transaction",
					e);
		} catch (FileNotFoundException e) {
			InsuredServices.log
					.error("Error creating banking information MQ INForm Transaction");
			throw new LinkedException(
					"Error creating banking information MQ INForm Transaction",
					e);
		}

	}

	/**
	 * This method will help us to send the W183 WEB Payment MQ Transaction and
	 * Inform via MQ.
	 *
	 * @param bankInfoDTO a {@link com.bcbssc.groupadmin.shared.dto.BankInformationDTO} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @throws com.bcbssc.netsys.LinkedException if any.
	 */
	public void sendPaymentInformation(BankInformationDTO bankInfoDTO,
			HttpServletRequest request) throws LinkedException {

		InsuredServices.log
				.debug("In InsuredServices.java - sendPaymentInformation()");
		try {
			GcomTransaction bankInfoTransaction = new GcomTransaction(
					this.gcomIniFile);
			bankInfoTransaction.sendPaymentInformation(bankInfoDTO, request);
			bankInfoDTO.setUserDTO(this.user);
			InformFactory.sendPaymentInformationInform(this.iniFile, this.user,
					bankInfoDTO);
		} catch (LinkedException e) {
			InsuredServices.log
					.error("Error in sending Payment Information MQ Transaction or INForm transaction");
			throw new LinkedException(
					"Error in sending Payment Information MQ Transaction or INForm transaction",
					e);
		} catch (FileNotFoundException e) {
			InsuredServices.log
					.error("Error in sending Payment Information MQ INForm transaction");
			throw new LinkedException(
					"Error in sending Payment Information MQ INForm transaction",
					e);
		}

	}

	/**
	 * Adds a new insured
	 *
	 * @param request
	 *            the request calling this service
	 * @throws com.bcbssc.netsys.LinkedException
	 *             if an MQ fails
	 * @param insuredDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredSearchDTO} object.
	 */
	public void addInsuredEmployee(InsuredSearchDTO insuredDTO,
			HttpServletRequest request) throws LinkedException {

		if (InsuredServices.log.isDebugEnabled()) {
			InsuredServices.log
					.debug("In InsuredServices.java - addInsuredEmployee()");
		}

		try {
			GcomTransaction addTransaction = new GcomTransaction(
					this.gcomIniFile);
			addTransaction.addInsuredEmployee(insuredDTO, request);
			insuredDTO.setUserDTO(this.user);
			InformFactory.sendEmployeeAddInform(this.iniFile, this.user,
					insuredDTO);
		} catch (FileNotFoundException e) {
			InsuredServices.log.error(e.toString());
			throw new LinkedException("Error creating INFOrm:", e);
		}
	}


     /**
      * <p>addInsuredEmployeeForRequestChange.</p>
      *
      * @param insuredDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredRequestChangeSearchDTO} object.
      * @param request a {@link javax.servlet.http.HttpServletRequest} object.
      * @throws com.bcbssc.netsys.LinkedException if any.
      */
     public void addInsuredEmployeeForRequestChange(
			InsuredRequestChangeSearchDTO insuredDTO, HttpServletRequest request)
			throws LinkedException {

		if (InsuredServices.log.isDebugEnabled()) {
			InsuredServices.log
					.debug("In InsuredServices.java - addInsuredEmployeeForRequestChange()"
							+ insuredDTO);
		}

		try {
			GroupAdminUserInformHandler gaih = new GroupAdminUserInformHandler(
					this.iniFile);

			gaih.sendAddInsuredRequestChangeInform(insuredDTO);

		} catch (FileNotFoundException e) {
			InsuredServices.log.error(e.toString());
			throw new LinkedException("Error creating INFOrm:", e);
		}
	}


	/**
	 * Modifies an existing insured
	 *
	 * @param request
	 *            the request calling this service
	 * @throws com.bcbssc.netsys.LinkedException
	 *             if an MQ fails
	 * @param insuredDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredSearchDTO} object.
	 */
	public void modifyInsuredEmployee(InsuredSearchDTO insuredDTO,
			HttpServletRequest request) throws LinkedException {

		try {
			GcomTransaction modifyTransaction = new GcomTransaction(
					this.gcomIniFile);
			insuredDTO.setTermReinstateFlag('P');
			insuredDTO.setUserDTO(this.user);
			modifyTransaction.changeInsuredEmployee(insuredDTO, request);
			InformFactory.sendEmployeeChangeInform(this.iniFile, this.user,
					insuredDTO);
		} catch (FileNotFoundException e) {
			InsuredServices.log.error(e.toString());
			throw new LinkedException("Error creating INFOrm:", e);
		}
	}

	/**
	 * <p>requestaChange.</p>
	 *
	 * @param insuredDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredRequestChangeSearchDTO} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @throws com.bcbssc.netsys.LinkedException if any.
	 */
	public void requestaChange(InsuredRequestChangeSearchDTO insuredDTO,
				HttpServletRequest request) throws LinkedException {

			try {

				insuredDTO.setTermReinstateFlag('P');
				insuredDTO.setUserDTO(this.user);

				GroupAdminUserInformHandler gaih = new GroupAdminUserInformHandler(this.iniFile);

				gaih.sendChangeRequestInform(insuredDTO);

			} catch (Exception e) {
				InsuredServices.log.error(e.toString());
				throw new LinkedException("Error creating INFOrm:", e);
			}
	}

	/**
	 * Modifies the annual salary of an existing insured
	 *
	 * @param request
	 *            the request calling this service
	 * @throws com.bcbssc.netsys.LinkedException
	 *             if an MQ fails
	 * @param insuredDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredSearchDTO} object.
	 */
	public void modifyAnnualSalary(InsuredSearchDTO insuredDTO,
			HttpServletRequest request) throws LinkedException {

		try {
			GcomTransaction modifyTransaction = new GcomTransaction(
					this.gcomIniFile);
			insuredDTO.setTermReinstateFlag('P');
			insuredDTO.setUserDTO(this.user);
			modifyTransaction.changeSalary(insuredDTO, request);
			InformFactory.sendEmployeeChangeInform(this.iniFile, this.user,
					insuredDTO);
		} catch (FileNotFoundException e) {
			InsuredServices.log.error(e.toString());
			throw new LinkedException("Error creating INFOrm:", e);
		}
	}

	/**
	 * Terminates an existing insured
	 *
	 * @param request
	 *            the request calling this service
	 * @throws com.bcbssc.netsys.LinkedException
	 *             if an MQ fails
	 * @param insuredDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredSearchDTO} object.
	 */
	public void terminateInsuredEmployee(InsuredSearchDTO insuredDTO,
			HttpServletRequest request) throws LinkedException {

		try {
			GcomTransaction modifyTransaction = new GcomTransaction(
					this.gcomIniFile);
			insuredDTO.setTermReinstateFlag('T');
			insuredDTO.setStatus("9");
			insuredDTO.setUserDTO(this.user);
			modifyTransaction.changeInsuredEmployee(insuredDTO, request);
			InformFactory.sendEmployeeTerminateInform(this.iniFile, this.user,
					insuredDTO);
		} catch (FileNotFoundException e) {
			InsuredServices.log.error(e.toString());
			throw new LinkedException("Error creating INFOrm:", e);
		}
	}

	/**
	 * Performs an ID card/certificate request
	 *
	 * @param request
	 *            the request calling this service
	 * @throws com.bcbssc.netsys.LinkedException
	 *             if an MQ fails
	 * @param insuredDTO a {@link com.bcbssc.groupadmin.shared.dto.SpecialRequestDTO} object.
	 */
	public void performSpecialRequest(SpecialRequestDTO insuredDTO,
			HttpServletRequest request) throws LinkedException {

		try {
			GcomTransaction specialRequestTransaction = new GcomTransaction(
					this.gcomIniFile);

			// Send the T217 Transaction when dental card is requested
			if (StringUtils.isNotEmpty(insuredDTO.getRequestDentalCard())) {
				insuredDTO.setRequestOption(insuredDTO.getRequestDentalCard());
				specialRequestTransaction.sendSpecialRequest(insuredDTO,
						request);
			}

			// Send the T217 Transaction when dental card and certificate is
			// requested
			if (StringUtils
					.isNotEmpty(insuredDTO.getRequestDentalCardAndCert())) {
				insuredDTO.setRequestOption(insuredDTO
						.getRequestDentalCardAndCert());
				specialRequestTransaction.sendSpecialRequest(insuredDTO,
						request);
			}

			// Send the T217 Transaction when certificate for all other
			// coverages are requested
			if (StringUtils.isNotEmpty(insuredDTO.getRequestOtherCert())) {
				insuredDTO.setRequestOption(insuredDTO.getRequestOtherCert());
				specialRequestTransaction.sendSpecialRequest(insuredDTO,
						request);
			}

			// Send the T217 Transaction when vision certificate is reqested
			if (StringUtils.isNotEmpty(insuredDTO.getRequestVision())) {
				insuredDTO.setRequestOption(insuredDTO.getRequestVision());
				specialRequestTransaction.sendSpecialRequest(insuredDTO,
						request);
			}
			insuredDTO.setUserDTO(this.user);
			InformFactory.sendRequestInformationInform(this.iniFile, this.user,
					insuredDTO);
		} catch (FileNotFoundException e) {
			InsuredServices.log.error(e.toString());
			throw new LinkedException("Error creating INFOrm:", e);
		}
	}

	/**
	 * Updates the NEM indicator according to the business rules
	 *
	 * @param insuredDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredDataDTO} object.
	 */
	public static void updateNemIndicator(InsuredDataDTO insuredDTO) {

		// reset boolean and then re-scan all coverages
		insuredDTO.setNemIndicator(false);

		ArrayList items = insuredDTO.getCoverageItems();
		for (int i = 0; i < items.size(); i++) {
			CoverageItem item = (CoverageItem) items.get(i);
			int nem = item.getNoEvidenceMaxVolume();
			int volume = item.getVolume();

			// OLD
			// If the NEM (No-Evidence-Max) field is greater than the amount
			// entered, set the entered amount to the NEM value and set the
			// W001-NEM-Indicator on the T001 MQ.

			// NEW
			// If the entered volume is greater than the NEM (No-Evidence-Max)
			// field, set the entered volume to the NEM value and set the
			// W001-NEM-Indicator on the T001 MQ.
			if (volume > nem) {
				InsuredServices.log
						.debug("setting nem indicator, updating volume to "
								+ nem);
				// do no reset the volume - we need to know what they entered
				insuredDTO.setNemIndicator(true);
			}
		}
	}

	/**
	 * Performs business logic associated with the insured details add action
	 *
	 * @param dentalCoverage
	 *            true if insured has dental coverage
	 * @return error key to display to input page, or null if no error
	 * @throws java.sql.SQLException
	 *             if an SQL error occurs
	 * @param insuredDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredDataDTO} object.
	 */
	public String processAddDetails(InsuredDataDTO insuredDTO,
			boolean dentalCoverage) throws SQLException {

		String returnString = null;
		Collection searchResults;
		String idNumber = insuredDTO.getSsn();

		// Forms the identification number correctly based on dental coverage
		if (dentalCoverage) {
			idNumber = "D" + idNumber;
		}

		InsuredSearchDTO duplicateSearchDTO = new InsuredSearchDTO();
		duplicateSearchDTO.setGroupNumber(insuredDTO.getGroupNumber());
		duplicateSearchDTO.setSearchIdentificationNumber(idNumber);
		duplicateSearchDTO.setSearchStatus(Constants.STATUS_ALL);
		duplicateSearchDTO.setActionType("ADD");
		EmployeeSearch search = new EmployeeSearch(this.iniFile);
		searchResults = search.performSearchById(duplicateSearchDTO);

		if (searchResults.size() == 0) {
			insuredDTO.setIdentificationNumber(idNumber);
		} else {
			returnString = InsuredServices.ERRORS_ADD_DUPLICATE_ID;
		}
		return returnString;
	}

	/**
	 * Returns true if identificationNumber indicates dental coverage
	 *
	 * @return true if identificationNumber indicates dental; false otherwise
	 * @param identificationNumber a {@link java.lang.String} object.
	 */
	public static boolean isIdentificationNumberDental(
			String identificationNumber) {
		boolean returnBoolean;
		if (identificationNumber == null) {
			returnBoolean = false;
		} else {
			returnBoolean = identificationNumber.indexOf('D') == 0;
		}
		return returnBoolean;
	}

	/**
	 * Returns any business logic error for the terminate details page
	 *
	 * @param insuredDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredSearchDTO} object.
	 * @return a {@link java.lang.String} object.
	 */
	public static String getTerminateError(InsuredSearchDTO insuredDTO) {
		String error = null;

		InsuredServices.log.debug("in getTerminateError; status is: "
				+ insuredDTO.getStatus());
		if (!insuredDTO.getStatus().equals(Constants.STATUS_ACTIVE)) {
			error = "errors.not.active";
		}

		return error;
	}




}
