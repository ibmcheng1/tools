/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/RulesQuery.java_v  $
 * $Workfile:   RulesQuery.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:24  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/RulesQuery.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:14:24   EN80
 * Initial revision.
 * 
 *    Rev 1.8   Apr 28 2009 10:18:14   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.7   Mar 18 2005 15:26:52   rdq70
 * Removed main method with possible HIPAA data.
 *
 *    Rev 1.6   Mar 18 2005 15:10:32   rdq70
 * BlueHammur changes.
 *
 *    Rev 1.5   Sep 28 2004 16:29:24   rxg97
 * Added logic to skip subsequent searched users.
 *
 *    Rev 1.4   Sep 28 2004 10:23:04   rxg97
 * Moved DB internals to AbstractDBSearch.
 *
 *    Rev 1.3   Sep 23 2004 16:24:52   rxg97
 * Changed DATA_TYP from SYSTEM to ACCESSID.
 *
 *    Rev 1.2   Sep 23 2004 12:28:52   rxg97
 * Trim SQL values during user creation in addUserValues().
 *
 *    Rev 1.1   Sep 22 2004 09:59:34   rxg97
 * Now subclassing AbstractUserSearch.  Moved db call internals to that class.
 *
 *    Rev 1.0   Sep 12 2004 15:17:26   rxg97
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.dbaccess;

import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.netsys.Config;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

/**
 * Provides querying of the Rules tables for access code and user validation.
 *
 * @author rxg97 (Jonathan Egger)
 * @version $Id: $Id
 */
public class RulesQuery extends AbstractDBSearch {

	/** Constant <code>DB_COLUMN_LAST_NAME="LAST_NAME"</code> */
	public static final String DB_COLUMN_LAST_NAME = "LAST_NAME";

	/** Constant <code>DB_COLUMN_FIRST_NAME="FIRST_NAME"</code> */
	public static final String DB_COLUMN_FIRST_NAME = "FIRST_NAME";

	/** Constant <code>DB_COLUMN_MIDDLE_INI="MIDDLE_INIT"</code> */
	public static final String DB_COLUMN_MIDDLE_INI = "MIDDLE_INIT";

	/** Constant <code>DB_COLUMN_SUFFIX="SUFFIX"</code> */
	public static final String DB_COLUMN_SUFFIX = "SUFFIX";

	/** Constant <code>DB_COLUMN_ADDRESS_LINE_1="ADDRESS_LN1"</code> */
	public static final String DB_COLUMN_ADDRESS_LINE_1 = "ADDRESS_LN1";

	/** Constant <code>DB_COLUMN_ADDRESS_LINE_2="ADDRESS_LN2"</code> */
	public static final String DB_COLUMN_ADDRESS_LINE_2 = "ADDRESS_LN2";

	/** Constant <code>DB_COLUMN_CITY="CITY"</code> */
	public static final String DB_COLUMN_CITY = "CITY";

	/** Constant <code>DB_COLUMN_STATE="STATE_CD"</code> */
	public static final String DB_COLUMN_STATE = "STATE_CD";

	/** Constant <code>DB_COLUMN_POSTAL_CODE="ZIP5"</code> */
	public static final String DB_COLUMN_POSTAL_CODE = "ZIP5";

	/** Constant <code>DB_COLUMN_ZIP_PLUS_4="ZIP4"</code> */
	public static final String DB_COLUMN_ZIP_PLUS_4 = "ZIP4";

	/** Constant <code>DB_COLUMN_COUNTRY="CNTRY_CD"</code> */
	public static final String DB_COLUMN_COUNTRY = "CNTRY_CD";

	/** Constant <code>DB_COLUMN_TELEPHONE="PHONE_NO"</code> */
	public static final String DB_COLUMN_TELEPHONE = "PHONE_NO";

	/** Constant <code>DB_COLUMN_TELEPHONE_EXT="PHONE_EXT"</code> */
	public static final String DB_COLUMN_TELEPHONE_EXT = "PHONE_EXT";

	/** Constant <code>DB_COLUMN_FAX="FAX_NO"</code> */
	public static final String DB_COLUMN_FAX = "FAX_NO";

	/** Constant <code>DB_COLUMN_GROUP_NAME="PRIMARY_GROUP_NME"</code> */
	public static final String DB_COLUMN_GROUP_NAME = "PRIMARY_GROUP_NME";

	/** Constant <code>DB_COLUMN_GROUP_NO="PRIMARY_GROUP_NO"</code> */
	public static final String DB_COLUMN_GROUP_NO = "PRIMARY_GROUP_NO";

	/** The log4j logger for this class. */
	protected static Logger log = Logger.getLogger(RulesQuery.class);

	/** The line of business number. */
	private final String rpn;

	/** The date format used by the database. */
	private final SimpleDateFormat sqlDateFormat = new SimpleDateFormat(
			Constants.SQL_DATE_FORMAT);

	/**
	 * Creates an <code>RulesQuery</code> and configures it with an INI file.
	 *
	 * @param iniFile
	 *            file path of the configuration INI file.
	 */
	public RulesQuery(String iniFile) {
		super(iniFile, "RULES_TABLE");
		this.rpn = Config.getPrivateProfileString("MISC", "RPN",
				com.bcbssc.struts.common.Constants.BLANK_STRING, iniFile);
	}

	/**
	 * Uses SQL to verify an access code/ssn/dob combination. Returns the user
	 * if verification is successful.
	 *
	 * @param accessCode
	 *            the user access code
	 * @param ssn
	 *            the user access ssn
	 * @param szDob
	 *            the user date of birth
	 * @return a user object, if the user was found in the datebase; otherwise,
	 *         <code>null</code>.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 */
	public GroupAdminUserDTO verifyAccessCode(String accessCode, String ssn,
			String szDob) throws SQLException {

		GroupAdminUserDTO user = null;

		final String serviceDate = this.sqlDateFormat.format(new Date());
		final StringBuffer sql = new StringBuffer(500);
		final String applicationId = Config.getPrivateProfileString("MISC",
				"APP_ID", com.bcbssc.struts.common.Constants.BLANK_STRING,
				this.iniFile);

		this.checkInit(); // Necessary since we need the _dbSchema before the
							// query creation

		sql
				.append(" SELECT * FROM ")
				.append(this._dbSchema)
				.append(".DT_TYP_WEB_ID WHERE RP_NO = '")
				.append(this.rpn)
				.append(
						"' AND PLAN_CD = '885' AND DATA_TYP = 'ACCESSID' AND ACCESS_CD = '")
				.append(accessCode).append("'").append(
						" AND APPLICATION_ID = '").append(applicationId)
				.append("' AND LAST_SIX_DGTS_SSN = '").append(ssn).append(
						"' AND DATE_OF_BIRTH = '").append(szDob).append(
						"' AND SYS_VOID_STS_IND = 'N' AND DT_TYP_BEG <= '")
				.append(serviceDate).append("' AND DT_TYP_TRM >= '").append(
						serviceDate).append("'");

		if (RulesQuery.log.isDebugEnabled()) {
			RulesQuery.log
					.debug("SQL statement to verify access code using rules table: ");
			RulesQuery.log.debug(sql.toString());
		}

		user = (GroupAdminUserDTO) this.performSearch(sql.toString(),
				new GroupAdminUserDTO());

		if (user != null) {
			user.setAccessCode(accessCode);
			user.setLast6SSN(ssn);
			user.setDateOfBirth(szDob);
		}

		return user;
	}

	/**
	 * Uses SQL to verify the specified accessCode exists in the database.
	 *
	 * @param accessCode
	 *            the user access code
	 * @return <code>true</code>, if <code>accessCode</code> was found in
	 *         the database; otherwise <code>false</code>.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 */
	public boolean verifyUserStatus(String accessCode) throws SQLException {

		final String serviceDate = this.sqlDateFormat.format(new Date());
		final String applicationId = Config.getPrivateProfileString("MISC",
				"APP_ID", com.bcbssc.struts.common.Constants.BLANK_STRING,
				this.iniFile);
		final StringBuffer sql = new StringBuffer(500);

		this.checkInit(); // Necessary since we need the _dbSchema before the
							// query creation

		sql
				.append(" SELECT * FROM ")
				.append(this._dbSchema)
				.append(".DT_TYP_WEB_ID WHERE RP_NO = '")
				.append(this.rpn)
				.append(
						"' AND PLAN_CD = '885' AND DATA_TYP = 'ACCESSID' AND ACCESS_CD = '")
				.append(accessCode).append("'").append(
						" AND APPLICATION_ID = '").append(applicationId)
				.append("' AND SYS_VOID_STS_IND = 'N' AND DT_TYP_BEG <= '")
				.append(serviceDate).append("' AND DT_TYP_TRM >= '").append(
						serviceDate).append("'");

		if (RulesQuery.log.isDebugEnabled()) {
			RulesQuery.log
					.debug("SQL statement to verify user status using rules table: ");
			RulesQuery.log.debug(sql.toString());
		}

		return this.performCheck(sql.toString());
	}

	/**
	 * Uses SQL to determine if an access has been requested for the specified
	 * ssn/dob combination.
	 *
	 * @param ssn
	 *            the user access ssn
	 * @param szDob
	 *            the user date of birth
	 * @return <code>true</code>, if <code>accessCode</code> was found in
	 *         the database; otherwise <code>false</code>.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 */
	public boolean accessCodeRequested(String ssn, String szDob)
			throws SQLException {

		final String serviceDate = this.sqlDateFormat.format(new Date());
		final String applicationId = Config.getPrivateProfileString("MISC",
				"APP_ID", com.bcbssc.struts.common.Constants.BLANK_STRING,
				this.iniFile);
		final StringBuffer sql = new StringBuffer(500);

		this.checkInit(); // Necessary since we need the _dbSchema before the
							// query creation

		sql
				.append(" SELECT ACCESS_CD FROM ")
				.append(this._dbSchema)
				.append(".DT_TYP_WEB_ID WHERE RP_NO = '")
				.append(this.rpn)
				.append(
						"' AND PLAN_CD = '885' AND DATA_TYP = 'ACCESSID' AND APPLICATION_ID = '")
				.append(applicationId).append("' AND LAST_SIX_DGTS_SSN = '")
				.append(ssn).append("' AND DATE_OF_BIRTH = '").append(szDob)
				.append("' AND SYS_VOID_STS_IND = 'N' AND DT_TYP_BEG <= '")
				.append(serviceDate).append("' AND DT_TYP_TRM >= '").append(
						serviceDate).append("'");

		if (RulesQuery.log.isDebugEnabled()) {
			RulesQuery.log
					.debug("SQL statement to determine if access code is requested using rules table: ");
			RulesQuery.log.debug(sql.toString());
		}

		return this.performCheck(sql.toString());
	}

	/**
	 * {@inheritDoc}
	 *
	 * Populates the given user object with the values from the result set.
	 */
	protected void addSearchItem(ResultSet data, Object obj)
			throws SQLException {

		GroupAdminUserDTO user = (GroupAdminUserDTO) obj;

		// the current column
		String cc = com.bcbssc.struts.common.Constants.BLANK_STRING;

		// The user search should only return a single user. If one has already
		// been found, skip this.
		if (user.getSamAccountName().length() == 0) {

			try {
				user.setLastName(data.getString(
						cc = RulesQuery.DB_COLUMN_LAST_NAME).trim());
				user.setGivenName(data.getString(
						cc = RulesQuery.DB_COLUMN_FIRST_NAME).trim());
				user.setMiddleIni(data.getString(
						cc = RulesQuery.DB_COLUMN_MIDDLE_INI).trim());
				user.setSuffix(data.getString(cc = RulesQuery.DB_COLUMN_SUFFIX)
						.trim());
				user.setStreet(data.getString(
						cc = RulesQuery.DB_COLUMN_ADDRESS_LINE_1).trim());
				user.setAddressLine2(data.getString(
						cc = RulesQuery.DB_COLUMN_ADDRESS_LINE_2).trim());
				user.setCity(data.getString(cc = RulesQuery.DB_COLUMN_CITY)
						.trim());
				user.setState(data.getString(cc = RulesQuery.DB_COLUMN_STATE)
						.trim());

				StringBuffer postalCode = new StringBuffer(data.getString(
						cc = RulesQuery.DB_COLUMN_POSTAL_CODE).trim());
				postalCode.append(data.getString(
						cc = RulesQuery.DB_COLUMN_ZIP_PLUS_4).trim());
				user.setPostalCode(postalCode.toString());

				user.setCountry(data.getString(
						cc = RulesQuery.DB_COLUMN_COUNTRY).trim());

				String telephoneNumber = data.getString(
						cc = RulesQuery.DB_COLUMN_TELEPHONE).trim();
				user.setTelephoneNumber(telephoneNumber);

				user.setTelephoneExt(data.getString(
						cc = RulesQuery.DB_COLUMN_TELEPHONE_EXT).trim());
				user.setFax(data.getString(cc = RulesQuery.DB_COLUMN_FAX)
						.trim());
				user.setGroupName(data.getString(
						cc = RulesQuery.DB_COLUMN_GROUP_NAME).trim());
				user.setGroupNumber(data.getString(
						cc = RulesQuery.DB_COLUMN_GROUP_NO).trim());
			} catch (SQLException e) {
				RulesQuery.log
						.error("error while getting DB value from column: "
								+ cc);
				throw e;
			}
		}
	}
}
