/*
 * @(#)ModifyInsuredDetailsForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.forms;

import com.bcbssc.groupadmin.shared.dto.Dependent;
import com.bcbssc.struts.common.FormDate;

import java.util.ArrayList;
import java.util.Collection;

import org.apache.struts.util.LabelValueBean;

/**
 * GroupAdmin Add Insured Details Form
 *
 * This bean extends the insured details form by providing modify-specific clear
 * and getResettable methods.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class ModifyInsuredDetailsForm extends InsuredDetailsForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Indicate whether this employee has dental or not
	 *
	 * @return a boolean.
	 */
	public boolean getDentalCoverage() {
		boolean returnBoolean;
		if (this.identificationNumber.startsWith("D")) {
			returnBoolean = true;
		} else {
			returnBoolean = false;
		}
		return returnBoolean;
	}

	/**
	 * Clears the user-editable data fields for this form
	 */
	public void clear() {
		this.givenName = com.bcbssc.struts.common.Constants.BLANK_STRING;
		this.lastName = com.bcbssc.struts.common.Constants.BLANK_STRING;
		this.middleIni = com.bcbssc.struts.common.Constants.BLANK_STRING;
		this.dateOfBirth = new FormDate();
		this.hireDate = new FormDate();
		this.identificationNumber = com.bcbssc.struts.common.Constants.BLANK_STRING;
		this.gender = com.bcbssc.struts.common.Constants.BLANK_STRING;
		this.setSsn(com.bcbssc.struts.common.Constants.BLANK_STRING);
		this.addressLine1 = com.bcbssc.struts.common.Constants.BLANK_STRING;
		this.addressLine2 = com.bcbssc.struts.common.Constants.BLANK_STRING;
		this.city = com.bcbssc.struts.common.Constants.BLANK_STRING;
		this.state = com.bcbssc.struts.common.Constants.BLANK_STRING;
		this.zip = com.bcbssc.struts.common.Constants.BLANK_STRING;
		this.department = com.bcbssc.struts.common.Constants.BLANK_STRING;
		this.payrollOfficeIdentifier = com.bcbssc.struts.common.Constants.BLANK_STRING;
		this.occupation = com.bcbssc.struts.common.Constants.BLANK_STRING;
		this.cobra = com.bcbssc.struts.common.Constants.BLANK_STRING;
		this.smoker = com.bcbssc.struts.common.Constants.BLANK_STRING;
		this.setSpouse(new Dependent());
	}

	/**
	 * Returns a collection of resettable name/value pairs. @ return Collection
	 * of LabelValueBean objects, each containing the name and value of a
	 * resettable property.
	 *
	 * @return a {@link java.util.Collection} object.
	 */
	public Collection getResettables() {
		ArrayList resettables = new ArrayList();

		resettables.add(new LabelValueBean("givenName", this.getGivenName()));
		resettables.add(new LabelValueBean("lastName", this.getLastName()));
		resettables.add(new LabelValueBean("middleIni", this.getMiddleIni()));
		resettables.add(new LabelValueBean("dobMonth", this.getDobMonth()));
		resettables.add(new LabelValueBean("dobDay", this.getDobDay()));
		resettables.add(new LabelValueBean("dobYear", this.getDobYear()));
		resettables.add(new LabelValueBean("gender", this.getGender()));
		resettables.add(new LabelValueBean("ssn", this.getSsn()));
		resettables.add(new LabelValueBean("addressLine1", this
				.getAddressLine1()));
		resettables.add(new LabelValueBean("addressLine2", this
				.getAddressLine2()));
		resettables.add(new LabelValueBean("city", this.getCity()));
		resettables.add(new LabelValueBean("state", this.getState()));
		resettables.add(new LabelValueBean("zip", this.getZip()));

		resettables.add(new LabelValueBean("department", this.getDepartment()));
		resettables.add(new LabelValueBean("payrollOfficeIdentifier", this
				.getPayrollOfficeIdentifier()));
		resettables.add(new LabelValueBean("occupation", this.getOccupation()));
		resettables.add(new LabelValueBean("cobra", this.getCobra()));
		resettables.add(new LabelValueBean("smoker", this.getSmoker()));

		resettables.add(new LabelValueBean("spouseExists", String.valueOf(this
				.getSpouseExists())));

		return resettables;
	}

	/**
	 * Returns a collection of resettable properties that are referenced by bean @ return
	 * Collection of LabelValueBean objects, each containing the name and value
	 * of a bean-referenced arrayed resettable property.
	 *
	 * @return a {@link java.util.Collection} object.
	 */
	public Collection getBeanResettables() {
		ArrayList resettables = new ArrayList();

		resettables.add(new LabelValueBean("spouse.added", String
				.valueOf(false)));
		resettables.add(new LabelValueBean("spouse.changed", String
				.valueOf(false)));

		resettables.add(new LabelValueBean("spouse.givenName", this.getSpouse()
				.getGivenName()));
		resettables.add(new LabelValueBean("spouse.lastName", this.getSpouse()
				.getLastName()));
		resettables.add(new LabelValueBean("spouse.middleIni", this.getSpouse()
				.getMiddleIni()));

		resettables.add(new LabelValueBean("spouse.dobMonth", this.getSpouse()
				.getDobMonth()));
		resettables.add(new LabelValueBean("spouse.dobDay", this.getSpouse()
				.getDobDay()));
		resettables.add(new LabelValueBean("spouse.dobYear", this.getSpouse()
				.getDobYear()));

		resettables.add(new LabelValueBean("spouse.gender", this.getSpouse()
				.getGender()));
		resettables.add(new LabelValueBean("spouse.ssn", this.getSpouse()
				.getSsn()));

		return resettables;
	}
}
