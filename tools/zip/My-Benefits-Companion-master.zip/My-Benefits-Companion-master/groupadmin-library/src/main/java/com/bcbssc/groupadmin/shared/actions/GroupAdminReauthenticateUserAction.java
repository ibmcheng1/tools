/*
 * @(#)GroupAdminReauthenticateAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.actions;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.groupadmin.shared.dto.RegistrationFormDTO;
import com.bcbssc.groupadmin.shared.services.GroupAdminRegistrationServices;
import com.bcbssc.struts.action.BaseAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;

/**
 * Group Admin Reauthenticate Action
 *
 * This class provides control processing the reauthenticate user action.
 * Because control for reauthentication is specific to group admin registration,
 * this class does not subclass a shared action.
 *
 * @author Surendra V Poranki
 * @version $Revision:   1.1  $
 */
public class GroupAdminReauthenticateUserAction extends BaseAction {

	/** log4j logger */
	private static final Logger log = Logger
			.getLogger(GroupAdminReauthenticateUserAction.class.getName());

	/** specifies reauthentication of user (as opposed to challenge reauth) */
	private static final String REAUTHENTICATE_TYPE_USER = "user";

	/**
	 * Processes the specified HTTP request, and create sthe corresponding HTTP
	 * response.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		ActionForward returnActionForward = null;
		DynaValidatorForm df = (DynaValidatorForm) form;

		String iniFile = CommonUtils.getIniFile(this.getServlet());
		String tdsIniFile = CommonUtils.getTDSIniFile(this.getServlet());

		GroupAdminRegistrationServices service = new GroupAdminRegistrationServices(
				iniFile, tdsIniFile);
		RegistrationFormDTO formDTO = new RegistrationFormDTO();
		BeanUtils.copyProperties(formDTO, df);

		String reauthtype = mapping.getParameter();
		GroupAdminReauthenticateUserAction.log.debug("reauthtype ="
				+ reauthtype);

		if (reauthtype
				.equals(GroupAdminReauthenticateUserAction.REAUTHENTICATE_TYPE_USER)) {
			// Reauthenticating user
			int status = service.reauthenticateUser(formDTO);

			String forwardname;

			switch (status) {
			case Constants.SERVICE_VALID:
				request.setAttribute("reauthenticationFormBean", formDTO);
				forwardname = com.bcbssc.registration.common.Constants.FORWARD_SUCCESS;
				break;
			case Constants.SERVICE_MULTIPLE_MATCH:
				request.setAttribute("reauthenticationFormBean", formDTO);
				forwardname = Constants.FORWARD_MULTIPLE_MATCH;
				break;
			default: // Constants.SERVICE_INVALID
				forwardname = Constants.FORWARD_NOTFOUND;
				break;
			}

			returnActionForward = mapping.findForward(forwardname);

		} else {
			// Reauthenticating challenge
			int status = service.reauthenticateChallenge(formDTO);

			String forwardname;

			switch (status) {
			case Constants.SERVICE_VALID:
				forwardname = com.bcbssc.registration.common.Constants.FORWARD_SUCCESS;
				request.setAttribute("resetPasswordForm", formDTO);
				break;
			case Constants.INVALID_ANSWER:
				forwardname = Constants.FORWARD_INVALID_ANSWER;
				request.setAttribute("reauthenticationFormBean", formDTO);
				break;
			default:
				this.addGlobalRequestMessage(request,
						"reauthenticate.challengefailed");
				request.setAttribute("reauthenticationFormBean", formDTO);
				return (new ActionForward(mapping.getInput()));
			}
			returnActionForward = mapping.findForward(forwardname);
		}
		return returnActionForward;
	}
}
