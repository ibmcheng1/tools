/*
 * @(#)CoverageDetailsAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.actions;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.dto.AddCoverageItem;
import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;
import com.bcbssc.groupadmin.shared.forms.AddCoverageForm;
import com.bcbssc.groupadmin.shared.services.InsuredServices;
import com.bcbssc.struts.action.BaseAction;

/**
 * Group Admin Insured Coverage Details Action
 *
 * This class provides control processing the coverage details action.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class CoverageDetailsAction extends BaseAction {

	/** log4j logger */
	private static final Logger log = Logger
			.getLogger(CoverageDetailsAction.class.getName());

	/**
	 * <p>Constructor for CoverageDetailsAction.</p>
	 */
	public CoverageDetailsAction() {
		super();
		if (CoverageDetailsAction.log.isDebugEnabled()) {
			CoverageDetailsAction.log
					.debug("Created CoverageDetailsAction object.");
		}
	}

	/**
	 * Processes the specified HTTP request, and creates the corresponding HTTP
	 * response.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		AddCoverageForm coverageForm = (AddCoverageForm) form;

		InsuredDataDTO insuredDataDTO = new InsuredDataDTO();
		BeanUtils.copyProperties(insuredDataDTO, coverageForm);

		ArrayList coverages = (ArrayList) coverageForm
				.getCoverageClasses();

		InsuredServices insuredServices = new InsuredServices(
				CommonUtils.getIniFile(this.getServlet()),
				CommonUtils.getGcomIniFile(this.getServlet()),
				(GroupAdminUserDTO) request
						.getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
		insuredServices.getCoverageDetails(insuredDataDTO, coverages);

		AddCoverageForm returnForm = (AddCoverageForm) this.getForm(
				"addCoverageForm", "/addCoverage", request);
		BeanUtils.copyProperties(returnForm, insuredDataDTO);

		// this is for an add insured employee path only
		AddCoverageItem.checkSpecialConditions(coverageForm, coverageForm
				.getCoverageItems());

		request.setAttribute("coverageForm", returnForm);
		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}

}
