/*
 * @(#)InsuredSearchForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.forms;

import com.bcbssc.groupadmin.shared.actions.InsuredModifyAction;
import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.groupadmin.shared.dto.CoverageItem;
import com.bcbssc.groupadmin.shared.dto.InsuredSearchDTO;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * GroupAdmin Insured Search Form
 *
 * This bean is used to transport insured employee search data. It is extended
 * by form classes that implement validate and clear methods specific to the
 * individual forms, if required.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class InsuredSearchForm extends InsuredDataForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** search type */
	private String searchType;

	/** search results */
	private Collection searchResults;
	
	private ArrayList policyList;

	/** search last name */
	private String searchLastName;

	/** selected path items */
	private String[] selectedPathItems = {};

	private ArrayList selectedPathItemsArrayList = null;

	/** path items */
	private String[] pathItems = { InsuredModifyAction.MODIFY_INSURED,
			InsuredModifyAction.MODIFY_COVERAGE,
			InsuredModifyAction.MODIFY_DEPENDENTS,
			InsuredModifyAction.MODIFY_SALARY };

	/** format used for getDate (instantiated in that method) */
	private static SimpleDateFormat dateFormat = null;

	/**
	 * Holds value of property identificationNumber.
	 */
	private String searchIdentificationNumber;

	/**
	 * Holds value of property searchStatus (defaulted to active).
	 */
	private String searchStatus = Options.STATUS_ACTIVE[com.bcbssc.struts.forms.Options.VALUE_INDEX];

	/**
	 * Holds value of property activeCount.
	 */
	private String activeCount;

	/**
	 * Holds value of property selectedID.
	 */
	private String selectedID;

	/**
	 * Holds value of property searchResultsCount.
	 */
	private String searchResultsCount;

	/**
	 * Holds value of property currentPage.
	 */
	private String currentPage;

	/**
	 * Holds value of property sortOrder.
	 */
	private int sortOrder = InsuredSearchDTO.SORT_BY_NAME_ASCENDING;

	/**
	 * Holds value of property insuredPageUpdated.
	 */
	private boolean insuredPageUpdated = false;

	/**
	 * Holds value of property coveragePageUpdated.
	 */
	private boolean coveragePageUpdated;

	/**
	 * Holds value of property dependentPageUpdated.
	 */
	private boolean dependentPageUpdated;

	/**
	 * Holds value of property salaryPageUpdated.
	 */
	private boolean salaryPageUpdated;

	/**
	 * Holds value of property addressUpdated.
	 */
	private boolean addressUpdated;

	/**
	 * Holds value of property addressAdded.
	 */
	private boolean addressAdded;

	/**
	 * Holds value of property payPeriod.
	 */
	private String payPeriod;

	/**
	 * Holds value of property productSelected.
	 */
	private String productSelected;

	/**
	 * Getter for property searchType.
	 *
	 * @return Value of property searchType.
	 */
	public String getSearchType() {
		return this.searchType;
	}

	/**
	 * Setter for property searchType.
	 *
	 * @param value
	 *            New value of property searchType.
	 */
	public void setSearchType(String value) {
		this.searchType = value;
	}

	/**
	 * Getter for property searchLastName.
	 *
	 * @return Value of property searchLastName.
	 */
	public String getSearchLastName() {
		return this.searchLastName;
	}

	/**
	 * Setter for property searchLastName.
	 *
	 * @param value
	 *            New value of property searchLastName.
	 */
	public void setSearchLastName(String value) {
		this.searchLastName = value;
	}

	/**
	 * Getter for property searchIdentificationNumber.
	 *
	 * @return Value of property searchIdentificationNumber.
	 */
	public String getSearchIdentificationNumber() {
		return this.searchIdentificationNumber;
	}

	/**
	 * Setter for property searchIdentificationNumber.
	 *
	 * @param searchIdentificationNumber
	 *            New value of property searchIdentificationNumber.
	 */
	public void setSearchIdentificationNumber(String searchIdentificationNumber) {
		this.searchIdentificationNumber = searchIdentificationNumber;
	}

	/**
	 * Getter for property searchStatus.
	 *
	 * @return Value of property searchStatus.
	 */
	public String getSearchStatus() {
		return this.searchStatus;
	}

	/**
	 * Setter for property searchStatus.
	 *
	 * @param searchStatus
	 *            New value of property searchStatus.
	 */
	public void setSearchStatus(String searchStatus) {
		this.searchStatus = searchStatus;
	}

	/**
	 * Getter for property searchResults.
	 *
	 * @return Value of property searchResults.
	 */
	public Collection getSearchResults() {
		return this.searchResults;
	}

	/**
	 * Setter for property searchResults.
	 *
	 * @param searchResults
	 *            New value of property searchResults.
	 */
	public void setSearchResults(Collection searchResults) {
		this.searchResults = searchResults;
	}

	/**
	 * Getter for property activeCount.
	 *
	 * @return Value of property activeCount.
	 */
	public String getActiveCount() {
		return this.activeCount;
	}

	/**
	 * Setter for property activeCount.
	 *
	 * @param activeCount
	 *            New value of property activeCount.
	 */
	public void setActiveCount(String activeCount) {
		this.activeCount = activeCount;
	}

	/**
	 * Getter for property selectedID.
	 *
	 * @return Value of property selectedID.
	 */
	public String getSelectedID() {
		return this.selectedID;
	}

	/**
	 * Setter for property selectedID.
	 *
	 * @param selectedID
	 *            New value of property selectedID.
	 */
	public void setSelectedID(String selectedID) {
		this.selectedID = selectedID;
	}

	/**
	 * <p>clear.</p>
	 */
	public void clear() {
		// Do nothing
	}

	/**
	 * Getter for property searchResultsCount.
	 *
	 * @return Value of property searchResultsCount.
	 */
	public String getSearchResultsCount() {
		return this.searchResultsCount;
	}

	/**
	 * Setter for property searchResultsCount.
	 *
	 * @param searchResultsCount
	 *            New value of property searchResultsCount.
	 */
	public void setSearchResultsCount(String searchResultsCount) {
		this.searchResultsCount = searchResultsCount;
	}

	/**
	 * Gets the formatted total premium
	 *
	 * @return formatted total premium
	 */
	public String getPremiumTotalFormatted() {
		return CommonUtils.formatCurrency(this.coverageItems.getPremiumTotal(),
				CoverageItem.PREMIUM_CENTS_DIGITS);
	}

	/**
	 * Gets the selected path items
	 *
	 * @return selected path items
	 */
	public String[] getSelectedPathItems() {
		// Reset the corresponding ArrayList (will be created again if needed)
		this.selectedPathItemsArrayList = null;
		return this.selectedPathItems;
	}

	/**
	 * Returns the selected path items as an ArrayList
	 *
	 * @return ArrayList containing selected path items
	 */
	public ArrayList getSelectedPathItemsArrayList() {
		if (this.selectedPathItemsArrayList == null) {
			this.selectedPathItemsArrayList = new ArrayList();

			for (int i = 0; i < this.selectedPathItems.length; i++) {
				this.selectedPathItemsArrayList.add(this.selectedPathItems[i]);
			}
		}
		return this.selectedPathItemsArrayList;
	}

	/**
	 * Setter for selected path items
	 *
	 * @param values
	 *            selected path items
	 */
	public void setSelectedPathItems(String[] values) {
		this.selectedPathItems = values;
	}

	/**
	 * Gets the path items
	 *
	 * @return path items
	 */
	public String[] getPathItems() {
		return this.pathItems;
	}

	/**
	 * Getter for property currentPage.
	 *
	 * @return Value of property currentPage.
	 */
	public String getCurrentPage() {
		return this.currentPage;
	}

	/**
	 * Setter for property currentPage.
	 *
	 * @param currentPage
	 *            New value of property currentPage.
	 */
	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}

	/**
	 * Gets today's date in mm/dd/yyyy format
	 *
	 * @return country options
	 */
	public String getDate() {
		if (InsuredSearchForm.dateFormat == null) {
			InsuredSearchForm.dateFormat = new SimpleDateFormat(
					Constants.DISPLAY_DATE_FORMAT);
		}

		return InsuredSearchForm.dateFormat.format(new Date());
	}

	/**
	 * Getter for property sortOrder.
	 *
	 * @return Value of property sortOrder.
	 */
	public int getSortOrder() {
		return this.sortOrder;
	}

	/**
	 * Setter for property sortOrder.
	 *
	 * @param sortOrder
	 *            New value of property sortOrder.
	 */
	public void setSortOrder(int sortOrder) {
		this.sortOrder = sortOrder;
	}

	/**
	 * Getter for property insuredPageUpdated.
	 *
	 * @return Value of property insuredPageUpdated.
	 */
	public boolean isInsuredPageUpdated() {
		return this.insuredPageUpdated;
	}

	/**
	 * Setter for property insuredPageUpdated.
	 *
	 * @param insuredPageUpdated
	 *            New value of property insuredPageUpdated.
	 */
	public void setInsuredPageUpdated(boolean insuredPageUpdated) {
		this.insuredPageUpdated = insuredPageUpdated;
	}

	/**
	 * Getter for property coveragePageUpdated.
	 *
	 * @return Value of property coveragePageUpdated.
	 */
	public boolean isCoveragePageUpdated() {
		return this.coveragePageUpdated;
	}

	/**
	 * Setter for property coveragePageUpdated.
	 *
	 * @param coveragePageUpdated
	 *            New value of property coveragePageUpdated.
	 */
	public void setCoveragePageUpdated(boolean coveragePageUpdated) {
		this.coveragePageUpdated = coveragePageUpdated;
	}

	/**
	 * Getter for property dependentPageUpdated.
	 *
	 * @return Value of property dependentPageUpdated.
	 */
	public boolean isDependentPageUpdated() {
		return this.dependentPageUpdated;
	}

	/**
	 * Setter for property dependentPageUpdated.
	 *
	 * @param dependentPageUpdated
	 *            New value of property dependentPageUpdated.
	 */
	public void setDependentPageUpdated(boolean dependentPageUpdated) {
		this.dependentPageUpdated = dependentPageUpdated;
	}

	/**
	 * Getter for property salaryPageUpdated.
	 *
	 * @return Value of property salaryPageUpdated.
	 */
	public boolean isSalaryPageUpdated() {
		return this.salaryPageUpdated;
	}

	/**
	 * Setter for property salaryPageUpdated.
	 *
	 * @param salaryPageUpdated
	 *            New value of property salaryPageUpdated.
	 */
	public void setSalaryPageUpdated(boolean salaryPageUpdated) {
		this.salaryPageUpdated = salaryPageUpdated;
	}

	/**
	 * Getter for property addressUpdated.
	 *
	 * @return Value of property addressUpdated.
	 */
	public boolean getAddressUpdated() {
		return this.addressUpdated;
	}

	/**
	 * Setter for property addressUpdated.
	 *
	 * @param addressUpdated
	 *            New value of property addressUpdated.
	 */
	public void setAddressUpdated(boolean addressUpdated) {
		this.addressUpdated = addressUpdated;
	}

	/**
	 * Getter for property addressAdded.
	 *
	 * @return Value of property addressUpdated.
	 */
	public boolean getAddressAdded() {
		return this.addressAdded;
	}

	/**
	 * Setter for property addressAdded.
	 *
	 * @param addressAdded a boolean.
	 */
	public void setAddressAdded(boolean addressAdded) {
		this.addressAdded = addressAdded;
	}

	/**
	 * Getter for property payPeriod
	 *
	 * @return Value of property payPeriod .
	 */
	public String getPayPeriod() {
		return this.payPeriod;
	}

	/**
	 * Getter for formatted property payPeriod.
	 *
	 * @return Formatted value of property payPeriod.
	 */
	public String getPayPeriodFormatted() {
		return com.bcbssc.struts.forms.Options.getLabelFromValue(Options
				.getGroupAdminInstance().getPayPeriodOptions(), this.payPeriod);
	}

	/**
	 * Setter for property payPeriod.
	 *
	 * @param payPeriod
	 *            New value of property payPeriod.
	 */
	public void setPayPeriod(String payPeriod) {
		this.payPeriod = payPeriod;
	}

	/**
	 * Getter for property productSelected
	 *
	 * @return Value of property productSelected .
	 */
	public String getProductSelected() {
		return this.productSelected;
	}

	/**
	 * Getter for formatted property productSelected.
	 *
	 * @return Formatted value of property productSelected.
	 */
	public String getProductSelectedFormatted() {
		return com.bcbssc.struts.forms.Options.getLabelFromValue(Options
				.getGroupAdminInstance().getProductOptions(),
				this.productSelected);
	}

	/**
	 * Setter for property productSelected.
	 *
	 * @param productSelected
	 *            New value of property productSelected.
	 */
	public void setProductSelected(String productSelected) {
		this.productSelected = productSelected;
	}
	
	/**
	 * <p>Setter for the field <code>policyList</code>.</p>
	 *
	 * @param policyList a {@link java.util.ArrayList} object.
	 */
	public void setPolicyList(ArrayList policyList){
		this.policyList = policyList;
	}

	
	/**
	 * <p>Getter for the field <code>policyList</code>.</p>
	 *
	 * @return a {@link java.util.ArrayList} object.
	 */
	public ArrayList getPolicyList(){
		
		if(null == this.policyList){
			policyList =  new ArrayList();
		}
		return this.policyList;
	}

}
