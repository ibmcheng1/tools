/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mq/InformRequestFormat.java_v  $
 * $Workfile:   InformRequestFormat.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:16:18  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mq/InformRequestFormat.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:16:18   EN80
 * Initial revision.
 * 
 *    Rev 1.13   Apr 28 2009 10:20:24   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.12   May 09 2006 10:33:22   rx08e
 * Changes for Vision Coverage.	
 *
 *    Rev 1.11   May 10 2005 12:11:26   rxr93
 * cache xml document for performance purposes
 *
 *    Rev 1.10   Mar 18 2005 15:10:34   rdq70
 * BlueHammur changes.
 *
 *    Rev 1.9   Mar 15 2005 14:47:26   rxr93
 * issm change
 *
 *    Rev 1.8   Mar 02 2005 12:37:44   rxr93
 * adjust label diplay for lists
 *
 *    Rev 1.7   Feb 25 2005 09:16:54   rxr93
 * add status, corrspName, and requestCode to the XML format
 *
 *    Rev 1.6   Feb 24 2005 17:17:28   rdq70
 * Added handling of null values.
 *
 *    Rev 1.5   Feb 24 2005 17:01:24   rxr93
 * change constructor, check for status in xml attributes
 *
 *    Rev 1.4   Feb 23 2005 16:38:14   rdq70
 * Use JXPath instead of direct reflection to evaluate value attributes.
 *
 *    Rev 1.3   Feb 23 2005 14:56:14   rdq70
 * Added handling of DateBeans.
 *
 *    Rev 1.2   Feb 23 2005 11:27:02   rxr93
 * accomidate static text in xml file
 *
 *    Rev 1.1   Feb 22 2005 16:46:34   rdq70
 * Code inspection / bug fixes
 */

package com.bcbssc.groupadmin.shared.mq;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.commons.jxpath.JXPathContext;
import org.apache.log4j.Logger;
import org.apache.xerces.parsers.DOMParser;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.bcbssc.struts.common.DateBean;

/**
 * Formats the content (request lines) of an Inform based on an XML input file.
 *
 * @author mark
 * @version $Id: $Id
 */
public class InformRequestFormat {

	/** log4j logger */
	private static final Logger logger = Logger
			.getLogger(InformRequestFormat.class);

	// node identifiers
	private static final String PARAM = "line";

	private static final String LIST = "list";

	private static final String CORRSP = "corrspName";

	private static final String IGNORE_NODE = "#text";

	// attribute tags
	private static final String REQUEST_CODE_KEY = "requestCode";

	private static final String STATUS_KEY = "status";

	private static final String STATUS_OPEN = "open";

	// for performance we need to cache the parsed xml file(s)
	private static HashMap documents;

	// name of xml file defineing the request line format
	private String xmlFileName;

	//
	private String corrspName;

	// requestCode (BILL, CERT, ...)
	private String requestCode;

	// indicate last inform parsed was closed or not closed (ie. open)
	private boolean closedInform;

	// formated output
	private String formattedOutput;

	static {
		// allocate object to hold parsed map
		InformRequestFormat.documents = new HashMap();
	}

	/**
	 * Creates a new Request Formatter for the file designated.
	 *
	 * @param xmlFile -
	 *            the xml file defining request line format.
	 */
	public InformRequestFormat(String xmlFile) {
		this.xmlFileName = xmlFile;

		if (InformRequestFormat.documents.get(xmlFile) == null) {
			InformRequestFormat.logger.debug("need to load file :" + xmlFile);
			this.loadXML();
		}
	}

	/**
	 * load xml file, parse and cache the document
	 * 
	 * @throws DOMException
	 */
	private void loadXML() {
		try {
			BufferedInputStream in = new BufferedInputStream(
					new FileInputStream(this.xmlFileName));

			// read and parse file
			InputSource xmlIn = new InputSource(in);
			DOMParser msgParser = new DOMParser();
			msgParser.parse(xmlIn);

			InformRequestFormat.documents.put(this.xmlFileName, msgParser
					.getDocument());

		} catch (Exception e) {
			InformRequestFormat.logger.error("Error:", e);
			final StringBuffer buf = new StringBuffer(64);
			buf.append("filename=").append(this.xmlFileName).append(": ")
					.append(e.getMessage());
			throw new DOMException((short) 0, buf.toString());
		}
	}

	/**
	 * boolean designating this is closed inform (or not)
	 *
	 * @return String
	 */
	public boolean isClosedInform() {
		return this.closedInform;
	}

	/**
	 * boolean designating this is open inform (or not)
	 *
	 * @return String
	 */
	public boolean isOpenInform() {
		return !this.closedInform;
	}

	/**
	 * Return the coorspName designated by the xml file
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getCorrspName() {
		return this.corrspName;
	}

	/**
	 * Return the request code designated by the xml file
	 *
	 * @return String
	 */
	public String getRequestCode() {
		return this.requestCode;
	}

	/**
	 * Return formated output for the request lines of the inform
	 *
	 * @return String
	 */
	public String getFormattedOutput() {
		return this.formattedOutput;
	}

	/**
	 * Process all lines for a task.
	 *
	 * @param mainObject
	 *            data object
	 * @throws java.io.FileNotFoundException
	 *             if the XML file is not found.
	 * @throws DOMException
	 *             if an error occurs.
	 * @param taskName a {@link java.lang.String} object.
	 */
	public void processLines(String taskName, Object mainObject)
			throws FileNotFoundException {

		try {

			// prepare output buffer
			StringBuffer requestLines = new StringBuffer(1000);

			// get document info and process it
			Document document = (Document) InformRequestFormat.documents
					.get(this.xmlFileName);
			if (document == null) {
				throw new FileNotFoundException(this.xmlFileName);
			}
			Element task = document.getDocumentElement();

			// get all elements for the taskName
			NodeList taskElements = task.getElementsByTagName(taskName);
			int len = taskElements.getLength();

			// variables used in loop
			Node taskLine = null;
			Node child = null;
			NodeList children = null;

			// was the main node found ?
			if (len == 1) {
				taskLine = taskElements.item(0);

				// get coorspName, requestCode, and status
				this.processTaskAttributes(taskLine);

				// get the child nodes
				children = taskLine.getChildNodes();

				for (int ni2 = 0; ni2 < children.getLength(); ni2++) {
					child = children.item(ni2);
					RequestLine line = new RequestLine(child);

					if (InformRequestFormat.PARAM.equalsIgnoreCase(line.name)) {
						this.formatLine(line, mainObject, "", requestLines);
					} else if (InformRequestFormat.LIST
							.equalsIgnoreCase(line.name)) {
						this.parseList(child, mainObject, requestLines);
					} else if (InformRequestFormat.CORRSP
							.equalsIgnoreCase(line.name)) {
						// this method also handles the coorspName
						this.formatLine(line, mainObject, "", requestLines);

						// save this for external use
						final StringBuffer buf = new StringBuffer(256);
						buf.append(line.label).append(": ").append(
								line.getData(mainObject));
						this.corrspName = buf.toString();
					} else if (!InformRequestFormat.IGNORE_NODE
							.equalsIgnoreCase(line.name)) {
						InformRequestFormat.logger
								.debug("Unrecognized element: " + line.name);
					}
				}
			} else {
				throw new DOMException((short) 0, "requestLines not found ");
			}

			this.formattedOutput = requestLines.toString();

		} catch (FileNotFoundException e) {
			if (InformRequestFormat.logger.isDebugEnabled()) {
				InformRequestFormat.logger.debug("Error opening file "
						+ this.xmlFileName + " = " + e);
			}
			throw e;

		} catch (Exception e) {
			InformRequestFormat.logger.error("Error:", e);
			final StringBuffer buf = new StringBuffer(64);
			buf.append("taskName=").append(taskName).append(": ").append(
					e.getMessage());
			throw new DOMException((short) 0, buf.toString());
		}
	}

	/**
	 * Formats a single line of output.
	 * 
	 * @param line
	 *            Definition from XML
	 * @param dataObj
	 *            Object with data required by XML
	 * @param prefix
	 *            String (for output only)
	 * @param buffer
	 *            Ouput buffer
	 */
	private void formatLine(RequestLine line, Object dataObj, String prefix,
			StringBuffer buffer) {

		buffer.append(prefix).append(line.label);

		if (!(line.label.trim().equals(""))) {
			buffer.append(": ");
		}

		final Object data = line.getData(dataObj);

		if (data instanceof DateBean) {
			final DateBean dateBean = (DateBean) data;
			buffer.append(dateBean.getMonth()).append('/');
			buffer.append(dateBean.getDay()).append('/');
			buffer.append(dateBean.getYear());
		} else if (data == null) {
			buffer.append("null");
		} else {
			buffer.append(data.toString());
		}
		buffer.append("\n");
	}

	/**
	 * Iterates through the accessors for each entry in a Collection.
	 * 
	 * @param listNode
	 *            Node defining the collection
	 * @param mainObject
	 *            Main data object
	 * @param buffer
	 *            output buffer
	 */
	private void parseList(Node listNode, Object mainObject, StringBuffer buffer) {
		RequestLine listSpec = new RequestLine(listNode);
		ArrayList listObjects = (ArrayList) listSpec.getData(mainObject);

		RequestLine line = null;

		if ((listObjects == null) || (listObjects.size() < 1)) {
			buffer.append(listSpec.label).append("(0) : no ").append(
					listSpec.label).append("s \n");
		} else {
			for (int ai = 0; ai < listObjects.size(); ai++) {
				Object obj = listObjects.get(ai);

				buffer.append(listSpec.label).append("(" + (ai + 1)).append(
						") : \n");
				for (Node n = listNode.getFirstChild(); n != null; n = n
						.getNextSibling()) {
					if (!InformRequestFormat.IGNORE_NODE.equalsIgnoreCase(n
							.getNodeName())) {
						line = new RequestLine(n);
						this.formatLine(line, obj, "  ", buffer);
					}
				}
			}
		}
	}

	/**
	 * check Inform Attribute: requestCode, and status (i.e. closed or open)
	 * 
	 * @param node
	 *            main node for the section(add, chanhe, ...)
	 */
	private void processTaskAttributes(Node node) {

		NamedNodeMap attrs = node.getAttributes();

		// get requestCode
		Node keyNode = attrs.getNamedItem(InformRequestFormat.REQUEST_CODE_KEY);
		if (keyNode != null) {
			this.requestCode = keyNode.getNodeValue();
		}

		// default status to closed
		this.closedInform = true;
		// look for status attribute
		keyNode = node.getAttributes().getNamedItem(
				InformRequestFormat.STATUS_KEY);
		if (keyNode != null) {
			if (InformRequestFormat.logger.isDebugEnabled()) {
				InformRequestFormat.logger.debug(node.getNodeName() + " "
						+ InformRequestFormat.STATUS_KEY + " = "
						+ keyNode.getNodeValue());
			}
			// if status is designated as OPEN, then set flag appropriate
			if (InformRequestFormat.STATUS_OPEN.equalsIgnoreCase(keyNode
					.getNodeValue())) {
				this.closedInform = false;
			}
		}
	}

	/**
	 * Inner class used to process a row in the XML definiton of a set of inform
	 * request lines.
	 * 
	 * @author $author$
	 * @version $Revision:   1.0  $
	 */
	private class RequestLine {

		private static final String NAME = "label";

		private static final String PATH = "value";

		/** The node name. */
		String name;

		/** The value of the value attribute. */
		String value;

		/** The value of the label attribute. */
		String label;

		/**
		 * Creates a new RequestLine object for the given node.
		 * 
		 * @param node
		 *            the node to use.
		 */
		RequestLine(Node node) {
			this.name = node.getNodeName();

			NamedNodeMap attr = node.getAttributes();

			if (attr != null) {
				Node labelNode = attr.getNamedItem(RequestLine.NAME);
				Node dataNode = attr.getNamedItem(RequestLine.PATH);

				if (labelNode != null) {
					this.label = labelNode.getNodeValue();
				}

				if (dataNode != null) {
					this.value = dataNode.getNodeValue();
				}
			}
		}

		/**
		 * Invokes the accessor method on the given object.
		 * 
		 * @param obj
		 *            the target object containing the data.
		 * 
		 * @return the output of the accessor method.
		 */
		Object getData(Object obj) {
			Object returnObject = null;
			JXPathContext beanContext = JXPathContext.newContext(obj);
			if (this.value != null) {
				returnObject = beanContext.getValue(this.value);
			}
			return returnObject;
		}
	}
}
