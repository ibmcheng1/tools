/*
 * @(#)ModifyDependentForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.forms;

import com.bcbssc.groupadmin.shared.dto.Dependent;

import java.util.ArrayList;
import java.util.Collection;

import org.apache.struts.util.LabelValueBean;

/**
 * GroupAdmin Modify Dependent Form
 *
 * This bean extends the DependentForm by providing getResettable methods
 * specific to the modify dependent form.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class ModifyDependentForm extends DependentForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Returns a collection of resettable name/value pairs. @ return Collection
	 * of LabelValueBean objects, each containing the name and value of a
	 * resettable property.
	 *
	 * @return a {@link java.util.Collection} object.
	 */
	public Collection getResettables() {
		ArrayList resettables = new ArrayList();
		return resettables;
	}

	/**
	 * Returns a collection of resettable properties that are referenced by bean @ return
	 * Collection of LabelValueBean objects, each containing the name and value
	 * of a bean-referenced arrayed resettable property.
	 *
	 * @return a {@link java.util.Collection} object.
	 */
	public Collection getBeanResettables() {
		ArrayList resettables = new ArrayList();

		int dependentItemCount = (this.dependents != null) ? this.dependents
				.size() : 0;
		for (int i = 0; i < dependentItemCount; i++) {
			Dependent dependent = this.getDependent(i);

			StringBuffer dependentLabel = new StringBuffer(16);
			dependentLabel.append("dependent[").append(i).append("].");

			StringBuffer propertyName = new StringBuffer(dependentLabel
					.toString());
			propertyName.append("changed");
			resettables.add(new LabelValueBean(propertyName.toString(), String
					.valueOf(false)));

			propertyName = new StringBuffer(dependentLabel.toString());
			propertyName.append("lastName");
			resettables.add(new LabelValueBean(propertyName.toString(), String
					.valueOf(dependent.getLastName())));

			propertyName = new StringBuffer(dependentLabel.toString());
			propertyName.append("givenName");
			resettables.add(new LabelValueBean(propertyName.toString(), String
					.valueOf(dependent.getGivenName())));

			propertyName = new StringBuffer(dependentLabel.toString());
			propertyName.append("middleIni");
			resettables.add(new LabelValueBean(propertyName.toString(), String
					.valueOf(dependent.getMiddleIni())));

			propertyName = new StringBuffer(dependentLabel.toString());
			propertyName.append("dobMonth");
			resettables.add(new LabelValueBean(propertyName.toString(), String
					.valueOf(dependent.getDobMonth())));

			propertyName = new StringBuffer(dependentLabel.toString());
			propertyName.append("dobDay");
			resettables.add(new LabelValueBean(propertyName.toString(), String
					.valueOf(dependent.getDobDay())));

			propertyName = new StringBuffer(dependentLabel.toString());
			propertyName.append("dobYear");
			resettables.add(new LabelValueBean(propertyName.toString(), String
					.valueOf(dependent.getDobYear())));

			propertyName = new StringBuffer(dependentLabel.toString());
			propertyName.append("dobMonth");
			resettables.add(new LabelValueBean(propertyName.toString(), String
					.valueOf(dependent.getDobMonth())));

			propertyName = new StringBuffer(dependentLabel.toString());
			propertyName.append("gender");
			resettables.add(new LabelValueBean(propertyName.toString(), String
					.valueOf(dependent.getGender())));

			propertyName = new StringBuffer(dependentLabel.toString());
			propertyName.append("ssn");
			resettables.add(new LabelValueBean(propertyName.toString(), String
					.valueOf(dependent.getSsn())));

			propertyName = new StringBuffer(dependentLabel.toString());
			propertyName.append("relationship");
			resettables.add(new LabelValueBean(propertyName.toString(), String
					.valueOf(dependent.getRelationship())));

			propertyName = new StringBuffer(dependentLabel.toString());
			propertyName.append("student");
			resettables.add(new LabelValueBean(propertyName.toString(), String
					.valueOf(dependent.getStudent())));
		}

		// <html:hidden name="dependent" property="dateOfBirthFormatted"
		// indexed="true"/>

		return resettables;
	}
}
