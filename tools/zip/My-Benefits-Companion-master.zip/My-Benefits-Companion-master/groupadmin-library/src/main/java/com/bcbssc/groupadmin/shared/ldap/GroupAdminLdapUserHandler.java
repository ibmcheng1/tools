/*
 * @(#)GroupAdminLdapUserHandler.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.ldap;

import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.naming.NamingException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.netsys.Config;
import com.bcbssc.netsys.jndi.LdapUser;
import com.bcbssc.netsys.jndi.MissingPropertyException;
import com.bcbssc.registration.common.Constants;
import com.bcbssc.registration.dto.UserDTO;
import com.bcbssc.registration.tds.impl.AbstractProfileManagementService;

/**
 * Group Administrator User LDAP Handler
 *
 * This class provides LDAP Group Administrator User support for add,
 * authenticate, reauthenticate, change password, modify and populate.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.2  $
 */
public class GroupAdminLdapUserHandler extends AbstractProfileManagementService {

	private static final String USERTYPE = "groupadmin";
	private static final int ADDPROFILE = 1;

	/** The log4j logger for this class. */
	private static Logger logger = Logger
			.getLogger(GroupAdminLdapUserHandler.class);

	/**
	 * Class constructor
	 *
	 * @param iniFile
	 *            INI file containing non LDAP info
	 * @param tdsIniFile a {@link java.lang.String} object.
	 */
	public GroupAdminLdapUserHandler(String iniFile, String tdsIniFile) {
		super(iniFile, tdsIniFile);

	}

	/**
	 * {@inheritDoc}
	 *
	 * Creates a user from LdapUser
	 */
	public UserDTO createUserFromLdapAttributes(LdapUser userAttributes)
			throws MissingPropertyException, NamingException,
			FileNotFoundException {

		GroupAdminUserDTO user = new GroupAdminUserDTO();

		user.setAccessCode((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_ACCESSCODE));
		user.setAddressLine2((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_STREET2));
		user.setChallenge((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_CHALLENGEQUESTION));
		user.setChallengeResponse((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_CHALLENGERESPONSE));
		user.setCity((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_CITY));
		user.setCommonName((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_COMMONNAME));
		user.setCountry((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_COUNTRY));
		user.setDateOfAcceptance((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_DOA));
		user.setDateOfBirth((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_DOB));
		user.setEnabled((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_ENABLED));
		if (StringUtils.isNotBlank((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_FAX))) {
			user.setFax((String) userAttributes
					.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_FAX));
		}
		if (StringUtils
				.isNotBlank((String) userAttributes
						.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_GENERATION_QUALIFIER))) {
			user
					.setSuffix((String) userAttributes
							.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_GENERATION_QUALIFIER));
		}
		
		user.setGivenName((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_GIVENNAME));
		user.setGroupName((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_GROUPNAME));
		user.setGroupNumber((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_GROUPNUMBER));
		user.setHomePhone((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_TELEPHONE));
		user.setTelephoneNumber((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_TELEPHONE));
		user.setLast6SSN((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_SSN));
		user.setLastAccess((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_LASTACCESS));
		user.setLastName((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_SN));
		user.setMail((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_EMAIL));
		user.setMiddleIni((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_MIDDLEINITIAL));
		// user.setOrg((String)userAttributes.getAttribute(Constants.TDS_L
		user.setPostalCode((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_POSTALCODE));
		user.setStreet((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_STREET));
		user.setState((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_STATE));

		user.setTelephoneExt((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_TELEPHONE_EXT));

		user.setSamAccountName((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_UID));

		user.setRoles(this.getRoles((String) userAttributes
				.getAttribute(Constants.TDS_LDAP_ATTRIBUTE_UID)));

		// get 'read only' role value
		String readOnlyRole = Config.getPrivateProfileString(
				com.bcbssc.registration.common.Constants.INI_LOCAL_SECTION,
				Constants.INI_READ_ONLY_ROLE,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);
		// set flag accordingly
		user.setReadOnly((user.getRoles().indexOf(readOnlyRole) >= 0));
		if (GroupAdminLdapUserHandler.logger.isDebugEnabled()) {
			GroupAdminLdapUserHandler.logger.debug(user.getSamAccountName()
					+ " , readOnly = " + user.getReadOnly());
		}

		return user;
	}

	/**
	 * {@inheritDoc}
	 *
	 * Adds a user to a Map attributesMap
	 */
	protected void appendUserToValMap(UserDTO user, Map attributesMap,
			int action) {

		final GroupAdminUserDTO gaUser = (GroupAdminUserDTO) user;
		final String sAMAccountName = gaUser.getSamAccountName();

		// Some of the attributes are updated only during initial profile
		// creation

		if (action == ADDPROFILE) {

			attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_ACCESSCODE, gaUser
					.getAccessCode());
			attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_SSN, gaUser
					.getLast6SSN());
			attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_DOB, gaUser
					.getDateOfBirth());
			attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_COMMONNAME, gaUser
					.getSamAccountName());
			attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_UID, gaUser
					.getSamAccountName());
			attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_DOA, gaUser
					.getDateOfAcceptance());
			attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_GROUPNUMBER, gaUser
					.getGroupNumber());
			attributesMap.put(Constants.LDAP_USERTYPE, USERTYPE);
			attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_WHENCREATED,
					getTimeStamp());

		}

		// The rest of the attributes can be changed with modify profile

		attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_WHENCHANGED,
				getTimeStamp());
		attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_GIVENNAME, gaUser
				.getGivenName());

		if (StringUtils.isNotBlank(gaUser.getMiddleIni())) {
			attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_MIDDLEINITIAL,
					gaUser.getMiddleIni());
		}

		attributesMap
				.put(Constants.TDS_LDAP_ATTRIBUTE_SN, gaUser.getLastName());

		attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_CITY, gaUser.getCity());

		attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_POSTALCODE, gaUser
				.getPostalCode());
		attributesMap
				.put(Constants.TDS_LDAP_ATTRIBUTE_STATE, gaUser.getState());
		attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_STREET, gaUser
				.getStreet());
		
		if (StringUtils.isNotBlank(gaUser.getAddressLine2())) {
			attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_STREET2, gaUser
				.getAddressLine2());
		}
		
		attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_EMAIL, gaUser.getMail());
		attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_TELEPHONE, gaUser
				.getTelephoneNumber());

		if (StringUtils.isNotBlank(gaUser.getTelephoneExt())) {
			attributesMap
					.put(
							com.bcbssc.registration.common.Constants.TDS_LDAP_ATTRIBUTE_TELEPHONE_EXT,
							gaUser.getTelephoneExt());
		}

		if (StringUtils.isNotBlank(gaUser.getSuffix())) {
			attributesMap
					.put(
							com.bcbssc.registration.common.Constants.TDS_LDAP_ATTRIBUTE_GENERATION_QUALIFIER,
							gaUser.getSuffix());
		}

		if (StringUtils.isNotBlank(gaUser.getFax())) {
			attributesMap
					.put(Constants.TDS_LDAP_ATTRIBUTE_FAX, gaUser.getFax());
		}

		attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_CHALLENGERESPONSE,
				gaUser.getChallengeResponse());

		attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_CHALLENGEQUESTION,
				gaUser.getChallenge());
		attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_GROUPNAME, gaUser
				.getGroupName());

		attributesMap.put(Constants.TDS_LDAP_ATTRIBUTE_COUNTRY, gaUser
				.getCountry());
		
	}

	private String getTimeStamp() {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
		return formatter.format(date) + ".0Z";
	}

}
