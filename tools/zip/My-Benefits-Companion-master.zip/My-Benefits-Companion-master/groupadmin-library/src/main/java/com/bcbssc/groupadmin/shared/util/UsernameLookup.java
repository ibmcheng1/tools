/**
 * 
 */
package com.bcbssc.groupadmin.shared.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.bcbssc.groupadmin.shared.dbaccess.AbstractDBSearch;
import com.bcbssc.netsys.Config;

/**
 *Please note, this class was ported over from MIM 1.0.
 * In times of hardship, the jar is (hopefully) here: U:\Unit1\MyInsuranceManagerStnd\commercial-library.jar
 *
 * @author mf36
 * @version $Id: $Id
 */
public class UsernameLookup extends AbstractDBSearch {
	private static final Logger log = Logger.getLogger(UsernameLookup.class);
	private String _iniFile = null;
	private final static String PURGE_TABLE = "LDAP_PURGE";

	/**
	 * <p>Constructor for UsernameLookup.</p>
	 *
	 * @param iniFile a {@link java.lang.String} object.
	 */
	public UsernameLookup(String iniFile) {
		super(iniFile, PURGE_TABLE);
		this._iniFile = iniFile;
		if (log.isDebugEnabled()) {
			log.debug("Created UsernameLookup object.");
		}
	}

	/**
	 * <p>isNameFound.</p>
	 *
	 * @param userName a {@link java.lang.String} object.
	 * @return a boolean.
	 */
	public boolean isNameFound(String userName) {
		ResultSet resultSet = null;
		String sql = "";
		boolean nameFound = false;
		try {
			checkInit();
			try {
				sql = getSqlQuery(userName);
				resultSet = getResultSet(sql);
				if (resultSet.next()) {
					nameFound = true;
				} else {
					nameFound = false;
				}
			} catch (SQLException se) {
				String sqlError = se.toString();
				log.error(" Statement execution created an error " + sqlError);
			} finally {
				cleanUp(resultSet);
				resultSet = null;
			}
		} catch (SQLException e) {
			String sqlError = e.toString();
			log.error(" Problem connecting to the database  " + sqlError);
		} finally {
			disconnect();
		}
		return nameFound;
	}

	private String getSqlQuery(String userName) {
		String tempUserName = userName;
		StringBuffer sb = new StringBuffer();
		tempUserName = tempUserName.toUpperCase();
		String getSchema = Config.getPrivateProfileString("SQL",
				"LDAP_PURGE_ODBC_QUALIFIER", "", this._iniFile);

		sb.append(" SELECT 1");
		sb.append(" FROM " + getSchema + "." + UsernameLookup.PURGE_TABLE);
		sb.append(" WHERE USER_NAME = '" + tempUserName + "'");
		sb.append(" FETCH FIRST 1 ROW ONLY WITH UR");
		log.debug(" The SQL to be executed for checking the purge table is :"
				+ sb.toString());

		return sb.toString();
	}

	/** {@inheritDoc} */
	@Override
	protected void addSearchItem(ResultSet data, Object obj)
			throws SQLException {
		
		
	}

}
