/**
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.groupadmin.shared.dto;

/**
 * This bean represents a bank account information for a group.
 */
public class BankInformationDTO extends InsuredDataDTO {

	/** status of the bank account, invalid(9) or valid (not 9) */
	private String bankStatus;

	/** name of the bank */
	private String bankName;

	/** bank routing number */
	private String bankRoutingNumber;

	/** bank account number */
	private String bankAccountNumber;

	/** account holder's name */
	private String accountHolderName;

	/**
	 * holds the account activity mode whether we are updating bank account
	 * information or inserting a new bank information
	 */
	private String activityCode;

	/**
	 * holds the tracking number when CGA sends bank or payment information to
	 * MQ and Inform.
	 */
	private String trackingNumber;

	/** holds the bank info or payment entry date */
	private String entryDate;

	/** holds the bank info or payment entry time */
	private String entryTime;

	/**
	 * holds the amount paid by the CGA out of total balance due. He can pay
	 * whole of total balance due or part of it.
	 */
	private String totalBalanceDue;

	/** This will hold the value for paid balance amount for inform. */
	private String paidBalanceforInform;

	/** Holds the inform status, true[closed] or false[open] */
	private boolean closedInform;

	/**
	 * Holds value of userDTO.
	 */
	private GroupAdminUserDTO userDTO;

	/**
	 * Setter for userDTO
	 *
	 * @param userDTO
	 *            New value of property userDTO.
	 */
	public void setUserDTO(GroupAdminUserDTO userDTO) {
		this.userDTO = userDTO;
	}

	/**
	 * Getter for userDTO
	 *
	 * @return a {@link com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO} object.
	 */
	public GroupAdminUserDTO getUserDTO() {
		return this.userDTO;
	}

	/**
	 * <p>Getter for the field <code>activityCode</code>.</p>
	 *
	 * @return Returns the activityCode.
	 */
	public String getActivityCode() {
		return this.activityCode;
	}

	/**
	 * <p>Setter for the field <code>activityCode</code>.</p>
	 *
	 * @param activityCode
	 *            The activityCode to set.
	 */
	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}

	/**
	 * <p>Getter for the field <code>accountHolderName</code>.</p>
	 *
	 * @return accountHolderName
	 */
	public String getAccountHolderName() {
		return this.accountHolderName;
	}

	/**
	 * <p>Setter for the field <code>accountHolderName</code>.</p>
	 *
	 * @param accountHolderName a {@link java.lang.String} object.
	 */
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	/**
	 * <p>Getter for the field <code>bankAccountNumber</code>.</p>
	 *
	 * @return bankAccountNumber
	 */
	public String getBankAccountNumber() {
		return this.bankAccountNumber;
	}

	/**
	 * <p>Setter for the field <code>bankAccountNumber</code>.</p>
	 *
	 * @param bankAccountNumber a {@link java.lang.String} object.
	 */
	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	/**
	 * <p>Getter for the field <code>bankName</code>.</p>
	 *
	 * @return bankName
	 */
	public String getBankName() {
		return this.bankName;
	}

	/**
	 * <p>Setter for the field <code>bankName</code>.</p>
	 *
	 * @param bankName a {@link java.lang.String} object.
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * <p>Getter for the field <code>bankRoutingNumber</code>.</p>
	 *
	 * @return bankRoutingNumber
	 */
	public String getBankRoutingNumber() {
		return this.bankRoutingNumber;
	}

	/**
	 * <p>Setter for the field <code>bankRoutingNumber</code>.</p>
	 *
	 * @param bankRoutingNumber a {@link java.lang.String} object.
	 */
	public void setBankRoutingNumber(String bankRoutingNumber) {
		this.bankRoutingNumber = bankRoutingNumber;
	}

	/**
	 * <p>Getter for the field <code>bankStatus</code>.</p>
	 *
	 * @return bankStatus
	 */
	public String getBankStatus() {
		return this.bankStatus;
	}

	/**
	 * <p>Setter for the field <code>bankStatus</code>.</p>
	 *
	 * @param bankStatus a {@link java.lang.String} object.
	 */
	public void setBankStatus(String bankStatus) {
		this.bankStatus = bankStatus;
	}

	/**
	 * <p>Getter for the field <code>trackingNumber</code>.</p>
	 *
	 * @return Returns the trackingNumber.
	 */
	public String getTrackingNumber() {
		return this.trackingNumber;
	}

	/**
	 * <p>Setter for the field <code>trackingNumber</code>.</p>
	 *
	 * @param trackingNumber
	 *            The trackingNumber to set.
	 */
	public void setTrackingNumber(String trackingNumber) {
		this.trackingNumber = trackingNumber;
	}

	/**
	 * <p>Getter for the field <code>entryDate</code>.</p>
	 *
	 * @return Returns the entryDate.
	 */
	public String getEntryDate() {
		return this.entryDate;
	}

	/**
	 * <p>Setter for the field <code>entryDate</code>.</p>
	 *
	 * @param entryDate
	 *            The entryDate to set.
	 */
	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}

	/**
	 * <p>Getter for the field <code>entryTime</code>.</p>
	 *
	 * @return Returns the entryTime.
	 */
	public String getEntryTime() {
		return this.entryTime;
	}

	/**
	 * <p>Setter for the field <code>entryTime</code>.</p>
	 *
	 * @param entryTime
	 *            The entryTime to set.
	 */
	public void setEntryTime(String entryTime) {
		this.entryTime = entryTime;
	}

	/**
	 * <p>Getter for the field <code>totalBalanceDue</code>.</p>
	 *
	 * @return Returns the totalBalanceDue.
	 */
	public String getTotalBalanceDue() {
		return this.totalBalanceDue;
	}

	/**
	 * <p>Setter for the field <code>totalBalanceDue</code>.</p>
	 *
	 * @param totalBalanceDue
	 *            The totalBalanceDue to set.
	 */
	public void setTotalBalanceDue(String totalBalanceDue) {
		this.totalBalanceDue = totalBalanceDue;
	}

	/**
	 * <p>Getter for the field <code>paidBalanceforInform</code>.</p>
	 *
	 * @return Returns the paidBalanceforInform.
	 */
	public String getPaidBalanceforInform() {
		return this.paidBalanceforInform;
	}

	/**
	 * <p>Setter for the field <code>paidBalanceforInform</code>.</p>
	 *
	 * @param paidBalanceforInform
	 *            The paidBalanceforInform to set.
	 */
	public void setPaidBalanceforInform(String paidBalanceforInform) {
		this.paidBalanceforInform = paidBalanceforInform;
	}

	/**
	 * <p>isClosedInform.</p>
	 *
	 * @return Returns the closedInform.
	 */
	public boolean isClosedInform() {
		return this.closedInform;
	}

	/**
	 * <p>Setter for the field <code>closedInform</code>.</p>
	 *
	 * @param closedInform
	 *            The closedInform to set.
	 */
	public void setClosedInform(boolean closedInform) {
		this.closedInform = closedInform;
	}

}
