/*
 * @(#)GroupAdminLogonAction.java
 *
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.actions;

import com.bcbssc.struts.action.BaseAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * CLife Reset Password Action
 *
 * This class provides control processing to forward the user to the welcomepage
 *
 * @author Surendra Poranki
 * @version $Revision:   1.0  $
 */
public class GroupAdminLogonAction extends BaseAction {

	/** log4j logger */
	private static final Logger log = Logger
			.getLogger(GroupAdminLogonAction.class.getName());

	/**
	 * Processes the specified HTTP request, and create sthe corresponding HTTP
	 * response.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		GroupAdminLogonAction.log.debug("Inside the GroupAdminLogonAction");

		String forwardname;
		forwardname = com.bcbssc.registration.common.Constants.FORWARD_WELCOME;
		GroupAdminLogonAction.log.debug("Forward name:" + forwardname);
		return mapping.findForward(forwardname);
	}
}
