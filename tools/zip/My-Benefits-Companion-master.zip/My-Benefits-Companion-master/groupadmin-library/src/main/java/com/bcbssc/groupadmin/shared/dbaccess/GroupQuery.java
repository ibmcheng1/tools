/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/GroupQuery.java_v  $
 * $Workfile:   GroupQuery.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:18  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/GroupQuery.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:14:18   EN80
 * Initial revision.
 * 
 *    Rev 1.23   Apr 28 2009 10:18:04   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.22   Apr 12 2005 09:04:36   rxr93
 * add last bill due date
 * 
 *    Rev 1.21   Apr 05 2005 15:58:42   rxr93
 * process all rows for an accesscode 
 * (it was only handling the 1st row returned)
 * 
 *    Rev 1.20   Mar 09 2005 10:05:06   rdq70
 * Fixed a runtime bug.
 *
 *    Rev 1.19   Feb 18 2005 12:23:54   rdq70
 * Added Original Effective Date.
 *
 *    Rev 1.18   Feb 18 2005 10:33:10   rdq70
 * Replaced new INI parameter with one that already existed.
 *
 *    Rev 1.17   Feb 17 2005 10:30:20   rdq70
 * Externalized Application ID.
 *
 *    Rev 1.16   Feb 09 2005 11:35:18   rdq70
 * Added last-billed-to-date to dropdown value.
 *
 *    Rev 1.15   Feb 09 2005 10:39:36   rxg97
 * Added name to group value.
 *
 *    Rev 1.14   Feb 08 2005 16:29:04   rdq70
 * Read result set forward only.
 *
 *    Rev 1.13   Feb 08 2005 10:56:30   rdq70
 * Incorporated SQL revisions.
 *
 *    Rev 1.12   Feb 03 2005 13:30:24   rdq70
 * Javadoc correction.
 *
 *    Rev 1.11   Feb 03 2005 10:49:52   rdq70
 * Renamed MQ_TABLE to GCOM_TABLE.
 *
 *    Rev 1.10   Feb 02 2005 09:37:36   rdq70
 * Revised Javadocs based on provided SQL descriptions.
 *
 *    Rev 1.9   Jan 31 2005 16:15:24   rdq70
 * Added a search by access ID.
 *
 *    Rev 1.8   Jan 31 2005 14:48:34   rdq70
 * Removed a debug log.
 *
 *    Rev 1.7   Jan 31 2005 14:45:32   rdq70
 * Changed SQL to use a group number range.
 *
 *    Rev 1.6   Jan 27 2005 12:51:56   rdq70
 * Corrected qualifier.
 *
 *    Rev 1.5   Jan 26 2005 17:43:04   rdq70
 * Removed unused imports.
 *
 *    Rev 1.4   Jan 26 2005 11:35:04   rdq70
 * Corrected text and value of label bean.
 *
 *    Rev 1.3   Jan 26 2005 11:24:56   rdq70
 * Changed query from being based on group ID to access (LDAP) ID.
 *
 *    Rev 1.2   Jan 26 2005 10:03:16   rdq70
 * BlueHammur changes.
 *
 *    Rev 1.1   Jan 25 2005 16:51:30   rdq70
 * Removed unused code and Javadocs.
 *
 *    Rev 1.0   Jan 25 2005 16:02:32   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.dbaccess;

import com.bcbssc.netsys.Config;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.apache.struts.util.LabelValueBean;

/**
 * This query creates for the dropdown box a list of groups the group
 * administrator has authority to update.<br>
 *
 * <pre>
 *     QMF NAME: RX13U.WEB_SQL_2
 *     TSO NAME: WEBSQL2
 * </pre>
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class GroupQuery extends AbstractDBSearch {

	/** The log4j logger for this class. */
	private static final Logger log = Logger.getLogger(GroupQuery.class);

	/** The 10-byte application ID in Rules. */
	private final String applicationId;

	/** <code>true</code>if currently searching by group. */
	private boolean byGroupSearch;

	/**
	 * Creates a <code>GroupQuery</code> and configures it with an INI file.
	 *
	 * @param iniFile
	 *            file path of the configuration INI file.
	 */
	public GroupQuery(String iniFile) {
		super(iniFile, "GCOM_TABLE");

		this.applicationId = Config.getPrivateProfileString("MISC", "APP_ID",
				com.bcbssc.struts.common.Constants.BLANK_STRING, iniFile);

		if (GroupQuery.log.isDebugEnabled()) {
			GroupQuery.log.debug("applicationId=" + this.applicationId);
		}
	}

	/**
	 * Searches for group options based on the given accessId.
	 *
	 * @param accessId
	 *            the LDAP ID for the search.
	 * @return a collection populated with the search results.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 */
	public Collection performSearch(String accessId) throws SQLException {
		this.byGroupSearch = false;

		// The Rules table uses a different qualifier
		String backupQual = this.qualParam;
		this.qualParam = "RULES_TABLE";

		// there may be multiple ranges, so we need an aggregate collection
		Collection totalGroups = new ArrayList();

		final String qualifier = Config.getPrivateProfileString("SQL",
				this.qualParam,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);

		final String date = this.dbFormat.format(new Date());
		final StringBuffer sql = new StringBuffer(275);

		sql.append("SELECT GROUP_NBR_FROM, GROUP_NBR_TO FROM ");
		sql.append(qualifier).append(".DT_TYP_WEB_GROUPS");
		sql
				.append(" WHERE RP_NO = '001' AND PLAN_CD = '885' AND DATA_TYP = 'WEBGROUP'");
		sql.append(" AND ACCESS_CD = ? AND APPLICATION_ID = ?");
		sql
				.append(" AND SYS_VOID_STS_IND = 'N' AND DT_TYP_BEG <= ? AND DT_TYP_TRM >= ?");

		final String[] params = { accessId, this.applicationId, date, date };

		// Read the rules table
		Collection results = this.performSearch(sql.toString(), params);
		this.qualParam = backupQual;
		this.initialized = false;

		final Iterator iterator = results.iterator();

		while (iterator.hasNext()) {
			String fromGroup = (String) iterator.next();

			if (iterator.hasNext()) {
				String toGroup = (String) iterator.next();

				// Read the group table with the rules results
				if ((toGroup.length() == 0) || fromGroup.equals(toGroup)) {
					results = this.performSearchByGroup(fromGroup);
				} else {
					results = this.performSearchByGroup(fromGroup, toGroup);
				}
				totalGroups.addAll(results);
			}
		}
		return totalGroups;
	}

	/**
	 * Creates for the dropdown box a list of groups the group administrator has
	 * authority to update.<br>
	 *
	 * <pre>
	 *     QMF NAME: RX13U.WEB_SQL_2
	 *     TSO NAME: WEBSQL2
	 * </pre>
	 *
	 * @param groupNo
	 *            the group number for the search. Can be 3, 10 or 13
	 *            characters.
	 * @return a collection populated with the search results.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 */
	public Collection performSearchByGroup(String groupNo) throws SQLException {
		if ((groupNo == null)
				|| ((groupNo.length() != 3) && (groupNo.length() != 10) && (groupNo
						.length() != 13))) {

			throw new IllegalArgumentException(
					"fromGroup must be 3, 10 or 13 characters");
		}

		this.checkInit(); // Necessary since we need the _dbSchema before the
							// query creation
		this.byGroupSearch = true;

		final String[] params;

		if (groupNo.length() == 3) {
			params = new String[] { groupNo.substring(0, 3) };
		} else if (groupNo.length() == 10) {
			params = new String[] { groupNo.substring(0, 3),
					groupNo.substring(3, 5), groupNo.substring(5, 10) };
		} else {
			params = new String[] { groupNo.substring(0, 3),
					groupNo.substring(3, 5), groupNo.substring(5, 10),
					groupNo.substring(10) };
		}

		return this.performSearch(this.getGroupSql(groupNo, null), params);
	}

	/**
	 * Creates for the dropdown box a list of groups the group administrator has
	 * authority to update.<br>
	 *
	 * <pre>
	 *     QMF NAME: RX13U.WEB_SQL_2
	 *     TSO NAME: WEBSQL2
	 * </pre>
	 *
	 * @param fromGroup
	 *            the beginning of the search range. Must be 13 characters.
	 * @param toGroup
	 *            the end of the search range. Must be 13 characters and the
	 *            first 10 must match that of <code>fromGroup</code>.
	 * @return a collection populated with the search results.
	 * @throws java.lang.IllegalArgumentException
	 *             if the arguments do not meet the requirements.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 */
	public Collection performSearchByGroup(String fromGroup, String toGroup)
			throws SQLException {
		if ((fromGroup == null) || (fromGroup.length() < 13)) {
			throw new IllegalArgumentException(
					"fromGroup must be 13 characters");
		}

		if ((toGroup == null) || (toGroup.length() < 13)
				|| !fromGroup.substring(0, 10).equals(toGroup.substring(0, 10))) {

			throw new IllegalArgumentException(
					"toGroup must be 13 characters and the first 10 must match that of fromGroup");
		}

		this.checkInit(); // Necessary since we need the _dbSchema before the
							// query creation
		this.byGroupSearch = true;

		final String[] params = { fromGroup.substring(0, 3),
				fromGroup.substring(3, 5), fromGroup.substring(5, 10),
				fromGroup.substring(10), toGroup.substring(10) };

		return this.performSearch(this.getGroupSql(fromGroup, toGroup), params);
	}

	/**
	 * {@inheritDoc}
	 *
	 * Adds data from the given result set to the target collection.
	 */
	protected void addSearchItem(ResultSet data, Object obj)
			throws SQLException {
		final Collection collection = (Collection) obj;

		if (this.byGroupSearch) {
			final StringBuffer text = new StringBuffer(64);
			final StringBuffer value = new StringBuffer();
			final String compCode = data.getString("COMP_CD").trim();
			final String grpPrfx = data.getString("GRP_PRFX").trim();
			final String grpBase = data.getString("GRP_BASE").trim();
			final String divCode = data.getString("DIV_CODE").trim();
			final String name = data.getString("NAME").trim();

			text.append(compCode).append(' ');
			text.append(grpPrfx).append(' ');
			text.append(grpBase).append(' ');
			text.append(divCode).append(' ');
			text.append(name);

			value.append(compCode);
			value.append(grpPrfx);
			value.append(grpBase);
			value.append(divCode);
			value.append('|').append(name);
			value.append('|').append(data.getString("LST BILLD TO DT"));
			value.append('|').append(data.getString("DIV EFF DT"));
			value.append('|').append(data.getString("BILL DUE DATE"));

			collection
					.add(new LabelValueBean(text.toString(), value.toString()));
		} else {
			collection.add(data.getString("GROUP_NBR_FROM").trim());
			collection.add(data.getString("GROUP_NBR_TO").trim());
		}
	}

	/**
	 * Returns the SQL for search-by-group.
	 * 
	 * @param fromGroup
	 *            the beginning of the search range.
	 * @param toGroup
	 *            the end of the search range.
	 * 
	 * @return the SQL for this search.
	 */
	private String getGroupSql(String fromGroup, String toGroup) {
		final StringBuffer sql = new StringBuffer(1500);

		sql
				.append(
						"SELECT A.COMP_CD"
								+ "    , A.GRP_PRFX"
								+ "    , A.GRP_BASE"
								+ "    , C.DIV_CODE"
								+ "    , VARCHAR(RTRIM(B.LAST_NAME) CONCAT"
								+ "              RTRIM(B.FRST_NAME) CONCAT"
								+ "              B.MID_NAME) \"NAME\""
								+ "    , CHAR(D.LAST_BILL_DUE_DATE,USA) \"BILL DUE DATE\""
								+ "    , CHAR(D.LAST_BILLED_TO_DTE,USA) \"LST BILLD TO DT\""
								+ "    , CHAR(C.ORIG_EFF_DATE,USA) \"DIV EFF DT\""
								+ " FROM ").append(this._dbSchema).append(
						".VPLCYGRZ A" + "    , ").append(this._dbSchema)
				.append(".VPLCYNMZ B" + "    , ").append(this._dbSchema)
				.append(".VPLCYDVZ C" + "    , ").append(this._dbSchema)
				.append(".VBILLDTZ D");

		sql.append(this.getWhereClause(fromGroup, toGroup));

		sql.append(" GROUP BY A.COMP_CD" + "   , A.GRP_PRFX"
				+ "   , A.GRP_BASE" + "   , C.DIV_CODE" + "   , B.LAST_NAME"
				+ "   , B.FRST_NAME" + "   , B.MID_NAME"
				+ "   , D.LAST_BILL_DUE_DATE" + "   , D.LAST_BILLED_TO_DTE"
				+ "   , C.ORIG_EFF_DATE");

		return sql.toString();
	}

	/**
	 * Returns the where clause of the search-by-group SQL.
	 * 
	 * @param fromGroup
	 *            the beginning of the search range.
	 * @param toGroup
	 *            the end of the search range.
	 * 
	 * @return the where clause of the SQL for this search.
	 */
	private String getWhereClause(String fromGroup, String toGroup) {
		final String retVal;

		if (toGroup != null) {
			retVal = " WHERE A.COMP_CD = ?" + "   AND A.COMP_CD = B.COMP_CD"
					+ "   AND B.COMP_CD = C.COMP_CD"
					+ "   AND C.COMP_CD = D.COMPANY_CODE"
					+ "   AND A.GRP_PRFX = ?"
					+ "   AND A.GRP_PRFX = B.GRP_PRFX"
					+ "   AND B.GRP_PRFX = C.GRP_PRFX"
					+ "   AND C.GRP_PRFX = D.GROUP_PREFIX"
					+ "   AND A.GRP_BASE = ?"
					+ "   AND A.GRP_BASE = B.GRP_BASE"
					+ "   AND B.GRP_BASE = C.GRP_BASE"
					+ "   AND C.GRP_BASE = D.GROUP_NUMBER"
					+ "   AND C.DIV_CODE >= ?" + "   AND C.DIV_CODE <= ?"
					+ "   AND C.DIV_CODE = B.DIV_CODE"
					+ "   AND C.DIV_CODE = D.DIVISION_ID"
					+ "   AND A.GRP_STAT = '1'" + "   AND C.DIV_STAT = '1'";
		} else if (fromGroup.length() == 3) {
			retVal = " WHERE A.COMP_CD = ?" + "   AND A.COMP_CD = B.COMP_CD"
					+ "   AND B.COMP_CD = C.COMP_CD"
					+ "   AND C.COMP_CD = D.COMPANY_CODE"
					+ "   AND A.GRP_PRFX = B.GRP_PRFX"
					+ "   AND B.GRP_PRFX = C.GRP_PRFX"
					+ "   AND C.GRP_PRFX = D.GROUP_PREFIX"
					+ "   AND A.GRP_BASE = B.GRP_BASE"
					+ "   AND B.GRP_BASE = C.GRP_BASE"
					+ "   AND C.GRP_BASE = D.GROUP_NUMBER"
					+ "   AND A.GRP_STAT = '1'" + "   AND C.DIV_STAT = '1'"
					+ "   AND B.DIV_CODE = C.DIV_CODE"
					+ "   AND C.DIV_CODE = D.DIVISION_ID";
		} else if (fromGroup.length() == 10) {
			retVal = " WHERE A.COMP_CD = ?" + "   AND A.COMP_CD = B.COMP_CD"
					+ "   AND B.COMP_CD = C.COMP_CD"
					+ "   AND C.COMP_CD = D.COMPANY_CODE"
					+ "   AND A.GRP_PRFX = ?"
					+ "   AND A.GRP_PRFX = B.GRP_PRFX"
					+ "   AND B.GRP_PRFX = C.GRP_PRFX"
					+ "   AND C.GRP_PRFX = D.GROUP_PREFIX"
					+ "   AND A.GRP_BASE = ?"
					+ "   AND A.GRP_BASE = B.GRP_BASE"
					+ "   AND B.GRP_BASE = C.GRP_BASE"
					+ "   AND C.GRP_BASE = D.GROUP_NUMBER"
					+ "   AND A.GRP_STAT = '1'" + "   AND C.DIV_STAT = '1'"
					+ "   AND B.DIV_CODE = C.DIV_CODE"
					+ "   AND C.DIV_CODE = D.DIVISION_ID";
		} else { // length 13
			retVal = " WHERE A.COMP_CD = ?" + "   AND A.COMP_CD = B.COMP_CD"
					+ "   AND B.COMP_CD = C.COMP_CD"
					+ "   AND C.COMP_CD = D.COMPANY_CODE"
					+ "   AND A.GRP_PRFX = ?"
					+ "   AND A.GRP_PRFX = B.GRP_PRFX"
					+ "   AND B.GRP_PRFX = C.GRP_PRFX"
					+ "   AND C.GRP_PRFX = D.GROUP_PREFIX"
					+ "   AND A.GRP_BASE = ?"
					+ "   AND A.GRP_BASE = B.GRP_BASE"
					+ "   AND B.GRP_BASE = C.GRP_BASE"
					+ "   AND C.GRP_BASE = D.GROUP_NUMBER"
					+ "   AND B.DIV_CODE = ?"
					+ "   AND B.DIV_CODE = C.DIV_CODE"
					+ "   AND C.DIV_CODE = D.DIVISION_ID"
					+ "   AND A.GRP_STAT = '1'" + "   AND C.DIV_STAT = '1'";
		}

		return retVal;
	}
}
