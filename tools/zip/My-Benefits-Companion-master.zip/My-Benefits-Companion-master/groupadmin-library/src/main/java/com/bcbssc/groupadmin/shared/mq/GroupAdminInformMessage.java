/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2003 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * GroupAdminInformMessage.java
 *
 * Created on September 7, 2004, 10:35 AM
 *
 */

package com.bcbssc.groupadmin.shared.mq;

/**
 * Encapsulates an INFOrm message for a Group Administrator User Update.
 */
public class GroupAdminInformMessage extends
		com.bcbssc.netsys.inform.AbstractInformMessage {

	private static final String FILE_INFORM = "GroupAdminUserUpdateInforms.xml";

	private static final String MAPPER_KEY = "GroupAdminUserUpdateInforms";

	private static final String TASK_PREFIX = "GroupAdminUserUpdate.";

	private String applicationName = "GroupAdminUserUpdate";

	/**
	 * Creates a new instance of GroupAdminInformMessage
	 */
	public GroupAdminInformMessage() {
		super();
	}

	/**
	 * Convenience constructor for setting the application upon instantiation.
	 *
	 * @param applicationName
	 *            The name of the application submitting the INFOrm
	 */
	public GroupAdminInformMessage(String applicationName) {
		super();
		this.setApplicationName(applicationName);
	}

	/**
	 * Gets the application name for the INFOrm message. Used by
	 * {@link com.bcbssc.netsys.inform.AbstractInformMessage} to get the proper Mapper instance.
	 *
	 * @return The application name for the current instance.
	 */
	public String getApplicationName() {
		return this.applicationName;
	}

	/**
	 * Gets the application name for the INFOrm message. Used by
	 * {@link com.bcbssc.netsys.inform.AbstractInformMessage} to get the proper Mapper instance.
	 *
	 * @param value
	 *            The application name for the current instance.
	 */
	public void setApplicationName(String value) {
		this.applicationName = value;
	}

	/**
	 * Gets the file path of the mappings file used to map INFOrm data.
	 *
	 * @return The file path used for mapping INFOrm data.
	 */
	public String getInformMapFile() {
		return GroupAdminInformMessage.FILE_INFORM;
	}

	/**
	 * Gets the key name for the INFOrm message.
	 *
	 * @return The key name for the INFOrm message.
	 */
	public String getMapperKey() {
		return GroupAdminInformMessage.MAPPER_KEY;
	}

	/**
	 * Gets the task prefix for the INFOrm message.
	 *
	 * @return The task prefix for the INFOrm message.
	 */
	public String getTaskPrefix() {
		return GroupAdminInformMessage.TASK_PREFIX;
	}

}
