/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/tags/LastUpdateDateTag.java_v  $
 * $Workfile:   LastUpdateDateTag.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:16:42  $
 * $Modtime:   Jun 17 2009 12:50:06  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/tags/LastUpdateDateTag.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:16:42   EN80
 * Initial revision.
 * 
 *    Rev 1.4   Apr 28 2009 10:20:58   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.3   Feb 22 2005 09:14:34   rdq70
 * Revised exception handling.
 *
 *    Rev 1.2   Feb 22 2005 09:03:14   rdq70
 * Corrected Javadocs.
 *
 *    Rev 1.1   Feb 22 2005 08:59:40   rdq70
 * First complete version.
 *
 *    Rev 1.0   Feb 21 2005 17:57:14   rdq70
 * Initial revision.
 */

package com.bcbssc.groupadmin.shared.tags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;
import org.apache.struts.taglib.TagUtils;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.dbaccess.LastUpdateQuery;
import com.bcbssc.struts.common.DateBean;

/**
 * Reads the Last Update Date from the database.
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class LastUpdateDateTag extends TagSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6133904501293214397L;

	/** log4j logger */
	private static final Logger log = Logger.getLogger(LastUpdateDateTag.class
			.getName());

	/**
	 * Generates the Last Update Date by reading the database.
	 *
	 * @return page body evaluation specifier.
	 * @throws javax.servlet.jsp.JspException if any.
	 */
	public int doStartTag() throws JspException {
		final StringBuffer message = new StringBuffer(128);

		try {
			final String iniFile = CommonUtils.getIniFile(this.pageContext
					.getServletContext());
			final DateBean date = new LastUpdateQuery(iniFile).performSearch();
			message.append(date.getMonth()).append('/').append(date.getDay())
					.append('/').append(date.getYear());
		} catch (Exception e) {
			LastUpdateDateTag.log.error(
					"Error reading last update date from database", e);
			message.append(
					"<!-- Error reading last update date from database: ")
					.append(e.getMessage()).append("-->");
		}

		// Print the retrieved message to our output writer
		TagUtils.getInstance().write(this.pageContext, message.toString());

		// Continue processing this page
		return Tag.SKIP_BODY;
	}
}
