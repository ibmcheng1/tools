/*
 * @(#)StrictlyOrderedArrayList.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.dto;

import java.util.ArrayList;

/**
 * GroupAdmin Coverage Item List
 *
 * This class represents a strictly ordered list of coverage items.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public abstract class StrictlyOrderedArrayList extends ArrayList {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Creates a blank object of the correct class for the specific list.
	 *
	 * @return a new blank object
	 */
	protected abstract Object createArrayObject();
    
    /**
     * Default constructor
     */
    public StrictlyOrderedArrayList() {
        super();
    }
    
    /**
     * Constructor that sets the list contents to that of another list
     *
     * @param list list whose contents will be copied to this object
     */
    public StrictlyOrderedArrayList(ArrayList list) {
        super();
        if (list != null) {
            addAll(list);
        }
    }
    
    /**
     * {@inheritDoc}
     *
     * Gets an item from the ArrayList, creating intermediate objects if needed
     */
    public Object get(int index) {
        Object item = null;

        if (index < this.size()) {
            item = super.get(index);
        }

        // If the item doesn't yet exist, create it and add it to the list
        if (item == null) {
            item = createArrayObject();
            add(index, item);
        }

        return item;
    }

    /**
     * {@inheritDoc}
     *
     * Adds an item at the specifed index of the list,
     * creating the list and creating placeholders for other items prior to the
     * specified index if necessary.
     */
    public void add(int index, Object newItem) {
        if (index < this.size()) {
            this.set(index, newItem);
        } else if (index == this.size()) {
            this.add(newItem);
        } else {
            // Items are not necessary added in the correct order.  If the index
            // exceeds the list size, create placeholders for the
            // as-yet-unset items.
            for (int i = this.size(); i < index; i++) {
                this.add(null);
            }
            this.add(newItem);
        }
    }    
}
