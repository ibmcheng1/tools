/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mapper/BeanMapper.java_v  $
 * $Workfile:   BeanMapper.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:15:50  $
 * $Modtime:   May 14 2009 11:33:30  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mapper/BeanMapper.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:15:50   EN80
 * Initial revision.
 * 
 *    Rev 1.2   Apr 28 2009 10:19:52   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.1   Jan 26 2005 10:03:16   rdq70
 * BlueHammur changes.
 *
 *    Rev 1.0   Jan 21 2005 10:35:54   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.mapper;

import com.bcbssc.netsys.web.mapper.MapMapper;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.dom4j.DocumentException;
import org.dom4j.Element;

/**
 * Maps data from an object to a Hashtable as defined by an XML configuration
 * file.
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class BeanMapper extends MapMapper {

	/**
	 * Gets data mapped from a passed Object using an XML configuration file.
	 * Uses default XML document structure of "Tasks."
	 *
	 * @param taskName -
	 *            task within the XML configuration file which is being mapped.
	 * @param bean -
	 *            the bean from which the data is mapped.
	 * @param request -
	 *            the request object.
	 * @return The mapped data.
	 * @throws org.dom4j.DocumentException
	 *             When there is an Exception while reading the XML
	 *             Configuration file.
	 */
	public Hashtable getTaskData(String taskName, Object bean,
			HttpServletRequest request) throws DocumentException {

		StringBuffer buf = new StringBuffer(32);
		buf.append("/tasks/task[@name='").append(taskName).append("']");
		return this.getData(buf.toString(), bean, request);
	}

	/**
	 * Created the default Map for the Mapper.
	 *
	 * @return the default Map for the Mapper.
	 */
	protected Map createMapObject() {
		return new Hashtable();
	}

	/**
	 * Gets data mapped from a passed Object using an XML configuration file.
	 * Uses the specified XML element path as the root node containing params.
	 * 
	 * @param containerPath -
	 *            the element path used as the root node of the task.
	 * @param bean -
	 *            the bean from which the data is mapped.
	 * @param request -
	 *            the request object.
	 * 
	 * @return The mapped data.
	 * 
	 * @throws DocumentException
	 *             When there is an Exception while reading the XML
	 *             Configuration file.
	 */
	private Hashtable getData(String containerPath, Object bean,
			HttpServletRequest request) throws DocumentException {

		this.loadDocument();
		Element task = (Element) this.document.selectSingleNode(containerPath);
		Hashtable parameters = null;

		if (task != null) {
			List list = task.element("params").elements("param");
			parameters = (Hashtable) this.getMap(bean, list, request, -1);
		}

		// log.debug("Task Parameters:\n" + parameters.toString());
		return parameters;
	}
}
