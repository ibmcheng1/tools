/*
 * @(#) GroupAdminTechnicalAction.java
 *
 * Created on January 4, 2006, 9:24 AM
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.actions;

import com.bcbssc.groupadmin.shared.dto.RegistrationFormDTO;
import com.bcbssc.groupadmin.shared.forms.TechnicalHelpForm;
import com.bcbssc.struts.action.BaseAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;

/**
 * * CLife Reset Password Action
 *
 * This class provides control processing to forward the user to the technical
 * help page
 *
 * @author Surendra Poranki
 * @version $Id: $Id
 */
public class GroupAdminTechnicalAction extends BaseAction {

	/** log4j logger */
	private static final Logger log = Logger
			.getLogger(GroupAdminTechnicalAction.class.getName());

	/**
	 * Processes the specified HTTP request, and create sthe corresponding HTTP
	 * response.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		GroupAdminTechnicalAction.log
				.debug("Inside the GroupAdminTechnicalAction");

		DynaValidatorForm df = (DynaValidatorForm) form;

		RegistrationFormDTO formDTO = new RegistrationFormDTO();
		BeanUtils.copyProperties(formDTO, df);

		// log.debug("User Name:"+ formDTO.getSamAccountName());
		// log.debug("Group Number:"+ formDTO.getGroupNumber());
		// log.debug("Access Code:"+ formDTO.getAccessCode());

		String forwardname;

		// Create a new technical help form containing only
		// the required properties
		TechnicalHelpForm newDTO = new TechnicalHelpForm(this.getServlet());
		newDTO.setSamAccountName(formDTO.getSamAccountName());
		newDTO.setGroupNumber(formDTO.getGroupNumber());
		newDTO.setAccessCode(formDTO.getAccessCode());

		forwardname = com.bcbssc.registration.common.Constants.FORWARD_SUCCESS;
		request.setAttribute("technicalHelpForm", newDTO);
		return mapping.findForward(forwardname);
	}
}
