/*
 * @(#)GroupAdminRegistrationServices.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.services;

import java.io.FileNotFoundException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.bcbssc.commapi.model.common.DAOException;
import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.groupadmin.shared.dbaccess.RoleQuery;
import com.bcbssc.groupadmin.shared.dbaccess.RulesQuery;
import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.groupadmin.shared.dto.RegistrationFormDTO;
import com.bcbssc.groupadmin.shared.dto.SuperUserDTO;
import com.bcbssc.groupadmin.shared.dto.TechnicalHelpFormDTO;
import com.bcbssc.groupadmin.shared.ldap.GroupAdminLdapUserHandler;
import com.bcbssc.groupadmin.shared.mq.GroupAdminTechnicalHelpInformHandler;
import com.bcbssc.groupadmin.shared.mq.GroupAdminUserInformHandler;
import com.bcbssc.groupadmin.shared.webpack.RulesProcessor;
import com.bcbssc.groupadmin.shared.webpack.WebpackException;
import com.bcbssc.netsys.Config;
import com.bcbssc.netsys.LinkedException;
import com.bcbssc.netsys.jndi.LdapException;
import com.bcbssc.netsys.jndi.MissingPropertyException;
import com.bcbssc.registration.dto.UserDTO;
import com.bcbssc.registration.services.IRegistrationServices;

/**
 * Group Administrator Registration Services
 *
 * This class provides the business logic for group administrator registration.
 * It is called from the action classes responsible for add, authenticate,
 * validate, reauthenticate, modify and change password.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.2  $
 */
public class GroupAdminRegistrationServices implements IRegistrationServices {

	/** log4j logger */
	protected static final Logger log = Logger
			.getLogger(GroupAdminRegistrationServices.class);

	/** the ini file containing service processing parameters */
	protected String iniFile = null;

	/** the ini file containing ssl connection parameters */
	protected String tdsIniFile = null;

	/**
	 * Constructs class, setting the servlet ini files
	 *
	 * @param _iniFile
	 *            the ini file containing service processing parameters
	 * @param _tdsIniFile a {@link java.lang.String} object.
	 */
	public GroupAdminRegistrationServices(String _iniFile, String _tdsIniFile) {
		this.iniFile = _iniFile;
		this.tdsIniFile = _tdsIniFile;
	}

	/**
	 * Returns an LDAP user handler
	 *
	 * @return the LDAP user handler contructed using the classes ini files
	 */
	protected GroupAdminLdapUserHandler getLdapUserHandler() {
		if (GroupAdminRegistrationServices.log.isDebugEnabled()) {
			GroupAdminRegistrationServices.log.debug("getting GroupAdminLdapUserHandler");
			GroupAdminRegistrationServices.log.debug("ini is: " + this.iniFile);
		
		}
		return new GroupAdminLdapUserHandler(this.iniFile,this.tdsIniFile);
	}

	/**
	 * Validates a user using the accessCode/ssn/dob. Checks rules database and
	 * determines if a profile already exists with the accessCode.
	 *
	 * @param dto
	 *            a RegistrationFormDTO form data object
	 * @return validation status
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 * @throws java.lang.IllegalAccessException
	 *             if an error occurs in copyProperties()
	 * @throws java.lang.reflect.InvocationTargetException
	 *             if an error occurs when copying the form to the user bean.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException
	 *             when any ldap confing property is missed in ini files
	 * @throws javax.naming.NamingException
	 *             when communication exception or ldap operation failure
	 *             scenarios
	 * @throws java.io.FileNotFoundException
	 *             when ini file not found
	 */
	public int validateUser(Object dto) throws  SQLException, IllegalAccessException,
			InvocationTargetException,  FileNotFoundException, MissingPropertyException, NamingException {

		RegistrationFormDTO form = (RegistrationFormDTO) dto;
		int status = Constants.SERVICE_INVALID;

		String accessCode = form.getAccessCode();
		String ssn = form.getLast6SSN();
		String dob = form.getDateOfBirth();

		if ((accessCode.length() != 0) && (ssn.length() != 0)) {

			RulesQuery rules = new RulesQuery(this.iniFile);

			GroupAdminUserDTO user = rules.verifyAccessCode(accessCode, ssn,
					dob);

			if (user != null) {

				GroupAdminLdapUserHandler luh = this.getLdapUserHandler();

				if (luh.profileExistsForUserIDorAccessCode(Constants.TDS_LDAP_ATTRIBUTE_ACCESSCODE,accessCode)) {
					status = Constants.ACCOUNT_EXISTS;
				} else {
					status = Constants.SERVICE_VALID;

					// Copy the user data to the form DTO
					this.copyProperties(form, user);
				}
			}
		}

		return status;
	}

	/**
	 * {@inheritDoc}
	 *
	 * Adds a user to the directory.
	 */
	public boolean addProfile(Object dto) throws IllegalAccessException,
			SQLException, FileNotFoundException,LdapException,MissingPropertyException,NamingException,
			InvocationTargetException, LinkedException {

		boolean success = false;

		RegistrationFormDTO form = (RegistrationFormDTO) dto;
		GroupAdminUserDTO user = new GroupAdminUserDTO();
		String samAccountName = form.getSamAccountName();
		String password = form.getUnicodePwd();

		GroupAdminLdapUserHandler luh = this.getLdapUserHandler();

		if (GroupAdminRegistrationServices.log.isDebugEnabled()) {
			GroupAdminRegistrationServices.log.debug("adding user: "
					+ form.getSamAccountName());
		}

		// Create a user from the form data by copying the beans
		this.copyProperties(user, form);

		// Add a profile for the new user
		success = luh.addUser(user, password);
		
		if (success) {
			// get role and update ldap
			this.updateRole(luh, user, samAccountName);

	
			//RD188C Changes for creating closed inform during registration
			 GroupAdminUserInformHandler gaih = new
			 GroupAdminUserInformHandler(iniFile);
			 gaih.sendProfileCreatedInform(user);
			luh
					.updateLastAccessTime(
							samAccountName,
							com.bcbssc.registration.common.Constants.TDS_LDAP_ATTRIBUTE_LASTACCESS);
		}
		return success;
	}

	/**
	 * Resets a user password during reauthentication and determines account
	 * revoked status.
	 *
	 * @param dto
	 *            a RegistrationFormDTO form data object
	 * @return reset password status (either SERVICE_VALID or ACCESS_REVOKED)
	 * @throws java.lang.Exception if any.
	 */
	public int resetPassword(Object dto) throws  Exception {
		RegistrationFormDTO form = (RegistrationFormDTO) dto;

		int status = Constants.SERVICE_INVALID;

		// Again, reauthenticate the user with the dob/ssn/challege to be sure
		// no one sneaks in a password reset
		if (this.reauthenticateChallenge(form) == Constants.SERVICE_VALID) {

			String samAccountName = form.getSamAccountName();
			String newpassword = form.getUnicodePwd();

			if (GroupAdminRegistrationServices.log.isDebugEnabled()) {
				GroupAdminRegistrationServices.log
						.debug("user reauthenticated; resetting user password: "
								+ samAccountName
								+ ", password length:"
								+ newpassword.length());
			}

			if ((samAccountName.length() != 0) && (newpassword.length() != 0)) {
				GroupAdminLdapUserHandler luh = this.getLdapUserHandler();

				if (luh.updatePassword(samAccountName, newpassword)) {
					// Get the user date using the new password
					GroupAdminUserDTO user = (GroupAdminUserDTO) luh
							.validateUser(samAccountName, newpassword);

					RulesQuery rules = new RulesQuery(this.iniFile);
					boolean verified = rules.verifyUserStatus(user
							.getAccessCode());
					if (GroupAdminRegistrationServices.log.isDebugEnabled()) {
						GroupAdminRegistrationServices.log
								.debug("USER AUTHENTICATE: " + verified);
					}

					if (verified) {
						status = Constants.SERVICE_VALID;
					} else {
						// Add user data to the form DTO that can be used for
						// the
						// prepopulated technical help form
						this.copyProperties(form, user);
						status = Constants.ACCESS_REVOKED;
					}
					luh
							.updateLastAccessTime(
									samAccountName,
									com.bcbssc.registration.common.Constants.TDS_LDAP_ATTRIBUTE_LASTACCESS);
				}
			}
		} else {
			GroupAdminRegistrationServices.log
					.debug("user not reauthenticated prior to resetting password");
			status = Constants.SERVICE_SECURITY_ERROR;
		}

		return status;
	}

	/**
	 * Reauthenticates a user using a SSN and dateOfBirth. Sets the challenge in
	 * the DTO if the user is found.
	 *
	 * @param dto
	 *            a RegistrationFormDTO form data object
	 * @return Constants.SERVICE_VALID if reauthenticaion was successful;
	 *         SERVICE_MULTIPLE_MATCH if directory contains more than one
	 *         profile for the SSN/dateOfBirth combination; SERVICE_INVALID if
	 *         authentication was not successful.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException
	 *             when any ldap confing property is missed in ini files
	 * @throws javax.naming.NamingException
	 *             when communication exception or ldap operation failure
	 *             scenarios
	 * @throws java.io.FileNotFoundException
	 *             when ini file not found
	 */
	public int reauthenticateUser(Object dto) throws FileNotFoundException, NamingException, MissingPropertyException {

		RegistrationFormDTO form = (RegistrationFormDTO) dto;

		// Validate username and password against LDAP
		String last6SSN = form.getLast6SSN();
		String dob = form.getDateOfBirth();

		String samAccountName = form.getSamAccountName();

		GroupAdminUserDTO user = null;
		GroupAdminLdapUserHandler luh = null;

		int status = Constants.SERVICE_INVALID;

		if ((last6SSN.length() != 0) && (dob.length() != 0)) {
			luh = this.getLdapUserHandler();

			int count;

			// If the form supplies a samAccountName, skip the user count
			// checking
			if (samAccountName.length() != 0) {
				count = 1;
			} else {
				count = luh.getProfileCount(last6SSN, dob);
				if (GroupAdminRegistrationServices.log.isDebugEnabled()) {
					StringBuffer msg = new StringBuffer(128);
					msg.append("Directory contains ").append(count);
					msg.append(" profile(s) for SSN: ").append(last6SSN);
					msg.append(" and DOB: ").append(dob);
					GroupAdminRegistrationServices.log.debug(msg.toString());
				}
			}

			if (count > 1) {
				status = Constants.SERVICE_MULTIPLE_MATCH;
			} else if (count == 1) {
				user = (GroupAdminUserDTO) luh.resetPassword(last6SSN, dob,
						samAccountName);
			}
		}

		if (user != null) {
			if (GroupAdminRegistrationServices.log.isDebugEnabled()) {
				StringBuffer msg = new StringBuffer(128);
				msg.append("User Found (").append(user.getSamAccountName());
				msg.append("); challenge is: ").append(user.getChallenge());
				GroupAdminRegistrationServices.log.debug(msg.toString());
			}
			form.setChallenge(user.getChallenge());
			status = Constants.SERVICE_VALID;
		}

		return status;
	}

	/**
	 * Reauthenticates a user identified by SSN and DOB using the
	 * challengeResponse. Sets the samAccountName in the DTO if the user was
	 * found.
	 *
	 * @param dto
	 *            a RegistrationFormDTO form data object
	 * @return reauthentication status indicator
	 * @throws java.lang.IllegalAccessException
	 *             if an error occurs in copyProperties()
	 * @throws java.lang.reflect.InvocationTargetException
	 *             if an error occurs when copying the form to the user bean.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException
	 *             when any ldap confing property is missed in ini files
	 * @throws javax.naming.NamingException
	 *             when communication exception or ldap operation failure
	 *             scenarios
	 * @throws java.io.FileNotFoundException
	 *             when ini file not found
	 */
	public int reauthenticateChallenge(Object dto)
			throws IllegalAccessException, InvocationTargetException,
			 FileNotFoundException, NamingException, MissingPropertyException {

		RegistrationFormDTO form = (RegistrationFormDTO) dto;

		// Validate username and password against LDAP
		String last6SSN = form.getLast6SSN();
		String dob = form.getDateOfBirth();
		String challengeResponse = form.getChallengeResponse();
		String samAccountName = form.getSamAccountName();

		GroupAdminUserDTO user = null;
		GroupAdminLdapUserHandler luh = this.getLdapUserHandler();

		int status = Constants.SERVICE_INVALID;

		if ((last6SSN.length() != 0) && (dob.length() != 0)) {
			if (GroupAdminRegistrationServices.log.isDebugEnabled()) {
				GroupAdminRegistrationServices.log
						.debug("searching user with last6SSN of " + last6SSN
								+ " and dob of " + dob);
			}
			user = (GroupAdminUserDTO) luh.resetPassword(last6SSN, dob,
					samAccountName);
		}

		if (user != null) {
			if (GroupAdminRegistrationServices.log.isDebugEnabled()) {
				GroupAdminRegistrationServices.log.debug("user found ("
						+ user.getSamAccountName() + "); challenge is: "
						+ user.getChallengeResponse());
			}

			if (challengeResponse.equalsIgnoreCase(user.getChallengeResponse())) {
				GroupAdminRegistrationServices.log
						.debug("challengeResponse matches");
				form.setSamAccountName(user.getSamAccountName());

				status = Constants.SERVICE_VALID;
			} else {
				int attempts = form.getChallengeAttempts();
				attempts++;

				if (GroupAdminRegistrationServices.log.isDebugEnabled()) {
					GroupAdminRegistrationServices.log
							.debug("challengeResponse (against valid user) not valid; "
									+ attempts + " attempt(s) so far");
				}

				form.setChallengeAttempts(attempts);

				if (attempts >= Constants.MAX_REAUTHENTICATE_ATTEMPTS) {

					// Add user data to the form DTO that can be used for the
					// password help form
					this.copyProperties(form, user);

					status = Constants.INVALID_ANSWER;
				}
			}
		}

		return status;
	}

	
	/**
	 * <p>authenticateSuperUser.</p>
	 *
	 * @param dto a {@link java.lang.Object} object.
	 * @return a int.
	 * @throws java.lang.Exception if any.
	 */
	public int authenticateSuperUser(Object dto) throws Exception {
		int returnInt;
		SuperUserDTO form = (SuperUserDTO) dto;

		// Validate username and password against LDAP
		String samAccountName = form.getSamAccountName();
		String unicodePwd = form.getUnicodePwd();
		String superUserType = form.getSuperUserType();
		String userClass     = form.getUserClass();
		
		String roles      = null;	
		boolean superUserValidated = false;
		boolean verified = false;
		
		GroupAdminLdapUserHandler luh = this.getLdapUserHandler();

		if ((samAccountName.length() != 0) && (unicodePwd.length() != 0)) {
			if (GroupAdminRegistrationServices.log.isDebugEnabled()) {
				GroupAdminRegistrationServices.log.debug("validating superUser: "
						+ samAccountName);
			}
			superUserValidated =  luh.validateSuperUser(samAccountName,unicodePwd);
		}

		if (superUserValidated) {
			verified = true;
			if (GroupAdminRegistrationServices.log.isDebugEnabled()) {
				GroupAdminRegistrationServices.log.debug("superUser authenticated:"+samAccountName+" type:"+userClass+" superUserType="+superUserType);
				
				// get Roles
				roles = luh.getSuperUserRoles(samAccountName);

				GroupAdminRegistrationServices.log
						.debug("Superuser authenticated: roles=" + roles);

				if (StringUtils.equals(superUserType, "GROUPADMIN_CLIFE_CSR")) {

					if (roles != null && (roles.indexOf("CWEB_CLIFE_GROUPADMIN_CSR") == -1)) {

						verified = false;
					}
				}
				if (StringUtils.equals(superUserType, "GROUPADMIN_CLIFE_HD")) {

					if (roles != null && (roles.indexOf("CWEB_CLIFE_GROUPADMIN_TSC") == -1)) {

						verified = false;
					}
				}

			}
		

			if (verified) {
				returnInt = Constants.SERVICE_VALID;
			} else {
				// Add user data to the form DTO that can be used for the
				// prepopulated technical help form
				//this.copyProperties(form, user);
				returnInt = Constants.ACCESS_REVOKED;
			}

		} else {
			// User/pass is invalid
			returnInt = Constants.SERVICE_INVALID;
		}
	
		return returnInt;
	}
	
	
	/**
	 * Authenticates a user against LDAP and ODBC using the samAccountName and
	 * password.
	 *
	 * @param dto
	 *            a RegistrationFormDTO form data object
	 * @return authentication status indicator
	 * @throws java.lang.Exception if any
	 */
	public int authenticateUser(Object dto) throws Exception {
		int returnInt;
		RegistrationFormDTO form = (RegistrationFormDTO) dto;

		// Validate username and password against LDAP
		String samAccountName = form.getSamAccountName();
		String unicodePwd = form.getUnicodePwd();

		GroupAdminUserDTO user = null;
		GroupAdminLdapUserHandler luh = this.getLdapUserHandler();

		if ((samAccountName.length() != 0) && (unicodePwd.length() != 0)) {
			if (GroupAdminRegistrationServices.log.isDebugEnabled()) {
				GroupAdminRegistrationServices.log.debug("validating user: "
						+ samAccountName);
			}
			user = (GroupAdminUserDTO) luh.validateUser(samAccountName,
					unicodePwd);
		}

		if (user != null) {
			if (GroupAdminRegistrationServices.log.isDebugEnabled()) {
				GroupAdminRegistrationServices.log.debug("user authenticated: "
						+ user.getGivenName() + " " + user.getLastName());
			
			}


			RulesQuery rules = new RulesQuery(this.iniFile);
			boolean verified = rules.verifyUserStatus(user.getAccessCode());
			if (GroupAdminRegistrationServices.log.isDebugEnabled()) {
				GroupAdminRegistrationServices.log.debug("USER AUTHENTICATE: "
						+ verified);
			}

			if (verified) {
				luh
						.updateLastAccessTime(
								samAccountName,
								com.bcbssc.registration.common.Constants.TDS_LDAP_ATTRIBUTE_LASTACCESS);

				// get role and update ldap
				this.updateRole(luh, user, samAccountName);

				returnInt = Constants.SERVICE_VALID;
			} else {
				// Add user data to the form DTO that can be used for the
				// prepopulated technical help form
				this.copyProperties(form, user);
				returnInt = Constants.ACCESS_REVOKED;
			}

		} else {
			// User/pass is invalid
			returnInt = Constants.SERVICE_INVALID;
		}
	
		return returnInt;
	}

	/**
	 * {@inheritDoc}
	 *
	 * Determines existance of a samAccountName in LDAP.
	 */
	public boolean usernameExists(Object dto) throws NamingException,MissingPropertyException,FileNotFoundException
			 {

		RegistrationFormDTO form = (RegistrationFormDTO) dto;
		boolean exists = false;

		String samAccountName = form.getSamAccountName();

		if (samAccountName.length() != 0) {

			GroupAdminLdapUserHandler luh = this.getLdapUserHandler();

			if (!luh.profileExistsForUserIDorAccessCode(Constants.TDS_LDAP_ATTRIBUTE_UID,samAccountName)) {
				exists = true;
			}
		}

		return exists;
	}

	/**
	 * Determines if an access code has already been requested for a user.
	 *
	 * @param dto
	 *            a RegistrationFormDTO form data object
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 * @return a boolean.
	 */
	public boolean accessCodeRequested(Object dto) throws SQLException {

		RegistrationFormDTO form = (RegistrationFormDTO) dto;

		String ssn = form.getLast6SSN();
		String dob = form.getDateOfBirth();

		RulesQuery rules = new RulesQuery(this.iniFile);

		return rules.accessCodeRequested(ssn, dob);
	}

	/**
	 * Requests a new access code
	 *
	 * @param dto
	 *            a RegistrationFormDTO form data object
	 * @throws java.lang.IllegalAccessException
	 *             if an error occurs when copying the form to the user bean.
	 * @throws java.lang.reflect.InvocationTargetException
	 *             if an error occurs when copying the form to the user bean.
	 * @throws java.text.ParseException
	 *             if the passed date of birth is not in the expected format
	 *             (mm/dd/yyyy).
	 * @throws com.bcbssc.commapi.model.common.DAOException if any.
	 * @return a boolean.
	 */
	public boolean requestAccessCode(Object dto) throws IllegalAccessException,
			InvocationTargetException, ParseException,  DAOException {

		boolean returnBoolean;
		RegistrationFormDTO form = (RegistrationFormDTO) dto;
		RulesProcessor rulesProcessor = new RulesProcessor(this.iniFile);
		GroupAdminUserDTO user = new GroupAdminUserDTO();

		this.copyProperties(user, form);

		String accessCode = rulesProcessor.requestNewAccessCode(user);
		if (accessCode != null) {
			if (GroupAdminRegistrationServices.log.isDebugEnabled()) {
				GroupAdminRegistrationServices.log
						.debug("got new access code: " + accessCode);
			}

			user.setAccessCode(accessCode);

			// send INFOrm
			GroupAdminUserInformHandler gaih = new GroupAdminUserInformHandler(
					this.iniFile);
			gaih.sendCodeRequestInform(user);

			returnBoolean = true;
		} else {
			GroupAdminRegistrationServices.log
					.debug("failed to get new access code");
			returnBoolean = false;
		}
		return returnBoolean;
	}

	/**
	 * {@inheritDoc}
	 *
	 * Submits a technical help request
	 */
	public void submitTechnicalHelpRequest(Object dto) {

		GroupAdminTechnicalHelpInformHandler gaih = new GroupAdminTechnicalHelpInformHandler(
				this.iniFile);
		gaih.sendTechnicalHelpInform((TechnicalHelpFormDTO) dto);
	}

	/**
	 * Sets the encrypted ONT Crentials Cookie in the servlet response
	 *
	 * @param samAccountName
	 *            the user name
	 * @param request
	 *            the servlet request.
	 * @param response
	 *            the servlet response.
	 * @throws java.lang.Exception if any.
	 */
	public void setEncryptedCookie(String samAccountName,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		GroupAdminLdapUserHandler luh = this.getLdapUserHandler();
		
		luh.writeOntCredCookie(samAccountName, request, response);
	}
	
	/**
	 * <p>setEncryptedRACFCookie.</p>
	 *
	 * @param racfId a {@link java.lang.String} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @param response a {@link javax.servlet.http.HttpServletResponse} object.
	 * @throws java.lang.Exception if any.
	 */
	public void setEncryptedRACFCookie(String racfId,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		GroupAdminLdapUserHandler luh = this.getLdapUserHandler();
		luh.writeRACFCookie(racfId, request, response);
	}
	
	/**
	 * <p>setCookie.</p>
	 *
	 * @param cookieName a {@link java.lang.String} object.
	 * @param cookieValue a {@link java.lang.String} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @param response a {@link javax.servlet.http.HttpServletResponse} object.
	 * @throws java.lang.Exception if any.
	 */
	public void setCookie(String cookieName,String cookieValue,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		GroupAdminLdapUserHandler luh = this.getLdapUserHandler();
		luh.writeCookie(cookieName, cookieValue, request, response);
	}

	/**
	 * Internal method to update the users role in LDAP
	 *
	 * @param samAccountName a {@link java.lang.String} object.
	 * @throws java.sql.SQLException if any.
	 * @throws com.bcbssc.netsys.jndi.MissingPropertyException
	 *             when any ldap confing property is missed in ini files
	 * @throws javax.naming.NamingException
	 *             when communication exception or ldap operation failure
	 *             scenarios
	 * @throws java.io.FileNotFoundException
	 *             when ini file not found
	 * @throws com.bcbssc.netsys.jndi.LdapException if any.
	 * @param luh a {@link com.bcbssc.groupadmin.shared.ldap.GroupAdminLdapUserHandler} object.
	 * @param user a {@link com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO} object.
	 * @throws com.bcbssc.netsys.LinkedException if any.
	 */
	public void updateRole(GroupAdminLdapUserHandler luh,
			GroupAdminUserDTO user, String samAccountName) throws SQLException,
			LinkedException, FileNotFoundException, NamingException, MissingPropertyException, LdapException {

		ArrayList<String> userRoles = new ArrayList<String>(10);
		String appName = Config.getPrivateProfileString(Constants.MISC_SECTION,
				Constants.INI_APP_NAME,
				com.bcbssc.struts.common.Constants.BLANK_STRING, this.iniFile);
		if (appName.indexOf("BEN") == -1) {
			userRoles
					.add(luh
							.getDistinguishedRoleName(com.bcbssc.registration.common.Constants.INI_APP_ROLE));
		}
		/*
		 * Roles will be coming from the DB2 tables with semi collan seperated
		 * strings. Ex: INQ:Y;UPD:Y;PAY:Y Now just tokenize them with ";"
		 * seperated string and get the individual role. Update the LDAP with
		 * each individual role which came from Databse.
		 */
		String allroles = new RoleQuery(this.iniFile).performSearch(user
				.getAccessCode());

		// check in LDAP if End to End monitor role is set
	/*	if (appName.indexOf("BEN") != -1) {
			String propertiesFile = Constants.LDAP_PROPERTIES;
			TopNavigationUtility topNavUtility = new TopNavigationUtility(
					propertiesFile);
			ArrayList roles = topNavUtility.getRolesForUser(samAccountName);
			boolean monitorFlag = false;
			for (int i = 0; i < roles.size(); i++) {
				if (("ont-roleuid=ETEM-1").equals(roles.get(i))) {
					monitorFlag = true;
					break;
				}
			}
			if (monitorFlag) {
				userRoles
						.add(luh
								.getDistinguishedRoleName(Constants.MONITOR_ROLE));
			}
		} */
		GroupAdminRegistrationServices.log.debug("allroles=" + allroles);
		int roleCount = StringUtils.countMatches(allroles, ";");
		int accessRevokedCount = StringUtils.countMatches(allroles, ":N");
		String role = "";
		String webAccessInd = "";
		if (allroles != null) {
			StringTokenizer st = new StringTokenizer(allroles, ";");
			while (st.hasMoreTokens()) {
				String nextRole = st.nextToken();
				role = StringUtils.split(nextRole, ":")[0];
				role = role.trim();
				webAccessInd = StringUtils.split(nextRole, ":")[1];
				webAccessInd = webAccessInd.trim();
				if (GroupAdminRegistrationServices.log.isDebugEnabled()) {
					GroupAdminRegistrationServices.log
							.debug("updateRole(): for " + samAccountName);
				}

				if (Constants.DB_UPDATE_ROLE.equals(role)) {
					userRoles
							.add(luh
									.getDistinguishedRoleName(Constants.INI_UPDATE_ROLE));
				} else if (Constants.DB_READ_ONLY_ROLE.equals(role)) {
					userRoles
							.add(luh
									.getDistinguishedRoleName(Constants.INI_READ_ONLY_ROLE));
				} else if (Constants.DB_PAY_ROLE.equals(role)) {
					userRoles.add(luh
							.getDistinguishedRoleName(Constants.INI_PAY_ROLE));
				} else if (Constants.DB_GRP_ROLE.equals(role)) {
					userRoles.add(luh
							.getDistinguishedRoleName(Constants.INI_GRP_ROLE));
				} else if ((Constants.ROLE_CORE.equals(role))
						&& (webAccessInd.equals("Y"))) {
					userRoles.add(luh
							.getDistinguishedRoleName(Constants.INI_ROLE_CORE));
					userRoles
							.add(luh
									.getDistinguishedRoleName(Constants.DENTAL_INI_ROLE_CORE));
				} else if ((Constants.ROLE_BLUESENROLL.equals(role))
						&& (webAccessInd.equals("Y"))) {
					userRoles
							.add(luh
									.getDistinguishedRoleName(Constants.INI_ROLE_BLUESENROLL));
					userRoles
							.add(luh
									.getDistinguishedRoleName(Constants.DENTAL_INI_ROLE_BLUESENROLL));
				} else if ((Constants.ROLE_EBILL.equals(role))
						&& (webAccessInd.equals("Y"))) {
					userRoles
							.add(luh
									.getDistinguishedRoleName(Constants.INI_ROLE_EBILL));
					userRoles
							.add(luh
									.getDistinguishedRoleName(Constants.DENTAL_INI_ROLE_EBILL));
				} else {
					StringBuffer buf = new StringBuffer(64);
					buf.append("Invalid database role (").append(role);
					buf.append("); defaulting to read-only");
					GroupAdminRegistrationServices.log.error(buf.toString());
					if (roleCount == accessRevokedCount) {
						userRoles
								.add(luh
										.getDistinguishedRoleName(Constants.INI_READ_ONLY_ROLE));
						if (appName.indexOf("BEN") != -1) {
							userRoles
									.add(luh
											.getDistinguishedRoleName(Constants.DENTAL_INI_ROLE_CORE));
						}
					}
				}
			}
		} else {
			StringBuffer buf = new StringBuffer(64);
			buf.append("Invalid database role (").append(role);
			buf.append("); defaulting to read-only, the role is null");
			GroupAdminRegistrationServices.log.error(buf.toString());
			userRoles.add(luh
					.getDistinguishedRoleName(Constants.INI_READ_ONLY_ROLE));
			if (appName.indexOf("BEN") != -1) {
				userRoles
						.add(luh
								.getDistinguishedRoleName(Constants.DENTAL_INI_ROLE_CORE));
			}
		}
		/*
		 * if (monitorFlag){
		 * groups.add(luh.getDistinguishedRoleName(Constants.MONITOR_ROLE)); }
		 */
		if (appName.indexOf("BEN") != -1) {
			userRoles.add(luh.getDistinguishedRoleName(Constants.MODIFY_PROFILE));
			luh.updateLdapAttribute(samAccountName, Constants.BCBSSC_GROUP,
					appName);
		}
		luh.updateRoles(samAccountName, userRoles);
	}

	/**
	 * Provides a wrapper for BeanUtils.copyProperties that includes exception
	 * logging.
	 * 
	 * @param toBean
	 *            the bean to which the properties will be copied.
	 * @param fromBean
	 *            the bean from which the properties will be copied.
	 * @throws IllegalAccessException
	 *             if an error occurs when copying the form to the user bean.
	 * @throws InvocationTargetException
	 *             if an error occurs when copying the form to the user bean.
	 */
	private void copyProperties(Object toBean, Object fromBean)
			throws IllegalAccessException, InvocationTargetException {
		 
		try {
			BeanUtils.copyProperties(toBean, fromBean);
		} catch (InvocationTargetException ite) {
			GroupAdminRegistrationServices.log.error("Reflection exception:",
					ite);
			GroupAdminRegistrationServices.log.error("Root cause:", ite
					.getTargetException());
			throw ite;
		}
	}

	/**
	 * <p>getUserFromCookie.</p>
	 *
	 * @param szOntCredCookie a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.registration.dto.UserDTO} object.
	 * @throws java.lang.Exception if any.
	 */
	public UserDTO getUserFromCookie(String szOntCredCookie) throws Exception {
		GroupAdminLdapUserHandler luh = this.getLdapUserHandler();

		UserDTO user = luh.getUserFromCookie(szOntCredCookie);
		return user;
	}

}
