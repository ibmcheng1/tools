/*
 * @(#)SuperUserDTO.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.dto;

import com.bcbssc.struts.common.DateBean;

/**
 * GroupAdmin Super User Data Transfer Object
 *
 * This bean transports data associated with super user logon.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.1  $
 */
public class SuperUserDTO {

    /**
     * Holds value of property userClass.
     */
    private String userClass;

    /**
     * Holds value of property racfId.
     */
    private String racfId;

    /**
     * Holds value of property functionType.
     */
    private String functionType;

    /**
     * Holds value of property ssn.
     */
    private String ssn;

    /**
     * Holds value of property dateOfBirth.
     */
    private DateBean dateOfBirth = new DateBean();

    /**
     * Holds value of property userName.
     */
    private String userName;

    /**
     * Holds value of property applicationId.
     */
    private String appId;

    /**
     * Holds value of property lastName.
     */
    private String lastName;

    /**
     * Getter for property userClass.
     *
     * @return Value of property userClass.
     */
    
    
    
    /** user name */
	private String samAccountName = com.bcbssc.struts.common.Constants.BLANK_STRING;
	/** user password */
	private String unicodePwd = com.bcbssc.struts.common.Constants.BLANK_STRING;
 
    private String superUserType = com.bcbssc.struts.common.Constants.BLANK_STRING;

    
    /**
     * <p>Setter for the field <code>superUserType</code>.</p>
     *
     * @param sUserType a {@link java.lang.String} object.
     */
    public void setSuperUserType(String sUserType){
    	
    	
    	this.superUserType = sUserType;
    }
    
    
    /**
     * <p>Getter for the field <code>superUserType</code>.</p>
     *
     * @return a {@link java.lang.String} object.
     */
    public String getSuperUserType(){
    	
    	
    	return this.superUserType;
    }
    
	/**
	 * Sets the user name
	 *
	 * @param value
	 *            user name
	 */
	public void setSamAccountName(String value) {
		this.samAccountName = value;
	}

	/**
	 * Gets the user name
	 *
	 * @return user name
	 */
	public String getSamAccountName() {
		return this.samAccountName;
	}

	/**
	 * Sets the user password
	 *
	 * @param value
	 *            user password
	 */
	public void setUnicodePwd(String value) {
		this.unicodePwd = value;
	}

	/**
	 * Gets the user password
	 *
	 * @return user password
	 */
	public String getUnicodePwd() {
		return this.unicodePwd;
	}
	
	
    /**
     * <p>Getter for the field <code>userClass</code>.</p>
     *
     * @return a {@link java.lang.String} object.
     */
    public String getUserClass() {
        return this.userClass;
    }

    /**
     * Setter for property userClass.
     *
     * @param userClass
     *            New value of property userClass.
     */
    public void setUserClass(String userClass) {
        this.userClass = userClass;
    }

    /**
     * Getter for property racfId.
     *
     * @return Value of property racfId.
     */
    public String getRacfId() {
        return this.racfId;
    }

    /**
     * Setter for property racfId.
     *
     * @param racfId
     *            New value of property racfId.
     */
    public void setRacfId(String racfId) {
        this.racfId = racfId;
    }

    /**
     * Getter for property functionType.
     *
     * @return Value of property functionType.
     */
    public String getFunctionType() {
        return this.functionType;
    }

    /**
     * Setter for property functionType.
     *
     * @param functionType
     *            New value of property functionType.
     */
    public void setFunctionType(String functionType) {
        this.functionType = functionType;
    }

    /**
     * Getter for property ssn.
     *
     * @return Value of property ssn.
     */
    public String getSsn() {
        return this.ssn;
    }

    /**
     * Setter for property ssn.
     *
     * @param ssn
     *            New value of property ssn.
     */
    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    /**
     * Getter for property dateOfBirth.
     *
     * @return Value of property dateOfBirth.
     */
    public DateBean getDateOfBirth() {
        return this.dateOfBirth;
    }

    /**
     * Setter for property dateOfBirth.
     *
     * @param dateOfBirth
     *            New value of property dateOfBirth.
     */
    public void setDateOfBirth(DateBean dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * Getter for property userName.
     *
     * @return Value of property userName.
     */
    public String getUserName() {
        return this.userName;
    }

    /**
     * Setter for property userName.
     *
     * @param userName
     *            New value of property userName.
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * Getter for property lastName.
     *
     * @return Value of property lastName.
     */
    public String getLastName() {
        return this.lastName;
    }

    /**
     * Setter for property lastName.
     *
     * @param lastName
     *            New value of property lastName.
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Getter for property applicationId.
     *
     * @return Value of property applicationId.
     */
    public String getAppId() {
        return this.appId;
    }

    /**
     * Setter for property applicationId.
     *
     * @param applicationId
     *            New value of property applicationId.
     */
    public void setAppId(String applicationId) {
        this.appId = applicationId;
    }

}
