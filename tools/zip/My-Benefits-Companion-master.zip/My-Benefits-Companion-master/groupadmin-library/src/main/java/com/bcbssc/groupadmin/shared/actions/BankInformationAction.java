/**
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.groupadmin.shared.actions;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.GenericValidator;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.util.LabelValueBean;

//import com.bcbssc.commercial.util.CommercialUtil;
import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.groupadmin.shared.dto.BankInformationDTO;
import com.bcbssc.groupadmin.shared.dto.BillHistoryDTO;
import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;
import com.bcbssc.groupadmin.shared.forms.BankInformationForm;
import com.bcbssc.groupadmin.shared.forms.CGAUtilityBean;
import com.bcbssc.groupadmin.shared.services.AccountServices;
import com.bcbssc.groupadmin.shared.services.BillServices;
import com.bcbssc.groupadmin.shared.services.InsuredServices;
import com.bcbssc.struts.action.SimpleDispatchAction;

/**
 * This class provides the control processing for the Banking Account
 * Information.
 *
 * @author X22R (Srini Gandu)
 * @version 1.0 Date 03/13/2006
 */
public class BankInformationAction extends SimpleDispatchAction {

    /** log4j logger */
    private static Logger log = Logger.getLogger(BankInformationAction.class);

    // Global declaration.
    ActionErrors errors = new ActionErrors();

    /**
     * <p>Constructor for BankInformationAction.</p>
     */
    public BankInformationAction() {
        super();
        if (BankInformationAction.log.isDebugEnabled()) {
            BankInformationAction.log
                    .debug("Created BankInformationAction object.");
        }
    }

    /**
     * This will get the groups details associated with this Group Admin (CGA)
     *
     * @param mapping
     *            the ActionMapping used to select this instance
     * @param form
     *            the optional bean for this request (if any)
     * @param request
     *            the HTTP request we are processing
     * @param response
     *            the HTTP request we are creating
     * @return describes where and how control should be forwarded, or null if
     *         the response has already been completed.
     * @throws java.lang.Exception if any.
     */
    public ActionForward getGroupsDetails(ActionMapping mapping,
            ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        this.displayLog("In getGroupsDetails()");

        BankInformationForm bankInformation = (BankInformationForm) form;
        Collection groupOptions = null;
        String forwardPage = null;
        /*
         * Populate the user(GA) information.
         */
        bankInformation
                .setUserDTO((GroupAdminUserDTO) request
                        .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));

        /*
         * Get the groups collection and it's count. if this GA has only one
         * group associated with him then check the validity of the bank account
         * details for this group.
         */
        groupOptions = bankInformation.getGroupOptions();
        int groupCount = groupOptions.size();
        this.displayLog("Group Count = " + groupCount);
        if (groupCount > 2) {
            // multiple groups
            forwardPage = Constants.FORWARD_VALID;
        } else {
            // single group only
            this.populateBankAccountDetails(bankInformation, groupOptions);
            forwardPage = this.getPageNavigation(bankInformation);
        }

        /*
         * Populate the CGAUtils bean with loaded bank details and set this bean
         * into the session. So we can use this bean to compare any bank info
         * changes the CGA has made later. Check this bean is already in session
         * or not, if in session we can make sure that the groupCount should be
         * preserved if it is already populated.
         */
        this.setGroupLoadedBankDetails(bankInformation, request);

        /*
         * Make it available this bankInformation bean in the request object.
         */
        request.setAttribute("bankInformationForm", bankInformation);

        return mapping.findForward(forwardPage);
    }

    /**
     * Displays the bank information update page when CGA clicks on the "Change
     * banking information" button to enable the user to update the current bank
     * information which is on the file.
     *
     * @param mapping a {@link org.apache.struts.action.ActionMapping} object.
     * @param form a {@link org.apache.struts.action.ActionForm} object.
     * @param request a {@link javax.servlet.http.HttpServletRequest} object.
     * @param response a {@link javax.servlet.http.HttpServletResponse} object.
     * @throws java.lang.Exception if any.
     * @return a {@link org.apache.struts.action.ActionForward} object.
     */
    public ActionForward changeBankInformation(ActionMapping mapping,
            ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        this.displayLog("In changeBankInformation()");
        BankInformationForm bankInformation = (BankInformationForm) form;
        this.displayLog("group = " + bankInformation.getGroup());
        this.displayLog("group number =" + bankInformation.getGroupNumber());
        /*
         * Populate the user(GA) information.
         */
        bankInformation
                .setUserDTO((GroupAdminUserDTO) request
                        .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));

        /*
         * Populate the CGAUtils bean with loaded bank details and set this bean
         * into the session. So we can use this bean to compare any bank info
         * changes the CGA has made later. Check this bean is already in session
         * or not, if in session we can make sure that the groupCount should be
         * preserved if it is already populated.
         */
        this.setGroupLoadedBankDetails(bankInformation, request);
        this
                .displayLog("Bank Information Object="
                        + bankInformation.toString());
        /*
         * Make it available this bankInformation bean in the request object.
         */
        request.setAttribute("bankInformationForm", bankInformation);
        /*
         * Forward the page.
         */
        return mapping
                .findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
    }

    /**
     * Gets the bank account details for that perticular group.
     *
     * @param mapping
     *            the ActionMapping used to select this instance
     * @param form
     *            the optional bean for this request (if any)
     * @param request
     *            the HTTP request we are processing
     * @param response
     *            the HTTP request we are creating
     * @return describes where and how control should be forwarded, or null if
     *         the response has already been completed.
     * @throws java.lang.Exception if any.
     */
    public ActionForward getBankDetails(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {

        this.displayLog("In getBankDetails()");
        /*
         * Get the form object to process.
         */
        BankInformationForm bankInformation = (BankInformationForm) form;
        String forwardingPage = null;

        /*
         * Check for the group number null or empty if it is empty or null then
         * just simply forward the update page with groups.
         */
        this.displayLog("bankInformation.getGroupNumber()="
                + bankInformation.getGroupNumber());
        if ((bankInformation.getGroupNumber() != null)
                && !"".equals(bankInformation.getGroupNumber())) {
            this.displayLog("group number is not null");
            /*
             * Make a DTO with the currently selected group number.
             */
            InsuredDataDTO insuredDTO = new InsuredDataDTO();

            insuredDTO.setGroupNumber(bankInformation.getGroupNumber());
            this.displayLog("bankInformation.getGroupNumber() = "
                    + bankInformation.getGroupNumber());
            /*
             * Create an account services object.
             */
            AccountServices accountServices = new AccountServices(CommonUtils
                    .getIniFile(this.getServlet()));
            /*
             * We will get the bean with bank account details and populate the
             * user related information.
             */
            BankInformationDTO bankInfoDTO = accountServices
                    .getBankAccountDetails(insuredDTO);

            /*
             * Populate bank information details.
             */
            bankInformation.setAccountHolderName(bankInfoDTO
                    .getAccountHolderName());
            bankInformation.setBankName(bankInfoDTO.getBankName());
            bankInformation.setBankAccountNumber(bankInfoDTO
                    .getBankAccountNumber());
            bankInformation.setBankAccountNumberConfirm(""); // this will
                                                                // remove any
                                                                // pre populated
                                                                // data from the
                                                                // jsp
                                                                // submission.
            bankInformation.setBankRoutingNumber(bankInfoDTO
                    .getBankRoutingNumber());
            bankInformation.setBankRoutingNumberConfirm(""); // this will
                                                                // remove any
                                                                // pre populated
                                                                // data from the
                                                                // jsp
                                                                // submission.
            bankInformation.setBankStatus(bankInfoDTO.getBankStatus());

            bankInformation
                    .setUserDTO((GroupAdminUserDTO) request
                            .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
            /*
             * Set the navigational page attribute into the object based on the
             * bank accont status.
             */
            this.displayLog("Bank Status=" + bankInformation.getBankStatus());
            /*
             * Determine the validity of the bank account for this group. If any
             * one of the five fields are not available then the flag will be
             * false. That means, there is invalid bank information.
             */
            forwardingPage = this.getPageNavigation(bankInformation);
        } else {
            this.displayLog("group number is null");
            bankInformation.clear();
            bankInformation
                    .setUserDTO((GroupAdminUserDTO) request
                            .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
            forwardingPage = Constants.FORWARD_VALID;
        }

        /*
         * Populate the CGAUtils bean with loaded bank details and set this bean
         * into the session. So we can use this bean to compare any bank info
         * changes the CGA has made later. Check this bean is already in session
         * or not, if in session we can make sure that the groupCount should be
         * preserved if it is already populated.
         */
        this.setGroupLoadedBankDetails(bankInformation, request);

        /*
         * Set the bank details object in the request object.
         */
        request.setAttribute("bankInformationForm", bankInformation);

        /*
         * Forward the bank information update page to the client.
         */
        return mapping.findForward(forwardingPage);
    }

    /**
     * Get's the bank account information for the selected group when CGA clicks
     * on the back button from the bank information confirm page.
     *
     * @param mapping a {@link org.apache.struts.action.ActionMapping} object.
     * @param form a {@link org.apache.struts.action.ActionForm} object.
     * @param request a {@link javax.servlet.http.HttpServletRequest} object.
     * @param response a {@link javax.servlet.http.HttpServletResponse} object.
     * @throws java.lang.Exception if any.
     * @return a {@link org.apache.struts.action.ActionForward} object.
     */
    public ActionForward getBankDetailsBack(ActionMapping mapping,
            ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        this.displayLog("In getBankDetailsBack()");
        /*
         * Get the form object to process.
         */
        BankInformationForm bankInformation = (BankInformationForm) form;
        String forwardPage = null;
        /*
         * Set the user details.
         */
        bankInformation
                .setUserDTO((GroupAdminUserDTO) request
                        .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));

        /*
         * Since this function can be called from bank confirmation page. We got
         * to check for existance of bank account or validity of it.
         */
        this.displayLog("bank status=" + bankInformation.getBankStatus());
        if (Constants.INVALID_BANK_STATUS.equals(bankInformation
                .getBankStatus())
                || !bankInformation.getBankAccountAvailableFlag()
                || StringUtils.isEmpty(bankInformation.getBankStatus())) {
            // go to invalid change page
            forwardPage = Constants.FORWARD_INVALID;
        } else {
            // go to valid add/change page
            forwardPage = Constants.FORWARD_VALID;
        }
        /*
         * Set the bank details object in the request object.
         */
        request.setAttribute("bankInformationForm", bankInformation);

        /*
         * Forward the bank information update page to the client.
         */
        return mapping.findForward(forwardPage);
    }

    /**
     * Validate the bank account details for that perticular group.
     *
     * @param mapping
     *            the ActionMapping used to select this instance
     * @param form
     *            the optional bean for this request (if any)
     * @param request
     *            the HTTP request we are processing
     * @param response
     *            the HTTP request we are creating
     * @return describes where and how control should be forwarded, or null if
     *         the response has already been completed.
     * @throws java.lang.Exception if any.
     */
    public ActionForward validateBankAccount(ActionMapping mapping,
            ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        this.displayLog("In validateBankAccount()");
        /*
         * Get the form object to process.
         */
        BankInformationForm bankInformation = (BankInformationForm) form;
        String forwardPage = null;

        bankInformation
                .setUserDTO((GroupAdminUserDTO) request
                        .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
        /*
         * Check any validation errors arised, if no then continue. if errors
         * then go back to group selection page to fix it.
         */
        ActionErrors errors = this.validateForm(bankInformation, request);
        if (errors.size() != 0) {
            this.saveErrors(request, errors);
            forwardPage = com.bcbssc.registration.common.Constants.FORWARD_FAILURE;
        } else {

            /*
             * Make a DTO with the currently selected group number.
             */
            InsuredDataDTO insuredDTO = new InsuredDataDTO();
            insuredDTO.setGroupNumber(bankInformation.getGroupNumber());

            /*
             * Create an account services object.
             */
            AccountServices accountServices = new AccountServices(CommonUtils
                    .getIniFile(this.getServlet()));
            /*
             * We will get the bean with bank account details.
             */
            BankInformationDTO bankInfoDTO = accountServices
                    .getBankAccountDetails(insuredDTO);

            /*
             * Populate bank information details.
             */
            bankInformation.setAccountHolderName(bankInfoDTO
                    .getAccountHolderName());
            bankInformation.setBankName(bankInfoDTO.getBankName());
            bankInformation.setBankAccountNumber(bankInfoDTO
                    .getBankAccountNumber());
            bankInformation.setBankRoutingNumber(bankInfoDTO
                    .getBankRoutingNumber());
            bankInformation.setBankStatus(bankInfoDTO.getBankStatus());

            /*
             * Determine the validity of the bank account for this group. If any
             * one of the five fields are not available then the flag will be
             * false. That means, there is invalid bank information, else check
             * on bank status.
             */
            forwardPage = this.getPageNavigation(bankInformation);

            /*
             * Populate the CGAUtils bean with loaded bank details and set this
             * bean into the session. So we can use this bean to compare any
             * bank info changes the CGA has made later. Check this bean is
             * already in session or not, if in session we can make sure that
             * the groupCount should be preserved if it is already populated.
             */
            this.setGroupLoadedBankDetails(bankInformation, request);

        }

        request.setAttribute("bankInformationForm", bankInformation);
        return mapping.findForward(forwardPage);

    }

    /**
     * When the user clicks back button from the payment enter page.
     *
     * @param mapping
     *            the ActionMapping used to select this instance
     * @param form
     *            the optional bean for this request (if any)
     * @param request
     *            the HTTP request we are processing
     * @param response
     *            the HTTP request we are creating
     * @return describes where and how control should be forwarded, or null if
     *         the response has already been completed.
     * @throws java.lang.Exception if any.
     */
    public ActionForward validateBankAccountBack(ActionMapping mapping,
            ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        this.displayLog("In validateBankAccountBack()");
        /**
         * Get the form object to process.
         */
        BankInformationForm bankInformation = (BankInformationForm) form;

        bankInformation
                .setUserDTO((GroupAdminUserDTO) request
                        .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));

        /**
         * Make a DTO with the currently selected group number.
         */
        InsuredDataDTO insuredDTO = new InsuredDataDTO();
        insuredDTO.setGroupNumber(bankInformation.getGroupNumber());

        /**
         * Create an account services object.
         */
        AccountServices accountServices = new AccountServices(CommonUtils
                .getIniFile(this.getServlet()));
        /**
         * We will get the bean with bank account details.
         */
        BankInformationDTO bankInfoDTO = accountServices
                .getBankAccountDetails(insuredDTO);

        /**
         * Populate bank information details.
         */
        bankInformation
                .setAccountHolderName(bankInfoDTO.getAccountHolderName());
        bankInformation.setBankName(bankInfoDTO.getBankName());
        bankInformation
                .setBankAccountNumber(bankInfoDTO.getBankAccountNumber());
        bankInformation
                .setBankRoutingNumber(bankInfoDTO.getBankRoutingNumber());
        bankInformation.setBankStatus(bankInfoDTO.getBankStatus());

        this
                .displayLog("Bank Information Object="
                        + bankInformation.toString());
        request.setAttribute("bankInformationForm", bankInformation);
        return mapping
                .findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);

    }

    /**
     * This will confirm the bank information entered by the Group
     * Administrator.
     *
     * @param mapping
     *            the ActionMapping used to select this instance
     * @param form
     *            the bean for this request.
     * @param request
     *            the Http Request for processing.
     * @param response
     *            the Http Response we are creating.
     * @return Describes where and how control should be forwarded or the null
     *         if the response is alredy been completed.
     * @throws java.lang.Exception
     *             if application business logic throws an exception.
     */
    public ActionForward confirmBankDetails(ActionMapping mapping,
            ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        this.displayLog("In confirmBankDetails()");
        /**
         * Create the bank information bean.
         */
        BankInformationForm bankInformation = (BankInformationForm) form;
        String forwardPage = null;

        bankInformation
                .setUserDTO((GroupAdminUserDTO) request
                        .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
        /**
         * Check any validation errors arised, if no then continue with
         * confirmation page. if errors then go back to add/change page to fix
         * it.
         */
        ActionErrors errors = this.validateForm(bankInformation, request);
        if (errors.size() == 0) {
            forwardPage = Constants.FORWARD_BANK_CONFIRM;
        } else {
            this.saveErrors(request, errors);
            forwardPage = com.bcbssc.registration.common.Constants.FORWARD_FAILURE;
        }

        /**
         * Put the necessary form bean into the request object.
         */
        request.setAttribute("bankInformationForm", bankInformation);
        /**
         * Then forward the success page to render in the web browser.
         */
        return mapping.findForward(forwardPage);
    }

    /**
     * This will send the inform with the confirmed bank details entered by the
     * Group Administrator.
     *
     * @param mapping
     *            the ActionMapping used to select this instance
     * @param form
     *            the bean for this request.
     * @param request
     *            the Http Request for processing.
     * @param response
     *            the Http Response we are creating.
     * @return Describes where and how control should be forwarded or the null
     *         if the response is alredy been completed.
     * @throws java.lang.Exception
     *             if application business logic throws an exception.
     */
    public ActionForward sendBankDetails(ActionMapping mapping,
            ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        this.displayLog("In sendBankDetails()");
        /**
         * Get the bean.
         */
        BankInformationForm bankInformation = (BankInformationForm) form;
        this.displayLog("Group Number=" + bankInformation.getGroupNumber());
        this.displayLog("Bank Account Number="
                + bankInformation.getBankAccountNumber());
        this.displayLog("Bank Status = " + bankInformation.getBankStatus());
        /**
         * Generate the tracking number and populate it in the
         * BankInformationForm bean.
         */
        bankInformation.setTrackingNumber(this.generateTrackingNumber());

        String currentDateTime = new SimpleDateFormat("yyyyMMddhh:mm:ss")
                .format(new Date());
        /* currentDate is used to display in the Inform message */
        String currentDate = currentDateTime.substring(0, 8);
        String currentTime = currentDateTime.substring(8);
        this.displayLog("date and time=" + currentDate + " & " + currentTime);
        bankInformation.setEntryDate(currentDate);
        bankInformation.setEntryTime(currentTime);

        /**
         * Activity Code: 'A' IF adding new bank info or 'C' IF Changing
         * existing bank info.
         */
        bankInformation.setActivityCode(this.getActivityCode(bankInformation,
                request));
        this.displayLog("bankInformation.getActivityCode() = "
                + bankInformation.getActivityCode());

        /**
         * Need to send the W841 Web Banking Transaction and Inform via MQ 1)
         * Create the insured services object and call the method.
         */
        BankInformationDTO bankInfoDTO = new BankInformationDTO();
        BeanUtils.copyProperties(bankInfoDTO, bankInformation);

        this.displayLog("bankInfoDTO.getCompany =" + bankInfoDTO.getCompany());
        this.displayLog("bankInfoDTO.getGroupPrefix ="
                + bankInfoDTO.getGroupPrefix());
        this.displayLog("bankInfoDTO.getGroupBase ="
                + bankInfoDTO.getGroupBase());
        this.displayLog("bankInfoDTO.getDivisionCode ="
                + bankInfoDTO.getDivisionCode());
        this.displayLog("bankInfoDTO.getBankStatus() ="
                + bankInfoDTO.getBankStatus());

        /**
         * If bank account status is '9', the we will send "OPEN" inform else we
         * send "CLOSED" inform.
         */
        if (Constants.INVALID_BANK_STATUS.equals(bankInfoDTO.getBankStatus())) {
            bankInfoDTO.setClosedInform(false);
        } else {
            bankInfoDTO.setClosedInform(true);
        }

        this.displayLog("Bank Details, Is Closed Inform:"
                + bankInfoDTO.isClosedInform());

        InsuredServices insuredServices = new InsuredServices(
                CommonUtils.getIniFile(this.getServlet()),
                CommonUtils.getGcomIniFile(this.getServlet()),
                (GroupAdminUserDTO) request
                        .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
        insuredServices.sendBankInformation(bankInfoDTO, request);

        /**
         * Put the necessary form bean into the request object.
         */
        request.setAttribute("bankInformationForm", bankInformation);
        /**
         * Then forward the success page to render in the web browser.
         */
        return mapping
                .findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
    }

    /**
     * When the GA clicks on the "PayBill" menu item this will call. There are
     * several things that we need to do here 1) Get the associated groups for
     * this GA If he has more than one group than disply the group selection
     * page. else if he has only one group than get the status of the bank
     * account information for this group If the status is invalid than show the
     * edit bank information page, else if it is valid show the bank info
     * confirmation page.
     *
     * @param mapping a {@link org.apache.struts.action.ActionMapping} object.
     * @param form a {@link org.apache.struts.action.ActionForm} object.
     * @param request a {@link javax.servlet.http.HttpServletRequest} object.
     * @param response a {@link javax.servlet.http.HttpServletResponse} object.
     * @return a {@link org.apache.struts.action.ActionForward} object.
     * @throws java.lang.Exception if any.
     */
    public ActionForward displayPaybillDetails(ActionMapping mapping,
            ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        this.displayLog("In displayPaybillDetails()");

        BankInformationForm bankInformation = (BankInformationForm) form;
        Collection groupOptions = null;
        String forwardPage = null;
        /**
         * Populate the user(GA) information.
         */
        bankInformation
                .setUserDTO((GroupAdminUserDTO) request
                        .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));

        /**
         * Get the groups collection and it's count. if this GA has only one
         * group associated with him then check the validity of the bank account
         * details for this group.
         */
        groupOptions = bankInformation.getGroupOptions();
        int groupCount = groupOptions.size();
        this.displayLog("Group Count = " + groupCount);

        /**
         * Count the number of groups Note: this group count includes the drop
         * down label on top and groups list below. Ex: LabelValueBean[-- Please
         * Choose One --, ] LabelValueBean[336 25 44148 000 NORTH OTTAWA
         * COMMUNITY HOSPITAL, 3362544148000|NORTH OTTAWA COMMUNITY
         * HOSPITAL|06/01/2005|04/01/2004|05/01/2005]
         */
        if (groupCount == 2) {
            // single group only
            this.populateBankAccountDetails(bankInformation, groupOptions);
            forwardPage = this.getPageNavigation(bankInformation);

        } else {
            // Multiple Groups or No Groups at all.
            forwardPage = Constants.FORWARD_GROUP_SELECTION;
        }

        /**
         * Populate the CGAUtils bean with loaded bank details and set this bean
         * into the session. So we can use this bean to compare any bank info
         * changes the CGA has made later. Check this bean is already in session
         * or not, if in session we can make sure that the groupCount should be
         * preserved if it is already populated.
         */
        this.setGroupLoadedBankDetails(bankInformation, request);

        /**
         * Make it available this bankInformation bean in the request object.
         */
        request.setAttribute("bankInformationForm", bankInformation);
        /**
         * forward the control back to the page.
         */
        return mapping.findForward(forwardPage);
    }

    /**
     * Gets the outstanding payment bill details for a selected group.
     *
     * @param mapping
     *            the ActionMapping used to select this instance
     * @param form
     *            the optional bean for this request (if any)
     * @param request
     *            the HTTP request we are processing
     * @param response
     *            the HTTP request we are creating
     * @return describes where and how control should be forwarded, or null if
     *         the response has already been completed.
     * @throws java.lang.Exception if any.
     */
    public ActionForward getPaymentDetails(ActionMapping mapping,
            ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        this.displayLog("In getPaymentDetails()");
        /**
         * Get the form object from the request object.
         */
        BankInformationForm bankInformation = (BankInformationForm) form;
        this.displayLog("Available bean=" + bankInformation);

        /**
         * populate the current GA DTO into bank info bean.
         */
        bankInformation
                .setUserDTO((GroupAdminUserDTO) request
                        .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));

        /**
         * Populate Insured DTO with the currently selected group number.
         */
        InsuredDataDTO insuredDTO = new InsuredDataDTO();
        insuredDTO.setGroupNumber(bankInformation.getGroupNumber());
        this.displayLog("bankInformation.getGroupNumber()="
                + bankInformation.getGroupNumber());

        /**
         * Create an bill services object.
         */
        BillServices billServices = new BillServices(CommonUtils
                .getIniFile(this.getServlet()));
        /**
         * We will get the bean with bank account details.
         */
        Collection outstandingBills = billServices.getbillHistory(insuredDTO);
        this.displayLog("In getPaymentDetails():outstandingBills size="
                + outstandingBills.size());

        /**
         * Populate the bankInformationForm bean with the above collection of
         * outstanding bills.
         */
        bankInformation.setSearchResults(outstandingBills);

        /**
         * Calculate the total balance due amount for this group.
         */
        bankInformation.setTotalBalanceDue(this.getTotalBalanceDue(
                bankInformation, outstandingBills));

        /**
         * Need to make the bankInformationForm available to the request object.
         */
        request.setAttribute("bankInformationForm", bankInformation);

        return mapping
                .findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);

    }

    /**
     * Back button functionality to the confirm payment page to display the
     * payment amount enter page.
     *
     * @param mapping a {@link org.apache.struts.action.ActionMapping} object.
     * @param form a {@link org.apache.struts.action.ActionForm} object.
     * @param request a {@link javax.servlet.http.HttpServletRequest} object.
     * @param response a {@link javax.servlet.http.HttpServletResponse} object.
     * @throws java.lang.Exception if any.
     * @return a {@link org.apache.struts.action.ActionForward} object.
     */
    public ActionForward getPaymentDetailsBack(ActionMapping mapping,
            ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        this.displayLog("In getPaymentDetailsBack()");
        /**
         * Get the form object from the request object.
         */
        BankInformationForm bankInformation = (BankInformationForm) form;
        this.displayLog("Available bean=" + bankInformation);

        /**
         * populate the current GA DTO into bankInformation bean.
         */
        bankInformation
                .setUserDTO((GroupAdminUserDTO) request
                        .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));

        /**
         * Populate Insured DTO with the currently selected group number.
         */
        InsuredDataDTO insuredDTO = new InsuredDataDTO();
        insuredDTO.setGroupNumber(bankInformation.getGroupNumber());
        this.displayLog("bankInformation.getGroupNumber()="
                + bankInformation.getGroupNumber());

        /**
         * Create an bill services object.
         */
        BillServices billServices = new BillServices(CommonUtils
                .getIniFile(this.getServlet()));

        /**
         * We will get the bean with bank account details.
         */
        Collection outstandingBills = billServices.getbillHistory(insuredDTO);
        this.displayLog("outstandingBills size=" + outstandingBills.size());

        /**
         * Populate the bank information bean with the above collection of
         * outstanding bills.
         */
        bankInformation.setSearchResults(outstandingBills);

        /**
         * Calculate the total balance due amount for this group. We need to set
         * the dollar amount and cents amount seperately.
         */
        String totalBalanceDue = this.getTotalBalanceDue(bankInformation,
                outstandingBills);
        bankInformation.setTotalBalanceDueDollars(totalBalanceDue.substring(0,
                totalBalanceDue.length() - 3));
        bankInformation.setTotalBalanceDueCents(totalBalanceDue
                .substring(totalBalanceDue.length() - 2));

        /**
         * Need to make the bankInformation available to the request object.
         */
        request.setAttribute("bankInformationForm", bankInformation);

        return mapping
                .findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);

    }

    /**
     * Confirms the group payment details for that perticular group.
     *
     * @param mapping
     *            the ActionMapping used to select this instance
     * @param form
     *            the optional bean for this request (if any)
     * @param request
     *            the HTTP request we are processing
     * @param response
     *            the HTTP request we are creating
     * @return describes where and how control should be forwarded, or null if
     *         the response has already been completed.
     * @throws java.lang.Exception if any.
     */
    public ActionForward confirmPaymentDetails(ActionMapping mapping,
            ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        this.displayLog("In confirmPaymentDetails()");
        String forwardPage = null;

        // Create the BankInformation bean
        BankInformationForm bankInformation = (BankInformationForm) form;
        this.displayLog("bankInformation.getGroupNumber()="
                + bankInformation.getGroupNumber());

        /**
         * Check for validations, if no errors continue..
         */
        ActionErrors errors = this.validateForm(bankInformation, request);
        if (errors.size() != 0) {
            this.displayLog("validation faild.");
            this.saveErrors(request, errors);
            forwardPage = com.bcbssc.registration.common.Constants.FORWARD_FAILURE;

            /**
             * Need to make sure the bill history collection and other
             * information is availble in the request scope when the error form
             * is loaded.
             */
            bankInformation
                    .setUserDTO((GroupAdminUserDTO) request
                            .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
            InsuredDataDTO insuredDTO = new InsuredDataDTO();
            insuredDTO.setGroupNumber(bankInformation.getGroupNumber());
            BillServices billServices = new BillServices(CommonUtils
                    .getIniFile(this.getServlet()));
            Collection outstandingBills = billServices
                    .getbillHistory(insuredDTO);
            this.displayLog("outstandingBills size=" + outstandingBills.size());
            bankInformation.setSearchResults(outstandingBills);

            /**
             * Calculate the total balance due amount for this group. We need to
             * set the dollar amount and cents amount seperately.
             */
            String totalBalanceDue = this.getTotalBalanceDue(bankInformation,
                    outstandingBills);
            bankInformation.setTotalBalanceDueDollars(totalBalanceDue
                    .substring(0, totalBalanceDue.length() - 3));
            bankInformation.setTotalBalanceDueCents(totalBalanceDue
                    .substring(totalBalanceDue.length() - 2));

        } else {

            /**
             * Get the Bank Account details by using the group number. Create an
             * account services object. We will get the bean with bank account
             * details. Copy all the DTO properties to bank info bean.
             */
            InsuredDataDTO insuredDTO = new InsuredDataDTO();
            insuredDTO.setGroupNumber(bankInformation.getGroupNumber());
            AccountServices accountServices = new AccountServices(CommonUtils
                    .getIniFile(this.getServlet()));
            BankInformationDTO bankInfoDTO = accountServices
                    .getBankAccountDetails(insuredDTO);
            /**
             * Populate bank information details.
             */
            bankInformation.setAccountHolderName(bankInfoDTO
                    .getAccountHolderName());
            bankInformation.setBankName(bankInfoDTO.getBankName());
            bankInformation.setBankAccountNumber(bankInfoDTO
                    .getBankAccountNumber());
            bankInformation.setBankRoutingNumber(bankInfoDTO
                    .getBankRoutingNumber());
            bankInformation.setBankStatus(bankInfoDTO.getBankStatus());

            // set the page.
            forwardPage = com.bcbssc.registration.common.Constants.FORWARD_SUCCESS;

            // dollars and cents.

            this.displayLog("bankInformation.getTotalBalanceDueDollars()="
                    + bankInformation.getTotalBalanceDueDollars());
            this.displayLog("bankInformation.getTotalBalanceDueCents()="
                    + bankInformation.getTotalBalanceDueCents());
            this.displayLog("bankInformation.getOtherBalanceDueDollars()="
                    + bankInformation.getOtherBalanceDueDollars());
            this.displayLog("bankInformation.getOtherBalanceDueCents()="
                    + bankInformation.getOtherBalanceDueCents());
            this.displayLog("bankInformation.isBalanceDueRadio()="
                    + bankInformation.isBalanceDueRadio());
            this.displayLog("bankInformation.getTotalBalanceDue()="
                    + bankInformation.getTotalBalanceDue());

        }

        /**
         * Put the necessary form bean into the request object. So that the
         * payment confirmation page can use those bean properties for display
         * in the web page.
         */
        request.setAttribute("bankInformationForm", bankInformation);

        /**
         * Then forward the success page to render in the web browser.
         */
        return mapping.findForward(forwardPage);
    }

    /**
     * This will send the inform with the confirmed payment details entered by
     * the Group Administrator.
     *
     * @param mapping
     *            the ActionMapping used to select this instance
     * @param form
     *            the bean for this request.
     * @param request
     *            the Http Request for processing.
     * @param response
     *            the Http Response we are creating.
     * @return Describes where and how control should be forwarded or the null
     *         if the response is alredy been completed.
     * @throws java.lang.Exception
     *             if application business logic throws an exception.
     */
    public ActionForward sendPaymentDetails(ActionMapping mapping,
            ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        this.displayLog("In sendPaymentDetails()");

        BankInformationForm bankInformation = (BankInformationForm) form;
        this.displayLog("bankInformation.getGroupNumber()="
                + bankInformation.getGroupNumber());
        /**
         * Create Bank Information Bean
         */
        InsuredDataDTO insuredDTO = new InsuredDataDTO();
        insuredDTO.setGroupNumber(bankInformation.getGroupNumber());
        AccountServices accountServices = new AccountServices(CommonUtils
                .getIniFile(this.getServlet()));
        BankInformationDTO bankInfoDTO = accountServices
                .getBankAccountDetails(insuredDTO);
        /**
         * Populate bank information details from DTO to form bean.
         */
        bankInformation
                .setAccountHolderName(bankInfoDTO.getAccountHolderName());
        bankInformation.setBankName(bankInfoDTO.getBankName());
        bankInformation
                .setBankAccountNumber(bankInfoDTO.getBankAccountNumber());
        bankInformation
                .setBankRoutingNumber(bankInfoDTO.getBankRoutingNumber());
        bankInformation.setBankStatus(bankInfoDTO.getBankStatus());
        /**
         * Generate Tracking number and populate it in the bankInformation.
         */
        bankInformation.setTrackingNumber(this.generateTrackingNumber());

        /**
         * This variable used to display in Payment Confirmation Page. Ex:
         * 06/06/2006 10:45 a.m.
         */
        String currentDateTime = this.getCurrentDateWithAMPM("MM/dd/yyyy hh:mm a");
        StringBuffer currentDateSB = new StringBuffer(20);

        /**
         * This variable used to display in INform Date Format: ccyymmdd.
         */
        String currentDate = "";
        currentDate = currentDateSB.append(currentDateTime.substring(6, 10))
                .append(currentDateTime.substring(0, 2)).append(
                        currentDateTime.substring(3, 5)).toString();
        String currentTime = currentDateTime.substring(8);
        bankInformation.setEntryDate(currentDate);
        bankInformation.setEntryTime(currentTime);
        bankInformation.setEntryDateTime(currentDateTime);

        if (BankInformationAction.log.isDebugEnabled()) {
            BankInformationAction.log.debug("currentDateTime="
                    + currentDateTime);
            BankInformationAction.log.debug("currentDate=" + currentDate);
            BankInformationAction.log.debug("currentTime=" + currentTime);
        }

        /**
         * Copy all the necessary properties from form bean to dto.
         */
        BeanUtils.copyProperties(bankInfoDTO, bankInformation);
        /**
         * Format the paid amount by removing the decimal point and populating
         * it back to bankInfoDTO, so that it will be available for MQ
         * transaction to send. For MQ we got to send all numbers with no
         * decimal point.
         */
        this.displayLog("bankInformation.getTotalBalanceDue()="
                + bankInformation.getTotalBalanceDue());
        String formattedPaidtAmount = this
                .getFormattedPaymentAmount(bankInfoDTO.getTotalBalanceDue());
        bankInfoDTO.setTotalBalanceDue(formattedPaidtAmount);

        /**
         * Need payment amount for Inform request line as it appears in the web
         * page with out dollar sign.(Ex: 122.22)
         */
        bankInfoDTO.setPaidBalanceforInform(bankInformation
                .getTotalBalanceDue());
        this.displayLog("Paid Amount format for Inform Request Line="
                + bankInfoDTO.getPaidBalanceforInform());

        /**
         * Send the W183 Transaction and Inform via the MQ.
         */
        InsuredServices insuredServices = new InsuredServices(
                CommonUtils.getIniFile(this.getServlet()),
                CommonUtils.getGcomIniFile(this.getServlet()),
                (GroupAdminUserDTO) request
                        .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
        insuredServices.sendPaymentInformation(bankInfoDTO, request);

        /**
         * Set the bankInformation in request object and then forward the
         * success page to render in the web browser.
         */
        request.setAttribute("bankInformationForm", bankInformation);
        return mapping
                .findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
    }

    /**
     * This will display the group selection page.
     *
     * @param mapping
     *            the ActionMapping used to select this instance
     * @param form
     *            the optional bean for this request (if any)
     * @param request
     *            the HTTP request we are processing
     * @param response
     *            the HTTP request we are creating
     * @return describes where and how control should be forwarded, or null if
     *         the response has already been completed.
     * @throws java.lang.Exception if any.
     */
    public ActionForward displayGroupSelection(ActionMapping mapping,
            ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        this.displayLog("In displayGroupSelection()");

        BankInformationForm bankInformation = (BankInformationForm) form;
        /**
         * Populate the user(GA) information.
         */
        bankInformation
                .setUserDTO((GroupAdminUserDTO) request
                        .getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));

        /**
         * Make it available this bankInformation bean in the request object.
         */
        request.setAttribute("bankInformationForm", bankInformation);

        return mapping.findForward(Constants.FORWARD_GROUP_SELECTION);
    }

    /**
     * This funtion will take the last balance due element which is the total
     * balance due for this group.
     *
     * @param bankInformation a {@link com.bcbssc.groupadmin.shared.forms.BankInformationForm} object.
     * @param coll a {@link java.util.Collection} object.
     * @return total balance due for this group.
     */
    public String getTotalBalanceDue(BankInformationForm bankInformation,
            Collection coll) {
        this.displayLog("In calculateTotalBalance()");
        /**
         * Take the last element(Total Balance) of the list of BillHistoryDTO
         * collection object.
         */
        BillHistoryDTO billHistoryDTO = new BillHistoryDTO();
        String totalBalanceDue = null;

        ArrayList outStandingBillsList = (ArrayList) coll;
        /**
         * Check for null outStandingBillsList
         */
        int billListSize = outStandingBillsList.size();
        if (!outStandingBillsList.isEmpty()
                && (outStandingBillsList.size() > 0)) {
            billHistoryDTO = (BillHistoryDTO) (outStandingBillsList
                    .get(billListSize - 1));
            totalBalanceDue = billHistoryDTO.getTotalDue().trim();
            this.displayLog("Total Balance Due from database="
                    + totalBalanceDue);
        }

        /**
         * If totalBalanceDue is empty or zero, then we need set that to "0.00"
         * and handle other radio button selection in the payment amount enter
         * jsp page.
         */
        if ((totalBalanceDue == null) || "".equals(totalBalanceDue)
                || "0.00".equals(totalBalanceDue)) {
            totalBalanceDue = "0.00";
        }
        this.displayLog("Balance after checking null and empty="
                + totalBalanceDue);

        /**
         * If negative dollar balance is there in the last transaction(Ex:
         * $-122.00), we need to put the dollar amount to '0.00'in the jsp front
         * end.
         */
        String totalBalanceDueForCheck = totalBalanceDue.substring(0,
                totalBalanceDue.length() - 3);
        this.displayLog("Balance before checking for negative balance = "
                + totalBalanceDueForCheck);
        if (Integer.parseInt(totalBalanceDueForCheck) <= 0) {
            this.displayLog("Negative balance=" + totalBalanceDue);
            totalBalanceDue = "0.00";
            // bankInformation.setBalanceDueRadio(false);
        }
        this.displayLog("Balance after checking for negative balance="
                + totalBalanceDue);

        // We need to set the dollar amount and cents amount seperately.
        // bankInformation.setTotalBalanceDue(totalBalanceDue);
        return totalBalanceDue;

    }

    /**
     * This will pupulate the bank account details for a perticular group.
     *
     * @param bankInformation a {@link com.bcbssc.groupadmin.shared.forms.BankInformationForm} object.
     * @throws java.lang.Exception if any.
     * @param groupOptions a {@link java.util.Collection} object.
     */
    public void populateBankAccountDetails(BankInformationForm bankInformation,
            Collection groupOptions) throws Exception {
        this.displayLog("In populateBankAccountDetails()");
        /**
         * Populate the group into bank information form bean
         * (BankInformationForm). Get the bank information details to get the
         * status of this group.
         */
        ArrayList dropdownList = (ArrayList) groupOptions;
        /**
         * Check for null collection and size. If the size is more than 1 then
         * only we should process this groups collection. Because this
         * collection is coming like below example. Ex: name and lable pairs. So
         * please choose one will be always there. LabelValueBean[-- Please
         * Choose One --, ] LabelValueBean[336 25 44148 000 NORTH OTTAWA
         * COMMUNITY HOSPITAL, 3362544148000|NORTH OTTAWA COMMUNITY
         * HOSPITAL|06/01/2005|04/01/2004|05/01/2005]
         */
        if ((dropdownList != null) && (dropdownList.size() > 1)) {

            this.displayLog("group size = " + dropdownList.size());
            this.displayLog("(String)dropdownList.get(1)="
                    + (dropdownList.get(1)).toString());
            /**
             * Instanciate the LabelValueBean with the second element which we
             * need. And get the value out of it and populate the group in the
             * bank info bean.
             */
            LabelValueBean availableGroup = (LabelValueBean) dropdownList
                    .get(1);
            this.displayLog("availableGroup.getValue()="
                    + availableGroup.getValue());
            bankInformation.setGroup(availableGroup.getValue());

            InsuredDataDTO insuredDTO = new InsuredDataDTO();
            this.displayLog("bankInformation.getGroupNumber() = "
                    + bankInformation.getGroupNumber());
            insuredDTO.setGroupNumber(bankInformation.getGroupNumber());

            /**
             * Create an account services object.
             */
            AccountServices accountServices = new AccountServices(CommonUtils
                    .getIniFile(this.getServlet()));
            /**
             * We will get the bean with bank account details.
             */
            BankInformationDTO bankInfoDTO = accountServices
                    .getBankAccountDetails(insuredDTO);

            /**
             * Populate bank information details to the bank form to display in
             * the front end.
             */
            bankInformation.setAccountHolderName(bankInfoDTO
                    .getAccountHolderName());
            bankInformation.setBankName(bankInfoDTO.getBankName());
            bankInformation.setBankAccountNumber(bankInfoDTO
                    .getBankAccountNumber());
            bankInformation.setBankRoutingNumber(bankInfoDTO
                    .getBankRoutingNumber());
            bankInformation.setBankStatus(bankInfoDTO.getBankStatus());

        }

    }

    /**
     * This will generate a numberic 9 digit number. Ex: two digit month + one
     * digit day + 6 digit seconds.
     *
     * @return generated tracking number.
     */
    private String generateTrackingNumber() {
        this.displayLog("In generateTrackingNumber()");
        /**
         * Use the last 10 digits from the system milli seconds which is a 13
         * digits number.
         */
        long timeInMilliSec = System.currentTimeMillis();
        String secondsStr = Long.toString(timeInMilliSec);
        this.displayLog("Generated Tracking Number = "
                + secondsStr.substring(3));
        return secondsStr.substring(3);
    }

    /**
     * Get the total balance in dollars and cents. Ex: 123.12 Now we need remove
     * the "." and send it to the MQ. Ex: 12312
     */
    private String getFormattedPaymentAmount(String paidAmount) {
        this.displayLog("In getFormattedPaymentAmount()");
        String dollars = StringUtils.split(paidAmount, ".")[0];
        String cents = StringUtils.split(paidAmount, ".")[1];
        this.displayLog("dollars + cents=" + dollars + cents);
        return dollars + cents;
    }

    /**
     * Get the activity code based on the comparision made between loaded bank
     * information in the session and current bank information bean. If loaded
     * data is blank that means CGA is adding new data then code is 'A' (Add) if
     * loaded data is not blank and is different then current data then the code
     * is 'C' (Change)
     */
    private String getActivityCode(BankInformationForm bankInformation,
            HttpServletRequest request) {
        this.displayLog("In getActivityCode():");
        String code = null;
        CGAUtilityBean groupLoadedBankDetails = (CGAUtilityBean) request
                .getSession().getAttribute("groupLoadedBankDetails");
        if (groupLoadedBankDetails == null) {
            groupLoadedBankDetails = new CGAUtilityBean();
        }

        this.displayLog("groupLoadedBankDetails="
                + groupLoadedBankDetails.toString());
        this.displayLog("groupLoadedBankDetails.getAccountHolderName()="
                + groupLoadedBankDetails.getAccountHolderName());
        this.displayLog("bankInformation.getAccountHolderName()="
                + bankInformation.getAccountHolderName());

        /*
         * Check for null or empty of each property. If all of them empty or
         * null Then consider they are adding new bank information.
         */
        if ((groupLoadedBankDetails.getAccountHolderName() == null)
                || ("".equals(groupLoadedBankDetails.getAccountHolderName()) && (groupLoadedBankDetails
                        .getBankAccountNumber() == null))
                || ("".equals(groupLoadedBankDetails.getBankAccountNumber()) && (groupLoadedBankDetails
                        .getBankName() == null))
                || ("".equals(groupLoadedBankDetails.getBankName()) && (groupLoadedBankDetails
                        .getBankRoutingNumber() == null))
                || "".equals(groupLoadedBankDetails.getBankRoutingNumber())) {
            // no intial values.
            code = Constants.ADD_ACTIVITY_CODE;
            this.displayLog("No existing bank info, then code=" + code);
        } else {
            // determine is there any change.
            if (!groupLoadedBankDetails.getAccountHolderName().equals(
                    bankInformation.getAccountHolderName())
                    || !groupLoadedBankDetails.getBankAccountNumber().equals(
                            bankInformation.getBankAccountNumber())
                    || !groupLoadedBankDetails.getBankName().equals(
                            bankInformation.getBankName())
                    || !groupLoadedBankDetails.getBankRoutingNumber().equals(
                            bankInformation.getBankRoutingNumber())) {
                // changed.
                code = Constants.CHANGE_ACTIVITY_CODE;
                this
                        .displayLog("Existing bank info changed, then code="
                                + code);
            } else {
                // not changed.
                /**
                 * Since the CGA want's to submit the information again, even
                 * though there is no change according to Colin Fairley we will
                 * set the code as change.
                 */
                code = Constants.CHANGE_ACTIVITY_CODE;
                this.displayLog("No change to existing bank info, then code="
                        + code);
            }
        }

        return code;
    }

    /**
     * Populate the CGAUtils bean with loaded bank details and set this bean
     * into the session. So we can use this bean to compare any bank info
     * changes the CGA has made later. Check this bean is already in session or
     * not, if in session we can make sure that the groupCount should be
     * preserved if it is already populated.
     *
     * @param bankInformation a {@link com.bcbssc.groupadmin.shared.forms.BankInformationForm} object.
     * @param request a {@link javax.servlet.http.HttpServletRequest} object.
     * @throws java.lang.Exception if any.
     */
    public void setGroupLoadedBankDetails(BankInformationForm bankInformation,
            HttpServletRequest request) throws Exception {

        this.displayLog("In setGroupLoadedBankDetails");
        CGAUtilityBean groupLoadedBankDetails = (CGAUtilityBean) request
                .getSession().getAttribute("groupLoadedBankDetails");
        if (groupLoadedBankDetails == null) {
            groupLoadedBankDetails = new CGAUtilityBean();
        }

        BeanUtils.copyProperties(groupLoadedBankDetails, bankInformation);
        // set the group count also.
        groupLoadedBankDetails.setGroupCount(Integer.toString(bankInformation
                .getGroupOptions().size()));
        this.displayLog("CGAUtilityBean:=" + groupLoadedBankDetails.toString());
        request.getSession().setAttribute("groupLoadedBankDetails",
                groupLoadedBankDetails);
    }

    /**
     * <p>validateForm.</p>
     *
     * @param form a {@link org.apache.struts.action.ActionForm} object.
     * @param request a {@link javax.servlet.http.HttpServletRequest} object.
     * @return a {@link org.apache.struts.action.ActionErrors} object.
     */
    public ActionErrors validateForm(ActionForm form, HttpServletRequest request) {

        this.displayLog("In validateForm()");
        BankInformationForm bankInformation = (BankInformationForm) form;
        this.displayLog("bankInformation.getFormName() = "
                + bankInformation.getFormName());

        if ((bankInformation.getFormName() != null)
                && !"".equals(bankInformation.getFormName())) {

            // Get the group property to validate.
            String group = bankInformation.getGroup().trim();

            if ("addPage".equals(bankInformation.getFormName())) {
                this.errors = new ActionErrors();
                // validate the group dropdown.
                if ((group == null) || "".equals(group)) {
                    this.errors.add("group", new ActionMessage(
                            "error.bankInformationForm.group.null"));
                }
                // validate other form fields.
                this.validateCommonFields(bankInformation, request);
            } else if ("errorPage".equals(bankInformation.getFormName())) {
                this.errors = new ActionErrors();
                this.validateCommonFields(bankInformation, request);
            } else if ("groupSelection".equals(bankInformation.getFormName())) {
                this.errors = new ActionErrors();
                // validate the group dropdown.
                if ((group == null) || "".equals(group)) {
                    this.errors.add("group", new ActionMessage(
                            "error.bankInformationForm.group.null"));
                }
            } else if ("paymentPage".equals(bankInformation.getFormName())) {
                boolean isBalanceRadio = bankInformation.isBalanceDueRadio();
                String paidBalance = bankInformation.getTotalBalanceDue()
                        .trim();
                this.errors = new ActionErrors();
                this.displayLog("isBalanceRadio=" + isBalanceRadio);
                this.displayLog("paidBalance=" + paidBalance);
                /**
                 * If other amount is selected, then we will validate other
                 * amount dollars and cents to be not empty and should be
                 * numbers.
                 */
                if (!isBalanceRadio) {
                    if ((paidBalance != null) && !"".equals(paidBalance)
                            && (paidBalance.length() >= 3)) {
                        String paidBalanceDollars = paidBalance.substring(0,
                                paidBalance.length() - 3);
                        String paidBalanceCents = paidBalance
                                .substring(paidBalance.length() - 2);
                        this.displayLog("paidBalanceDollars="
                                + paidBalanceDollars);
                        this.displayLog("paidBalanceCents=" + paidBalanceCents);
                        if ((paidBalanceDollars == null)
                                || "".equals(paidBalanceDollars)) {
                            this.displayLog("No amount");
                            this.errors
                                    .add(
                                            "otherBalanceDueDollars",
                                            new ActionMessage(
                                                    "error.bankInformationForm.otherBalanceDueDollars.null"));
                        } else if (!GenericValidator.isInt(paidBalanceDollars)
                                || !GenericValidator.isInt(paidBalanceCents)) {
                            this
                                    .displayLog("Either dollar amount or cents amount is not integer");
                            this.errors
                                    .add(
                                            "otherBalanceDueDollars",
                                            new ActionMessage(
                                                    "error.bankInformationForm.otherBalanceDueDollars.NotNumber"));
                        } else if (Integer.parseInt(paidBalanceDollars) <= 0) {
                            if (Integer.parseInt(paidBalanceCents) <= 0) {
                                this
                                        .displayLog("dollar and cents not greater than zero");
                                this.errors
                                        .add(
                                                "otherBalanceDueDollars",
                                                new ActionMessage(
                                                        "error.bankInformationForm.otherBalanceDueDollars.zero"));
                            }
                        } else if (Integer.parseInt(paidBalanceDollars) > 0) {
                            if (Integer.parseInt(paidBalanceCents) < 0) {
                                this
                                        .displayLog("dollar greater than zero but cents negative amount");
                                this.errors
                                        .add(
                                                "otherBalanceDueDollars",
                                                new ActionMessage(
                                                        "error.bankInformationForm.otherBalanceDueDollars.NotNumber"));
                            }
                        }

                    }

                }

            }
        }

        return this.errors;
    }

    /**
     * <p>validateCommonFields.</p>
     *
     * @param bankInformation a {@link com.bcbssc.groupadmin.shared.forms.BankInformationForm} object.
     * @param request a {@link javax.servlet.http.HttpServletRequest} object.
     */
    public void validateCommonFields(BankInformationForm bankInformation,
            HttpServletRequest request) {
        this.displayLog("In validateCommonFields()");
        String bankName = bankInformation.getBankName().trim();
        String bankRoutingNumber = bankInformation.getBankRoutingNumber()
                .trim();
        String bankRoutingNumberConfirm = bankInformation
                .getBankRoutingNumberConfirm().trim();
        String bankAccountNumber = bankInformation.getBankAccountNumber()
                .trim();
        String bankAccountNumberConfirm = bankInformation
                .getBankAccountNumberConfirm().trim();
        String accountHolderName = bankInformation.getAccountHolderName()
                .trim();

        // validate the bank name
        if ((bankName == null) || "".equals(bankName)) {
            this.errors.add("bankName", new ActionMessage(
                    "error.bankInformationForm.bankName.null"));
        } else if (!this.isBankNameValid(bankName)) {
            this.errors.add("bankName", new ActionMessage(
                    "error.bankInformationForm.bankName.inValid"));
        }

        // validate the bank routing number
        if ((bankRoutingNumber == null) || "".equals(bankRoutingNumber)) {
            this.errors.add("bankRoutingNumber", new ActionMessage(
                    "error.bankInformationForm.bankRoutingNumber.null"));
        } else if (!GenericValidator.isInt(bankRoutingNumber)) {
            this.errors.add("bankRoutingNumber", new ActionMessage(
                    "error.bankInformationForm.bankRoutingNumber.NotNumber"));
        }

        // validate the confirmed bank routing number.
        if ((bankRoutingNumberConfirm == null)
                || "".equals(bankRoutingNumberConfirm)) {
            this.errors.add("bankRoutingNumberConfirm", new ActionMessage(
                    "error.bankInformationForm.bankRoutingNumberConfirm.null"));
        } else if (!GenericValidator.isInt(bankRoutingNumberConfirm)) {
            this.errors
                    .add(
                            "bankRoutingNumberConfirm",
                            new ActionMessage(
                                    "error.bankInformationForm.bankRoutingNumberConfirm.NotNumber"));
        } else if ((bankRoutingNumber != null)
                && !bankRoutingNumber.equals(bankRoutingNumberConfirm)) {
            this.errors.add("bankRoutingNumberConfirm", new ActionMessage(
                    "error.bankInformationForm.bankRoutingNumberMismatch"));
        }

        // validate the bank account number.
        if ((bankAccountNumber == null) || "".equals(bankAccountNumber)) {
            this.errors.add("bankAccountNumber", new ActionMessage(
                    "error.bankInformationForm.bankAccountNumber.null"));
        } else if (!com.bcbssc.struts.common.CommonUtils
                .isAlphaNumeric(bankAccountNumber)) {
            this.errors
                    .add(
                            "bankAccountNumber",
                            new ActionMessage(
                                    "error.bankInformationForm.bankAccountNumber.alphanumeric"));
        }

        // validate the confirmed bank account number.
        if ((bankAccountNumberConfirm == null)
                || "".equals(bankAccountNumberConfirm)) {
            this.errors.add("bankAccountNumberConfirm", new ActionMessage(
                    "error.bankInformationForm.bankAccountNumberConfirm.null"));
        } else if ((bankAccountNumber != null)
                && !bankAccountNumber.equals(bankAccountNumberConfirm)) {
            this.errors.add("bankAccountNumberConfirm", new ActionMessage(
                    "error.bankInformationForm.bankAccountNumberMismatch"));
        }

        // validate the account holder's name.
        if ((accountHolderName == null) || "".equals(accountHolderName)) {
            this.errors.add("accountHolderName", new ActionMessage(
                    "error.bankInformationForm.accountHolderName.null"));
        } else if (!this.isAcctHolderNameValid(accountHolderName)) {
            this.errors
                    .add(
                            "accountHolderName",
                            new ActionMessage(
                                    "error.bankInformationForm.accountHolderName.numberExists"));
        }
    }

    /**
     * The given string should not contain number and it can contain a quote (')
     * or hyphen (-) which are part of special characters.
     *
     * @param v -
     *            String.
     * @return true or false.
     */
    private boolean isAcctHolderNameValid(String v) {
        this.displayLog("In isAcctHolderNameValid()");
        boolean flag = false;

        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            this.displayLog("character" + i + ": " + c);
            if (Character.isDigit(c)) {
                // It is a number, throw an error message.
                flag = false;
                break;
            }
            if (!this.isSpecialChar(c)) {
                // If not one of those special characters exists, then throw an
                // error message.
                flag = false;
                break;
            }
            flag = true;
        }
        return flag;
    }

    /**
     * Bank Name will alllow numbers, alpha characters, and few special
     * characters like ([']single quote, [-]hiphen, [ ]space).
     *
     * @param v
     * @return flag (true/false)
     */
    private boolean isBankNameValid(String v) {
        this.displayLog("In isBankNameValid()");
        boolean flag = false;
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            this.displayLog("character" + i + ": " + c);
            if (Character.isDigit(c)) {
                // It is a number, no error message.
                flag = true;
            } else {
                if (!this.isSpecialChar(c)) {
                    // If not one of those special characters exists, then throw
                    // an error message.
                    flag = false;
                    break;
                }
                flag = true;
            }
        }
        return flag;
    }

    /**
     * If it is a special character, then validate it with (')collan, (-)hiphen
     * and ( )space character If the char is not either one of those special
     * characters then throw an error message.
     *
     * @param c
     * @return flag. true: character allowed, false:character not allowed.
     */
    private boolean isSpecialChar(char c) {
        this.displayLog("In isSpecialChar");
        boolean flag = false;

        if (!Character.isLetter(c)) {
            if ((c != '-') && (c != '\'') && (c != ' ')) {
                flag = false;
            } else {
                flag = true;
            }
        } else {
            flag = true;
        }
        return flag;

    }

    private void displayLog(String logString) {
        if (BankInformationAction.log.isDebugEnabled()) {
            BankInformationAction.log.debug(logString);
        }
    }

    /**
     * Determine the validity of the bank account for this group. If any one of
     * the five fields are not available then the flag will be false. That
     * means, there is invalid bank information. This flag will be used in jsp
     * to show the related error message.
     */
    private boolean isBankAccountPresent(BankInformationForm bankInformation) {

        boolean baFlag = true;
        if (StringUtils.isEmpty(bankInformation.getAccountHolderName())
                || StringUtils.isEmpty(bankInformation.getBankName())
                || StringUtils.isEmpty(bankInformation.getBankAccountNumber())
                || StringUtils.isEmpty(bankInformation.getBankRoutingNumber())
                || StringUtils.isEmpty(bankInformation.getBankStatus())) {

            // No bank information available.
            this.displayLog("No or Insufficent Bank Account Information");
            baFlag = false;
            this.displayLog("bankAccountAvailableFlag=" + baFlag);
        }
        return baFlag;
    }

    /**
     * This will return the forwarded page attribute based on the bank
     * information availability flag and bank information web payment status
     * indicator.
     *
     * @param bankInformation
     * @return forwarding page.
     */
    private String getPageNavigation(BankInformationForm bankInformation) {
        String forwardingPage = "";
        if (!this.isBankAccountPresent(bankInformation)) {
            // this flag will be used in jsp to show the related error message.
            bankInformation.setBankAccountAvailableFlag(false);
            this.displayLog("Bank Account Available Flag = "
                    + bankInformation.getBankAccountAvailableFlag());
            forwardingPage = Constants.FORWARD_INVALID;
        } else {
            forwardingPage = this.getPageNavigationOnStatus(bankInformation
                    .getBankStatus());
        }
        return forwardingPage;
    }

    /**
     * This will provide the forwarding page(invalid / valid page) based on the
     * bank account status.
     *
     * @param bankAcctStatus
     * @return forwarding page.
     */
    private String getPageNavigationOnStatus(String bankAcctStatus) {
        String forwardingPage = "";
        if (Constants.INVALID_BANK_STATUS.equals(bankAcctStatus)
                || StringUtils.isEmpty(bankAcctStatus)) {
            this.displayLog("Invalid Bank Account");
            forwardingPage = Constants.FORWARD_INVALID;
        } else {
            this.displayLog("Valid Bank Account");
            forwardingPage = Constants.FORWARD_VALID;
        }
        return forwardingPage;
    }
    /**
     * <p>getCurrentDateWithAMPM.</p>
     *
     * @param strToFormat a {@link java.lang.String} object.
     * @return a {@link java.lang.String} object.
     */
    public String getCurrentDateWithAMPM(String strToFormat) {
		String foramttedStr = null;
		String ampmStr = null;
		StringBuffer strBuff = new StringBuffer(300);

		foramttedStr = new SimpleDateFormat(strToFormat).format(new Date());
		ampmStr = foramttedStr.substring(16).toLowerCase();
		log.debug("truncated am/pm string=" + ampmStr);

		foramttedStr = foramttedStr.substring(0, 17);
		log.debug("truncated date string=" + foramttedStr);

		strBuff.append(foramttedStr).append(ampmStr.charAt(1)).append(".")
				.append(ampmStr.charAt(2)).append(".");

		log.debug("result formatted date string=" + strBuff.toString());

		return strBuff.toString();
	}
}
