/*
 * @(#)InsuredDetailsForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.forms;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

/**
 * GroupAdmin Insured Details Form
 *
 * This bean provides data transport and validation for insured details forms
 * (add and modify)
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public abstract class InsuredDetailsForm extends InsuredSearchForm {

    /**
     * Clears the user-editable data fields for this form
     */
    public abstract void clear();

    /**
     * Getter for property dobMonth.
     *
     * @return Value of property dobMonth.
     */
    public String getDobMonth() {
        return this.dateOfBirth.getMonth();
    }

    /**
     * Getter for property dobDay.
     *
     * @return Value of property dobDay.
     */
    public String getDobDay() {
        return this.dateOfBirth.getDay();
    }

    /**
     * Getter for property dobYear.
     *
     * @return Value of property dobYear.
     */
    public String getDobYear() {
        return this.dateOfBirth.getYear();
    }

    /**
     * Setter for property dobMonth.
     *
     * @param value
     *            New value of property dobMonth.
     */
    public void setDobMonth(String value) {
        this.dateOfBirth.setMonth(value);
    }

    /**
     * Setter for property dobDay.
     *
     * @param value
     *            New value of property dobDay.
     */
    public void setDobDay(String value) {
        this.dateOfBirth.setDay(value);
    }

    /**
     * Setter for property dobYear.
     *
     * @param value
     *            New value of property dobYear.
     */
    public void setDobYear(String value) {
        this.dateOfBirth.setYear(value);
    }

    /**
     * Getter for property hireMonth.
     *
     * @return Value of property hireMonth.
     */
    public String getHireMonth() {
        return this.hireDate.getMonth();
    }

    /**
     * Getter for property hireDay.
     *
     * @return Value of property hireDay.
     */
    public String getHireDay() {
        return this.hireDate.getDay();
    }

    /**
     * Getter for property hireYear.
     *
     * @return Value of property hireYear.
     */
    public String getHireYear() {
        return this.hireDate.getYear();
    }

    /**
     * Setter for property hireMonth.
     *
     * @param value
     *            New value of property hireMonth.
     */
    public void setHireMonth(String value) {
        this.hireDate.setMonth(value);
    }

    /**
     * Setter for property hireDay.
     *
     * @param value
     *            New value of property hireDay.
     */
    public void setHireDay(String value) {
        this.hireDate.setDay(value);
    }

    /**
     * Setter for property hireYear.
     *
     * @param value
     *            New value of property hireYear.
     */
    public void setHireYear(String value) {
        this.hireDate.setYear(value);
    }

    /**
     * Gets the telephone area code
     *
     * @return telephone area code
     */
    public String getTelephoneNumberAreacode() {
        return this.telephoneNumber.getAreacode();
    }

    /**
     * Gets the telephone number prefix
     *
     * @return telephone number prefix
     */
    public String getTelephoneNumberPrefix() {
        return this.telephoneNumber.getPrefix();
    }

    /**
     * Gets the telephone number suffix
     *
     * @return telephone number suffix
     */
    public String getTelephoneNumberSuffix() {
        return this.telephoneNumber.getSuffix();
    }

    /**
     * Sets the telephone number area code directly
     *
     * @param value
     *            telephone number area code
     */
    public void setTelephoneNumberAreacode(String value) {
        this.telephoneNumber.setAreacode(value);
    }

    /**
     * Sets the telephone number prefix directly
     *
     * @param value
     *            telephone number prefix
     */
    public void setTelephoneNumberPrefix(String value) {
        this.telephoneNumber.setPrefix(value);
    }

    /**
     * Sets the telephone number suffix directly
     *
     * @param value
     *            telephone number suffix
     */
    public void setTelephoneNumberSuffix(String value) {
        this.telephoneNumber.setSuffix(value);
    }

    /**
     * {@inheritDoc}
     *
     * Validates the form.
     */
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {
        ActionErrors errors = super.validate(mapping, request);

        return errors;
    }
}
