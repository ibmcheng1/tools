/*
 * @(#)GroupAdminSetPermissionsAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.actions;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.services.GroupAdminSecureServices;
import com.bcbssc.registration.actions.SetPermissionsAction;
import com.bcbssc.registration.dto.UserDTO;
import com.bcbssc.registration.services.ISecureServices;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;

/**
 * Group Admin SetPermissionsAction Action
 *
 * This class provides an application specific implmentation of
 * SetPermissionsAction.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.1  $
 */
public final class GroupAdminSetPermissionsAction extends SetPermissionsAction {

	/**
	 * Creates an application-specific services object
	 *
	 * @return services object
	 */
	protected ISecureServices getServices() {
		// The servlet has the context that contains the ini file locations
		ActionServlet actionServlet = this.getServlet();
		String iniFile = CommonUtils.getIniFile(actionServlet);
		String tdsIniFile = CommonUtils.getTDSIniFile(actionServlet);
		return new GroupAdminSecureServices(iniFile, tdsIniFile);
	}

	/**
	 * {@inheritDoc}
	 *
	 *************************************************************************
	 * Process the specified HTTP request, and create the corresponding HTTP
	 * response (or forward to another web component that will create it).
	 * Return an <code>ActionForward</code> instance describing where and how
	 * control should be forwarded, or <code>null</code> if the response has
	 * already been completed.
	 * @exception Exception
	 *                if business logic throws an exception
	 */
	public ActionForward execute(UserDTO user, ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		request.setAttribute("user", user);
		return super.execute(user, mapping, form, request, response);
	}
}
