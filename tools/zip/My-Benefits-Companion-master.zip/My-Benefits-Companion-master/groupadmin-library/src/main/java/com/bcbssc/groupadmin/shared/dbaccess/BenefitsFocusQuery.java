/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/BenefitsFocusQuery.java_v  $
 * $Workfile:   BenefitsFocusQuery.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:04  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/BenefitsFocusQuery.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:14:04   EN80
 * Initial revision.
 * 
 *    Rev 1.3   Apr 28 2009 10:17:46   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.2   Sep 14 2006 17:43:04   rx08e
 * Changed to include the order by clause in the query.
 * 
 *    Rev 1.1   Sep 14 2006 13:07:04   rx08e
 * Changed to support access revoked path
 * 
 *    Rev 1.0   Sep 14 2006 09:38:44   rx08e
 * Initial revision.
 */

package com.bcbssc.groupadmin.shared.dbaccess;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * Provides querying of the Rules tables for access code using the date of birth
 * and ssn.
 *
 * @author x08e (Venugopal Anchoori)
 * @version $Id: $Id
 */
public class BenefitsFocusQuery extends AbstractDBSearch {

	/** The log4j logger for this class. */
	protected static Logger log = Logger.getLogger(BenefitsFocusQuery.class);

	HashMap accessDetails = new HashMap();

	/**
	 * Creates an <code>RulesQuery</code> and configures it with an INI file.
	 *
	 * @param iniFile
	 *            file path of the configuration INI file.
	 */
	public BenefitsFocusQuery(String iniFile) {
		super(iniFile, "RULES_TABLE");
	}

	/**
	 * Performs an SQL query to join the GROUPS and the ACCESS table to get the
	 * access Id for a specific group.
	 *
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 * @param lastSixSsn a {@link java.lang.String} object.
	 * @param dateOfBirth a {@link java.lang.String} object.
	 * @param lastName a {@link java.lang.String} object.
	 * @return a {@link java.util.HashMap} object.
	 */
	public HashMap getAccessCode(String lastSixSsn, String dateOfBirth,
			String lastName) throws SQLException {

		final StringBuffer sql = new StringBuffer(500);

		this.checkInit();

		sql.append(" SELECT ACCESS_CD, SYS_VOID_STS_IND FROM ").append(
				this._dbSchema).append(".DT_TYP_WEB_ID ").append(" WHERE ")
				.append(" LAST_SIX_DGTS_SSN = '").append(lastSixSsn)
				.append("'").append(" AND DATE_OF_BIRTH = '").append(
						dateOfBirth).append("'");
		if (StringUtils.isNotBlank(lastName)) {
			sql.append(" AND LAST_NAME = '").append(lastName).append("' ");
		}
		sql.append(" ORDER BY DT_TYP_TM_STMP DESC ");
		sql.append(" FETCH FIRST 1 ROW ONLY ");

		if (BenefitsFocusQuery.log.isDebugEnabled()) {
			BenefitsFocusQuery.log
					.debug("SQL statement to get Access Code for given SSN, DOB and Group Number : ");
			BenefitsFocusQuery.log.debug(sql.toString());
		}

		this.performSearch(sql.toString(), this.accessDetails);
		return this.accessDetails;
	}

	/*
	 * This method is used to return the results retrived from the query by
	 * looking up the WEB_ID table. with the input as lastName, date of birth
	 * and SSN. @param data ResultSet of the executed query @param obj Object in
	 * which the results could be packed and sent across.
	 */
	/** {@inheritDoc} */
	protected void addSearchItem(ResultSet data, Object obj)
			throws SQLException {
		this.accessDetails = (HashMap) obj;
		String accessId = data.getString("ACCESS_CD").trim();
		String voidIndicator = data.getString("SYS_VOID_STS_IND").trim();
		this.accessDetails.put("ACCESS_CODE", accessId);
		this.accessDetails.put("VOID_INDICATOR", voidIndicator);
	}
}
