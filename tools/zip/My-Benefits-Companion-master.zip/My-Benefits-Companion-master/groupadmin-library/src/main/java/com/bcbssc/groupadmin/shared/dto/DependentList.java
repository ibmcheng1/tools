/*
 * @(#)DependentList.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.dto;

import java.util.ArrayList;

/**
 * GroupAdmin Dependent List
 *
 * This class represents a strictly ordered list of dependents.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class DependentList extends StrictlyOrderedArrayList {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2837793772289229008L;

	/**
	 * <p>createArrayObject.</p>
	 *
	 * @return a {@link java.lang.Object} object.
	 */
	protected Object createArrayObject() {
		return new Dependent();
	}

	/**
	 * Constructor; creates an empty DependentList
	 */
	public DependentList() {
		super();
	}

	/**
	 * Constructor; creates a DependentList with data
	 *
	 * @param list
	 *            list containing data for new DependentList
	 */
	public DependentList(ArrayList list) {
		super(list);
	}

	/**
	 * Gets a dependent from the DependentList, creating intermediate objects if
	 * needed
	 *
	 * @param index
	 *            index of the item to get
	 * @return item at the specified index
	 */
	public Dependent getDependent(int index) {
		return (Dependent) super.get(index);
	}

	/**
	 * Determines if a dependent has changed
	 *
	 * @return true if a dependnet has changed, false otherwise
	 */
	public boolean dependentChanged() {
		boolean changed = false;

		for (int i = 0; i < this.size(); i++) {
			Dependent dependent = (Dependent) this.get(i);
			if (dependent.isChanged()) {
				changed = true;
				break;
			}
		}

		return changed;
	}
}
