/*
 * @(#)TechnicalHelpFormDTO.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.dto;

/**
 * Form Data Transfer Object for the Technical Help Form
 *
 * This bean transports data between the technical help action and services.
 * attributes of this form correspond directly to the technicalHelpForm
 * form-bean defined in the struts-config.xml file.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class TechnicalHelpFormDTO {

	/** user name */
	private String samAccountName = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** city */
	private String city = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** email confirmation */
	private String confirmMail = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** first name */
	private String givenName = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** last name */
	private String lastName = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** email address */
	private String mail = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** postal code */
	private String postalCode = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** country code */
	private String country = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** state name */
	private String state = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** first line of address */
	private String street = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** telephone number */
	private String telephoneNumber = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** technical help question */
	private String helpQuestion = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** technical help reason (e.g., access revoked) */
	private String reason = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** group number */
	private String groupNumber = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** access code */
	private String accessCode = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** * */

	/** middle initial */
	private String middleIni = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** suffix of name */
	private String suffix = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** date of birth */
	private String dateOfBirth = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** last 6 digits of social security number */
	private String last6SSN = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** second line of address */
	private String addressLine2 = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** telephone extension */
	private String telephoneExt = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/** fax number */
	private String fax = com.bcbssc.struts.common.Constants.BLANK_STRING;

	/**
	 * Sets the user name
	 *
	 * @param value
	 *            user name
	 */
	public void setSamAccountName(String value) {
		this.samAccountName = value;
	}

	/**
	 * Gets the user name
	 *
	 * @return user name
	 */
	public String getSamAccountName() {
		return this.samAccountName;
	}

	/**
	 * Sets the last name
	 *
	 * @param value
	 *            last name
	 */
	public void setLastName(String value) {
		this.lastName = value;
	}

	/**
	 * Gets the last name
	 *
	 * @return last name
	 */
	public String getLastName() {
		return this.lastName;
	}

	/**
	 * Sets the first name
	 *
	 * @return first name
	 */
	public String getGivenName() {
		return this.givenName;
	}

	/**
	 * Gets the first name
	 *
	 * @param value
	 *            first name
	 */
	public void setGivenName(String value) {
		this.givenName = value;
	}

	/**
	 * Sets the middle initial
	 *
	 * @param value
	 *            middle initial
	 */
	public void setMiddleIni(String value) {
		this.middleIni = value;
	}

	/**
	 * Gets the middle initial
	 *
	 * @return middle initial
	 */
	public String getMiddleIni() {
		return this.middleIni;
	}

	/**
	 * Sets the suffix of name
	 *
	 * @param value
	 *            suffix of name
	 */
	public void setSuffix(String value) {
		this.suffix = value;
	}

	/**
	 * Gets the suffix of name
	 *
	 * @return suffix of name
	 */
	public String getSuffix() {
		return this.suffix;
	}

	/**
	 * Gets the date of birth
	 *
	 * @return date of birth
	 */
	public String getDateOfBirth() {
		return this.dateOfBirth;
	}

	/**
	 * Sets the date of birth
	 *
	 * @param value
	 *            date of birth
	 */
	public void setDateOfBirth(String value) {
		this.dateOfBirth = value;
	}

	/**
	 * Sets the last 6 digits of social security number
	 *
	 * @param value
	 *            last 6 digits of social security number
	 */
	public void setLast6SSN(String value) {
		this.last6SSN = value;
	}

	/**
	 * Gets the last 6 digits of social security number
	 *
	 * @return last 6 digits of social security number
	 */
	public String getLast6SSN() {
		return this.last6SSN;
	}

	/**
	 * Gets the first line of address
	 *
	 * @return first line of address
	 */
	public String getStreet() {
		return this.street;
	}

	/**
	 * Sets the first line of address
	 *
	 * @param value
	 *            first line of address
	 */
	public void setStreet(String value) {
		this.street = value;
	}

	/**
	 * Gets the second line of address
	 *
	 * @return second line of address
	 */
	public String getAddressLine2() {
		return this.addressLine2;
	}

	/**
	 * Sets the second line of address
	 *
	 * @param value
	 *            second line of address
	 */
	public void setAddressLine2(String value) {
		this.addressLine2 = value;
	}

	/**
	 * Gets the city name
	 *
	 * @return city name
	 */
	public String getCity() {
		return this.city;
	}

	/**
	 * Gets the city name
	 *
	 * @param value
	 *            city name
	 */
	public void setCity(String value) {
		this.city = value;
	}

	/**
	 * Gets the state name
	 *
	 * @return state name
	 */
	public String getState() {
		return this.state;
	}

	/**
	 * Sets the state name
	 *
	 * @param value
	 *            state name
	 */
	public void setState(String value) {
		this.state = value;
	}

	/**
	 * Gets the postal code
	 *
	 * @return postal code
	 */
	public String getPostalCode() {
		return this.postalCode;
	}

	/**
	 * Sets the postal code
	 *
	 * @param value
	 *            postal code
	 */
	public void setPostalCode(String value) {
		this.postalCode = value;
	}

	/**
	 * Gets the country code
	 *
	 * @return country code
	 */
	public String getCountry() {
		return this.country;
	}

	/**
	 * Sets the country code
	 *
	 * @param value
	 *            country code
	 */
	public void setCountry(String value) {
		this.country = value;
	}

	/**
	 * Gets the email address
	 *
	 * @return email address
	 */
	public String getMail() {
		return this.mail;
	}

	/**
	 * Sets the email address
	 *
	 * @param value
	 *            email address
	 */
	public void setMail(String value) {
		this.mail = value;
	}

	/**
	 * Gets the email confirmation
	 *
	 * @return email confirmation
	 */
	public String getConfirmMail() {
		return this.confirmMail;
	}

	/**
	 * Sets the email confirmation
	 *
	 * @param value
	 *            email confirmation
	 */
	public void setConfirmMail(String value) {
		this.confirmMail = value;
	}

	/**
	 * Gets the telephone number
	 *
	 * @return telephone number
	 */
	public String getTelephoneNumber() {
		return this.telephoneNumber;
	}

	/**
	 * Sets the telephone number
	 *
	 * @param value
	 *            telephone number
	 */
	public void setTelephoneNumber(String value) {
		this.telephoneNumber = value;
	}

	/**
	 * Gets the telephone extension
	 *
	 * @return telephone extension
	 */
	public String getTelephoneExt() {
		return this.telephoneExt;
	}

	/**
	 * Sets the telephone extension
	 *
	 * @param value
	 *            telephone extension
	 */
	public void setTelephoneExt(String value) {
		this.telephoneExt = value;
	}

	/**
	 * Gets the fax number
	 *
	 * @return fax number
	 */
	public String getFax() {
		return this.fax;
	}

	/**
	 * Sets the fax number
	 *
	 * @param value
	 *            fax number
	 */
	public void setFax(String value) {
		this.fax = value;
	}

	/**
	 * Gets the technical help question
	 *
	 * @return technical help question
	 */
	public String getHelpQuestion() {
		return this.helpQuestion;
	}

	/**
	 * Sets the technical help question
	 *
	 * @param value
	 *            technical help question
	 */
	public void setHelpQuestion(String value) {
		this.helpQuestion = value;
	}

	/**
	 * Gets the technical help reason
	 *
	 * @return technical help reason
	 */
	public String getReason() {
		return this.reason;
	}

	/**
	 * Sets the technical help reason
	 *
	 * @param value
	 *            technical help reason
	 */
	public void setReason(String value) {
		this.reason = value;
	}

	/**
	 * Gets the group number
	 *
	 * @return group number
	 */
	public String getGroupNumber() {
		return this.groupNumber;
	}

	/**
	 * Sets the group number
	 *
	 * @param value
	 *            technical group number
	 */
	public void setGroupNumber(String value) {
		this.groupNumber = value;
	}

	/**
	 * Gets the access code
	 *
	 * @return access code
	 */
	public String getAccessCode() {
		return this.accessCode;
	}

	/**
	 * Sets the access code
	 *
	 * @param value
	 *            access code
	 */
	public void setAccessCode(String value) {
		this.accessCode = value;
	}
}
