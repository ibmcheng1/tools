/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mq/RetrySender.java_v  $
 * $Workfile:   RetrySender.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:16:18  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mq/RetrySender.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:16:18   EN80
 * Initial revision.
 * 
 *    Rev 1.2   Apr 28 2009 10:20:26   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.1   Mar 18 2005 12:59:50   rdq70
 * BlueHammur changes.
 *
 *    Rev 1.0   Mar 04 2005 10:56:24   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.mq;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.apache.log4j.RollingFileAppender;

/**
 * Attempts to re-send failed messages.
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class RetrySender {
	/** The log4j logger for this class. */
	private static final Logger log = Logger.getLogger(RetrySender.class);

	/** The base file path of error logs. */
	private String baseFileName;

	/** The maximum file name index. */
	private int maxFileIndex;

	/** The messanger used to send messages. */
	GcomMessenger messenger;

	/**
	 * Creates a new RetrySender object.
	 *
	 * @param messenger
	 *            the messanger to use to send messages.
	 * @param appender
	 *            the log4j appender that handles message errors.
	 */
	public RetrySender(GcomMessenger messenger, RollingFileAppender appender) {
		this.messenger = messenger;
		this.baseFileName = appender.getFile();
		this.maxFileIndex = appender.getMaxBackupIndex();
	}

	/**
	 * Attempts to re-send failed MQ messages.
	 */
	public void resendFiles() {
		for (int i = 1; i <= this.maxFileIndex; i++) {
			StringBuffer buf = new StringBuffer(100);
			buf.append(this.baseFileName).append(".").append(i);
			File file = new File(buf.toString());

			if (file.exists()) {
				this.retryFile(file);
			}
		}
	}

	/**
	 * Attempts to re-send the MQ message in the given file.
	 * 
	 * @param file -
	 *            the file with the message contents.
	 */
	private void retryFile(File file) {
		BufferedInputStream inStream = null;

		try {
			inStream = new BufferedInputStream(new FileInputStream(file));
			int datum = inStream.read();
			StringBuffer buf = new StringBuffer(2000);

			while (datum >= 0) {
				buf.append((char) datum);
				datum = inStream.read();
			}

			final String message = buf.toString();

			try {
				inStream.close();
				inStream = null;
			} finally {
				this.messenger.sendMessage(message, true);
				this.archive(file, message);

				if (RetrySender.log.isDebugEnabled()) {
					RetrySender.log.debug("Successfully re-sent message:");
					RetrySender.log.debug(message);
				}
			}
		} catch (Exception e) {
			RetrySender.log.error("Error trying to re-send "
					+ file.getAbsolutePath(), e);
		} finally {
			if (inStream != null) {
				try {
					inStream.close();
				} catch (Exception e) {
					RetrySender.log.info("Exception closing read-only file", e);
				}
			}
		}
	}

	/**
	 * Archives the error file that was re-sent.
	 * 
	 * @param file -
	 *            the error file.
	 * @param message -
	 *            the contents of the file.
	 */
	private void archive(File file, String message) {
		boolean renamed = false;

		try {
			File dir = new File(file.getParent(), "archives");
			if (!dir.exists()) {
				dir.mkdir();
			}

			File archive = File.createTempFile("resent", ".log", dir);
			archive.delete();
			file.renameTo(archive);
			renamed = true;
		} catch (IOException e) {
			RetrySender.log.error("Error archiving file:", e);
		} finally {
			if (!renamed) {
				file.delete();
			}
		}
	}
}
