/*
 *
 * @(#)Constants.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.common;

import java.util.ResourceBundle;

/**
 * Group Administration Application Constants
 *
 * @author Jonathan Egger
 * @version $Revision:   1.1  $
 */
public class Constants extends com.bcbssc.registration.common.Constants {
    /** Constant <code>clientConfigurationResources</code> */
    protected static ResourceBundle clientConfigurationResources = ResourceBundle.getBundle("ClientConfiguration");
    /**
     * General Logger or Category used in conjunction with log4j
     */
    public static final String GENERAL_CATEGORY = "GENERAL";

    /**
     * Config file/Servlet context iniFile parameter name
     */
    public static final String TDS_INIFILE_PARAMETER_NAME = "tdsIniFile";
    
    /** Constant <code>TDS_SU_INIFILE_PARAMETER_NAME="tdsSuperUserIniFile"</code> */
    public static final String TDS_SU_INIFILE_PARAMETER_NAME = "tdsSuperUserIniFile";
    /**
     * Config file/Servlet context iniFile parameter name
     */
    public static final String INIFILE_PARAMETER_NAME = "iniFile";

    /**
     * Config file/Servlet context sslIniFile parameter name
     */
    public static final String SSL_INI_PARAMETER_NAME = "sslIniFile";

    /**
     * Config file/Servlet context iniFile parameter name
     */
    public static final String NATL_INI_PARAMETER_NAME = "nationalIniFile";

    /**
     * Config file/Servlet context sslIniFile parameter name
     */
    public static final String NATL_SSL_INI_PARAMETER_NAME = "nationalSslIniFile";

    /**
     * Config file/Servlet context gcomIniFile parameter name
     */
    public static final String GCOM_INI_PARAMETER_NAME = "gcomIniFile";
    
    
    /**
     * Update role label in LDAP INI.
     */
    public static final String INI_UPDATE_ROLE = "UPDATE_ROLE";

    /**
     * Read-only role label in LDAP INI.
     */
    public static final String INI_READ_ONLY_ROLE = "READ_ONLY_ROLE";

    /**
     * Pay role lable (C-3) in the CGA.INI file for using to update the LDAP.
     */
    public static final String INI_PAY_ROLE = "PAY_ROLE";

    /**
     * Pay role lable (C-4) in the CGA.INI file for using to add AddNewGroup.
     */
    public static final String INI_GRP_ROLE = "GRP_ROLE";

    /**
     * Core Role used for the benefits coordinator ( this is also the default
     * role ).
     */
    public static final String ROLE_CORE = "CORE";

    /**
     * Blues Enroll used for the benefits coordinator.
     */
    public static final String ROLE_BLUESENROLL = "BLUESENROLL";

    /**
     * E-Bill used for the benefits coordinator.
     */
    public static final String ROLE_EBILL = "EBILL";

    /**
     * Application Role defined in the ini file.
     */
    public static final String INI_ROLE_CORE = "APP_ROLE";

    /**
     * Blues Enroll defined in the ini file.
     */
    public static final String INI_ROLE_BLUESENROLL = "BLUES_ENROLL";

    /**
     * E Bill definition in the ini file.
     */
    public static final String INI_ROLE_EBILL = "E_BILL";

    /**
     * Application Role defined in the ini file.
     */
    public static final String DENTAL_INI_ROLE_CORE = "DENTAL_APP_ROLE";

    /**
     * Blues Enroll defined in the ini file.
     */
    public static final String DENTAL_INI_ROLE_BLUESENROLL = "DENTAL_BLUES_ENROLL";

    /**
     * E Bill definition in the ini file.
     */
    public static final String DENTAL_INI_ROLE_EBILL = "DENTAL_E_BILL";

    /**
     * Modify Profile role definition in the ini file.
     */
    public static final String MODIFY_PROFILE = "MODIFY_PROFILE";

    /**
     * End to end monitor role definition in the ini file.
     */
    public static final String MONITOR_ROLE = "TOPAZ_MONITOR";

    /**
     * Pay role in the Rules table.
     */
    public static final String DB_GRP_ROLE = "GRP";

    /**
     * Pay role in the Rules table.
     */
    public static final String DB_PAY_ROLE = "PAY";

    /**
     * Update role in the Rules table.
     */
    public static final String DB_UPDATE_ROLE = "UPD";

    /**
     * Read-only role in the Rules table.
     */
    public static final String DB_READ_ONLY_ROLE = "INQ";

    /**
     * Activity Codes for the MQ Transaction regarding bank information add or
     * change.
     */
    public static final String ADD_ACTIVITY_CODE = "A";

    /** Constant <code>CHANGE_ACTIVITY_CODE="C"</code> */
    public static final String CHANGE_ACTIVITY_CODE = "C";

    /** This is the Invalid Bank WEB Payment Status for a CGA's Group */
    public static final String INVALID_BANK_STATUS = "9";

    /*
     * MISC Section of the ini File
     */
    /** Constant <code>MISC_SECTION="MISC"</code> */
    public static final String MISC_SECTION = "MISC";

    /*
     * The ldap attribute to have the application name
     */
    /** Constant <code>BCBSSC_GROUP="bcbsgroup"</code> */
    public static final String BCBSSC_GROUP = "bcbsgroup";

    /*
     * The name of the filed defined in the ini file.
     */
    /** Constant <code>INI_APP_NAME="APP_NAME"</code> */
    public static final String INI_APP_NAME = "APP_NAME";

    /*
     * This is used to determine any error with the benefits focus
     */
    /** Constant <code>BENEFITS_DECRYPT_ERROR="decrypt_error"</code> */
    public static final String BENEFITS_DECRYPT_ERROR = "decrypt_error";

    /*
     * This is to define the comma delimiter
     */
    /** Constant <code>SEMICOLON_DELIMITER=";"</code> */
    public static final String SEMICOLON_DELIMITER = ";";

    /**
     * Max authentication attempts before lockout
     */
    public static final int MAX_AUTHENTICATE_ATTEMPTS = 3;

    /**
     * Max challengeattempts before lockout
     */
    public static final int MAX_REAUTHENTICATE_ATTEMPTS = 3;

    /**
     * Service return values
     */
    public static final int SERVICE_SECURITY_ERROR = -2;

    /** Constant <code>SERVICE_INVALID=-1</code> */
    public static final int SERVICE_INVALID = -1;

    /** Constant <code>SERVICE_VALID=0</code> */
    public static final int SERVICE_VALID = 0;

    /**
     * Additional authenticate/reauthenticate service return values
     */
    public static final int INVALID_ANSWER = 3;

    /** Constant <code>ACCESS_REVOKED=4</code> */
    public static final int ACCESS_REVOKED = 4;

    /** Constant <code>SERVICE_MULTIPLE_MATCH=5</code> */
    public static final int SERVICE_MULTIPLE_MATCH = 5;

    /**
     * Validation service return values
     */
    public static final int ACCOUNT_EXISTS = 1;

    /** Constant <code>ACCOUNT_EXPIRED=2</code> */
    public static final int ACCOUNT_EXPIRED = 2;

    /**
     * Action servlet forward mapping values
     */
    public static final String FORWARD_INVALID_ANSWER = "invalid_answer";

    /** Constant <code>FORWARD_ACCESS_REVOKED="access_revoked"</code> */
    public static final String FORWARD_ACCESS_REVOKED = "access_revoked";

    /** Constant <code>FORWARD_INVALID_CREDENTIALS="invalid_credentials"</code> */
    public static final String FORWARD_INVALID_CREDENTIALS = "invalid_credentials";

    /** Constant <code>FORWARD_NOTFOUND="notfound"</code> */
    public static final String FORWARD_NOTFOUND = "notfound";

    /** Constant <code>FORWARD_MULTIPLE_MATCH="multiple_match"</code> */
    public static final String FORWARD_MULTIPLE_MATCH = "multiple_match";

    /** Constant <code>FORWARD_VALID="valid"</code> */
    public static final String FORWARD_VALID = "valid";

    /** Constant <code>FORWARD_INVALID="invalid"</code> */
    public static final String FORWARD_INVALID = "invalid";

    /** Constant <code>FORWARD_GROUP_SELECTION="groupSelection"</code> */
    public static final String FORWARD_GROUP_SELECTION = "groupSelection";

    /** Constant <code>FORWARD_BANK_CONFIRM_FOR_PAY="bankConfirmFromPayEntry"</code> */
    public static final String FORWARD_BANK_CONFIRM_FOR_PAY = "bankConfirmFromPayEntry";

    /** Constant <code>FORWARD_BANK_CONFIRM="bankConfirm"</code> */
    public static final String FORWARD_BANK_CONFIRM = "bankConfirm";

    /**
     * Date format used by SQL.
     */
    public static final String SQL_DATE_FORMAT = "yyyy-MM-dd";

    /**
     * Date format to be displayed on the mainframe.
     */
    public static final String WEBPACK_DATE_FORMAT = "yyyy-MM-dd";

    /**
     * Date format to be used on form displays
     */
    public static final String DISPLAY_DATE_FORMAT = "MM/dd/yyyy";

    /**
     * Insured Status Values
     */
    public static final String STATUS_ACTIVE = "1";

    /** Constant <code>STATUS_CONVERSION="3"</code> */
    public static final String STATUS_CONVERSION = "3";

    /** Constant <code>STATUS_PENDED="4"</code> */
    public static final String STATUS_PENDED = "4";

    /** Constant <code>STATUS_INACTIVE="9"</code> */
    public static final String STATUS_INACTIVE = "9";

    /** Constant <code>STATUS_ALL="1,9"</code> */
    public static final String STATUS_ALL = "1,9";

    /**
     * Bill status values
     */
    public static final String BILL_BILLED = "0";

    /** Constant <code>BILL_PARTIAL="1"</code> */
    public static final String BILL_PARTIAL = "1";

    /** Constant <code>BILL_NOT_CLEARED="2"</code> */
    public static final String BILL_NOT_CLEARED = "2";

    /** Constant <code>BILL_PAID="3"</code> */
    public static final String BILL_PAID = "3";

    /**
     * Pay Period Values
     */
    public static final String PAY_PERIOD_WEEKLY = "52";

    /** Constant <code>PAY_PERIOD_BI_WEEKLY="26"</code> */
    public static final String PAY_PERIOD_BI_WEEKLY = "26";

    /** Constant <code>PAY_PERIOD_SEMI_MONTHLY="24"</code> */
    public static final String PAY_PERIOD_SEMI_MONTHLY = "24";

    /** Constant <code>PAY_PERIOD_MONTHLY="12"</code> */
    public static final String PAY_PERIOD_MONTHLY = "12";

    /**
     * Product Values
     */
    public static final String PRODUCT_LIFE = "LIFE";

    /** Constant <code>PRODUCT_DENTAL="DNTL"</code> */
    public static final String PRODUCT_DENTAL = "DNTL";

    /** Constant <code>PRODUCT_VISION="VISN"</code> */
    public static final String PRODUCT_VISION = "VISN";

    /** Constant <code>PRODUCT_STD="STD"</code> */
    public static final String PRODUCT_STD = "STD";

    /** Constant <code>PRODUCT_LTD="LTD"</code> */
    public static final String PRODUCT_LTD = "LTD";

    /** Constant <code>PRODUCT_VOLUNTARY="ALL"</code> */
    public static final String PRODUCT_VOLUNTARY = "ALL";

    /*
     * Coverage codes
     */
    /** Constant <code>COVERAGE_LIFE="LIFE"</code> */
    public static final String COVERAGE_LIFE = "LIFE";

    /** Constant <code>COVERAGE_LIFE_DEPENDENT="DEPE"</code> */
    public static final String COVERAGE_LIFE_DEPENDENT = "DEPE";

    /** Constant <code>COVERAGE_LIFE_VOLUNTARY="VLIF"</code> */
    public static final String COVERAGE_LIFE_VOLUNTARY = "VLIF";

    /** Constant <code>COVERAGE_LIFE_VOLUNTARY_SPOUSE="VSPS"</code> */
    public static final String COVERAGE_LIFE_VOLUNTARY_SPOUSE = "VSPS";

    /** Constant <code>COVERAGE_LIFE_VOLUNTARY_SPOUSE_MALE="VSPM"</code> */
    public static final String COVERAGE_LIFE_VOLUNTARY_SPOUSE_MALE = "VSPM";

    /** Constant <code>COVERAGE_LIFE_VOLUNTARY_SPOUSE_FEMALE="VSPF"</code> */
    public static final String COVERAGE_LIFE_VOLUNTARY_SPOUSE_FEMALE = "VSPF";

    /** Constant <code>COVERAGE_LIFE_VOLUNTARY_CHILD="VCHI"</code> */
    public static final String COVERAGE_LIFE_VOLUNTARY_CHILD = "VCHI";

    public static final String COVERAGE_AD_D = "AD&D";

    /** Constant <code>COVERAGE_AD_D_CL="ADCL"</code> */
    public static final String COVERAGE_AD_D_CL = "ADCL";

    /** Constant <code>COVERAGE_AD_D_VOLUNTARY="VADD"</code> */
    public static final String COVERAGE_AD_D_VOLUNTARY = "VADD";

    /** Constant <code>COVERAGE_AD_D_VOLUNTARY_SPOUSE="VADS"</code> */
    public static final String COVERAGE_AD_D_VOLUNTARY_SPOUSE = "VADS";

    /** Constant <code>COVERAGE_AD_D_VOLUNTARY_FEMALE="VADF"</code> */
    public static final String COVERAGE_AD_D_VOLUNTARY_FEMALE = "VADF";

    /** Constant <code>COVERAGE_AD_D_VOLUNTARY_MALE="VADM"</code> */
    public static final String COVERAGE_AD_D_VOLUNTARY_MALE = "VADM";

    /** Constant <code>COVERAGE_AD_D_SU="SUAD"</code> */
    public static final String COVERAGE_AD_D_SU = "SUAD";

    /** Constant <code>COVERAGE_AD_D_SU_FEMALE="SADF"</code> */
    public static final String COVERAGE_AD_D_SU_FEMALE = "SADF";

    /** Constant <code>COVERAGE_AD_D_SU_MALE="SADM"</code> */
    public static final String COVERAGE_AD_D_SU_MALE = "SADM";
    
    /** Constant <code>LDAP_PROPERTIES="ldap.properties"</code> */
    public static final String LDAP_PROPERTIES = "ldap.properties";

    /** Constant <code>EXCEPTION="EXCEPTION"</code> */
    public static final String EXCEPTION = "EXCEPTION";
    
    /** Constant <code>APPLICATION_CONFIG_CLIFE_ID="clientConfigurationResources.getString("{trunked}</code> */
    public static final String APPLICATION_CONFIG_CLIFE_ID = clientConfigurationResources.getString("clientconfiguration.clife.id");
    /** Constant <code>APPLICATION_CONFIG_CHC_ID="clientConfigurationResources.getString("{trunked}</code> */
    public static final String APPLICATION_CONFIG_CHC_ID = clientConfigurationResources.getString("clientconfiguration.chc.id");
    /** Constant <code>APPLICATION_CONFIG_FCL_ID="clientConfigurationResources.getString("{trunked}</code> */
    public static final String APPLICATION_CONFIG_FCL_ID = clientConfigurationResources.getString("clientconfiguration.fcl.id");
    /** Constant <code>APPLICATION_CONFIG_HEALTHNET_ID="clientConfigurationResources.getString("{trunked}</code> */
    public static final String APPLICATION_CONFIG_HEALTHNET_ID = clientConfigurationResources.getString("clientconfiguration.healthnet.id");
    /** Constant <code>APPLICATION_CONFIG_BCBSSC_ID="clientConfigurationResources.getString("{trunked}</code> */
    public static final String APPLICATION_CONFIG_BCBSSC_ID = clientConfigurationResources.getString("clientconfiguration.bcbssc.id");
    
    /** Constant <code>CONNECTION_FACTORY="java:comp/env/jms/connectionFactory"</code> */
    public static final String CONNECTION_FACTORY="java:comp/env/jms/connectionFactory";
    /** Constant <code>INFORM_QUEUE="java:comp/env/jms/inform"</code> */
    public static final String INFORM_QUEUE="java:comp/env/jms/inform";
    /** Constant <code>GCOM_QUEUE="java:comp/env/jms/gcom"</code> */
    public static final String GCOM_QUEUE="java:comp/env/jms/gcom";
}
