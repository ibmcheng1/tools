/*
 * @(#)EffectiveDateCalculator.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.services;

import com.bcbssc.groupadmin.shared.dto.CoverageItem;
import com.bcbssc.struts.common.DateBean;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.ResourceBundle;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * Effective Date Calculator
 *
 * This class determines effective dates.
 *
 * @author Mark Perry
 * @version $Revision:   1.2  $
 */
public class EffectiveDateCalculator {

	/** log4j logger */
	protected static Logger log = Logger
			.getLogger(EffectiveDateCalculator.class.getName());

	// Error messages

	// Comment this piece of code to test using the main method.

	/** Constant <code>ERROR_MSG_CHECK_WAIT_PERIOD_CODE="errors.waitperiodcode"</code> */
	public static final String ERROR_MSG_CHECK_WAIT_PERIOD_CODE = "errors.waitperiodcode";

	/** Constant <code>ERROR_MSG_90_DAYS="errors.effectivedate90days"</code> */
	public static final String ERROR_MSG_90_DAYS = "errors.effectivedate90days";

	/** Constant <code>clifeResources</code> */
	protected static ResourceBundle clifeResources = ResourceBundle
			.getBundle("ApplicationResources");

	private final static String COVERAGE_CODES_BASED_ON_GROUP_BILL_DATES = "1";

	private final static String COVERAGE_CODES_NOT_BASED_ON_GROUP_BILL_DATES = "2";

	private final static String COVERAGE_CODES_EFFECTIVE_ON_DATE_OF_HIRE = "3";

	private final static String COVERAGE_CODES_WITH_ERROR_MESSAGE = "4";

	private final static String COVERAGE_CODES_BASED_ON_GROUP_BILL_DATES_SPL = "5";

	// Comment till here to test using the main method

	/*
	 * // Uncomment this piece of code to test using the main method and also
	 * comment the above piece of code.
	 * 
	 * public static final String ERROR_MSG_CHECK_WAIT_PERIOD_CODE =
	 * "errors.waitperiodcode"; public static final String ERROR_MSG_90_DAYS =
	 * "errors.effectivedate90days";
	 * 
	 * private final static String COVERAGE_CODES_BASED_ON_GROUP_BILL_DATES =
	 * "030,045,060,090,091,120,150,180,210,240,270,360,365,730"; private final
	 * static String COVERAGE_CODES_NOT_BASED_ON_GROUP_BILL_DATES =
	 * "903,906,909,912,918"; private final static String
	 * COVERAGE_CODES_EFFECTIVE_ON_DATE_OF_HIRE = "000, 900"; private final
	 * static String COVERAGE_CODES_BASED_ON_GROUP_BILL_DATES_SPL = "001";
	 * private final static String COVERAGE_CODES_WITH_ERROR_MESSAGE = "888,
	 * 999";
	 */

	/**
	 * Creates a new instance of EffectiveDateCalculator
	 */
	public EffectiveDateCalculator() {
		// do nothing
	}

	/**
	 * Determines coverage effective date.
	 *
	 * @param dateOfHire
	 *            employee hire date
	 * @param waitPeriodCode
	 *            coverage wait period code
	 * @param waitPeriodCode
	 *            coverage wait period code
	 * @param waitPeriod
	 *            coverage wait period in days
	 * @param lastBillDate
	 *            coverage last bill date
	 * @return effective date
	 * @param calculationCategory a {@link java.lang.String} object.
	 */
	public static DateBean getEffectiveDate(DateBean dateOfHire,
			String waitPeriodCode, int waitPeriod, DateBean lastBillDate,
			String calculationCategory) {

		DateBean effectiveDate = new DateBean();
		Calendar hireDatePlusWaitPeriod = Calendar.getInstance();

		if (EffectiveDateCalculator.log.isDebugEnabled()) {
			StringBuffer sbTempBuffer = new StringBuffer();
			sbTempBuffer.append("dateOfHire = ").append(dateOfHire.toString())
					.append(", ");
			sbTempBuffer.append("waitPeriodCode = ").append(
					waitPeriodCode.toString()).append(", ");
			sbTempBuffer.append("waitPeriod = ").append(waitPeriod)
					.append(", ");
			sbTempBuffer.append("lastBillDate = ").append(
					lastBillDate.toString()).append(", ");
			sbTempBuffer.append("calculationCategory = ").append(
					calculationCategory);

			EffectiveDateCalculator.log
					.debug("Executing EffectiveDateCalculator::getEffectiveDate with arguments "
							+ sbTempBuffer);
		}

		hireDatePlusWaitPeriod.set(Integer.parseInt(dateOfHire.getYear()),
				Integer.parseInt(dateOfHire.getMonth()) - 1, Integer
						.parseInt(dateOfHire.getDay()));
		hireDatePlusWaitPeriod.add(Calendar.DATE, waitPeriod);

		/*
		 * Logic : If the waitPeriodCode belongs to the codes based on group
		 * bill dates, check to see if the hireDay is greater than the billing
		 * day for the group. If yes the the coverage is effective from the
		 * billing day for the group of the next month (hireDate + waitperiod +
		 * 1). So technically add one month to the hireDatePlusWaitPeriodDay.
		 */
		if (EffectiveDateCalculator.COVERAGE_CODES_BASED_ON_GROUP_BILL_DATES
				.equals(calculationCategory)) {

			hireDatePlusWaitPeriod.add(Calendar.DATE, -1); // -1 to include the
															// date of hire.

			int groupBillingDay = Integer.parseInt(lastBillDate.getDay());
			int hireDatePlusWaitPeriodDay = hireDatePlusWaitPeriod
					.get(Calendar.DAY_OF_MONTH);

			if (hireDatePlusWaitPeriodDay >= groupBillingDay) {
				hireDatePlusWaitPeriod.add(Calendar.MONTH, 1);
			}

			effectiveDate.setYear(String.valueOf(hireDatePlusWaitPeriod
					.get(Calendar.YEAR)));
			effectiveDate.setMonth(String.valueOf(hireDatePlusWaitPeriod
					.get(Calendar.MONTH) + 1));
			effectiveDate.setDay(String.valueOf(groupBillingDay));
		} else if (EffectiveDateCalculator.COVERAGE_CODES_BASED_ON_GROUP_BILL_DATES_SPL
				.equals(calculationCategory)) {

			int groupBillingDay = Integer.parseInt(lastBillDate.getDay());
			int hireDatePlusWaitPeriodDay = hireDatePlusWaitPeriod
					.get(Calendar.DAY_OF_MONTH);

			if (hireDatePlusWaitPeriodDay >= groupBillingDay) {
				hireDatePlusWaitPeriod.add(Calendar.MONTH, 1);
			}

			effectiveDate.setYear(String.valueOf(hireDatePlusWaitPeriod
					.get(Calendar.YEAR)));
			effectiveDate.setMonth(String.valueOf(hireDatePlusWaitPeriod
					.get(Calendar.MONTH) + 1));
			effectiveDate.setDay(String.valueOf(groupBillingDay));
		} else if (EffectiveDateCalculator.COVERAGE_CODES_NOT_BASED_ON_GROUP_BILL_DATES
				.equals(calculationCategory)) {

			hireDatePlusWaitPeriod.add(Calendar.DATE, -1); // -1 to include the
															// date of hire.

			effectiveDate.setYear(String.valueOf(hireDatePlusWaitPeriod
					.get(Calendar.YEAR)));
			effectiveDate.setMonth(String.valueOf(hireDatePlusWaitPeriod
					.get(Calendar.MONTH) + 1));
			effectiveDate.setDay(String.valueOf(hireDatePlusWaitPeriod
					.get(Calendar.DAY_OF_MONTH)));
		} else if (EffectiveDateCalculator.COVERAGE_CODES_EFFECTIVE_ON_DATE_OF_HIRE
				.equals(calculationCategory)) {
			effectiveDate.setYear(String.valueOf(hireDatePlusWaitPeriod
					.get(Calendar.YEAR)));
			effectiveDate.setMonth(String.valueOf(hireDatePlusWaitPeriod
					.get(Calendar.MONTH) + 1));
			effectiveDate.setDay(String.valueOf(hireDatePlusWaitPeriod
					.get(Calendar.DAY_OF_MONTH)));
		} else if (EffectiveDateCalculator.COVERAGE_CODES_WITH_ERROR_MESSAGE
				.equals(calculationCategory)) {
			effectiveDate = new DateBean();
		} else {
			effectiveDate = new DateBean();
		}

		if (EffectiveDateCalculator.log.isDebugEnabled()) {
			EffectiveDateCalculator.log
					.debug("End of getEffectiveDate() in EffectiveDateCalculator.java, return value is"
							+ effectiveDate.toString());
		}

		return effectiveDate;
	}

	/**
	 * Determines default date of change date (no offset).
	 *
	 * @param lastBillDate
	 *            coverage last bill date
	 * @return default effective date
	 */
	public static DateBean getDefaultChangeDate(DateBean lastBillDate) {
		// no offset requested
		return EffectiveDateCalculator.getDefaultChangeDate(lastBillDate, 0);
	}

	/**
	 * Determines default date of change date.
	 *
	 * @param lastBillDate
	 *            coverage last bill date
	 * @param days_offset #
	 *            days to adjust default value by
	 * @return default effective date
	 */
	public static DateBean getDefaultChangeDate(DateBean lastBillDate,
			int days_offset) {

		DateBean changeDate = new DateBean();
		Calendar defaultDate = Calendar.getInstance();

		int currentDay = defaultDate.get(Calendar.DAY_OF_MONTH);
		int lastBillingDay = Integer.parseInt(lastBillDate.getDay());

		// if current day GREATER THAT groupBillingDate day
		if (currentDay > lastBillingDay) {

			// increase current month/year by 1 month
			defaultDate.add(Calendar.MONTH, 1);
		}
		// use the lastBillingDay for day of month
		defaultDate.set(Calendar.DAY_OF_MONTH, lastBillingDay);

		// apply any offset requested
		if (days_offset != 0) {
			defaultDate.add(Calendar.DAY_OF_YEAR, days_offset);
		}

		// load the DateBean for return
		changeDate.setYear(String.valueOf(defaultDate.get(Calendar.YEAR)));
		changeDate
				.setMonth(String.valueOf(defaultDate.get(Calendar.MONTH) + 1));
		changeDate.setDay(String
				.valueOf(defaultDate.get(Calendar.DAY_OF_MONTH)));

		return changeDate;
	}

	/**
	 * Determines if an error message is displayed based on effective date and
	 * wait period code.
	 *
	 * @param effectiveDate
	 *            coverage effedtive date
	 * @param waitPeriodCode
	 *            coverage wait period code
	 * @return String error message to return or null if no error
	 * @param calculationCategory a {@link java.lang.String} object.
	 */
	public static String getErrorMessage(DateBean effectiveDate,
			String waitPeriodCode, String calculationCategory) {
		String returnString = null;
		if (EffectiveDateCalculator.log.isDebugEnabled()) {
			EffectiveDateCalculator.log
					.debug("Start of getErrorMessage() in EffectiveDateCalculator.java");
			EffectiveDateCalculator.log.debug("effectiveDate = "
					+ effectiveDate);
			EffectiveDateCalculator.log.debug("waitPeriodCode = "
					+ waitPeriodCode);
			EffectiveDateCalculator.log.debug("calculationCategory = "
					+ calculationCategory);
		}

		if (!(EffectiveDateCalculator.COVERAGE_CODES_BASED_ON_GROUP_BILL_DATES
				.equals(calculationCategory))
				&& !(EffectiveDateCalculator.COVERAGE_CODES_BASED_ON_GROUP_BILL_DATES_SPL
						.equals(calculationCategory))
				&& !(EffectiveDateCalculator.COVERAGE_CODES_NOT_BASED_ON_GROUP_BILL_DATES
						.equals(calculationCategory))
				&& !(EffectiveDateCalculator.COVERAGE_CODES_WITH_ERROR_MESSAGE
						.equals(calculationCategory))
				&& !(EffectiveDateCalculator.COVERAGE_CODES_EFFECTIVE_ON_DATE_OF_HIRE
						.equals(calculationCategory))) {

			returnString = EffectiveDateCalculator.ERROR_MSG_CHECK_WAIT_PERIOD_CODE;
		} else if (EffectiveDateCalculator.COVERAGE_CODES_WITH_ERROR_MESSAGE
				.equals(calculationCategory)) {
			if (EffectiveDateCalculator.log.isDebugEnabled()) {
				EffectiveDateCalculator.log
						.debug("errMessageWaitPeriods.contains(waitPeriodCode)");
			}
			returnString = EffectiveDateCalculator.ERROR_MSG_CHECK_WAIT_PERIOD_CODE;
		} else {

			Calendar testEffectiveDate = Calendar.getInstance();
			if(StringUtils.isNotBlank(effectiveDate.getYear())
					&& StringUtils.isNotBlank(effectiveDate.getMonth())
					&& StringUtils.isNotBlank(effectiveDate.getDay())) {
				
				testEffectiveDate.set(Integer.parseInt(effectiveDate.getYear()),
						Integer.parseInt(effectiveDate.getMonth()) - 1, Integer
								.parseInt(effectiveDate.getDay()));
				Calendar currentDateMinusNinety = Calendar.getInstance();
	
				if (EffectiveDateCalculator.log.isDebugEnabled()) {
					EffectiveDateCalculator.log.debug("testEffectiveDate value is"
							+ testEffectiveDate.toString());
					EffectiveDateCalculator.log
							.debug("currentDateMinusNinety value is"
									+ currentDateMinusNinety.toString());
				}
	
				currentDateMinusNinety.add(Calendar.DAY_OF_YEAR, -90);
	
				if (EffectiveDateCalculator.log.isDebugEnabled()) {
					EffectiveDateCalculator.log
							.debug("currentDateMinusNinety again is"
									+ currentDateMinusNinety.toString());
				}
	
				// Coverage effective dates cannot be more than 90 days from the
				// current date.
				// If the calculation is more than 90 days in the past the coverage
				// is denied,
				// display error message.
				if (testEffectiveDate.before(currentDateMinusNinety)) {
					returnString = EffectiveDateCalculator.ERROR_MSG_90_DAYS;
				}
			}
		}
		return returnString;
	}

	/**
	 * Iterates through the coverage items list, looking for EffectiveDate-
	 * related errors for each item.
	 *
	 * @param coverageItems
	 *            list of coverage items
	 * @return String error message to return or null if no error
	 */
	public static String getErrorMessage(ArrayList coverageItems) {
		String error = null;

		Iterator items = coverageItems.iterator();
		while (items.hasNext() && (error == null)) {

			CoverageItem item = (CoverageItem) items.next();
			error = EffectiveDateCalculator.getErrorMessage(item
					.getEffectiveDate(), item.getWaitingPeriodCode(), item
					.getWaitPeriodCalculationCategory());
		}

		return error;
	}

	/*
	 * 
	 * Uncomment the main method to test the Effective date calculator stand
	 * alone.
	 * 
	 * public static void main(String[] args) {
	 * 
	 * BasicConfigurator.configure();
	 * 
	 * DateBean hireDate = new DateBean(); hireDate.setDay("19");
	 * hireDate.setMonth("07"); hireDate.setYear("2006");
	 * 
	 * DateBean billingDate = new DateBean(); billingDate.setDay("15");
	 * billingDate.setMonth("06"); billingDate.setYear("2006");
	 * 
	 * DateBean effectiveDate =
	 * EffectiveDateCalculator.getEffectiveDate(hireDate, "060", 60,
	 * billingDate); }
	 */
}
