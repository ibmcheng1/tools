/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUE CROSS BLUE SHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION, OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright (c) 2005 Blue Cross Blue Shield of South Carolina.
 * All rights reserved.
 * An independent Licensee of the Blue Cross and Blue Shield Association.
 *
 * GroupAdminPayrollDeductionAmountsInformHandler.java
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/mq/GroupAdminPayrollDeductionAmountsInformHandler.java_v  $
 * $Workfile:   GroupAdminPayrollDeductionAmountsInformHandler.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:16:02  $
 * $Modtime:   May 14 2009 11:33:32  $
 */
package com.bcbssc.groupadmin.shared.mq;

import com.bcbssc.groupadmin.shared.dto.PayrollDeductionAmountsDTO;
import com.bcbssc.netsys.Config;
import com.bcbssc.netsys.inform.InformEndLine;
import com.bcbssc.netsys.inform.InformInquiryLine;
import com.bcbssc.netsys.inform.InformUtil;

import java.util.Properties;

/**
 * Handles Group Admin INFOrm messaging for payroll deduction amount events.
 *
 * @author X22A (B. Smith)
 * @version $Revision:   1.0  $
 */
public class GroupAdminPayrollDeductionAmountsInformHandler {
	/**
	 * configuration properties file section where property values are located
	 */
	private static final String INI_SECTION = "MISC";

	/**
	 * configuratin properties file key for the info type
	 */
	private static final String INFO_TYPE = "USER_INFO_TYPE";

	/**
	 * configuration properties file key for the RPN
	 */
	private static final String RPN = "RPN";

	/**
	 * configuration properties file for the Company Code
	 */
	private static final String COMPANY_CODE = "APP_INFO_COMPANY_CODE";

	/**
	 * configruation properties file for the Corporate Code
	 */
	private static final String CORPORATE_CODE = "APP_INFO_CORPORATE_CODE";

	/**
	 * configuration properties file for the Department Code
	 */
	private static final String DEPARTMENT_CODE = "APP_INFO_DEPARTMENT_CODE";

	/**
	 * configuration properties file for the Division Code
	 */
	private static final String DIVISION_CODE = "APP_INFO_DIVISION_CODE";

	/**
	 * configuration properties file for the Application Name
	 */
	private static final String APP_NAME = "APP_NAME";

	/**
	 * configuration properties file for the Application Type
	 */
	private static final String APP_TYPE = "APP_TYPE";

	/**
	 * configuration properties file for the Employee ID
	 */
	private static final String EMPLOYEE_ID = "PAYROLL_EMP_ID";

	/**
	 * configuration properties for this object
	 */
	private Properties properties = null;

	/**
	 * the application-specific INI file
	 */
	private String iniFile = null;

	/**
	 * creates a new GroupAdminPayrollDeductionAmountsInformHandler
	 *
	 * @param iniFile
	 *            configuration properties file
	 */
	public GroupAdminPayrollDeductionAmountsInformHandler(String iniFile) {
		this.iniFile = iniFile;
		this.properties = Config.getConfigSection(
				GroupAdminPayrollDeductionAmountsInformHandler.INI_SECTION,
				iniFile);
	}

	/**
	 * Creates and sends an INFOrm for the specified user denoting use of the
	 * calculate payroll deduction feature
	 *
	 * @param info a {@link com.bcbssc.groupadmin.shared.dto.PayrollDeductionAmountsDTO} object.
	 */
	public void sendCalculatePayrollDeductionInform(
			PayrollDeductionAmountsDTO info) {
		String appType = this.properties
				.getProperty(GroupAdminPayrollDeductionAmountsInformHandler.APP_TYPE);
		String appName = this.properties
				.getProperty(GroupAdminPayrollDeductionAmountsInformHandler.APP_NAME);

		GroupAdminPayrollDeductionAmountsInformMessage gaim = new GroupAdminPayrollDeductionAmountsInformMessage();

		InformHeader ihb = new InformHeader();
		ihb
				.setInfoType(this.properties
						.getProperty(GroupAdminPayrollDeductionAmountsInformHandler.INFO_TYPE));
		ihb.setKeyId(info.getGroupNumber());
		ihb.setAltKeyId(info.getAccessCode());
		ihb
				.setRpn(this.properties
						.getProperty(GroupAdminPayrollDeductionAmountsInformHandler.RPN));
		ihb
				.setCompanyCode(this.properties
						.getProperty(GroupAdminPayrollDeductionAmountsInformHandler.COMPANY_CODE));
		ihb
				.setCorporateCode(this.properties
						.getProperty(GroupAdminPayrollDeductionAmountsInformHandler.CORPORATE_CODE));
		ihb
				.setDepartmentCode(this.properties
						.getProperty(GroupAdminPayrollDeductionAmountsInformHandler.DEPARTMENT_CODE));
		ihb
				.setDivisionCode(this.properties
						.getProperty(GroupAdminPayrollDeductionAmountsInformHandler.DIVISION_CODE));
		ihb
				.setEmployeeId(this.properties
						.getProperty(GroupAdminPayrollDeductionAmountsInformHandler.EMPLOYEE_ID));

		ihb.setAction("A");
		ihb.setStatusCode("2");
		ihb.setStatusType("CL");

		// ClaimNumber is an unused field we can use for appName
		StringBuffer corrspName = new StringBuffer(32);
		corrspName.append("WEB").append(appType).append(": ").append(appName);
		ihb.setClaimNumber(corrspName.toString());
		gaim.setHeader(ihb);

		gaim.addLine(new InformInquiryLine());

		StringBuffer verbiage = new StringBuffer(512);
		verbiage.append(appType).append(":PAYROLL DEDUCTION AMOUNTS\n");
		verbiage.append("Group Number: ").append(info.getGroupNumber()).append(
				"\n");
		verbiage.append("Next Bill Due Date: ").append(
				info.getBillDueDateFormatted()).append("\n");
		verbiage.append("Today's Date: ").append(info.getDate()).append("\n");
		verbiage.append("Division Name: ").append(info.getDivisionName())
				.append("\n");
		verbiage.append("Active Count: ").append(info.getActiveCount()).append(
				"\n");
		verbiage.append("Pay Period: ").append(info.getPayPeriodFormatted())
				.append("\n");
		verbiage.append("Product: ").append(info.getProductSelectedFormatted())
				.append("\n");
		verbiage.append("UserName: ").append(
				info.getUserDTO().getSamAccountName() + " - "
						+ info.getUserDTO().getGivenName() + " "
						+ info.getUserDTO().getLastName()).append("\n");

		InformUtil.addRequestLines(gaim, verbiage.toString());
		gaim.addLine(new InformEndLine());

		CommonInformUtils.sendMessage(gaim, "PAYROLLDEDUCTIONAMOUNTS",
				this.iniFile);
	}
}
