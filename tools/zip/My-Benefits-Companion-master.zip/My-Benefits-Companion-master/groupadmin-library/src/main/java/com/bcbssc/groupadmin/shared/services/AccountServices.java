/**
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 */

/**
 * Deals with Bank Account related services like get, insert, delete account operations.
 * @author X22R (Srini Gandu)
 * @version 1.0
 * Date	03/15/2006
 *
 */
package com.bcbssc.groupadmin.shared.services;

import com.bcbssc.groupadmin.shared.dbaccess.AccountQuery;
import com.bcbssc.groupadmin.shared.dto.BankInformationDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;

import java.sql.SQLException;

import org.apache.log4j.Logger;

/**
 * Provides bank account detail services for the CGA groups.
 *
 * @author X22R (Srini Gandu)
 * @version 1.0 Date 03/20/2006
 */
public class AccountServices {

	/** log4j logger */
	protected static final Logger log = Logger.getLogger(AccountServices.class);

	/** the ini file containing service processing parameters */
	protected String iniFile = null;

	/**
	 * Constructs class, setting the servlet ini files
	 *
	 * @param iniFile
	 *            the ini file containing service processing parameters
	 */
	public AccountServices(String iniFile) {
		this.iniFile = iniFile;
	}

	/**
	 * Get the bank account detials.
	 *
	 * @return BankInformationForm object
	 * @throws java.sql.SQLException
	 *             Unexpected Exception
	 * @param insuredDTO a {@link com.bcbssc.groupadmin.shared.dto.InsuredDataDTO} object.
	 */
	public BankInformationDTO getBankAccountDetails(InsuredDataDTO insuredDTO)
			throws SQLException {
		try {
			AccountQuery accountQuery = new AccountQuery(this.iniFile);
			BankInformationDTO bankInfoDTO = accountQuery
					.performSearch(insuredDTO);
			return bankInfoDTO;

		} catch (SQLException sqlEx) {
			AccountServices.log.error(
					"Error during bank account details query", sqlEx);
			throw sqlEx;
		}
	}

}
