/*
 * @(#)GroupAdminResetPasswordAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.actions;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.common.Constants;
import com.bcbssc.groupadmin.shared.dto.RegistrationFormDTO;
import com.bcbssc.groupadmin.shared.services.GroupAdminRegistrationServices;
import com.bcbssc.struts.action.BaseAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.DynaValidatorForm;

/**
 * CLife Reset Password Action
 *
 * This class provides control processing the reauthenticate action. Because
 * control for reset password is specific to group admin registration, this
 * class does not subclass a shared action.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.1  $
 */
public class GroupAdminResetPasswordAction extends BaseAction {

	/** log4j logger */
	private static final Logger log = Logger
			.getLogger(GroupAdminResetPasswordAction.class.getName());

	/**
	 * <p>Constructor for GroupAdminResetPasswordAction.</p>
	 */
	public GroupAdminResetPasswordAction() {
		super();
		if (GroupAdminResetPasswordAction.log.isDebugEnabled()) {
			GroupAdminResetPasswordAction.log
					.debug("Created GroupAdminResetPasswordAction object.");
		}
	}

	/**
	 * Processes the specified HTTP request, and create sthe corresponding HTTP
	 * response.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		int status;
		String forwardname;

		String iniFile = CommonUtils.getIniFile(this.getServlet());
		String tdsIniFile = CommonUtils.getTDSIniFile(this.getServlet());

		DynaValidatorForm df = (DynaValidatorForm) form;
		GroupAdminRegistrationServices service = new GroupAdminRegistrationServices(
				iniFile, tdsIniFile);
		RegistrationFormDTO formDTO = new RegistrationFormDTO();
		BeanUtils.copyProperties(formDTO, df);

		status = service.resetPassword(formDTO);
		switch (status) {
		case Constants.ACCESS_REVOKED:
			// This will only be returned if validate
			forwardname = Constants.FORWARD_ACCESS_REVOKED;
			request.setAttribute("populatedHelpForm", formDTO);
			break;
		case Constants.SERVICE_SECURITY_ERROR:
			forwardname = com.bcbssc.registration.common.Constants.FORWARD_SECURITY_ERROR;
			break;
		case Constants.SERVICE_INVALID:
			forwardname = com.bcbssc.registration.common.Constants.FORWARD_FAILURE;
			break;
		default:
			service.setEncryptedCookie(formDTO.getSamAccountName(), request,
					response);
			forwardname = com.bcbssc.registration.common.Constants.FORWARD_SUCCESS;
			break;
		}

		return mapping.findForward(forwardname);
	}
}
