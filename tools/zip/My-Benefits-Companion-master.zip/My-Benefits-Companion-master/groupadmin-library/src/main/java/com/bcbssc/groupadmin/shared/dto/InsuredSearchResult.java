/*
 * @(#)InsuredSearchResult.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.dto;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.forms.Options;
import com.bcbssc.struts.common.FormDate;

/**
 * GroupAdmin Insured Search Result
 *
 * This bean contains the search result data for a single employee. It includes
 * formatting methods for form display.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class InsuredSearchResult extends Object {

	/**
	 * Holds value of property identificationNumber.
	 */
	private String identificationNumber;

	/**
	 * Holds value of property givenName.
	 */
	private String givenName;

	/**
	 * Holds value of property lastName.
	 */
	private String lastName;

	/**
	 * Holds value of property middleIni.
	 */
	private String middleIni;

	/**
	 * Holds value of property dateOfBirth.
	 */
	private FormDate dateOfBirth = new FormDate();

	/**
	 * Holds value of property gender.
	 */
	private String gender;

	/**
	 * Holds value of property status.
	 */
	private String status;

	/**
	 * Holds value of property coverageClassDescription.
	 */
	private String coverageClassDescription;

	/**
	 * Holds value of property premium.
	 */
	private String premium;

	/**
	 * Holds value of property lastProcessedDate.
	 */
	private FormDate lastProcessedDate = new FormDate();

	/**
	 * Holds value of property lifePremiumPayPeriod.
	 */
	private String lifePremiumPayPeriod;

	/**
	 * Holds value of property lifePremium.
	 */
	private String lifePremium;

	/**
	 * Holds value of property dentalPremiumPayPeriod.
	 */
	private String dentalPremiumPayPeriod;

	/**
	 * Holds value of property dentalPremium.
	 */
	private String dentalPremium;

	/**
	 * Holds value of property visionPremiumPayPeriod.
	 */
	private String visionPremiumPayPeriod;

	/**
	 * Holds value of property visionPremium.
	 */
	private String visionPremium;

	/**
	 * Holds value of property stdPremiumPayPeriod.
	 */
	private String stdPremiumPayPeriod;

	/**
	 * Holds value of property stdPremium.
	 */
	private String stdPremium;

	/**
	 * Holds value of property ltdPremiumPayPeriod.
	 */
	private String ltdPremiumPayPeriod;

	/**
	 * Holds value of property ltdPremium.
	 */
	private String ltdPremium;

	/**
	 * Holds value of property totalPremiumPayPeriod.
	 */
	private String totalPremiumPayPeriod;

	/**
	 * Holds value of property totalPremium.
	 */
	private String totalPremium;

	/**
	 * Holds value of property payrollDeductionAmt.
	 */
	private String payrollDeductionAmt = "0";

	/**
	 * Getter for property identificationNumber.
	 *
	 * @return Value of property identificationNumber.
	 */
	public String getIdentificationNumber() {
		return this.identificationNumber;
	}

	/**
	 * Setter for property identificationNumber.
	 *
	 * @param identificationNumber
	 *            New value of property identificationNumber.
	 */
	public void setIdentificationNumber(String identificationNumber) {
		this.identificationNumber = identificationNumber;
	}

	/**
	 * Getter for property givenName.
	 *
	 * @return Value of property givenName.
	 */
	public String getGivenName() {
		return this.givenName;
	}

	/**
	 * Setter for property givenName.
	 *
	 * @param givenName
	 *            New value of property givenName.
	 */
	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	/**
	 * Getter for property lastName.
	 *
	 * @return Value of property lastName.
	 */
	public String getLastName() {
		return this.lastName;
	}

	/**
	 * Setter for property lastName.
	 *
	 * @param value
	 *            New value of property lastName.
	 */
	public void setLastName(String value) {
		this.lastName = value;
	}

	/**
	 * Getter for property middleIni.
	 *
	 * @return Value of property middleIni.
	 */
	public String getMiddleIni() {
		return this.middleIni;
	}

	/**
	 * Setter for property middleIni.
	 *
	 * @param middleIni
	 *            New value of property middleIni.
	 */
	public void setMiddleIni(String middleIni) {
		this.middleIni = middleIni;
	}

	/**
	 * Getter for property dateOfBirth.
	 *
	 * @return Value of property dateOfBirth.
	 */
	public String getDateOfBirthFormatted() {
		return this.dateOfBirth.toString();
	}

	/**
	 * Setter for property dateOfBirth.
	 *
	 * @param date
	 *            New value of property dateOfBirth.
	 */
	public void setDateOfBirth(com.bcbssc.struts.common.DateBean date) {
		this.dateOfBirth.setDate(date);
	}

	/**
	 * Formatted getter for property gender.
	 *
	 * @return Formatted value of property gender.
	 */
	public String getGenderFormatted() {
		return com.bcbssc.struts.forms.Options.getLabelFromValue(Options
				.getGroupAdminInstance().getGenderOptions(), this.gender);
	}

	/**
	 * Setter for property gender.
	 *
	 * @param gender
	 *            New value of property gender.
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * Formatted getter for property status.
	 *
	 * @return Formatted value of property status.
	 */
	public String getStatusFormatted() {
		return com.bcbssc.struts.forms.Options.getLabelFromValue(Options
				.getGroupAdminInstance().getEmployeeStatusOptions(),
				this.status);
	}

	/**
	 * Getter for property status.
	 *
	 * @return Value of property status.
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * Setter for property status.
	 *
	 * @param status
	 *            New value of property status.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Getter for property coverageClassDescription.
	 *
	 * @return Value of property coverageClassDescription.
	 */
	public String getCoverageClassDescription() {
		return this.coverageClassDescription;
	}

	/**
	 * Setter for property coverageClassDescription.
	 *
	 * @param value a {@link java.lang.String} object.
	 */
	public void setCoverageClassDescription(String value) {
		this.coverageClassDescription = value;
	}

	/**
	 * Formatted getter for property premium.
	 *
	 * @return Formatted value of property premium.
	 */
	public String getPremiumFormatted() {
		return CommonUtils.formatDecimalCurrency(this.premium);
	}

	/**
	 * Setter for property premium.
	 *
	 * @param premium
	 *            New value of property premium.
	 */
	public void setPremium(String premium) {
		this.premium = premium;
	}

	/**
	 * Formatted getter for property lastProcessedDate.
	 *
	 * @return Formatted value of property lastProcessedDate.
	 */
	public String getLastProcessedDateFormatted() {
		return this.lastProcessedDate.toString();
	}

	/**
	 * Setter for property lastProcessedDate.
	 *
	 * @param bean
	 *            New value of property lastProcessedDate.
	 */
	public void setLastProcessedDate(com.bcbssc.struts.common.DateBean bean) {
		this.lastProcessedDate.setDate(bean);
	}

	/**
	 * Getter for property lifePremiumPayPeriod".
	 *
	 * @return Value of property lifePremiumPayPeriod".
	 */
	public String getLifePremiumPayPeriod() {
		return CommonUtils.formatDecimalCurrency(this.lifePremiumPayPeriod);
	}

	/**
	 * Setter for property lifePremiumPayPeriod".
	 *
	 * @param lifePremiumPayPeriod"
	 *            New value of property lifePremiumPayPeriod".
	 */
	public void setLifePremiumPayPeriod(String lifePremiumPayPeriod) {
		this.lifePremiumPayPeriod = lifePremiumPayPeriod;
	}

	/**
	 * Getter for property lifePremium.
	 *
	 * @return Value of property lifePremium.
	 */
	public String getLifePremium() {
		return CommonUtils.formatDecimalCurrency(this.lifePremium);
	}

	/**
	 * Setter for property lifePremiumMonthly.
	 *
	 * @param lifePremium a {@link java.lang.String} object.
	 */
	public void setLifePremium(String lifePremium) {
		this.lifePremium = lifePremium;
	}

	/**
	 * Getter for property dentalPremiumPayPeriod.
	 *
	 * @return Value of property dentalPremiumPayPeriod".
	 */
	public String getDentalPremiumPayPeriod() {
		return CommonUtils.formatDecimalCurrency(this.dentalPremiumPayPeriod);
	}

	/**
	 * Setter for property dentalPremiumPayPeriod.
	 *
	 * @param dentalPremiumPayPeriod"
	 *            New value of property dentalPremiumPayPeriod.
	 */
	public void setDentalPremiumPayPeriod(String dentalPremiumPayPeriod) {
		this.dentalPremiumPayPeriod = dentalPremiumPayPeriod;
	}

	/**
	 * Getter for property dentalPremium.
	 *
	 * @return Value of property dentalPremium.
	 */
	public String getDentalPremium() {
		return CommonUtils.formatDecimalCurrency(this.dentalPremium);
	}

	/**
	 * Setter for property dentalPremium.
	 *
	 * @param dentalPremium a {@link java.lang.String} object.
	 */
	public void setDentalPremium(String dentalPremium) {
		this.dentalPremium = dentalPremium;
	}

	/**
	 * Getter for property visionPremiumPayPeriod.
	 *
	 * @return Value of property visionPremiumPayPeriod".
	 */
	public String getVisionPremiumPayPeriod() {
		return CommonUtils.formatDecimalCurrency(this.visionPremiumPayPeriod);
	}

	/**
	 * Setter for property visionPremiumPayPeriod.
	 *
	 * @param visionPremiumPayPeriod"
	 *            New value of property visionPremiumPayPeriod.
	 */
	public void setVisionPremiumPayPeriod(String visionPremiumPayPeriod) {
		this.visionPremiumPayPeriod = visionPremiumPayPeriod;
	}

	/**
	 * Getter for property visionPremium.
	 *
	 * @return Value of property visionPremium.
	 */
	public String getVisionPremium() {
		return CommonUtils.formatDecimalCurrency(this.visionPremium);
	}

	/**
	 * Setter for property visionPremium.
	 *
	 * @param visionPremium
	 *            New value of property visionPremium.
	 */
	public void setVisionPremium(String visionPremium) {
		this.visionPremium = visionPremium;
	}

	/**
	 * Getter for property stdPremiumPayPeriod.
	 *
	 * @return Value of property stdPremiumPayPeriod.
	 */
	public String getStdPremiumPayPeriod() {
		return CommonUtils.formatDecimalCurrency(this.stdPremiumPayPeriod);
	}

	/**
	 * Setter for property stdPremiumPayPeriod.
	 *
	 * @param stdPremiumPayPeriod"
	 *            New value of property stdPremiumPayPeriod.
	 */
	public void setStdPremiumPayPeriod(String stdPremiumPayPeriod) {
		this.stdPremiumPayPeriod = stdPremiumPayPeriod;
	}

	/**
	 * Getter for property stdPremium.
	 *
	 * @return Value of property stdPremium.
	 */
	public String getStdPremium() {
		return CommonUtils.formatDecimalCurrency(this.stdPremium);
	}

	/**
	 * Setter for property stdPremium.
	 *
	 * @param stdPremium
	 *            New value of property stdPremium.
	 */
	public void setStdPremium(String stdPremium) {
		this.stdPremium = stdPremium;
	}

	/**
	 * Getter for property ltdPremiumPayPeriod.
	 *
	 * @return Value of property ltdPremiumPayPeriod.
	 */
	public String getLtdPremiumPayPeriod() {
		return CommonUtils.formatDecimalCurrency(this.ltdPremiumPayPeriod);
	}

	/**
	 * Setter for property ltdPremiumPayPeriod.
	 *
	 * @param ltdPremiumPayPeriod
	 *            New value of property ltdPremiumPayPeriod.
	 */
	public void setLtdPremiumPayPeriod(String ltdPremiumPayPeriod) {
		this.ltdPremiumPayPeriod = ltdPremiumPayPeriod;
	}

	/**
	 * Getter for property ltdPremium.
	 *
	 * @return Value of property ltdPremium.
	 */
	public String getLtdPremium() {
		return CommonUtils.formatDecimalCurrency(this.ltdPremium);
	}

	/**
	 * Setter for property ltdPremium.
	 *
	 * @param ltdPremium
	 *            New value of property ltdPremium.
	 */
	public void setLtdPremium(String ltdPremium) {
		this.ltdPremium = ltdPremium;
	}

	/**
	 * Getter for property totalPremiumPayPeriod.
	 *
	 * @return Value of property totalPremiumPayPeriod.
	 */
	public String getTotalPremiumPayPeriod() {
		return CommonUtils.formatDecimalCurrency(this.totalPremiumPayPeriod);
	}

	/**
	 * Setter for property totalPremiumPayPeriod.
	 *
	 * @param totalPremiumPayPeriod
	 *            New value of property totalPremiumPayPeriod.
	 */
	public void setTotalPremiumPayPeriod(String totalPremiumPayPeriod) {
		this.totalPremiumPayPeriod = totalPremiumPayPeriod;
	}

	/**
	 * Getter for property totalPremium.
	 *
	 * @return Value of property totalPremium.
	 */
	public String getTotalPremium() {
		return CommonUtils.formatDecimalCurrency(this.totalPremium);
	}

	/**
	 * Setter for property totalPremium.
	 *
	 * @param totalPremium a {@link java.lang.String} object.
	 */
	public void setTotalPremium(String totalPremium) {
		this.totalPremium = totalPremium;
	}

	/**
	 * Setter for property payrollDeductionAmt
	 *
	 * @param payrollDeductionAmt a {@link java.lang.String} object.
	 */
	public void setPayrollDeductionAmt(String payrollDeductionAmt) {
		this.payrollDeductionAmt = payrollDeductionAmt;
	}

	/**
	 * Getter for property payrollDeductionAmt
	 *
	 * @return Value of property payrollDeductionAmt .
	 */
	public String getPayrollDeductionAmt() {
		return this.payrollDeductionAmt;
	}

}
