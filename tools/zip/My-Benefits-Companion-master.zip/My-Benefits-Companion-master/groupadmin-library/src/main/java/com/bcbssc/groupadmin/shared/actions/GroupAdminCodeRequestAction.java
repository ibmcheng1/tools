/*
 * @(#)GroupAdminCodeRequestAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.dto.RegistrationFormDTO;
import com.bcbssc.groupadmin.shared.forms.CodeRequestForm;
import com.bcbssc.groupadmin.shared.services.GroupAdminRegistrationServices;
import com.bcbssc.struts.action.SimpleDispatchAction;

/**
 * Group Admin Access Code Request Action
 *
 * This class provides control processing of the code request action. Because
 * control for access code request is specific to group admin registration, this
 * class does not subclass a shared registration action.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.1  $
 */
public class GroupAdminCodeRequestAction extends SimpleDispatchAction {

	/** log4j logger */
	private static final Logger log = Logger
			.getLogger(GroupAdminCodeRequestAction.class.getName());

	/**
	 * Processes the specified HTTP request, and create sthe corresponding HTTP
	 * response.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward verifyCode(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		ActionForward returnActionForward = null;
		String iniFile = CommonUtils.getIniFile(this.getServlet());
		String tdsIniFile = CommonUtils.getTDSIniFile(this.getServlet());

		CodeRequestForm df = (CodeRequestForm) form;
		GroupAdminRegistrationServices service = new GroupAdminRegistrationServices(
				iniFile, tdsIniFile);
		RegistrationFormDTO formDTO = new RegistrationFormDTO();
		BeanUtils.copyProperties(formDTO, df);

		// Determine if access code has already been requested
		if (service.accessCodeRequested(formDTO)) {
			this.addGlobalRequestMessage(request, "errors.coderequested");

			// The CodeRequestForm requires dropdowns which are
			// not provided by the form object. Create a new form
			// object from the DTO data.
			CodeRequestForm crf = (CodeRequestForm) this.getForm(
					"codeRequestForm", "/confirmCodeRequest", request);
			BeanUtils.copyProperties(crf, formDTO);
			request.setAttribute("codeRequestForm", crf);
			returnActionForward = (new ActionForward(mapping.getInput()));
		} else {
			request.setAttribute("codeRequestForm", formDTO);
			returnActionForward = mapping
					.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
		}
		return returnActionForward;
	}

	/**
	 * <p>submitRequest.</p>
	 *
	 * @param mapping a {@link org.apache.struts.action.ActionMapping} object.
	 * @param form a {@link org.apache.struts.action.ActionForm} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @param response a {@link javax.servlet.http.HttpServletResponse} object.
	 * @return a {@link org.apache.struts.action.ActionForward} object.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward submitRequest(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		ActionForward returnActionForward = null;
		String iniFile = CommonUtils.getIniFile(this.getServlet());
		String tdsIniFile = CommonUtils.getTDSIniFile(this.getServlet());

		CodeRequestForm df = (CodeRequestForm) form;
		GroupAdminRegistrationServices service = new GroupAdminRegistrationServices(
				iniFile, tdsIniFile);
		RegistrationFormDTO formDTO = new RegistrationFormDTO();
		BeanUtils.copyProperties(formDTO, df);

		// Request the access code
		try {
			if (service.requestAccessCode(formDTO)) {
				returnActionForward = mapping
						.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
			} else {
				returnActionForward = mapping
						.findForward(com.bcbssc.registration.common.Constants.FORWARD_FAILURE);
			}
		} catch (Exception wpe) {
			GroupAdminCodeRequestAction.log.warn("Webpack Error", wpe);

			String msg = wpe.toString();

			if (msg.indexOf("ZIP") != -1) {
				// If a Zip code error occurs, return user to initial code
				// request screen
				this.addGlobalRequestMessage(request,
						"errors.coderequest.zipcode");

				// The CodeRequestForm requires dropdowns which are
				// not provided by the form object. Create a new form
				// object from the DTO data.
				CodeRequestForm crf = (CodeRequestForm) this.getForm(
						"codeRequestForm", "/requestCode", request);
				BeanUtils.copyProperties(crf, formDTO);

				returnActionForward = mapping.findForward("webpack_error");
			} else {
				throw wpe;
			}
		}
		return returnActionForward;
	}

}
