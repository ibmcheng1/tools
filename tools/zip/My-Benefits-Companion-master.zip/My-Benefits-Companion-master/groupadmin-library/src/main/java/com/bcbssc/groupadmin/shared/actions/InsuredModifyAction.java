/*
 * @(#)InsuredModifyAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.actions;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredRequestChangeSearchDTO;
import com.bcbssc.groupadmin.shared.dto.InsuredSearchDTO;
import com.bcbssc.groupadmin.shared.forms.ChangeSelectionForm;
import com.bcbssc.groupadmin.shared.forms.InsuredSearchForm;
import com.bcbssc.groupadmin.shared.forms.ModifyCoverageForm;
import com.bcbssc.groupadmin.shared.forms.ModifyDependentForm;
import com.bcbssc.groupadmin.shared.forms.ModifyInsuredDetailsForm;
import com.bcbssc.groupadmin.shared.forms.ModifySalaryForm;
import com.bcbssc.groupadmin.shared.forms.RequestChangeSelectionForm;
import com.bcbssc.groupadmin.shared.services.InsuredServices;
import com.bcbssc.struts.action.SimpleDispatchAction;

/**
 * Group Admin Insured Modify Action
 *
 * This class provides control processing for the insured modify page.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class InsuredModifyAction extends SimpleDispatchAction {

	/** log4j logger */
	private static final Logger log = Logger
			.getLogger(InsuredModifyAction.class.getName());

	/** page names used for navigation */
	public static final String SELECT_PATH = "select_path";

	/** Constant <code>MODIFY_INSURED="modify_insured"</code> */
	public static final String MODIFY_INSURED = "modify_insured";

	/** Constant <code>MODIFY_COVERAGE="modify_coverage"</code> */
	public static final String MODIFY_COVERAGE = "modify_coverage";

	/** Constant <code>MODIFY_DEPENDENTS="modify_dependents"</code> */
	public static final String MODIFY_DEPENDENTS = "modify_dependents";

	/** Constant <code>MODIFY_SALARY="modify_salary"</code> */
	public static final String MODIFY_SALARY = "modify_salary";

	/** Constant <code>CONFIRM_MODIFY="confirm_modify"</code> */
	public static final String CONFIRM_MODIFY = "confirm_modify";

	private static ArrayList<String> pathOrder;

	boolean toSalaryPage = false;

	static {
		InsuredModifyAction.pathOrder = new ArrayList<String>();
		InsuredModifyAction.pathOrder.add(InsuredModifyAction.SELECT_PATH);
		InsuredModifyAction.pathOrder.add(InsuredModifyAction.MODIFY_INSURED);
		InsuredModifyAction.pathOrder.add(InsuredModifyAction.MODIFY_COVERAGE);
		InsuredModifyAction.pathOrder
				.add(InsuredModifyAction.MODIFY_DEPENDENTS);
		InsuredModifyAction.pathOrder.add(InsuredModifyAction.MODIFY_SALARY);
		InsuredModifyAction.pathOrder.add(InsuredModifyAction.CONFIRM_MODIFY);
	}

	/**
	 * Displays the modify path selection form
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward displayPathSelection(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		InsuredSearchForm insuredSearchForm = (InsuredSearchForm) form;
		insuredSearchForm.setCurrentPage(InsuredModifyAction.SELECT_PATH);
		ChangeSelectionForm changeSelectionForm = (ChangeSelectionForm) this
				.getForm("changeSelectionForm", "/modifySelectionEntered",
						request);
		BeanUtils.copyProperties(changeSelectionForm, form);

		// calculate the default change effective date
		changeSelectionForm.defaultChangeEffectiveDate();

		request.setAttribute("changeSelectionForm", changeSelectionForm);
		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}



	/**
	 * <p>displayRequestaChangeSelection.</p>
	 *
	 * @param mapping a {@link org.apache.struts.action.ActionMapping} object.
	 * @param form a {@link org.apache.struts.action.ActionForm} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @param response a {@link javax.servlet.http.HttpServletResponse} object.
	 * @return a {@link org.apache.struts.action.ActionForward} object.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward displayRequestaChangeSelection(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		InsuredSearchForm insuredSearchForm = (InsuredSearchForm) form;
		insuredSearchForm.setCurrentPage(InsuredModifyAction.SELECT_PATH);
		RequestChangeSelectionForm changeSelectionForm = (RequestChangeSelectionForm) this
				.getForm("requestaChangeSelectionForm",
						"/initiateRequestaChange", request);
		BeanUtils.copyProperties(changeSelectionForm, form);

		// calculate the default change effective date
		changeSelectionForm.defaultChangeEffectiveDate();
		changeSelectionForm.defaultReHireDate();
		changeSelectionForm.defaultReqChangeTerminationDate();
		changeSelectionForm.defaultEffectiveTerminationDate();
		changeSelectionForm.defaultCoverageEffectiveDate();

		request.setAttribute("requestaChangeSelectionForm",changeSelectionForm);
		return mapping.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}


	/**
	 * <p>confirmRequestaChangeSelection.</p>
	 *
	 * @param mapping a {@link org.apache.struts.action.ActionMapping} object.
	 * @param form a {@link org.apache.struts.action.ActionForm} object.
	 * @param request a {@link javax.servlet.http.HttpServletRequest} object.
	 * @param response a {@link javax.servlet.http.HttpServletResponse} object.
	 * @return a {@link org.apache.struts.action.ActionForward} object.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward confirmRequestaChangeSelection(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		RequestChangeSelectionForm insuredForm = (RequestChangeSelectionForm) form;

		InsuredRequestChangeSearchDTO insuredDTO = new InsuredRequestChangeSearchDTO();

		BeanUtils.copyProperties(insuredDTO, insuredForm);
		InsuredServices insuredServices = new InsuredServices(
				CommonUtils.getIniFile(this.getServlet()),
				CommonUtils.getGcomIniFile(this.getServlet()),
				(GroupAdminUserDTO) request
						.getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));
		InsuredModifyAction.log
				.debug("In InsuredModifyAction : confirmRequestaChangeSelection(), isSalaryPageUpdated() = "
						+ insuredForm.isSalaryPageUpdated());

		if (insuredForm.isSalaryPageUpdated()) {
			insuredServices.modifyAnnualSalary(insuredDTO, request);
		}

		insuredServices.requestaChange(insuredDTO, request);

		request.setAttribute("searchForm", insuredForm);
		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}






	/**
	 * Goes back from search selection page
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward pathSelectionBack(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		request.setAttribute("searchForm", form);
		return mapping.findForward("back");
	}

	/**
	 * Continues to the next modify path, as specified by the selected path
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward modifyContinue(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		InsuredSearchForm insuredSearchForm = (InsuredSearchForm) form;
		insuredSearchForm.updateCoverageItemList();
		String nextPage = this.getNextPage(insuredSearchForm.getCurrentPage(),
				insuredSearchForm.getSelectedPathItemsArrayList());

		this.setRequestForm(request, nextPage, insuredSearchForm);
		return mapping.findForward(nextPage);
	}

	/**
	 * Navigates backwards, as specified by the selected path
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward modifyBack(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		InsuredSearchForm insuredSearchForm = (InsuredSearchForm) form;
		String previousPage = this.getPreviousPage(insuredSearchForm
				.getCurrentPage(), insuredSearchForm
				.getSelectedPathItemsArrayList());

		this.setRequestForm(request, previousPage, insuredSearchForm);
		return mapping.findForward(previousPage);
	}

	/**
	 * Navigates backwards from modify dependents page
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward modifyDependentsBack(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		InsuredSearchForm insuredSearchForm = (InsuredSearchForm) form;
		String previousPage = this.getPreviousPage(insuredSearchForm
				.getCurrentPage(), insuredSearchForm
				.getSelectedPathItemsArrayList());

		InsuredDataDTO insuredDataDTO = new InsuredDataDTO();
		BeanUtils.copyProperties(insuredDataDTO, insuredSearchForm);
		InsuredServices.removeBlankDependents(insuredDataDTO);
		BeanUtils.copyProperties(insuredSearchForm, insuredDataDTO);

		this.setRequestForm(request, previousPage, insuredSearchForm);
		return mapping.findForward(previousPage);
	}

	/**
	 * Sets the form as the appropriate request attribute, depending on the next
	 * page.
	 *
	 * @param request
	 *            the HTTP request we are processing
	 * @param nextPage
	 *            forward name of the next page
	 * @param insuredSearchForm
	 *            form to be set in request
	 * @throws java.lang.Exception
	 *             if BeanUtils.copyProperties() fails
	 */
	private void setRequestForm(HttpServletRequest request, String nextPage,
			InsuredSearchForm insuredSearchForm) throws Exception {

		// Go ahead and set the new current page value in the form bean
		insuredSearchForm.setCurrentPage(nextPage);

		if (nextPage.equals(InsuredModifyAction.SELECT_PATH)) {
			ChangeSelectionForm changeSelectionForm = (ChangeSelectionForm) this
					.getForm("changeSelectionForm", "/modifySelectionEntered",
							request);
			BeanUtils.copyProperties(changeSelectionForm, insuredSearchForm);
			request.setAttribute("changeSelectionForm", changeSelectionForm);
		} else if (nextPage.equals(InsuredModifyAction.MODIFY_INSURED)) {
			ModifyInsuredDetailsForm modifyInsuredDetailsForm = (ModifyInsuredDetailsForm) this
					.getForm("modifyInsuredDetailsForm",
							"/modifyInsuredEntered", request);
			BeanUtils.copyProperties(modifyInsuredDetailsForm,
					insuredSearchForm);
			request.setAttribute("modifyInsuredDetailsForm",
					modifyInsuredDetailsForm);
		} else if (nextPage.equals(InsuredModifyAction.MODIFY_COVERAGE)) {
			ModifyCoverageForm modifyCoverageForm = (ModifyCoverageForm) this
					.getForm("modifyCoverageForm", "/modifyCoverageEntered",
							request);
			BeanUtils.copyProperties(modifyCoverageForm, insuredSearchForm);
			request.setAttribute("modifyCoverageForm", modifyCoverageForm);
		} else if (nextPage.equals(InsuredModifyAction.MODIFY_DEPENDENTS)) {
			ModifyDependentForm modifyDependentForm = (ModifyDependentForm) this
					.getForm("modifyDependentForm", "/modifyDependentEntered",
							request);
			BeanUtils.copyProperties(modifyDependentForm, insuredSearchForm);
			request.setAttribute("modifyDependentForm", modifyDependentForm);
		} else if (nextPage.equals(InsuredModifyAction.MODIFY_SALARY)) {
			ModifySalaryForm modifySalaryForm = (ModifySalaryForm) this
					.getForm("modifySalaryForm", "/modifySalaryEntered",
							request);
			BeanUtils.copyProperties(modifySalaryForm, insuredSearchForm);
			// C15021 : CLife MBC change - copy the change effective date into
			// the salary change effective date
			if (this.toSalaryPage) {
				modifySalaryForm
						.copyChangeEffectiveDateToSalaryChangeEffectiveDate();
				this.toSalaryPage = false;
			}
			request.setAttribute("modifySalaryForm", modifySalaryForm);
		} else if (nextPage.equals(InsuredModifyAction.CONFIRM_MODIFY)) {
			request.setAttribute("searchForm", insuredSearchForm);
		}
	}

	/**
	 * Returns the next page in the modify navigation order, which depends on
	 * the user's path selection.
	 *
	 * @param currentPage
	 *            forward name of the current page
	 * @param selectedPathItems
	 *            list of the forward names of the selected path items
	 * @return forward name of of the next page, or the current page if no
	 *         previous page is available.
	 */
	String getNextPage(String currentPage, ArrayList selectedPathItems) {
		String nextPage = null;
		int nextPageIndex = InsuredModifyAction.pathOrder.indexOf(currentPage) + 1;

		while ((currentPage != null) && (nextPage == null)) {
			if (nextPageIndex < InsuredModifyAction.pathOrder.size()) {
				String nextOrderedPage = (String) InsuredModifyAction.pathOrder
						.get(nextPageIndex);
				if (selectedPathItems.contains(nextOrderedPage)
						|| nextOrderedPage
								.equals(InsuredModifyAction.SELECT_PATH)
						|| nextOrderedPage
								.equals(InsuredModifyAction.CONFIRM_MODIFY)) {
					nextPage = nextOrderedPage;
				} else {
					nextPageIndex++;
				}

			} else {
				nextPage = currentPage;
			}
		}

		if ((nextPage != null)
				&& nextPage.equals(InsuredModifyAction.MODIFY_SALARY)) {
			this.toSalaryPage = true;
		}

		return nextPage;
	}

	/**
	 * Returns the previous page in the modify navigation order, which depends
	 * on the user's path selection.
	 *
	 * @param currentPage
	 *            forward name of the current page
	 * @param selectedPathItems
	 *            list of the forward names of the selected path items
	 * @return forward name of of the previous page, or the current page if no
	 *         previous page is available.
	 */
	String getPreviousPage(String currentPage, ArrayList selectedPathItems) {
		String previousPage = null;
		int previousPageIndex = InsuredModifyAction.pathOrder
				.indexOf(currentPage) - 1;

		while ((currentPage != null) && (previousPage == null)) {
			if (previousPageIndex >= 0) {
				String previousOrderedPage = (String) InsuredModifyAction.pathOrder
						.get(previousPageIndex);
				if (selectedPathItems.contains(previousOrderedPage)
						|| previousOrderedPage
								.equals(InsuredModifyAction.SELECT_PATH)
						|| previousOrderedPage
								.equals(InsuredModifyAction.CONFIRM_MODIFY)) {
					previousPage = previousOrderedPage;
				} else {
					previousPageIndex--;
				}

			} else {
				previousPage = currentPage;
			}
		}

		return previousPage;
	}

	/**
	 * Adds another dependent to the dependent list.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward addNextDependent(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModifyDependentForm modifyDependentForm = (ModifyDependentForm) form;

		InsuredDataDTO insuredDataDTO = new InsuredDataDTO();
		BeanUtils.copyProperties(insuredDataDTO, modifyDependentForm);
		InsuredServices.addNextDependent(insuredDataDTO);

		ModifyDependentForm newForm = (ModifyDependentForm) this.getForm(
				"modifyDependentForm", "/modifyDependentEntered", request);
		BeanUtils.copyProperties(newForm, insuredDataDTO);

		request.setAttribute("modifyDependentForm", newForm);
		return mapping.findForward(InsuredModifyAction.MODIFY_DEPENDENTS);
	}

	/**
	 * Submits the Insured/Coverage/Dependents information
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward confirmModify(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		InsuredSearchForm insuredForm = (InsuredSearchForm) form;
		InsuredSearchDTO insuredDTO = new InsuredSearchDTO();
		BeanUtils.copyProperties(insuredDTO, insuredForm);
		InsuredServices insuredServices = new InsuredServices(
				CommonUtils.getIniFile(this.getServlet()),
				CommonUtils.getGcomIniFile(this.getServlet()),
				(GroupAdminUserDTO) request
						.getAttribute(com.bcbssc.registration.common.Constants.USER_DTO));

		InsuredModifyAction.log
				.debug("In InsuredModifyAction : confirmModify(), isSalaryPageUpdated() = "
						+ insuredForm.isSalaryPageUpdated());

		if (insuredForm.isSalaryPageUpdated()) {
			insuredServices.modifyAnnualSalary(insuredDTO, request);
		}

		if ((insuredForm.isInsuredPageUpdated())
				|| (insuredForm.isCoveragePageUpdated())
				|| (insuredForm.isDependentPageUpdated())) {
			insuredServices.modifyInsuredEmployee(insuredDTO, request);
		}

		request.setAttribute("searchForm", insuredForm);
		return mapping
				.findForward(com.bcbssc.registration.common.Constants.FORWARD_SUCCESS);
	}

	// public static void main(String[] inArgs) {
	// InsuredModifyAction action = new InsuredModifyAction();
	// ArrayList selectedPathItems = new ArrayList();
	// selectedPathItems.add(MODIFY_INSURED);
	// selectedPathItems.add(MODIFY_COVERAGE);
	// System.out.println(action.getPreviousPage(MODIFY_COVERAGE,
	// selectedPathItems));
	// }
}
