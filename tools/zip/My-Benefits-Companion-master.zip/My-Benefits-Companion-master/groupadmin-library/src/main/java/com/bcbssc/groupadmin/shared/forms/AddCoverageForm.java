/*
 * @(#)AddCoverageForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.forms;

import com.bcbssc.groupadmin.shared.dto.CoverageClass;
import com.bcbssc.groupadmin.shared.dto.CoverageItemList;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;
import com.bcbssc.groupadmin.shared.services.InsuredServices;

import java.util.Collection;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;

/**
 * GroupAdmin Add Coverage Form
 *
 * This bean extends the InsuredSearchForm by providing a clear method specific
 * to the add coverage form.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class AddCoverageForm extends CoverageForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** log4j logger */
	private static Logger log = Logger.getLogger(AddCoverageForm.class);

	/** list of potential coverage classes */
	private Collection coverageClasses = null;

	/**
	 * Clears the user-editable data fields for this form
	 */
	public void clear() {
		this.annualSalaryCents = com.bcbssc.struts.common.Constants.BLANK_STRING;
		this.annualSalaryDollars = com.bcbssc.struts.common.Constants.BLANK_STRING;
		this.setCoverageClass(new CoverageClass());
		this.otherDental = "N";
		this.spouseDental = "N";
		this.dentalDependentCount = 0;
		this.coverageItems = new CoverageItemList(this);
		this.averageHoursWorked = com.bcbssc.struts.common.Constants.BLANK_STRING;
	}

	/**
	 * Gets the coverage class list from ODBC
	 *
	 * @return coverage class list
	 * @throws java.lang.Exception if any.
	 */
	public Collection getCoverageClasses() throws Exception {

		if (this.coverageClasses == null) {
			if (this.getServlet() != null) {
				InsuredServices insuredServices = this.getInsuredServices();
				InsuredDataDTO insuredDataDTO = new InsuredDataDTO();
				BeanUtils.copyProperties(insuredDataDTO, this);
				this.coverageClasses = insuredServices
						.getCoverageClasses(insuredDataDTO);
			}
		}
		return this.coverageClasses;
	}

	/**
	 * Gets the coverage class list size
	 *
	 * @return coverage class list size
	 * @throws java.lang.Exception if any.
	 */
	public int getCoverageClassesCount() throws Exception {
		if (this.coverageClasses == null) {
			this.getCoverageClasses();
		}

		return (this.coverageClasses == null) ? 0 : this.coverageClasses.size();
	}

    /**
     * <p>getCoverageItemsCount.</p>
     *
     * @return a int.
     * @throws java.lang.Exception if any.
     */
    public int getCoverageItemsCount() throws Exception{
		return this.coverageItems.size();
	}
	/**
	 * <p>getClassPresent.</p>
	 *
	 * @return a boolean.
	 */
	public boolean getClassPresent() {

		AddCoverageForm.log.debug("The returned value is "
				+ (this.getClassHasDentalCoverage() || this
						.getClassHasVisionCoverage()));

		return this.getClassHasDentalCoverage()
				|| this.getClassHasVisionCoverage();
	}

	/**
	 * <p>getDentalAndVisionSelected.</p>
	 *
	 * @return a boolean.
	 */
	public boolean getDentalAndVisionSelected() {
		return this.getDentalCoverage() && this.getVisionCoverage();
	}

	/**
	 * <p>getDisplayVision.</p>
	 *
	 * @return a boolean.
	 */
	public boolean getDisplayVision() {
		return this.getClassHasVisionCoverage() && this.getVisionCoverage();
	}

	/**
	 * <p>getDisplayDental.</p>
	 *
	 * @return a boolean.
	 */
	public boolean getDisplayDental() {
		return this.getClassHasDentalCoverage() && this.getDentalCoverage();
	}

}
