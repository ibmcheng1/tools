/*
 * @(#)GroupAdminModifyProfileAction.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.groupadmin.shared.actions;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.dto.GroupAdminUserDTO;
import com.bcbssc.groupadmin.shared.dto.RegistrationFormDTO;
import com.bcbssc.groupadmin.shared.forms.ProfileActionForm;
import com.bcbssc.groupadmin.shared.services.GroupAdminSecureServices;
import com.bcbssc.registration.services.ISecureServices;
import com.bcbssc.struts.action.BaseAction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionServlet;

/**
 * Group Admin Modify Profile Action
 *
 * This class provides control processing the modify profile action (both
 * populate and add). Because modify profile control is fairly generic, this
 * class extends the shared registration modify profile action.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.1  $
 */
public class GroupAdminModifyProfileAction extends BaseAction {

	/** log4j logger */
	private static final Logger logger = Logger
			.getLogger(GroupAdminModifyProfileAction.class.getName());

	/** modify profile action type: display populated form name */
	private static final String POPULATE = "populate";

	/** modify profile action type: confirm data */
	private static final String CONFIRM = "confirm";

	/**
	 * Creates an application-specific services object
	 * 
	 * @return services object
	 */
	private ISecureServices getServices() {
		// The servlet has the context that contains the ini file locations
		ActionServlet actionServlet = this.getServlet();
		String iniFile = CommonUtils.getIniFile(actionServlet);
		String tdsIniFile = CommonUtils.getTDSIniFile(actionServlet);
		return new GroupAdminSecureServices(iniFile, tdsIniFile);
	}

	/**
	 * Processes the specified HTTP request, and creates the corresponding HTTP
	 * response.
	 *
	 * @param mapping
	 *            the ActionMapping used to select this instance
	 * @param form
	 *            the optional bean for this request (if any)
	 * @param request
	 *            the HTTP request we are processing
	 * @param response
	 *            the HTTP request we are creating
	 * @return describes where and how control should be forwarded, or null if
	 *         the response has already been completed.
	 * @throws java.lang.Exception if any.
	 */
	public ActionForward execute(
			// UserDTO user,
			ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ProfileActionForm df = (ProfileActionForm) form;
		String buttonval = df.getButton();

		String actiontype = mapping.getParameter();
		String forward;

		// Create CGA validation service and perform CGA-specific form to DTO
		// translation
		GroupAdminSecureServices service = (GroupAdminSecureServices) this
				.getServices();
		RegistrationFormDTO formDTO = new RegistrationFormDTO();
		BeanUtils.copyProperties(formDTO, df);

		GroupAdminUserDTO user = (GroupAdminUserDTO) request
				.getAttribute("user");
		GroupAdminModifyProfileAction.logger.debug("displaying user!!!");
		GroupAdminModifyProfileAction.logger.debug("" + user);
		if (actiontype.equals(GroupAdminModifyProfileAction.POPULATE)) {
			service.populateForm(formDTO, user);

			// The CreateProfileForm requires dropdowns which are
			// not provided by the form object. Create a new form
			// object from the DTO data.
			ProfileActionForm paf = (ProfileActionForm) this.getForm(
					"modifyProfileForm", "/displayModifyProfile", request);
			BeanUtils.copyProperties(paf, formDTO);

			forward = com.bcbssc.registration.common.Constants.FORWARD_SUCCESS;

		} else if (actiontype.equals(GroupAdminModifyProfileAction.CONFIRM)) {
			if (buttonval
					.equals(com.bcbssc.registration.common.Constants.FORM_BUTTON_CANCEL)) {
				forward = com.bcbssc.registration.common.Constants.FORWARD_CANCEL;
			} else {
				forward = com.bcbssc.registration.common.Constants.FORWARD_SUCCESS;
			}
		} else {
			if (buttonval
					.equals(com.bcbssc.registration.common.Constants.FORM_BUTTON_CANCEL)) {
				forward = com.bcbssc.registration.common.Constants.FORWARD_CANCEL;
			} else if (buttonval
					.equals(com.bcbssc.registration.common.Constants.FORM_BUTTON_BACK)) {
				// The CreateProfileForm requires dropdowns which are
				// not provided by the form object. Create a new form
				// object from the DTO data.
				ProfileActionForm paf = (ProfileActionForm) this.getForm(
						"modifyProfileForm", "/displayModifyProfile", request);
				BeanUtils.copyProperties(paf, formDTO);

				forward = com.bcbssc.registration.common.Constants.FORWARD_BACK;
			} else {
				if (service.modifyProfile(formDTO, user)) {
					forward = com.bcbssc.registration.common.Constants.FORWARD_SUCCESS;
				} else {
					forward = com.bcbssc.registration.common.Constants.FORWARD_SECURITY_ERROR;
				}
			}
		}

		return mapping.findForward(forward);
	}
}
