/*
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/common/CommonUtils.java_v  $
 * $Workfile:   CommonUtils.java  $
 * $Revision:   1.2  $
 * $Date:   Sep 08 2010 09:37:26  $
 * $Modtime:   Jul 23 2010 11:32:18  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/common/CommonUtils.java_v  $
 * 
 *    Rev 1.2   Sep 08 2010 09:37:26   x94s
 * RD188C Creating closed inform when user registers his profile
 *
 *    Rev 1.1   Jun 29 2010 08:41:14   x94s
 * RD188C Tivoli implementation
 *
 *    Rev 1.0   Jun 26 2009 15:13:52   EN80
 * Initial revision.
 *
 *    Rev 1.26   Apr 28 2009 10:17:30   rff74
 * Java6 Upgrade
 *
 *    Rev 1.25   Jan 06 2006 18:59:44   rx08e
 * Fixes to support the National Super User functionality.
 *
 *    Rev 1.24   Apr 05 2005 16:46:26   rxr93
 * fix formatCurrency to deal with negative numbers
 *
 *    Rev 1.23   Mar 22 2005 14:40:58   rxg97
 * Added superuser support to setPermissionsAdapter().
 *
 *    Rev 1.22   Mar 17 2005 17:11:20   rxg97
 * Fixed a bug in formatCurrency() that was causing an exception for numbers with less digits than the cents precision.
 *
 *    Rev 1.21   Mar 15 2005 14:42:16   rxr93
 * remove main() - issm
 *
 *    Rev 1.20   Mar 11 2005 16:10:08   rxg97
 * Added blank value handling to formatCurrency.
 *
 *    Rev 1.19   Mar 09 2005 18:28:14   rxg97
 * Created formatCurrency methods that include cents precision arguments.
 *
 *    Rev 1.18   Mar 07 2005 13:19:48   rxr93
 * issm changes
 *
 */

package com.bcbssc.groupadmin.shared.common;

import com.bcbssc.registration.permissions.RolePermissionsAdapter;
import com.bcbssc.struts.common.DateBean;
import com.bcbssc.struts.forms.Options;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.GenericTypeValidator;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionServlet;

/**
 * Group Administration Common Utilities
 *
 * This class provides a container for miscellanous utility methods used
 * throughout the application.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.2  $
 */
public class CommonUtils extends com.bcbssc.registration.common.CommonUtils {
    /**
     * <p>The log4j <CODE>Logger</CODE> for this class.</p>
     */
    private static final Logger log = Logger.getLogger(CommonUtils.class);

    /** Name of the postalCode form bean */
    private static final String POSTAL_CODE_BEAN_NAME = "postalCode";

    /** Name of the state form bean */
    private static final String STATE_BEAN_NAME = "state";

    /**
     * Performs specialized Zip code validation US only 1. This field is
     * required. 2. This field must be numeric. 3. This field requires 5 or 9
     * digits. Non US This field must be spaces.
     *
     * @param errors
     *            form error messages
     * @param countryCode
     *            country code from form
     * @param postalCode
     *            postal code from form
     */
    public static void validatePostalCode(ActionErrors errors,
            String countryCode, String postalCode) {

        if (!errors.get(CommonUtils.POSTAL_CODE_BEAN_NAME).hasNext()) {
            String country = countryCode.trim();
            String zip = postalCode.trim();
            if ((country.length() == 0)
                    || country.equals(Options.US_COUNTRY_CODE)) {
                if (zip.length() == 0) {
                    errors.add(CommonUtils.POSTAL_CODE_BEAN_NAME,
                            new ActionMessage("errors.required"));
                } else if ((zip.length() != 5) && (zip.length() != 9)) {
                    errors.add(CommonUtils.POSTAL_CODE_BEAN_NAME,
                            new ActionMessage("errors.postalcode.length"));
                } else {
                    // US Zip code must be Integer
                    Integer result = GenericTypeValidator.formatInt(zip);
                    if (result == null) {
                        errors.add(CommonUtils.POSTAL_CODE_BEAN_NAME,
                                new ActionMessage("errors.integer"));
                    }
                }
            } else if (country.equals(Options.CA_COUNTRY_CODE)) {
                if (zip.length() == 0) {
                    errors.add(CommonUtils.POSTAL_CODE_BEAN_NAME,
                            new ActionMessage("errors.required"));
                } else {
                    // CA Zip code must be alphanumeric but can contain spaces
                    // Replace any spaces with a number so isAlphaNumeric will
                    // work
                    zip = zip.replace(' ', '0');
                    if (!com.bcbssc.struts.common.CommonUtils
                            .isAlphaNumeric(zip)) {
                        errors.add(CommonUtils.POSTAL_CODE_BEAN_NAME,
                                new ActionMessage("errors.alphanumeric"));
                    }
                }
            } else {
                if (zip.length() != 0) {
                    errors.add(CommonUtils.POSTAL_CODE_BEAN_NAME,
                            new ActionMessage("errors.notempty"));
                }
            }
        }
    }

    /**
     * Performs specialized State validation US only This field is required. Non
     * US This field must be spaces.
     *
     * @param errors
     *            form error messages
     * @param countryCode
     *            country code from form
     * @param stateCode
     *            state code from form
     */
    public static void validateState(ActionErrors errors, String countryCode,
            String stateCode) {

        if (!errors.get(CommonUtils.STATE_BEAN_NAME).hasNext()) {
            String country = countryCode.trim();
            String state = stateCode.trim();
            if (country.equals(Options.US_COUNTRY_CODE)
                    || country.equals(Options.CA_COUNTRY_CODE)) {
                if (state.length() == 0) {
                    errors.add(CommonUtils.STATE_BEAN_NAME, new ActionMessage(
                            "errors.required"));
                }
            } else {
                if (state.length() != 0) {
                    errors.add(CommonUtils.STATE_BEAN_NAME, new ActionMessage(
                            "errors.notempty"));
                }
            }
        }
    }

    /**
     * If a user role exists, sets the permissionsAdapter attribute in the
     * request to the appropriate adapter for the role.
     *
     * @param request
     *            request for which permissionsAdapter will be set
     * @param roles a {@link java.lang.String} object.
     * @param superUserType a {@link java.lang.String} object.
     */
    public static void setPermissionsAdapter(HttpServletRequest request,
            String roles, String superUserType) {
        // If the role is set, we are on the secure side, use the role to get
        // the permissionsAdapter
        if (roles.length() > 0) {
            RolePermissionsAdapter permissions = new RolePermissionsAdapter(
                    roles, superUserType);
            request.setAttribute("permissionsAdapter", permissions);
        }
    }

    /**
     * Returns the ini file from the servlet context.
     *
     * @param servlet
     *            the servlet
     * @return name of the ini file from the servlet context
     */
    public static String getIniFile(ActionServlet servlet) {
    	logger.debug("Servlet Context is: " + servlet.getServletContext());
        return CommonUtils.getIniFile(servlet.getServletContext());
    }


    /**
     * <p>getTDSIniFile.</p>
     *
     * @param servlet a {@link org.apache.struts.action.ActionServlet} object.
     * @return a {@link java.lang.String} object.
     */
    public static final String getTDSIniFile(ActionServlet servlet){
    	return CommonUtils.getTDSIniFile(servlet.getServletContext());
    }
    
    /**
     * <p>getTDSSuperUserIniFile.</p>
     *
     * @param servlet a {@link org.apache.struts.action.ActionServlet} object.
     * @return a {@link java.lang.String} object.
     */
    public static final String getTDSSuperUserIniFile(ActionServlet servlet){
    	return CommonUtils.getTDSSuperUserIniFile(servlet.getServletContext());
    }
    /**
     * Returns the SSL ini file from the servlet context.
     *
     * @param servlet
     *            the servlet
     * @return name of the SSL ini file from the servlet context.
     */
    public static String getSslIniFile(ActionServlet servlet) {
        return CommonUtils.getTDSIniFile(servlet.getServletContext());
    }

    /**
     * Returns the ini file from the servlet context.
     *
     * @param servlet
     *            the servlet
     * @return name of the ini file from the servlet context.
     */
    public static String getNationalIniFile(ActionServlet servlet) {
        return CommonUtils.getNationalIniFile(servlet.getServletContext());
    }

    /**
     * Returns the SSL ini file from the servlet context.
     *
     * @param servlet
     *            the servlet
     * @return name of the SSL ini file from the servlet context.
     */
    public static String getNationalSslIniFile(ActionServlet servlet) {
        return CommonUtils.getNationalSslIniFile(servlet.getServletContext());
    }

    /**
     * Returns the GCOM ini file from the servlet context.
     *
     * @param servlet
     *            the servlet
     * @return name of the GCOM ini file from the servlet context.
     */
    public static String getGcomIniFile(ActionServlet servlet) {
        return CommonUtils.getGcomIniFile(servlet.getServletContext());
    }
    
    
    /**
     * {@inheritDoc}
     *
     * Gets the application-specific INI file
     */
    public static String getIniFile(ServletContext context) {
    	String iniFile = (String) context.getAttribute(Constants.INIFILE_PARAMETER_NAME);
    	logger.debug("iniFile is:" + iniFile);
    	return iniFile;

    }


    /**
     * <p>getTDSIniFile.</p>
     *
     * @param context a {@link javax.servlet.ServletContext} object.
     * @return a {@link java.lang.String} object.
     */
    public static String getTDSIniFile(ServletContext context){

    	return (String) context.getAttribute(Constants.TDS_INIFILE_PARAMETER_NAME);

    }
    
    /**
     * <p>getTDSSuperUserIniFile.</p>
     *
     * @param context a {@link javax.servlet.ServletContext} object.
     * @return a {@link java.lang.String} object.
     */
    public static String getTDSSuperUserIniFile(ServletContext context){

    	return (String) context.getAttribute(Constants.TDS_SU_INIFILE_PARAMETER_NAME);

    }

    /**
     * Gets the application-specific SSL INI file
     *
     * @return INI file name
     * @param context a {@link javax.servlet.ServletContext} object.
     */
    public static String getSslIniFile(ServletContext context) {
        return (String) context.getAttribute(Constants.SSL_INI_PARAMETER_NAME);
    }

    /**
     * Gets the application-specific INI file
     *
     * @return INI file name
     * @param context a {@link javax.servlet.ServletContext} object.
     */
    public static String getNationalIniFile(ServletContext context) {
        return (String) context.getAttribute(Constants.NATL_INI_PARAMETER_NAME);
    }

    /**
     * Gets the application-specific SSL INI file
     *
     * @return INI file name
     * @param context a {@link javax.servlet.ServletContext} object.
     */
    public static String getNationalSslIniFile(ServletContext context) {
        return (String) context
                .getAttribute(Constants.NATL_SSL_INI_PARAMETER_NAME);
    }

    /**
     * Gets the application-specific GCOM INI file
     *
     * @return INI file name
     * @param context a {@link javax.servlet.ServletContext} object.
     */
    public static String getGcomIniFile(ServletContext context) {
        return (String) context.getAttribute(Constants.GCOM_INI_PARAMETER_NAME);
    }

    

    /**
     * Formats a dollars/cents int into a US currency String value, where cents
     * contains two decimal places of precision
     *
     * @param amount
     *            Currency value in concatenated dollarscents format
     * @return formatted US currency value
     */
    public static String formatCurrency(int amount) {
        return CommonUtils.formatCurrency(amount, 2);
    }

    /**
     * Formats a dollarscents String into a US currency String value, where
     * cents contains two decimal places of precision
     *
     * @param amount
     *            Currency value in concatenated dollarscents format
     * @return formatted US currency value
     */
    public static String formatCurrency(String amount) {
        return CommonUtils.formatCurrency(amount, 2);
    }

    /**
     * Formats a dollars/cents int into a US currency String value
     *
     * @param amount
     *            Currency value in concatenated dollarscents format
     * @param centsDecimalPlaces
     *            the number of decimal places for the cents
     * @return formatted US currency value
     */
    public static String formatCurrency(int amount, int centsDecimalPlaces) {
        return CommonUtils.formatCurrency(Integer.toString(amount, 10),
                centsDecimalPlaces);
    }

    /**
     * Formats a dollarscents String into a US currency String value
     *
     * @param amount
     *            Currency value in concatenated dollarscents format
     * @param centsDecimalPlaces
     *            the number of decimal places for the cents
     * @return formatted US currency value
     */
    public static String formatCurrency(String amount, int centsDecimalPlaces) {
        StringBuffer formattedAmount = new StringBuffer(8);
        String tempAmount = amount;

        boolean negative = false;
        int len = tempAmount.length();

        if (len == 0) {
            return com.bcbssc.struts.common.Constants.BLANK_STRING;
        } else if (len > 1) {
            if (tempAmount.charAt(0) == '-') {
                negative = true;

                // strip off sign
                tempAmount = tempAmount.substring(1);
            }
        }

        if (centsDecimalPlaces > 2) {
            int newlength = tempAmount.length() - (centsDecimalPlaces - 2);
            if (newlength >= 0) {
                formattedAmount.append(tempAmount.substring(0, newlength));
            }
        } else {
            formattedAmount.append(tempAmount);
        }

        while (formattedAmount.length() < 3) {
            formattedAmount.insert(0, "0");
        }

        formattedAmount.insert(formattedAmount.length() - 2, '.');

        for (int i = formattedAmount.length() - 6; i > 0; i -= 3) {
            formattedAmount.insert(i, ',');
        }

        if (negative) {
            // put sign back
            formattedAmount.insert(0, "-");
        }
        formattedAmount.insert(0, "$");

        return formattedAmount.toString();
    }

    /**
     * Formats a dollars.cents String into a US currency String value
     *
     * @param amount
     *            Currency value in concatenated dollars.cents format
     * @return formatted US currency value
     */
    public static String formatDecimalCurrency(String amount) {
        StringBuffer formattedAmount = new StringBuffer(8);

        formattedAmount.append(amount);

        // Add a . if needed
        if (formattedAmount.toString().indexOf('.') == -1) {
            formattedAmount.append(".00");
        }
        // If 1st char is decimal point, insert a 0 for dollar value
        if (formattedAmount.charAt(0) == '.') {
            formattedAmount.insert(0, '0');
        }
        // Pad to two places after the decmial point if needed
        while (formattedAmount.length() <= formattedAmount.toString().indexOf(
                '.') + 2) {
            formattedAmount.append("0");
        }

        // add commas as needed
        for (int i = formattedAmount.length() - 6; i > 0; i -= 3) {
            formattedAmount.insert(i, ',');
        }

        formattedAmount.insert(0, "$");

        return formattedAmount.toString();
    }

    /**
     * Formats dollars into a US currency String value
     *
     * @param amount
     *            Currency value in dollars
     * @return formatted US currency value
     */
    public static String formatDollarCurrency(int amount) {
        return CommonUtils.formatDollarCurrency(Integer.toString(amount, 10));
    }

    /**
     * Formats a dollars String into a US currency String value
     *
     * @param amount
     *            Currency value in dollars format
     * @return formatted US currency value
     */
    public static String formatDollarCurrency(String amount) {
        StringBuffer formattedAmount = new StringBuffer(8);

        formattedAmount.append(amount);

        for (int i = formattedAmount.length() - 3; i > 0; i -= 3) {
            formattedAmount.insert(i, ',');
        }

        formattedAmount.insert(0, "$");

        return formattedAmount.toString();
    }

    /**
     * Creates a date bean from a string.
     *
     * @param dateStr
     *            a string of the form MM.dd.yyyy, where '.' is any character.
     *            If less than 10 characters, no fields will be set on the bean.
     *            Characters after the 10th position are ignored.
     * @return a new date bean.
     */
    public static final DateBean getDateBean(String dateStr) {
        DateBean dateBean = new DateBean();
        if (dateStr.length() >= 10) {
            dateBean.setMonth(dateStr.substring(0, 2));
            dateBean.setDay(dateStr.substring(3, 5));
            dateBean.setYear(dateStr.substring(6, 10));
        }
        return dateBean;
    }

    /**
     * pad a string top the desired length
     *
     * @param value
     *            String to pad
     * @param pad
     *            char to pad with
     * @param len
     *            length desired
     * @return a {@link java.lang.String} object.
     */
    public static String padValue(String value, char pad, int len) {
        if (value == null) {
            CommonUtils.log.debug("padValue() value = null");
            return value;
        }
        StringBuffer buffer = new StringBuffer(pad);
        buffer.append(value);
        while (buffer.length() < len) {
            buffer.insert(0, pad);
        }
        if (CommonUtils.log.isDebugEnabled()) {
            CommonUtils.log.debug(" '" + value + "'='" + buffer.toString()
                    + "'");
        }
        return buffer.toString();
    }
    
    /**
     * <p>getServerHostName.</p>
     *
     * @param request a {@link javax.servlet.http.HttpServletRequest} object.
     * @return a {@link java.lang.String} object.
     */
    public static String getServerHostName(HttpServletRequest request){
    	String hostName = StringUtils.EMPTY;
    	String requestUrl = request.getRequestURL().toString();
		String requestUri = request.getRequestURI();
		CommonUtils.log.debug("getServerHostName:RequestURL:"+requestUrl);
		CommonUtils.log.debug("getServerHostName:RequestURI:"+requestUri);
		hostName = requestUrl.substring(0,requestUrl.indexOf(requestUri));
		CommonUtils.log.debug("getServerHostName:hostName:"+hostName);
    	return hostName;
    }
}
