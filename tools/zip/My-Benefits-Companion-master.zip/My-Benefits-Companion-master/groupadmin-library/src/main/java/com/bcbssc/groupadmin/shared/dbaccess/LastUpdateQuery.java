/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/LastUpdateQuery.java_v  $
 * $Workfile:   LastUpdateQuery.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:20  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/LastUpdateQuery.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:14:20   EN80
 * Initial revision.
 * 
 *    Rev 1.2   Apr 28 2009 10:18:08   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.1   Feb 15 2005 15:09:56   rxg97
 * Modified to return a DateBean instead of a String.
 * 
 *    Rev 1.0   Feb 03 2005 16:24:06   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.dbaccess;

import com.bcbssc.struts.common.DateBean;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * This query pulls the last update date for the welcome page.<br>
 *
 * <pre>
 *     QMF NAME: RX13U.RX13U.WEB_SQL_1
 *     TSO NAME: WEBSQL1
 * </pre>
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class LastUpdateQuery extends AbstractDBSearch {

	/** Contains the results of this query. */
	private DateBean result;

	/**
	 * Creates a <code>LastUpdateQuery</code> and configures it with an INI
	 * file.
	 *
	 * @param iniFile
	 *            file path of the configuration INI file.
	 */
	public LastUpdateQuery(String iniFile) {
		super(iniFile, "GCOM_TABLE");
	}

	/**
	 * Pulls the last update date for the welcome page.<br>
	 *
	 * <pre>
	 *     QMF NAME: RX13U.RX13U.WEB_SQL_1
	 *     TSO NAME: WEBSQL1
	 * </pre>
	 *
	 * @return the search results.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 */
	public DateBean performSearch() throws SQLException {
		this.checkInit(); // Necessary since we need the _dbSchema before the
							// query creation

		final StringBuffer sql = new StringBuffer(256);

		sql.append(
				"SELECT CHAR(LAST_BILL_DUE_DATE,USA) \"LAST_PROCESS_DATE\""
						+ "  FROM ").append(this._dbSchema).append(
				".VBILLDTZ" + "  WHERE COMPANY_CODE = '000'"
						+ "    AND GROUP_PREFIX = '00'"
						+ "    AND GROUP_NUMBER = '00000  '"
						+ "    AND DIVISION_ID = '000  '");

		this.performSearch(sql.toString(), null);
		return this.result;
	}

	/**
	 * {@inheritDoc}
	 *
	 * Adds data from the given result set to the target object.
	 */
	protected void addSearchItem(ResultSet data, Object obj)
			throws SQLException {
		this.result = DatabaseProxy.getDateBean(data.getString(1));
	}
}
