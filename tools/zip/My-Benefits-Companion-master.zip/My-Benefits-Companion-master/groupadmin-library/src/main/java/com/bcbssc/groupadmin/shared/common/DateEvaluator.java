/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2003 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * DateEvaluator.java
 *
 * Created on July 30, 2003, 1:21 PM
 *
 */

package com.bcbssc.groupadmin.shared.common;

import com.bcbssc.struts.common.DateBean;

import org.apache.log4j.Logger;

/**
 * Document
 *
 * <pre>
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/common/DateEvaluator.java_v  $
 * $Workfile:   DateEvaluator.java  $
 * $Revision:   1.0  $
 * $Date:   Sep 22 2009 15:04:22  $
 * $Modtime:   Sep 21 2009 12:33:18  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/common/DateEvaluator.java_v  $
 *
 *    Rev 1.0   Sep 22 2009 15:04:22   rx24c
 * Initial revision.
 *
 *    Rev 1.0   Jun 26 2009 15:28:10   EN80
 * Initial revision.
 *
 *    Rev 1.2   Apr 28 2009 09:55:14   rff74
 * Java6 Upgrade
 *
 *    Rev 1.1   Mar 19 2009 10:32:00   rff74
 * Java6 Upgrade
 *
 *    Rev 1.0   Jul 31 2003 15:03:06   rcj97
 * Initial revision.
 * </pre>
 *
 * @author CJ97 (R. Porter)
 * @version $Id: $Id
 */
public class DateEvaluator extends com.bcbssc.netsys.web.AbstractValueEvaluator {

	/** The log4j logger for this class */
	private static Logger log = Logger.getLogger(DateEvaluator.class);

	/**
	 * Creates a new instance of DateEvaluator
	 */
	public DateEvaluator() {
		if (DateEvaluator.log.isDebugEnabled()) {
			DateEvaluator.log.debug("Created DateEvaluator object.");
		}
	}

	/**
	 * <p>doEvaluate.</p>
	 *
	 * @return a {@link java.lang.Object} object.
	 */
	protected Object doEvaluate() {

		String formattedDate	= "";

		try {

			DateBean dateBean	= (DateBean) this.valueObject;
			formattedDate 		= dateBean.getYear() + dateBean.getMonth() + dateBean.getDay();
		}
		catch(Exception exception) {
			log.error("Error creating somrthing.", exception);
		}

		return formattedDate;
	}

}
