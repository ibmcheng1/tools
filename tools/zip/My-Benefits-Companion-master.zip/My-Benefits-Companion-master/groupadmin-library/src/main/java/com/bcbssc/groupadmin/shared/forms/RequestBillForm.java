/*
 * @(#)RequestBillForm.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * Created on Feb 18, 2005
 *
 * Bean for processing bill requests
 */
package com.bcbssc.groupadmin.shared.forms;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;
import com.bcbssc.groupadmin.shared.services.BillServices;

import java.util.ArrayList;
import java.util.Collection;

/**
 * <p>RequestBillForm class.</p>
 *
 * @author XR93
 * @version $Id: $Id
 */
public class RequestBillForm extends InsuredSearchForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** bill date options */
	private Collection billDateOptions;

	/** date selected */
	private String selectedBillDate;

	/** what kind of request */
	private String requestType;

	/** what kind of bill requested */
	private String billType;

	/**
	 * Clears the user-editable data fields for this form
	 */
	public void clear() {
		this.billDateOptions = new ArrayList();
		this.selectedBillDate = "";
	}

	/**
	 * make a Collection of LabelValueBean objects or building a select tag in
	 * jsp
	 *
	 * @return Collection of LabelValueBean objects
	 * @throws java.lang.Exception if any.
	 */
	public Collection getBillDateOptions() throws Exception {

		if ((this.billDateOptions == null) && (this.getServlet() != null)) {
			// make a DTO with the currently selected group number
			InsuredDataDTO dataDTO = new InsuredDataDTO();
			dataDTO.setGroupNumber(this.getGroupNumber());

			String iniFile = CommonUtils.getIniFile(this.getServlet());

			// fetch the last 6 bill history row from DB2
			BillServices billServices = new BillServices(iniFile);
			// make into a choice list
			this.billDateOptions = billServices.getbillOptions(dataDTO);
		}
		return this.billDateOptions;
	}

	/**
	 * <p>Setter for the field <code>billDateOptions</code>.</p>
	 *
	 * @param collection a {@link java.util.Collection} object.
	 */
	public void setBillDateOptions(Collection collection) {
		this.billDateOptions = collection;
	}

	/**
	 * <p>Getter for the field <code>selectedBillDate</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getSelectedBillDate() {
		return this.selectedBillDate;
	}

	/**
	 * <p>Setter for the field <code>selectedBillDate</code>.</p>
	 *
	 * @param string a {@link java.lang.String} object.
	 */
	public void setSelectedBillDate(String string) {
		this.selectedBillDate = string;
	}

	/**
	 * Type of request: history, summary, or other
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getRequestType() {
		return this.requestType;
	}

	/**
	 * Type of request: history, summary, or other
	 *
	 * @param string
	 *            type
	 */
	public void setRequestType(String string) {
		this.requestType = string;
	}

	/**
	 * Type of bill requested:
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getBillType() {
		return this.billType;
	}

	/**
	 * Type of bill requested:
	 *
	 * @param string
	 *            type
	 */
	public void setBillType(String string) {
		this.billType = string;
	}

	/**
	 * Type of bill requested:
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getFormattedBillType() {
		return com.bcbssc.struts.forms.Options.getLabelFromValue(this
				.getOptions().getBillTypeOptions(), this.billType);
	}

	/**
	 * Type of bill requested:
	 *
	 * @param string
	 *            type
	 */
	public void setFormattedBillType(String string) {
		// Do nothing
	}

}
