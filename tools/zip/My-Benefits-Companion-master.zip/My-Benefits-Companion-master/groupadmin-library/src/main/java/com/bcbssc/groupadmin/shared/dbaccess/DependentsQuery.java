/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/DependentsQuery.java_v  $
 * $Workfile:   DependentsQuery.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:14:14  $
 * $Modtime:   May 14 2009 11:33:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-library-groupadmin/src/main/java/com/bcbssc/groupadmin/shared/dbaccess/DependentsQuery.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:14:14   EN80
 * Initial revision.
 * 
 *    Rev 1.8   Apr 28 2009 10:17:58   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.7   Feb 16 2005 09:45:42   rdq70
 * Incorporated revised SQL.
 *
 *    Rev 1.6   Feb 15 2005 16:15:22   rdq70
 * Removed formatting of gender, status, student and smoker.
 *
 *    Rev 1.5   Feb 15 2005 11:17:50   rdq70
 * Removed SSN formatting built into SQL.
 *
 *    Rev 1.4   Feb 08 2005 14:26:20   rdq70
 * Use ASSIGNED_NAME_ID instead of NAME_ID.
 *
 *    Rev 1.3   Feb 03 2005 13:30:24   rdq70
 * Javadoc correction.
 *
 *    Rev 1.2   Feb 03 2005 10:49:52   rdq70
 * Renamed MQ_TABLE to GCOM_TABLE.
 *
 *    Rev 1.1   Feb 02 2005 11:18:40   rdq70
 * Added Dependent.nameId property.
 *
 *    Rev 1.0   Feb 02 2005 09:56:30   rdq70
 * Initial revision.
 *
 */

package com.bcbssc.groupadmin.shared.dbaccess;

import com.bcbssc.groupadmin.shared.dto.Dependent;
import com.bcbssc.groupadmin.shared.dto.InsuredDataDTO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

/**
 * This query pulls the detail information for an insured employees' dependents
 * (except for spouse).<br>
 *
 * <pre>
 *     QMF NAME: RX13U.WEB_SQL_5_D
 *     TSO NAME: WEBSQL5D
 * </pre>
 *
 * @author dq70 (D. Allen)
 * @version $Id: $Id
 */
public class DependentsQuery extends AbstractDBSearch {

	/**
	 * Creates a <code>DependentsQuery</code> and configures it with an INI
	 * file.
	 *
	 * @param iniFile
	 *            file path of the configuration INI file.
	 */
	public DependentsQuery(String iniFile) {
		super(iniFile, "GCOM_TABLE");
	}

	/**
	 * Pulls the detail information for an insured employees' dependents (except
	 * for spouse), and adds them to the given parent bean. <br>
	 *
	 * <pre>
	 *     QMF NAME: RX13U.WEB_SQL_5_D
	 *     TSO NAME: WEBSQL5D
	 * </pre>
	 *
	 * @param insuredData
	 *            the bean containing data for the search. It needs only the
	 *            groupNumber and identificationNumber properties set.
	 * @return the <code>DependentList</code> of the the given
	 *         <code>insuredData</code> populated with the search results.
	 * @throws java.sql.SQLException
	 *             if an error occurs during the SQL query.
	 */
	public Collection performSearch(InsuredDataDTO insuredData)
			throws SQLException {
		this.checkInit(); // Necessary since we need the _dbSchema before the
							// query creation

		final StringBuffer sql = new StringBuffer(1500);

		sql.append(
				"SELECT LAST_NAME" + "  , FIRST_NAME" + "  , INITIAL"
						+ "  , CHAR(DOB,USA) \"DOB\"" + "  , SEX" + "  , SSN"
						+ "  , CASE BENE_RELATION"
						+ "      WHEN 'HUS' THEN 'SPS'"
						+ "      WHEN 'WIF' THEN 'SPS'"
						+ "      WHEN 'FTR' THEN 'PRT'"
						+ "      WHEN 'MTH' THEN 'PRT'"
						+ "      WHEN 'CLH' THEN 'CHL'"
						+ "      WHEN 'DTR' THEN 'CHL'"
						+ "      WHEN 'SON' THEN 'CHL'"
						+ "      ELSE BENE_RELATION"
						+ "    END \"RELATIONSHIP\""
						+ "  , STUDENT_IND \"STUDENT\"" + "  , NAME_ID"
						+ "  , ASSIGNED_NAME_ID" + "    FROM ").append(
				this._dbSchema).append(
				".VCRTDPDZ" + "   WHERE COMPANY_CODE = ?"
						+ "     AND GROUP_PREFIX = ?"
						+ "     AND GROUP_NUMBER = ?"
						+ "     AND DIVISION_ID = ?"
						+ "     AND CERTIFICATE_ID = ?"
						+ "     AND BENE_RELATION NOT IN ('SPS','HUS','WIF')");

		final String[] params = { insuredData.getCompany(),
				insuredData.getGroupPrefix(), insuredData.getGroupBase(),
				insuredData.getDivisionCode(),
				insuredData.getIdentificationNumber() };

		return this.performSearch(sql.toString(), params, insuredData
				.getDependents());
	}

	/**
	 * {@inheritDoc}
	 *
	 * Adds data from the given result set to the target collection.
	 * @see com.bcbssc.groupadmin.shared.dto.DependentList
	 */
	protected void addSearchItem(ResultSet data, Object obj)
			throws SQLException {
		final Collection collection = (Collection) obj;
		final Dependent dependent = new Dependent();

		dependent.setLastName(data.getString("LAST_NAME").trim());
		dependent.setGivenName(data.getString("FIRST_NAME").trim());
		dependent.setMiddleIni(data.getString("INITIAL"));
		dependent.setDateOfBirth(DatabaseProxy.getDateBean(data
				.getString("DOB")));
		dependent.setGender(data.getString("SEX"));
		dependent.setSsn(data.getString("SSN").trim());
		dependent.setRelationship(data.getString("RELATIONSHIP"));
		dependent.setStudent(data.getString("STUDENT"));
		// dependent.setNameId(data.getString("NAME_ID").trim());
		dependent.setNameId(data.getString("ASSIGNED_NAME_ID").trim());

		collection.add(dependent);
	}
}
