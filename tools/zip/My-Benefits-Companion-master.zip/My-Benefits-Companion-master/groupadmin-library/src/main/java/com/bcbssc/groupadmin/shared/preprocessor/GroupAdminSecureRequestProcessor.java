/*
 * @(#)GroupAdminSecureRequestProcessor.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.groupadmin.shared.preprocessor;

import com.bcbssc.registration.preprocessor.SecureRequestProcessor;

import com.bcbssc.groupadmin.shared.common.CommonUtils;
import com.bcbssc.groupadmin.shared.services.GroupAdminSecureServices;
import com.bcbssc.registration.services.ISecureServices;

import javax.servlet.ServletContext;

//import org.apache.log4j.Logger;

/**
 * GroupAdmin Permission Request Processor
 *
 * This provides an application-specific implementation of the permission-setting
 * RequestProcessor.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.1  $
 */
public class GroupAdminSecureRequestProcessor extends SecureRequestProcessor {

	/** log4j logger */
//    private static Logger logger = Logger.getLogger(GroupAdminSecureRequestProcessor.class);;

    /**
     * Creates an application-specific services object
     *
     * @return services object
     */
    protected ISecureServices getServices() {
        // The servlet has the context that contains the ini file locations
        ServletContext servletContext = getServletContext();
        String iniFile = CommonUtils.getIniFile(servletContext);
        String tdsIniFile = CommonUtils.getTDSIniFile(servletContext);   
        //String tdsSuperUserIniFile = CommonUtils.getTDSSuperUserIniFile(servletContext); 
        return new GroupAdminSecureServices(iniFile, tdsIniFile);
    }
}
