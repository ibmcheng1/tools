package com.bcbssc.commapi.model.common;

import java.io.Serializable;

 /**
  * An class representing a APIException object.
  *
  * @author FF74
  * @version $Id: $Id
  */
 public class APIException extends Exception implements Serializable {
    
    /** Holds value of the serialVersionUID */
    private static final long serialVersionUID = -209867936048L;

    /**
     * Creates a new instance of APIException
     */
    public APIException() {
        this(null, null);
    }// End of constructor APIException()

    /**
     * Creates a new instance of APIException
     *
     * @param message a {@link java.lang.String} object.
     */
    public APIException(String message) {
        this(message, null);
    }// End of constructor APIException(String)

    /**
     * Creates a new instance of APIException
     *
     * @param cause a {@link java.lang.Throwable} object.
     */
    public APIException(Throwable cause) {
        this(null, cause);
    }// End of constructor APIException(Throwable)

    /**
     * Creates a new instance of APIException
     *
     * @param message a {@link java.lang.String} object.
     * @param cause a {@link java.lang.Throwable} object.
     */
    public APIException(String message, Throwable cause) {
        super(message, cause);
    }// End of constructor APIException(String, Throwable)
}// End of class APIException
