package com.bcbssc.commapi.model.common;

import java.io.Serializable;

/**
 * An class representing a DocumentNotFoundException object.
 *
 * @author FF74
 * @version $Id: $Id
 */
public class DocumentNotFoundException extends APIException implements
		Serializable {
	
    /** Holds value of the serialVersionUID */
	private static final long serialVersionUID = 1L;

	/**
	 * Creates a new instance of DocumentNotFoundException
	 */
	public DocumentNotFoundException() {
		this(null, null);
	}// End of constructor DocumentNotFoundException()
	
	/**
	 * Creates a new instance of DocumentNotFoundException
	 *
	 * @param message a {@link java.lang.String} object.
	 */
	public DocumentNotFoundException(String message) {
		this(message, null);
	}// End of constructor DocumentNotFoundException(String)
	
	/**
	 * Creates a new instance of DocumentNotFoundException
	 *
	 * @param cause a {@link java.lang.Throwable} object.
	 */
	public DocumentNotFoundException(Throwable cause) {
		this(null, cause);
	}// End of constructor DocumentNotFoundException(Throwable)
	
	/**
	 * Creates a new instance of DocumentNotFoundException
	 *
	 * @param message a {@link java.lang.String} object.
	 * @param cause a {@link java.lang.Throwable} object.
	 */
	public DocumentNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}// End of constructor DocumentNotFoundException(String, Throwable)
}// End of class DocumentNotFoundException
