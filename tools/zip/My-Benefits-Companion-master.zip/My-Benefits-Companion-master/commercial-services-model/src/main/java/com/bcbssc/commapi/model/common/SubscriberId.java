/**
 * 
 */
package com.bcbssc.commapi.model.common;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * An class representing a SubscriberId object.
 *
 * @author FF74
 * @version $Id: $Id
 */
public class SubscriberId implements Serializable {
	
    /** Holds value of the serialVersionUID */
	private static final long serialVersionUID = 1538844695691268827L;

    /** Holds value of property memberNumber. */
	private String memberNumber;

    /** Holds value of property idCardNumber. */
	private String idCardNumber;
	
	/**
	 * Creates a new instance of SubscriberId
	 */
	public SubscriberId() {
		this(null, null);
	}// End of constructor SubscriberId()
	
	/**
	 * Creates a new instance of SubscriberId
	 *
	 * @param memberNumber a {@link java.lang.String} object.
	 * @param idCardNumber a {@link java.lang.String} object.
	 */
	public SubscriberId(String memberNumber, String idCardNumber) {
		this.memberNumber = memberNumber;
		this.idCardNumber = idCardNumber;
	}// End of constructor SubscriberId(String, String)
	
	/**
	 * Getter for property memberNumber.
	 *
	 * @return the memberNumber
	 */
	public String getMemberNumber() {
		return this.memberNumber;
	}// End of method getMemberNumber()

	/**
	 * Setter for property memberNumber.
	 *
	 * @param memberNumber the memberNumber to set
	 */
	public void setMemberNumber(String memberNumber) {
		this.memberNumber = memberNumber;
	}// End of method setMemberNumber()

	/**
	 * Getter for property idCardNumber.
	 *
	 * @return the idCardNumber
	 */
	public String getIdCardNumber() {
		return this.idCardNumber;
	}// End of method getIdCardNumber()

	/**
	 * Setter for property idCardNumber.
	 *
	 * @param idCardNumber the idCardNumber to set
	 */
	public void setIdCardNumber(String idCardNumber) {
		this.idCardNumber = idCardNumber;
	}// End of method setIdCardNumber()

	/**
	 * The string representation of this class.
	 *
	 * @return the string representation of this class
	 */
	public String toString() {
    	return ToStringBuilder.reflectionToString(this);
    }// End of method toString()
}// End of class SubscriberId
