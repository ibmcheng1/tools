/**
 * 
 */
package com.bcbssc.commapi.model.documentarchive;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.log4j.Logger;

import com.bcbssc.commapi.model.common.CommonListDocument;

/**
 * An class representing a EDIGReport object.
 *
 * @author FF74
 * @version $Id: $Id
 */
public class EDIGReport extends CommonListDocument implements Serializable {
	
    /** Holds value of the serialVersionUID */
	private static final long serialVersionUID = 1L;

	/** The log4j logger for this class */
    private static Logger logger = Logger.getLogger(EDIGReport.class);

    /** Holds value of property npi. */
	private String npi;

    /** Holds value of property postingDate. */
	private String postingDate;

    /** Holds value of property provider. */
	private String provider;

    /** Holds value of property receivedDate. */
	private String receivedDate;

    /** Holds value of property reportId. */
	private String reportId;

    /** Holds value of property reportIdDesc. */
	private String reportIdDesc;

	/**
	 * Creates a new instance of EDIGReport
	 */
	public EDIGReport() {
		if(EDIGReport.logger.isDebugEnabled()) {
			EDIGReport.logger.debug("Created EDIGReport object.");
		}// End of if(EDIGReport.logger.isDebugEnabled())
	}// End of constructor EDIGReport()

	/**
	 * Getter for property npi.
	 *
	 * @return the npi
	 */
	public String getNpi() {
		return this.npi;
	}// End of method getNpi()

	/**
	 * Setter for property npi.
	 *
	 * @param npi the npi to set
	 */
	public void setNpi(String npi) {
		this.npi = npi;
	}// End of method setNpi()

	/**
	 * Getter for property postingDate.
	 *
	 * @return the postingDate
	 */
	public String getPostingDate() {
		return this.postingDate;
	}// End of method getPostingDate()

	/**
	 * Setter for property postingDate.
	 *
	 * @param postingDate the postingDate to set
	 */
	public void setPostingDate(String postingDate) {
		this.postingDate = postingDate;
	}// End of method setPostingDate()

	/**
	 * Getter for property provider.
	 *
	 * @return the provider
	 */
	public String getProvider() {
		return this.provider;
	}// End of method getProvider()

	/**
	 * Setter for property provider.
	 *
	 * @param provider the provider to set
	 */
	public void setProvider(String provider) {
		this.provider = provider;
	}// End of method setProvider()

	/**
	 * Getter for property receivedDate.
	 *
	 * @return the receivedDate
	 */
	public String getReceivedDate() {
		return this.receivedDate;
	}// End of method getReceivedDate()

	/**
	 * Setter for property receivedDate.
	 *
	 * @param receivedDate the receivedDate to set
	 */
	public void setReceivedDate(String receivedDate) {
		this.receivedDate = receivedDate;
	}// End of method setReceivedDate()

	/**
	 * Getter for property reportId.
	 *
	 * @return the reportId
	 */
	public String getReportId() {
		return this.reportId;
	}// End of method getReportId()

	/**
	 * Setter for property reportId.
	 *
	 * @param reportId the reportId to set
	 */
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}// End of method setReportId()

	/**
	 * Getter for property reportIdDesc.
	 *
	 * @return the reportIdDesc
	 */
	public String getReportIdDesc() {
		return this.reportIdDesc;
	}// End of method getReportIdDesc()

	/**
	 * Setter for property reportIdDesc.
	 *
	 * @param reportIdDesc the reportIdDesc to set
	 */
	public void setReportIdDesc(String reportIdDesc) {
		this.reportIdDesc = reportIdDesc;
	}// End of method setReportIdDesc()

	/**
	 * The string representation of this class.
	 *
	 * @return the string representation of this class
	 */
	public String toString() {
    	return ToStringBuilder.reflectionToString(this);
    }// End of method toString()
}// End of class EDIGReport
