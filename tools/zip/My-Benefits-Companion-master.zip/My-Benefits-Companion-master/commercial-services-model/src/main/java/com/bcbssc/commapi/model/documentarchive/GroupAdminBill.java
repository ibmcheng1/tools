/**
 * 
 */
package com.bcbssc.commapi.model.documentarchive;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.log4j.Logger;

import com.bcbssc.commapi.model.common.CommonListDocument;

/**
 * An class representing a GroupAdminBill object.
 *
 * @author FF74
 * @version $Id: $Id
 */
public class GroupAdminBill extends CommonListDocument implements Serializable {
	
    /** Holds value of the serialVersionUID */
	private static final long serialVersionUID = 1L;

	/** The log4j logger for this class */
    private static Logger logger = Logger.getLogger(GroupAdminBill.class);

    /** Holds value of property date. */
	private String date;

    /** Holds value of property description. */
	private String description;

    /** Holds value of property groupNumber. */
	private String groupNumber;

    /** Holds value of property postingDate. */
	private String postingDate;

    /** Holds value of property reportId. */
	private String reportId;

    /** Holds value of property reportIdDesc. */
	private String reportIdDesc;

	/**
	 * Creates a new instance of GroupAdminBill
	 */
	public GroupAdminBill() {
		if(GroupAdminBill.logger.isDebugEnabled()) {
			GroupAdminBill.logger.debug("Created GroupAdminBill object.");
		}// End of if(GroupAdminBill.logger.isDebugEnabled())
	}// End of constructor GroupAdminBill()

	/**
	 * Getter for property groupNumber.
	 *
	 * @return the groupNumber
	 */
	public String getGroupNumber() {
		return this.groupNumber;
	}// End of method getGroupNumber()

	/**
	 * Setter for property groupNumber.
	 *
	 * @param groupNumber the groupNumber to set
	 */
	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}// End of method setGroupNumber()

	/**
	 * Getter for property postingDate.
	 *
	 * @return the postingDate
	 */
	public String getPostingDate() {
		return this.postingDate;
	}// End of method getPostingDate()

	/**
	 * Setter for property postingDate.
	 *
	 * @param postingDate the postingDate to set
	 */
	public void setPostingDate(String postingDate) {
		this.postingDate = postingDate;
	}// End of method setPostingDate()

	/**
	 * Getter for property reportId.
	 *
	 * @return the reportId
	 */
	public String getReportId() {
		return this.reportId;
	}// End of method getReportId()

	/**
	 * Setter for property reportId.
	 *
	 * @param reportId the reportId to set
	 */
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}// End of method setReportId()

	/**
	 * Getter for property reportIdDesc.
	 *
	 * @return the reportIdDesc
	 */
	public String getReportIdDesc() {
		return this.reportIdDesc;
	}// End of method getReportIdDesc()

	/**
	 * Setter for property reportIdDesc.
	 *
	 * @param reportIdDesc the reportId to set
	 */
	public void setReportIdDesc(String reportIdDesc) {
		this.reportIdDesc = reportIdDesc;
	}// End of method setReportIdDesc()

	/**
	 * Getter for property description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return this.description;
	}// End of method getDescription()

	/**
	 * Setter for property description.
	 *
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}// End of method setDescription()

	/**
	 * Getter for property date.
	 *
	 * @return the date
	 */
	public String getDate() {
		return this.date;
	}// End of method getDate()

	/**
	 * Setter for property date.
	 *
	 * @param date the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}// End of method setDate()

	/**
	 * The string representation of this class.
	 *
	 * @return the string representation of this class
	 */
	public String toString() {
    	return ToStringBuilder.reflectionToString(this);
    }// End of method toString()
}// End of class GroupAdminBill
