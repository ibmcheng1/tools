/**
 * 
 */
package com.bcbssc.commapi.model.documentarchive;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.log4j.Logger;

import com.bcbssc.commapi.model.common.CommonListDocument;

/**
 * An class representing a Letter object.
 *
 * @author FF74
 * @version $Id: $Id
 */
public class Letter extends CommonListDocument implements Serializable {
	
    /** Holds value of the serialVersionUID */
	private static final long serialVersionUID = 1L;

	/** The log4j logger for this class */
    private static Logger logger = Logger.getLogger(Letter.class);

    /** Holds value of property claimNumber. */
	private String claimNumber;

    /** Holds value of property filler1. */
	private String filler1;

    /** Holds value of property idCardNumber. */
	private String idCardNumber;

    /** Holds value of property patientName. */
	private String patientName;

    /** Holds value of property postingDate. */
	private String postingDate;

    /** Holds value of property providerNumber. */
	private String providerNumber;

    /** Holds value of property regionId. */
	private String regionId;

    /** Holds value of property reportId. */
	private String reportId;

    /** Holds value of property reportIdDescription. */
	private String reportIdDescription;

    /** Holds value of property serviceDate. */
	private String serviceDate;

    /** Holds value of property subscriberId. */
	private String subscriberId;

    /** Holds value of property timeStamp. */
	private String timeStamp;

	/**
	 * Creates a new instance of Letter
	 */
	public Letter() {
		if(Letter.logger.isDebugEnabled()) {
			Letter.logger.debug("Created Letter object.");
		}// End of if(Letter.logger.isDebugEnabled())
	}// End of constructor Letter()

	/**
	 * Getter for property claimNumber.
	 *
	 * @return the claimNumber
	 */
	public String getClaimNumber() {
		return this.claimNumber;
	}// End of method getClaimNumber()

	/**
	 * Setter for property claimNumber.
	 *
	 * @param claimNumber the claimNumber to set
	 */
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}// End of method setClaimNumber()

	/**
	 * Getter for property subscriberId.
	 *
	 * @return the subscriberId
	 */
	public String getSubscriberId() {
		return this.subscriberId;
	}// End of method getSubscriberId()

	/**
	 * Setter for property subscriberId.
	 *
	 * @param subscriberId the subscriberId to set
	 */
	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}// End of method setSubscriberId()

	/**
	 * Getter for property providerNumber.
	 *
	 * @return the providerNumber
	 */
	public String getProviderNumber() {
		return this.providerNumber;
	}// End of method getProviderNumber()

	/**
	 * Setter for property providerNumber.
	 *
	 * @param providerNumber the providerNumber to set
	 */
	public void setProviderNumber(String providerNumber) {
		this.providerNumber = providerNumber;
	}// End of method setProviderNumber()

	/**
	 * Getter for property timeStamp.
	 *
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return this.timeStamp;
	}// End of method getTimeStamp()

	/**
	 * Setter for property timeStamp.
	 *
	 * @param timeStamp the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}// End of method setTimeStamp()

	/**
	 * Getter for property idCardNumber.
	 *
	 * @return the idCardNumber
	 */
	public String getIdCardNumber() {
		return this.idCardNumber;
	}// End of method getIdCardNumber()

	/**
	 * Setter for property idCardNumber.
	 *
	 * @param idCardNumber the idCardNumber to set
	 */
	public void setIdCardNumber(String idCardNumber) {
		this.idCardNumber = idCardNumber;
	}// End of method setIdCardNumber()

	/**
	 * Getter for property postingDate.
	 *
	 * @return the postingDate
	 */
	public String getPostingDate() {
		return this.postingDate;
	}// End of method getPostingDate()

	/**
	 * Setter for property postingDate.
	 *
	 * @param postingDate the postingDate to set
	 */
	public void setPostingDate(String postingDate) {
		this.postingDate = postingDate;
	}// End of method setPostingDate()
	
	/**
	 * Getter for property regionId.
	 *
	 * @return the regionId
	 */
	public String getRegionId() {
		return this.regionId;
	}// End of method getRegionId()

	/**
	 * Setter for property regionId.
	 *
	 * @param regionId the regionId to set
	 */
	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}// End of method setRegionId()

	/**
	 * Getter for property reportId.
	 *
	 * @return the reportId
	 */
	public String getReportId() {
		return this.reportId;
	}// End of method getReportId()

	/**
	 * Setter for property reportId.
	 *
	 * @param reportId the reportId to set
	 */
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}// End of method setReportId()

	/**
	 * Getter for property patientName.
	 *
	 * @return the patientName
	 */
	public String getPatientName() {
		return this.patientName;
	}// End of method getPatientName()

	/**
	 * Setter for property patientName.
	 *
	 * @param patientName the patientName to set
	 */
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}// End of method setPatientName()

	/**
	 * Getter for property serviceDate.
	 *
	 * @return the serviceDate
	 */
	public String getServiceDate() {
		return this.serviceDate;
	}// End of method getServiceDate()

	/**
	 * Setter for property serviceDate.
	 *
	 * @param serviceDate the serviceDate to set
	 */
	public void setServiceDate(String serviceDate) {
		this.serviceDate = serviceDate;
	}// End of method setServiceDate()

	/**
	 * Getter for property filler1.
	 *
	 * @return the filler1
	 */
	public String getFiller1() {
		return this.filler1;
	}// End of method getFiller1()

	/**
	 * Setter for property filler1.
	 *
	 * @param filler1 the filler1 to set
	 */
	public void setFiller1(String filler1) {
		this.filler1 = filler1;
	}// End of method setFiller1()

	/**
	 * Getter for property reportIdDescription.
	 *
	 * @return the reportIdDescription
	 */
	public String getReportIdDescription() {
		return this.reportIdDescription;
	}// End of method getReportIdDescription()

	/**
	 * Setter for property reportIdDescription.
	 *
	 * @param reportIdDescription the reportIdDescription to set
	 */
	public void setReportIdDescription(String reportIdDescription) {
		this.reportIdDescription = reportIdDescription;
	}// End of method setReportIdDescription()

	/**
	 * The string representation of this class.
	 *
	 * @return the string representation of this class
	 */
	public String toString() {
    	return ToStringBuilder.reflectionToString(this);
    }// End of method toString()
}// End of class Letter
