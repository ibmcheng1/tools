/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * WebServiceCommonInput.java
 * 
 * Created on Oct 12, 2009 by EN80

 */

package com.bcbssc.services.model;

import java.io.Serializable;

/**
 * This class holds the minimum required service inputs.
 *
 * <pre>
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-services-model/src/main/java/com/bcbssc/services/model/WebServiceCommonInput.java_v  $
 * $Workfile:   WebServiceCommonInput.java  $
 * $Revision:   1.0  $
 * $Date:   Oct 20 2009 12:00:40  $
 * $Modtime:   Oct 19 2009 13:33:56  $
 * </pre>
 *
 * @author $Author:   EN80  $
 * @version $Id: $Id
 */
public class WebServiceCommonInput implements Serializable {

	private static final long serialVersionUID = 186786786785567L;
	
	private String hostID;
	private String hostPassword;
	private String hostRegion;
	/**
	 * <p>Getter for the field <code>hostID</code>.</p>
	 *
	 * @return the hostID
	 */
	public String getHostID() {
		return hostID;
	}
	/**
	 * <p>Setter for the field <code>hostID</code>.</p>
	 *
	 * @param hostID the hostID to set
	 */
	public void setHostID(String hostID) {
		this.hostID = hostID;
	}
	/**
	 * <p>Getter for the field <code>hostPassword</code>.</p>
	 *
	 * @return the hostPassword
	 */
	public String getHostPassword() {
		return hostPassword;
	}
	/**
	 * <p>Setter for the field <code>hostPassword</code>.</p>
	 *
	 * @param hostPassword the hostPassword to set
	 */
	public void setHostPassword(String hostPassword) {
		this.hostPassword = hostPassword;
	}
	/**
	 * <p>Getter for the field <code>hostRegion</code>.</p>
	 *
	 * @return the hostRegion
	 */
	public String getHostRegion() {
		return hostRegion;
	}
	/**
	 * <p>Setter for the field <code>hostRegion</code>.</p>
	 *
	 * @param hostRegion the hostRegion to set
	 */
	public void setHostRegion(String hostRegion) {
		this.hostRegion = hostRegion;
	}	
	
	//@TODO add more attributes as required
	
	
}
