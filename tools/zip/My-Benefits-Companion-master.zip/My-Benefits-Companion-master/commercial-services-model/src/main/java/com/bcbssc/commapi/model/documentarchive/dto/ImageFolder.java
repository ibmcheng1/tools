/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * ImageFolder.java
 * Date: May 25, 2010
 */
package com.bcbssc.commapi.model.documentarchive.dto;

/**
 * An enum representing an ImageFolder name.
 *
 * Author: FF74
 *
 * @author jc33
 * @version $Id: $Id
 */
public enum ImageFolder {

	// EDIG folder names
	EDIG_REPORTS("EDIG.REPORTS"),
	EDIG_DETAIL_REPORTS("EDIGDETL"),
	EDIG_SUMMARY_REPORTS("EDIGSUMM"),

	// EOB folder names
	EOBS("EOBS"),
	WEB_SUMMARYEOB ("WEB.SUMMARYEOB"),
	
	// GROUP ADMIN folder name
	GROUP_ADMIN_BILL("CPLGRB"),
	// GROUP ADMIN CERT FOLDER NAME
	
	GROUP_ADMIN_CERT("GCOM.WEB.CERT"),
	GROUP_ADMIN_POLICY("GCOM.WEB.POLICY"),
	GROUP_ADMIN_DENTAL_CARD("GCOMDENC"),

	// DENTAL LETTER folder names
    DENTAL_PROV_LETTERS("DENTAL.PROV.LETTERS"),
	DENTAL_SBSR_LETTERS("DENTAL.SBSR.LETTERS"),
	
	// SECURE RESPONSE folder name
	SECURE_RESPONSE("SECURE.RESPONSE"),
	
	// REMIT folder names
    PROFESSIONAL_REMITS("DOCTOR.REMITS"),
	INSTITUTIONAL_REMITS("HOSPITAL.REMITS"),
	OUTPATIENTLINELEVEL_REMITS("HOSPITAL.REMITS"),
	DENTAL_REMITS("DENTAL.REMITS");

    /** Holds value of property folderName. */
	private String folderName;

	/**
     * Creates a new enum of ImageFolder.
     * 
	 * @param folderName the folderName to set
	 */
	private ImageFolder(String folderName) {
		this.folderName = folderName;
	}// End of constructor ImageFolder()

	/**
	 * Getter for property folderName.
	 *
	 * @return the folderName
	 */
	public String getFolderName() {
		return this.folderName;
	}// End of method getFolderName()
}// End of enum ImageFolder
