/**
 * 
 */
package com.bcbssc.commapi.model.common;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * An class representing a GroupAdminId object.
 *
 * @author FF74
 * @version $Id: $Id
 */
public class GroupAdminId implements Serializable {
	
    /** Holds value of the serialVersionUID */
	private static final long serialVersionUID = 15395691268827L;

    /** Holds value of property groupAdminIdentifier. */
	private String groupAdminIdentifier;
	
	
	private String certId;
	
	private String dentalCardId;
	
	
	
	/**
	 * <p>Setter for the field <code>dentalCardId</code>.</p>
	 *
	 * @param dentalCardId a {@link java.lang.String} object.
	 */
	public void setDentalCardId(String dentalCardId){
		this.dentalCardId = dentalCardId;
	}
	
	
	/**
	 * <p>Getter for the field <code>dentalCardId</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getDentalCardId(){
		return this.dentalCardId;
	}
	
	/**
	 * <p>Getter for the field <code>certId</code>.</p>
	 *
	 * @return the certId
	 */
	public String getCertId() {
		return certId;
	}

	/**
	 * <p>Setter for the field <code>certId</code>.</p>
	 *
	 * @param certId the certId to set
	 */
	public void setCertId(String certId) {
		this.certId = certId;
	}

	/**
	 * Creates a new instance of GroupAdminId
	 */
	public GroupAdminId() {
		this(null);
	}// End of constructor GroupAdminId()
	
	/**
	 * Creates a new instance of GroupAdminId
	 *
	 * @param groupAdminIdentifier a {@link java.lang.String} object.
	 */
	public GroupAdminId(String groupAdminIdentifier) {
		this.groupAdminIdentifier = groupAdminIdentifier;
	}// End of constructor GroupAdminId(String)

	/**
	 * Getter for property groupAdminIdentifier.
	 *
	 * @return the groupAdminIdentifier
	 */
	public String getGroupAdminIdentifier() {
		return this.groupAdminIdentifier;
	}// End of method getGroupAdminIdentifier()

	/**
	 * Setter for property groupAdminIdentifier.
	 *
	 * @param groupAdminIdentifier the groupAdminIdentifier to set
	 */
	public void setGroupAdminIdentifier(String groupAdminIdentifier) {
		this.groupAdminIdentifier = groupAdminIdentifier;
	}// End of method setGroupAdminIdentifier()

	/**
	 * The string representation of this class.
	 *
	 * @return the string representation of this class
	 */
	public String toString() {
    	return ToStringBuilder.reflectionToString(this);
    }// End of method toString()
}// End of class GroupAdminId
