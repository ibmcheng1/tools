package com.bcbssc.commapi.model.documentarchive;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.log4j.Logger;

import com.bcbssc.commapi.model.common.CommonListDocument;

/**
 * An class representing a Remit object.
 *
 * Author: FF74
 *
 * @author jc33
 * @version $Id: $Id
 */
public class Remit extends CommonListDocument implements Serializable {
	
    /** Holds value of the serialVersionUID */
	private static final long serialVersionUID = 1L;

	/** The log4j logger for this class */
    private static Logger logger = Logger.getLogger(Remit.class);

    /** Holds value of property checkDate. */
	private String checkDate;

    /** Holds value of property descriptive. */
	private String descriptive;

    /** Holds value of property npi. */
	private String npi;

    /** Holds value of property postingDate. */
	private String postingDate;

    /** Holds value of property providerNo. */
	private String providerNo;

    /** Holds value of property regionId. */
	private String regionId;

    /** Holds value of property reportId. */
	private String reportId;

    /** Holds value of property reportIdDesc. */
	private String reportIdDesc;

	/**
	 * Creates a new instance of Remit
	 */
	public Remit() {
		if(Remit.logger.isDebugEnabled()) {
			Remit.logger.debug("Created Remit object.");
		}// End of if(Remit.logger.isDebugEnabled())
	}// End of constructor Remit()
	
	/**
	 * Getter for property npi.
	 *
	 * @return the npi
	 */
	public String getNPI() {
		return npi;
	}// End of method getSubscriberId()

	/**
	 * Setter for property npi.
	 *
	 * @param npi the npi to set
	 */
	public void setNPI(String npi) {
		this.npi = npi;
	}// End of method getSubscriberId()

	/**
	 * Getter for property providerNo.
	 *
	 * @return the providerNo
	 */
	public String getProviderNo() {
		return providerNo;
	}// End of method getSubscriberId()

	/**
	 * Setter for property providerNo.
	 *
	 * @param providerNo the providerNo to set
	 */
	public void setProviderNo(String providerNo) {
		this.providerNo = providerNo;
	}// End of method getSubscriberId()

	/**
	 * Getter for property reportId.
	 *
	 * @return the reportId
	 */
	public String getReportId() {
		return reportId;
	}// End of method getSubscriberId()

	/**
	 * Setter for property reportId.
	 *
	 * @param reportId the reportId to set
	 */
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}// End of method getSubscriberId()

	/**
	 * Getter for property descriptive.
	 *
	 * @return the descriptive
	 */
	public String getDescriptive() {
		return descriptive;
	}// End of method getSubscriberId()

	/**
	 * Setter for property descriptive.
	 *
	 * @param descriptive the descriptive to set
	 */
	public void setDescriptive(String descriptive) {
		this.descriptive = descriptive;
	}// End of method getSubscriberId()

	/**
	 * Getter for property regionId.
	 *
	 * @return the regionId
	 */
	public String getRegionId() {
		return regionId;
	}// End of method getSubscriberId()

	/**
	 * Setter for property regionId.
	 *
	 * @param regionId the regionId to set
	 */
	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}// End of method getSubscriberId()

	/**
	 * Getter for property postingDate.
	 *
	 * @return the postingDate
	 */
	public String getPostingDate() {
		return postingDate;
	}// End of method getSubscriberId()

	/**
	 * Setter for property postingDate.
	 *
	 * @param postingDate the postingDate to set
	 */
	public void setPostingDate(String postingDate) {
		this.postingDate = postingDate;
	}// End of method getSubscriberId()

	/**
	 * Getter for property reportIdDesc.
	 *
	 * @return the reportIdDesc
	 */
	public String getReportIdDesc() {
		return reportIdDesc;
	}// End of method getSubscriberId()

	/**
	 * Setter for property reportIdDesc.
	 *
	 * @param reportIdDesc the reportIdDesc to set
	 */
	public void setReportIdDesc(String reportIdDesc) {
		this.reportIdDesc = reportIdDesc;
	}// End of method getSubscriberId()

	/**
	 * Getter for property checkDate.
	 *
	 * @return the checkDate
	 */
	public String getCheckDate() {
		return checkDate;
	}// End of method getSubscriberId()

	/**
	 * Setter for property checkDate.
	 *
	 * @param checkDate the checkDate to set
	 */
	public void setCheckDate(String checkDate) {
		this.checkDate = checkDate;
	}// End of method getSubscriberId()

	/**
	 * The string representation of this class.
	 *
	 * @return the string representation of this class
	 */
	public String toString() {
    	return ToStringBuilder.reflectionToString(this);
    }// End of method toString()
}// End of class Remit
