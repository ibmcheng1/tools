/**
 * 
 */
package com.bcbssc.commapi.model.documentarchive;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.log4j.Logger;

import com.bcbssc.commapi.model.common.CommonListDocument;

/**
 * An class representing a EOB object.
 *
 * @author FF74
 * @version $Id: $Id
 */
public class EOB extends CommonListDocument implements Serializable {
	
    /** Holds value of the serialVersionUID */
	private static final long serialVersionUID = 1L;

	/** The log4j logger for this class */
    private static Logger logger = Logger.getLogger(EOB.class);

    /** Holds value of property checkDate. */
	private String checkDate;

    /** Holds value of property claimNumber. */
	private String claimNumber;

    /** Holds value of property filler1. */
	private String filler1;

    /** Holds value of property idCardNumber. */
	private String idCardNumber;

    /** Holds value of property patientName. */
	private String patientName;

    /** Holds value of property postingDate. */
	private String postingDate;

    /** Holds value of property regionId. */
	private String regionId;

    /** Holds value of property reportId. */
	private String reportId;

    /** Holds value of property reportIdDesc. */
	private String reportIdDesc;

    /** Holds value of property subId. */
	private String subId;

	/**
	 * Creates a new instance of EOB
	 */
	public EOB() {
		if(EOB.logger.isDebugEnabled()) {
			EOB.logger.debug("Created EOB object.");
		}// End of if(EOB.logger.isDebugEnabled())
	}// End of constructor EOB()

	/**
	 * Getter for property checkDate.
	 *
	 * @return the checkDate
	 */
	public String getCheckDate() {
		return this.checkDate;
	}// End of method getCheckDate()

	/**
	 * Setter for property checkDate.
	 *
	 * @param checkDate the checkDate to set
	 */
	public void setCheckDate(String checkDate) {
		this.checkDate = checkDate;
	}// End of method setCheckDate()

	/**
	 * Getter for property claimNumber.
	 *
	 * @return the claimNumber
	 */
	public String getClaimNumber() {
		return this.claimNumber;
	}// End of method getClaimNumber()

	/**
	 * Setter for property claimNumber.
	 *
	 * @param claimNumber the claimNumber to set
	 */
	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}// End of method setClaimNumber()

	/**
	 * Getter for property filler1.
	 *
	 * @return the filler1
	 */
	public String getFiller1() {
		return this.filler1;
	}// End of method getFiller1()

	/**
	 * Setter for property filler1.
	 *
	 * @param filler1 the filler1 to set
	 */
	public void setFiller1(String filler1) {
		this.filler1 = filler1;
	}// End of method setFiller1()

	/**
	 * Getter for property idCardNumber.
	 *
	 * @return the idCardNumber
	 */
	public String getIdCardNumber() {
		return this.idCardNumber;
	}// End of method getIdCardNumber()

	/**
	 * Setter for property idCardNumber.
	 *
	 * @param idCardNumber the idCardNumber to set
	 */
	public void setIdCardNumber(String idCardNumber) {
		this.idCardNumber = idCardNumber;
	}// End of method setIdCardNumber()

	/**
	 * Getter for property patientName.
	 *
	 * @return the patientName
	 */
	public String getPatientName() {
		return this.patientName;
	}// End of method getPatientName()

	/**
	 * Setter for property patientName.
	 *
	 * @param patientName the patientName to set
	 */
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}// End of method setPatientName()

	/**
	 * Getter for property postingDate.
	 *
	 * @return the postingDate
	 */
	public String getPostingDate() {
		return this.postingDate;
	}// End of method getPostingDate()

	/**
	 * Setter for property postingDate.
	 *
	 * @param postingDate the postingDate to set
	 */
	public void setPostingDate(String postingDate) {
		this.postingDate = postingDate;
	}// End of method setPostingDate()

	/**
	 * Getter for property regionId.
	 *
	 * @return the regionId
	 */
	public String getRegionId() {
		return this.regionId;
	}// End of method getRegionId()

	/**
	 * Setter for property regionId.
	 *
	 * @param regionId the regionId to set
	 */
	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}// End of method setRegionId()

	/**
	 * Getter for property reportId.
	 *
	 * @return the reportId
	 */
	public String getReportId() {
		return this.reportId;
	}// End of method getReportId()

	/**
	 * Setter for property reportId.
	 *
	 * @param reportId the reportId to set
	 */
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}// End of method setReportId()

	/**
	 * Getter for property reportIdDesc.
	 *
	 * @return the reportIdDesc
	 */
	public String getReportIdDesc() {
		return this.reportIdDesc;
	}// End of method getReportIdDesc()

	/**
	 * Setter for property reportIdDesc.
	 *
	 * @param reportIdDesc the reportIdDesc to set
	 */
	public void setReportIdDesc(String reportIdDesc) {
		this.reportIdDesc = reportIdDesc;
	}// End of method setReportIdDesc()

	/**
	 * Getter for property subId.
	 *
	 * @return the subId
	 */
	public String getSubId() {
		return this.subId;
	}// End of method getSubId()

	/**
	 * Setter for property subId.
	 *
	 * @param subId the subId to set
	 */
	public void setSubId(String subId) {
		this.subId = subId;
	}// End of method setSubId()

	/**
	 * The string representation of this class.
	 *
	 * @return the string representation of this class
	 */
	public String toString() {
    	return ToStringBuilder.reflectionToString(this);
    }// End of method toString()
}// End of class EOB
