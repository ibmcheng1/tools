/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * WebServicesCommonOutput.java
 * 
 * Created on Oct 12, 2009 by EN80

 */

package com.bcbssc.services.model;

import java.io.Serializable;

/**
 * This class holds the minimum required service outputs.
 *
 * <pre>
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-services-model/src/main/java/com/bcbssc/services/model/WebServicesCommonOutput.java_v  $
 * $Workfile:   WebServicesCommonOutput.java  $
 * $Revision:   1.0  $
 * $Date:   Oct 20 2009 12:00:42  $
 * $Modtime:   Oct 16 2009 13:56:22  $
 * </pre>
 *
 * @author $Author:   EN80  $
 * @version $Id: $Id
 */
public class WebServicesCommonOutput implements Serializable {

	private static final long serialVersionUID = 43953l;
	private String applicationMessage;
	private String serviceMessageCode;
	private String serviceMessage;
	private String systemMessage;
	
	private String ebizReplyAbendcode; 
	private String ebizReplyStatus;
	private String ebizReplyStatusMessage;
	/**
	 * <p>Getter for the field <code>applicationMessage</code>.</p>
	 *
	 * @return the applicationMessage
	 */
	public String getApplicationMessage() {
		return applicationMessage;
	}
	/**
	 * <p>Setter for the field <code>applicationMessage</code>.</p>
	 *
	 * @param applicationMessage the applicationMessage to set
	 */
	public void setApplicationMessage(String applicationMessage) {
		this.applicationMessage = applicationMessage;
	}
	/**
	 * <p>Getter for the field <code>ebizReplyAbendcode</code>.</p>
	 *
	 * @return the ebizReplyAbendcode
	 */
	public String getEbizReplyAbendcode() {
		return ebizReplyAbendcode;
	}
	/**
	 * <p>Setter for the field <code>ebizReplyAbendcode</code>.</p>
	 *
	 * @param ebizReplyAbendcode the ebizReplyAbendcode to set
	 */
	public void setEbizReplyAbendcode(String ebizReplyAbendcode) {
		this.ebizReplyAbendcode = ebizReplyAbendcode;
	}
	/**
	 * <p>Getter for the field <code>ebizReplyStatus</code>.</p>
	 *
	 * @return the ebizReplyStatus
	 */
	public String getEbizReplyStatus() {
		return ebizReplyStatus;
	}
	/**
	 * <p>Setter for the field <code>ebizReplyStatus</code>.</p>
	 *
	 * @param ebizReplyStatus the ebizReplyStatus to set
	 */
	public void setEbizReplyStatus(String ebizReplyStatus) {
		this.ebizReplyStatus = ebizReplyStatus;
	}
	/**
	 * <p>Getter for the field <code>ebizReplyStatusMessage</code>.</p>
	 *
	 * @return the ebizReplyStatusMessage
	 */
	public String getEbizReplyStatusMessage() {
		return ebizReplyStatusMessage;
	}
	/**
	 * <p>Setter for the field <code>ebizReplyStatusMessage</code>.</p>
	 *
	 * @param ebizReplyStatusMessage the ebizReplyStatusMessage to set
	 */
	public void setEbizReplyStatusMessage(String ebizReplyStatusMessage) {
		this.ebizReplyStatusMessage = ebizReplyStatusMessage;
	}
	/**
	 * <p>Getter for the field <code>serviceMessage</code>.</p>
	 *
	 * @return the serviceMessage
	 */
	public String getServiceMessage() {
		return serviceMessage;
	}
	/**
	 * <p>Setter for the field <code>serviceMessage</code>.</p>
	 *
	 * @param serviceMessage the serviceMessage to set
	 */
	public void setServiceMessage(String serviceMessage) {
		this.serviceMessage = serviceMessage;
	}
	/**
	 * <p>Getter for the field <code>serviceMessageCode</code>.</p>
	 *
	 * @return the serviceMessageCode
	 */
	public String getServiceMessageCode() {
		return serviceMessageCode;
	}
	/**
	 * <p>Setter for the field <code>serviceMessageCode</code>.</p>
	 *
	 * @param serviceMessageCode the serviceMessageCode to set
	 */
	public void setServiceMessageCode(String serviceMessageCode) {
		this.serviceMessageCode = serviceMessageCode;
	}
	/**
	 * <p>Getter for the field <code>systemMessage</code>.</p>
	 *
	 * @return the systemMessage
	 */
	public String getSystemMessage() {
		return systemMessage;
	}
	/**
	 * <p>Setter for the field <code>systemMessage</code>.</p>
	 *
	 * @param systemMessage the systemMessage to set
	 */
	public void setSystemMessage(String systemMessage) {
		this.systemMessage = systemMessage;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	/**
	 * <p>toString.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String toString(){
		StringBuffer output = new StringBuffer();
		output.append("*********** Service OutPut Begin ***************").append("\n");
		output.append("applicationMessage=" + applicationMessage).append("\n");
		output.append("serviceMessageCode=" + serviceMessageCode).append("\n");
		output.append("serviceMessage=" + serviceMessage).append("\n");
		output.append("systemMessage=" + systemMessage).append("\n");
		output.append("ebizReplyAbendcode=" + ebizReplyAbendcode).append("\n");
		output.append("ebizReplyStatus=" + ebizReplyStatus).append("\n");
		output.append("ebizReplyStatusMessage=" + ebizReplyStatusMessage).append("\n");
		output.append("*********** Service OutPut End ***************").append("\n");
		return output.toString();
	}

}
