/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * DocumentSearchKey.java
 * Date: May 25, 2010
 */
package com.bcbssc.commapi.model.documentarchive.dto;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.log4j.Logger;

/**
 * An class representing a DocumentSearchKey object.
 *
 * Author: FF74
 *
 * @author jc33
 * @version $Id: $Id
 */
public class DocumentSearchKey {

	/** The log4j logger for this class */
    private static Logger logger = Logger.getLogger(DocumentSearchKey.class);

    /** Holds value of property keyName. */
    private String keyName;

    /** Holds value of property keyValue. */
	private String keyValue;

    /** Holds value of property operator. */
	private DocumentSearchKeyOperator operator;

	/**
	 * Creates a new instance of DocumentSearchKey
	 */
	public DocumentSearchKey() {
		if(DocumentSearchKey.logger.isDebugEnabled()) {
			DocumentSearchKey.logger.debug("Created DocumentSearchKey object.");
		}// End of if(DocumentSearchKey.logger.isDebugEnabled())
	}// End of constructor DocumentSearchKey()

	/**
	 * Getter for property keyName.
	 *
	 * @return the keyName
	 */
	public String getKeyName() {
		return this.keyName;
	}// End of method getKeyName()

	/**
	 * Setter for property keyName.
	 *
	 * @param keyName the keyName to set
	 */
	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}// End of method setKeyName()

	/**
	 * Getter for property keyValue.
	 *
	 * @return the keyValue
	 */
	public String getKeyValue() {
		return this.keyValue;
	}// End of method getKeyValue()

	/**
	 * Setter for property keyValue.
	 *
	 * @param keyValue the keyValue to set
	 */
	public void setKeyValue(String keyValue) {
		this.keyValue = keyValue;
	}// End of method setKeyValue()

	/**
	 * Getter for property operator.
	 *
	 * @return the operator
	 */
	public DocumentSearchKeyOperator getOperator() {
		return this.operator;
	}// End of method getOperator()

	/**
	 * Setter for property operator.
	 *
	 * @param operator the operator to set
	 */
	public void setOperator(DocumentSearchKeyOperator operator) {
		this.operator = operator;
	}// End of method setOperator()

	/**
	 * The string representation of this class.
	 *
	 * @return the string representation of this class
	 */
	public String toString() {
    	return ToStringBuilder.reflectionToString(this);
    }// End of method toString()
}// End of class DocumentSearchKey
