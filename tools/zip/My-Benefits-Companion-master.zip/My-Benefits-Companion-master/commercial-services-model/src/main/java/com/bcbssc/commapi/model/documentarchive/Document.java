package com.bcbssc.commapi.model.documentarchive;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * An class representing a Document object.
 *
 * @author FF74
 * @version $Id: $Id
 */
public class Document implements Serializable {
	
    /** Holds value of the serialVersionUID */
	private static final long serialVersionUID = -4444259725534613386L;

    /** Holds value of property mimeType. */
	private String mimeType;

    /** Holds value of property content. */
    private byte[] content;   
    
   /**
    * Creates a new instance of Document
    */
   public Document(){
    	this(null, null);
    }// End of constructor Document()
    
	/**
	 * Creates a new instance of Document
	 *
	 * @param mimeType a {@link java.lang.String} object.
	 */
	public Document(String mimeType) {
		this(mimeType, null);
	}// End of constructor Document(String)

	/**
	 * Creates a new instance of Document
	 *
	 * @param content an array of {@link byte} objects.
	 */
	public Document(byte[] content) {
		this(null, content);
	}// End of constructor Document(byte[])

	/**
	 * Creates a new instance of Document
	 *
	 * @param mimeType a {@link java.lang.String} object.
	 * @param content an array of {@link byte} objects.
	 */
	public Document(String mimeType, byte[] content) {
		this.mimeType = mimeType;
		this.content = content;
	}// End of constructor Document(String, byte[])

	/**
	 * Getter for property mimeType.
	 *
	 * @return the mimeType
	 */
	public String getMimeType() {
          return this.mimeType;
    }// End of method getMimeType()

    /**
     * Setter for property mimeType.
     *
     * @param mimeType the mimeType to set
     */
    public void setMimeType(String mimeType) {
          this.mimeType = mimeType;
    }// End of method setMimeType()

    /**
     * Getter for property content.
     *
     * @return the content
     */
    public byte[] getContent() {
          return this.content;
    }// End of method getContent()

    /**
     * Setter for property content.
     *
     * @param content the content to set
     */
    public void setContent(byte[] content) {
          this.content = content;
	}// End of method setContent()

	/**
	 * The string representation of this class.
	 *
	 * @return the string representation of this class
	 */
	public String toString() {
    	return ToStringBuilder.reflectionToString(this);
    }// End of method toString()
}// End of class Document
