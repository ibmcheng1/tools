/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * RulesDatatypeMaintenance.java
 * 
 * Created on Oct 12, 2009 by EN80

 */

package com.bcbssc.services.model.rules;

import java.util.List;

import com.bcbssc.services.model.WebServiceCommonInput;

/**
 * This class holds the minimum required service inputs for Rules Data Type Maintenance.
 *
 * <pre>
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-services-model/src/main/java/com/bcbssc/services/model/rules/RulesDatatypeMaintenance.java_v  $
 * $Workfile:   RulesDatatypeMaintenance.java  $
 * $Revision:   1.0  $
 * $Date:   Oct 20 2009 12:00:46  $
 * $Modtime:   Oct 19 2009 13:37:56  $
 * </pre>
 *
 * @author $Author:   EN80  $
 * @version $Id: $Id
 */
public class RulesDatatypeMaintenance extends WebServiceCommonInput {

	private static final long serialVersionUID = 1863486786785567L;
	
	private String rpn; 
	private String planCode;
	private String dataType;
	private String webRacf; 
	private String userSignOnId; 
	private String totalRecordCount;
	
	private List rulesDataTypeActionItems;

	/**
	 * <p>Getter for the field <code>dataType</code>.</p>
	 *
	 * @return the dataType
	 */
	public String getDataType() {
		return dataType;
	}

	/**
	 * <p>Setter for the field <code>dataType</code>.</p>
	 *
	 * @param dataType the dataType to set
	 */
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	/**
	 * <p>Getter for the field <code>planCode</code>.</p>
	 *
	 * @return the planCode
	 */
	public String getPlanCode() {
		return planCode;
	}

	/**
	 * <p>Setter for the field <code>planCode</code>.</p>
	 *
	 * @param planCode the planCode to set
	 */
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}

	/**
	 * <p>Getter for the field <code>rpn</code>.</p>
	 *
	 * @return the rpn
	 */
	public String getRpn() {
		return rpn;
	}

	/**
	 * <p>Setter for the field <code>rpn</code>.</p>
	 *
	 * @param rpn the rpn to set
	 */
	public void setRpn(String rpn) {
		this.rpn = rpn;
	}

	/**
	 * <p>Getter for the field <code>rulesDataTypeActionItems</code>.</p>
	 *
	 * @return the rulesDataTypeActionItems
	 */
	public List getRulesDataTypeActionItems() {
		return rulesDataTypeActionItems;
	}

	/**
	 * <p>Setter for the field <code>rulesDataTypeActionItems</code>.</p>
	 *
	 * @param rulesDataTypeActionItems the rulesDataTypeActionItems to set
	 */
	public void setRulesDataTypeActionItems(List rulesDataTypeActionItems) {
		this.rulesDataTypeActionItems = rulesDataTypeActionItems;
	}

	/**
	 * <p>Getter for the field <code>totalRecordCount</code>.</p>
	 *
	 * @return the totalRecordCount
	 */
	public String getTotalRecordCount() {
		return totalRecordCount;
	}

	/**
	 * <p>Setter for the field <code>totalRecordCount</code>.</p>
	 *
	 * @param totalRecordCount the totalRecordCount to set
	 */
	public void setTotalRecordCount(String totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
	}

	/**
	 * <p>Getter for the field <code>userSignOnId</code>.</p>
	 *
	 * @return the userSignOnId
	 */
	public String getUserSignOnId() {
		return userSignOnId;
	}

	/**
	 * <p>Setter for the field <code>userSignOnId</code>.</p>
	 *
	 * @param userSignOnId the userSignOnId to set
	 */
	public void setUserSignOnId(String userSignOnId) {
		this.userSignOnId = userSignOnId;
	}

	/**
	 * <p>Getter for the field <code>webRacf</code>.</p>
	 *
	 * @return the webRacf
	 */
	public String getWebRacf() {
		return webRacf;
	}

	/**
	 * <p>Setter for the field <code>webRacf</code>.</p>
	 *
	 * @param webRacf the webRacf to set
	 */
	public void setWebRacf(String webRacf) {
		this.webRacf = webRacf;
	}
	
	/**
	 * <p>toString.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String toString(){
		
		StringBuffer output = new StringBuffer();
		output.append("\n***********  RulesDatatypeMaintenance  BEGIN ***************").append("\n");
		output.append("dataType=" + dataType).append("\t");
		output.append("palnCode=" + planCode).append("\t");
		output.append("rpn=" + rpn).append("\t");
		output.append("webRacf=" + webRacf).append("\t");
		output.append("userSignOnId=" + userSignOnId).append("\t");
		output.append("totalRecordCount=" + totalRecordCount).append("\t");
		output.append("\n***********  RulesDatatypeMaintenance  END ***************").append("\n");
		return output.toString();
	}	
	
	

}
