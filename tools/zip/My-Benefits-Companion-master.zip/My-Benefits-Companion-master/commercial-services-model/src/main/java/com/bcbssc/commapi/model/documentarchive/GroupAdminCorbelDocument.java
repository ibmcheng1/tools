/**
 * 
 */
package com.bcbssc.commapi.model.documentarchive;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.log4j.Logger;

import com.bcbssc.commapi.model.common.CommonListDocument;

/**
 * A class representing a GroupAdminCorbelDocuments object.
 *
 * @author X94s
 * @version $Id: $Id
 */
public class GroupAdminCorbelDocument extends CommonListDocument implements Serializable {
	
    /** Holds value of the serialVersionUID */
	private static final long serialVersionUID = 1L;

	/** The log4j logger for this class */
    private static Logger logger = Logger.getLogger(GroupAdminCorbelDocument.class);

    /** Holds value of property groupNumber. */
	private String groupNumber;
	
	
	private String reportId;
	
	private String reportIdDesc;
	
	/** Holds value of property certId. */
	private String certId;
	
	/** Holds value of property groupName. */
	private String groupName;
	

	

	
	  /** Holds value of property postingDate. */
	private String postingDate;
	
    /** Holds value of property effectiveDate. */
	private String effectiveDate;
	/**
	 * <p>Getter for the field <code>certId</code>.</p>
	 *
	 * @return the certId
	 */
	public String getCertId() {
		return certId;
	}


	/**
	 * <p>Setter for the field <code>certId</code>.</p>
	 *
	 * @param certId the certId to set
	 */
	public void setCertId(String certId) {
		this.certId = certId;
	}


	/**
	 * <p>Getter for the field <code>certName</code>.</p>
	 *
	 * @return the certName
	 */
	public String getCertName() {
		return certName;
	}


	/**
	 * <p>Setter for the field <code>certName</code>.</p>
	 *
	 * @param certName the certName to set
	 */
	public void setCertName(String certName) {
		this.certName = certName;
	}


	/**
	 * <p>Getter for the field <code>dentalCardId</code>.</p>
	 *
	 * @return the dentalCardId
	 */
	public String getDentalCardId() {
		return dentalCardId;
	}


	/**
	 * <p>Setter for the field <code>dentalCardId</code>.</p>
	 *
	 * @param dentalCardId the dentalCardId to set
	 */
	public void setDentalCardId(String dentalCardId) {
		this.dentalCardId = dentalCardId;
	}


	/**
	 * <p>Getter for the field <code>dentalCardName</code>.</p>
	 *
	 * @return the dentalCardName
	 */
	public String getDentalCardName() {
		return dentalCardName;
	}


	/**
	 * <p>Setter for the field <code>dentalCardName</code>.</p>
	 *
	 * @param dentalCardName the dentalCardName to set
	 */
	public void setDentalCardName(String dentalCardName) {
		this.dentalCardName = dentalCardName;
	}


	/** Holds value of property certName. */
	private String certName;
	
	private String dentalCardId;
	
	private String dentalCardName;
	/**
	 * <p>Getter for the field <code>reportIdDesc</code>.</p>
	 *
	 * @return the reportIdDesc
	 */
	public String getReportIdDesc() {
		return reportIdDesc;
	}


	/**
	 * <p>Setter for the field <code>reportIdDesc</code>.</p>
	 *
	 * @param reportIdDesc the reportIdDesc to set
	 */
	public void setReportIdDesc(String reportIdDesc) {
		this.reportIdDesc = reportIdDesc;
	}


	/**
	 * <p>Getter for the field <code>reportId</code>.</p>
	 *
	 * @return the reportId
	 */
	public String getReportId() {
		return reportId;
	}


	/**
	 * <p>Setter for the field <code>reportId</code>.</p>
	 *
	 * @param reportId the reportId to set
	 */
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}


	/**
	 * <p>Getter for the field <code>description</code>.</p>
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}


	/**
	 * <p>Setter for the field <code>description</code>.</p>
	 *
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}


	private String description;
    
	/**
	 * <p>Getter for the field <code>groupNumber</code>.</p>
	 *
	 * @return the groupNumber
	 */
	public String getGroupNumber() {
		return groupNumber;
	}


	/**
	 * <p>Setter for the field <code>groupNumber</code>.</p>
	 *
	 * @param groupNumber the groupNumber to set
	 */
	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}


	/**
	 * <p>Getter for the field <code>groupName</code>.</p>
	 *
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}


	/**
	 * <p>Setter for the field <code>groupName</code>.</p>
	 *
	 * @param groupName the groupName to set
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	/**
	 * <p>Getter for the field <code>postingDate</code>.</p>
	 *
	 * @return the postingDate
	 */
	public String getPostingDate() {
		return postingDate;
	}


	/**
	 * <p>Setter for the field <code>postingDate</code>.</p>
	 *
	 * @param postingDate the postingDate to set
	 */
	public void setPostingDate(String postingDate) {
		this.postingDate = postingDate;
	}


	/**
	 * <p>Getter for the field <code>effectiveDate</code>.</p>
	 *
	 * @return the effectiveDate
	 */
	public String getEffectiveDate() {
		return effectiveDate;
	}


	/**
	 * <p>Setter for the field <code>effectiveDate</code>.</p>
	 *
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}






	/**
	 * Creates a new instance of GroupAdminCorbelDocuments
	 */
	public GroupAdminCorbelDocument() {
		if(GroupAdminCorbelDocument.logger.isDebugEnabled()) {
			GroupAdminCorbelDocument.logger.debug("Created GroupAdminCorbelDocument object.");
		}// End of if(GroupAdminPolicy.logger.isDebugEnabled())
	}// End of constructor GroupAdminPolicy()

	
	/**
	 * The string representation of this class.
	 *
	 * @return the string representation of this class
	 */
	public String toString() {
    	return ToStringBuilder.reflectionToString(this);
    }// End of method toString()
}// End of class GroupAdminCert
