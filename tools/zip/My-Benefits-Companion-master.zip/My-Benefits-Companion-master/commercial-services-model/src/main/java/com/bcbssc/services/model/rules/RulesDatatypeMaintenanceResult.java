/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * RulesDatatypeMaintenanceResult.java
 * 
 * Created on Oct 12, 2009 by EN80

 */

package com.bcbssc.services.model.rules;

import com.bcbssc.services.model.WebServicesCommonOutput;

/**
 * This class holds the minimum required service outputs from Rules Data Type Maintenance.
 *
 * <pre>
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-services-model/src/main/java/com/bcbssc/services/model/rules/RulesDatatypeMaintenanceResult.java_v  $
 * $Workfile:   RulesDatatypeMaintenanceResult.java  $
 * $Revision:   1.1  $
 * $Date:   Oct 21 2009 16:37:34  $
 * $Modtime:   Oct 21 2009 10:36:26  $
 * </pre>
 *
 * @author $Author:   EN80  $
 * @version $Id: $Id
 */
public class RulesDatatypeMaintenanceResult extends WebServicesCommonOutput {

	private static final long serialVersionUID = 1333486786785567L;
	
	private String totalRecordsVoided;
	private String errorRecordLocation;

	/**
	 * <p>Getter for the field <code>totalRecordsVoided</code>.</p>
	 *
	 * @return the totalRecordsVoided
	 */
	public String getTotalRecordsVoided() {
		return totalRecordsVoided;
	}

	/**
	 * <p>Setter for the field <code>totalRecordsVoided</code>.</p>
	 *
	 * @param totalRecordsVoided the totalRecordsVoided to set
	 */
	public void setTotalRecordsVoided(String totalRecordsVoided) {
		this.totalRecordsVoided = totalRecordsVoided;
	}
	
	
	
	/**
	 * <p>Getter for the field <code>errorRecordLocation</code>.</p>
	 *
	 * @return the errorRecordLocation
	 */
	public String getErrorRecordLocation() {
		return errorRecordLocation;
	}

	/**
	 * <p>Setter for the field <code>errorRecordLocation</code>.</p>
	 *
	 * @param errorRecordLocation the errorRecordLocation to set
	 */
	public void setErrorRecordLocation(String errorRecordLocation) {
		this.errorRecordLocation = errorRecordLocation;
	}

	/* (non-Javadoc)
	 * @see com.bcbssc.services.model.WebServicesCommonOutput#toString()
	 */
	/**
	 * <p>toString.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String toString(){
		
		StringBuffer output = new StringBuffer();
		output.append(super.toString()).append("\n");
		output.append("totalRecordsVoided = " + totalRecordsVoided);
		output.append("errorRecordLocation = " + errorRecordLocation);
		
		return output.toString();
	}
}
