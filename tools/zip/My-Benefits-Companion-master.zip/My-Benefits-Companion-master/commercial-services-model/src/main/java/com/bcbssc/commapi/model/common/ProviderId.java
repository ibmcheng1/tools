/**
 * 
 */
package com.bcbssc.commapi.model.common;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * An class representing a ProviderId object.
 *
 * @author FF74
 * @version $Id: $Id
 */
public class ProviderId implements Serializable {
	
    /** Holds value of the serialVersionUID */
	private static final long serialVersionUID = 15395691268827L;

    /** Holds value of property nationalProviderIdentifier. */
	private String nationalProviderIdentifier;

    /** Holds value of property federalTaxIdNumber. */
	private String federalTaxIdNumber;
	
	private String providerNumberKey;
	
	/**
	 * Creates a new instance of ProviderId
	 */
	public ProviderId() {
		this(null, null);
	}// End of constructor ProviderId()
	
	/**
	 * Creates a new instance of ProviderId
	 *
	 * @param federalTaxIdNumber a {@link java.lang.String} object.
	 * @param nationalProviderIdentifier a {@link java.lang.String} object.
	 */
	public ProviderId(String federalTaxIdNumber,
			          String nationalProviderIdentifier) {
		this.federalTaxIdNumber = federalTaxIdNumber;
		this.nationalProviderIdentifier = nationalProviderIdentifier;
	}// End of constructor ProviderId(String, String)

	
	/**
	 * <p>Setter for the field <code>providerNumberKey</code>.</p>
	 *
	 * @param provNumberKey a {@link java.lang.String} object.
	 */
	public void setProviderNumberKey(String provNumberKey){
		this.providerNumberKey = provNumberKey;
		
	}
	
	/**
	 * <p>Getter for the field <code>providerNumberKey</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getProviderNumberKey(){
		return this.providerNumberKey ;
		
	}
	
	/**
	 * Getter for property nationalProviderIdentifier.
	 *
	 * @return the nationalProviderIdentifier
	 */
	public String getNationalProviderIdentifier() {
		return this.nationalProviderIdentifier;
	}// End of method getNationalProviderIdentifier()

	/**
	 * Setter for property nationalProviderIdentifier.
	 *
	 * @param nationalProviderIdentifier the nationalProviderIdentifier to set
	 */
	public void setNationalProviderIdentifier(String nationalProviderIdentifier) {
		this.nationalProviderIdentifier = nationalProviderIdentifier;
	}// End of method setNationalProviderIdentifier()

	/**
	 * Getter for property federalTaxIdNumber.
	 *
	 * @return the federalTaxIdNumber
	 */
	public String getFederalTaxIdNumber() {
		return this.federalTaxIdNumber;
	}// End of method getFederalTaxIdNumber()

	/**
	 * Setter for property federalTaxIdNumber.
	 *
	 * @param federalTaxIdNumber the federalTaxIdNumber to set
	 */
	public void setFederalTaxIdNumber(String federalTaxIdNumber) {
		this.federalTaxIdNumber = federalTaxIdNumber;
	}// End of method setFederalTaxIdNumber()

	/**
	 * The string representation of this class.
	 *
	 * @return the string representation of this class
	 */
	public String toString() {
    	return ToStringBuilder.reflectionToString(this);
    }// End of method toString()
}// End of class ProviderId
