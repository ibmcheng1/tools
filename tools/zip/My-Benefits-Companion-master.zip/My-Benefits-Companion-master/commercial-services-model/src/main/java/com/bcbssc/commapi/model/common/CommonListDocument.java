package com.bcbssc.commapi.model.common;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.bcbssc.commapi.model.documentarchive.dto.ImageFolder;


/**
 * An class representing a CommonListDocument object.
 *
 * @author FF74
 * @version $Id: $Id
 */
public class CommonListDocument implements Serializable {
	
    /** Holds value of the serialVersionUID */
    private static final long serialVersionUID = 5705574657013412600L;

    /** Holds value of property docId. */
	private String docId;

    /** Holds value of property docType. */
	private String docType;

    /** Holds value of property mimeType. */
	private String mimeType;

    /** Holds value of property imageFolderName. */
	private ImageFolder imageFolderName;

	/**
	 * Getter for property docId.
	 *
	 * @return the docId
	 */
	public String getDocId() {
		return docId;
	}// End of method getDocId()

	/**
	 * Setter for property docId.
	 *
	 * @param docId the docId to set
	 */
	public void setDocId(String docId) {
		this.docId = docId;
	}// End of method setDocId()

	/**
	 * Getter for property docType.
	 *
	 * @return the docType
	 */
	public String getDocType() {
		return docType;
	}// End of method getDocType()

	/**
	 * Setter for property docType.
	 *
	 * @param docType the docType to set
	 */
	public void setDocType(String docType) {
		this.docType = docType;
	}// End of method setDocType()

	/**
	 * Getter for property mimeType.
	 *
	 * @return the mimeType
	 */
	public String getMimeType() {
		return mimeType;
	}// End of method getMimeType()

	/**
	 * Setter for property mimeType.
	 *
	 * @param mimeType the mimeType to set
	 */
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}// End of method setMimeType()

	/**
	 * Getter for property imageFolderName.
	 *
	 * @return the imageFolderName
	 */
	public ImageFolder getImageFolderName() {
		return imageFolderName;
	}// End of method getImageFolderName()

	/**
	 * Setter for property imageFolderName.
	 *
	 * @param imageFolderName the imageFolderName to set
	 */
	public void setImageFolderName(ImageFolder imageFolderName) {
		this.imageFolderName = imageFolderName;
	}// End of method setImageFolderName()

	/**
	 * The string representation of this class.
	 *
	 * @return the string representation of this class
	 */
	public String toString() {
    	return ToStringBuilder.reflectionToString(this);
    }// End of method toString()
}// End of class CommonListDocument
