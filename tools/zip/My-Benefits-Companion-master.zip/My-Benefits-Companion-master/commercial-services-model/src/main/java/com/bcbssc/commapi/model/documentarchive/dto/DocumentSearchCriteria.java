/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * DocumentSearchCriteria.java
 * Date: May 25, 2010
 */
package com.bcbssc.commapi.model.documentarchive.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.log4j.Logger;

/**
 * An class representing a DocumentSearchCriteria object.
 *
 * Author: FF74
 *
 * @author jc33
 * @version $Id: $Id
 */
public class DocumentSearchCriteria implements Serializable{
	
    /** Holds value of the serialVersionUID */
	private static final long serialVersionUID = 1L;

	/** The log4j logger for this class */
    private static Logger logger = Logger.getLogger(DocumentSearchCriteria.class);	

    /** Holds value of property imageFolder. */
	private ImageFolder imageFolder;

    /** Holds value of property searchBeginDate. */
	private Date searchBeginDate;

    /** Holds value of property searchEndDate. */
	private Date searchEndDate;

    /** Holds value of property orSearchCriteria. */
	private boolean orSearchCriteria;

    /** Holds value of property searchConditions. */
	List <DocumentSearchKey> searchConditions;

	/**
	 * Creates a new instance of DocumentSearchCriteria
	 */
	public DocumentSearchCriteria() {
		if(DocumentSearchCriteria.logger.isDebugEnabled()) {
			DocumentSearchCriteria.logger.debug("Created DocumentSearchCriteria object.");
		}// End of if(DocumentSearchCriteria.logger.isDebugEnabled())
	}// End of constructor DocumentSearchCriteria()

	/**
	 * Getter for property imageFolder.
	 *
	 * @return the imageFolder
	 */
	public ImageFolder getImageFolder() {
		return this.imageFolder;
	}// End of method getImageFolder()

	/**
	 * Setter for property imageFolder.
	 *
	 * @param imageFolder the imageFolder to set
	 */
	public void setImageFolder(ImageFolder imageFolder) {
		this.imageFolder = imageFolder;
	}// End of method setImageFolder()

	/**
	 * Getter for property searchBeginDate.
	 *
	 * @return the searchBeginDate
	 */
	public Date getSearchBeginDate() {
		return this.searchBeginDate;
	}// End of method getSearchBeginDate()

	/**
	 * Setter for property searchBeginDate.
	 *
	 * @param searchBeginDate the searchBeginDate to set
	 */
	public void setSearchBeginDate(Date searchBeginDate) {
		this.searchBeginDate = searchBeginDate;
	}// End of method setSearchBeginDate()

	/**
	 * Getter for property searchEndDate.
	 *
	 * @return the searchEndDate
	 */
	public Date getSearchEndDate() {
		return this.searchEndDate;
	}// End of method getSearchEndDate()

	/**
	 * Setter for property searchEndDate.
	 *
	 * @param searchEndDate the searchEndDate to set
	 */
	public void setSearchEndDate(Date searchEndDate) {
		this.searchEndDate = searchEndDate;
	}// End of method setSearchEndDate()

	/**
	 * Getter for property orSearchCriteria.
	 *
	 * @return the orSearchCriteria
	 */
	public boolean isOrSearchCriteria() {
		return this.orSearchCriteria;
	}// End of method isOrSearchCriteria()

	/**
	 * Setter for property orSearchCriteria.
	 *
	 * @param orSearchCriteria the orSearchCriteria to set
	 */
	public void setOrSearchCriteria(boolean orSearchCriteria) {
		this.orSearchCriteria = orSearchCriteria;
	}// End of method setOrSearchCriteria()

	/**
	 * Getter for property searchConditions.
	 *
	 * @return the searchConditions
	 */
	public List<DocumentSearchKey> getSearchConditions() {
		return this.searchConditions;
	}// End of method getSearchConditions()

	/**
	 * Setter for property searchConditions.
	 *
	 * @param searchConditions the searchConditions to set
	 */
	public void setSearchConditions(List<DocumentSearchKey> searchConditions) {
		this.searchConditions = searchConditions;
	}// End of method setSearchConditions()

	/**
	 * The string representation of this class.
	 *
	 * @return the string representation of this class
	 */
	public String toString() {
    	return ToStringBuilder.reflectionToString(this);
    }// End of method toString()
}// End of class DocumentSearchCriteria
