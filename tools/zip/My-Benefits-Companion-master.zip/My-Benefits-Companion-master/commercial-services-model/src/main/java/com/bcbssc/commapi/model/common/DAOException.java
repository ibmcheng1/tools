/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.commapi.model.common;

/**
 * Data Access exception
 *
 * @author EN80
 * @version 1.0
 */
public class DAOException extends Exception {
	
    /** Holds value of the serialVersionUID */
	private static final long serialVersionUID = -209867936048L;

	/**
	 * Creates a new instance of DAOException.
	 */
	public DAOException() {
		this(null, null);
	}// End of constructor DAOException()

	/**
	 * Creates a new instance of DAOException with a descriptive message.
	 *
	 * @param message
	 *            The exception message.
	 */
	public DAOException(String message) {
		this(message, null);
	}// End of constructor DAOException(String)

	/**
	 * Creates a new instance of DAOException with the given root cause.
	 *
	 * @param rootCause
	 *            The root cause of this exception.
	 */
	public DAOException(Throwable rootCause) {
		this(null, rootCause);
	}// End of constructor DAOException(Throwable)

	/**
	 * Creates a new instance of DAOException with a descriptive message
	 * and a root cause.
	 *
	 * @param message
	 *            The exception message.
	 * @param rootCause
	 *            The root cause of this exception.
	 */
	public DAOException(String message, Throwable rootCause) {
		super(message, rootCause);
	}// End of constructor DAOException(String, Throwable)
}// End of class DAOException