
package com.bcbssc.services.model.statchat;

import java.io.Serializable;

/**
 * <p>CallDataDTO class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class CallDataDTO implements Serializable {

	private static final long serialVersionUID 		= -2448928534361761448L;

	private String rpn;

	private String planCode;

	private String systemId;

	private String keyId;

	private String keyType;

	private String racfId;

	private String clientType;

	private String inputChannel;

	private String statChatIndicator;

	private String ammsGroupNumber;

	private String providerFederalTaxId;

	private String providerNpi;

	private String locationNumber;

	private String subscriberAlphaPrefix;

	private String subscriberDatabaseNumber;

	private String subscriberIdCardNumber;

	private String patientId;

	private String patientDateOfBirth;

	private String subscriberFullName;

	private String subscriberAddressLineOne;

	private String subscriberAddressLineTwo;

	private String subscriberAddressLineThree;

	private String subscriberCity;

	private String subscriberState;

	private String subscriberZipCode;

	private String patientFullName;

	private String dateOfService;

	private String transferFrom;

	private String transferType;

	private String transferTarget;

	private String transferTargetType;

	/**
	 * <p>Getter for the field <code>rpn</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getRpn() {
		return rpn;
	}

	/**
	 * <p>Setter for the field <code>rpn</code>.</p>
	 *
	 * @param rpn a {@link java.lang.String} object.
	 */
	public void setRpn(String rpn) {
		this.rpn = rpn;
	}

	/**
	 * <p>Getter for the field <code>planCode</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getPlanCode() {
		return planCode;
	}

	/**
	 * <p>Setter for the field <code>planCode</code>.</p>
	 *
	 * @param planCode a {@link java.lang.String} object.
	 */
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}

	/**
	 * <p>Getter for the field <code>systemId</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getSystemId() {
		return systemId;
	}

	/**
	 * <p>Setter for the field <code>systemId</code>.</p>
	 *
	 * @param systemId a {@link java.lang.String} object.
	 */
	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	/**
	 * <p>Getter for the field <code>keyId</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getKeyId() {
		return keyId;
	}

	/**
	 * <p>Setter for the field <code>keyId</code>.</p>
	 *
	 * @param keyId a {@link java.lang.String} object.
	 */
	public void setKeyId(String keyId) {
		this.keyId = keyId;
	}

	/**
	 * <p>Getter for the field <code>keyType</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getKeyType() {
		return keyType;
	}

	/**
	 * <p>Setter for the field <code>keyType</code>.</p>
	 *
	 * @param keyType a {@link java.lang.String} object.
	 */
	public void setKeyType(String keyType) {
		this.keyType = keyType;
	}

	/**
	 * <p>Getter for the field <code>racfId</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getRacfId() {
		return racfId;
	}

	/**
	 * <p>Setter for the field <code>racfId</code>.</p>
	 *
	 * @param racfId a {@link java.lang.String} object.
	 */
	public void setRacfId(String racfId) {
		this.racfId = racfId;
	}

	/**
	 * <p>Getter for the field <code>clientType</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getClientType() {
		return clientType;
	}

	/**
	 * <p>Setter for the field <code>clientType</code>.</p>
	 *
	 * @param clientType a {@link java.lang.String} object.
	 */
	public void setClientType(String clientType) {
		this.clientType = clientType;
	}

	/**
	 * <p>Getter for the field <code>inputChannel</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getInputChannel() {
		return inputChannel;
	}

	/**
	 * <p>Setter for the field <code>inputChannel</code>.</p>
	 *
	 * @param inputChannel a {@link java.lang.String} object.
	 */
	public void setInputChannel(String inputChannel) {
		this.inputChannel = inputChannel;
	}

	/**
	 * <p>Getter for the field <code>statChatIndicator</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getStatChatIndicator() {
		return statChatIndicator;
	}

	/**
	 * <p>Setter for the field <code>statChatIndicator</code>.</p>
	 *
	 * @param statChatIndicator a {@link java.lang.String} object.
	 */
	public void setStatChatIndicator(String statChatIndicator) {
		this.statChatIndicator = statChatIndicator;
	}

	/**
	 * <p>Getter for the field <code>ammsGroupNumber</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getAmmsGroupNumber() {
		return ammsGroupNumber;
	}

	/**
	 * <p>Setter for the field <code>ammsGroupNumber</code>.</p>
	 *
	 * @param ammsGroupNumber a {@link java.lang.String} object.
	 */
	public void setAmmsGroupNumber(String ammsGroupNumber) {
		this.ammsGroupNumber = ammsGroupNumber;
	}

	/**
	 * <p>Getter for the field <code>providerFederalTaxId</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getProviderFederalTaxId() {
		return providerFederalTaxId;
	}

	/**
	 * <p>Setter for the field <code>providerFederalTaxId</code>.</p>
	 *
	 * @param providerFederalTaxId a {@link java.lang.String} object.
	 */
	public void setProviderFederalTaxId(String providerFederalTaxId) {
		this.providerFederalTaxId = providerFederalTaxId;
	}

	/**
	 * <p>Getter for the field <code>providerNpi</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getProviderNpi() {
		return providerNpi;
	}

	/**
	 * <p>Setter for the field <code>providerNpi</code>.</p>
	 *
	 * @param providerNpi a {@link java.lang.String} object.
	 */
	public void setProviderNpi(String providerNpi) {
		this.providerNpi = providerNpi;
	}

	/**
	 * <p>Getter for the field <code>locationNumber</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getLocationNumber() {
		return locationNumber;
	}

	/**
	 * <p>Setter for the field <code>locationNumber</code>.</p>
	 *
	 * @param locationNumber a {@link java.lang.String} object.
	 */
	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}

	/**
	 * <p>Getter for the field <code>subscriberAlphaPrefix</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getSubscriberAlphaPrefix() {
		return subscriberAlphaPrefix;
	}

	/**
	 * <p>Setter for the field <code>subscriberAlphaPrefix</code>.</p>
	 *
	 * @param subscriberAlphaPrefix a {@link java.lang.String} object.
	 */
	public void setSubscriberAlphaPrefix(String subscriberAlphaPrefix) {
		this.subscriberAlphaPrefix = subscriberAlphaPrefix;
	}

	/**
	 * <p>Getter for the field <code>subscriberDatabaseNumber</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getSubscriberDatabaseNumber() {
		return subscriberDatabaseNumber;
	}

	/**
	 * <p>Setter for the field <code>subscriberDatabaseNumber</code>.</p>
	 *
	 * @param subscriberDatabaseNumber a {@link java.lang.String} object.
	 */
	public void setSubscriberDatabaseNumber(String subscriberDatabaseNumber) {
		this.subscriberDatabaseNumber = subscriberDatabaseNumber;
	}

	/**
	 * <p>Getter for the field <code>subscriberIdCardNumber</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getSubscriberIdCardNumber() {
		return subscriberIdCardNumber;
	}

	/**
	 * <p>Setter for the field <code>subscriberIdCardNumber</code>.</p>
	 *
	 * @param subscriberIdCardNumber a {@link java.lang.String} object.
	 */
	public void setSubscriberIdCardNumber(String subscriberIdCardNumber) {
		this.subscriberIdCardNumber = subscriberIdCardNumber;
	}

	/**
	 * <p>Getter for the field <code>patientId</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getPatientId() {
		return patientId;
	}

	/**
	 * <p>Setter for the field <code>patientId</code>.</p>
	 *
	 * @param patientId a {@link java.lang.String} object.
	 */
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	/**
	 * <p>Getter for the field <code>patientDateOfBirth</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getPatientDateOfBirth() {
		return patientDateOfBirth;
	}

	/**
	 * <p>Setter for the field <code>patientDateOfBirth</code>.</p>
	 *
	 * @param patientDateOfBirth a {@link java.lang.String} object.
	 */
	public void setPatientDateOfBirth(String patientDateOfBirth) {
		this.patientDateOfBirth = patientDateOfBirth;
	}

	/**
	 * <p>Getter for the field <code>subscriberFullName</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getSubscriberFullName() {
		return subscriberFullName;
	}

	/**
	 * <p>Setter for the field <code>subscriberFullName</code>.</p>
	 *
	 * @param subscriberFullName a {@link java.lang.String} object.
	 */
	public void setSubscriberFullName(String subscriberFullName) {
		this.subscriberFullName = subscriberFullName;
	}

	/**
	 * <p>Getter for the field <code>subscriberAddressLineOne</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getSubscriberAddressLineOne() {
		return subscriberAddressLineOne;
	}

	/**
	 * <p>Setter for the field <code>subscriberAddressLineOne</code>.</p>
	 *
	 * @param subscriberAddressLineOne a {@link java.lang.String} object.
	 */
	public void setSubscriberAddressLineOne(String subscriberAddressLineOne) {
		this.subscriberAddressLineOne = subscriberAddressLineOne;
	}

	/**
	 * <p>Getter for the field <code>subscriberAddressLineTwo</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getSubscriberAddressLineTwo() {
		return subscriberAddressLineTwo;
	}

	/**
	 * <p>Setter for the field <code>subscriberAddressLineTwo</code>.</p>
	 *
	 * @param subscriberAddressLineTwo a {@link java.lang.String} object.
	 */
	public void setSubscriberAddressLineTwo(String subscriberAddressLineTwo) {
		this.subscriberAddressLineTwo = subscriberAddressLineTwo;
	}

	/**
	 * <p>Getter for the field <code>subscriberAddressLineThree</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getSubscriberAddressLineThree() {
		return subscriberAddressLineThree;
	}

	/**
	 * <p>Setter for the field <code>subscriberAddressLineThree</code>.</p>
	 *
	 * @param subscriberAddressLineThree a {@link java.lang.String} object.
	 */
	public void setSubscriberAddressLineThree(String subscriberAddressLineThree) {
		this.subscriberAddressLineThree = subscriberAddressLineThree;
	}

	/**
	 * <p>Getter for the field <code>subscriberCity</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getSubscriberCity() {
		return subscriberCity;
	}

	/**
	 * <p>Setter for the field <code>subscriberCity</code>.</p>
	 *
	 * @param subscriberCity a {@link java.lang.String} object.
	 */
	public void setSubscriberCity(String subscriberCity) {
		this.subscriberCity = subscriberCity;
	}

	/**
	 * <p>Getter for the field <code>subscriberState</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getSubscriberState() {
		return subscriberState;
	}

	/**
	 * <p>Setter for the field <code>subscriberState</code>.</p>
	 *
	 * @param subscriberState a {@link java.lang.String} object.
	 */
	public void setSubscriberState(String subscriberState) {
		this.subscriberState = subscriberState;
	}

	/**
	 * <p>Getter for the field <code>subscriberZipCode</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getSubscriberZipCode() {
		return subscriberZipCode;
	}

	/**
	 * <p>Setter for the field <code>subscriberZipCode</code>.</p>
	 *
	 * @param subscriberZipCode a {@link java.lang.String} object.
	 */
	public void setSubscriberZipCode(String subscriberZipCode) {
		this.subscriberZipCode = subscriberZipCode;
	}

	/**
	 * <p>Getter for the field <code>patientFullName</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getPatientFullName() {
		return patientFullName;
	}

	/**
	 * <p>Setter for the field <code>patientFullName</code>.</p>
	 *
	 * @param patientFullName a {@link java.lang.String} object.
	 */
	public void setPatientFullName(String patientFullName) {
		this.patientFullName = patientFullName;
	}

	/**
	 * <p>Getter for the field <code>dateOfService</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getDateOfService() {
		return dateOfService;
	}

	/**
	 * <p>Setter for the field <code>dateOfService</code>.</p>
	 *
	 * @param dateOfService a {@link java.lang.String} object.
	 */
	public void setDateOfService(String dateOfService) {
		this.dateOfService = dateOfService;
	}

	/**
	 * <p>Getter for the field <code>transferFrom</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getTransferFrom() {
		return transferFrom;
	}

	/**
	 * <p>Setter for the field <code>transferFrom</code>.</p>
	 *
	 * @param transferFrom a {@link java.lang.String} object.
	 */
	public void setTransferFrom(String transferFrom) {
		this.transferFrom = transferFrom;
	}

	/**
	 * <p>Getter for the field <code>transferType</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getTransferType() {
		return transferType;
	}

	/**
	 * <p>Setter for the field <code>transferType</code>.</p>
	 *
	 * @param transferType a {@link java.lang.String} object.
	 */
	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}

	/**
	 * <p>Getter for the field <code>transferTarget</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getTransferTarget() {
		return transferTarget;
	}

	/**
	 * <p>Setter for the field <code>transferTarget</code>.</p>
	 *
	 * @param transferTarget a {@link java.lang.String} object.
	 */
	public void setTransferTarget(String transferTarget) {
		this.transferTarget = transferTarget;
	}

	/**
	 * <p>Getter for the field <code>transferTargetType</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getTransferTargetType() {
		return transferTargetType;
	}

	/**
	 * <p>Setter for the field <code>transferTargetType</code>.</p>
	 *
	 * @param transferTargetType a {@link java.lang.String} object.
	 */
	public void setTransferTargetType(String transferTargetType) {
		this.transferTargetType = transferTargetType;
	}
}
