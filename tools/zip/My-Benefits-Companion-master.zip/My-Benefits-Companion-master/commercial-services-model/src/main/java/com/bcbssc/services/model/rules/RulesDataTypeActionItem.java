/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * RulesDataTypeActionItem.java
 * 
 * Created on Oct 19, 2009 by EN80

 */

package com.bcbssc.services.model.rules;

import java.io.Serializable;

/**
 * This class holds the Rules DataType Action Item.
 *
 * <pre>
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-services-model/src/main/java/com/bcbssc/services/model/rules/RulesDataTypeActionItem.java_v  $
 * $Workfile:   RulesDataTypeActionItem.java  $
 * $Revision:   1.0  $
 * $Date:   Oct 20 2009 12:00:44  $
 * $Modtime:   Oct 19 2009 13:39:02  $
 * </pre>
 *
 * @author $Author:   EN80  $
 * @version $Id: $Id
 */
public class RulesDataTypeActionItem implements Serializable {

		private static final long serialVersionUID = 18686786785567L;
		
		private String actionCode; 
		private String keyFieldOne; 
		private String keyFieldTwo;
		private String keyFieldThree; 
		private String beginDate; 
		private String terminationDate;
		private String dataFieldOne; 
		private String dataFieldTwo; 
		private String dataFieldThree;
		/**
		 * <p>Getter for the field <code>actionCode</code>.</p>
		 *
		 * @return the actionCode
		 */
		public String getActionCode() {
			return actionCode;
		}
		/**
		 * <p>Setter for the field <code>actionCode</code>.</p>
		 *
		 * @param actionCode the actionCode to set
		 */
		public void setActionCode(String actionCode) {
			this.actionCode = actionCode;
		}
		/**
		 * <p>Getter for the field <code>beginDate</code>.</p>
		 *
		 * @return the beginDate
		 */
		public String getBeginDate() {
			return beginDate;
		}
		/**
		 * <p>Setter for the field <code>beginDate</code>.</p>
		 *
		 * @param beginDate the beginDate to set
		 */
		public void setBeginDate(String beginDate) {
			this.beginDate = beginDate;
		}
		/**
		 * <p>Getter for the field <code>dataFieldOne</code>.</p>
		 *
		 * @return the dataFieldOne
		 */
		public String getDataFieldOne() {
			return dataFieldOne;
		}
		/**
		 * <p>Setter for the field <code>dataFieldOne</code>.</p>
		 *
		 * @param dataFieldOne the dataFieldOne to set
		 */
		public void setDataFieldOne(String dataFieldOne) {
			this.dataFieldOne = dataFieldOne;
		}
		/**
		 * <p>Getter for the field <code>dataFieldThree</code>.</p>
		 *
		 * @return the dataFieldThree
		 */
		public String getDataFieldThree() {
			return dataFieldThree;
		}
		/**
		 * <p>Setter for the field <code>dataFieldThree</code>.</p>
		 *
		 * @param dataFieldThree the dataFieldThree to set
		 */
		public void setDataFieldThree(String dataFieldThree) {
			this.dataFieldThree = dataFieldThree;
		}
		/**
		 * <p>Getter for the field <code>dataFieldTwo</code>.</p>
		 *
		 * @return the dataFieldTwo
		 */
		public String getDataFieldTwo() {
			return dataFieldTwo;
		}
		/**
		 * <p>Setter for the field <code>dataFieldTwo</code>.</p>
		 *
		 * @param dataFieldTwo the dataFieldTwo to set
		 */
		public void setDataFieldTwo(String dataFieldTwo) {
			this.dataFieldTwo = dataFieldTwo;
		}
		/**
		 * <p>Getter for the field <code>keyFieldOne</code>.</p>
		 *
		 * @return the keyFieldOne
		 */
		public String getKeyFieldOne() {
			return keyFieldOne;
		}
		/**
		 * <p>Setter for the field <code>keyFieldOne</code>.</p>
		 *
		 * @param keyFieldOne the keyFieldOne to set
		 */
		public void setKeyFieldOne(String keyFieldOne) {
			this.keyFieldOne = keyFieldOne;
		}
		/**
		 * <p>Getter for the field <code>keyFieldThree</code>.</p>
		 *
		 * @return the keyFieldThree
		 */
		public String getKeyFieldThree() {
			return keyFieldThree;
		}
		/**
		 * <p>Setter for the field <code>keyFieldThree</code>.</p>
		 *
		 * @param keyFieldThree the keyFieldThree to set
		 */
		public void setKeyFieldThree(String keyFieldThree) {
			this.keyFieldThree = keyFieldThree;
		}
		/**
		 * <p>Getter for the field <code>keyFieldTwo</code>.</p>
		 *
		 * @return the keyFieldTwo
		 */
		public String getKeyFieldTwo() {
			return keyFieldTwo;
		}
		/**
		 * <p>Setter for the field <code>keyFieldTwo</code>.</p>
		 *
		 * @param keyFieldTwo the keyFieldTwo to set
		 */
		public void setKeyFieldTwo(String keyFieldTwo) {
			this.keyFieldTwo = keyFieldTwo;
		}
		/**
		 * <p>Getter for the field <code>terminationDate</code>.</p>
		 *
		 * @return the terminationDate
		 */
		public String getTerminationDate() {
			return terminationDate;
		}
		/**
		 * <p>Setter for the field <code>terminationDate</code>.</p>
		 *
		 * @param terminationDate the terminationDate to set
		 */
		public void setTerminationDate(String terminationDate) {
			this.terminationDate = terminationDate;
		}
		
		/* (non-Javadoc)
		 * @see java.lang.Object#toString()
		 */
		/**
		 * <p>toString.</p>
		 *
		 * @return a {@link java.lang.String} object.
		 */
		public String toString(){
			
			StringBuffer output = new StringBuffer();
			output.append("\n*********** One RulesDataType ActionItem BEGIN ***************").append("\n");
			output.append("actionCode=" + actionCode).append("\t");
			output.append("keyFieldOne=" + keyFieldOne).append("\t");
			output.append("keyFieldTwo=" + keyFieldTwo).append("\t");
			output.append("keyFieldThree=" + keyFieldThree).append("\t");
			output.append("beginDate=" + beginDate).append("\t");
			output.append("terminationDate=" + terminationDate).append("\t");
			output.append("dataFieldOne=" + dataFieldOne).append("\t");
			output.append("dataFieldTwo=" + dataFieldTwo).append("\t");
			output.append("dataFieldThree=" + dataFieldThree).append("\t\n");
			output.append("\n*********** One RulesDataType ActionItem END ***************").append("\n");
			return output.toString();
		}

	
}
