/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2011 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.services.model.common;


/**
 * <p>SamlAssertionException class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class SamlAssertionException extends APIException {

	/**
	 *
	 */
	private static final long serialVersionUID = -181905661491301539L;

	/**
	 * Creates a new instance of SamlAssertionException.
	 */
	public SamlAssertionException() {
		super();
	}

	/**
	 * Creates a new instance of SamlAssertionException with a descriptive message.
	 *
	 * @param message
	 *            The exception message.
	 */
	public SamlAssertionException(String message) {
		super(message);
	}

	/**
	 * Creates a new instance of SamlAssertionException with a descriptive message and a
	 * root cause.
	 *
	 * @param message
	 *            The exception message.
	 * @param rootCause
	 *            The root cause of this exception.
	 */
	public SamlAssertionException(String message, Throwable rootCause) {
		super(message, rootCause);
	}

	/**
	 * Creates a new instance of SamlAssertionException with the given root cause.
	 *
	 * @param rootCause
	 *            The root cause of this exception.
	 */
	public SamlAssertionException(Throwable rootCause) {
		super(rootCause);
	}
}
