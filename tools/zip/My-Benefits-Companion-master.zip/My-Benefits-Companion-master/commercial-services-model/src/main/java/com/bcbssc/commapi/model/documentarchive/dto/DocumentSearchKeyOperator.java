/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * DocumentSearchKeyOperator.java
 * Date: May 25, 2010
 */
package com.bcbssc.commapi.model.documentarchive.dto;

/**
 * An enum representing a DocumentSearchKey operator.
 *
 * Author: FF74
 *
 * @author jc33
 * @version $Id: $Id
 */
public enum DocumentSearchKeyOperator {

	BETWEEN (1024),
	EQUAL (1),
	GREATER_THAN (16),
	GREATER_THAN_EQUAL (32),
	IN (64),
	LESS_THAN (4),
	LESS_THAN_EQUAL (8),
	LIKE (256),
	NOT_BETWEEN (2048),
	NOT_EQUAL (20),
	NOT_IN (128),
	NOT_LIKE (512),
	INPUT_TYPE_CHOICE (67),
	INPUT_TYPE_NORMAL (78),
	INPUT_TYPE_NOTE_COLOR (90),
	INPUT_TYPE_NOTE_TEXT_SEARCH (65),
	INPUT_TYPE_SEGMENT (83),
	INPUT_TYPE_TEXT_SEARCH (84),
	FLDQ_BASE (66),
	FLDQ_DATE (68),
	FLDQ_DATETIME (67),
	FLDQ_TIME (84),
	FLDQ_TZ_DATETIME (90);

    /** Holds value of property key. */
	private int key;
	
	/**
     * Creates a new enum of DocumentSearchKeyOperator.
     * 
	 * @param keyValue the keyValue to set
	 */
	private DocumentSearchKeyOperator(int keyValue){
		this.key = keyValue;
	}// End of constructor DocumentSearchKeyOperator()
	
    /**
     * Getter for property key.
     *
     * @return the key
     */
    public int getKey(){
        return this.key;
    }// End of method getKey()
}// End of enum DocumentSearchKeyOperator
