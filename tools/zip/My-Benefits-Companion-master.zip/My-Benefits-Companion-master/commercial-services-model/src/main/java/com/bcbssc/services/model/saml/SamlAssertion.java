/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2011 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.services.model.saml;

import java.io.Serializable;
import java.util.HashMap;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

/**
 * <p>SamlAssertion class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class SamlAssertion implements Serializable {

	private static final long serialVersionUID = 6030166868956350920L;

	private String nameQualifier;

	private String signedByEntity;

	private HashMap<String, String> attributes;

	/**
	 * <p>Getter for the field <code>nameQualifier</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getNameQualifier() {
		return nameQualifier;
	}

	/**
	 * <p>Setter for the field <code>nameQualifier</code>.</p>
	 *
	 * @param nameQualifier a {@link java.lang.String} object.
	 */
	public void setNameQualifier(String nameQualifier) {
		this.nameQualifier = nameQualifier;
	}

	/**
	 * <p>Getter for the field <code>signedByEntity</code>.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String getSignedByEntity() {
		return signedByEntity;
	}

	/**
	 * <p>Setter for the field <code>signedByEntity</code>.</p>
	 *
	 * @param signedByEntity a {@link java.lang.String} object.
	 */
	public void setSignedByEntity(String signedByEntity) {
		this.signedByEntity = signedByEntity;
	}

	/**
	 * <p>Getter for the field <code>attributes</code>.</p>
	 *
	 * @return a {@link java.util.HashMap} object.
	 */
	public HashMap<String, String> getAttributes() {
		return attributes;
	}

	/**
	 * <p>Setter for the field <code>attributes</code>.</p>
	 *
	 * @param attributes a {@link java.util.HashMap} object.
	 */
	public void setAttributes(HashMap<String, String> attributes) {
		this.attributes = attributes;
	}

	/**
	 * <p>toString.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
