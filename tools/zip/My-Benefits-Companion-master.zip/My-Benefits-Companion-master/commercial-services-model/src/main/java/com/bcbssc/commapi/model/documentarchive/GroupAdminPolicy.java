/**
 * 
 */
package com.bcbssc.commapi.model.documentarchive;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.log4j.Logger;

import com.bcbssc.commapi.model.common.CommonListDocument;

/**
 * A class representing a GroupAdminCert object.
 *
 * @author X94s
 * @version $Id: $Id
 */
public class GroupAdminPolicy extends CommonListDocument implements Serializable {
	
    /** Holds value of the serialVersionUID */
	private static final long serialVersionUID = 1L;

	/** The log4j logger for this class */
    private static Logger logger = Logger.getLogger(GroupAdminPolicy.class);

    /** Holds value of property groupNumber. */
	private String groupNumber;
	
	
	private String reportId;
	
	private String reportIdDesc;
	
	/**
	 * <p>Getter for the field <code>reportIdDesc</code>.</p>
	 *
	 * @return the reportIdDesc
	 */
	public String getReportIdDesc() {
		return reportIdDesc;
	}


	/**
	 * <p>Setter for the field <code>reportIdDesc</code>.</p>
	 *
	 * @param reportIdDesc the reportIdDesc to set
	 */
	public void setReportIdDesc(String reportIdDesc) {
		this.reportIdDesc = reportIdDesc;
	}


	/**
	 * <p>Getter for the field <code>reportId</code>.</p>
	 *
	 * @return the reportId
	 */
	public String getReportId() {
		return reportId;
	}


	/**
	 * <p>Setter for the field <code>reportId</code>.</p>
	 *
	 * @param reportId the reportId to set
	 */
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}


	/**
	 * <p>Getter for the field <code>description</code>.</p>
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}


	/**
	 * <p>Setter for the field <code>description</code>.</p>
	 *
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}


	private String description;
    
	/**
	 * <p>Getter for the field <code>groupNumber</code>.</p>
	 *
	 * @return the groupNumber
	 */
	public String getGroupNumber() {
		return groupNumber;
	}


	/**
	 * <p>Setter for the field <code>groupNumber</code>.</p>
	 *
	 * @param groupNumber the groupNumber to set
	 */
	public void setGroupNumber(String groupNumber) {
		this.groupNumber = groupNumber;
	}


	/**
	 * <p>Getter for the field <code>groupName</code>.</p>
	 *
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}


	/**
	 * <p>Setter for the field <code>groupName</code>.</p>
	 *
	 * @param groupName the groupName to set
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	/**
	 * <p>Getter for the field <code>postingDate</code>.</p>
	 *
	 * @return the postingDate
	 */
	public String getPostingDate() {
		return postingDate;
	}


	/**
	 * <p>Setter for the field <code>postingDate</code>.</p>
	 *
	 * @param postingDate the postingDate to set
	 */
	public void setPostingDate(String postingDate) {
		this.postingDate = postingDate;
	}


	/**
	 * <p>Getter for the field <code>effectiveDate</code>.</p>
	 *
	 * @return the effectiveDate
	 */
	public String getEffectiveDate() {
		return effectiveDate;
	}


	/**
	 * <p>Setter for the field <code>effectiveDate</code>.</p>
	 *
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}


	/** Holds value of property groupName. */
	private String groupName;
	

	

	
	  /** Holds value of property postingDate. */
	private String postingDate;
	
    /** Holds value of property effectiveDate. */
	private String effectiveDate;



	/**
	 * Creates a new instance of GroupAdminBill
	 */
	public GroupAdminPolicy() {
		if(GroupAdminPolicy.logger.isDebugEnabled()) {
			GroupAdminPolicy.logger.debug("Created GroupAdminPolicy object.");
		}// End of if(GroupAdminPolicy.logger.isDebugEnabled())
	}// End of constructor GroupAdminPolicy()

	
	/**
	 * The string representation of this class.
	 *
	 * @return the string representation of this class
	 */
	public String toString() {
    	return ToStringBuilder.reflectionToString(this);
    }// End of method toString()
}// End of class GroupAdminCert
