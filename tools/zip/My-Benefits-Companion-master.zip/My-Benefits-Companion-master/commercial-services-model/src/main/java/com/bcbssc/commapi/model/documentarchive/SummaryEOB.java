package com.bcbssc.commapi.model.documentarchive;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.log4j.Logger;

import com.bcbssc.commapi.model.common.CommonListDocument;

/**
 * An class representing a SummaryEOB object.
 *
 * Author: FF74
 *
 * @author jc33
 * @version $Id: $Id
 */
public class SummaryEOB extends CommonListDocument implements Serializable {
	
    /** Holds value of the serialVersionUID */
	private static final long serialVersionUID = 1L;

	/** The log4j logger for this class */
    private static Logger logger = Logger.getLogger(SummaryEOB.class);

    /** Holds value of property idCardNo. */
	private String idCardNo;

    /** Holds value of property postingDate. */
	private String postingDate;

    /** Holds value of property reportId. */
	private String reportId;

    /** Holds value of property reportIdDesc. */
	private String reportIdDesc;

    /** Holds value of property statementStartDate. */
	private String statementStartDate;

    /** Holds value of property statementEndDate. */
	private String statementEndDate;

    /** Holds value of property subscriberId. */
	private String subscriberId;

	/**
	 * Creates a new instance of SummaryEOB
	 */
	public SummaryEOB() {
		if(SummaryEOB.logger.isDebugEnabled()) {
			SummaryEOB.logger.debug("Created SummaryEOB object.");
		}// End of if(SummaryEOB.logger.isDebugEnabled())
	}// End of constructor SummaryEOB()

	/**
	 * Getter for property subscriberId.
	 *
	 * @return the subscriberId
	 */
	public String getSubscriberId() {
		return this.subscriberId;
	}// End of method getSubscriberId()

	/**
	 * Setter for property subscriberId.
	 *
	 * @param subscriberId the subscriberId to set
	 */
	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}// End of method setSubscriberId()

	/**
	 * Getter for property idCardNo.
	 *
	 * @return the idCardNo
	 */
	public String getIdCardNo() {
		return this.idCardNo;
	}// End of method getIdCardNo()

	/**
	 * Setter for property idCardNo.
	 *
	 * @param idCardNo the idCardNo to set
	 */
	public void setIdCardNo(String idCardNo) {
		this.idCardNo = idCardNo;
	}// End of method setIdCardNo()

	/**
	 * Getter for property statementStartDate.
	 *
	 * @return the statementStartDate
	 */
	public String getStatementStartDate() {
		return this.statementStartDate;
	}// End of method getStatementStartDate()

	/**
	 * Setter for property statementStartDate.
	 *
	 * @param statementStartDate the statementStartDate to set
	 */
	public void setStatementStartDate(String statementStartDate) {
		this.statementStartDate = statementStartDate;
	}// End of method setStatementStartDate()

	/**
	 * Getter for property statementEndDate.
	 *
	 * @return the statementEndDate
	 */
	public String getStatementEndDate() {
		return this.statementEndDate;
	}// End of method getStatementEndDate()

	/**
	 * Setter for property statementEndDate.
	 *
	 * @param statementEndDate the statementEndDate to set
	 */
	public void setStatementEndDate(String statementEndDate) {
		this.statementEndDate = statementEndDate;
	}// End of method setStatementEndDate()

	/**
	 * Getter for property postingDate.
	 *
	 * @return the postingDate
	 */
	public String getPostingDate() {
		return this.postingDate;
	}// End of method getPostingDate()

	/**
	 * Setter for property postingDate.
	 *
	 * @param postingDate the postingDate to set
	 */
	public void setPostingDate(String postingDate) {
		this.postingDate = postingDate;
	}// End of method setPostingDate()

	/**
	 * Getter for property reportId.
	 *
	 * @return the reportId
	 */
	public String getReportId() {
		return this.reportId;
	}// End of method getReportId()

	/**
	 * Setter for property reportId.
	 *
	 * @param reportId the reportId to set
	 */
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}// End of method setReportId()

	/**
	 * Getter for property reportIdDesc.
	 *
	 * @return the reportIdDesc
	 */
	public String getReportIdDescription() {
		return this.reportIdDesc;
	}// End of method getReportIdDescription()

	/**
	 * Setter for property reportIdDesc.
	 *
	 * @param reportIdDesc the reportIdDesc to set
	 */
	public void setReportIdDesc(String reportIdDesc) {
		this.reportIdDesc = reportIdDesc;
	}// End of method setReportIdDesc()

	/**
	 * The string representation of this class.
	 *
	 * @return the string representation of this class
	 */
	public String toString() {
    	return ToStringBuilder.reflectionToString(this);
    }// End of method toString()
}// End of class SummaryEOB
