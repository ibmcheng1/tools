/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * DocumentDTO.java
 * Date: May 25, 2010
 */
package com.bcbssc.commapi.model.documentarchive.dto;

import java.io.Serializable;
import java.util.HashMap;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.log4j.Logger;

/**
 * An class representing a DocumentDTO object.
 *
 * Author: FF74
 *
 * @author jc33
 * @version $Id: $Id
 */
public class DocumentDTO implements Serializable {
	
    /** Holds value of the serialVersionUID */
	private static final long serialVersionUID = 1L;

	/** The log4j logger for this class */
    private static Logger logger = Logger.getLogger(DocumentDTO.class);

    /** Holds value of property docId. */
	private String docId;

    /** Holds value of property mimeType. */
	private String mimeType;

    /** Holds value of property documentType. */
	private String documentType;

    /** Holds value of property documentAttributes. */
	private HashMap<String, String> documentAttributes;

	/**
	 * Creates a new instance of DocumentDTO
	 */
	public DocumentDTO() {
		if(DocumentDTO.logger.isDebugEnabled()) {
			DocumentDTO.logger.debug("Created DocumentSearchCriteria object.");
		}// End of if(DocumentDTO.logger.isDebugEnabled())
	}// End of constructor DocumentDTO()

	/**
	 * Getter for property docId.
	 *
	 * @return the docId
	 */
	public String getDocId() {
		return this.docId;
	}// End of method getDocId()

	/**
	 * Setter for property docId.
	 *
	 * @param docId the docId to set
	 */
	public void setDocId(String docId) {
		this.docId = docId;
	}// End of method setDocId()

	/**
	 * Getter for property mimeType.
	 *
	 * @return the mimeType
	 */
	public String getMimeType() {
		return this.mimeType;
	}// End of method getMimeType()

	/**
	 * Setter for property mimeType.
	 *
	 * @param mimeType the mimeType to set
	 */
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}// End of method setMimeType()

	/**
	 * Getter for property documentType.
	 *
	 * @return the documentType
	 */
	public String getDocumentType() {
		return this.documentType;
	}// End of method getDocumentType()

	/**
	 * Setter for property documentType.
	 *
	 * @param documentType the documentType to set
	 */
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}// End of method setDocumentType()

	/**
	 * Getter for property documentAttributes.
	 *
	 * @return the documentAttributes
	 */
	public HashMap<String, String> getDocumentAttributes() {
		return this.documentAttributes;
	}// End of method getDocumentAttributes()

	/**
	 * Setter for property documentAttributes.
	 *
	 * @param documentAttributes the documentAttributes to set
	 */
	public void setDocumentAttributes(HashMap<String, String> documentAttributes) {
		this.documentAttributes = documentAttributes;
	}// End of method setDocumentAttributes()

	/**
	 * The string representation of this class.
	 *
	 * @return the string representation of this class
	 */
	public String toString() {
    	return ToStringBuilder.reflectionToString(this);
    }// End of method toString()
}// End of class DocumentDTO
