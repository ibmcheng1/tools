/*
 * Created on Jan 5, 2005
 * @author XR93
 * 
 * Copyright (c) 2004 by BlueCross and BlueShield of South Carolina
 * All Rights Reserved.
 * 
 * Parse and format phone numbers containing (area code) ppp-ssss 
 */

package com.bcbssc.struts.common;

import org.apache.log4j.Logger;

/**
 * <p>PhoneNumber class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class PhoneNumber {

	private static Logger logger = Logger.getLogger(PhoneNumber.class);

	/** 1st 3 chars of 10 char number */
	protected String areacode = "";

	/** chars 4-7 of 10 char number */
	protected String prefix = "";

	/** chars 8-10 of 10 char number */
	protected String suffix = "";

	/**
	 * <p>Constructor for PhoneNumber.</p>
	 */
	public PhoneNumber() {
		if (PhoneNumber.logger.isDebugEnabled()) {
			PhoneNumber.logger.debug("Created PhoneNumber object.");
		}
	}

	/**
	 * create a blank object
	 *
	 * @return a {@link com.bcbssc.struts.common.PhoneNumber} object.
	 */
	public static PhoneNumber blank() {
		return new PhoneNumber();
	}

	/**
	 * parse number aaapppsssss into area code, prefix and suffix
	 *
	 * @param rawNumber
	 *            10 char phone number
	 */
	public void parse(String rawNumber) {
		if (rawNumber.length() == 10) {
			this.areacode = rawNumber.substring(0, 3);
			this.prefix = rawNumber.substring(3, 6);
			this.suffix = rawNumber.substring(6);
		} else {
			if (PhoneNumber.logger.isDebugEnabled()) {
				PhoneNumber.logger.debug("parse(): invalid phone number: "
						+ rawNumber);
			}
		}
	}

	/**
	 * <p>Getter for the field <code>areacode</code>.</p>
	 *
	 * @return areacode
	 */
	public String getAreacode() {
		return this.areacode;
	}

	/**
	 * <p>Getter for the field <code>prefix</code>.</p>
	 *
	 * @return prefix
	 */
	public String getPrefix() {
		return this.prefix;
	}

	/**
	 * <p>Getter for the field <code>suffix</code>.</p>
	 *
	 * @return suffix
	 */
	public String getSuffix() {
		return this.suffix;
	}

	/**
	 * save area code
	 *
	 * @param string
	 *            areaCode
	 */
	public void setAreacode(String string) {
		this.areacode = string;
	}

	/**
	 * save prefix
	 *
	 * @param string
	 *            prefix
	 */
	public void setPrefix(String string) {
		this.prefix = string;
	}

	/**
	 * save suffix
	 *
	 * @param string
	 *            suffix
	 */
	public void setSuffix(String string) {
		this.suffix = string;
	}

	/**
	 * format the three parts into a 10 char phone number aaapppssss
	 *
	 * @return phone number (10 chars)
	 */
	public String toString() {
		StringBuffer s = new StringBuffer(this.areacode).append(this.prefix)
				.append(this.suffix);
		return s.toString();
	}

	/**
	 * format the three parts into (aaa) ppp-ssss string for display
	 *
	 * @return phone number (14 chars)
	 */
	public String format() {
		StringBuffer s = new StringBuffer(16);
		if (this.areacode.length() > 0) {
			s.append('(').append(this.areacode).append(')');
		}
		if ((this.prefix.length() > 0) && (this.suffix.length() > 0)) {
			s.append(this.prefix).append("-").append(this.suffix);
		}
		return s.toString();
	}
}
