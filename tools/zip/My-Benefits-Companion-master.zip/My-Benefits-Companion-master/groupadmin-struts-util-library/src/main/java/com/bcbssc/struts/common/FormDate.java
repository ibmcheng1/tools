/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-strutsutil/src/main/java/com/bcbssc/struts/common/FormDate.java_v  $
 * $Workfile:   FormDate.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:56:12  $
 * $Modtime:   May 23 2009 00:19:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-strutsutil/src/main/java/com/bcbssc/struts/common/FormDate.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:56:12   EN80
 * Initial revision.
 * 
 *    Rev 1.11   Apr 28 2009 10:42:40   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.10   Mar 19 2009 10:46:16   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.9   Apr 28 2005 10:35:32   rxr93
 * issm compliance
 * 
 *    Rev 1.8   Apr 27 2005 14:42:22   rxr93
 * add makeCalendar()
 * 
 *    Rev 1.7   Apr 18 2005 10:03:46   rxr93
 * remove unneeded debnug statements
 * 
 *    Rev 1.6   Mar 22 2005 14:30:14   rdq70
 * Added today().
 *
 *    Rev 1.5   Mar 22 2005 13:08:40   rxg97
 * Added getter for formatted method.
 *
 *    Rev 1.4   Mar 15 2005 13:41:52   rxr93
 * issm change
 *
 *    Rev 1.3   Mar 10 2005 09:40:32   rxg97
 * Return of day/month padding.
 *
 *    Rev 1.2   Mar 09 2005 19:57:36   rxg97
 * Removed date padding.
 *
 *    Rev 1.1   Mar 07 2005 11:07:42   rxr93
 * ISSM suggested change
 *
 */
package com.bcbssc.struts.common;

import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.apache.log4j.Logger;

/**
 * A date object for forms.
 *
 * @author jc33
 * @version $Id: $Id
 */
public class FormDate extends DateBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1625399599296869997L;

	/** The log4j logger for this class */
	private static Logger logger = Logger.getLogger(FormDate.class);

	/* padding strings */
	private static final String SINGLE_DATE_PAD = "0";

	private static final String YEAR_DATE_PAD = "20";

	/** month */
	protected String month = "";

	/** day */
	protected String day = "";

	/** year */
	protected String year = "";

	/**
	 * <p>Constructor for FormDate.</p>
	 */
	public FormDate() {
		if (FormDate.logger.isDebugEnabled()) {
			FormDate.logger.debug("Created FormDate object.");
		}
	}

	/**
	 * Creates a blank object.
	 *
	 * @return a {@link com.bcbssc.struts.common.FormDate} object.
	 */
	public static FormDate blank() {
		FormDate sd = new FormDate();
		return sd;
	}

	/**
	 * Creates a date object for today.
	 *
	 * @return a {@link com.bcbssc.struts.common.FormDate} object.
	 */
	public static FormDate today() {
		final FormDate today = new FormDate();
		final GregorianCalendar cal = new GregorianCalendar();
		final DecimalFormat formatter = new DecimalFormat("00");

		today.setMonth(formatter.format(cal.get(Calendar.MONTH) + 1));
		today.setDay(formatter.format(cal.get(Calendar.DATE)));

		formatter.applyPattern("0000");
		today.setYear(formatter.format(cal.get(Calendar.YEAR)));

		return today;
	}

	/**
	 * parses a date into month day and year accepts two or one digits for month
	 * and day accepts two or four digits for year
	 *
	 * @param date
	 *            full date
	 */
	public void parse(String date) {
		boolean error = false;

		int firstSlashIndex = date.indexOf('/');
		int secondSlashIndex = -1;

		if (firstSlashIndex == -1) {
			error = true;
		} else {
			secondSlashIndex = date.indexOf('/', firstSlashIndex + 1);

			if (secondSlashIndex == -1) {
				error = true;
			}
		}

		if (!error) {
			String unformattedMonth = date.substring(0, firstSlashIndex);
			int monthLength = unformattedMonth.length();
			String unformattedDay = date.substring(firstSlashIndex + 1,
					secondSlashIndex);
			int dayLength = unformattedDay.length();
			String unformattedYear = date.substring(secondSlashIndex + 1);
			int yearLength = unformattedYear.length();

			if ((monthLength == 0) || (dayLength == 0) || (yearLength == 0)
					|| (monthLength > 2) || (dayLength > 2) || (yearLength > 4)
					|| (yearLength == 3)) {
				error = true;
			} else {
				if (monthLength == 1) {
					unformattedMonth = FormDate.SINGLE_DATE_PAD
							+ unformattedMonth;
				}

				if (dayLength == 1) {
					unformattedDay = FormDate.SINGLE_DATE_PAD + unformattedDay;
				}

				if (yearLength == 2) {
					unformattedYear = FormDate.YEAR_DATE_PAD + unformattedYear;
				}

				this.month = unformattedMonth;
				this.day = unformattedDay;
				this.year = unformattedYear;
			}
		}

		if (error) {
			FormDate.logger.error("parse(): invalid date " + date);
		}
	}

	/**
	 * <p>Getter for the field <code>month</code>.</p>
	 *
	 * @return month
	 */
	public String getMonth() {
		return this.month;
	}

	/**
	 * <p>Getter for the field <code>day</code>.</p>
	 *
	 * @return day
	 */
	public String getDay() {
		return this.day;
	}

	/**
	 * <p>Getter for the field <code>year</code>.</p>
	 *
	 * @return year
	 */
	public String getYear() {
		return this.year;
	}

	/**
	 * {@inheritDoc}
	 *
	 * save month
	 */
	public void setMonth(String string) {
		if (string.length() == 1) {
			this.month = "0" + string;
		} else {
			this.month = string;
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * save day
	 */
	public void setDay(String string) {
		if (string.length() == 1) {
			this.day = "0" + string;
		} else {
			this.day = string;
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * save year
	 */
	public void setYear(String string) {
		this.year = string;
	}

	/**
	 * sets the year to that of another datebean
	 *
	 * @param bean
	 *            datebean representing year to be set
	 */
	public void setDate(DateBean bean) {
		this.day = bean.getDay();
		this.month = bean.getMonth();
		this.year = bean.getYear();
	}

	/**
	 * format the three parts into a mm/dd/yyyy year
	 *
	 * @return formatted date
	 */
	public String toString() {
		String returnString = Constants.BLANK_STRING;
		if ((this.month.length() > 0) || (this.day.length() > 0)
				|| (this.year.length() > 0)) {
			StringBuffer s = new StringBuffer(this.month).append('/').append(
					this.day).append('/').append(this.year);
			return s.toString();
		}
		return returnString;
	}

	/**
	 * provides a bean getter implementation of toString()
	 *
	 * @return formatted date
	 */
	public String getFormatted() {
		return this.toString();
	}

	/**
	 * provides a bean setter implementation of parse()
	 *
	 * @param date a {@link java.lang.String} object.
	 */
	public void setFormatted(String date) {
		this.parse(date);
	}

	/**
	 * Convert this object to a java.util.Calendar
	 *
	 * @return java.util.Calendar
	 */
	public Calendar makeCalendar() {
		return FormDate.makeCalendar(this);
	}

	/**
	 * Convert a DateBean to a java.util.Calendar
	 *
	 * @return java.util.Calendar
	 * @param dtb a {@link com.bcbssc.struts.common.DateBean} object.
	 */
	public static Calendar makeCalendar(DateBean dtb) {

		// default the value
		Calendar retVal = null;
		try {
			if ((dtb == null) || "".equals(dtb.getYear())
					|| "".equals(dtb.getMonth()) || "".equals(dtb.getDay())) {
				// blank, return an uninitilaized date
				if (FormDate.logger.isDebugEnabled()) {
					FormDate.logger
							.debug("makeCalendar() - not set or unusable, return uninitialized date");
				}
				retVal = new GregorianCalendar();
			} else {
				// 1st load to a calender object
				retVal = new GregorianCalendar(Integer.parseInt(dtb.getYear()),
						Integer.parseInt(dtb.getMonth()) - 1, Integer
								.parseInt(dtb.getDay()));

			}
		} catch (NumberFormatException nfe) {
			if (dtb != null) {
				FormDate.logger.error("makeCalendar() - invalid date "
						+ dtb.toString());
			}
			FormDate.logger
					.error("makeCalendar() - invalid date, incoming DateBean parameter was null");
		}
		return retVal;
	}
}
