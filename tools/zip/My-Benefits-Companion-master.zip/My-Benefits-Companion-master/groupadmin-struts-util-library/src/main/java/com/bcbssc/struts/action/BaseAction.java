/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-strutsutil/src/main/java/com/bcbssc/struts/action/BaseAction.java_v  $
 * $Workfile:   BaseAction.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:56:04  $
 * $Modtime:   Apr 18 2005 09:45:22  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-strutsutil/src/main/java/com/bcbssc/struts/action/BaseAction.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:56:04   EN80
 * Initial revision.
 * 
 *    Rev 1.2   Apr 18 2005 10:02:46   rxr93
 * fix log debug to show form name rather than form contents
 * 
 *    Rev 1.1   Mar 07 2005 11:11:08   rxr93
 * issm changes
 * 
 */ 
package com.bcbssc.struts.action;

import org.apache.log4j.Logger;
import org.apache.struts.Globals;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.config.ModuleConfig;
import org.apache.struts.util.RequestUtils;

import javax.servlet.http.HttpServletRequest;


/**
 * <p>BaseAction class.</p>
 *
 * @author XR93
 *
 * Common logic used by BlueCross and BlueShield of South Carolina
 * action classes
 * @version $Id: $Id
 */
public class BaseAction extends Action {
    /** log4j logger */
    private static final Logger logger = Logger.getLogger(BaseAction.class);

    /**
     * <p>Constructor for BaseAction.</p>
     */
    public BaseAction() {
        super();
    }

    /**
     * Create or reload the form associated with the 'path' requested.
     *
     * @param formName 	key used in storing form in session
     * @param path 		from struts-config.xml (ie /createProfile)
     * @param request 	servlet request object
     * @return form		ActionForm object (actually a class that extends ActionForm)
     */
    protected ActionForm getForm(String formName, String path, HttpServletRequest request) {

        ActionForm form = (ActionForm) request.getAttribute(formName);

        if (form == null) {
            form = (ActionForm) request.getSession().getAttribute(formName);
        }

        if (form == null) {
            ModuleConfig modConfig = (ModuleConfig) request.getAttribute(Globals.MODULE_KEY);

            ActionMapping mapping = (ActionMapping) modConfig.findActionConfig(path);
            logger.debug("getForm() mapping: " + mapping);
            form = RequestUtils.createActionForm(request, mapping, modConfig,
                                                 (ActionServlet) getServlet());

            String key = mapping.getAttribute();

            if ("request".equals(mapping.getScope())) {
                request.setAttribute(key, form);
            } else {
                request.getSession().setAttribute(key, form);
            }
        }
		logger.debug("getForm() form loaded: " + form.getClass().getName());
        return form;
    }

    /**
     * Adds a global message to the request
     *
     * @param request  the HTTP request to add the message
     * @param property  the name of the message in the properties file
     */
    protected void addGlobalRequestMessage(HttpServletRequest request, String property) {
        ActionMessages messages   = new ActionMessages();
        ActionMessage  newMessage = new ActionMessage(property);
        messages.add(ActionMessages.GLOBAL_MESSAGE, newMessage);
        saveMessages(request, messages);
    }
}
