/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-strutsutil/src/main/java/com/bcbssc/struts/common/SocialSecurityNumber.java_v  $
 * $Workfile:   SocialSecurityNumber.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:56:14  $
 * $Modtime:   May 23 2009 00:19:32  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-strutsutil/src/main/java/com/bcbssc/struts/common/SocialSecurityNumber.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:56:14   EN80
 * Initial revision.
 * 
 *    Rev 1.3   Apr 28 2009 10:42:44   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.2   Mar 19 2009 10:46:18   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.1   Mar 07 2005 11:08:08   rxr93
 * issm suggested change
 *
 */
package com.bcbssc.struts.common;

import org.apache.log4j.Logger;

/**
 * <p>SocialSecurityNumber class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class SocialSecurityNumber {

	/** The log4j logger for this class */
	private static Logger log = Logger.getLogger(SocialSecurityNumber.class);

	/** ssn */
	private String ssn = "";

	/**
	 * <p>Constructor for SocialSecurityNumber.</p>
	 */
	public SocialSecurityNumber() {
		if (SocialSecurityNumber.log.isDebugEnabled()) {
			SocialSecurityNumber.log
					.debug("Created SocialSecurityNumber object.");
		}
	}

	/**
	 * create a blank object
	 *
	 * @return a {@link com.bcbssc.struts.common.SocialSecurityNumber} object.
	 */
	public static SocialSecurityNumber blank() {
		return new SocialSecurityNumber();
	}

	/**
	 * return unformatted ssn
	 *
	 * @return unformatted ssn
	 */
	public String getValue() {
		return this.ssn;
	}

	/**
	 * save ssn
	 *
	 * @param string
	 *            unformatted ssn
	 */
	public void setValue(String string) {
		this.ssn = string;
	}

	/**
	 * return the unformatted ssn
	 *
	 * @return unformatted ssn
	 */
	public String toString() {
		return this.ssn;
	}

	/**
	 * format the ssn into xxx-xx-xxxx format
	 *
	 * @return formatted ssn
	 */
	public String format() {
		String returnString = Constants.BLANK_STRING;
		if (this.ssn.length() == 9) {
			StringBuffer formattedSsn = new StringBuffer();
			formattedSsn.append(this.ssn.substring(0, 3)).append('-').append(
					this.ssn.substring(3, 5)).append('-').append(
					this.ssn.substring(5));
			returnString = formattedSsn.toString();
		}
		return returnString;
	}
}
