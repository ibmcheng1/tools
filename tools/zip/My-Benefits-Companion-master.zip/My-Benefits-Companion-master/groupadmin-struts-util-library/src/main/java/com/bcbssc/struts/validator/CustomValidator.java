/*
 * @(#)CustomValidator.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-strutsutil/src/main/java/com/bcbssc/struts/validator/CustomValidator.java_v  $
 * $Workfile:   CustomValidator.java  $
 * $Revision:   1.2  $
 * $Date:   Aug 26 2009 14:45:02  $
 * $Modtime:   Aug 26 2009 11:35:52  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-strutsutil/src/main/java/com/bcbssc/struts/validator/CustomValidator.java_v  $
 * 
 *    Rev 1.2   Aug 26 2009 14:45:02   js39
 * Handled the IllegalArgumentException.
 *
 *    Rev 1.1   Aug 03 2009 10:44:00   rx24c
 * Changed the method signatures to struts 1.3 standards.
 *
 *    Rev 1.0   Jun 26 2009 15:56:20   EN80
 * Initial revision.
 *
 *    Rev 1.19   Apr 28 2009 10:42:50   rff74
 * Java6 Upgrade
 *
 *    Rev 1.18   Mar 19 2009 10:46:20   rff74
 * Java6 Upgrade
 *
 *    Rev 1.17   Feb 22 2006 11:29:32   rx22q
 * fixed the logic for zip code
 *
 *    Rev 1.16   Jan 30 2006 10:43:36   rx22q
 * changed the logic for validating the username in create profile.
 *
 *    Rev 1.15   Jan 24 2006 17:32:38   rx22q
 * bluehammur changes
 *
 *    Rev 1.14   Jan 18 2006 11:02:56   rx22q
 * Changes for the web security
 *
 *    Rev 1.13   Jan 13 2006 11:41:36   rx22q
 * Chnages for user name validation
 *
 *    Rev 1.12   Jan 10 2006 18:33:40   rx22q
 * Chnages for web security for zip code
 *
 *    Rev 1.11   Jan 06 2006 15:02:10   rx22q
 * fixes for web security
 *
 *    Rev 1.10   Dec 19 2005 10:19:34   rx22q
 * Changed the logic for zip code validation.
 *
 *    Rev 1.9   Nov 23 2005 16:54:44   rx24c
 * Changes made for the statecode message
 *
 *    Rev 1.8   Nov 22 2005 10:06:38   rx22q
 * Changed the error mesages for postal code validation according to the new standards
 * websecurity fixes for postal code validation
 *
 *    Rev 1.7   Mar 23 2005 14:31:10   rdq70
 * Handle dates of the form: today+n, today-n.
 *
 *    Rev 1.6   Mar 21 2005 17:28:28   rxg97
 * Added support for requiredif validation in postalcode validator.
 *
 *    Rev 1.5   Mar 18 2005 16:33:36   rxg97
 * Updated validatePostalCode() to default to US if country var is not passed in.
 *
 *    Rev 1.4   Mar 17 2005 14:56:00   rdq70
 * Added verifyMutuallyExclusive().
 *
 *    Rev 1.3   Mar 15 2005 13:30:50   rxr93
 * issm changes
 *
 *    Rev 1.2   Mar 07 2005 11:06:58   rxr93
 * issm suggested changes
 *
 */

package com.bcbssc.struts.validator;

import com.bcbssc.struts.common.CommonUtils;
import com.bcbssc.struts.common.Constants;
import com.bcbssc.struts.forms.Options;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.validator.Field;
import org.apache.commons.validator.GenericTypeValidator;
import org.apache.commons.validator.GenericValidator;
import org.apache.commons.validator.ValidatorAction;
import org.apache.commons.validator.util.ValidatorUtils;
import org.apache.commons.validator.Validator;
import org.apache.log4j.Logger;
import org.apache.regexp.RE;
import org.apache.regexp.RESyntaxException;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.validator.Resources;

/**
 * Shared Registration Custom Validator
 *
 * This class provides extensions to the struts Validator package for
 * specialized shared registration validations. It currently supports the
 * following validations:<br>
 * <br>
 *
 * <pre>
 *      validateAlphanumeric
 *          description: verifies all characters are alphanumeric
 *          required validator.rules.xml entry:
 *              &lt;validator name=&quot;alphanumeric&quot;
 *                  classname=&quot;com.bcbssc.sharedreg.validator.CustomValidator&quot;
 *                  method=&quot;validateAlphanumeric&quot;
 *                  methodParams=&quot;java.lang.Object,
 *                      org.apache.commons.validator.ValidatorAction,
 *                      org.apache.commons.validator.Field,
 *                      org.apache.struts.action.ActionMessages,
 *                      javax.servlet.http.HttpServletRequest&quot;
 *                  msg=&quot;errors.alphanumeric&quot;&gt;
 *              &lt;/validator&gt;
 *          example validator.xml rule:
 *              &lt;field property=&quot;accessCode&quot; depends=&quot;required, alphanumeric&quot;/&gt;
 *      validateLengthRange
 *          description: provides combined min/max length checking
 *          required validator.rules.xml entry:
 *              &lt;validator name=&quot;lengthrange&quot;
 *                  classname=&quot;com.bcbssc.registration.validator.CustomValidator&quot;
 *                  method=&quot;validateLengthRange&quot;
 *                  methodParams=&quot;java.lang.Object,
 *                      org.apache.commons.validator.ValidatorAction,
 *                      org.apache.commons.validator.Field,
 *                      org.apache.struts.action.ActionMessages,
 *                      javax.servlet.http.HttpServletRequest&quot;
 *                  msg=&quot;errors.lengthrange&quot;&gt;
 *              &lt;/validator&gt;
 *          example validator.xml rule:
 *              &lt;field property=&quot;unicodePwd&quot; depends=&quot;required,lengthrange&quot;&gt;
 *                  &lt;arg0 key=&quot;characters&quot; resource=&quot;false&quot;/&gt;
 *                  &lt;arg1 key=&quot;${var:minlength}&quot; resource=&quot;false&quot;/&gt;
 *                  &lt;arg2 key=&quot;${var:maxlength}&quot; resource=&quot;false&quot;/&gt;
 *                  &lt;var&gt;
 *                      &lt;var-name&gt;minlength&lt;/var-name&gt;
 *                      &lt;var-value&gt;6&lt;/var-value&gt;
 *                  &lt;/var&gt;
 *                  &lt;var&gt;
 *                      &lt;var-name&gt;maxlength&lt;/var-name&gt;
 *                      &lt;var-value&gt;11&lt;/var-value&gt;
 *                  &lt;/var&gt;
 *              &lt;/field&gt;
 *      verifyMutuallyExclusive
 *          description: verifies that given fields are mutually exclusive
 *          required validator.rules.xml entry:
 *              &lt;validator name=&quot;mutuallyExclusive&quot;
 *                  classname=&quot;com.bcbssc.sharedreg.validator.CustomValidator&quot;
 *                  method=&quot;verifyMutuallyExclusive&quot;
 *                  methodParams=&quot;java.lang.Object,
 *                      org.apache.commons.validator.ValidatorAction,
 *                      org.apache.commons.validator.Field,
 *                      org.apache.struts.action.ActionMessages,
 *                      javax.servlet.http.HttpServletRequest&quot;
 *                  msg=&quot;errors.mutuallyExclusive&quot;&gt;
 *              &lt;/validator&gt;
 *          example validator.xml rule:
 *              &lt;field property=&quot;searchIdentificationNumber&quot; depends=&quot;mutuallyExclusive&quot;&gt;
 *                  &lt;msg name=&quot;mutuallyExclusive&quot; key=&quot;errors.searchForm.mutuallyExclusive&quot;/&gt;
 *                  &lt;var&gt;
 *                      &lt;var-name&gt;fieldcount&lt;/var-name&gt;
 *                      &lt;var-value&gt;1&lt;/var-value&gt;
 *                  &lt;/var&gt;
 *                  &lt;var&gt;
 *                      &lt;var-name&gt;field1&lt;/var-name&gt;
 *                      &lt;var-value&gt;searchLastName&lt;/var-value&gt;
 *                  &lt;/var&gt;
 *              &lt;/field&gt;
 * </pre>
 *
 * @author Jonathan Egger
 * @version $Revision:   1.2  $
 */
public class CustomValidator implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 5705574657013412600L;

    /** log4j logger */
    private static Logger logger = Logger.getLogger(CustomValidator.class);

    /** The date format input from forms */
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(
            Constants.FORM_DATE_FORMAT);

    /** Specifies use of today's date in daterange rule */
    private static final String DATE_TODAY = "today";

    /** Name of the unicodePwd bean property */
    private static final String UNICODE_PWD = "unicodePwd";

    /** Confirmation Unicodepassword propery name */
    private static final String CONF_UNICODE_PWD = "confUnicodePwd";

    /**
     * Check for single or double quotes.
     *
     * @param bean
     *            The bean validation is being performed on.
     * @param va
     *            The ValidatorAction that is currently being performed.
     * @param field
     *            The Field object associated with the current field being
     *            validated
     * @param errors
     *            The ActionMessages object to add errors to if any validation
     *            errors occur
     * @param request
     *            Current request object
     * @return true if valid, false otherwise
     * @param va
     *            The ValidatorAction that is currently being performed.
     * @param v a {@link org.apache.commons.validator.Validator} object.
     */
    public static boolean validateNoQuotes(Object bean, ValidatorAction va,
            Field field, ActionMessages errors, Validator v, HttpServletRequest request) {

        String value = ValidatorUtils.getValueAsString(bean, field
                .getProperty());
        if (CustomValidator.logger.isDebugEnabled()) {
            CustomValidator.logger.debug("no quotes =[" + value + "]");
        }
        if (value.length() > 0) {
            try {
                RE regexp = new RE("['\"]");
                if (regexp.match(value)) {
                    errors.add(field.getKey(), Resources.getActionMessage(
                            v, request, va, field));
                }
            } catch (RESyntaxException e) {
                CustomValidator.logger.error("Invalid regexp syntax: ", e);
                errors.add(field.getKey(), Resources.getActionMessage(v, request,
                        va, field));
            }
        }
        return errors.isEmpty();
    }

    /**
     * Checks if the field is alphanumeric.
     *
     * @param bean
     *            The bean validation is being performed on.
     * @param va
     *            The ValidatorAction that is currently being performed.
     * @param field
     *            The Field object associated with the current field being
     *            validated
     * @param errors
     *            The ActionMessages object to add errors to if any validation
     *            errors occur
     * @param request
     *            Current request object
     * @return true if valid, false otherwise
     * @param va
     *            The ValidatorAction that is currently being performed.
     * @param v a {@link org.apache.commons.validator.Validator} object.
     */
    public static boolean validateAlphanumeric(Object bean, ValidatorAction va,
            Field field, ActionMessages errors, Validator v, HttpServletRequest request) {

        boolean returnBoolean;
        String value = ValidatorUtils.getValueAsString(bean, field
                .getProperty());

        // If value is blank, count on one of the required validators to
        // generate
        // the error
        if (GenericValidator.isBlankOrNull(value)) {
            returnBoolean = true;
        } else {
            if (!CommonUtils.isAlphaNumeric(value)) {
                errors.add(field.getKey(), Resources.getActionMessage(v, request,
                        va, field));
            }
            returnBoolean = errors.isEmpty();
        }
        return returnBoolean;
    }

    /**
     * Checks if the field is within a range.
     *
     * @param bean
     *            The bean validation is being performed on.
     * @param va
     *            The ValidatorAction that is currently being performed.
     * @param field
     *            The Field object associated with the current field being
     *            validated
     * @param errors
     *            The ActionMessages object to add errors to if any validation
     *            errors occur
     * @param request
     *            Current request object
     * @return true if valid, false otherwise
     * @param va
     *            The ValidatorAction that is currently being performed.
     * @param v a {@link org.apache.commons.validator.Validator} object.
     */
    public static boolean validateLengthRange(Object bean, ValidatorAction va,
            Field field, ActionMessages errors, Validator v, HttpServletRequest request) {

        boolean returnBoolean;
        String value = ValidatorUtils.getValueAsString(bean, field
                .getProperty());
        int min = Integer.parseInt(field.getVarValue("minlength"));
        int max = Integer.parseInt(field.getVarValue("maxlength"));

        // If value is blank, count on one of the required validators to
        // generate
        // the error
        if (GenericValidator.isBlankOrNull(value)) {
            returnBoolean = true;
        } else {
            if ((value.length() < min) || (value.length() > max)) {
                errors.add(field.getKey(), Resources.getActionMessage(v, request,
                        va, field));
            }
            returnBoolean = errors.isEmpty();
        }

        return returnBoolean;
    }

    /**
     * Checks if the date field is within a range.
     *
     * @param bean
     *            The bean validation is being performed on.
     * @param va
     *            The ValidatorAction that is currently being performed.
     * @param field
     *            The Field object associated with the current field being
     *            validated
     * @param errors
     *            The ActionMessages object to add errors to if any validation
     *            errors occur
     * @param request
     *            Current request object
     * @return true if valid, false otherwise
     * @param va
     *            The ValidatorAction that is currently being performed.
     * @param v a {@link org.apache.commons.validator.Validator} object.
     */
    public static boolean validateDateRange(Object bean, ValidatorAction va,
            Field field, ActionMessages errors, Validator v, HttpServletRequest request) {

        boolean returnBoolean;
        String value = ValidatorUtils.getValueAsString(bean, field
                .getProperty());
        String min = field.getVarValue("mindate");
        String max = field.getVarValue("maxdate");

        // If value is blank, count on one of the required validators to
        // generate
        // the error
        if (GenericValidator.isBlankOrNull(value)) {
            returnBoolean = true;
        } else {
            try {
                final Date date = CustomValidator.DATE_FORMAT.parse(value);
                final Date minDate;
                if (min == null) {
                    minDate = date;
                } else {
                    minDate = CustomValidator.parseDate(min);
                }
                final Date maxDate;
                if (max == null) {
                    maxDate = date;
                } else {
                    maxDate = CustomValidator.parseDate(max);
                }
                if (CustomValidator.logger.isDebugEnabled()) {
                    CustomValidator.logger.debug("comparing " + date
                            + " to range (" + minDate + ", " + maxDate + ")");
                }
                if (date.before(minDate) || date.after(maxDate)) {
                    errors.add(field.getKey(), Resources.getActionMessage(
                            v, request, va, field));
                }
            } catch (ParseException pe) {
                if (CustomValidator.logger.isDebugEnabled()) {
                    CustomValidator.logger.debug("parse(" + value + ") "
                            + pe.toString());
                }
                errors.add(field.getKey(), Resources.getActionMessage(v, request,
                        va, field));
            }
            returnBoolean = errors.isEmpty();
        }
        return returnBoolean;
    }

    /**
     * Verify that this field matches the designated 'other' field (ie. password
     * confirmation, email addr confirmation ...)
     *
     * @param bean
     *            The bean validation is being performed on.
     * @param va
     *            The ValidatorAction that is currently being performed.
     * @param field
     *            The Field object associated with the current field being
     *            validated
     * @param errors
     *            The ActionMessages object to add errors to if any validation
     *            errors occur
     * @param request
     *            Current request object
     * @return true if valid, false otherwise
     * @param va
     *            The ValidatorAction that is currently being performed.
     * @param v a {@link org.apache.commons.validator.Validator} object.
     */
    public static boolean validateMatch(Object bean, ValidatorAction va,
            Field field, ActionMessages errors, Validator v, HttpServletRequest request) {

        boolean returnBoolean;
        String value = ValidatorUtils.getValueAsString(bean, field
                .getProperty());
        String dependProp = field.getVarValue("match");

        String dependValue = ValidatorUtils.getValueAsString(bean, dependProp);

        // If value is blank, count on one of the required validators to
        // generate
        // the error
        if (GenericValidator.isBlankOrNull(value)
                || GenericValidator.isBlankOrNull(dependValue)) {
            errors.add(field.getKey(), Resources.getActionMessage(v, request, va,
                    field));
            returnBoolean = errors.isEmpty();
        } else if (value.equals(dependValue)) {
            returnBoolean = true;
        } else {
            errors.add(field.getKey(), Resources.getActionMessage(v, request, va,
                    field));
            returnBoolean = errors.isEmpty();
        }
        return returnBoolean;
    }

    /**
     * Performs specialized Zip code validation US only 1. This field is
     * required. 2. This field must be numeric. 3. This field requires 5 or 9
     * digits. Canada 1. field is required 2. Alpha numeric and spaces allow Non
     * US This field must be spaces.
     *
     * @param bean
     *            The bean validation is being performed on.
     * @param field
     *            The Field object associated with the current field being
     *            validated
     * @param errors
     *            The ActionMessages object to add errors to if any validation
     *            errors occur
     */
    public static void validatePostalCode(Object bean, Field field,
            ActionMessages errors) {
        CustomValidator.logger.debug("Inside Postal Code Validation ");
        String postalCode = ValidatorUtils.getValueAsString(bean, field
                .getProperty());

        // logger.debug("Bean Name: "+bean.getClass().getName());
        String beanName = bean.getClass().getName();
        String countryProp = field.getVarValue("country");
        String country = Constants.BLANK_STRING;

        // If value is blank, count on one of the required validators to
        // generate
        // the error
        /*
         * if (GenericValidator.isBlankOrNull(postalCode)) {
         * errors.add(field.getKey(), new ActionMessage("error.postalCode.null")); }
         */

        if (countryProp != null) {
            // If country isn't passed, leave country blank (defaults to US)
            String countryCode = ValidatorUtils.getValueAsString(bean,
                    countryProp);
            country = countryCode.trim();
        }
        String zip = postalCode.trim();
        String dental = field.getVarValue("field[0]");
        String dentalCoverage = null;

        try {
            dentalCoverage      = ValidatorUtils.getValueAsString(bean, dental);
        }
        catch(Exception exception) {
        }
        // logger.debug("dental property:"+dental);
        // logger.debug("dentalCoverage password:"+dentalCoverage);
        // logger.debug("Zip Code: "+zip);
        // Added this logic aonly for AddInsuredDetailsForm
        // This is not a good desing need to be fixed once the complete
        // application uses
        // same error framework

        if ((beanName
                .equalsIgnoreCase("com.bcbssc.groupadmin.shared.forms.AddInsuredDetailsForm"))
                || (beanName
                        .equalsIgnoreCase("com.bcbssc.groupadmin.shared.forms.ModifyInsuredDetailsForm"))) {
            // logger.debug("Bean name validation ");

            if("false".equals(dentalCoverage)) {
                // Do nothing
            }
            else if (zip.length() == 0) {
                // logger.debug("for Zip null ");
                errors.add(field.getKey(), new ActionMessage("errors.required"));
            } else if ((zip.length() != 5) && (zip.length() != 9)) {
                Integer result = GenericTypeValidator.formatInt(zip);
                if (result == null) {
                    errors.add(field.getKey(),
                            new ActionMessage("errors.integer"));
                } else {
                    errors.add(field.getKey(), new ActionMessage(
                            "errors.postalcode.length"));
                }
            }
        } else if ((country.length() == 0)
                || country.equals(Options.US_COUNTRY_CODE)) {
            // logger.debug("Inside US ");
            if (zip.length() == 0) {
                // logger.debug("for Zip null ");
                errors.add(field.getKey(), new ActionMessage(
                        "error.postalCode.null"));
            } else if ((zip.length() != 5) && (zip.length() != 9)) {
                Integer result = GenericTypeValidator.formatInt(zip);
                if (result == null) {
                    errors.add(field.getKey(), new ActionMessage(
                            "error.postalCode.numeric"));
                } else {
                    errors.add(field.getKey(), new ActionMessage(
                            "error.postalCode.length"));
                }
            } else {
                // logger.debug("Inside US and numeric check ");
                // US Zip code must be Integer
                Integer result = GenericTypeValidator.formatInt(zip);
                if (result == null) {
                    errors.add(field.getKey(), new ActionMessage(
                            "error.postalCode.numeric"));
                }
            }
        } else if (country.equals(Options.CA_COUNTRY_CODE)) {
            // logger.debug("Inside Canada ");
            if (zip.length() == 0) {
                errors.add(field.getKey(), new ActionMessage(
                        "error.postalCode.null"));
            } else {
                // CA Zip code must be alphanumeric but can contain spaces
                // Replace any spaces with a number so isAlphaNumeric will work
                // logger.debug("Inside Canada alpha ");
                zip = zip.replace(' ', '0');
                if (!CommonUtils.isAlphaNumeric(zip)) {
                    errors.add(field.getKey(), new ActionMessage(
                            "error.postalCode.alphanumeric"));
                }
            }
        } else {
            // logger.debug("Inside other countries ");
            if (zip.length() != 0) {
                errors.add(field.getKey(), new ActionMessage(
                        "error.postalCode.otherCountries"));
            }
        }
    }

    /**
     * Performs specialized State validation US only This field is required. Non
     * US This field must be spaces.
     *
     * @param errors
     *            form error messages
     * @param bean a {@link java.lang.Object} object.
     * @param field a {@link org.apache.commons.validator.Field} object.
     */
    public static void validateStateCode(Object bean, Field field,
            ActionMessages errors) {

        String state = ValidatorUtils.getValueAsString(bean, field
                .getProperty());

        String countryProp = field.getVarValue("country");
        String country = ValidatorUtils.getValueAsString(bean, countryProp);

        if (country.equals(Options.US_COUNTRY_CODE)
                || country.equals(Options.CA_COUNTRY_CODE)) {
            if (state.length() == 0) {
                errors.add(field.getKey(), new ActionMessage(
                        "error.codeRequestForm.state.null"));
            }
        } else {
            if (state.length() != 0) {
                errors.add(field.getKey(), new ActionMessage("errors.notempty"));
            }
        }
    }

    /**
     * Performs specialized phone extension validation
     *
     * @param errors
     *            form error messages
     * @param bean a {@link java.lang.Object} object.
     * @param field a {@link org.apache.commons.validator.Field} object.
     */
    public static void validatePhoneExtension(Object bean, Field field,
            ActionMessages errors) {

        String phoneNumber = ValidatorUtils.getValueAsString(bean, field
                .getProperty());

        String phoneExtProp = field.getVarValue("match");
        CustomValidator.logger.debug("Phone Extension:" + phoneExtProp);

        String phoneExt = ValidatorUtils.getValueAsString(bean, phoneExtProp);

        if (phoneNumber.length() == 0) {
            if (!(phoneExt.length() == 0)) {
                errors.add(field.getKey(), new ActionMessage(
                        "error.createProfileForm.phoneextension.null"));
            }
        }
    }

    /**
     * Validate LDAP user name to make sure there are reserved words used
     *
     * @param bean a {@link java.lang.Object} object.
     * @param va
     *            ValidatorAction (defined in validate-rules.xml)
     * @param field
     *            form's Field (defined in validate.xml)
     * @param errors
     *            list of errors
     * @param request
     *            HttpServletRequest
     * @param va
     *            ValidatorAction (defined in validate-rules.xml)
     * @param v a {@link org.apache.commons.validator.Validator} object.
     * @throws java.lang.Exception if any.
     */
    public static void validateSamAccountReserved(Object bean,
            ValidatorAction va, Field field, ActionMessages errors, Validator v,
            HttpServletRequest request) throws Exception {

        String samAccountName = ValidatorUtils.getValueAsString(bean, field
                .getProperty());

        // String unicodepwd = ValidatorUtil.getValueAsString(bean,
        // "unicodePwd");
        // String confunicodepwd = ValidatorUtil.getValueAsString(bean,
        // "confUnicodePwd");
        String pwd = field.getVarValue("unicodePwd");
        String unicodepwd = ValidatorUtils.getValueAsString(bean, pwd);
        String confpwd = field.getVarValue("confUnicodePwd");
        String confunicodepwd = ValidatorUtils.getValueAsString(bean, confpwd);
        String beanName = bean.getClass().getName();
        if (CustomValidator.logger.isDebugEnabled()) {
            CustomValidator.logger.debug("conf password property:" + confpwd);
            CustomValidator.logger.debug("password property:" + pwd);
            CustomValidator.logger
                    .debug("validateSamAccountReserved method() password:"
                            + unicodepwd);
            CustomValidator.logger
                    .debug("validateSamAccountReserved method() conf password:"
                            + confunicodepwd);
            CustomValidator.logger
                    .debug("validateSamAccountReserved method() bean Name:"
                            + beanName);
        }

        if (samAccountName.length() > 0) {
            if ("service".equals(samAccountName)
                    || "system".equals(samAccountName)
                    || "guest".equals(samAccountName)
                    || "network".equals(samAccountName)) {
                // logger.debug("validateSamAccountReserved method() end
                // reserved");
                errors.add(field.getKey(), new ActionMessage(
                        "errors.samaccountname.reserved"));
                if (!("".equalsIgnoreCase(unicodepwd))
                        && !("".equalsIgnoreCase(confunicodepwd))
                        && (unicodepwd.length() >= 6)
                        && (confunicodepwd.length() >= 6)) {
                    errors.add(CustomValidator.UNICODE_PWD, new ActionMessage(
                            "error.createProfileForm.passWord.null"));
                    errors
                            .add(
                                    CustomValidator.CONF_UNICODE_PWD,
                                    new ActionMessage(
                                            "errors.createProfileForm.confirmpwd.required"));
                }
            } else if (samAccountName.charAt(samAccountName.length() - 1) == ' ') {
                // logger.debug("validateSamAccountSpaces method() end spaces");
                // errors.add(field.getKey(), Resources.getActionMessage(request,
                // va, field));
                errors.add(field.getKey(), new ActionMessage(
                        "errors.samaccountname.endspaces"));
                if (!("".equalsIgnoreCase(unicodepwd))
                        && !("".equalsIgnoreCase(confunicodepwd))
                        && (unicodepwd.length() >= 6)
                        && (confunicodepwd.length() >= 6)) {
                    errors.add(CustomValidator.UNICODE_PWD, new ActionMessage(
                            "error.createProfileForm.passWord.null"));
                    errors
                            .add(
                                    CustomValidator.CONF_UNICODE_PWD,
                                    new ActionMessage(
                                            "errors.createProfileForm.confirmpwd.required"));
                }
            } else if (unicodepwd.equalsIgnoreCase(samAccountName)) {
                if (beanName
                        .equalsIgnoreCase("com.bcbssc.groupadmin.shared.forms.ProfileActionForm")) {
                    errors
                            .add(
                                    CustomValidator.UNICODE_PWD,
                                    new ActionMessage(
                                            "errors.createProfileForm.unicodepwd.usernamematch"));
                    errors
                            .add(
                                    CustomValidator.CONF_UNICODE_PWD,
                                    new ActionMessage(
                                            "errors.createProfileForm.confirmpwd.required"));
                } else {
                    errors.add(CustomValidator.UNICODE_PWD, new ActionMessage(
                            "errors.unicodepwd.usernamematch"));
                    errors
                            .add(
                                    CustomValidator.CONF_UNICODE_PWD,
                                    new ActionMessage(
                                            "error.changePasswordForm.confirmpwd.required"));
                }
            } else {
                try {
                    // logger.debug("validateSamAccountValidChars method()
                    // before RE"+samAccountName);
                    RE regexp = new RE("[\\.\\*@#,\\+\\/\\\\<>:;\\?=]");
                    if (regexp.match(samAccountName)) {
                        // logger.debug("validateSamAccountValidChars method()
                        // validating user name");
                        // errors.add(field.getKey(),
                        // Resources.getActionMessage(request, va, field));
                        errors.add(field.getKey(), new ActionMessage(
                                "errors.samaccountname.invalidchars"));
                        if (!("".equalsIgnoreCase(unicodepwd))
                                && !("".equalsIgnoreCase(confunicodepwd))
                                && (unicodepwd.length() >= 6)
                                && (confunicodepwd.length() >= 6)) {
                            errors
                                    .add(
                                            CustomValidator.UNICODE_PWD,
                                            new ActionMessage(
                                                    "error.createProfileForm.passWord.null"));
                            errors
                                    .add(
                                            CustomValidator.CONF_UNICODE_PWD,
                                            new ActionMessage(
                                                    "errors.createProfileForm.confirmpwd.required"));
                        }
                    }
                } catch (RESyntaxException e) {
                    CustomValidator.logger.error("Invalid regexp syntax: ", e);
                    errors.add(field.getKey(), Resources.getActionMessage(
                            v, request, va, field));
                    throw new Exception();
                }
            }
        }
    }

    /**
     * Validate LDAP user name to make sure there are no trailing spaces ?
     *
     * @param bean a {@link java.lang.Object} object.
     * @param field
     *            form's Field (defined in validate.xml)
     * @param errors
     *            list of errors
     */
    public static void validateSamAccountSpaces(Object bean, Field field,
            ActionMessages errors) {

        String samAccountName = ValidatorUtils.getValueAsString(bean, field
                .getProperty());

        if (samAccountName.length() > 0) {
            if (samAccountName.charAt(samAccountName.length() - 1) == ' ') {
                CustomValidator.logger
                        .debug("validateSamAccountSpaces method() end spaces");
                // errors.add(field.getKey(), Resources.getActionMessage(request,
                // va, field));
                errors.add(field.getKey(), new ActionMessage(
                        "errors.samaccountname.endspaces"));
            }
        }
    }

    /**
     * Validate LDAP user name to make sure there are no invalid characters
     *
     * @param bean a {@link java.lang.Object} object.
     * @param va
     *            ValidatorAction (defined in validate-rules.xml)
     * @param field
     *            form's Field (defined in validate.xml)
     * @param errors
     *            list of errors
     * @param request
     *            HttpServletRequest
     * @param va
     *            ValidatorAction (defined in validate-rules.xml)
     * @param v a {@link org.apache.commons.validator.Validator} object.
     */
    public static void validateSamAccountValidChars(Object bean,
            ValidatorAction va, Field field, ActionMessages errors, Validator v,
            HttpServletRequest request) {

        String samAccountName = ValidatorUtils.getValueAsString(bean, field
                .getProperty());

        if (samAccountName.length() > 0) {
            try {
                CustomValidator.logger
                        .debug("validateSamAccountValidChars method() before RE"
                                + samAccountName);
                RE regexp = new RE("[\\.\\*@#,\\+\\/\\\\<>:;\\?=]");
                if (regexp.match(samAccountName)) {
                    CustomValidator.logger
                            .debug("validateSamAccountValidChars method() validating user name");
                    // errors.add(field.getKey(),
                    // Resources.getActionMessage(request, va, field));
                    errors.add(field.getKey(), new ActionMessage(
                            "errors.samaccountname.invalidchars"));
                }
            } catch (RESyntaxException e) {
                CustomValidator.logger.error("Invalid regexp syntax: ", e);
                errors.add(field.getKey(), Resources.getActionMessage(v, request,
                        va, field));
            }
        }
    }

    /**
     * Verifies that given fields are mutually exclusive.
     *
     * @param bean
     *            The bean validation is being performed on.
     * @param va
     *            The ValidatorAction that is currently being performed.
     * @param field
     *            The Field object associated with the current field being
     *            validated
     * @param errors
     *            The ActionMessages object to add errors to if any validation
     *            errors occur
     * @param request
     *            Current request object
     * @return true if valid, false otherwise
     * @param va
     *            The ValidatorAction that is currently being performed.
     * @param v a {@link org.apache.commons.validator.Validator} object.
     */
    public static boolean verifyMutuallyExclusive(Object bean,
            ValidatorAction va, Field field, ActionMessages errors, Validator v,
            HttpServletRequest request) {

        String value = ValidatorUtils.getValueAsString(bean, field
                .getProperty());
        boolean foundOne = !GenericValidator.isBlankOrNull(value);
        int count = Integer.parseInt(field.getVarValue("fieldcount"));

        for (int i = 1; i <= count; i++) {
            final String name = field.getVarValue("field" + i);
            final String val = ValidatorUtils.getValueAsString(bean, name);
            if (!GenericValidator.isBlankOrNull(val)) {
                if (foundOne) {
                    errors.add(field.getKey(), Resources.getActionMessage(
                            v, request, va, field));
                    break;
                }
                foundOne = true;
            }
        }
        return errors.isEmpty();
    }

    /**
     * Parses a date expression.
     *
     * @param strDate
     *            a date expression of one of the following forms:
     *            <ol>
     *            <li>today</li>
     *            <li>today+n</li>
     *            <li>today-n</li>
     *            <li>MM/dd/yyyy</li>
     *            </ol>
     *
     * @return a date object representing the date expression.
     *
     * @throws ParseException
     *             if the date cannot be parsed.
     */
    private static Date parseDate(String strDate) throws ParseException {
        final Date retVal;
        final int len = CustomValidator.DATE_TODAY.length();

        if (strDate.startsWith(CustomValidator.DATE_TODAY)) {
            GregorianCalendar cal = new GregorianCalendar();
            if (strDate.length() > len + 1) {
                int index = len;
                if (strDate.charAt(len) == '+') {
                    index++;
                }
                final DecimalFormat format = new DecimalFormat("0");
                final int value = format.parse(strDate.substring(index))
                        .intValue();
                cal.add(Calendar.DATE, value);
            }
            retVal = cal.getTime();
        } else {
            retVal = CustomValidator.DATE_FORMAT.parse(strDate);
        }
        return retVal;
    }
}
