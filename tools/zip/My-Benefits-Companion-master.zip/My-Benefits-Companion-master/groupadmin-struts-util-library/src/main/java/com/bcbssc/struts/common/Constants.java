/*
 *
 * @(#)Constants.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.struts.common;

/**
 * Struts Common Constants
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class Constants {

    /**
     * Blank String
     **/
    public static final String BLANK_STRING = "".intern();
    
    /**
     * Pipe Separator
     **/
    public static final String PIPE_SEPARATOR = "|".intern();    
    
    
    /**
     * Format of dates input from forms
     */
    public static final String FORM_DATE_FORMAT = "MM/dd/yyyy";

}
