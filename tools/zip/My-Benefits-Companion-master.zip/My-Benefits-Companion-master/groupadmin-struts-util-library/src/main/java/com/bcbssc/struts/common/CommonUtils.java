/*
 *
 * @(#)CommonUtils.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.struts.common;

import java.util.ArrayList;
import java.util.Collection;
import java.util.StringTokenizer;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.util.LabelValueBean;

import com.opennetwork.DSUtils.IDSValList;

import org.apache.log4j.Logger;

/**
 * Common Registration Utilities
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class CommonUtils {
	
    /**
     * The log4j <CODE>Logger</CODE> for this class.
     */
    protected static final Logger logger = Logger.getLogger(CommonUtils.class);

    /**
     * Read the supplied string and determine whether or not it is null; if it is, return an empty
     * string "", otherwise, return the original value <code> String strValue =
     * Common.formatNulltoEmptyString( strValue ); </code>
     *
     * @param strValue supplied String
     * @return String parameter value or empty String ("")
     */
    public static String formatNulltoEmptyString(String strValue) {
        return strValue != null ? strValue.trim() : Constants.BLANK_STRING;
    }

    /**
     * Read the supplied string and determine whether or not it is null; if it is, return the other
     * supplied string; otherwise, return the original value <code> String strValue =
     * Common.formatNulltoString( strValue ); </code>
     *
     * @param strOrgValue supplied String
     * @param strValueToReturn supplied String objectdefault value if the parameter value does
     *        not exist
     * @return String parameter value or empty String ("")
     */
    public static String formatNulltoString(String strOrgValue, String strValueToReturn) {
        return !(strOrgValue == null) ? strOrgValue
                                             : !(strValueToReturn == null)
                                                 ? strValueToReturn : Constants.BLANK_STRING;
    }

    /**
     * Checks if the passed String is null or has length of zero.
     *
     * @param str String to test for null or length.
     * @return boolean
     */
    public static boolean isNotNullAndNotEmpty(String str) {
    	boolean returnboolean = false;
        if (str != null && str.trim().length() > 0) {
        	returnboolean = true;
        }
        return returnboolean;
    }

    /**
     * Splits a string into an ArrayList based on a delimiter.
     *
     * @param msg string to parse.
     * @param delim delimiter
     * @return ArrayList Resulting ArrayList
     */
    public static ArrayList<String> splitString(String msg, String delim) {
        ArrayList<String> list = new ArrayList<String>();
        if (CommonUtils.isNotNullAndNotEmpty(msg)) {
            StringTokenizer st = new StringTokenizer(msg, delim);
            while (st.hasMoreTokens()) {
                list.add(st.nextToken());
            }
        }
        return list;
    }

    /**
     * Returns true if the passed string is a valid value.
     *
     * @param value value to check.
     * @return true if the passed string is a valid value, otherwise false.
     */
    public static boolean isValidValue(String value) {
    	boolean returnBoolean = true;
        if (value == null || value.length() == 0 || "null".equals(value)) {
        	returnBoolean = false;
        }
        return returnBoolean;
    }

    /**
     * Returns the time taken to complete a specific task in seconds.milliseconds format.
     *
     * @param startTime start time.
     * @param message message to display.
     * @return the time taken to complete a specific task.
     */
    public static String getExecutionTime(long startTime, String message) {
        long nSqlTime = System.currentTimeMillis() - startTime;

        return new StringBuffer(100).append(message).append(nSqlTime / 1000).append(".")
                                    .append(nSqlTime % 1000).append(" Seconds.")
                                    .toString();
    }

	/**
	 * Reads a cookie value from the request
	 *
	 * @param cookieName  the name of the cookie to read
	 * @param request  the HTTP request containing the cookie
	 * @return the cookie value or "" if the cookie is empty
	 */
	public static String readCookie(String cookieName, HttpServletRequest request) {
        String retString = Constants.BLANK_STRING;
        Cookie[] cookies = request.getCookies();
		if(cookies != null) {
            for(int i = 0; i < cookies.length; i++) {
                String name = cookies[i].getName();
                if(name.equals(cookieName)) {
                    retString = cookies[i].getValue();
                    break;
                } // end if cookie is dn cookie
            } // end for (i = 0...
        }
        return retString;
    }
    
    /**
     * <p>writeCookie.</p>
     *
     * @param name a {@link java.lang.String} object.
     * @param value a {@link java.lang.String} object.
     * @param domain a {@link java.lang.String} object.
     * @param path a {@link java.lang.String} object.
     * @param maxAge a int.
     * @return a {@link javax.servlet.http.Cookie} object.
     */
    public static Cookie writeCookie(String name,String value,String domain,String path,int maxAge) {
        Cookie retCookie = new Cookie(name,value);
        retCookie.setPath(path);
        retCookie.setDomain(domain);
        retCookie.setMaxAge(maxAge);
        return retCookie;
    }    

	/**
	 * Gets a single valued string from a DSmart IDSValList
	 *
	 * @param name  name of the string to get
	 * @return value
	 * @param valList a {@link com.opennetwork.DSUtils.IDSValList} object.
	 */
	public static String getSingleValuedString(String name, IDSValList valList) {
		String retval = Constants.BLANK_STRING;
		String [] value = valList.getValueStringArray(name);
		if (value != null) {
			retval = value[0];
		}
		return retval;
	}    

	/**
	 * Verifies that two fields match.  Adds an error to the specified field if
	 * they don't match, but only if this field doesn't already have an
	 * error.
	 *
	 * @param errors  the errors associated with this form
	 * @param value1  first field value
	 * @param value2  second field value
	 * @param errorFieldName  name of the field for which an error may be added
	 * @param errorProperty label of the error property to use for the error
	 */
	public static void validateMatchingIfErrorless(ActionErrors errors, String value1,
                                                   String value2, String errorFieldName,
                                                   String errorProperty) {
        if(!errors.get(errorFieldName).hasNext()) {
            if (!value1.equals(value2)) {
                errors.add(errorFieldName, new ActionMessage(errorProperty,
                           "validationMatch mismatch"));
            }
        }
    }

    /**
     * Joins the contents of a String array using the specified delimiter
     *
     * @param array  array to be joined
     * @param delim  delimiter to use
     * @return joined array contents
     */
    public static String join( String[] array, String delim ) {
        StringBuffer sb = CommonUtils.join(array, delim, new StringBuffer());
        return sb.toString();
    }

    /**
     * Joins the contents of a String array using the specified delimiter
     *
     * @param array  array to be joined
     * @param delim  delimiter to use
     * @param sb  will contain the joined contents
     * @return joined array contents
     */
    public static StringBuffer join( String[] array, String delim, StringBuffer sb ) {
        for ( int i=0; i<array.length; i++ ) {
            if (i!=0) {
                sb.append(delim);
            }
            sb.append(array[i]);
        }
        return sb;		
    }

    /**
     * Determines if a String is alphanumeric.
     *
     * @param v  String to check
     * @return true if String is alphanumeric, false otherwise
     */
    public static boolean isAlphaNumeric(String v){
		boolean flag=false;
        for (int i=0; i < v.length(); i++){
			flag = Character.isLetterOrDigit(v.charAt(i));
            if (!flag) {
				break;
			}
		}
		return flag;
     }

    /**
     * Determines the default for a dropdown Collection of LabelValueBean
     * objects.
     *
     * @param options Collection of LabelValueBean objects
     * @return the value of the default object
     */
    public static String getDefaultOption(Collection<Object> options) {
    	String returnString = null;
        if (options == null || options.size() != 2) {
        	returnString = Constants.BLANK_STRING;
        } else {
            // One real option and a default value.  Make real option the
            // default
            Object [] optionsArray = options.toArray();
            LabelValueBean option = (LabelValueBean)optionsArray[1];
            returnString = option.getValue();
        }
        return returnString;
    }
}
