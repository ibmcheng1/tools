/*
 *
 * @(#)GroupedOption.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.struts.forms;

import org.apache.log4j.Logger;

/**
 * A grouped dropdown option (see setGroupedOptions in common.js for more info)
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class GroupedOption {

	/** The log4j logger for this class */
	private static Logger log = Logger.getLogger(GroupedOption.class);

	/** Group to which the option is associated */
	private String optionGroup;

	/** Value of the option */
	private String optionValue;

	/** Label of the option */
	private String optionLabel;

	/**
	 * Creates a new instance of Option
	 *
	 * @param group a {@link java.lang.String} object.
	 * @param value a {@link java.lang.String} object.
	 * @param label a {@link java.lang.String} object.
	 */
	public GroupedOption(String group, String value, String label) {
		super();
		this.optionGroup = group;
		this.optionValue = value;
		this.optionLabel = label;
		if (GroupedOption.log.isDebugEnabled()) {
			GroupedOption.log.debug("Created GroupedOption object.");
		}
	}

	/**
	 * Gets the option group
	 *
	 * @return option group
	 */
	public String getOptionGroup() {
		return this.optionGroup;
	}

	/**
	 * Gets the option value
	 *
	 * @return option value
	 */
	public String getOptionValue() {
		return this.optionValue;
	}

	/**
	 * Gets the option label
	 *
	 * @return option label
	 */
	public String getOptionLabel() {
		return this.optionLabel;
	}
}
