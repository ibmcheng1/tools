/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2003 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * File:       DateBean.java
 * Created:    March 19, 2009 11:25:05 AM EDT
 * Author:     ff74 (W. Sims)
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-strutsutil/src/main/java/com/bcbssc/struts/common/DateBean.java_v  $
 * $Workfile:   DateBean.java  $
 * $Revision:   1.1  $
 * $DateBean$
 * $Modtime:   Sep 18 2009 14:44:22  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-strutsutil/src/main/java/com/bcbssc/struts/common/DateBean.java_v  $
 * 
 *    Rev 1.1   Sep 22 2009 16:32:22   rx24c
 * overridded tostring
 *
 *    Rev 1.0   Jun 26 2009 15:56:10   EN80
 * Initial revision.
 *
 *    Rev 1.1   Apr 28 2009 10:42:38   rff74
 * Java6 Upgrade
 *
 *    Rev 1.0   Mar 19 2009 11:36:12   rff74
 * Initial revision.
 *
 */

package com.bcbssc.struts.common;

import java.util.Calendar;
import java.util.Date;
import com.bcbssc.netsys.web.SessionDataBean;
import org.apache.log4j.Logger;

/**
 * <p>DateBean class.</p>
 *
 * @author .Net Systems
 * @version $Id: $Id
 */
public class DateBean extends SessionDataBean implements
		java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 8560679373928980793L;

	/** The log4j logger for this class */
	private static Logger log = Logger.getLogger(DateBean.class);

	private final String DEFAULT_STRING = "";

	/** Holds value of property month. */
	private String month = this.DEFAULT_STRING;

	/** Holds value of property day. */
	private String day = this.DEFAULT_STRING;

	/** Holds value of property year. */
	private String year = this.DEFAULT_STRING;

	/**
	 * Creates a new instance of DateBean
	 */
	public DateBean() {
		super();
		if (DateBean.log.isDebugEnabled()) {
			DateBean.log.debug("Created DateBean object.");
		}
	}

	/**
	 * Implementation of .toString() for DateBean located in
	 * com.bcbssc.netsys.web.SessionDataBean
	 */

	/**
	 * Implementation of .equals() for DateBean located in
	 * com.bcbssc.netsys.web.SessionDataBean
	 */

	/**
	 * Getter for property month.
	 *
	 * @return Value of property month.
	 */
	public String getMonth() {
		return this.month;
	}

	/**
	 * Setter for property month.
	 *
	 * @param month
	 *            New value of property month.
	 */
	public void setMonth(String month) {
		this.month = month;
	}

	/**
	 * Getter for property day.
	 *
	 * @return Value of property day.
	 */
	public String getDay() {
		return this.day;
	}

	/**
	 * Setter for property day.
	 *
	 * @param day
	 *            New value of property day.
	 */
	public void setDay(String day) {
		this.day = day;
	}

	/**
	 * Getter for property year.
	 *
	 * @return Value of property year.
	 */
	public String getYear() {
		return this.year;
	}

	/**
	 * Setter for property year.
	 *
	 * @param year
	 *            New value of property year.
	 */
	public void setYear(String year) {
		this.year = year;
	}

	/**
	 * <p>getDate.</p>
	 *
	 * @return a {@link java.util.Date} object.
	 */
	public Date getDate() {

		Date returnDate = null;
		Calendar calendar = Calendar.getInstance();

		try {
			calendar.set(Integer.parseInt(this.year), Integer
					.parseInt(this.month) - 1, Integer.parseInt(this.day));
			returnDate = calendar.getTime();
		} catch (Exception ex) {
			// Do nothing.
		}

		return returnDate;
	}


	/**
	 * <p>toString.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String toString(){

		StringBuffer sbTempBuffer = new StringBuffer();
		sbTempBuffer.append("month = ").append(this.month).append("-");
		sbTempBuffer.append("year = ").append(this.year).append("-");
		sbTempBuffer.append("day = ").append(this.day).append(", ");

		return sbTempBuffer.toString();
	}
}
