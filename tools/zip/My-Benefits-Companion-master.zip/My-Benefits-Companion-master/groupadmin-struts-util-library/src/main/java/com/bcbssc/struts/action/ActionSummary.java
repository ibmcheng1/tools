/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2005 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-strutsutil/src/main/java/com/bcbssc/struts/action/ActionSummary.java_v  $
 * $Workfile:   ActionSummary.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:56:02  $
 * $Modtime:   Jun 17 2009 12:50:20  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-strutsutil/src/main/java/com/bcbssc/struts/action/ActionSummary.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:56:02   EN80
 * Initial revision.
 * 
 *    Rev 1.3   Mar 19 2009 12:47:08   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.2   Mar 19 2009 10:46:14   rff74
 * Java6 Upgrade
 * 
 *    Rev 1.1   Apr 27 2005 13:28:12   rxr93
 * remove unneeded debug  statements
 * 
 *    Rev 1.0   Apr 12 2005 13:20:46   rxr93
 * Initial revision.
 * 
 */
package com.bcbssc.struts.action;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionErrors;

/**
 * <p>ActionSummary class.</p>
 *
 * @author XR93
 *
 * This class compiles the errors received for a form (ActionErrors) into a
 * summary (keyed as SUMMARY)
 * @version $Id: $Id
 */
public class ActionSummary {

	/** log4j logger */
	private static final Logger log = Logger.getLogger(ActionSummary.class);

	/** key to the summary */
	private static final String KEY = "SUMMARY";

	/**
	 * 
	 */
	private ActionSummary() {
		// factory class, no instance needs to be created
		if (ActionSummary.log.isDebugEnabled()) {
			ActionSummary.log.debug("Created ActionSummary object.");
		}
	}

	/**
	 * Create an error summary with page breaks suitable for html page display
	 *
	 * @param errorList a {@link org.apache.struts.action.ActionErrors} object.
	 */
	public static void createSummary(ActionErrors errorList) {
		// after validation, create a sumary of the errors
		// use hashset to eliminate duplicates
		HashSet<String> keys = new HashSet<String>();
		ArrayList<ActionMessage> errSummary = new ArrayList<ActionMessage>();

		Iterator it = errorList.get();
		while (it.hasNext()) {
			ActionMessage o = (ActionMessage) it.next();

			// colect message into a combined list
			if (!keys.contains(o.getKey())) {
				keys.add(o.getKey());
				errSummary.add(o);
			}
		}

		Iterator<ActionMessage> it2 = errSummary.iterator();
		while (it2.hasNext()) {
			ActionMessage o = (ActionMessage) it2.next();
			errorList.add(ActionSummary.KEY, o);
			errorList.add(ActionSummary.KEY, new ActionMessage("errors.break"));
		}
	}
}
