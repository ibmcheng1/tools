/*
 * @(#)Options.java
 *
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.struts.forms;

import com.bcbssc.struts.common.Constants;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import org.apache.log4j.Logger;
import org.apache.struts.util.LabelValueBean;

/**
 * Common Struts Options
 *
 * This class provides common options used by struts forms.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public class Options {

	/** log4j logger */
	private static Logger log = Logger.getLogger(Options.class);

	private static Options uniqueInstance = new Options();

	// Option String array indices
	/** Constant <code>LABEL_INDEX=0</code> */
	public static final int LABEL_INDEX = 0;

	/** Constant <code>VALUE_INDEX=1</code> */
	public static final int VALUE_INDEX = 1;

	/** US Country Code */
	public static final String US_COUNTRY_CODE = "US";

	/** Canada Country Code */
	public static final String CA_COUNTRY_CODE = "CA";

	/** Gender option labels and values */
	private static final String[] MALE_OPTION = { "Male", "M" };

	private static final String[] FEMALE_OPTION = { "Female", "F" };

	/** Smoker option labels and values */
	private static final String[] NONSMOKER_OPTION = { "No", "N" };

	private static final String[] SMOKER_OPTION = { "Yes", "S" };

	/** yes/no option labels and values */
	private static final String[] YES_OPTION = { "Yes", "Y" };

	private static final String[] NO_OPTION = { "No", "N" };

	/** class action options labels and values */
	private static final String[] CLASS_ACTION_ACCEPTED = { "Accepted", "S" };

	private static final String[] CLASS_ACTION_DECLINED = { "Declined", "R" };

	/** Grouped state options */
	private static Vector<GroupedOption> groupedStateOptions;

	/* static initializer */
	static {
		Options.groupedStateOptions = new Vector<GroupedOption>();
		Options.setGroupedStateOptions(Options.groupedStateOptions);
	}

	/**
	 * <p>getInstance.</p>
	 *
	 * @return a {@link com.bcbssc.struts.forms.Options} object.
	 */
	public static Options getInstance() {
		if (Options.log.isDebugEnabled()) {
			Options.log.debug("Returning an Options object.");
		}
		return Options.uniqueInstance;
	}

	/**
	 * Sets the state/region groupedStateOptions object
	 * 
	 * @param options
	 *            object to contain the state/region GroupedOption objects
	 */
	private static void setGroupedStateOptions(Vector<GroupedOption> options) {

		// US States
		String country = Options.US_COUNTRY_CODE;
		options.add(new GroupedOption(country, "", "--Please Choose One--"));
		options.add(new GroupedOption(country, "AL", "Alabama"));
		options.add(new GroupedOption(country, "AK", "Alaska"));
		options.add(new GroupedOption(country, "AS", "American Samoa"));
		options.add(new GroupedOption(country, "AZ", "Arizona"));
		options.add(new GroupedOption(country, "AR", "Arkansas"));
		options.add(new GroupedOption(country, "CA", "California"));
		options.add(new GroupedOption(country, "CO", "Colorado"));
		options.add(new GroupedOption(country, "CT", "Connecticut"));
		options.add(new GroupedOption(country, "DE", "Delaware"));
		options.add(new GroupedOption(country, "DC", "District of Columbia"));
		options.add(new GroupedOption(country, "FM",
				"Federated States of Micronesia"));
		options.add(new GroupedOption(country, "FL", "Florida"));
		options.add(new GroupedOption(country, "GA", "Georgia"));
		options.add(new GroupedOption(country, "GU", "Guam"));
		options.add(new GroupedOption(country, "HI", "Hawaii"));
		options.add(new GroupedOption(country, "ID", "Idaho"));
		options.add(new GroupedOption(country, "IL", "Illinois"));
		options.add(new GroupedOption(country, "IN", "Indiana"));
		options.add(new GroupedOption(country, "IA", "Iowa"));
		options.add(new GroupedOption(country, "KS", "Kansas"));
		options.add(new GroupedOption(country, "KY", "Kentucky"));
		options.add(new GroupedOption(country, "LA", "Louisiana"));
		options.add(new GroupedOption(country, "ME", "Maine"));
		options.add(new GroupedOption(country, "MH", "Marshall Islands"));
		options.add(new GroupedOption(country, "MD", "Maryland"));
		options.add(new GroupedOption(country, "MA", "Massachusetts"));
		options.add(new GroupedOption(country, "MI", "Michigan"));
		options.add(new GroupedOption(country, "MN", "Minnesota"));
		options.add(new GroupedOption(country, "MS", "Mississippi"));
		options.add(new GroupedOption(country, "MO", "Missouri"));
		options.add(new GroupedOption(country, "MT", "Montana"));
		options.add(new GroupedOption(country, "NE", "Nebraska"));
		options.add(new GroupedOption(country, "NV", "Nevada"));
		options.add(new GroupedOption(country, "NH", "New Hampshire"));
		options.add(new GroupedOption(country, "NJ", "New Jersey"));
		options.add(new GroupedOption(country, "NM", "New Mexico"));
		options.add(new GroupedOption(country, "NY", "New York"));
		options.add(new GroupedOption(country, "NC", "North Carolina"));
		options.add(new GroupedOption(country, "ND", "North Dakota"));
		options
				.add(new GroupedOption(country, "MP",
						"Northern Mariana Islands"));
		options.add(new GroupedOption(country, "OH", "Ohio"));
		options.add(new GroupedOption(country, "OK", "Oklahoma"));
		options.add(new GroupedOption(country, "OR", "Oregon"));
		options.add(new GroupedOption(country, "PA", "Pennsylvania"));
		options.add(new GroupedOption(country, "PR", "Puerto Rico"));
		options.add(new GroupedOption(country, "RI", "Rhode Island"));
		options.add(new GroupedOption(country, "SC", "South Carolina"));
		options.add(new GroupedOption(country, "SD", "South Dakota"));
		options.add(new GroupedOption(country, "TN", "Tennessee"));
		options.add(new GroupedOption(country, "TX", "Texas"));
		options.add(new GroupedOption(country, "VI", "U.S. Virgin Islands"));
		options.add(new GroupedOption(country, "UT", "Utah"));
		options.add(new GroupedOption(country, "VT", "Vermont "));
		options.add(new GroupedOption(country, "VA", "Virginia"));
		options.add(new GroupedOption(country, "WA", "Washington"));
		options.add(new GroupedOption(country, "WV", "West Virginia"));
		options.add(new GroupedOption(country, "WI", "Wisconsin"));
		options.add(new GroupedOption(country, "WY", "Wyoming"));

		// Canadian provinces
		country = Options.CA_COUNTRY_CODE;
		options.add(new GroupedOption(country, "AB", "Alberta"));
		options.add(new GroupedOption(country, "BC", "British Columbia"));
		options.add(new GroupedOption(country, "MB", "Manitoba"));
		options.add(new GroupedOption(country, "NB", "New Brunswick"));
		options.add(new GroupedOption(country, "NL",
				"Newfoundland and Labrador"));
		options.add(new GroupedOption(country, "NT", "Northwest Territories"));
		options.add(new GroupedOption(country, "NS", "Nova Scotia"));
		options.add(new GroupedOption(country, "NU", "Nunavut"));
		options.add(new GroupedOption(country, "ON", "Ontario"));
		options.add(new GroupedOption(country, "PE", "Prince Edward Island"));
		options.add(new GroupedOption(country, "QC", "Quebec"));
		options.add(new GroupedOption(country, "SK", "Saskatchewan"));
		options.add(new GroupedOption(country, "YT", "Yukon"));
	}

	/**
	 * Creates a vector of grouped state/region options for USA and Canada
	 *
	 * @return Vector of GroupedOption objects each containing a state/region
	 *         for either USA or Canada.
	 */
	public Vector<GroupedOption> getGroupedStateOptions() {
		if (Options.log.isDebugEnabled()) {
			Options.log.debug("in get grouped state options!!!");
		}
		return Options.groupedStateOptions;
	}

	/**
	 * Creates a Collection of all state/region options for USA and Canada
	 *
	 * @return Collection of all state/region option objects for both USA and
	 *         Canada
	 */
	public Collection<LabelValueBean> getAllStateOptions() {
		Collection<LabelValueBean> options = new ArrayList<LabelValueBean>();
		Vector<GroupedOption> vectorOptions = this.getGroupedStateOptions();
		for (int i = 0; i < vectorOptions.size(); i++) {
			GroupedOption indexedOption = (GroupedOption) vectorOptions.get(i);
			options.add(new LabelValueBean(indexedOption.getOptionLabel(),
					indexedOption.getOptionValue()));
		}
		return options;
	}

	/**
	 * Creates a Collection of all state/region options for USA only
	 *
	 * @return Collection of all state/region option objects for USA
	 */
	public Collection<LabelValueBean> getUnitedStatesOptions() {
		Collection<LabelValueBean> options = new ArrayList<LabelValueBean>();
		Vector<GroupedOption> vectorOptions = this.getGroupedStateOptions();
		for (int i = 0; i < vectorOptions.size(); i++) {
			GroupedOption indexedOption = (GroupedOption) vectorOptions.get(i);
			if (indexedOption.getOptionGroup().equals(Options.US_COUNTRY_CODE)) {
				options.add(new LabelValueBean(indexedOption.getOptionLabel(),
						indexedOption.getOptionValue()));
			}
		}
		return options;
	}

	/**
	 * Creates the gender options
	 *
	 * @return List of gender options
	 */
	public List<LabelValueBean> getGenderOptions() {
		ArrayList<LabelValueBean> genderOptions = new ArrayList<LabelValueBean>();
		genderOptions.add(new LabelValueBean("--Please Choose One--",
				Constants.BLANK_STRING));
		genderOptions.add(new LabelValueBean(
				Options.MALE_OPTION[Options.LABEL_INDEX],
				Options.MALE_OPTION[Options.VALUE_INDEX]));
		genderOptions.add(new LabelValueBean(
				Options.FEMALE_OPTION[Options.LABEL_INDEX],
				Options.FEMALE_OPTION[Options.VALUE_INDEX]));
		return genderOptions;
	}

	/**
	 * Creates the smoker options
	 *
	 * @return List of smoker options
	 */
	public List<LabelValueBean> getSmokerOptions() {
		ArrayList<LabelValueBean> smokerOptions = new ArrayList<LabelValueBean>();
		smokerOptions.add(new LabelValueBean(
				Options.NONSMOKER_OPTION[Options.LABEL_INDEX],
				Options.NONSMOKER_OPTION[Options.VALUE_INDEX]));
		smokerOptions.add(new LabelValueBean(
				Options.SMOKER_OPTION[Options.LABEL_INDEX],
				Options.SMOKER_OPTION[Options.VALUE_INDEX]));
		return smokerOptions;
	}

	/**
	 * Creates a simple no/yes options list
	 *
	 * @return yes/no options list
	 */
	public List<LabelValueBean> getNoYesOptions() {
		ArrayList<LabelValueBean> yesNoOptions = new ArrayList<LabelValueBean>();
		yesNoOptions.add(new LabelValueBean(
				Options.NO_OPTION[Options.LABEL_INDEX],
				Options.NO_OPTION[Options.VALUE_INDEX]));
		yesNoOptions.add(new LabelValueBean(
				Options.YES_OPTION[Options.LABEL_INDEX],
				Options.YES_OPTION[Options.VALUE_INDEX]));
		return yesNoOptions;
	}

	/**
	 * Creates a simple blank/no/yes options list
	 *
	 * @return yes/no options list
	 */
	public List<LabelValueBean> getBlankNoYesOptions() {
		ArrayList<LabelValueBean> yesNoOptions = new ArrayList<LabelValueBean>();
		yesNoOptions.add(new LabelValueBean(Constants.BLANK_STRING,
				Constants.BLANK_STRING));
		yesNoOptions.add(new LabelValueBean(
				Options.NO_OPTION[Options.LABEL_INDEX],
				Options.NO_OPTION[Options.VALUE_INDEX]));
		yesNoOptions.add(new LabelValueBean(
				Options.YES_OPTION[Options.LABEL_INDEX],
				Options.YES_OPTION[Options.VALUE_INDEX]));
		return yesNoOptions;
	}

	/**
	 * Creates class action options
	 *
	 * @return List of class action options
	 */
	public List<LabelValueBean> getClassActionOptions() {
		ArrayList<LabelValueBean> classActionOptions = new ArrayList<LabelValueBean>();
		classActionOptions.add(new LabelValueBean(
				Options.CLASS_ACTION_ACCEPTED[Options.LABEL_INDEX],
				Options.CLASS_ACTION_ACCEPTED[Options.VALUE_INDEX]));
		classActionOptions.add(new LabelValueBean(
				Options.CLASS_ACTION_DECLINED[Options.LABEL_INDEX],
				Options.CLASS_ACTION_DECLINED[Options.VALUE_INDEX]));
		return classActionOptions;
	}

	/**
	 * Returns the label associated with a specified value for a specified
	 * options list.
	 *
	 * @param optionsList
	 *            the list on which to perform this lookup
	 * @param value
	 *            the value to lookup
	 * @return the label associated with value, or value if the label could not
	 *         be found
	 */
	public static String getLabelFromValue(List<LabelValueBean> optionsList, String value) {
		String label = null;
		Iterator<LabelValueBean> iter = optionsList.iterator();
		while ((label == null) && iter.hasNext()) {
			LabelValueBean currentOption = (LabelValueBean) iter.next();
			if (currentOption.getValue().equalsIgnoreCase(value)) {
				label = currentOption.getLabel();
			}
		}
		return label = (("".equals(value) || (label == null)) ? value : label);
	}
}
