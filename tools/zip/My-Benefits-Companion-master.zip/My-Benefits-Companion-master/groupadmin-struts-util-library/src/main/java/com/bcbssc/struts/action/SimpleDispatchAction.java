/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * Copyright (C) 2004 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-strutsutil/src/main/java/com/bcbssc/struts/action/SimpleDispatchAction.java_v  $
 * $Workfile:   SimpleDispatchAction.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:56:06  $
 * $Modtime:   Mar 28 2005 16:01:10  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-strutsutil/src/main/java/com/bcbssc/struts/action/SimpleDispatchAction.java_v  $
 * 
 *    Rev 1.0   Jun 26 2009 15:56:06   EN80
 * Initial revision.
 * 
 *    Rev 1.3   Mar 28 2005 15:04:06   rxr93
 * improve debugging
 * 
 *    Rev 1.2   Mar 24 2005 12:09:00   rdq70
 * Added condition to debug logs.
 *
 *    Rev 1.1   Mar 07 2005 11:11:42   rxr93
 * issm changes
 *
 */

package com.bcbssc.struts.action;

import org.apache.struts.actions.DispatchAction;
import org.apache.struts.Globals;
import org.apache.struts.config.ModuleConfig;
import org.apache.struts.util.RequestUtils;
import org.apache.struts.action.*;
import org.apache.log4j.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Shared Registration Simple Dispatch Action
 *
 * This class simplifies the struts DispatchAction by expecting the method
 * name to be directly specified as the parameter rather than using the
 * parameter as the request lookup name for the method.
 *
 * @author Jonathan Egger
 * @version $Revision:   1.0  $
 */
public abstract class SimpleDispatchAction extends DispatchAction {

    /** log4j logger */
    private static final Logger log = Logger.getLogger(SimpleDispatchAction.class);

    /**
     * {@inheritDoc}
     *
     * Processes the specified HTTP request, and creates the corresponding HTTP
     * response.
     */
    public ActionForward execute(ActionMapping mapping, ActionForm form,
                                 HttpServletRequest request, HttpServletResponse response)
        throws Exception
    {
        String parameter = mapping.getParameter();
        if(parameter == null)
        {
            String message = messages.getMessage("dispatch.handler", mapping.getPath());
            log.error(message);
            response.sendError(500, message);
            return null;
        }
        else
        {
        	log.debug("dispatch to " + parameter);
            return dispatchMethod(mapping, form, request, response, parameter);
        }
    }

    /**
     * Create or reload the form associated with the 'path' requested.
     *
     * @param formName  key used in storing form in session
     * @param path      from struts-config.xml (ie /createProfile)
     * @param request   servlet request object
     * @return form     ActionForm object (actually a class that extends ActionForm)
     */
    protected ActionForm getForm(String formName, String path, HttpServletRequest request) {

        ActionForm form = (ActionForm) request.getAttribute(formName);

        if (form == null) {
            form = (ActionForm) request.getSession().getAttribute(formName);
        }

        if (form == null) {
            ModuleConfig modConfig = (ModuleConfig) request.getAttribute(Globals.MODULE_KEY);

            ActionMapping mapping = (ActionMapping) modConfig.findActionConfig(path);
            if (log.isDebugEnabled()) {
                log.debug("getForm() mapping: " + mapping);
            }

            form = RequestUtils.createActionForm(request, mapping, modConfig,
                                                 (ActionServlet) getServlet());

            String key = mapping.getAttribute();

            if ("request".equals(mapping.getScope())) {
                request.setAttribute(key, form);
            } else {
                request.getSession().setAttribute(key, form);
            }
        }

        if (log.isDebugEnabled()) {
            log.debug("getForm() form loaded: " + form.getClass().getName());
        }

        return form;
    }

    /**
     * Adds a global message to the request
     *
     * @param request  the HTTP request to add the message
     * @param property  the name of the message in the properties file
     */
    protected void addGlobalRequestMessage(HttpServletRequest request, String property) {
        ActionMessages messages   = new ActionMessages();
        ActionMessage  newMessage = new ActionMessage(property);
        messages.add(ActionMessages.GLOBAL_MESSAGE, newMessage);
        saveMessages(request, messages);
    }
}
