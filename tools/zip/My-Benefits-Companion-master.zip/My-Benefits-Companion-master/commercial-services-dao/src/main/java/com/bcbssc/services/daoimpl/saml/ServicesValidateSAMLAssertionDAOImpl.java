package com.bcbssc.services.daoimpl.saml;

import java.util.HashMap;
import javax.xml.rpc.ServiceException;
import com.bcbssc.services.model.saml.SamlAssertion;
import com.bcbssc.services.model.common.DAOException;
import com.bcbssc.services.model.common.SamlAssertionException;
import com.bcbssc.services.dao.saml.ValidateSAMLAssertionDAO;
import com.bcbssc.services.utils.BaseServicesDAO;
import com.bcbssc.wsutils.WebServiceConsumerCallback;
import com.bcbssc.wsutils.WebServiceConsumerTemplate;
import com.bcbssc.wsutils.exception.BcbsscDetailedSoapFaultException;
import com.bcbssc.services.validatesamlassertion.SamlServiceLocator;
import com.bcbssc.services.validatesamlassertion.SamlService;
import com.bcbssc.services.validatesamlassertion.SamlServicePortType;
import com.bcbssc.services.validatesamlassertion.svc.IndividualAttribute;
import com.bcbssc.services.validatesamlassertion.svc.ValidateSAMLAssertionResponse;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <p>ServicesValidateSAMLAssertionDAOImpl class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class ServicesValidateSAMLAssertionDAOImpl extends BaseServicesDAO
		implements ValidateSAMLAssertionDAO, WebServiceConsumerCallback {

	private static final Log log = LogFactory
			.getLog(ServicesValidateSAMLAssertionDAOImpl.class);
	private static final String SERVICE_NAME = "ValidateSAMLAssertion";
	private static final boolean isThisSOAExpressService = false;

	/** {@inheritDoc} */
	public SamlAssertion validateSamlAssertion(String samlAssertionStr)
			throws SamlAssertionException, DAOException {
		SamlAssertion samlAssertion = null;
		ValidateSAMLAssertionResponse response = null;

		try {
			WebServiceConsumerTemplate template = new WebServiceConsumerTemplate();

			response = (ValidateSAMLAssertionResponse) template.consumeService(
					samlAssertionStr, this);

			samlAssertion = populateSamlAssertion(response);
		} catch (BcbsscDetailedSoapFaultException faultExp) {
			String errorMessage = faultExp.getFaultDetails()
					.getApplicationMessage();
			log.error(faultExp.getFaultString(), faultExp);
			if (StringUtils.isNotBlank(errorMessage)) {
				throw new SamlAssertionException(errorMessage);
			} else {
				throw new SamlAssertionException(faultExp.getMessage());
			}
		} catch (Exception exp) {
			log.error(exp.getMessage(), exp);
			throw new DAOException(exp.getMessage());
		}

		return samlAssertion;
	}

	/** {@inheritDoc} */
	public Object invokeService(Object serviceInput, Object serviceClient)
			throws Exception {
		final SamlServicePortType service = (SamlServicePortType) serviceClient;
		String samlAssertionString = (String) serviceInput;
		return service.validateSAMLAssertion(samlAssertionString);
	}

	/** {@inheritDoc} */
	public Object mapInput(Object modelInput) {
		String samlAssertionString = (String) modelInput;
		return samlAssertionString;
	}

	/** {@inheritDoc} */
	public Object mapOutput(Object serviceOutput) {
		ValidateSAMLAssertionResponse validateSAMLAssertionResponse = (ValidateSAMLAssertionResponse) serviceOutput;
		return validateSAMLAssertionResponse;
	}

	/**
	 * <p>getService.</p>
	 *
	 * @return a {@link java.lang.Object} object.
	 */
	public Object getService() {
		SamlServiceLocator serviceLocator = null;
		SamlServicePortType servicePort = null;

		try {
			serviceLocator = (SamlServiceLocator) getServiceWithHandlersLoaded(
					SamlService.class, SERVICE_NAME, isThisSOAExpressService);

			servicePort = serviceLocator.getSamlServicePort();
		} catch (ServiceException sex) {
			log.error("serviceToInvoke was not configured with Handlers", sex);

		}

		return servicePort;
	}

	private SamlAssertion populateSamlAssertion(
			ValidateSAMLAssertionResponse validateSAMLAssertionResponse) {
		SamlAssertion samlAssertion = new SamlAssertion();

		IndividualAttribute[] attributes = validateSAMLAssertionResponse
				.getAttributes();
		HashMap<String, String> attrMap = new HashMap<String, String>();
		if (attributes != null) {
			for (IndividualAttribute attr : attributes) {
				attrMap.put(attr.getName(), attr.getValue());
			}
		}
		samlAssertion.setAttributes(attrMap);
		samlAssertion.setNameQualifier(validateSAMLAssertionResponse
				.getNameQualifier());
		samlAssertion.setSignedByEntity(validateSAMLAssertionResponse
				.getSigningCertCN());
		return samlAssertion;
	}

}
