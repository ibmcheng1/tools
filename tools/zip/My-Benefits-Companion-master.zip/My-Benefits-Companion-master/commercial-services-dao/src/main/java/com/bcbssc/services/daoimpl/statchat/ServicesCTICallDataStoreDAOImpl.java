/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * CTICallDataStoreServiceCallBack.java
 */
package com.bcbssc.services.daoimpl.statchat;

import javax.xml.rpc.ServiceException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.services.cticalldatastore.CTICallDataStoreInput;
import com.bcbssc.services.cticalldatastore.CTICallDataStoreOutput;
import com.bcbssc.services.cticalldatastore.CTICallDataStoreService;
import com.bcbssc.services.cticalldatastore.CTICallDataStoreServiceService;
import com.bcbssc.services.dao.statchat.CTICallDataStoreDAO;
import com.bcbssc.services.model.common.DAOException;
import com.bcbssc.services.model.statchat.CallDataDTO;
import com.bcbssc.services.utils.BaseServicesDAO;
import com.bcbssc.wsutils.WebServiceConsumerCallback;
import com.bcbssc.wsutils.WebServiceConsumerTemplate;
import com.bcbssc.wsutils.exception.BcbsscDetailedSoapFaultException;

/**
 * <p>ServicesCTICallDataStoreDAOImpl class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class ServicesCTICallDataStoreDAOImpl extends BaseServicesDAO
implements CTICallDataStoreDAO, WebServiceConsumerCallback {		

	private static final Log log 							= LogFactory.getLog(ServicesCTICallDataStoreDAOImpl.class);
	
	//private static final String KEYTYPE_CALLERID			= "CALLID";
	
	private static final String SERVICE_NAME = "CTICallDataStore";
	private static final boolean isThisSOAExpressService = true;
	
	
	/** {@inheritDoc} */
	public void saveCallDataInformation(CallDataDTO callDataDTO) throws DAOException {
	
		try {

			WebServiceConsumerTemplate template 	= new WebServiceConsumerTemplate();
			template.consumeService(callDataDTO, this);
        }
		catch (BcbsscDetailedSoapFaultException soapFaultException) {
			log.error("Error executing CTICallDataStoreService " + soapFaultException.getFaultString(), soapFaultException);
			throw new DAOException("Error executing CTICallDataStoreService " + soapFaultException.getFaultString());
		}		
		catch(Exception exception) {
        	log.error("CallDataDAOBean.performServiceCall() failed <> ", exception);
        	throw new DAOException("WebServiceConsumerTemplate.consumeService failed <> " + exception.getMessage());            
        }
	    
		if(log.isDebugEnabled()) {
			log.debug("CTICallDataStoreService response bean: " + callDataDTO);
		}
		
		
		
	}
	
    /**
     * <p>getService.</p>
     *
     * @return a {@link java.lang.Object} object.
     */
    public Object getService() {
    	CTICallDataStoreService serviceToReturn = null;

		try {
			CTICallDataStoreServiceService serviceToLoadHandlers = (CTICallDataStoreServiceService)getServiceWithHandlersLoaded(CTICallDataStoreServiceService.class, SERVICE_NAME , isThisSOAExpressService);
			serviceToReturn = serviceToLoadHandlers.getCTICallDataStore();
		}catch(ServiceException sex) {
			log.error("serviceToInvoke was not configured with Handlers" , sex);
			
		}
		return serviceToReturn;
    }

    /** {@inheritDoc} */
    public Object mapInput(Object requestPassed) {
    	
CallDataDTO callDataDTO								= (CallDataDTO) requestPassed;
    	
    	CTICallDataStoreInput input							= new CTICallDataStoreInput();
    	
    	input.setAmmsGroupNumber(callDataDTO.getAmmsGroupNumber());
    	input.setClientType(callDataDTO.getClientType());
    	input.setDateOfService(callDataDTO.getDateOfService());
    	input.setInputChannel(callDataDTO.getInputChannel());
    	input.setKeyId(callDataDTO.getKeyId());
    	input.setKeyType(callDataDTO.getKeyType());
    	input.setPatientDateOfBirth(callDataDTO.getPatientDateOfBirth());
    	input.setPatientFullName(callDataDTO.getPatientFullName());
    	input.setPatientId(callDataDTO.getPatientId());
    	input.setPlanCode(callDataDTO.getPlanCode());
    	input.setProviderId(callDataDTO.getProviderFederalTaxId());
    	input.setProviderNpi(callDataDTO.getProviderNpi());
    	input.setProviderType12Number(callDataDTO.getLocationNumber());
    	input.setRacfId(callDataDTO.getRacfId());
    	input.setRpn(callDataDTO.getRpn());
    	input.setStatChatIndicator(callDataDTO.getStatChatIndicator());
    	input.setSubscriberAddressLine1(callDataDTO.getSubscriberAddressLineOne());
    	input.setSubscriberAddressLine2(callDataDTO.getSubscriberAddressLineTwo());
    	input.setSubscriberAddressLine3(callDataDTO.getSubscriberAddressLineThree());
    	input.setSubscriberAlphaPrefix(callDataDTO.getSubscriberAlphaPrefix());
    	input.setSubscriberCity(callDataDTO.getSubscriberCity());
    	input.setSubscriberDatabaseNumber(callDataDTO.getSubscriberDatabaseNumber());
    	input.setSubscriberFullName(callDataDTO.getSubscriberFullName());
    	input.setSubscriberId(callDataDTO.getSubscriberIdCardNumber());
    	input.setSubscriberState(callDataDTO.getSubscriberState());
    	input.setSubscriberZipCode(callDataDTO.getSubscriberZipCode());
    	input.setSystemId(callDataDTO.getSystemId());
    	input.setTransferTarget(callDataDTO.getTransferTarget());
    	input.setPatientFullName(callDataDTO.getPatientFullName());
    	return input;
    }

    /** {@inheritDoc} */
    public Object invokeService(Object serviceInput, Object serviceClient) throws Exception {

    	CTICallDataStoreService service 					= (CTICallDataStoreService) (serviceClient);
    	CTICallDataStoreOutput result						= service.storeCtiCallData((CTICallDataStoreInput) serviceInput);
    	
    	return result;    	
   
    	
    }

    /** {@inheritDoc} */
    public Object mapOutput(Object serviceOutput) {

    	return serviceOutput;
    }    
}
