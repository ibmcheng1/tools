/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * DocumentRerieveDAOBean.java
 * Date: May 26, 2010
 */
package com.bcbssc.services.daoimpl.documentarchive;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.rpc.ServiceException;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.bcbssc.commapi.model.common.DAOException;
import com.bcbssc.commapi.model.common.DocumentNotFoundException;
import com.bcbssc.commapi.model.documentarchive.Document;
import com.bcbssc.commapi.model.documentarchive.dto.DocumentDTO;
import com.bcbssc.commapi.model.documentarchive.dto.DocumentSearchCriteria;
import com.bcbssc.commapi.model.documentarchive.dto.DocumentSearchKey;
import com.bcbssc.commapi.model.documentarchive.dto.ImageFolder;
import com.bcbssc.services.dao.documentarchive.DocumentRetrieveDAO;
import com.bcbssc.services.imagegatewayretriever.FolderSearchResult;
import com.bcbssc.services.imagegatewayretriever.SearchHit;
import com.bcbssc.services.imagegatewayretriever.ig.IimggwRetriever;
import com.bcbssc.services.imagegatewayretriever.ig.ImggwRetrieverService;
import com.bcbssc.services.imagegatewayretriever.od.BasicKeyCriterion;
import com.bcbssc.services.imagegatewayretriever.od.BasicSearchCriteria;
import com.bcbssc.services.utils.BaseServicesDAO;
import com.bcbssc.wsutils.WebServiceConsumerCallback;
import com.bcbssc.wsutils.WebServiceConsumerTemplate;
import com.bcbssc.wsutils.exception.BcbsscDetailedSoapFaultException;

/**
 *
 * Author: FF74
 *
 * @author jc33
 * @version $Id: $Id
 */
public class DocumentRetrieveDAOImpl extends BaseServicesDAO implements
WebServiceConsumerCallback, DocumentRetrieveDAO {

	private static final Logger logger = Logger.getLogger(DocumentRetrieveDAOImpl.class);
	private static final String SERVICE_NAME = "ImageGatewayRetriever";
	//private static final String GET_METHOD_NAME = "getImggwRetriever";
	private static final String DATE_FMT  = "MM/dd/yyyy";
	private static DateFormat dateformat = new SimpleDateFormat(DocumentRetrieveDAOImpl.DATE_FMT);
	private static final String AFP2PDF_MIME_TYPE = "AFP2PDF";
    private static final String PDF_MIME_TYPE = "application/pdf";
	private static final String ENCODING_SCHEME = "UTF-8";
	private static final String RESPONSE_MESSAGE = "Response Message: ";
	private static final String RESPONSE_CODE = "Response Code: ";
	private static final String AUTHENTICATION = "Authorization";
	private static final String CONTENT_TYPE = "Content-Type";
	private static final String X_WWW_FORM_URLENCODED = "application/x-www-form-urlencoded";

	/**
	 * {@inheritDoc}
	 *
	 * Get the requested document based on the folder name and document id.
	 */
	public Document getDocumentDetail(ImageFolder folderName, String docId)
			throws DAOException, DocumentNotFoundException {

		// Create return document object
		Document document=null;

		try {
			
			// Encode the parameter values
			String encodedHostUser = URLEncoder.encode((String)FACTORY_UTILS.getBean("web.services.host.id", String.class), DocumentRetrieveDAOImpl.ENCODING_SCHEME);
			String encodedHostPassword = URLEncoder.encode((String)FACTORY_UTILS.getBean("web.services.host.password", String.class), DocumentRetrieveDAOImpl.ENCODING_SCHEME);
			String encodedAfpTransferTo = URLEncoder.encode(DocumentRetrieveDAOImpl.AFP2PDF_MIME_TYPE, DocumentRetrieveDAOImpl.ENCODING_SCHEME);
			String encodedFolderName = URLEncoder.encode(folderName.getFolderName(), DocumentRetrieveDAOImpl.ENCODING_SCHEME);
			String encodedDocId = URLEncoder.encode(docId, DocumentRetrieveDAOImpl.ENCODING_SCHEME);

			// Create HttpURL Connection object
			HttpURLConnection connection = (HttpURLConnection) (new URL((String)FACTORY_UTILS.getBean("DocumentArchive.baseImageGatewayServletUrl", String.class))).openConnection();
			connection.setRequestProperty(DocumentRetrieveDAOImpl.CONTENT_TYPE, DocumentRetrieveDAOImpl.X_WWW_FORM_URLENCODED);
			connection.setRequestProperty(DocumentRetrieveDAOImpl.AUTHENTICATION, URLEncoder.encode((String)FACTORY_UTILS.getBean("web.services.consumer.id", String.class), DocumentRetrieveDAOImpl.ENCODING_SCHEME));
			connection.setDoOutput(true);

			// Create the OutputStreamWriter connection object
			OutputStreamWriter osw = new OutputStreamWriter(connection.getOutputStream());
			osw.write("user=" + encodedHostUser);
			osw.write("&password=" + encodedHostPassword);
			osw.write("&folderName=" + encodedFolderName);
			osw.write("&docId=" + encodedDocId);
			osw.write("&afpTransferTo=" + encodedAfpTransferTo);
			osw.close();

			// Get the response
			int resCode = connection.getResponseCode();
			String resMessage = connection.getResponseMessage();
			DocumentRetrieveDAOImpl.logger.debug(DocumentRetrieveDAOImpl.RESPONSE_CODE + resCode);
			DocumentRetrieveDAOImpl.logger.debug(DocumentRetrieveDAOImpl.RESPONSE_MESSAGE + resMessage);

			// Check if the response code is OK
			if (resCode != HttpURLConnection.HTTP_OK) {
				DocumentRetrieveDAOImpl.logger.error(DocumentRetrieveDAOImpl.RESPONSE_CODE + resCode);
				DocumentRetrieveDAOImpl.logger.error(DocumentRetrieveDAOImpl.RESPONSE_MESSAGE + resMessage);
				throw new DAOException("Error Connecting to Server.\n"+
						DocumentRetrieveDAOImpl.RESPONSE_CODE+resCode+"\n"+
						DocumentRetrieveDAOImpl.RESPONSE_MESSAGE+resMessage);
			}// End of if(resCode)

			// Create the document object
			document = new Document(DocumentRetrieveDAOImpl.PDF_MIME_TYPE, IOUtils.toByteArray(connection.getInputStream()));

		} catch (UnsupportedEncodingException e) {
			throw new DAOException(e);
		} catch (MalformedURLException e) {
			throw new DAOException(e);
		} catch (IOException e) {
			throw new DAOException(e);
		}// End of try-catch-catch-catch block


		// Return document object
		return document;
	}// End of method getDocumentDetail

	/**
	 * {@inheritDoc}
	 *
	 * Get a document list based on the document search criteria.
	 */
	public List<DocumentDTO> getDocumentList(DocumentSearchCriteria searchCriteria) throws DAOException {

		// Create return list object
		List<DocumentDTO> documentList = null;
		DocumentRetrieveDAOImpl.logger.debug("getDocumentList--"+searchCriteria.toString());
		try {
			// Create the WebServiceConsumerTemplate object
            WebServiceConsumerTemplate template  = new WebServiceConsumerTemplate();

            // Obtain the document list
            documentList = (List<DocumentDTO>) template.consumeService(searchCriteria, this);

        } catch (BcbsscDetailedSoapFaultException ex) {
        	String errorMessageCode = ex.getFaultDetails().getServiceMessageCode();
        	String errorMessage = ex.getFaultDetails().getApplicationMessage();
        	DocumentRetrieveDAOImpl.logger.error("Exception has occured when running web service call.\nerrorMessageCode:"+errorMessageCode+"\nerrorMessage:"+errorMessage);
        	throw new DAOException("Exception has occured when running web service call.\nerrorMessageCode:"+errorMessageCode+"\nerrorMessage:"+errorMessage);
		} catch (Exception e){
			DocumentRetrieveDAOImpl.logger.error("Exception has occured when running web service call.\n"+e.getMessage());
			throw new DAOException("An Input Error has occured. "+e.getMessage());
		}// End of try-catch-catch block

		// Return the list object
		return documentList;
	}// End of method getDocumentList

	/**
	 * <p>getService.</p>
	 *
	 * @return a {@link java.lang.Object} object.
	 */
	public Object getService() {

		// Create return IimggwRetriever object
		IimggwRetriever serviceToReturn = null;

		try {

			// Obtain the ImggwRetrieverService object
			ImggwRetrieverService serviceToLoadHandlers = (ImggwRetrieverService)this.getServiceWithHandlersLoaded(ImggwRetrieverService.class, DocumentRetrieveDAOImpl.SERVICE_NAME);

			// Obtain the IimggwRetriever object
			serviceToReturn = serviceToLoadHandlers.getImggwRetriever();

		} catch (ServiceException se) {
			DocumentRetrieveDAOImpl.logger.error("serviceToInvoke was not configured with Handlers" , se);
		}// End of try-catch block

		// Return the IimggwRetriever object
		return serviceToReturn;
	}// End of method getService

	/** {@inheritDoc} */
	public Object invokeService(Object serviceInput, Object serviceClient) throws Exception {

		// Cast the serviceInput object to a BasicSearchCriteria object
		BasicSearchCriteria bsc = (BasicSearchCriteria)serviceInput;

		// Cast the serviceClient object to a IimggwRetriever object
		IimggwRetriever ir = (IimggwRetriever)serviceClient;

		// Call the method getDocListOnDemand from the ImggwRetriever service
		FolderSearchResult fsr =  ir.getDocListOnDemand((String)FACTORY_UTILS.getBean("web.services.host.id", String.class), (String)FACTORY_UTILS.getBean("web.services.host.password", String.class), bsc);

		// Return the FolderSearchResult object
		return fsr;
	}// End of method invokeService

	/** {@inheritDoc} */
	public Object mapInput(Object requestPassed) {

		// Cast the requestPassed object to a DocumentSearchCriteria object
		DocumentSearchCriteria dsc = (DocumentSearchCriteria)requestPassed;

		// Create a basic key criterion list object
		List<BasicKeyCriterion> bkcList = new ArrayList<BasicKeyCriterion>();

		// Loop through the search conditions
		for (DocumentSearchKey dsk :  dsc.getSearchConditions()) {

			// Create a basic key criterion object
			BasicKeyCriterion bsk = new BasicKeyCriterion();

			// Set the name value, the operator value, and the search value
			bsk.setName(dsk.getKeyName());
			bsk.setOperator(dsk.getOperator().getKey());
			bsk.setSearchValue(dsk.getKeyValue());

			// Add the basic key criterion to the list
			bkcList.add(bsk);
		}// End of for(DocumentSearchKey)

		// Create the returning Basic Search Criteria object
		BasicSearchCriteria basicSearchCriteria = new BasicSearchCriteria();

		// Set the folder name, the search begin date, the search end date
		// the boolean OR search criteria and the criteria list
		basicSearchCriteria.setFolderName(dsc.getImageFolder().getFolderName());
		basicSearchCriteria.setSearchDateBegin(DocumentRetrieveDAOImpl.dateformat.format(dsc.getSearchBeginDate()));
		basicSearchCriteria.setSearchDateEnd(DocumentRetrieveDAOImpl.dateformat.format(dsc.getSearchEndDate()));
		basicSearchCriteria.setOrSearchCriteria(dsc.isOrSearchCriteria());
		basicSearchCriteria.setCriteriaList((BasicKeyCriterion[])bkcList.toArray(new BasicKeyCriterion[0]));

		// Return the BasicSearchCriteria object
		return basicSearchCriteria;
	}// End of method mapInput

	/** {@inheritDoc} */
	public Object mapOutput(Object serviceOuput) {

		// Cast the service output object to a FolderSearchResult object
		FolderSearchResult searchOutput = (FolderSearchResult) serviceOuput;

		// Create the returning document list object
		List<DocumentDTO> documentListOutPut = new ArrayList<DocumentDTO>();

		// Get the returning display column names
		String[] columns = searchOutput.getDisplayColumns();

		// Loop through the returning documents
		for (SearchHit hit : searchOutput.getDocumentRecords()) {

			// Create a new document object
			DocumentDTO documentDTO  = new DocumentDTO();

			// Create a HashMap object to hold the returning
			// row of values with it's corresponding column name
			HashMap<String,String> displayValues = new HashMap<String,String>();

			// Get the returning row of values
			String[] values = hit.getDisplayValues();

			// Loop through the returning rows of values
			for (int indx=0; indx<values.length; indx++){

				// Put the returning value with it's corresponding column name
				displayValues.put(columns[indx], values[indx]);
			}// End of for(indx)

			// Set the document attributes, the document type,
            // the mime type, the document id
			documentDTO.setDocumentAttributes(displayValues);
			documentDTO.setDocumentType(hit.getDocumentType());
			documentDTO.setMimeType(hit.getMimeType());
			documentDTO.setDocId(hit.getDocId());

			// Add document to return list
			documentListOutPut.add(documentDTO);
		}// End of for(SearchHit)

		// Return the document list object
		return documentListOutPut;
	}// End of method mapOutput
}// End of class DocumentRetrieveDAOImpl
