/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 * ServicesRulesDataTypeMaintenanceDAOImpl.java
 *
 * Created on Nov 19, 2009 by EN80

 */

package com.bcbssc.services.daoimpl.rules;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import javax.xml.rpc.ServiceException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.bcbssc.services.dao.rules.RulesDataTypeMaintenanceDAO;
import com.bcbssc.services.model.rules.RulesDataTypeActionItem;
import com.bcbssc.services.model.rules.RulesDatatypeMaintenance;
import com.bcbssc.services.model.rules.RulesDatatypeMaintenanceResult;
import com.bcbssc.services.rulesdatatypemaintenance.RulesDataTypeMaintenanceInput;
import com.bcbssc.services.rulesdatatypemaintenance.RulesDataTypeMaintenanceOutput;
import com.bcbssc.services.rulesdatatypemaintenance.RulesDataTypeMaintenanceService;
import com.bcbssc.services.rulesdatatypemaintenance.RulesDataTypeMaintenanceServiceService;
import com.bcbssc.services.utils.BaseServicesDAO;
import com.bcbssc.wsutils.WebServiceConsumerCallback;
import com.bcbssc.wsutils.WebServiceConsumerTemplate;

/**
 * <p>ServicesRulesDataTypeMaintenanceDAOImpl class.</p>
 *
 * @author EN80
 * @version $Id: $Id
 */
public class ServicesRulesDataTypeMaintenanceDAOImpl extends BaseServicesDAO implements
		RulesDataTypeMaintenanceDAO, WebServiceConsumerCallback {

	 private static final int MAX_SERVICE_ACTION_ITEMS = 25;

	 private static final Logger log = Logger.getLogger(ServicesRulesDataTypeMaintenanceDAOImpl.class);

	 private static final String SERVICE_INPUT_CLASS_NAME = "com.bcbssc.services.rulesdatatypemaintenance.RulesDataTypeMaintenanceInput";

	 // Service name doesn't change for this service. So keep the value here.
	 private static final String SERVICE_NAME = "RulesDataTypeMaintenance";

	 private static final boolean isThisSOAExpressService =  true;
	 /* (non-Javadoc)
	 * @see com.bcbssc.services.dao.rules.RulesDataTypeMaintenanceDAO#performRulesDataTypeOperation(com.bcbssc.services.model.rules.RulesDatatypeMaintenance)
	 */
	/** {@inheritDoc} */
	public RulesDatatypeMaintenanceResult performRulesDataTypeOperation(
			RulesDatatypeMaintenance input) throws Exception {

		return performRulesDataTypeOperation(input,false);
	}


	/* (non-Javadoc)
	 * @see com.bcbssc.services.dao.rules.RulesDataTypeMaintenanceDAO#performRulesDataTypeOperation(com.bcbssc.services.model.rules.RulesDatatypeMaintenance, boolean)
	 */
	/** {@inheritDoc} */
	public RulesDatatypeMaintenanceResult performRulesDataTypeOperation(
			RulesDatatypeMaintenance input, boolean rollbackOnError)
			throws Exception {

		RulesDatatypeMaintenanceResult output = new RulesDatatypeMaintenanceResult();

        if(null == input){
             throw new IllegalArgumentException("Input required for the service is null.");
        }else{
            validateInput(input);
        }
        List currentActionItems   = new ArrayList();
        List originalActionItems  = input.getRulesDataTypeActionItems();
        boolean performServiceOperationAgain = true;
        int noOfTimesServiceCalled           = 0;
        int lastRunSuccesfulOccuranceItem    = 0;

        do{
            if(log.isDebugEnabled()) {
                log.debug("Remaining items size= " + originalActionItems.size());
            }
            //reset the currentActionItems and prepare for next loop
            currentActionItems   = new ArrayList();

            int countLimit                  = MAX_SERVICE_ACTION_ITEMS * (noOfTimesServiceCalled + 1);

            for(int i=noOfTimesServiceCalled*MAX_SERVICE_ACTION_ITEMS; i < originalActionItems.size(); i ++) {

                if(i < countLimit) {
                    currentActionItems.add(originalActionItems.get(i));
                }
            }
            // set the currentActionItems and run the service
            input.setRulesDataTypeActionItems(currentActionItems);
            input.setTotalRecordCount(String.valueOf(currentActionItems.size()));
            try {
                output = processService(input);
                checkResponseStatus(output.getServiceMessageCode(), output.getServiceMessage(), output.getApplicationMessage());
            }catch(Exception exception) {
                // Since exception happened, we are not going to call the service with remaining items any more.
                performServiceOperationAgain = false;

                if(output.getErrorRecordLocation() != null ) {
                    lastRunSuccesfulOccuranceItem = Integer.parseInt(output.getErrorRecordLocation());
                }

                if(rollbackOnError) {
                    try {
                        currentActionItems   = new ArrayList();
                        log.debug("originalActionItems size = " + originalActionItems.size());
                        int itemsToRollBack = (MAX_SERVICE_ACTION_ITEMS * noOfTimesServiceCalled) + (lastRunSuccesfulOccuranceItem-1);
                        log.debug("itemsToRollBack from Original list = " + itemsToRollBack);
                        if(itemsToRollBack > 0) {
	                        for(int i=0; i <  itemsToRollBack; i ++) {
	                                currentActionItems.add(originalActionItems.get(i));
	                        }
	                        currentActionItems = reverseActionItems(currentActionItems);
	                        input.setRulesDataTypeActionItems(currentActionItems);
	                        input.setTotalRecordCount(String.valueOf(currentActionItems.size()));
	                        if(log.isDebugEnabled()) {
	                            log.debug("Perform roll back for previous success Items" + currentActionItems.toString());
	                        }
	                        output = performRulesDataTypeOperation(input);
                        }
                    }catch(Exception rollBackExp) {
                        throw new Exception("Exception reported while trying to roll back the operation" , rollBackExp);
                    }

                }
                throw new Exception("Exception reported while performing service call " , exception);
            }
            noOfTimesServiceCalled ++;
            if(originalActionItems.size() <= noOfTimesServiceCalled* MAX_SERVICE_ACTION_ITEMS) {
                performServiceOperationAgain = false;
            }
        }while(performServiceOperationAgain);

        return output;

    }

	/**
	 * @param input
	 * @return RulesDatatypeMaintenanceResult
	 * @throws Exception
	 */
	private RulesDatatypeMaintenanceResult processService(RulesDatatypeMaintenance input)throws Exception {

		RulesDatatypeMaintenanceResult output = null;
		try {
			WebServiceConsumerTemplate template = new WebServiceConsumerTemplate();
			output = (RulesDatatypeMaintenanceResult) template.consumeService(input, this);
		}catch(Exception ex) {
			log.error("WebServiceConsumerTemplate.consumeService failed " , ex);
			throw new ServiceException("WebServiceConsumerTemplate.consumeService failed" , ex);
		}
		return output;
	}

	/* (non-Javadoc)
	 * @see com.bcbssc.wsutils.WebServiceConsumerCallback#getService()
	 */
	/**
	 * <p>getService.</p>
	 *
	 * @return a {@link java.lang.Object} object.
	 */
	public Object getService() {

		RulesDataTypeMaintenanceService serviceToReturn = null;

		try {
			RulesDataTypeMaintenanceServiceService serviceToLoadHandlers = (RulesDataTypeMaintenanceServiceService)getServiceWithHandlersLoaded(RulesDataTypeMaintenanceServiceService.class, SERVICE_NAME , isThisSOAExpressService);
			serviceToReturn = serviceToLoadHandlers.getRulesDataTypeMaintenance();
		}catch(ServiceException sex) {
			log.error("serviceToInvoke was not configured with Handlers" , sex);
			
		}
		return serviceToReturn;
	}

	/* (non-Javadoc)
	 * @see com.bcbssc.wsutils.WebServiceConsumerCallback#invokeService(java.lang.Object, java.lang.Object)
	 */
	/** {@inheritDoc} */
	public Object invokeService(Object serviceInput, Object serviceClient) throws Exception {

		RulesDataTypeMaintenanceService service = (RulesDataTypeMaintenanceService)serviceClient;
		RulesDataTypeMaintenanceOutput result =  service.maintainRulesDataType((RulesDataTypeMaintenanceInput)serviceInput);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.bcbssc.wsutils.WebServiceConsumerCallback#mapInput(java.lang.Object)
	 */
	/** {@inheritDoc} */
	public Object mapInput(Object passedInputData) {

		RulesDatatypeMaintenance inputData = (RulesDatatypeMaintenance) passedInputData;

		RulesDataTypeMaintenanceInput  serviceInput = new RulesDataTypeMaintenanceInput();

        serviceInput.setRpn(StringUtils.defaultString(inputData.getRpn()));
        serviceInput.setPlanCode(StringUtils.defaultString(inputData.getPlanCode()));
        serviceInput.setDataType(StringUtils.defaultString(inputData.getDataType()));
        serviceInput.setWebRacf(StringUtils.defaultString(inputData.getWebRacf())); 
        serviceInput.setUserSignOnId(StringUtils.defaultString(inputData.getUserSignOnId()));
        serviceInput.setTotalRecordCount(StringUtils.defaultString(inputData.getTotalRecordCount()));
        serviceInput.setToEscapeChar(Boolean.FALSE);
        // Common Service inputs MWIConfig & HostID & HostPassword are set by handlers

        if(log.isDebugEnabled()){
            StringBuffer buffer = new StringBuffer(0);
            buffer.append("Will run service:" + getService().toString() +" with the following input:\n")
                .append("rpn="+serviceInput.getRpn()+"\n")
                .append("planCode="+serviceInput.getPlanCode()+"\n")
                .append("dataType="+serviceInput.getDataType()+"\n")
                .append("webRacf="+serviceInput.getWebRacf()+"\n")
                .append("userSignOnId="+serviceInput.getUserSignOnId()+"\n")
                .append("totalRecordCount="+serviceInput.getTotalRecordCount()+"\n");                
                log.debug(buffer.toString());
        }
        List actionItems = inputData.getRulesDataTypeActionItems();

        StringBuffer buffer = new StringBuffer(50);
        for(int i=0; i< actionItems.size(); i++){

            int index = i+1;
            RulesDataTypeActionItem oneActionItem = (RulesDataTypeActionItem)actionItems.get(i);

            String method1 ="setActionCode" + index;
            String method2 ="setKeyFieldOne" + index;
            String method3 ="setKeyFieldTwo" + index;
            String method4 ="setKeyFieldThree" + index;
            String method5 ="setBeginDate" + index;
            String method6 ="setTerminationDate" + index;
            String method7 ="setDataFieldOne" + index;
            String method8 ="setDataFieldTwo" + index;
            String method9 ="setDataFieldThree" + index;
            try{
                invoke(serviceInput,SERVICE_INPUT_CLASS_NAME,method1, new Class[] {String.class},new Object[] {StringUtils.defaultString(oneActionItem.getActionCode())} );
                invoke(serviceInput,SERVICE_INPUT_CLASS_NAME,method2, new Class[] {String.class},new Object[] {StringUtils.defaultString(oneActionItem.getKeyFieldOne())} );
                invoke(serviceInput,SERVICE_INPUT_CLASS_NAME,method3, new Class[] {String.class},new Object[] {(String)oneActionItem.getKeyFieldTwo()} );
                invoke(serviceInput,SERVICE_INPUT_CLASS_NAME,method4, new Class[] {String.class},new Object[] {StringUtils.defaultString(oneActionItem.getKeyFieldThree())} );
                invoke(serviceInput,SERVICE_INPUT_CLASS_NAME,method5, new Class[] {String.class},new Object[] {StringUtils.defaultString(oneActionItem.getBeginDate())} );
                invoke(serviceInput,SERVICE_INPUT_CLASS_NAME,method6, new Class[] {String.class},new Object[] {StringUtils.defaultString(oneActionItem.getTerminationDate())} );
                invoke(serviceInput,SERVICE_INPUT_CLASS_NAME,method7, new Class[] {String.class},new Object[] {StringUtils.defaultString(oneActionItem.getDataFieldOne())} );
                invoke(serviceInput,SERVICE_INPUT_CLASS_NAME,method8, new Class[] {String.class},new Object[] {StringUtils.defaultString(oneActionItem.getDataFieldTwo())} );
                invoke(serviceInput,SERVICE_INPUT_CLASS_NAME,method9, new Class[] {String.class},new Object[] {StringUtils.defaultString(oneActionItem.getDataFieldThree())} );
            }catch(Exception refExpection){
                log.error("Exception while populating Service Inputs fields using Reflection",refExpection);
            }
            buffer.append("\n" + oneActionItem.toString());
        }
        if(log.isDebugEnabled()){
            log.debug("Following action items passed to input\n" + buffer.toString());
        }
        return serviceInput;
	}

	
	/* (non-Javadoc)
	 * @see com.bcbssc.wsutils.WebServiceConsumerCallback#mapOutput(java.lang.Object)
	 */
	/** {@inheritDoc} */
	public Object mapOutput(Object serviceOuput) {

		log.debug("Output the result now before casting " + serviceOuput.toString());
		RulesDatatypeMaintenanceResult rulesDatatypeMaintenanceResult = new RulesDatatypeMaintenanceResult();
		try {
			RulesDataTypeMaintenanceOutput serviceresult = (RulesDataTypeMaintenanceOutput)serviceOuput;

			rulesDatatypeMaintenanceResult.setTotalRecordsVoided(serviceresult.getTotalRecordsVoided());
			//@TODO added this later
			rulesDatatypeMaintenanceResult.setErrorRecordLocation(serviceresult.getErrorRecordLocation());

			rulesDatatypeMaintenanceResult.setApplicationMessage(serviceresult.getApplicationMessage());
			rulesDatatypeMaintenanceResult.setServiceMessage(serviceresult.getServiceMessage());
			rulesDatatypeMaintenanceResult.setSystemMessage(serviceresult.getSystemMessage());
			rulesDatatypeMaintenanceResult.setServiceMessageCode(serviceresult.getServiceMessageCode());
		}catch(Exception ex) {
			log.error("Exception while parsing the service output" ,ex );
		}

        return rulesDatatypeMaintenanceResult;
	}

	/**
     * @param aClass
     * @param aMethod
     * @param params
     * @param args
     * @throws Exception
     */
    private static void invoke (RulesDataTypeMaintenanceInput serviceInput, String aClass, String aMethod, Class[] params, Object[] args)
                throws Exception {
            Class c = Class.forName(aClass);
            Method m = c.getDeclaredMethod(aMethod, params);
            //Object i = c.newInstance();
            Object r = m.invoke(serviceInput, args);
    }

    /**
     * @param input
     * @throws Exception
     */
    private void validateInput(RulesDatatypeMaintenance input)throws Exception {

        if(StringUtils.isBlank(input.getRpn())){
            throw new IllegalArgumentException("<RPN> is required input for the service execution.");
        }else if(StringUtils.isBlank(input.getPlanCode())){
            throw new IllegalArgumentException("<PlanCode> is required input for the service execution.");
        }else if (StringUtils.isBlank(input.getDataType())){
            throw new IllegalArgumentException("<DataType> is required input for the service execution.");
        //}else if(StringUtils.isBlank(input.getWebRacf())){
        //    throw new IllegalArgumentException("<WebRACF> is required input for the service execution.");
        }else if(StringUtils.isBlank(input.getTotalRecordCount())){
            throw new IllegalArgumentException("<Total Record Count> is required input for the service execution.");
        }else if(StringUtils.isBlank(input.getUserSignOnId())){
            throw new IllegalArgumentException("<User Sign on Id> is required input for the service execution.");
        }

        if(log.isDebugEnabled()){
            log.debug("Service Input data validation passed.");
        }
        //@TODO check if any other fields are required inputs for the service. Service Consumer will
        // perform pre check for action items.

    }

    /**
     * @param actionItems
     * @return
     */
    private List reverseActionItems(List actionItems) {

        for(int i=0; i< actionItems.size(); i++){
            RulesDataTypeActionItem oneActionItem = (RulesDataTypeActionItem)actionItems.get(i);
            if(StringUtils.equalsIgnoreCase(oneActionItem.getActionCode(),"A")) {
                // if added then void it
                oneActionItem.setActionCode("V3");
            }else if(StringUtils.equalsIgnoreCase(oneActionItem.getActionCode(),"V3")) {  // For MIM implementation only.
                // if added then void it
                oneActionItem.setActionCode("A");
            }
            // for V1,V2,V3 then is no way to rollback data. @TODO check
        }
        return actionItems;
    }


}
