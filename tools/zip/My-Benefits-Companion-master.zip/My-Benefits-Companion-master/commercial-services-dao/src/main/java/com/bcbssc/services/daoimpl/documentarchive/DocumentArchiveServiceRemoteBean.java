/**
 *
 */
package com.bcbssc.services.daoimpl.documentarchive;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.bcbssc.commapi.model.common.APIException;
import com.bcbssc.commapi.model.common.DAOException;
import com.bcbssc.commapi.model.common.DocumentNotFoundException;
import com.bcbssc.commapi.model.common.GroupAdminId;
import com.bcbssc.commapi.model.common.ProviderId;
import com.bcbssc.commapi.model.common.SubscriberId;
import com.bcbssc.commapi.model.documentarchive.Document;
import com.bcbssc.commapi.model.documentarchive.EDIGReport;
import com.bcbssc.commapi.model.documentarchive.EOB;
import com.bcbssc.commapi.model.documentarchive.GroupAdminBill;
import com.bcbssc.commapi.model.documentarchive.GroupAdminCorbelDocument;
import com.bcbssc.commapi.model.documentarchive.Letter;
import com.bcbssc.commapi.model.documentarchive.Remit;
import com.bcbssc.commapi.model.documentarchive.SummaryEOB;
import com.bcbssc.commapi.model.documentarchive.dto.DocumentDTO;
import com.bcbssc.commapi.model.documentarchive.dto.DocumentSearchCriteria;
import com.bcbssc.commapi.model.documentarchive.dto.DocumentSearchKey;
import com.bcbssc.commapi.model.documentarchive.dto.DocumentSearchKeyOperator;
import com.bcbssc.commapi.model.documentarchive.dto.ImageFolder;
import com.bcbssc.services.dao.documentarchive.DocumentArchiveServiceRemote;


/**
 * <p>DocumentArchiveServiceRemoteBean class.</p>
 *
 * @author FF74
 * @version $Id: $Id
 */
public class DocumentArchiveServiceRemoteBean
       implements DocumentArchiveServiceRemote, Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	static Logger logger = Logger.getLogger(DocumentArchiveServiceRemoteBean.class);

    // Document Archive Input/Output Constants
    private static final String EMPTY_STRING 			= "";
    private static final String CHECK_DATE 				= "CHECK DATE";
    private static final String CLAIM_NO 				= "CLAIM NO";
    private static final String CLAIM_NUMBER 			= "CLAIM NUMBER";
    private static final String DATE 					= "DATE";
    private static final String DESCRIPTION 			= "DESCRIPTION";
    private static final String DESCRIPTIVE 			= "DESCRIPTIVE";
    private static final String FILLER1 				= "FILLER1";
    private static final String GROUP_NUMBER 			= "GROUP NUMBER";
    private static final String ID_CARD_NO 				= "ID CARD NO";
    private static final String ID_CARD_NUMBER 			= "ID CARD NUMBER";
	private static final String NPI 					= "NPI";
	private static final String PATIENT_NAME 			= "PATIENT NAME";
	private static final String POSTING_DATE 			= "POSTING DATE";
	//private static final String PROVIDER_NO 			= "PROVIDER NO";
	private static final String REGION_ID 				= "REGION ID";
	private static final String REPORT_ID 				= "REPORT_ID";
	private static final String REPORT_ID_DESC 			= "REPORT ID DESC";
	private static final String STATEMENT_END 			= "STATEMENT END";
	private static final String STATEMENT_START 		= "STATEMENT START";
	private static final String SUB_ID 					= "SUB-ID";
    private static final String SUBSCRIBER_ID 			= "SUBSCRIBER ID";
    private static final String TIMESTAMP 				= "TIMESTAMP";
    private static final String EDIG_PROVIDER 			= "PROVIDER";
    private static final String RECEIVED_DATE 			= "RECEIVED DATE";
    private static final String CERT_ID 				= "CERT ID";
    private static final String EFFECTIVE_DATE 			= "EFFECTIVE DATE";
    private static final String DENTAL_CARD_ID 			= "CARD ID";
    private static final boolean FALSE 					= false;
    //private static final boolean TRUE 					= true;

    // Date Formatting Constants
	private static final String DATE_FMT  				= "MM/dd/yyyy";
	private static DateFormat dateformat 				= new SimpleDateFormat(DATE_FMT);

	// Exception Message Constants
	private static final String DNFE_MESSAGE 			= "Empty list was returned.";

	// Logging Constants
	private static final String ADDED_SPACE 			= "Added ";
	private static final String COLON_SPACE 			= ": ";
	private static final String SEARCH_CRITERIA_OBJECTS = " searchCriteria object(s).";

	/**
	 * {@inheritDoc}
	 *
	 * Get the requested document based on the dates, provider, subscriber information and claim number.
	 */
	public Document getCorrespondenceResponseDocument(ProviderId provider, SubscriberId subscriber,
			String claimNumber, String postingDate, String timestamp, Date dateFrom, Date dateTo) throws DocumentNotFoundException,
			APIException {
    
		
		if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
		    DocumentArchiveServiceRemoteBean.logger.debug("Timestamp:"+timestamp);
		}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		
		
		// Create return List<Letter> object
		List<Letter> listToReturn = new ArrayList<Letter>();

		// Create and populate DocumentSearchKey List object
		List<DocumentSearchKey> dskl= new ArrayList<DocumentSearchKey>();
		int searchCriteriaCount = 0;

		

		// Add idCardNumber if it was sent
		String idCardNumber = null;
		if(subscriber != null) {
			idCardNumber = subscriber.getIdCardNumber();
		}// End of if(subscriber != null)
		if(this.isNotNullAndNotEmpty(idCardNumber)){
			DocumentSearchKey dsk2 = new DocumentSearchKey();
			dsk2.setKeyName(DocumentArchiveServiceRemoteBean.ID_CARD_NUMBER);
			dsk2.setKeyValue(idCardNumber);
			dsk2.setOperator(DocumentSearchKeyOperator.EQUAL);
			dskl.add(dsk2);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.ID_CARD_NO + DocumentArchiveServiceRemoteBean.COLON_SPACE + idCardNumber);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of if(this.isNotNullAndNotEmpty(idCardNumber))

		
		
		// Add subscriberId if it was sent
		String subscriberId = null;
		if(subscriber != null) {
			subscriberId = subscriber.getMemberNumber();
		}// End of if(subscriber != null)
		if(this.isNotNullAndNotEmpty(subscriberId)){
			DocumentSearchKey dsk5 = new DocumentSearchKey();
			dsk5.setKeyName(DocumentArchiveServiceRemoteBean.SUB_ID);
			dsk5.setKeyValue(subscriberId);
			dsk5.setOperator(DocumentSearchKeyOperator.EQUAL);
			dskl.add(dsk5);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.SUB_ID + DocumentArchiveServiceRemoteBean.COLON_SPACE + subscriberId);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of if(!((subscriberId == null) || (EMPTY_STRING.equals(subscriberId))))

		// Add timestamp if it was sent
		if(this.isNotNullAndNotEmpty(timestamp)){
			DocumentSearchKey dsk6 = new DocumentSearchKey();
			dsk6.setKeyName(DocumentArchiveServiceRemoteBean.TIMESTAMP);
			dsk6.setKeyValue(timestamp);
			dsk6.setOperator(DocumentSearchKeyOperator.EQUAL);
			dskl.add(dsk6);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.TIMESTAMP + DocumentArchiveServiceRemoteBean.COLON_SPACE + timestamp);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of if(this.isNotNullAndNotEmpty(timestamp))

	    // Log the number of search criteria objects added
		if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
		    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + searchCriteriaCount + DocumentArchiveServiceRemoteBean.SEARCH_CRITERIA_OBJECTS);
		}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())

		// Create and populate DocumentSearchCriteria object
		DocumentSearchCriteria dsc = new DocumentSearchCriteria();
		dsc.setImageFolder(ImageFolder.SECURE_RESPONSE);
		dsc.setOrSearchCriteria(FALSE);
		dsc.setSearchEndDate(dateTo);
		dsc.setSearchBeginDate(dateFrom);
		dsc.setSearchConditions(dskl);

		// Create the document list object
		List<DocumentDTO> documentList = null;

		try {
			// Call getDocumentList() of DocumentRetrieveDAOBean
			documentList = (new DocumentRetrieveDAOImpl()).getDocumentList(dsc);
		} catch (DAOException e) {
			throw new APIException(e);
		}// End of try-catch

		// Check list contains at least one object
		if(documentList.size() > 0) {

			// Loop through the returned list
			for(DocumentDTO doc : documentList) {

				// Create and initialize a letter object
				Letter letter = new Letter();

				// Store the returning doc type, mime type,
				// doc id, and image folder name
				letter.setDocType(doc.getDocumentType());
				letter.setMimeType(doc.getMimeType());
				letter.setDocId(doc.getDocId());
				letter.setImageFolderName(ImageFolder.SECURE_RESPONSE);

				// Store the returning column names and their corresponding values
				HashMap<String, String> da = doc.getDocumentAttributes();
				
				letter.setIdCardNumber(this.trim(da.get(DocumentArchiveServiceRemoteBean.ID_CARD_NUMBER)));
				letter.setSubscriberId(this.trim(da.get(DocumentArchiveServiceRemoteBean.SUB_ID)));
				letter.setTimeStamp(this.trim(da.get(DocumentArchiveServiceRemoteBean.TIMESTAMP)));

				// Add the letter object to the list
				listToReturn.add(letter);

			}// End of for(DocumentDTO doc : documentList)
		} else {

			// Empty list, throw exception
			throw new DocumentNotFoundException(DocumentArchiveServiceRemoteBean.DNFE_MESSAGE);
		}// End of if(documentList.size() > 0)

	    // Log the returning list size
		if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
		    DocumentArchiveServiceRemoteBean.logger.debug("Letter returning list size was " + listToReturn.size() + ".");
		}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())

		// Create the returning letter object
		Letter letter = new Letter();

		// Check size of returning list
		if(listToReturn.isEmpty()) {
			// Empty list, throw DocumentNotFoundException
			throw new DocumentNotFoundException(DocumentArchiveServiceRemoteBean.DNFE_MESSAGE);
		} else if(listToReturn.size() == 1) {
			// get the single document from the list
			letter = listToReturn.get(0);
		} else {
			// get the first document in the list
			letter = listToReturn.get(0);
		}// End of if(listToReturn.isEmpty())

		// Return the document object
		return this.getDocument(letter.getImageFolderName(), letter.getDocId());
	}// End of getCorrespondenceResponseDocument method

	/**
	 * {@inheritDoc}
	 *
	 * Get the requested document based on the dates, subscriber information and claim number.
	 */
	public Document getDentalSubscriberLetter(SubscriberId subscriber,
			String claimNumber, Date dateProcessed, Date dateFrom, Date dateTo)
			throws DocumentNotFoundException, APIException {

		// Create return List<Letter> object
		List<Letter> listToReturn = new ArrayList<Letter>();

		// Create and populate DocumentSearchKey List object
		List<DocumentSearchKey> dskl= new ArrayList<DocumentSearchKey>();
		int searchCriteriaCount = 0;

		// Add claimNumber if it was sent
		if(this.isNotNullAndNotEmpty(claimNumber)){
			DocumentSearchKey dsk1 = new DocumentSearchKey();
			dsk1.setKeyName(DocumentArchiveServiceRemoteBean.CLAIM_NO);
			dsk1.setKeyValue(claimNumber);
			dsk1.setOperator(DocumentSearchKeyOperator.EQUAL);
			dskl.add(dsk1);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.CLAIM_NO + DocumentArchiveServiceRemoteBean.COLON_SPACE + claimNumber);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of (this.isNotNullAndNotEmpty(claimNumber))

		// Add idCardNumber if it was sent
		String idCardNumber = null;
		if(subscriber != null) {
			idCardNumber = subscriber.getIdCardNumber();
		}// End of if(subscriber != null)
		if(this.isNotNullAndNotEmpty(idCardNumber)){
			DocumentSearchKey dsk2 = new DocumentSearchKey();
			dsk2.setKeyName(DocumentArchiveServiceRemoteBean.ID_CARD_NUMBER);
			dsk2.setKeyValue(idCardNumber);
			dsk2.setOperator(DocumentSearchKeyOperator.EQUAL);
			dskl.add(dsk2);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.ID_CARD_NO + DocumentArchiveServiceRemoteBean.COLON_SPACE + idCardNumber);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of if(this.isNotNullAndNotEmpty(idCardNumber))

		// Add subscriberId if it was sent
		String subscriberId = null;
		if(subscriber != null) {
			subscriberId = subscriber.getMemberNumber();
		}// End of if(subscriber != null)
		if(this.isNotNullAndNotEmpty(subscriberId)){
			DocumentSearchKey dsk3 = new DocumentSearchKey();
			dsk3.setKeyName(DocumentArchiveServiceRemoteBean.SUB_ID);
			dsk3.setKeyValue(subscriberId);
			dsk3.setOperator(DocumentSearchKeyOperator.EQUAL);
			dskl.add(dsk3);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.SUB_ID + DocumentArchiveServiceRemoteBean.COLON_SPACE + subscriberId);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of if(!((subscriberId == null) || (EMPTY_STRING.equals(subscriberId))))

	    // Log the number of search criteria objects added
		if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
		    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + searchCriteriaCount + DocumentArchiveServiceRemoteBean.SEARCH_CRITERIA_OBJECTS);
		}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())

		// Create and populate DocumentSearchCriteria object
		DocumentSearchCriteria dsc = new DocumentSearchCriteria();
		dsc.setImageFolder(ImageFolder.DENTAL_SBSR_LETTERS);
		dsc.setOrSearchCriteria(FALSE);
		dsc.setSearchEndDate(dateTo);
		dsc.setSearchBeginDate(dateFrom);
		dsc.setSearchConditions(dskl);

		// Create the document list object
		List<DocumentDTO> documentList = null;

		try {
			// Call getDocumentList() of DocumentRetrieveDAOBean
			documentList = (new DocumentRetrieveDAOImpl()).getDocumentList(dsc);
		} catch (DAOException e) {
			throw new APIException(e);
		}// End of try-catch

		// Check list contains at least one object
		if(documentList.size() > 0) {

			// Loop through the returned list
			for(DocumentDTO doc : documentList) {

				// Create and initialize a letter object
				Letter letter = new Letter();

				// Store the returning doc type, mime type,
				// doc id, and image folder name
				letter.setDocType(doc.getDocumentType());
				letter.setMimeType(doc.getMimeType());
				letter.setDocId(doc.getDocId());
				letter.setImageFolderName(ImageFolder.DENTAL_SBSR_LETTERS);

				// Store the returning column names and their corresponding values
				HashMap<String, String> da = doc.getDocumentAttributes();
				letter.setClaimNumber(this.trim(da.get(DocumentArchiveServiceRemoteBean.CLAIM_NO)));
				letter.setIdCardNumber(this.trim(da.get(DocumentArchiveServiceRemoteBean.ID_CARD_NUMBER)));
				letter.setPostingDate(this.trim(da.get(DocumentArchiveServiceRemoteBean.POSTING_DATE)));
				letter.setRegionId(this.trim(da.get(DocumentArchiveServiceRemoteBean.REGION_ID)));
				letter.setReportId(this.trim(da.get(DocumentArchiveServiceRemoteBean.REPORT_ID)));
				letter.setReportIdDescription(this.trim(da.get(DocumentArchiveServiceRemoteBean.REPORT_ID_DESC)));
				letter.setSubscriberId(this.trim(da.get(DocumentArchiveServiceRemoteBean.SUB_ID)));

				// Add the letter object to the list
				listToReturn.add(letter);

			}// End of for(DocumentDTO doc : documentList)
		} else {

			// Empty list, throw exception
			throw new DocumentNotFoundException(DocumentArchiveServiceRemoteBean.DNFE_MESSAGE);
		}// End of if(documentList.size() > 0)

	    // Log the returning list size
		if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
		    DocumentArchiveServiceRemoteBean.logger.debug("Letter returning list size was " + listToReturn.size() + ".");
		}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())

		// Create eob object
		Letter letter = new Letter();

		// Check size of returning list
		if(listToReturn.isEmpty()) {
			// Empty list, throw DocumentNotFoundException
			throw new DocumentNotFoundException(DocumentArchiveServiceRemoteBean.DNFE_MESSAGE);
		} else if(listToReturn.size() == 1) {
			// get single document in the list
			letter = listToReturn.get(0);
		} else {
			// get the first document in the list
			letter = listToReturn.get(0);
		}// End of if(listToReturn.isEmpty())

		// Return the document object
		return this.getDocument(letter.getImageFolderName(), letter.getDocId());
	}// End of getDentalOrthodonticLetter method

	/**
	 * {@inheritDoc}
	 *
	 * Get the requested document based on the dates, subscriber information and claim number.
	 */
	public Document getDentalProviderLetter(SubscriberId subscriber,
			String claimNumber, Date dateProcessed, Date dateFrom, Date dateTo)
			throws DocumentNotFoundException, APIException {

		// Create return List<Letter> object
		List<Letter> listToReturn = new ArrayList<Letter>();

		// Create and populate DocumentSearchKey List object
		List<DocumentSearchKey> dskl= new ArrayList<DocumentSearchKey>();
		int searchCriteriaCount = 0;

		// Add claimNumber if it was sent
		if(this.isNotNullAndNotEmpty(claimNumber)){
			DocumentSearchKey dsk1 = new DocumentSearchKey();
			dsk1.setKeyName(DocumentArchiveServiceRemoteBean.CLAIM_NO);
			dsk1.setKeyValue(claimNumber);
			dsk1.setOperator(DocumentSearchKeyOperator.EQUAL);
			dskl.add(dsk1);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.CLAIM_NO + DocumentArchiveServiceRemoteBean.COLON_SPACE + claimNumber);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of (this.isNotNullAndNotEmpty(claimNumber))

		// Add idCardNumber if it was sent
		String idCardNumber = null;
		if(subscriber != null) {
			idCardNumber = subscriber.getIdCardNumber();
		}// End of if(subscriber != null)
		if(this.isNotNullAndNotEmpty(idCardNumber)){
			DocumentSearchKey dsk2 = new DocumentSearchKey();
			dsk2.setKeyName(DocumentArchiveServiceRemoteBean.ID_CARD_NUMBER);
			dsk2.setKeyValue(idCardNumber);
			dsk2.setOperator(DocumentSearchKeyOperator.EQUAL);
			dskl.add(dsk2);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.ID_CARD_NO + DocumentArchiveServiceRemoteBean.COLON_SPACE + idCardNumber);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of if(this.isNotNullAndNotEmpty(idCardNumber))

		// Add subscriberId if it was sent
		String subscriberId = null;
		if(subscriber != null) {
			subscriberId = subscriber.getMemberNumber();
		}// End of if(subscriber != null)
		if(this.isNotNullAndNotEmpty(subscriberId)){
			DocumentSearchKey dsk3 = new DocumentSearchKey();
			dsk3.setKeyName(DocumentArchiveServiceRemoteBean.SUB_ID);
			dsk3.setKeyValue(subscriberId);
			dsk3.setOperator(DocumentSearchKeyOperator.EQUAL);
			dskl.add(dsk3);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.SUB_ID + DocumentArchiveServiceRemoteBean.COLON_SPACE + subscriberId);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of if(!((subscriberId == null) || (EMPTY_STRING.equals(subscriberId))))

	    // Log the number of search criteria objects added
		if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
		    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + searchCriteriaCount + DocumentArchiveServiceRemoteBean.SEARCH_CRITERIA_OBJECTS);
		}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())

		// Create and populate DocumentSearchCriteria object
		DocumentSearchCriteria dsc = new DocumentSearchCriteria();
		dsc.setImageFolder(ImageFolder.DENTAL_PROV_LETTERS);
		dsc.setOrSearchCriteria(FALSE);
		dsc.setSearchEndDate(dateTo);
		dsc.setSearchBeginDate(dateFrom);
		dsc.setSearchConditions(dskl);

		// Create the document list object
		List<DocumentDTO> documentList = null;

		try {
			// Call getDocumentList() of DocumentRetrieveDAOBean
			documentList = (new DocumentRetrieveDAOImpl()).getDocumentList(dsc);
		} catch (DAOException e) {
			throw new APIException(e);
		}// End of try-catch

		// Check list contains at least one object
		if(documentList.size() > 0) {

			// Loop through the returned list
			for(DocumentDTO doc : documentList) {

				// Create and initialize a letter object
				Letter letter = new Letter();

				// Store the returning doc type, mime type,
				// doc id, and image folder name
				letter.setDocType(doc.getDocumentType());
				letter.setMimeType(doc.getMimeType());
				letter.setDocId(doc.getDocId());
				letter.setImageFolderName(ImageFolder.DENTAL_PROV_LETTERS);

				// Store the returning column names and their corresponding values
				HashMap<String, String> da = doc.getDocumentAttributes();
				letter.setClaimNumber(this.trim(da.get(DocumentArchiveServiceRemoteBean.CLAIM_NO)));
				letter.setIdCardNumber(this.trim(da.get(DocumentArchiveServiceRemoteBean.ID_CARD_NUMBER)));
				letter.setPostingDate(this.trim(da.get(DocumentArchiveServiceRemoteBean.POSTING_DATE)));
				letter.setRegionId(this.trim(da.get(DocumentArchiveServiceRemoteBean.REGION_ID)));
				letter.setReportId(this.trim(da.get(DocumentArchiveServiceRemoteBean.REPORT_ID)));
				letter.setReportIdDescription(this.trim(da.get(DocumentArchiveServiceRemoteBean.REPORT_ID_DESC)));
				letter.setSubscriberId(this.trim(da.get(DocumentArchiveServiceRemoteBean.SUB_ID)));

				// Add the letter object to the list
				listToReturn.add(letter);

			}// End of for(DocumentDTO doc : documentList)
		} else {

			// Empty list, throw exception
			throw new DocumentNotFoundException(DocumentArchiveServiceRemoteBean.DNFE_MESSAGE);
		}// End of if(documentList.size() > 0)

	    // Log the returning list size
		if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
		    DocumentArchiveServiceRemoteBean.logger.debug("Letter returning list size was " + listToReturn.size() + ".");
		}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())

		// Create eob object
		Letter letter = new Letter();

		// Check size of returning list
		if(listToReturn.isEmpty()) {
			// Empty list, throw DocumentNotFoundException
			throw new DocumentNotFoundException(DocumentArchiveServiceRemoteBean.DNFE_MESSAGE);
		} else if(listToReturn.size() == 1) {
			// get single document in the list
			letter = listToReturn.get(0);
		} else {
			// get the first document in the list
			letter = listToReturn.get(0);
		}// End of if(listToReturn.isEmpty())

		// Return the document object
		return this.getDocument(letter.getImageFolderName(), letter.getDocId());
	}// End of getDentalPreTreatmentLetter method

	/**
	 * {@inheritDoc}
	 *
	 * Get the requested edig report document.
	 */
	public Document getEDIGReport(EDIGReport edigReport)
			throws DocumentNotFoundException, APIException {

		// Return the document object
		return this.getDocument(edigReport.getImageFolderName(), edigReport.getDocId());
	}// End of getEDIGReport method

	/**
	 * {@inheritDoc}
	 *
	 * Get a document list based on the dates, provider information and folder name.
	 */
	public List<EDIGReport> getEDIGReportList(ProviderId provider,
			ImageFolder edigFolderName, Date dateFrom, Date dateTo)
			throws DocumentNotFoundException, APIException {

		// Create return List<Remit> object
		List<EDIGReport> listToReturn = new ArrayList<EDIGReport>();

		// Create and populate DocumentSearchKey List object
		List<DocumentSearchKey> dskl= new ArrayList<DocumentSearchKey>();
		int searchCriteriaCount = 0;

		// Add providerId if it was sent
		String providerId = null;
		if(provider != null) {
			providerId = provider.getFederalTaxIdNumber();
		}// End of if(provider != null)
		if(this.isNotNullAndNotEmpty(providerId)){
			DocumentSearchKey dsk1 = new DocumentSearchKey();
			dsk1.setKeyName(DocumentArchiveServiceRemoteBean.EDIG_PROVIDER);
			dsk1.setKeyValue(providerId);
			dsk1.setOperator(DocumentSearchKeyOperator.LIKE);
			dskl.add(dsk1);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.EDIG_PROVIDER + DocumentArchiveServiceRemoteBean.COLON_SPACE + providerId);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of if(this.isNotNullAndNotEmpty(providerId))

		// Add npi if it was sent
		String npi = null;
		if(provider != null) {
			npi = provider.getNationalProviderIdentifier();
		}// End of if(provider != null)
		if(this.isNotNullAndNotEmpty(npi)){
			DocumentSearchKey dsk2 = new DocumentSearchKey();
			dsk2.setKeyName(DocumentArchiveServiceRemoteBean.NPI);
			dsk2.setKeyValue(npi);
			dsk2.setOperator(DocumentSearchKeyOperator.LIKE);
			dskl.add(dsk2);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.NPI + DocumentArchiveServiceRemoteBean.COLON_SPACE + npi);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of if(this.isNotNullAndNotEmpty(npi))

	    // Log the number of search criteria objects added
		if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
		    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + searchCriteriaCount + DocumentArchiveServiceRemoteBean.SEARCH_CRITERIA_OBJECTS);
		}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())

		// Create and populate DocumentSearchCriteria object
		DocumentSearchCriteria dsc = new DocumentSearchCriteria();
		dsc.setImageFolder(edigFolderName);
		dsc.setOrSearchCriteria(FALSE);
		dsc.setSearchBeginDate(dateFrom);
		dsc.setSearchEndDate(dateTo);
		dsc.setSearchConditions(dskl);

		// Call getDocumentList() of DocumentRetrieveDAOBean
		List<DocumentDTO> documentList = null;
		try {
			documentList = (new DocumentRetrieveDAOImpl()).getDocumentList(dsc);
		} catch (DAOException e) {
			throw new APIException(e);
		}// End of try/catch

		// Check list contains at least one object
		if(documentList.size() > 0) {

			// Populate return list
			for(DocumentDTO doc : documentList) {

				// Create and initialize a report object
				EDIGReport report = new EDIGReport();

				// Store the returning doc type, mime type,
				// doc id, and the image folder name
				report.setDocType(doc.getDocumentType());
				report.setMimeType(doc.getMimeType());
				report.setDocId(doc.getDocId());
				report.setImageFolderName(edigFolderName);

				// Store the returning column names and their corresponding values
				HashMap<String, String> da = doc.getDocumentAttributes();
				report.setProvider(this.trim(da.get(DocumentArchiveServiceRemoteBean.EDIG_PROVIDER)));
				report.setNpi(this.trim(da.get(DocumentArchiveServiceRemoteBean.NPI)));
				report.setReceivedDate(this.trim(da.get(DocumentArchiveServiceRemoteBean.RECEIVED_DATE)));
				report.setPostingDate(this.trim(da.get(DocumentArchiveServiceRemoteBean.POSTING_DATE)));
				report.setReportId(this.trim(da.get(DocumentArchiveServiceRemoteBean.REPORT_ID)));

				// Add the report object to the list
				listToReturn.add(report);
			}// End of for(DocumentDTO doc : documentList)
		} else {
			throw new DocumentNotFoundException(DocumentArchiveServiceRemoteBean.DNFE_MESSAGE);
		}// End of if(documentList.size() > 0)
		return listToReturn;
	}// End of getEDIGReportList method

	/**
	 * {@inheritDoc}
	 *
	 * Get the requested document based on the dates, subscriber information and claim number.
	 */
	public Document getExplanationOfBenefits(SubscriberId subscriber,
            String claimNumber, Date dateProcessed, Date dateFrom, Date dateTo)
			throws DocumentNotFoundException, APIException {

		// Create return List<EOB> object
		List<EOB> listToReturn = new ArrayList<EOB>();

		// Create and populate DocumentSearchKey List object
		List<DocumentSearchKey> dskl= new ArrayList<DocumentSearchKey>();
		int searchCriteriaCount = 0;

		// Add claimNumber if it was sent
		if(this.isNotNullAndNotEmpty(claimNumber)){
			DocumentSearchKey dsk1 = new DocumentSearchKey();
			dsk1.setKeyName(DocumentArchiveServiceRemoteBean.CLAIM_NUMBER);
			dsk1.setKeyValue(claimNumber);
			dsk1.setOperator(DocumentSearchKeyOperator.EQUAL);
			dskl.add(dsk1);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.CLAIM_NUMBER + DocumentArchiveServiceRemoteBean.COLON_SPACE + claimNumber);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of if(this.isNotNullAndNotEmpty(claimNumber))

		// Add memberNumber if it was sent
		String memberNumber = null;
		if(subscriber != null) {
			memberNumber = subscriber.getMemberNumber();
		}// End of if(subscriber != null)
		if(this.isNotNullAndNotEmpty(memberNumber)){
			DocumentSearchKey dsk2 = new DocumentSearchKey();
			dsk2.setKeyName(DocumentArchiveServiceRemoteBean.SUB_ID);
			dsk2.setKeyValue(memberNumber);
			dsk2.setOperator(DocumentSearchKeyOperator.EQUAL);
			dskl.add(dsk2);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.SUB_ID + DocumentArchiveServiceRemoteBean.COLON_SPACE + memberNumber);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of if(this.isNotNullAndNotEmpty(memberNumber))

		// Add dateProcessed if it was sent
		if((dateProcessed != null)&&(this.isNotNullAndNotEmpty(dateformat.format(dateProcessed)))){
			DocumentSearchKey dsk3 = new DocumentSearchKey();
			dsk3.setKeyName(DocumentArchiveServiceRemoteBean.CHECK_DATE);
			dsk3.setKeyValue(dateformat.format(dateProcessed));
			dsk3.setOperator(DocumentSearchKeyOperator.EQUAL);
			dskl.add(dsk3);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.CHECK_DATE + DocumentArchiveServiceRemoteBean.COLON_SPACE + dateProcessed);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of if((dateProcessed != null)&&(this.isNotNullAndNotEmpty(dateformat.format(dateProcessed))))

		// Add idCardNumber if it was sent
		String idCardNumber = null;
		if(subscriber != null) {
			idCardNumber = subscriber.getIdCardNumber();
		}// End of if(subscriber != null)
		if(this.isNotNullAndNotEmpty(idCardNumber)){
			DocumentSearchKey dsk4 = new DocumentSearchKey();
			dsk4.setKeyName(DocumentArchiveServiceRemoteBean.ID_CARD_NUMBER);
			dsk4.setKeyValue(idCardNumber);
			dsk4.setOperator(DocumentSearchKeyOperator.EQUAL);
			dskl.add(dsk4);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.ID_CARD_NUMBER + DocumentArchiveServiceRemoteBean.COLON_SPACE + idCardNumber);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of if(this.isNotNullAndNotEmpty(idCardNumber))

	    // Log the number of search criteria objects added
		if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
		    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + searchCriteriaCount + DocumentArchiveServiceRemoteBean.SEARCH_CRITERIA_OBJECTS);
		}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())

		// Create and populate DocumentSearchCriteria object
		DocumentSearchCriteria dsc = new DocumentSearchCriteria();
		dsc.setImageFolder(ImageFolder.EOBS);
		dsc.setOrSearchCriteria(FALSE);
		dsc.setSearchEndDate(dateTo);
		dsc.setSearchBeginDate(dateFrom);
		dsc.setSearchConditions(dskl);

		// Create the document list object
		List<DocumentDTO> documentList = null;

		try {
			// Call getDocumentList() of DocumentRetrieveDAOBean
			documentList = (new DocumentRetrieveDAOImpl()).getDocumentList(dsc);
		} catch (DAOException e) {
			throw new APIException(e);
		}// End of try-catch

		// Check list contains at least one object
		if(documentList.size() > 0) {

			// Populate return list
			for(DocumentDTO doc : documentList) {

				// Create and initialize an eob object
				EOB eob = new EOB();

				// Store the returning doc type, mime type,
				// doc id, and the image folder name
				eob.setDocType(doc.getDocumentType());
				eob.setMimeType(doc.getMimeType());
				eob.setDocId(doc.getDocId());
				eob.setImageFolderName(ImageFolder.EOBS);

				// Store the returning column names and their corresponding values
				HashMap<String, String> da = doc.getDocumentAttributes();
				eob.setPostingDate(this.trim(da.get(DocumentArchiveServiceRemoteBean.POSTING_DATE)));
				eob.setReportId(this.trim(da.get(DocumentArchiveServiceRemoteBean.REPORT_ID)));
				eob.setClaimNumber(this.trim(da.get(DocumentArchiveServiceRemoteBean.CLAIM_NUMBER)));
				eob.setSubId(this.trim(da.get(DocumentArchiveServiceRemoteBean.SUB_ID)));
				eob.setPatientName(this.trim(da.get(DocumentArchiveServiceRemoteBean.PATIENT_NAME)));
				eob.setCheckDate(this.trim(da.get(DocumentArchiveServiceRemoteBean.CHECK_DATE)));
				eob.setFiller1(this.trim(da.get(DocumentArchiveServiceRemoteBean.FILLER1)));
				eob.setIdCardNumber(this.trim(da.get(DocumentArchiveServiceRemoteBean.ID_CARD_NUMBER)));
				eob.setRegionId(this.trim(da.get(DocumentArchiveServiceRemoteBean.REGION_ID)));
				eob.setReportIdDesc(this.trim(da.get(DocumentArchiveServiceRemoteBean.REPORT_ID_DESC)));

				// Add the eob object to the list
				listToReturn.add(eob);

			}// End of for(DocumentDTO doc : documentList)
		} else {

			// Empty list, throw exception
			throw new DocumentNotFoundException(DocumentArchiveServiceRemoteBean.DNFE_MESSAGE);
		}// End of if(documentList.size() > 0)

	    // Log the returning list size
		if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
		    DocumentArchiveServiceRemoteBean.logger.debug("EOB returning list size was " + listToReturn.size() + ".");
		}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())

		// Create eob object
		EOB eob = new EOB();

		// Check size of returning list
		if(listToReturn.isEmpty()) {
			// Empty list, throw DocumentNotFoundException
			throw new DocumentNotFoundException(DocumentArchiveServiceRemoteBean.DNFE_MESSAGE);
		} else if(listToReturn.size() == 1) {
			// get single document in the list
			eob = listToReturn.get(0);
		} else {
			// get the first document in the list
			eob = listToReturn.get(0);
		}// End of if(listToReturn.isEmpty())

		// Return the document object
		return this.getDocument(eob.getImageFolderName(), eob.getDocId());
	}// End of getExplanationOfBenefits method

	/**
	 * {@inheritDoc}
	 *
	 * Get the requested group admin bill document.
	 */
	public Document getGroupAdminBill(GroupAdminBill groupAdminBill)
			throws DocumentNotFoundException, APIException {

		// Return the document object
		return this.getDocument(groupAdminBill.getImageFolderName(), groupAdminBill.getDocId());
	}// End of getGroupAdminBill method

	
	/**
	 * Get the requested group admin policy document.
	 *
	 * @return Document
	 * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if there is an exception.
	 * @throws com.bcbssc.commapi.model.common.APIException if there is an exception.
	 * @param groupAdminCert a {@link com.bcbssc.commapi.model.documentarchive.GroupAdminCorbelDocument} object.
	 */
	public Document getGroupAdminCert(GroupAdminCorbelDocument groupAdminCert)
			throws DocumentNotFoundException, APIException {
		return getDocument(groupAdminCert.getImageFolderName(),
				groupAdminCert.getDocId());
	}

	/**
	 * <p>getGroupAdminPolicy.</p>
	 *
	 * @param groupAdminPolicy a {@link com.bcbssc.commapi.model.documentarchive.GroupAdminCorbelDocument} object.
	 * @return a {@link com.bcbssc.commapi.model.documentarchive.Document} object.
	 * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if any.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 */
	public Document getGroupAdminPolicy(
			GroupAdminCorbelDocument groupAdminPolicy)
			throws DocumentNotFoundException, APIException {
		return getDocument(groupAdminPolicy.getImageFolderName(),
				groupAdminPolicy.getDocId());
	}

	/**
	 * <p>getGroupAdminDentalCard.</p>
	 *
	 * @param groupAdminDentalCard a {@link com.bcbssc.commapi.model.documentarchive.GroupAdminCorbelDocument} object.
	 * @return a {@link com.bcbssc.commapi.model.documentarchive.Document} object.
	 * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if any.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 */
	public Document getGroupAdminDentalCard(
			GroupAdminCorbelDocument groupAdminDentalCard)
			throws DocumentNotFoundException, APIException {
		return getDocument(groupAdminDentalCard.getImageFolderName(),
				groupAdminDentalCard.getDocId());
	}
	
	/**
	 * {@inheritDoc}
	 *
	 * Get a document list based on the dates and group admin id.
	 */
	public List<GroupAdminBill> getGroupAdminBillList(GroupAdminId groupAdminId,
			Date dateFrom, Date dateTo) throws DocumentNotFoundException,
			APIException {

		// Create return List<GroupAdminBill> object
		List<GroupAdminBill> listToReturn = new ArrayList<GroupAdminBill>();

		// Create and populate DocumentSearchKey List object
		List<DocumentSearchKey> dskl= new ArrayList<DocumentSearchKey>();
		int searchCriteriaCount = 0;

		// Add groupAdminId if it was sent
		String groupNumber = null;
		if(groupAdminId != null) {
			groupNumber = groupAdminId.getGroupAdminIdentifier();
		}// End of if(groupAdminId != null)
		if(this.isNotNullAndNotEmpty(groupNumber)){
			DocumentSearchKey dsk1 = new DocumentSearchKey();
			dsk1.setKeyName(DocumentArchiveServiceRemoteBean.GROUP_NUMBER);
			dsk1.setKeyValue(groupNumber);
			dsk1.setOperator(DocumentSearchKeyOperator.LIKE);
			dskl.add(dsk1);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.GROUP_NUMBER + DocumentArchiveServiceRemoteBean.COLON_SPACE + groupNumber);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of if(this.isNotNullAndNotEmpty(groupNumber))

	    // Log the number of search criteria objects added
		if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
		    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + searchCriteriaCount + DocumentArchiveServiceRemoteBean.SEARCH_CRITERIA_OBJECTS);
		}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())

		// Create and populate DocumentSearchCriteria object
		DocumentSearchCriteria dsc = new DocumentSearchCriteria();
		dsc.setImageFolder(ImageFolder.GROUP_ADMIN_BILL);
		dsc.setOrSearchCriteria(FALSE);
		dsc.setSearchBeginDate(dateFrom);
		dsc.setSearchEndDate(dateTo);
		dsc.setSearchConditions(dskl);


		// Create the document list object
		List<DocumentDTO> documentList = null;

		try {
			// Call getDocumentList() of DocumentRetrieveDAOBean
			documentList = (new DocumentRetrieveDAOImpl()).getDocumentList(dsc);
		} catch (DAOException e) {
			throw new APIException(e);
		}// End of try-catch

		// Check list contains at least one object
		if(documentList.size() > 0) {

			// Populate return list
			for(DocumentDTO doc : documentList) {

				// Create and initialize a groupAdminBill object
				GroupAdminBill groupAdminBill = new GroupAdminBill();

				// Store the returning doc type, mime type,
				// doc id, and the image folder name
				groupAdminBill.setDocType(doc.getDocumentType());
				groupAdminBill.setMimeType(doc.getMimeType());
				groupAdminBill.setDocId(doc.getDocId());
				groupAdminBill.setImageFolderName(ImageFolder.GROUP_ADMIN_BILL);

				// Store the returning column names and their corresponding values
				HashMap<String, String> da = doc.getDocumentAttributes();
				groupAdminBill.setDate(this.trim(da.get(DocumentArchiveServiceRemoteBean.DATE)));
				groupAdminBill.setDescription(this.trim(da.get(DocumentArchiveServiceRemoteBean.DESCRIPTION)));
				groupAdminBill.setGroupNumber(this.trim(da.get(DocumentArchiveServiceRemoteBean.GROUP_NUMBER)));
				groupAdminBill.setPostingDate(this.trim(da.get(DocumentArchiveServiceRemoteBean.POSTING_DATE)));
				groupAdminBill.setReportId(this.trim(da.get(DocumentArchiveServiceRemoteBean.REPORT_ID)));
				groupAdminBill.setReportIdDesc(this.trim(da.get(DocumentArchiveServiceRemoteBean.REPORT_ID_DESC)));

				// Add the groupAdminBill object to the list
				listToReturn.add(groupAdminBill);

			}// End of for(DocumentDTO doc : documentList)
		} else {

			// Empty list, throw exception
			throw new DocumentNotFoundException(DocumentArchiveServiceRemoteBean.DNFE_MESSAGE);
		}// End of if(documentList.size() > 0)

		// Return the list of remit objects
		return listToReturn;
	}// End of getGroupAdminBillList method

	
	/**
	 * <p>getGroupAdminDentalCardList.</p>
	 *
	 * @param groupAdminId a {@link com.bcbssc.commapi.model.common.GroupAdminId} object.
	 * @param dateFrom a {@link java.util.Date} object.
	 * @param dateTo a {@link java.util.Date} object.
	 * @return a {@link java.util.List} object.
	 * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if any.
	 * @throws com.bcbssc.commapi.model.common.APIException if any.
	 */
	public List<GroupAdminCorbelDocument> getGroupAdminDentalCardList(GroupAdminId groupAdminId, Date dateFrom, Date dateTo)
    throws DocumentNotFoundException, APIException
  {
    List<GroupAdminCorbelDocument> listToReturn = new ArrayList<GroupAdminCorbelDocument>();

    List<DocumentSearchKey> docSearchKeyList = new ArrayList<DocumentSearchKey>();

    int searchCriteriaCount = 0;
    
    String groupNumber = null;
    if (groupAdminId != null)
    {
      groupNumber = groupAdminId.getGroupAdminIdentifier();
    }
    
    if (isNotNullAndNotEmpty(groupNumber)) {
      DocumentSearchKey dsk1 = new DocumentSearchKey();
      dsk1.setKeyName(DocumentArchiveServiceRemoteBean.GROUP_NUMBER);
      dsk1.setKeyValue(groupNumber);
      dsk1.setOperator(DocumentSearchKeyOperator.LIKE);
      docSearchKeyList.add(dsk1);
      searchCriteriaCount++;

      if (logger.isDebugEnabled()) {
        logger.debug("Added GROUP NUMBER: " + groupNumber);
      }
    }

    String dentalCardId = null;
    if (groupAdminId != null)
    {
      dentalCardId = groupAdminId.getDentalCardId();
      
      logger.debug("dentalCardId: " + dentalCardId);
    }
    
    if (isNotNullAndNotEmpty(dentalCardId)) {
      DocumentSearchKey dsk2 = new DocumentSearchKey();
      dsk2.setKeyName(DocumentArchiveServiceRemoteBean.DENTAL_CARD_ID);
      dsk2.setKeyValue(dentalCardId);
      dsk2.setOperator(DocumentSearchKeyOperator.LIKE);
      docSearchKeyList.add(dsk2);
      searchCriteriaCount++;

      if (logger.isDebugEnabled()) {
        logger.debug("Added CARD ID: " + dentalCardId);
      }
    }

    DocumentSearchCriteria dsc = new DocumentSearchCriteria();
    dsc.setImageFolder(ImageFolder.GROUP_ADMIN_DENTAL_CARD);
    dsc.setOrSearchCriteria(false);
    dsc.setSearchBeginDate(dateFrom);
    dsc.setSearchEndDate(dateTo);
    dsc.setSearchConditions(docSearchKeyList);
  

    List<DocumentDTO> documentList = null;

    try
    {
      documentList = new DocumentRetrieveDAOImpl().getDocumentList(dsc);
    } catch (DAOException e) {
      throw new APIException(e);
    }

    if (documentList.size() > 0)
    {
      for (DocumentDTO doc : documentList)
      {
        GroupAdminCorbelDocument groupAdminDentalCard = new GroupAdminCorbelDocument();

        groupAdminDentalCard.setDocType(doc.getDocumentType());
        groupAdminDentalCard.setMimeType(doc.getMimeType());
        groupAdminDentalCard.setDocId(doc.getDocId());
        groupAdminDentalCard.setImageFolderName(ImageFolder.GROUP_ADMIN_DENTAL_CARD);

        HashMap<String, String> da = doc.getDocumentAttributes();
        groupAdminDentalCard.setEffectiveDate(trim((String)da.get(DocumentArchiveServiceRemoteBean.EFFECTIVE_DATE)));
        groupAdminDentalCard.setDescription(trim((String)da.get(DocumentArchiveServiceRemoteBean.DESCRIPTION)));
        groupAdminDentalCard.setGroupNumber(trim((String)da.get(DocumentArchiveServiceRemoteBean.GROUP_NUMBER)));
        groupAdminDentalCard.setPostingDate(trim((String)da.get(DocumentArchiveServiceRemoteBean.POSTING_DATE)));
        groupAdminDentalCard.setReportId(trim(formatReportId((String)da.get(DocumentArchiveServiceRemoteBean.REPORT_ID))));
        groupAdminDentalCard.setReportIdDesc(trim((String)da.get(DocumentArchiveServiceRemoteBean.REPORT_ID_DESC)));
        groupAdminDentalCard.setDentalCardId(trim((String)da.get(DocumentArchiveServiceRemoteBean.DENTAL_CARD_ID)));
     
        listToReturn.add(groupAdminDentalCard);
      }

    }
    else
    {
      throw new DocumentNotFoundException("Empty list was returned.");
    }

    return listToReturn;
  }
	
	
	 /**
	  * <p>getGroupAdminCertList.</p>
	  *
	  * @param groupAdminId a {@link com.bcbssc.commapi.model.common.GroupAdminId} object.
	  * @param dateFrom a {@link java.util.Date} object.
	  * @param dateTo a {@link java.util.Date} object.
	  * @return a {@link java.util.List} object.
	  * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if any.
	  * @throws com.bcbssc.commapi.model.common.APIException if any.
	  */
	 public List<GroupAdminCorbelDocument> getGroupAdminCertList(GroupAdminId groupAdminId, Date dateFrom, Date dateTo)
	    throws DocumentNotFoundException, APIException
	  {
	    List<GroupAdminCorbelDocument> listToReturn = new ArrayList<GroupAdminCorbelDocument>();

	    List<DocumentSearchKey> docSearchKeyList = new ArrayList<DocumentSearchKey>();

	    int searchCriteriaCount = 0;
	   
	    String groupNumber = null;
	    if (groupAdminId != null)
	    {
	      groupNumber = groupAdminId.getGroupAdminIdentifier();
	    }
	    
	    if (isNotNullAndNotEmpty(groupNumber)) {
	      DocumentSearchKey dsk1 = new DocumentSearchKey();
	      dsk1.setKeyName(DocumentArchiveServiceRemoteBean.GROUP_NUMBER);
	      dsk1.setKeyValue(groupNumber);
	      dsk1.setOperator(DocumentSearchKeyOperator.LIKE);
	      docSearchKeyList.add(dsk1);
	      searchCriteriaCount++;

	      if (logger.isDebugEnabled()) {
	        logger.debug("Added GROUP NUMBER: " + groupNumber);
	      }
	    }

	    String certId = null;
	    if (groupAdminId != null)
	    {
	      certId = groupAdminId.getCertId();
	    }
	    
	    if (isNotNullAndNotEmpty(certId)) {
	      DocumentSearchKey dsk2 = new DocumentSearchKey();
	      dsk2.setKeyName(DocumentArchiveServiceRemoteBean.CERT_ID);
	      dsk2.setKeyValue(certId);
	      dsk2.setOperator(DocumentSearchKeyOperator.LIKE);
	      docSearchKeyList.add(dsk2);
	      searchCriteriaCount++;

	      if (logger.isDebugEnabled()) {
	        logger.debug("Added CERT ID: " + certId);
	      }
	    }

	    DocumentSearchCriteria dsc = new DocumentSearchCriteria();
	    dsc.setImageFolder(ImageFolder.GROUP_ADMIN_CERT);
	    dsc.setOrSearchCriteria(false);
	    dsc.setSearchBeginDate(dateFrom);
	    dsc.setSearchEndDate(dateTo);
	    dsc.setSearchConditions(docSearchKeyList);

	    List<DocumentDTO> documentList = null;

	    try
	    {
	      documentList = new DocumentRetrieveDAOImpl().getDocumentList(dsc);
	    } catch (DAOException e) {
	      throw new APIException(e);
	    }

	    if (documentList.size() > 0)
	    {
	      for (DocumentDTO doc : documentList)
	      {
	    	GroupAdminCorbelDocument groupAdminCert = new GroupAdminCorbelDocument();
	    	groupAdminCert.setDocType(doc.getDocumentType());
	        groupAdminCert.setMimeType(doc.getMimeType());
	        groupAdminCert.setDocId(doc.getDocId());
	        groupAdminCert.setImageFolderName(ImageFolder.GROUP_ADMIN_CERT);

	        HashMap<String, String> da = doc.getDocumentAttributes();
	        groupAdminCert.setEffectiveDate(trim((String)da.get(DocumentArchiveServiceRemoteBean.EFFECTIVE_DATE)));
	        groupAdminCert.setDescription(trim((String)da.get(DocumentArchiveServiceRemoteBean.DESCRIPTION)));
	        groupAdminCert.setGroupNumber(trim((String)da.get(DocumentArchiveServiceRemoteBean.GROUP_NUMBER)));
	        groupAdminCert.setPostingDate(trim((String)da.get(DocumentArchiveServiceRemoteBean.POSTING_DATE)));
	        groupAdminCert.setReportId(trim(formatReportId((String)da.get(DocumentArchiveServiceRemoteBean.REPORT_ID))));
	        groupAdminCert.setReportIdDesc(trim((String)da.get(DocumentArchiveServiceRemoteBean.REPORT_ID_DESC)));

	        listToReturn.add(groupAdminCert);
	      }

	    }
	    else
	    {
	      throw new DocumentNotFoundException("Empty list was returned.");
	    }

	    return listToReturn;
	  }
	
	
	/**
	 * Get a document list based on the dates and group admin id.
	 *
	 * @param groupAdminId a {@link com.bcbssc.commapi.model.common.GroupAdminId} object.
	 * @param dateFrom a {@link java.util.Date} object.
	 * @param dateTo a {@link java.util.Date} object.
	 * @return returns a list of {@link GroupAdminCorbelDocument} objects.
	 * @throws com.bcbssc.commapi.model.common.DocumentNotFoundException if there is an exception.
	 * @throws com.bcbssc.commapi.model.common.APIException if there is an exception.
	 */
	public ArrayList<GroupAdminCorbelDocument> getGroupAdminPolicyList(GroupAdminId groupAdminId, Date dateFrom, Date dateTo)
    throws DocumentNotFoundException, APIException
  {
    ArrayList<GroupAdminCorbelDocument> listToReturn = new ArrayList<GroupAdminCorbelDocument>();

    ArrayList<DocumentSearchKey> docSearchKeyList = new ArrayList<DocumentSearchKey>();

    int searchCriteriaCount = 0;

    String groupNumber = null;
    if (groupAdminId != null)
    {
      groupNumber = groupAdminId.getGroupAdminIdentifier();
    }
    
    if (isNotNullAndNotEmpty(groupNumber)) {
      DocumentSearchKey dsk1 = new DocumentSearchKey();
      dsk1.setKeyName(DocumentArchiveServiceRemoteBean.GROUP_NUMBER);
      dsk1.setKeyValue(groupNumber);
      dsk1.setOperator(DocumentSearchKeyOperator.LIKE);
      docSearchKeyList.add(dsk1);
      searchCriteriaCount++;

      if (logger.isDebugEnabled()) {
        logger.debug("Added GROUP NUMBER: " + groupNumber);
      }
    }

    DocumentSearchCriteria dsc = new DocumentSearchCriteria();
    dsc.setImageFolder(ImageFolder.GROUP_ADMIN_POLICY);
    dsc.setOrSearchCriteria(false);
    dsc.setSearchBeginDate(dateFrom);
    dsc.setSearchEndDate(dateTo);
    dsc.setSearchConditions(docSearchKeyList);

    List<DocumentDTO> documentList = null;

    try
    {
      documentList = new DocumentRetrieveDAOImpl().getDocumentList(dsc);
    } catch (DAOException e) {
      throw new APIException(e);
    }

    if (documentList.size() > 0)
    {
      for (DocumentDTO doc : documentList)
      {
        GroupAdminCorbelDocument groupAdminPolicy = new GroupAdminCorbelDocument();

        groupAdminPolicy.setDocType(doc.getDocumentType());
        groupAdminPolicy.setMimeType(doc.getMimeType());
        groupAdminPolicy.setDocId(doc.getDocId());
        groupAdminPolicy.setImageFolderName(ImageFolder.GROUP_ADMIN_POLICY);

        HashMap<String, String> da = doc.getDocumentAttributes();
        groupAdminPolicy.setEffectiveDate(trim((String)da.get(DocumentArchiveServiceRemoteBean.EFFECTIVE_DATE)));
        groupAdminPolicy.setDescription(trim((String)da.get(DocumentArchiveServiceRemoteBean.DESCRIPTION)));
        groupAdminPolicy.setGroupNumber(trim((String)da.get(DocumentArchiveServiceRemoteBean.GROUP_NUMBER)));
        groupAdminPolicy.setPostingDate(trim((String)da.get(DocumentArchiveServiceRemoteBean.POSTING_DATE)));
        groupAdminPolicy.setReportId(trim(formatReportId((String)da.get(DocumentArchiveServiceRemoteBean.REPORT_ID))));
        groupAdminPolicy.setReportIdDesc(formattedReportDescriptin(trim((String)da.get(DocumentArchiveServiceRemoteBean.REPORT_ID_DESC))));

        listToReturn.add(groupAdminPolicy);
      }

    }
    else
    {
      throw new DocumentNotFoundException("Empty list was returned.");
    }

    return listToReturn;
  }

	
	
	/**
	 * {@inheritDoc}
	 *
	 * Get the requested remit document.
	 */
	public Document getRemit(Remit remit)
            throws DocumentNotFoundException, APIException {

		// Return the document object
		return this.getDocument(remit.getImageFolderName(), remit.getDocId());
	}// End of getRemit method

	/**
	 * {@inheritDoc}
	 *
	 * Get a document list based on the dates, provider information and folder name.
	 */
	public List<Remit> getRemitList(ProviderId provider,
            ImageFolder remitFolderName, Date dateFrom, Date dateTo)
			throws DocumentNotFoundException, APIException {

		// Create return List<Remit> object
		List<Remit> listToReturn = new ArrayList<Remit>();

		// Create and populate DocumentSearchKey List object
		List<DocumentSearchKey> dskl= new ArrayList<DocumentSearchKey>();
		int searchCriteriaCount = 0;

		// Add providerId if it was sent
		String providerId = null;
		if(provider != null) {
			providerId = provider.getFederalTaxIdNumber();
		}// End of if(provider != null)
		if(this.isNotNullAndNotEmpty(providerId)){
			DocumentSearchKey dsk1 = new DocumentSearchKey();
			dsk1.setKeyName(provider.getProviderNumberKey());
			dsk1.setKeyValue(providerId);
			dsk1.setOperator(DocumentSearchKeyOperator.LIKE);
			dskl.add(dsk1);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + provider.getProviderNumberKey() + DocumentArchiveServiceRemoteBean.COLON_SPACE + providerId);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of if(this.isNotNullAndNotEmpty(providerId))

		// Add npi if it was sent
		String npi = null;
		if(provider != null) {
			npi = provider.getNationalProviderIdentifier();
		}// End of if(provider != null)
		if(this.isNotNullAndNotEmpty(npi)){
			DocumentSearchKey dsk2 = new DocumentSearchKey();
			dsk2.setKeyName(DocumentArchiveServiceRemoteBean.NPI);
			dsk2.setKeyValue(npi);
			dsk2.setOperator(DocumentSearchKeyOperator.LIKE);
			dskl.add(dsk2);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.NPI + DocumentArchiveServiceRemoteBean.COLON_SPACE + npi);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of if(this.isNotNullAndNotEmpty(npi))

	    // Log the number of search criteria objects added
		if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
		    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + searchCriteriaCount + DocumentArchiveServiceRemoteBean.SEARCH_CRITERIA_OBJECTS);
		}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())

		// Create and populate DocumentSearchCriteria object
		DocumentSearchCriteria dsc = new DocumentSearchCriteria();
		dsc.setImageFolder(remitFolderName);
		dsc.setOrSearchCriteria(FALSE);
		dsc.setSearchBeginDate(dateFrom);
		dsc.setSearchEndDate(dateTo);
		dsc.setSearchConditions(dskl);


		// Create the document list object
		List<DocumentDTO> documentList = null;

		try {
			// Call getDocumentList() of DocumentRetrieveDAOBean
			documentList = (new DocumentRetrieveDAOImpl()).getDocumentList(dsc);
		} catch (DAOException e) {
			throw new APIException(e);
		}// End of try-catch

		// Check list contains at least one object
		if(documentList.size() > 0) {

			// Populate return list
			for(DocumentDTO doc : documentList) {

				// Create and initialize a remit object
				Remit remit = new Remit();

				// Store the returning doc type, mime type,
				// doc id, and the image folder name
				remit.setDocType(doc.getDocumentType());
				remit.setMimeType(doc.getMimeType());
				remit.setDocId(doc.getDocId());
				remit.setImageFolderName(remitFolderName);

				// Store the returning column names and their corresponding values
				HashMap<String, String> da = doc.getDocumentAttributes();
				remit.setReportId(this.trim(da.get(DocumentArchiveServiceRemoteBean.REPORT_ID)));
				remit.setDescriptive(this.trim(da.get(DocumentArchiveServiceRemoteBean.DESCRIPTIVE)));
				remit.setRegionId(this.trim(da.get(DocumentArchiveServiceRemoteBean.REGION_ID)));
				remit.setPostingDate(this.trim(da.get(DocumentArchiveServiceRemoteBean.POSTING_DATE)));
				remit.setReportIdDesc(this.trim(da.get(DocumentArchiveServiceRemoteBean.REPORT_ID_DESC)));
				remit.setNPI(this.trim(da.get(DocumentArchiveServiceRemoteBean.NPI)));
				remit.setProviderNo(this.trim(da.get(provider.getProviderNumberKey())));
				remit.setCheckDate(this.trim(da.get(DocumentArchiveServiceRemoteBean.CHECK_DATE)));

				// Add the summaryEOB object to the list
				listToReturn.add(remit);

			}// End of for(DocumentDTO doc : documentList)
		} else {

			// Empty list, throw exception
			throw new DocumentNotFoundException(DocumentArchiveServiceRemoteBean.DNFE_MESSAGE);
		}// End of if(documentList.size() > 0)

		// Return the list of remit objects
		return listToReturn;
	}// End of getRemitList method

	/**
	 * {@inheritDoc}
	 *
	 * Get the requested Summary EOB document.
	 */
	public Document getSummaryExplanationOfBenefits(SummaryEOB summaryEOB)
			throws DocumentNotFoundException, APIException {

		// Return the document object
		return this.getDocument(summaryEOB.getImageFolderName(), summaryEOB.getDocId());
	}// End of getSummaryExplanationOfBenefits method

	/**
	 * {@inheritDoc}
	 *
	 * Get a document list based on the dates and subscriber information.
	 */
	public List<SummaryEOB> getSummaryExplanationOfBenefitsList(
			SubscriberId subscriber, Date dateFrom, Date dateTo)
			throws DocumentNotFoundException, APIException {

		// Create return List<SummaryEOB> object
		List<SummaryEOB> listToReturn = new ArrayList<SummaryEOB>();

		// Create and initialize DocumentSearchKey List object
		List<DocumentSearchKey> dskl= new ArrayList<DocumentSearchKey>();

		// Create and initialize searchCriteriaCount primitive int
		int searchCriteriaCount = 0;

		// Add subscriberId if it was sent
		String subscriberId = null;
		if(subscriber != null) {
			subscriberId = subscriber.getMemberNumber();
		}// End of if(subscriber != null)
		if(this.isNotNullAndNotEmpty(subscriberId)){
			DocumentSearchKey dsk1 = new DocumentSearchKey();
			dsk1.setKeyName(DocumentArchiveServiceRemoteBean.SUBSCRIBER_ID);
			dsk1.setKeyValue(subscriberId);
			dsk1.setOperator(DocumentSearchKeyOperator.EQUAL);
			dskl.add(dsk1);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.SUBSCRIBER_ID + DocumentArchiveServiceRemoteBean.COLON_SPACE + subscriberId);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of if(!((subscriberId == null) || (EMPTY_STRING.equals(subscriberId))))

		// Add idCardNumber if it was sent
		String idCardNumber = null;
		if(subscriber != null) {
			idCardNumber = subscriber.getIdCardNumber();
		}// End of if(subscriber != null)
		if(this.isNotNullAndNotEmpty(idCardNumber)){
			DocumentSearchKey dsk2 = new DocumentSearchKey();
			dsk2.setKeyName(DocumentArchiveServiceRemoteBean.ID_CARD_NO);
			dsk2.setKeyValue(idCardNumber);
			dsk2.setOperator(DocumentSearchKeyOperator.EQUAL);
			dskl.add(dsk2);
			searchCriteriaCount++;
		    // Log the search criteria object added
			if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
			    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + DocumentArchiveServiceRemoteBean.ID_CARD_NO + DocumentArchiveServiceRemoteBean.COLON_SPACE + idCardNumber);
			}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())
		}// End of if(this.isNotNullAndNotEmpty(idCardNumber))

	    // Log the number of search criteria objects added
		if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled()) {
		    DocumentArchiveServiceRemoteBean.logger.debug(DocumentArchiveServiceRemoteBean.ADDED_SPACE + searchCriteriaCount + DocumentArchiveServiceRemoteBean.SEARCH_CRITERIA_OBJECTS);
		}// End of if(DocumentArchiveServiceRemoteBean.logger.isDebugEnabled())

		// Create and populate DocumentSearchCriteria object
		DocumentSearchCriteria dsc = new DocumentSearchCriteria();
		dsc.setImageFolder(ImageFolder.WEB_SUMMARYEOB);
		dsc.setOrSearchCriteria(DocumentArchiveServiceRemoteBean.FALSE);
		dsc.setSearchBeginDate(dateFrom);
		dsc.setSearchEndDate(dateTo);
		dsc.setSearchConditions(dskl);

		// Create the document list object
		List<DocumentDTO> documentList = null;
		try {
			// Call getDocumentList() of DocumentRetrieveDAOBean
			documentList = (new DocumentRetrieveDAOImpl()).getDocumentList(dsc);
		} catch (DAOException e) {
			throw new APIException(e);
		}// End of try-catch

		// Check list contains at least one object
		if(documentList.size() > 0) {

			// Populate return list
			for(DocumentDTO doc : documentList) {

				// Create and initialize a summaryEOB object
				SummaryEOB summaryEOB = new SummaryEOB();

				// Store the returning doc type, mime type,
				// doc id, and the image folder name
				summaryEOB.setDocType(doc.getDocumentType());
				summaryEOB.setMimeType(doc.getMimeType());
				summaryEOB.setDocId(doc.getDocId());
				summaryEOB.setImageFolderName(ImageFolder.WEB_SUMMARYEOB);

				// Store the returning column names and their corresponding values
				HashMap<String, String> da = doc.getDocumentAttributes();
				summaryEOB.setPostingDate(this.trim(da.get(DocumentArchiveServiceRemoteBean.POSTING_DATE)));
				summaryEOB.setReportId(this.trim(da.get(DocumentArchiveServiceRemoteBean.REPORT_ID)));
				summaryEOB.setSubscriberId(this.trim(da.get(DocumentArchiveServiceRemoteBean.SUBSCRIBER_ID)));
				summaryEOB.setIdCardNo(da.get(this.trim(DocumentArchiveServiceRemoteBean.ID_CARD_NO)));
				summaryEOB.setStatementStartDate(this.trim(da.get(DocumentArchiveServiceRemoteBean.STATEMENT_START)));
				summaryEOB.setStatementEndDate(this.trim(da.get(DocumentArchiveServiceRemoteBean.STATEMENT_END)));
				summaryEOB.setReportIdDesc(this.trim(da.get(DocumentArchiveServiceRemoteBean.REPORT_ID_DESC)));

				// Add the summaryEOB object to the list
				listToReturn.add(summaryEOB);
			}// End of for(DocumentDTO doc : documentList)

		} else {

			// Empty list, throw exception
			throw new DocumentNotFoundException(DocumentArchiveServiceRemoteBean.DNFE_MESSAGE);
		}// End of if(documentList.size() > 0)

		// Return the list of remit objects
		return listToReturn;
	}// End of getSummaryExplanationOfBenefitsList method

	private boolean isNotNullAndNotEmpty(String valueToCheck) {

		// Create initial return value as a boolean equal to true
		boolean valueToReturn = true;

		// Check if null obejct or empty string
		if((valueToCheck == null) ||
           (DocumentArchiveServiceRemoteBean.EMPTY_STRING.equals(valueToCheck))) {

			// Set return value to false
			valueToReturn = false;
		}// End of if(valueToCheck)

		// Return the trimmed value or initial empty string
		return valueToReturn;
	}// End of isNotNullAndNotEmpty method

	private String trim(String valueToCheck) {

		// Create initial return value as an empty string
		String valueToReturn = DocumentArchiveServiceRemoteBean.EMPTY_STRING;

		// Trim only if object is not null
		if(valueToCheck != null) {

			// Set trimmed value to return
			valueToReturn = valueToCheck.trim();
		}// End of if(valueToCheck != null)

		// Return the trimmed value or initial empty string
		return valueToReturn;
	}// End of trim method

	private Document getDocument(ImageFolder folderName, String docId)
            throws APIException, DocumentNotFoundException {

		// Create return document object
		Document doc = null;

		try {
			// Obtain the requested document
			doc = (new DocumentRetrieveDAOImpl()).getDocumentDetail(folderName, docId);
		} catch (DAOException e) {
			throw new APIException(e);
		}// End of try-catch

		// Return the document object
		return doc;
	}// End of getDocument method
	
	
	
	
	private String 	formatReportId(String rptId){
		String reportId = rptId;
		if(reportId.indexOf("-") != -1){
			String[] tempReportId = rptId.split("-");
			reportId = tempReportId[0];
		}
			
		return reportId;
		
	}
	
private String formattedReportDescriptin(String reportIdDesc){
		
		String[] tempDesc = reportIdDesc.split(" ");
		StringBuffer sb = new StringBuffer();
		for(int i=0;i<tempDesc.length;i++){
			
			if(i >1){
			sb.append(tempDesc[i]);sb.append(" ");
			}
		}
		
		return sb.toString();
	}
	
}// End of DocumentArchiveServiceRemoteBean class
