package com.bcbssc.services.daoimpl.accesscoderequest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import javax.xml.rpc.ServiceException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.commapi.model.common.DAOException;
import com.bcbssc.services.dao.accesscoderequest.AccessCodeRequestDAO;
import com.bcbssc.services.accesscoderequest.AccessCodeRequestInput;
import com.bcbssc.services.accesscoderequest.AccessCodeRequestOutput;
import com.bcbssc.services.accesscoderequest.AccessCodeRequestService;
import com.bcbssc.services.accesscoderequest.AccessCodeRequestServiceService;
import com.bcbssc.services.utils.BaseServicesDAO;
import com.bcbssc.wsutils.WebServiceConsumerCallback;
import com.bcbssc.wsutils.WebServiceConsumerTemplate;
import com.bcbssc.wsutils.exception.BcbsscDetailedSoapFaultException;

/**
 * <p>ServicesAccessCodeRequestDAOImpl class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class ServicesAccessCodeRequestDAOImpl extends BaseServicesDAO implements AccessCodeRequestDAO,WebServiceConsumerCallback {

	private static final Log log = LogFactory.getLog(ServicesAccessCodeRequestDAOImpl.class);
	
	/** Constant <code>WEBPACK_DATE_FORMAT="yyyy-MM-dd"</code> */
	public static final String WEBPACK_DATE_FORMAT = "yyyy-MM-dd";
	/** The date format used by the mainframe. */
	private final SimpleDateFormat mfDateFormat = new SimpleDateFormat(WEBPACK_DATE_FORMAT);
	
	/** The date format used in the application. */
	private final SimpleDateFormat appDateFormat = new SimpleDateFormat(WEBPACK_DATE_FORMAT);
 
	private static final String SERVICE_NAME = "AccessCodeRequest";
	private static final boolean isThisSOAExpressService = true;


	/** {@inheritDoc} */
	@Override
	public String requestNewAccessCode(HashMap<String, String> userDTO) throws DAOException
			 {
		// TODO Auto-generated method stub
		
		String accessCodeGenerated = null;
		try {

			WebServiceConsumerTemplate template 	= new WebServiceConsumerTemplate();
			AccessCodeRequestOutput outPut = (AccessCodeRequestOutput) template.consumeService(userDTO, this);
			accessCodeGenerated = outPut.getAccessCodeGenerated();
        }
		catch (BcbsscDetailedSoapFaultException soapFaultException) {
			log.error("Error executing ServicesAccessCodeRequest " + soapFaultException.getFaultString(), soapFaultException);
			throw new DAOException("Error executing ServicesAccessCodeRequest " + soapFaultException.getFaultString());
		}		
		catch(Exception exception) {
        	log.error("ServicesAccessCodeRequest() failed <> ", exception);
        	throw new DAOException("ServicesAccessCodeRequest failed <> " + exception.getMessage());            
        }
	    
		if(log.isDebugEnabled()) {
			log.debug("ServicesAccessCodeRequest response bean: " + accessCodeGenerated);
		}
		
		return accessCodeGenerated;
	}

	/** {@inheritDoc} */
	@Override
	public Object getService() {
		AccessCodeRequestService serviceToReturn = null;

		try {
			AccessCodeRequestServiceService serviceToLoadHandlers = (AccessCodeRequestServiceService)getServiceWithHandlersLoaded(AccessCodeRequestServiceService.class, SERVICE_NAME , isThisSOAExpressService);
			serviceToReturn = serviceToLoadHandlers.getAccessCodeRequest();
		}catch(ServiceException sex) {
			log.error("serviceToInvoke was not configured with Handlers" , sex);
			
		}
		return serviceToReturn;
	}

	/** {@inheritDoc} */
	@Override
	public Object invokeService(Object serviceInput, Object serviceClient) throws Exception {
		AccessCodeRequestService service 	= (AccessCodeRequestService) (serviceClient);
		AccessCodeRequestOutput result		= service.getAccessCode((AccessCodeRequestInput) serviceInput);
    	
    	return result; 
	}

	/** {@inheritDoc} */
	@SuppressWarnings("unchecked")
	@Override
	public Object mapInput(Object requestPassed) {
		// TODO Auto-generated method stub
		
		HashMap<String, String> userDTO	= (HashMap<String, String>) requestPassed;
    	
    	AccessCodeRequestInput input	= new AccessCodeRequestInput();
    	input.setRpn(userDTO.get("RPN"));
    	input.setApplicationId(userDTO.get("APPLICATIONID"));
    
    	input.setPlanCode("885");
    	
    	input.setAddressLine1(userDTO.get("STREET"));
		input.setAddressLine2(userDTO.get("ADDRESSLINE2"));
		
		
		input.setCity(userDTO.get("CITY"));
		input.setCountryCode(userDTO.get("COUNTRY"));

		Date dob = null;
		try {
			dob = this.appDateFormat.parse(userDTO.get("DATEOFBIRTH"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		input.setDateOfBirth(this.mfDateFormat.format(dob));

		input.setPhoneExtension(userDTO.get("TELEPHONEEXT"));
		input.setFaxNumber(userDTO.get("FAX"));
		input.setFirstName(userDTO.get("GIVENNAME"));
		input.setPrimaryGroupName(userDTO.get("GROUPNAME"));
		input.setPrimaryGroupNumber(userDTO.get("GROUPNUMBERSTRIPPED"));
		input.setLastName(userDTO.get("LASTNAME"));
		input.setMiddleInitial(userDTO.get("MIDDLEINI"));
		input.setPhoneNumber(userDTO.get("TELEPHONENUMBER"));
		input.setLastSixDigitsOfSsn(userDTO.get("LAST6SSN"));
		input.setState(userDTO.get("STATE"));
		input.setNameSuffix(userDTO.get("SUFFIX"));
		input.setCity(userDTO.get("CITY"));
		input.setCountryCode(userDTO.get("COUNTRY"));
		input.setAddressLine1(userDTO.get("STREET"));
		input.setAddressLine2(userDTO.get("ADDRESSLINE2"));
		
		
		
        
		String postalCode = userDTO.get("POSTALCODE");
		if (postalCode.length() <= 5) {
			input.setZipCode(postalCode);
			input.setZipCodePlus4("");
		} else {
			input.setZipCode(postalCode.substring(0, 5));
			input.setZipCodePlus4(postalCode.substring(5));
		}

		

		return input;
	}

	/** {@inheritDoc} */
	@Override
	public Object mapOutput(Object serviceOutput) {
		// TODO Auto-generated method stub
		return serviceOutput;
	}

}
