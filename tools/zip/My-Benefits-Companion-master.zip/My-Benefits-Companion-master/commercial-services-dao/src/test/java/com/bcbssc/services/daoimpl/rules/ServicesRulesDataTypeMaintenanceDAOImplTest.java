package com.bcbssc.services.daoimpl.rules;

//import javax.security.auth.Subject;import org.apache.log4j.Logger;
/*
import org.jmock.Mock;
import org.jmock.cglib.MockObjectTestCase; */
/**
* Service impl test for ServicesRulesDataTypeMaintenanceDAOImplTest
** <pre>
* [PVCS]
* $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-services-dao/src/test/java/com/bcbssc/services/daoimpl/rules/ServicesRulesDataTypeMaintenanceDAOImplTest.java_v  $
* $Workfile:   ServicesRulesDataTypeMaintenanceDAOImplTest.java  $
* $Revision:   1.1  $
* $Date:   Nov 30 2009 14:06:16  $
* $Modtime:   Nov 30 2009 14:05:00  $
* </pre>
* @author $Author:   EN80  $
*/
public class ServicesRulesDataTypeMaintenanceDAOImplTest /*extends MockObjectTestCase */{
/*
    private Mock mockService;
    private Mock mockServiceManager;
    private Subject subject;
    private ServicesRulesDataTypeMaintenanceDAOImpl rulesDAO; */
    
    //private static final Logger log = Logger.getLogger(ServicesRulesDataTypeMaintenanceDAOImplTest.class);
    protected void setUp() throws Exception {
    	/*
	mockService = mock(MaintainRulesDataTypeSoapBindingStub.class);
        registerToVerify(mockService);
        
        mockServiceManager = mock(ServiceClientManager.class);
        registerToVerify(mockServiceManager);
        
        BaseDiagnosticActionExecutor executor = new BaseDiagnosticActionExecutor();
        executor.setActionName("");
        
        ServiceExecutorTemplate template = new ServiceExecutorTemplate();
        template.setActionExecutor(executor);
        
        rulesDAO = new ServicesRulesDataTypeMaintenanceDAOImpl();
        rulesDAO.setServiceManager((ServiceClientManager) mockServiceManager.proxy());
        rulesDAO.setExecutorTemplate(template);
        rulesDAO.setRegion("TESTREGION");
        rulesDAO.setServiceName("MaintainRulesDataType");
        rulesDAO.setTimeout("1000");
        
        Set principals = new HashSet();
        principals.add(new RacfIdPrincipal());
        principals.add(new RegionPrincipal());
        Set empty = new HashSet();
        Set credentials = new HashSet();
        credentials.add(new RacfPasswordCredential());
        subject = new Subject(false, principals, empty, credentials);
        
        SubjectUtils.setUserId(subject, RacfIdPrincipal.class, "TESTID");
        SubjectUtils.setPassword(subject, RacfPasswordCredential.class, "PASSWORD");
        SubjectUtils.setRegion(subject, "SUBJECTREGION"); */
    }
    

    public final void testPerformRulesDataTypeOperation() {
	   /*Stub[] results = new Stub[1];
        results[0] = returnValue((MaintainRulesDataTypeSoapBindingStub) mockService.proxy());
        Constraint[] input = new Constraint[2];
        input[0] = ANYTHING;
        input[1] = ANYTHING;
        
        mockServiceManager.expects(atLeastOnce()).method("getServiceInstance").with(input).will(onConsecutiveCalls(results));
        
        MaintainRulesDataTypeOutput output = new MaintainRulesDataTypeOutput();
        output.setServiceMessageCode("00000");  // comment this if you wantto fail
        output.setServiceMessage("Successful");
        output.setApplicationMessage("Successful");
        Stub[] results2 = new Stub[1];
        results2[0] = returnValue(output);
        Constraint[] input2 = new Constraint[1];
        input2[0] = ANYTHING;
        
        mockService.expects(atLeastOnce()).method("cgInvoke").with(input2).will(onConsecutiveCalls(results2));
        
        mockService.expects(atLeastOnce()).method("setTimeout").with(new Constraint[] {ANYTHING});
        
        final RulesDatatypeMaintenance serviceInput= new RulesDatatypeMaintenance();
        serviceInput.setUserSignOnId("LEXMEDCTR");
        serviceInput.setPlanCode("885");
        serviceInput.setRpn("001");
        serviceInput.setDataType("TEST");
        serviceInput.setUserSignOnId("testracf");
        serviceInput.setWebRacf("Dontcare");
        serviceInput.setTotalRecordCount("1");
		List ActionItems = new ArrayList();
		
		RulesDataTypeActionItem oneActionItem = new RulesDataTypeActionItem();
		oneActionItem.setActionCode("A");
		oneActionItem.setKeyFieldOne("SriniTest1");
		oneActionItem.setKeyFieldTwo("001");
		oneActionItem.setKeyFieldThree("1029292923");
		oneActionItem.setBeginDate("2009-10-01");
		oneActionItem.setTerminationDate("9900-12-31");
		oneActionItem.setDataFieldOne("OFFICE");		
		ActionItems.add(oneActionItem);
		
		oneActionItem = new RulesDataTypeActionItem();
		oneActionItem.setActionCode("A");
		oneActionItem.setKeyFieldOne("SriniTest2");
		oneActionItem.setKeyFieldTwo("001");
		oneActionItem.setKeyFieldThree("1029292923");
		oneActionItem.setBeginDate("2009-10-01");
		oneActionItem.setTerminationDate("9900-12-31");
		oneActionItem.setDataFieldOne("OFFICE");		
		ActionItems.add(oneActionItem);
		
		oneActionItem = new RulesDataTypeActionItem();
		oneActionItem.setActionCode("A");
		oneActionItem.setKeyFieldOne("SriniTest3");
		oneActionItem.setKeyFieldTwo("001");
		oneActionItem.setKeyFieldThree("1029292923");
		oneActionItem.setBeginDate("2009-10-01");
		oneActionItem.setTerminationDate("9900-12-31");
		oneActionItem.setDataFieldOne("OFFICE");		
		ActionItems.add(oneActionItem);
		
		oneActionItem = new RulesDataTypeActionItem();
		oneActionItem.setActionCode("A");
		oneActionItem.setKeyFieldOne("SriniTest4");
		oneActionItem.setKeyFieldTwo("001");
		oneActionItem.setKeyFieldThree("1029292923");
		oneActionItem.setBeginDate("2009-10-01");
		oneActionItem.setTerminationDate("9900-12-31");
		oneActionItem.setDataFieldOne("OFFICE");		
		ActionItems.add(oneActionItem);
		
		
		oneActionItem = new RulesDataTypeActionItem();
		oneActionItem.setActionCode("A");
		oneActionItem.setKeyFieldOne("SriniTest5");
		oneActionItem.setKeyFieldTwo("001");
		oneActionItem.setKeyFieldThree("1029292923");
		oneActionItem.setBeginDate("2009-10-01");
		oneActionItem.setTerminationDate("9900-12-31");
		oneActionItem.setDataFieldOne("OFFICE");		
		ActionItems.add(oneActionItem);
		
		serviceInput.setRulesDataTypeActionItems(ActionItems);
		
        
        RulesDatatypeMaintenanceResult result =  null;
        try {
        	result = (RulesDatatypeMaintenanceResult) SubjectUtils.runAsSubject(new PrivilegedExceptionAction() {

                 public Object run() throws Exception {
                     return rulesDAO.performRulesDataTypeOperation(serviceInput);
                 }
                 
             }, subject);
         } catch (Exception e) {
             log.error(e);
             fail("This should not have thrown an exception" + e );
         }       
         */
    	
       // assertTrue(true);
    }
         
     

}

