/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2008 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : ClaimEntryModuleConfiguration.java
 *
 * Created Date     : Jan 29, 2008
 *
 * Author           : Neena Musti (CF57).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Neena Musti (CF57)      Jan 29, 2007    Initial version for Configuration
 */

package com.bcbssc.configuration.beans;

import org.apache.log4j.Logger;

/**
 * <p>ClaimStatusInformBucketDetails class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class ClaimStatusInformBucketDetails extends InformBucketDetails {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6401842763271580412L;

	/** The log4j logger for this class */
	private static Logger log = Logger
			.getLogger(ClaimStatusInformBucketDetails.class);

	private String acsinformInfoType;

	private String acsinformCorpCd;

	private String acsinformCompanyCd;

	private String acsinformDivisionCd;

	private String acsinformDeptCd;

	private String acsinformEmplId;

	/**
	 * <p>Constructor for ClaimStatusInformBucketDetails.</p>
	 */
	public ClaimStatusInformBucketDetails() {
		super();
		if (ClaimStatusInformBucketDetails.log.isDebugEnabled()) {
			ClaimStatusInformBucketDetails.log
					.debug("Created ClaimStatusInformBucketDetails object.");
		}
	}

	/**
	 * Retreives the value of acsinformInfoType.
	 *
	 * @return Returns the acsinformInfoType.
	 */
	public String getAcsinformInfoType() {
		return this.acsinformInfoType;
	}

	/**
	 * Sets the value of acsinformInfoType.
	 *
	 * @param acsinformInfoType
	 *            The acsinformInfoType to set.
	 */
	public void setAcsinformInfoType(String acsinformInfoType) {
		this.acsinformInfoType = acsinformInfoType;
	}

	/**
	 * Retreives the value of acsinformCorpCd.
	 *
	 * @return Returns the acsinformCorpCd.
	 */
	public String getAcsinformCorpCd() {
		return this.acsinformCorpCd;
	}

	/**
	 * Sets the value of acsinformCorpCd.
	 *
	 * @param acsinformCorpCd
	 *            The acsinformCorpCd to set.
	 */
	public void setAcsinformCorpCd(String acsinformCorpCd) {
		this.acsinformCorpCd = acsinformCorpCd;
	}

	/**
	 * Retreives the value of acsinformCompanyCd.
	 *
	 * @return Returns the acsinformCompanyCd.
	 */
	public String getAcsinformCompanyCd() {
		return this.acsinformCompanyCd;
	}

	/**
	 * Sets the value of acsinformCompanyCd.
	 *
	 * @param acsinformCompanyCd
	 *            The acsinformCompanyCd to set.
	 */
	public void setAcsinformCompanyCd(String acsinformCompanyCd) {
		this.acsinformCompanyCd = acsinformCompanyCd;
	}

	/**
	 * Retreives the value of acsinformDivisionCd.
	 *
	 * @return Returns the acsinformDivisionCd.
	 */
	public String getAcsinformDivisionCd() {
		return this.acsinformDivisionCd;
	}

	/**
	 * Sets the value of acsinformDivisionCd.
	 *
	 * @param acsinformDivisionCd
	 *            The acsinformDivisionCd to set.
	 */
	public void setAcsinformDivisionCd(String acsinformDivisionCd) {
		this.acsinformDivisionCd = acsinformDivisionCd;
	}

	/**
	 * Retreives the value of acsinformDeptCd.
	 *
	 * @return Returns the acsinformDeptCd.
	 */
	public String getAcsinformDeptCd() {
		return this.acsinformDeptCd;
	}

	/**
	 * Sets the value of acsinformDeptCd.
	 *
	 * @param acsinformDeptCd
	 *            The acsinformDeptCd to set.
	 */
	public void setAcsinformDeptCd(String acsinformDeptCd) {
		this.acsinformDeptCd = acsinformDeptCd;
	}

	/**
	 * Retreives the value of acsinformEmplId.
	 *
	 * @return Returns the acsinformEmplId.
	 */
	public String getAcsinformEmplId() {
		return this.acsinformEmplId;
	}

	/**
	 * Sets the value of acsinformEmplId.
	 *
	 * @param acsinformEmplId
	 *            The acsinformEmplId to set.
	 */
	public void setAcsinformEmplId(String acsinformEmplId) {
		this.acsinformEmplId = acsinformEmplId;
	}

}
