/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2008 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : IdcardModuleConfiguration.java
 *
 * Created Date     : Jan 15, 2008
 *
 * Author           : Andrea Meyer (X62E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Andrea Meyer (X62E)   	Jan 15, 2008    Initial version for Configuration
 */

package com.bcbssc.configuration.beans;

import org.apache.log4j.Logger;

/**
 * <p>IdcardModuleConfiguration class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class IdcardModuleConfiguration extends ModuleConfiguration {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1790529446258656670L;

	/** The log4j logger for this class */
	private static Logger log = Logger
			.getLogger(IdcardModuleConfiguration.class);

	boolean sendAddressToInform;

	boolean checkVerified;

	boolean sendCompanyCodeTransferInform;

	boolean sendExtloc;

	String statusCode;

	String statusType;

	String requestReason;

	String mqFrom;

	/**
	 * <p>Constructor for IdcardModuleConfiguration.</p>
	 */
	public IdcardModuleConfiguration() {
		super();
		if (IdcardModuleConfiguration.log.isDebugEnabled()) {
			IdcardModuleConfiguration.log
					.debug("Created IdcardModuleConfiguration object.");
		}
	}

	/**
	 * <p>Getter for the field <code>mqFrom</code>.</p>
	 *
	 * @return the mqFrom
	 */
	public String getMqFrom() {
		return this.mqFrom;
	}

	/**
	 * <p>Setter for the field <code>mqFrom</code>.</p>
	 *
	 * @param mqFrom
	 *            the mqFrom to set
	 */
	public void setMqFrom(String mqFrom) {
		this.mqFrom = mqFrom;
	}

	/**
	 * <p>Getter for the field <code>sendAddressToInform</code>.</p>
	 *
	 * @return the sendAddressToInform
	 */
	public boolean getSendAddressToInform() {
		return this.sendAddressToInform;
	}

	/**
	 * <p>Setter for the field <code>sendAddressToInform</code>.</p>
	 *
	 * @param sendAddressToInform
	 *            the sendAddressToInform to set
	 */
	public void setSendAddressToInform(boolean sendAddressToInform) {
		this.sendAddressToInform = sendAddressToInform;
	}

	/**
	 * <p>toString.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String toString() {
		return super.toString();
	}

	/**
	 * <p>Getter for the field <code>checkVerified</code>.</p>
	 *
	 * @return the checkVerified
	 */
	public boolean getCheckVerified() {
		return this.checkVerified;
	}

	/**
	 * <p>Setter for the field <code>checkVerified</code>.</p>
	 *
	 * @param checkVerified
	 *            the checkVerified to set
	 */
	public void setCheckVerified(boolean checkVerified) {
		this.checkVerified = checkVerified;
	}

	/**
	 * <p>Getter for the field <code>statusCode</code>.</p>
	 *
	 * @return the statusCode
	 */
	public String getStatusCode() {
		return this.statusCode;
	}

	/**
	 * <p>Setter for the field <code>statusCode</code>.</p>
	 *
	 * @param statusCode
	 *            the statusCode to set
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * <p>Getter for the field <code>statusType</code>.</p>
	 *
	 * @return the statusType
	 */
	public String getStatusType() {
		return this.statusType;
	}

	/**
	 * <p>Setter for the field <code>statusType</code>.</p>
	 *
	 * @param statusType
	 *            the statusType to set
	 */
	public void setStatusType(String statusType) {
		this.statusType = statusType;
	}

	/**
	 * <p>Getter for the field <code>requestReason</code>.</p>
	 *
	 * @return the requestReason
	 */
	public String getRequestReason() {
		return this.requestReason;
	}

	/**
	 * <p>Setter for the field <code>requestReason</code>.</p>
	 *
	 * @param requestReason
	 *            the requestReason to set
	 */
	public void setRequestReason(String requestReason) {
		this.requestReason = requestReason;
	}

	/**
	 * <p>Getter for the field <code>sendExtloc</code>.</p>
	 *
	 * @return the sendExtloc
	 */
	public boolean getSendExtloc() {
		return this.sendExtloc;
	}

	/**
	 * <p>Setter for the field <code>sendExtloc</code>.</p>
	 *
	 * @param sendExtloc
	 *            the sendExtloc to set
	 */
	public void setSendExtloc(boolean sendExtloc) {
		this.sendExtloc = sendExtloc;
	}

	/**
	 * <p>Getter for the field <code>sendCompanyCodeTransferInform</code>.</p>
	 *
	 * @return the sendCompanyCodeTransferInform
	 */
	public boolean getSendCompanyCodeTransferInform() {
		return this.sendCompanyCodeTransferInform;
	}

	/**
	 * <p>Setter for the field <code>sendCompanyCodeTransferInform</code>.</p>
	 *
	 * @param sendCompanyCodeTransferInform
	 *            the sendCompanyCodeTransferInform to set
	 */
	public void setSendCompanyCodeTransferInform(
			boolean sendCompanyCodeTransferInform) {
		this.sendCompanyCodeTransferInform = sendCompanyCodeTransferInform;
	}

}
