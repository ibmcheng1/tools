/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2007 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : ConfigurationManager.java
 *
 * Created Date     : Sep 20, 2007
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Sep 20, 2007     Initial version for Configuration
 */

package com.bcbssc.configuration.services;

import com.bcbssc.configuration.ClientConfigurationException;
import com.bcbssc.configuration.beans.ClientConfiguration;
import com.bcbssc.configuration.beans.GlobalConfiguration;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

/**
 * This is the manager class for client configuration. This class is used to
 * retreive the configuration for a particular client. The class uses the
 * springs framework to load and parse the client configuration XML's and holds
 * the bean factory. When ever there is a need for the data specific to a client
 * the bean factory is used to retreive the client configuration data to the
 * client. This class is a singleton as we do not need multiple instances of
 * this class.
 *
 * @author Thiagu Chandrasekaran (X29E).
 * @version 1.0
 */
public class ClientConfigurationManager {

	private static final Logger log = Logger
			.getLogger(ClientConfigurationManager.class);

	private static final String DEFAULT_CONFIGURATION = "default";

	private static final String GLOBAL_SETTING = "globalSettings";

	private static ClientConfigurationManager configurationManager = null;

	private static final String CLIENT_CONFIGURATION_FILE = "clientConfiguration.xml";

	private BeanFactory beanFactory = null;

	/**
	 * Private constructor. Needed for Singleton.
	 * 
	 * @throws ClientConfigurationException if there is an exception.
	 */
	private ClientConfigurationManager() throws ClientConfigurationException {
		this.populateConfigurations();
		if (ClientConfigurationManager.log.isDebugEnabled()) {
			ClientConfigurationManager.log
					.debug("Created ClientConfigurationManager object.");
		}
	}

	/**
	 * Private constructor. Needed for Singleton.
	 *
	 * @return a {@link com.bcbssc.configuration.services.ClientConfigurationManager} object.
	 */
	public static ClientConfigurationManager getInstance() {

		if (ClientConfigurationManager.configurationManager == null) {
			try {
				ClientConfigurationManager.configurationManager = new ClientConfigurationManager();
			} catch (ClientConfigurationException configurationException) {
				configurationException.printStackTrace();
				ClientConfigurationManager.log.error(
						"Error creating the configuration manager instance",
						configurationException);
			}
		}

		return ClientConfigurationManager.configurationManager;
	}

	/**
	 * This method is used to retreive the global configuration. Global
	 * configurations are common across all client and are present in the
	 * globalconfiguration.xml. This method retreives the global configuration
	 * and copy the properties into another object and returns the other object.
	 * So this will not affect the source instance if the caller modified the
	 * returned object.
	 *
	 * @return a {@link com.bcbssc.configuration.beans.GlobalConfiguration} object.
	 */
	public GlobalConfiguration getGlobalConfiguration() {

		GlobalConfiguration globalConfiguration = new GlobalConfiguration();
		GlobalConfiguration sourceConfiguration = null;

		try {

			sourceConfiguration = (GlobalConfiguration) this.beanFactory
					.getBean(ClientConfigurationManager.GLOBAL_SETTING);
			BeanUtils.copyProperties(globalConfiguration, sourceConfiguration);
		} catch (Exception exception) {

			globalConfiguration = null;
			ClientConfigurationManager.log.error(
					"Error retreiving the global configuration", exception);
		}

		return globalConfiguration;
	}

	/**
	 * This method is used to retreive the client configuration. Client
	 * configurations are specific to clients and are present in the
	 * clientname.xml. This method retreives the client configuration for the
	 * specified client name and copies the properties into another object and
	 * returns the other object. So this will not affect the source instance if
	 * the caller modified the returned object.
	 *
	 * @param clientName a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.configuration.beans.ClientConfiguration} object.
	 */
	public ClientConfiguration getClientConfiguration(String clientName) {

		ClientConfiguration clientConfiguration = null;
		ClientConfiguration sourceConfiguration = null;

		try {

			clientConfiguration = new ClientConfiguration();

			if (StringUtils.isNotBlank(clientName)) {
				sourceConfiguration = (ClientConfiguration) this.beanFactory
						.getBean(clientName);
			}

			if (sourceConfiguration == null) {
				sourceConfiguration = (ClientConfiguration) this.beanFactory
						.getBean(ClientConfigurationManager.DEFAULT_CONFIGURATION);
				sourceConfiguration.setDefaultProfile(true);
			}

			BeanUtils.copyProperties(clientConfiguration, sourceConfiguration);
		} catch (Exception exception) {

			clientConfiguration = null;
			ClientConfigurationManager.log.error(
					"Error retreiving the configuration for the client name "
							+ clientName, exception);
		}

		return clientConfiguration;
	}

	/**
	 * Private method. This method loads the configuration xmls using spring
	 * framework.
	 * 
	 * @throws ClientConfigurationException
	 */
	private void populateConfigurations() throws ClientConfigurationException {

		try {

			ClassPathResource resource = new ClassPathResource(
					ClientConfigurationManager.CLIENT_CONFIGURATION_FILE);
			this.beanFactory = new XmlBeanFactory(resource);
		} catch (Exception exception) {
			ClientConfigurationManager.log.error(
					"Error loading the configuration data", exception);
			throw new ClientConfigurationException(
					"Error loading the configuration data", exception);
		}
	}
}
