/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2008 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : ClaimStatusModuleConfiguration.java
 *
 * Created Date     : Jan 23, 2008
 *
 * Author           : Neena Musti (CF57).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Neena.M (CF57)        Jan 23, 2008     Initial version for Configuration
 */

package com.bcbssc.configuration.beans;

import org.apache.log4j.Logger;

/**
 * <p>ClaimStatusModuleConfiguration class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class ClaimStatusModuleConfiguration extends ModuleConfiguration {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6545050937380570444L;

	/** The log4j logger for this class */
	private static Logger log = Logger
			.getLogger(ClaimStatusModuleConfiguration.class);

	private String healthACSPage;

	private String dentalACSPage;

	private String healthAPSPage;

	private String dentalAPSPage;

	/**
	 * Creates a new instance of ClaimStatusModuleConfiguration
	 */
	public ClaimStatusModuleConfiguration() {
		super();
		if (ClaimStatusModuleConfiguration.log.isDebugEnabled()) {
			ClaimStatusModuleConfiguration.log
					.debug("Created ClaimStatusModuleConfiguration object.");
		}
	}

	/**
	 * <p>toString.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String toString() {
		return super.toString();
	}

	/**
	 * Retrieves the value of healthACSPage.
	 *
	 * @return Returns the healthACSPage.
	 */
	public String getHealthACSPage() {
		return this.healthACSPage;
	}

	/**
	 * Sets the value of healthACSPage.
	 *
	 * @param healthACSPage
	 *            The healthACSPage to set.
	 */
	public void setHealthACSPage(String healthACSPage) {
		this.healthACSPage = healthACSPage;
	}

	/**
	 * Retrieves the value of dentalACSPage.
	 *
	 * @return Returns the dentalACSPage.
	 */
	public String getDentalACSPage() {
		return this.dentalACSPage;
	}

	/**
	 * Sets the value of dentalACSPage.
	 *
	 * @param dentalACSPage
	 *            The dentalACSPage to set.
	 */
	public void setDentalACSPage(String dentalACSPage) {
		this.dentalACSPage = dentalACSPage;
	}

	/**
	 * Retrieves the value of healthAPSPage.
	 *
	 * @return Returns the healthAPSPage.
	 */
	public String getHealthAPSPage() {
		return this.healthAPSPage;
	}

	/**
	 * Sets the value of healthAPSPage.
	 *
	 * @param healthAPSPage
	 *            The healthAPSPage to set.
	 */
	public void setHealthAPSPage(String healthAPSPage) {
		this.healthAPSPage = healthAPSPage;
	}

	/**
	 * Retrieves the value of dentalAPSPage.
	 *
	 * @return Returns the dentalAPSPage.
	 */
	public String getDentalAPSPage() {
		return this.dentalAPSPage;
	}

	/**
	 * Sets the value of dentalAPSPage.
	 *
	 * @param dentalAPSPage
	 *            The dentalAPSPage to set.
	 */
	public void setDentalAPSPage(String dentalAPSPage) {
		this.dentalAPSPage = dentalAPSPage;
	}

}
