/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2007 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : InformData.java
 *
 * Created Date     : Oct 5, 2007
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Oct 5, 2007     Initial version for Configuration
 */

package com.bcbssc.configuration.beans;

import org.apache.log4j.Logger;

/**
 * <p>InformData class.</p>
 *
 * @author Thiagu Chandrasekaran (X29E).
 * @version 1.0
 */
public class InformData extends com.bcbssc.netsys.web.SessionDataBean implements
		java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -526468396394728267L;

	/** The log4j logger for this class */
	private static Logger log = Logger.getLogger(InformData.class);

	private InformDetails informDetails;

	private InformBucketDetails loggedInformBucketDetails;

	private InformBucketDetails requestedInformBucketDetails;

	private InformBucketDetails transferredInformBucketDetails;

	/**
	 * <p>Constructor for InformData.</p>
	 */
	public InformData() {
		super();
		if (InformData.log.isDebugEnabled()) {
			InformData.log.debug("Created InformData object.");
		}
	}

	/**
	 * <p>Getter for the field <code>informDetails</code>.</p>
	 *
	 * @return Returns the correspName.
	 */
	public InformDetails getInformDetails() {
		return this.informDetails;
	}

	/**
	 * <p>Setter for the field <code>informDetails</code>.</p>
	 *
	 * @param informDetails a {@link com.bcbssc.configuration.beans.InformDetails} object.
	 */
	public void setInformDetails(InformDetails informDetails) {
		this.informDetails = informDetails;
	}

	/**
	 * <p>Getter for the field <code>loggedInformBucketDetails</code>.</p>
	 *
	 * @return the loggedInformBucketDetails
	 */
	public InformBucketDetails getLoggedInformBucketDetails() {
		return this.loggedInformBucketDetails;
	}

	/**
	 * <p>Setter for the field <code>loggedInformBucketDetails</code>.</p>
	 *
	 * @param loggedInformBucketDetails
	 *            the loggedInformBucketDetails to set
	 */
	public void setLoggedInformBucketDetails(
			InformBucketDetails loggedInformBucketDetails) {
		this.loggedInformBucketDetails = loggedInformBucketDetails;
	}

	/**
	 * <p>Getter for the field <code>requestedInformBucketDetails</code>.</p>
	 *
	 * @return the requestedInformBucketDetails
	 */
	public InformBucketDetails getRequestedInformBucketDetails() {
		return this.requestedInformBucketDetails;
	}

	/**
	 * <p>Setter for the field <code>requestedInformBucketDetails</code>.</p>
	 *
	 * @param requestedInformBucketDetails
	 *            the requestedInformBucketDetails to set
	 */
	public void setRequestedInformBucketDetails(
			InformBucketDetails requestedInformBucketDetails) {
		this.requestedInformBucketDetails = requestedInformBucketDetails;
	}

	/**
	 * <p>Getter for the field <code>transferredInformBucketDetails</code>.</p>
	 *
	 * @return the transferredInformBucketDetails
	 */
	public InformBucketDetails getTransferredInformBucketDetails() {
		return this.transferredInformBucketDetails;
	}

	/**
	 * <p>Setter for the field <code>transferredInformBucketDetails</code>.</p>
	 *
	 * @param transferredInformBucketDetails
	 *            the transferredInformBucketDetails to set
	 */
	public void setTransferredInformBucketDetails(
			InformBucketDetails transferredInformBucketDetails) {
		this.transferredInformBucketDetails = transferredInformBucketDetails;
	}

	/**
	 * <p>toString.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String toString() {

		StringBuffer stringBuffer = new StringBuffer();

		stringBuffer.append("InformData = [").append("informDetails = ")
					.append(this.informDetails).append(", ")
					.append("loggedInformBucketDetails = ")
					.append(this.loggedInformBucketDetails).append(", ")
					.append("requestedInformBucketDetails = ")
					.append(this.requestedInformBucketDetails).append(", ")
					.append("transferredInformBucketDetails = ")
					.append(this.transferredInformBucketDetails).append("]");

		return stringBuffer.toString();
	}
}
