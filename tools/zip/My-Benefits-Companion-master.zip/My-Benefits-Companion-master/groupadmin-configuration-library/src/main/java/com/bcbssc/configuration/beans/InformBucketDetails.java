/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2008 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : InformBucketDetails.java
 *
 * Created Date     : Jan 29, 2008
 *
 * Author           : Neena Musti (CF57).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Neena.M. (CF57)        Jan 29, 2008     Initial version for Configuration
 */

package com.bcbssc.configuration.beans;

import org.apache.log4j.Logger;

/**
 * <p>InformBucketDetails class.</p>
 *
 * @author Neena Musti (CF57)
 * @version 1.0
 */
public class InformBucketDetails extends com.bcbssc.netsys.web.SessionDataBean
		implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4580687942235274934L;

	/** The log4j logger for this class */
	private static Logger log = Logger.getLogger(InformBucketDetails.class);

	private String informType = "";

	private String corporateCode = "";

	private String companyCode = "";

	private String divisionCode = "";

	private String departmentCode = "";

	private String employeeId = "";

	private String mqIndicator = "";

	private String eligCode = "";

	private String inquiryLocationCode = "";

	private String clientName = "";

	private String customerName = "";

	private String statusCode = "";

	/**
	 * <p>Constructor for InformBucketDetails.</p>
	 */
	public InformBucketDetails() {
		super();
		if (InformBucketDetails.log.isDebugEnabled()) {
			InformBucketDetails.log
					.debug("Created InformBucketDetails object.");
		}
	}

	/**
	 * <p>toString.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String toString() {

		StringBuffer stringBuffer = new StringBuffer();

		stringBuffer.append("InformBucketDetails = [")
			.append("informType = ").append(this.informType).append(", ")
			.append("corporateCode = ").append(this.corporateCode).append(", ")
			.append("companyCode = ").append(this.companyCode).append(", ")
			.append("divisionCode = ").append(this.divisionCode).append(", ")
			.append("departmentCode = ").append(this.departmentCode).append(", ")
			.append("employeeId = ").append(this.employeeId).append(", ")
			.append("mqIndicator = ").append(this.mqIndicator).append(", ")
			.append("eligCode = ").append(this.eligCode).append(", ")
			.append("inquiryLocationCode = ").append(this.inquiryLocationCode)
			.append(", ").append("clientName = ").append(this.clientName)
			.append("customerName = ").append(this.customerName)
			.append("statusCode = ").append(this.statusCode)
			.append("]");

		return stringBuffer.toString();
	}

	/**
	 * Retreives the value of informType.
	 *
	 * @return Returns the informType.
	 */
	public String getInformType() {
		return this.informType;
	}

	/**
	 * Sets the value of informType.
	 *
	 * @param informType
	 *            The informType to set.
	 */
	public void setInformType(String informType) {
		this.informType = informType;
	}

	/**
	 * Retreives the value of corporateCode.
	 *
	 * @return Returns the corporateCode.
	 */
	public String getCorporateCode() {
		return this.corporateCode;
	}

	/**
	 * Sets the value of corporateCode.
	 *
	 * @param corporateCode
	 *            The corporateCode to set.
	 */
	public void setCorporateCode(String corporateCode) {
		this.corporateCode = corporateCode;
	}

	/**
	 * Retreives the value of companyCode.
	 *
	 * @return Returns the companyCode.
	 */
	public String getCompanyCode() {
		return this.companyCode;
	}

	/**
	 * Sets the value of companyCode.
	 *
	 * @param companyCode
	 *            The companyCode to set.
	 */
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	/**
	 * Retreives the value of divisionCode.
	 *
	 * @return Returns the divisionCode.
	 */
	public String getDivisionCode() {
		return this.divisionCode;
	}

	/**
	 * Sets the value of divisionCode.
	 *
	 * @param divisionCode
	 *            The divisionCode to set.
	 */
	public void setDivisionCode(String divisionCode) {
		this.divisionCode = divisionCode;
	}

	/**
	 * Retreives the value of departmentCode.
	 *
	 * @return Returns the departmentCode.
	 */
	public String getDepartmentCode() {
		return this.departmentCode;
	}

	/**
	 * Sets the value of departmentCode.
	 *
	 * @param departmentCode
	 *            The departmentCode to set.
	 */
	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}

	/**
	 * Retreives the value of employeeId.
	 *
	 * @return Returns the employeeId.
	 */
	public String getEmployeeId() {
		return this.employeeId;
	}

	/**
	 * Sets the value of employeeId.
	 *
	 * @param employeeId
	 *            The employeeId to set.
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * Retreives the value of mqIndicator.
	 *
	 * @return Returns the mqIndicator.
	 */
	public String getMqIndicator() {
		return this.mqIndicator;
	}

	/**
	 * Sets the value of mqIndicator.
	 *
	 * @param mqIndicator
	 *            the mqIndicator to set.
	 */
	public void setMqIndicator(String mqIndicator) {
		this.mqIndicator = mqIndicator;
	}

	/**
	 * Retreives the value of eligCode.
	 *
	 * @return Returns the eligCode.
	 */
	public String getEligCode() {
		return this.eligCode;
	}

	/**
	 * Sets the value of eligCode.
	 *
	 * @param eligCode
	 *            the eligCode to set.
	 */
	public void setEligCode(String eligCode) {
		this.eligCode = eligCode;
	}

	/**
	 * <p>Getter for the field <code>inquiryLocationCode</code>.</p>
	 *
	 * @return the inquiryLocationCode
	 */
	public String getInquiryLocationCode() {
		return this.inquiryLocationCode;
	}

	/**
	 * <p>Setter for the field <code>inquiryLocationCode</code>.</p>
	 *
	 * @param inquiryLocationCode
	 *            the inquiryLocationCode to set
	 */
	public void setInquiryLocationCode(String inquiryLocationCode) {
		this.inquiryLocationCode = inquiryLocationCode;
	}

	/**
	 * <p>Getter for the field <code>clientName</code>.</p>
	 *
	 * @return the clientName
	 */
	public String getClientName() {
		return this.clientName;
	}

	/**
	 * <p>Setter for the field <code>clientName</code>.</p>
	 *
	 * @param clientName
	 *            the correspondingName to set
	 */
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	/**
	 * Retreives the value of customerName.
	 *
	 * @return Returns the customerName.
	 */
	public String getCustomerName() {
		return this.customerName;
	}

	/**
	 * Sets the value of customerName.
	 *
	 * @param customerName
	 *            The customerName to set.
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * Retreives the value of statusCode.
	 *
	 * @return Returns the statusCode.
	 */
	public String getStatusCode() {
		return this.statusCode;
	}

	/**
	 * Sets the value of statusCode.
	 *
	 * @param statusCode a {@link java.lang.String} object.
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

}
