/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2007 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : ApplicationSpecificInformData.java
 *
 * Created Date     : Oct 5, 2007
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Oct 5, 2007     Initial version for Configuration
 */

package com.bcbssc.configuration.beans;

import java.util.Map;

import org.apache.log4j.Logger;

/**
 * <p>ApplicationSpecificInformData class.</p>
 *
 * @author Thiagu Chandrasekaran (X29E).
 * @version 1.0
 */
public class ApplicationSpecificInformData {

	/** The log4j logger for this class */
	private static Logger log = Logger
			.getLogger(ApplicationSpecificInformData.class);

	private String mqFrom;

	private String correspName;

	private Map infpData;

	private Map infoData;

	/**
	 * <p>Constructor for ApplicationSpecificInformData.</p>
	 */
	public ApplicationSpecificInformData() {
		super();
		if (ApplicationSpecificInformData.log.isDebugEnabled()) {
			ApplicationSpecificInformData.log
					.debug("Created ApplicationSpecificInformData object.");
		}
	}

	/**
	 * <p>Getter for the field <code>correspName</code>.</p>
	 *
	 * @return Returns the correspName.
	 */
	public String getCorrespName() {
		return this.correspName;
	}

	/**
	 * <p>Setter for the field <code>correspName</code>.</p>
	 *
	 * @param correspName
	 *            The correspName to set.
	 */
	public void setCorrespName(String correspName) {
		this.correspName = correspName;
	}

	/**
	 * <p>Getter for the field <code>infoData</code>.</p>
	 *
	 * @return Returns the infoData.
	 */
	public Map getInfoData() {
		return this.infoData;
	}

	/**
	 * <p>Setter for the field <code>infoData</code>.</p>
	 *
	 * @param infoData
	 *            The infoData to set.
	 */
	public void setInfoData(Map infoData) {
		this.infoData = infoData;
	}

	/**
	 * <p>Getter for the field <code>infpData</code>.</p>
	 *
	 * @return Returns the infpData.
	 */
	public Map getInfpData() {
		return this.infpData;
	}

	/**
	 * <p>Setter for the field <code>infpData</code>.</p>
	 *
	 * @param infpData
	 *            The infpData to set.
	 */
	public void setInfpData(Map infpData) {
		this.infpData = infpData;
	}

	/**
	 * <p>Getter for the field <code>mqFrom</code>.</p>
	 *
	 * @return Returns the mqFrom.
	 */
	public String getMqFrom() {
		return this.mqFrom;
	}

	/**
	 * <p>Setter for the field <code>mqFrom</code>.</p>
	 *
	 * @param mqFrom
	 *            The mqFrom to set.
	 */
	public void setMqFrom(String mqFrom) {
		this.mqFrom = mqFrom;
	}
}
