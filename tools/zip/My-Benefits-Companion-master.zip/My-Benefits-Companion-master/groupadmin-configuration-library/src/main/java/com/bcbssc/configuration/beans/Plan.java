/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2007 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : Plan.java
 *
 * Created Date     : Oct 5, 2007
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Oct 5, 2007     Initial version for Configuration
 */

package com.bcbssc.configuration.beans;

import org.apache.log4j.Logger;

/**
 * <p>Plan class.</p>
 *
 * @author Thiagu Chandrasekaran (X29E).
 * @version 1.0
 */
public class Plan {

	/** The log4j logger for this class */
	private static Logger log = Logger.getLogger(Plan.class);

	private String displayName;

	private String value;

	private String rpn;

	private String company;

	private String companyAbbreviation;

	private String memberNumberPrefix;

	private String payorCode;

	private String lineOfBusiness;

	/**
	 * <p>Constructor for Plan.</p>
	 */
	public Plan() {
		super();
		if (Plan.log.isDebugEnabled()) {
			Plan.log.debug("Created Plan object.");
		}
	}

	/**
	 * <p>Getter for the field <code>lineOfBusiness</code>.</p>
	 *
	 * @return the lineOfBusiness
	 */
	public String getLineOfBusiness() {
		return this.lineOfBusiness;
	}

	/**
	 * <p>Setter for the field <code>lineOfBusiness</code>.</p>
	 *
	 * @param lineOfBusiness
	 *            the lineOfBusiness to set
	 */
	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	/**
	 * <p>Getter for the field <code>payorCode</code>.</p>
	 *
	 * @return the payorCode
	 */
	public String getPayorCode() {
		return this.payorCode;
	}

	/**
	 * <p>Setter for the field <code>payorCode</code>.</p>
	 *
	 * @param payorCode
	 *            the payorCode to set
	 */
	public void setPayorCode(String payorCode) {
		this.payorCode = payorCode;
	}

	/**
	 * <p>Getter for the field <code>memberNumberPrefix</code>.</p>
	 *
	 * @return the memberNumberPrefix
	 */
	public String getMemberNumberPrefix() {
		return this.memberNumberPrefix;
	}

	/**
	 * <p>Setter for the field <code>memberNumberPrefix</code>.</p>
	 *
	 * @param memberNumberPrefix
	 *            the memberNumberPrefix to set
	 */
	public void setMemberNumberPrefix(String memberNumberPrefix) {
		this.memberNumberPrefix = memberNumberPrefix;
	}

	/**
	 * <p>Getter for the field <code>companyAbbreviation</code>.</p>
	 *
	 * @return the companyAbbreviation
	 */
	public String getCompanyAbbreviation() {
		return this.companyAbbreviation;
	}

	/**
	 * <p>Setter for the field <code>companyAbbreviation</code>.</p>
	 *
	 * @param companyAbbreviation
	 *            the companyAbbreviation to set
	 */
	public void setCompanyAbbreviation(String companyAbbreviation) {
		this.companyAbbreviation = companyAbbreviation;
	}

	/**
	 * <p>Getter for the field <code>company</code>.</p>
	 *
	 * @return the company
	 */
	public String getCompany() {
		return this.company;
	}

	/**
	 * <p>Setter for the field <code>company</code>.</p>
	 *
	 * @param company
	 *            the company to set
	 */
	public void setCompany(String company) {
		this.company = company;
	}

	/**
	 * Retreives the value of displayName.
	 *
	 * @return Returns the displayName.
	 */
	public String getDisplayName() {
		return this.displayName;
	}

	/**
	 * Sets the value of displayName.
	 *
	 * @param displayName
	 *            The displayName to set.
	 */
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	/**
	 * Retreives the value of rpn.
	 *
	 * @return Returns the rpn.
	 */
	public String getRpn() {
		return this.rpn;
	}

	/**
	 * Sets the value of rpn.
	 *
	 * @param rpn
	 *            The rpn to set.
	 */
	public void setRpn(String rpn) {
		this.rpn = rpn;
	}

	/**
	 * Retreives the value of value.
	 *
	 * @return Returns the value.
	 */
	public String getValue() {
		return this.value;
	}

	/**
	 * Sets the value of value.
	 *
	 * @param value
	 *            The value to set.
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * The toString implementation for the Plan. Appends all the properties in a
	 * user readable format and returns the append value.
	 *
	 * @return Returns the bean as a string representation.
	 */
	public String toString() {

		StringBuffer stringBuffer = new StringBuffer();

		stringBuffer.append("Plan = [").append("displayName = ")
					.append(this.displayName).append(", ")
					.append("value = ").append(this.value).append(", ")
					.append("rpn = ").append(this.rpn).append(", ")
					.append("company = ").append(this.company).append(", ")
					.append("payorCode = ").append(this.payorCode).append(", ")
					.append("companyAbbreviation = ")
					.append(this.companyAbbreviation).append(", ")
					.append("memberNumberPrefix = ")
					.append(this.memberNumberPrefix).append("]");

		return stringBuffer.toString();
	}
}
