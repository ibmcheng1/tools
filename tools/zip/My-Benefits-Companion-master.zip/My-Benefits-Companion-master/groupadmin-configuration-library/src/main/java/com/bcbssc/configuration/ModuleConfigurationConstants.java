/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2008 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : ModuleConfigurationConstants.java
 *
 * Created Date     : Jan 23, 2008
 *
 * Author           : Neena Musti (CF57).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  N Musti (CF57)        Jan 23, 2008    Initial version for Configuration
 */

package com.bcbssc.configuration;

import org.apache.log4j.Logger;

/**
 * The ModuleConfigurationConstants class defines constant values for the given
 * modules that are available for each client. It will be used by module
 * configuration classes and/or application jsps.
 *
 *
 * <pre>
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-configuration/src/main/java/com/bcbssc/configuration/ModuleConfigurationConstants.java_v  $
 * $Workfile:   ModuleConfigurationConstants.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:42:48  $
 * $Modtime:   May 14 2009 11:33:40  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-configuration/src/main/java/com/bcbssc/configuration/ModuleConfigurationConstants.java_v  $
 *
 *    Rev 1.0   Jun 26 2009 15:42:48   EN80
 * Initial revision.
 *
 *    Rev 1.2   Apr 28 2009 10:05:52   rff74
 * Java6 Upgrade
 *
 *    Rev 1.1   Feb 28 2008 12:01:52   rx29e
 * MHIM Code review changes and Inform changes.
 *
 *    Rev 1.0   Jan 25 2008 10:36:20   rcf57
 * Initial revision.
 *
 *    Rev 1.0   Jan 23 2008 14:09:32   cf57
 * Initial revision.
 * </pre>
 *
 * @author CF57
 * @version $Id: $Id
 */
public class ModuleConfigurationConstants {

	/** The log4j logger for this class */
	private static Logger log = Logger
			.getLogger(ModuleConfigurationConstants.class);

	/* constant to define Claim Status module */
	/** Constant <code>MODULE_CONFIG_STATUS_ID="claimstatus"</code> */
	public static final String MODULE_CONFIG_STATUS_ID = "claimstatus";

	/* constant to define Superuser module */
	/** Constant <code>MODULE_CONFIG_SUPERUSER_ID="superuser"</code> */
	public static final String MODULE_CONFIG_SUPERUSER_ID = "superuser";

	/* constant to define Ohi module */
	/** Constant <code>MODULE_CONFIG_OHI_ID="ohi"</code> */
	public static final String MODULE_CONFIG_OHI_ID = "ohi";

	/* constant to define Eligibility module */
	/** Constant <code>MODULE_CONFIG_ELIG_ID="eligibility"</code> */
	public static final String MODULE_CONFIG_ELIG_ID = "eligibility";

	/* constant to define Claim Entry module */
	/** Constant <code>MODULE_CONFIG_ENTRY_ID="claimentry"</code> */
	public static final String MODULE_CONFIG_ENTRY_ID = "claimentry";

	/* constant to define Patient Directory module */
	/** Constant <code>MODULE_CONFIG_PATDIR_ID="patientdirectory"</code> */
	public static final String MODULE_CONFIG_PATDIR_ID = "patientdirectory";

	/* constant to define Superbill module */
	/** Constant <code>MODULE_CONFIG_SUPERBILL_ID="superbill"</code> */
	public static final String MODULE_CONFIG_SUPERBILL_ID = "superbill";

	/* constant to define Authorization Status module */
	/** Constant <code>MODULE_CONFIG_AUTH_ID="authstatus"</code> */
	public static final String MODULE_CONFIG_AUTH_ID = "authstatus";

	/* constant to define Pre Certification module */
	/** Constant <code>MODULE_CONFIG_PRECERT_ID="precertification"</code> */
	public static final String MODULE_CONFIG_PRECERT_ID = "precertification";

	/* constant to define Referrals module */
	/** Constant <code>MODULE_CONFIG_REFERRAL_ID="referrals"</code> */
	public static final String MODULE_CONFIG_REFERRAL_ID = "referrals";

	/* constant to define Primary Care Physician module */
	/** Constant <code>MODULE_CONFIG_PCP_ID="primarycarephysician"</code> */
	public static final String MODULE_CONFIG_PCP_ID = "primarycarephysician";

	/* constant to define ID Cards module */
	/** Constant <code>MODULE_CONFIG_IDC_ID="idcard"</code> */
	public static final String MODULE_CONFIG_IDC_ID = "idcard";

	/* constant to define Remittances module */
	/** Constant <code>MODULE_CONFIG_REMIT_ID="remit"</code> */
	public static final String MODULE_CONFIG_REMIT_ID = "remit";

	/**
	 * <p>Constructor for ModuleConfigurationConstants.</p>
	 */
	public ModuleConfigurationConstants() {
		super();
		if (ModuleConfigurationConstants.log.isDebugEnabled()) {
			ModuleConfigurationConstants.log
					.debug("Created ModuleConfigurationConstants object.");
		}
	}

}
