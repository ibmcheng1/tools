/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2008 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : EligibilityModuleConfiguration.java
 *
 * Created Date     : Jan 15, 2008
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Jan 15, 2008    Initial version for Configuration
 */

package com.bcbssc.configuration.beans;

import org.apache.log4j.Logger;

/**
 * <p>EligibilityModuleConfiguration class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class EligibilityModuleConfiguration extends ModuleConfiguration {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5606744787551503439L;

	/** The log4j logger for this class */
	private static Logger log = Logger
			.getLogger(EligibilityModuleConfiguration.class);

	private boolean providerSearchEnabled;

	private boolean allDentalBenefitsEnabled;

	private boolean hraEnabled;

	private boolean bxTransactionAllowed;

	private boolean authorizationAvailable;

	private boolean fepMessageDisplayed;

	private String npiWarningType;

	private String healthHomePage;

	private String dentalHomePage;

	private boolean callTMDC = true;

	/**
	 * <p>Constructor for EligibilityModuleConfiguration.</p>
	 */
	public EligibilityModuleConfiguration() {
		super();
		if (EligibilityModuleConfiguration.log.isDebugEnabled()) {
			EligibilityModuleConfiguration.log
					.debug("Created EligibilityModuleConfiguration object.");
		}
	}

	/**
	 * <p>isProviderSearchEnabled.</p>
	 *
	 * @return the providerSearchEnabled
	 */
	public boolean isProviderSearchEnabled() {
		return this.providerSearchEnabled;
	}

	/**
	 * <p>Setter for the field <code>providerSearchEnabled</code>.</p>
	 *
	 * @param providerSearchEnabled
	 *            the providerSearchEnabled to set
	 */
	public void setProviderSearchEnabled(boolean providerSearchEnabled) {
		this.providerSearchEnabled = providerSearchEnabled;
	}

	/**
	 * <p>isAllDentalBenefitsEnabled.</p>
	 *
	 * @return the allDentalBenefitsEnabled
	 */
	public boolean isAllDentalBenefitsEnabled() {
		return this.allDentalBenefitsEnabled;
	}

	/**
	 * <p>Setter for the field <code>allDentalBenefitsEnabled</code>.</p>
	 *
	 * @param allDentalBenefitsEnabled
	 *            the allDentalBenefitsEnabled to set
	 */
	public void setAllDentalBenefitsEnabled(boolean allDentalBenefitsEnabled) {
		this.allDentalBenefitsEnabled = allDentalBenefitsEnabled;
	}

	/**
	 * <p>isHraEnabled.</p>
	 *
	 * @return the hraEnabled
	 */
	public boolean isHraEnabled() {
		return this.hraEnabled;
	}

	/**
	 * <p>Setter for the field <code>hraEnabled</code>.</p>
	 *
	 * @param hraEnabled
	 *            the hraEnabled to set
	 */
	public void setHraEnabled(boolean hraEnabled) {
		this.hraEnabled = hraEnabled;
	}

	/**
	 * <p>isBxTransactionAllowed.</p>
	 *
	 * @return the bxTransactionAllowed
	 */
	public boolean isBxTransactionAllowed() {
		return this.bxTransactionAllowed;
	}

	/**
	 * <p>Setter for the field <code>bxTransactionAllowed</code>.</p>
	 *
	 * @param bxTransactionAllowed
	 *            the bxTransactionAllowed to set
	 */
	public void setBxTransactionAllowed(boolean bxTransactionAllowed) {
		this.bxTransactionAllowed = bxTransactionAllowed;
	}

	/**
	 * <p>isAuthorizationAvailable.</p>
	 *
	 * @return the authorizationAvailable
	 */
	public boolean isAuthorizationAvailable() {
		return this.authorizationAvailable;
	}

	/**
	 * <p>Setter for the field <code>authorizationAvailable</code>.</p>
	 *
	 * @param authorizationAvailable
	 *            the authorizationAvailable to set
	 */
	public void setAuthorizationAvailable(boolean authorizationAvailable) {
		this.authorizationAvailable = authorizationAvailable;
	}

	/**
	 * <p>isFepMessageDisplayed.</p>
	 *
	 * @return the fepMessageDisplayed
	 */
	public boolean isFepMessageDisplayed() {
		return this.fepMessageDisplayed;
	}

	/**
	 * <p>Setter for the field <code>fepMessageDisplayed</code>.</p>
	 *
	 * @param fepMessageDisplayed
	 *            the fepMessageDisplayed to set
	 */
	public void setFepMessageDisplayed(boolean fepMessageDisplayed) {
		this.fepMessageDisplayed = fepMessageDisplayed;
	}

	/**
	 * <p>Getter for the field <code>npiWarningType</code>.</p>
	 *
	 * @return the npiWarningType
	 */
	public String getNpiWarningType() {
		return this.npiWarningType;
	}

	/**
	 * <p>Setter for the field <code>npiWarningType</code>.</p>
	 *
	 * @param npiWarningType a {@link java.lang.String} object.
	 */
	public void setNpiWarningType(String npiWarningType) {
		this.npiWarningType = npiWarningType;
	}

	/**
	 * <p>Getter for the field <code>healthHomePage</code>.</p>
	 *
	 * @return the healthHomePage
	 */
	public String getHealthHomePage() {
		return this.healthHomePage;
	}

	/**
	 * <p>Setter for the field <code>healthHomePage</code>.</p>
	 *
	 * @param healthHomePage
	 *            the healthHomePage to set
	 */
	public void setHealthHomePage(String healthHomePage) {
		this.healthHomePage = healthHomePage;
	}

	/**
	 * <p>Getter for the field <code>dentalHomePage</code>.</p>
	 *
	 * @return the dentalHomePage
	 */
	public String getDentalHomePage() {
		return this.dentalHomePage;
	}

	/**
	 * <p>Setter for the field <code>dentalHomePage</code>.</p>
	 *
	 * @param dentalHomePage
	 *            the dentalHomePage to set
	 */
	public void setDentalHomePage(String dentalHomePage) {
		this.dentalHomePage = dentalHomePage;
	}

	/**
	 * <p>isCallTMDC.</p>
	 *
	 * @return the callTMDC
	 */
	public boolean isCallTMDC() {
		return this.callTMDC;
	}

	/**
	 * <p>Setter for the field <code>callTMDC</code>.</p>
	 *
	 * @param callTMDC
	 *            the callTMDC to set
	 */
	public void setCallTMDC(boolean callTMDC) {
		this.callTMDC = callTMDC;
	}
}
