/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2007 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : ClientConfigurationException.java
 *
 * Created Date     : Sep 20, 2007
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Sep 20, 2007    Initial version for Configuration
 */

package com.bcbssc.configuration;

import com.bcbssc.netsys.LinkedException;

import org.apache.log4j.Logger;

/**
 * <p>ClientConfigurationException class.</p>
 *
 * @author Thiagu Chandrasekaran (X29E).
 * @version 1.0
 */
public class ClientConfigurationException extends LinkedException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5655325418858972332L;

	/** The log4j logger for this class */
	private static Logger log = Logger
			.getLogger(ClientConfigurationException.class);

	/**
	 * Creates a new instance of ClientConfigurationException.
	 */
	public ClientConfigurationException() {
		super();
		if (ClientConfigurationException.log.isDebugEnabled()) {
			ClientConfigurationException.log
					.debug("Created ClientConfigurationException object.");
		}
	}

	/**
	 * Creates a new instance of ClientConfigurationException with a descriptive
	 * message.
	 *
	 * @param message
	 *            The exception message.
	 */
	public ClientConfigurationException(String message) {
		super(message);
		if (ClientConfigurationException.log.isDebugEnabled()) {
			ClientConfigurationException.log
					.debug("Created ClientConfigurationException object.");
		}
	}

	/**
	 * Creates a new instance of ClientConfigurationException with a descriptive
	 * message and a root cause.
	 *
	 * @param message
	 *            The exception message.
	 * @param rootCause
	 *            The root cause of this exception.
	 */
	public ClientConfigurationException(String message, Throwable rootCause) {
		super(message, rootCause);
		if (ClientConfigurationException.log.isDebugEnabled()) {
			ClientConfigurationException.log
					.debug("Created ClientConfigurationException object.");
		}
	}

	/**
	 * Creates a new instance of ClientConfigurationException with the given
	 * root cause.
	 *
	 * @param rootCause
	 *            The root cause of this exception.
	 */
	public ClientConfigurationException(Throwable rootCause) {
		super(rootCause);
		if (ClientConfigurationException.log.isDebugEnabled()) {
			ClientConfigurationException.log
					.debug("Created ClientConfigurationException object.");
		}
	}
}
