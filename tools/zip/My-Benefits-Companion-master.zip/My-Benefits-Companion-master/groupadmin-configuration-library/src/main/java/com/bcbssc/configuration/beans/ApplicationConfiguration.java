/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2007 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : ApplicationConfiguration.java
 *
 * Created Date     : Sep 20, 2007
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Sep 20, 2007     Initial version for Configuration
 */

package com.bcbssc.configuration.beans;

import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

/**
 * <p>ApplicationConfiguration class.</p>
 *
 * @author Thiagu Chandrasekaran (X29E).
 * @version 1.0
 */
public class ApplicationConfiguration {

	private static final Logger log = Logger
			.getLogger(ApplicationConfiguration.class);

	private Map profileData;

	private RPNDetails rpnDetails;

	private String companyName;

	private List healthPlans;

	private List dentalPlans;

	private ResourceBundle resourceBundle;

	private String resourceBundleFileName;

	private ApplicationSpecificInformData informBucketDetails;

	private boolean defaultProfile;

	/**
	 * <p>Constructor for ApplicationConfiguration.</p>
	 */
	public ApplicationConfiguration() {
		super();
		if (ApplicationConfiguration.log.isDebugEnabled()) {
			ApplicationConfiguration.log
					.debug("Created ApplicationConfiguration object.");
		}
	}

	/**
	 * Retreives the value of alternateRpn.
	 *
	 * @return Returns the alternateRpn.
	 */
	public String getAlternateRpn() {
		return this.rpnDetails.getAlternaterpn();
	}

	/**
	 * <p>getDentalCompany.</p>
	 *
	 * @return Returns the dentalCompany.
	 */
	public String getDentalCompany() {
		return ((RegistrationProfile) this.profileData.get("member"))
				.getCompany();
	}

	/**
	 * <p>getProvidercompany.</p>
	 *
	 * @return Returns the providercompany.
	 */
	public String getProvidercompany() {
		return ((RegistrationProfile) this.profileData.get("provider"))
				.getCompany();
	}

	/**
	 * <p>Getter for the field <code>companyName</code>.</p>
	 *
	 * @return Returns the companyName.
	 */
	public String getCompanyName() {
		return this.companyName;
	}

	/**
	 * <p>Setter for the field <code>companyName</code>.</p>
	 *
	 * @param companyName
	 *            The companyName to set.
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
	 * Retreives the value of dentalPlans.
	 *
	 * @return Returns the dentalPlans.
	 */
	public List getDentalPlans() {
		return this.dentalPlans;
	}

	/**
	 * Sets the value of dentalPlans.
	 *
	 * @param dentalPlans
	 *            The dentalPlans to set.
	 */
	public void setDentalPlans(List dentalPlans) {
		this.dentalPlans = dentalPlans;
	}

	/**
	 * Retreives the value of healthPlans.
	 *
	 * @return Returns the healthPlans.
	 */
	public List getHealthPlans() {
		return this.healthPlans;
	}

	/**
	 * Sets the value of healthPlans.
	 *
	 * @param healthPlans
	 *            The healthPlans to set.
	 */
	public void setHealthPlans(List healthPlans) {
		this.healthPlans = healthPlans;
	}

	/**
	 * Retreives the value of profileData.
	 *
	 * @return Returns the profileData.
	 */
	public Map getProfileData() {
		return this.profileData;
	}

	/**
	 * Sets the value of profileData.
	 *
	 * @param profileData
	 *            The profileData to set.
	 */
	public void setProfileData(Map profileData) {
		this.profileData = profileData;
	}

	/**
	 * Retreives the value of resourceBundle.
	 *
	 * @return Returns the resourceBundle.
	 */
	public ResourceBundle getResourceBundle() {
		return this.resourceBundle;
	}

	/**
	 * Sets the value of resourceBundle.
	 *
	 * @param resourceBundle
	 *            The resourceBundle to set.
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * Retreives the value of resourceBundleFileName.
	 *
	 * @return Returns the resourceBundleFileName.
	 */
	public String getResourceBundleFileName() {
		return this.resourceBundleFileName;
	}

	/**
	 * Sets the value of resourceBundleFileName.
	 *
	 * @param resourceBundleFileName
	 *            The resourceBundleFileName to set.
	 */
	public void setResourceBundleFileName(String resourceBundleFileName) {

		this.resourceBundleFileName = resourceBundleFileName;

		try {
			this.resourceBundle = ResourceBundle
					.getBundle(this.resourceBundleFileName);
		} catch (Exception exception) {
			ApplicationConfiguration.log
					.error("Unable to create the resource bundle from the file name "
							+ this.resourceBundleFileName);
		}
	}

	/**
	 * Retreives the value of rpn.
	 *
	 * @return Returns the rpn.
	 */
	public String getRpn() {
		return this.rpnDetails.getBaserpn();
	}

	/**
	 * Retreives the value of rpnDetails.
	 *
	 * @return Returns the rpnDetails.
	 */
	public RPNDetails getRpnDetails() {
		return this.rpnDetails;
	}

	/**
	 * Sets the value of rpnDetails.
	 *
	 * @param rpnDetails
	 *            The rpnDetails to set.
	 */
	public void setRpnDetails(RPNDetails rpnDetails) {
		this.rpnDetails = rpnDetails;
	}

	/**
	 * Retreives the value of informBucketDetails.
	 *
	 * @return Returns the informBucketDetails.
	 */
	public ApplicationSpecificInformData getInformBucketDetails() {
		return this.informBucketDetails;
	}

	/**
	 * Sets the value of rpnDetails.
	 *
	 * @param informBucketDetails a {@link com.bcbssc.configuration.beans.ApplicationSpecificInformData} object.
	 */
	public void setInformBucketDetails(
			ApplicationSpecificInformData informBucketDetails) {
		this.informBucketDetails = informBucketDetails;
	}

	/**
	 * The toString implementation for the ApplicationConfiguration. Appends all
	 * the properties in a user readable format and returns the append value.
	 *
	 * @return Returns the bean as a string representation.
	 */
	public String toString() {

		StringBuffer stringBuffer = new StringBuffer();

		stringBuffer.append("ApplicationConfiguration = [")
			.append("rpnDetails = ").append(this.rpnDetails).append(", ")
			.append("healthPlans = ").append(this.healthPlans).append(", ")
			.append("dentalPlans = ").append(this.dentalPlans).append(", ")
			.append("profileData = ").append(this.profileData).append(", ")
			.append("resourceBundleFileName = ")
			.append(this.resourceBundleFileName).append("]");

		return stringBuffer.toString();
	}

	/**
	 * Retreives the value of defaultProfile.
	 *
	 * @return Returns the defaultProfile.
	 */
	public boolean isDefaultProfile() {
		return this.defaultProfile;
	}

	/**
	 * Sets the value of defaultProfile.
	 *
	 * @param defaultProfile
	 *            The defaultProfile to set.
	 */
	public void setDefaultProfile(boolean defaultProfile) {
		this.defaultProfile = defaultProfile;
	}
}
