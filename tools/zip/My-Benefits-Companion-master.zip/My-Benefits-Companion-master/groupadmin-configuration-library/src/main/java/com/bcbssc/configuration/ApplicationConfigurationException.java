/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2007 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : ApplicationConfigurationException.java
 *
 * Created Date     : Sep 20, 2007
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Sep 20, 2007    Initial version for Configuration
 */

package com.bcbssc.configuration;

import com.bcbssc.netsys.LinkedException;

import org.apache.log4j.Logger; 

/**
 * <p>ApplicationConfigurationException class.</p>
 *
 * @author Thiagu Chandrasekaran (X29E).
 * @version 1.0
 */
public class ApplicationConfigurationException extends LinkedException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -858274288285318457L;

	/** The log4j logger for this class */
	private static Logger log = Logger
			.getLogger(ApplicationConfigurationException.class);

	/**
	 * Creates a new instance of ApplicationConfigurationException.
	 */
	public ApplicationConfigurationException() {
		super();
		if (ApplicationConfigurationException.log.isDebugEnabled()) {
			ApplicationConfigurationException.log
					.debug("Created ApplicationConfigurationException object.");
		}
	}

	/**
	 * Creates a new instance of ApplicationConfigurationException with a
	 * descriptive message.
	 *
	 * @param message
	 *            The exception message.
	 */
	public ApplicationConfigurationException(String message) {
		super(message);
		if (ApplicationConfigurationException.log.isDebugEnabled()) {
			ApplicationConfigurationException.log
					.debug("Created ApplicationConfigurationException object.");
		}
	}

	/**
	 * Creates a new instance of ApplicationConfigurationException with a
	 * descriptive message and a root cause.
	 *
	 * @param message
	 *            The exception message.
	 * @param rootCause
	 *            The root cause of this exception.
	 */
	public ApplicationConfigurationException(String message, Throwable rootCause) {
		super(message, rootCause);
		if (ApplicationConfigurationException.log.isDebugEnabled()) {
			ApplicationConfigurationException.log
					.debug("Created ApplicationConfigurationException object.");
		}
	}

	/**
	 * Creates a new instance of ApplicationConfigurationException with the
	 * given root cause.
	 *
	 * @param rootCause
	 *            The root cause of this exception.
	 */
	public ApplicationConfigurationException(Throwable rootCause) {
		super(rootCause);
		if (ApplicationConfigurationException.log.isDebugEnabled()) {
			ApplicationConfigurationException.log
					.debug("Created ApplicationConfigurationException object.");
		}
	}

}
