/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2007 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : RPNDetails.java
 *
 * Created Date     : Oct 9, 2007
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Oct 9, 2007     Initial version for Configuration
 */

package com.bcbssc.configuration.beans;

import org.apache.log4j.Logger;

/**
 * <p>RPNDetails class.</p>
 *
 * @author Thiagu Chandrasekaran (X29E).
 * @version 1.0
 */
public class RPNDetails {

	/** The log4j logger for this class */
	private static Logger log = Logger.getLogger(RPNDetails.class);

	private String baserpn;

	private String alternaterpn;

	private String ammsrpn;

	private String pimsrpn;

	private String selgrpn;

	private String tmcsrpn;

	private String rulesrpn;

	private String seinrpn;

	private String tmplrpn;

	/**
	 * <p>Constructor for RPNDetails.</p>
	 */
	public RPNDetails() {
		super();
		if (RPNDetails.log.isDebugEnabled()) {
			RPNDetails.log.debug("Created RPNDetails object.");
		}
	}

	/**
	 * Retreives the value of alternaterpn.
	 *
	 * @return Returns the alternaterpn.
	 */
	public String getAlternaterpn() {
		return this.alternaterpn;
	}

	/**
	 * Sets the value of alternaterpn.
	 *
	 * @param alternaterpn
	 *            The alternaterpn to set.
	 */
	public void setAlternaterpn(String alternaterpn) {
		this.alternaterpn = alternaterpn;
	}

	/**
	 * Retreives the value of ammsrpn.
	 *
	 * @return Returns the ammsrpn.
	 */
	public String getAmmsrpn() {
		return this.ammsrpn;
	}

	/**
	 * Sets the value of ammsrpn.
	 *
	 * @param ammsrpn
	 *            The ammsrpn to set.
	 */
	public void setAmmsrpn(String ammsrpn) {
		this.ammsrpn = ammsrpn;
	}

	/**
	 * Retreives the value of baserpn.
	 *
	 * @return Returns the baserpn.
	 */
	public String getBaserpn() {
		return this.baserpn;
	}

	/**
	 * Sets the value of baserpn.
	 *
	 * @param baserpn
	 *            The baserpn to set.
	 */
	public void setBaserpn(String baserpn) {
		this.baserpn = baserpn;
	}

	/**
	 * Retreives the value of pimsrpn.
	 *
	 * @return Returns the pimsrpn.
	 */
	public String getPimsrpn() {
		return this.pimsrpn;
	}

	/**
	 * Sets the value of pimsrpn.
	 *
	 * @param pimsrpn
	 *            The pimsrpn to set.
	 */
	public void setPimsrpn(String pimsrpn) {
		this.pimsrpn = pimsrpn;
	}

	/**
	 * Retreives the value of rulesrpn.
	 *
	 * @return Returns the rulesrpn.
	 */
	public String getRulesrpn() {
		return this.rulesrpn;
	}

	/**
	 * Sets the value of rulesrpn.
	 *
	 * @param rulesrpn
	 *            The rulesrpn to set.
	 */
	public void setRulesrpn(String rulesrpn) {
		this.rulesrpn = rulesrpn;
	}

	/**
	 * Retreives the value of seinrpn.
	 *
	 * @return Returns the seinrpn.
	 */
	public String getSeinrpn() {
		return this.seinrpn;
	}

	/**
	 * Sets the value of seinrpn.
	 *
	 * @param seinrpn
	 *            The seinrpn to set.
	 */
	public void setSeinrpn(String seinrpn) {
		this.seinrpn = seinrpn;
	}

	/**
	 * Retreives the value of selgrpn.
	 *
	 * @return Returns the selgrpn.
	 */
	public String getSelgrpn() {
		return this.selgrpn;
	}

	/**
	 * Sets the value of selgrpn.
	 *
	 * @param selgrpn
	 *            The selgrpn to set.
	 */
	public void setSelgrpn(String selgrpn) {
		this.selgrpn = selgrpn;
	}

	/**
	 * Retreives the value of tmcsrpn.
	 *
	 * @return Returns the tmcsrpn.
	 */
	public String getTmcsrpn() {
		return this.tmcsrpn;
	}

	/**
	 * Sets the value of tmcsrpn.
	 *
	 * @param tmcsrpn
	 *            The tmcsrpn to set.
	 */
	public void setTmcsrpn(String tmcsrpn) {
		this.tmcsrpn = tmcsrpn;
	}

	/**
	 * Retreives the value of tmplrpn.
	 *
	 * @return Returns the tmplrpn.
	 */
	public String getTmplrpn() {
		return this.tmplrpn;
	}

	/**
	 * Sets the value of tmplrpn.
	 *
	 * @param tmplrpn
	 *            The tmplrpn to set.
	 */
	public void setTmplrpn(String tmplrpn) {
		this.tmplrpn = tmplrpn;
	}

	/**
	 * The toString implementation for the RPNDetails. Appends all the
	 * properties in a user readable format and returns the append value.
	 *
	 * @return Returns the bean as a string representation.
	 */
	public String toString() {

		StringBuffer stringBuffer = new StringBuffer();

		stringBuffer.append("RPNDetails = [").append("baserpn = ")
					.append(this.baserpn).append(", ").append("alternaterpn = ")
					.append(this.alternaterpn).append(", ").append("ammsrpn = ")
					.append(this.ammsrpn).append(", ").append("pimsrpn = ")
					.append(this.pimsrpn).append(", ").append("selgrpn = ")
					.append(this.selgrpn).append(", ").append("tmcsrpn = ")
					.append(this.tmcsrpn).append(", ").append("rulesrpn = ")
					.append(this.rulesrpn).append(", ").append("seinrpn = ")
					.append(this.seinrpn).append(", ").append("tmplrpn = ")
					.append(this.tmplrpn).append("]");

		return stringBuffer.toString();
	}
}
