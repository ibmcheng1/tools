/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2008 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : ModuleConfiguration.java
 *
 * Created Date     : Jan 15, 2008
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Jan 15, 2008    Initial version for Configuration
 */

package com.bcbssc.configuration.beans;

import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

/**
 * <p>ModuleConfiguration class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class ModuleConfiguration extends com.bcbssc.netsys.web.SessionDataBean
		implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3932011924485316975L;

	private static final Logger log = Logger
			.getLogger(ModuleConfiguration.class);

	private String resourceBundleFileName;

	private PlanList healthPlans;

	private PlanList dentalPlans;

	private ResourceBundle resourceBundle;

	private Map informData;

	/**
	 * <p>Constructor for ModuleConfiguration.</p>
	 */
	public ModuleConfiguration() {
		super();
		if (ModuleConfiguration.log.isDebugEnabled()) {
			ModuleConfiguration.log
					.debug("Created ModuleConfiguration object.");
		}
	}

	/**
	 * <p>Getter for the field <code>dentalPlans</code>.</p>
	 *
	 * @return the dentalPlans
	 */
	public PlanList getDentalPlans() {
		return this.dentalPlans;
	}

	/**
	 * <p>Setter for the field <code>dentalPlans</code>.</p>
	 *
	 * @param dentalPlans
	 *            the dentalPlans to set
	 */
	public void setDentalPlans(PlanList dentalPlans) {
		this.dentalPlans = dentalPlans;
	}

	/**
	 * <p>Getter for the field <code>healthPlans</code>.</p>
	 *
	 * @return the healthPlans
	 */
	public PlanList getHealthPlans() {
		return this.healthPlans;
	}

	/**
	 * <p>Setter for the field <code>healthPlans</code>.</p>
	 *
	 * @param healthPlans
	 *            the healthPlans to set
	 */
	public void setHealthPlans(PlanList healthPlans) {
		this.healthPlans = healthPlans;
	}

	/**
	 * Retrieves the value of resourceBundle.
	 *
	 * @return Returns the resourceBundle.
	 */
	public ResourceBundle getResourceBundle() {
		return this.resourceBundle;
	}

	/**
	 * Sets the value of resourceBundle.
	 *
	 * @param resourceBundle
	 *            The resourceBundle to set.
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * Retrieves the value of resourceBundleFileName.
	 *
	 * @return Returns the resourceBundleFileName.
	 */
	public String getResourceBundleFileName() {
		return this.resourceBundleFileName;
	}

	/**
	 * Sets the value of resourceBundleFileName.
	 *
	 * @param resourceBundleFileName
	 *            The resourceBundleFileName to set.
	 */
	public void setResourceBundleFileName(String resourceBundleFileName) {

		this.resourceBundleFileName = resourceBundleFileName;

		try {
			this.resourceBundle = ResourceBundle
					.getBundle(this.resourceBundleFileName);
		} catch (Exception exception) {
			ModuleConfiguration.log
					.error("Unable to create the resource bundle from the file name "
							+ this.resourceBundleFileName);
		}
	}

	/**
	 * Retrieves the value of informData.
	 *
	 * @return Returns the informData.
	 */
	public Map getInformData() {
		return this.informData;
	}

	/**
	 * Sets the value of informData.
	 *
	 * @param informData
	 *            The informData to set.
	 */
	public void setInformData(Map informData) {
		this.informData = informData;
	}

	/**
	 * <p>toString.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String toString() {

		StringBuffer stringBuffer = new StringBuffer();

		stringBuffer.append("ModuleConfiguration = [")
					.append("resourceBundleFileName = ")
					.append(this.resourceBundleFileName).append(", ")
					.append("healthPlans = ")
					.append(this.healthPlans).append(", ")
					.append("dentalPlans = ")
					.append(this.dentalPlans).append("]");

		return stringBuffer.toString();
	}
}
