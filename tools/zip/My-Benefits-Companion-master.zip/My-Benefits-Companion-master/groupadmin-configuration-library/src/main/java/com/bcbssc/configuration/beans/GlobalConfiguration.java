/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2008 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : GlobalConfiguration.java
 *
 * Created Date     : Jan 15, 2008
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Jan 15, 2008    Initial version for Configuration
 */
package com.bcbssc.configuration.beans;

import java.util.Map;

import org.apache.log4j.Logger;

/**
 * <p>GlobalConfiguration class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class GlobalConfiguration extends com.bcbssc.netsys.web.SessionDataBean
		implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6037941862327445857L;

	/** The log4j logger for this class */
	private static Logger log = Logger.getLogger(GlobalConfiguration.class);

	Map iniMappings;

	/**
	 * <p>Constructor for GlobalConfiguration.</p>
	 */
	public GlobalConfiguration() {
		super();
		if (GlobalConfiguration.log.isDebugEnabled()) {
			GlobalConfiguration.log
					.debug("Created GlobalConfiguration object.");
		}
	}

	/**
	 * <p>Getter for the field <code>iniMappings</code>.</p>
	 *
	 * @return the iniMappings
	 */
	public Map getIniMappings() {
		return this.iniMappings;
	}

	/**
	 * <p>Setter for the field <code>iniMappings</code>.</p>
	 *
	 * @param iniMappings
	 *            the iniMappings to set
	 */
	public void setIniMappings(Map iniMappings) {
		this.iniMappings = iniMappings;
	}
}
