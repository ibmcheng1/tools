/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2007 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : ClientConfiguration.java
 *
 * Created Date     : Sep 20, 2007
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Sep 20, 2007     Initial version for Configuration
 */

package com.bcbssc.configuration.beans;

import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

/**
 * <p>ClientConfiguration class.</p>
 *
 * @author Thiagu Chandrasekaran (X29E).
 * @version 1.0
 */
public class ClientConfiguration extends com.bcbssc.netsys.web.SessionDataBean
		implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -6912566979033029614L;

	private static final Logger log = Logger
			.getLogger(ClientConfiguration.class);

	private Map profileData;

	private Map moduleConfigurations;

	private RPNDetails rpnDetails;

	private String companyName;

	private PlanList healthPlans;

	private PlanList dentalPlans;

	private ResourceBundle resourceBundle;

	private String resourceBundleFileName;

	private Map informData;

	private boolean defaultProfile;

	private boolean statChatEnabled;

	private boolean rcgrRulesEnabled;

	private boolean dentalEnabled;

	private boolean healthEnabled;

	private boolean lineItemEnabled;
	
	private boolean provMIMCredHelpEnabled;

	private String providerLogonPage;
	
	/**
	 * <p>Getter for the field <code>providerLogonPage</code>.</p>
	 *
	 * @return the providerLogonPage
	 */
	public String getProviderLogonPage() {
		return providerLogonPage;
	}


	/**
	 * <p>Setter for the field <code>providerLogonPage</code>.</p>
	 *
	 * @param providerLogonPage the providerLogonPage to set
	 */
	public void setProviderLogonPage(String providerLogonPage) {
		this.providerLogonPage = providerLogonPage;
	}


	/**
	 * <p>Constructor for ClientConfiguration.</p>
	 */
	public ClientConfiguration() {
		super();
		if (ClientConfiguration.log.isDebugEnabled()) {
			ClientConfiguration.log
					.debug("Created ClientConfiguration object.");
		}
	}


	/**
	 * Retreives the value of provMIMCredHelpEnabled
	 *
	 * @return the provMIMCredHelpEnabled
	 */
	public boolean isProvMIMCredHelpEnabled() {
		return provMIMCredHelpEnabled;
	}

	/**
	 * Sets the value of lineItemEnabled provMIMCredHelpEnabled
	 *
	 * @param provMIMCredHelpEnabled the provMIMCredHelpEnabled to set
	 */
	public void setProvMIMCredHelpEnabled(boolean provMIMCredHelpEnabled) {
		this.provMIMCredHelpEnabled = provMIMCredHelpEnabled;
	}

	
	/**
	 * Retreives the value of lineItemEnabled.
	 *
	 * @return Returns the lineItemEnabled.
	 */
	public boolean isLineItemEnabled() {
		return this.lineItemEnabled;
	}

	/**
	 * Sets the value of lineItemEnabled.
	 *
	 * @param lineItemEnabled
	 *            The lineItemEnabled to set.
	 */
	public void setLineItemEnabled(boolean lineItemEnabled) {
		this.lineItemEnabled = lineItemEnabled;
	}

	/**
	 * Retreives the value of healthEnabled.
	 *
	 * @return Returns the healthEnabled.
	 */
	public boolean isHealthEnabled() {
		return this.healthEnabled;
	}

	/**
	 * Sets the value of healthEnabled.
	 *
	 * @param healthEnabled
	 *            The healthEnabled to set.
	 */
	public void setHealthEnabled(boolean healthEnabled) {
		this.healthEnabled = healthEnabled;
	}

	/**
	 * <p>getModuleConfiguration.</p>
	 *
	 * @param moduleName a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.configuration.beans.ModuleConfiguration} object.
	 */
	public ModuleConfiguration getModuleConfiguration(String moduleName) {

		ModuleConfiguration moduleConfiguration = null;

		if (this.moduleConfigurations != null) {
			moduleConfiguration = (ModuleConfiguration) this.moduleConfigurations
					.get(moduleName);
		}

		return moduleConfiguration;
	}

	/**
	 * <p>Getter for the field <code>moduleConfigurations</code>.</p>
	 *
	 * @return the moduleConfigurations
	 */
	public Map getModuleConfigurations() {
		return this.moduleConfigurations;
	}

	/**
	 * <p>Setter for the field <code>moduleConfigurations</code>.</p>
	 *
	 * @param moduleConfigurations
	 *            the moduleConfigurations to set
	 */
	public void setModuleConfigurations(Map moduleConfigurations) {
		this.moduleConfigurations = moduleConfigurations;
	}

	/**
	 * Retreives the value of alternateRpn.
	 *
	 * @return Returns the alternateRpn.
	 */
	public String getAlternateRpn() {
		return this.rpnDetails.getAlternaterpn();
	}

	/**
	 * <p>getDentalCompany.</p>
	 *
	 * @return Returns the dentalCompany.
	 */
	public String getDentalCompany() {
		return ((RegistrationProfile) this.profileData.get("member"))
				.getCompany();
	}

	/**
	 * <p>getProvidercompany.</p>
	 *
	 * @return Returns the providercompany.
	 */
	public String getProvidercompany() {
		return ((RegistrationProfile) this.profileData.get("provider"))
				.getCompany();
	}

	/**
	 * <p>Getter for the field <code>companyName</code>.</p>
	 *
	 * @return Returns the companyName.
	 */
	public String getCompanyName() {
		return this.companyName;
	}

	/**
	 * <p>Setter for the field <code>companyName</code>.</p>
	 *
	 * @param companyName
	 *            The companyName to set.
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
	 * Retreives the value of dentalPlans.
	 *
	 * @return Returns the dentalPlans.
	 */
	public PlanList getDentalPlans() {
		return this.dentalPlans;
	}

	/**
	 * Sets the value of dentalPlans.
	 *
	 * @param dentalPlans
	 *            The dentalPlans to set.
	 */
	public void setDentalPlans(PlanList dentalPlans) {
		this.dentalPlans = dentalPlans;
	}

	/**
	 * Retreives the value of healthPlans.
	 *
	 * @return Returns the healthPlans.
	 */
	public PlanList getHealthPlans() {
		return this.healthPlans;
	}

	/**
	 * Sets the value of healthPlans.
	 *
	 * @param healthPlans
	 *            The healthPlans to set.
	 */
	public void setHealthPlans(PlanList healthPlans) {
		this.healthPlans = healthPlans;
	}

	/**
	 * Retreives the value of profileData.
	 *
	 * @return Returns the profileData.
	 */
	public Map getProfileData() {
		return this.profileData;
	}

	/**
	 * Sets the value of profileData.
	 *
	 * @param profileData
	 *            The profileData to set.
	 */
	public void setProfileData(Map profileData) {
		this.profileData = profileData;
	}

	/**
	 * Retreives the value of resourceBundle.
	 *
	 * @return Returns the resourceBundle.
	 */
	public ResourceBundle getResourceBundle() {
		return this.resourceBundle;
	}

	/**
	 * Sets the value of resourceBundle.
	 *
	 * @param resourceBundle
	 *            The resourceBundle to set.
	 */
	public void setResourceBundle(ResourceBundle resourceBundle) {
		this.resourceBundle = resourceBundle;
	}

	/**
	 * Retreives the value of resourceBundleFileName.
	 *
	 * @return Returns the resourceBundleFileName.
	 */
	public String getResourceBundleFileName() {
		return this.resourceBundleFileName;
	}

	/**
	 * Sets the value of resourceBundleFileName.
	 *
	 * @param resourceBundleFileName
	 *            The resourceBundleFileName to set.
	 */
	public void setResourceBundleFileName(String resourceBundleFileName) {

		this.resourceBundleFileName = resourceBundleFileName;

		try {
			this.resourceBundle = ResourceBundle
					.getBundle(this.resourceBundleFileName);
		} catch (Exception exception) {
			ClientConfiguration.log
					.error("Unable to create the resource bundle from the file name "
							+ this.resourceBundleFileName);
		}
	}

	/**
	 * Retreives the value of rpn.
	 *
	 * @return Returns the rpn.
	 */
	public String getRpn() {
		return this.rpnDetails.getBaserpn();
	}

	/**
	 * Retreives the value of rpnDetails.
	 *
	 * @return Returns the rpnDetails.
	 */
	public RPNDetails getRpnDetails() {
		return this.rpnDetails;
	}

	/**
	 * Sets the value of rpnDetails.
	 *
	 * @param rpnDetails
	 *            The rpnDetails to set.
	 */
	public void setRpnDetails(RPNDetails rpnDetails) {
		this.rpnDetails = rpnDetails;
	}

	/**
	 * Retreives the value of informData.
	 *
	 * @return Returns the informData.
	 */
	public Map getInformData() {
		return this.informData;
	}

	/**
	 * Sets the value of informData.
	 *
	 * @param informData
	 *            The informData to set.
	 */
	public void setInformData(Map informData) {
		this.informData = informData;
	}

	/**
	 * The toString implementation for the ClientConfiguration. Appends all the
	 * properties in a user readable format and returns the append value.
	 *
	 * @return Returns the bean as a string representation.
	 */
	public String toString() {

		StringBuffer stringBuffer = new StringBuffer();

		stringBuffer.append("ClientConfiguration = [");
		stringBuffer.append("rpnDetails = ").append(this.rpnDetails).append(
				", ");
		stringBuffer.append("healthPlans = ").append(this.healthPlans).append(
				", ");
		stringBuffer.append("dentalPlans = ").append(this.dentalPlans).append(
				", ");
		stringBuffer.append("profileData = ").append(this.profileData).append(
				", ");
		stringBuffer.append("informData = ").append(this.informData).append(
				", ");
		stringBuffer.append("ModuleConfigurations = ").append(
				this.moduleConfigurations).append(", ");
		stringBuffer.append("resourceBundleFileName = ").append(
				this.resourceBundleFileName);
		stringBuffer.append("]");

		return stringBuffer.toString();
	}

	/**
	 * Retreives the value of defaultProfile.
	 *
	 * @return Returns the defaultProfile.
	 */
	public boolean isDefaultProfile() {
		return this.defaultProfile;
	}

	/**
	 * Sets the value of defaultProfile.
	 *
	 * @param defaultProfile
	 *            The defaultProfile to set.
	 */
	public void setDefaultProfile(boolean defaultProfile) {
		this.defaultProfile = defaultProfile;
	}

	/**
	 * Retreives the value of statChatEnabled.
	 *
	 * @return Returns the statChatEnabled.
	 */
	public boolean isStatChatEnabled() {
		return this.statChatEnabled;
	}

	/**
	 * Sets the value of statChatEnabled.
	 *
	 * @param statChatEnabled a boolean.
	 */
	public void setStatChatEnabled(boolean statChatEnabled) {
		this.statChatEnabled = statChatEnabled;
	}

	/**
	 * Retreives the value of dentalEnabled.
	 *
	 * @return Returns the dentalEnabled.
	 */
	public boolean isDentalEnabled() {
		return this.dentalEnabled;
	}

	/**
	 * Sets the value of dentalEnabled.
	 *
	 * @param dentalEnabled
	 *            The dentalEnabled to set.
	 */
	public void setDentalEnabled(boolean dentalEnabled) {
		this.dentalEnabled = dentalEnabled;
	}

	/**
	 * Retreives the value of rcgrRulesEnabled.
	 *
	 * @return Returns the rcgrRulesEnabled.
	 */
	public boolean isRcgrRulesEnabled() {
		return this.rcgrRulesEnabled;
	}

	/**
	 * Sets the value of rcgrRulesEnabled.
	 *
	 * @param rulesEnabled a boolean.
	 */
	public void setRcgrRulesEnabled(boolean rulesEnabled) {
		this.rcgrRulesEnabled = rulesEnabled;
	}
}
