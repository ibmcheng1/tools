/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2008 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : PatientDirectoryModuleConfiguration.java
 *
 * Created Date     : Jan 15, 2008
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Sep 20, 2008    Initial version for Configuration
 */

package com.bcbssc.configuration.beans;

import org.apache.log4j.Logger;

/**
 * <p>PatientDirectoryModuleConfiguration class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class PatientDirectoryModuleConfiguration extends ModuleConfiguration {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3546275847904423189L;

	/** The log4j logger for this class */
	private static Logger log = Logger
			.getLogger(PatientDirectoryModuleConfiguration.class);

	private String locationSelectionPage;

	/**
	 * <p>Constructor for PatientDirectoryModuleConfiguration.</p>
	 */
	public PatientDirectoryModuleConfiguration() {
		super();
		if (PatientDirectoryModuleConfiguration.log.isDebugEnabled()) {
			PatientDirectoryModuleConfiguration.log
					.debug("Created PatientDirectoryModuleConfiguration object.");
		}
	}

	/**
	 * <p>Getter for the field <code>locationSelectionPage</code>.</p>
	 *
	 * @return the locationSelectionPage
	 */
	public String getLocationSelectionPage() {
		return this.locationSelectionPage;
	}

	/**
	 * <p>Setter for the field <code>locationSelectionPage</code>.</p>
	 *
	 * @param locationSelectionPage
	 *            the locationSelectionPage to set
	 */
	public void setLocationSelectionPage(String locationSelectionPage) {
		this.locationSelectionPage = locationSelectionPage;
	}
}
