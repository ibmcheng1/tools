/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2007 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : PlanUtil.java
 *
 * Created Date     : Jan 16, 2008
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Jan 16, 2008     Initial version for Configuration
 */

package com.bcbssc.configuration.utils;

import com.bcbssc.configuration.beans.ClientConfiguration;
import com.bcbssc.configuration.beans.ModuleConfiguration;
import com.bcbssc.configuration.beans.Plan;
import com.bcbssc.configuration.beans.PlanList;

import java.lang.reflect.Method;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * <p>PlanUtil class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class PlanUtil {

	private static final Logger logger = Logger.getLogger(PlanUtil.class);

	private PlanUtil() {
		super();
		if (PlanUtil.logger.isDebugEnabled()) {
			PlanUtil.logger.debug("Created PlanUtil object.");
		}
	}

	/**
	 * Retreive the healthplan list for the specified client and module name.
	 * Retreives the module specific health plans list for the specified client.
	 * if no module specific health plans list is found, the client specific
	 * health plan list will be returned.
	 *
	 * @param clientConfiguration a {@link com.bcbssc.configuration.beans.ClientConfiguration} object.
	 * @param moduleName a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.configuration.beans.PlanList} object.
	 */
	public static PlanList getHealthPlanList(
			ClientConfiguration clientConfiguration, String moduleName) {

		PlanList planList = null;
		ModuleConfiguration moduleConfiguration = null;

		if (moduleName == null) {
			planList = clientConfiguration.getHealthPlans();
		} else {

			moduleConfiguration = (ModuleConfiguration) clientConfiguration
					.getModuleConfigurations().get(moduleName);

			if (moduleConfiguration != null) {

				planList = moduleConfiguration.getHealthPlans();

				if ((planList == null) || (planList.getPlans() == null)) {
					planList = clientConfiguration.getHealthPlans();
				}
			} else {
				planList = clientConfiguration.getHealthPlans();
			}
		}

		return planList;
	}

	/**
	 * Retreive the dentalplan list for the specified client and module name.
	 * Retreives the module specific dental plans list for the specified client.
	 * if no module specific dental plans list is found, the client specific
	 * dental plan list will be returned.
	 *
	 * @param clientConfiguration a {@link com.bcbssc.configuration.beans.ClientConfiguration} object.
	 * @param moduleName a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.configuration.beans.PlanList} object.
	 */
	public static PlanList getDentalPlanList(
			ClientConfiguration clientConfiguration, String moduleName) {

		PlanList planList = null;
		ModuleConfiguration moduleConfiguration = null;

		if (moduleName == null) {
			planList = clientConfiguration.getDentalPlans();
		} else {

			moduleConfiguration = (ModuleConfiguration) clientConfiguration
					.getModuleConfigurations().get(moduleName);

			if (moduleConfiguration != null) {

				planList = moduleConfiguration.getDentalPlans();

				if ((planList == null) || (planList.getPlans() == null)) {
					planList = clientConfiguration.getDentalPlans();
				}
			} else {
				planList = clientConfiguration.getDentalPlans();
			}
		}

		return planList;
	}

	/**
	 * Retreive the dental plan for the specified client and module name
	 * identified by the plan value. Retreives the module specific dental plans
	 * list for the specified client. if no module specific dental plans list is
	 * found, the client specific dental plan list will be returned. Uses this
	 * plan list to identifed the plan which has the plan value same as the
	 * passed plan value and returns the plan.
	 *
	 * @param clientConfiguration a {@link com.bcbssc.configuration.beans.ClientConfiguration} object.
	 * @param moduleName a {@link java.lang.String} object.
	 * @param planValue a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.configuration.beans.Plan} object.
	 */
	public static Plan getDentalPlan(ClientConfiguration clientConfiguration,
			String moduleName, String planValue) {

		Plan plan = null;

		PlanList planList = null;
		List plans = null;

		String valueField = null;
		String localPlanValue = null;
		Plan localPlan = null;

		int iListSize = -1;
		int iLoopIndex = -1;

		planList = PlanUtil.getDentalPlanList(clientConfiguration, moduleName);
		valueField = planList.getValueField();
		plans = planList.getPlans();
		iListSize = plans.size();

		for (iLoopIndex = 0; iLoopIndex < iListSize; iLoopIndex++) {

			localPlan = (Plan) plans.get(iLoopIndex);
			localPlanValue = PlanUtil.getPlanValue(localPlan, valueField);

			if (localPlanValue.equals(planValue)) {
				plan = localPlan;
				break;
			}
		}

		return plan;
	}

	/**
	 * Retreive the health plan for the specified client and module name
	 * identified by the plan value. Retreives the module specific health plans
	 * list for the specified client. if no module specific health plans list is
	 * found, the client specific health plan list will be returned. Uses this
	 * plan list to identifed the plan which has the plan value same as the
	 * passed plan value and returns the plan.
	 *
	 * @param clientConfiguration a {@link com.bcbssc.configuration.beans.ClientConfiguration} object.
	 * @param moduleName a {@link java.lang.String} object.
	 * @param planValue a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.configuration.beans.Plan} object.
	 */
	public static Plan getHealthPlan(ClientConfiguration clientConfiguration,
			String moduleName, String planValue) {

		Plan plan = null;

		PlanList planList = null;
		List plans = null;

		String valueField = null;
		String localPlanValue = null;
		Plan localPlan = null;

		int iListSize = -1;
		int iLoopIndex = -1;

		planList = PlanUtil.getHealthPlanList(clientConfiguration, moduleName);
		valueField = planList.getValueField();
		plans = planList.getPlans();
		iListSize = plans.size();

		for (iLoopIndex = 0; iLoopIndex < iListSize; iLoopIndex++) {

			localPlan = (Plan) plans.get(iLoopIndex);
			localPlanValue = PlanUtil.getPlanValue(localPlan, valueField);

			if (localPlanValue.equals(planValue)) {
				plan = localPlan;
				break;
			}
		}

		return plan;
	}

	/**
	 * Retreives the health plan object given the rpn. This is utility method
	 * similar to get health plan. But instead of passing the selected value we
	 * pass an RPN to get the health plan.
	 *
	 * @param clientConfiguration a {@link com.bcbssc.configuration.beans.ClientConfiguration} object.
	 * @param moduleName a {@link java.lang.String} object.
	 * @param rpn a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.configuration.beans.Plan} object.
	 */
	public static Plan getHealthPlanByRpn(
			ClientConfiguration clientConfiguration, String moduleName,
			String rpn) {

		Plan plan = null;

		PlanList planList = null;
		List plans = null;

		String localRpn = null;
		Plan localPlan = null;

		int iListSize = -1;
		int iLoopIndex = -1;

		planList = PlanUtil.getHealthPlanList(clientConfiguration, moduleName);
		plans = planList.getPlans();
		iListSize = plans.size();

		for (iLoopIndex = 0; iLoopIndex < iListSize; iLoopIndex++) {

			localPlan = (Plan) plans.get(iLoopIndex);
			localRpn = localPlan.getRpn();

			if (localRpn.equals(rpn)) {
				plan = localPlan;
				break;
			}
		}

		return plan;
	}

	/**
	 * Utility method to get the plan value from the plan, by passing the value
	 * field. This method is used internally, but this method is made public so
	 * that others can use this method.
	 *
	 * @param plan a {@link com.bcbssc.configuration.beans.Plan} object.
	 * @param valueField a {@link java.lang.String} object.
	 * @return a {@link java.lang.String} object.
	 */
	public static String getPlanValue(Plan plan, String valueField) {

		String planValue = null;

		try {

			Method valueFieldGetter = Plan.class.getMethod("get"
					+ StringUtils.capitalize(valueField), (Class[]) null);
			planValue = (String) valueFieldGetter.invoke(plan, (Object[]) null);
		} catch (Exception exception) {
			PlanUtil.logger.warn("The property " + valueField
					+ " is not configured correctly for plan " + plan);
		}

		return StringUtils.stripToEmpty(planValue);
	}

	/**
	 * Add health prefix if available to the member number.
	 *
	 * @param clientConfiguration a {@link com.bcbssc.configuration.beans.ClientConfiguration} object.
	 * @param moduleName a {@link java.lang.String} object.
	 * @param planValue a {@link java.lang.String} object.
	 * @param memberNumber a {@link java.lang.String} object.
	 * @return a {@link java.lang.String} object.
	 */
	public static String addHealthPrefixToMemberNumber(
			ClientConfiguration clientConfiguration, String moduleName,
			String planValue, String memberNumber) {

		Plan selectedPlan = PlanUtil.getHealthPlan(clientConfiguration,
				moduleName, planValue);
		String prefix = selectedPlan.getMemberNumberPrefix();
		String returnString = memberNumber;

		if (StringUtils.isNotBlank(prefix)) {

			if ((!memberNumber.startsWith(prefix.toUpperCase()))
					&& (!memberNumber.startsWith(prefix.toLowerCase()))) {
				returnString = prefix + memberNumber;
			}
		}

		return returnString;
	}

	/**
	 * Add dental prefix if available to the member number.
	 *
	 * @param clientConfiguration a {@link com.bcbssc.configuration.beans.ClientConfiguration} object.
	 * @param moduleName a {@link java.lang.String} object.
	 * @param planValue a {@link java.lang.String} object.
	 * @param memberNumber a {@link java.lang.String} object.
	 * @return a {@link java.lang.String} object.
	 */
	public static String addDentalPrefixToMemberNumber(
			ClientConfiguration clientConfiguration, String moduleName,
			String planValue, String memberNumber) {

		Plan selectedPlan = PlanUtil.getDentalPlan(clientConfiguration,
				moduleName, planValue);
		String prefix = selectedPlan.getMemberNumberPrefix();
		String returnString = memberNumber;

		if (StringUtils.isNotBlank(prefix)) {

			if ((!memberNumber.startsWith(prefix.toUpperCase()))
					&& (!memberNumber.startsWith(prefix.toLowerCase()))) {
				returnString = prefix + memberNumber;
			}
		}

		return returnString;
	}

	/**
	 * Remove health prefix if available from the member number.
	 *
	 * @param clientConfiguration a {@link com.bcbssc.configuration.beans.ClientConfiguration} object.
	 * @param moduleName a {@link java.lang.String} object.
	 * @param planValue a {@link java.lang.String} object.
	 * @param memberNumber a {@link java.lang.String} object.
	 * @return a {@link java.lang.String} object.
	 */
	public static String removeHealthPrefixFromMemberNumber(
			ClientConfiguration clientConfiguration, String moduleName,
			String planValue, String memberNumber) {

		Plan selectedPlan = PlanUtil.getHealthPlan(clientConfiguration,
				moduleName, planValue);
		String prefix = selectedPlan.getMemberNumberPrefix();
		String returnString = memberNumber;

		if (StringUtils.isNotBlank(prefix)) {

			if (memberNumber.startsWith(prefix.toUpperCase())
					|| memberNumber.startsWith(prefix.toLowerCase())) {
				returnString = memberNumber.substring(prefix.length());
			}
		}
		return returnString;
	}

	/**
	 * Remove dental prefix if available from the member number.
	 *
	 * @param clientConfiguration a {@link com.bcbssc.configuration.beans.ClientConfiguration} object.
	 * @param moduleName a {@link java.lang.String} object.
	 * @param planValue a {@link java.lang.String} object.
	 * @param memberNumber a {@link java.lang.String} object.
	 * @return a {@link java.lang.String} object.
	 */
	public static String removeDentalPrefixFromMemberNumber(
			ClientConfiguration clientConfiguration, String moduleName,
			String planValue, String memberNumber) {

		Plan selectedPlan = PlanUtil.getDentalPlan(clientConfiguration,
				moduleName, planValue);
		String prefix = selectedPlan.getMemberNumberPrefix();
		String returnString = memberNumber;

		if (StringUtils.isNotBlank(prefix)) {

			if (memberNumber.startsWith(prefix.toUpperCase())
					|| memberNumber.startsWith(prefix.toLowerCase())) {
				returnString = memberNumber.substring(prefix.length());
			}
		}
		return returnString;
	}

	/**
	 * Retrieves the dental plan object given the rpn. This is utility method
	 * similar to get dental plan. But instead of passing the selected value we
	 * pass an RPN to get the dental plan.
	 *
	 * @param clientConfiguration a {@link com.bcbssc.configuration.beans.ClientConfiguration} object.
	 * @param moduleName a {@link java.lang.String} object.
	 * @param rpn a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.configuration.beans.Plan} object.
	 */
	public static Plan getDentalPlanByRpn(
			ClientConfiguration clientConfiguration, String moduleName,
			String rpn) {

		Plan plan = null;

		PlanList planList = null;
		List plans = null;

		String localRpn = null;
		Plan localPlan = null;

		int iListSize = -1;
		int iLoopIndex = -1;

		planList = PlanUtil.getDentalPlanList(clientConfiguration, moduleName);
		plans = planList.getPlans();
		iListSize = plans.size();

		for (iLoopIndex = 0; iLoopIndex < iListSize; iLoopIndex++) {

			localPlan = (Plan) plans.get(iLoopIndex);
			localRpn = localPlan.getRpn();

			if (localRpn.equals(rpn)) {
				plan = localPlan;
				break;
			}
		}

		return plan;
	}
}
