/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2008 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : ClaimEntryModuleConfiguration.java
 *
 * Created Date     : Jan 15, 2008
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Jan 15, 2007    Initial version for Configuration
 */

package com.bcbssc.configuration.beans;

import java.util.Map;

import org.apache.log4j.Logger;

/**
 * <p>ClaimEntryModuleConfiguration class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class ClaimEntryModuleConfiguration extends ModuleConfiguration {

	/**
	 *
	 */
	private static final long serialVersionUID = -2359895217365596391L;

	/** The log4j logger for this class */
	private static Logger log = Logger
			.getLogger(ClaimEntryModuleConfiguration.class);

	private boolean superbillEnabled;

	private String healthClaimEntryWelcomePage;

	private String institutionalClaimEntryWelcomePage;

	private String locationSelectionPage;

	private Map payerDetails;

	/**
	 * <p>Constructor for ClaimEntryModuleConfiguration.</p>
	 */
	public ClaimEntryModuleConfiguration() {
		super();
		if (ClaimEntryModuleConfiguration.log.isDebugEnabled()) {
			ClaimEntryModuleConfiguration.log
					.debug("Created ClaimEntryModuleConfiguration object.");
		}
	}

	/**
	 * <p>Getter for the field <code>healthClaimEntryWelcomePage</code>.</p>
	 *
	 * @return the healthClaimEntryWelcomePage
	 */
	public String getHealthClaimEntryWelcomePage() {
		return this.healthClaimEntryWelcomePage;
	}

	/**
	 * <p>Setter for the field <code>healthClaimEntryWelcomePage</code>.</p>
	 *
	 * @param healthClaimEntryWelcomePage
	 *            the healthClaimEntryWelcomePage to set
	 */
	public void setHealthClaimEntryWelcomePage(
			String healthClaimEntryWelcomePage) {
		this.healthClaimEntryWelcomePage = healthClaimEntryWelcomePage;
	}

	/**
	 * <p>Getter for the field <code>institutionalClaimEntryWelcomePage</code>.</p>
	 *
	 * @return the institutionalClaimEntryWelcomePage
	 */
	public String getInstitutionalClaimEntryWelcomePage() {
		return this.institutionalClaimEntryWelcomePage;
	}

	/**
	 * <p>Setter for the field <code>institutionalClaimEntryWelcomePage</code>.</p>
	 *
	 * @param institutionalClaimEntryWelcomePage
	 *            the institutionalClaimEntryWelcomePage to set
	 */
	public void setInstitutionalClaimEntryWelcomePage(
			String institutionalClaimEntryWelcomePage) {
		this.institutionalClaimEntryWelcomePage = institutionalClaimEntryWelcomePage;
	}

	/**
	 * <p>isSuperbillEnabled.</p>
	 *
	 * @return the superbillEnabled
	 */
	public boolean isSuperbillEnabled() {
		return this.superbillEnabled;
	}

	/**
	 * <p>Setter for the field <code>superbillEnabled</code>.</p>
	 *
	 * @param superbillEnabled
	 *            the superbillEnabled to set
	 */
	public void setSuperbillEnabled(boolean superbillEnabled) {
		this.superbillEnabled = superbillEnabled;
	}

	/**
	 * <p>Getter for the field <code>payerDetails</code>.</p>
	 *
	 * @return the payerDetails
	 */
	public Map getPayerDetails() {
		return this.payerDetails;
	}

	/**
	 * <p>Setter for the field <code>payerDetails</code>.</p>
	 *
	 * @param payerDetails
	 *            the payerDetails to set
	 */
	public void setPayerDetails(Map payerDetails) {
		this.payerDetails = payerDetails;
	}

	/**
	 * <p>getPayerDetailKeys.</p>
	 *
	 * @return an array of {@link java.lang.String} objects.
	 */
	public String[] getPayerDetailKeys() {

		String[] keys = new String[this.payerDetails.size()];
		this.payerDetails.keySet().toArray(keys);
		return keys;
	}

	/**
	 * <p>getPayerDetailValues.</p>
	 *
	 * @return an array of {@link java.lang.String} objects.
	 */
	public String[] getPayerDetailValues() {

		String[] values = new String[this.payerDetails.size()];
		this.payerDetails.values().toArray(values);
		return values;
	}

	/**
	 * <p>Getter for the field <code>locationSelectionPage</code>.</p>
	 *
	 * @return the locationSelectionPage
	 */
	public String getLocationSelectionPage() {
		return this.locationSelectionPage;
	}

	/**
	 * <p>Setter for the field <code>locationSelectionPage</code>.</p>
	 *
	 * @param locationSelectionPage
	 *            the locationSelectionPage to set
	 */
	public void setLocationSelectionPage(String locationSelectionPage) {
		this.locationSelectionPage = locationSelectionPage;
	}
}
