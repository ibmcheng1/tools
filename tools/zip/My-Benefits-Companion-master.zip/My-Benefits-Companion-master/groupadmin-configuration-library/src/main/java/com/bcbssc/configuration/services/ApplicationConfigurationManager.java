/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2007 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : ConfigurationManager.java
 *
 * Created Date     : Sep 20, 2007
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Sep 20, 2007     Initial version for Configuration
 */

package com.bcbssc.configuration.services;

import org.apache.log4j.Logger;

import com.bcbssc.configuration.ApplicationConfigurationException;
import com.bcbssc.configuration.beans.ApplicationConfiguration;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.BeanFactory;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.core.io.ClassPathResource;
import org.springframework.beans.factory.xml.XmlBeanFactory;

/**
 * <p>ApplicationConfigurationManager class.</p>
 *
 * @author Thiagu Chandrasekaran (X29E).
 * @version 1.0
 */
public class ApplicationConfigurationManager {

	private static final Logger log = Logger
			.getLogger(ApplicationConfigurationManager.class);

	private static final String DEFAULT_CONFIGURATION = "default";

	private static ApplicationConfigurationManager configurationManager = null;

	private static final String APPLICATION_CONFIGURATION_FILE = "applicationconfiguration.xml";

	private BeanFactory beanFactory = null;

	private ApplicationConfigurationManager()
			throws ApplicationConfigurationException {
		this.populateConfigurations();
		if (ApplicationConfigurationManager.log.isDebugEnabled()) {
			ApplicationConfigurationManager.log
					.debug("Created ApplicationConfigurationManager object.");
		}
	}

	/**
	 * <p>getInstance.</p>
	 *
	 * @return a {@link com.bcbssc.configuration.services.ApplicationConfigurationManager} object.
	 */
	public static ApplicationConfigurationManager getInstance() {

		if (ApplicationConfigurationManager.configurationManager == null) {
			try {
				ApplicationConfigurationManager.configurationManager = new ApplicationConfigurationManager();
			} catch (ApplicationConfigurationException configurationException) {
				ApplicationConfigurationManager.log.error(
						"Error creating the configuration manager instance",
						configurationException);
			}
		}

		return ApplicationConfigurationManager.configurationManager;
	}

	/**
	 * <p>getApplicationConfiguration.</p>
	 *
	 * @param applicationName a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.configuration.beans.ApplicationConfiguration} object.
	 */
	public ApplicationConfiguration getApplicationConfiguration(
			String applicationName) {

		ApplicationConfiguration applicationConfiguration = null;
		ApplicationConfiguration sourceConfiguration = null;

		try {

			applicationConfiguration = new ApplicationConfiguration();

			if (StringUtils.isNotBlank(applicationName)) {
				sourceConfiguration = (ApplicationConfiguration) this.beanFactory
						.getBean(applicationName);
			}

			if (sourceConfiguration == null) {
				sourceConfiguration = (ApplicationConfiguration) this.beanFactory
						.getBean(ApplicationConfigurationManager.DEFAULT_CONFIGURATION);
				sourceConfiguration.setDefaultProfile(true);
			}

			BeanUtils.copyProperties(applicationConfiguration,
					sourceConfiguration);
		} catch (Exception exception) {
			applicationConfiguration = null;
			ApplicationConfigurationManager.log.error(
					"Error retreiving the configuration for the application name "
							+ applicationName, exception);
		}

		return applicationConfiguration;
	}

	private void populateConfigurations()
			throws ApplicationConfigurationException {

		try {
			ClassPathResource resource = new ClassPathResource(
					ApplicationConfigurationManager.APPLICATION_CONFIGURATION_FILE);
			this.beanFactory = new XmlBeanFactory(resource);
		} catch (Exception exception) {
			throw new ApplicationConfigurationException(
					"Error loading the configuration data", exception);
		}
	}

}
