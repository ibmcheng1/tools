/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2008 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : InformDetails.java
 *
 * Created Date     : Jan 30, 2008
 *
 * Author           : Neena Musti (CF57).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Neena.M. (CF57)        Jan 30, 2008     Initial version for Configuration
 */

package com.bcbssc.configuration.beans;

import org.apache.log4j.Logger;

/**
 * <p>InformDetails class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class InformDetails extends com.bcbssc.netsys.web.SessionDataBean
		implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3716489971324844L;

	/** The log4j logger for this class */
	private static Logger log = Logger.getLogger(InformDetails.class);

	private String mqFrom;

	private String correspName;

	private String requestReason;

	/**
	 * <p>toString.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String toString() {

		StringBuffer stringBuffer = new StringBuffer();

		stringBuffer.append("InformDetails = [").append("mqFrom = ")
					.append(this.mqFrom).append(", ").append("correspName = ")
					.append(this.correspName).append("]");

		return stringBuffer.toString();
	}

	/**
	 * Creates a new instance of InformDetails
	 */
	public InformDetails() {
		super();
		if (InformDetails.log.isDebugEnabled()) {
			InformDetails.log.debug("Created InformDetails object.");
		}
	}

	/**
	 * <p>Getter for the field <code>correspName</code>.</p>
	 *
	 * @return Returns the correspName.
	 */
	public String getCorrespName() {
		return this.correspName;
	}

	/**
	 * <p>Setter for the field <code>correspName</code>.</p>
	 *
	 * @param correspName
	 *            The correspName to set.
	 */
	public void setCorrespName(String correspName) {
		this.correspName = correspName;
	}

	/**
	 * <p>Getter for the field <code>mqFrom</code>.</p>
	 *
	 * @return Returns the mqFrom.
	 */
	public String getMqFrom() {
		return this.mqFrom;
	}

	/**
	 * <p>Setter for the field <code>mqFrom</code>.</p>
	 *
	 * @param mqFrom
	 *            The mqFrom to set.
	 */
	public void setMqFrom(String mqFrom) {
		this.mqFrom = mqFrom;
	}

	/**
	 * <p>Getter for the field <code>requestReason</code>.</p>
	 *
	 * @return the requestReason
	 */
	public String getRequestReason() {
		return this.requestReason;
	}

	/**
	 * <p>Setter for the field <code>requestReason</code>.</p>
	 *
	 * @param requestReason
	 *            the requestReason to set
	 */
	public void setRequestReason(String requestReason) {
		this.requestReason = requestReason;
	}
}
