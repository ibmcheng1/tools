/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2007 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : ClientConfigurationConstants.java
 *
 * Created Date     : Nov 1, 2007
 *
 * Author           : Andrea Meyer (X62E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  A Meyer (X62E)        Nov 1, 2007    Initial version for Configuration
 */

package com.bcbssc.configuration;

import java.util.ResourceBundle;

import org.apache.log4j.Logger;

/**
 * The ClientConfigurationConstants class defines constant values used by the
 * client configuration module or applications that need to interface with this
 * module.
 *
 * <pre>
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-configuration/src/main/java/com/bcbssc/configuration/ClientConfigurationConstants.java_v  $
 * $Workfile:   ClientConfigurationConstants.java  $
 * $Revision:   1.1  $
 * $Date:   Nov 05 2009 15:56:46  $
 * $Modtime:   Nov 04 2009 11:25:04  $
 * $Log:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-configuration/src/main/java/com/bcbssc/configuration/ClientConfigurationConstants.java_v  $
 *
 *    Rev 1.1   Nov 05 2009 15:56:46   rx24c
 * Added variables for provider registration and technical help
 *
 *    Rev 1.0   Jun 26 2009 15:42:46   EN80
 * Initial revision.
 *
 *    Rev 1.10   Apr 28 2009 10:05:48   rff74
 * Java6 Upgrade
 *
 *    Rev 1.9   Jul 30 2008 15:33:12   rcf57
 * CX1430 : Added new constants for the pretreatment estimate configurations and also moved some constants around.
 *
 *    Rev 1.8   Jul 24 2008 16:26:02   rcf57
 * CX1430 : Added a couple more constants.
 *
 *    Rev 1.7   Jul 20 2008 14:11:20   rcf57
 * CX1430 : Added another constant.
 *
 *    Rev 1.6   Jul 18 2008 15:31:16   rcf57
 * CX1430 : Added several constants.
 *
 *    Rev 1.5   Jul 14 2008 15:01:10   rx29e
 * CX1430 : Fixed closed inform issues with Patient Directory and Member Registration. Also modified the check for RCGR call enabled among the clients.
 *
 *    Rev 1.4   Jun 25 2008 21:55:22   rcf57
 * CX1430 : Removed state specific module constants and replaced them with state specific inform function constants.
 *
 *    Rev 1.3   Jun 24 2008 19:38:12   rcf57
 * CX1430 : Added constants for State health and dental plans.
 *
 *    Rev 1.2   Feb 28 2008 12:01:52   rx29e
 * MHIM Code review changes and Inform changes.
 *
 *    Rev 1.1   Jan 02 2008 14:07:32   rx29e
 * Moved the hardcoded constant values to the properties file ClientConfiguration.properties
 *
 *    Rev 1.0   Nov 01 2007 10:39:32   x62e
 * Initial revision.
 * </pre>
 *
 * @author X62E
 * @version $Id: $Id
 */
public class ClientConfigurationConstants {

	/** The log4j logger for this class */
	private static Logger log = Logger
			.getLogger(ClientConfigurationConstants.class);

	/** Constant <code>clientConfigurationResources</code> */
	protected static ResourceBundle clientConfigurationResources = ResourceBundle
			.getBundle("ClientConfiguration");

	/*
	 * constant to define session variable used by application configuration to
	 * identify client application name
	 */
	/** Constant <code>CLIENT_CONFIG_SESSION_VAR="ClientConfigurationConstants.clientConf"{trunked}</code> */
	public static final String CLIENT_CONFIG_SESSION_VAR = ClientConfigurationConstants.clientConfigurationResources
			.getString("clientconfiguration.session.variablename");

	/*
	 * constant to define Florida Combined Life LSV application configuration
	 * bean ID
	 */
	/** Constant <code>CLIENT_CONFIG_FCL_ID="ClientConfigurationConstants.clientConf"{trunked}</code> */
	public static final String CLIENT_CONFIG_FCL_ID = ClientConfigurationConstants.clientConfigurationResources
			.getString("clientconfiguration.fcl.id");

	/*
	 * constant to define Florida Combined Life LSV application configuration
	 * bean ID
	 */
	/** Constant <code>CLIENT_CONFIG_HEALTHNET_ID="ClientConfigurationConstants.clientConf"{trunked}</code> */
	public static final String CLIENT_CONFIG_HEALTHNET_ID = ClientConfigurationConstants.clientConfigurationResources
			.getString("clientconfiguration.healthnet.id");

	/*
	 * constant to define Blue Cross Blue Shield SC application configuration
	 * bean ID
	 */
	/** Constant <code>CLIENT_CONFIG_BCBSSC_ID="ClientConfigurationConstants.clientConf"{trunked}</code> */
	public static final String CLIENT_CONFIG_BCBSSC_ID = ClientConfigurationConstants.clientConfigurationResources
			.getString("clientconfiguration.bcbssc.id");

	/* constant to define BlueChoice application configuration bean ID */
	/** Constant <code>CLIENT_CONFIG_CHC_ID="ClientConfigurationConstants.clientConf"{trunked}</code> */
	public static final String CLIENT_CONFIG_CHC_ID = ClientConfigurationConstants.clientConfigurationResources
			.getString("clientconfiguration.chc.id");

	/* constant to define Companion Life application configuration bean ID */
	/** Constant <code>CLIENT_CONFIG_CLIFE_ID="ClientConfigurationConstants.clientConf"{trunked}</code> */
	public static final String CLIENT_CONFIG_CLIFE_ID = ClientConfigurationConstants.clientConfigurationResources
			.getString("clientconfiguration.clife.id");

	/* constant to define default application configuration bean ID */
	/** Constant <code>CLIENT_CONFIG_DEFAULT_ID="ClientConfigurationConstants.clientConf"{trunked}</code> */
	public static final String CLIENT_CONFIG_DEFAULT_ID = ClientConfigurationConstants.clientConfigurationResources
			.getString("clientconfiguration.default.id");

	/** Constant <code>IMAGE_HEADER_LEFT="headerleft"</code> */
	public static final String IMAGE_HEADER_LEFT = "headerleft";

	/** Constant <code>IMAGE_HEADER_RIGHT="headerright"</code> */
	public static final String IMAGE_HEADER_RIGHT = "headerright";

	/** Constant <code>IMAGE_ID_CARD="idcard"</code> */
	public static final String IMAGE_ID_CARD = "idcard";

	/** Constant <code>INQUIRYTYPE_MEMBER="Member"</code> */
	public static final String INQUIRYTYPE_MEMBER = "Member";

	/** Constant <code>INQUIRYTYPE_PROVIDER="Provider"</code> */
	public static final String INQUIRYTYPE_PROVIDER = "Provider";

	/** Constant <code>INQUIRYTYPE_BENEFITS_COORDINATOR="BC"</code> */
	public static final String INQUIRYTYPE_BENEFITS_COORDINATOR = "BC";

	/** Constant <code>INFORMDATA_HEALTH="health"</code> */
	public static final String INFORMDATA_HEALTH = "health";

	/** Constant <code>INFORMDATA_DENTAL="dental"</code> */
	public static final String INFORMDATA_DENTAL = "dental";

	/** Constant <code>INFORMDATA_DEFAULT="default"</code> */
	public static final String INFORMDATA_DEFAULT = "default";

	/** Constant <code>INFORMDATA_BENEFITS_COORDINATOR="benefitsCoordinator"</code> */
	public static final String INFORMDATA_BENEFITS_COORDINATOR = "benefitsCoordinator";

	/** Constant <code>INFORMDATA_MEMBER_REGISTRATION="memberRegistration"</code> */
	public static final String INFORMDATA_MEMBER_REGISTRATION = "memberRegistration";

	/** Constant <code>INFORMDATA_PROVIDER_REGISTRATION="providerRegistration"</code> */
	public static final String INFORMDATA_PROVIDER_REGISTRATION = "providerRegistration";

	/** Constant <code>INFORMDATA_STATE_MEMBER_REGISTRATION="statememberRegistration"</code> */
	public static final String INFORMDATA_STATE_MEMBER_REGISTRATION = "statememberRegistration";

	/** Constant <code>INFORMDATA_CHC_MEMBER_REGISTRATION="chcmemberRegistration"</code> */
	public static final String INFORMDATA_CHC_MEMBER_REGISTRATION = "chcmemberRegistration";

	/** Constant <code>PROFILEDATA_MEMBER="member"</code> */
	public static final String PROFILEDATA_MEMBER = "member";

	/** Constant <code>PROFILEDATA_PROVIDER="provider"</code> */
	public static final String PROFILEDATA_PROVIDER = "provider";

	/** Constant <code>PROFILEDATA_SUPERUSER="superuser"</code> */
	public static final String PROFILEDATA_SUPERUSER = "superuser";

	/** Constant <code>INFORMDATA_HEALTHCLOSED="healthClosed"</code> */
	public static final String INFORMDATA_HEALTHCLOSED = "healthClosed";

	/** Constant <code>INFORMDATA_TECH_HELP="technicalHelp"</code> */
	public static final String INFORMDATA_TECH_HELP = "technicalHelp";

	/** Constant <code>INFORMDATA_HEALTHOPEN="healthOpen"</code> */
	public static final String INFORMDATA_HEALTHOPEN = "healthOpen";

	/** Constant <code>INFORMDATA_DENTALCLOSED="dentalClosed"</code> */
	public static final String INFORMDATA_DENTALCLOSED = "dentalClosed";

	/** Constant <code>INFORMDATA_DENTALOPEN="dentalOpen"</code> */
	public static final String INFORMDATA_DENTALOPEN = "dentalOpen";

	/** Constant <code>INFORMDATA_PRETREATMENTDENTALCLOSED="dentalPreTreatmentClosed"</code> */
	public static final String INFORMDATA_PRETREATMENTDENTALCLOSED = "dentalPreTreatmentClosed";

	/** Constant <code>INFORMDATA_PVDRHEALTHCLOSED="providerHealthClosed"</code> */
	public static final String INFORMDATA_PVDRHEALTHCLOSED = "providerHealthClosed";

	/** Constant <code>INFORMDATA_PVDRHEALTHOPEN="providerHealthOpen"</code> */
	public static final String INFORMDATA_PVDRHEALTHOPEN = "providerHealthOpen";

	/** Constant <code>INFORMDATA_PVDRDENTALCLOSED="providerDentalClosed"</code> */
	public static final String INFORMDATA_PVDRDENTALCLOSED = "providerDentalClosed";

	/** Constant <code>INFORMDATA_PVDRDENTALOPEN="providerDentalOpen"</code> */
	public static final String INFORMDATA_PVDRDENTALOPEN = "providerDentalOpen";

	/** Constant <code>INFORMDATA_PVDRDENTALPRETREATMENTCLOSED="providerDentalPreTreatmentClosed"</code> */
	public static final String INFORMDATA_PVDRDENTALPRETREATMENTCLOSED = "providerDentalPreTreatmentClosed";

	/** Constant <code>INFORMDATA_STATEHEALTHCLOSED="stateHealthClosed"</code> */
	public static final String INFORMDATA_STATEHEALTHCLOSED = "stateHealthClosed";

	/** Constant <code>INFORMDATA_STATEHEALTHOPEN="stateHealthOpen"</code> */
	public static final String INFORMDATA_STATEHEALTHOPEN = "stateHealthOpen";

	/** Constant <code>INFORMDATA_STATEDENTALCLOSED="stateDentalClosed"</code> */
	public static final String INFORMDATA_STATEDENTALCLOSED = "stateDentalClosed";

	/** Constant <code>INFORMDATA_STATEDENTALOPEN="stateDentalOpen"</code> */
	public static final String INFORMDATA_STATEDENTALOPEN = "stateDentalOpen";

	/** Constant <code>INFORMDATA_STATEPRETREATMENTDENTALCLOSED="stateDentalPreTreatmentClosed"</code> */
	public static final String INFORMDATA_STATEPRETREATMENTDENTALCLOSED = "stateDentalPreTreatmentClosed";

	/** Constant <code>INFORMDATA_STATEPVDRHEALTHCLOSED="stateProviderHealthClosed"</code> */
	public static final String INFORMDATA_STATEPVDRHEALTHCLOSED = "stateProviderHealthClosed";

	/** Constant <code>INFORMDATA_STATEPVDRHEALTHOPEN="stateProviderHealthOpen"</code> */
	public static final String INFORMDATA_STATEPVDRHEALTHOPEN = "stateProviderHealthOpen";

	/** Constant <code>INFORMDATA_STATEPVDRDENTALCLOSED="stateProviderDentalClosed"</code> */
	public static final String INFORMDATA_STATEPVDRDENTALCLOSED = "stateProviderDentalClosed";

	/** Constant <code>INFORMDATA_STATEPVDRDENTALOPEN="stateProviderDentalOpen"</code> */
	public static final String INFORMDATA_STATEPVDRDENTALOPEN = "stateProviderDentalOpen";

	/** Constant <code>INFORMDATA_STATEPVDRDENTALPRETREATMENTCLOSED="stateProviderDentalPreTreatmentClosed"</code> */
	public static final String INFORMDATA_STATEPVDRDENTALPRETREATMENTCLOSED = "stateProviderDentalPreTreatmentClosed";

	private ClientConfigurationConstants() {
		super();
		if (ClientConfigurationConstants.log.isDebugEnabled()) {
			ClientConfigurationConstants.log
					.debug("Created ClientConfigurationConstants object.");
		}
	}

}
