/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2008 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : PlanList.java
 *
 * Created Date     : Jan 15, 2008
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Jan 15, 2008    Initial version for Configuration
 */
package com.bcbssc.configuration.beans;

import java.util.List;

import org.apache.log4j.Logger;

/**
 * <p>PlanList class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class PlanList extends com.bcbssc.netsys.web.SessionDataBean implements
		java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8356016466709169359L;

	/** The log4j logger for this class */
	private static Logger log = Logger.getLogger(PlanList.class);

	private List plans;

	private String valueField;

	private int selectedIndex;

	private boolean displayDropDown;

	/**
	 * <p>Constructor for PlanList.</p>
	 */
	public PlanList() {
		super();
		if (PlanList.log.isDebugEnabled()) {
			PlanList.log.debug("Created PlanList object.");
		}
	}

	/**
	 * <p>isDisplayDropDown.</p>
	 *
	 * @return the displayDropDown
	 */
	public boolean isDisplayDropDown() {
		return this.displayDropDown;
	}

	/**
	 * <p>Setter for the field <code>displayDropDown</code>.</p>
	 *
	 * @param displayDropDown
	 *            the displayDropDown to set
	 */
	public void setDisplayDropDown(boolean displayDropDown) {
		this.displayDropDown = displayDropDown;
	}

	/**
	 * <p>Getter for the field <code>selectedIndex</code>.</p>
	 *
	 * @return the selectedIndex
	 */
	public int getSelectedIndex() {
		return this.selectedIndex;
	}

	/**
	 * <p>Setter for the field <code>selectedIndex</code>.</p>
	 *
	 * @param selectedIndex
	 *            the selectedIndex to set
	 */
	public void setSelectedIndex(int selectedIndex) {
		this.selectedIndex = selectedIndex;
	}

	/**
	 * <p>Getter for the field <code>plans</code>.</p>
	 *
	 * @return the plans
	 */
	public List getPlans() {
		return this.plans;
	}

	/**
	 * <p>Setter for the field <code>plans</code>.</p>
	 *
	 * @param plans
	 *            the plans to set
	 */
	public void setPlans(List plans) {
		this.plans = plans;
	}

	/**
	 * <p>Getter for the field <code>valueField</code>.</p>
	 *
	 * @return the valueField
	 */
	public String getValueField() {
		return this.valueField;
	}

	/**
	 * <p>Setter for the field <code>valueField</code>.</p>
	 *
	 * @param valueField
	 *            the valueField to set
	 */
	public void setValueField(String valueField) {
		this.valueField = valueField;
	}

	/**
	 * <p>toString.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String toString() {

		StringBuffer stringBuffer = new StringBuffer();

		stringBuffer.append("PlanList = [").append("plans = ")
					.append(this.plans).append(", ").append("valueField = ")
					.append(this.valueField).append(", ")
					.append("selectedIndex = ")
					.append(this.selectedIndex).append(", ")
					.append("displayDropDown = ")
					.append(this.displayDropDown).append("]");

		return stringBuffer.toString();
	}
}
