/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2007 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : RegistrationProfile.java
 *
 * Created Date     : Oct 5, 2007
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Oct 5, 2007     Initial version for Configuration
 */

package com.bcbssc.configuration.beans;

import java.util.Map;

import org.apache.log4j.Logger;

/**
 * <p>RegistrationProfile class.</p>
 *
 * @author Thiagu Chandrasekaran (X29E).
 * @version 1.0
 */
public class RegistrationProfile extends com.bcbssc.netsys.web.SessionDataBean
		implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6453048871364174443L;

	/** The log4j logger for this class */
	private static Logger log = Logger.getLogger(RegistrationProfile.class);

	private String homePage;

	private String homePageContent;

	private String dentalHomePageContent;

	private String loginPage;

	private String loginPageContent;

	private String legalAgreement;

	private String passwordChangePage;

	private String contactUsPage;

	private String passwordSecurityPage;

	private String passwordHelpPage;

	private String createProfilePage;

	private String createProfileBasicInformationPage;

	private String createProfileConfirmationPage;

	private String modifyProfilePage;

	private String modifyProfileConfirmationPage;

	private String profileExistsPage;

	private String profileChangedPage;

	private String profileNotFoundPage;

	private String loginErrorPage;

	private String challengePage;

	private String faqPage;

	private Map imagesData;

	private String company;

	/**
	 * <p>Constructor for RegistrationProfile.</p>
	 */
	public RegistrationProfile() {
		super();
		if (RegistrationProfile.log.isDebugEnabled()) {
			RegistrationProfile.log
					.debug("Created RegistrationProfile object.");
		}
	}

	/**
	 * <p>Getter for the field <code>company</code>.</p>
	 *
	 * @return Returns the company.
	 */
	public String getCompany() {
		return this.company;
	}

	/**
	 * <p>Setter for the field <code>company</code>.</p>
	 *
	 * @param company
	 *            The company to set.
	 */
	public void setCompany(String company) {
		this.company = company;
	}

	/**
	 * Retreives the value of createProfileConfirmationPage.
	 *
	 * @return Returns the createProfileConfirmationPage.
	 */
	public String getCreateProfileConfirmationPage() {
		return this.createProfileConfirmationPage;
	}

	/**
	 * Sets the value of createProfileConfirmationPage.
	 *
	 * @param createProfileConfirmationPage
	 *            The createProfileConfirmationPage to set.
	 */
	public void setCreateProfileConfirmationPage(
			String createProfileConfirmationPage) {
		this.createProfileConfirmationPage = createProfileConfirmationPage;
	}

	/**
	 * Retreives the value of createProfilePage.
	 *
	 * @return Returns the createProfilePage.
	 */
	public String getCreateProfilePage() {
		return this.createProfilePage;
	}

	/**
	 * Sets the value of createProfilePage.
	 *
	 * @param createProfilePage
	 *            The createProfilePage to set.
	 */
	public void setCreateProfilePage(String createProfilePage) {
		this.createProfilePage = createProfilePage;
	}

	/**
	 * Retreives the value of homePage.
	 *
	 * @return Returns the homePage.
	 */
	public String getHomePage() {
		return this.homePage;
	}

	/**
	 * Sets the value of homePage.
	 *
	 * @param homePage
	 *            The homePage to set.
	 */
	public void setHomePage(String homePage) {
		this.homePage = homePage;
	}

	/**
	 * Retreives the value of legalAgreement.
	 *
	 * @return Returns the legalAgreement.
	 */
	public String getLegalAgreement() {
		return this.legalAgreement;
	}

	/**
	 * Sets the value of legalAgreement.
	 *
	 * @param legalAgreement
	 *            The legalAgreement to set.
	 */
	public void setLegalAgreement(String legalAgreement) {
		this.legalAgreement = legalAgreement;
	}

	/**
	 * Retreives the value of loginErrorPage.
	 *
	 * @return Returns the loginErrorPage.
	 */
	public String getLoginErrorPage() {
		return this.loginErrorPage;
	}

	/**
	 * Sets the value of loginErrorPage.
	 *
	 * @param loginErrorPage
	 *            The loginErrorPage to set.
	 */
	public void setLoginErrorPage(String loginErrorPage) {
		this.loginErrorPage = loginErrorPage;
	}

	/**
	 * Retreives the value of loginPage.
	 *
	 * @return Returns the loginPage.
	 */
	public String getLoginPage() {
		return this.loginPage;
	}

	/**
	 * Sets the value of loginPage.
	 *
	 * @param loginPage
	 *            The loginPage to set.
	 */
	public void setLoginPage(String loginPage) {
		this.loginPage = loginPage;
	}

	/**
	 * Retreives the value of modifyProfileConfirmationPage.
	 *
	 * @return Returns the modifyProfileConfirmationPage.
	 */
	public String getModifyProfileConfirmationPage() {
		return this.modifyProfileConfirmationPage;
	}

	/**
	 * Sets the value of modifyProfileConfirmationPage.
	 *
	 * @param modifyProfileConfirmationPage
	 *            The modifyProfileConfirmationPage to set.
	 */
	public void setModifyProfileConfirmationPage(
			String modifyProfileConfirmationPage) {
		this.modifyProfileConfirmationPage = modifyProfileConfirmationPage;
	}

	/**
	 * Retreives the value of modifyProfilePage.
	 *
	 * @return Returns the modifyProfilePage.
	 */
	public String getModifyProfilePage() {
		return this.modifyProfilePage;
	}

	/**
	 * Sets the value of modifyProfilePage.
	 *
	 * @param modifyProfilePage
	 *            The modifyProfilePage to set.
	 */
	public void setModifyProfilePage(String modifyProfilePage) {
		this.modifyProfilePage = modifyProfilePage;
	}

	/**
	 * Retreives the value of passwordChangePage.
	 *
	 * @return Returns the passwordChangePage.
	 */
	public String getPasswordChangePage() {
		return this.passwordChangePage;
	}

	/**
	 * Sets the value of passwordChangePage.
	 *
	 * @param passwordChangePage
	 *            The passwordChangePage to set.
	 */
	public void setPasswordChangePage(String passwordChangePage) {
		this.passwordChangePage = passwordChangePage;
	}

	/**
	 * Retreives the value of passwordSecurityPage.
	 *
	 * @return Returns the passwordSecurityPage.
	 */
	public String getPasswordSecurityPage() {
		return this.passwordSecurityPage;
	}

	/**
	 * Sets the value of passwordSecurityPage.
	 *
	 * @param passwordSecurityPage
	 *            The passwordSecurityPage to set.
	 */
	public void setPasswordSecurityPage(String passwordSecurityPage) {
		this.passwordSecurityPage = passwordSecurityPage;
	}

	/**
	 * Retreives the value of profileExistsPage.
	 *
	 * @return Returns the profileExistsPage.
	 */
	public String getProfileExistsPage() {
		return this.profileExistsPage;
	}

	/**
	 * Sets the value of profileExistsPage.
	 *
	 * @param profileExistsPage
	 *            The profileExistsPage to set.
	 */
	public void setProfileExistsPage(String profileExistsPage) {
		this.profileExistsPage = profileExistsPage;
	}

	/**
	 * Retreives the value of loginPageContent.
	 *
	 * @return Returns the loginPageContent.
	 */
	public String getLoginPageContent() {
		return this.loginPageContent;
	}

	/**
	 * Sets the value of loginPageContent.
	 *
	 * @param loginPageContent
	 *            The loginPageContent to set.
	 */
	public void setLoginPageContent(String loginPageContent) {
		this.loginPageContent = loginPageContent;
	}

	/**
	 * <p>Getter for the field <code>faqPage</code>.</p>
	 *
	 * @return Returns the faqPage.
	 */
	public String getFaqPage() {
		return this.faqPage;
	}

	/**
	 * <p>Setter for the field <code>faqPage</code>.</p>
	 *
	 * @param faqPage
	 *            The faqPage to set.
	 */
	public void setFaqPage(String faqPage) {
		this.faqPage = faqPage;
	}

	/**
	 * Retreives the value of imagesData.
	 *
	 * @return Returns the imagesData.
	 */
	public Map getImagesData() {
		return this.imagesData;
	}

	/**
	 * Sets the value of imagesData.
	 *
	 * @param imagesData
	 *            The imagesData to set.
	 */
	public void setImagesData(Map imagesData) {
		this.imagesData = imagesData;
	}

	/**
	 * Retreives the value of createProfileBasicInformationPage.
	 *
	 * @return Returns the createProfileBasicInformationPage.
	 */
	public String getCreateProfileBasicInformationPage() {
		return this.createProfileBasicInformationPage;
	}

	/**
	 * Sets the value of createProfileBasicInformationPage.
	 *
	 * @param createProfileBasicInformationPage
	 *            The createProfileBasicInformationPage to set.
	 */
	public void setCreateProfileBasicInformationPage(
			String createProfileBasicInformationPage) {
		this.createProfileBasicInformationPage = createProfileBasicInformationPage;
	}

	/**
	 * Retreives the value of passwordHelpPage.
	 *
	 * @return Returns the passwordHelpPage.
	 */
	public String getPasswordHelpPage() {
		return this.passwordHelpPage;
	}

	/**
	 * Sets the value of passwordHelpPage.
	 *
	 * @param passwordHelpPage
	 *            The passwordHelpPage to set.
	 */
	public void setPasswordHelpPage(String passwordHelpPage) {
		this.passwordHelpPage = passwordHelpPage;
	}

	/**
	 * The toString implementation for the RegistrationProfile. Appends all the
	 * properties in a user readable format and returns the append value.
	 *
	 * @return Returns the bean as a string representation.
	 */
	public String toString() {

		StringBuffer stringBuffer = new StringBuffer();

		stringBuffer.append("RegistrationProfile = [").append("homePage = ")
					.append(this.homePage).append(", ")
					.append("loginPage = ")
					.append(this.loginPage).append(", ")
					.append("loginPageContent = ")
					.append(this.loginPageContent).append(", ")
					.append("legalAgreement = ")
					.append(this.legalAgreement).append(", ")
					.append("passwordChangePage = ")
					.append(this.passwordChangePage).append(", ")
					.append("passwordHelpPage = ")
					.append(this.passwordHelpPage).append(", ")
					.append("passwordSecurityPage = ")
					.append(this.passwordSecurityPage).append(", ")
					.append("createProfilePage = ")
					.append(this.createProfilePage).append(", ")
					.append("createProfileConfirmationPage = ")
					.append(this.createProfileConfirmationPage).append(", ")
					.append("modifyProfilePage = ")
					.append(this.modifyProfilePage).append(", ")
					.append("modifyProfileConfirmationPage = ")
					.append(this.modifyProfileConfirmationPage).append(", ")
					.append("profileExistsPage = ")
					.append(this.profileExistsPage).append(", ")
					.append("loginErrorPage = ")
					.append(this.loginErrorPage).append(", ")
					.append("imageData = ")
					.append(this.imagesData).append("]");

		return stringBuffer.toString();
	}

	/**
	 * Retreives the value of contactUsPage.
	 *
	 * @return Returns the contactUsPage.
	 */
	public String getContactUsPage() {
		return this.contactUsPage;
	}

	/**
	 * Sets the value of contactUsPage.
	 *
	 * @param contactUsPage
	 *            The contactUsPage to set.
	 */
	public void setContactUsPage(String contactUsPage) {
		this.contactUsPage = contactUsPage;
	}

	/**
	 * Retreives the value of homePageContent.
	 *
	 * @return Returns the homePageContent.
	 */
	public String getHomePageContent() {
		return this.homePageContent;
	}

	/**
	 * Sets the value of homePageContent.
	 *
	 * @param homePageContent
	 *            The homePageContent to set.
	 */
	public void setHomePageContent(String homePageContent) {
		this.homePageContent = homePageContent;
	}

	/**
	 * Retreives the value of dentalHomePageContent.
	 *
	 * @return Returns the dentalHomePageContent.
	 */
	public String getDentalHomePageContent() {
		return this.dentalHomePageContent;
	}

	/**
	 * Sets the value of dentalHomePageContent.
	 *
	 * @param dentalHomePageContent
	 *            The dentalHomePageContent to set.
	 */
	public void setDentalHomePageContent(String dentalHomePageContent) {
		this.dentalHomePageContent = dentalHomePageContent;
	}

	/**
	 * <p>Getter for the field <code>challengePage</code>.</p>
	 *
	 * @return the challengePage
	 */
	public String getChallengePage() {
		return this.challengePage;
	}

	/**
	 * <p>Setter for the field <code>challengePage</code>.</p>
	 *
	 * @param challengePage
	 *            the challengePage to set
	 */
	public void setChallengePage(String challengePage) {
		this.challengePage = challengePage;
	}

	/**
	 * <p>Getter for the field <code>profileChangedPage</code>.</p>
	 *
	 * @return the profileChangedPage
	 */
	public String getProfileChangedPage() {
		return this.profileChangedPage;
	}

	/**
	 * <p>Setter for the field <code>profileChangedPage</code>.</p>
	 *
	 * @param profileChangedPage
	 *            the profileChangedPage to set
	 */
	public void setProfileChangedPage(String profileChangedPage) {
		this.profileChangedPage = profileChangedPage;
	}

	/**
	 * <p>Getter for the field <code>profileNotFoundPage</code>.</p>
	 *
	 * @return the profileNotFoundPage
	 */
	public String getProfileNotFoundPage() {
		return this.profileNotFoundPage;
	}

	/**
	 * <p>Setter for the field <code>profileNotFoundPage</code>.</p>
	 *
	 * @param profileNotFoundPage
	 *            the profileNotFoundPage to set
	 */
	public void setProfileNotFoundPage(String profileNotFoundPage) {
		this.profileNotFoundPage = profileNotFoundPage;
	}
}
