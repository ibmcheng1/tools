/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2007 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : InformUtil.java
 *
 * Created Date     : Jan 30, 2008
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Jan 01, 2008     Initial version for Configuration
 */

package com.bcbssc.configuration.utils;

import com.bcbssc.configuration.beans.ClientConfiguration;
import com.bcbssc.configuration.beans.InformData;
import com.bcbssc.configuration.beans.ModuleConfiguration;

import org.apache.log4j.Logger;

/**
 * This is the utility class for inform data. This class is used to retreive
 * values inform data for the client as defined in the client specific
 * configuration.
 *
 * @author Thiagu Chandrasekaran (X29E).
 * @version 1.0
 */
public class InformUtil {

	/** The log4j logger for this class */
	private static Logger log = Logger.getLogger(InformUtil.class);

	private InformUtil() {
		super();
		if (InformUtil.log.isDebugEnabled()) {
			InformUtil.log.debug("Created InformUtil object.");
		}
	}

	/**
	 * Retreives the inform data for the client configuration using the module
	 * name and functionality. the module name could be like claim entry, claim
	 * status etc, and the functionality is could be like health, dental etc.
	 * The processing / precedence logic is as follows.
	 *
	 * (1) if inform data exists for module configuration and functionality use
	 * that. (2) else if default inform data exists for module configuration use
	 * that. (3) else if inform data exists for functionality at client level
	 * use that. (4) else if default inform data exists at client level use
	 * that.
	 *
	 * @param applicationConfiguration a {@link com.bcbssc.configuration.beans.ClientConfiguration} object.
	 * @param moduleName a {@link java.lang.String} object.
	 * @param functionality a {@link java.lang.String} object.
	 * @return a {@link com.bcbssc.configuration.beans.InformData} object.
	 */
	public static InformData getInformData(
			ClientConfiguration applicationConfiguration, String moduleName,
			String functionality) {

		InformData informData = null;
		ModuleConfiguration moduleConfiguration = null;

		if (moduleName == null) {
			informData = InformUtil.getInformDataForClient(
					applicationConfiguration, functionality);
		} else {
			moduleConfiguration = (ModuleConfiguration) applicationConfiguration
					.getModuleConfigurations().get(moduleName);

			if (moduleConfiguration != null) {

				if (moduleConfiguration.getInformData() != null) {

					informData = (InformData) moduleConfiguration
							.getInformData().get(functionality);

					if (informData == null) {
						informData = (InformData) moduleConfiguration
								.getInformData().get("default");
					}
				}

				if (informData == null) {
					informData = InformUtil.getInformDataForClient(
							applicationConfiguration, functionality);
				}
			} else {
				informData = InformUtil.getInformDataForClient(
						applicationConfiguration, functionality);
			}

		}

		return informData;
	}

	/**
	 * Private method. Used to retreive the inform data at the client level.
	 * 
	 * @param applicationConfiguration
	 * @param functionality
	 * @return
	 */
	private static InformData getInformDataForClient(
			ClientConfiguration applicationConfiguration, String functionality) {

		InformData informData = (InformData) applicationConfiguration
				.getInformData().get(functionality);

		if (informData == null) {
			informData = (InformData) applicationConfiguration.getInformData()
					.get("default");
		}
		return informData;
	}
}
