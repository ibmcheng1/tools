/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2008 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : OHIModuleConfiguration.java
 *
 * Created Date     : Jan 15, 2008
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Sep 20, 2008    Initial version for Configuration
 */

package com.bcbssc.configuration.beans;

import org.apache.log4j.Logger;

/**
 * <p>OHIModuleConfiguration class.</p>
 *
 * @author jc33
 * @version $Id: $Id
 */
public class OHIModuleConfiguration extends ModuleConfiguration {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6146078495885558091L;

	/** The log4j logger for this class */
	private static Logger log = Logger.getLogger(OHIModuleConfiguration.class);

	/**
	 * <p>Constructor for OHIModuleConfiguration.</p>
	 */
	public OHIModuleConfiguration() {
		super();
		if (OHIModuleConfiguration.log.isDebugEnabled()) {
			OHIModuleConfiguration.log
					.debug("Created OHIModuleConfiguration object.");
		}
	}

	/**
	 * <p>toString.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String toString() {
		return super.toString();
	}

}
