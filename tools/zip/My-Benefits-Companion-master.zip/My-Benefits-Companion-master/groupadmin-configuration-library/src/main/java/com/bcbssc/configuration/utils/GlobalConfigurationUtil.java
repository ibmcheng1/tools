/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2007 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : GlobalConfigurationUtil.java
 *
 * Created Date     : Jan 16, 2008
 *
 * Author           : Thiagu Chandrasekaran (X29E).
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  Thiagu.C. (X29E)        Jan 16, 2008     Initial version for Configuration
 */

package com.bcbssc.configuration.utils;

import com.bcbssc.configuration.beans.GlobalConfiguration;
import com.bcbssc.configuration.services.ClientConfigurationManager;
import com.bcbssc.netsys.Config;

import java.net.URL;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * This is the utility class for global configuration. This class is used to
 * retreive values from the global configuration.
 *
 * @author Thiagu Chandrasekaran (X29E).
 * @version 1.0
 */
public class GlobalConfigurationUtil {

	/** The log4j logger for this class */
	private static Logger log = Logger.getLogger(GlobalConfigurationUtil.class);

	/**
	 * <p>Constructor for GlobalConfigurationUtil.</p>
	 */
	public GlobalConfigurationUtil() {
		super();
		if (GlobalConfigurationUtil.log.isDebugEnabled()) {
			GlobalConfigurationUtil.log
					.debug("Created GlobalConfigurationUtil object.");
		}
	}

	/**
	 * Retreives the INI file name for the passed moduleName. Retreives the
	 * global configuration object from the client configuration manager and
	 * uses the module name as the key to retreive the INI file name for that
	 * module
	 *
	 * @param moduleName a {@link java.lang.String} object.
	 * @return a {@link java.lang.String} object.
	 */
	public static String getIniFileName(String moduleName) {

		String iniFileName = null;
		GlobalConfiguration globalConfiguration = null;
		Map iniMappings = null;

		if (StringUtils.isNotBlank(moduleName)) {

			globalConfiguration = ClientConfigurationManager.getInstance()
					.getGlobalConfiguration();
			iniMappings = globalConfiguration.getIniMappings();
			iniFileName = (String) iniMappings.get(moduleName);
		}

		return iniFileName;
	}

	/**
	 * Gets the INI filename as a URL to facilitate reading from the stream.
	 *
	 * @param moduleName a {@link java.lang.String} object.
	 * @return a {@link java.net.URL} object.
	 */
	public static URL getAsUrl(String moduleName) {

		URL iniFileUrl = null;

		String iniFileName = GlobalConfigurationUtil.getIniFileName(moduleName);

		if (StringUtils.isNotBlank(iniFileName)) {

			ClassLoader classLoader = Thread.currentThread()
					.getContextClassLoader();

			if (classLoader == null) {
				classLoader = GlobalConfigurationUtil.class.getClassLoader();
			}

			iniFileUrl = classLoader.getResource(iniFileName);
		}

		return iniFileUrl;
	}

	/**
	 * Retreives the value from the ini given the modulename, section and key.
	 * If key not not found in the inifile, the default value is returned. If
	 * the module is not found returns the defaultValue.
	 *
	 * @param moduleName a {@link java.lang.String} object.
	 * @param iniSection a {@link java.lang.String} object.
	 * @param key a {@link java.lang.String} object.
	 * @param defaultValue a {@link java.lang.String} object.
	 * @return a {@link java.lang.String} object.
	 */
	public static String getPropertyValueFromIni(String moduleName,
			String iniSection, String key, String defaultValue) {

		String iniFileName = GlobalConfigurationUtil.getIniFileName(moduleName);
		String returnValue = defaultValue;

		if (StringUtils.isNotBlank(iniFileName)) {
			returnValue = Config.getPrivateProfileString(iniSection, key,
					defaultValue, iniFileName);
		}

		return returnValue;
	}
}
