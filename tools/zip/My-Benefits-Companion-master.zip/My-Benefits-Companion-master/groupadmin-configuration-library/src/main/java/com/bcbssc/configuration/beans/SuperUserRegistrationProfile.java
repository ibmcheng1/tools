/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUECROSS BLUESHIELD
 * OF SOUTH CAROLINA. ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright 2008 BlueCross BlueShield of South Carolina. All Rights Reserved.
 *
 * File Name        : SuperUserRegistrationProfile.java
 *
 * Created Date     : Feb 5, 2008
 *
 * Author           : EN80.
 *
 * Revison History  :
 *
 *                  Author                  Date            Change Log
 *                  --------------------------------------------------------------------------------
 *                  EN80        			Feb 5, 2008     Initial version for Configuration
 */

package com.bcbssc.configuration.beans;

import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

/**
 * <p>SuperUserRegistrationProfile class.</p>
 *
 * @author Srini Parise.
 * @version 1.0
 */
public class SuperUserRegistrationProfile extends RegistrationProfile {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6603879843998662807L;

	/** The log4j logger for this class */
	private static Logger log = Logger
			.getLogger(SuperUserRegistrationProfile.class);

	// used for super user CSR Initial login Page
	private String superUserCSRLoginPage;

	// used for super user Help desk Initial login Page
	private String superUserHDLoginPage;

	// used for super user Member authentication
	private String superUserMemberAuthPage;

	// used for super user Provider authentication
	private String superUserProviderAuthPage;

	// used for super user Benefits Coordinator authentication
	private String superUserBeneCordAuthPage;

	// used for super user auth transaction
	private String superUserTrans;

	// used for super user Help Desk auth transaction
	private String helpDeskTrans;

	// used for super csr inquiry types
	private Map superCsrInquiryTypes;

	// used for super Help Desk inquiry types
	private Map superHelpDeskInquiryTypes;

	/**
	 * <p>Constructor for SuperUserRegistrationProfile.</p>
	 */
	public SuperUserRegistrationProfile() {
		super();
		if (SuperUserRegistrationProfile.log.isDebugEnabled()) {
			SuperUserRegistrationProfile.log
					.debug("Created SuperUserRegistrationProfile object.");
		}
	}

	/**
	 * <p>Getter for the field <code>superUserCSRLoginPage</code>.</p>
	 *
	 * @return Returns the superUserCSRLoginPage.
	 */
	public String getSuperUserCSRLoginPage() {
		return this.superUserCSRLoginPage;
	}

	/**
	 * <p>Setter for the field <code>superUserCSRLoginPage</code>.</p>
	 *
	 * @param superUserCSRLoginPage
	 *            The superUserCSRLoginPage to set.
	 */
	public void setSuperUserCSRLoginPage(String superUserCSRLoginPage) {
		this.superUserCSRLoginPage = superUserCSRLoginPage;
	}

	/**
	 * <p>Getter for the field <code>superUserHDLoginPage</code>.</p>
	 *
	 * @return Returns the superUserHDLoginPage.
	 */
	public String getSuperUserHDLoginPage() {
		return this.superUserHDLoginPage;
	}

	/**
	 * <p>Setter for the field <code>superUserHDLoginPage</code>.</p>
	 *
	 * @param superUserHDLoginPage
	 *            The superUserHDLoginPage to set.
	 */
	public void setSuperUserHDLoginPage(String superUserHDLoginPage) {
		this.superUserHDLoginPage = superUserHDLoginPage;
	}

	/**
	 * <p>Getter for the field <code>superUserMemberAuthPage</code>.</p>
	 *
	 * @return Returns the superUserMemberAuthPage.
	 */
	public String getSuperUserMemberAuthPage() {
		return this.superUserMemberAuthPage;
	}

	/**
	 * <p>Setter for the field <code>superUserMemberAuthPage</code>.</p>
	 *
	 * @param superUserMemberAuthPage
	 *            The superUserMemberAuthPage to set.
	 */
	public void setSuperUserMemberAuthPage(String superUserMemberAuthPage) {
		this.superUserMemberAuthPage = superUserMemberAuthPage;
	}

	/**
	 * <p>Getter for the field <code>superUserProviderAuthPage</code>.</p>
	 *
	 * @return Returns the superUserProviderAuthPage.
	 */
	public String getSuperUserProviderAuthPage() {
		return this.superUserProviderAuthPage;
	}

	/**
	 * <p>Setter for the field <code>superUserProviderAuthPage</code>.</p>
	 *
	 * @param superUserProviderAuthPage
	 *            The superUserProviderAuthPage to set.
	 */
	public void setSuperUserProviderAuthPage(String superUserProviderAuthPage) {
		this.superUserProviderAuthPage = superUserProviderAuthPage;
	}

	/**
	 * <p>Getter for the field <code>superUserBeneCordAuthPage</code>.</p>
	 *
	 * @return Returns the superUserBeneCordAuthPagee.
	 */
	public String getSuperUserBeneCordAuthPage() {
		return this.superUserBeneCordAuthPage;
	}

	/**
	 * <p>Setter for the field <code>superUserBeneCordAuthPage</code>.</p>
	 *
	 * @param superUserBeneCordAuthPage a {@link java.lang.String} object.
	 */
	public void setSuperUserBeneCordAuthPage(String superUserBeneCordAuthPage) {
		this.superUserBeneCordAuthPage = superUserBeneCordAuthPage;
	}

	/**
	 * <p>Getter for the field <code>superUserTrans</code>.</p>
	 *
	 * @return Returns the superUserTrans.
	 */
	public String getSuperUserTrans() {
		return this.superUserTrans;
	}

	/**
	 * <p>Setter for the field <code>superUserTrans</code>.</p>
	 *
	 * @param superUserTrans
	 *            The superUserTrans to set.
	 */
	public void setSuperUserTrans(String superUserTrans) {
		this.superUserTrans = superUserTrans;
	}

	/**
	 * <p>Getter for the field <code>helpDeskTrans</code>.</p>
	 *
	 * @return Returns the helpDeskTrans.
	 */
	public String getHelpDeskTrans() {
		return this.helpDeskTrans;
	}

	/**
	 * <p>Setter for the field <code>helpDeskTrans</code>.</p>
	 *
	 * @param helpDeskTrans a {@link java.lang.String} object.
	 */
	public void setHelpDeskTrans(String helpDeskTrans) {
		this.helpDeskTrans = helpDeskTrans;
	}

	/**
	 * <p>Getter for the field <code>superCsrInquiryTypes</code>.</p>
	 *
	 * @return Returns the superCsrInquiryTypes.
	 */
	public Map getSuperCsrInquiryTypes() {
		return this.superCsrInquiryTypes;
	}

	/**
	 * <p>Setter for the field <code>superCsrInquiryTypes</code>.</p>
	 *
	 * @param superCsrInquiryTypes
	 *            The superCsrInquiryTypes to set.
	 */
	public void setSuperCsrInquiryTypes(Map superCsrInquiryTypes) {
		this.superCsrInquiryTypes = superCsrInquiryTypes;
	}

	/**
	 * <p>Getter for the field <code>superHelpDeskInquiryTypes</code>.</p>
	 *
	 * @return Returns the superHespDeskInquiryTypes.
	 */
	public Map getSuperHelpDeskInquiryTypes() {
		return this.superHelpDeskInquiryTypes;
	}

	/**
	 * <p>Setter for the field <code>superHelpDeskInquiryTypes</code>.</p>
	 *
	 * @param superHelpDeskInquiryTypes a {@link java.util.Map} object.
	 */
	public void setSuperHelpDeskInquiryTypes(Map superHelpDeskInquiryTypes) {
		this.superHelpDeskInquiryTypes = superHelpDeskInquiryTypes;
	}

	/**
	 * The toString implementation for the RegistrationProfile. Appends all the
	 * properties in a user readable format and returns the append value.
	 *
	 * @return Returns the bean as a string representation.
	 */
	public String toString() {

		StringBuffer stringBuffer = new StringBuffer(super.toString());
		stringBuffer.append("superUserMemberAuthPage = ")
					.append(this.superUserMemberAuthPage)
					.append("superUserProviderAuthPage = ")
					.append(this.superUserProviderAuthPage)
					.append("setSuperUserTrans = ").append(this.superUserTrans)
					.append("helpDeskTrans = ").append(this.helpDeskTrans);

		return stringBuffer.toString();
	}

	/**
	 * <p>getInquiryTypesDisplay.</p>
	 *
	 * @param userType
	 *            (Supercsr or superhelpdesk)
	 * @return String of constructed dropdown
	 */
	public String getInquiryTypesDisplay(String userType) {

		StringBuffer dropDown = new StringBuffer();
		dropDown.append("<select name='InquiryType' size='1'>");
		if (userType.equalsIgnoreCase("supercsr")) {
			Iterator it = this.superCsrInquiryTypes.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pairs = (Map.Entry) it.next();
				dropDown.append("\n<option value='").append(pairs.getKey())
						.append("'>");
				dropDown.append(pairs.getValue()).append("</option>");
			}
		} else {
			Iterator it = this.superHelpDeskInquiryTypes.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pairs = (Map.Entry) it.next();
				dropDown.append("\n<option value='").append(pairs.getKey())
						.append("'>");
				dropDown.append(pairs.getValue()).append("</option>");
			}
		}
		dropDown.append("</select>");
		return dropDown.toString();
	}

	/**
	 * <p>getSuperUserLoginPage.</p>
	 *
	 * @param userType
	 *            (Supercsr or superhelpdesk)
	 * @return String of login page url
	 */
	public String getSuperUserLoginPage(String userType) {
		String returnString = null;
		if (userType.equalsIgnoreCase("superhelpdesk")) {
			returnString = this.getSuperUserHDLoginPage();
		} else {
			returnString = this.getSuperUserCSRLoginPage();
		}
		return returnString;
	}
}
