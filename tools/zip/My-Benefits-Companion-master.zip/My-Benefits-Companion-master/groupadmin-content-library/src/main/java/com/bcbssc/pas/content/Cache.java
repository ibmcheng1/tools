/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2007 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-content/src/main/java/com/bcbssc/pas/content/Cache.java_v  $
 * $Workfile:   Cache.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:44:20  $
 * $Modtime:   May 14 2009 11:33:48  $
 */

package com.bcbssc.pas.content;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.StringWriter;
import java.net.URL;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.oro.text.perl.Perl5Util;

/**
 * TODO NOT USED
 * Defines the Content Manager memory and file cache.
 *
 * @author DQ70
 * @version $Id: $Id
 */
public class Cache {
	private static final Logger log = Logger.getLogger(Cache.class);

	private final Perl5Util perl = new Perl5Util();

	private final Map<URL, String> cache = new Hashtable<URL, String>();

	private final Map<URL, Date> timeOuts = new Hashtable<URL, Date>();

	private final Configuration config;

	/**
	 * Creates a new Content Manager Cache.
	 *
	 * @param config
	 *            the configuration bean.
	 */
	public Cache(Configuration config) {
		this.config = config;
		if (Cache.log.isDebugEnabled()) {
			Cache.log.debug("Created Cache object.");
		}
	}

	/**
	 * Caches the given content.
	 *
	 * @param url
	 *            the URL for the content.
	 * @param content
	 *            the content to cache.
	 */
	public void put(URL url, String content) {
		this.cache.put(url, content);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MINUTE, this.config.getTimeOut());
		this.timeOuts.put(url, cal.getTime());

		// Write to disk cache
		File file = this.getFile(url);
		BufferedWriter buf = null;

		try {
			if (Cache.log.isDebugEnabled()) {
				Cache.log.debug("Creating file " + file.getAbsolutePath());
			}
			file.getParentFile().mkdirs();
			buf = new BufferedWriter(new FileWriter(file));
			buf.write(content);
		} catch (Exception e) {
			Cache.log.warn("Unable to write disk cache; file: "
					+ file.getAbsolutePath(), e);
		} finally {
			if (buf != null) {
				try {
					buf.close();
				} catch (Exception e) {
					Cache.log.warn("Error closing file: "
							+ file.getAbsolutePath(), e);
				}
			}
		}
	}

	/**
	 * Gets the cached content for the given URL.
	 *
	 * @param url
	 *            the URL for the content.
	 * @return the cached content for the given key, or null if either the
	 *         content is not found or if its time-out has expired.
	 */
	public String get(URL url) {
		String content = (String) this.cache.get(url);

		if (content != null) {
			Date date = (Date) this.timeOuts.get(url);

			if (new Date().after(date)) {
				Cache.log.debug("Memory cache expired");
				content = null;
			}
		}

		return content;
	}

	/**
	 * Attempts to read the content for the given URL from the either the memory
	 * cache (including expired entries) or the disk cache.
	 *
	 * @param url
	 *            the URL to read.
	 * @return the cached content of the URL.
	 * @throws com.bcbssc.pas.content.ContentException if any.
	 */
	public String getBackup(URL url) throws ContentException {
		final String content = (String) this.cache.get(url);
		if (content != null) {
			Cache.log.debug("Found in memory cache, possibly expired");
			return content;
		}

		Cache.log.debug("Checking file cache");
		final File file = this.getFile(url);
		if (!file.exists()) {
			throw new ContentException("No file cache for "
					+ file.getAbsolutePath());
		}

		final StringWriter out = new StringWriter((int) file.length());
		BufferedReader in = null;

		try {
			Cache.log.debug("Reading file cache");
			in = new BufferedReader(new FileReader(file));
			String s = in.readLine();

			while (s != null) {
				out.write(s);
				s = in.readLine();
			}

			out.close(); // Does nothing
		} catch (Exception e) {
			throw new ContentException("Error reading "
					+ file.getAbsolutePath(), e);
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (Exception e) {
					Cache.log.warn("Error closing read-only resource", e);
				}
			}
		}

		return out.toString();
	}

	/**
	 * Returns a cache file for the given URL.
	 * 
	 * @param url
	 *            the URL needing a cache file.
	 * @return a cache file for the given URL.
	 */
	File getFile(URL url) {
		String path = url.toExternalForm();
		path = this.perl.substitute("s/[^0-9a-zA-Z_.\\/]/_/g", path);

		final StringBuffer buf = new StringBuffer(this.config
				.getCacheDirectory().length()
				+ path.length() + 16);
		buf.append(this.config.getCacheDirectory());
		buf.append(File.separatorChar).append(path);
		buf.append(File.separatorChar).append("_content.cache");
		return new File(buf.toString());
	}

	/**
	 * Used by Test framework to remove a URL from the cache.
	 * 
	 * @param url
	 *            the URL to remove.
	 */
	void remove(URL url) {
		this.cache.remove(url);
		this.timeOuts.remove(url);
	}
}
