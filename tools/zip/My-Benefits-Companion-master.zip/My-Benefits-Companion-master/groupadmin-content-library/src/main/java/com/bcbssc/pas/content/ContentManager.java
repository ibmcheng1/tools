/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2007 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-content/src/main/java/com/bcbssc/pas/content/ContentManager.java_v  $
 * $Workfile:   ContentManager.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:44:24  $
 * $Modtime:   May 14 2009 11:33:48  $
 */

package com.bcbssc.pas.content;

import java.io.BufferedInputStream;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Hashtable;
import java.util.Map;

import org.apache.log4j.Logger;

/**
 * TODO NOT USED
 * Retrieves (and caches) content from the Content Manager.
 *
 * @author DQ70
 * @version $Id: $Id
 */
public class ContentManager {
	private static final Logger log = Logger.getLogger(ContentManager.class);

	private static final Map<Configuration, ContentManager> MANAGERS = new Hashtable<Configuration, ContentManager>();

	private static ContentManager defaultContentManager;

	private final Configuration config;

	private final Cache cache;

	/**
	 * Constructs a new Contentmanager with a default configuration.
	 * 
	 * @param cacheDir
	 *            the file cache folder.
	 */
	private ContentManager(String cacheDir) {
		this.config = new Configuration();
		this.config.setFileCache(true);
		this.config.setTimeOut(15);
		this.config.setCacheDirectory(cacheDir);
		this.cache = new Cache(this.config);
		if (ContentManager.log.isDebugEnabled()) {
			ContentManager.log.debug("Created ContentManager object.");
		}
	}

	/**
	 * Constructs a new Contentmanager with the given configuration.
	 * 
	 * @param config
	 *            the configuration bean.
	 */
	private ContentManager(Configuration config) {
		this.config = config;
		this.cache = new Cache(config);
		if (ContentManager.log.isDebugEnabled()) {
			ContentManager.log.debug("Created ContentManager object.");
		}
	}

	/**
	 * Factory for ContentManager with a file cache and a 15 minute time-out.
	 *
	 * @param cacheDir
	 *            the file cache folder.
	 * @return a ContentManager instance.
	 */
	public static ContentManager getInstance(String cacheDir) {
		if (ContentManager.defaultContentManager == null) {
			ContentManager.defaultContentManager = new ContentManager(cacheDir);
			ContentManager.MANAGERS.put(
					ContentManager.defaultContentManager.config,
					ContentManager.defaultContentManager);
		}

		return ContentManager.defaultContentManager;
	}

	/**
	 * Factory for ContentManager with the given configuration.
	 *
	 * @param config
	 *            the configuration bean.
	 * @return a ContentManager instance.
	 */
	public static ContentManager getInstance(Configuration config) {
		ContentManager manager = (ContentManager) ContentManager.MANAGERS
				.get(config);
		if (manager == null) {
			manager = new ContentManager(config);
			ContentManager.MANAGERS.put(config, manager);
		}
		return manager;
	}

	/**
	 * Returns the content for the given URL.
	 *
	 * @param url
	 *            the URL for which to retrieve content. The protocol must be
	 *            HTTP.
	 * @return the desired content.
	 * @throws com.bcbssc.pas.content.ContentException if any.
	 */
	public String getContent(URL url) throws ContentException {
		String content = this.cache.get(url);
		if (content == null) {
			try {
				content = this.readContent(url);
				this.cache.put(url, content);
			} catch (ContentException e) {
				if (this.config.isFileCache()) {
					ContentManager.log.error(
							"Error reading URL (failing to backup cache): "
									+ url, e);
					content = this.cache.getBackup(url);
				} else {
					throw e;
				}
			}
		} else if (ContentManager.log.isDebugEnabled()) {
			ContentManager.log.debug("Found in memory cache: " + url);
		}
		return content;
	}

	/**
	 * Returns the content for the given URL.
	 *
	 * @param url
	 *            the URL for which to retrieve content. The protocol must be
	 *            HTTP.
	 * @return the desired content.
	 * @see java.net.URL#URL(java.lang.String)
	 * @throws com.bcbssc.pas.content.ContentException if any.
	 */
	public String getContent(String url) throws ContentException {
		try {
			return this.getContent(new URL(url));
		} catch (MalformedURLException e) {
			throw new ContentException("Malformed URL: " + url, e);
		}
	}

	/**
	 * Returns the body content (between the &lt;Ektron&gt;&lt;/Ektron&gt; tags) for the
	 * given URL.
	 *
	 * @param url
	 *            the URL for which to retrieve content. The protocol must be
	 *            HTTP.
	 * @return the desired content.
	 * @throws com.bcbssc.pas.content.ContentException if any.
	 */
	public String getBodyContent(URL url) throws ContentException {
		String content = this.cache.get(url);
		if (content == null) {
			try {
				content = this.readContent(url);
				final int begin = content.indexOf("<Ektron>");
				final int end = content.indexOf("</Ektron>");

				if ((begin < 0) || (end < 0)) {
					throw new ContentException(
							"Invalid content, missing begin and end tags; URL="
									+ url);
				}
				content = content.substring(begin + 8, end);
				this.cache.put(url, content);
			} catch (ContentException e) {
				if (this.config.isFileCache()) {
					ContentManager.log.error(
							"Error reading URL (failing to backup cache): "
									+ url, e);
					content = this.cache.getBackup(url);
				} else {
					throw e;
				}
			}
		} else if (ContentManager.log.isDebugEnabled()) {
			ContentManager.log.debug("Found in memory cache: " + url);
		}
		return content;
	}

	/**
	 * Returns the body content (between the &lt;Ektron&gt;&lt;/Ektron&gt; tags) for the
	 * given URL.
	 *
	 * @param url
	 *            the URL for which to retrieve content. The protocol must be
	 *            HTTP.
	 * @return the desired content.
	 * @see java.net.URL#URL(java.lang.String)
	 * @throws com.bcbssc.pas.content.ContentException if any.
	 */
	public String getBodyContent(String url) throws ContentException {
		try {
			return this.getBodyContent(new URL(url));
		} catch (MalformedURLException e) {
			throw new ContentException("Malformed URL: " + url, e);
		}
	}

	private String readContent(URL url) throws ContentException {
		HttpURLConnection conn = null;
		BufferedInputStream in = null;
		StringWriter out = null;
		if (ContentManager.log.isDebugEnabled()) {
			ContentManager.log.debug("Reading URL: " + url);
		}
		try {
			conn = (HttpURLConnection) url.openConnection();
			conn.setRequestProperty("content-type", "text/html");
			conn.setRequestMethod("GET");
			in = new BufferedInputStream(conn.getInputStream());
			final int size = conn.getContentLength();
			out = new StringWriter(size < 16 ? 2048 : size);
			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new ContentException("Bad response code ("
						+ conn.getResponseCode()
						+ ") from Content Manager; URL=" + url);
			}
			int c = in.read();
			while (c >= 0) {
				out.write(c);
				c = in.read();
			}
			out.close(); // Does nothing
		} catch (Exception e) {
			throw new ContentException("Error reading URL: " + url, e);
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (Exception e) {
					ContentManager.log.warn("Error closing read-only resource",
							e);
				}
			}
			if (conn != null) {
				conn.disconnect();
			}
		}
		return out.toString();
	}
}
