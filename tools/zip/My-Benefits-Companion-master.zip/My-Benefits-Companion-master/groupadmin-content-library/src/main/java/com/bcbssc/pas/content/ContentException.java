/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2007 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-content/src/main/java/com/bcbssc/pas/content/ContentException.java_v  $
 * $Workfile:   ContentException.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:44:22  $
 * $Modtime:   May 14 2009 11:33:48  $
 */

package com.bcbssc.pas.content;

import java.io.PrintStream;
import java.io.PrintWriter;

import org.apache.log4j.Logger;

/**
 * Signals that an error has occurred in the Content Manager.
 *
 * @author DQ70
 * @version $Id: $Id
 */
public class ContentException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1468349454217862924L;

	private static final Logger log = Logger.getLogger(ContentException.class);

	private Throwable cause;

	/**
	 * Creates a new ContentException.
	 *
	 * @param s a {@link java.lang.String} object.
	 * @param t a {@link java.lang.Throwable} object.
	 */
	public ContentException(String s, Throwable t) {
		this(s);
		this.cause = t;
	}

	/**
	 * Creates a new ContentException.
	 *
	 * @param t a {@link java.lang.Throwable} object.
	 */
	public ContentException(Throwable t) {
		super();
		this.cause = t;
		if (ContentException.log.isDebugEnabled()) {
			ContentException.log.debug("Created ContentException object.");
		}
	}

	/**
	 * Creates a new ContentException.
	 *
	 * @param s a {@link java.lang.String} object.
	 */
	public ContentException(String s) {
		super(s);
		if (ContentException.log.isDebugEnabled()) {
			ContentException.log.debug("Created ContentException object.");
		}
	}

	/**
	 * <p>printStackTrace.</p>
	 *
	 * @see java.lang.Throwable#printStackTrace()
	 */
	public void printStackTrace() {
		super.printStackTrace();
		if (this.cause != null) {
			System.err.println("Cause:");
			this.cause.printStackTrace();
		}
	}

	/**
	 * <p>printStackTrace.</p>
	 *
	 * @see java.lang.Throwable#printStackTrace(java.io.PrintStream)
	 * @param s a {@link java.io.PrintStream} object.
	 */
	public void printStackTrace(PrintStream s) {
		super.printStackTrace(s);
		if (this.cause != null) {
			s.println("Cause:");
			this.cause.printStackTrace(s);
		}
	}

	/**
	 * <p>printStackTrace.</p>
	 *
	 * @see java.lang.Throwable#printStackTrace(java.io.PrintWriter)
	 * @param s a {@link java.io.PrintWriter} object.
	 */
	public void printStackTrace(PrintWriter s) {
		super.printStackTrace(s);
		if (this.cause != null) {
			s.println("Cause:");
			this.cause.printStackTrace(s);
		}
	}
}
