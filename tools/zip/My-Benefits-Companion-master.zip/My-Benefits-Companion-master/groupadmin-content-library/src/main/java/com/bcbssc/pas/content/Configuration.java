/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2007 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/MyInsuranceManager/commercial-library-content/src/main/java/com/bcbssc/pas/content/Configuration.java_v  $
 * $Workfile:   Configuration.java  $
 * $Revision:   1.0  $
 * $Date:   Jun 26 2009 15:44:20  $
 * $Modtime:   May 14 2009 11:33:48  $
 */

package com.bcbssc.pas.content;

import org.apache.log4j.Logger;

/**
 * The configuration bean for the ContentManager.
 *
 * @author DQ70
 * @version $Id: $Id
 */
public class Configuration {
	private static final Logger log = Logger.getLogger(Configuration.class);

	private int timeOut;

	private boolean fileCache;

	private String cacheDirectory;

	/**
	 * <p>Constructor for Configuration.</p>
	 */
	public Configuration() {
		if (Configuration.log.isDebugEnabled()) {
			Configuration.log.debug("Created Configuration object.");
		}
	}

	/**
	 * Indicates if a file cache will be used.
	 *
	 * @return the fileCache property.
	 */
	public boolean isFileCache() {
		return this.fileCache;
	}

	/**
	 * Determines whether or not a file cache will be used.
	 *
	 * @param fileCache
	 *            The fileCache value to set.
	 */
	public void setFileCache(boolean fileCache) {
		this.fileCache = fileCache;
	}

	/**
	 * Gets the time-out value for the cache.
	 *
	 * @return the timeOut property.
	 */
	public int getTimeOut() {
		return this.timeOut;
	}

	/**
	 * Sets the time-out value for the cache.
	 *
	 * @param timeOut
	 *            The timeOut value to set.
	 */
	public void setTimeOut(int timeOut) {
		this.timeOut = timeOut;
	}

	/**
	 * Gets the cache directory.
	 *
	 * @return Returns the cacheDirectory.
	 */
	public String getCacheDirectory() {
		return this.cacheDirectory;
	}

	/**
	 * Sets the cache directory.
	 *
	 * @param cacheDirectory
	 *            The cacheDirectory to set.
	 */
	public void setCacheDirectory(String cacheDirectory) {
		this.cacheDirectory = cacheDirectory;
	}

	/** {@inheritDoc} */
	public boolean equals(Object obj) {
		if (!(obj instanceof Configuration)) {
			return false;
		}

		final Configuration config = (Configuration) obj;

		return (this.fileCache == config.fileCache)
				&& (this.timeOut == config.timeOut);
	}

	/**
	 * <p>hashCode.</p>
	 *
	 * @see java.lang.Object#hashCode()
	 * @return a int.
	 */
	public int hashCode() {
		int hash = this.timeOut;
		hash += this.fileCache ? 10000 : 0;
		return hash;
	}
}
