/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.services.utils;

import com.bcbssc.services.ServicesAuthorizationException;
import com.bcbssc.services.ServicesDataAccessException;
import com.bcbssc.services.ServicesInputException;
import org.junit.Assert;
import org.junit.Test;

/**
 * The test class for {@link BaseServicesDAO}.
 */
public class BaseServicesDAOTest {

    /**
     * Test method for {@link BaseServicesDAO#checkResponseStatus(String, String, String)} with all null inputs.
     * @throws Exception Throws an exception based on the input.
     */
    @Test(expected = ServicesDataAccessException.class)
    public void testCheckResponseStatusNullInputs() throws Exception {
        BaseServicesDAO dao = new BaseServicesDAO();
        // with a null reponseStatusCode, it should throw an exception
        dao.checkResponseStatus(null, null, null);
    }

    /**
     * Test method for {@link BaseServicesDAO#checkResponseStatus(String, String, String)} with an invalid response
     * status code.
     * @throws Exception Throws an exception based on the input.
     */
    @Test(expected = ServicesDataAccessException.class)
    public void testCheckResponseStatusInvalidCode() throws Exception {
        BaseServicesDAO dao = new BaseServicesDAO();
        dao.checkResponseStatus("response", null, null);
    }

    /**
     * Test method for {@link BaseServicesDAO#checkResponseStatus(String, String, String)} with a padded status code.
     * @throws Exception Throws an exception based on the input.
     */
    @Test(expected = ServicesAuthorizationException.class)
    public void testCheckResponseStatusPaddedCode() throws Exception {
        BaseServicesDAO dao = new BaseServicesDAO();
        dao.checkResponseStatus(" 2 ", null, null);
    }

    /**
     * Test method for {@link BaseServicesDAO#checkResponseStatus(String, String, String)} with null status messages.
     * @throws Exception Throws an exception based on the input.
     */
    @Test
    public void testCheckResponseStatusNullMessages() throws Exception {
        BaseServicesDAO dao = new BaseServicesDAO();
        try {
            dao.checkResponseStatus("9abc", null, null);
        } catch (ServicesDataAccessException e) {
            // check to make sure the message was set to the responseStatusMessage - responseSystemMessage
            Assert.assertEquals("With null inputs, the message should have come out with a null message",
                    "null - null", e.getMessage());
        }
    }

    /**
     * Test method for {@link BaseServicesDAO#checkResponseStatus(String, String, String)} with populated status
     * messages.
     * @throws Exception Throws an exception based on the input.
     */
    @Test
    public void testCheckResponseStatusMessages() throws Exception {
        BaseServicesDAO dao = new BaseServicesDAO();
        try {
            dao.checkResponseStatus("9abc", "status", "system");
        } catch (ServicesDataAccessException e) {
            // check to make sure the message was set to the responseStatusMessage - responseSystemMessage
            Assert.assertEquals("With both messages set, an exception message should have been set",
                    "status - system", e.getMessage());
        }
    }

    /**
     * Test method for {@link BaseServicesDAO#checkResponseStatus(String, String, String)} with a code starting with 3.
     * @throws Exception Throws an exception based on the input.
     */
    @Test(expected = ServicesDataAccessException.class)
    public void testCheckResponseStatusDataAccessExceptions3() throws Exception {
        BaseServicesDAO dao = new BaseServicesDAO();
        dao.checkResponseStatus("3", "status", "system");
    }

    /**
     * Test method for {@link BaseServicesDAO#checkResponseStatus(String, String, String)} with a code starting with 4.
     * @throws Exception Throws an exception based on the input.
     */
    @Test(expected = ServicesDataAccessException.class)
    public void testCheckResponseStatusDataAccessExceptions4() throws Exception {
        BaseServicesDAO dao = new BaseServicesDAO();
        dao.checkResponseStatus("4", "status", "system");
    }

    /**
     * Test method for {@link BaseServicesDAO#checkResponseStatus(String, String, String)} with a code starting with 5.
     * @throws Exception Throws an exception based on the input.
     */
    @Test(expected = ServicesDataAccessException.class) 
    /* @Test(expected = ServicesAuthorizationException.class)*/
    public void testCheckResponseStatusDataAccessExceptions5() throws Exception {
        BaseServicesDAO dao = new BaseServicesDAO();
        dao.checkResponseStatus("5", "status", "system");
    }

    /**
     * Test method for {@link BaseServicesDAO#checkResponseStatus(String, String, String)} with a code starting with 6.
     * @throws Exception Throws an exception based on the input.
     */
    @Test(expected = ServicesDataAccessException.class)
    public void testCheckResponseStatusDataAccessExceptions6() throws Exception {
        BaseServicesDAO dao = new BaseServicesDAO();
        dao.checkResponseStatus("6", "status", "system");
    }

    /**
     * Test method for {@link BaseServicesDAO#checkResponseStatus(String, String, String)} with a code starting with 7.
     * @throws Exception Throws an exception based on the input.
     */
    @Test(expected = ServicesDataAccessException.class)
    public void testCheckResponseStatusDataAccessExceptions7() throws Exception {
        BaseServicesDAO dao = new BaseServicesDAO();
        dao.checkResponseStatus("7", "status", "system");
    }

    /**
     * Test method for {@link BaseServicesDAO#checkResponseStatus(String, String, String)} with a code starting with 8.
     * @throws Exception Throws an exception based on the input.
     */
    @Test(expected = ServicesDataAccessException.class)
    public void testCheckResponseStatusDataAccessExceptions8() throws Exception {
        BaseServicesDAO dao = new BaseServicesDAO();
        dao.checkResponseStatus("8", "status", "system");
    }

    /**
     * Test method for {@link BaseServicesDAO#checkResponseStatus(String, String, String)} with a code starting with 9.
     * @throws Exception Throws an exception based on the input.
     */
    @Test(expected = ServicesDataAccessException.class)
    public void testCheckResponseStatusDataAccessExceptions9() throws Exception {
        BaseServicesDAO dao = new BaseServicesDAO();
        dao.checkResponseStatus("9", "status", "system");
    }

    /**
     * Test method for {@link BaseServicesDAO#checkResponseStatus(String, String, String)} with a code starting with 1.
     * @throws Exception Throws an exception based on the input.
     */
    @Test(expected = ServicesInputException.class)
    public void testCheckResponseStatusServicesInputException() throws Exception {
        BaseServicesDAO dao = new BaseServicesDAO();
        dao.checkResponseStatus("1", "status", "system");
    }

    /**
     * Test method for {@link BaseServicesDAO#checkResponseStatus(String, String, String)} with a code starting with 2.
     * @throws Exception Throws an exception based on the input.
     */
    @Test(expected = ServicesAuthorizationException.class)
    public void testCheckResponseStatusServicesAuthorizationException() throws Exception {
        BaseServicesDAO dao = new BaseServicesDAO();
        dao.checkResponseStatus("2", "status", "system");
    }
}
