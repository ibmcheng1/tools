/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2006 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * BeanFactoryUtils.java
 * 
 * Created on Apr 6, 2006, 6:36:29 PM by DG70
 */

package com.bcbssc.services.utils;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.access.BeanFactoryLocator;
import org.springframework.beans.factory.access.BeanFactoryReference;
import org.springframework.beans.factory.access.SingletonBeanFactoryLocator;

/**
 * BeanFactoryUtils is a helper class for accessing Spring Framework - managed
 * objects.  It comprises the "glue code" between the application and Spring,
 * and serves as a decoupler from org.springframework.* APIs.
 * <pre>
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-services-utils/src/main/java/com/bcbssc/services/utils/BeanFactoryUtils.java_v  $
 * $Workfile:   BeanFactoryUtils.java  $
 * $Revision:   1.0  $
 * $Date:   Nov 30 2009 13:53:56  $
 * $Modtime:   Nov 30 2009 13:43:36  $
 * </pre>
 *
 * @author $Author:   EN80  $
 * @version $Id: $Id
 */
public class BeanFactoryUtils {

    /** Constant <code>DEFAULT_BEAN_FACTORY_NAME="com.bcbssc.mim.defaultbeanfactory"</code> */
    public static final String DEFAULT_BEAN_FACTORY_NAME = "com.bcbssc.mim.defaultbeanfactory";
    
    private static BeanFactoryLocator defaultLocator = null;
    
    private String beanFactoryName;
    
    /**
     * <p>Constructor for BeanFactoryUtils.</p>
     */
    public BeanFactoryUtils(){    	
    	beanFactoryName = DEFAULT_BEAN_FACTORY_NAME;
    }
    
    /**
     * <p>Constructor for BeanFactoryUtils.</p>
     *
     * @param beanFactoryName a {@link java.lang.String} object.
     */
    public BeanFactoryUtils(String beanFactoryName){
    	this.beanFactoryName = beanFactoryName;
    }
    
    /**
     * Sets a global, singleton BeanFactoryLocator to be used by all instances
     * of BeanFactoryUtils.
     * Note: If one is never set, this class will utilize Spring's
     * <code>SingletonBeanFactoryLocator</code>.
     *
     * @param locator a BeanFactoryLocator implementation to be used by all
     * BeanFactoryUtils instances.
     */
    public static void setDefaultBeanFactoryLocator(BeanFactoryLocator locator) {
        defaultLocator = locator;
    }
    
    /**
     * Retrieves an object of an expected type, using a default bean factory
     * and using the class name of the expectedType as the String name of the
     * bean
     *
     * @param expectedType the type of object expected
     * @return an instantiated object of the requested type, typically
     * prototyped via external configuration.
     * @throws java.lang.NullPointerException if expectedType or beanName is null
     * @see #getBean(String, String, Class)
     * @param beanName a {@link java.lang.String} object.
     */
    public Object getBean(String beanName, Class expectedType) {
        return this.getBean(beanFactoryName, beanName, expectedType);
    }
    
    /**
     * Retrieves an object of an expected type, using the type's name itself
     * as the beanName
     *
     * @param expectedType the type of object expected
     * @return an instantiated object of the requested type, typically
     * prototyped via external configuration.
     * @throws java.lang.NullPointerException if expectedType is null
     * @see #getBean(String, Class)
     */
    public Object getBean(Class expectedType) {
        return (this.getBean(expectedType.getName(), expectedType));
    }
    
    /**
     * Retrieves an object produced by the Spring Framework.  In a way, this
     * method acts as a supreme object factory.
     *
     * @param factoryName the name of a particular factory that may
     * contain the bean in question.
     * @param beanName a {@link java.lang.String} object.
     * @throws org.springframework.beans.BeansException (a runtime exception)
     * if an error occurs during bean retrieval.  This may be anything from
     * an instantiation error to an improper configuration, etc.
     * @see BeanFactory#getBean(String, Class)
     * @param expectedType a {@link java.lang.Class} object.
     * @return a {@link java.lang.Object} object.
     */
    public Object getBean(String factoryName, String beanName, Class expectedType) {
        BeanFactory beanFactory = this.getBeanFactory(factoryName);
        //use the 2-arg flavor of getBean() to prevent our caller from getting
        //classcast exceptions if the factory gives back an unexpected type
        //(e.g., something's configured wrong)
        return beanFactory.getBean(beanName, expectedType);
    }
    
    /**
     * <p>getBeanFactory.</p>
     *
     * @param name a {@link java.lang.String} object.
     * @return a {@link org.springframework.beans.factory.BeanFactory} object.
     */
    protected BeanFactory getBeanFactory(String name) {
        BeanFactoryLocator factoryLocator = this.getBeanFactoryLocator();
        BeanFactoryReference beanFactoryReference = factoryLocator.useBeanFactory(name);
        
        return beanFactoryReference.getFactory();
    }
    
    /**
     * <p>getBeanFactoryLocator.</p>
     *
     * @return a {@link org.springframework.beans.factory.access.BeanFactoryLocator} object.
     */
    protected BeanFactoryLocator getBeanFactoryLocator() {
        BeanFactoryLocator locator = defaultLocator;
        if (locator == null) {
            locator = this.createBeanFactoryLocator();
        }
        
        return locator;
    }
    
    /**
     * <p>createBeanFactoryLocator.</p>
     *
     * @return a {@link org.springframework.beans.factory.access.BeanFactoryLocator} object.
     */
    protected BeanFactoryLocator createBeanFactoryLocator() {
        return SingletonBeanFactoryLocator.getInstance();
    }
}
