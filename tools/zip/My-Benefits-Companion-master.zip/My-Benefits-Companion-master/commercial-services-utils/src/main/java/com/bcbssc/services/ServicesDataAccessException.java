/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2007 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * ServiceDataAccessException.java
 * 
 * Created on Jul 26, 2007, 1:28:25 PM by X33B
 */

package com.bcbssc.services;

/**
 * Exception class
 *
 * <pre>
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-services-utils/src/main/java/com/bcbssc/services/ServicesDataAccessException.java_v  $
 * $Workfile:   ServicesDataAccessException.java  $
 * $Revision:   1.0  $
 * $Date:   Nov 30 2009 13:53:54  $
 * $Modtime:   Nov 30 2009 13:41:26  $
 * </pre>
 *
 * @author $Author:   EN80  $
 * @version $Id: $Id
 */
public class ServicesDataAccessException extends Exception {
    
	private static final long serialVersionUID = 678672332867l;
    /**
     * <p>Constructor for ServicesDataAccessException.</p>
     *
     * @param message a {@link java.lang.String} object.
     */
    public ServicesDataAccessException(String message) {
        super(message);
    }

    /**
     * <p>Constructor for ServicesDataAccessException.</p>
     *
     * @param cause a {@link java.lang.Throwable} object.
     */
    public ServicesDataAccessException(Throwable cause) {
        super(cause.toString());
    }

    /**
     * <p>Constructor for ServicesDataAccessException.</p>
     *
     * @param message a {@link java.lang.String} object.
     * @param cause a {@link java.lang.Throwable} object.
     */
    public ServicesDataAccessException(String message, Throwable cause) {
        super(message, cause);
    }
}
