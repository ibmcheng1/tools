/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 * BaseServicesDAO.java
 *
 * Created on Nov 19, 2009 by EN80

 */

package com.bcbssc.services.utils;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.bcbssc.services.ServicesAuthorizationException;
import com.bcbssc.services.ServicesDataAccessException;
import com.bcbssc.services.ServicesInputException;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;

/**
 * Base class for Services DAO with common methods.
 *
 * <pre>
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-services-utils/src/main/java/com/bcbssc/services/utils/BaseServicesDAO.java_v  $
 * $Workfile:   BaseServicesDAO.java  $
 * $Revision:   1.1  $
 * $Date:   Dec 21 2010 15:15:52  $
 * $Modtime:   Dec 21 2010 15:14:26  $
 * </pre>
 *
 * @author $Author:   x94s  $
 * @version $Id: $Id
 */
public class BaseServicesDAO {

private static final Logger log = Logger.getLogger(BaseServicesDAO.class);

private String beanFactoryPath;
private String baseEndpointUrl;
private String baseEndpointRegion;
/** Constant <code>FACTORY_UTILS</code> */
public static BeanFactoryUtils FACTORY_UTILS =null;
/**
 * <p>checkResponseStatus.</p>
 *
 * @param responseStatusCode a {@link java.lang.String} object.
 * @param responseStatusMessage a {@link java.lang.String} object.
 * @param responseSystemMessage a {@link java.lang.String} object.
 * @throws java.lang.Exception if any.
 */
public void checkResponseStatus(String responseStatusCode, String responseStatusMessage, String responseSystemMessage) throws Exception{

		if(log.isDebugEnabled()){
			log.debug(
					"Checking response status:" +
					" responseStatusCode=" + responseStatusCode +
					", responseStatusMessage=" + responseStatusMessage +
					", responseSystemMessage=" + responseSystemMessage);
		}
		/*
		 * 0000 - 0999: Successfully executed
		 * 1000 - 1999: Input error
		 * 2000 - 2999: Access error
		 * 3000 - 9999: Internal failure
		 */
		String exceptionMessage = responseStatusMessage + " - " + responseSystemMessage;
		if(StringUtils.isNotBlank(responseStatusCode)){
			String responseType = StringUtils.substring(responseStatusCode.trim(), 0, 1);
			if(StringUtils.isNumeric(responseType)){
				int responseTypeInt = Integer.parseInt(responseType);
				if(responseTypeInt == 1){
					//Input error
					throw new ServicesInputException(exceptionMessage);
				} else if(responseTypeInt == 2){
					//Access error
					throw new ServicesAuthorizationException(exceptionMessage);
				} else if(responseTypeInt >= 3){
					//Internal error
					throw new ServicesDataAccessException(exceptionMessage);
				}
			} else{
				//Response code is invalid (ie. does not start with a number)
				throw new ServicesDataAccessException("Invalid response status code: " + responseStatusCode);
			}
		} else{
			//Response code is missing
			throw new ServicesDataAccessException("Missing response status code.");
		}

	}

	/**
	 * <p>getServiceWithHandlersLoaded.</p>
	 *
	 * @param serviceInterfaceClass a {@link java.lang.Class} object.
	 * @param serviceName a {@link java.lang.String} object.
	 * @return a {@link javax.xml.rpc.Service} object.
	 * @throws javax.xml.rpc.ServiceException if any.
	 */
	public Service getServiceWithHandlersLoaded(Class serviceInterfaceClass, String serviceName) throws ServiceException {

		return getServiceWithHandlersLoaded(serviceInterfaceClass,serviceName,false);
	}

	/**
	 * <p>getServiceWithHandlersLoaded.</p>
	 *
	 * @param serviceInterfaceClass a {@link java.lang.Class} object.
	 * @param serviceName a {@link java.lang.String} object.
	 * @param soaExpress a boolean.
	 * @throws javax.xml.rpc.ServiceException
	 * @return a {@link javax.xml.rpc.Service} object.
	 */
	public Service getServiceWithHandlersLoaded(Class serviceInterfaceClass,String serviceName, boolean soaExpress) throws ServiceException {

		Service returnService = null;
		try {
			// BeanPath should be set in service defination
			if(StringUtils.isBlank(this.getBeanFactoryPath())){
				this.setBeanFactoryPath("com.bcbssc.mim.defaultbeanfactory");
			}
			FACTORY_UTILS        = new BeanFactoryUtils(this.getBeanFactoryPath());
			WebServiceHandlersInput handlersInput = new WebServiceHandlersInput();
			// consumer ID and password are not going change from service to service
			handlersInput.setWsSecurityId((String)FACTORY_UTILS.getBean("web.services.consumer.id", String.class));
			handlersInput.setWsSecurityPassword((String)FACTORY_UTILS.getBean("web.services.consumer.password", String.class));
 			// HOST RACF ID and password are not going change from service to service
			handlersInput.setCicsHostID((String)FACTORY_UTILS.getBean("web.services.host.id", String.class));
			handlersInput.setCicsHostPassword((String)FACTORY_UTILS.getBean("web.services.host.password", String.class));
			/*
			 * endPointURl and region may vary for services during development. So set those value in bean defination while
			 * defining the service. In case if those values were not set, set to defult url and region.
			 */


			if(StringUtils.isBlank(this.getBaseEndpointRegion())){

				if(serviceName.equalsIgnoreCase("ImageGatewayRetriever")){
				this.setBaseEndpointRegion((String)FACTORY_UTILS.getBean("DocumentArchive.baseImageGatewayRegion", String.class)); 
				}else if(serviceName.equalsIgnoreCase("ValidateSAMLAssertion")){
					this.setBaseEndpointRegion((String)FACTORY_UTILS.getBean("ValidateSAMLAssertion.baseEndpointRegion", String.class));
				}else if(serviceName.equalsIgnoreCase("CTICallDataStore")){
					this.setBaseEndpointRegion((String)FACTORY_UTILS.getBean("CTICallDataStore.baseEndpointRegion", String.class));
				}else{
					this.setBaseEndpointRegion((String)FACTORY_UTILS.getBean("web.services.baseendpoint.region.default", String.class));
				}

			}


			if(StringUtils.isBlank(this.getBaseEndpointUrl())){

				if(serviceName.equalsIgnoreCase("ImageGatewayRetriever")){
					this.setBaseEndpointUrl((String)FACTORY_UTILS.getBean("DocumentArchive.baseImageGatewayUrl", String.class));
				}else if(serviceName.equalsIgnoreCase("ValidateSAMLAssertion")){
					this.setBaseEndpointUrl((String)FACTORY_UTILS.getBean("ValidateSAMLAssertion.baseEndpointUrl", String.class));
				}else if(serviceName.equalsIgnoreCase("CTICallDataStore")){
					this.setBaseEndpointUrl((String)FACTORY_UTILS.getBean("CTICallDataStore.baseEndpointUrl", String.class));
				}else{
					this.setBaseEndpointUrl((String)FACTORY_UTILS.getBean("web.services.baseendpoint.url.default", String.class));
				}

			}



            handlersInput.setBaseEndpointUrl(this.getBaseEndpointUrl());

			handlersInput.setBaseEndpointRegion(this.getBaseEndpointRegion());
			handlersInput.setCicsRegion(this.getBaseEndpointRegion());

			LoadJaxRpcHandlers jaxrpcHandlers = new LoadJaxRpcHandlers(handlersInput);
			returnService = jaxrpcHandlers.getServiceWithJaxRpcHandlers(serviceInterfaceClass, serviceName, soaExpress);
		}catch(ServiceException ex) {
			throw new ServiceException(serviceName + " Can not be loaded with required JAX RPC Handlers" + ex);
		}

		return returnService;
	}

	/**
	 * <p>Getter for the field <code>beanFactoryPath</code>.</p>
	 *
	 * @return the beanFactoryPath
	 */
	public String getBeanFactoryPath() {
		return beanFactoryPath;
	}

	/**
	 * <p>Setter for the field <code>beanFactoryPath</code>.</p>
	 *
	 * @param beanFactoryPath the beanFactoryPath to set
	 */
	public void setBeanFactoryPath(String beanFactoryPath) {
		this.beanFactoryPath = beanFactoryPath;
	}

	/**
	 * <p>Getter for the field <code>baseEndpointRegion</code>.</p>
	 *
	 * @return the baseEndpointRegion
	 */
	public String getBaseEndpointRegion() {
		return baseEndpointRegion;
	}

	/**
	 * <p>Setter for the field <code>baseEndpointRegion</code>.</p>
	 *
	 * @param baseEndpointRegion the baseEndpointRegion to set
	 */
	public void setBaseEndpointRegion(String baseEndpointRegion) {
		this.baseEndpointRegion = baseEndpointRegion;
	}

	/**
	 * <p>Getter for the field <code>baseEndpointUrl</code>.</p>
	 *
	 * @return the baseEndpointUrl
	 */
	public String getBaseEndpointUrl() {
		return baseEndpointUrl;
	}

	/**
	 * <p>Setter for the field <code>baseEndpointUrl</code>.</p>
	 *
	 * @param baseEndpointUrl the baseEndpointUrl to set
	 */
	public void setBaseEndpointUrl(String baseEndpointUrl) {
		this.baseEndpointUrl = baseEndpointUrl;
	}





}
