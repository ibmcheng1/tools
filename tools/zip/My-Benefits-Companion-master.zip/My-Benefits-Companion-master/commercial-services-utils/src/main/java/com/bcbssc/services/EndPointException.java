/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUE CROSS AND BLUE SHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION, OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright (c) 2006 Blue Cross and Blue Shield of South Carolina.
 * All rights reserved.
 * An independent licensee of the Blue Cross and Blue Shield Association.
 *
 * EndPointException.java
 *
 */
package com.bcbssc.services;

/**
 * End point Exception
 *
 * <pre>
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-services-utils/src/main/java/com/bcbssc/services/EndPointException.java_v  $
 * $Workfile:   EndPointException.java  $
 * $Revision:   1.0  $
 * $Date:   Nov 30 2009 13:53:54  $
 * $Modtime:   Nov 30 2009 13:40:16  $
 * </pre>
 *
 * @author $Author:   EN80  $
 * @version $Id: $Id
 */
public class EndPointException extends Exception {

	private static final long serialVersionUID = 67867867l;
	/**
	 * <p>Constructor for EndPointException.</p>
	 */
	public EndPointException() {
	}

	/**
	 * <p>Constructor for EndPointException.</p>
	 *
	 * @param message a {@link java.lang.String} object.
	 */
	public EndPointException(String message) {
		super(message);
	}

	/**
	 * <p>Constructor for EndPointException.</p>
	 *
	 * @param cause a {@link java.lang.Throwable} object.
	 */
	public EndPointException(Throwable cause) {
		super(cause);
	}

	/**
	 * <p>Constructor for EndPointException.</p>
	 *
	 * @param message a {@link java.lang.String} object.
	 * @param cause a {@link java.lang.Throwable} object.
	 */
	public EndPointException(String message, Throwable cause) {
		super(message, cause);
	}

}
