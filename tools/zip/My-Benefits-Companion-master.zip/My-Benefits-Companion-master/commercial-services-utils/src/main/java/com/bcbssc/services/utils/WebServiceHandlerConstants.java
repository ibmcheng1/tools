/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * WebServiceHandlerConstants.java
 * 
 * Created on Nov 19, 2009 by EN80

 */

package com.bcbssc.services.utils;

import java.io.Serializable;

/**
 * Constants
 *
 * <pre>
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-services-utils/src/main/java/com/bcbssc/services/utils/WebServiceHandlerConstants.java_v  $
 * $Workfile:   WebServiceHandlerConstants.java  $
 * $Revision:   1.0  $
 * $Date:   Nov 30 2009 13:53:58  $
 * $Modtime:   Nov 30 2009 13:51:10  $
 * </pre>
 *
 * @author $Author:   EN80  $
 * @version $Id: $Id
 */
public class WebServiceHandlerConstants implements Serializable {

	private static final long serialVersionUID = 347353L;
    
	/** Constant <code>STRATEGY_SIMPLE="simple"</code> */
	public static final String STRATEGY_SIMPLE              = "simple";
	/** Constant <code>CLIENTCONFIG_STRATEGY="clientconfig.strategy"</code> */
	public static final String CLIENTCONFIG_STRATEGY        = "clientconfig.strategy";	
	/** Constant <code>SIMPLE_HOSTID="simple.hostid"</code> */
	public static final String SIMPLE_HOSTID                = "simple.hostid";
	/** Constant <code>SIMPLE_HOSTPASSWORD="simple.hostpassword"</code> */
	public static final String SIMPLE_HOSTPASSWORD          = "simple.hostpassword";
	/** Constant <code>SIMPLE_REGION="simple.region"</code> */
	public static final String SIMPLE_REGION                = "simple.region";
	/** Constant <code>ENDPOINT_STRATEGY="endpoint.strategy"</code> */
	public static final String ENDPOINT_STRATEGY            = "endpoint.strategy";
	/** Constant <code>SIMPLE_BASEURL="simple.baseurl"</code> */
	public static final String SIMPLE_BASEURL               = "simple.baseurl";
	/** Constant <code>CREDENTIAL_STRATEGY="credential.strategy"</code> */
	public static final String CREDENTIAL_STRATEGY          = "credential.strategy";
	/** Constant <code>SIMPLE_USERNAME="simple.username"</code> */
	public static final String SIMPLE_USERNAME              = "simple.username";
	/** Constant <code>SIMPLE_PASSWORD="simple.password"</code> */
	public static final String SIMPLE_PASSWORD              = "simple.password";
	/** Constant <code>SERVICE_NAME="service.name"</code> */
	public static final String SERVICE_NAME                 = "service.name";
}
