/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * WebServiceHandlersInput.java
 * 
 * Created on Nov 19, 2009 by EN80

 */

package com.bcbssc.services.utils;

import java.io.Serializable;

/**
 * Model for Service hanlders input.
 *
 * <pre>
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-services-utils/src/main/java/com/bcbssc/services/utils/WebServiceHandlersInput.java_v  $
 * $Workfile:   WebServiceHandlersInput.java  $
 * $Revision:   1.0  $
 * $Date:   Nov 30 2009 13:53:58  $
 * $Modtime:   Nov 30 2009 13:51:36  $
 * </pre>
 *
 * @author $Author:   EN80  $
 * @version $Id: $Id
 */
public class WebServiceHandlersInput implements Serializable {

	private static final long serialVersionUID = 34353L;
	
	 private String baseEndpointUrl;
	 private String baseEndpointRegion;
	 private String wsSecurityId;
	 private String wsSecurityPassword;
	 private String cicsHostID;
	 private String cicsHostPassword;
	 private String cicsRegion;
	/**
	 * <p>Getter for the field <code>baseEndpointRegion</code>.</p>
	 *
	 * @return the baseEndpointRegion
	 */
	public String getBaseEndpointRegion() {
		return baseEndpointRegion;
	}
	/**
	 * <p>Setter for the field <code>baseEndpointRegion</code>.</p>
	 *
	 * @param baseEndpointRegion the baseEndpointRegion to set
	 */
	public void setBaseEndpointRegion(String baseEndpointRegion) {
		this.baseEndpointRegion = baseEndpointRegion;
	}
	/**
	 * <p>Getter for the field <code>baseEndpointUrl</code>.</p>
	 *
	 * @return the baseEndpointUrl
	 */
	public String getBaseEndpointUrl() {
		return baseEndpointUrl;
	}
	/**
	 * <p>Setter for the field <code>baseEndpointUrl</code>.</p>
	 *
	 * @param baseEndpointUrl the baseEndpointUrl to set
	 */
	public void setBaseEndpointUrl(String baseEndpointUrl) {
		this.baseEndpointUrl = baseEndpointUrl;
	}
	/**
	 * <p>Getter for the field <code>cicsHostID</code>.</p>
	 *
	 * @return the cicsHostID
	 */
	public String getCicsHostID() {
		return cicsHostID;
	}
	/**
	 * <p>Setter for the field <code>cicsHostID</code>.</p>
	 *
	 * @param cicsHostID the cicsHostID to set
	 */
	public void setCicsHostID(String cicsHostID) {
		this.cicsHostID = cicsHostID;
	}
	/**
	 * <p>Getter for the field <code>cicsHostPassword</code>.</p>
	 *
	 * @return the cicsHostPassword
	 */
	public String getCicsHostPassword() {
		return cicsHostPassword;
	}
	/**
	 * <p>Setter for the field <code>cicsHostPassword</code>.</p>
	 *
	 * @param cicsHostPassword the cicsHostPassword to set
	 */
	public void setCicsHostPassword(String cicsHostPassword) {
		this.cicsHostPassword = cicsHostPassword;
	}
	/**
	 * <p>Getter for the field <code>cicsRegion</code>.</p>
	 *
	 * @return the cicsRegion
	 */
	public String getCicsRegion() {
		return cicsRegion;
	}
	/**
	 * <p>Setter for the field <code>cicsRegion</code>.</p>
	 *
	 * @param cicsRegion the cicsRegion to set
	 */
	public void setCicsRegion(String cicsRegion) {
		this.cicsRegion = cicsRegion;
	}
	/**
	 * <p>Getter for the field <code>wsSecurityId</code>.</p>
	 *
	 * @return the wsSecurityId
	 */
	public String getWsSecurityId() {
		return wsSecurityId;
	}
	/**
	 * <p>Setter for the field <code>wsSecurityId</code>.</p>
	 *
	 * @param wsSecurityId the wsSecurityId to set
	 */
	public void setWsSecurityId(String wsSecurityId) {
		this.wsSecurityId = wsSecurityId;
	}
	/**
	 * <p>Getter for the field <code>wsSecurityPassword</code>.</p>
	 *
	 * @return the wsSecurityPassword
	 */
	public String getWsSecurityPassword() {
		return wsSecurityPassword;
	}
	/**
	 * <p>Setter for the field <code>wsSecurityPassword</code>.</p>
	 *
	 * @param wsSecurityPassword the wsSecurityPassword to set
	 */
	public void setWsSecurityPassword(String wsSecurityPassword) {
		this.wsSecurityPassword = wsSecurityPassword;
	}
	 
	/**
	 * <p>toString.</p>
	 *
	 * @return a {@link java.lang.String} object.
	 */
	public String toString() {
		
		StringBuffer returnString = new StringBuffer();
		returnString.append("baseEndpointUrl =" +baseEndpointUrl +"\t");
		returnString.append("baseEndpointRegion =" +baseEndpointRegion +"\t");
		returnString.append("wsSecurityId =" +wsSecurityId +"\t");
		returnString.append("wsSecurityPassword =" +wsSecurityPassword +"\t");
		returnString.append("cicsHostID =" +cicsHostID +"\t");
		returnString.append("cicsHostPassword =" +cicsHostPassword +"\t");
		returnString.append("cicsRegion =" +cicsRegion +"\t");
		return returnString.toString();
	}
	 
}
