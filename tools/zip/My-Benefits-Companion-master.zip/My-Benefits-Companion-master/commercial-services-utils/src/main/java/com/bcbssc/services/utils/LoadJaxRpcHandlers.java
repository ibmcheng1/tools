/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.

 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * LoadJaxRpcHandlers.java
 * 
 * Created on Nov 18, 2009 by EN80

 */

package com.bcbssc.services.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.ServiceFactory;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.HandlerRegistry;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.bcbssc.wsutils.jaxrpc.BcbsscStandardEndpointHandler;
import com.bcbssc.wsutils.jaxrpc.BcbsscStandardWsseHandler;
import com.bcbssc.wsutils.jaxrpc.SoaExpressHandler;

/**
 *Utility class for loading the required JAX rpc hanlders .
 *
 * <pre>
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-services-utils/src/main/java/com/bcbssc/services/utils/LoadJaxRpcHandlers.java_v  $
 * $Workfile:   LoadJaxRpcHandlers.java  $
 * $Revision:   1.0  $
 * $Date:   Nov 30 2009 13:53:56  $
 * $Modtime:   Nov 30 2009 13:44:42  $
 * </pre>
 *
 * @author $Author:   EN80  $
 * @version $Id: $Id
 */
public class LoadJaxRpcHandlers {
    
	private String baseEndpointUrl;
    private String baseEndpointRegion;
    private String wsSecurityId;
    private String wsSecurityPassword;
    private String cicsHostID;
    private String cicsHostPassword;
    private String cicsRegion;
    
    static Logger logger = Logger.getLogger(LoadJaxRpcHandlers.class);
    
    /**
     * <p>Constructor for LoadJaxRpcHandlers.</p>
     *
     * @param webServiceHandlerInput a {@link com.bcbssc.services.utils.WebServiceHandlersInput} object.
     */
    public LoadJaxRpcHandlers(WebServiceHandlersInput webServiceHandlerInput){
    	
    	
    	baseEndpointUrl     =webServiceHandlerInput.getBaseEndpointUrl();
    	baseEndpointRegion  =webServiceHandlerInput.getBaseEndpointRegion();
    	wsSecurityId        =webServiceHandlerInput.getWsSecurityId();
    	wsSecurityPassword  =webServiceHandlerInput.getWsSecurityPassword();
    	cicsHostID          =webServiceHandlerInput.getCicsHostID();
    	cicsHostPassword    =webServiceHandlerInput.getCicsHostPassword();
    	cicsRegion          =webServiceHandlerInput.getCicsRegion();
    	if(logger.isDebugEnabled()) {
			logger.debug("Inside LoadJaxRpcHandlers data passed: " + 	webServiceHandlerInput.toString());
		}
    }
    
    
	/**
	 * <p>getServiceWithJaxRpcHandlers.</p>
	 *
	 * @param serviceInterfaceClass a {@link java.lang.Class} object.
	 * @param serviceName a {@link java.lang.String} object.
	 * @param soaExpress a boolean.
	 * @throws javax.xml.rpc.ServiceException
	 * @return a {@link javax.xml.rpc.Service} object.
	 */
	public Service getServiceWithJaxRpcHandlers(Class serviceInterfaceClass,
		String serviceName, boolean soaExpress) throws ServiceException {
		if(logger.isDebugEnabled()) {
			logger.debug("Inside getServiceWithJaxRpcHandlers" + " serviceName =" + serviceName
					+ " soaExpress= " + soaExpress + " serviceInterfaceClass = " + serviceInterfaceClass.getName());
		}
		if (StringUtils.isBlank(serviceName)) {
			throw new ServiceException ("serviceName cannot be null.Please check the service name.");
		}else if(StringUtils.isBlank(this.baseEndpointUrl)) {
			throw new ServiceException ("baseEndpointUrl cannot be null.Please check the value.");
		}else if(StringUtils.isBlank(this.baseEndpointRegion)) {
			throw new ServiceException ("baseEndpointRegion cannot be null.Please check the value.");
		}else if(StringUtils.isBlank(this.wsSecurityId)) {
			throw new ServiceException ("wsSecurityId cannot be null.Please check the value.");
		}else if(StringUtils.isBlank(this.wsSecurityPassword)) {
			throw new ServiceException ("wsSecurityPassword cannot be null.Please check the value.");
		}else if(StringUtils.isBlank(this.cicsHostID)) {
			throw new ServiceException ("cicsHostID cannot be null.Please check the value.");
		}else if(StringUtils.isBlank(this.cicsHostPassword)) {
			throw new ServiceException ("cicsHostPassword cannot be null.Please check the value.");
		}else if(StringUtils.isBlank(this.cicsRegion)) {
			throw new ServiceException ("cicsRegion cannot be null.Please check the value.");
		}
		ServiceFactory serviceFactory = ServiceFactory.newInstance();
		Service service = serviceFactory.loadService(serviceInterfaceClass);
		HandlerRegistry registry = service.getHandlerRegistry();
		Iterator portsIterator = service.getPorts();
        
		while (portsIterator.hasNext()) {
			List chain = registry.getHandlerChain((QName)portsIterator.next());
			if (chain != null) {

				chain.addAll(this.getJaxRpcHandlerInfo(serviceName,soaExpress));
			}

		}

		return service;

	}

	/**
	 * @param serviceName
	 * @param soaExpress
	 * @return
	 */
	private List getJaxRpcHandlerInfo(String serviceName,
			boolean soaExpress) {		
		
		List<HandlerInfo> list = new ArrayList<HandlerInfo>();
        // Config SoaExpressHandler now
		if (soaExpress) {
			Map<String, String> soaxConfig = new HashMap<String, String>();
			soaxConfig.put(WebServiceHandlerConstants.CLIENTCONFIG_STRATEGY, WebServiceHandlerConstants.STRATEGY_SIMPLE);
			soaxConfig.put(WebServiceHandlerConstants.SIMPLE_HOSTID, cicsHostID);
			soaxConfig.put(WebServiceHandlerConstants.SIMPLE_HOSTPASSWORD, cicsHostPassword);
			soaxConfig.put(WebServiceHandlerConstants.SIMPLE_REGION, cicsRegion);
			HandlerInfo soaxInfo = new HandlerInfo(SoaExpressHandler.class,
					soaxConfig, null);

			list.add(soaxInfo);
			if(logger.isDebugEnabled()) {
				logger.debug("SoaExpressHandler has added to the chain with parameters " + soaxConfig.toString());
			}

		}
 	    //Config BcbsscStandardEndpointHandler now
		Map<String, String> endpointConfig = new HashMap<String, String>();
		endpointConfig.put(WebServiceHandlerConstants.SERVICE_NAME, serviceName);
		endpointConfig.put(WebServiceHandlerConstants.ENDPOINT_STRATEGY, WebServiceHandlerConstants.STRATEGY_SIMPLE);
		endpointConfig.put(WebServiceHandlerConstants.SIMPLE_BASEURL, baseEndpointUrl);
		endpointConfig.put(WebServiceHandlerConstants.SIMPLE_REGION, baseEndpointRegion);

		HandlerInfo endpointInfo = new HandlerInfo(
				BcbsscStandardEndpointHandler.class, endpointConfig, null);
		if(logger.isDebugEnabled()) {
			logger.debug("BcbsscStandardEndpointHandler has added to the chain with parameters " + endpointConfig.toString());
		}
		list.add(endpointInfo);

 		//Config BcbsscStandardWsseHandler now
		Map<String, String>  wsseConfig = new HashMap<String, String> ();
		wsseConfig.put(WebServiceHandlerConstants.CREDENTIAL_STRATEGY, WebServiceHandlerConstants.STRATEGY_SIMPLE);
		wsseConfig.put(WebServiceHandlerConstants.SIMPLE_USERNAME, wsSecurityId);		
		wsseConfig.put(WebServiceHandlerConstants.SIMPLE_PASSWORD, wsSecurityPassword);
		HandlerInfo wsseInfo = new HandlerInfo(BcbsscStandardWsseHandler.class,	wsseConfig, null);
		if(logger.isDebugEnabled()) {
			logger.debug("BcbsscStandardWsseHandler has added to the chain with parameters " + wsseConfig.toString());
		} 
		list.add(wsseInfo);

		return list;

	}

}
