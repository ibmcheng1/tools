/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2007 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * ServiceDataAccessException.java
 * 
 * Created on Jul 26, 2007, 1:28:25 PM by X33B
 */

package com.bcbssc.services;


/**
 * End point Exception
 *
 * <pre>
 * [PVCS]
 * $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/Commercial/Commercial-shared/commercial-services-utils/src/main/java/com/bcbssc/services/ServicesAuthorizationException.java_v  $
 * $Workfile:   ServicesAuthorizationException.java  $
 * $Revision:   1.0  $
 * $Date:   Nov 30 2009 13:53:54  $
 * $Modtime:   Nov 30 2009 13:40:50  $
 * </pre>
 *
 * @author $Author:   EN80  $
 * @version $Id: $Id
 */
public class ServicesAuthorizationException extends ServicesDataAccessException {
	
	private static final long serialVersionUID = 67343867867l;
    /**
     * <p>Constructor for ServicesAuthorizationException.</p>
     *
     * @param message a {@link java.lang.String} object.
     */
    public ServicesAuthorizationException(String message) {
        super(message);
    }

    /**
     * <p>Constructor for ServicesAuthorizationException.</p>
     *
     * @param cause a {@link java.lang.Throwable} object.
     */
    public ServicesAuthorizationException(Throwable cause) {
        super(cause.toString());
    }

    /**
     * <p>Constructor for ServicesAuthorizationException.</p>
     *
     * @param message a {@link java.lang.String} object.
     * @param cause a {@link java.lang.Throwable} object.
     */
    public ServicesAuthorizationException(String message, Throwable cause) {
        super(message, cause);
    }
}
