/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.testutils.naming;

import junit.framework.TestCase;

import javax.naming.InitialContext;

public class SimpleInitialContextStubberTest extends TestCase {

    /**
     * Tests the basic functionality (aka the framework's contract).
     */
    public void testBasic() throws Throwable {
        // Set up.
        String JNDI_NAME = "my/jndi/name";
        SimpleInitialContextStubber jndi = new SimpleInitialContextStubber();
        jndi.bind(JNDI_NAME, "123");

        // Actual test.
        InitialContext context = new InitialContext();
        String value = (String) context.lookup(JNDI_NAME);
        assertEquals("123", value);
        assertEquals(1, jndi.getHitCount(JNDI_NAME));

        value = (String) context.lookup(JNDI_NAME);
        assertEquals("123", value);
        assertEquals(2, jndi.getHitCount(JNDI_NAME));

        context.close();

        // Remove all JNDI values.
        jndi.unbindAll();

        boolean exceptionThrown = false;
        try {
            context.lookup(JNDI_NAME);
            fail("There should no longer be any values in JNDI.");
        } catch (Exception ex) {
            exceptionThrown = true;
        }
        assertTrue(exceptionThrown);

        exceptionThrown = false;
        try {
            jndi.getHitCount(JNDI_NAME);
            fail("There should no longer be any values in JNDI.");
        } catch (Exception ex) {
            exceptionThrown = true;
        }
        assertTrue(exceptionThrown);

        jndi.shutDown();
    }
}