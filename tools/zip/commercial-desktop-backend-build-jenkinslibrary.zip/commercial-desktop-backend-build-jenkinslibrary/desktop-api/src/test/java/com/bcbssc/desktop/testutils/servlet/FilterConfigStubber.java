/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.testutils.servlet;

import com.bcbssc.desktop.testutils.EnumerationStubber;

import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * A mock implementation of the {@link FilterConfig}.
 * For example (for more see web.xml):
 * <pre>
 * &lt;filter&gt;
 *     &lt;filter-name&gt;SubjectFilter&lt;/filter-name&gt;
 *     &lt;filter-class&gt;com.bcbssc.hnfs.filter.TricareSubjectFilter&lt;/filter-class&gt;
 *      &lt;init-param&gt;
 *          &lt;param-name&gt;rpnField&lt;/param-name&gt;
 *          &lt;param-value&gt;rpn&lt;/param-value&gt;
 *      &lt;/init-param&gt;
 * &lt;/filter&gt;
 * </pre>
 */
public class FilterConfigStubber implements FilterConfig {
    /**
     * The filter name as defined in web.xml
     */
    private String filterName;

    /**
     * In real life, this is created dynamically at run time by the container.
     */
    private ServletContext servletContext;

    /**
     * The setup configuration as defined in web.xml
     */
    private Map<String, String> initParameters;

    /**
     * Constructor.
     */
    public FilterConfigStubber() {
        initParameters = new HashMap<String, String>();
    }

    @Override
    public String getFilterName() {
        return filterName;
    }

    public void setFilterName(String name) {
        this.filterName = name;
    }

    public void setInitParameters(Map<String, String> params) {
        this.initParameters = params;
    }

    @Override
    public String getInitParameter(String name) {
        return initParameters.get(name);
    }

    public void setInitParameter(String name, String value) {
        initParameters.put(name, value);
    }

    @Override
    public Enumeration getInitParameterNames() {
        Set<String> keys = initParameters.keySet();
        return new EnumerationStubber<String>(keys.iterator());
    }

    @Override
    public ServletContext getServletContext() {
        return servletContext;
    }

    public void setServletContext(ServletContext context) {
        this.servletContext = context;
    }
}
