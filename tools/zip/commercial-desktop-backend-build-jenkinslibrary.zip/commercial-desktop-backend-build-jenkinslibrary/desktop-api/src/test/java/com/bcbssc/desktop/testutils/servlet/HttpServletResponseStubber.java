/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.testutils.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Collection;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

/**
 * A mock class that can be used in junit tests to represent an HttpServletResponse. Implement
 * methods as necessary.
 */
public class HttpServletResponseStubber implements HttpServletResponse {
    private boolean isCommitted = false;
    private String contentType = null;
    private PrintWriter writer = null;
    private StringWriter out = null;
    private String redirectPage = null;
    private final Map<String, Object> headers = new HashMap<String, Object>();
    private final ServletOutputStreamStubber outputStream = new ServletOutputStreamStubber();
    private int statusCode;
    private String statusMessage;
    private int contentLength;

    public HttpServletResponseStubber() {
    }

    public Object getHeaderValue(String headerName) {
        return headers.get(headerName);
    }

    @Override
    public void addCookie(Cookie cookie) {
        throw new UnsupportedOperationException("HttpServletResponseStubber addCookie - This method hasn't been implemented yet");
    }

    @Override
    public void addDateHeader(String name, long date) {
        headers.put(name, new Long(date));
    }

    @Override
    public void addHeader(String name, String value) {
        headers.put(name, value);
    }

    @Override
    public void addIntHeader(String name, int value) {
        headers.put(name, new Integer(value));
    }

    @Override
    public boolean containsHeader(String name) {
        return headers.containsKey(name);
    }

    @Override
    public String encodeRedirectURL(String url) {
        String result = null;
        // Per http://docs.oracle.com/javase/6/docs/api/java/net/URLEncoder.html#encode(java.lang.String, java.lang.String)
        // UTF-8 is recommend and strongly encouraged.
        try {
            result = URLEncoder.encode(url, "UTF-8");
        } catch (final UnsupportedEncodingException e) {
            e.printStackTrace();
            result = e.getMessage();
        }
        return result;
    }

    /**
     * @see http://docs.oracle.com/javaee/6/api/javax/servlet/http/HttpServletResponse.html
     * @deprecated As of version 2.1, use encodeRedirectURL(String url) instead
     */
    @Deprecated
    @Override
    public String encodeRedirectUrl(String url) {
        return encodeRedirectURL(url);
    }

    @Override
    public String encodeURL(String url) {
        return url;
    }

    @Override
    public String encodeUrl(String url) {
        throw new UnsupportedOperationException("HttpServletResponseStubber encodeUrl - This method is deprecated, please do not use it");
    }

    @Override
    public void sendError(int sc) throws IOException {
        setStatusCode(sc);
    }

    @Override
    public void sendError(int sc, String msg) throws IOException {
        setStatusCode(sc);
        setStatusMessage(msg);
    }

    @Override
    public void sendRedirect(String location) throws IOException {
        redirectPage = location;
    }

    @Override
    public int getStatus() {
        throw new UnsupportedOperationException("HttpServletResponseStubber getStatus - This method hasn't been implemented yet");
    }

    @Override
    public Collection<String> getHeaders(String s) {
        throw new UnsupportedOperationException("HttpServletResponseStubber getHeaders - This method hasn't been implemented yet");
    }

    @Override
    public Collection<String> getHeaderNames() {
        throw new UnsupportedOperationException("HttpServletResponseStubber getHeaderNames - This method hasn't been implemented yet");
    }

    @Override
    public void setDateHeader(String name, long date) {
        headers.put(name, new Long(date));
    }

    @Override
    public void setHeader(String name, String value) {
        headers.put(name, value);
    }

    @Override
    public String getHeader(String name) {
        return (String) headers.get(name);
    }

    @Override
    public void setIntHeader(String name, int value) {
        headers.put(name, new Integer(value));
    }

    @Override
    public void setStatus(int sc) {
        setStatusCode(sc);
    }

    @Override
    public void setStatus(int sc, String sm) {
        setStatusCode(sc);
        setStatusMessage(sm);
    }

    @Override
    public void flushBuffer() throws IOException {
        if (isCommitted) {
            throw new IllegalStateException("Response already committed.");
        }
        isCommitted = true;
        return;
    }

    @Override
    public int getBufferSize() {
        throw new UnsupportedOperationException("HttpServletResponseStubber getBufferSize - This method hasn't been implemented yet");
    }

    @Override
    public String getCharacterEncoding() {
        throw new UnsupportedOperationException("HttpServletResponseStubber getCharacterEncoding - This method hasn't been implemented yet");
    }

    @Override
    public String getContentType() {
        return contentType;
    }

    @Override
    public Locale getLocale() {
        throw new UnsupportedOperationException("HttpServletResponseStubber getLocale - This method hasn't been implemented yet");
    }

    @Override
    public ServletOutputStream getOutputStream() throws IOException {
        return outputStream;
    }

    public ServletOutputStreamStubber getServletOutputStreamStubber() {
        return outputStream;
    }

    @Override
    public PrintWriter getWriter() throws IOException {
        out = new StringWriter();
        writer = new PrintWriter(out);
        return writer;
    }

    @Override
    public boolean isCommitted() {
        return isCommitted;
    }

    @Override
    public void reset() {
        throw new UnsupportedOperationException("HttpServletResponseStubber reset - This method hasn't been implemented yet");
    }

    @Override
    public void resetBuffer() {
        throw new UnsupportedOperationException("HttpServletResponseStubber resetBuffer - This method hasn't been implemented yet");
    }

    @Override
    public void setBufferSize(int size) {
        throw new UnsupportedOperationException("HttpServletResponseStubber setBufferSize - This method hasn't been implemented yet");
    }

    @Override
    public void setCharacterEncoding(String charset) {
        throw new UnsupportedOperationException("HttpServletResponseStubber setCharacterEncoding - This method hasn't been implemented yet");
    }

    @Override
    public void setContentLength(int len) {
        contentLength = len;
    }

    @Override
    public void setContentLengthLong(long l) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    public int getContentLength() {
        return contentLength;
    }

    @Override
    public void setContentType(String type) {
        contentType = type;
    }

    @Override
    public void setLocale(Locale loc) {
        throw new UnsupportedOperationException("HttpServletResponseStubber setLocale - This method hasn't been implemented yet");
    }

    /**
     * @return the out
     */
    public StringWriter getOut() {
        return out;
    }

    /**
     * @return the redirectPage
     */
    public String getRedirectPage() {
        return redirectPage;
    }

    /**
     * @param statusCode the statusCode to set
     */
    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * @return the statusCode
     */
    public int getStatusCode() {
        return statusCode;
    }

    /**
     * @param statusMessage the statusMessage to set
     */
    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    /**
     * @return the statusMessage
     */
    public String getStatusMessage() {
        return statusMessage;
    }

}