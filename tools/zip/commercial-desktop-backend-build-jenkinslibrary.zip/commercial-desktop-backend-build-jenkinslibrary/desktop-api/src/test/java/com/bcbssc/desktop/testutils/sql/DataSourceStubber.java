/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.testutils.sql;

import javax.sql.DataSource;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.logging.Logger;

/**
 * A mock implementation of {@link DataSource}.
 */
public class DataSourceStubber implements DataSource {
    /**
     * Allows legacy applications to create non PreparedStatements.
     */
    private boolean isAllowedToUseNonPreparedStatements;

    /**
     * Allows application to call close on the connection multiple times.
     */
    private boolean isAllowedMultipleConnectionCloses;

    public DataSourceStubber() {
        // Nothing to do.
    }

    public DataSourceStubber(boolean isAllowedToUseNonPreparedStatements, boolean isAllowedMultipleConnectionCloses) {
        this.isAllowedToUseNonPreparedStatements = isAllowedToUseNonPreparedStatements;
        this.isAllowedMultipleConnectionCloses = isAllowedMultipleConnectionCloses;
    }

    @Override
    public int getLoginTimeout() throws SQLException {
        // TODO
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public PrintWriter getLogWriter() throws SQLException {
        // TODO
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void setLoginTimeout(int seconds) throws SQLException {
        // TODO
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void setLogWriter(PrintWriter out) throws SQLException {
        // TODO
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public <T> T unwrap(Class<T> iface) throws SQLException {
        // TODO
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        // TODO
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Connection getConnection() throws SQLException {
        ConnectionStubber connection = new ConnectionStubber(this.isAllowedToUseNonPreparedStatements, this.isAllowedMultipleConnectionCloses);
        connection.open();
        return connection;
    }

    @Override
    public Connection getConnection(String theUsername, String thePassword) throws SQLException {
        ConnectionStubber connection = new ConnectionStubber(this.isAllowedToUseNonPreparedStatements, this.isAllowedMultipleConnectionCloses);
        connection.open();
        return connection;
    }

    @Override
    public Logger getParentLogger() throws SQLFeatureNotSupportedException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }
}
