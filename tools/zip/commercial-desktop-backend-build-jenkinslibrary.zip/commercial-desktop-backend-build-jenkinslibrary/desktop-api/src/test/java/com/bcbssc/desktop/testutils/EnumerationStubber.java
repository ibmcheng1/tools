/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUE CROSS BLUE SHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.
 * ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUE CROSS BLUE SHIELD OF SOUTH CAROLINA.
 * ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.testutils;

import java.util.Enumeration;
import java.util.Iterator;

/**
 * Half baked enumeration, probably not safe because we don't copy the collection.
 * Copied from DesktopCCM.
 */
public class EnumerationStubber<E> implements Enumeration<E> {
    private Iterator<E> iterator;

    public EnumerationStubber(Iterator<E> iterator) {
        this.iterator = iterator;
    }

    @Override
    public boolean hasMoreElements() {
        return this.iterator.hasNext();
    }

    @Override
    public E nextElement() {
        return this.iterator.next();
    }
}
