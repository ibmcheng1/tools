/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.testutils.servlet;

import com.bcbssc.desktop.testutils.EnumerationStubber;
import com.bcbssc.desktop.testutils.security.PrincipalStubber;
import org.apache.commons.lang.StringUtils;

import javax.servlet.AsyncContext;
import javax.servlet.DispatcherType;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpUpgradeHandler;
import javax.servlet.http.Part;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.Principal;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * A mock class that can be used in JUnit tests to represent an HttpServletRequest.
 * Implement methods as necessary.
 */
public class HttpServletRequestStubber implements HttpServletRequest {

	/**
	 * De facto standard ip address forwarding for web servers.
	 * @see <a href="http://en.wikipedia.org/wiki/X-Forwarded-For">http://en.wikipedia.org/wiki/X-Forwarded-For</a>
	 */
	public static final String HEADER_ID_X_FORWARDED_FOR = "X-FORWARDED-FOR";

	/** IP address of the client or last proxy that sent the request. */
	private String remoteAddress = "127.0.0.666";
	private Map<String, String> headers = new HashMap<String, String>();
	private Map<String, String[]> parameterMap = new HashMap<String, String[]>();
	private Map<String, Object> attributeMap = new HashMap<String, Object>();
	private HttpSessionStubber session = null;
	private String contextPath = "";
	/** Example: /foo/bar/servletName */
	private String requestUri;
	/** Example: http://hostName:port/foo/bar/servletName */
	private String requestUrl;
	private PrincipalStubber user;
	private String scheme;
	private String servletPath;
	/** Will only be created if {@link #getRequestDispatcher(String)} is called. */
	private RequestDispatcherStubber requestDispatcherStubber = null;
	private ServletInputStreamStubber inputStream = null;
	public String method = "GET";
	public Cookie[] cookies = null;

	@Override
	public String getAuthType() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public String getContextPath() {
		return contextPath;
	}

	public void setContextPath(String contextPath) {
		this.contextPath = contextPath;
	}

	@Override
	public Cookie[] getCookies() {
		return this.cookies;
	}

	@Override
	public long getDateHeader(String arg0) {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public String getHeader(String headerName) {
		return this.headers.get(headerName);
	}

	public void setHeader(String headerName, String value) {
		this.headers.put(headerName, value);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Enumeration getHeaderNames() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Enumeration getHeaders(String arg0) {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public int getIntHeader(String arg0) {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public String getMethod() {
		return this.method;
	}

	@Override
	public String getPathInfo() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public String getPathTranslated() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	/**
	 * Does not have the leading ? per most real life implementations.
	 */
	@Override
	public String getQueryString() {
		StringBuilder builder = new StringBuilder();

		boolean isFirst = true;
		for (Map.Entry<String, String[]> entry : this.parameterMap.entrySet()) {
			if (false == isFirst) {
				builder.append("&");
			} else {
				isFirst = false;
			}
			// @TODO encode the key and value per RFC 1738. 
			builder.append(entry.getKey()).append("=").append(stringArrayToString(entry.getValue()));
		}

		return builder.toString();
	}

	private String stringArrayToString(String[] a) {
		StringBuilder builder = new StringBuilder();
		boolean isFirst = true;
		for (int i = 0; i < a.length; i++) {
			if (false == isFirst) {
				builder.append(",");
			} else {
				isFirst = false;
			}
			builder.append(a[i]);
		}
		return builder.toString();
	}

	@Override
	public String getRemoteUser() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public String getRequestURI() {
		return this.requestUri;
	}

	public void setRequestURI(String uri) {
		this.requestUri = uri;
	}

	@Override
	public StringBuffer getRequestURL() {
		StringBuffer result = null;
		if (StringUtils.isBlank(this.requestUrl)) {
			// Some one was lazy and didn't set this in the JUnit.
			result = new StringBuffer("requestUrl is null");
		} else {
			result = new StringBuffer(this.requestUrl);
		}
		return result;
	}

	public void setRequestURL(String requestUrl) {
		this.requestUrl = requestUrl;
	}

	@Override
	public String getRequestedSessionId() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public String getServletPath() {
		return this.servletPath;
	}

	public void setServletPath(String servletPath) {
		this.servletPath = servletPath;
	}

	@Override
	public HttpSession getSession() {
		if (null == this.session) {
			this.session = new HttpSessionStubber();
		}
		return this.session;
	}

    @Override
    public String changeSessionId() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
	public HttpSession getSession(boolean create) {
		if (null == this.session && create) {
			this.session = new HttpSessionStubber();
		}
		return this.session;
	}

	public HttpSessionStubber getHttpSessionStubber() {
		if (null == this.session) {
			this.session = new HttpSessionStubber();
		}
		return this.session;
	}

	public void setHttpSessionStubber(HttpSessionStubber session) {
		this.session = session;
	}

	@Override
	public Principal getUserPrincipal() {
		return this.user;
	}

	public PrincipalStubber getUserPrincipalStubber() {
		return this.user;
	}

	public void setUserPrincipal(PrincipalStubber user) {
		this.user = user;
	}

	@Override
	public boolean isRequestedSessionIdFromCookie() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public boolean isRequestedSessionIdFromURL() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public boolean isRequestedSessionIdFromUrl() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public boolean isRequestedSessionIdValid() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public boolean isUserInRole(String arg0) {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public Object getAttribute(String name) {
		Object result = null;
		if (null != attributeMap && attributeMap.containsKey(name)) {
			result = attributeMap.get(name);
		}
		return result;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Enumeration getAttributeNames() {
		Set<String> keys = attributeMap.keySet();
		return new EnumerationStubber<String>(keys.iterator());
	}

	@Override
	public String getCharacterEncoding() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public int getContentLength() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

    @Override
    public long getContentLengthLong() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
	public String getContentType() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public ServletInputStream getInputStream() throws IOException {
		return this.inputStream;
	}

	public void setInputStream(ServletInputStreamStubber inputStream) throws IOException {
		this.inputStream = inputStream;
	}

	@Override
	public String getLocalAddr() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public String getLocalName() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public int getLocalPort() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public Locale getLocale() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Enumeration getLocales() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public String getParameter(String name) {
		String result = null;
		if (null != parameterMap && parameterMap.containsKey(name)) {
			result = parameterMap.get(name)[0];
		}
		return result;
	}

	public void setParameter(String name, String value) {
		this.parameterMap.put(name, new String[]{value});
	}

	public void setParameters(String name, String... values ) {
		this.parameterMap.put(name, values);
	}

	public void setParameterMap(Map<String, String[]> map) {
		this.parameterMap = map;
	}

	@Override
	public Map<String, String[]> getParameterMap() {
		return this.parameterMap;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Enumeration getParameterNames() {
		Set<String> keys = parameterMap.keySet();
		return new EnumerationStubber<String>(keys.iterator());
	}

	@Override
	public String[] getParameterValues(String name) {
		String[] result = null;
		if (null != parameterMap && parameterMap.containsKey(name)) {
			result = parameterMap.get(name);
		}
		return result;
	}

	@Override
	public String getProtocol() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public BufferedReader getReader() throws IOException {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public String getRealPath(String path) {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public String getRemoteAddr() {
		return this.remoteAddress;
	}

	public void setRemoteAddr(String remoteAddress) {
		this.remoteAddress = remoteAddress;
	}

	@Override
	public String getRemoteHost() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public int getRemotePort() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public RequestDispatcher getRequestDispatcher(String path) {
		this.requestDispatcherStubber = new RequestDispatcherStubber(path);
		return this.requestDispatcherStubber;
	}

	/**
	 * @return
	 *	  Will be null if the {@link #getRequestDispatcher(String)} wasn't called.
	 */
	public RequestDispatcherStubber getRequestDispatcherStubber() {
		return this.requestDispatcherStubber;
	}

	@Override
	public String getScheme() {
		return this.scheme;
	}

	public void setScheme(String scheme) {
		this.scheme = scheme;
	}

	@Override
	public String getServerName() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public int getServerPort() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public boolean isSecure() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public void removeAttribute(String name) {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	public Map<String, Object> getAttributeMap() {
		return attributeMap;
	}

	@Override
	public void setAttribute(String name, Object o) {
		if (null == attributeMap) {
			attributeMap = new HashMap<String, Object>(10);
		}
		attributeMap.put(name, o);
	}

	@Override
	public void setCharacterEncoding(String env) throws UnsupportedEncodingException {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public boolean authenticate(HttpServletResponse httpServletResponse) throws IOException, ServletException {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public void login(String s, String s1) throws ServletException {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public void logout() throws ServletException {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public Collection<Part> getParts() throws IOException, ServletException {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public Part getPart(String s) throws IOException, ServletException {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

    @Override
    public <T extends HttpUpgradeHandler> T upgrade(Class<T> aClass) throws IOException, ServletException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
	public ServletContext getServletContext() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public AsyncContext startAsync() throws IllegalStateException {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public AsyncContext startAsync(ServletRequest servletRequest, ServletResponse servletResponse) throws IllegalStateException {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public boolean isAsyncStarted() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public boolean isAsyncSupported() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public AsyncContext getAsyncContext() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}

	@Override
	public DispatcherType getDispatcherType() {
		throw new UnsupportedOperationException("This method hasn't been implemented yet");
	}
}