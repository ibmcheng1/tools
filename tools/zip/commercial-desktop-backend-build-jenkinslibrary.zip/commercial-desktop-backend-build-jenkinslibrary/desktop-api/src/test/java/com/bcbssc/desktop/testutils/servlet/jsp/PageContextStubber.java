/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.testutils.servlet.jsp;

import com.bcbssc.desktop.testutils.servlet.HttpServletRequestStubber;
import com.bcbssc.desktop.testutils.servlet.HttpServletResponseStubber;
import com.bcbssc.desktop.testutils.servlet.HttpSessionStubber;
import com.bcbssc.desktop.testutils.servlet.ServletContextStubber;

import javax.el.ELContext;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.el.ExpressionEvaluator;
import javax.servlet.jsp.el.VariableResolver;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

/**
 * A mock {@link javax.servlet.jsp.PageContext}.
 */
public class PageContextStubber extends PageContext {
    private ServletRequest request = new HttpServletRequestStubber();
    private ServletResponse response = new HttpServletResponseStubber();
    private JspWriterStubber out = new JspWriterStubber();
    private ServletContextStubber servletContext = new ServletContextStubber();

    /**
     * Outer Integer key is the scope.
     * Within that is the normal String key and finally the object.
     */
    private Map<Integer, Map<String, Object>> attributes = new HashMap<Integer, Map<String, Object>>();

    private HttpSessionStubber session = new HttpSessionStubber();

    public PageContextStubber() {
        this.attributes.put(PageContext.APPLICATION_SCOPE, new HashMap<String, Object>());
        this.attributes.put(PageContext.PAGE_SCOPE, new HashMap<String, Object>());
        this.attributes.put(PageContext.REQUEST_SCOPE, new HashMap<String, Object>());
        this.attributes.put(PageContext.SESSION_SCOPE, new HashMap<String, Object>());
    }

    @Override
    public void forward(String relativeUrlPath) throws ServletException, IOException {
        throw new UnsupportedOperationException("PageContextStubber.forward This method hasn't been implemented yet");
    }

    @Override
    public Exception getException() {
        throw new UnsupportedOperationException("PageContextStubber.getException This method hasn't been implemented yet");
    }

    @Override
    public Object getPage() {
        throw new UnsupportedOperationException("PageContextStubber.getPage This method hasn't been implemented yet");
    }

    @Override
    public ServletRequest getRequest() {
        return this.request;
    }

    public void setRequest(ServletRequest request) {
        this.request = request;
    }

    @Override
    public ServletResponse getResponse() {
        return this.response;
    }

    @Override
    public ServletConfig getServletConfig() {
        throw new UnsupportedOperationException("PageContextStubber.getServletConfig This method hasn't been implemented yet");
    }

    @Override
    public ServletContext getServletContext() {
        return this.servletContext;
    }

    public void setServletContext(ServletContextStubber context) {
        this.servletContext = context;
    }

    @Override
    public HttpSession getSession() {
        return this.session;
    }

    @Override
    public void handlePageException(Exception e) throws ServletException, IOException {
        throw new UnsupportedOperationException("PageContextStubber.handlePageException This method hasn't been implemented yet");
    }

    @Override
    public void handlePageException(Throwable t) throws ServletException, IOException {
        throw new UnsupportedOperationException("PageContextStubber.handlePageException This method hasn't been implemented yet");
    }

    @Override
    public void include(String relativeUrlPath) throws ServletException, IOException {
        throw new UnsupportedOperationException("PageContextStubber.include This method hasn't been implemented yet");
    }

    @Override
    public void include(String relativeUrlPath, boolean flush) throws ServletException, IOException {
        throw new UnsupportedOperationException("PageContextStubber.include This method hasn't been implemented yet");
    }

    @Override
    public void initialize(Servlet servlet, ServletRequest request, ServletResponse response, String errorPageURL, boolean needsSession, int bufferSize, boolean autoFlush) throws IOException, IllegalStateException, IllegalArgumentException {
        throw new UnsupportedOperationException("PageContextStubber.initialize This method hasn't been implemented yet");
    }

    @Override
    public void release() {
        throw new UnsupportedOperationException("PageContextStubber.release This method hasn't been implemented yet");
    }

    @Override
    public Object findAttribute(String name) {
        throw new UnsupportedOperationException("PageContextStubber.findAttribute This method hasn't been implemented yet");
    }

    @Override
    public Object getAttribute(String name) {
        return getAttribute(name, PageContext.PAGE_SCOPE);
    }

    @Override
    public Object getAttribute(String name, int scope) {
        return this.attributes.get(scope).get(name);
    }

    @Override
    public Enumeration<String> getAttributeNamesInScope(int scope) {
        throw new UnsupportedOperationException("PageContextStubber.getAttributeNamesInScope This method hasn't been implemented yet");
    }

    @Override
    public int getAttributesScope(String name) {
        throw new UnsupportedOperationException("PageContextStubber.getAttributesScope This method hasn't been implemented yet");
    }

    @Override
    public ELContext getELContext() {
        throw new UnsupportedOperationException("PageContextStubber.getELContext This method hasn't been implemented yet");
    }

    @Override
    public ExpressionEvaluator getExpressionEvaluator() {
        throw new UnsupportedOperationException("PageContextStubber.getExpressionEvaluator This method hasn't been implemented yet");
    }

    @Override
    public JspWriter getOut() {
        return this.out;
    }

    public JspWriterStubber getOutJspWriterStubber() {
        return this.out;
    }

    @Override
    public VariableResolver getVariableResolver() {
        throw new UnsupportedOperationException("PageContextStubber.getVariableResolver This method hasn't been implemented yet");
    }

    @Override
    public void removeAttribute(String name) {
        removeAttribute(name, PageContext.PAGE_SCOPE);
    }

    @Override
    public void removeAttribute(String name, int scope) {
        this.attributes.get(scope).remove(name);
    }

    @Override
    public void setAttribute(String name, Object value) {
        setAttribute(name, value, PageContext.PAGE_SCOPE);
    }

    @Override
    public void setAttribute(String name, Object value, int scope) {
        this.attributes.get(scope).put(name, value);
    }
}
