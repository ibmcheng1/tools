/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.testutils.sql;

import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;

/**
 * A mock Connection for JUnit.
 */
public class ConnectionStubber implements Connection {

    /**
     * Determines if the mock connection open or closed.
     */
    private boolean isOpen;

    /**
     * Determines if the mock connection auto commits or not.
     */
    private boolean isAutoCommit;

    /**
     * Allows legacy applications to create non PreparedStatements.
     */
    private boolean isAllowedToUseNonPreparedStatements;

    /**
     * Allows application to call close multiple times.
     */
    private boolean isAllowedMultipleCloses;

    public ConnectionStubber() {
        // Nothing to do.
    }

    public ConnectionStubber(boolean isAllowedToUseNonPreparedStatements, boolean isAllowedMultipleCloses) {
        this.isAllowedToUseNonPreparedStatements = isAllowedToUseNonPreparedStatements;
        this.isAllowedMultipleCloses = isAllowedMultipleCloses;
    }

    @Override
    public <T> T unwrap(Class<T> iface) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void clearWarnings() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    public void open() {
        if (this.isOpen) {
            throw new IllegalStateException("ConnectionStubber is already open.");
        }
        this.isOpen = true;
    }

    @Override
    public void close() throws SQLException {
        if (this.isOpen) {
            this.isOpen = false;
        } else {
            if (this.isAllowedMultipleCloses) {
                // Nothing to do.
            } else {
                throw new IllegalStateException("ConnectionStubber is not open.");
            }
        }
    }

    @Override
    public void commit() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Statement createStatement() throws SQLException {
        if (this.isAllowedToUseNonPreparedStatements) {
            if (isClosed()) {
                throw new IllegalStateException("ConnectionStubber is closed.");
            }
            return new StatementStubber();
        } else {
            throw new UnsupportedOperationException("Your application should only use prepareStatement");
        }
    }

    @Override
    public Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException {
        if (this.isAllowedToUseNonPreparedStatements) {
            if (isClosed()) {
                throw new IllegalStateException("ConnectionStubber is closed.");
            }
            throw new UnsupportedOperationException("This method hasn't been implemented yet");
        } else {
            throw new UnsupportedOperationException("Your application should only use prepareStatement");
        }
    }

    @Override
    public Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
        if (this.isAllowedToUseNonPreparedStatements) {
            if (isClosed()) {
                throw new IllegalStateException("ConnectionStubber is closed.");
            }
            throw new UnsupportedOperationException("This method hasn't been implemented yet");
        } else {
            throw new UnsupportedOperationException("Your application should only use prepareStatement");
        }
    }

    @Override
    public boolean getAutoCommit() throws SQLException {
        return this.isAutoCommit;
    }

    @Override
    public String getCatalog() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public int getHoldability() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public DatabaseMetaData getMetaData() throws SQLException {
        return new DatabaseMetaDataStubber();
    }

    @Override
    public int getTransactionIsolation() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Map<String, Class<?>> getTypeMap() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public SQLWarning getWarnings() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isClosed() throws SQLException {
        return (false == this.isOpen);
    }

    @Override
    public boolean isReadOnly() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public String nativeSQL(String sql) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public CallableStatement prepareCall(String sql) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public PreparedStatement prepareStatement(String sql) throws SQLException {
        if (isClosed()) {
            throw new IllegalStateException("ConnectionStubber is closed.");
        }
        return new PreparedStatementStubber(this, sql);
    }

    @Override
    public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public PreparedStatement prepareStatement(String sql, int[] columnIndexes) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public PreparedStatement prepareStatement(String sql, String[] columnNames) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void releaseSavepoint(Savepoint savepoint) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void rollback() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void rollback(Savepoint savepoint) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void setAutoCommit(boolean autoCommit) throws SQLException {
        this.isAutoCommit = autoCommit;
    }

    @Override
    public void setCatalog(String catalog) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void setHoldability(int holdability) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void setReadOnly(boolean readOnly) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Savepoint setSavepoint() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Savepoint setSavepoint(String name) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void setTransactionIsolation(int level) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void setTypeMap(Map<String, Class<?>> map) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Clob createClob() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Blob createBlob() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public NClob createNClob() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public SQLXML createSQLXML() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isValid(int timeout) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void setClientInfo(String name, String value) throws SQLClientInfoException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void setClientInfo(Properties properties) throws SQLClientInfoException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public String getClientInfo(String name) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Properties getClientInfo() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Array createArrayOf(String typeName, Object[] elements) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Struct createStruct(String typeName, Object[] attributes) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void setSchema(String schema) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public String getSchema() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void abort(Executor executor) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void setNetworkTimeout(Executor executor, int milliseconds) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public int getNetworkTimeout() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /**
     * Converts the given SQL query into a single one line query with escaped newlines, tabs, etc.
     */
    public static String convertToOneLinerSql(String sql) {
        //String clean = StringUtils.replaceEach(sql, String[] searchList, String[] replacementList)
        String clean = sql;
        clean = clean.replace("\\", "\\\\");
        clean = clean.replace("\n", "\\n");
        clean = clean.replace("\r", "\\r");
        clean = clean.replace("\t", "\\t");
        return clean;
    }
}
