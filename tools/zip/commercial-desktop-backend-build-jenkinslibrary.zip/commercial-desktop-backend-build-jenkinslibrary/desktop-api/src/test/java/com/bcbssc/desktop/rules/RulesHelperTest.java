/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * RulesHelperTest.java
 * 
 * Created on Dec 2, 2010, 11:39:28 AM by JC33
 */
package com.bcbssc.desktop.rules;

import java.text.SimpleDateFormat;

import junit.framework.TestCase;

/**
 * JUnit test case for {@link RulesHelper}.
 * 
 * @author jc33
 */
public class RulesHelperTest extends TestCase {

    /**
     * Test method for {@link com.bcbssc.desktop.rules.RulesHelper#extractSubscriberBirthdate(java.text.SimpleDateFormat, java.lang.String)}.
     */
    public void testExtractSubscriberBirthdate() {
        SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
        
        // try with a null birthdate
        String outputBirthdate = RulesHelper.extractSubscriberBirthdate(formatter, null);
        assertNotNull("The birthdate returned (null input) was null when it should have been an empty string", outputBirthdate);
        assertEquals("The birthdate returned (null input) was something other than empty string", "", outputBirthdate);
        
        // try with an empty string birthdate
        outputBirthdate = RulesHelper.extractSubscriberBirthdate(formatter, "");
        assertNotNull("The birthdate returned (empty input) was null when it should have been an empty string", outputBirthdate);
        assertEquals("The birthdate returned (empty input) was something other than empty string", "", outputBirthdate);
        
        // try with a full date birthdate
        String originalBirthdate = "02/11/1981";
        String expectedBirthdate = "02-11-1981";
        outputBirthdate = RulesHelper.extractSubscriberBirthdate(formatter, originalBirthdate);
        assertNotNull("The birthdate returned (full date input) was null when it should have been " + expectedBirthdate, outputBirthdate);
        assertEquals("The birthdate returned (full date input) (" + outputBirthdate + ") did not match the expected birthdate (" + expectedBirthdate + ")", expectedBirthdate, outputBirthdate);
        
        // try with a partial birthdate
        originalBirthdate = "02/1981";
        expectedBirthdate = "02-01-1981";
        outputBirthdate = RulesHelper.extractSubscriberBirthdate(formatter, originalBirthdate);
        assertNotNull("The birthdate returned (partial date input) was null when it should have been " + expectedBirthdate, outputBirthdate);
        assertEquals("The birthdate returned (partial date input) (" + outputBirthdate + ") did not match the expected birthdate (" + expectedBirthdate + ")", expectedBirthdate, outputBirthdate);
        
        // try some strange examples
        originalBirthdate = "02";
        outputBirthdate = RulesHelper.extractSubscriberBirthdate(formatter, originalBirthdate);
        assertNotNull("The birthdate returned (strange input 1) was null when it should not have been", outputBirthdate);
        assertEquals("The birthdate returned (strange input 1) was something other than empty string", "", outputBirthdate);
        
        originalBirthdate = " / / ";
        outputBirthdate = RulesHelper.extractSubscriberBirthdate(formatter, originalBirthdate);
        assertNotNull("The birthdate returned (strange input 2) was null when it should not have been", outputBirthdate);
        assertEquals("The birthdate returned (strange input 2) was something other than empty string", "", outputBirthdate);
        
        originalBirthdate = "abc";
        outputBirthdate = RulesHelper.extractSubscriberBirthdate(formatter, originalBirthdate);
        assertNotNull("The birthdate returned (strange input 3) was null when it should not have been", outputBirthdate);
        assertEquals("The birthdate returned (strange input 3) was something other than empty string", "", outputBirthdate);
    }

}
