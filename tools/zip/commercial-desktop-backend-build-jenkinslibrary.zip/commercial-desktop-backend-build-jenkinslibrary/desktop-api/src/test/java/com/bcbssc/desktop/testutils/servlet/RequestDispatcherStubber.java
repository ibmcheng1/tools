/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.testutils.servlet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.io.IOException;

/**
 * A mock class that represents a {@link RequestDispatcher}. This allows for executing
 * servlets in JUnit tests that use the {@link RequestDispatcher}.
 */
public class RequestDispatcherStubber implements RequestDispatcher {
    
    private String url = null;

    /**
     * In real life, the forward function must be called in order to actually forward the request to the given URL.
     * This flag allows the JUnit test to verify that it was indeed called.
     */
    private boolean forwardCalled = false;

    public RequestDispatcherStubber(String url) {
        this.url = url;
    }

    @Override
    public void forward(ServletRequest paramServletRequest, ServletResponse paramServletResponse) throws ServletException, IOException {
        this.forwardCalled = true;
    }

    @Override
    public void include(ServletRequest paramServletRequest, ServletResponse paramServletResponse) throws ServletException, IOException {
        // TODO: There is no sane or easy way to implement this.
        // You'll have to something crazy like searching the entire file system and writing some JSP engine. Gah!
        // Just don't blow up the JUnit tests.
    }

    /**
     * @return the url
     */
    public String getUrl() {
        return this.url;
    }

    /**
     * @return the forwardCalled
     */
    public boolean getForwardCalled() {
        return this.forwardCalled;
    }

}
