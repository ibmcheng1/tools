/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.testutils.mock;

import com.bcbssc.desktop.biz.EnvironmentBiz;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;

import javax.security.auth.Subject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * An <code>EnvironmentBiz</code> intended for JUnit or testing situations where there is no server.
 */
public class MockEnvironmentBiz implements EnvironmentBiz {
    final Map<EnvironmentObjects, Object> mappings = new TreeMap<EnvironmentObjects, Object>();
    final List<String> environments = new ArrayList<String>();

    @Override
	public <T> T get(EnvironmentObjects environmentObject, Class<T> expectedClass, Subject subject) {
        return (T) mappings.get(environmentObject);
    }

    @Override
	public String get(EnvironmentObjects environmentObject, Subject subject) {
        return (String) mappings.get(environmentObject);
    }

    @Override
	public <T> T getCommon(EnvironmentObjects environmentObject, Class<T> expectedClass) {
        return (T) mappings.get(environmentObject);
    }

    @Override
	public boolean isDefined(EnvironmentObjects environmentObject, Subject subject) {
        return mappings.containsKey(environmentObject);
    }

    @Override
	public boolean isEnvironmentDefined(String environment) {
        return environments.contains(environment);
    }

    @Override
	public List<String> getEnvironments() {
        return environments;
    }

    public void put(EnvironmentObjects environmentObject, Object value) {
        mappings.put(environmentObject, value);
    }

    public void addEnvironment(String environment) {
        environments.add(environment);
    }
}
