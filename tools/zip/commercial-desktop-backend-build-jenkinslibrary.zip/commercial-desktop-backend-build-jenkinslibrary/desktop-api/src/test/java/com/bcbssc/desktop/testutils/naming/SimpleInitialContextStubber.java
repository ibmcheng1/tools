/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.testutils.naming;

import org.apache.commons.lang.StringUtils;

import javax.naming.Context;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * A mock JNDI framework for JUnit.
 * Usage:
 * <pre>
        // Set up.
        String JNDI_NAME = "my/jndi/name";
        SimpleInitialContextStubber jndi = new SimpleInitialContextStubber();
        jndi.bind(JNDI_NAME, "123");

        // Actual test.
        String value = (String) new InitialContext().lookup(JNDI_NAME);
        Assert.assertEquals("123", value);
        Assert.assertEquals(1, jndi.getHitCount(JNDI_NAME));
 
        // Remove all JNDI values.
        jndi.unbindAll();

        // Or to return to the normal InitialContext
        // jndi.shutDown(); 
 * </pre>
 */
public class SimpleInitialContextStubber {
    private static class Entry {
        public Object value;
        public long hitCount;

        public Entry(Object value) {
            this.value = value;
            this.hitCount = 0;
        }
    }
    private static final Map<String, Entry> BINDINGS = Collections.synchronizedMap(new HashMap<String, Entry>());

    private String theOldFactory;

    /**
     * As soon as you create our stubber, we start hijacking any InitialContext calls.
     */
    public SimpleInitialContextStubber() {
    	this.theOldFactory = System.setProperty(Context.INITIAL_CONTEXT_FACTORY, SimpleInitialContextFactory.class.getName());
    }

    /**
     * Unbinds all and stops using our stubber and return to the use of whatever was the default.
     */
    public SimpleInitialContextStubber shutDown() {
    	unbindAll();

    	// Be careful, the default factory may not be defined.
    	if (null != this.theOldFactory) {
    		System.setProperty(Context.INITIAL_CONTEXT_FACTORY, this.theOldFactory);
    	}
    	return this;
    }

    /**
     * Fetches the bound JNDI name and increments the hit counter.
     * Static for the SimpleContext object.
     */
    public static Object getValue(String name) {
        Entry entry = BINDINGS.get(name);
        entry.hitCount++;
        return entry.value;
    }

    /**
     * Static for the SimpleContext object.
     */
    public static boolean containsKey(String name) {
        return BINDINGS.containsKey(name);
    }

    /**
     * Gets the number of times the given JNDI name was fetched.
     *
     * @param name
     *      The JNDI name for a bound object.
     * @return
     *      The number of times the given name was fetched.
     * @throws IllegalStateException
     *      If there is no binding for the given name.
     */
    public long getHitCount(String name) {
        Entry entry = BINDINGS.get(name);
        if (null == entry) {
            throw new IllegalStateException("No entry for name = " + name);
        }
        return entry.hitCount;
    }

    /**
     * Add key/value pair to context
     * @param name
     * @param value
     *      Must not be null or eval to a blank string.
     */
    public SimpleInitialContextStubber bind(String name, Object value) {
        if (null == value || StringUtils.isBlank(value.toString())) {
            // Well... via the AdminConfig scripting you can do it but not via the WAS Console.
            // This is an attempt to try to enforce the bullsh!t 'conventions' of JNDI.
            throw new IllegalArgumentException("A blank or null JNDI value is not allowed.");
        }
        BINDINGS.put(name, new Entry(value));
        return this;
    }

    public SimpleInitialContextStubber bind(Class clazz, Object value) {
        BINDINGS.put(clazz.getName(), new Entry(value));
        return this;
    }

    /**
     * Same as bind("cell/persistent/" + name, value)
     */
    public SimpleInitialContextStubber bindCell(String name, Object value) {
        bind("cell/persistent/" + name, value);
		return this;
    }

    public SimpleInitialContextStubber bindEjbLocal(Class<?> ejbInterface, Object implInstance) {
        bind("ejblocal:" + ejbInterface.getName(), implInstance);
        return this;
    }

    /**
     * Remove key from context
     * @param name
     * @return
     * 		The object being removed.
     */
    public Object unbind(String name) {
        return BINDINGS.remove(name);
    }

    /**
     * Remove all key/value pairs from the context
     */
    public void unbindAll() {
        BINDINGS.clear();
    }
}
