/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.testutils.sql;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Map;
import java.util.Vector;

/**
 * Mock implementation of the {@link ResultSet} interface.
 */
public class ResultSetStubber implements ResultSet {


    private static final int CURSOR_INVALID = -9999;
    private static final int CURSOR_BEFORE_FIRST = -8888;
    private static final int CURSOR_AFTER_LAST = -7777;

    private ResultSetMetaDataStubber metaData = new ResultSetMetaDataStubber();
    private Vector<Vector<Object>> rows = new Vector<Vector<Object>>();

    /**
     * The row that we're currently on.
     */
    private int cursor = CURSOR_INVALID;

    /**
     * Determines if the result set is open or closed.
     */
    private boolean isOpen = false;

    /**
     * A flag that determines whether or not calls to the {@link #restart()} method are allowed.
     */
    private boolean isRestartable = false;

    public ResultSetStubber() {
        // Nothing to do.  The initial values are set by fields.
    }

    /**
     * Copy constructor.
     */
    public ResultSetStubber(ResultSetStubber resultSet) {
        if (false == resultSet.isEmpty()) {
            this.metaData = new ResultSetMetaDataStubber(resultSet.metaData);
            this.rows.addAll(resultSet.rows);
            this.cursor = CURSOR_BEFORE_FIRST;
            this.isOpen = true;
        }
    }

    public void open() {
        this.isOpen = true;
    }

    public void setIsRestartable(boolean flag) {
        this.isRestartable = flag;
    }

    /**
     * Keeps the same row and meta data but sets the cursor back to the beginning.
     * This allows a JUnit test to keep reusing the same results across multiple tests.
     */
    public void restart() {
        if (false == this.isRestartable) {
            throw new IllegalStateException("Restarts not allowed for this result set.");
        }

        this.cursor = CURSOR_BEFORE_FIRST;
        this.isOpen = true;
    }

    /**
     * @param type
     *      See {@link java.sql.Types}.
     */
    public ResultSetStubber addColumn(String name, int type) {
        metaData.addColumn(name, type);
        return this;
    }

    public ResultSetStubber addRow(Object[] row) {
        cursor = CURSOR_BEFORE_FIRST;
        Vector<Object> rowAsVector = new Vector<Object>();
        rowAsVector.addAll(Arrays.asList(row));
        rows.add(rowAsVector);
        return this;
    }

    private boolean isEmpty() {
        return rows.isEmpty() || metaData.isEmpty();
    }

    @Override
    public <T> T unwrap(Class<T> iface) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean absolute(int row) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void afterLast() throws SQLException {
        if(!rows.isEmpty()) {
            cursor = CURSOR_AFTER_LAST;
        }
    }

    @Override
    public void beforeFirst() throws SQLException {
        if(!rows.isEmpty()) {
            cursor = CURSOR_BEFORE_FIRST;
        }
    }

    @Override
    public void cancelRowUpdates() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void clearWarnings() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void close() throws SQLException {
        if (metaData == null || cursor == CURSOR_INVALID || false == isOpen) {
            // Not explicitly in the spec but useful for testing.
            throw new IllegalStateException("ResultSet is already closed or was never opened.");
        }

        // Do NOT clear the data if we intend to restart the result set.
        if (false == this.isRestartable) {
            metaData = null;
            rows.clear();
        }
        cursor = CURSOR_INVALID;
        isOpen = false;
    }

    @Override
    public void deleteRow() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public int findColumn(String columnName) throws SQLException {
        return this.metaData.getColumnIndex(columnName);
    }

    @Override
    public boolean first() throws SQLException {
        boolean result = true;

        if (rows.isEmpty()) {
            result = false;
        } else {
            cursor = 0;
        }

        return result;
    }

    @Override
    public Array getArray(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Array getArray(String colName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public InputStream getAsciiStream(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public InputStream getAsciiStream(String columnName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public BigDecimal getBigDecimal(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public BigDecimal getBigDecimal(int columnIndex, int scale) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public BigDecimal getBigDecimal(String columnName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public BigDecimal getBigDecimal(String columnName, int scale) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public InputStream getBinaryStream(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public InputStream getBinaryStream(String columnName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Blob getBlob(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Blob getBlob(String columnName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean getBoolean(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean getBoolean(String columnName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public byte getByte(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public byte getByte(String columnName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public byte[] getBytes(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public byte[] getBytes(String columnName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Reader getCharacterStream(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Reader getCharacterStream(String columnName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Clob getClob(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Clob getClob(String colName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public int getConcurrency() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public String getCursorName() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Date getDate(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Date getDate(int columnIndex, Calendar cal) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Date getDate(String columnName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Date getDate(String columnName, Calendar cal) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public double getDouble(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public double getDouble(String columnName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public int getFetchDirection() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public int getFetchSize() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public float getFloat(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public float getFloat(String columnName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public int getInt(int columnIndex) throws SQLException {
        // NOTE: getColumnType is base 1 index.
        int type = metaData.getColumnType(columnIndex);

        // This type of stupid logic is allowed in most ResultSet impls.
        Integer result = null;
        if (Types.VARCHAR == type) {
            String temp = (String) rows.get(cursor).get(columnIndex-1);
            result = Integer.valueOf(temp);
        } else {
            result = (Integer) rows.get(cursor).get(columnIndex-1);
        }
        return result.intValue();
    }

    @Override
    public int getInt(String columnName) throws SQLException {
        // get base 1 column index from name.
        int columnIndex = metaData.getColumnIndex(columnName);
        return getInt(columnIndex);
    }

    @Override
    public long getLong(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public long getLong(String columnName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public ResultSetMetaData getMetaData() throws SQLException {
        return metaData;
    }

    @Override
    public Object getObject(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Object getObject(int columnIndex, Map<String, Class<?>> map) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Object getObject(String columnName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Object getObject(String columnName, Map<String, Class<?>> map) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Ref getRef(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Ref getRef(String colName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public int getRow() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public short getShort(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public short getShort(String columnName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Statement getStatement() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public String getString(int columnIndex) throws SQLException {
    	Vector<Object> rowData = rows.get(cursor);
        return (String) rowData.get(columnIndex-1);
    }

    @Override
    public String getString(String columnName) throws SQLException {
        // get base 1 column index from name.
        int columnIndex = metaData.getColumnIndex(columnName);
        return getString(columnIndex);
    }

    @Override
    public Time getTime(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Time getTime(int columnIndex, Calendar cal) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Time getTime(String columnName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Time getTime(String columnName, Calendar cal) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Timestamp getTimestamp(int columnIndex) throws SQLException {
        return (Timestamp) rows.get(cursor).get(columnIndex-1);
    }

    @Override
    public Timestamp getTimestamp(int columnIndex, Calendar cal) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Timestamp getTimestamp(String columnName) throws SQLException {
        // get base 1 column index from name
        int columnIndex = metaData.getColumnIndex(columnName);
        return getTimestamp(columnIndex);
    }

    @Override
    public Timestamp getTimestamp(String columnName, Calendar cal) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public int getType() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public InputStream getUnicodeStream(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public InputStream getUnicodeStream(String columnName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public URL getURL(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public URL getURL(String columnName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public SQLWarning getWarnings() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void insertRow() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isAfterLast() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isBeforeFirst() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isFirst() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isLast() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean last() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void moveToCurrentRow() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void moveToInsertRow() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean next() throws SQLException {
        boolean result = false;

        if (CURSOR_BEFORE_FIRST == cursor) {
            cursor = 0;
            result = true;
        } else if (CURSOR_AFTER_LAST == cursor) {
            throw new SQLException("No more rows.");
        } else if (rows.isEmpty()) {
            cursor = CURSOR_AFTER_LAST;
            result = false;
        } else {
            cursor++;
            result = true;
            if (cursor >= rows.size()) {
                cursor = CURSOR_AFTER_LAST;
                result = false;
            }
        }
        return result;
    }

    @Override
    public boolean previous() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void refreshRow() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean relative(int rowOffset) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean rowDeleted() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean rowInserted() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean rowUpdated() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void setFetchDirection(int direction) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void setFetchSize(int rows) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateArray(int columnIndex, Array x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateArray(String columnName, Array x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateAsciiStream(int columnIndex, InputStream x, int length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateAsciiStream(String columnName, InputStream x, int length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateBigDecimal(int columnIndex, BigDecimal x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateBigDecimal(String columnName, BigDecimal x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateBinaryStream(int columnIndex, InputStream x, int length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateBinaryStream(String columnName, InputStream x, int length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateBlob(int columnIndex, Blob x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateBlob(String columnName, Blob x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateBoolean(int columnIndex, boolean x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateBoolean(String columnName, boolean x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateByte(int columnIndex, byte x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateByte(String columnName, byte x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateBytes(int columnIndex, byte[] x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateBytes(String columnName, byte[] x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateCharacterStream(int columnIndex, Reader x, int length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateCharacterStream(String columnName, Reader reader, int length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateClob(int columnIndex, Clob x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateClob(String columnName, Clob x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateDate(int columnIndex, Date x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateDate(String columnName, Date x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateDouble(int columnIndex, double x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateDouble(String columnName, double x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateFloat(int columnIndex, float x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateFloat(String columnName, float x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateInt(int columnIndex, int x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateInt(String columnName, int x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateLong(int columnIndex, long x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateLong(String columnName, long x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateNull(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateNull(String columnName) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateObject(int columnIndex, Object x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateObject(int columnIndex, Object x, int scale) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateObject(String columnName, Object x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateObject(String columnName, Object x, int scale) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateRef(int columnIndex, Ref x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateRef(String columnName, Ref x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateRow() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateShort(int columnIndex, short x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateShort(String columnName, short x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateString(int columnIndex, String x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateString(String columnName, String x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateTime(int columnIndex, Time x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateTime(String columnName, Time x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateTimestamp(int columnIndex, Timestamp x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateTimestamp(String columnName, Timestamp x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean wasNull() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public RowId getRowId(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public RowId getRowId(String columnLabel) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateRowId(int columnIndex, RowId x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateRowId(String columnLabel, RowId x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public int getHoldability() throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isClosed() throws SQLException {
        return (false == this.isOpen);
    }

    @Override
    public void updateNString(int columnIndex, String nString) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateNString(String columnLabel, String nString) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateNClob(int columnIndex, NClob nClob) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateNClob(String columnLabel, NClob nClob) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public NClob getNClob(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public NClob getNClob(String columnLabel) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public SQLXML getSQLXML(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public SQLXML getSQLXML(String columnLabel) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateSQLXML(int columnIndex, SQLXML xmlObject) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateSQLXML(String columnLabel, SQLXML xmlObject) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public String getNString(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public String getNString(String columnLabel) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Reader getNCharacterStream(int columnIndex) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Reader getNCharacterStream(String columnLabel) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateNCharacterStream(int columnIndex, Reader x, long length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateNCharacterStream(String columnLabel, Reader reader, long length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateAsciiStream(int columnIndex, InputStream x, long length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateBinaryStream(int columnIndex, InputStream x, long length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateCharacterStream(int columnIndex, Reader x, long length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateAsciiStream(String columnLabel, InputStream x, long length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateBinaryStream(String columnLabel, InputStream x, long length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateCharacterStream(String columnLabel, Reader reader, long length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateBlob(int columnIndex, InputStream inputStream, long length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateBlob(String columnLabel, InputStream inputStream, long length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateClob(int columnIndex, Reader reader, long length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateClob(String columnLabel, Reader reader, long length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateNClob(int columnIndex, Reader reader, long length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateNClob(String columnLabel, Reader reader, long length) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateNCharacterStream(int columnIndex, Reader x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateNCharacterStream(String columnLabel, Reader reader) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateAsciiStream(int columnIndex, InputStream x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateBinaryStream(int columnIndex, InputStream x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateCharacterStream(int columnIndex, Reader x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateAsciiStream(String columnLabel, InputStream x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateBinaryStream(String columnLabel, InputStream x) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateCharacterStream(String columnLabel, Reader reader) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateBlob(int columnIndex, InputStream inputStream) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateBlob(String columnLabel, InputStream inputStream) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateClob(int columnIndex, Reader reader) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateClob(String columnLabel, Reader reader) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateNClob(int columnIndex, Reader reader) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateNClob(String columnLabel, Reader reader) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateObject(int columnIndex, Object x, SQLType targetSqlType, int scaleOrLength) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateObject(String columnLabel, Object x, SQLType targetSqlType, int scaleOrLength) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateObject(int columnIndex, Object x, SQLType targetSqlType) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void updateObject(String columnLabel, Object x, SQLType targetSqlType) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public <T> T getObject(int columnIndex, Class<T> type) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public <T> T getObject(String columnLabel, Class<T> type) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }
}
