/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.testutils.servlet;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * A simple (but not efficient) mock implementation of a {@link FilterChain}.
 */
public class FilterChainStubber implements FilterChain {
    
    private static final Logger log = Logger.getLogger(FilterChainStubber.class.getName());
    
    /**
     * The filters that are chained together.
     */
    private List<Filter> filterList;

    /**
     *  A ServletException to throw, should one be needed for testing.
     */
    private RuntimeException exceptionToThrow = null;
    
    /**
     * Constructor.
     */
    public FilterChainStubber() {
        filterList = new ArrayList<Filter>();
    }

    /**
     * Constructor, intended for internal use.
     */
    protected FilterChainStubber(List<Filter> chain) {
        filterList = chain;
    }

    /**
     * Adds the given filter to the chain.
     */
    public void addFilter(Filter filter) {
        filterList.add(filter);
    }

    /**
     * Gets the entire list of filters that are chained together.
     */
    public List<Filter> getFilterList() {
        return filterList;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
        if (!filterList.isEmpty()) {
            // Pops off the next filter and creates another chain.
            List<Filter> nextFilters = new ArrayList<Filter>(filterList);
            Filter first = nextFilters.remove(0);
            if(null != this.exceptionToThrow){
                log.severe("Throwing " + this.exceptionToThrow);
                throw this.exceptionToThrow;
            }
            // Continue the rest of the chain - as long as there are more filters.
            if(!nextFilters.isEmpty()){
                FilterChainStubber nextChain = new FilterChainStubber(nextFilters);
                first.doFilter(request, response, nextChain);
            }
        }
    }

    public void setExceptionToThrow(RuntimeException inExceptionToThrow) {
        this.exceptionToThrow = inExceptionToThrow;
    }

    public Exception getExceptionToThrow() {
        return exceptionToThrow;
    }
}
