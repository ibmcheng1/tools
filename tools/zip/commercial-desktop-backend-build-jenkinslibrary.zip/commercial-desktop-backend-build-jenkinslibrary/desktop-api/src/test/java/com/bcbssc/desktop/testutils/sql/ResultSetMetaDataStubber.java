/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUE CROSS BLUE SHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.
 * ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUE CROSS BLUE SHIELD OF SOUTH CAROLINA.
 * ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.testutils.sql;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

public class ResultSetMetaDataStubber implements ResultSetMetaData {
    private static class ColumnData {
        private String name;
        /** {@link java.sql.Types} */
        private int type;
        /** Zero based index. */
        private int index;
        public ColumnData(String name, int type, int index) {
            this.name = name;
            this.type = type;
            this.index = index;
        }
        public String getName() {
            return name;
        }
        public int getType() {
            return type;
        }
        /** Gets the zero based index. */
        public int getIndex() {
            return index;
        }
    }

    /**
     * Maps column name to the actual column data.
     * Most real life implementations are case insensitive so methods implement in here should always do toUpperCase.
     */
    private Map<String, ColumnData> columnNameMap = new HashMap<String, ColumnData>();
    private Vector<ColumnData> columns = new Vector<ColumnData>();

    /**
     * Constructor.
     */
    public ResultSetMetaDataStubber() {
        // Nothing to do.
    }

    /**
     * Copy constructor.
     */
    public ResultSetMetaDataStubber(ResultSetMetaDataStubber metaData) {
        this.columnNameMap.putAll(metaData.columnNameMap);
        this.columns.addAll(metaData.columns);
    }

    public boolean isEmpty() {
         return columns.isEmpty() || columnNameMap.isEmpty();
    }

    /**
     * @param type
     *      See {@link java.sql.Types}.
     */
    public void addColumn(String name, int type) {
        int index = columns.size();
        ColumnData newColumn = new ColumnData(name.toUpperCase(), type, index);
        columns.add(newColumn);
        columnNameMap.put(name.toUpperCase(), newColumn);
    }

    /**
     * The base 1 index of the given column name.
     */
    public int getColumnIndex(String columnName) {
        return columnNameMap.get(columnName.toUpperCase()).getIndex()+1;
    }

    @Override
    public <T> T unwrap(Class<T> iface) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public String getCatalogName(int column) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public String getColumnClassName(int column) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public int getColumnCount() throws SQLException {
        return columns.size();
    }

    @Override
    public int getColumnDisplaySize(int column) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public String getColumnLabel(int column) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public String getColumnName(int column) throws SQLException {
        return columns.get(column-1).getName();
    }

    @Override
    public int getColumnType(int column) throws SQLException {
        return this.columns.get(column-1).getType();
    }

    @Override
    public String getColumnTypeName(int column) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public int getPrecision(int column) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public int getScale(int column) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public String getSchemaName(int column) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public String getTableName(int column) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isAutoIncrement(int column) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isCaseSensitive(int column) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isCurrency(int column) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isDefinitelyWritable(int column) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public int isNullable(int column) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isReadOnly(int column) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isSearchable(int column) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isSigned(int column) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isWritable(int column) throws SQLException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }
}
