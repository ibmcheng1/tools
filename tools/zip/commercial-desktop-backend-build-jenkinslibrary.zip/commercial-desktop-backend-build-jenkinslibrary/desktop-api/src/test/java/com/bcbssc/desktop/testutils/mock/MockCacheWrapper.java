/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.testutils.mock;

import com.bcbssc.desktop.dao.cache.ICacheWrapper;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * A mock cacheWrapper for Junit tests that need to simulate dynaCache
 */
public class MockCacheWrapper implements ICacheWrapper {

    /** logger */
    private static final Log logger = LogFactory.getLog(MockCacheWrapper.class);

    /** TreeMap just because it's useful to see the dump sorted. */
    private static Map<String, Serializable> DATA_STORE = new TreeMap<String, Serializable>();

    private static int SECONDS_IN_MINUTE = 60;
    // session cache timeout = 540 minutes (32,400 seconds) +  20 minutes (1,200 seconds)
    private static int SESSION_INACTIVITY_SECONDS = (540 * SECONDS_IN_MINUTE) + (20 * SECONDS_IN_MINUTE);
    //application cache timeout = none
    private static int APPLICATION_INACTIVITY_SECONDS = 0;

    public MockCacheWrapper() throws Exception {
    	// If this throws an exception then the previous test case had a problem.
    	this.clear();
    }

    public MockCacheWrapper clear() throws Exception {
	    serialize();
    	DATA_STORE.clear();
    	return this;
    }

    private Map<String, Serializable> getCacheInstance() throws Exception {
    	serialize();
    	return DATA_STORE;
    }

    @Override
	public Serializable getEntry(String key) throws Exception {
        
    	Map<String, Serializable> map = getCacheInstance();
    	HashMap<?,?> entry = null;

        if (map.containsKey(key)) {
            entry = (HashMap<?, ?>) map.get(key);
        }


        if(entry != null) {
                System.out.println("CACHE ENTRY FETCHED FOR KEY [" + key + "] = [" + entry.getClass().getCanonicalName() + "]");
                
                for (Map.Entry<?, ?> mapEntry: entry.entrySet()) {
                    System.out.println("MockCacheWrapper: getEntry(): " + mapEntry.getKey() + " " + mapEntry.getValue());
                }
                
        } else {
                System.out.println("CACHE ENTRY NOT FETCHED FOR KEY [" + key + "]");
        }
        
        return entry;
    }

    @Override
    public Set<String> getKeys() throws Exception {
         return getCacheInstance().keySet();
    }

    @Override
	public boolean hasEntry(String key) throws Exception {
        return getCacheInstance().containsKey(key);
    }
    
    @Override
	public Serializable setApplicationEntry(String key, Serializable entry) throws Exception {
        if(logger.isDebugEnabled()) {
            logger.debug("SETTING CACHE ENTRY - APPLICATION - KEY [" + key + "]");
        }
        int inactivity_time = APPLICATION_INACTIVITY_SECONDS;
        return setEntry(key, entry, inactivity_time);
    }

    @Override
	public Serializable setSessionEntry(String key, Serializable entry) throws Exception {
        
        if(logger.isDebugEnabled()) {
            logger.debug("SETTING CACHE ENTRY - SESSION - KEY [" + key + "]");
        }
        
        int inactivity_time = SESSION_INACTIVITY_SECONDS;
        return setEntry(key, entry, inactivity_time);
    }

    /**
     * Sets an entry in the Cache. Entry properties are loaded from defaults.
     * @param key String
     * @param entry Object
     * @return Object - the cached object.
     */
    public Serializable setEntry(String key, Serializable entry, int inactivity_time) throws Exception {
    	Map<String, Serializable> map = getCacheInstance();
        Serializable result = null;
        if (null != map) {
            result = (Serializable) map.put(key, entry);
            serialize();
        } else {
            throw new IllegalStateException("Attempted to save an entry into cache, but the cache map could not be found!!");
        }
        return result;
    }
    
    /**
     * Removes an entry from cache if it exists.
     * @param key String
     */
    @Override
	public void removeEntry(String key) throws Exception {
        if(logger.isDebugEnabled()){
            logger.debug("REMOVING CACHE ENTRY: " + key);
        }
        Map<String, Serializable> map = getCacheInstance();
        if (null != map){
            map.remove(key);
        } else{
            throw new IllegalStateException("Attempted to remove an entry from cache, but the cache map could not be found!!");
        }
    }
    
    public static void updateMockCacheWrapperMap(String sessionId, String key, Serializable value) throws Exception {
    	HashMap<String, Serializable> tempMap = new HashMap<String, Serializable>();
        tempMap.put(key, value);
        
        DATA_STORE.put(sessionId, tempMap);
        serialize();
    }

    /** Make sure that everything in the data store is serializable. */
    private static byte[] serialize() throws Exception {
        ObjectOutputStream oos = null;
        ByteArrayOutputStream baos = null;

        baos = new ByteArrayOutputStream();
        oos = new ObjectOutputStream(baos);
        oos.writeObject(DATA_STORE);
        oos.flush();

        byte[] data = baos.toByteArray();
        return data;
    }
}
