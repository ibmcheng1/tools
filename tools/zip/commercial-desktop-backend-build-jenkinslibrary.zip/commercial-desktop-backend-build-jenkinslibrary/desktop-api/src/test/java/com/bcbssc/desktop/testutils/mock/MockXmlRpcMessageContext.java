/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.testutils.mock;

import javax.xml.rpc.handler.MessageContext;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/**
 * Implements the XML-RPC <code>MessageContext</code> for JUnit tests.
 */
public class MockXmlRpcMessageContext implements MessageContext {
    final Map<String, Object>map = new TreeMap<String, Object>();

    @Override
	public void setProperty(String paramString, Object paramObject) {
        map.put(paramString, paramObject);
    }

    @Override
	public Object getProperty(String paramString) {
        return map.get(paramString);
    }

    @Override
	public void removeProperty(String paramString) {
        map.remove(paramString);
    }

    @Override
	public boolean containsProperty(String paramString) {
        return map.containsKey(paramString);
    }

    @Override
	@SuppressWarnings("rawtypes")
    public Iterator getPropertyNames() {
        return map.keySet().iterator();
    }
}
