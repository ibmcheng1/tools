/*
 * Copyright (C) 2012 BlueCross BlueShield of South Carolina, all rights reserved.
 *
 * This software is the confidential and proprietary property of
 * BlueCross BlueShield of South Carolina ("Confidential Information").
 * Any unauthorized use or reproduction is strictly prohibited.
 */
package com.bcbssc.desktop.api;

import javax.security.auth.Subject;

import com.bcbssc.desktop.testutils.naming.SimpleInitialContextStubber;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;

import junit.framework.TestCase;

/**
 * Tests {@link DesktopAPI}
 */
public class DesktopAPITest extends TestCase {
    public void testCreateStaticSubject() throws Throwable {
        final SimpleInitialContextStubber stubber = new SimpleInitialContextStubber();
        stubber.bind(EnvironmentObjects.REGION_DEFAULT.getName(), "DV7ST1");
        stubber.bind(EnvironmentObjects.DEFAULT_RPN.getName(), "001");
        stubber.bind(EnvironmentObjects.STATIC_RACF_ID.getName(), "WEB4CSR");
        stubber.bind(EnvironmentObjects.STATIC_RACF_PASSWORD.getName(), "WEB$CSR1");

        final Subject applicationSubject = DesktopAPI.createStaticSubject("CSR");
        assertNotNull(applicationSubject);

        stubber.shutDown();
    }
}
