/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.testutils.servlet.jsp;

import javax.servlet.jsp.JspWriter;
import java.io.IOException;
import java.io.StringWriter;

/**
 * A mock {@link javax.servlet.jsp.JspWriter}, internally a {@link java.io.StringWriter}.
 * The data payload can be retrieved by calling the {@link #toString} method.
 */
public class JspWriterStubber extends JspWriter {
    private int bufferSize;
    private StringWriter writer;

    public JspWriterStubber() {
        this(1000, false);
    }

    protected JspWriterStubber(int bufferSize, boolean autoFlush) {
        super(bufferSize, autoFlush);
        this.bufferSize = bufferSize;
        this.writer = new StringWriter(bufferSize);
    }

    @Override
    public void clear() throws IOException {
        this.writer = new StringWriter(this.bufferSize);
    }

    @Override
    public void clearBuffer() throws IOException {
        this.writer = new StringWriter(this.bufferSize);
    }

    @Override
    public void close() throws IOException {
        this.writer.close();
    }

    @Override
    public void flush() throws IOException {
        this.writer.flush();
    }

    @Override
    public int getRemaining() {
        throw new UnsupportedOperationException("JspWriterStubber.getRemaining This method hasn't been implemented yet");
    }

    @Override
    public void newLine() throws IOException {
        this.writer.append('\n');
    }

    @Override
    public void print(boolean b) throws IOException {
        throw new UnsupportedOperationException("JspWriterStubber.print(boolean) This method hasn't been implemented yet");
    }

    @Override
    public void print(char c) throws IOException {
        this.writer.write(c);
    }

    @Override
    public void print(int i) throws IOException {
        this.writer.write(i);
    }

    @Override
    public void print(long l) throws IOException {
        throw new UnsupportedOperationException("JspWriterStubber.print(long) This method hasn't been implemented yet");
    }

    @Override
    public void print(float f) throws IOException {
        throw new UnsupportedOperationException("JspWriterStubber.print(float) This method hasn't been implemented yet");
    }

    @Override
    public void print(double d) throws IOException {
        throw new UnsupportedOperationException("JspWriterStubber.print(double) This method hasn't been implemented yet");
    }

    @Override
    public void print(char[] s) throws IOException {
        this.writer.write(s);
    }

    @Override
    public void print(String s) throws IOException {
        this.writer.write(s);
    }

    @Override
    public void print(Object obj) throws IOException {
        this.writer.write(obj.toString());
    }

    @Override
    public void println() throws IOException {
        this.writer.append('\n');
    }

    @Override
    public void println(boolean x) throws IOException {
        throw new UnsupportedOperationException("JspWriterStubber.println(boolean) This method hasn't been implemented yet");
    }

    @Override
    public void println(char x) throws IOException {
        throw new UnsupportedOperationException("JspWriterStubber.println(char) This method hasn't been implemented yet");
    }

    @Override
    public void println(int x) throws IOException {
        throw new UnsupportedOperationException("JspWriterStubber.println(int) This method hasn't been implemented yet");
    }

    @Override
    public void println(long x) throws IOException {
        throw new UnsupportedOperationException("JspWriterStubber.println(long) This method hasn't been implemented yet");
    }

    @Override
    public void println(float x) throws IOException {
        throw new UnsupportedOperationException("JspWriterStubber.println(float) This method hasn't been implemented yet");
    }

    @Override
    public void println(double x) throws IOException {
        throw new UnsupportedOperationException("JspWriterStubber.println(double) This method hasn't been implemented yet");
    }

    @Override
    public void println(char[] x) throws IOException {
        this.writer.write(x);
        this.writer.append('\n');
    }

    @Override
    public void println(String x) throws IOException {
        this.writer.write(x);
        this.writer.append('\n');
    }

    @Override
    public void println(Object x) throws IOException {
        this.println(x.toString());
    }

    @Override
    public void write(char[] cbuf, int off, int len) throws IOException {
        this.writer.write(cbuf, off, len);
    }

    @Override
    public String toString() {
        return this.writer.toString();
    }
}
