/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.testutils.servlet;

import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;

public class ServletInputStreamStubber extends ServletInputStream {
	private ByteArrayInputStream inputStream;

	public ServletInputStreamStubber(byte[] buf) {
		inputStream = new ByteArrayInputStream(buf);
	}

	public ServletInputStreamStubber(byte[] buf, int offset, int length) {
		inputStream = new ByteArrayInputStream(buf, offset, length);
	}

	public ServletInputStreamStubber(String input) {
		this(input.getBytes());
	}

	public ServletInputStreamStubber(StringBuilder input) {
		this(input.toString().getBytes());
	}

	@Override
	public int read() throws IOException {
		return inputStream.read();
	}

    @Override
    public boolean isFinished() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isReady() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void setReadListener(ReadListener readListener) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }
}