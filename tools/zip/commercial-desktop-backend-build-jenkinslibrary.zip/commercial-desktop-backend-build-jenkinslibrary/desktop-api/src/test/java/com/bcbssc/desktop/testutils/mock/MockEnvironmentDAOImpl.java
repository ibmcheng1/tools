/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.testutils.mock;

import com.bcbssc.desktop.dao.EnvironmentDAO;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;

import javax.security.auth.Subject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Intended for junit or testing situations where there is no server. Does not support multiple regions.
 * 
 * @author X87M
 */
public class MockEnvironmentDAOImpl implements EnvironmentDAO {
    /**
     * The mock JNDI storage. Does not accurately support the node logic for the name paths but good enough for junit.
     */
    private static Map<String, Object> mockJndiStorage;

    /**
     * Constructor.
     */
    public MockEnvironmentDAOImpl() {
        mockJndiStorage = new HashMap<String, Object>();
    }

    @Override
	public Object getObject(EnvironmentObjects environmentObject, Subject subject) {
        return mockJndiStorage.get(environmentObject.getBaseId());
    }

    public void setObject(EnvironmentObjects environmentObject, Object value) {
        mockJndiStorage.put(environmentObject.getBaseId(), value);
    }

    @Override
	public Object getCommonObject(EnvironmentObjects environmentObject) {
        return mockJndiStorage.get(environmentObject.getBaseId());
    }

    @Override
	public boolean isEnvironmentDefined(String environment) {
        // TODO Implement
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
	public List<String> getEnvironments() {
        // TODO Auto-generated method stub
        return null;
    }
}