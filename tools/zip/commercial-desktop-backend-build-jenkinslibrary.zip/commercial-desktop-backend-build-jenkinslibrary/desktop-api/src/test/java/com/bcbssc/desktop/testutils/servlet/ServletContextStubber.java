/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.testutils.servlet;

import javax.servlet.Filter;
import javax.servlet.FilterRegistration;
import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;
import javax.servlet.SessionCookieConfig;
import javax.servlet.SessionTrackingMode;
import javax.servlet.descriptor.JspConfigDescriptor;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.EventListener;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * A mock class that represents a {@link ServletContext}. This allows for executing
 * servlets in JUnit tests that use the {@link ServletContext}.
 */
public class ServletContextStubber implements ServletContext {
    /**
     * The absolute file system path of the server's web app.
     * For example, <code>C:/IBM/WebSphere/AppServer/profiles/AppSrv01/installedApps/AF-5S5GLS1Node01Cell/crmhnfs.ear/desktop-ccm.war/</code>
     * <br/>
     * NOTE: Yes the current working directory when running JUnit in RAD is the project's root
     * but when the war is deployed to the server what's in WebContent is the root.
     */
    private String realPathRoot = "WebContent";

    /**
     * The web application's context path (with leading '/') as defined in the container.
     * For example, <code>/crmhnfs</code>
     */
    private String contextPath;

    private RequestDispatcher dispatcher = null;

    private Map<String, Object> attributes = new HashMap<String, Object>();

    @Override
    public Object getAttribute(String paramString) {
        return attributes.get(paramString);
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Enumeration getAttributeNames() {
        throw new UnsupportedOperationException("getAttributeNames method hasn't been implemented yet");
    }

    @Override
    public ServletContext getContext(String paramString) {
        throw new UnsupportedOperationException("getContext method hasn't been implemented yet");
    }

    /**
     * Gets the root context with leading '/'.
     * For example, "/crmwest".
     */
    @Override
    public String getContextPath() {
        return this.contextPath;
    }

    /**
     * Sets the root context, for example, "/crmwest".
     */
    public void setContextPath(String contextPath) {
        if (false == contextPath.startsWith("/")) {
            throw new IllegalArgumentException("Context path must start with /");
        }
        this.contextPath = contextPath;
    }

    @Override
    public String getInitParameter(String paramString) {
        throw new UnsupportedOperationException("getInitParameter method hasn't been implemented yet");
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Enumeration getInitParameterNames() {
        throw new UnsupportedOperationException("getInitParameterNames method hasn't been implemented yet");
    }

    @Override
    public int getMajorVersion() {
        throw new UnsupportedOperationException("getMajorVersion method hasn't been implemented yet");
    }

    @Override
    public String getMimeType(String paramString) {
        throw new UnsupportedOperationException("getMimeType method hasn't been implemented yet");
    }

    @Override
    public int getMinorVersion() {
        throw new UnsupportedOperationException("getMinorVersion method hasn't been implemented yet");
    }

    @Override
    public RequestDispatcher getNamedDispatcher(String paramString) {
        throw new UnsupportedOperationException("getNamedDispatcher method hasn't been implemented yet");
    }

    @Override
    public String getRealPath(String path) {
        // The spec doesn't really say this but real production code assumes this.
        if (false == path.startsWith("/")) {
            path = "/" + path;
        }
        return realPathRoot + path;
    }

    public void setRealPathRoot(String realPathRoot) {
        this.realPathRoot = realPathRoot;
    }

    @Override
    public RequestDispatcher getRequestDispatcher(String url) {
        if (null == dispatcher) {
            dispatcher = new RequestDispatcherStubber(url);
        }
        return dispatcher;
    }

    @Override
    public URL getResource(String paramString) throws MalformedURLException {
        throw new UnsupportedOperationException("getResource method hasn't been implemented yet");
    }

    @Override
    public InputStream getResourceAsStream(String paramString) {
        throw new UnsupportedOperationException("getResourceAsStream method hasn't been implemented yet");
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Set getResourcePaths(String paramString) {
        throw new UnsupportedOperationException("getResourcePaths method hasn't been implemented yet");
    }

    @Override
    public String getServerInfo() {
        throw new UnsupportedOperationException("getServerInfo method hasn't been implemented yet");
    }

    @Override
    public Servlet getServlet(String paramString) throws ServletException {
        throw new UnsupportedOperationException("getServlet method hasn't been implemented yet");
    }

    @Override
    public String getServletContextName() {
        throw new UnsupportedOperationException("getServletContextName method hasn't been implemented yet");
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Enumeration getServletNames() {
        throw new UnsupportedOperationException("getServletNames method hasn't been implemented yet");
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Enumeration getServlets() {
        throw new UnsupportedOperationException("getServlets method hasn't been implemented yet");
    }

    @Override
    public void log(String paramString) {
        throw new UnsupportedOperationException("log(String) method hasn't been implemented yet");
    }

    @Override
    public void log(Exception paramException, String paramString) {
        throw new UnsupportedOperationException("log(Exception, String) method hasn't been implemented yet");
    }

    @Override
    public void log(String paramString, Throwable paramThrowable) {
        throw new UnsupportedOperationException("log(String, Throwable) method hasn't been implemented yet");
    }

    @Override
    public void removeAttribute(String paramString) {
        throw new UnsupportedOperationException("removeAttribute method hasn't been implemented yet");
    }

    @Override
    public void setAttribute(String paramString, Object paramObject) {
        attributes.put(paramString, paramObject);
    }

    @Override
    public int getEffectiveMajorVersion() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public int getEffectiveMinorVersion() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean setInitParameter(String s, String s1) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public ServletRegistration.Dynamic addServlet(String s, String s1) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public ServletRegistration.Dynamic addServlet(String s, Servlet servlet) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public ServletRegistration.Dynamic addServlet(String s, Class<? extends Servlet> aClass) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public <T extends Servlet> T createServlet(Class<T> aClass) throws ServletException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public ServletRegistration getServletRegistration(String s) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Map<String, ? extends ServletRegistration> getServletRegistrations() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public FilterRegistration.Dynamic addFilter(String s, String s1) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public FilterRegistration.Dynamic addFilter(String s, Filter filter) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public FilterRegistration.Dynamic addFilter(String s, Class<? extends Filter> aClass) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public <T extends Filter> T createFilter(Class<T> aClass) throws ServletException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public FilterRegistration getFilterRegistration(String s) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Map<String, ? extends FilterRegistration> getFilterRegistrations() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public SessionCookieConfig getSessionCookieConfig() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void setSessionTrackingModes(Set<SessionTrackingMode> set) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Set<SessionTrackingMode> getDefaultSessionTrackingModes() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Set<SessionTrackingMode> getEffectiveSessionTrackingModes() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void addListener(String s) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public <T extends EventListener> void addListener(T t) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void addListener(Class<? extends EventListener> aClass) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public <T extends EventListener> T createListener(Class<T> aClass) throws ServletException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public JspConfigDescriptor getJspConfigDescriptor() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public ClassLoader getClassLoader() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void declareRoles(String... strings) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public String getVirtualServerName() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /**
     * @return the dispatcher
     */
    public RequestDispatcher getDispatcher() {
        return dispatcher;
    }

    /**
     * @param dispatcher the dispatcher to set
     */
    public void setDispatcher(RequestDispatcher dispatcher) {
        this.dispatcher = dispatcher;
    }

}
