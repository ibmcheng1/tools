/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.testutils.servlet;

import javax.servlet.ServletOutputStream;
import javax.servlet.WriteListener;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * A simple mock implementation of the {@link ServletOutputStream}.
 * Supports raw binary data as well as text data.
 *
 * More methods are available to be overridden but the javadocs state
 * that the <code>write(int)</code> is the only one that <b>needs</b> to be.
 */
public class ServletOutputStreamStubber extends ServletOutputStream {
    private ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

    @Override
    public void write(int b) throws IOException {
        this.outputStream.write(b);
    }

    public ByteArrayOutputStream getOutputStream() {
        return this.outputStream;
    }

    @Override
    public String toString() {
        return this.outputStream.toString();
    }

    @Override
    public boolean isReady() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void setWriteListener(WriteListener writeListener) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }
}
