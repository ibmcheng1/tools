package com.bcbssc.desktop.testutils.security;

import java.security.Principal;

public class PrincipalStubber implements Principal {
    private String name;

    @Override
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }
}