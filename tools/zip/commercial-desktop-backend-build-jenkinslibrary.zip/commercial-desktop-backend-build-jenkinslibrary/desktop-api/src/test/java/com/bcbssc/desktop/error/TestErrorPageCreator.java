/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.error;

import java.util.ArrayList;

import com.bcbssc.desktop.util.exception.security.DataAccessAuthorizationException;
import com.bcbssc.domain.exceptions.WorkManagerProcessFailedException;

import junit.framework.Assert;
import junit.framework.TestCase;

/**
 * Test class for ErrorPageCreator
 */
public class TestErrorPageCreator extends TestCase {
    private static final String EXCEPTIONCLASSNAME_WITH_CUSTOM_FLAG= DataAccessAuthorizationException.class.getName();
    private static final String FRIENDLYMESSAGE_FOR_EXCEPTION = "You do not have authorization to use this feature.";
    private static final String EXCEPTIONCLASSNAME_WITHOUT_CUSTOM_FLAG = "TestException";

    public void testGetErrorBody() throws Exception{
        String exceptionClassNameForCustom = EXCEPTIONCLASSNAME_WITH_CUSTOM_FLAG;
        String exceptionClassName = EXCEPTIONCLASSNAME_WITHOUT_CUSTOM_FLAG;
        String s1ErrorBody = ErrorPageCreator.getErrorBody(exceptionClassName, "TestException", exceptionClassName, 1, "Test Exception Message", null);
        String s2ErrorBody = ErrorPageCreator.getErrorBody(exceptionClassNameForCustom, "TestException", exceptionClassNameForCustom, 1, "Test Exception Message", null);

        assertNotNull(s1ErrorBody);
        assertNotNull(s2ErrorBody);
        // Check if the correct flag was retrieved
        assertTrue(s1ErrorBody.contains(MonitorFlags.MONITOR_TICKET_S1.toString()));
        // Check if the custom display message was retrieved
        assertTrue(s2ErrorBody.contains(FRIENDLYMESSAGE_FOR_EXCEPTION));
        
        assertTrue(s2ErrorBody.contains(MonitorFlags.MONITOR_TICKET_NONE.toString()));
        
    }

    public void testDeDupeExceptionList(){
        ArrayList<Throwable> testExceptionList = new ArrayList<Throwable>();
        ArrayList<Throwable> deDupedList = new ArrayList<Throwable>();
        NullPointerException NPE1 = new NullPointerException("test nullPointerException 1");
        testExceptionList.add(NPE1);
        NullPointerException NPE2 = new NullPointerException("test nullPointerException 2");
        testExceptionList.add(NPE2);

        deDupedList = (ArrayList<Throwable>) ErrorPageCreator.deDupeExceptionList(testExceptionList);
        int listSize = deDupedList.size();
        int expectedListSize = 1;
        assertEquals(listSize,expectedListSize);

    }

    public void test_getErrorBody() throws Throwable {
    	WorkManagerProcessFailedException ex = new WorkManagerProcessFailedException(new ArrayList<Throwable>());
    	ex.getExceptions().add(new DataAccessAuthorizationException("This is a access problem."));
    	ex.getExceptions().add(new RuntimeException("This is a general problem."));
    	String actual = ErrorPageCreator.getErrorBody(ex, ex.getClass(), null, "junit-message", "junit-requestUri");
    	String expected = "<span class=\"errorMsg\">You do not have authorization to use this feature.</span><div class=\"errorinformation\"><h1>com.bcbssc.desktop.util.exception.security.DataAccessAuthorizationException</h1><h2>junit-message</h1><h4>MONITOR_TICKET_NONE</h4><pre>com.bcbssc.desktop.util.exception.security.DataAccessAuthorizationException: This is a access problem.</pre><hr/><i>Error accessing junit-requestUri</i><ul></ul></div>";
    	Assert.assertEquals(expected, actual);
    }
}
