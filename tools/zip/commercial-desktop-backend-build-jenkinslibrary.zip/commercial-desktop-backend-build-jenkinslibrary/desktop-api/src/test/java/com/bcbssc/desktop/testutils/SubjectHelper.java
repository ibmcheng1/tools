/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.testutils;

import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.ApplicationClient;
import com.bcbssc.domain.entity.InformIdentification;
import com.bcbssc.domain.entity.Subsystem;
import com.bcbssc.domain.entity.auth.InformIdPrincipal;
import com.bcbssc.domain.entity.enums.Subsystems;

import javax.security.auth.Subject;
import java.util.HashMap;
import java.util.Map;

/**
 * A SubjectHelper contains helper methods for dealing with Subject objects in 
 * unit tests.  Typically when code under test is executed in a live environment, 
 * a Subject already exists.  However, in a unit test scenario, it can be tedious to 
 * set up a Subject to simulate how the code is actually executed.
 * This class helps with that setup.
 *
 * 
 * @author $Author$  (original: DG70)
 * @version $Revision$
 */
public class SubjectHelper {

    String rpn;
    String planCode;
    Map<String, Subsystem> subsystemRpns;
    String informQualifier;
    String region;

    public SubjectHelper() {
    	this.planCode = "JUNIT_PLAN_CODE";

    	this.subsystemRpns = new HashMap<String, Subsystem>();
    	for (Subsystems e : Subsystems.values()) {
    		this.subsystemRpns.put(e.getName(), new Subsystem(e, "JUNIT_RPN_FOR_" + e.getName()));
    	}

    	this.informQualifier = "JUNIT_INFORM_QUALIFIER";
    }

    /**
     * Builds a Subject object based on object properties of this class.
     * If these properties are null, the result is a Subject suitable for use 
     * with SubjectUtils.set*() - i.e. the usual Principal objects are set (but may be empty).
     * @return a populated Subject object
     */
    public Subject buildSubject() {
        Subject user = SubjectUtils.createEmptySubject();
        SubjectUtils.setRPN(user, this.getRpn());
        SubjectUtils.setRegion(user, this.getRegion());
        ApplicationClient client = new ApplicationClient();
        client.setPlanCode(this.planCode);
        client.setInformQualifier(this.informQualifier);
        client.setAppId("JUNIT_APP_ID");
        client.setAliasRpn("JUNIT_ALIAS_RPN");
        client.setClientId("JUNIT_CLIENT_ID");

        SubjectUtils.setClient(user, client);
        SubjectUtils.setRPNSubsystems(user, this.subsystemRpns);

        user.getPrincipals().add(new InformIdPrincipal());
        InformIdentification informId = new InformIdentification();
        informId.setCompany("JUNIT_COMPANY");
        informId.setDivision("JUNIT_DIVISION");
        informId.setDepartment("JUNIT_DEPARTMENT");
        SubjectUtils.setInformId(user, informId);

        return user;
    }

    public void setSubsystemRpn(String name, String rpn) {
        Subsystem system = this.subsystemRpns.get(name);
        if (system == null) {
            system = new Subsystem();
            this.subsystemRpns.put(name, system);
        }
        system.setRpn(rpn);
    }

    /**
     * @return the rpn
     */
    public String getRpn() {
        return rpn;
    }

    /**
     * @param rpn the rpn to set
     */
    public void setRpn(String rpn) {
        this.rpn = rpn;
    }

    /**
     * @return the planCode
     */
    public String getPlanCode() {
        return planCode;
    }

    /**
     * @param planCode the planCode to set
     */
    public void setPlanCode(String planCode) {
        this.planCode = planCode;
    }

    /**
     * @return the subsystemRpns
     */
    public Map<String, Subsystem> getSubsystemRpns() {
        return subsystemRpns;
    }

    /**
     * @param subsystemRpns the subsystemRpns to set
     */
    public void setSubsystemRpns(Map<String, Subsystem> subsystemRpns) {
        this.subsystemRpns = subsystemRpns;
    }

    /**
     * @return the informQualifier
     */
    public String getInformQualifier() {
        return informQualifier;
    }

    /**
     * @param informQualifier the informQualifier to set
     */
    public void setInformQualifier(String informQualifier) {
        this.informQualifier = informQualifier;
    }

    /**
     * @return the region
     */
    public String getRegion() {
        return region;
    }

    /**
     * @param region the region to set
     */
    public void setRegion(String region) {
        this.region = region;
    }
}
