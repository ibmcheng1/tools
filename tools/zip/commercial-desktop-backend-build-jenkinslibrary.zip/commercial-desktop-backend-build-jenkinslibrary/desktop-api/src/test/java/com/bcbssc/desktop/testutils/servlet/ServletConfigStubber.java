/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.testutils.servlet;

import com.bcbssc.desktop.testutils.EnumerationStubber;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * A mock class that represents a {@link ServletConfig}. This allows for executing
 * servlets in JUnit tests that use the {@link ServletConfig}.
 */
public class ServletConfigStubber implements ServletConfig {

    Map<String, String> initParams = new HashMap<String, String>();

    private ServletContextStubber context = null;

    @Override
    public String getInitParameter(String name) {
        return initParams.get(name);
    }

    public void setInitParameter(String name, String value) {
        initParams.put(name, value);
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Enumeration getInitParameterNames() {
        Set<String> keys = initParams.keySet();
        return new EnumerationStubber<String>(keys.iterator());
    }

    @Override
    public ServletContext getServletContext() {
        if (null == this.context) {
            this.context = new ServletContextStubber();
        }
        return this.context;
    }

    @Override
    public String getServletName() {
        throw new UnsupportedOperationException("getServletName method hasn't been implemented yet");
    }

    /**
     * @return the context
     */
    public ServletContextStubber getServletContextStubber() {
        if (null == this.context) {
            this.context = new ServletContextStubber();
        }
        return this.context;
    }

    /**
     * @param context the context to set
     */
    public void setServletContextStubber(ServletContextStubber context) {
        this.context = context;
    }

}
