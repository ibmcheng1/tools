/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * StateNames.java
 * 
 * Created on Aug 14, 2009, 10:55:24 AM by JC33
 */
package com.bcbssc.desktop.states;

/**
 * Contains constants for the state names. These are the names that are sent out
 * to the portlet that registers for the stateViewHandler in the desktop object.
 *
 * <pre>
 * [Harvest]
 * </pre>
 * 
 * @author JC33 (original: JC33)
 * @version 
 */
public class StateNames {

    public static final String CALL_STATE_TEXT = "CALL";
    public static final String SELECT_WORK_STATE_TEXT = "Select Work State";
    public static final String SEARCH_STATE_TEXT = "Member Search";
    public static final String GROUP_SEARCH_STATE_TEXT = "Group Search";
    public static final String END_TASK_STATE_TEXT = "Ending Task";
    public static final String CONFIRM_STATE_TEXT = "Confirm Member";
    public static final String CONFIRM_GROUP_STATE_TEXT = "Confirm Group";
    public static final String RESEARCH_STATE_TEXT = "Research Mode";
    public static final String IN_CALL_STATE_TEXT = "Call Mode";
    public static final String READY_STATE_TEXT = "Desktop Ready";
    public static final String INCOMING_CALL_TEXT = "Incoming Call";
    
}
