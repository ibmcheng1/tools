/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.cache;

import java.io.Serializable;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.dao.cache.ICacheWrapper;
import com.ibm.websphere.cache.DistributedMap;
import com.ibm.websphere.cache.EntryInfo;
import com.ibm.wsspi.cache.DistributedObjectCacheFactory;

/**
 * This is a generic wrapper around DynaCache for standard operations.
 */
public class CacheWrapper implements ICacheWrapper  {

    /** logger */
    private static final Log logger = LogFactory.getLog(CacheWrapper.class);

    private static String MAP_NAME = "";
    private static boolean IS_DISK_CACHE_ENABLED;
    private static int SECONDS_IN_MINUTE = 60;
    private static int DEFAULT_TIME_TO_LIVE;
    private static int SESSION_INACTIVITY_SECONDS;
    private static int APPLICATION_INACTIVITY_SECONDS;
    private static int DEFAULT_PRIORITY;


    /**
     * Initializes static values on first static access of CacheWrapper class.
     */
    static {
        MAP_NAME = "desktop";
        IS_DISK_CACHE_ENABLED = false;
        DEFAULT_TIME_TO_LIVE = 0;

        //session cache timeout = 540 minutes (32,400 seconds) +  20 minutes (1,200 seconds)
        SESSION_INACTIVITY_SECONDS = (540 * SECONDS_IN_MINUTE) + (20 * SECONDS_IN_MINUTE);

        //application cache timeout = none
        APPLICATION_INACTIVITY_SECONDS = 0;

        DEFAULT_PRIORITY = 0;
    }

    /**
     * Returns the Cache Instance defined by the MAP_NAME constant.
     * @return DistributedMap
     */
    private static DistributedMap getCacheInstance() {
        return getCacheInstance(MAP_NAME);
    }

    /**
     * Returns the Cache Instance defined by the map_name param.
     * @param map_name
     * @return DistributedMap
     */
    private static DistributedMap getCacheInstance(String map_name) {
        return DistributedObjectCacheFactory.getMap(map_name);
    }

    /**
     * Returns a cache entry by the key param
     * Searches disk cache also if IS_DISK_CACHE_ENABLED constant is true.
     * @param key
     * @return Object
     */
    @Override
    public Serializable getEntry(String key) throws Exception {
        final DistributedMap map = getCacheInstance();
        Serializable entry = null;

        if (null != map) {
            if (map.containsKey(key, IS_DISK_CACHE_ENABLED)) {
                entry = (Serializable) map.get(key);
            }
        }

        if(entry != null) {
            if(logger.isDebugEnabled()) {
                logger.debug("CACHE ENTRY FETCHED FOR KEY [" + key + "] = [" + entry.getClass().getCanonicalName() + "]");
            }
        }
        else {
            if(logger.isDebugEnabled()) {
                logger.debug("CACHE ENTRY NOT FETCHED FOR KEY [" + key + "]");
            }
        }

        return entry;
    }

    /**
     * Returns the set of keys that can be used to retrieve data from cache
     *
     * @return
     */
    @SuppressWarnings("unchecked")
    @Override
    public Set<String> getKeys() throws Exception {
        return getCacheInstance().keySet();
    }

    /**
     * Checks to make sure the given key is available in the cache instance
     *
     * @param key
     * @return
     */
    @Override
    public boolean hasEntry(String key) throws Exception {
        return getCacheInstance().containsKey(key);
    }


    /**
     * Sets an 'application' entry in the Cache - an entry that should remain in cache permanently.
     * @param key String
     * @param entry Object
     * @return Object - the cached object.
     */
    @Override
    public Serializable setApplicationEntry(String key, Serializable entry) throws Exception {
        if(logger.isDebugEnabled()) {
            logger.debug("SETTING CACHE ENTRY - APPLICATION - KEY [" + key + "]");
        }
        final int inactivity_time = APPLICATION_INACTIVITY_SECONDS;
        return setEntry(key, entry, inactivity_time);
    }


    /**
     * Sets a 'session' entry in the Cache - an entry that should remain in cache only for the duration of an HTTP session
     * @param key String
     * @param entry Object
     * @return Object - the cached object.
     */
    @Override
    public Serializable setSessionEntry(String key, Serializable entry) throws Exception {
        if(logger.isDebugEnabled()) {
            logger.debug("SETTING CACHE ENTRY - SESSION - KEY [" + key + "]");
        }

        final int inactivity_time = SESSION_INACTIVITY_SECONDS;
        return setEntry(key, entry, inactivity_time);
    }

    /**
     * Sets and replicates a data item to all Dynacache instances in the cluster.
     * @param key String
     * @param entry
     * 		The value to store and replicate.
     * @return
     * 		The cached object (should be exact same as the given entry instance).
     */
    private static Serializable setEntry(String key, Serializable entry, int inactivity_time) {
        final int priority = DEFAULT_PRIORITY;
        final int ttl = DEFAULT_TIME_TO_LIVE;

        final DistributedMap map = getCacheInstance();
        Serializable result = null;
        if (null != map) {
            // NOTE: This is the only time data entries will be replicated to the other nodes.
            // NEVER USE EntryInfo.SHARED_PUSH_PULL it will cause horrible performance.
            result = (Serializable) map.put(key, entry, priority, ttl, inactivity_time, EntryInfo.SHARED_PUSH, null);
        } else {
            throw new IllegalStateException("Attempted to save an entry into cache, but the cache map could not be found!!");
        }
        return result;
    }

    /**
     * Removes an entry from cache if it exists.
     * @param key String
     */
    @Override
    public void removeEntry(String key) throws Exception {
        if(logger.isDebugEnabled()){
            logger.debug("REMOVING CACHE ENTRY: " + key);
        }
        final DistributedMap map = getCacheInstance();
        if (null != map){
            map.remove(key);
        } else{
            throw new IllegalStateException("Attempted to remove an entry from cache, but the cache map could not be found!!");
        }
    }

}
