/**

 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF

 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY

 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY

 * PROHIBITED.

 * COPYRIGHT 2008 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS

 * RESERVED.

 * 

 * DesktopPayload.java

 * Created on 5/18/2009 by Dale Ewald

 */
package com.bcbssc.desktop.payload;

import java.io.Serializable;
import javax.xml.namespace.QName;

/*
 * Class to define the Desktop payload
 */
public class DesktopPayload implements Serializable {
	private static final long serialVersionUID = 3096225223829979382L;
	public static final String DEFAULT_NAMESPACE = "http://bcbssc.com/desktop/";
	public static final String DEFAULT_EVENT_NAME = "GenericEvent";
	public static final String DEFAULT_QNAME_STRING = "{" + DEFAULT_NAMESPACE + "}" + DEFAULT_EVENT_NAME;
	
	private String payloadString;
	
	/**
	 * @return String the generic String that was sent as the payload.
	 */
	public String getPayloadString() {
		return payloadString;
	}
	
	/**
	 * @param payloadString String the generic String to use as the payload.
	 */
	public void setPayloadString(String payloadString) {
		this.payloadString = payloadString;
	}
	
	/**
	 * Returns a new javax.xml.namespace.QName object constructed of
	 * the DEFAULT_NAMESPACE and the DEFAULT_EVENT_NAME 
	 * @return QName
	 */
	public QName getQName() {
		return new QName(DEFAULT_NAMESPACE, DEFAULT_EVENT_NAME);
	}
}
