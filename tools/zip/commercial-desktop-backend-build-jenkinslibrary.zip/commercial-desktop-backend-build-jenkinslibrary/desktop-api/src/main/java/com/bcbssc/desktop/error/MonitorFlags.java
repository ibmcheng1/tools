/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * MonitorFlags.java
 * 
 * Created on Jun 5, 2012, 2:03:44 PM by XCE1
 */
package com.bcbssc.desktop.error;


/**
 * Enumeration of all desktop CEM monitor flags.
 *
 * <pre>
 * [Harvest]
 * </pre>
 * 
 * @author $Author$  (original: XCE1)
 * @version $Revision$
 */
public enum MonitorFlags {
    MONITOR_TICKET_S1,
    MONITOR_TICKET_S2,
    MONITOR_TICKET_S3,
    MONITOR_TICKET_NONE;
}
