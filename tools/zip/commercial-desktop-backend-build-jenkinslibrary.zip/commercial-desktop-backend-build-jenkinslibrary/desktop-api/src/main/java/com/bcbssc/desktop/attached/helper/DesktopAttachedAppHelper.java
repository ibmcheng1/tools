/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUE CROSS BLUE SHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.
 * ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2010 BLUE CROSS BLUE SHIELD OF SOUTH CAROLINA.
 * ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.attached.helper;

/**
 * A marker interface for an object that help build the request parameters to launch an attached application.
 *
 * @author X87M
 * @deprecated The functionality from this class should move to the frontend.
 */
public interface DesktopAttachedAppHelper {
    // No methods (yet) just a marker interface.
}
