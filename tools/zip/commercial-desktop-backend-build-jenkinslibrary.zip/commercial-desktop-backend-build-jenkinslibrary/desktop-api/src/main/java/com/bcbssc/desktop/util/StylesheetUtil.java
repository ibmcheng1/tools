/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * StylesheetUtil.java
 * 
 * Created on Jan 20, 2010, 11:59:44 AM by JC33
 */
package com.bcbssc.desktop.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * A class to assist in the construction of stylesheet include links and 
 * anything that may also be associated with it.
 *
 * <pre>
 * [Harvest]
 * </pre>
 * 
 * @author $Author$  (original: JC33)
 * @version $Revision$
 */
public class StylesheetUtil {

    /**
     * Returns a String that contains links to the style sheets both to the
     * generic desktop.css as well as application specific style sheets
     * @return
     * @throws IOException
     */
	public static String getStylesheetLinks() throws IOException {
        InputStream in = StylesheetUtil.class
                .getResourceAsStream("/com/bcbssc/desktop/resource/DesktopDialogs.properties");
        Properties props = new Properties();
        props.load(in);
        String styleSheets = props.getProperty("base.window.styleSheets");
        String[] desktopStyleSheets = styleSheets.split(",");
        StringBuffer buffer = new StringBuffer(200);
        buffer.append("<link rel=\"stylesheet\" type=\"text/css\" href=\"/BCBSPortalWeb2/themes/html/BCBSPortalWeb2/css/desktop.css\"/>");
        for (int i = 0; i < desktopStyleSheets.length; i++) {
            buffer.append("<link rel=\"stylesheet\" type=\"text/css\" href=\"/BCBSPortalWeb2/themes/html/BCBSPortalWeb2/css/desktop-"
                            + desktopStyleSheets[i] + ".css\"/>");
        }
        
        return buffer.toString();
    }

}
