/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * FormLauncherServlet.java
 * 
 * Created on March 22, 2010, 10:51:34 AM by HX61
 */
package com.bcbssc.desktop.launcher;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * This is a generic servlet to handle launching attached applications via a generated form.
 * The servlet takes the following inputs:
 * <pre>
 *    Name                    Input Type          Possible Values       Default Value
 *    --------------------------------------------------------------------------------
 *    methodType              request attribute   String "GET","POST"   "POST"
 *    includeDesktopAdapter   request attribute   Boolean TRUE, FALSE   TRUE
 *    desktopAdapterSource    request parameter   String url path       N/A
 *    portletWindowID         request parameter   String id             N/A
 *    targetUrl               request attribute   String url path       N/A
 *    formkeys                request attribute   Map&lt;String, String&gt;   N/A
 * </pre>
 * 
 * @author $Author$  (original: HX61)
 * @version $Revision$
 */
public class LauncherFormServlet extends HttpServlet {

    private static final long serialVersionUID = -6050846622698232740L;
    private static final Log log = LogFactory.getLog(LauncherFormServlet.class);

    /* @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse) */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        handleRequest(request, response);
    }

    /* @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse) */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
            IOException {
        handleRequest(request, response);
    }

    /**
     * This method serves as the delegate for GET and POST requests.  It is the workhorse for the servlet.
     * 
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException,
            IOException {

    	String methodType = (String)request.getAttribute("methodType");
    	if(StringUtils.isBlank(methodType)){
    		methodType = "POST";
    	}
    	Boolean includeDesktopAdapter = (Boolean)request.getAttribute("includeDesktopAdapter");
    	String desktopAdapterSource = request.getParameter("desktopAdapterSource");
    	String portletWindowID = request.getParameter("portletWindowID");
    	String desktopAdapterLink = null;
    	if(StringUtils.isNotBlank(desktopAdapterSource) && StringUtils.isNotBlank(portletWindowID)){
    		desktopAdapterLink = desktopAdapterSource + "?portletWindowID=" + portletWindowID;
    	} else{
    		includeDesktopAdapter = Boolean.FALSE;
    	}
    	if(includeDesktopAdapter == null){
    		includeDesktopAdapter = Boolean.TRUE;
    	}
    	String targetUrl = (String)request.getAttribute("targetUrl");
    	if(StringUtils.isBlank(targetUrl)){
    		throw new IllegalArgumentException("A target url must be provided.");
    	}
    	Map<String, String> formKeys = (Map<String, String>)request.getAttribute("formkeys");
    	
    	//If our targetUrl has any query string parameters specified on it, we'll need to parse those out
    	//and add them as form keys    	
    	String[] urlParts = StringUtils.split(targetUrl, '?');
    	if(urlParts.length > 1){
    		if(formKeys == null){
    			formKeys = new HashMap<String, String>();
    		}
    		targetUrl = urlParts[0];
    		String queryString = urlParts[1];
    		String[] queryStringParameters = StringUtils.split(queryString, '&');
    		for(String parameter: queryStringParameters){
    			String[] paramKeyValue = StringUtils.split(parameter, '=');
    			if(paramKeyValue.length > 1) {
                            formKeys.put(paramKeyValue[0], paramKeyValue[1]);    			    
    			}
    			else {
                            //in the event that a parameter doesn't have a value
                            formKeys.put(paramKeyValue[0], StringUtils.EMPTY);                                   			    
    			}
    		}
    	}
    	
    	Set<Map.Entry<String, String>> formKeySet = null;
    	if(formKeys != null){
    		formKeySet = formKeys.entrySet();
    	}
    	
    	//Generate the form and auto-submission based on the request parameters and attributes
    	//Creating the markup in code here would typically be a bad thing, but this allows us to share
    	//the functionality across multiple applications without having to copy stock JSPs into every web
    	//application (which then creates a maintenance nightmare).
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();            
        out.println("<html>");
        out.println("<head></head>");
        out.println("<body>");
        out.println("<form id='launcherForm' name='launcherForm' method='" + methodType + "' action='" + targetUrl + "'>");
        if(includeDesktopAdapter){
        	out.println("<input type='hidden' name='desktopAdapterLink' value='" + desktopAdapterLink + "' />");
        }
        if(formKeySet != null){
	        for(Map.Entry<String, String> entry : formKeySet){
	        	out.println("<input type='hidden' name='" + entry.getKey() + "' value='" + entry.getValue() + "' />");
	        }
        }
        out.println("</form>");
        out.println("<script type='text/javascript'>");
        out.println("function autoSubmit(){");
        out.println("   var launcherForm = document.getElementById('launcherForm'); ");
        out.println("   if(launcherForm){ launcherForm.submit(); } ");
        out.println("}");
        out.println("autoSubmit();");
        out.println("</script>");
        out.println("</body>");
        out.println("</html>");
        out.close();
    }

}
