package com.bcbssc.desktop.util;

import java.util.Iterator;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;

/**
* This phase listener checks if there is a client ID with message and will set the client ID as 
* ${focus} in the request map. It will also gather all client IDs with message and will set it as
* ${highlight} in the request map.
*/
public class SetFocusListener implements PhaseListener 
{
	private static final long serialVersionUID = 1L;

	/**
     * Returns the PhaseId renered response
     * @see javax.faces.event.PhaseListener#getPhaseId()
     */
    public PhaseId getPhaseId() 
    {

        // Listen on render response phase.
        return PhaseId.RENDER_RESPONSE;
    }

    /**
     * Sets the focus and highlight before the phase is rendered
     * 
     * @see javax.faces.event.PhaseListener#beforePhase(javax.faces.event.PhaseEvent)
     */
    public void beforePhase(PhaseEvent event) 
    {
        // Init.
        FacesContext facesContext = event.getFacesContext();
        String focus = null;
        StringBuffer highlight = new StringBuffer();

        // Iterate over all client ID's with messages.
        Iterator clientIdsWithMessages = facesContext.getClientIdsWithMessages();
        while (clientIdsWithMessages.hasNext()) 
        {
            String clientIdWithMessages = (String)clientIdsWithMessages.next();
            if (focus == null) 
            {
                focus = clientIdWithMessages;
            }
            highlight.append(clientIdWithMessages);
            if (clientIdsWithMessages.hasNext()) 
            {
                highlight.append(",");
            }
        }

        // Set ${focus} and ${highlight} in JSP.
        facesContext.getExternalContext().getRequestMap().put("focus", focus);
        facesContext.getExternalContext().getRequestMap().put("highlight", highlight.toString());
    }

    /**
     * This method does nothing
     * @see javax.faces.event.PhaseListener#afterPhase(javax.faces.event.PhaseEvent)
     */
    public void afterPhase(PhaseEvent event) 
    {
        // Do nothing.
    }

}

