/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2011 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * Perspective.java
 * 
 * Created on Jul 14, 2011, 2:05:56 PM by JC33
 */
package com.bcbssc.desktop.perspective;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

/**
 * An enumeration representing the different perspectives that are available 
 * on the base desktop application
 *
 * @author Jon Sturdevant
 */
public enum Perspective {

    SUBSCRIBER("subscriber"),
    GROUP("group"),
    APPLICANT("application"),
    CUSTOMER("customer");
    
    private static final Map<String, Perspective> NAME_TO_ENUM = new HashMap<String, Perspective>();
    static {
        for (Perspective perspective : values()) {
            NAME_TO_ENUM.put(perspective.name, perspective);
        }
    }
    
    private String name;
    
    private Perspective(String name) {
        this.name = name;
    }
    
    public String getName() {
        return this.name;
    }
    
    /**
     * Returns the enum that matches with the name or null if no match can be found.
     * 
     * @param name The name of the enum to get
     * @return The enum that matches with the name or null if no match can be found.
     */
    public static Perspective fromName(String name) {
        Perspective result = null;
        if (StringUtils.isNotBlank(name)) {
            result = NAME_TO_ENUM.get(name);
        }
        return result;
    }
    
}
