/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * DesktopAttachedClaimsHelper.java
 * Created on 5/18/2009 by Dale Ewald
 */
package com.bcbssc.desktop.attached.helper;

/**
 * Helper class to pre-load the data that is needed for Medical Management
 *
 * @deprecated The functionality from this class should move to the frontend.
 */
public class DesktopAttachedMedicalManagementHelper implements DesktopAttachedAppHelper {
}
