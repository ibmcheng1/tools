/**

 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF

 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY

 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY

 * PROHIBITED.

 * COPYRIGHT 2008 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS

 * RESERVED.

 * 

 * EmulatorPayload.java

 * Created on 6/8/2009 by Dale Ewald

 */
package com.bcbssc.desktop.payload;

import javax.xml.namespace.QName;
import java.io.Serializable;

/*
 * Class to define the Emulator Payload
 */
public class EmulatorPayload implements Serializable {
    private static final long serialVersionUID = -1517313904770938100L;

    public static final String EMULATOR_NAMESPACE = "http://bcbssc.com/emulator";
    public static final String EMULATOR_EVENT_NAME = "EmulatorEvent";
    public static final String EMULATOR_QNAME_STRING = "{" + EMULATOR_NAMESPACE + "}" + EMULATOR_EVENT_NAME;

    public static final String EMULATOR_SET_KEY_EVENT_NAME = "EmulatorSetKeyEvent";
    public static final String EMULATOR_SET_KEY_QNAME_STRING = "{" + EMULATOR_NAMESPACE + "}" + EMULATOR_SET_KEY_EVENT_NAME;
    
    public static final String EMULATOR_SYSTEM_COMMAND = "EmulatorSystemCommandEvent";
    // create string
    public static final String EMULATOR_SYSTEM_COMMAND_QNAME_STRING = "{" + EMULATOR_NAMESPACE + "}" + EMULATOR_SYSTEM_COMMAND;

    private String command;
    private String session;
    private String key;
    private String value;
    
    private String namespace;

    /**
     * @return String the value of the command property.
     */
    public String getCommand() {
        return command;
    }

    /**
     * @param command String the value to set in the command property.
     */
    public void setCommand(String command) {
        this.command = command;
    }

    /**
     * @return String the value of the session property.
     */
    public String getSession() {
        return session;
    }

    /**
     * @param session String the value to set in the session property.
     */
    public void setSession(String session) {
        this.session = session;
    }

    /**
     * Returns a new javax.xml.namespace.QName object constructed of
     * the EMULATOR_NAMESPACE and the EMULATOR_EVENT_NAME 
     * @return QName
     */
    public QName getQName() {
        return new QName(EMULATOR_NAMESPACE, EMULATOR_EVENT_NAME);
    }
    
    public QName getSetKeyQName() {
        return new QName(EMULATOR_NAMESPACE, EMULATOR_SET_KEY_EVENT_NAME);
    }
    
    // Issue 17352 and 19695
    public QName getSetSystemCommandQName() {
    	return new QName(EMULATOR_NAMESPACE, EMULATOR_SYSTEM_COMMAND);
    }
    
    
    /**
     * @return the key
     */
    public String getKey() {
        return key;
    }

    /**
     * @param key the key to set
     */
    public void setKey(String key) {
        this.key = key;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * @param value the value to set
     */
    public void setValue(String value) {
        this.value = value;
    }
    
    
    /**
     * @return the value
     */
    public String getNamespace() {
        return namespace;
    }

    /**
     * @param namespace the value to set
     */
    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }    
    
}
