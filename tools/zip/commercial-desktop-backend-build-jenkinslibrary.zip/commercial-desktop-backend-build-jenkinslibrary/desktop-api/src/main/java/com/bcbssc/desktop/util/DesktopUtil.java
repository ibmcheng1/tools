/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * DesktopUtil.java
 * 
 * Created on Aug 18, 2009, 9:18:44 AM by JC33
 */
package com.bcbssc.desktop.util;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * This class provides several utility methods that are used through out the
 * application
 *
 * <pre>
 * [Harvest]
 * </pre>
 * 
 * @author JC33 (original: JC33)
 * @version 
 */
public class DesktopUtil {
    /**
     * Class loader.
     * @param defaultObject
     * @return
     */
    protected static ClassLoader getCurrentClassLoader(Object defaultObject) {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();

        if (loader == null) {
            loader = defaultObject.getClass().getClassLoader();
        }
        return loader;
    }

    /**
     * Get message from resource bundle
     * @param bundleName
     * @param key
     * @param params
     * @param locale
     * @return
     */
    public static String getMessageResourceString(String bundleName, String key, Object params[], Locale locale) {
        String text = null;
        ResourceBundle bundle = ResourceBundle.getBundle(bundleName, locale, getCurrentClassLoader(params));
        try {
            text = bundle.getString(key);
        } catch (MissingResourceException e) {
            text = "?? key " + key + " not found ??";
        }
        if (params != null) {
            MessageFormat mf = new MessageFormat(text, locale);
            text = mf.format(params, new StringBuffer(), null).toString();
        }
        return text;
    }
}
