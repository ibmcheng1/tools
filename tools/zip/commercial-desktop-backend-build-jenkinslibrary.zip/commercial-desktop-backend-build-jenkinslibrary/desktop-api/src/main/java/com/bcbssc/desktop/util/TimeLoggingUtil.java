/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * TimeLoggingUtil.java
 * 
 * Created on Aug 16, 2012, 2:11:35 PM by XCE1
 */
package com.bcbssc.desktop.util;

import org.apache.commons.lang.time.StopWatch;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * This utility class will provide methods to log timings for functions which required to be monitored for slowness.

 * 
 * @author $Author$  (original: XCE1)
 * @version $Revision$
 */
public class TimeLoggingUtil {
    String TIMING_MESSAGE = " The function \"%s\" performed by \"%s\" took %s milliseconds to complete.%n";
    StopWatch stopWatch = null;
    StringBuffer message = null;

    private static final Log timeLogger = LogFactory.getLog("com.bcbssc.desktop.timings");

    /**
     * Default constructor.
     */
    public TimeLoggingUtil() {
        super();
        this.stopWatch = new StopWatch();
        this.message = new StringBuffer();
    }

    /**
     * Stops and resets the timer and adds the end time for the specified function to the message buffer.
     * 
     * @param functionName
     * @param systemName
     */
    public void readTimerforFunction(String functionName, String systemName) {
        //stops the timer
        this.stopWatch.stop();
        this.message.append(String.format(TIMING_MESSAGE, functionName, systemName, this.stopWatch.getTime()));
        //resets the timer for next use.
        this.stopWatch.reset();
    }

    /**
     * Starts the timer and Add the start message to the message buffer for the specified function.
     */
    public void startTimer(){
        //starts the timer.
        this.stopWatch.start();
    }

    /**
     *  Writes the current message buffer into debug logs.
     */
    public void logTime() {
        // Add timer messages to the debug logs.
        timeLogger.debug(this.message);
    }
}
