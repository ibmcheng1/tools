/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * SessionHistoryDataHandler.java
 * Created on Jul 29, 2009 4:02:45 PM by dewald
 */
package com.bcbssc.desktop.history;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.domain.entity.Group;
import com.bcbssc.domain.entity.SessionHistoryDataType;
import com.bcbssc.domain.entity.Subscriber;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

/**
 * A handler for Session History Data, to handle User Session Map data population.
 * 
 * To use:
 * From Emulator Coordinator Action - instantiate an object of this type and call storeTermData(request)
 * From other areas - instantiate an object of this type and call storeHistoryData(Map&lt;String, String&gt;, type, request)
 * 
 * @author dale.ewald
 *
 */
public class SessionHistoryDataHandler {
    private static Log log = LogFactory.getLog(SessionHistoryDataHandler.class);

    private static final String EXECUTE_COMMANDS_PARAM = "executeCommands";
    private static final String SESSION_DATA_SOURCE_PARAM = "sessionDataSource";
    private static final String DEFAULT_EMULATOR_SESSION = "SESSION1";
    private static final String SUBSCRIBER_KEY = "subscriberID";
    private static final String KEY_VALUE = "global.keyValue";

    /** The emulator session id. */
    private String sessionDataSource;
    private List<SessionHistoryDataType> sessionHistoryDataTypes;
    /** The WAS request session. */
    private String sessionId;
    private HashMap<String, Serializable> emulatorSessionMap;
    private HashMap<String, Serializable> emulatorDefaultSessionMap;
    private String historyListType;
    private ArrayList historyList;
    private Map targetListElement;
    private String targetElementPrimaryKey;

    private class SessionDataComparator implements Comparator<Map<String, String>> {

        private String primaryKey;

        public int compare(Map<String, String> data1, Map<String, String> data2) {
            if (null == primaryKey) {
                throw new RuntimeException("The primary key must be set in order to use the comparator");
            }
            String key1 = data1.get(primaryKey);
            String key2 = data2.get(primaryKey);
            int result = 0;
            if (null == key1 && null != key2) {
                result = 1;
            } else if (null != key1 && null == key2) {
                result = -1;
            } else if (null != key1 && null != key2) {
                result = key1.compareToIgnoreCase(key2);
            }
            return result;
        }

        /**
         * @param primaryKey the primaryKey to set
         */
        public void setPrimaryKey(String primaryKey) {
            this.primaryKey = primaryKey;
        }

        /**
         * @return the primaryKey
         */
        public String getPrimaryKey() {
            return primaryKey;
        }

    }

    /**
     * Pulls a list of maps from the session history data that corresponds to the type passed
     * in. If the type is not a session history data type or if there is no data available,
     * null will be returned.
     * 
     * @param type The session history data type to be used to retrieve the list of maps
     * @param sessionId
     * 		The session ID that should be used to access DynaCache.
     * 		The WAS request session id.
     * @return A list of maps that represent the data that has been passed for the given type
     * or null if there is no data available.
     */
    public List<Map<String, String>> getHistoryData(String type, String sessionId) throws Exception {
        List<Map<String, String>> historyList = new ArrayList<Map<String, String>>();

        Subscriber subscriber = (Subscriber) DesktopAPI.getSearchResult(sessionId, Subscriber.class);
        Group group = (Group) DesktopAPI.getSearchResult(sessionId, Group.class);
        
        if (subscriber != null || group != null) {
            loadHistoryData(sessionId);
            SessionHistoryDataType sessionHistoryDataType = getSessionHistoryDataType(type);

            // Load historyList from each emulator session
            getHistoryDataFromEmulatorSession(DesktopAPI.SESSION1, type, sessionId, historyList);
            getHistoryDataFromEmulatorSession(DesktopAPI.SESSION2, type, sessionId, historyList);
            getHistoryDataFromEmulatorSession(DesktopAPI.SESSION3, type, sessionId, historyList);

            if (null != historyList && historyList.size() > 0 && null != sessionHistoryDataType) {
                if (log.isDebugEnabled()) {
                    log.debug("Before looking for duplicates, the list size is " + historyList.size());
                }

                // look for duplicates
                SessionDataComparator comparator = new SessionDataComparator();
                comparator.setPrimaryKey(sessionHistoryDataType.getPrimaryKey());
                Collections.sort(historyList, comparator);

                // now that it is sorted, check to see if there are two of the same next to each other
                String previousKeyValue = StringUtils.EMPTY;
                Iterator<Map<String, String>> iter = historyList.listIterator();
                while (iter.hasNext()) {
                    Map<String, String> sessionData = iter.next();
                    String keyValue = sessionData.get(sessionHistoryDataType.getPrimaryKey());
                    String dataSubscriber = sessionData.get(SUBSCRIBER_KEY);

                    if (StringUtils.equalsIgnoreCase(keyValue, previousKeyValue)) {
                        // Remove duplicate items
                        iter.remove();
                    } else if (null == group && (StringUtils.isNotBlank(dataSubscriber) && !StringUtils.equalsIgnoreCase(dataSubscriber, subscriber.getId()))) {
                        // Remove any items from the list that don't belong to the currently loaded subscriber
                        iter.remove();
                    } else {
                        // We don't want to safe the previous ID on a removed item.
                        previousKeyValue = keyValue;
                    }
                }

                if (log.isDebugEnabled()) {
                    log.debug("After looking for duplicates, the list size is " + historyList.size());
                }
            }
        } else {
            if (log.isWarnEnabled()) {
                log.warn("No subscriber present in Dynacache for History Data fetch.");
            }
        }
        return historyList;

    }

    /**
     * Pulls history data from Emulator session
     * 
     * @param emulatorSessionName
     * @param type
     * @param sessionId
     * 		The WAS request session id.
     * @param historyList
     */
    @SuppressWarnings("unchecked")
    protected void getHistoryDataFromEmulatorSession(String emulatorSessionName, String type, String sessionId, List<Map<String, String>> historyList) throws Exception {
        sessionDataSource = emulatorSessionName;
        if (log.isDebugEnabled()) {
            log.debug("Setting the session to " + sessionDataSource);
        }
        loadHistoryData(sessionId);
        if (isSessionHistoryDataType(type)) {
            List<Map<String, String>> values = (List<Map<String, String>>) emulatorSessionMap.get(type);
            if (log.isDebugEnabled()) {
                log.debug("the list retrieve from " + sessionDataSource + " is " + values);
            }
            if (null != values) {
                historyList.addAll(values);
            }
        }
    }

    /**
     * Loads data into this object's properties
     * @param sessionId
     * 		The WAS request session id.
     */
    public void loadHistoryData(String sessionId) throws Exception {
        // Retrieve list of SessionHistoryDataTypes from DesktopAPI
        sessionHistoryDataTypes = DesktopAPI.getSessionHistoryDataTypeListBySessionId(sessionId);

        // if caller doesn't set sessionDataSource before calling this method, set to DEFAULT_EMULATOR_SESSION
        if (StringUtils.isEmpty(sessionDataSource)) {
            sessionDataSource = DEFAULT_EMULATOR_SESSION;
        }

        // retrieve the user's session data
        HashMap<String, Serializable> userSessionMap = DesktopAPI.getUserSessionMap(sessionId);

        // retrieve the emulator session map from user's session data, or create it
        if (userSessionMap.containsKey(sessionDataSource)) {
            emulatorSessionMap = (HashMap<String, Serializable>) userSessionMap.get(sessionDataSource);
        } else {
            emulatorSessionMap = new HashMap<String, Serializable>();
        }
    }

    /**
     * Returns information from the emulatorSessionMap property of this object.
     * Only works with global data (i.e. "keys" data).
     * For List types, use getHistoryListDataByKey instead.
     * @param keyName
     * @return
     */
    public String getKeyValue(String keyName) {
        if (emulatorSessionMap.containsKey(keyName)) {
            return (String) emulatorSessionMap.get(keyName);
        }
        return null;
    }

    /**
     * Populates this object's properties with data to be later saved with user's session keyed by emulator session.
     * Checks if "type" is a List-oriented type, updates or creates a target element in a list in the emulator session store.
     * If "type" is not List-oriented, updates or creates the data directly in the emulator session store.
     * @param type String the type of data to be updated. If it is not a List-oriented type, this param is essentially ignored.
     * @param field String the target field to be updated
     * @param value String the value to be updated in the target field
     */
    @SuppressWarnings("unchecked")
    public void queueHistoryData(String type, String field, String value) throws Exception {
    	
        // test if type is a Session History Data Type (list-oriented type such as claims)
        if (isSessionHistoryDataType(type)) {
            if (null == historyListType) {
                historyListType = type;
            }
            if (isPrimaryKey(historyListType, field)) {
                targetElementPrimaryKey = field;
            }

            if (log.isDebugEnabled()) {
                log.debug("Update " + historyListType + " List element");
            }

            if (historyList == null) {
                // get historyList from emulatorSessionMap; create empty if null                        
                if (emulatorDefaultSessionMap.containsKey(historyListType)) {
                    historyList = (ArrayList) emulatorDefaultSessionMap.get(historyListType);
                } else {
                    historyList = new ArrayList();
                }
            }
            if (targetListElement == null) {
                targetListElement = new HashMap();
            }
            targetListElement.put(field, value);

        } else {
            if (log.isDebugEnabled()) {
                log.debug("Update " + field + " direct type element");
            }
            
            // This is to load the provider data into the correct session history
            // for display purposes on Keys and End Task
            if(StringUtils.equalsIgnoreCase(type, KEY_VALUE)){
            	sessionDataSource = DEFAULT_EMULATOR_SESSION;
            	HashMap<String, Serializable> userSessionMap = DesktopAPI.getUserSessionMap(this.sessionId);
            	emulatorSessionMap = (HashMap<String, Serializable>) userSessionMap.get(sessionDataSource);
            }

            
            // Session History direct type (not an element in a list)                   
            emulatorSessionMap.put(field, value);
        }
    }
    
    /**
     * Using the private properties of this object, updates the user's session map.
     * Handles updates to existing history information in the user's session map, as well as adding new history information.
     * 
     * @param sessionId
     * 		The WAS request session, NOT the emulator session.
     */
    @SuppressWarnings("unchecked")
    public void saveHistoryData(String sessionId) throws Exception {
    	this.sessionId = sessionId;
    	if (historyList != null) {
            if (targetListElement != null) {
                // find Primary Key in targetListElement map
                String primaryKeyValue = (String) targetListElement.get(targetElementPrimaryKey);

                if (primaryKeyValue != null) {
                    // check for existence of targetListElement Map in historyList by primary key
                    // update historyList element if found, or add targetListElement to historyList if new
                    boolean found = false;
                    ListIterator listIter = historyList.listIterator();
                    while (listIter.hasNext() && !found) {
                        Map _targetElement = (Map) listIter.next();
                        if (_targetElement.get(targetElementPrimaryKey).equals(primaryKeyValue)) {
                            found = true;
                            for (Object _key : targetListElement.keySet()) {
                                _targetElement.put(_key, targetListElement.get(_key));
                            }
                            listIter.set(_targetElement);
                        }
                    }
                    if (!found) {
                        historyList.add(targetListElement);
                    }
                }
            }
            if (isSessionHistoryDataType(historyListType)) {
                emulatorDefaultSessionMap.put(historyListType, historyList);
            } else {
                emulatorSessionMap.put(historyListType, historyList);
            }
        }
    	HashMap<String, Serializable> userSessionMap = DesktopAPI.getUserSessionMap(sessionId);
        userSessionMap.put(DEFAULT_EMULATOR_SESSION, emulatorDefaultSessionMap);
        userSessionMap.put(sessionDataSource, emulatorSessionMap);
        DesktopAPI.replicateUserSessionMap(sessionId);
    }

    /**
     * Parses a command sent in from Static Emulator.
     * Command should be formatted such as healthClaims.claimNumber=value.
     * As of this writing, command is formatted as healthClaims['claimNumber']="value"
     * @param command String
     * @return String[]
     */
    private String[] parseCommand(String command) {
        String command_arr[] = command.split("=");
        String targetKey = command_arr[0]; // parsed as   healthClaims['claimNumber']                   
        String targetValue = StringUtils.remove(command_arr[1], "\""); // parsed as   value             
        String targetObject = targetKey.substring(0, targetKey.indexOf("["));
        String targetProperty = targetKey.substring(targetKey.indexOf("'") + 1, targetKey.lastIndexOf("'"));

        return new String[] { targetObject, targetProperty, targetValue };
    }

    /**
     * Determines if param typeName represents a SessionHistoryDataType (a List type).
     * @param typeName the name of the type that you want to search for in sessionHistoryDataTypes
     * @return boolean
     */
    private boolean isSessionHistoryDataType(String typeName) {
        return getSessionHistoryDataType(typeName) != null;
    }

    /**
     * Retrieves the SessionHistoryDataType by the param typeName.
     * @param typeName the name of the type that you want to search for in sessionHistoryDataTypes
     * @return SessionHistoryDataType
     */
    private SessionHistoryDataType getSessionHistoryDataType(String typeName) {
        SessionHistoryDataType sessionHistoryDataType = null;
        if (null != sessionHistoryDataTypes) {
            for (Iterator iter = sessionHistoryDataTypes.iterator(); iter.hasNext();) {
                SessionHistoryDataType _sessionHistoryDataType = (SessionHistoryDataType) iter.next();
                if (StringUtils.equals(typeName, _sessionHistoryDataType.getTypeName())) {
                    sessionHistoryDataType = _sessionHistoryDataType;
                    break;
                }
            }
        }
        return sessionHistoryDataType;
    }

    /**
     * Checks if the field param is the primary key of the type param's SessionHistoryDataType definition.
     * @param type
     * @param field
     * @return
     */
    private boolean isPrimaryKey(String type, String field) {
        SessionHistoryDataType sessionHistoryDataType = getSessionHistoryDataType(type);
        if (null != sessionHistoryDataType && StringUtils.equals(sessionHistoryDataType.getPrimaryKey(), field)) {
            return true;
        }
        return false;
    }

    /**
     * Returns a History List for the type provided, from the userSessionMap.
     * If the History List does not exist in the userSessionMap, an empty List is returned.
     * @param type
     * @param userSessionMap
     * @return
     */
    @SuppressWarnings("unchecked")
    private static List<Map<String, String>> getHistoryList(String type, Map userSessionMap) {
        List<Map<String, String>> historyList = (List<Map<String, String>>) userSessionMap.get(type);
        // if it wasn't there, create a new one
        if (null == historyList) {
            historyList = new ArrayList<Map<String, String>>();
        }
        return historyList;
    }
}
