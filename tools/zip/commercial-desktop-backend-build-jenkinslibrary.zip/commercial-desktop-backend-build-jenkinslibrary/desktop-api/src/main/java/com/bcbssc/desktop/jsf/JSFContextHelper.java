/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * JSFContextHelper.java
 */
package com.bcbssc.desktop.jsf;

import java.util.Iterator;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.component.NamingContainer;
import javax.faces.component.UIComponent;
import javax.faces.component.UIComponentBase;
import javax.faces.component.html.HtmlInputSecret;
import javax.faces.component.html.HtmlInputText;
import javax.faces.component.html.HtmlInputTextarea;
import javax.faces.component.html.HtmlSelectOneMenu;
import javax.faces.context.FacesContext;

import com.bcbssc.desktop.util.DesktopUtil;

/**
 * This is a utility class that provides various generic methods that 
 * can be used throughout the application
 *
 * <pre>
 * [Harvest]
 * </pre>
 * 
 * @author JC33 (original: X95F)
 * @version 
 */
public class JSFContextHelper {

    protected static final int APPLICATION_SCOPE = 0;
    protected static final int SESSION_SCOPE = 1;
    protected static final int REQUEST_SCOPE = 2;
    protected static final String JSF_APPLICATION_SCOPE = "applicationScope";;
    protected static final String JSF_SESSION_SCOPE = "sessionScope";
    protected static final String JSF_REQUEST_SCOPE = "requestScope";

    /**
     * Get message from bundle and return it 
     * @return
     */
    public static String getResourceMessage(String key) {
        FacesContext context = FacesContext.getCurrentInstance();
        String text = DesktopUtil.getMessageResourceString(context.getApplication().getMessageBundle(), key, null, context.getViewRoot().getLocale());
        return text;
    }

    /**
     * Get an attribute based on a key from the facesContext and return that object
     * @param key
     * @param scope
     * @return
     */
    public static Object getAttribute(String key, int scope) {
        Object attribute = null;
        FacesContext facesCtx = FacesContext.getCurrentInstance();

        if (facesCtx != null) {
            attribute = facesCtx.getApplication().createValueBinding(buildBindingString(scope, key)).getValue(facesCtx);
        }
        return attribute;
    }

    /**
     * Set the value of a FacesContext attribute
     * @param key
     * @param value
     * @param scope
     */
    public static void setAttribute(String key, Object value, int scope) {
        FacesContext facesCtx = FacesContext.getCurrentInstance();
        facesCtx.getApplication().createValueBinding(buildBindingString(scope, key)).setValue(facesCtx, value);
    }

    
    /**
     * Remove an attribute from the FacesContext
     * @param key
     * @param scope
     */
    @SuppressWarnings("unchecked")
    public static void removeAttribute(String key, int scope) {
        FacesContext facesCtx = FacesContext.getCurrentInstance();
        Map scopeMap = (Map) facesCtx.getApplication().createValueBinding(buildBindingString(scope)).getValue(facesCtx);
        scopeMap.remove(key);
    }

    
    /**
     * Get and return a session object from the FacesContext
     * @param mode
     * @return
     */
    public static Object getSession(boolean mode) {
        Object session = null;
        FacesContext facesCtx = FacesContext.getCurrentInstance();

        if (facesCtx != null) {
            session = facesCtx.getExternalContext().getSession(mode);
        }
        return session;
    }

    /**
     * Get and return the map of objects in the HTTP Scope
     * @param scope
     * @return
     */
    @SuppressWarnings("unchecked")
    public static Map getScopeMap(int scope) {
        FacesContext facesCtx = FacesContext.getCurrentInstance();
        Map scopeMap = (Map) facesCtx.getApplication().createValueBinding(buildBindingString(scope)).getValue(facesCtx);
        return scopeMap;
    }

    /**
     * Get and return the map of objects in the HTTPSession
     * @return
     */
    @SuppressWarnings("unchecked")
    public static Map getSessionMap() {
        return getScopeMap(SESSION_SCOPE);
    }

    /**
     * Get and return the map of objects in the HTTPSession
     * @return
     */
    @SuppressWarnings("unchecked")
    public static Map getRequestMap() {
        return getScopeMap(REQUEST_SCOPE);
    }

    /**
     * Get and return a Request Parameter Map from the FacesContext 
     * @return
     */
    @SuppressWarnings("unchecked")
    public static Map getRequestParamsMap() {
        return FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
    }

	/**
	 * Get an attribute based on a key from the facesContext in the REQUEST_SCOPE and return that object
	 * @param key
	 * @return
	 */
    public static Object getAttributeFromRequest(String key) {
        return getAttribute(key, REQUEST_SCOPE);
    }

    /**
     * Set the value of a FacesContext attribute in the REQUEST_SCOPE
     * @param key
     * @param value
     */
    public static void setAttributeInRequest(String key, Object value) {
        setAttribute(key, value, REQUEST_SCOPE);
    }

    /**
     * Remove an attribute from the FacesContext in the REQUEST_SCOPE
     * @param key
     */
    public static void removeAttributeFromRequest(String key) {
        removeAttribute(key, REQUEST_SCOPE);
    }

	/**
	 * Get an attribute based on a key from the facesContext in the SESSION_SCOPE and return that object
	 * @param key
	 * @return
	 */    
    public static Object getAttributeFromSession(String key) {
        return getAttribute(key, SESSION_SCOPE);
    }

    /**
     * Set the value of a FacesContext attribute in the SESSION_SCOPE
     * @param key
     * @param value
     */
    public static void setAttributeInSession(String key, Object value) {
        setAttribute(key, value, SESSION_SCOPE);
    }

    /**
     * Remove an attribute from the FacesContext in the SESSION_SCOPE
     * @param key
     */
    public static void removeAttributeFromSession(String key) {
        removeAttribute(key, SESSION_SCOPE);
    }

	/**
	 * Get an attribute based on a key from the facesContext in the APPLICATION_SCOPE and return that object
	 * @param key
	 * @return
	 */      
    public static Object getAttributeFromApplication(String key) {
        return getAttribute(key, APPLICATION_SCOPE);
    }

    /**
     * Set the value of a FacesContext attribute in the APPLICATION_SCOPE
     * @param key
     * @param value
     */
    public static void setAttributeInApplication(String key, Object value) {
        setAttribute(key, value, APPLICATION_SCOPE);
    }

    /**
     * Remove an attribute from the FacesContext in the APPLICATION_SCOPE
     * @param key
     */
    public static void removeAttributeFromApplication(String key) {
        removeAttribute(key, APPLICATION_SCOPE);
    }

    /**
     * Create and return a String determined by the scope that is passed in
     * by calling the buildBindingString method
     * 
     * @param scope
     * @return
     */
    public static String buildBindingString(int scope) {
        return buildBindingString(scope, null);
    }

    /**
     * Return a String that is built and whose content is determined by scope param and the 
     * key param
     * 
     * @param scope
     * @param key
     * @return
     */
    public static String buildBindingString(int scope, String key) {
        StringBuffer bindingStr = new StringBuffer();
        bindingStr.append("#{");
        switch (scope) {
            case APPLICATION_SCOPE:
                bindingStr.append(JSF_APPLICATION_SCOPE);
                break;
            case SESSION_SCOPE:
                bindingStr.append(JSF_SESSION_SCOPE);
                break;
            case REQUEST_SCOPE:
                bindingStr.append(JSF_REQUEST_SCOPE);
                break;
            default:
                break;
        }
        if (key != null) {
            bindingStr.append(".");
            bindingStr.append(key);
        }
        bindingStr.append("}");
        return bindingStr.toString();
    }

    /**
     * Add an error message to the faces context for display on the page.
     * 
     * Use this method when no error style needs to be applied to the UIComponent
     * and no detailed error message needs to be displayed
     * 
     * @param errorMsg
     */
    public static void addErrorMessage(String errorMsg) {
        addErrorMessage(errorMsg, errorMsg);
    }


    /**
     * Add an error message to the faces context for display on the page.
     * 
     * Use this method when no error style needs to be applied to the UIComponent
     * and a detailed error message needs to be displayed
     */
    public static void addErrorMessage(String errorMsg, String detailMessage) {
        FacesContext facesCtx = FacesContext.getCurrentInstance();
        facesCtx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, errorMsg, detailMessage));
    }

	/**
 	 * add an error message to the faces context for display on the page.
     * 
     * Use this method when no error style needs to be applied to the UIComponent
     * and a detailed error message needs to be displayed
     */
    public static void addErrorMessageForComponent(String clientId, String messageId) {
        FacesContext ctx = FacesContext.getCurrentInstance();
        String message = getResourceMessage(messageId);
        ctx.addMessage(clientId, new FacesMessage(FacesMessage.SEVERITY_ERROR, message, message));
    }

    
    /**
     * Method to add an error message to the faces context for display on the page.
     * 
     * Use this method when no error style needs to be applied to the UIComponent
     * and a detailed error message needs to be displayed
     */
    public static void addErrorMessageForComponent(String clientId, String messageId, String additionalMsg) {
        FacesContext ctx = FacesContext.getCurrentInstance();
        String message = getResourceMessage(messageId);
        message = message + " " + additionalMsg;
        ctx.addMessage(clientId, new FacesMessage(FacesMessage.SEVERITY_ERROR, message, message));
    }

    /**  
     * Method to add an error message to the faces context for display on the page.
     * 
     * Use this method when an error style needs to be applied to the UIComponent
     * and a detailed error message needs to be displayed
    */
    public static void addErrorMessage(UIComponent uiComponent, String errorMsg, String detailMessage) {
        if (uiComponent instanceof HtmlSelectOneMenu) {
            setStyle(uiComponent, "selectOneMenu_Error");
        } else {
            setStyle(uiComponent, "inputText_Error");
        }
        FacesContext facesCtx = FacesContext.getCurrentInstance();
        facesCtx.addMessage(uiComponent.getClientId(facesCtx), new FacesMessage(FacesMessage.SEVERITY_ERROR, errorMsg, detailMessage));
    }

    /**  
     * Method to add an error message to the faces context for display on the page.
     * 
     * Use this method when an error style needs to be applied to the UIComponent
     * and no detailed error message needs to be displayed
    */
    public static void addErrorMessage(UIComponent uiComponent, String errorMsg) {
        addErrorMessage(uiComponent, errorMsg, "");
    }

    /**
     * Method is used to check if there are error messages in the Faces Context.
     */
    public static boolean hasErrorMessages() {
        FacesContext facesCtx = FacesContext.getCurrentInstance();
        return facesCtx.getMessages().hasNext();
    }

    /**
     * <p>
     * Return the {@link UIComponent}(if any) with the specified
     * <code>id</code>, searching recursively starting at the specified
     * <code>base</code>, and examining the base component itself, followed
     * by examining all the base component's facets and children. Unlike
     * findComponent method of {@link UIComponentBase}, which skips recursive
     * scan each time it finds a {@link NamingContainer}, this method examines
     * all components, regardless of their namespace (assuming IDs are unique).
     * 
     * @param base
     *            Base {@link UIComponent}from which to search
     * @param id
     *            Component identifier to be matched
     */
    @SuppressWarnings("unchecked")
    public static UIComponent findComponent(UIComponent base, String id) {

        // Is the "base" component itself the match we are looking for?
        if (id.equals(base.getId())) {
            return base;
        }

        // Search through our facets and children
        UIComponent kid = null;
        UIComponent result = null;
        Iterator kids = base.getFacetsAndChildren();
        while (kids.hasNext() && (result == null)) {
            kid = (UIComponent) kids.next();
            if (id.equals(kid.getId())) {
                result = kid;
                break;
            }
            result = findComponent(kid, id);
            if (result != null) {
                break;
            }
        }
        return result;
    }

    /**
     * Return the UIComponent from the context root for a specific Id
     * @param id
     * @return
     */
    public static UIComponent findComponentInRoot(String id) {
        UIComponent ret = null;

        FacesContext context = FacesContext.getCurrentInstance();
        if (context != null) {
            UIComponent root = context.getViewRoot();
            ret = findComponent(root, id);
        }

        return ret;
    }

    /**
     * Set the style on the component passed in.
     */
    public static void setStyle(UIComponent uiComponent, String style) {
        if (uiComponent != null) {
            if (uiComponent instanceof HtmlInputSecret) {
                ((HtmlInputSecret) uiComponent).setStyleClass(style);
            } else if (uiComponent instanceof HtmlInputText) {
                ((HtmlInputText) uiComponent).setStyleClass(style);
            } else if (uiComponent instanceof HtmlInputTextarea) {
                ((HtmlInputTextarea) uiComponent).setStyleClass(style);
            } else if (uiComponent instanceof HtmlSelectOneMenu) {
                ((HtmlSelectOneMenu) uiComponent).setStyleClass(style);
            }
        }
    }

}
