/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * DataValidator.java
 */
package com.bcbssc.desktop.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import com.bcbssc.desktop.jsf.JSFContextHelper;

/**
 * Data validator
 * Checks for special characters
 * @author x95f
 *
 */
public class DataValidator implements Validator {
    private static final Pattern DATA_PATTERN = Pattern.compile("[^<>{}\\[\\];\\&%]+");

    /**
     * Validate data input
     */
    public void validate(FacesContext arg0, UIComponent arg1, Object value) throws ValidatorException {
        String valEntered = (String) value;

        /* Check to see if the value is free of special characters */
        Matcher matcher = DATA_PATTERN.matcher(valEntered);

        if (!matcher.matches()) {
            String text = JSFContextHelper.getResourceMessage("value.invalid");
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, text, text);

            arg0.addMessage(arg1.getClientId(arg0), message);
        }
    }

    /**
     * For check within the backing beans
     */
    public static boolean validate(String text) {
        Matcher matcher = DATA_PATTERN.matcher(text);
        if (!matcher.matches()) {
            return false;
        }

        return true;
    }

}
