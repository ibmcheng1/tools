/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * StateManagerPayload.java
 * 
 * Created on Jun 10, 2009, 3:57:55 PM by JC69
 */
package com.bcbssc.desktop.payload;

import javax.xml.namespace.QName;

/**
 * This class is a state manager payload to be used for sending
 * data (a payload) to the state manager portlet via wires (events).
 *
 * <pre>
 * [Harvest]
 * </pre>
 * 
 * @author $Author$  (original: JC69)
 * @version $Revision$
 */
public class StateManagerPayload extends DesktopPayload {

    private static final long serialVersionUID = -679704958389490233L;

    public static final String NAMESPACE = "http://bcbssc.com/state";

    /**
     * @deprecated Replaced by {@link #CHANGE_STATE_EVENT_NAME}.
     */
    public static final String EVENT_NAME = "ChangeStateEvent";

    /**
     * The event that signals a state change.
     */
    public static final String CHANGE_STATE_EVENT_NAME = "ChangeStateEvent";

    /**
     * Generic change data event, will use the model objects attached to the payload as the "changed data".
     */
    public static final String CHANGE_DATA_EVENT_NAME = "changedata";
    public static final String CHANGE_DATA_EVENT_NAME_SUBSCRIBER = "changedata-subscriber";
    public static final String CHANGE_DATA_EVENT_NAME_GROUP = "changedata-group";
    public static final String CHANGE_DATA_EVENT_NAME_PATIENT = "changedata-patient";
    public static final String CHANGE_DATA_EVENT_NAME_CUSTOMER = "changedata-customer";
    public static final String CHANGE_DATA_EVENT_NAME_APPLICANT  = "changedata-applicant";
    public static final String CHANGE_DATA_EVENT_NAME_APPLICATION  = "changedata-application";

    public static final String CURRENT_STATE_EVENT_NAME = "currentstate";

    /**
     * The <code>qname</code> parameter in the <code>&amp;ProcessEvent</code> annotation
     * for portlets handling a state change event.
     */
    public static final String CHANGE_STATE_QNAME_STRING = "{" + NAMESPACE + "}" + CHANGE_STATE_EVENT_NAME;
    public static final String CHANGE_DATA_QNAME_STRING = "{" + NAMESPACE + "}" + CHANGE_DATA_EVENT_NAME;
    public static final String CHANGE_DATA_QNAME_STRING_SUBSCRIBER = "{" + NAMESPACE + "}" + CHANGE_DATA_EVENT_NAME_SUBSCRIBER;
    public static final String CHANGE_DATA_QNAME_STRING_GROUP = "{" + NAMESPACE + "}" + CHANGE_DATA_EVENT_NAME_GROUP;
    public static final String CHANGE_DATA_QNAME_STRING_PATIENT = "{" + NAMESPACE + "}" + CHANGE_DATA_EVENT_NAME_PATIENT;
    public static final String CHANGE_DATA_QNAME_STRING_CUSTOMER = "{" + NAMESPACE + "}" + CHANGE_DATA_EVENT_NAME_CUSTOMER;
    public static final String CHANGE_DATA_QNAME_STRING_APPLICANT = "{" + NAMESPACE + "}" + CHANGE_DATA_EVENT_NAME_APPLICANT;
    public static final String CURRENT_STATE_QNAME_STRING = "{" + NAMESPACE + "}" + CURRENT_STATE_EVENT_NAME;

    // Constants used to define the various actions that this payload can send
    // @see #stateAction
    public static final String MAKE_READY = "makeReady"; //Desktop Idle or Ready state
    public static final String RESEARCH = "research"; //Desktop Research state
    public static final String IN_CALL = "inCall"; //Desktop Call Mode state
    public static final String END_TASK = "endTask"; //Desktop Ending Task state
    public static final String SELECT_WORK = "selectWork"; //Desktop Select Work state
    public static final String SEARCH = "search"; //Desktop Search (research) state
    public static final String LOAD_DATA = "loadData"; //Desktop Loading Data state
    public static final String CONFIRM = "confirm"; //Desktop Confirm Search Result state
    public static final String CALL_POP = "callPop"; //Desktop Incoming Call (call pop) state
    public static final String START_NEW_CALL = "startNewCall"; //Desktop New Call Search state

    /**
     * A state action is the payload to be sent to the state manager portlet.
     * This action will hold the action the state manager must perform.
     * <br>
     * The portlet itself will ask the state manager to execute the action 
     * (in other words, go into a different state).
     */
    private String stateAction;

    /**
     * If <code>Boolean.TRUE</code> then will delete all the session saved data.
     */
    private Boolean dataReset = Boolean.FALSE;
    
    private Boolean resetSubscriber = Boolean.FALSE;
    private Boolean resetGroup = Boolean.FALSE;
    private Boolean resetProvider = Boolean.FALSE;
    private Boolean resetPatient = Boolean.FALSE;
    private Boolean resetApplicant = Boolean.FALSE;

    /**
     * @return the change data qname
     */
    public static QName getChangeDataQName() {
        return new QName(NAMESPACE, CHANGE_DATA_EVENT_NAME);
    }

    /**
     * @return the change subscriber data qname
     */
    public static QName getChangeSubscriberDataQName() {
        return new QName(NAMESPACE, CHANGE_DATA_EVENT_NAME_SUBSCRIBER);
    }

    /**
     * @return the change group data qname
     */
    public static QName getChangeGroupDataQName() {
        return new QName(NAMESPACE, CHANGE_DATA_EVENT_NAME_GROUP);
    }

    /**
     * @return the change patient data qname
     */
    public static QName getChangePatientDataQName() {
        return new QName(NAMESPACE, CHANGE_DATA_EVENT_NAME_PATIENT);
    }

    /**
     * @return the change customer data qname
     */
    public static QName getChangeCustomerDataQName() {
        return new QName(NAMESPACE, CHANGE_DATA_EVENT_NAME_CUSTOMER);
    }

    /**
     * @return the change applicant data qname
     */
    public static QName getChangeApplicantDataQName() {
    	return new QName(NAMESPACE, CHANGE_DATA_EVENT_NAME_APPLICANT);
    }

    /**
     * @return the change application data qname 
     */
    public static QName getChangeApplicationDataQName() {
    	return new QName(NAMESPACE, CHANGE_DATA_EVENT_NAME_APPLICATION);
    }

    /**
     * @return the current state qname
     */
    public static QName getCurrentStateQName() {
        return new QName(NAMESPACE, CURRENT_STATE_EVENT_NAME);
    }

    /**
     * @return the change state qname
     */
    public static QName getChangeStateQName() {
        return new QName(NAMESPACE, CHANGE_STATE_EVENT_NAME);
    }

    /**
     * @return an action the state manager will execute in order to
     * go into a different state
     */
    public String getStateAction() {
        return stateAction;
    }

    /**
     * @param stateAction
     */
    public void setStateAction(String stateAction) {
        this.stateAction = stateAction;
    }

    /**
     * @return the dataReset
     */
    public Boolean isDataReset() {
        return dataReset;
    }

    /**
     * @param dataReset the dataReset to set
     */
    public void setDataReset(Boolean dataReset) {
        this.dataReset = dataReset;
    }

    /**
     * @param resetSubscriber the resetSubscriber to set
     */
    public void setResetSubscriber(Boolean resetSubscriber) {
        this.resetSubscriber = resetSubscriber;
    }

    /**
     * @return the resetSubscriber
     */
    public Boolean isResetSubscriber() {
        return resetSubscriber;
    }

    /**
     * @param resetGroup the resetGroup to set
     */
    public void setResetGroup(Boolean resetGroup) {
        this.resetGroup = resetGroup;
    }

    /**
     * @return the resetGroup
     */
    public Boolean isResetGroup() {
        return resetGroup;
    }

    /**
     * @param resetProvider the resetProvider to set
     */
    public void setResetProvider(Boolean resetProvider) {
        this.resetProvider = resetProvider;
    }

    /**
     * @return the resetProvider
     */
    public Boolean isResetProvider() {
        return resetProvider;
    }

    /**
     * @param resetPatient the resetPatient to set
     */
    public void setResetPatient(Boolean resetPatient) {
        this.resetPatient = resetPatient;
    }

    /**
     * @return the resetPatient
     */
    public Boolean isResetPatient() {
        return resetPatient;
    }

    /**
     * @param resetApplicant indicator to reset applicant data
     */
    public void setResetApplicant(Boolean resetApplicant) {
        this.resetApplicant = resetApplicant;
    }

    /**
     * @return indicator to reset applicant data
     */
    public Boolean getResetApplicant() {
        return resetApplicant;
    }

}
