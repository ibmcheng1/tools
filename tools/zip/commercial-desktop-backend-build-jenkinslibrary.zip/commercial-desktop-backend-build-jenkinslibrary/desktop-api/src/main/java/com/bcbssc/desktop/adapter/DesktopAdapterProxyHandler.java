/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2008 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * DesktopAdapterProxyHandler.java
 * Created on Jul 13, 2009 1:09:49 PM by dewald
 */
package com.bcbssc.desktop.adapter;

/**
 * Class typically used by the Control Panel Portlet upon receiving requests made by Attached 
 * Applications (via DesktopAdapterProxy JavaScript objects).<br>
 * Contains methods dealing with running emulator transactions, storing rollup data in 
 * Session History, etc...
 * 
 * @author Dale Ewald
 * @deprecated The functionality of this class should be moved to the frontend.
 */
public class DesktopAdapterProxyHandler {

}
