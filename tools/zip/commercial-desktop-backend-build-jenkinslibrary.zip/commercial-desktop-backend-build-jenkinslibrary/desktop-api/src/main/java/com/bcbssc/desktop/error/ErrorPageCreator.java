/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2013 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * ErrorPageCreator.java
 * 
 * Created on Jun 5, 2012, 1:30:51 PM by XCE1
 */
package com.bcbssc.desktop.error;

import com.bcbssc.desktop.util.DesktopUtil;
import com.bcbssc.desktop.util.exception.DataAccessException;
import com.bcbssc.desktop.util.exception.DataAccessRetrievalFailureException;
import com.bcbssc.desktop.util.exception.security.DataAccessAuthorizationException;
import com.bcbssc.desktop.util.exception.security.DataAccessUnauthorizedException;
import com.bcbssc.domain.exceptions.WorkManagerProcessFailedException;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

/**
 * This class will provide the logic for creating error body and stack trace in desktop application error page.
 */
public class ErrorPageCreator {
    private static final String GENERIC_ERROR_MESSAGE_KEY = "generic.error.message";
    private static final String EXCEPTION_ERROR_MESSAGE_KEY_SUFFIX = ".error.message.key";
    private static final String DEFAULT_ERROR_MONITOR_FLAG_KEY = "default.monitor.flag";
    private static final String EXCEPTION_ERROR_MONITOR_FLAG_SUFFIX = ".monitor.flag";
    private static final Log log = LogFactory.getLog(ErrorPageCreator.class);

    /**
     * Creates the error page body for cases where the error data was passed in via request attributes or where we can reference the objects directly.
     * 
     * @param exception
     *      Required.
     * @param exceptionType
     *      Required.
     * @param statusCode
     *      Optional, may be null.
     * @param message
     *      Required.
     * @param requestUri
     *      Required.
     * @return
     *      The HTML text for the error page body.
     * @throws IOException
     *      If there was an exception getting the GlobalMessages resource.
     */
    public static String getErrorBody(Throwable exception, Class exceptionType, Integer statusCode, String message, String requestUri) throws IOException {
        String errorBody;
        String exceptionClassName = exception.getClass().getName();
        String exceptionToString = exception.toString();
        String exceptionTypeClassName = exceptionType.getName();

        if(exception instanceof WorkManagerProcessFailedException){
            errorBody = getMultipleErrorBody((WorkManagerProcessFailedException) exception, statusCode, message, requestUri);
        } else{
            errorBody = getErrorBody(exceptionClassName, exceptionToString, exceptionTypeClassName, statusCode, message, requestUri);
          }
        return errorBody;
    }

    /**
     * 
     * Find out what kind of exceptions compose the WorkManagerProcessFailedException and process them by priority.
     * High Priority exceptions: 30000 level service message codes from web service.
     * Mid Priority exceptions: 20000 level service message codes from web service.
     * Low Priority exceptions: 10000 level service message codes from web service or anything else.
     * 
     * See ServicesDataAccessExceptionInterceptor for more on how these exceptions are thrown
     * 
     * @param exception The process exception.
     * @param statusCode The status code from the call.
     * @param message The message.
     * @param requestUri The request uri.
     * @return A string.
     * @throws IOException If there is an IO error.
     */
    protected static String getMultipleErrorBody(WorkManagerProcessFailedException exception, Integer statusCode, String message, String requestUri) throws IOException {

        ArrayList<Throwable> lowPriorityExceptionList = new ArrayList<>(); //10000 level service message code or any other exceptions
        ArrayList<Throwable> midPriorityExceptionList = new ArrayList<>(); //20000 level service message code
        ArrayList<Throwable> highPriorityExceptionList = new ArrayList<>(); //30000 level service message code
        ArrayList<Throwable> deDupedExceptions = new ArrayList<>();
        ArrayList<Throwable> exceptionList = (ArrayList<Throwable>) exception.getExceptions();

        //split up exceptions by priority
        for(Throwable currentException : exceptionList) {
            if (DataAccessRetrievalFailureException.class.isAssignableFrom(currentException.getClass())) {
                highPriorityExceptionList.add(currentException);
            } else if (DataAccessAuthorizationException.class.isAssignableFrom(currentException.getClass()) || 
                        DataAccessUnauthorizedException.class.isAssignableFrom(currentException.getClass()) || 
                        WorkManagerProcessFailedException.class.isAssignableFrom(currentException.getClass())) {
                midPriorityExceptionList.add(currentException);
            } else{
                lowPriorityExceptionList.add(currentException);
            }
        }
                
        /*
         * we are only going to process one priority level of exception.
         * if we have high priority, only process those, etc.
         * for whatever priority level of exception we are going to process, remove duplicate 
         * exceptions from the list.  
         */
        if(!highPriorityExceptionList.isEmpty()){
            deDupedExceptions = (ArrayList<Throwable>) deDupeExceptionList(highPriorityExceptionList);
        } else if(!midPriorityExceptionList.isEmpty()){
            deDupedExceptions = (ArrayList<Throwable>) deDupeExceptionList(midPriorityExceptionList);
        } else if(!lowPriorityExceptionList.isEmpty()){
            deDupedExceptions = (ArrayList<Throwable>) deDupeExceptionList(lowPriorityExceptionList);
        }
        
        return createMultipleErrorBody(deDupedExceptions, statusCode, message, requestUri);
    }
    
    /**
     * Dedupe a list of exceptions
     * @param exceptionList The list to dedupe.
     * @return A deduped list of Throwable objects.
     */
    protected static List<Throwable> deDupeExceptionList(List<Throwable> exceptionList){
        Set<String> exceptionClasses = new HashSet<String>();
        List<Throwable> deDupedExceptions = new ArrayList<Throwable>();
        String currentExceptionClassName = null;

        for(Throwable exception: exceptionList) {
            currentExceptionClassName = exception.getClass().getName();
            if(!exceptionClasses.contains(currentExceptionClassName)){
                exceptionClasses.add(currentExceptionClassName);
                deDupedExceptions.add(exception);
            }
        }
        return deDupedExceptions;        
    }
    
    /**
     * Creates the error page body for a list of exceptions.
     * Search through the properties file to see if any of the exceptions we are processing have
     * custom verbiage defined.  If not, we treat these as generic exceptions.   
     * Display the first occurrence of a custom exception on the page, if one exists.
     * All subsequent exceptions will be hidden on the page. 
     * If no custom exception is found, display the info about the first generic message found.
     * 
     * @param exceptions The exceptions to create the body.
     * @param statusCode The status code.
     * @param message The message.
     * @param requestUri The request URI.
     * @return A string.
     * @throws IOException If the is an i/o error.
     */
    protected static String createMultipleErrorBody(ArrayList<Throwable> exceptions, Integer statusCode, String message, String requestUri) throws IOException {
        InputStream propertiesFileInputStream = DesktopUtil.class.getResourceAsStream("/com/bcbssc/desktop/resource/GlobalMessages.properties");
        Properties props = new Properties();
        props.load(propertiesFileInputStream);
            
        String exceptionKey;
        String messageKey;
        String customMessage = null;
        String genericMessage;
        String displayMessage;
        String exceptionClassName;
        String exceptionToString;
        String reason;
        //buffer of all secondary exceptions to be hidden on the page.
        StringBuffer otherExceptionsOutput =  new StringBuffer(5000);
        Throwable firstCustomException = null;
        Throwable firstGenericException = null;
        boolean foundCustomException = false;
        boolean foundGenericException = false;
        
        //get generic error message to display if we don't find any custom exception verbiage
        genericMessage = props.getProperty(GENERIC_ERROR_MESSAGE_KEY);
       
        //loop through our list of exceptions and process them based on what we find in the properties file.
        for (Throwable currentException: exceptions) {
            exceptionClassName = currentException.getClass().getName();
            exceptionToString = currentException.toString();
            exceptionKey = exceptionClassName + EXCEPTION_ERROR_MESSAGE_KEY_SUFFIX;
            messageKey = props.getProperty(exceptionKey, null);
            if(messageKey == null){     //we have a generic exception
                if(!foundGenericException){//save off our first generic exception found to potentially display
                    foundGenericException = true;
                    firstGenericException = currentException;
                } else{//we found another generic exception, add it to the list
                    otherExceptionsOutput.append("<li>" + exceptionToString + "</li>");
                  }
            } else{     //we found a custom exception
                if(!foundCustomException){//save off our first custom exception found to display
                    foundCustomException = true;
                    customMessage = props.getProperty(messageKey);
                    firstCustomException = currentException;
                } else{    //we found another custom exception, add it to the list
                    otherExceptionsOutput.append("<li>" + exceptionToString + "</li>");
                  }   
              }
        }       

        /*
         * determine what exception data to display on the page.
         * if we found a custom exception, display it, otherwise display the first generic exception we encountered. 
         */
       
        if(foundCustomException){
            displayMessage = customMessage;
            exceptionToString = firstCustomException.toString();
            exceptionClassName = firstCustomException.getClass().getName();
            /* in case we encountered a generic exception in the list prior to finding a custom
             * exception, add the generic exception to the secondary list.
             * 
             */
            if(foundGenericException){ 
                otherExceptionsOutput.append("<li>" + firstGenericException.toString() + "</li>");
            }
        }
        else{
            displayMessage = genericMessage;
            exceptionToString = firstGenericException.toString();
            exceptionClassName = firstGenericException.getClass().getName();
        }
        
        // get monitor flag defined for the exception class.
        MonitorFlags monitorFlagEnum = getMonitorFlagEnum(props,exceptionClassName);
        
        // The error reason is either the status code or the exception type
        reason = exceptionClassName;
        if (null != statusCode) {
            reason = statusCode.toString();
        }
        
        return createErrorBody(monitorFlagEnum, message, requestUri, displayMessage, exceptionToString, reason, otherExceptionsOutput, foundCustomException);
    }

    /**
     * create the error message body to be displayed on the page
     * 
     * @param message The message.
     * @param requestUri The request URI.
     * @param displayMessage The display message.
     * @param exceptionToString The exception to string.
     * @param reason The reason.
     * @param otherExceptionsOutput - used to hide secondary error messages on page
     * @param foundCustomException - if true, create hidden secondary error messages
     * @return A string.
     */
    protected static String createErrorBody(MonitorFlags monitorFlag, String message, String requestUri, String displayMessage, String exceptionToString, String reason,
            StringBuffer otherExceptionsOutput, boolean foundCustomException) {
        StringBuffer errorBody = new StringBuffer(2500);
        errorBody.append("<span class=\"errorMsg\">");
        errorBody.append(displayMessage);
        errorBody.append("</span>");
        errorBody.append("<div class=\"errorinformation\">");
        errorBody.append("<h1>" + reason + "</h1>");
        errorBody.append("<h2>" + message + "</h1>");
        errorBody.append("<h4>" + monitorFlag.toString() + "</h4>");
        errorBody.append("<pre>");
        errorBody.append(exceptionToString);
        errorBody.append("</pre>");
        errorBody.append("<hr/>");
        errorBody.append("<i>Error accessing " + requestUri + "</i>");

        if(foundCustomException){
            errorBody.append("<ul>");
            errorBody.append(otherExceptionsOutput);
            errorBody.append("</ul>");
        }
        errorBody.append("</div>");
        return errorBody.toString();
    }
    
    /**
     * Creates the error page body for cases where the error data was passed in via request parameters.
     *
     * @param exceptionClassName
     *      Required.
     * @param exceptionToString
     *      Required.
     * @param exceptionTypeClassName
     *      Required.
     * @param statusCode
     *      Optional, may be null.
     * @param message
     *      Required.
     * @param requestUri
     *      Required.
     * @return
     *      The HTML text for the error page body.
     * @throws IOException
     *      If there was an exception getting the GlobalMessages resource.
     */
    public static String getErrorBody(String exceptionClassName, String exceptionToString, String exceptionTypeClassName, Integer statusCode, String message, String requestUri) throws IOException {
        InputStream in = DesktopUtil.class.getResourceAsStream("/com/bcbssc/desktop/resource/GlobalMessages.properties");
        Properties props = new Properties();
        props.load(in);

        String exceptionKey = exceptionClassName + EXCEPTION_ERROR_MESSAGE_KEY_SUFFIX;        
        String messageKey = props.getProperty(exceptionKey, GENERIC_ERROR_MESSAGE_KEY);
        String friendlyMessage = props.getProperty(messageKey);

        // get monitor flag defined for the exception class.
        MonitorFlags monitorFlagEnum = getMonitorFlagEnum(props,exceptionClassName);

        // The error reason is either the status code or the exception type
        String reason = exceptionTypeClassName;
        if (null != statusCode) {
            reason = statusCode.toString();
        }

        return createErrorBody(monitorFlagEnum,message, requestUri, friendlyMessage, exceptionToString, reason, null, false);
    }

    public static String getErrorAjaxResponse(Throwable exception) throws IOException {
        Throwable relevantException;
        int exceptionIndex = ExceptionUtils.indexOfType(exception, DataAccessException.class);
        if(exceptionIndex > -1){
            relevantException = ExceptionUtils.getThrowables(exception)[exceptionIndex];
        } else{
            relevantException = exception;
        }
        
        return getFriendlyMessage(relevantException);
    }
    
    private static String getFriendlyMessage(Throwable exception) throws IOException{
        InputStream in = DesktopUtil.class.getResourceAsStream("/com/bcbssc/desktop/resource/GlobalMessages.properties");
        Properties props = new Properties();
        props.load(in);
        
        String exceptionKey = exception.getClass().getName() + EXCEPTION_ERROR_MESSAGE_KEY_SUFFIX;
        String messageKey = props.getProperty(exceptionKey, GENERIC_ERROR_MESSAGE_KEY);
        return props.getProperty(messageKey);
    }
    
    protected static MonitorFlags getMonitorFlagEnum(Properties props, String exceptionClassName){
        String exceptionFlagKey = exceptionClassName + EXCEPTION_ERROR_MONITOR_FLAG_SUFFIX;
        String monitorFlag= props.getProperty(exceptionFlagKey);
        //If custom monitor flag doesnt exist for the exception type, default to the default monitor flag. 
        if(StringUtils.isBlank(monitorFlag)){
            monitorFlag = props.getProperty(DEFAULT_ERROR_MONITOR_FLAG_KEY);
        }
        MonitorFlags monitorFlagEnum = null;
        if(monitorFlag !=null){
            try{
                monitorFlagEnum = MonitorFlags.valueOf(monitorFlag);
            }catch(IllegalArgumentException ex){
                //No enum found for the string retrieved, defaulting to S1 enum
                log.error("No monitor flag enum found for the string , "+ monitorFlag + ". Defaulting to S1 flag");
                monitorFlagEnum = MonitorFlags.MONITOR_TICKET_S1;
            }
        }else{
            //String retrieved from props is null, default to S1 enum.
            log.error("Monitor flag string retrieved is null Defaulting to S1 flag");
            monitorFlagEnum = MonitorFlags.MONITOR_TICKET_S1;
        }
        return monitorFlagEnum;
    }


}
