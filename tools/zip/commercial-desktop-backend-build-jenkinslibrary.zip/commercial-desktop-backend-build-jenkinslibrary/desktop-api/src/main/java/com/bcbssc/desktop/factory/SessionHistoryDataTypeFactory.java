/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * SessionHistoryDataTypeFactory.java
 * Created on 6/8/2009 by Dale Ewald
 */
package com.bcbssc.desktop.factory;

import com.bcbssc.domain.entity.SessionHistoryDataType;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;

/**
 * This class is used to create and populate a list containing the history of various
 * items that are accessed by the user  
 */
public class SessionHistoryDataTypeFactory {
    
	/**
	 * Depending on the appId create a list containing session history of various items accessed 
	 * @param appId
	 * @return
	 */
	
	public static ArrayList<SessionHistoryDataType> createSessionHistoryTypeList(String appId) {
        ArrayList<SessionHistoryDataType> list = new ArrayList<SessionHistoryDataType>();
        if ("CSR".equalsIgnoreCase(appId)) {
            list.add(createSessionHistoryDataType("dentalClaims", "Dental Claims", "", "", "claimNumber"));
            list.add(createSessionHistoryDataType("healthClaims", "Health Claims", "", "", "claimNumber"));
        } else if ("MBR".equalsIgnoreCase(appId)) {
            list.add(createSessionHistoryDataType("dentalClaims", "Dental Claims", "claimValidation", "dentalClaims", "claimNumber"));
            list.add(createSessionHistoryDataType("healthClaims", "Health Claims", "claimValidation", "healthClaims", "claimNumber"));
            list.add(createSessionHistoryDataType("visionClaims", "Vision Claims", "claimValidation", "visionClaims", "claimNumber"));
            list.add(createSessionHistoryDataType("imagePrints", "Image Prints", "printValidation", "imagePrints", "folderID"));
            list.add(createSessionHistoryDataType("letterPrints", "Letters Printed", "letterValidation", "letterPrints", "letterID"));
            list.add(createSessionHistoryDataType("indBills", "Individual Bills", "indBillsValidation", "indBills", "subscriberID"));
            list.add(createSessionHistoryDataType("grpBills", "Group Bills", "grpBillsValidation", "grpBills", "grpID"));
            list.add(createSessionHistoryDataType("ammsNumber", "AMMS Number", "ammsNumberValidation", "ammsNumber", "ammsNumber"));
        } else if(StringUtils.equalsIgnoreCase(appId, "MCS")){
            list.add(createSessionHistoryDataType("authorizations", "Authorizations", "", "", "authorizationNumber"));
            list.add(createSessionHistoryDataType("dentalClaims", "Dental Claims", "", "", "claimNumber"));
            list.add(createSessionHistoryDataType("healthClaims", "Health Claims", "", "", "claimNumber"));
        } else if (StringUtils.equalsIgnoreCase(appId, "AVL")) {
            list.add(createSessionHistoryDataType("healthClaims", "Health Claims", "", "", "claimNumber"));            
        }
        return list;
    }

	/**
	 * Create and populate a SessionHistoryDataType object that can be stored in the 
	 * sessionHistoryDataList that is tracking these items for the current user in the 
	 * current session
	 *
     * @param typeName The type name.
     * @param description The description.
     * @param validationFunction The validation function.
     * @param idPrefix The id prefix.
     * @param primaryKey The primary key.
     * @return A {@link SessionHistoryDataType} object.
     */
    public static SessionHistoryDataType createSessionHistoryDataType(String typeName, String description, String validationFunction, String idPrefix, String primaryKey) {
        SessionHistoryDataType sessionHistoryDataType = new SessionHistoryDataType();
        sessionHistoryDataType.setTypeName(typeName);
        sessionHistoryDataType.setDescription(description);
        sessionHistoryDataType.setValidationFunction(validationFunction);
        sessionHistoryDataType.setIdPrefix(idPrefix);
        sessionHistoryDataType.setPrimaryKey(primaryKey);
        return sessionHistoryDataType;
    }
}
