/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.attached.helper;

/**
 * Helper class to pre-load the data that is needed by the eligibility application.
 *
 * @author JC33 X87M
 * @deprecated The functionality from this class should move to the frontend.
 */
public class DesktopAttachedEligibilityHelper implements DesktopAttachedAppHelper {
}
