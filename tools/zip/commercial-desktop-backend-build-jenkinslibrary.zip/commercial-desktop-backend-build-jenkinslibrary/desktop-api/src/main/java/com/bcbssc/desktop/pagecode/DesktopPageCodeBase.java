/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 * DesktopPageCodeBase.java
 */
package com.bcbssc.desktop.pagecode;

import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.component.NamingContainer;
import javax.faces.component.UIComponent;
import javax.faces.component.UIComponentBase;
import javax.faces.component.UIForm;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

import com.bcbssc.desktop.jsf.JSFContextHelper;
import com.bcbssc.desktop.validation.DataValidator;

/**
 * Provides a common base class for all generated code behind files.
 */
@SuppressWarnings("unchecked")
public abstract class DesktopPageCodeBase {
    protected UIForm form;

    public DesktopPageCodeBase() {
    }

    /**
     * Use onSubmit to code for any common submission instructions.
     * For example, if there are multiple Links or Buttons on your JSF Form
     * that should perform the same Action.
     * @return String
     */
    public abstract String onSubmit();

    /**
     * Use onCancel to clear Form data.
     * @return String
     */
    public abstract String onCancel();

    /**
     * Use onLoad(FacesContext) to code for prerender functionality,
     * i.e. functionality that should trigger as the Page is loading.
     * @param facescontext
     */
    public abstract void onLoad(FacesContext facescontext) throws Throwable;

    /**
     * Validate data input
     */
    public void validate(FacesContext context, UIComponent toValidate, Object value) throws ValidatorException {

        String valEntered = (String) value;

        if (!DataValidator.validate(valEntered)) {
            String text = JSFContextHelper.getResourceMessage("value.invalid");
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, text, text);

            context.addMessage(toValidate.getClientId(context), message);
        }

    }

    /**
     * Add error message for component
     */
    protected void addErrorMessageForComponent(String clientId, String messageId) {
        FacesContext ctx = FacesContext.getCurrentInstance();
        JSFContextHelper.addErrorMessageForComponent(getForm().getClientId(ctx) + ":" + clientId, messageId);
    }

    /**
     * Add error message for component
     */
    protected void addErrorMessageForComponent(String clientId, String messageId, String additionalMsg) {
        FacesContext ctx = FacesContext.getCurrentInstance();
        JSFContextHelper.addErrorMessageForComponent(getForm().getClientId(ctx) + ":" + clientId, messageId, additionalMsg);
    }

    /**
     * Get message from bundle
     * @return
     */
    protected String getResourceMessage(String key) {
        return JSFContextHelper.getResourceMessage(key);
    }

    //--------------------------------------------------------------
    // Convenience Session Attribute Accessors
    //--------------------------------------------------------------

    protected Object getAttributeFromRequest(String key) {
        return JSFContextHelper.getAttributeFromRequest(key);
    }

    protected void setAttributeInRequest(String key, Object value) {
        JSFContextHelper.setAttributeInRequest(key, value);
    }

    protected void removeAttributeFromRequest(String key) {
        JSFContextHelper.removeAttributeFromRequest(key);
    }

    protected Object getAttributeFromSession(String key) {
        return JSFContextHelper.getAttributeFromSession(key);
    }

    protected void setAttributeInSession(String key, Object value) {
        JSFContextHelper.setAttributeInSession(key, value);
    }

    protected void removeAttributeFromSession(String key) {
        JSFContextHelper.removeAttributeFromSession(key);
    }

    protected Object getAttributeFromApplication(String key) {
        return JSFContextHelper.getAttributeFromApplication(key);
    }

    protected void setAttributeInApplication(String key, Object value) {
        JSFContextHelper.setAttributeInApplication(key, value);
    }

    protected void removeAttributeFromApplication(String key) {
        JSFContextHelper.removeAttributeFromApplication(key);
    }

    //--------------------------------------------------------------
    // Convenience Session Exception Handling Accessors
    //--------------------------------------------------------------

    /**
     * Method to add an error message to the faces context for display on the page.
     *
     * Use this method when no error style needs to be applied to the UIComponent
     * and no detailed error message needs to be displayed
     */
    protected void addErrorMessage(String errorMsg) {
        JSFContextHelper.addErrorMessage(errorMsg);
    }

    /**
     * Method to add an error message to the faces context for display on the page.
     *
     * Use this method when no error style needs to be applied to the UIComponent
     * and a detailed error message needs to be displayed
     */
    protected void addErrorMessage(String errorMsg, String detailMessage) {
        JSFContextHelper.addErrorMessage(errorMsg, detailMessage);
    }

    /**
     * Method to add an error message to the faces context for display on the page.
     *
     * Use this method when an error style needs to be applied to the UIComponent
     * and no detailed error message needs to be displayed
    */
    protected void addErrorMessage(UIComponent uiComponent, String errorMsg) {
        JSFContextHelper.addErrorMessage(uiComponent, errorMsg);
    }

    /**
     * Method to add an error message to the faces context for display on the page.
     *
     * Use this method when an error style needs to be applied to the UIComponent
     * and a detailed error message needs to be displayed
     */
    protected void addErrorMessage(UIComponent uiComponent, String errorMsg, String detailMessage) {
        JSFContextHelper.addErrorMessage(uiComponent, errorMsg, detailMessage);
    }

    /**
     * Method to check if there are error messages in the faces context
     */
    protected boolean hasErrorMessages() {
        return JSFContextHelper.hasErrorMessages();
    }

    protected void gotoPage(String pageName) {
        if (pageName != null) {
            FacesContext context = getFacesContext();
            UIViewRoot newView = context.getApplication().getViewHandler().createView(context, pageName);
            context.setViewRoot(newView);
            context.renderResponse();
        }
    }

    /**
     * <p>Return the {@link UIComponent} (if any) with the specified
     * <code>id</code>, searching recursively starting at the specified
     * <code>base</code>, and examining the base component itself, followed
     * by examining all the base component's facets and children.
     * Unlike findComponent method of {@link UIComponentBase}, which
     * skips recursive scan each time it finds a {@link NamingContainer},
     * this method examines all components, regardless of their namespace
     * (assuming IDs are unique).
     *
     * @param base Base {@link UIComponent} from which to search
     * @param id Component identifier to be matched
     */
    public static UIComponent findComponent(UIComponent base, String id) {

        return JSFContextHelper.findComponent(base, id);

    }

    public static UIComponent findComponentInRoot(String id) {

        return JSFContextHelper.findComponentInRoot(id);

    }

    /**
     * Place an Object on the tree's attribute map
     *
     * @param key
     * @param value
     */
    protected void putTreeAttribute(String key, Object value) {
        getFacesContext().getViewRoot().getAttributes().put(key, value);
    }

    /**
     * Retrieve an Object from the tree's attribute map
     * @param key
     * @return
     */
    protected Object getTreeAttribute(String key) {
        return getFacesContext().getViewRoot().getAttributes().get(key);
    }

    /**
     * Return the result of the resolved expression
     *
     * @param expression
     * @return
     */
    protected Object resolveExpression(String expression) {
        Object value = null;
        if ((expression.indexOf("#{") != -1) && (expression.indexOf("#{") < expression.indexOf('}'))) {
            value = getFacesContext().getApplication().createValueBinding(expression).getValue(getFacesContext());
        } else {
            value = expression;
        }
        return value;
    }

    /**
     * Return the managed bean with the given name
     *
     * @param mgdBeanName   the name of the managed bean to retrieve
     * @return
     */
    protected Object getManagedBean(String mgdBeanName) {
        String expression = "#{" + mgdBeanName + "}";
        return resolveExpression(expression);
    }

    /**
     * Resolve all parameters passed in via the argNames/argValues array pair, and
     * add them to the provided paramMap. If a parameter can not be resolved, then it
     * will attempt to be retrieved from a cachemap stored using the cacheMapKey
     *
     * @param paramMap
     * @param argNames
     * @param argValues
     * @param cacheMapKey
     */
    protected void resolveParams(Map paramMap, String[] argNames, String[] argValues, String cacheMapKey) {

        Object rawCache = getTreeAttribute(cacheMapKey);
        Map cache = Collections.EMPTY_MAP;
        if (rawCache instanceof Map) {
            cache = (Map) rawCache;
        }
        for (int i = 0; i < argNames.length; i++) {
            Object result = resolveExpression(argValues[i]);
            if (result == null) {
                result = cache.get(argNames[i]);
            }
            paramMap.put(argNames[i], result);
        }
        putTreeAttribute(cacheMapKey, paramMap);
    }

    /**
     * Returns a full system path for a file path given relative to the web project
     */
    protected static String getRealPath(String relPath) {
        String path = relPath;
        try {
            URL url = FacesContext.getCurrentInstance().getExternalContext().getResource(relPath);
            if (url != null) {
                path = url.getPath();
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return path;
    }

    /**
     * Returns an InputStream for a resource at the given path
     */
    protected static InputStream getResourceInputStream(String relPath) {
        return FacesContext.getCurrentInstance().getExternalContext().getResourceAsStream(relPath);
    }

    protected void logException(Throwable throwable) {
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        throwable.printStackTrace(printWriter);
        log(stringWriter.toString());
    }

    protected void log(String message) {
        System.out.println(message);
    }

    public Map getApplicationScope() {
        return getFacesContext().getExternalContext().getApplicationMap();
    }

    public FacesContext getFacesContext() {
        return FacesContext.getCurrentInstance();
    }

    public Map getRequestParam() {
        return getFacesContext().getExternalContext().getRequestParameterMap();
    }

    public Map getRequestScope() {
        return getFacesContext().getExternalContext().getRequestMap();
    }

    public Map getSessionScope() {
        return getFacesContext().getExternalContext().getSessionMap();
    }

    public UIForm getForm() {
        return form;
    }

    public void setForm(UIForm form) {
        this.form = form;
    }

    public String getFormId() {
        FacesContext ctx = FacesContext.getCurrentInstance();
        return getForm().getClientId(ctx);
    }
}