/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2017 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.api;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.cache.CacheWrapper;
import com.bcbssc.desktop.dao.auth.NotAuthenticatedException;
import com.bcbssc.desktop.dao.cache.ICacheWrapper;
import com.bcbssc.desktop.factory.SessionHistoryDataTypeFactory;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.jndi.JndiUtils;
import com.bcbssc.domain.cache.CacheDataStore;
import com.bcbssc.domain.entity.ApplicationClient;
import com.bcbssc.domain.entity.InformIdentification;
import com.bcbssc.domain.entity.SessionHistoryDataType;
import com.bcbssc.domain.entity.Subsystem;
import com.bcbssc.domain.entity.alerts.AlertsCache;
import com.bcbssc.domain.entity.auth.RacfIdPrincipal;
import com.bcbssc.domain.entity.auth.RacfPasswordCredential;
import com.bcbssc.domain.entity.cti.CallCenterAttribute;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;
import com.bcbssc.domain.entity.inform.InformData;

/**
 * This class provides some generic accesses for various data in the application.
 *
 * @author JC33, Dale Ewald
 */
public class DesktopAPI {

    public static final String APPID_KEY = "APPID";

    public static final String KEY_DELIM = "_";
    private static final String USER_SUBJECT_KEY = "SUBJECT";
    public static final String PICKLIST_KEY_SUFFIX = "PICKLIST";
    private static final String PICKLIST_DEFAULT_KEY_SUFFIX = "PICKLIST_DEFAULTS";
    public static final String RULES_KEY_SUFFIX = "RULES";
    private static final String CLIENT_LISTS_KEY = "CLIENT_LISTS";
    private static final String SUBSYSTEM_RPN_MAP_KEY = "SUBSYSTEM_RPN_MAP";
    private static final String SESSION_HISTORY_TYPES_PREFIX = "SESSION_HISTORY_TYPES_";
    private static final String INFORM_DATA_KEY = "INFORM_DATA";

    private static final String RULES_DATA_TYPE_KEY = "RULES_DATA_TYPE";
    public static final String ICD_COMPLIANCE_CATEGORIES = "icdComplianceCategories";
    public static final String ICD_COMPLIANCE_DATE = "icdComplianceDate";

    public static final String PICKLIST_STATUS = "PICKLIST_STATUS";
    public static final String PICKLIST_CATEGORY = "PICKLIST_CATEGORY";
    public static final String PICKLIST_REQUEST_REASON = "PICKLIST_REQUEST_REASON";
    public static final String PICKLIST_CONTACT_TYPE = "PICKLIST_CONTACT_TYPE";
    public static final String PICKLIST_RESOLUTION = "PICKLIST_RESOLUTION";
    public static final String PICKLIST_SEVERITY = "PICKLIST_SEVERITY";
    public static final String PICKLIST_TRANSFER = "PICKLIST_TRANSFER";
    public static final String SESSION1 = "SESSION1";
    public static final String SESSION2 = "SESSION2";
    public static final String SESSION3 = "SESSION3";
    public static final String GLOBAL_KEY_GROUP_ID = "groupId";
    public static final String GLOBAL_KEY_AMMS_GROUP_NUMBER = "ammsGroupNumber";
    public static final String GLOBAL_KEY_CES_GROUP_NUMBER = "cesGroupNumber";
    public static final String GLOBAL_KEY_CLIENT_NUMBER = "clientNumber";
    public static final String GLOBAL_KEY_BILL_NUMBER = "billNumber";
    public static final String GLOBAL_KEY_BUSINESS_TYPE_CODE = "businessType";
    public static final String GLOBAL_KEY_BUSINESS_TYPE_DESCRIPTION = "businessTypeDesc";
    public static final String GLOBAL_KEY_HIC_NUMBER = "hicNumber";
    public static final String GLOBAL_KEY_NPI_NUMBER = "npiNumber";
    public static final String GLOBAL_KEY_SERVICE_CENTER = "serviceCenter";
    public static final String GLOBAL_KEY_SUBSCRIBER_NUMBER = "subscriberNumber";
    public static final String GLOBAL_KEY_PROVIDER_ID = "providerId";
    public static final String GLOBAL_KEY_PROVIDER_NUMBER = "providerNumber";
    public static final String GLOBAL_KEY_PROVIDER_NAME = "providerName";
    public static final String GLOBAL_KEY_MASTER_AR_NUMBER = "masterARNumber";
    //one use of policy type is for Summary of Benefits and Coverage:
    public static final String GLOBAL_KEY_HEALTH_COVERAGE_POLICY_TYPE = "healthCoveragePolicyType";

    public static final String PICKLIST_PATTERN = "[a-zA-Z0-9]+\\_[a-zA-Z0-9]+\\_[a-zA-Z0-9]+\\_[a-zA-Z0-9]+\\_[a-zA-Z0-9]+PICKLIST";
    public static final String PICKLIST_DEFAULTS_PATTERN = "[a-zA-Z0-9]+\\_[a-zA-Z0-9]+\\_[a-zA-Z0-9]+PICKLIST\\_DEFAULTS";
    public static final String RULES_PATTERN = "[A-Z]{3}+\\_[0-9]{3}+\\_[a-zA-Z]+\\_[a-zA-Z0-9]+\\_[a-zA-Z0-9]+\\_[a-zA-Z0-9]+\\_[a-zA-Z0-9]+RULES";

    public static final String DATA_TYPE_SUBSCRIBER = "subscriber";
    public static final String DATA_TYPE_GROUP = "group";
    public static final String DATA_TYPE_PATIENT = "patient";
    public static final String DATA_TYPE_APPLICATION = "application";
    public static final String DATA_TYPE_GROUP_COVERAGE = "groupCoverage";
    public static final String DATA_TYPE_APPLICATION_STATUS = "application-status";
    public static final String DATA_TYPE_CUSTOMER = "customer";

    public static final String DEFAULT_ENVIRONMENT = "default";

    private static final String DEFAULT_PLAN_CODE = "885";

    private static final String RELAY_LOOKUP_FLAG = "RELAY_LOOKUP_FLAG";

    private static final String CALL_CENTERS_DISABLED_FOR_CONCIERGE = "CALL_CENTERS_DISABLED_FOR_CONCIERGE";

    /**
     * cacheWrapper defaults to a concrete instance of cacheWrapper.
     */
    private static ICacheWrapper cacheWrapper = new CacheWrapper();

    private static final Log log = LogFactory.getLog(DesktopAPI.class);

    /**
     * Sets the cacheWrapper.  Allows for Junit testing to set the cacheWrapper to a mock object.
     * @param cacheWrapperToSet ICacheWrapper
     */
    public static void setCacheWrapper(ICacheWrapper cacheWrapperToSet) {
        cacheWrapper = cacheWrapperToSet;
    }

    /**
     * Returns the cacheWrapper.  Example usage:
     * desktop-endtask-app/src/com/bcbssc/desktop/endtask/servlet/CacheDumpServlet.java
     */
    public static ICacheWrapper getCacheWrapper() {
        return cacheWrapper;
    }

    /**
     * Retrieves the AppId value for programmatic use.
     * @param sessionId String
     * @return String
     */
    public static String getAppId(String sessionId) throws Exception {
        return (String) getUserSessionMapEntry(sessionId, DesktopAPI.APPID_KEY);
    }

    /**
     * Sets the picklist defaults into dynacache for the company, division and department that is passed in
     * @param company
     * @param division
     * @param department
     * @param picklistDefaults
     */
    public static void setPicklistDefaults(String company, String division, String department, HashMap<String, String> picklistDefaults) throws Exception {
        final String key = company + KEY_DELIM + division + KEY_DELIM + department + PICKLIST_DEFAULT_KEY_SUFFIX;
        if ((null != picklistDefaults) && !picklistDefaults.isEmpty()) {
            if (!cacheWrapper.hasEntry(key)) {
                cacheWrapper.setApplicationEntry(key, picklistDefaults);
            }
        }
    }

    /**
     * Retrieves the picklist defaults. The session Id is used to retrieve the subject which is used
     * to get the company, division and department that should be used to get the value.
     * @param sessionId
     * @return
     */
    public static Map<String, String> getPicklistDefaults(String sessionId) throws Exception {
        final Subject subject = getUserSubject(sessionId);
        final InformIdentification informId = SubjectUtils.getInformId(subject);

        final String company = informId.getCompany();
        final String division = informId.getDivision();
        final String department = informId.getDepartment();

        final String key = company + KEY_DELIM + division + KEY_DELIM + department + PICKLIST_DEFAULT_KEY_SUFFIX;
        if (log.isDebugEnabled()) {
            log.debug("Looking up picklist defaults with key: " + key);
        }
        return (Map<String, String>) cacheWrapper.getEntry(key);
    }

    /**
     * verify the picklists have been stored
     * @param subject
     * @return true or false depending on the picklists' presence in storage
     */
    public static boolean verifyPicklistsStored(Subject subject) throws Exception {
        final String key = getPicklistCodesKeyFromSubject(subject);
        boolean hasEntry = Boolean.FALSE;

        if (log.isDebugEnabled()) {
            log.debug("the key used to store the picklist codes is: " + key);
        }

        if (cacheWrapper.hasEntry(key)) {
            hasEntry = Boolean.TRUE;
        }

        return hasEntry;
    }

    /**
     * Adds the supplied picklistCodes Map to Cache, keyed by the composite of data provided in the subject
     *
     * @param subject
     * @param picklistCodes
     */
    public static void setPicklistCodes(Subject subject, HashMap<String, ?> picklistCodes) throws Exception {
        final String key = getPicklistCodesKeyFromSubject(subject);

        if (log.isDebugEnabled()) {
            log.debug("The key used to store the picklist codes is [" + key + "]");
        }

        if ((null != picklistCodes) && !picklistCodes.isEmpty()) {
            cacheWrapper.setApplicationEntry(key, picklistCodes);
        }
    }

    /**
     * Adds the supplied picklistCodes Map to Cache, keyed by the composite of data provided in the session
     *
     * @param sessionId The session ID that can be used to retrieve the subject
     * @param picklistCodes The codes to save
     */
    public static void setPicklistCodes(String sessionId, HashMap<String, ?> picklistCodes) throws Exception {
        final String key = getPicklistCodesKey(sessionId);
        storePicklistCodes(picklistCodes, key, true);
    }

    /**
     * @param picklistCodes
     * @param key
     */
    private static void storePicklistCodes(HashMap<String, ?> picklistCodes, String key, boolean checkExists) throws Exception {
        if ((null != picklistCodes) && !picklistCodes.isEmpty()) {
            boolean saveData = true;
            if (checkExists && cacheWrapper.hasEntry(key)) {
                saveData = false;
            }
            if (saveData) {
                if (log.isDebugEnabled()) {
                    log.debug("The key used to store the picklist codes is \n\t" + key);
                }

                cacheWrapper.setApplicationEntry(key, picklistCodes);
            }
        }
    }

    /**
     * Stores the picklist codes the hard way. This method should be avoided if a Subject, PortletRequest or session id is available
     *
     * @param applicationId
     * @param clientId
     * @param company
     * @param division
     * @param department
     * @param picklistCodes
     */
    public static void setPicklistCodes(String applicationId, String clientId, String company, String division, String department, HashMap<String, ?> picklistCodes) throws Exception {
        final String key = applicationId + KEY_DELIM + clientId + KEY_DELIM + company + KEY_DELIM + division + KEY_DELIM + department + PICKLIST_KEY_SUFFIX;
        storePicklistCodes(picklistCodes, key, false);
    }

    /**
     * @param sessionId
     * @return
     */
    private static String getPicklistCodesKey(String sessionId) throws Exception {
        final Subject subject = getUserSubject(sessionId);
        return getPicklistCodesKeyFromSubject(subject);
    }

    /**
     * @param subject
     * @return
     */
    private static String getPicklistCodesKeyFromSubject(Subject subject) {
        final InformIdentification informId = SubjectUtils.getInformId(subject);
        final ApplicationClient client = SubjectUtils.getClient(subject);

        final String key = client.getAppId() + KEY_DELIM + client.getClientId() + KEY_DELIM + informId.getCompany() + KEY_DELIM + informId.getDivision() + KEY_DELIM
                        + informId.getDepartment() + PICKLIST_KEY_SUFFIX;
        return key;
    }

    /**
     * Retrieves a full Map of Picklist Codes for the User's Company, Division, Department
     * @param sessionId
     * @return Map
     */
    public static Map getAllPicklistCodes(String sessionId) throws Exception {
        final String key = getPicklistCodesKey(sessionId);
        if (log.isDebugEnabled()) {
            log.debug("Looking up picklists with key: " + key);
        }
        return (Map) cacheWrapper.getEntry(key);
    }

    /**
     * Retrieves a List of Picklist Codes based on the provided type.
     * @param sessionId String
     * @param type String
     * @return List
     */
    public static List getPicklistCodes(String sessionId, String type) throws Exception {
        final Map<String, List> picklists = getAllPicklistCodes(sessionId);
        List codes = null;
        if (null != picklists) {
            if (picklists.containsKey(type)) {
                codes = picklists.get(type);
            }
        }
        return codes;
    }

    /**
     * Retrieves the data that has been retrieved from the emulator for the given session
     *
     * @param sessionId
     * @param emulatorSession
     * @return
     */
    public static Map getUserTaskHistoryData(String sessionId, String emulatorSession) throws Exception {
        final Map<String, Serializable> usermap = getUserSessionMap(sessionId);
        if (usermap.containsKey(emulatorSession)) {
            return (Map) usermap.get(emulatorSession);
        } else {
            return null;
        }
    }

    /**
     * Adds the supplied clientList Map into Cache.
     *
     * @param applicationId The application id for the client list
     * @param clientList the client list for the given application id
     */
    @SuppressWarnings("unchecked")
    public static void setClientList(String applicationId, List<ApplicationClient> clientList) throws Exception {
        if ((null != clientList) && !clientList.isEmpty()) {
            HashMap<String, ArrayList<ApplicationClient>> clientLists =
                            (HashMap<String, ArrayList<ApplicationClient>>) cacheWrapper.getEntry(CLIENT_LISTS_KEY);
            if(clientLists == null) {
                clientLists = new HashMap<String, ArrayList<ApplicationClient>>();
            }
            clientLists.put(applicationId, new ArrayList<ApplicationClient>(clientList));
            cacheWrapper.setApplicationEntry(CLIENT_LISTS_KEY, clientLists);
        }
    }

    /**
     * Retrieves the clientList Map from Cache.
     * A map of applicationId to the list of available clients.
     *
     * @param applicationId The application id for the client list to retrieve
     * @return
     */
    @SuppressWarnings("unchecked")
    public static List<ApplicationClient> getClientList(String applicationId) throws Exception {
        List<ApplicationClient> clientList = null;
        final HashMap<String, ArrayList<ApplicationClient>> clientLists =
                        (HashMap<String, ArrayList<ApplicationClient>>) cacheWrapper.getEntry(CLIENT_LISTS_KEY);
        if((clientLists != null) && (clientLists.size() > 0)) {
            clientList = clientLists.get(applicationId);
        }
        return clientList;
    }

    /**
     * Removes the entire client list cache.
     *
     * @throws Exception
     */
    public static void removeClientListsCache() throws Exception {
        cacheWrapper.removeEntry(CLIENT_LISTS_KEY);
    }

    /**
     * Retrieve the application client from cache.
     *
     * @param applicationId The application ID for which client list to retrieve
     * @param clientId The Id for the {@link ApplicationClient} to retrieve from cache.
     * @return An {@link ApplicationClient} object for the client and application ids specified.
     */
    public static ApplicationClient getClientFromClientList(final String applicationId, final String clientId) throws Exception {
        ApplicationClient client = null;
        // get the client list out of cache
        final List<ApplicationClient> applicationClients = getClientList(applicationId);
        if (null != applicationClients) {
            for (final ApplicationClient applicationClient : applicationClients) {
                if ((null != applicationClient) && StringUtils.equalsIgnoreCase(clientId, applicationClient.getClientId())) {
                    client = applicationClient;
                    break;
                }
            }
        }
        return client;
    }

    /**
     * Adds the supplied Subsystem RPN Map into Cache.
     *
     * @param allSubsystemRpns map Map of RPN Subsystem map
     */
    public static void setSubsystemRpnMap(HashMap<String, Map<String, Subsystem>> allSubsystemRpns) throws Exception {
        final String key = SUBSYSTEM_RPN_MAP_KEY;
        if ((null != allSubsystemRpns) && !allSubsystemRpns.isEmpty()) {
            cacheWrapper.setApplicationEntry(key, allSubsystemRpns);
        }
    }

    /**
     * Retrieves the Subsystem RPN Map from Cache.
     * @return
     */
    @SuppressWarnings("unchecked")
    public static HashMap<String, Map<String, Subsystem>> getSubsystemRpnMap() throws Exception {
        return (HashMap<String, Map<String, Subsystem>>) cacheWrapper.getEntry(SUBSYSTEM_RPN_MAP_KEY);
    }

    /**
     * Removes the subsystem RPN Map from Cache.
     *
     * @throws Exception
     */
    public static void removeSubsystemsRpnMap() throws Exception {
        cacheWrapper.removeEntry(SUBSYSTEM_RPN_MAP_KEY);
    }

    /**
     * Adds the supplied rulesEntries Map to Cache, key by the composite of data in the subject
     *
     * @param subject
     * @param rulesEntries
     */
    public static void setRulesEntries(Subject subject, HashMap<String, ?> rulesEntries) throws Exception {
        final String key = getRulesEntriesKeyFromSubject(subject);
        if ((null != rulesEntries) && !rulesEntries.isEmpty()) {
            if (!cacheWrapper.hasEntry(key)) {
                if (log.isDebugEnabled()) {
                    log.debug("The key that is being used to store the rule entries is \n\t" + key);
                }
                cacheWrapper.setApplicationEntry(key, rulesEntries);
            }
        }
    }

    /**
     * Adds the supplied rulesEntries Map to Cache, key by the composite of data in the session
     *
     * @param sessionId
     * @param rulesEntries
     */
    public static void setRulesEntries(String sessionId, HashMap<String, ?> rulesEntries) throws Exception {
        final String key = getRulesEntriesKey(sessionId);
        storeRulesEntries(rulesEntries, key, true);
    }

    /**
     * @param rulesEntries
     * @param key
     * @param checkExists
     */
    private static void storeRulesEntries(HashMap<String, ?> rulesEntries, String key, boolean checkExists) throws Exception {
        if ((null != rulesEntries) && !rulesEntries.isEmpty()) {
            boolean saveData = true;
            if (checkExists && cacheWrapper.hasEntry(key)) {
                saveData = false;
            }
            if (saveData) {
                if (log.isDebugEnabled()) {
                    log.debug("The key that is being used to store the rule entries is \n\t" + key);
                }
                cacheWrapper.setApplicationEntry(key, rulesEntries);
            }
        }
    }

    /**
     * Stores the rule entries the hard way. This method should be avoided if a Subject, PortletRequest or session id is available
     *
     * @param applicationId
     * @param rpn
     * @param company
     * @param division
     * @param department
     * @param region
     * @param rulesEntries
     */
    public static void setRulesEntries(String applicationId, String rpn, String clientId, String company, String division, String department, String region,
                    HashMap<String, ?> rulesEntries) throws Exception {
        final String key = applicationId + KEY_DELIM + rpn + KEY_DELIM + clientId + KEY_DELIM + company + KEY_DELIM + division + KEY_DELIM + department + KEY_DELIM
                        + region + RULES_KEY_SUFFIX;
        storeRulesEntries(rulesEntries, key, false);
    }

    /**
     * Gets the key to be used for storing and retrieving rules data to cache
     * @param sessionId
     * @return
     */
    private static String getRulesEntriesKey(String sessionId) throws Exception {
        final Subject subject = getUserSubjectStrict(sessionId);
        return getRulesEntriesKeyFromSubject(subject);
    }

    /**
     * @param subject
     * @return
     */
    private static String getRulesEntriesKeyFromSubject(Subject subject) {
        final InformIdentification informId = SubjectUtils.getInformId(subject);
        final ApplicationClient client = SubjectUtils.getClient(subject);

        final String key = client.getAppId() + KEY_DELIM + client.getAliasRpn() + KEY_DELIM + client.getClientId() + KEY_DELIM + informId.getCompany() + KEY_DELIM
                        + informId.getDivision() + KEY_DELIM + informId.getDepartment() + KEY_DELIM + SubjectUtils.getRegion(subject) + RULES_KEY_SUFFIX;

        return key;
    }

    /**
     * Gets the rulesEntries Object from Cache, keyed by the data stored in the session
     *
     * @param sessionId
     * @return
     */
    public static HashMap<String, ?> getRulesEntries(String sessionId) throws Exception {
        final String key = getRulesEntriesKey(sessionId);
        if (log.isDebugEnabled()) {
            log.debug("Looking up rules with key: " + key);
        }
        return (HashMap<String, ?>) cacheWrapper.getEntry(key);
    }

    /**
     * Gets the rulesEntries Map from Cache using a specified subject
     *
     * @param subject
     * @return
     */
    public static Map<String, ?> getRulesEntries(Subject subject) throws Exception {
        final String key = getRulesEntriesKeyFromSubject(subject);
        if (log.isDebugEnabled()) {
            log.debug("Looking up rules with key: " + key);
        }
        return (Map<String, ?>) cacheWrapper.getEntry(key);
    }

    public static void removeRulesEntries(Subject subject) throws Exception {
        final String key = getRulesEntriesKeyFromSubject(subject);
        if (log.isDebugEnabled()) {
            log.debug("Looking up rules with key: " + key);
        }
        cacheWrapper.removeEntry(key);
    }

    public static void removeAllRulesEntriesCaches() throws Exception {
        for(final String key : cacheWrapper.getKeys()) {
            if(StringUtils.contains(key, RULES_KEY_SUFFIX)) {
                cacheWrapper.removeEntry(key);
            }
        }
    }

    /**
     * Locates a user's cached data by the param sessionId.
     * @param sessionId String
     * @return Map
     */
    public static HashMap<String, Serializable> getUserSessionMap(String sessionId) throws Exception {
        HashMap<String, Serializable> map = (HashMap<String, Serializable>) cacheWrapper.getEntry(sessionId);
        if (null == map) {
            map = new HashMap<String, Serializable>();
            map.put(AlertsCache.class.getName(), new AlertsCache());
            map.put(CacheDataStore.class.getName(), new CacheDataStore());
            cacheWrapper.setSessionEntry(sessionId, map);
        }
        return map;
    }

    /** Push out the user's session map data to the Dynacache instances on other nodes. */
    public static void replicateUserSessionMap(String sessionId) throws Exception {
        final Serializable obj = cacheWrapper.getEntry(sessionId);
        cacheWrapper.setSessionEntry(sessionId, obj);
    }

    /**
     * Removes any entries from DynaCache that the user has accumulated as part of their session.
     * @param sessionId
     */
    public static void removeUserSession(String sessionId) throws Exception {
        cacheWrapper.removeEntry(sessionId);
        cacheWrapper.removeEntry(INFORM_DATA_KEY + sessionId);
    }

    /**
     * Returns the User Subject, if stored in cache.
     * @param sessionId String
     * @return Subject
     */
    public static Subject getUserSubject(String sessionId) throws Exception {
        final Map map = getUserSessionMap(sessionId);
        Subject subject = null;
        if (map.containsKey(USER_SUBJECT_KEY)) {
            subject = (Subject) map.get(USER_SUBJECT_KEY);
        }
        return subject;
    }

    /**
     * Returns the User Subject, if stored in cache.
     * @param sessionId String
     * @return Subject
     */
    public static Subject getUserSubjectStrict(String sessionId) throws Exception {
        final Subject subject = getUserSubject(sessionId);
        if(subject == null) {
            throw new NotAuthenticatedException("A user subject could not be found in cache");
        }
        return subject;
    }

    /**
     * Builds the initial User data Map using the supplied parameters, and
     * stores in cache.
     *
     * @param sessionId
     * 		The users's the session id (typically from WebSphere Portal).
     * @param appId
     * 		The string representing the Desktop App (ie "CSR", "MBR", etc)
     * @param user
     * 		The user's Subject.
     */
    public static void setUserStartupData(String sessionId, String appId, Subject user) throws Exception {
        SubjectUtils.setSessionId(user, sessionId);
        final Map<String, Serializable> map = getUserSessionMap(sessionId);
        map.put(APPID_KEY, appId);
        map.put(USER_SUBJECT_KEY, user);
        // Make sure that all the nodes get the user's subject.
        replicateUserSessionMap(sessionId);
    }

    /**
     * Creates and caches the Session History Data Types (list types) to be used in the Desktop.
     * @param appId String representing the Desktop App (ie "CSR", "MBR", etc)
     */
    public static void setSessionHistoryDataTypes(String appId) throws Exception {
        final String key = SESSION_HISTORY_TYPES_PREFIX + appId;
        if (!cacheWrapper.hasEntry(key)) {
            final ArrayList<SessionHistoryDataType> list = SessionHistoryDataTypeFactory.createSessionHistoryTypeList(appId);
            cacheWrapper.setApplicationEntry(SESSION_HISTORY_TYPES_PREFIX + appId, list);
        }
    }

    /**
     * Returns the Session History Type List from Cache by App ID.
     * @param appId String representing the Desktop App (ie "CSR", "MBR", etc)
     * @return List
     */
    public static List getSessionHistoryDataTypeList(String appId) throws Exception {
        return (List) cacheWrapper.getEntry(SESSION_HISTORY_TYPES_PREFIX + appId);
    }

    /**
     * Finds the App ID through the provided sessionId param and returns the
     * Session History Type list in Cache.
     *
     * @param sessionId The session ID to be used to lookup information from DynaCache
     * @return A list of session history data types
     */
    public static List getSessionHistoryDataTypeListBySessionId(String sessionId) throws Exception {
        final String appId = (String) getUserSessionMapEntry(sessionId, APPID_KEY);
        return (List) cacheWrapper.getEntry(SESSION_HISTORY_TYPES_PREFIX + appId);
    }

    /**
     * Returns the value of the Map Entry for the param key, from the user's cached data.
     * @param sessionId String
     * @param key String
     * @return Object
     */
    public static Serializable getUserSessionMapEntry(String sessionId, String key) throws Exception {
        final Map<String, Serializable> map = getUserSessionMap(sessionId);
        Serializable mapEntry = null;
        if (map.containsKey(key)) {
            mapEntry = map.get(key);
        }
        return mapEntry;
    }

    /**
     * Returns a user's Search result from cache.
     * @param sessionId String
     * @param resultType String value of Public Render Parameter VIEW
     * @return The cached object.
     * @deprecated Convert the DAO that fetches the data you need into AbstractDaoCaching and just call it.
     */
    @Deprecated
    public static <T extends Serializable> T getSearchResult(String sessionId, Class<T> resultType) throws Exception {
        T searchResult = null;
        if (null != resultType) {
            searchResult = (T) getSearchResult(sessionId, resultType.getName());
        }
        return searchResult;
    }

    /**
     * Returns a user's Search result from cache.
     * @param sessionId
     * @param resultType
     * @return
     * @deprecated Convert the DAO that fetches the data you need into AbstractDaoCaching and just call it.
     */
    @Deprecated
    public static Serializable getSearchResult(String sessionId, String resultType) throws Exception {
        Serializable searchResult = null;
        if (null != resultType) {
            final Map<String, Serializable> map = getUserSessionMap(sessionId);
            if (map.containsKey(resultType)) {
                searchResult = map.get(resultType);
            }
        }
        return searchResult;
    }

    /**
     * Returns result cached by session id.
     *
     * @param request
     *      Used to get the session id for the user.
     * @param resultType
     *      The type that cached object is stored under.
     * @return
     *      The cached object.
     * @deprecated Convert the DAO that fetches the data you need into AbstractDaoCaching and just call it.
     */
    @Deprecated
    public static <T extends Serializable> T getSearchResult(HttpServletRequest request, Class<T> resultType) throws Exception {
        return getSearchResult(request.getSession().getId(), resultType);
    }

    /**
     * Stores a user's Search result in cache.
     * @param sessionId String
     * @param result Object search result
     * @deprecated Convert the DAO that fetches the data you need into AbstractDaoCaching and just call it.
     */
    @Deprecated
    public static void setSearchResult(String sessionId, Serializable result) throws Exception {
        setSearchResult(sessionId, result, result.getClass());
    }

    /**
     * Stores a user's Search result in cache.
     *
     * @param sessionId
     * @param result
     *      The instance of a search result object.
     * @param resultType
     *      The Class of the result object.
     * @throws IllegalArgumentException
     *      If the given resultType represents a <code>java.util.Collection</code>.
     *      This is to enforce proper model design.
     *      <br>
     *      For example, instead of <code>List&lt;Foo&gt;</code>
     *      another model should be created for example <code>FooInfo</code> that contains the actual list.
     * @deprecated Convert the DAO that fetches the data you need into AbstractDaoCaching and just call it.
     */
    @Deprecated
    public static void setSearchResult(String sessionId, Serializable result, Class<? extends Serializable> resultType) throws Exception {
        if (java.util.Collection.class.isAssignableFrom(resultType)) {
            throw new IllegalArgumentException("Cannot set search resultType of type java.util.Collection.");
        }

        if (null != resultType) {
            final Map<String, Serializable> map = getUserSessionMap(sessionId);
            map.put(resultType.getName(), result);
        }
    }

    /**
     * Removes a user's search result from cache.
     *
     * @param sessionId
     *      The HTTP session id
     * @param resultType
     *      The Class of the result object.
     * @deprecated Convert the DAO that fetches the data you need into AbstractDaoCaching and just call it.
     */
    @Deprecated
    public static void removeSearchResult(String sessionId, Class<? extends Serializable> resultType) throws Exception {
        if (null != resultType) {
            final Map<String, Serializable> map = getUserSessionMap(sessionId);
            map.remove(resultType.getName());
        }
    }

    /**
     * Updates a single property on the specified search result.
     * A thin convenience wrapper around {@link DesktopAPI#setSearchResultProperties(String, Class, Map)}.
     *
     * @see DesktopAPI#setSearchResultProperties(String, Class, Map)
     * @deprecated Convert the DAO that fetches the data you need into AbstractDaoCaching and just call it.
     */
    @Deprecated
    public static void setSearchResultProperty(String sessionId, Class<? extends Serializable> resultType, String property, Serializable propertyValue) throws Exception {
        final Map<String, Serializable> properties = new HashMap<String, Serializable>();
        properties.put(property, propertyValue);
        setSearchResultProperties(sessionId, resultType, properties);
    }

    /**
     * Updates multiple properties on the specified search result object.
     * <br>
     * Assumes the following:
     * <ol>
     * <li>There is already a search result of the specified type stored (a null search result will be ignored).</li>
     * <li>The specified property exists on the root of the search result and is not a nested chain of properties.</li>
     * </ol>
     * This method is synchronized so that the search result is updated one piece at a time to avoid
     * multiple invoking parties from stepping on each other.
     *
     * @param sessionId
     *
     * @param resultType
     *      The model object class (for example, <code>Subscriber.class</code>).
     *
     * @param properties
     *      A mapping from the property name to the property value.
     *      In this case, the property name is the <code>xxx</code> in <code>setXxx(x)</code>.
     *      Case sensitive and should follow camel case (for example, <code>"fooBar"</code> for <code>"setFooBar(FooBar p)"</code>).
     *
     * @throws Exception
     *      If a writable property for the value type does not exist.  In this event, any updates to the result object will not be saved.
     * @deprecated Convert the DAO that fetches the data you need into AbstractDaoCaching and just call it.
     */
    @Deprecated
    public synchronized static void setSearchResultProperties(String sessionId, Class<? extends Serializable> resultType, Map<String, Serializable> properties) throws Exception {

        // Get the model object.
        final Serializable searchResult = getSearchResult(sessionId, resultType);

        if (null != searchResult) {
            final BeanInfo beanInfo = Introspector.getBeanInfo(resultType);
            final Map<String, PropertyDescriptor> mapDescriptors = new HashMap<String, PropertyDescriptor>();

            // set up the map for easy lookup.
            final PropertyDescriptor[] descriptors = beanInfo.getPropertyDescriptors();
            for (final PropertyDescriptor descriptor : descriptors) {
                mapDescriptors.put(descriptor.getName(), descriptor);
            }

            // find each of properties and set them.
            for (final String property : properties.keySet()) {
                if (mapDescriptors.containsKey(property) && (null != mapDescriptors.get(property))) {
                    // Update the model object.
                    final Method writeMethod = mapDescriptors.get(property).getWriteMethod();
                    final Object[] parameters = { properties.get(property) };
                    writeMethod.invoke(searchResult, parameters);
                } else {
                    // no property on this bean.
                    throw new Exception("Property " + property + " not found in class " + resultType.getName());
                }
            }

            // Save the updated model object.
            setSearchResult(sessionId, searchResult, resultType);
        }
    }

    /**
     * Fetch alert data from cache.
     * @deprecated Convert the DAO that fetches the data you need into AbstractDaoCaching and just call it.
     */
    @Deprecated
    public static AlertsCache getAlertsCache(HttpServletRequest request) throws Exception {
        return getAlertsCache(request.getSession(false).getId());
    }


    /**
     * Fetch alert data from cache
     * @deprecated Convert the DAO that fetches the data you need into AbstractDaoCaching and just call it.
     */
    @Deprecated
    public static AlertsCache getAlertsCache(String sessionId) throws Exception {
        final Map<String, Serializable> map = getUserSessionMap(sessionId);
        return (AlertsCache) map.get(AlertsCache.class.getName());
    }

    /**
     * Clear alert data from cache
     * @deprecated Convert the DAO that fetches the data you need into AbstractDaoCaching and just call it.
     */
    @Deprecated
    public static void clearAlertCache(String sessionId) throws Exception {
        final Map<String, Serializable> map = getUserSessionMap(sessionId);
        map.put(AlertsCache.class.getName(), new AlertsCache());
    }

    /**
     * Stores INFOrm data into cache.
     * @param sessionId Session Id used to identify the user.
     * @param informData InformData Object to store in the cache.
     */
    public static void setInformData(String sessionId, InformData informData) throws Exception {
        cacheWrapper.setSessionEntry(INFORM_DATA_KEY + sessionId, informData);
    }

    /**
     * Retrieves the INFOrm data from cache.
     * @param sessionId Session Id used to identify the user.
     * @return InformData Object for the user.
     */
    public static InformData getInformData(String sessionId) throws Exception {
        return (InformData) cacheWrapper.getEntry(INFORM_DATA_KEY + sessionId);
    }

    /**
     * Sets the call center attribute to cache
     *
     * @param callCenterAttribute
     * @param callCenter
     * @param productCode
     * @param rpn
     */
    public static void setCallCenterAttributeData(CallCenterAttribute callCenterAttribute, String callCenter, String productCode, String rpn) throws Exception {
        cacheWrapper.setApplicationEntry(callCenter + "_" + productCode + "_" + rpn, callCenterAttribute);
    }

    /**
     * Sets the relay lookup flag
     *
     * @param lookupFlag
     * @throws Exception
     */
    public static void setRelayLookupFlag(Boolean lookupFlag) throws Exception {
        cacheWrapper.setApplicationEntry(RELAY_LOOKUP_FLAG, lookupFlag);
    }

    /**
     * Retrieve the relay lookup flag
     *
     * @return relayLookupFlag
     * @throws Exception
     */
    public static Boolean getRelayLookupFlag() throws Exception {
        Boolean relayLookupFlag = true;
        final Object relayLookupFlagObject = cacheWrapper.getEntry(RELAY_LOOKUP_FLAG);
        if (null != relayLookupFlagObject) {
            relayLookupFlag = (Boolean)relayLookupFlagObject;
        }
        return relayLookupFlag;
    }

    public static void setCallCentersDisabledForConcierge(String disabledCallCenters) throws Exception {
        cacheWrapper.setApplicationEntry(CALL_CENTERS_DISABLED_FOR_CONCIERGE, disabledCallCenters);
    }

    public static String getCallCentersDisabledForConcierge() throws Exception {
        String disabledCallCenters = null;
        final Object disabledCallCentersObject = cacheWrapper.getEntry(CALL_CENTERS_DISABLED_FOR_CONCIERGE);
        if (null != disabledCallCentersObject) {
            disabledCallCenters = (String)disabledCallCentersObject;
        }
        return disabledCallCenters;
    }

    public static void removeCallCentersDisabledForConcierge() throws Exception {
        cacheWrapper.removeEntry(CALL_CENTERS_DISABLED_FOR_CONCIERGE);
    }

    /**
     * Retrieve a call center attribute from cache
     *
     * @param callCenter
     * @param productCode
     * @param rpn
     * @return
     */
    public static CallCenterAttribute getCallCenterAttribute(String callCenter, String productCode, String rpn) throws Exception {
        CallCenterAttribute callCenterAttribute = null;

        final Object callCenterAttributeObject = cacheWrapper.getEntry(callCenter + "_" + productCode + "_" + rpn);
        if(null != callCenterAttributeObject) {
            callCenterAttribute = (CallCenterAttribute)callCenterAttributeObject;
        }

        return callCenterAttribute;
    }

    /**
     * This creates the Subject that will be used for static host requests (such as sign-on and some of the old jdbc calls).
     * It is to be used when the current user's credentials are not needed to run the backing host service
     *
     * @param applicationId
     * 		If modelClient is provided then this will be ignored.
     * @param region
     * @param modelClient
     * 		Optional but recommended.
     * 		This the client data to model the static subject off of.
     * 		Things like the RPN, PlanCode, ClientId will be use.
     * 		See DesktopExecutionContextConfigStrategyImpl.java for list or Select Client code.
     * @return
     * @throws Exception
     */
    public static Subject createStaticSubject(String applicationId, String region, ApplicationClient modelClient) throws Exception {

        final Subject subject = SubjectUtils.createEmptySubject();

        SubjectUtils.setSessionId(subject, "STATIC_SUBJECT_SESSION_ID");
        SubjectUtils.setEnvironment(subject, "default");

        final String staticRacfId = JndiUtils.lookupObject(String.class, EnvironmentObjects.STATIC_RACF_ID.getName());
        final String staticRacfPassword = JndiUtils.lookupObject(String.class, EnvironmentObjects.STATIC_RACF_PASSWORD.getName());
        if (StringUtils.isEmpty(region)) {
            region = JndiUtils.lookupObject(String.class, EnvironmentObjects.REGION_DEFAULT.getName());
        }

        final String defaultRpn = JndiUtils.lookupNumericString(EnvironmentObjects.DEFAULT_RPN.getName());
        final String defaultPlanCode = DEFAULT_PLAN_CODE;

        if(log.isTraceEnabled()) {
            log.trace("defaultRpn: " + defaultRpn);
        }

        SubjectUtils.setUserId(subject, RacfIdPrincipal.class, staticRacfId);
        SubjectUtils.setPassword(subject, RacfPasswordCredential.class, staticRacfPassword);
        SubjectUtils.setRegion(subject, region);

        if (null == modelClient) {
            final ApplicationClient client = new ApplicationClient();
            client.setRpn(defaultRpn);
            client.setAliasRpn(defaultRpn);
            client.setPlanCode(defaultPlanCode);
            if (StringUtils.isNotBlank(applicationId)) {
                client.setAppId(applicationId);
            }
            SubjectUtils.setClient(subject, client);
            SubjectUtils.setRPN(subject, defaultRpn);
        } else {
            SubjectUtils.setClient(subject, modelClient.deepClone());
            SubjectUtils.setRPN(subject, modelClient.getRpn());
        }

        return subject;
    }

    /**
     * This creates the Subject that will be used for static host requests (such as sign-on and some of the old jdbc calls).
     * It is to be used when the current user's credentials are not needed to run the backing host service
     *
     * @param applicationId
     * @return
     * @throws Exception
     */
    public static Subject createStaticSubject(String applicationId) throws Exception {
        return createStaticSubject(applicationId, null, null);
    }

    /**
     * Retrieve a map of RULES data type entries associated with environment from cache
     * @return  Map of RULES data type entries associated with environment
     */
    public static HashMap<String, Object> getRulesDataTypeEntries() throws Exception {
        return (HashMap<String, Object>)cacheWrapper.getEntry(RULES_DATA_TYPE_KEY);
    }

    /**
     * Store a map of RULES data type entries associated with environment in cache
     * @param rulesDataTypeEntriesMap Map of RULES data type entries associated with environment
     */
    public static void setRulesDataTypeEntries(HashMap<String, Object> rulesDataTypeEntriesMap) throws Exception {
        if ((null != rulesDataTypeEntriesMap) && !rulesDataTypeEntriesMap.isEmpty()) {
            cacheWrapper.setApplicationEntry(RULES_DATA_TYPE_KEY, rulesDataTypeEntriesMap);
        }
    }

    /**
     * Removes all cached data for the rules data type key
     * @throws Exception
     */
    public static void removeRulesDataTypeEntriesCache() throws Exception {
        cacheWrapper.removeEntry(RULES_DATA_TYPE_KEY);
    }

    public static CacheDataStore getCacheDataStore(HttpServletRequest request) throws Exception {
        return getCacheDataStore(request.getSession(false).getId());
    }
    public static CacheDataStore getCacheDataStore(Subject subject) throws Exception {
        return getCacheDataStore(SubjectUtils.getSessionId(subject));
    }
    public static CacheDataStore getCacheDataStore(String sessionId) throws Exception {
        return CacheDataStore.class.cast(getUserSessionMap(sessionId).get(CacheDataStore.class.getName()));
    }
}
