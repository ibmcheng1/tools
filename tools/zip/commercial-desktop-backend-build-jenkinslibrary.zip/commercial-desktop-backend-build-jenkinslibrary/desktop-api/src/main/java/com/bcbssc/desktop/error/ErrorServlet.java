/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2013 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.error;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.util.DesktopUtil;
import com.bcbssc.desktop.util.StylesheetUtil;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.exception.DataAccessException;
import com.bcbssc.domain.entity.ApplicationClient;
import com.bcbssc.domain.exceptions.WorkManagerProcessFailedException;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.security.auth.Subject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Properties;

/**
 * This is a generic servlet to handle errors and display the error page.
 *
 * @author JC33 X87M
 */
public class ErrorServlet extends HttpServlet {
    private static final long serialVersionUID = -6050846622698232740L;
    private static final Log log = LogFactory.getLog(ErrorServlet.class);

    /**
     * Error message string, passed via attribute or parameter.
     */
    public static final String REQUEST_KEY_MESSAGE = "javax.servlet.error.message";

    /**
     * An unique identifier for the error or just a classification of the error.
     * Integer object if passed via attribute or Integer parsible string if by parameter.
     */
    public static final String REQUEST_KEY_STATUS_CODE = "javax.servlet.error.status_code";

    /**
     * If passed via attribute then throwable object that was caught else if passed by parameter then the class name of the exception caught.
     */
    public static final String REQUEST_KEY_EXCEPTION = "javax.servlet.error.exception";

    /**
     * The result of the caught exception's toString method, only passed by parameter.
     */
    public static final String REQUEST_KEY_EXCEPTION_TO_STRING = "javax.servlet.error.exception.to.string";

    /**
     * The URI or component name that the error originated from, passed via attribute or parameter.
     */
    public static final String REQUEST_KEY_REQUEST_URI = "javax.servlet.error.request_uri";

    /**
     * The message to use when we weren't given the data.
     */
    public static final String UNKNOWN_EXCEPTION_MESSAGE = "An unknown exception happened, but the details were not passed to the ErrorServlet";
    
    protected class ErrorData {
        /** Required. */
        private String exceptionClassName;
        /** Required. */
        private String exceptionToString;
        /** Required. */
        private String exceptionTypeClassName;
        /** Optional, may be null. */
        private Integer statusCode;
        /** Required. */
        private String message;
        /** Required. */
        private String requestUri;
        /** Optional. */
        private String applicationId;
        /** Required. */
        private Throwable exception;

        public Throwable getException() {
            return exception;
        }
        public void setException(Throwable exception) {
            this.exception = exception;
        }
        public String getExceptionClassName() {
            return this.exceptionClassName;
        }
        public void setExceptionClassName(String exceptionClassName) {
            this.exceptionClassName = exceptionClassName;
        }
        public String getExceptionToString() {
            return this.exceptionToString;
        }
        public void setExceptionToString(String exceptionToString) {
            this.exceptionToString = exceptionToString;
        }
        public String getExceptionTypeClassName() {
            return this.exceptionTypeClassName;
        }
        public void setExceptionTypeClassName(String exceptionTypeClassName) {
            this.exceptionTypeClassName = exceptionTypeClassName;
        }
        public Integer getStatusCode() {
            return this.statusCode;
        }
        public void setStatusCode(Integer statusCode) {
            this.statusCode = statusCode;
        }
        public String getMessage() {
            return this.message;
        }
        public void setMessage(String message) {
            this.message = message;
        }
        public String getRequestUri() {
            return this.requestUri;
        }
        public void setRequestUri(String requestUri) {
            this.requestUri = requestUri;
        }
        public String getApplicationId() {
            return this.applicationId;
        }
        public void setApplicationId(String applicationId) {
            this.applicationId = applicationId;
        }
    }

    /* @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse) */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
			handleRequest(request, response);
		} catch (RuntimeException e) {
			throw e;
		} catch (ServletException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} catch (Throwable t) {
			throw new RuntimeException(t);
		}
    }

    /* @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse) */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
			handleRequest(request, response);
		} catch (RuntimeException e) {
			throw e;
		} catch (ServletException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} catch (Throwable t) {
			throw new RuntimeException(t);
		}
    }

    /**
     * Checks if the type of exception is {@link DataAccessException} or {@link WorkManagerProcessFailedException} and return 
     * the throwable object to display on the error page.
     * 
     * @param exception
     *      The exception object passed to this servlet, may be null.
     * @return
     *      The throwable object to display on the error page.
     *      If the given exception is null then it will default to a generic exception.
     */
    protected Throwable getExceptionToWrite(Throwable exception) {
        Throwable exceptionToWrite;
        int exceptionIndex = ExceptionUtils.indexOfType(exception, DataAccessException.class);
        int workMangerProcessFailedExceptionIndex = ExceptionUtils.indexOfType(exception, WorkManagerProcessFailedException.class);
        if(exceptionIndex > -1){
            exceptionToWrite = ExceptionUtils.getThrowables(exception)[exceptionIndex];
        } else if(workMangerProcessFailedExceptionIndex > -1){
               exceptionToWrite = ExceptionUtils.getThrowables(exception)[workMangerProcessFailedExceptionIndex];
        } else{
            exceptionToWrite = exception;
        }
        
        if (null == exceptionToWrite) {
            exceptionToWrite = new RuntimeException(UNKNOWN_EXCEPTION_MESSAGE);
        }
        return exceptionToWrite;
    }

    /**
     * Attempts to get the error data from the given request's attributes.
     *
     * @return
     *      The populated error data object or null if no data was on the request's attributes.
     */
    private ErrorData getErrorDataFromAttributes(HttpServletRequest request) {
        ErrorData errorData = null;

        // If we don't have the exception class then assume we don't have the rest and return null.
        Throwable exception = (Throwable) request.getAttribute(REQUEST_KEY_EXCEPTION);
        if (null != exception) {
            // Sanitize the exception we were given.
            Throwable exceptionToWrite = this.getExceptionToWrite(exception);

            //First, let's log the error
            log.error("An error has occurred processing the requested web application", exceptionToWrite);

            String exceptionClassName = exceptionToWrite.getClass().getName();
            String exceptionToString = exceptionToWrite.toString();
            Integer statusCode = (Integer) request.getAttribute(REQUEST_KEY_STATUS_CODE);
            String message = (String) request.getAttribute(REQUEST_KEY_MESSAGE);
            String requestUri = (String) request.getAttribute(REQUEST_KEY_REQUEST_URI);

            errorData = new ErrorData();
            errorData.setExceptionClassName(exceptionClassName);
            errorData.setExceptionToString(exceptionToString);
            errorData.setExceptionTypeClassName(exceptionClassName);
            errorData.setStatusCode(statusCode);
            errorData.setMessage(message);
            errorData.setRequestUri(requestUri);
            errorData.setException(exceptionToWrite);
        }
        return errorData;

    }

    /**
     * Attempts to get the error data from the given request's parameters.
     *
     * @return
     *      The populated error data object or null if no data was on the request's parameters.
     */
    private ErrorData getErrorDataFromParameters(HttpServletRequest request) {
        ErrorData errorData = null;

        // If we don't have the exception class then assume we don't have the rest and return null.
        String exceptionClassName = request.getParameter(REQUEST_KEY_EXCEPTION);
        if (StringUtils.isNotBlank(exceptionClassName)) {
            String exceptionToString = request.getParameter(REQUEST_KEY_EXCEPTION_TO_STRING);

            Integer statusCode = null;
            String statusCodeString = request.getParameter(REQUEST_KEY_STATUS_CODE);
            if (StringUtils.isNotBlank(statusCodeString) && StringUtils.isNumeric(statusCodeString)) {
                statusCode = Integer.valueOf(statusCodeString);
            }

            String message = request.getParameter(REQUEST_KEY_MESSAGE);

            String requestUri = request.getParameter(REQUEST_KEY_REQUEST_URI);

            errorData = new ErrorData();
            errorData.setExceptionClassName(exceptionClassName);
            errorData.setExceptionToString(exceptionToString);
            errorData.setExceptionTypeClassName(exceptionClassName);
            errorData.setStatusCode(statusCode);
            errorData.setMessage(message);
            errorData.setRequestUri(requestUri);
            errorData.setException(null);
        }
        return errorData;
    }

    /**
     * Creates the default error data.
     *
     * @return
     *      The default error data.
     */
    private ErrorData getErrorDataFromDefaults() {
        Throwable exceptionToWrite = new RuntimeException(UNKNOWN_EXCEPTION_MESSAGE);

        ErrorData defaultErrorData = new ErrorData();
        defaultErrorData.setExceptionClassName(exceptionToWrite.getClass().getName());
        defaultErrorData.setExceptionToString(exceptionToWrite.toString());
        defaultErrorData.setExceptionTypeClassName(exceptionToWrite.getClass().getName());
        defaultErrorData.setStatusCode(null);
        defaultErrorData.setException(null);
        defaultErrorData.setMessage(UNKNOWN_EXCEPTION_MESSAGE);
        defaultErrorData.setRequestUri(UNKNOWN_EXCEPTION_MESSAGE);

        return defaultErrorData;
    }

    protected ErrorData getErrorData(HttpServletRequest request) throws Exception {
        // Get the error data from where ever.
        ErrorData errorData = getErrorDataFromAttributes(request);
        if (null == errorData) {
            errorData = getErrorDataFromParameters(request);
        }
        if (null == errorData) {
            errorData = getErrorDataFromDefaults();
        }

        // Get the desktop that the user is running.
        Subject subject = DesktopAPI.getUserSubject(request.getSession().getId());
        if (null != subject) {
            ApplicationClient client = SubjectUtils.getClient(subject);
            if (null != client) {
                String applicationId = SubjectUtils.getClient(subject).getAppId();
                errorData.setApplicationId(applicationId);
            }
        }

        return errorData;
    }

    /**
     * Gets the error information from the request and creates the error page.
     *
     * @param request The request.
     * @param response The response.
     * @throws IOException
     *      If there is a problem writing out the error page.
     */
    private void handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ErrorData errorData = getErrorData(request);
        String exceptionClassName = errorData.getExceptionClassName();
        String exceptionToString = errorData.getExceptionToString();
        String exceptionTypeClassName = errorData.getExceptionTypeClassName();
        Integer statusCode = errorData.getStatusCode();
        String message = errorData.getMessage();
        String requestUri = errorData.getRequestUri();
        String applicationId = errorData.getApplicationId();
        Throwable exceptionToThrow = null;
        Class exceptionClass = null;
        if(errorData.getException() != null){
            exceptionToThrow = errorData.getException();
            exceptionClass = exceptionToThrow.getClass();
        }
        
        //Get the list of exceptinos from the properties files.
        InputStream inputStream = DesktopUtil.class.getResourceAsStream("/com/bcbssc/desktop/resource/GlobalMessages.properties");
        Properties propertiesFile = new Properties();
        propertiesFile.load(inputStream);
             
        //
        // The servlet should write directly to the response output stream instead of forwarding 
        // to a jsp, that way all of the logic is contained within this one class, and no other files 
        // have to be propagated to all of the attached apps.
        //
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        //If the exception should not have a ticket generated by CEM 
        //then set the status code to be 200
        MonitorFlags monitorFlagEnum = ErrorPageCreator.getMonitorFlagEnum(propertiesFile,exceptionClassName);
        if(log.isDebugEnabled()) {
            log.debug("The monitor flag for this exception is:  " + monitorFlagEnum.toString());
        }
        if(monitorFlagEnum != null) {
            if(monitorFlagEnum.equals(MonitorFlags.MONITOR_TICKET_NONE)){
                response.setStatus(HttpServletResponse.SC_OK);
            }
        }
        
        // The error reason is either the status code or the exception type
        String reason = exceptionClassName;
        if (null != statusCode) {
            reason = statusCode.toString();
        }

        out.println("<html>");
        out.println("<head><title>" + reason + ": " + message + "</title>");
        out.println(StylesheetUtil.getStylesheetLinks());
        out.println("</head>");
        out.print("<body");
        if (StringUtils.isNotBlank(applicationId)) {
            out.print(" class=\"" + applicationId + "\"");
        }
        out.println(">");
        //if we have the actual exception object, pass it
        if(exceptionToThrow != null){
            out.println(ErrorPageCreator.getErrorBody(exceptionToThrow, exceptionClass, statusCode, message, requestUri));
        } else{
            out.println(ErrorPageCreator.getErrorBody(exceptionClassName, exceptionToString, exceptionTypeClassName, statusCode, message, requestUri));
          }
        out.println("</body>");
        out.println("</html>");
    }
}
