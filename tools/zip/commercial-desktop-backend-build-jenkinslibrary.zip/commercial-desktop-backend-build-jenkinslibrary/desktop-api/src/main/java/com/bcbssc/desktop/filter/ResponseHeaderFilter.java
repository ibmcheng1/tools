/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * ResponseHeaderFilter.java
 * 
 * Created on Oct 15, 2010, 3:15:22 PM by JM28
 */
package com.bcbssc.desktop.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

/**
 * Filter that adds meta information to the response header.
 * This meta information can be used to control browser caching,
 * browser compatibility level, etc.
 *
 */
public class ResponseHeaderFilter implements Filter {

    private static final String INTERNET_EXPLORER_COMPATIBILITY_PARAMETER = "X-UA-Compatible";
    private String internetExplorerCompatibility = "IE=EmulateIE7";

    /* @see javax.servlet.Filter#destroy() */
    @Override
    public void destroy() {
        //Unimplemented
    }

    /* @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain) */
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletResponse httpServletResponse = (HttpServletResponse) response;
        httpServletResponse.addHeader(INTERNET_EXPLORER_COMPATIBILITY_PARAMETER, internetExplorerCompatibility);
        chain.doFilter(request, httpServletResponse);
    }

    /* @see javax.servlet.Filter#init(javax.servlet.FilterConfig) */
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        //If we have a value set in the filter config, use it
        String internetExplorerCompatibilityValue = filterConfig.getInitParameter(INTERNET_EXPLORER_COMPATIBILITY_PARAMETER);
        if (StringUtils.isNotBlank(internetExplorerCompatibilityValue)) {
            internetExplorerCompatibility = internetExplorerCompatibilityValue;
        }
    }

}
