/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF BLUE CROSS BLUE SHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.
 * ANY UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2016 BLUE CROSS BLUE SHIELD OF SOUTH CAROLINA.
 * ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.attached;

/**
 * The list of Base Desktop owned / controlled attached web applications (also called pop-ups or non-portlets).
 * Note that the URL defined in the enum may be modified by one of the attached app helpers or utils.
 *
 * @see com.bcbssc.desktop.attached.helper.DesktopAttachedAppHelper
 * @see com.bcbssc.desktop.attached.DesktopAttachedApplicationUtils
 * @author X87M
 * @deprecated The functionality from this class should move to the frontend.
 */
public enum DesktopAttachedApps {
}
