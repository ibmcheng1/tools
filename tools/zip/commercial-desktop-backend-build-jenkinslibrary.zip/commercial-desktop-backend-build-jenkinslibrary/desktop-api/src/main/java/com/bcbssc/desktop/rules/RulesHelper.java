/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.rules;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * This class purpose is to replace the tokens that are received 
 * from the rules in emulator transaction strings to actual values
 * that will be used in the transactions sent to the emulator
 * @deprecated This functionality should be moved somewhere else.
 */
public class RulesHelper {


    private static final Log log = LogFactory.getLog(RulesHelper.class);

    /**
     * Formats the birthdate into a string usable in transactions. This will handle dates in either
     * of the following formats:
     *     - MM/dd/yyyy
     *     - MM/yyyy
     * 
     * If the provided birthdate is null or empty string, this will return an empty string.
     * 
     * @param dateFormatter The formatter to use to format the end result
     * @param birthdate The birthdate that needs to be formatted
     * @return Empty string if the provided birthdate is invalid or a string representation 
     * of the birthdate in the specified format
     */
    protected static String extractSubscriberBirthdate(SimpleDateFormat dateFormatter, String birthdate) {
        String dateOfBirthString = StringUtils.EMPTY;
        if (null != birthdate) {
            try {
                Calendar dateOfBirth = Calendar.getInstance();
                //fetch and reformat date-of-birth
                //MM/dd/yyyy or MM/yyyy
                String[] datePieces = birthdate.split("/");
                int datePiecesLength = datePieces.length;
                // make sure we were able to parse out the pieces and that there are at least two elements
                if (null != datePieces && datePiecesLength > 1) {
                    dateOfBirth.set(Calendar.MONTH, Integer.parseInt(datePieces[0]) - 1);
                    // if there are 3 pieces, then we have a full date
                    if (datePiecesLength > 2) {
                        dateOfBirth.set(Calendar.DAY_OF_MONTH, Integer.parseInt(datePieces[1]));
                        dateOfBirth.set(Calendar.YEAR, Integer.parseInt(datePieces[2]));
                    } else {
                        dateOfBirth.set(Calendar.YEAR, Integer.parseInt(datePieces[1]));
                        // we have no month, set the day of month to the first...
                        dateOfBirth.set(Calendar.DAY_OF_MONTH, 1);
                    }
                    dateOfBirthString = dateFormatter.format(dateOfBirth.getTime());
                }
            } catch (NumberFormatException e) {
                log.warn("Failed to parse subscriber's birthDate [" + birthdate + "]");
            }
        }
        return dateOfBirthString;
    }
}
