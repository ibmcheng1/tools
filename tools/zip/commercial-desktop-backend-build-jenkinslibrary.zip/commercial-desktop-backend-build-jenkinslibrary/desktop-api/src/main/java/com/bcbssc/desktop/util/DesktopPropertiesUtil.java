/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2015 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * This is a convenience class to load property files into memory.  Calling methods should only read data from the properties objects
 */
public final class DesktopPropertiesUtil {
    private static Log log = LogFactory.getLog(DesktopPropertiesUtil.class);
    private static Properties desktopDialogsProperties;
    private static Properties globalMessagesProperties;

    static {
        desktopDialogsProperties = loadProperties("/com/bcbssc/desktop/resource/DesktopDialogs.properties");
        globalMessagesProperties = loadProperties("/com/bcbssc/desktop/resource/GlobalMessages.properties");
    }

    /**
     * Helper method; Loads a resource and puts it into a properties object
     * 
     * @param resourceLocation
     * @return
     */
    private static Properties loadProperties(String resourceLocation) {
        Properties props = null;
        InputStream in = null;
        try {
            in = DesktopPropertiesUtil.class.getResourceAsStream(resourceLocation);
            try {
                props = new Properties();
                props.load(in);
            } catch (IOException ioException) {
                log.error("Unable to load DesktopDialogs.properties file!", ioException);
            }
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException ioException) {
                    log.error("Unable to close inputstream!", ioException);
                }
            }
        }

        return props;
    }

    /**
     * Gets the desktop dialogs properties
     * 
     * @return
     */
    public static Properties getDesktopDialogsProperties() {
        return desktopDialogsProperties;
    }

    /**
     * Gets the desktop global messages
     * 
     * @return
     */
    public static Properties getGlobalMessagesProperties() {
        return globalMessagesProperties;
    }
}
