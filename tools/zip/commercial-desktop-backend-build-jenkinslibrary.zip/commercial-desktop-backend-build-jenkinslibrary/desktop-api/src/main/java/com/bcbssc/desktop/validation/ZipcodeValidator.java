/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * ZipcodeValidator.java
 */
package com.bcbssc.desktop.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import com.bcbssc.desktop.jsf.JSFContextHelper;

/**
 * This class is used to validate that the zipcode being entered
 * is in a valid zipcode format.
 * 
 * @author x95f
 *
 */
public class ZipcodeValidator implements Validator {
    private static final Pattern PATTERN = Pattern.compile("^(\\d{5})[- ]?(\\d{4})?$");

    /**
     * Checks to see if the value submitted is in a valid zipcode format and 
     * if it is not sets a Faces error message, if it is a valid format then it does nothing
     */
    public void validate(FacesContext arg0, UIComponent arg1, Object value) throws ValidatorException {
        String valueentered = (String) value;

        /* Check to see if the value is a valid email id */
        Matcher matcher = PATTERN.matcher(valueentered);

        if (!matcher.matches()) {
            String text = JSFContextHelper.getResourceMessage("zipcode.invalid");
            //LoggerFactory.getTraceLogger().info(text);
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, text, text);

            arg0.addMessage(arg1.getClientId(arg0), message);
        }
    }

}
