/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * XMLStringBuilderTest.java
 * 
 * Created on Nov 4, 2009, 10:42:29 AM by JC33
 */
package com.bcbssc.domain.annotations;

import junit.framework.TestCase;

/**
 * JUnit test to test the xml annotation code and the XMLStringBuilder
 *
 * <pre>
 * [Harvest]
 * </pre>
 * 
 * @author $Author$  (original: JC33)
 * @version $Revision$
 */
public class XMLStringBuilderTest extends TestCase {

    /**
     * @param name
     */
    public XMLStringBuilderTest(String name) {
        super(name);
    }

    /**
     * Test method for {@link com.bcbssc.domain.annotations.XMLStringBuilder#toString(java.lang.Object)}.
     */
    public void testToStringObject() {
        TestXMLClass test = new TestXMLClass();
        test.setField1("Field 1 Value");
        test.setField2(new Integer(2));
        test.setField3(Boolean.TRUE);
        test.setField4(new ComplexType());
        
        String toString = test.toString();
        
        assertNotNull(toString);
        
        String testToString = "<testRoot xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n    <field1><![CDATA[FIELD 1 VALUE]]></field1>\n    <field2><![CDATA[2]]></field2>\n    <field3><![CDATA[TRUE]]></field3>\n    <field4><![CDATA[<COMPLEXROOT XMLNS:XSI=\"HTTP://WWW.W3.ORG/2001/XMLSCHEMA-INSTANCE\">\n    <COMPLEX1 XSI:NIL=\"TRUE\"/>\n    <COMPLEX2 XSI:NIL=\"TRUE\"/>\n</COMPLEXROOT>]]></field4>\n</testRoot>";
        assertEquals(testToString, toString);
    }

    /**
     * Tests the nillable and required attributes of the XMLElement annotation.
     */
    public void testXmlElementAnnotation() {
        /*
         * If a field is marked as not required but not nillable then the field shouldn't show up at all (field1)
         * 
         * If a field is marked as required and not nillable then the field should show up as empty (field2 and field4)
         * 
         * If a field is marked as not required and nillable then the field should show up as nil (field3)
         */
        TestXMLClass test = new TestXMLClass();
        
        String toString = test.toString();
        
        assertNotNull(toString);
        
        String testToString = "<testRoot xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n    <field2></field2>\n    <field3 xsi:nil=\"true\"/>\n    <field4></field4>\n</testRoot>";
        assertEquals(testToString, toString);
    }
    
    @XMLRoot(name="testRoot")
    private class TestXMLClass {
        
        @XMLElement(name="field1", required=false)
        private String field1;
        @XMLElement(name="field2")
        private Integer field2;
        @XMLElement(name="field3", nillable=true, required=false)
        private Boolean field3;
        @XMLElement(name="field4")
        private ComplexType field4;
        
        /**
         * @return the field1
         */
        public String getField1() {
            return field1;
        }
        /**
         * @param field1 the field1 to set
         */
        public void setField1(String field1) {
            this.field1 = field1;
        }
        /**
         * @return the field2
         */
        public Integer getField2() {
            return field2;
        }
        /**
         * @param field2 the field2 to set
         */
        public void setField2(Integer field2) {
            this.field2 = field2;
        }
        /**
         * @return the field3
         */
        public Boolean getField3() {
            return field3;
        }
        /**
         * @param field3 the field3 to set
         */
        public void setField3(Boolean field3) {
            this.field3 = field3;
        }
        /**
         * @return the field4
         */
        public ComplexType getField4() {
            return field4;
        }
        /**
         * @param field4 the field4 to set
         */
        public void setField4(ComplexType field4) {
            this.field4 = field4;
        }

        @Override
        public String toString() {
            return XMLStringBuilder.toString(this);
        }
        
    }
    
    @XMLRoot(name="complexRoot")
    private class ComplexType {

        @XMLElement(name="complex1", required=false, nillable=true)
        private String complex1;
        @XMLElement(name="complex2", required=false, nillable=true)
        private String complex2;
        
        /**
         * @return the complex1
         */
        public String getComplex1() {
            return complex1;
        }
        /**
         * @param complex1 the complex1 to set
         */
        public void setComplex1(String complex1) {
            this.complex1 = complex1;
        }
        /**
         * @return the complex2
         */
        public String getComplex2() {
            return complex2;
        }
        /**
         * @param complex2 the complex2 to set
         */
        public void setComplex2(String complex2) {
            this.complex2 = complex2;
        }

        @Override
        public String toString() {
            return XMLStringBuilder.toString(this);
        }
    }

}
