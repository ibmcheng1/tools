/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * XMLStringBuilder.java
 * 
 * Created on Oct 26, 2009, 11:17:07 AM by HX20
 */
package com.bcbssc.domain.annotations;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Helper class to generate the XML string from a class that uses the XMLElement and XMLRoot annotations.
 *
 * <pre>
 * [Harvest]
 * </pre>
 * 
 * @author $Author$  (original: HX20)
 * @version $Revision$
 */
public class XMLStringBuilder {
    
    private static final Log log = LogFactory.getLog(XMLStringBuilder.class);

    /**
     * Takes an object with the XMLRoot annotation, and converts it to an XML
     * String. If the object does not contain the XMLRoot annotation, an empty
     * string is returned.
     * 
     * @param object
     *            the object to convert
     * @return The XML String representation of object
     */
    static public String toString(Object object) {
        StringBuilder builder = new StringBuilder();
        Class<?> clazz = object.getClass();
        PropertyDescriptor[] descriptors = getPropertyDescriptors(clazz);
        Field[] fields = clazz.getDeclaredFields();
        Method[] methods = clazz.getDeclaredMethods();

        if (clazz.isAnnotationPresent(XMLRoot.class)) {
            XMLRoot rootAnnotation = clazz.getAnnotation(XMLRoot.class);
            builder.append("<").append(rootAnnotation.name()).append(
                    " xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">").append("\n");

            for (Field field : fields) {

                if (field.isAnnotationPresent(XMLElement.class)) {
                    XMLElement fieldAnnotation = field.getAnnotation(XMLElement.class);

                    Method getterMethod = findGetterMethod(descriptors, field);
                    buildXMLElement(object, builder, fieldAnnotation, getterMethod);
                }
            }
            
            for (Method method: methods) {
                if (method.isAnnotationPresent(XMLElement.class)) {
                    XMLElement methodAnnotation = method.getAnnotation(XMLElement.class);
                    
                    buildXMLElement(object, builder, methodAnnotation, method);
                }
            }
            builder.append("</").append(rootAnnotation.name()).append(">");
        }
        return builder.toString();
    }

    /**
     * @param object
     * @param builder
     * @param annotatedObject
     * @param getterMethod
     */
    private static void buildXMLElement(Object object, StringBuilder builder, XMLElement annotatedObject,
            Method getterMethod) {
        String value = invokeGetterMethod(object, getterMethod);

        if (!StringUtils.isBlank(value)) {
            builder.append("    <").append(annotatedObject.name()).append(">");
            if (annotatedObject.cdata()) {
                builder.append("<![CDATA[");
            }
            if (annotatedObject.useUpperCase()) {
                value = value.toUpperCase();
            }            
            builder.append(value);
            if (annotatedObject.cdata()) {
                builder.append("]]>");
            }
            builder.append("</").append(annotatedObject.name()).append(">").append("\n");
        } else if (annotatedObject.nillable()) {
            builder.append("    <").append(annotatedObject.name()).append(" xsi:nil=\"true\"").append("/>")
                    .append("\n");
        } else if (annotatedObject.required()) {
            builder.append("    <").append(annotatedObject.name()).append(">").append("</").append(
                    annotatedObject.name()).append(">").append("\n");
        }
    }

    static private PropertyDescriptor[] getPropertyDescriptors(Class<?> clazz) {
        PropertyDescriptor[] descriptors = new PropertyDescriptor[0];
        BeanInfo beanInfo;
        try {
            beanInfo = Introspector.getBeanInfo(clazz);
            descriptors = beanInfo.getPropertyDescriptors();
        } catch (IntrospectionException e) {
            log.error("There was an exception attempting to get the bean information", e);
        }
        return descriptors;
    }

    static private Method findGetterMethod(PropertyDescriptor[] descriptors, Field field) {
        Method getterMethod = null;
        for (PropertyDescriptor descriptor : descriptors) {
            if (descriptor.getName().equals(field.getName())) {
                getterMethod = descriptor.getReadMethod();
                break;
            }
        }
        return getterMethod;
    }

    static private String invokeGetterMethod(Object object, Method getterMethod) {
        String stringValue = null;

        if (null != getterMethod) {
            try {
                Object value = getterMethod.invoke(object, (Object[]) null);
                if (null != value) {
                    stringValue = String.valueOf(value);
                }
            } catch (Exception e) {
                log.error("There was an exception attempting to invoke the getter method" + getterMethod.getName() + ": " , e);
            }
        }

        return stringValue;
    }

}
