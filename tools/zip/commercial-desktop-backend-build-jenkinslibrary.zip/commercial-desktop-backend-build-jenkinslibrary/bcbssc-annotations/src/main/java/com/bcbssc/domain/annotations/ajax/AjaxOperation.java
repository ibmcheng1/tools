/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * AjaxOperation.java
 * 
 * Created on Sep 24, 2010, 11:47:10 AM by JC33
 */
package com.bcbssc.domain.annotations.ajax;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * This annotation is used to denote methods that are to be used to process ajax operations.
 * An example is that a method definition could look like...
 * 
 * &#64;AjaxOperation(name = "myCustomOperation")
 * protected void performOperation(HttpServletRequest request, HttpServletResponse response) {
 *     // do something
 * }
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface AjaxOperation {
    
    /**
     * The name of the operation.
     * @return The name of the operation.
     */
    String name();
}
