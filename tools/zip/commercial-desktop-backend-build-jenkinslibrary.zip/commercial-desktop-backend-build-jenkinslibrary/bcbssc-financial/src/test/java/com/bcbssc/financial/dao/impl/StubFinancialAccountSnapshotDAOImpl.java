/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.financial.dao.impl;

import java.math.BigDecimal;
import java.util.Date;

import com.bcbssc.financial.dao.FinancialAccountSnapshotDAO;
import com.bcbssc.financial.model.FinancialAccountSnapshot;
import com.bcbssc.model.subscriber.Subscriber;

/**
* Generic stub for FinancialAccountSnapshotDAO
*
*/
public class StubFinancialAccountSnapshotDAOImpl implements
        FinancialAccountSnapshotDAO {

    /* (non-Javadoc)
     * @see com.bcbssc.financial.dao.FinancialAccountSnapshotDAO#retrieveAccountSnapshot()
     */
    public FinancialAccountSnapshot retrieveAccountSnapshot(Subscriber subscriber) {
        FinancialAccountSnapshot snapshot = new FinancialAccountSnapshot();
        snapshot.setAccountNumber("12340-STUB");
        snapshot.setBalance(new BigDecimal("3000.00"));
        snapshot.setClaimPaymentConsent(true);
        snapshot.setLastUpdated(new Date());
        return snapshot;
    }

}
