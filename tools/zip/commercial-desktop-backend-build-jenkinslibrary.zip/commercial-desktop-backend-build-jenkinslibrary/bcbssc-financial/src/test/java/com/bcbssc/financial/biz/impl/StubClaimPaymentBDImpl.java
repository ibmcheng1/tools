/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.financial.biz.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.bcbssc.financial.biz.ClaimPaymentBD;
import com.bcbssc.financial.model.ClaimPayment;
import com.bcbssc.financial.model.ClaimPaymentReceipt;
import com.bcbssc.financial.model.PaymentSystemAvailability;
import com.bcbssc.financial.model.PaymentSystemAvailabilityCriteria;

/**
 * Test stub implementation for ClaimPaymentBD
 *
 */
public class StubClaimPaymentBDImpl implements ClaimPaymentBD {

    /* (non-Javadoc)
     * @see com.bcbssc.financial.biz.ClaimPaymentBD#submitClaimPayment(com.bcbssc.financial.model.ClaimPayment)
     */
    public ClaimPaymentReceipt submitClaimPayment(ClaimPayment payment) {
        ClaimPaymentReceipt receipt = new ClaimPaymentReceipt();

        receipt.setBankErrorCode("");
        receipt.setBankErrorDescription("");
        receipt.setTransactionDate(new Date());
        receipt.setReferenceNumber("123456789");
        receipt.setAmountPaid(payment.getPaymentAmount());
        receipt.setReturnCode("S");

        return receipt;
    }

    public ClaimPaymentReceipt retrieveLatestClaimPaymentReceipt(ClaimPayment payment) {
        if (null == payment.getPaymentAmount()) {
            payment.setPaymentAmount(new BigDecimal("100.00"));
        }
        return submitClaimPayment(payment);
    }

    public List retrieveClaimPaymentReceipts(ClaimPayment payment) {
        List list = new ArrayList();
        list.add(retrieveLatestClaimPaymentReceipt(payment));
        return list;
    }

    public PaymentSystemAvailability getSystemAvailability(PaymentSystemAvailabilityCriteria paymentSystemAvailabilityCriteria) {
        PaymentSystemAvailability avail = new PaymentSystemAvailability();
        avail.setPaymentEnabled(true);
        avail.setPaymentSystemStatus("GREEN"); //?
        return avail;
    }

}
