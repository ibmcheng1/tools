/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.dao.impl;

import com.bcbssc.financial.model.ClaimPaymentReceiptSummary;
import com.bcbssc.financial.model.ReceiptSummarySearchCriteria;
import com.bcbssc.model.ClientBusinessSectorCode;
import com.bcbssc.model.subscriber.Subscriber;
import com.bcbssc.services.cdhpreceiptlist.ArrayOfCDHPReceiptListReceiptData;
import com.bcbssc.services.cdhpreceiptlist.CDHPReceiptListInput;
import com.bcbssc.services.cdhpreceiptlist.CDHPReceiptListOutput;
import com.bcbssc.services.cdhpreceiptlist.CDHPReceiptListReceiptData;
import com.bcbssc.services.cdhpreceiptlist.CDHPReceiptListService;
import junit.framework.TestCase;
import org.apache.commons.lang.StringUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * Test class for WebServiceReceiptSummaryDAOImpl
 *
 */
public class WebServiceReceiptSummaryDAOImplTest extends TestCase {
    private WebServiceReceiptSummaryDAOImpl objectUnderTest;

    @Override
    protected void setUp() throws Exception {
        this.objectUnderTest = new WebServiceReceiptSummaryDAOImpl() {
            @Override
            public WebServiceReceiptSummaryPagingResult consumeService(ReceiptSummarySearchCriteria input) {
                CDHPReceiptListInput serviceInput = mapInput(input);
                return mapOutput((new StubCDHPReceiptList()).getReceiptListing(serviceInput));
            }
        };
        super.setUp();
    }

    public void test_retrieveClientPaymentReceiptSummary_singlePage() {
        ReceiptSummarySearchCriteria criteria = new ReceiptSummarySearchCriteria();
        Calendar fromCal = new GregorianCalendar(2008, 0, 31);
        Calendar toCal = new GregorianCalendar(2008, 1, 28);
        ClientBusinessSectorCode clientBusinessSectorCode = new ClientBusinessSectorCode();
        clientBusinessSectorCode.setRpn("001");
        criteria.setClientBusinessSectorCode(clientBusinessSectorCode);
        criteria.setFromDate(fromCal.getTime());
        criteria.setToDate(toCal.getTime());
        criteria.setRetrieveVoided(true);
        criteria.setStatusFilter("SDI");
        Subscriber subscriber = new Subscriber();
        subscriber.setDatabaseNumber("117099001");
        criteria.setSubscriber(subscriber);

        List results = objectUnderTest.retrieveClientPaymentReceiptSummary(criteria);

        assertEquals(377, results.size());
    }

    public void test_retrieveClientPaymentReceiptSummary_multiPage() {
        ReceiptSummarySearchCriteria criteria = new ReceiptSummarySearchCriteria();
        Calendar fromCal = new GregorianCalendar(2008, 0, 31);
        Calendar toCal = new GregorianCalendar(2008, 1, 28);
        ClientBusinessSectorCode clientBusinessSectorCode = new ClientBusinessSectorCode();
        clientBusinessSectorCode.setRpn("001");
        criteria.setClientBusinessSectorCode(clientBusinessSectorCode);
        criteria.setFromDate(fromCal.getTime());
        criteria.setToDate(toCal.getTime());
        criteria.setRetrieveVoided(true);
        criteria.setStatusFilter("SDI");
        Subscriber subscriber = new Subscriber();
        subscriber.setDatabaseNumber("117099002");
        criteria.setSubscriber(subscriber);

        List results = objectUnderTest.retrieveClientPaymentReceiptSummary(criteria);

        // Should return 4 pages worth of data.
        assertEquals(4 * 377, results.size());
    }

    public void test_mapCriteriaToInput() {
        ReceiptSummarySearchCriteria criteria = new ReceiptSummarySearchCriteria();
        Calendar fromCal = new GregorianCalendar(2008, 0, 31);
        Calendar toCal = new GregorianCalendar(2008, 1, 28);
        ClientBusinessSectorCode clientBusinessSectorCode = new ClientBusinessSectorCode();
        clientBusinessSectorCode.setRpn("001");
        criteria.setClientBusinessSectorCode(clientBusinessSectorCode);
        criteria.setFromDate(fromCal.getTime());
        criteria.setToDate(toCal.getTime());
        criteria.setRetrieveVoided(true);
        criteria.setStatusFilter("SDI");
        Subscriber subscriber = new Subscriber();
        subscriber.setDatabaseNumber("117099001");
        criteria.setSubscriber(subscriber);

        CDHPReceiptListInput input = new CDHPReceiptListInput();
        objectUnderTest.mapCriteriaToInput(criteria, input);

        assertEquals("001", input.getRpn());
        assertEquals("01312008", input.getReceiptFromDate());
        assertEquals("02282008", input.getReceiptToDate());
        assertEquals("SDI", input.getReceiptStatusIndicator());
        assertEquals("117099001", input.getSubscriberId());
        assertEquals("Y", input.getVoidIndicator());
    }

    public void test_mapCriteriaToInput2() {
        ReceiptSummarySearchCriteria criteria = new ReceiptSummarySearchCriteria();
        Calendar fromCal = new GregorianCalendar(2008, 0, 31);
        Calendar toCal = new GregorianCalendar(2008, 1, 28);
        ClientBusinessSectorCode clientBusinessSectorCode = new ClientBusinessSectorCode();
        clientBusinessSectorCode.setRpn("001");
        criteria.setClientBusinessSectorCode(clientBusinessSectorCode);
        criteria.setFromDate(fromCal.getTime());
        criteria.setToDate(toCal.getTime());
        criteria.setRetrieveVoided(false);
        criteria.setStatusFilter(null);
        Subscriber subscriber = new Subscriber();
        subscriber.setDatabaseNumber("117099001");
        criteria.setSubscriber(subscriber);

        CDHPReceiptListInput input = new CDHPReceiptListInput();
        objectUnderTest.mapCriteriaToInput(criteria, input);

        assertEquals("001", input.getRpn());
        assertEquals("01312008", input.getReceiptFromDate());
        assertEquals("02282008", input.getReceiptToDate());
        assertEquals("S", input.getReceiptStatusIndicator());
        assertEquals("117099001", input.getSubscriberId());
        assertEquals("N", input.getVoidIndicator());
    }

    public void test_mapPagingResultToInput() {
        WebServiceReceiptSummaryPagingResult pagingResult = new WebServiceReceiptSummaryPagingResult();
        CDHPReceiptListInput input = new CDHPReceiptListInput();
        pagingResult.setInitialClaimNumber("123456789");
        pagingResult.setInitialDate("01/01/2009");
        pagingResult.setInitialTransactionType("S");
        pagingResult.setPageNumber("029");

        objectUnderTest.mapPagingResultToInput(pagingResult, input);

        assertEquals("123456789", input.getInitialClaimNumber());
        assertEquals("01/01/2009", input.getInitialReceiptDate());
        assertEquals("S", input.getInitialTransactionType());
        assertEquals("030", input.getRequestPageNumber());
    }

    public void test_mapOutputToReceiptSummary() {
        CDHPReceiptListReceiptData receiptData = new CDHPReceiptListReceiptData();
        receiptData.setAmountPaid("250");
        receiptData.setReceiptDate("01/31/2008");
        receiptData.setClaimNumber("9999999999");
        receiptData.setProviderName("ACME INC");
        receiptData.setReceiptStatus("S");
        receiptData.setTransactionType("S");
        receiptData.setVoidStatus("Y");

        ClaimPaymentReceiptSummary summary = objectUnderTest.mapOutputToReceiptSummary(receiptData);

        assertEquals(new BigDecimal("250"), summary.getAmount());
        assertEquals(new GregorianCalendar(2008, 0, 31).getTime(), summary.getReceiptDate());
        assertEquals("9999999999", summary.getClaimNumber());
        assertEquals("ACME INC", summary.getProviderName());
        assertEquals("S", summary.getStatus());
        assertEquals("S", summary.getType());
        assertEquals("Y", summary.getVoid());
    }

    public void test_mapOutputToPagingResult() {
        List<ClaimPaymentReceiptSummary> results = new ArrayList<>();
        CDHPReceiptListOutput output = new CDHPReceiptListOutput();
        output.setReceiptData(new ArrayOfCDHPReceiptListReceiptData());
        CDHPReceiptListReceiptData returnReceiptListingReceiptData = new CDHPReceiptListReceiptData();
        returnReceiptListingReceiptData.setReceiptDate("01/31/2008");
        returnReceiptListingReceiptData.setClaimNumber("9999999999");
        returnReceiptListingReceiptData.setTransactionType("S");
        output.getReceiptData().getCDHPReceiptListReceiptData().add(returnReceiptListingReceiptData);
        output.setPageNumber("029");
        output.setTotalPages("032");

        WebServiceReceiptSummaryPagingResult pagingResult = objectUnderTest.mapOutputToPagingResult(results, output);

        assertEquals("9999999999", pagingResult.getInitialClaimNumber());
        assertEquals("01/31/2008", pagingResult.getInitialDate());
        assertEquals("S", pagingResult.getInitialTransactionType());
        assertEquals("029", pagingResult.getPageNumber());
        assertEquals("032", pagingResult.getPageTotal());
        assertEquals(results, pagingResult.getReceiptSummaries());

    }

    /**
     * Test to make sure that when the parsing of a date fails that null is returned
     */
    public void test_parseDate() {
        String date = "parseDate";
        String format = "MM/dd/yyyy";

        Date result = objectUnderTest.parseDate(date, format);

        assertNull("The date did not get returned as null when there was an exception", result);
    }

    /**
     * Test to make sure that when the formatting of a date fails that empty string is returned
     */
    public void test_formatDate() {
        String format = "MM/dd/yyyy";

        String result = objectUnderTest.formatDate(null, format);

        assertEquals("The format call should have returned empty string.", StringUtils.EMPTY, result);
    }

    private class StubCDHPReceiptList implements CDHPReceiptListService {

        @Override
        public CDHPReceiptListOutput getReceiptListing(CDHPReceiptListInput input) {
            List<CDHPReceiptListReceiptData> list = new ArrayList<>(378);
            for (int i = 0; i < 377; i++) {
                CDHPReceiptListReceiptData receiptData = new CDHPReceiptListReceiptData();
                receiptData.setReceiptDate("01/31/2008");
                receiptData.setClaimNumber("9999999999");
                receiptData.setTransactionType("S");
                list.add(receiptData);
            }
            // add a blank record to make sure it is handled correctly because SOA will return blank rows
            CDHPReceiptListReceiptData receiptData = new CDHPReceiptListReceiptData();
            receiptData.setReceiptDate(StringUtils.EMPTY);
            receiptData.setClaimNumber(StringUtils.EMPTY);
            receiptData.setTransactionType(StringUtils.EMPTY);
            list.add(receiptData);

            CDHPReceiptListOutput serviceOutput = new CDHPReceiptListOutput();
            serviceOutput.setReceiptData(new ArrayOfCDHPReceiptListReceiptData());
            serviceOutput.getReceiptData().getCDHPReceiptListReceiptData().addAll(list);

            if (input.getSubscriberId().endsWith("1")) {
                serviceOutput.setPageNumber("032");
                serviceOutput.setTotalPages("032");
            } else if (!input.getSubscriberId().endsWith("1") && input.getRequestPageNumber() == null) {
                serviceOutput.setPageNumber("029");
                serviceOutput.setTotalPages("032");
            } else if (input.getRequestPageNumber() != null) {
                serviceOutput.setPageNumber(input.getRequestPageNumber());
                serviceOutput.setTotalPages("032");
            }

            serviceOutput.setApplicationMessage("");
            serviceOutput.setServiceMessage("");
            serviceOutput.setServiceMessageCode("9999999999");
            serviceOutput.setSystemMessage("");

            return serviceOutput;
        }
    }

}
