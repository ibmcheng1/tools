/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2013 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.financial.dao.impl;

import com.bcbssc.financial.model.FinancialAccountMeta;
import com.bcbssc.financial.model.FinancialInstitution;
import com.bcbssc.financial.model.PaymentOptionInput;
import com.bcbssc.model.ClientBusinessSectorCode;
import com.bcbssc.model.subscriber.Subscriber;
import com.bcbssc.services.cdhppaymentoptioninfo.CDHPPaymentOptionInfoInput;
import com.bcbssc.services.cdhppaymentoptioninfo.CDHPPaymentOptionInfoOutput;
import com.bcbssc.services.cdhppaymentoptioninfo.CDHPPaymentOptionInfoService;
import com.bcbssc.wsutils.exception.WebServicesException;
import junit.framework.TestCase;
import org.apache.commons.lang.StringUtils;

/**
 * Unit test for the {@link WebServiceFinancialAccountMetaDAOImpl} class.
 */
public class WebServiceFinancialAccountMetaDAOImplTest extends TestCase {

    /**
     * Test method for {@link com.bcbssc.financial.dao.impl.WebServiceFinancialAccountMetaDAOImpl#retrieveAccountMeta(com.bcbssc.model.subscriber.Subscriber, java.lang.String, com.bcbssc.model.ClientBusinessSectorCode)}.
     */
    public void testRetrieveAccountMeta_CheckMapInput_Minimal() {
        WebServiceFinancialAccountMetaDAOImpl impl = new WebServiceFinancialAccountMetaDAOImpl();
        // does not handle null inputs (Subscriber, String, ClientBusinessSectorCode)
        PaymentOptionInput domainInput = new PaymentOptionInput();
        domainInput.setSubscriber(new Subscriber());
        domainInput.setPatientId(StringUtils.EMPTY);
        domainInput.setSectorCode(new ClientBusinessSectorCode());
        domainInput.setAccountUpdate(StringUtils.EMPTY);
        domainInput.setPaymentOption(StringUtils.EMPTY);
        CDHPPaymentOptionInfoInput input = impl.mapInput(domainInput);

        // Empty subscriber object means a null subscriber ID
        assertNull(input.getSubscriberId());
        assertEquals("Patient ID wasn't empty - '" + input.getPatientId() + "'", StringUtils.EMPTY, input.getPatientId());
        assertEquals("Account Update Indicator wasn't empty - '" + input.getCdhpAccountUpdateIndicator() + "'", StringUtils.EMPTY,
                input.getCdhpAccountUpdateIndicator());
        assertEquals("Payment Option Code wasn't empty - '" + input.getCdhpPaymentOptionCode() + "'", StringUtils.EMPTY, input.getCdhpPaymentOptionCode());
        assertNull("Requested RPN wasn't null - " + input.getRequestRpn(), input.getRequestRpn());
    }

    /**
     * Test method for {@link com.bcbssc.financial.dao.impl.WebServiceFinancialAccountMetaDAOImpl#retrieveAccountMeta(com.bcbssc.model.subscriber.Subscriber, java.lang.String, com.bcbssc.model.ClientBusinessSectorCode)}.
     */
    public void testRetrieveAccountMeta_CheckMapInput_FullFunction_NotBlueChoice() {
        WebServiceFinancialAccountMetaDAOImpl impl = new WebServiceFinancialAccountMetaDAOImpl();
        Subscriber subscriber = new Subscriber();
        // database number is the only field used on the Subscriber object
        subscriber.setDatabaseNumber("databasenumber");

        ClientBusinessSectorCode code = new ClientBusinessSectorCode();
        // rpn is the only field used on the ClientBusinessSectorCode object
        code.setRpn("rpn");

        PaymentOptionInput domainInput = new PaymentOptionInput();
        domainInput.setSubscriber(subscriber);
        domainInput.setPatientId("patientid");
        domainInput.setSectorCode(code);
        domainInput.setAccountUpdate(StringUtils.EMPTY);
        domainInput.setPaymentOption(StringUtils.EMPTY);

        CDHPPaymentOptionInfoInput input = impl.mapInput(domainInput);

        assertEquals("Subscriber ID wasn't 'databasenumber' as expected", "databasenumber", input.getSubscriberId());
        assertEquals("Patient ID wasn't 'patientid' as expected", "patientid", input.getPatientId());
        assertEquals("Account Update Indicator wasn't empty - '" + input.getCdhpAccountUpdateIndicator() + "'", StringUtils.EMPTY,
                input.getCdhpAccountUpdateIndicator());
        assertEquals("Payment Option Code wasn't empty - '" + input.getCdhpPaymentOptionCode() + "'", StringUtils.EMPTY, input.getCdhpPaymentOptionCode());
        assertEquals("Requested RPN wasn't 'rpn' as expected", "rpn", input.getRequestRpn());
    }

    /**
     * Test method for {@link com.bcbssc.financial.dao.impl.WebServiceFinancialAccountMetaDAOImpl#retrieveAccountMeta(com.bcbssc.model.subscriber.Subscriber, java.lang.String, com.bcbssc.model.ClientBusinessSectorCode)}.
     */
    public void testRetrieveAccountMeta_CheckMapInput_FullFunction_BlueChoice() {
        WebServiceFinancialAccountMetaDAOImpl impl = new WebServiceFinancialAccountMetaDAOImpl();
        Subscriber subscriber = new Subscriber();
        // database number is the only field used on the Subscriber object
        subscriber.setDatabaseNumber("databasenumber");

        ClientBusinessSectorCode code = new ClientBusinessSectorCode();
        // rpn is the only field used on the ClientBusinessSectorCode object
        code.setRpn("035");

        PaymentOptionInput domainInput = new PaymentOptionInput();
        domainInput.setSubscriber(subscriber);
        domainInput.setPatientId("patientid");
        domainInput.setSectorCode(code);
        domainInput.setPaymentOption(StringUtils.EMPTY);
        domainInput.setAccountUpdate(StringUtils.EMPTY);

        CDHPPaymentOptionInfoInput input = impl.mapInput(domainInput);

        assertEquals("Subscriber ID wasn't 'Kdatabasenumber' as expected", "Kdatabasenumber", input.getSubscriberId());
        assertEquals("Patient ID wasn't 'patientid' as expected", "patientid", input.getPatientId());
        assertEquals("Account Update Indicator wasn't empty - '" + input.getCdhpAccountUpdateIndicator() + "'", StringUtils.EMPTY,
                input.getCdhpAccountUpdateIndicator());
        assertEquals("Payment Option Code wasn't empty - '" + input.getCdhpPaymentOptionCode() + "'", StringUtils.EMPTY, input.getCdhpPaymentOptionCode());
        assertEquals("Requested RPN wasn't '035' as expected", "035", input.getRequestRpn());
    }

    /**
     * Test method for {@link com.bcbssc.financial.dao.impl.WebServiceFinancialAccountMetaDAOImpl#retrieveAccountMeta(com.bcbssc.model.subscriber.Subscriber, java.lang.String, com.bcbssc.model.ClientBusinessSectorCode)}.
     */
    public void testRetrieveAccountMeta_CheckMapOutput_UnparsableDates() {
        WebServiceFinancialAccountMetaDAOImpl impl = new WebServiceFinancialAccountMetaDAOImpl();
        CDHPPaymentOptionInfoOutput output = new CDHPPaymentOptionInfoOutput();
        // leave everything as null (except for dates) and make sure it will handle it
        output.setAccountClosedDate(StringUtils.EMPTY);
        output.setCdhpPaymentOptionEffectiveDate(StringUtils.EMPTY);

        FinancialAccountMeta meta = impl.mapOutput(output);
        FinancialInstitution institution = meta.getFinancialInstitution();
        assertNotNull("The FinancialInstitution object was null", institution);
        assertNull("The URL wasn't null", institution.getUrl());
        assertNull("Monday hours weren't null", institution.getMondayHoursOfOperation());
        assertNull("Tuesday hours weren't null", institution.getTuesdayHoursOfOperation());
        assertNull("Wednesday hours weren't null", institution.getWednesdayHoursOfOperation());
        assertNull("Thursday hours weren't null", institution.getThursdayHoursOfOperation());
        assertNull("Friday hours weren't null", institution.getFridayHoursOfOperation());
        assertNull("Saturday hours weren't null", institution.getSaturdayHoursOfOperation());
        assertNull("Sunday hours weren't null", institution.getSundayHoursOfOperation());
        assertNull("The institution name wasn't null", institution.getName());
        assertNull("The institution phone number wasn't null", institution.getPhoneNumber());
        assertNull("The institution routing number wasn't null", institution.getRoutingNumber());

        assertNull("The active account indicator wasn't null", meta.getAccountActiveIndicator());
        assertNull("The account closed date wasn't null", meta.getAccountCloseDate());
        assertNull("The payment effective date wasn't null", meta.getPaymentEffDate());
        assertNull("The payment option indicator wasn't null", meta.getPaymentOptionIndicator());
        assertNull("The database id wasn't null", meta.getSubscriberDatabaseNumber());
        assertNull("The subscriber SSN wasn't null", meta.getSubscriberSSN());
    }

    /**
     * Test method for {@link com.bcbssc.financial.dao.impl.WebServiceFinancialAccountMetaDAOImpl#retrieveAccountMeta(com.bcbssc.model.subscriber.Subscriber, java.lang.String, com.bcbssc.model.ClientBusinessSectorCode)}.
     */
    public void testRetrieveAccountMeta_CheckMapOutput_FullData() {
        WebServiceFinancialAccountMetaDAOImpl impl = new WebServiceFinancialAccountMetaDAOImpl();
        CDHPPaymentOptionInfoOutput output = new CDHPPaymentOptionInfoOutput();
        output.setAccountClosedDate("03/15/2010");
        output.setCdhpPaymentOptionEffectiveDate("01/19/2009");
        output.setPartnerWebAddress("http://www.google.com");
        output.setMondayHoursOfOperation("monday");
        output.setTuesdayHoursOfOperation("tuesday");
        output.setWednesdayHoursOfOperation("wednesday");
        output.setThursdayHoursOfOperation("thursday");
        output.setFridayHoursOfOperation("friday");
        output.setSaturdayHoursOfOperation("saturday");
        output.setSundayHoursOfOperation("sunday");
        output.setPartnerName("google");
        output.setPartnerPhoneNumber("(650)253-0000");
        output.setPartnerNumber("1,000,000,000,000,000");
        output.setAccountActiveIndicator("active");
        output.setCdhpPaymentOptionIndicator("option");
        output.setSubscriberSocialSecurityNumber("ssn");

        FinancialAccountMeta meta = impl.mapOutput(output);
        FinancialInstitution institution = meta.getFinancialInstitution();
        assertNotNull("The FinancialInstitution object was null", institution);
        assertEquals("http://www.google.com", institution.getUrl());
        assertEquals("monday", institution.getMondayHoursOfOperation());
        assertEquals("tuesday", institution.getTuesdayHoursOfOperation());
        assertEquals("wednesday", institution.getWednesdayHoursOfOperation());
        assertEquals("thursday", institution.getThursdayHoursOfOperation());
        assertEquals("friday", institution.getFridayHoursOfOperation());
        assertEquals("saturday", institution.getSaturdayHoursOfOperation());
        assertEquals("sunday", institution.getSundayHoursOfOperation());
        assertEquals("google", institution.getName());
        assertEquals("(650)253-0000", institution.getPhoneNumber());
        assertEquals("1,000,000,000,000,000", institution.getRoutingNumber());

        assertEquals("active", meta.getAccountActiveIndicator());
        assertNotNull("Closed date was null", meta.getAccountCloseDate());
        assertNotNull("Payment Effective date was null", meta.getPaymentEffDate());
        assertEquals("option", meta.getPaymentOptionIndicator());
        assertEquals("ssn", meta.getSubscriberSSN());
    }

    /**
     * Test method for {@link com.bcbssc.financial.dao.impl.WebServiceFinancialAccountMetaDAOImpl#updatePaymentOption(com.bcbssc.model.subscriber.Subscriber, java.lang.String, java.lang.String, com.bcbssc.model.ClientBusinessSectorCode)}.
     */
    public void testUpdatePaymentOption() {
        // the only difference between this method call and the previous is that this one supplies more inputs to the web service
        WebServiceFinancialAccountMetaDAOImpl impl = new WebServiceFinancialAccountMetaDAOImpl();
        Subscriber subscriber = new Subscriber();
        // database number is the only field used on the Subscriber object
        subscriber.setDatabaseNumber("databasenumber");

        ClientBusinessSectorCode code = new ClientBusinessSectorCode();
        // rpn is the only field used on the ClientBusinessSectorCode object
        code.setRpn("rpn");

        PaymentOptionInput domainInput = new PaymentOptionInput();
        domainInput.setAccountUpdate("U");
        domainInput.setPaymentOption("option");
        domainInput.setSubscriber(subscriber);
        domainInput.setPatientId("patientid");
        domainInput.setSectorCode(code);

        CDHPPaymentOptionInfoInput input = impl.mapInput(domainInput);

        assertEquals("Subscriber ID wasn't 'databasenumber' as expected", "databasenumber", input.getSubscriberId());
        assertEquals("Patient ID wasn't 'patientid' as expected", "patientid", input.getPatientId());
        assertEquals("Account Update Indicator wasn't 'U' as expected", "U", input.getCdhpAccountUpdateIndicator());
        assertEquals("Payment Option Code wasn't 'option' as expected", "option", input.getCdhpPaymentOptionCode());
        assertEquals("Requested RPN wasn't 'rpn' as expected", "rpn", input.getRequestRpn());
    }
}
