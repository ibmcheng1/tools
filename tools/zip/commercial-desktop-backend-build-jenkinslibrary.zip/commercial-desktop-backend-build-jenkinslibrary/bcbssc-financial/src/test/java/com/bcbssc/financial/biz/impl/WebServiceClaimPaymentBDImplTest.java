/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.financial.biz.impl;

import com.bcbssc.financial.model.ClaimPayment;
import com.bcbssc.financial.model.ClaimPaymentReceipt;
import com.bcbssc.model.ClientBusinessSectorCode;
import com.bcbssc.model.subscriber.Subscriber;
import com.bcbssc.services.cdhpclaimpaymentinfo.ArrayOfCDHPClaimPaymentInfoReceiptData;
import com.bcbssc.services.cdhpclaimpaymentinfo.CDHPClaimPaymentInfoInput;
import com.bcbssc.services.cdhpclaimpaymentinfo.CDHPClaimPaymentInfoOutput;
import com.bcbssc.services.cdhpclaimpaymentinfo.CDHPClaimPaymentInfoReceiptData;
import junit.framework.TestCase;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.List;

/**
 * Test case for {@link WebServiceClaimPaymentBDImpl}
 */
public class WebServiceClaimPaymentBDImplTest extends TestCase {

    /**
     * Test method for {@link com.bcbssc.financial.biz.impl.WebServiceClaimPaymentBDImpl#retrieveClaimPaymentReceipts(com.bcbssc.financial.model.ClaimPayment)}.
     */
    public void testRetrieveClaimPaymentReceipts_CheckMapInput_Minimal() {
        WebServiceClaimPaymentBDImpl impl = new WebServiceClaimPaymentBDImpl();
        // payment must have a ClientBusinessSectorCode and a Subscriber
        ClaimPayment payment = new ClaimPayment();
        payment.setClientBusinessSector(new ClientBusinessSectorCode());
        // subscriber must have a DateOfBirth
        Subscriber subscriber = new Subscriber();
        Calendar birthday = Calendar.getInstance();
        birthday.clear();
        birthday.set(Calendar.MONTH, Calendar.FEBRUARY);
        birthday.set(Calendar.DATE, 11);
        birthday.set(Calendar.YEAR, 1981);
        subscriber.setDateOfBirth(birthday.getTime());
        payment.setSubscriber(subscriber);
        payment.setReceiptMode(true);

        CDHPClaimPaymentInfoInput input = impl.mapInput(payment);
        assertNotNull("The input for the service shouldn't be null", input);
        assertNull("The rpn should have been null", input.getRequestRpn());
        assertEquals("The receipt status wasn't what was expected.", "SDI", input.getRequestReceiptStatus());
        assertEquals("The void indicator wasn't what was expected.", "N", input.getRequestVoidIndicator());
        assertNull("The alias rpn should have been null", input.getRequestAliasRpn());
        assertEquals("The debit amount wasn't what was expected.", "0", input.getRequestDebitAmount());
        assertNull("The bank routing number should have been null", input.getRequestBankRoutingNumber());
        assertNull("The account number should have been null", input.getRequestAccountNumber());
        assertEquals("The line of business wasn't what was expected.", "H", input.getRequestLineOfBusiness());
        assertNull("The claim number should have been null", input.getRequestClaimNumber());
        assertNull("The provider name should have been null", input.getRequestProviderName());
        assertNull("The provider number should have been null", input.getRequestProviderNumber());
        assertEquals("The subscriber date of birth wasn't what was expected.", "02-11-1981", input.getRequestSubscriberDateOfBirth());
        assertNull("The subscriber id should have been null", input.getRequestSubscriberId());
        assertNull("The subscriber first name should have been null", input.getRequestSubscriberFirstName());
        assertNull("The subscriber last name should have been null", input.getRequestSubscriberLastName());
        assertNull("The subscriber SSN should have been null", input.getRequestSubscriberSSN());
        assertNull("The group number should have been null", input.getRequestGroupNumber());
        assertEquals("The action indicator wasn't what was expected.", "R", input.getRequestActionIndicator());
        assertEquals("The receipt source wasn't what was expected.", "W", input.getRequestReceiptSource());
    }

    /**
     * Test method for {@link com.bcbssc.financial.biz.impl.WebServiceClaimPaymentBDImpl#retrieveClaimPaymentReceipts(com.bcbssc.financial.model.ClaimPayment)}.
     */
    public void testRetrieveClaimPaymentReceipts_CheckMapInput_FullFunction_NotBlueChoice() {
        WebServiceClaimPaymentBDImpl impl = new WebServiceClaimPaymentBDImpl();
        // payment must have a ClientBusinessSectorCode and a Subscriber
        ClaimPayment payment = new ClaimPayment();
        ClientBusinessSectorCode code = new ClientBusinessSectorCode();
        // rpn is the only field used on the ClientBusinessSectorCode object
        code.setRpn("rpn");
        payment.setClientBusinessSector(code);
        payment.setReceiptMode(true);

        Subscriber subscriber = new Subscriber();
        Calendar birthday = Calendar.getInstance();
        birthday.clear();
        birthday.set(Calendar.MONTH, Calendar.FEBRUARY);
        birthday.set(Calendar.DATE, 11);
        birthday.set(Calendar.YEAR, 1981);
        subscriber.setDateOfBirth(birthday.getTime());
        subscriber.setDatabaseNumber("databasenumber");
        subscriber.getPersonName().setFirstName("thomas");
        subscriber.getPersonName().setLastName("edison");
        subscriber.setSocialSecurityNumber("000-00-0001");
        subscriber.setGroupNumber("groupnumber");
        payment.setSubscriber(subscriber);
        payment.setPaymentAmount(new BigDecimal(48000000));
        payment.setReceiptStatusFilter("RM");
        payment.setShowVoidedReceipts("Y");
        payment.setBankRoutingNumber("0000115577");
        payment.setAccountNumber("00255884");
        payment.setClaimNumber("7T21584010000");
        payment.setProviderName("Ben Franklin Fixes Em");
        payment.setProviderNumber("00000001");

        CDHPClaimPaymentInfoInput input = impl.mapInput(payment);
        assertNotNull("The input for the service shouldn't be null", input);
        assertEquals("The rpn wasn't what was expected", "rpn", input.getRequestRpn());
        assertEquals("The receipt status wasn't what was expected.", "RM", input.getRequestReceiptStatus());
        assertEquals("The void indicator wasn't what was expected.", "Y", input.getRequestVoidIndicator());
        assertEquals("The alias rpn wasn't what was expected", "rpn", input.getRequestAliasRpn());
        assertEquals("The debit amount wasn't what was expected.", "48000000", input.getRequestDebitAmount());
        assertEquals("The bank routing number wasn't what was expected", "0000115577", input.getRequestBankRoutingNumber());
        assertEquals("The account number wasn't what was expected", "00255884", input.getRequestAccountNumber());
        assertEquals("The line of business wasn't what was expected.", "H", input.getRequestLineOfBusiness());
        assertEquals("The claim number wasn't what was expected", "7T21584010000", input.getRequestClaimNumber());
        assertEquals("The provider name wasn't what was expected", "Ben Franklin Fixes Em", input.getRequestProviderName());
        assertEquals("The provider number wasn't what was expected", "00000001", input.getRequestProviderNumber());
        assertEquals("The subscriber date of birth wasn't what was expected.", "02-11-1981", input.getRequestSubscriberDateOfBirth());
        assertEquals("The subscriber id wasn't what was expected", "databasenumber", input.getRequestSubscriberId());
        assertEquals("The subscriber first name wasn't what was expected", "thomas", input.getRequestSubscriberFirstName());
        assertEquals("The subscriber last name wasn't what was expected", "edison", input.getRequestSubscriberLastName());
        assertEquals("The subscriber SSN wasn't what was expected", "000-00-0001", input.getRequestSubscriberSSN());
        assertEquals("The action indicator wasn't what was expected.", "R", input.getRequestActionIndicator());
        assertEquals("The receipt source wasn't what was expected.", "W", input.getRequestReceiptSource());
    }

    /**
     * Test method for {@link com.bcbssc.financial.biz.impl.WebServiceClaimPaymentBDImpl#retrieveClaimPaymentReceipts(com.bcbssc.financial.model.ClaimPayment)}.
     */
    public void testRetrieveClaimPaymentReceipts_CheckMapInput_FullFunction_BlueChoice() {
        WebServiceClaimPaymentBDImpl impl = new WebServiceClaimPaymentBDImpl();
        // payment must have a ClientBusinessSectorCode and a Subscriber
        ClaimPayment payment = new ClaimPayment();
        ClientBusinessSectorCode code = new ClientBusinessSectorCode();
        // rpn is the only field used on the ClientBusinessSectorCode object
        code.setRpn("035");
        payment.setClientBusinessSector(code);

        Subscriber subscriber = new Subscriber();
        Calendar birthday = Calendar.getInstance();
        birthday.clear();
        birthday.set(Calendar.MONTH, Calendar.FEBRUARY);
        birthday.set(Calendar.DATE, 11);
        birthday.set(Calendar.YEAR, 1981);
        subscriber.setDateOfBirth(birthday.getTime());
        subscriber.setDatabaseNumber("databasenumber");
        subscriber.getPersonName().setFirstName("thomas");
        subscriber.getPersonName().setLastName("edison");
        subscriber.setSocialSecurityNumber("000-00-0001");
        subscriber.setGroupNumber("groupnumber");
        payment.setSubscriber(subscriber);
        payment.setPaymentAmount(new BigDecimal(48000000));
        payment.setReceiptStatusFilter("RM");
        payment.setShowVoidedReceipts("Y");
        payment.setBankRoutingNumber("0000115577");
        payment.setAccountNumber("00255884");
        payment.setClaimNumber("7T21584010000");
        payment.setProviderName("Ben Franklin Fixes Em");
        payment.setProviderNumber("00000001");
        payment.setReceiptMode(true);

        CDHPClaimPaymentInfoInput input = impl.mapInput(payment);
        assertNotNull("The input for the service shouldn't be null", input);
        assertEquals("The rpn wasn't what was expected", "035", input.getRequestRpn());
        assertEquals("The receipt status wasn't what was expected.", "RM", input.getRequestReceiptStatus());
        assertEquals("The void indicator wasn't what was expected.", "Y", input.getRequestVoidIndicator());
        assertEquals("The alias rpn wasn't what was expected", "035", input.getRequestAliasRpn());
        assertEquals("The debit amount wasn't what was expected.", "48000000", input.getRequestDebitAmount());
        assertEquals("The bank routing number wasn't what was expected", "0000115577", input.getRequestBankRoutingNumber());
        assertEquals("The account number wasn't what was expected", "00255884", input.getRequestAccountNumber());
        assertEquals("The line of business wasn't what was expected.", "H", input.getRequestLineOfBusiness());
        assertEquals("The claim number wasn't what was expected", "7T21584010000", input.getRequestClaimNumber());
        assertEquals("The provider name wasn't what was expected", "Ben Franklin Fixes Em", input.getRequestProviderName());
        assertEquals("The provider number wasn't what was expected", "00000001", input.getRequestProviderNumber());
        assertEquals("The subscriber date of birth wasn't what was expected.", "02-11-1981", input.getRequestSubscriberDateOfBirth());
        assertEquals("The subscriber id wasn't what was expected", "Kdatabasenumber", input.getRequestSubscriberId());
        assertEquals("The subscriber first name wasn't what was expected", "thomas", input.getRequestSubscriberFirstName());
        assertEquals("The subscriber last name wasn't what was expected", "edison", input.getRequestSubscriberLastName());
        assertEquals("The subscriber SSN wasn't what was expected", "000-00-0001", input.getRequestSubscriberSSN());
        assertEquals("The action indicator wasn't what was expected.", "R", input.getRequestActionIndicator());
        assertEquals("The receipt source wasn't what was expected.", "W", input.getRequestReceiptSource());
    }

    /**
     * Test method for {@link com.bcbssc.financial.biz.impl.WebServiceClaimPaymentBDImpl#submitClaimPayment(com.bcbssc.financial.model.ClaimPayment)}.
     * 
     * This test runs through the same code as the previous tests, so we are just going to test the stuff that is specific to this method
     */
    public void testSubmitClaimPayment_CheckMapInput() {
        WebServiceClaimPaymentBDImpl impl = new WebServiceClaimPaymentBDImpl();
        // payment must have a ClientBusinessSectorCode and a Subscriber
        ClaimPayment payment = new ClaimPayment();
        payment.setClientBusinessSector(new ClientBusinessSectorCode());
        // subscriber must have a DateOfBirth
        Subscriber subscriber = new Subscriber();
        Calendar birthday = Calendar.getInstance();
        birthday.clear();
        birthday.set(Calendar.MONTH, Calendar.FEBRUARY);
        birthday.set(Calendar.DATE, 11);
        birthday.set(Calendar.YEAR, 1981);
        subscriber.setDateOfBirth(birthday.getTime());
        payment.setSubscriber(subscriber);

        CDHPClaimPaymentInfoInput input = impl.mapInput(payment);
        assertNotNull("The input for the service shouldn't be null", input);
        assertEquals("The action indicator wasn't what was expected.", "P", input.getRequestActionIndicator());
    }

    /**
     * Test method for {@link com.bcbssc.financial.biz.impl.WebServiceClaimPaymentBDImpl#retrieveLatestClaimPaymentReceipt(com.bcbssc.financial.model.ClaimPayment)}.
     * 
     * All methods in this class delegate to the callService method which uses a single mapOutput method. This will be the only test method for
     * checking that the output gets mapped appropriately.
     */
    public void testRetrieveLatestClaimPaymentReceipt_CheckMapOutput_DefaultOutput() {
        WebServiceClaimPaymentBDImpl impl = new WebServiceClaimPaymentBDImpl();
        List<ClaimPaymentReceipt> receipts = impl.mapOutput(getDefaultOutput());
        // with the default output, this should have produced 2 results
        assertNotNull(receipts);
        assertEquals("Should have only been 2 results", 2, receipts.size());
        ClaimPaymentReceipt receipt1 = receipts.get(0);
        ClaimPaymentReceipt receipt2 = receipts.get(1);
        assertNotNull(receipt1);
        assertNull("The amount paid for receipt 1 wasn't what was expected", receipt1.getAmountPaid());
        assertNull("The transaction date for receipt 1 wasn't what was expected", receipt1.getTransactionDate());
        assertNull("The authorization code for receipt 1 wasn't what was expected", receipt1.getAuthorizationCode());
        assertNull("The bank error code for receipt 1 wasn't what was expected", receipt1.getBankErrorCode());
        assertNull("The bank error description for receipt 1 wasn't what was expected", receipt1.getBankErrorDescription());
        assertNull("The reference number for receipt 1 wasn't what was expected", receipt1.getReferenceNumber());
        assertNull("The return code for receipt 1 wasn't what was expected", receipt1.getReturnCode());
        assertNull("The receipt status for receipt 1 wasn't what was expected", receipt1.getReceiptStatus());
        assertNull("The credit card number for receipt 1 wasn't what was expect", receipt1.getCreditCardNumber());
        assertNull("The card type for receipt 1 wasn't what was expected", receipt1.getCardType());
        assertNull("The transaction type for receipt 1 wasn't what was expected", receipt1.getTransactionType());
        assertNull("The claim number for receipt 1 wasn't what was expected", receipt1.getClaimNumber());
        assertNull("The subscriber id for receipt 1 wasn't what was expected", receipt1.getSubscriberId());
        assertEquals("The subscriber name for receipt 1 wasn't what was expected", "null null", receipt1.getSubscriberName());
        assertNull("The patient name for receipt 1 wasn't what was expected", receipt1.getPatientName());
        assertNull("The provider name for receipt 1 wasn't what was expected", receipt1.getProviderName());
        assertNull("The date of service for receipt 1 wasn't what was expected", receipt1.getDateOfService());
        assertNull("The provider charges for receipt 1 wasn't what was expected", receipt1.getProviderCharges());

        assertNotNull(receipt2);
        assertEquals("The amount paid for receipt 2 wasn't what was expected", new BigDecimal(0), receipt2.getAmountPaid());
        //2011-04-15-13.43.07
        Calendar transactionDate = Calendar.getInstance();
        transactionDate.clear();
        transactionDate.set(Calendar.YEAR, 2011);
        transactionDate.set(Calendar.MONTH, Calendar.APRIL);
        transactionDate.set(Calendar.DATE, 15);
        transactionDate.set(Calendar.HOUR_OF_DAY, 13);
        transactionDate.set(Calendar.MINUTE, 43);
        transactionDate.set(Calendar.SECOND, 7);
        assertEquals("The transaction date for receipt 2 wasn't what was expected", transactionDate.getTime(), receipt2.getTransactionDate());
        assertEquals("The authorization code for receipt 2 wasn't what was expected", "authcode", receipt2.getAuthorizationCode());
        assertEquals("The bank error code for receipt 2 wasn't what was expected", "errorcode", receipt2.getBankErrorCode());
        assertEquals("The bank error description for receipt 2 wasn't what was expected", "errordescription", receipt2.getBankErrorDescription());
        assertEquals("The reference number for receipt 2 wasn't what was expected", "referencenumber", receipt2.getReferenceNumber());
        assertEquals("The return code for receipt 2 wasn't what was expected", "returncode", receipt2.getReturnCode());
        assertEquals("The receipt status for receipt 2 wasn't what was expected", "receiptstatus", receipt2.getReceiptStatus());
        assertEquals("The credit card number for receipt 2 wasn't what was expect", "creditcard", receipt2.getCreditCardNumber());
        assertEquals("The card type for receipt 2 wasn't what was expected", "cardtype", receipt2.getCardType());
        assertEquals("The transaction type for receipt 2 wasn't what was expected", "transactiontype", receipt2.getTransactionType());
        assertEquals("The claim number for receipt 2 wasn't what was expected", "claimnumber", receipt2.getClaimNumber());
        assertEquals("The subscriber id for receipt 2 wasn't what was expected", "subscriberid", receipt2.getSubscriberId());
        assertEquals("The subscriber name for receipt 2 wasn't what was expected", "firstname lastname", receipt2.getSubscriberName());
        assertEquals("The patient name for receipt 2 wasn't what was expected", "patientname", receipt2.getPatientName());
        assertEquals("The provider name for receipt 2 wasn't what was expected", "providername", receipt2.getProviderName());
        //2009-12-31
        Calendar serviceDate = Calendar.getInstance();
        serviceDate.clear();
        serviceDate.set(Calendar.YEAR, 2009);
        serviceDate.set(Calendar.MONTH, Calendar.DECEMBER);
        serviceDate.set(Calendar.DATE, 31);
        assertEquals("The date of service for receipt 2 wasn't what was expected", serviceDate.getTime(), receipt2.getDateOfService());
        assertEquals("The provider charges for receipt 2 wasn't what was expected", new BigDecimal(80), receipt2.getProviderCharges());
    }

    private CDHPClaimPaymentInfoOutput getDefaultOutput() {
        CDHPClaimPaymentInfoOutput output = new CDHPClaimPaymentInfoOutput();
        output.setReceiptData(new ArrayOfCDHPClaimPaymentInfoReceiptData());

        CDHPClaimPaymentInfoReceiptData data1 = new CDHPClaimPaymentInfoReceiptData();
        data1.setAmountPaid("seven");
        data1.setDebitAmount("0");
        data1.setTransactionDateAndTime("");
        data1.setDateOfService("");
        data1.setProviderCharges("nan");
        output.getReceiptData().getCDHPClaimPaymentInfoReceiptData().add(data1);

        CDHPClaimPaymentInfoReceiptData data2 = new CDHPClaimPaymentInfoReceiptData();
        data2.setAmountPaid("0");
        data2.setDebitAmount("40");
        data2.setTransactionDateAndTime("2011-04-15-13.43.07.123");
        data2.setDateOfService("12/31/2009");
        data2.setProviderCharges("80");
        data2.setAuthorizationCode("authcode");
        data2.setBankErrorCode("errorcode");
        data2.setBankErrorDescription("errordescription");
        data2.setReferenceNumber("referencenumber");
        data2.setReturnCode("returncode");
        data2.setReceiptStatus("receiptstatus");
        data2.setCardLastFourNumber("creditcard");
        data2.setCardType("cardtype");
        data2.setReceiptType("transactiontype");
        data2.setClaimNumber("claimnumber");
        data2.setSubscriberId("subscriberid");
        data2.setSubscriberFirstName("firstname");
        data2.setSubscriberLastName("lastname");
        data2.setPatientName("patientname");
        data2.setProviderName("providername");
        output.getReceiptData().getCDHPClaimPaymentInfoReceiptData().add(data2);

        // leave one blank to make sure it doesn't get included in the results
        CDHPClaimPaymentInfoReceiptData data3 = new CDHPClaimPaymentInfoReceiptData();
        output.getReceiptData().getCDHPClaimPaymentInfoReceiptData().add(data3);
        return output;
    }
}
