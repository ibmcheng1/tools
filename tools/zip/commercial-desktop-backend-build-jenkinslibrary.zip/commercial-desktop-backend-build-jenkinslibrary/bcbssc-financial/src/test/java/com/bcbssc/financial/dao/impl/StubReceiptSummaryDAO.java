/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.financial.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.bcbssc.financial.dao.ReceiptSummaryDAO;
import com.bcbssc.financial.model.ClaimPaymentReceiptSummary;
import com.bcbssc.financial.model.ReceiptSummarySearchCriteria;

/**
 * Stub implementation for ReceiptSummaryDAO.
 *
 */
public class StubReceiptSummaryDAO implements ReceiptSummaryDAO {

    public List retrieveClientPaymentReceiptSummary(ReceiptSummarySearchCriteria criteria) {
        List list = new ArrayList();

        ClaimPaymentReceiptSummary s1 = new ClaimPaymentReceiptSummary();
        s1.setAmount(new BigDecimal("50.00"));
        s1.setClaimNumber("1234567890");
        s1.setProviderName("ACME Medical");
        s1.setReceiptDate(new Date());
        s1.setStatus("STATUS");
        s1.setType("X");
        s1.setVoid("N");
        list.add(s1);

        ClaimPaymentReceiptSummary s2 = new ClaimPaymentReceiptSummary();
        s2.setAmount(new BigDecimal("75.00"));
        s2.setClaimNumber("1234567891");
        s2.setProviderName("GI Medical");
        s2.setReceiptDate(new Date());
        s2.setStatus("STATUS");
        s2.setType("X");
        s2.setVoid("Y");
        list.add(s2);

        ClaimPaymentReceiptSummary s3 = new ClaimPaymentReceiptSummary();
        s3.setAmount(new BigDecimal("100.00"));
        s3.setClaimNumber("1234567892");
        s3.setProviderName("BlueChoice Medical");
        s3.setReceiptDate(new Date());
        s3.setStatus("STATUS");
        s3.setType("X");
        s3.setVoid("N");
        list.add(s3);

        ClaimPaymentReceiptSummary s4 = new ClaimPaymentReceiptSummary();
        s4.setAmount(new BigDecimal("125.00"));
        s4.setClaimNumber("1234567893");
        s4.setProviderName("HOSP Medical");
        s4.setReceiptDate(new Date());
        s4.setStatus("STATUS");
        s4.setType("X");
        s4.setVoid("Y");
        list.add(s4);

        return list;
    }

}
