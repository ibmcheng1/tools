/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.financial.dao.impl;

import com.bcbssc.financial.dao.FinancialAccountMetaDAO;
import com.bcbssc.financial.model.FinancialAccountMeta;
import com.bcbssc.financial.model.FinancialInstitution;
import com.bcbssc.model.ClientBusinessSectorCode;
import com.bcbssc.model.subscriber.Subscriber;

/**
* Generic stub for FinancialAccountMetaDAO
*
*/
public class StubFinancialAccountMetaDAOImpl implements FinancialAccountMetaDAO {

    /* (non-Javadoc)
     * @see com.bcbssc.financial.dao.FinancialAccountMetaDAO#retrieveAccountMeta(com.bcbssc.model.subscriber.Subscriber, com.bcbssc.model.ClientBusinessSectorCode)
     */
    public FinancialAccountMeta retrieveAccountMeta(Subscriber subscriber,
                                                    String patentId,
                                                    ClientBusinessSectorCode cbsc) {

        FinancialInstitution institution = new FinancialInstitution();
        institution.setName("Toolkit Bank - Stubbed Object");
        institution.setRoutingNumber("9876543210");

        FinancialAccountMeta accountMeta = new FinancialAccountMeta();
        accountMeta.setFinancialInstitution(institution);
        accountMeta.setSubscriberDatabaseNumber(subscriber.getDatabaseNumber());
        accountMeta.setSubscriberSSN("123456789");

        accountMeta.setAccountActiveIndicator("A"); // A or I
        accountMeta.setPaymentOptionIndicator("C"); // C(laim by Claim) or A(uto)

        accountMeta.setAccountCloseDate(null);
        accountMeta.setPaymentEffDate(null);

        return accountMeta;
    }

    public FinancialAccountMeta updatePaymentOption(Subscriber subscriber,
                                                    String patientId,
                                                    String paymentOption,
                                                    ClientBusinessSectorCode cbsc) {
        return retrieveAccountMeta(null,
                                   null,
                                   null);
    }

}
