/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.dao;

import java.util.Date;

import com.bcbssc.financial.model.FinancialAccountSnapshot;
import com.bcbssc.model.ClientBusinessSectorCode;
import com.bcbssc.model.subscriber.Subscriber;

/**
 * Defines the search criteria for financial account retrieval.
 *
 */
public class FinancialAccountSearchCriteria {

    private Subscriber subscriber;
    private ClientBusinessSectorCode clientBusinessSectorCode;
    private Date startDate;
    private Date endDate;
    private Integer pastDays;
    private FinancialAccountSnapshot financialAccount;

    public ClientBusinessSectorCode getClientBusinessSectorCode() {
        return clientBusinessSectorCode;
    }

    public void setClientBusinessSectorCode(ClientBusinessSectorCode clientBusinessSectorCode) {
        this.clientBusinessSectorCode = clientBusinessSectorCode;
    }

    public Subscriber getSubscriber() {
        return subscriber;
    }

    public void setSubscriber(Subscriber subscriber) {
        this.subscriber = subscriber;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    /**
     * @return the pastDays
     */
    public Integer getPastDays() {
        return pastDays;
    }

    /**
     * @param pastDays the pastDays to set
     */
    public void setPastDays(Integer pastDays) {
        this.pastDays = pastDays;
    }

    /**
     * @return the financialAccount
     */
    public FinancialAccountSnapshot getFinancialAccount() {
        return financialAccount;
    }

    /**
     * @param financialAccount the financialAccount to set
     */
    public void setFinancialAccount(FinancialAccountSnapshot financialAccount) {
        this.financialAccount = financialAccount;
    }

}
