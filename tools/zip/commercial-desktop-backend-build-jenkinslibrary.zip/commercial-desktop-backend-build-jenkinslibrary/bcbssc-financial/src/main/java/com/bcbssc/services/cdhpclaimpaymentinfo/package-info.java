@javax.xml.bind.annotation.XmlSchema(namespace = "http://CDHPClaimPaymentInfo.RMPPT101EJB.claims.bcbssc.com")
package com.bcbssc.services.cdhpclaimpaymentinfo;
