/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.dao;

import com.bcbssc.financial.model.FinancialAccountSnapshot;
import com.bcbssc.model.subscriber.Subscriber;

/**
 * Interface that defines financial account snapshot retrieval operation.
 *
 */
public interface FinancialAccountSnapshotDAO {

    public FinancialAccountSnapshot retrieveAccountSnapshot(Subscriber subscriber);

}
