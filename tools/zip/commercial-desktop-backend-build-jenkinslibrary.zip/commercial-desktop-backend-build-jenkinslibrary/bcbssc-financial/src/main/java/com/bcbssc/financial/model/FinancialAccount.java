/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.model;

import java.math.BigDecimal;
import java.util.Date;
import java.io.*;

/**
 * Model object for financial account.
 *
 */
public class FinancialAccount implements Serializable {

    static final long serialVersionUID = 6466269374871141770L;
    private String accountNumber;
    private String accountType;
    private String accountStatus;
    private BigDecimal accountBalance;
    private FinancialInstitution financialInstitution;
    private BigDecimal availableBalance;
    private Date accountBalanceDate;
    private Float interestRate;
    private Date lastStatementDate;
    private BigDecimal lastInterestPaymentAmount;
    private BigDecimal lastStatementBalance;
    private BigDecimal yearToDateInterestPaid;
    private String paymentOption;
    /*
     * Authorized to pay entity from account
     */
    private boolean paymentAllowed;

    public FinancialInstitution getFinancialInstitution() {
        return financialInstitution;
    }

    public void setFinancialInstitution(FinancialInstitution bank) {
        this.financialInstitution = bank;
    }

    public BigDecimal getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(BigDecimal accountBalance) {
        this.accountBalance = accountBalance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public Date getAccountBalanceDate() {
        return accountBalanceDate;
    }

    public void setAccountBalanceDate(Date accountBalanceDate) {
        this.accountBalanceDate = accountBalanceDate;
    }

    public BigDecimal getAvailableBalance() {
        return availableBalance;
    }

    public void setAvailableBalance(BigDecimal availableBalance) {
        this.availableBalance = availableBalance;
    }

    public boolean isPaymentAllowed() {
        return paymentAllowed;
    }

    public void setPaymentAllowed(boolean paymentAllowed) {
        this.paymentAllowed = paymentAllowed;
    }

    public Float getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(Float interestRate) {
        this.interestRate = interestRate;
    }

    public BigDecimal getLastInterestPaymentAmount() {
        return lastInterestPaymentAmount;
    }

    public void setLastInterestPaymentAmount(BigDecimal lastInterestPaymentAmount) {
        this.lastInterestPaymentAmount = lastInterestPaymentAmount;
    }

    public BigDecimal getLastStatementBalance() {
        return lastStatementBalance;
    }

    public void setLastStatementBalance(BigDecimal lastStatementBalance) {
        this.lastStatementBalance = lastStatementBalance;
    }

    public Date getLastStatementDate() {
        return lastStatementDate;
    }

    public void setLastStatementDate(Date lastStatementDate) {
        this.lastStatementDate = lastStatementDate;
    }

    public String getPaymentOption() {
        return paymentOption;
    }

    public void setPaymentOption(String paymentOption) {
        this.paymentOption = paymentOption;
    }

    public BigDecimal getYearToDateInterestPaid() {
        return yearToDateInterestPaid;
    }

    public void setYearToDateInterestPaid(BigDecimal yearToDateInterestPaid) {
        this.yearToDateInterestPaid = yearToDateInterestPaid;
    }

}
