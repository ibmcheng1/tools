/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

/**
 * Model object for financial account transactions
 *
 */
public class FinancialAccountTransaction implements Serializable {
    private static final long serialVersionUID = 1L;

    private static final String BCBSSC_MERCHANT = "BCBSSC";
    private static final String BLUECHOICE_MERCHANT = "BlueChoice";

    private String transactionId;
    private Date effectiveDate;
    private Date postingDate;
    private String transactionType;
    private String merchant;
    private String description;
    private BigDecimal amount;
    private String checkNumber;

    public String getDescription() {
        return description;
    }

    public void setDescription(String additionalDescription) {
        this.description = additionalDescription;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCheckNumber() {
        return checkNumber;
    }

    public void setCheckNumber(String checkNumber) {
        this.checkNumber = checkNumber;
    }

    public String getMerchant() {
        return merchant;
    }

    public void setMerchant(String description) {
        this.merchant = description;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public Date getPostingDate() {
        return postingDate;
    }

    public void setPostingDate(Date postingDate) {
        this.postingDate = postingDate;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    /**
     * Determines whether a transaction is a BCBSSC transaction based on the contents of the
     * merchant field.
     * 
     * @return true if BCBSSC transaction, false otherwise.
     */
    public boolean isBcbsscFlag() {
        return StringUtils.containsIgnoreCase(merchant,
                                              BCBSSC_MERCHANT);
    }

    /**
     * Determines whether a transaction is a BlueChoice transaction based on the contents of the
     * merchant field.
     * 
     * @return true if BlueChoice transaction, false otherwise.
     */
    public boolean isBlueChoiceFlag() {
        return StringUtils.containsIgnoreCase(merchant,
                                              BLUECHOICE_MERCHANT);
    }
}
