/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.dao;

import java.util.List;

import com.bcbssc.financial.model.ClaimPaymentReceiptSummary;
import com.bcbssc.financial.model.ReceiptSummarySearchCriteria;

/**
 * Interface for retrieve receipt listing.
 */
public interface ReceiptSummaryDAO {
    /**
     * Retrieve the payment receipt summary.
     *
     * @param criteria The criteria to use to get the receipt summary.
     * @return List of ClaimPaymentReceiptSummary objects
     */
    List<ClaimPaymentReceiptSummary> retrieveClientPaymentReceiptSummary(ReceiptSummarySearchCriteria criteria);
}
