/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */

package com.bcbssc.financial.dao.impl;

import com.bcbssc.financial.model.ClaimPaymentReceiptSummary;

import java.util.List;

/**
 * Value Object used to paginate Receipt list results.
 *
 */
public class WebServiceReceiptSummaryPagingResult {
    private String initialClaimNumber;
    private String initialDate;
    private String initialTransactionType;
    private String pageNumber;
    private String pageTotal;
    private List<ClaimPaymentReceiptSummary> receiptSummaries;

    public String getInitialClaimNumber() {
        return initialClaimNumber;
    }

    public void setInitialClaimNumber(String initialClaimNumber) {
        this.initialClaimNumber = initialClaimNumber;
    }

    public String getInitialDate() {
        return initialDate;
    }

    public void setInitialDate(String initialDate) {
        this.initialDate = initialDate;
    }

    public String getInitialTransactionType() {
        return initialTransactionType;
    }

    public void setInitialTransactionType(String initialTransactionType) {
        this.initialTransactionType = initialTransactionType;
    }

    public String getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(String pageNumber) {
        this.pageNumber = pageNumber;
    }

    public String getPageTotal() {
        return pageTotal;
    }

    public void setPageTotal(String pageTotal) {
        this.pageTotal = pageTotal;
    }

    public List<ClaimPaymentReceiptSummary> getReceiptSummaries() {
        return receiptSummaries;
    }

    public void setReceiptSummaries(List<ClaimPaymentReceiptSummary> receiptSummaries) {
        this.receiptSummaries = receiptSummaries;
    }
}
