/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.model;

import com.bcbssc.model.ClientBusinessSectorCode;

/**
 * Transfer object for search criteria for Payment system availability.
 *
 */
public class PaymentSystemAvailabilityCriteria {

    private ClientBusinessSectorCode _clientBusinessSectorCode = null;
    private String _partnerCode = null;

    /**
     * 
     * @param clientBusinessSectorCode The client business sector code to set.
     */
    public void setClientBusinessSectorCode(ClientBusinessSectorCode clientBusinessSectorCode) {
        _clientBusinessSectorCode = clientBusinessSectorCode;
    }

    public ClientBusinessSectorCode getClientBusinessSectorCode() {
        return _clientBusinessSectorCode;
    }

    /**
     * 
     * @param partnerCode The partner code to set.
     */
    public void setPartnerCode(String partnerCode) {
        _partnerCode = partnerCode;
    }

    public String getPartnerCode() {
        return _partnerCode;
    }

}
