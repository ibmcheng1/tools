/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.financial.model;

import com.bcbssc.model.ClientBusinessSectorCode;
import com.bcbssc.model.subscriber.Subscriber;

public class PaymentOptionInput {
    private ClientBusinessSectorCode sectorCode;
    private Subscriber subscriber;
    private String patientId;
    private String accountUpdate;
    private String paymentOption;

    /**
     * Gets the sectorCode.
     *
     * @return Returns the sectorCode.
     */
    public ClientBusinessSectorCode getSectorCode() {
        return sectorCode;
    }

    /**
     * Sets the sectorCode.
     *
     * @param sectorCode The sectorCode to set.
     */
    public void setSectorCode(ClientBusinessSectorCode sectorCode) {
        this.sectorCode = sectorCode;
    }

    /**
     * Gets the subscriber.
     *
     * @return Returns the subscriber.
     */
    public Subscriber getSubscriber() {
        return subscriber;
    }

    /**
     * Sets the subscriber.
     *
     * @param subscriber The subscriber to set.
     */
    public void setSubscriber(Subscriber subscriber) {
        this.subscriber = subscriber;
    }

    /**
     * Gets the patientId.
     *
     * @return Returns the patientId.
     */
    public String getPatientId() {
        return patientId;
    }

    /**
     * Sets the patientId.
     *
     * @param patientId The patientId to set.
     */
    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    /**
     * Gets the accountUpdate.
     *
     * @return Returns the accountUpdate.
     */
    public String getAccountUpdate() {
        return accountUpdate;
    }

    /**
     * Sets the accountUpdate.
     *
     * @param accountUpdate The accountUpdate to set.
     */
    public void setAccountUpdate(String accountUpdate) {
        this.accountUpdate = accountUpdate;
    }

    /**
     * Gets the paymentOption.
     *
     * @return Returns the paymentOption.
     */
    public String getPaymentOption() {
        return paymentOption;
    }

    /**
     * Sets the paymentOption.
     *
     * @param paymentOption The paymentOption to set.
     */
    public void setPaymentOption(String paymentOption) {
        this.paymentOption = paymentOption;
    }
}
