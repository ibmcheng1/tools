/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Model object for financial account snapshot.
 *
 */
public class FinancialAccountSnapshot implements Serializable {
    private static final long serialVersionUID = 1L;
    private String accountNumber;
    private BigDecimal balance;
    private BigDecimal lastStatementBalance;
    private boolean claimPaymentConsent;
    private Date lastUpdated;
    private Date lastStatementDate;

    /**
     * @return the accountNumber
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * @param accountNumber the accountNumber to set
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * @return the balance
     */
    public BigDecimal getBalance() {
        return balance;
    }

    /**
     * @param balance the balance to set
     */
    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    /**
     * @return the claimPaymentConsent
     */
    public boolean isClaimPaymentConsent() {
        return claimPaymentConsent;
    }

    /**
     * @param claimPaymentConsent the claimPaymentConsent to set
     */
    public void setClaimPaymentConsent(boolean claimPaymentConsent) {
        this.claimPaymentConsent = claimPaymentConsent;
    }

    /**
     * @return the lastUpdated
     */
    public Date getLastUpdated() {
        return lastUpdated;
    }

    /**
     * @param lastUpdated the lastUpdated to set
     */
    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    /**
     * @return the lastStatementBalance
     */
    public BigDecimal getLastStatementBalance() {
        return lastStatementBalance;
    }

    /**
     * @param lastStatementBalance the lastStatementBalance to set
     */
    public void setLastStatementBalance(BigDecimal lastStatementBalance) {
        this.lastStatementBalance = lastStatementBalance;
    }

    /**
     * @return the lastStatementDate
     */
    public Date getLastStatementDate() {
        return lastStatementDate;
    }

    /**
     * @param lastStatementDate the lastStatementDate to set
     */
    public void setLastStatementDate(Date lastStatementDate) {
        this.lastStatementDate = lastStatementDate;
    }
}
