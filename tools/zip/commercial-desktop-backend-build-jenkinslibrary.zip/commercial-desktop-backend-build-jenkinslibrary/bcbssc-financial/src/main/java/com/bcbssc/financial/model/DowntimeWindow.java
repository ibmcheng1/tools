/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.model;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.Serializable;
import java.util.Date;

/**
 * DowntimeWindow model object
 *
 */
public class DowntimeWindow implements Comparable, Serializable {

    private static final long serialVersionUID = 1L;
    private static final Log logger = LogFactory.getLog(DowntimeWindow.class);

    private Date startDate = null;
    private Date endDate = null;

    /**
     * 
     * @param startDate The start date for downtime.
     * @param endDate The end date for downtime.
     */
    public DowntimeWindow(Date startDate, Date endDate) {
        this.startDate = startDate;
        this.endDate = endDate;
    }

    /**
     * 
     * @return The start date for downtime.
     */
    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    /**
     * 
     * @return The end date for downtime.
     */
    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public int compareTo(Object in) {
        int rtn = 0;
        try {
            if (in != null && this.getStartDate() != null
                    && ((DowntimeWindow) in).getStartDate() != null) {
                if (this.getStartDate()
                        .before(((DowntimeWindow) in).getStartDate())) {
                    rtn = -1;
                } else if (this.getStartDate()
                               .after(((DowntimeWindow) in).getStartDate())) {
                    rtn = +1;
                }
            }
        } catch (ClassCastException cce) {
            logger.info("There was an error attempting to compare a DowntimeWindow object with something else.", cce);
        }
        return rtn;
    }

}
