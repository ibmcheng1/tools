/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.model;

import java.io.Serializable;

/**
 * Data Transport Object for Financial Institutions
 * 
 */
public class FinancialInstitution implements Serializable {

    private static final long serialVersionUID = 1L;
    private String routingNumber;
    private String name;
    private String phoneNumber;
    private String mondayHoursOfOperation;
    private String tuesdayHoursOfOperation;
    private String wednesdayHoursOfOperation;
    private String thursdayHoursOfOperation;
    private String fridayHoursOfOperation;
    private String saturdayHoursOfOperation;
    private String sundayHoursOfOperation;
    private String url;

    public String getFridayHoursOfOperation() {
        return fridayHoursOfOperation;
    }

    public void setFridayHoursOfOperation(String fridayHoursOfOperation) {
        this.fridayHoursOfOperation = fridayHoursOfOperation;
    }

    public String getMondayHoursOfOperation() {
        return mondayHoursOfOperation;
    }

    public void setMondayHoursOfOperation(String mondayHoursOfOperation) {
        this.mondayHoursOfOperation = mondayHoursOfOperation;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getRoutingNumber() {
        return routingNumber;
    }

    public void setRoutingNumber(String routingNumber) {
        this.routingNumber = routingNumber;
    }

    public String getSaturdayHoursOfOperation() {
        return saturdayHoursOfOperation;
    }

    public void setSaturdayHoursOfOperation(String saturdayHoursOfOperation) {
        this.saturdayHoursOfOperation = saturdayHoursOfOperation;
    }

    public String getSundayHoursOfOperation() {
        return sundayHoursOfOperation;
    }

    public void setSundayHoursOfOperation(String sundayHoursOfOperation) {
        this.sundayHoursOfOperation = sundayHoursOfOperation;
    }

    public String getThursdayHoursOfOperation() {
        return thursdayHoursOfOperation;
    }

    public void setThursdayHoursOfOperation(String thursdayHoursOfOperation) {
        this.thursdayHoursOfOperation = thursdayHoursOfOperation;
    }

    public String getTuesdayHoursOfOperation() {
        return tuesdayHoursOfOperation;
    }

    public void setTuesdayHoursOfOperation(String tuesdayHoursOfOperation) {
        this.tuesdayHoursOfOperation = tuesdayHoursOfOperation;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getWednesdayHoursOfOperation() {
        return wednesdayHoursOfOperation;
    }

    public void setWednesdayHoursOfOperation(String wednesdayHoursOfOperation) {
        this.wednesdayHoursOfOperation = wednesdayHoursOfOperation;
    }

}
