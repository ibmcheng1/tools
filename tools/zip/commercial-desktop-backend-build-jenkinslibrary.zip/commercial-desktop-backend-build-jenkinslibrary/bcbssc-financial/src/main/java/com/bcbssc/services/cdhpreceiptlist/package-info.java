@javax.xml.bind.annotation.XmlSchema(namespace = "http://CDHPReceiptList.RMRLT101EJB.claims.bcbssc.com")
package com.bcbssc.services.cdhpreceiptlist;
