/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2013 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.dao.impl;

import com.bcbssc.desktopshared.util.services.BaseServiceIntegrator;
import com.bcbssc.financial.dao.ReceiptSummaryDAO;
import com.bcbssc.financial.model.ClaimPaymentReceiptSummary;
import com.bcbssc.financial.model.ReceiptSummarySearchCriteria;
import com.bcbssc.services.cdhpreceiptlist.CDHPReceiptListInput;
import com.bcbssc.services.cdhpreceiptlist.CDHPReceiptListOutput;
import com.bcbssc.services.cdhpreceiptlist.CDHPReceiptListReceiptData;
import com.bcbssc.services.cdhpreceiptlist.CDHPReceiptListService;
import org.apache.commons.lang.StringUtils;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Web service implementation for ReceiptSummaryDAO. Service used is CDHPReceiptList.
 */
public class WebServiceReceiptSummaryDAOImpl extends BaseServiceIntegrator<CDHPReceiptListService, ReceiptSummarySearchCriteria, CDHPReceiptListInput, CDHPReceiptListOutput, WebServiceReceiptSummaryPagingResult> implements ReceiptSummaryDAO {
    private static final String OUTPUT_DATE_PATTERN = "MM/dd/yyyy";
    private static final String SEARCH_DATE_PATTERN = "MMddyyyy";
    private CDHPReceiptListService service;

    @Override
    public List<ClaimPaymentReceiptSummary> retrieveClientPaymentReceiptSummary(ReceiptSummarySearchCriteria criteria) {
        List<ClaimPaymentReceiptSummary> receiptSummaries = new ArrayList<>();
        WebServiceReceiptSummaryPagingResult pagingResult = null;
        try {
            // The webservice returns a max of 377 records per invocation. The following
            // logic repeatedly calls the webservice until it reaches the last page of data.
            // The results of each call are aggregated into one List.
            do {
                criteria.setPagingResult(pagingResult);
                pagingResult = this.consumeService(criteria);
                receiptSummaries.addAll(pagingResult.getReceiptSummaries());
            } while (!pagingResult.getPageNumber().equals(pagingResult.getPageTotal()));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return receiptSummaries;
    }

    @Override
    public void setService(CDHPReceiptListService service) {
        this.service = service;
    }

    @Override
    public CDHPReceiptListService getService() {
        return service;
    }

    @Override
    public CDHPReceiptListInput mapInput(ReceiptSummarySearchCriteria criteria) {
        CDHPReceiptListInput input = new CDHPReceiptListInput();
        mapCriteriaToInput(criteria, input);
        // If this is not the first invocation, then populate the service input
        // with WebServiceReceiptSummaryPagingResult data from previous invocation.
        if (criteria.getPagingResult() != null) {
            mapPagingResultToInput(criteria.getPagingResult(), input);
        }

        return input;
    }

    @Override
    public CDHPReceiptListOutput invokeService(CDHPReceiptListInput input, CDHPReceiptListService service) throws Exception {
        return service.getReceiptListing(input);
    }

    @Override
    public WebServiceReceiptSummaryPagingResult mapOutput(CDHPReceiptListOutput serviceOutput) {
        List<ClaimPaymentReceiptSummary> results = new ArrayList<>();
        WebServiceReceiptSummaryPagingResult pagingResult = mapOutputToPagingResult(results, serviceOutput);
        List<CDHPReceiptListReceiptData> array = serviceOutput.getReceiptData().getCDHPReceiptListReceiptData();
        for (CDHPReceiptListReceiptData receiptData : array) {
            if (StringUtils.isBlank(receiptData.getClaimNumber())) {
                break;
            }
            ClaimPaymentReceiptSummary summary = mapOutputToReceiptSummary(receiptData);
            results.add(summary);
        }
        return pagingResult;
    }

    void mapCriteriaToInput(final ReceiptSummarySearchCriteria criteria, CDHPReceiptListInput input) {
        input.setSubscriberId(criteria.getSubscriber().getDatabaseNumber());
        input.setRpn(criteria.getClientBusinessSectorCode().getRpn());
        input.setReceiptFromDate(formatDate(criteria.getFromDate(), SEARCH_DATE_PATTERN));
        input.setReceiptToDate(formatDate(criteria.getToDate(), SEARCH_DATE_PATTERN));
        input.setReceiptStatusIndicator(criteria.getStatusFilter() == null ? "S" : criteria.getStatusFilter());
        input.setVoidIndicator(criteria.isRetrieveVoided() ? "Y" : "N");

        input.setToEscapeChar(Boolean.FALSE);
    }

    void mapPagingResultToInput(final WebServiceReceiptSummaryPagingResult pagingResult, CDHPReceiptListInput input) {
        input.setInitialClaimNumber(pagingResult.getInitialClaimNumber());
        input.setInitialReceiptDate(pagingResult.getInitialDate());
        input.setInitialTransactionType(pagingResult.getInitialTransactionType());
        int pn = Integer.parseInt(pagingResult.getPageNumber());
        String requestedPage = Integer.toString(++pn);
        input.setRequestPageNumber(StringUtils.leftPad(requestedPage, 3, '0'));
    }

    ClaimPaymentReceiptSummary mapOutputToReceiptSummary(CDHPReceiptListReceiptData receiptData) {
        ClaimPaymentReceiptSummary summary = new ClaimPaymentReceiptSummary();
        summary.setAmount(parseBigDecimal(receiptData.getAmountPaid()));
        summary.setReceiptDate(parseDate(receiptData.getReceiptDate(), OUTPUT_DATE_PATTERN));
        summary.setClaimNumber(receiptData.getClaimNumber());
        summary.setProviderName(receiptData.getProviderName());
        summary.setStatus(receiptData.getReceiptStatus());
        summary.setType(receiptData.getTransactionType());
        summary.setVoid(receiptData.getVoidStatus());
        return summary;
    }

    WebServiceReceiptSummaryPagingResult mapOutputToPagingResult(List<ClaimPaymentReceiptSummary> results, CDHPReceiptListOutput serviceOutput) {
        CDHPReceiptListReceiptData receiptData = serviceOutput.getReceiptData().getCDHPReceiptListReceiptData().get(0);
        WebServiceReceiptSummaryPagingResult pagingResult = new WebServiceReceiptSummaryPagingResult();
        pagingResult.setInitialClaimNumber(receiptData.getClaimNumber());
        pagingResult.setInitialDate(receiptData.getReceiptDate());
        pagingResult.setInitialTransactionType(receiptData.getTransactionType());
        pagingResult.setPageNumber(serviceOutput.getPageNumber());
        pagingResult.setPageTotal(serviceOutput.getTotalPages());
        pagingResult.setReceiptSummaries(results);
        return pagingResult;
    }

    Date parseDate(String date, String format) {
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        Date result;
        try {
            result = formatter.parse(date);
        } catch (Exception e) {
            result = null;
        }
        return result;
    }

    String formatDate(Date date, String format) {
        SimpleDateFormat formater = new SimpleDateFormat(format);
        String result;
        try {
            result = formater.format(date);
        } catch (Exception e) {
            result = StringUtils.EMPTY;
        }
        return result;

    }

    private BigDecimal parseBigDecimal(String value) {
        BigDecimal result;
        try {
            result = new BigDecimal(value);
        } catch (Exception e) {
            result = null;
        }
        return result;
    }
}
