/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.model;

import java.io.Serializable;
import java.util.Date;

/**
 * Model object for metadata of financial accounts.
 *
 */
public class FinancialAccountMeta implements Serializable {
    private static final long serialVersionUID = 1L;
    private FinancialInstitution financialInstitution;
    private String subscriberSSN;
    private String subscriberDatabaseNumber;
    private String accountActiveIndicator;
    private String paymentOptionIndicator;
    private Date paymentEffDate;
    private Date accountCloseDate;

    /**
     * @return the accountActiveIndicator
     */
    public String getAccountActiveIndicator() {
        return accountActiveIndicator;
    }

    /**
     * @param accountActiveIndicator the accountActiveIndicator to set
     */
    public void setAccountActiveIndicator(String accountActiveIndicator) {
        this.accountActiveIndicator = accountActiveIndicator;
    }

    /**
     * @return the accountCloseDate
     */
    public Date getAccountCloseDate() {
        return accountCloseDate;
    }

    /**
     * @param accountCloseDate the accountCloseDate to set
     */
    public void setAccountCloseDate(Date accountCloseDate) {
        this.accountCloseDate = accountCloseDate;
    }

    /**
     * @return the financialInstitution
     */
    public FinancialInstitution getFinancialInstitution() {
        return financialInstitution;
    }

    /**
     * @param financialInstitution the financialInstitution to set
     */
    public void setFinancialInstitution(FinancialInstitution financialInstitution) {
        this.financialInstitution = financialInstitution;
    }

    /**
     * @return the paymentEffDate
     */
    public Date getPaymentEffDate() {
        return paymentEffDate;
    }

    /**
     * @param paymentEffDate the paymentEffDate to set
     */
    public void setPaymentEffDate(Date paymentEffDate) {
        this.paymentEffDate = paymentEffDate;
    }

    /**
     * @return the paymentOptionIndicator
     */
    public String getPaymentOptionIndicator() {
        return paymentOptionIndicator;
    }

    /**
     * @param paymentOptionIndicator the paymentOptionIndicator to set
     */
    public void setPaymentOptionIndicator(String paymentOptionIndicator) {
        this.paymentOptionIndicator = paymentOptionIndicator;
    }

    /**
     * @return the subscriberDatabaseNumber
     */
    public String getSubscriberDatabaseNumber() {
        return subscriberDatabaseNumber;
    }

    /**
     * @param subscriberDatabaseNumber the subscriberDatabaseNumber to set
     */
    public void setSubscriberDatabaseNumber(String subscriberDatabaseNumber) {
        this.subscriberDatabaseNumber = subscriberDatabaseNumber;
    }

    /**
     * @return the subscriberSSN
     */
    public String getSubscriberSSN() {
        return subscriberSSN;
    }

    /**
     * @param subscriberSSN the subscriberSSN to set
     */
    public void setSubscriberSSN(String subscriberSSN) {
        this.subscriberSSN = subscriberSSN;
    }
}
