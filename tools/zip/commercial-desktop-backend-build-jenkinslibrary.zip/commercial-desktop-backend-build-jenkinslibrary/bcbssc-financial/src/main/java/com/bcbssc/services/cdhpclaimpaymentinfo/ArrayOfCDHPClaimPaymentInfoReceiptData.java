
package com.bcbssc.services.cdhpclaimpaymentinfo;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ArrayOfCDHPClaimPaymentInfoReceiptData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ArrayOfCDHPClaimPaymentInfoReceiptData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CDHPClaimPaymentInfoReceiptData" type="{http://CDHPClaimPaymentInfo.RMPPT101EJB.claims.bcbssc.com}CDHPClaimPaymentInfoReceiptData" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArrayOfCDHPClaimPaymentInfoReceiptData", propOrder = {
    "cdhpClaimPaymentInfoReceiptData"
})
public class ArrayOfCDHPClaimPaymentInfoReceiptData {

    @XmlElement(name = "CDHPClaimPaymentInfoReceiptData", nillable = true)
    protected List<CDHPClaimPaymentInfoReceiptData> cdhpClaimPaymentInfoReceiptData;

    /**
     * Gets the value of the cdhpClaimPaymentInfoReceiptData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cdhpClaimPaymentInfoReceiptData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCDHPClaimPaymentInfoReceiptData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CDHPClaimPaymentInfoReceiptData }
     * 
     * 
     */
    public List<CDHPClaimPaymentInfoReceiptData> getCDHPClaimPaymentInfoReceiptData() {
        if (cdhpClaimPaymentInfoReceiptData == null) {
            cdhpClaimPaymentInfoReceiptData = new ArrayList<CDHPClaimPaymentInfoReceiptData>();
        }
        return this.cdhpClaimPaymentInfoReceiptData;
    }

}
