
package com.bcbssc.services.cdhpclaimpaymentinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CDHPClaimPaymentInfoInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CDHPClaimPaymentInfoInput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="requestRpn" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestAliasRpn" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestSubscriberId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestClaimNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestActionIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestTransactionType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestReceiptSource" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestLineOfBusiness" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestSubscriberFirstName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestSubscriberLastName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestSubscriberDateOfBirth" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestGroupNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestVoidIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestProviderNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestProviderName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestSubscriberSSN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestAccountNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestBankRoutingNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestDebitAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestReceiptStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="hostID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="hostPassword" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="toEscapeChar" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="MWIConfig" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="applTrace" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CDHPClaimPaymentInfoInput", propOrder = {
    "requestRpn",
    "requestAliasRpn",
    "requestSubscriberId",
    "requestClaimNumber",
    "requestActionIndicator",
    "requestTransactionType",
    "requestReceiptSource",
    "requestLineOfBusiness",
    "requestSubscriberFirstName",
    "requestSubscriberLastName",
    "requestSubscriberDateOfBirth",
    "requestGroupNumber",
    "requestVoidIndicator",
    "requestProviderNumber",
    "requestProviderName",
    "requestSubscriberSSN",
    "requestAccountNumber",
    "requestBankRoutingNumber",
    "requestDebitAmount",
    "requestReceiptStatus",
    "hostID",
    "hostPassword",
    "toEscapeChar",
    "mwiConfig",
    "applTrace"
})
public class CDHPClaimPaymentInfoInput {

    @XmlElement(required = true, nillable = true)
    protected String requestRpn;
    @XmlElement(required = true, nillable = true)
    protected String requestAliasRpn;
    @XmlElement(required = true, nillable = true)
    protected String requestSubscriberId;
    @XmlElement(required = true, nillable = true)
    protected String requestClaimNumber;
    @XmlElement(required = true, nillable = true)
    protected String requestActionIndicator;
    @XmlElement(required = true, nillable = true)
    protected String requestTransactionType;
    @XmlElement(required = true, nillable = true)
    protected String requestReceiptSource;
    @XmlElement(required = true, nillable = true)
    protected String requestLineOfBusiness;
    @XmlElement(required = true, nillable = true)
    protected String requestSubscriberFirstName;
    @XmlElement(required = true, nillable = true)
    protected String requestSubscriberLastName;
    @XmlElement(required = true, nillable = true)
    protected String requestSubscriberDateOfBirth;
    @XmlElement(required = true, nillable = true)
    protected String requestGroupNumber;
    @XmlElement(required = true, nillable = true)
    protected String requestVoidIndicator;
    @XmlElement(required = true, nillable = true)
    protected String requestProviderNumber;
    @XmlElement(required = true, nillable = true)
    protected String requestProviderName;
    @XmlElement(required = true, nillable = true)
    protected String requestSubscriberSSN;
    @XmlElement(required = true, nillable = true)
    protected String requestAccountNumber;
    @XmlElement(required = true, nillable = true)
    protected String requestBankRoutingNumber;
    @XmlElement(required = true, nillable = true)
    protected String requestDebitAmount;
    @XmlElement(required = true, nillable = true)
    protected String requestReceiptStatus;
    @XmlElement(required = true, nillable = true)
    protected String hostID;
    @XmlElement(required = true, nillable = true)
    protected String hostPassword;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean toEscapeChar;
    @XmlElement(name = "MWIConfig", required = true, nillable = true)
    protected String mwiConfig;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean applTrace;

    /**
     * Gets the value of the requestRpn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestRpn() {
        return requestRpn;
    }

    /**
     * Sets the value of the requestRpn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestRpn(String value) {
        this.requestRpn = value;
    }

    /**
     * Gets the value of the requestAliasRpn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestAliasRpn() {
        return requestAliasRpn;
    }

    /**
     * Sets the value of the requestAliasRpn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestAliasRpn(String value) {
        this.requestAliasRpn = value;
    }

    /**
     * Gets the value of the requestSubscriberId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestSubscriberId() {
        return requestSubscriberId;
    }

    /**
     * Sets the value of the requestSubscriberId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestSubscriberId(String value) {
        this.requestSubscriberId = value;
    }

    /**
     * Gets the value of the requestClaimNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestClaimNumber() {
        return requestClaimNumber;
    }

    /**
     * Sets the value of the requestClaimNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestClaimNumber(String value) {
        this.requestClaimNumber = value;
    }

    /**
     * Gets the value of the requestActionIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestActionIndicator() {
        return requestActionIndicator;
    }

    /**
     * Sets the value of the requestActionIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestActionIndicator(String value) {
        this.requestActionIndicator = value;
    }

    /**
     * Gets the value of the requestTransactionType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestTransactionType() {
        return requestTransactionType;
    }

    /**
     * Sets the value of the requestTransactionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestTransactionType(String value) {
        this.requestTransactionType = value;
    }

    /**
     * Gets the value of the requestReceiptSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestReceiptSource() {
        return requestReceiptSource;
    }

    /**
     * Sets the value of the requestReceiptSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestReceiptSource(String value) {
        this.requestReceiptSource = value;
    }

    /**
     * Gets the value of the requestLineOfBusiness property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestLineOfBusiness() {
        return requestLineOfBusiness;
    }

    /**
     * Sets the value of the requestLineOfBusiness property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestLineOfBusiness(String value) {
        this.requestLineOfBusiness = value;
    }

    /**
     * Gets the value of the requestSubscriberFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestSubscriberFirstName() {
        return requestSubscriberFirstName;
    }

    /**
     * Sets the value of the requestSubscriberFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestSubscriberFirstName(String value) {
        this.requestSubscriberFirstName = value;
    }

    /**
     * Gets the value of the requestSubscriberLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestSubscriberLastName() {
        return requestSubscriberLastName;
    }

    /**
     * Sets the value of the requestSubscriberLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestSubscriberLastName(String value) {
        this.requestSubscriberLastName = value;
    }

    /**
     * Gets the value of the requestSubscriberDateOfBirth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestSubscriberDateOfBirth() {
        return requestSubscriberDateOfBirth;
    }

    /**
     * Sets the value of the requestSubscriberDateOfBirth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestSubscriberDateOfBirth(String value) {
        this.requestSubscriberDateOfBirth = value;
    }

    /**
     * Gets the value of the requestGroupNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestGroupNumber() {
        return requestGroupNumber;
    }

    /**
     * Sets the value of the requestGroupNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestGroupNumber(String value) {
        this.requestGroupNumber = value;
    }

    /**
     * Gets the value of the requestVoidIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestVoidIndicator() {
        return requestVoidIndicator;
    }

    /**
     * Sets the value of the requestVoidIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestVoidIndicator(String value) {
        this.requestVoidIndicator = value;
    }

    /**
     * Gets the value of the requestProviderNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestProviderNumber() {
        return requestProviderNumber;
    }

    /**
     * Sets the value of the requestProviderNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestProviderNumber(String value) {
        this.requestProviderNumber = value;
    }

    /**
     * Gets the value of the requestProviderName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestProviderName() {
        return requestProviderName;
    }

    /**
     * Sets the value of the requestProviderName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestProviderName(String value) {
        this.requestProviderName = value;
    }

    /**
     * Gets the value of the requestSubscriberSSN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestSubscriberSSN() {
        return requestSubscriberSSN;
    }

    /**
     * Sets the value of the requestSubscriberSSN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestSubscriberSSN(String value) {
        this.requestSubscriberSSN = value;
    }

    /**
     * Gets the value of the requestAccountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestAccountNumber() {
        return requestAccountNumber;
    }

    /**
     * Sets the value of the requestAccountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestAccountNumber(String value) {
        this.requestAccountNumber = value;
    }

    /**
     * Gets the value of the requestBankRoutingNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestBankRoutingNumber() {
        return requestBankRoutingNumber;
    }

    /**
     * Sets the value of the requestBankRoutingNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestBankRoutingNumber(String value) {
        this.requestBankRoutingNumber = value;
    }

    /**
     * Gets the value of the requestDebitAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestDebitAmount() {
        return requestDebitAmount;
    }

    /**
     * Sets the value of the requestDebitAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestDebitAmount(String value) {
        this.requestDebitAmount = value;
    }

    /**
     * Gets the value of the requestReceiptStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestReceiptStatus() {
        return requestReceiptStatus;
    }

    /**
     * Sets the value of the requestReceiptStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestReceiptStatus(String value) {
        this.requestReceiptStatus = value;
    }

    /**
     * Gets the value of the hostID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHostID() {
        return hostID;
    }

    /**
     * Sets the value of the hostID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHostID(String value) {
        this.hostID = value;
    }

    /**
     * Gets the value of the hostPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHostPassword() {
        return hostPassword;
    }

    /**
     * Sets the value of the hostPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHostPassword(String value) {
        this.hostPassword = value;
    }

    /**
     * Gets the value of the toEscapeChar property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isToEscapeChar() {
        return toEscapeChar;
    }

    /**
     * Sets the value of the toEscapeChar property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setToEscapeChar(Boolean value) {
        this.toEscapeChar = value;
    }

    /**
     * Gets the value of the mwiConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMWIConfig() {
        return mwiConfig;
    }

    /**
     * Sets the value of the mwiConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMWIConfig(String value) {
        this.mwiConfig = value;
    }

    /**
     * Gets the value of the applTrace property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isApplTrace() {
        return applTrace;
    }

    /**
     * Sets the value of the applTrace property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setApplTrace(Boolean value) {
        this.applTrace = value;
    }

}
