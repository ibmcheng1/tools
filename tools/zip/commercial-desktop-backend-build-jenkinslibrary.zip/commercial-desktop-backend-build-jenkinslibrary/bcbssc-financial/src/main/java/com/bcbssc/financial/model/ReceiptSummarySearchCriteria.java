/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.model;

import java.util.Date;

import com.bcbssc.financial.dao.impl.WebServiceReceiptSummaryPagingResult;
import com.bcbssc.model.ClientBusinessSectorCode;
import com.bcbssc.model.subscriber.Subscriber;

/**
 *  Transfer object for the search criteria for Receipt Summary search.
 *
 */
public class ReceiptSummarySearchCriteria {
    private Subscriber subscriber;
    private ClientBusinessSectorCode clientBusinessSectorCode;
    private boolean retrieveVoided;
    private Date fromDate;
    private Date toDate;
    private String statusFilter;
    private WebServiceReceiptSummaryPagingResult pagingResult;

    public Subscriber getSubscriber() {
        return subscriber;
    }

    public void setSubscriber(Subscriber subscriber) {
        this.subscriber = subscriber;
    }

    public ClientBusinessSectorCode getClientBusinessSectorCode() {
        return clientBusinessSectorCode;
    }

    public void setClientBusinessSectorCode(ClientBusinessSectorCode clientBusinessSectorCode) {
        this.clientBusinessSectorCode = clientBusinessSectorCode;
    }

    public boolean isRetrieveVoided() {
        return retrieveVoided;
    }

    public void setRetrieveVoided(boolean retrieveVoided) {
        this.retrieveVoided = retrieveVoided;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    public String getStatusFilter() {
        return statusFilter;
    }

    public void setStatusFilter(String statusFilter) {
        this.statusFilter = statusFilter;
    }

    /**
     * Gets the pagingResult.
     *
     * @return Returns the pagingResult.
     */
    public WebServiceReceiptSummaryPagingResult getPagingResult() {
        return pagingResult;
    }

    /**
     * Sets the pagingResult.
     *
     * @param pagingResult The pagingResult to set.
     */
    public void setPagingResult(WebServiceReceiptSummaryPagingResult pagingResult) {
        this.pagingResult = pagingResult;
    }
}
