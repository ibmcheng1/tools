/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.dao;

import com.bcbssc.model.subscriber.Subscriber;

import java.util.List;

/**
 * DAO for accessing the Finacial Account Transaction History.
 *
 */
public interface FinancialAccountTransactionsDAO {

    /**
     * Searches for the account transaction history based on the given FincialAccountSearchCriteria
     * and returns a List of FincialAccountTransactions.
     * 
     * @param criteria  The criteria on which to search
     * @return a List of FinacialAccountTransactions
     */
    public List retrieveAccountHistory(FinancialAccountSearchCriteria criteria)
            throws Exception;

    /**
     * Searches for the account transaction history based on the given Subscriber Tax Id
     * and returns a List of FincialAccountTransactions.
     * 
     * @param subscriber  The criteria on which to search
     * @return a List of FinacialAccountTransactions
     */
    public List retrieveAccountHistoryByTaxId(Subscriber subscriber)
            throws Exception;
}
