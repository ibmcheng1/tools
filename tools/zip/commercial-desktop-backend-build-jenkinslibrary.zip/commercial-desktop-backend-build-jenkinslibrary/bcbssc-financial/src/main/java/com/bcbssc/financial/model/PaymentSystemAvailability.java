/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Encapsulates information about the availability of the CDHP claim payment system.
 *
 */
public class PaymentSystemAvailability implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String DOWNTYPE_IMMEDIATE = "IMMEDIATE";
    public static final String DOWNTYPE_SCHEDULED = "SCHEDULED";

    private String paymentSystemStatus = null;
    private List downtimeWindowList = new ArrayList();
    private boolean paymentEnabled = true;

    /**
     * @return the paymentEnabled
     */
    public boolean isPaymentEnabled() {
        return paymentEnabled;
    }

    /**
     * @param paymentsEnabled the paymentEnabled to set
     */
    public void setPaymentEnabled(boolean paymentsEnabled) {
        this.paymentEnabled = paymentsEnabled;
    }

    /**
     * @return the paymentSystemStatus
     */
    public String getPaymentSystemStatus() {
        return paymentSystemStatus;
    }

    /**
     * @param paymentSystemStatus the paymentSystemStatus to set
     */
    public void setPaymentSystemStatus(String paymentSystemStatus) {
        this.paymentSystemStatus = paymentSystemStatus;
    }

    /**
     * 
     * @return Returns a list of downtime windows.
     */
    public List getDowntimeWindowList() {
        return downtimeWindowList;
    }

    public void setDowntimeWindowList(List downtimeWindowList) {
        this.downtimeWindowList = downtimeWindowList;
    }

    /**
     * 
     */
    public String toString() {
        return "paymentSystemStatus=[" + paymentSystemStatus
                + "], paymentEnabled=[" + paymentEnabled
                + "], downtimeWindowList=[" + downtimeWindowList + "]";
    }

}
