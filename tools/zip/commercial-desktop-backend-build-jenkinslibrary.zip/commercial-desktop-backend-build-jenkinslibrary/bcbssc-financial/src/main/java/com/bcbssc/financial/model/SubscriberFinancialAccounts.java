/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.model;

/**
 * Model object for subscriber financial accounts.
 * 
 */
public class SubscriberFinancialAccounts {

    private FinancialAccount healthReimbursementAccount;
    private FinancialAccount medicalFlexibleSpendingAccount;
    private FinancialAccount dependentFlexibleSpendingAccount;
    private FinancialAccount healthSavingsAccount;

    public FinancialAccount getDependentFlexibleSpendingAccount() {
        return dependentFlexibleSpendingAccount;
    }

    public void setDependentFlexibleSpendingAccount(FinancialAccount dependentFlexibleSpendingAccount) {
        this.dependentFlexibleSpendingAccount =
            dependentFlexibleSpendingAccount;
    }

    public FinancialAccount getHealthReimbursementAccount() {
        return healthReimbursementAccount;
    }

    public void setHealthReimbursementAccount(FinancialAccount healthReimbursementAccount) {
        this.healthReimbursementAccount = healthReimbursementAccount;
    }

    public FinancialAccount getHealthSavingsAccount() {
        return healthSavingsAccount;
    }

    public void setHealthSavingsAccount(FinancialAccount healthSavingsAccount) {
        this.healthSavingsAccount = healthSavingsAccount;
    }

    public FinancialAccount getMedicalFlexibleSpendingAccount() {
        return medicalFlexibleSpendingAccount;
    }

    public void setMedicalFlexibleSpendingAccount(FinancialAccount medicalFlexibleSpendingAccount) {
        this.medicalFlexibleSpendingAccount = medicalFlexibleSpendingAccount;
    }

}
