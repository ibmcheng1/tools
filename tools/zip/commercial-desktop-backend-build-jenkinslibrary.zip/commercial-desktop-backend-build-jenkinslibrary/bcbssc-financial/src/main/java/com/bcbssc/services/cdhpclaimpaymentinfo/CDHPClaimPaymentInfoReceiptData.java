
package com.bcbssc.services.cdhpclaimpaymentinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CDHPClaimPaymentInfoReceiptData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CDHPClaimPaymentInfoReceiptData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="rpn" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="aliasRpn" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="subscriberId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="claimNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="actionIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="transactionType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="receiptSource" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lineOfBusiness" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="subscriberFirstName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="subscriberLastName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="subscriberDateOfBirth" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="groupNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="providerNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="providerName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="subscriberSocialSecurityNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="accountNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="bankRoutingNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="debitAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="merchantCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="accountUserName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="dateOfService" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="patientName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="providerCharges" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="accountPassword" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="transactionDateAndTime" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="receiptType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="trackingNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cardType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="referenceNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="authorizationCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="troutNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cardLastFourNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="amountPaid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="expirationDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="returnCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="receiptStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="bankErrorCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="bankErrorDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CDHPClaimPaymentInfoReceiptData", propOrder = {
    "rpn",
    "aliasRpn",
    "subscriberId",
    "claimNumber",
    "actionIndicator",
    "transactionType",
    "receiptSource",
    "lineOfBusiness",
    "subscriberFirstName",
    "subscriberLastName",
    "subscriberDateOfBirth",
    "groupNumber",
    "providerNumber",
    "providerName",
    "subscriberSocialSecurityNumber",
    "accountNumber",
    "bankRoutingNumber",
    "debitAmount",
    "merchantCode",
    "accountUserName",
    "dateOfService",
    "patientName",
    "providerCharges",
    "accountPassword",
    "transactionDateAndTime",
    "receiptType",
    "trackingNumber",
    "cardType",
    "referenceNumber",
    "authorizationCode",
    "troutNumber",
    "cardLastFourNumber",
    "amountPaid",
    "expirationDate",
    "returnCode",
    "receiptStatus",
    "bankErrorCode",
    "bankErrorDescription"
})
public class CDHPClaimPaymentInfoReceiptData {

    @XmlElement(required = true, nillable = true)
    protected String rpn;
    @XmlElement(required = true, nillable = true)
    protected String aliasRpn;
    @XmlElement(required = true, nillable = true)
    protected String subscriberId;
    @XmlElement(required = true, nillable = true)
    protected String claimNumber;
    @XmlElement(required = true, nillable = true)
    protected String actionIndicator;
    @XmlElement(required = true, nillable = true)
    protected String transactionType;
    @XmlElement(required = true, nillable = true)
    protected String receiptSource;
    @XmlElement(required = true, nillable = true)
    protected String lineOfBusiness;
    @XmlElement(required = true, nillable = true)
    protected String subscriberFirstName;
    @XmlElement(required = true, nillable = true)
    protected String subscriberLastName;
    @XmlElement(required = true, nillable = true)
    protected String subscriberDateOfBirth;
    @XmlElement(required = true, nillable = true)
    protected String groupNumber;
    @XmlElement(required = true, nillable = true)
    protected String providerNumber;
    @XmlElement(required = true, nillable = true)
    protected String providerName;
    @XmlElement(required = true, nillable = true)
    protected String subscriberSocialSecurityNumber;
    @XmlElement(required = true, nillable = true)
    protected String accountNumber;
    @XmlElement(required = true, nillable = true)
    protected String bankRoutingNumber;
    @XmlElement(required = true, nillable = true)
    protected String debitAmount;
    @XmlElement(required = true, nillable = true)
    protected String merchantCode;
    @XmlElement(required = true, nillable = true)
    protected String accountUserName;
    @XmlElement(required = true, nillable = true)
    protected String dateOfService;
    @XmlElement(required = true, nillable = true)
    protected String patientName;
    @XmlElement(required = true, nillable = true)
    protected String providerCharges;
    @XmlElement(required = true, nillable = true)
    protected String accountPassword;
    @XmlElement(required = true, nillable = true)
    protected String transactionDateAndTime;
    @XmlElement(required = true, nillable = true)
    protected String receiptType;
    @XmlElement(required = true, nillable = true)
    protected String trackingNumber;
    @XmlElement(required = true, nillable = true)
    protected String cardType;
    @XmlElement(required = true, nillable = true)
    protected String referenceNumber;
    @XmlElement(required = true, nillable = true)
    protected String authorizationCode;
    @XmlElement(required = true, nillable = true)
    protected String troutNumber;
    @XmlElement(required = true, nillable = true)
    protected String cardLastFourNumber;
    @XmlElement(required = true, nillable = true)
    protected String amountPaid;
    @XmlElement(required = true, nillable = true)
    protected String expirationDate;
    @XmlElement(required = true, nillable = true)
    protected String returnCode;
    @XmlElement(required = true, nillable = true)
    protected String receiptStatus;
    @XmlElement(required = true, nillable = true)
    protected String bankErrorCode;
    @XmlElement(required = true, nillable = true)
    protected String bankErrorDescription;

    /**
     * Gets the value of the rpn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRpn() {
        return rpn;
    }

    /**
     * Sets the value of the rpn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRpn(String value) {
        this.rpn = value;
    }

    /**
     * Gets the value of the aliasRpn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAliasRpn() {
        return aliasRpn;
    }

    /**
     * Sets the value of the aliasRpn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAliasRpn(String value) {
        this.aliasRpn = value;
    }

    /**
     * Gets the value of the subscriberId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriberId() {
        return subscriberId;
    }

    /**
     * Sets the value of the subscriberId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriberId(String value) {
        this.subscriberId = value;
    }

    /**
     * Gets the value of the claimNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimNumber() {
        return claimNumber;
    }

    /**
     * Sets the value of the claimNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimNumber(String value) {
        this.claimNumber = value;
    }

    /**
     * Gets the value of the actionIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActionIndicator() {
        return actionIndicator;
    }

    /**
     * Sets the value of the actionIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActionIndicator(String value) {
        this.actionIndicator = value;
    }

    /**
     * Gets the value of the transactionType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionType() {
        return transactionType;
    }

    /**
     * Sets the value of the transactionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionType(String value) {
        this.transactionType = value;
    }

    /**
     * Gets the value of the receiptSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptSource() {
        return receiptSource;
    }

    /**
     * Sets the value of the receiptSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptSource(String value) {
        this.receiptSource = value;
    }

    /**
     * Gets the value of the lineOfBusiness property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    /**
     * Sets the value of the lineOfBusiness property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLineOfBusiness(String value) {
        this.lineOfBusiness = value;
    }

    /**
     * Gets the value of the subscriberFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriberFirstName() {
        return subscriberFirstName;
    }

    /**
     * Sets the value of the subscriberFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriberFirstName(String value) {
        this.subscriberFirstName = value;
    }

    /**
     * Gets the value of the subscriberLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriberLastName() {
        return subscriberLastName;
    }

    /**
     * Sets the value of the subscriberLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriberLastName(String value) {
        this.subscriberLastName = value;
    }

    /**
     * Gets the value of the subscriberDateOfBirth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriberDateOfBirth() {
        return subscriberDateOfBirth;
    }

    /**
     * Sets the value of the subscriberDateOfBirth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriberDateOfBirth(String value) {
        this.subscriberDateOfBirth = value;
    }

    /**
     * Gets the value of the groupNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupNumber() {
        return groupNumber;
    }

    /**
     * Sets the value of the groupNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupNumber(String value) {
        this.groupNumber = value;
    }

    /**
     * Gets the value of the providerNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderNumber() {
        return providerNumber;
    }

    /**
     * Sets the value of the providerNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderNumber(String value) {
        this.providerNumber = value;
    }

    /**
     * Gets the value of the providerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderName() {
        return providerName;
    }

    /**
     * Sets the value of the providerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderName(String value) {
        this.providerName = value;
    }

    /**
     * Gets the value of the subscriberSocialSecurityNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriberSocialSecurityNumber() {
        return subscriberSocialSecurityNumber;
    }

    /**
     * Sets the value of the subscriberSocialSecurityNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriberSocialSecurityNumber(String value) {
        this.subscriberSocialSecurityNumber = value;
    }

    /**
     * Gets the value of the accountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Sets the value of the accountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNumber(String value) {
        this.accountNumber = value;
    }

    /**
     * Gets the value of the bankRoutingNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankRoutingNumber() {
        return bankRoutingNumber;
    }

    /**
     * Sets the value of the bankRoutingNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankRoutingNumber(String value) {
        this.bankRoutingNumber = value;
    }

    /**
     * Gets the value of the debitAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebitAmount() {
        return debitAmount;
    }

    /**
     * Sets the value of the debitAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebitAmount(String value) {
        this.debitAmount = value;
    }

    /**
     * Gets the value of the merchantCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMerchantCode() {
        return merchantCode;
    }

    /**
     * Sets the value of the merchantCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMerchantCode(String value) {
        this.merchantCode = value;
    }

    /**
     * Gets the value of the accountUserName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountUserName() {
        return accountUserName;
    }

    /**
     * Sets the value of the accountUserName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountUserName(String value) {
        this.accountUserName = value;
    }

    /**
     * Gets the value of the dateOfService property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateOfService() {
        return dateOfService;
    }

    /**
     * Sets the value of the dateOfService property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateOfService(String value) {
        this.dateOfService = value;
    }

    /**
     * Gets the value of the patientName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientName() {
        return patientName;
    }

    /**
     * Sets the value of the patientName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientName(String value) {
        this.patientName = value;
    }

    /**
     * Gets the value of the providerCharges property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderCharges() {
        return providerCharges;
    }

    /**
     * Sets the value of the providerCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderCharges(String value) {
        this.providerCharges = value;
    }

    /**
     * Gets the value of the accountPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountPassword() {
        return accountPassword;
    }

    /**
     * Sets the value of the accountPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountPassword(String value) {
        this.accountPassword = value;
    }

    /**
     * Gets the value of the transactionDateAndTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionDateAndTime() {
        return transactionDateAndTime;
    }

    /**
     * Sets the value of the transactionDateAndTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionDateAndTime(String value) {
        this.transactionDateAndTime = value;
    }

    /**
     * Gets the value of the receiptType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptType() {
        return receiptType;
    }

    /**
     * Sets the value of the receiptType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptType(String value) {
        this.receiptType = value;
    }

    /**
     * Gets the value of the trackingNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrackingNumber() {
        return trackingNumber;
    }

    /**
     * Sets the value of the trackingNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrackingNumber(String value) {
        this.trackingNumber = value;
    }

    /**
     * Gets the value of the cardType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardType() {
        return cardType;
    }

    /**
     * Sets the value of the cardType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardType(String value) {
        this.cardType = value;
    }

    /**
     * Gets the value of the referenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReferenceNumber() {
        return referenceNumber;
    }

    /**
     * Sets the value of the referenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReferenceNumber(String value) {
        this.referenceNumber = value;
    }

    /**
     * Gets the value of the authorizationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthorizationCode() {
        return authorizationCode;
    }

    /**
     * Sets the value of the authorizationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthorizationCode(String value) {
        this.authorizationCode = value;
    }

    /**
     * Gets the value of the troutNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTroutNumber() {
        return troutNumber;
    }

    /**
     * Sets the value of the troutNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTroutNumber(String value) {
        this.troutNumber = value;
    }

    /**
     * Gets the value of the cardLastFourNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardLastFourNumber() {
        return cardLastFourNumber;
    }

    /**
     * Sets the value of the cardLastFourNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardLastFourNumber(String value) {
        this.cardLastFourNumber = value;
    }

    /**
     * Gets the value of the amountPaid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmountPaid() {
        return amountPaid;
    }

    /**
     * Sets the value of the amountPaid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmountPaid(String value) {
        this.amountPaid = value;
    }

    /**
     * Gets the value of the expirationDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExpirationDate() {
        return expirationDate;
    }

    /**
     * Sets the value of the expirationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpirationDate(String value) {
        this.expirationDate = value;
    }

    /**
     * Gets the value of the returnCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReturnCode() {
        return returnCode;
    }

    /**
     * Sets the value of the returnCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReturnCode(String value) {
        this.returnCode = value;
    }

    /**
     * Gets the value of the receiptStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptStatus() {
        return receiptStatus;
    }

    /**
     * Sets the value of the receiptStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptStatus(String value) {
        this.receiptStatus = value;
    }

    /**
     * Gets the value of the bankErrorCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankErrorCode() {
        return bankErrorCode;
    }

    /**
     * Sets the value of the bankErrorCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankErrorCode(String value) {
        this.bankErrorCode = value;
    }

    /**
     * Gets the value of the bankErrorDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankErrorDescription() {
        return bankErrorDescription;
    }

    /**
     * Sets the value of the bankErrorDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankErrorDescription(String value) {
        this.bankErrorDescription = value;
    }

}
