
package com.bcbssc.services.cdhpreceiptlist;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CDHPReceiptListInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CDHPReceiptListInput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="rpn" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="subscriberId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="terminalId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="voidIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="receiptFromDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="receiptToDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="viewClaim" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="subClaimNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="claimAdjustmentLevel" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="receiptStatusIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestPageNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="initialClaimNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="initialReceiptDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="initialTransactionType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="hostID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="hostPassword" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="toEscapeChar" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="MWIConfig" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="applTrace" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CDHPReceiptListInput", propOrder = {
    "rpn",
    "subscriberId",
    "terminalId",
    "voidIndicator",
    "receiptFromDate",
    "receiptToDate",
    "viewClaim",
    "subClaimNumber",
    "claimAdjustmentLevel",
    "receiptStatusIndicator",
    "requestPageNumber",
    "initialClaimNumber",
    "initialReceiptDate",
    "initialTransactionType",
    "hostID",
    "hostPassword",
    "toEscapeChar",
    "mwiConfig",
    "applTrace"
})
public class CDHPReceiptListInput {

    @XmlElement(required = true, nillable = true)
    protected String rpn;
    @XmlElement(required = true, nillable = true)
    protected String subscriberId;
    @XmlElement(required = true, nillable = true)
    protected String terminalId;
    @XmlElement(required = true, nillable = true)
    protected String voidIndicator;
    @XmlElement(required = true, nillable = true)
    protected String receiptFromDate;
    @XmlElement(required = true, nillable = true)
    protected String receiptToDate;
    @XmlElement(required = true, nillable = true)
    protected String viewClaim;
    @XmlElement(required = true, nillable = true)
    protected String subClaimNumber;
    @XmlElement(required = true, nillable = true)
    protected String claimAdjustmentLevel;
    @XmlElement(required = true, nillable = true)
    protected String receiptStatusIndicator;
    @XmlElement(required = true, nillable = true)
    protected String requestPageNumber;
    @XmlElement(required = true, nillable = true)
    protected String initialClaimNumber;
    @XmlElement(required = true, nillable = true)
    protected String initialReceiptDate;
    @XmlElement(required = true, nillable = true)
    protected String initialTransactionType;
    @XmlElement(required = true, nillable = true)
    protected String hostID;
    @XmlElement(required = true, nillable = true)
    protected String hostPassword;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean toEscapeChar;
    @XmlElement(name = "MWIConfig", required = true, nillable = true)
    protected String mwiConfig;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean applTrace;

    /**
     * Gets the value of the rpn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRpn() {
        return rpn;
    }

    /**
     * Sets the value of the rpn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRpn(String value) {
        this.rpn = value;
    }

    /**
     * Gets the value of the subscriberId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriberId() {
        return subscriberId;
    }

    /**
     * Sets the value of the subscriberId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriberId(String value) {
        this.subscriberId = value;
    }

    /**
     * Gets the value of the terminalId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTerminalId() {
        return terminalId;
    }

    /**
     * Sets the value of the terminalId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTerminalId(String value) {
        this.terminalId = value;
    }

    /**
     * Gets the value of the voidIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVoidIndicator() {
        return voidIndicator;
    }

    /**
     * Sets the value of the voidIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVoidIndicator(String value) {
        this.voidIndicator = value;
    }

    /**
     * Gets the value of the receiptFromDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptFromDate() {
        return receiptFromDate;
    }

    /**
     * Sets the value of the receiptFromDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptFromDate(String value) {
        this.receiptFromDate = value;
    }

    /**
     * Gets the value of the receiptToDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptToDate() {
        return receiptToDate;
    }

    /**
     * Sets the value of the receiptToDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptToDate(String value) {
        this.receiptToDate = value;
    }

    /**
     * Gets the value of the viewClaim property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getViewClaim() {
        return viewClaim;
    }

    /**
     * Sets the value of the viewClaim property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setViewClaim(String value) {
        this.viewClaim = value;
    }

    /**
     * Gets the value of the subClaimNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubClaimNumber() {
        return subClaimNumber;
    }

    /**
     * Sets the value of the subClaimNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubClaimNumber(String value) {
        this.subClaimNumber = value;
    }

    /**
     * Gets the value of the claimAdjustmentLevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimAdjustmentLevel() {
        return claimAdjustmentLevel;
    }

    /**
     * Sets the value of the claimAdjustmentLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimAdjustmentLevel(String value) {
        this.claimAdjustmentLevel = value;
    }

    /**
     * Gets the value of the receiptStatusIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptStatusIndicator() {
        return receiptStatusIndicator;
    }

    /**
     * Sets the value of the receiptStatusIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptStatusIndicator(String value) {
        this.receiptStatusIndicator = value;
    }

    /**
     * Gets the value of the requestPageNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestPageNumber() {
        return requestPageNumber;
    }

    /**
     * Sets the value of the requestPageNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestPageNumber(String value) {
        this.requestPageNumber = value;
    }

    /**
     * Gets the value of the initialClaimNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInitialClaimNumber() {
        return initialClaimNumber;
    }

    /**
     * Sets the value of the initialClaimNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInitialClaimNumber(String value) {
        this.initialClaimNumber = value;
    }

    /**
     * Gets the value of the initialReceiptDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInitialReceiptDate() {
        return initialReceiptDate;
    }

    /**
     * Sets the value of the initialReceiptDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInitialReceiptDate(String value) {
        this.initialReceiptDate = value;
    }

    /**
     * Gets the value of the initialTransactionType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInitialTransactionType() {
        return initialTransactionType;
    }

    /**
     * Sets the value of the initialTransactionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInitialTransactionType(String value) {
        this.initialTransactionType = value;
    }

    /**
     * Gets the value of the hostID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHostID() {
        return hostID;
    }

    /**
     * Sets the value of the hostID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHostID(String value) {
        this.hostID = value;
    }

    /**
     * Gets the value of the hostPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHostPassword() {
        return hostPassword;
    }

    /**
     * Sets the value of the hostPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHostPassword(String value) {
        this.hostPassword = value;
    }

    /**
     * Gets the value of the toEscapeChar property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isToEscapeChar() {
        return toEscapeChar;
    }

    /**
     * Sets the value of the toEscapeChar property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setToEscapeChar(Boolean value) {
        this.toEscapeChar = value;
    }

    /**
     * Gets the value of the mwiConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMWIConfig() {
        return mwiConfig;
    }

    /**
     * Sets the value of the mwiConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMWIConfig(String value) {
        this.mwiConfig = value;
    }

    /**
     * Gets the value of the applTrace property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isApplTrace() {
        return applTrace;
    }

    /**
     * Sets the value of the applTrace property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setApplTrace(Boolean value) {
        this.applTrace = value;
    }

}
