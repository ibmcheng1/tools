/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.dao;

import com.bcbssc.financial.model.FinancialAccountMeta;
import com.bcbssc.model.ClientBusinessSectorCode;
import com.bcbssc.model.subscriber.Subscriber;

/**
 * Interface for Financial account operations.
 *
 */
public interface FinancialAccountMetaDAO {

    /**
     * Retrieves financial account metadata for a given subscriber and line of
     * business.
     * @param subscriber the Subscriber for whom to look up financial account
     * metadata (i.e. information about a health savings account, etc).
     * @param patientId The patient for whom to look up the financial account.
     * @param cbsc The client business sector code to use to lookup data.
     * @return a FinancialAccountMeta object representing keys to a Subscriber's
     * financial account, or <code>null</code> if the subscriber has no such
     * account.
     */
    public FinancialAccountMeta retrieveAccountMeta(Subscriber subscriber,
                                                    String patientId,
                                                    ClientBusinessSectorCode cbsc);

    /**
     * Updates patients paymentOption and returns updated financial meta data
     * etc).
     * @param subscriber the Subscriber for whom to set the payment option for.
     * @param patientId The patient for whom to set the payment option for.
     * @param paymentOption The option to update.
     * @param cbsc The client business sector code to use to lookup data.
     * @return a FinancialAccountMeta object representing keys to a Subscriber's
     * financial account, or <code>null</code> if the subscriber has no such
     * account.
     */
    public FinancialAccountMeta updatePaymentOption(Subscriber subscriber,
                                                    String patientId,
                                                    String paymentOption,
                                                    ClientBusinessSectorCode cbsc);

}
