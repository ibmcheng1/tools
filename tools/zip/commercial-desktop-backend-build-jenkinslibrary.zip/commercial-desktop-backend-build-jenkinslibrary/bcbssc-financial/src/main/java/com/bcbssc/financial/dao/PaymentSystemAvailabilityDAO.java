/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.dao;

import com.bcbssc.financial.model.PaymentSystemAvailability;
import com.bcbssc.financial.model.PaymentSystemAvailabilityCriteria;

/**
 * The PaymentSystemAvailabilityDAO is responsible for retrieving the active status of the CDHP Claim Payment system - IE is it available or not.
 *
 *
 */
public interface PaymentSystemAvailabilityDAO {

    /**
     * Retrieves the active status of the CDHP Claim Payment system - IE is it available or not.
     * @param paymentSystemAvailabilityCriteria the criteria to use to get the availability.
     * @return a PaymentSystemAvailability response containing information on the level of 
     * availability of cdhp claim payment processing.
     */
    PaymentSystemAvailability getPaymentSystemAvailability(PaymentSystemAvailabilityCriteria paymentSystemAvailabilityCriteria);
}
