/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.biz;

import java.util.List;

import com.bcbssc.financial.model.ClaimPayment;
import com.bcbssc.financial.model.ClaimPaymentReceipt;
import com.bcbssc.financial.model.PaymentSystemAvailability;
import com.bcbssc.financial.model.PaymentSystemAvailabilityCriteria;

/**
 * ClaimPaymentBD interface
 *
 */
public interface ClaimPaymentBD {
    /**
     * Submit a payment for a claim.
     *
     * @param payment The payment information to submit.
     * @return Returns a {@link ClaimPaymentReceipt} object with the receipt information.
     */
    public ClaimPaymentReceipt submitClaimPayment(ClaimPayment payment);

    /**
     * Retrieves the latest payment receipt.
     *
     * @param payment The payment to use to lookup receipts.
     * @return Returns a {@link ClaimPaymentReceipt} object representing the latest receipt.
     */
    public ClaimPaymentReceipt retrieveLatestClaimPaymentReceipt(ClaimPayment payment);

    /**
     * Retrieves the list of receipts for a given payment.
     *
     * @param payment The payment to use to lookup receipts.
     * @return Returns a List of {@link ClaimPaymentReceipt} objects representing the list of receipts for the payment.
     */
    public List retrieveClaimPaymentReceipts(ClaimPayment payment);

    /**
     * Retrieves the system availability.
     *
     * @param paymentSystemAvailabilityCriteria The criteria to use to get availability.
     * @return Returns a {@link PaymentSystemAvailability} object representing the availability of the system.
     */
    public PaymentSystemAvailability getSystemAvailability(PaymentSystemAvailabilityCriteria paymentSystemAvailabilityCriteria);
}
