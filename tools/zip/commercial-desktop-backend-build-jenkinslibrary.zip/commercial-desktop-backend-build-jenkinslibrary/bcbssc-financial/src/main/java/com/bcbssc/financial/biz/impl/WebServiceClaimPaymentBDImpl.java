/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2013 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 */
package com.bcbssc.financial.biz.impl;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.bcbssc.desktopshared.util.services.BaseServiceIntegrator;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;

import com.bcbssc.financial.biz.ClaimPaymentBD;
import com.bcbssc.financial.model.ClaimPayment;
import com.bcbssc.financial.model.ClaimPaymentReceipt;
import com.bcbssc.financial.model.PaymentSystemAvailability;
import com.bcbssc.financial.model.PaymentSystemAvailabilityCriteria;
import com.bcbssc.services.cdhpclaimpaymentinfo.CDHPClaimPaymentInfoInput;
import com.bcbssc.services.cdhpclaimpaymentinfo.CDHPClaimPaymentInfoOutput;
import com.bcbssc.services.cdhpclaimpaymentinfo.CDHPClaimPaymentInfoReceiptData;
import com.bcbssc.services.cdhpclaimpaymentinfo.CDHPClaimPaymentInfoService;

/**
 * Webservice implementation of ClaimPaymentBD. CDHPClaimPaymentInfo is the service name in UDDI
 */
public class WebServiceClaimPaymentBDImpl extends BaseServiceIntegrator<CDHPClaimPaymentInfoService, ClaimPayment, CDHPClaimPaymentInfoInput, CDHPClaimPaymentInfoOutput, List<ClaimPaymentReceipt>> implements ClaimPaymentBD {

    private static final String[] DATE_PATTERNS = { "MM-dd-yyyy", "yyyyMMddHHmmss", "yyyy-MM-dd-HH.mm.ss", "MM/dd/yyyy" };

    private CDHPClaimPaymentInfoService service;

    /**
     * @see com.bcbssc.financial.biz.ClaimPaymentBD#retrieveLatestClaimPaymentReceipt(com.bcbssc.financial.model.ClaimPayment)
     */
    @Override
    public ClaimPaymentReceipt retrieveLatestClaimPaymentReceipt(ClaimPayment payment) {
        return retrieveClaimPaymentReceipts(payment).get(0);
    }

    @Override
    public List<ClaimPaymentReceipt> retrieveClaimPaymentReceipts(ClaimPayment payment) {
        payment.setReceiptMode(true);
        return this.consumeService(payment);
    }

    @Override
    public ClaimPaymentReceipt submitClaimPayment(ClaimPayment payment) {
        payment.setReceiptMode(false);
        List<ClaimPaymentReceipt> reciepts = this.consumeService(payment);
        return reciepts.get(0);
    }

    @Override
    public PaymentSystemAvailability getSystemAvailability(PaymentSystemAvailabilityCriteria paymentSystemAvailabilityCriteria) {
        //return getAvailabilityDAO().getPaymentSystemAvailability(paymentSystemAvailabilityCriteria);
        throw new UnsupportedOperationException("This method is not yet implemeneted.");
    }

    @Override
    public void setService(CDHPClaimPaymentInfoService service) {
        this.service = service;
    }

    @Override
    public CDHPClaimPaymentInfoService getService() {
        return service;
    }

    @Override
    public CDHPClaimPaymentInfoInput mapInput(ClaimPayment payment) {
        CDHPClaimPaymentInfoInput serviceInput = new CDHPClaimPaymentInfoInput();

        String paymentAmount = "0";

        if (payment.getPaymentAmount() != null) {
            paymentAmount = payment.getPaymentAmount().toString();
        }

        serviceInput.setRequestRpn(payment.getClientBusinessSector().getRpn());

        // ReturnReceiptListing Criteria - optional fields.
        // receiptStatus: S = "Successful", D = "Declined", I = "Incomplete"
        //                The statuses can be combined into one string "SDI"
        // voidIndicator: Y = "Show Voids", N = "Don't show voids"
        String receiptStatus = payment.getReceiptStatusFilter();
        String voidIndicator = payment.getShowVoidedReceipts();
        serviceInput.setRequestReceiptStatus(receiptStatus == null ? "SDI" : receiptStatus);
        serviceInput.setRequestVoidIndicator(voidIndicator == null ? "N" : voidIndicator);

        // for the alias so we are reusing getRpn
        serviceInput.setRequestAliasRpn(payment.getClientBusinessSector().getRpn());

        serviceInput.setRequestDebitAmount(paymentAmount);
        serviceInput.setRequestBankRoutingNumber(payment.getBankRoutingNumber());
        serviceInput.setRequestAccountNumber(payment.getAccountNumber());
        serviceInput.setRequestLineOfBusiness("H"); // H is for HEALTH

        serviceInput.setRequestClaimNumber(payment.getClaimNumber());
        serviceInput.setRequestProviderName(payment.getProviderName());
        serviceInput.setRequestProviderNumber(payment.getProviderNumber());

        // Bluechoice subscriber number prefix added, if needed
        String subscriberId = payment.getSubscriber().getDatabaseNumber();
        if ("035".equals(payment.getClientBusinessSector().getRpn()) && !subscriberId.startsWith("K")) {
            subscriberId = "K" + subscriberId;
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
        serviceInput.setRequestSubscriberDateOfBirth(dateFormat.format(payment.getSubscriber().getDateOfBirth()));

        serviceInput.setRequestSubscriberId(subscriberId);
        serviceInput.setRequestSubscriberFirstName(payment.getSubscriber().getPersonName().getFirstName());
        serviceInput.setRequestSubscriberLastName(payment.getSubscriber().getPersonName().getLastName());
        serviceInput.setRequestSubscriberSSN(payment.getSubscriber().getSocialSecurityNumber());
        serviceInput.setRequestGroupNumber(payment.getSubscriber().getGroupNumber());

        if (payment.isReceiptMode()) {
            serviceInput.setRequestActionIndicator("R");
        } else {
            // Payment transaction
            serviceInput.setRequestActionIndicator("P");
        }

        serviceInput.setRequestReceiptSource("W");
        return serviceInput;
    }

    @Override
    public CDHPClaimPaymentInfoOutput invokeService(CDHPClaimPaymentInfoInput input, CDHPClaimPaymentInfoService service) throws Exception {
        return service.payClaimOrViewReceipt(input);
    }

    @Override
    public List<ClaimPaymentReceipt> mapOutput(CDHPClaimPaymentInfoOutput serviceOutput) {
        List<ClaimPaymentReceipt> results = new ArrayList<>();
        List<CDHPClaimPaymentInfoReceiptData> receipts = serviceOutput.getReceiptData().getCDHPClaimPaymentInfoReceiptData();

        for (CDHPClaimPaymentInfoReceiptData serviceReceipt : receipts) {
            // Break out on blank fields, to avoid empty records
            if (StringUtils.isBlank(serviceReceipt.getAmountPaid()) && StringUtils.isBlank(serviceReceipt.getDebitAmount())) {
                break;
            }

            ClaimPaymentReceipt receipt = new ClaimPaymentReceipt();
            try {
                receipt.setAmountPaid(new BigDecimal(serviceReceipt.getAmountPaid()));
            } catch (NumberFormatException e) {
                receipt.setAmountPaid(null);
            }

            receipt.setTransactionDate(parseDate(serviceReceipt.getTransactionDateAndTime()));
            receipt.setAuthorizationCode(serviceReceipt.getAuthorizationCode());
            receipt.setBankErrorCode(serviceReceipt.getBankErrorCode());
            receipt.setBankErrorDescription(serviceReceipt.getBankErrorDescription());
            receipt.setReferenceNumber(serviceReceipt.getReferenceNumber());
            receipt.setReturnCode(serviceReceipt.getReturnCode());
            receipt.setReceiptStatus(serviceReceipt.getReceiptStatus());
            receipt.setCreditCardNumber(serviceReceipt.getCardLastFourNumber());
            receipt.setCardType(serviceReceipt.getCardType());
            receipt.setTransactionType(serviceReceipt.getReceiptType());
            receipt.setClaimNumber(serviceReceipt.getClaimNumber());
            receipt.setSubscriberId(serviceReceipt.getSubscriberId());
            receipt.setSubscriberName(serviceReceipt.getSubscriberFirstName() + " " + serviceReceipt.getSubscriberLastName());
            receipt.setPatientName(serviceReceipt.getPatientName());
            receipt.setProviderName(serviceReceipt.getProviderName());
            receipt.setDateOfService(parseDate(serviceReceipt.getDateOfService()));

            try {
                receipt.setProviderCharges(new BigDecimal(serviceReceipt.getProviderCharges()));
            } catch (NumberFormatException nfe) {
                receipt.setProviderCharges(null);
            }

            results.add(receipt);
        }

        return results;
    }

    private Date parseDate(String dateField) {
        Date dateValue;

        // Remove fractions of a second, if they exist
        int dotIndex = dateField.lastIndexOf(".");
        if (dotIndex != -1) {
            dateField = dateField.substring(0, dotIndex);
        }

        // Set dateValue to null if format is invalid.
        try {
            dateValue = DateUtils.parseDate(dateField, DATE_PATTERNS);
        } catch (ParseException e) {
            dateValue = null;
        }
        return dateValue;
    }

}
