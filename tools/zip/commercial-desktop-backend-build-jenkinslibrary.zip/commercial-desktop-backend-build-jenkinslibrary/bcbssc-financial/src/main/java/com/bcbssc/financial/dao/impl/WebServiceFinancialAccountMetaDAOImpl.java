/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2013 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 */

package com.bcbssc.financial.dao.impl;

import com.bcbssc.desktopshared.util.services.BaseServiceIntegrator;
import com.bcbssc.financial.dao.FinancialAccountMetaDAO;
import com.bcbssc.financial.model.FinancialAccountMeta;
import com.bcbssc.financial.model.FinancialInstitution;
import com.bcbssc.financial.model.PaymentOptionInput;
import com.bcbssc.model.ClientBusinessSectorCode;
import com.bcbssc.model.subscriber.Subscriber;
import com.bcbssc.services.cdhppaymentoptioninfo.CDHPPaymentOptionInfoInput;
import com.bcbssc.services.cdhppaymentoptioninfo.CDHPPaymentOptionInfoOutput;
import com.bcbssc.services.cdhppaymentoptioninfo.CDHPPaymentOptionInfoService;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Web Service implementation of FinancialAccountMetaDAO
 */
public class WebServiceFinancialAccountMetaDAOImpl extends BaseServiceIntegrator<CDHPPaymentOptionInfoService, PaymentOptionInput, CDHPPaymentOptionInfoInput, CDHPPaymentOptionInfoOutput, FinancialAccountMeta> implements FinancialAccountMetaDAO {

    @Override
    public FinancialAccountMeta retrieveAccountMeta(Subscriber subscriber, String patientId, ClientBusinessSectorCode sectorCode) {
        FinancialAccountMeta financialAccountMeta;
        try {
            PaymentOptionInput input = new PaymentOptionInput();
            input.setSubscriber(subscriber);
            input.setPatientId(patientId);
            input.setSectorCode(sectorCode);
            financialAccountMeta = this.consumeService(input);
            // put the subscriber id in the data because it doesn't come back from the service
            financialAccountMeta.setSubscriberDatabaseNumber(subscriber.getDatabaseNumber());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return financialAccountMeta;
    }

    @Override
    public FinancialAccountMeta updatePaymentOption(Subscriber subscriber, String patientId, String paymentOption, ClientBusinessSectorCode sectorCode) {
        FinancialAccountMeta financialAccountMeta;
        try {
            PaymentOptionInput input = new PaymentOptionInput();
            input.setAccountUpdate("U");
            input.setPaymentOption(paymentOption);
            input.setSubscriber(subscriber);
            input.setPatientId(patientId);
            input.setSectorCode(sectorCode);
            financialAccountMeta = this.consumeService(input);
            // put the subscriber id in the data because it doesn't come back from the service
            financialAccountMeta.setSubscriberDatabaseNumber(subscriber.getDatabaseNumber());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return financialAccountMeta;
    }

    private CDHPPaymentOptionInfoService service;

    @Override
    public void setService(CDHPPaymentOptionInfoService service) {
        this.service = service;
    }

    @Override
    public CDHPPaymentOptionInfoService getService() {
        return service;
    }

    @Override
    public CDHPPaymentOptionInfoInput mapInput(PaymentOptionInput input) {
        CDHPPaymentOptionInfoInput serviceInput = new CDHPPaymentOptionInfoInput();

        // Bluechoice subscriber number prefix added, if needed
        String subscriberId = input.getSubscriber().getDatabaseNumber();
        if ("035".equals(input.getSectorCode().getRpn()) && !subscriberId.startsWith("K")) {
            subscriberId = "K" + subscriberId;
        }

        serviceInput.setSubscriberId(subscriberId);
        serviceInput.setPatientId(input.getPatientId());
        serviceInput.setCdhpAccountUpdateIndicator(input.getAccountUpdate());
        serviceInput.setCdhpPaymentOptionCode(input.getPaymentOption());
        serviceInput.setRequestRpn(input.getSectorCode().getRpn());

        return serviceInput;
    }

    @Override
    public CDHPPaymentOptionInfoOutput invokeService(CDHPPaymentOptionInfoInput input, CDHPPaymentOptionInfoService service) throws Exception {
        return service.getOrUpdateCdhpPaymentOption(input);
    }

    @Override
    public FinancialAccountMeta mapOutput(CDHPPaymentOptionInfoOutput serviceOutput) {
        FinancialInstitution institution = new FinancialInstitution();
        institution.setUrl(serviceOutput.getPartnerWebAddress());
        institution.setMondayHoursOfOperation(serviceOutput.getMondayHoursOfOperation());
        institution.setTuesdayHoursOfOperation(serviceOutput.getTuesdayHoursOfOperation());
        institution.setWednesdayHoursOfOperation(serviceOutput.getWednesdayHoursOfOperation());
        institution.setThursdayHoursOfOperation(serviceOutput.getThursdayHoursOfOperation());
        institution.setFridayHoursOfOperation(serviceOutput.getFridayHoursOfOperation());
        institution.setSaturdayHoursOfOperation(serviceOutput.getSaturdayHoursOfOperation());
        institution.setSundayHoursOfOperation(serviceOutput.getSundayHoursOfOperation());
        institution.setName(serviceOutput.getPartnerName());
        institution.setPhoneNumber(serviceOutput.getPartnerPhoneNumber());
        institution.setRoutingNumber(serviceOutput.getPartnerNumber());

        FinancialAccountMeta accountMeta = new FinancialAccountMeta();
        accountMeta.setAccountActiveIndicator(serviceOutput.getAccountActiveIndicator());
        accountMeta.setAccountCloseDate(parseDate(serviceOutput.getAccountClosedDate()));
        accountMeta.setFinancialInstitution(institution);
        accountMeta.setPaymentEffDate(parseDate(serviceOutput.getCdhpPaymentOptionEffectiveDate()));
        accountMeta.setPaymentOptionIndicator(serviceOutput.getCdhpPaymentOptionIndicator());
        // serviceOutput does not contain databaseId, thus it must be passed in.
        accountMeta.setSubscriberSSN(serviceOutput.getSubscriberSocialSecurityNumber());

        return accountMeta;
    }

    private Date parseDate(String hostDate) {
        final String DATE_PATTERN = "MM/dd/yy";
        SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_PATTERN);
        Date date;

        try {
            date = dateFormat.parse(hostDate);
        } catch (ParseException e) {
            date = null;
        }

        return date;
    }

}
