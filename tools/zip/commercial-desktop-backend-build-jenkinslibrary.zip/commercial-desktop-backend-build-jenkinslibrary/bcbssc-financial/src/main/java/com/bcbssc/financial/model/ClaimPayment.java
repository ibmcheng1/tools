/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.financial.model;

import java.io.Serializable;
import java.math.BigDecimal;

import com.bcbssc.model.ClientBusinessSectorCode;
import com.bcbssc.model.subscriber.Subscriber;

/**
 * Model object for claim payment details.
 *
 */
public class ClaimPayment implements Serializable {

    private static final long serialVersionUID = 1L;

    private FinancialAccountMeta financialAccountMetadata;
    private ClientBusinessSectorCode clientBusinessSector;
    private Subscriber subscriber;
    private BigDecimal paymentAmount;
    private String claimNumber;
    private String providerName;
    private String providerNumber;
    private String bankRoutingNumber;
    private String accountNumber;
    private boolean receiptMode;

    // Return Receipt Listing criteria
    private String receiptStatusFilter;
    private String showVoidedReceipts;

    public String getBankRoutingNumber() {
        return bankRoutingNumber;
    }

    public void setBankRoutingNumber(String bankRoutingNumber) {
        this.bankRoutingNumber = bankRoutingNumber;
    }

    public String getClaimNumber() {
        return claimNumber;
    }

    public void setClaimNumber(String claimNumber) {
        this.claimNumber = claimNumber;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public String getProviderNumber() {
        return providerNumber;
    }

    public void setProviderNumber(String providerNumber) {
        this.providerNumber = providerNumber;
    }

    /**
     * @return the clientBusinessSector
     */
    public ClientBusinessSectorCode getClientBusinessSector() {
        return this.clientBusinessSector;
    }

    /**
     * @param clientBusinessSector the clientBusinessSector to set
     */
    public void setClientBusinessSector(ClientBusinessSectorCode clientBusinessSector) {
        this.clientBusinessSector = clientBusinessSector;
    }

    /**
     * @return the financialAccountMetadata
     */
    public FinancialAccountMeta getFinancialAccountMetadata() {
        return this.financialAccountMetadata;
    }

    /**
     * @param financialAccountMetadata the financialAccountMetadata to set
     */
    public void setFinancialAccountMetadata(FinancialAccountMeta financialAccountMetadata) {
        this.financialAccountMetadata = financialAccountMetadata;
    }

    /**
     * @return the paymentAmount
     */
    public BigDecimal getPaymentAmount() {
        return this.paymentAmount;
    }

    /**
     * @param paymentAmount the paymentAmount to set
     */
    public void setPaymentAmount(BigDecimal paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    /**
     * @return the subscriber
     */
    public Subscriber getSubscriber() {
        return this.subscriber;
    }

    /**
     * @param subscriber the subscriber to set
     */
    public void setSubscriber(Subscriber subscriber) {
        this.subscriber = subscriber;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getReceiptStatusFilter() {
        return receiptStatusFilter;
    }

    public void setReceiptStatusFilter(String receiptStatusFilter) {
        this.receiptStatusFilter = receiptStatusFilter;
    }

    public String getShowVoidedReceipts() {
        return showVoidedReceipts;
    }

    public void setShowVoidedReceipts(String showVoidedReceipts) {
        this.showVoidedReceipts = showVoidedReceipts;
    }

    /**
     * Gets the receiptMode.
     *
     * @return Returns the receiptMode.
     */
    public boolean isReceiptMode() {
        return receiptMode;
    }

    /**
     * Sets the receiptMode.
     *
     * @param receiptMode The receiptMode to set.
     */
    public void setReceiptMode(boolean receiptMode) {
        this.receiptMode = receiptMode;
    }
}
