
package com.bcbssc.services.policyadminarhistory;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PolicyAdminARHistoryAccountReceivable complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PolicyAdminARHistoryAccountReceivable">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="coveragePeriodBeginDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billDueDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="periodBilled" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="totalPayments" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="coveragePeriodEndDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="periodAdjustments" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="periodNetDue" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="coverageMarketingPackage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="periodFees" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="previousBalance" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="coverageSubMarketingPackage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="periodBalance" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="currentBalance" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PolicyAdminARHistoryAccountReceivable", propOrder = {
    "coveragePeriodBeginDate",
    "billDueDate",
    "periodBilled",
    "totalPayments",
    "coveragePeriodEndDate",
    "periodAdjustments",
    "periodNetDue",
    "coverageMarketingPackage",
    "periodFees",
    "previousBalance",
    "coverageSubMarketingPackage",
    "periodBalance",
    "currentBalance"
})
public class PolicyAdminARHistoryAccountReceivable {

    @XmlElement(required = true, nillable = true)
    protected String coveragePeriodBeginDate;
    @XmlElement(required = true, nillable = true)
    protected String billDueDate;
    @XmlElement(required = true, nillable = true)
    protected String periodBilled;
    @XmlElement(required = true, nillable = true)
    protected String totalPayments;
    @XmlElement(required = true, nillable = true)
    protected String coveragePeriodEndDate;
    @XmlElement(required = true, nillable = true)
    protected String periodAdjustments;
    @XmlElement(required = true, nillable = true)
    protected String periodNetDue;
    @XmlElement(required = true, nillable = true)
    protected String coverageMarketingPackage;
    @XmlElement(required = true, nillable = true)
    protected String periodFees;
    @XmlElement(required = true, nillable = true)
    protected String previousBalance;
    @XmlElement(required = true, nillable = true)
    protected String coverageSubMarketingPackage;
    @XmlElement(required = true, nillable = true)
    protected String periodBalance;
    @XmlElement(required = true, nillable = true)
    protected String currentBalance;

    /**
     * Gets the value of the coveragePeriodBeginDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoveragePeriodBeginDate() {
        return coveragePeriodBeginDate;
    }

    /**
     * Sets the value of the coveragePeriodBeginDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoveragePeriodBeginDate(String value) {
        this.coveragePeriodBeginDate = value;
    }

    /**
     * Gets the value of the billDueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillDueDate() {
        return billDueDate;
    }

    /**
     * Sets the value of the billDueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillDueDate(String value) {
        this.billDueDate = value;
    }

    /**
     * Gets the value of the periodBilled property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPeriodBilled() {
        return periodBilled;
    }

    /**
     * Sets the value of the periodBilled property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPeriodBilled(String value) {
        this.periodBilled = value;
    }

    /**
     * Gets the value of the totalPayments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTotalPayments() {
        return totalPayments;
    }

    /**
     * Sets the value of the totalPayments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTotalPayments(String value) {
        this.totalPayments = value;
    }

    /**
     * Gets the value of the coveragePeriodEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoveragePeriodEndDate() {
        return coveragePeriodEndDate;
    }

    /**
     * Sets the value of the coveragePeriodEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoveragePeriodEndDate(String value) {
        this.coveragePeriodEndDate = value;
    }

    /**
     * Gets the value of the periodAdjustments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPeriodAdjustments() {
        return periodAdjustments;
    }

    /**
     * Sets the value of the periodAdjustments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPeriodAdjustments(String value) {
        this.periodAdjustments = value;
    }

    /**
     * Gets the value of the periodNetDue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPeriodNetDue() {
        return periodNetDue;
    }

    /**
     * Sets the value of the periodNetDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPeriodNetDue(String value) {
        this.periodNetDue = value;
    }

    /**
     * Gets the value of the coverageMarketingPackage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoverageMarketingPackage() {
        return coverageMarketingPackage;
    }

    /**
     * Sets the value of the coverageMarketingPackage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoverageMarketingPackage(String value) {
        this.coverageMarketingPackage = value;
    }

    /**
     * Gets the value of the periodFees property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPeriodFees() {
        return periodFees;
    }

    /**
     * Sets the value of the periodFees property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPeriodFees(String value) {
        this.periodFees = value;
    }

    /**
     * Gets the value of the previousBalance property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreviousBalance() {
        return previousBalance;
    }

    /**
     * Sets the value of the previousBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreviousBalance(String value) {
        this.previousBalance = value;
    }

    /**
     * Gets the value of the coverageSubMarketingPackage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoverageSubMarketingPackage() {
        return coverageSubMarketingPackage;
    }

    /**
     * Sets the value of the coverageSubMarketingPackage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoverageSubMarketingPackage(String value) {
        this.coverageSubMarketingPackage = value;
    }

    /**
     * Gets the value of the periodBalance property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPeriodBalance() {
        return periodBalance;
    }

    /**
     * Sets the value of the periodBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPeriodBalance(String value) {
        this.periodBalance = value;
    }

    /**
     * Gets the value of the currentBalance property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrentBalance() {
        return currentBalance;
    }

    /**
     * Sets the value of the currentBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrentBalance(String value) {
        this.currentBalance = value;
    }

}
