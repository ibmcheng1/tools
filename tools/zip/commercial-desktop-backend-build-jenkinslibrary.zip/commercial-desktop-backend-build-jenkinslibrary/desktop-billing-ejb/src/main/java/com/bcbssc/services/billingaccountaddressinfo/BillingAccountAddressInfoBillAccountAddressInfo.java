
package com.bcbssc.services.billingaccountaddressinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BillingAccountAddressInfoBillAccountAddressInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BillingAccountAddressInfoBillAccountAddressInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="rpn" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="rpnDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billInfoNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingAddressTypeCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingAddressTypeCodeDesc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="clientNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="clientName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingAddressRecordBeginDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingAddressRecordTermDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingAddressName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingAddressContactName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingAddressLine1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingAddressLine2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingAddressCity" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingAddressStateCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingAddressZipCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingAddressZipCodePlus4" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingAreaCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingPhoneNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingPhoneExtensionNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingFaxNumberAreaCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingFaxNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingEmailAddress" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingNotesLine1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingNotesLine2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingNotesLine3" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billingNotesLine4" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lastOperatorTransactionId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lastOperatorName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lastTransactionDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BillingAccountAddressInfoBillAccountAddressInfo", propOrder = {
    "rpn",
    "rpnDescription",
    "billInfoNumber",
    "billingAddressTypeCode",
    "billingAddressTypeCodeDesc",
    "clientNumber",
    "clientName",
    "billingAddressRecordBeginDate",
    "billingAddressRecordTermDate",
    "billingAddressName",
    "billingAddressContactName",
    "billingAddressLine1",
    "billingAddressLine2",
    "billingAddressCity",
    "billingAddressStateCode",
    "billingAddressZipCode",
    "billingAddressZipCodePlus4",
    "billingAreaCode",
    "billingPhoneNumber",
    "billingPhoneExtensionNumber",
    "billingFaxNumberAreaCode",
    "billingFaxNumber",
    "billingEmailAddress",
    "billingNotesLine1",
    "billingNotesLine2",
    "billingNotesLine3",
    "billingNotesLine4",
    "lastOperatorTransactionId",
    "lastOperatorName",
    "lastTransactionDate"
})
public class BillingAccountAddressInfoBillAccountAddressInfo {

    @XmlElement(required = true, nillable = true)
    protected String rpn;
    @XmlElement(required = true, nillable = true)
    protected String rpnDescription;
    @XmlElement(required = true, nillable = true)
    protected String billInfoNumber;
    @XmlElement(required = true, nillable = true)
    protected String billingAddressTypeCode;
    @XmlElement(required = true, nillable = true)
    protected String billingAddressTypeCodeDesc;
    @XmlElement(required = true, nillable = true)
    protected String clientNumber;
    @XmlElement(required = true, nillable = true)
    protected String clientName;
    @XmlElement(required = true, nillable = true)
    protected String billingAddressRecordBeginDate;
    @XmlElement(required = true, nillable = true)
    protected String billingAddressRecordTermDate;
    @XmlElement(required = true, nillable = true)
    protected String billingAddressName;
    @XmlElement(required = true, nillable = true)
    protected String billingAddressContactName;
    @XmlElement(required = true, nillable = true)
    protected String billingAddressLine1;
    @XmlElement(required = true, nillable = true)
    protected String billingAddressLine2;
    @XmlElement(required = true, nillable = true)
    protected String billingAddressCity;
    @XmlElement(required = true, nillable = true)
    protected String billingAddressStateCode;
    @XmlElement(required = true, nillable = true)
    protected String billingAddressZipCode;
    @XmlElement(required = true, nillable = true)
    protected String billingAddressZipCodePlus4;
    @XmlElement(required = true, nillable = true)
    protected String billingAreaCode;
    @XmlElement(required = true, nillable = true)
    protected String billingPhoneNumber;
    @XmlElement(required = true, nillable = true)
    protected String billingPhoneExtensionNumber;
    @XmlElement(required = true, nillable = true)
    protected String billingFaxNumberAreaCode;
    @XmlElement(required = true, nillable = true)
    protected String billingFaxNumber;
    @XmlElement(required = true, nillable = true)
    protected String billingEmailAddress;
    @XmlElement(required = true, nillable = true)
    protected String billingNotesLine1;
    @XmlElement(required = true, nillable = true)
    protected String billingNotesLine2;
    @XmlElement(required = true, nillable = true)
    protected String billingNotesLine3;
    @XmlElement(required = true, nillable = true)
    protected String billingNotesLine4;
    @XmlElement(required = true, nillable = true)
    protected String lastOperatorTransactionId;
    @XmlElement(required = true, nillable = true)
    protected String lastOperatorName;
    @XmlElement(required = true, nillable = true)
    protected String lastTransactionDate;

    /**
     * Gets the value of the rpn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRpn() {
        return rpn;
    }

    /**
     * Sets the value of the rpn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRpn(String value) {
        this.rpn = value;
    }

    /**
     * Gets the value of the rpnDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRpnDescription() {
        return rpnDescription;
    }

    /**
     * Sets the value of the rpnDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRpnDescription(String value) {
        this.rpnDescription = value;
    }

    /**
     * Gets the value of the billInfoNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillInfoNumber() {
        return billInfoNumber;
    }

    /**
     * Sets the value of the billInfoNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillInfoNumber(String value) {
        this.billInfoNumber = value;
    }

    /**
     * Gets the value of the billingAddressTypeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingAddressTypeCode() {
        return billingAddressTypeCode;
    }

    /**
     * Sets the value of the billingAddressTypeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingAddressTypeCode(String value) {
        this.billingAddressTypeCode = value;
    }

    /**
     * Gets the value of the billingAddressTypeCodeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingAddressTypeCodeDesc() {
        return billingAddressTypeCodeDesc;
    }

    /**
     * Sets the value of the billingAddressTypeCodeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingAddressTypeCodeDesc(String value) {
        this.billingAddressTypeCodeDesc = value;
    }

    /**
     * Gets the value of the clientNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientNumber() {
        return clientNumber;
    }

    /**
     * Sets the value of the clientNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientNumber(String value) {
        this.clientNumber = value;
    }

    /**
     * Gets the value of the clientName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientName() {
        return clientName;
    }

    /**
     * Sets the value of the clientName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientName(String value) {
        this.clientName = value;
    }

    /**
     * Gets the value of the billingAddressRecordBeginDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingAddressRecordBeginDate() {
        return billingAddressRecordBeginDate;
    }

    /**
     * Sets the value of the billingAddressRecordBeginDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingAddressRecordBeginDate(String value) {
        this.billingAddressRecordBeginDate = value;
    }

    /**
     * Gets the value of the billingAddressRecordTermDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingAddressRecordTermDate() {
        return billingAddressRecordTermDate;
    }

    /**
     * Sets the value of the billingAddressRecordTermDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingAddressRecordTermDate(String value) {
        this.billingAddressRecordTermDate = value;
    }

    /**
     * Gets the value of the billingAddressName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingAddressName() {
        return billingAddressName;
    }

    /**
     * Sets the value of the billingAddressName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingAddressName(String value) {
        this.billingAddressName = value;
    }

    /**
     * Gets the value of the billingAddressContactName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingAddressContactName() {
        return billingAddressContactName;
    }

    /**
     * Sets the value of the billingAddressContactName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingAddressContactName(String value) {
        this.billingAddressContactName = value;
    }

    /**
     * Gets the value of the billingAddressLine1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingAddressLine1() {
        return billingAddressLine1;
    }

    /**
     * Sets the value of the billingAddressLine1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingAddressLine1(String value) {
        this.billingAddressLine1 = value;
    }

    /**
     * Gets the value of the billingAddressLine2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingAddressLine2() {
        return billingAddressLine2;
    }

    /**
     * Sets the value of the billingAddressLine2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingAddressLine2(String value) {
        this.billingAddressLine2 = value;
    }

    /**
     * Gets the value of the billingAddressCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingAddressCity() {
        return billingAddressCity;
    }

    /**
     * Sets the value of the billingAddressCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingAddressCity(String value) {
        this.billingAddressCity = value;
    }

    /**
     * Gets the value of the billingAddressStateCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingAddressStateCode() {
        return billingAddressStateCode;
    }

    /**
     * Sets the value of the billingAddressStateCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingAddressStateCode(String value) {
        this.billingAddressStateCode = value;
    }

    /**
     * Gets the value of the billingAddressZipCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingAddressZipCode() {
        return billingAddressZipCode;
    }

    /**
     * Sets the value of the billingAddressZipCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingAddressZipCode(String value) {
        this.billingAddressZipCode = value;
    }

    /**
     * Gets the value of the billingAddressZipCodePlus4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingAddressZipCodePlus4() {
        return billingAddressZipCodePlus4;
    }

    /**
     * Sets the value of the billingAddressZipCodePlus4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingAddressZipCodePlus4(String value) {
        this.billingAddressZipCodePlus4 = value;
    }

    /**
     * Gets the value of the billingAreaCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingAreaCode() {
        return billingAreaCode;
    }

    /**
     * Sets the value of the billingAreaCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingAreaCode(String value) {
        this.billingAreaCode = value;
    }

    /**
     * Gets the value of the billingPhoneNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingPhoneNumber() {
        return billingPhoneNumber;
    }

    /**
     * Sets the value of the billingPhoneNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingPhoneNumber(String value) {
        this.billingPhoneNumber = value;
    }

    /**
     * Gets the value of the billingPhoneExtensionNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingPhoneExtensionNumber() {
        return billingPhoneExtensionNumber;
    }

    /**
     * Sets the value of the billingPhoneExtensionNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingPhoneExtensionNumber(String value) {
        this.billingPhoneExtensionNumber = value;
    }

    /**
     * Gets the value of the billingFaxNumberAreaCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingFaxNumberAreaCode() {
        return billingFaxNumberAreaCode;
    }

    /**
     * Sets the value of the billingFaxNumberAreaCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingFaxNumberAreaCode(String value) {
        this.billingFaxNumberAreaCode = value;
    }

    /**
     * Gets the value of the billingFaxNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingFaxNumber() {
        return billingFaxNumber;
    }

    /**
     * Sets the value of the billingFaxNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingFaxNumber(String value) {
        this.billingFaxNumber = value;
    }

    /**
     * Gets the value of the billingEmailAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingEmailAddress() {
        return billingEmailAddress;
    }

    /**
     * Sets the value of the billingEmailAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingEmailAddress(String value) {
        this.billingEmailAddress = value;
    }

    /**
     * Gets the value of the billingNotesLine1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingNotesLine1() {
        return billingNotesLine1;
    }

    /**
     * Sets the value of the billingNotesLine1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingNotesLine1(String value) {
        this.billingNotesLine1 = value;
    }

    /**
     * Gets the value of the billingNotesLine2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingNotesLine2() {
        return billingNotesLine2;
    }

    /**
     * Sets the value of the billingNotesLine2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingNotesLine2(String value) {
        this.billingNotesLine2 = value;
    }

    /**
     * Gets the value of the billingNotesLine3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingNotesLine3() {
        return billingNotesLine3;
    }

    /**
     * Sets the value of the billingNotesLine3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingNotesLine3(String value) {
        this.billingNotesLine3 = value;
    }

    /**
     * Gets the value of the billingNotesLine4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillingNotesLine4() {
        return billingNotesLine4;
    }

    /**
     * Sets the value of the billingNotesLine4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillingNotesLine4(String value) {
        this.billingNotesLine4 = value;
    }

    /**
     * Gets the value of the lastOperatorTransactionId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastOperatorTransactionId() {
        return lastOperatorTransactionId;
    }

    /**
     * Sets the value of the lastOperatorTransactionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastOperatorTransactionId(String value) {
        this.lastOperatorTransactionId = value;
    }

    /**
     * Gets the value of the lastOperatorName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastOperatorName() {
        return lastOperatorName;
    }

    /**
     * Sets the value of the lastOperatorName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastOperatorName(String value) {
        this.lastOperatorName = value;
    }

    /**
     * Gets the value of the lastTransactionDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastTransactionDate() {
        return lastTransactionDate;
    }

    /**
     * Sets the value of the lastTransactionDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastTransactionDate(String value) {
        this.lastTransactionDate = value;
    }

}
