
package com.bcbssc.services.policyadminarhistory;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.bcbssc.services.policyadminarhistory package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _EbizException_QNAME = new QName("http://cmpgen.microfocus.com", "EbizException");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.bcbssc.services.policyadminarhistory
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link EbizException }
     * 
     */
    public EbizException createEbizException() {
        return new EbizException();
    }

    /**
     * Create an instance of {@link GetAccountsReceivableHistory }
     * 
     */
    public GetAccountsReceivableHistory createGetAccountsReceivableHistory() {
        return new GetAccountsReceivableHistory();
    }

    /**
     * Create an instance of {@link PolicyAdminARHistoryInput }
     * 
     */
    public PolicyAdminARHistoryInput createPolicyAdminARHistoryInput() {
        return new PolicyAdminARHistoryInput();
    }

    /**
     * Create an instance of {@link GetAccountsReceivableHistoryResponse }
     * 
     */
    public GetAccountsReceivableHistoryResponse createGetAccountsReceivableHistoryResponse() {
        return new GetAccountsReceivableHistoryResponse();
    }

    /**
     * Create an instance of {@link PolicyAdminARHistoryOutput }
     * 
     */
    public PolicyAdminARHistoryOutput createPolicyAdminARHistoryOutput() {
        return new PolicyAdminARHistoryOutput();
    }

    /**
     * Create an instance of {@link PolicyAdminARHistoryAccountReceivable }
     * 
     */
    public PolicyAdminARHistoryAccountReceivable createPolicyAdminARHistoryAccountReceivable() {
        return new PolicyAdminARHistoryAccountReceivable();
    }

    /**
     * Create an instance of {@link ArrayOfPolicyAdminARHistoryAccountReceivable }
     * 
     */
    public ArrayOfPolicyAdminARHistoryAccountReceivable createArrayOfPolicyAdminARHistoryAccountReceivable() {
        return new ArrayOfPolicyAdminARHistoryAccountReceivable();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EbizException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://cmpgen.microfocus.com", name = "EbizException")
    public JAXBElement<EbizException> createEbizException(EbizException value) {
        return new JAXBElement<EbizException>(_EbizException_QNAME, EbizException.class, null, value);
    }

}
