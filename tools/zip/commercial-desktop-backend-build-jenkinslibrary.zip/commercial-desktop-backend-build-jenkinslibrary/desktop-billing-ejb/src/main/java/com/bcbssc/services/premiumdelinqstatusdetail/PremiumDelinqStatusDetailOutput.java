
package com.bcbssc.services.premiumdelinqstatusdetail;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PremiumDelinqStatusDetailOutput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PremiumDelinqStatusDetailOutput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="applicationMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="systemMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="serviceMessageCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="serviceMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="rpn" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="customerName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="clientName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="masterArName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="parameterMasterId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="delinquencyStage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cancelOnHoldIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lastPaymentAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lastPaymentDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cancelHoldStageDelinqArAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cancelHoldStageDelinqArDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cancelHoldStageArAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cancelHoldStageDueDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="clientDelinquencySetId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="currentDelinquentArAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="currentDelinquencyArDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="currentAccountReceivableAmt" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="currentAccountReceivableDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="projectedCancelEffectiveDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="initialEvaluationDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="projectedCancelProcessDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="stageBeginDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cancelReasonCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cancelReasonDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="dueDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="letterDistributionCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="letterDistributionCodeDesc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ebizReplyAbendcode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ebizReplyStatus" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ebizReplyStatusMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PremiumDelinqStatusDetailOutput", propOrder = {
    "applicationMessage",
    "systemMessage",
    "serviceMessageCode",
    "serviceMessage",
    "rpn",
    "customerName",
    "clientName",
    "masterArName",
    "parameterMasterId",
    "delinquencyStage",
    "cancelOnHoldIndicator",
    "lastPaymentAmount",
    "lastPaymentDate",
    "cancelHoldStageDelinqArAmount",
    "cancelHoldStageDelinqArDate",
    "cancelHoldStageArAmount",
    "cancelHoldStageDueDate",
    "clientDelinquencySetId",
    "currentDelinquentArAmount",
    "currentDelinquencyArDate",
    "currentAccountReceivableAmt",
    "currentAccountReceivableDate",
    "projectedCancelEffectiveDate",
    "initialEvaluationDate",
    "projectedCancelProcessDate",
    "stageBeginDate",
    "cancelReasonCode",
    "cancelReasonDescription",
    "dueDate",
    "letterDistributionCode",
    "letterDistributionCodeDesc",
    "ebizReplyAbendcode",
    "ebizReplyStatus",
    "ebizReplyStatusMessage"
})
public class PremiumDelinqStatusDetailOutput {

    @XmlElement(required = true, nillable = true)
    protected String applicationMessage;
    @XmlElement(required = true, nillable = true)
    protected String systemMessage;
    @XmlElement(required = true, nillable = true)
    protected String serviceMessageCode;
    @XmlElement(required = true, nillable = true)
    protected String serviceMessage;
    @XmlElement(required = true, nillable = true)
    protected String rpn;
    @XmlElement(required = true, nillable = true)
    protected String customerName;
    @XmlElement(required = true, nillable = true)
    protected String clientName;
    @XmlElement(required = true, nillable = true)
    protected String masterArName;
    @XmlElement(required = true, nillable = true)
    protected String parameterMasterId;
    @XmlElement(required = true, nillable = true)
    protected String delinquencyStage;
    @XmlElement(required = true, nillable = true)
    protected String cancelOnHoldIndicator;
    @XmlElement(required = true, nillable = true)
    protected String lastPaymentAmount;
    @XmlElement(required = true, nillable = true)
    protected String lastPaymentDate;
    @XmlElement(required = true, nillable = true)
    protected String cancelHoldStageDelinqArAmount;
    @XmlElement(required = true, nillable = true)
    protected String cancelHoldStageDelinqArDate;
    @XmlElement(required = true, nillable = true)
    protected String cancelHoldStageArAmount;
    @XmlElement(required = true, nillable = true)
    protected String cancelHoldStageDueDate;
    @XmlElement(required = true, nillable = true)
    protected String clientDelinquencySetId;
    @XmlElement(required = true, nillable = true)
    protected String currentDelinquentArAmount;
    @XmlElement(required = true, nillable = true)
    protected String currentDelinquencyArDate;
    @XmlElement(required = true, nillable = true)
    protected String currentAccountReceivableAmt;
    @XmlElement(required = true, nillable = true)
    protected String currentAccountReceivableDate;
    @XmlElement(required = true, nillable = true)
    protected String projectedCancelEffectiveDate;
    @XmlElement(required = true, nillable = true)
    protected String initialEvaluationDate;
    @XmlElement(required = true, nillable = true)
    protected String projectedCancelProcessDate;
    @XmlElement(required = true, nillable = true)
    protected String stageBeginDate;
    @XmlElement(required = true, nillable = true)
    protected String cancelReasonCode;
    @XmlElement(required = true, nillable = true)
    protected String cancelReasonDescription;
    @XmlElement(required = true, nillable = true)
    protected String dueDate;
    @XmlElement(required = true, nillable = true)
    protected String letterDistributionCode;
    @XmlElement(required = true, nillable = true)
    protected String letterDistributionCodeDesc;
    @XmlElement(required = true, nillable = true)
    protected String ebizReplyAbendcode;
    protected int ebizReplyStatus;
    @XmlElement(required = true, nillable = true)
    protected String ebizReplyStatusMessage;

    /**
     * Gets the value of the applicationMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationMessage() {
        return applicationMessage;
    }

    /**
     * Sets the value of the applicationMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationMessage(String value) {
        this.applicationMessage = value;
    }

    /**
     * Gets the value of the systemMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystemMessage() {
        return systemMessage;
    }

    /**
     * Sets the value of the systemMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystemMessage(String value) {
        this.systemMessage = value;
    }

    /**
     * Gets the value of the serviceMessageCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceMessageCode() {
        return serviceMessageCode;
    }

    /**
     * Sets the value of the serviceMessageCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceMessageCode(String value) {
        this.serviceMessageCode = value;
    }

    /**
     * Gets the value of the serviceMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceMessage() {
        return serviceMessage;
    }

    /**
     * Sets the value of the serviceMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceMessage(String value) {
        this.serviceMessage = value;
    }

    /**
     * Gets the value of the rpn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRpn() {
        return rpn;
    }

    /**
     * Sets the value of the rpn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRpn(String value) {
        this.rpn = value;
    }

    /**
     * Gets the value of the customerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * Sets the value of the customerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerName(String value) {
        this.customerName = value;
    }

    /**
     * Gets the value of the clientName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientName() {
        return clientName;
    }

    /**
     * Sets the value of the clientName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientName(String value) {
        this.clientName = value;
    }

    /**
     * Gets the value of the masterArName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMasterArName() {
        return masterArName;
    }

    /**
     * Sets the value of the masterArName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMasterArName(String value) {
        this.masterArName = value;
    }

    /**
     * Gets the value of the parameterMasterId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParameterMasterId() {
        return parameterMasterId;
    }

    /**
     * Sets the value of the parameterMasterId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParameterMasterId(String value) {
        this.parameterMasterId = value;
    }

    /**
     * Gets the value of the delinquencyStage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDelinquencyStage() {
        return delinquencyStage;
    }

    /**
     * Sets the value of the delinquencyStage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDelinquencyStage(String value) {
        this.delinquencyStage = value;
    }

    /**
     * Gets the value of the cancelOnHoldIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCancelOnHoldIndicator() {
        return cancelOnHoldIndicator;
    }

    /**
     * Sets the value of the cancelOnHoldIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCancelOnHoldIndicator(String value) {
        this.cancelOnHoldIndicator = value;
    }

    /**
     * Gets the value of the lastPaymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastPaymentAmount() {
        return lastPaymentAmount;
    }

    /**
     * Sets the value of the lastPaymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastPaymentAmount(String value) {
        this.lastPaymentAmount = value;
    }

    /**
     * Gets the value of the lastPaymentDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastPaymentDate() {
        return lastPaymentDate;
    }

    /**
     * Sets the value of the lastPaymentDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastPaymentDate(String value) {
        this.lastPaymentDate = value;
    }

    /**
     * Gets the value of the cancelHoldStageDelinqArAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCancelHoldStageDelinqArAmount() {
        return cancelHoldStageDelinqArAmount;
    }

    /**
     * Sets the value of the cancelHoldStageDelinqArAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCancelHoldStageDelinqArAmount(String value) {
        this.cancelHoldStageDelinqArAmount = value;
    }

    /**
     * Gets the value of the cancelHoldStageDelinqArDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCancelHoldStageDelinqArDate() {
        return cancelHoldStageDelinqArDate;
    }

    /**
     * Sets the value of the cancelHoldStageDelinqArDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCancelHoldStageDelinqArDate(String value) {
        this.cancelHoldStageDelinqArDate = value;
    }

    /**
     * Gets the value of the cancelHoldStageArAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCancelHoldStageArAmount() {
        return cancelHoldStageArAmount;
    }

    /**
     * Sets the value of the cancelHoldStageArAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCancelHoldStageArAmount(String value) {
        this.cancelHoldStageArAmount = value;
    }

    /**
     * Gets the value of the cancelHoldStageDueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCancelHoldStageDueDate() {
        return cancelHoldStageDueDate;
    }

    /**
     * Sets the value of the cancelHoldStageDueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCancelHoldStageDueDate(String value) {
        this.cancelHoldStageDueDate = value;
    }

    /**
     * Gets the value of the clientDelinquencySetId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientDelinquencySetId() {
        return clientDelinquencySetId;
    }

    /**
     * Sets the value of the clientDelinquencySetId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientDelinquencySetId(String value) {
        this.clientDelinquencySetId = value;
    }

    /**
     * Gets the value of the currentDelinquentArAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrentDelinquentArAmount() {
        return currentDelinquentArAmount;
    }

    /**
     * Sets the value of the currentDelinquentArAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrentDelinquentArAmount(String value) {
        this.currentDelinquentArAmount = value;
    }

    /**
     * Gets the value of the currentDelinquencyArDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrentDelinquencyArDate() {
        return currentDelinquencyArDate;
    }

    /**
     * Sets the value of the currentDelinquencyArDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrentDelinquencyArDate(String value) {
        this.currentDelinquencyArDate = value;
    }

    /**
     * Gets the value of the currentAccountReceivableAmt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrentAccountReceivableAmt() {
        return currentAccountReceivableAmt;
    }

    /**
     * Sets the value of the currentAccountReceivableAmt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrentAccountReceivableAmt(String value) {
        this.currentAccountReceivableAmt = value;
    }

    /**
     * Gets the value of the currentAccountReceivableDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrentAccountReceivableDate() {
        return currentAccountReceivableDate;
    }

    /**
     * Sets the value of the currentAccountReceivableDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrentAccountReceivableDate(String value) {
        this.currentAccountReceivableDate = value;
    }

    /**
     * Gets the value of the projectedCancelEffectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProjectedCancelEffectiveDate() {
        return projectedCancelEffectiveDate;
    }

    /**
     * Sets the value of the projectedCancelEffectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProjectedCancelEffectiveDate(String value) {
        this.projectedCancelEffectiveDate = value;
    }

    /**
     * Gets the value of the initialEvaluationDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInitialEvaluationDate() {
        return initialEvaluationDate;
    }

    /**
     * Sets the value of the initialEvaluationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInitialEvaluationDate(String value) {
        this.initialEvaluationDate = value;
    }

    /**
     * Gets the value of the projectedCancelProcessDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProjectedCancelProcessDate() {
        return projectedCancelProcessDate;
    }

    /**
     * Sets the value of the projectedCancelProcessDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProjectedCancelProcessDate(String value) {
        this.projectedCancelProcessDate = value;
    }

    /**
     * Gets the value of the stageBeginDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStageBeginDate() {
        return stageBeginDate;
    }

    /**
     * Sets the value of the stageBeginDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStageBeginDate(String value) {
        this.stageBeginDate = value;
    }

    /**
     * Gets the value of the cancelReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCancelReasonCode() {
        return cancelReasonCode;
    }

    /**
     * Sets the value of the cancelReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCancelReasonCode(String value) {
        this.cancelReasonCode = value;
    }

    /**
     * Gets the value of the cancelReasonDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCancelReasonDescription() {
        return cancelReasonDescription;
    }

    /**
     * Sets the value of the cancelReasonDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCancelReasonDescription(String value) {
        this.cancelReasonDescription = value;
    }

    /**
     * Gets the value of the dueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDueDate() {
        return dueDate;
    }

    /**
     * Sets the value of the dueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDueDate(String value) {
        this.dueDate = value;
    }

    /**
     * Gets the value of the letterDistributionCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLetterDistributionCode() {
        return letterDistributionCode;
    }

    /**
     * Sets the value of the letterDistributionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLetterDistributionCode(String value) {
        this.letterDistributionCode = value;
    }

    /**
     * Gets the value of the letterDistributionCodeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLetterDistributionCodeDesc() {
        return letterDistributionCodeDesc;
    }

    /**
     * Sets the value of the letterDistributionCodeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLetterDistributionCodeDesc(String value) {
        this.letterDistributionCodeDesc = value;
    }

    /**
     * Gets the value of the ebizReplyAbendcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEbizReplyAbendcode() {
        return ebizReplyAbendcode;
    }

    /**
     * Sets the value of the ebizReplyAbendcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEbizReplyAbendcode(String value) {
        this.ebizReplyAbendcode = value;
    }

    /**
     * Gets the value of the ebizReplyStatus property.
     * 
     */
    public int getEbizReplyStatus() {
        return ebizReplyStatus;
    }

    /**
     * Sets the value of the ebizReplyStatus property.
     * 
     */
    public void setEbizReplyStatus(int value) {
        this.ebizReplyStatus = value;
    }

    /**
     * Gets the value of the ebizReplyStatusMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEbizReplyStatusMessage() {
        return ebizReplyStatusMessage;
    }

    /**
     * Sets the value of the ebizReplyStatusMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEbizReplyStatusMessage(String value) {
        this.ebizReplyStatusMessage = value;
    }

}
