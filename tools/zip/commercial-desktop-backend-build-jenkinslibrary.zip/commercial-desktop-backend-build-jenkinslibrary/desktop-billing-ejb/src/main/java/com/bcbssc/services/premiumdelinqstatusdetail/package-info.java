@javax.xml.bind.annotation.XmlSchema(namespace = "http://PremiumDelinqStatusDetail.DLQCT101EJB.commercial.bcbssc.com")
package com.bcbssc.services.premiumdelinqstatusdetail;
