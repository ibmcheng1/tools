/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2014 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 */
package com.bcbssc.desktop.biz.bd;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.BillingInformationBiz;
import com.bcbssc.desktop.biz.BusinessClassificationCodeBiz;
import com.bcbssc.desktop.dao.SubscriberDAO;
import com.bcbssc.desktop.dao.billing.AccountsReceivableDetailDAO;
import com.bcbssc.desktop.dao.billing.AccountsReceivableHistoryDAO;
import com.bcbssc.desktop.dao.billing.AccountsReceivableSummaryDAO;
import com.bcbssc.desktop.dao.billing.BillingAccountAddressDAO;
import com.bcbssc.desktop.dao.billing.BillingDAO;
import com.bcbssc.desktop.dao.billing.DelinquencyStatusDAO;
import com.bcbssc.desktop.dao.group.GroupSummaryDAO;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.dao.DataRetrievalHandler;
import com.bcbssc.desktop.util.dao.executor.WorkExecutor;
import com.bcbssc.desktop.util.dao.executor.WorkTask;
import com.bcbssc.domain.entity.BusinessClassificationCode;
import com.bcbssc.domain.entity.Coverage;
import com.bcbssc.domain.entity.Group;
import com.bcbssc.domain.entity.Subscriber;
import com.bcbssc.domain.entity.Subsystem;
import com.bcbssc.domain.entity.billing.AccountReceivable;
import com.bcbssc.domain.entity.billing.AccountsReceivableHistory;
import com.bcbssc.domain.entity.billing.AccountsReceivableSummary;
import com.bcbssc.domain.entity.billing.BillingContactInformation;
import com.bcbssc.domain.entity.billing.BillingInformation;
import com.bcbssc.domain.entity.billing.DelinquencyStatusDetails;
import com.bcbssc.domain.entity.codes.Code;
import com.bcbssc.domain.entity.enums.Subsystems;
import com.bcbssc.domain.entity.enums.billing.PolicyType;
import com.bcbssc.domain.entity.enums.billing.ReportIdentifier;
import com.bcbssc.domain.entity.group.GroupSearchCriteria;
import com.bcbssc.domain.exceptions.AccountClosedException;
import com.bcbssc.domain.valueobject.MenuLink;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.security.auth.Subject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;

/**
 * Billing Information lookup business delegate
 *
 */
@Stateless
public class BillingInformationBizBDImpl implements BillingInformationBiz {

    /**
     * logger
     */
    private static Log log = LogFactory.getLog(BillingInformationBizBDImpl.class);

    private static final int TWO = 2;
    private static final int THREE = 3;
    private static final String BLUE_CHOICE_RPN = "035";
    private static final String USERCONFIG = "USERCONFIG";
    private static final String RETRIEVE_GROUP_INFO = "RETRIEVE_GROUP_INFO";
    private static final String RETRIEVE_BILLING_INFO = "RETRIEVE_BILLING_INFO";
    private static final String RETRIEVE_DELINQUENCY_STATUS_INFO = "RETRIEVE_DELINQUENCY_STATUS_INFO";
    private static final String RETRIEVE_ACCOUNTS_RECEIVABLE_DETAIL_INFO = "RETRIEVE_ACCOUNTS_RECEIVABLE_DETAIL_INFO";
    private static final String RETRIEVE_ACCOUNTS_RECEIVABLE_HISTORY_INFO = "RETRIEVE_ACCOUNTS_RECEIVABLE_HISTORY_INFO";
    private static final String RETRIEVE_ACCOUNTS_RECEIVABLE_SUMMARY_INFO = "RETRIEVE_ACCOUNTS_RECEIVABLE_SUMMARY_INFO";
    private static final String RETRIEVE_BILLING_ACCOUNT_ADDRESS_INFO = "RETRIEVE_BILLING_ACCOUNT_ADDRESS_INFO";
    private static final String RETRIEVE_ID_SEARCH_INFO_FLAG = "RETRIEVE_ID_SEARCH_INFO";

    @EJB
    private BillingDAO billingDAO;

    @EJB
    private GroupSummaryDAO groupSummaryDAO;

    @EJB
    private BillingAccountAddressDAO billingAccountAddressDAO;

    @EJB
    private DelinquencyStatusDAO delinquencyStatusDAO;

    @EJB
    private AccountsReceivableHistoryDAO accountsReceivableHistoryDAO;

    @EJB
    private AccountsReceivableSummaryDAO accountsReceivableSummaryDAO;

    @EJB
    private AccountsReceivableDetailDAO accountsReceivableDetailDAO;

    @EJB
    private BusinessClassificationCodeBiz businessClassificationCodeBiz;

    @EJB
    private SubscriberDAO subscriberDAO;

    @Resource(lookup="concurrent/executor")
    private ExecutorService executor;

    /**
     * fetch billing information for a group, must call several services, some concurrently, some subsequently
     */
    @Override
    public BillingInformation fetchBillingInformationForGroup(String masterARNumber, String cesGroupNumber, String productCode, String coverageId,
            Subject subject) throws Exception {

        if (subject == null) {
            throw new IllegalArgumentException("Subject must be provided to this method");
        }

        BillingInformation billingInformation = new BillingInformation();
        billingInformation.setGroupPolicy(Boolean.TRUE);
        billingInformation = this.setReportIdentifier(billingInformation, subject);

        if (log.isDebugEnabled()) {
            log.debug("fetchBillingInformationForGroup() called for arNumber [" + masterARNumber + "], groupNumber [" + cesGroupNumber + "], productCode ["
                    + productCode + "], coverageId [" + coverageId + "]");
        }

        try {
            /*
             * initial DAO calls
             */
            billingInformation = this.fetchInitialGroupBillingInformation(billingInformation, masterARNumber, cesGroupNumber, productCode, coverageId, subject);

            /*
             * secondary DAO calls, reliant on data from initial calls
             */
            billingInformation = this.fetchSecondaryGroupBillingInformation(billingInformation, subject);

        } catch (AccountClosedException ace) {
            log.warn("Billing Summary - Account Closed for group [" + cesGroupNumber + "].");
            billingInformation = null;
        }

        if (log.isDebugEnabled()) {
            log.debug("returning BillingInformation = [" + billingInformation + "]");
        }
        return billingInformation;
    }

    /**
     * fetch billing information for an individual, must call several services, some concurrently, some subsequently
     */
    @Override
    public BillingInformation fetchBillingInformationForSubscriber(Subscriber subscriber, Subject subject) throws Exception {
        BillingInformation billingInformation = null;
        String coverageId = StringUtils.EMPTY;
        String groupNumber = StringUtils.EMPTY;
        String productCode = StringUtils.EMPTY;
        boolean groupPolicy;
        boolean subscriberHasCoverage;
        Map<String, MenuLink> userConfigs = getUserConfigEntries(subject);
        MenuLink idSearchLink = userConfigs.get(RETRIEVE_ID_SEARCH_INFO_FLAG);

        if (subject == null) {
            throw new IllegalArgumentException("Subject must be provided to this method");
        }
        if (subscriber == null) {
            throw new IllegalArgumentException("Subscriber must be provided to this method");
        }

        if (log.isDebugEnabled()) {
            log.debug("fetchBillingInformationForSubscriber() called for subscriberID [" + subscriber.getId() + "]");
        }

        final String subId = subscriber.getDatabaseNumber();
        List<Subscriber> resultSubscribers = new ArrayList<>();

        //fetch group/coverage information
        Coverage latestCoverage = subscriber.getLatestCoverage();
        if (null == latestCoverage) {
            //coverage data won't come through from a callpop, so look it up with sbrid
            try {
                resultSubscribers = SubjectUtils.runAsSubject(() -> subscriberDAO.findById(subId), subject);
            } catch (Exception exception) {
                //if an exception is generated, allow DataRetrievalHandler to handle the exception
                DataRetrievalHandler.handleDataRetrievalException(idSearchLink, exception);
            }
            if (resultSubscribers.size() == 1) {
                subscriber = resultSubscribers.iterator().next();
                latestCoverage = subscriber.getLatestCoverage();
            } 
        }
        if (log.isDebugEnabled()) {
            log.debug("subscriberDAO findbyid results: " + subscriber.toString());
        }
        if (null != latestCoverage) {
            coverageId = latestCoverage.getCoverageId().toString();
            if (null != latestCoverage.getCoverageId().getProductCode()) {
                productCode = latestCoverage.getCoverageId().getProductCode().getCode();
            }
            groupNumber = subscriber.getCesGroupNumber();
            billingInformation = new BillingInformation();
            billingInformation.setGroupNumber(groupNumber);
            subscriberHasCoverage = Boolean.TRUE;
        } else {
            String warnMsg = "Subscriber [" + subscriber.getId() + "] does not have latest coverage!!";
            log.warn(warnMsg);
            //subscriber's coverage isn't populated = no data is found
            subscriberHasCoverage = Boolean.FALSE;
        }
         
    
        if (subscriberHasCoverage) {
            //fetch group/coverage information
            BusinessClassificationCode busClassificationCode = businessClassificationCodeBiz.findCodeBySubscriberLatestCoverage(subscriber, subject);
            if ((null == busClassificationCode) || (null == busClassificationCode.getPolicyType())) {
                //if the policy type wasn't fetched, default to individual
                groupPolicy = Boolean.FALSE;
            } else {
                groupPolicy = (busClassificationCode.getPolicyType() == PolicyType.GROUP);
            }
            if (log.isDebugEnabled() && busClassificationCode != null) {
                log.debug("busClassificationCode from findCodeBySubscriberLatestCoverage: " + busClassificationCode.toString());
            }

            if (log.isDebugEnabled()) {
                log.debug("Subscriber (" + subscriber.getId() + ") on Group Policy :: [" + groupPolicy + "]");
            }

            //set group policy indicator 
            billingInformation.setGroupPolicy(groupPolicy);
            billingInformation = this.setReportIdentifier(billingInformation, subject);

            try {
                /* initial DAO calls */
                billingInformation = this.fetchInitialSubscriberBillingInformation(billingInformation, subscriber.getId(), groupNumber, productCode,
                        coverageId, subject);

                /* secondary DAO calls, dependent on data from initial calls */
                billingInformation = this.fetchSecondarySubscriberBillingInformation(billingInformation, subject);

                /* tertiary DAO calls, dependent on data from initial and secondary calls */
                billingInformation = this.fetchTertiarySubscriberBillingInformation(billingInformation, subject);

            } catch (AccountClosedException ace) {
                log.warn("Billing Summary - Account Closed for subscriber [" + subscriber.getId() + "].");
                billingInformation = null;
            }
        }

        if (log.isDebugEnabled()) {
        	log.debug("returning BillingInformation = [" + billingInformation + "]");
        }
        return billingInformation;
    }

    /**
     * fetch Health Coverage Policy type for the provided subscriber
     */
    public PolicyType fetchHealthCoveragePolicyType(final Subscriber subscriber, Subject subject) throws Exception {
        PolicyType policyType = PolicyType.INDIVIDUAL;

        List<Subscriber> resultSubscribers = new ArrayList<>();
        Map<String, MenuLink> userConfigs = getUserConfigEntries(subject);
        MenuLink idSearchLink = userConfigs.get(RETRIEVE_ID_SEARCH_INFO_FLAG);
        Subscriber subscriberForCoverage;
        boolean subscriberHasCoverage;

        //fetch coverage information
        Coverage latestCoverage = subscriber.getLatestCoverage();
        if (null == latestCoverage) {
            //coverage data won't come through from a callpop, so look it up with sbrid
            try {
                resultSubscribers = SubjectUtils.runAsSubject(() -> subscriberDAO.findById(subscriber.getDatabaseNumber()), subject);
            } catch (Exception exception) {
                //if an exception is generated, allow DataRetrievalHandler to handle the exception
                DataRetrievalHandler.handleDataRetrievalException(idSearchLink, exception);
            }
            if (resultSubscribers.size() == 1) {
                subscriberForCoverage = resultSubscribers.iterator().next();
                latestCoverage = subscriberForCoverage.getLatestCoverage();
            } else {
                throw new IllegalStateException("got unexpected number(" + resultSubscribers.size() + ") of records returned from findById for sbr: "
                        + subscriber.getId());
            }
        }
        if (null != latestCoverage) {
            subscriberHasCoverage = true;
        } else {
            log.warn("Subscriber [" + subscriber.getId() + "] does not have latest coverage");
            subscriberHasCoverage = false;
        }

        if (subscriberHasCoverage) {
            //fetch business classification code information
            BusinessClassificationCode busClassificationCode = businessClassificationCodeBiz.findCodeBySubscriberLatestCoverage(subscriber, subject);
            //if the policy type wasn't fetched, default to individual
            if ((busClassificationCode != null) && (busClassificationCode.getPolicyType() != null)) {
                policyType = busClassificationCode.getPolicyType();
            }
        }

        return policyType;
    }

    /**
     * fetch accounts receivable history for the provided subscriber id or master ar number
     */
    public AccountsReceivableHistory fetchAccountsReceivable(String subscriberID, String masterARNumber, Subject subject) throws Exception {
        AccountsReceivableHistory history = new AccountsReceivableHistory();

        if (StringUtils.isBlank(subscriberID) && StringUtils.isBlank(masterARNumber)) {
            throw new IllegalArgumentException("subscriberID or masterARNumber must be provided to this method");
        }
        if (subject == null) {
            throw new IllegalArgumentException("Subject must be provided to this method");
        }

        if (StringUtils.isNotBlank(subscriberID)) {

            //run Billing Account Info
            BillingInformation billingInformation = this.getBillingInformationWithSubscriberId(subscriberID, subject);
            history.setBusinessTypeCode(billingInformation.getBusinessTypeCode());
            history.setClientNumber(billingInformation.getClientNumber());
            history.setMasterARNumber(billingInformation.getMasterARNumber());

            //run PolicyAdminARSummary and PolicyAdminARHistory concurrently
            ArrayList<WorkTask<?>> workTasks = new ArrayList<>(TWO);
            // add work item Threads to list   
            workTasks.add(retrieveAccountsReceivableHistory(history.getMasterARNumber(), subject, null, history));
            workTasks.add(retrieveAccountsReceivableSummary(history.getMasterARNumber(), subject, null, history));

            //create a work executor, execute work tasks
            WorkExecutor workExecutor = new WorkExecutor(executor, workTasks);
            workExecutor.executeWorkTasks();
        } else if (StringUtils.isNotBlank(masterARNumber)) {

            history.setMasterARNumber(masterARNumber);

            //run BillingSummaryInfo PolicyAdminARSummary and PolicyAdminARHistory concurrently
            ArrayList<WorkTask<?>> workTasks = new ArrayList<>(THREE);
            // add work item Threads to list            
            workTasks.add(retrieveBillingInformation(history.getMasterARNumber(), null, subject, null, history));
            workTasks.add(retrieveAccountsReceivableHistory(history.getMasterARNumber(), subject, null, history));
            workTasks.add(retrieveAccountsReceivableSummary(history.getMasterARNumber(), subject, null, history));

            //create a work executor, execute work tasks
            WorkExecutor workExecutor = new WorkExecutor(executor, workTasks);
            workExecutor.executeWorkTasks();
        }

        return history;
    }

    /**
     * fetch accounts receivable details
     * @see com.bcbssc.desktop.biz.BillingInformationBiz#fetchAccountsReceivableDetail(com.bcbssc.domain.entity.billing.AccountReceivable, java.lang.String,
     * javax.security.auth.Subject)
     */
    public AccountReceivable fetchAccountsReceivableDetail(final AccountReceivable accountReceivable, final String masterARNumber, Subject subject)
            throws Exception {

        if (subject == null) {
            throw new IllegalArgumentException("Subject must be provided to this method");
        }

        Map<String, MenuLink> userConfigs = getUserConfigEntries(subject);
        MenuLink accountsReceivableDetailSearchFlag = userConfigs.get(RETRIEVE_ACCOUNTS_RECEIVABLE_DETAIL_INFO);
        AccountReceivable account = null;

        if (log.isDebugEnabled()) {
            log.debug("fetching accounts receivable detail information");
        }
        if (DataRetrievalHandler.runDataRetrieval(accountsReceivableDetailSearchFlag)) {
            try {
                account = SubjectUtils.runAsSubject(() -> accountsReceivableDetailDAO.fetchAccountsReceivableDetail(masterARNumber, accountReceivable.getCoveragePeriod()), subject);
                if (log.isDebugEnabled()) {
                    log.debug("fetched accounts receivable detail [" + account + "]");
                }
            } catch (Exception exception) {
                //if an exception is generated, allow DataRetrievalHandler to handle the exception
                DataRetrievalHandler.handleDataRetrievalException(accountsReceivableDetailSearchFlag, exception);
            }
        }
        return account;
    }

    /**
     * (non-Javadoc)
     */
    @Override
    public Map<DelinquencyStatusService, Object> getDelinquencyStatusInfo(String clientNumber, Code businessTypeCode,
            final String masterAccountsReceivableNumber, Subject subject) throws Exception {

        if (subject == null) {
            throw new IllegalArgumentException("Subject must be provided to this method");
        }

        Map<String, MenuLink> userConfigs = getUserConfigEntries(subject);

        Map<DelinquencyStatusService, Object> serviceResults = null;

        if (StringUtils.isNotEmpty(masterAccountsReceivableNumber)) {
            DelinquencyStatusDetails details = null;
            if (StringUtils.isEmpty(clientNumber) && businessTypeCode == null) {
                BillingInformation billingInformation = getBillingInformation(userConfigs, masterAccountsReceivableNumber, subject);
                if (billingInformation != null) {
                    serviceResults = new HashMap<>(2);
                    serviceResults.put(DelinquencyStatusService.BILLING_ACCOUNT_INFO, billingInformation);
                    clientNumber = billingInformation.getClientNumber();
                    businessTypeCode = billingInformation.getBusinessTypeCode();
                    details = getDelinquencyStatusDetails(userConfigs, clientNumber, businessTypeCode, masterAccountsReceivableNumber, subject);
                }
            } else {
                serviceResults = new HashMap<>(1);
                details = getDelinquencyStatusDetails(userConfigs, clientNumber, businessTypeCode, masterAccountsReceivableNumber, subject);
            }

            if (details != null) {
                serviceResults.put(DelinquencyStatusService.DELINQUENCY_STATUS, details);
            }

        }
        return serviceResults;

    }

    /**
     * fetch BillingInformation for subscribers using initial DAO calls - calls to GroupSummary (group policy), BillingSummaryInfo (individual policy)
     * @param billingInformation - billing information to be populated, returned
     * @param subscriberId - subscriber id
     * @param groupNumber - group number 
     * @param productCode - product
     * @param coverageId - coverage
     * @param subject - used for DAO calls
     * @return provided BillingInformation, mutated
     * @throws Exception If there is an error.
     */
    private BillingInformation fetchInitialSubscriberBillingInformation(BillingInformation billingInformation, final String subscriberId,
            final String groupNumber, final String productCode, final String coverageId, Subject subject) throws Exception {

        Group group = null;
        BillingInformation fetchedBillingInformation = null;

        MenuLink menuLink;
        Map<String, MenuLink> userConfigs = getUserConfigEntries(subject);

        /*
         * fetch billing information if not on group policy 
         */
        if (!billingInformation.getGroupPolicy()) {
            menuLink = userConfigs.get(RETRIEVE_BILLING_INFO);
            if (menuLink == null) {
                log.warn("menulink not found for key [" + RETRIEVE_BILLING_INFO + "]");
            }

            if (DataRetrievalHandler.runDataRetrieval(menuLink)) {
                try {
                    fetchedBillingInformation = SubjectUtils.runAsSubject(() -> billingDAO.findBySubscriber(subscriberId), subject);
                } catch (Exception exception) {
                    //if an exception is generated, allow DataRetrievalHandler to handle the exception
                    DataRetrievalHandler.handleDataRetrievalException(menuLink, exception);
                }
            }
            billingInformation = this.fetchBillingInformation(fetchedBillingInformation, billingInformation);
        }

        //for individual policies, check billing information for MAR and if not present assume the subscriber is on a group policy
        if (billingInformation.getGroupPolicy() || StringUtils.isEmpty(billingInformation.getMasterARNumber())) {
            billingInformation.setGroupPolicy(Boolean.TRUE);

            menuLink = userConfigs.get(RETRIEVE_GROUP_INFO);
            if (menuLink == null) {
                log.warn("menulink not found for key [" + RETRIEVE_GROUP_INFO + "]");
            }

            if (DataRetrievalHandler.runDataRetrieval(menuLink)) {
                try {
                    final GroupSearchCriteria criteria = new GroupSearchCriteria();
                    criteria.setCesGroupNumber(groupNumber);
                    criteria.setProductCode(productCode);
                    criteria.setCoverageId(coverageId);
                    group = SubjectUtils.runAsSubject(() -> groupSummaryDAO.getGroupInformation(criteria), subject);
                } catch (Exception exception) {
                    //if an exception is generated, allow DataRetrievalHandler to handle the exception
                    DataRetrievalHandler.handleDataRetrievalException(menuLink, exception);
                }
            }
            billingInformation = this.fetchBillingInformation(group, billingInformation);
        }

        return billingInformation;
    }

    /**
     * fetch BillingInformation for subscribers using secondary (subsequent) DAO calls - calls to BillingSummary (group policy),
     * BillingAccountAddress/AccountsReceivableSummary (individual policy)
     * @param billingInformation - mutated and returned by this method
     * @param subject - used for DAO calls
     * @return billingInformation - the provided BillingInformation, mutated
     * @throws Exception If there is an error.
     */
    private BillingInformation fetchSecondarySubscriberBillingInformation(BillingInformation billingInformation, Subject subject) throws Exception {

        BillingInformation fetchedBillingInformation = null;
        final BillingInformation criteriaBillingInformation = billingInformation;
        Map<String, MenuLink> userConfigs = getUserConfigEntries(subject);
        /*
         * if group policy, fetch billing information via billing DAO
         */
        if (billingInformation.getGroupPolicy()) {

            //fetch billing information if not on group policy            
            MenuLink menuLink = userConfigs.get(RETRIEVE_BILLING_INFO);
            if (menuLink == null) {
                log.warn("menulink not found for key [" + RETRIEVE_BILLING_INFO + "]");
            }

            if (DataRetrievalHandler.runDataRetrieval(menuLink)) {
                try {
                    fetchedBillingInformation = SubjectUtils.runAsSubject(() -> billingDAO.findByARNumber(criteriaBillingInformation.getMasterARNumber()), subject);
                } catch (Exception exception) {
                    //if an exception is generated, allow DataRetrievalHandler to handle the exception
                    DataRetrievalHandler.handleDataRetrievalException(menuLink, exception);
                }
            }
            billingInformation = this.fetchBillingInformation(fetchedBillingInformation, billingInformation);

        } else {
            ArrayList<WorkTask<?>> workTasks = new ArrayList<>(THREE);
            workTasks.add(retrieveBillingAccountAddressInfo(billingInformation.getListBillNumber(), subject, billingInformation));
            workTasks.add(retrieveAccountsReceivableSummary(billingInformation.getMasterARNumber(), subject, billingInformation, null));
            workTasks.add(retrieveAccountsReceivableHistory(billingInformation.getMasterARNumber(), subject, billingInformation, null));

            //create a work executor, execute work tasks
            WorkExecutor workExecutor = new WorkExecutor(executor, workTasks);
            workExecutor.executeWorkTasks();
        }

        return billingInformation;
    }

    /**
     * fetch BillingInformation for subscribers using tertiary (subsequent) DAO calls - calls to PremiumDelinquencyStatus/AccountsReceivableHistory (group
     * policy)
     * @param billingInformation - mutated and returned by this method
     * @param subject - used for DAO calls
     * @return billingInformation - the provided BillingInformation, mutated
     * @throws Exception If there is an error.
     */
    private BillingInformation fetchTertiarySubscriberBillingInformation(BillingInformation billingInformation, Subject subject) throws Exception {

        /*
         * tertiary service calls
         */
        if (billingInformation.getGroupPolicy()) {
            ArrayList<WorkTask<?>> workTasks = new ArrayList<>(TWO);
            workTasks.add(retrievePremiumDelinquencyStatusDetail(billingInformation.getClientNumber(), billingInformation.getBusinessTypeCode(),
                    billingInformation.getMasterARNumber(), subject, billingInformation));
            workTasks.add(retrieveAccountsReceivableHistory(billingInformation.getMasterARNumber(), subject, billingInformation, null));

            //create a work executor, execute work tasks
            WorkExecutor workExecutor = new WorkExecutor(executor, workTasks);
            workExecutor.executeWorkTasks();
        }

        return billingInformation;
    }

    /**
     * fetch BillingInformation for Groups using initial (primary) DAO calls - calls to BillingSummary/GroupSummary/AccountsReceivableHistory
     * @param billingInformation - billing information to be populated
     * @param masterARNumber - accounts receivable number
     * @param cesGroupNumber - group number
     * @param productCode - product
     * @param coverageId - coverage
     * @param subject - used for DAO calls
     * @return provided BillingInformation, mutated
     */
    private BillingInformation fetchInitialGroupBillingInformation(BillingInformation billingInformation, String masterARNumber, String cesGroupNumber,
            String productCode, String coverageId, Subject subject) throws Exception {

        /*
         * List for DAO calls to be made concurrently 
         */
        ArrayList<WorkTask<?>> workTasks = new ArrayList<>(THREE);

        // add work item Threads to list
        workTasks.add(retrieveBillingInformation(masterARNumber, null, subject, billingInformation, null));
        workTasks.add(retrieveGroupSummary(cesGroupNumber, productCode, coverageId, subject, billingInformation));
        workTasks.add(retrieveAccountsReceivableSummary(masterARNumber, subject, billingInformation, null));
        workTasks.add(retrieveAccountsReceivableHistory(masterARNumber, subject, billingInformation, null));

        //create a work executor, execute work tasks
        WorkExecutor workExecutor = new WorkExecutor(executor, workTasks);
        workExecutor.executeWorkTasks();

        return billingInformation;
    }

    /**
     * fetch billing information for Groups using secondary DAO call (dependent on data from initial DAO calls) - PremiumDelinquencyStatusDetail only
     * @param billingInformation - billing information to be fetched
     * @param subject - used for DAO calls
     * @return provided BillingInformation, mutated
     * @throws Exception If there is an error.
     */
    private BillingInformation fetchSecondaryGroupBillingInformation(BillingInformation billingInformation, Subject subject) throws Exception {

        DelinquencyStatusDetails delinquencyStatusDetails = null;
        final BillingInformation criteriaBillingInformation = billingInformation;
        Map<String, MenuLink> userConfigs = getUserConfigEntries(subject);
        MenuLink menuLink = userConfigs.get(RETRIEVE_DELINQUENCY_STATUS_INFO);
        if (menuLink == null) {
            log.warn("menulink not found for key [" + RETRIEVE_DELINQUENCY_STATUS_INFO + "]");
        }

        if (DataRetrievalHandler.runDataRetrieval(menuLink)) {
            try {
                delinquencyStatusDetails = SubjectUtils.runAsSubject(() -> delinquencyStatusDAO.getDelinquencyStatusDetail(criteriaBillingInformation.getClientNumber(),
                                criteriaBillingInformation.getBusinessTypeCode(), criteriaBillingInformation.getMasterARNumber()), subject);
            } catch (Exception exception) {
                //if an exception is generated, allow DataRetrievalHandler to handle the exception
                DataRetrievalHandler.handleDataRetrievalException(menuLink, exception);
            }
        }

        billingInformation = this.fetchBillingInformation(delinquencyStatusDetails, billingInformation);
        if (log.isDebugEnabled() && delinquencyStatusDetails != null) {
            log.debug("fetchsecondarygroupbillinfo returned delinquencystatusdetails: " + delinquencyStatusDetails.toString());
        }
        return billingInformation;
    }

    /**
     * fetch BillingInformation information from the provided thread
     *
     * @param object Input object.
     * @param billingInformation Billing information.
     * @return BillingInformation
     */
    private BillingInformation fetchBillingInformation(Object object, BillingInformation billingInformation) {

        //take action based on parameter type
        if (object instanceof AccountsReceivableSummary) {
            //fetch results off the thread
            AccountsReceivableSummary accountsReceivableSummary = (AccountsReceivableSummary) object;
            if (billingInformation != null) {
                if (log.isDebugEnabled()) {
                    log.debug("fetched arSummary [" + accountsReceivableSummary + "] from ARSummary");
                }
                billingInformation.setCurrentBalance(accountsReceivableSummary.getCurrentBalanceDue());
                billingInformation.setDueDate(accountsReceivableSummary.getDueDate());
                billingInformation.setLastPayment(accountsReceivableSummary.getLastPaymentAmount());
                billingInformation.setLastPaymentReceivedDate(accountsReceivableSummary.getLastPaymentReceivedDate());
            }
        } else if (object instanceof AccountsReceivableHistory) {
            //fetch results off the thread
            AccountsReceivableHistory accountsReceivableHistory = (AccountsReceivableHistory) object;
            if (billingInformation != null) {
                if (log.isDebugEnabled()) {
                    log.debug("fetched arHistory [" + accountsReceivableHistory + "] from ARHistory");
                }
                billingInformation.setHasCoveragePeriods(accountsReceivableHistory.getHasCoveragePeriods());
            }
        } else if (object instanceof Group) {
            //fetch results off the thread
            Group group = (Group) object;
            if (billingInformation != null) {
                if (log.isDebugEnabled()) {
                    log.debug("fetched group [" + group + "] from GroupSummary");
                }
                billingInformation.setMasterARNumber(group.getMasterARNumber());
                billingInformation.setGroupName(group.getGroupName());
                billingInformation.setClientNumber(group.getClientNumber());
                billingInformation.setDueDate(group.getBillDueDate());
                billingInformation.setStatementCreatedDate(group.getLastBillDate());
                billingInformation.setPaymentSummaryNumber(group.getPaymentSummaryNumber());
            }
        } else if (object instanceof BillingContactInformation) {
            //fetch results off the thread
            BillingContactInformation fetchedInformation = (BillingContactInformation) object;
            if (log.isDebugEnabled()) {
                log.debug("fetched billing contact information [" + fetchedInformation + "] from BillingAccountAddressInfo");
            }
            billingInformation.setListBillName(fetchedInformation.getAddressName().getLastName());
            billingInformation.setListBillAccountNumber(fetchedInformation.getBillAccountNumber());
            billingInformation.setListBillContactName(fetchedInformation.getContactName().getLastName());
            billingInformation.setListBillPhoneNumber(fetchedInformation.getWorkPhoneNumber());
        } else if (object instanceof DelinquencyStatusDetails) {
            //fetch results off the thread
            DelinquencyStatusDetails fetchedInformation = (DelinquencyStatusDetails) object;
            boolean delinquencyStatus = Boolean.FALSE;
            if (this.isDelinquencyStatusPopulated(fetchedInformation)) {
                if (log.isDebugEnabled()) {
                    log.debug("fetched delinquency status [" + fetchedInformation + "] from PremiumDelinquencyStatus");
                }
                delinquencyStatus = Boolean.TRUE;
            }
            billingInformation.setDelinquencyStatus(delinquencyStatus);
        } else if (object instanceof BillingInformation) {
            //fetch results off the thread
            BillingInformation fetchedInformation = (BillingInformation) object;
            if (log.isDebugEnabled()) {
                log.debug("fetched billing information [" + fetchedInformation + "] from BillingSummary");
            }
            billingInformation.setBillNumber(fetchedInformation.getBillNumber());
            billingInformation.setListBillNumber(fetchedInformation.getListBillNumber());
            billingInformation.setMasterARNumber(fetchedInformation.getMasterARNumber());
            billingInformation.setClientNumber(fetchedInformation.getClientNumber());
            billingInformation.setBillModeCode(fetchedInformation.getBillModeCode());
            billingInformation.setDueDay(fetchedInformation.getDueDay());
            billingInformation.setSortCode(fetchedInformation.getSortCode());
            billingInformation.setBillFormatCode(fetchedInformation.getBillFormatCode());
            billingInformation.setBusinessTypeCode(fetchedInformation.getBusinessTypeCode());
            billingInformation.setSuppressDescription(fetchedInformation.getSuppressDescription());
            billingInformation.setAccountsRecievableCreationDescription(fetchedInformation.getAccountsRecievableCreationDescription());
            billingInformation.setPaymentMethodCode(fetchedInformation.getPaymentMethodCode());
            billingInformation.setOutputTypeCode(fetchedInformation.getOutputTypeCode());
            billingInformation.setBankAccountName(fetchedInformation.getBankAccountName());
            billingInformation.setBankAccountNumber(fetchedInformation.getBankAccountNumber());
            billingInformation.setAbaRoutingNumber(fetchedInformation.getAbaRoutingNumber());
            billingInformation.setCreditCardNumber(fetchedInformation.getCreditCardNumber());
            billingInformation.setCreditCardExpiration(fetchedInformation.getCreditCardExpiration());
        }

        return billingInformation;
    }

    /**
     * Helper method to retrieve billing account information for delinquency status call if billing info parameters missing
     * @param subscriberId The subscriber id.
     * @param subject The subject.
     * @return billing information for use in delinquency status call
     * @throws Exception If there is an error.
     */
    private BillingInformation getBillingInformationWithSubscriberId(final String subscriberId, Subject subject) throws Exception {
        Map<String, MenuLink> userConfigs = getUserConfigEntries(subject);
        MenuLink billingInfoSearchFlag = userConfigs.get(RETRIEVE_BILLING_INFO);
        BillingInformation billingInformation = null;
        if (DataRetrievalHandler.runDataRetrieval(billingInfoSearchFlag)) {
            try {
                billingInformation = SubjectUtils.runAsSubject(() -> billingDAO.findBySubscriber(subscriberId), subject);
            } catch (AccountClosedException ace) {
                log.warn("Billing Summary - Account Closed for subscriber [" + subscriberId + "].");
            } catch (Exception exception) {
                //if an exception is generated, allow DataRetrievalHandler to handle the exception
                DataRetrievalHandler.handleDataRetrievalException(billingInfoSearchFlag, exception);
            }
        }
        return billingInformation;
    }

    /**
     * Helper method to retrieve billing account information for delinquency status call if billing info parameters missing
     * @param userConfigs
     * @param masterAccountsReceivableNumber
     * @param subject
     * @return billing information for use in delinquency status call
     * @throws Exception
     */
    private BillingInformation getBillingInformation(Map<String, MenuLink> userConfigs, final String masterAccountsReceivableNumber, Subject subject)
            throws Exception {
        MenuLink billingInfoSearchFlag = userConfigs.get(RETRIEVE_BILLING_INFO);
        BillingInformation billingInformation = null;
        if (DataRetrievalHandler.runDataRetrieval(billingInfoSearchFlag)) {
            try {
                billingInformation = SubjectUtils.runAsSubject(() -> billingDAO.findByARNumber(masterAccountsReceivableNumber), subject);
            } catch (AccountClosedException ace) {
                log.warn("Billing Summary - Account Closed for master accounts receivable number [" + masterAccountsReceivableNumber + "].");
            } catch (Exception exception) {
                //if an exception is generated, allow DataRetrievalHandler to handle the exception
                DataRetrievalHandler.handleDataRetrievalException(billingInfoSearchFlag, exception);
            }
        }
        return billingInformation;
    }

    /**
     * Helper method to contain details for retrieving Delinquency Status Details
     *
     * @param userConfigs
     * @param clientNumber
     * @param businessTypeCode
     * @param masterAccountsReceivableNumber
     * @param subject
     * @return
     * @throws Exception
     */
    private DelinquencyStatusDetails getDelinquencyStatusDetails(Map<String, MenuLink> userConfigs, final String clientNumber, final Code businessTypeCode,
            final String masterAccountsReceivableNumber, Subject subject) throws Exception {

        MenuLink delinquencyStatusInfoSearchFlag = userConfigs.get(RETRIEVE_DELINQUENCY_STATUS_INFO);

        DelinquencyStatusDetails details = null;

        if (DataRetrievalHandler.runDataRetrieval(delinquencyStatusInfoSearchFlag)) {
            try {
                details = SubjectUtils.runAsSubject(() -> delinquencyStatusDAO.getDelinquencyStatusDetail(clientNumber, businessTypeCode, masterAccountsReceivableNumber), subject);
            } catch (Exception exception) {
                //if an exception is generated, allow DataRetrievalHandler to handle the exception
                DataRetrievalHandler.handleDataRetrievalException(delinquencyStatusInfoSearchFlag, exception);
            }
        }

        if (log.isDebugEnabled() && details != null) {
            log.debug("getdelinquencystatusdetails returned delinquencystatusdetails: " + details.toString());
        }
        return details;
    }

    /**
     * fetch a WorkItem instance to run the Accounts Receivable History DAO
     *
     * @param masterARNumber
     * @param subject
     * @param billingInformation
     * @param history
     * @return
     */
    private WorkTask<AccountsReceivableHistory> retrieveAccountsReceivableHistory(final String masterARNumber, final Subject subject,
            final BillingInformation billingInformation, final AccountsReceivableHistory history) {
        return new WorkTask<AccountsReceivableHistory>(RETRIEVE_ACCOUNTS_RECEIVABLE_HISTORY_INFO, subject, () -> accountsReceivableHistoryDAO.getAccountsReceivableHistory(masterARNumber, null)) {
            @Override
            public void onComplete() {
                //populate history from results
                AccountsReceivableHistory fetchedAccountsReceivableHistory = this.getResults();
                if (fetchedAccountsReceivableHistory != null) {
                    if (history != null) {
                        history.setAccountsReceivable(fetchedAccountsReceivableHistory.getAccountsReceivable());
                        history.setMasterARName(fetchedAccountsReceivableHistory.getMasterARName());
                    }
                    if (billingInformation != null) {
                        //fetch results off the thread
                        AccountsReceivableHistory accountsReceivableHistory = this.getResults();
                        if (accountsReceivableHistory != null) {
                            if (log.isDebugEnabled()) {
                                log.debug("fetched arHistory [" + accountsReceivableHistory + "] from ARHistory");
                            }
                            billingInformation.setHasCoveragePeriods(accountsReceivableHistory.getHasCoveragePeriods());
                        }
                    }
                }
            }
        };
    }

    /**
     * fetch a Work instance to run the Delinquency Status DAO
     *
     * @param clientNumber
     * @param businessTypeCode
     * @param masterARNumber
     * @param subject
     * @param billingInformation
     * @return
     */
    private WorkTask<DelinquencyStatusDetails> retrievePremiumDelinquencyStatusDetail(final String clientNumber, final Code businessTypeCode,
            final String masterARNumber, final Subject subject, final BillingInformation billingInformation) {
        return new WorkTask<DelinquencyStatusDetails>(RETRIEVE_DELINQUENCY_STATUS_INFO, subject, () -> delinquencyStatusDAO.getDelinquencyStatusDetail(clientNumber, businessTypeCode, masterARNumber)) {
            @Override
            public void onComplete() {
                //fetch results off the thread
                DelinquencyStatusDetails fetchedInformation = this.getResults();
                boolean delinquencyStatus = Boolean.FALSE;
                if (fetchedInformation != null && isDelinquencyStatusPopulated(fetchedInformation)) {
                    if (log.isDebugEnabled()) {
                        log.debug("fetched delinquency status [" + fetchedInformation + "] from PremiumDelinquencyStatus");
                    }
                    if (log.isDebugEnabled()) {
                        log.debug("fetched delinquency status [" + fetchedInformation + "] from PremiumDelinquencyStatus");
                    }
                    delinquencyStatus = Boolean.TRUE;
                }
                billingInformation.setDelinquencyStatus(delinquencyStatus);
            }
        };
    }

    /**
     * fetch a Work instance to run the Group Summary DAO
     *
     * @param groupNumber
     * @param productCode
     * @param coverageId
     * @param subject
     * @param billingInformation
     * @return
     */
    private WorkTask<Group> retrieveGroupSummary(final String groupNumber, final String productCode, final String coverageId, final Subject subject,
            final BillingInformation billingInformation) {
        final GroupSearchCriteria criteria = new GroupSearchCriteria();
        criteria.setCesGroupNumber(groupNumber);
        criteria.setProductCode(productCode);
        criteria.setCoverageId(coverageId);

        return new WorkTask<Group>(RETRIEVE_GROUP_INFO, subject, () -> groupSummaryDAO.getGroupInformation(criteria)) {
            @Override
            public void onComplete() {
                Group group = this.getResults();
                if (group != null) {
                    if (log.isDebugEnabled()) {
                        log.debug("fetched group [" + group + "] from GroupSummary");
                    }
                    billingInformation.setMasterARNumber(group.getMasterARNumber());
                    billingInformation.setGroupName(group.getGroupName());
                    billingInformation.setClientNumber(group.getClientNumber());
                    billingInformation.setDueDate(group.getBillDueDate());
                    billingInformation.setStatementCreatedDate(group.getLastBillDate());
                    billingInformation.setPaymentSummaryNumber(group.getPaymentSummaryNumber());
                }
            }
        };
    }

    /**
     * fetch a Work instance to run the Billing Account Address Info DAO
     *
     * @param listBillNumber
     * @param subject
     * @param billingInformation
     * @return
     */
    private WorkTask<BillingContactInformation> retrieveBillingAccountAddressInfo(final String listBillNumber, final Subject subject,
            final BillingInformation billingInformation) {
        return new WorkTask<BillingContactInformation>(RETRIEVE_BILLING_ACCOUNT_ADDRESS_INFO, subject, () -> billingAccountAddressDAO.findListBillContactInformation(listBillNumber)) {
            @Override
            public void onComplete() {
                BillingContactInformation fetchedInformation = this.getResults();
                if (log.isDebugEnabled()) {
                    log.debug("fetched billing contact information [" + fetchedInformation + "] from BillingAccountAddressInfo");
                }
                if (fetchedInformation != null) {
                    billingInformation.setListBillName(fetchedInformation.getAddressName().getLastName());
                    billingInformation.setListBillAccountNumber(fetchedInformation.getBillAccountNumber());
                    billingInformation.setListBillContactName(fetchedInformation.getContactName().getLastName());
                    billingInformation.setListBillPhoneNumber(fetchedInformation.getWorkPhoneNumber());
                }
            }
        };
    }

    /**
     * fetch a Work instance to run the Accounts Receivable Summary DAO
     *
     * @param masterARNumber
     * @param subject
     * @param billingInformation
     * @param accountsReceivableHistory
     * @return
     */
    private WorkTask<AccountsReceivableSummary> retrieveAccountsReceivableSummary(final String masterARNumber, final Subject subject,
            final BillingInformation billingInformation, final AccountsReceivableHistory accountsReceivableHistory) {
        return new WorkTask<AccountsReceivableSummary>(RETRIEVE_ACCOUNTS_RECEIVABLE_SUMMARY_INFO, subject, () -> accountsReceivableSummaryDAO.getAccountsReceivableSummary(masterARNumber)) {
            @Override
            public void onComplete() {
                AccountsReceivableSummary accountsReceivableSummary = this.getResults();
                if (accountsReceivableSummary != null) {
                    if (billingInformation != null) {
                        if (log.isDebugEnabled()) {
                            log.debug("fetched arSummary [" + accountsReceivableSummary + "] from ARSummary");
                        }
                        billingInformation.setCurrentBalance(accountsReceivableSummary.getCurrentBalanceDue());
                        billingInformation.setDueDate(accountsReceivableSummary.getDueDate());
                        billingInformation.setLastPayment(accountsReceivableSummary.getLastPaymentAmount());
                        billingInformation.setLastPaymentReceivedDate(accountsReceivableSummary.getLastPaymentReceivedDate());
                    }
                    if (accountsReceivableHistory != null) {
                        accountsReceivableHistory.setGroupNumber(accountsReceivableSummary.getGroupNumber());
                    }
                }
            }
        };
    }

    /**
     * fetch a Work instance to run the Billing Information DAO
     *
     * @param masterARNumber
     * @param subscriberId
     * @param subject
     * @param billingInformation
     * @param accountsReceivableHistory
     * @return
     */
    private WorkTask<BillingInformation> retrieveBillingInformation(final String masterARNumber, final String subscriberId, final Subject subject,
            final BillingInformation billingInformation, final AccountsReceivableHistory accountsReceivableHistory) {
        return new WorkTask<BillingInformation>(RETRIEVE_BILLING_INFO, subject, () -> {
            try {
                if (StringUtils.isNotEmpty(subscriberId)) {
                    return billingDAO.findBySubscriber(subscriberId);
                } else {
                    return billingDAO.findByARNumber(masterARNumber);
                }
            } catch (AccountClosedException ace) {
                //log message - propagate exception
                if (StringUtils.isNotEmpty(subscriberId)) {
                    log.warn("Billing Summary - Account Closed for subscriber [" + subscriberId + "].");
                } else {
                    log.warn("Billing Summary - Account Closed for masterARNumber [" + masterARNumber + "].");
                }
                throw ace;
            }
        }) {
            @Override
            public void onComplete() {
                BillingInformation fetchedInformation = this.getResults();
                if (fetchedInformation != null) {
                    if (log.isDebugEnabled()) {
                        log.debug("fetched billing information [" + fetchedInformation + "] from BillingSummary");
                    }
                    if (billingInformation != null) {
                        billingInformation.setBillNumber(fetchedInformation.getBillNumber());
                        billingInformation.setListBillNumber(fetchedInformation.getListBillNumber());
                        billingInformation.setMasterARNumber(fetchedInformation.getMasterARNumber());
                        billingInformation.setClientNumber(fetchedInformation.getClientNumber());
                        billingInformation.setBillModeCode(fetchedInformation.getBillModeCode());
                        billingInformation.setDueDay(fetchedInformation.getDueDay());
                        billingInformation.setSortCode(fetchedInformation.getSortCode());
                        billingInformation.setBillFormatCode(fetchedInformation.getBillFormatCode());
                        billingInformation.setBusinessTypeCode(fetchedInformation.getBusinessTypeCode());
                        billingInformation.setSuppressDescription(fetchedInformation.getSuppressDescription());
                        billingInformation.setAccountsRecievableCreationDescription(fetchedInformation.getAccountsRecievableCreationDescription());
                        billingInformation.setPaymentMethodCode(fetchedInformation.getPaymentMethodCode());
                        billingInformation.setOutputTypeCode(fetchedInformation.getOutputTypeCode());
                        billingInformation.setBankAccountName(fetchedInformation.getBankAccountName());
                        billingInformation.setBankAccountNumber(fetchedInformation.getBankAccountNumber());
                        billingInformation.setAbaRoutingNumber(fetchedInformation.getAbaRoutingNumber());
                        billingInformation.setCreditCardNumber(fetchedInformation.getCreditCardNumber());
                        billingInformation.setCreditCardExpiration(fetchedInformation.getCreditCardExpiration());
                    }
                    if (accountsReceivableHistory != null) {
                        accountsReceivableHistory.setClientNumber(fetchedInformation.getClientNumber());
                        accountsReceivableHistory.setBusinessTypeCode(fetchedInformation.getBusinessTypeCode());
                        accountsReceivableHistory.setMasterARNumber(fetchedInformation.getMasterARNumber());
                    }
                }
            }
        };
    }

    /**
     * get the report identifier on the provided Billing Information
     *
     * @param billingInformation
     * @param subject
     * @return
     */
    private BillingInformation setReportIdentifier(BillingInformation billingInformation, Subject subject) {

        //use the current RPN to set the report identifier
        Map<String, Subsystem> subsystemMap = SubjectUtils.getRPNSubsystems(subject);
        Subsystem info = subsystemMap.get(Subsystems.INFO.getName());
        String rpn = info.getRpn();
        if (rpn.equals(BLUE_CHOICE_RPN)) {
            billingInformation.setReportIdentifier(ReportIdentifier.CHCBILL);
        } else {
            if (billingInformation.getGroupPolicy()) {
                billingInformation.setReportIdentifier(ReportIdentifier.PVTBBILL);
            } else {
                billingInformation.setReportIdentifier(ReportIdentifier.PVTDBL);
            }
        }
        if (billingInformation.getReportIdentifier() == null) {
            log.warn("could not set report identifier, defaulting to [" + ReportIdentifier.PVTDBL + "]");
            billingInformation.setReportIdentifier(ReportIdentifier.PVTDBL);
        }

        return billingInformation;
    }

    /**
     * determine if Delinquency Status details are populated
     * @param details
     * @return
     */
    private boolean isDelinquencyStatusPopulated(DelinquencyStatusDetails details) {
        return StringUtils.isNotBlank(details.getCancelOnHoldIndicator()) || StringUtils.isNotBlank(details.getClientDelinquencySetId())
                || StringUtils.isNotBlank(details.getClientName()) || StringUtils.isNotBlank(details.getCustomerName())
                || StringUtils.isNotBlank(details.getDelinquencyStage()) || StringUtils.isNotBlank(details.getMasterAccountsReceivableName())
                || StringUtils.isNotBlank(details.getParameterMasterId()) || (details.getCancelHoldStageAccountsReceivableAmount() != null)
                || (details.getCancelHoldStageDelinquencyAccountsReceivableAmount() != null)
                || (details.getCancelHoldStageDelinquencyAccountsReceivableDate() != null) || (details.getCancelHoldStageDueDate() != null)
                || (StringUtils.isNotBlank(details.getCancelReasonCode().getCode())) || (details.getCurrentAccountsReceivableAmount() != null)
                || (details.getCurrentAccountsReceivableDate() != null) || (details.getCurrentDelinquentAccountsReceivableAmount() != null)
                || (details.getCurrentDelinquentAccountsReceivableDate() != null) || (details.getDueDate() != null)
                || (details.getInitialEvaluationDate() != null) || (details.getLastPaymentAmount() != null) || (details.getLastPaymentDate() != null)
                || (StringUtils.isNotBlank(details.getLetterDistributionCode().getCode())) || (details.getProjectedCancelEffectiveDate() != null)
                || (details.getProjectedCancelProcessDate() != null);
    }

    /**
     * fetch userConfigs via DesktopAPI
     * @param subject
     * @return Map of userconfigs
     */
    private static Map<String, MenuLink> getUserConfigEntries(Subject subject) throws Exception {
        Map<String, ?> rulesEntries = DesktopAPI.getRulesEntries(subject);
        @SuppressWarnings("unchecked")
        Map<String, MenuLink> userConfigs = (Map<String, MenuLink>) rulesEntries.get(USERCONFIG);
        return userConfigs;
    }

    /**
     * @param billingDAO the billingDAO to set
     */
    public void setBillingDAO(BillingDAO billingDAO) {
        this.billingDAO = billingDAO;
    }

    /**
     * @param groupSummaryDAO the groupSummaryDAO to set
     */
    public void setGroupSummaryDAO(GroupSummaryDAO groupSummaryDAO) {
        this.groupSummaryDAO = groupSummaryDAO;
    }

    /**
     * @param billingAccountAddressDAO the billingAccountAddressDAO to set
     */
    public void setBillingAccountAddressDAO(BillingAccountAddressDAO billingAccountAddressDAO) {
        this.billingAccountAddressDAO = billingAccountAddressDAO;
    }

    /**
     * @param delinquencyStatusDAO the delinquencyStatusDAO to set
     */
    public void setDelinquencyStatusDAO(DelinquencyStatusDAO delinquencyStatusDAO) {
        this.delinquencyStatusDAO = delinquencyStatusDAO;
    }

    /**
     * @param accountsReceivableHistoryDAO the accountsReceivableHistoryDAO to set
     */
    public void setAccountsReceivableHistoryDAO(AccountsReceivableHistoryDAO accountsReceivableHistoryDAO) {
        this.accountsReceivableHistoryDAO = accountsReceivableHistoryDAO;
    }

    /**
     * @param accountsReceivableSummaryDAO the accountsReceivableSummaryDAO to set
     */
    public void setAccountsReceivableSummaryDAO(AccountsReceivableSummaryDAO accountsReceivableSummaryDAO) {
        this.accountsReceivableSummaryDAO = accountsReceivableSummaryDAO;
    }

    /**
     * @param accountsReceivableDetailDAO the accountsReceivableDetailDAO to set
     */
    public void setAccountsReceivableDetailDAO(AccountsReceivableDetailDAO accountsReceivableDetailDAO) {
        this.accountsReceivableDetailDAO = accountsReceivableDetailDAO;
    }

    /**
     * @param businessClassificationCodeBiz the businessClassificationCodeBiz to set
     */
    public void setBusinessClassificationCodeBiz(BusinessClassificationCodeBiz businessClassificationCodeBiz) {
        this.businessClassificationCodeBiz = businessClassificationCodeBiz;
    }

    /**
     * @param subscriberDAO the subscriberDAO to set
     */
    public void setSubscriberDAO(SubscriberDAO subscriberDAO) {
        this.subscriberDAO = subscriberDAO;
    }
}
