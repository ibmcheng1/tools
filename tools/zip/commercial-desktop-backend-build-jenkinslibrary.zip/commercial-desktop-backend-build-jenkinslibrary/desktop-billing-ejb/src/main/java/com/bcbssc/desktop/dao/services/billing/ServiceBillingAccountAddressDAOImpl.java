/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2013 BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.dao.services.billing;

import javax.ejb.Stateless;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.dao.billing.BillingAccountAddressDAO;
import com.bcbssc.domain.entity.billing.BillingContactInformation;
import com.bcbssc.domain.entity.enums.billing.AddressType;
import com.bcbssc.domain.valueobject.PhoneNumber;
import com.bcbssc.services.billingaccountaddressinfo.BillingAccountAddressInfoBillAccountAddressInfo;
import com.bcbssc.services.billingaccountaddressinfo.BillingAccountAddressInfoInput;
import com.bcbssc.services.billingaccountaddressinfo.BillingAccountAddressInfoOutput;
import com.bcbssc.services.billingaccountaddressinfo.BillingAccountAddressInfoService;
import com.bcbssc.wsutils.WebServiceConsumerCallback;
import com.bcbssc.wsutils.WebServiceConsumerTemplate;

import java.util.List;

/**
 * Billing Account Address DAO implementation - methods for fetching Bill Account Address information 
 */
@Stateless(name = "BillingAccountAddressDAO")
public class ServiceBillingAccountAddressDAOImpl implements BillingAccountAddressDAO {

    private static final Log logger = LogFactory.getLog(ServiceBillingAccountAddressDAOImpl.class);

    /**
     * fetch list bill information
     * @see com.bcbssc.desktop.dao.billing.BillingAccountAddressDAO#findListBillContactInformation(java.lang.String) 
     */
    public BillingContactInformation findListBillContactInformation(String billNumber) throws Exception {
        if (null == billNumber) {
            throw new IllegalArgumentException("A billNumber must be provided to run this web service call");
        }

        BillingAccountAddressInfoWebServiceConsumerCallback consumer = getWebServiceConsumerCallback();
        consumer.billNumber = billNumber;
        //always use the 'Latest Address' when performing this lookup
        consumer.addressTypeCode = AddressType.LA.toString();
        //execute the web service
        return (BillingContactInformation) new WebServiceConsumerTemplate().consumeService(null, consumer);
    }

    /**
     * utility method for unit testing, override and provide a unit
     * implementation of the service proxy
     */
    protected BillingAccountAddressInfoService getBillingAccountAddressInfoService() {
//        return (BillingAccountAddressInfoService) new ServiceClientGenerator("BillingAccountAddressInfo").getServiceClient();
        throw new UnsupportedOperationException("This class needs to be updated to use BaseServiceIntegrator");
    }

    /**
     * Returns the <code>WebServiceConsumerCallback</code> for this DAO.
     */
    protected BillingAccountAddressInfoWebServiceConsumerCallback getWebServiceConsumerCallback() {
        return new BillingAccountAddressInfoWebServiceConsumerCallback();
    }

    /**
     * Web Service Consumer for BillingAccountAddressInfo
     */
    protected class BillingAccountAddressInfoWebServiceConsumerCallback implements WebServiceConsumerCallback {

        private String billNumber = StringUtils.EMPTY;
        private String addressTypeCode = StringUtils.EMPTY;

        /**
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#getService()
         */
        public Object getService() {
            return getBillingAccountAddressInfoService();
        }

        /**
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#invokeService(java.lang.Object, java.lang.Object)
         */
        public Object invokeService(Object serviceInput, Object serviceClient) throws Exception {
            return ((BillingAccountAddressInfoService) serviceClient)
                    .getBillingAccountAddressInfo((BillingAccountAddressInfoInput) serviceInput);
        }

        /**
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#mapInput(java.lang.Object)
         */
        public Object mapInput(Object modelInput) {
            BillingAccountAddressInfoInput input = new BillingAccountAddressInfoInput();
            input.setBillInfoNumberRequested(this.billNumber);
            input.setAddressTypeCode(this.addressTypeCode);
            //hostid,hostpassword,mwiconfig,toescapechar set by handler
            return input;
        }

        /**
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#mapOutput(java.lang.Object)
         */
        public Object mapOutput(Object serviceResponse) {
            BillingAccountAddressInfoOutput output = (BillingAccountAddressInfoOutput) serviceResponse;
            List<BillingAccountAddressInfoBillAccountAddressInfo> results = output.getBillAccountAddressInfo().getBillingAccountAddressInfoBillAccountAddressInfo();

            BillingContactInformation billingContactInformation = null;

            //fetch billing information if provided
            if (!results.isEmpty()) {
                //use the first populated record
                for (BillingAccountAddressInfoBillAccountAddressInfo addressInfo : results) {
                    if (!StringUtils.isBlank(StringUtils.trimToEmpty(addressInfo.getBillInfoNumber()))) {
                        billingContactInformation = new BillingContactInformation();

                        billingContactInformation.getAddressName().setLastName(StringUtils.trimToEmpty(addressInfo.getBillingAddressName()));
                        billingContactInformation.setBillAccountNumber(StringUtils.trimToEmpty(addressInfo.getBillInfoNumber()));
                        billingContactInformation.getContactName().setLastName(StringUtils.trimToEmpty(addressInfo.getBillingAddressContactName()));
                        PhoneNumber listBillPhoneNumber = new PhoneNumber();
                        String phoneNumber = StringUtils.trimToEmpty(addressInfo.getBillingPhoneNumber());
                        if (phoneNumber.length() == 7) {
                            listBillPhoneNumber.setAreaCode(StringUtils.trimToEmpty(addressInfo.getBillingAreaCode()));
                            listBillPhoneNumber.setPrefix(phoneNumber.substring(0, 3));
                            listBillPhoneNumber.setSuffix(phoneNumber.substring(3));
                            listBillPhoneNumber.setExtension(StringUtils.trimToEmpty(addressInfo.getBillingPhoneExtensionNumber()));
                        }
                        billingContactInformation.setWorkPhoneNumber(listBillPhoneNumber);
                        break;
                    }
                }
            }

            return billingContactInformation;
        }
    }

}
