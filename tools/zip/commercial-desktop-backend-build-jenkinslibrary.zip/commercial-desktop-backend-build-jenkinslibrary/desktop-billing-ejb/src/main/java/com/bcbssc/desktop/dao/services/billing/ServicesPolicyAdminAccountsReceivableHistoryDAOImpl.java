/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2013 BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.dao.services.billing;

import com.bcbssc.desktop.dao.billing.AccountsReceivableHistoryDAO;
import com.bcbssc.desktop.util.data.DataParsingUtils;
import com.bcbssc.domain.entity.billing.AccountReceivable;
import com.bcbssc.domain.entity.billing.AccountsReceivableHistory;
import com.bcbssc.services.policyadminarhistory.PolicyAdminARHistoryAccountReceivable;
import com.bcbssc.services.policyadminarhistory.PolicyAdminARHistoryInput;
import com.bcbssc.services.policyadminarhistory.PolicyAdminARHistoryOutput;
import com.bcbssc.services.policyadminarhistory.PolicyAdminARHistoryService;
import com.bcbssc.wsutils.WebServiceConsumerCallback;
import com.bcbssc.wsutils.WebServiceConsumerTemplate;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.ejb.Stateless;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * DAO for fetching AccountsReceivableHistory data
 */
@Stateless(name = "ServicesPolicyAdminAccountsReceivableHistoryDAO")
public class ServicesPolicyAdminAccountsReceivableHistoryDAOImpl implements AccountsReceivableHistoryDAO {

    /** logger  */
    private static final Log logger = LogFactory.getLog(ServicesPolicyAdminAccountsReceivableHistoryDAOImpl.class);
    private static final char COMMA = ',';

    /**
     * fetch ARHistory
     * @param masterARNumber
     * @param asOfDateRequested
     * @return
     * @throws Exception
     */
    public AccountsReceivableHistory getAccountsReceivableHistory(String masterARNumber, Date asOfDateRequested) throws Exception {

        if(StringUtils.isBlank(masterARNumber)) {
            throw new IllegalArgumentException("masterARNumber must be provided");
        }
        
        PolicyAdminAccountsReceivableHistoryWebServiceConsumer consumer = getWebServiceConsumerCallback();
        DateFormat dateFormat = new SimpleDateFormat(DataParsingUtils.FORMAT_DASHES_FULLYEAR_MONTH_DAY);
        if (asOfDateRequested != null) {
            consumer.asOfDateRequested = dateFormat.format(asOfDateRequested);
        }
        consumer.masterARNumber = masterARNumber;

        return (AccountsReceivableHistory) new WebServiceConsumerTemplate().consumeService(null, consumer);
    }

    /**
     * utility method for unit testing, override and provide a unit
     * implementation of the service proxy
     * 
     * @return
     */
    protected PolicyAdminARHistoryService getPolicyAdminArHistoryService() {
//        return (PolicyAdminARHistoryService) new ServiceClientGenerator("PolicyAdminARHistory").getServiceClient();
        throw new UnsupportedOperationException("This class needs to be updated to extend BaseServiceIntegrator");
    }

    /**
     * Returns the <code>WebServiceConsumerCallback</code> for this DAO.
     */
    protected PolicyAdminAccountsReceivableHistoryWebServiceConsumer getWebServiceConsumerCallback() {
        return new PolicyAdminAccountsReceivableHistoryWebServiceConsumer();
    }

    /**
     * Web Service Consumer for the PolicyAdminARHistory web service
     */
    protected class PolicyAdminAccountsReceivableHistoryWebServiceConsumer implements WebServiceConsumerCallback {

        private String asOfDateRequested;
        private String masterARNumber;

        /**
         * Gets the <code>PolicyAdminARHistory</code> service handle.
         */
        @Override
        public Object getService() {
            return getPolicyAdminArHistoryService();
        }

        /**
         * invokes the web service
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#invokeService(java.lang.Object, java.lang.Object)
         */
        public Object invokeService(Object serviceInput, Object serviceClient) throws Exception {

            PolicyAdminARHistoryService service = (PolicyAdminARHistoryService) serviceClient;
            PolicyAdminARHistoryOutput result = service.getAccountsReceivableHistory((PolicyAdminARHistoryInput) serviceInput);
            return result;
        }

        /**
         * map the input for the web service 
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#mapInput(java.lang.Object)
         */
        public Object mapInput(Object obj) {
            PolicyAdminARHistoryInput input = new PolicyAdminARHistoryInput();
            input.setAsOfDateRequested(this.asOfDateRequested);
            input.setMasterArNumber(this.masterARNumber);
            return input;
        }

        /**
         * map the output from the web service
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#mapOutput(java.lang.Object)
         */
        public Object mapOutput(Object serviceResponse) {
            PolicyAdminARHistoryOutput output = (PolicyAdminARHistoryOutput) serviceResponse;
            AccountsReceivableHistory results = new AccountsReceivableHistory();

            //master AR name
            results.setMasterARName(output.getMasterArName());

            //accounts
            List<AccountReceivable> accountReceivableList = new ArrayList<>();
            if (!output.getAccountReceivable().getPolicyAdminARHistoryAccountReceivable().isEmpty()) {
                List<PolicyAdminARHistoryAccountReceivable> accounts = output.getAccountReceivable().getPolicyAdminARHistoryAccountReceivable();

                for (PolicyAdminARHistoryAccountReceivable account : accounts) {
                    AccountReceivable accountReceivable = new AccountReceivable();
                    if (StringUtils.isNotBlank(account.getCoveragePeriodBeginDate()) && StringUtils.isNotBlank(account.getCoveragePeriodEndDate())) {

                        if (StringUtils.isNotBlank(StringUtils.trimToEmpty(account.getBillDueDate()))) {
                            try {
                                accountReceivable.setBillDueDate(DataParsingUtils.dateFromHalfUsa(StringUtils.trimToEmpty(account.getBillDueDate())));
                            } catch (IllegalArgumentException iae) {
                                logger.warn("Unable to parse bill due date = [" + account.getBillDueDate() + "]");
                            }
                        }

                        if (StringUtils.isNotBlank(StringUtils.trimToEmpty(account.getCoveragePeriodBeginDate()))) {
                            try {
                                accountReceivable.getCoveragePeriod().setStartDate(DataParsingUtils.dateFromHalfUsa(StringUtils.trimToEmpty(account
                                        .getCoveragePeriodBeginDate())));
                            } catch (IllegalArgumentException iae) {
                                logger.warn("Unable to parse coverage period begin date = [" + account.getCoveragePeriodBeginDate() + "]");
                            }
                        }

                        if (StringUtils.isNotBlank(StringUtils.trimToEmpty(account.getCoveragePeriodEndDate()))) {
                            try {
                                accountReceivable.getCoveragePeriod().setEndDate(DataParsingUtils.dateFromHalfUsa(StringUtils.trimToEmpty(account
                                        .getCoveragePeriodEndDate())));
                            } catch (IllegalArgumentException iae) {
                                logger.warn("Unable to parse coverage period end date = [" + account.getCoveragePeriodEndDate() + "]");
                            }
                        }

                        accountReceivable.setCoverageMarketingPackage(StringUtils.trimToEmpty(account.getCoverageMarketingPackage()));
                        accountReceivable.setCoverageSubMarketingPackage(StringUtils.trimToEmpty(account.getCoverageSubMarketingPackage()));

                        try {
                            accountReceivable.setPeriodBilled(new BigDecimal(formatAmount(account.getPeriodBilled())));
                        } catch (NumberFormatException nfe) {
                            logger.warn("Could not parse period billed [" + account.getPeriodBilled() + "]");
                        }

                        try {
                            accountReceivable.setPeriodAdjustments(new BigDecimal(formatAmount(account.getPeriodAdjustments())));
                        } catch (NumberFormatException nfe) {
                            logger.warn("Could not parse period adjustments [" + account.getPeriodAdjustments() + "]");
                        }

                        try {
                            accountReceivable.setPeriodFees(new BigDecimal(formatAmount(account.getPeriodFees())));
                        } catch (NumberFormatException nfe) {
                            logger.warn("Could not parse period fees [" + account.getPeriodFees() + "]");
                        }

                        try {
                            accountReceivable.setPeriodBalance(new BigDecimal(formatAmount(account.getPeriodBalance())));
                        } catch (NumberFormatException nfe) {
                            logger.warn("Could not parse period balance [" + account.getPeriodBalance() + "]");
                        }

                        try {
                            accountReceivable.setTotalPayments(new BigDecimal(formatAmount(account.getTotalPayments())));
                        } catch (NumberFormatException nfe) {
                            logger.warn("Could not parse total payments [" + account.getTotalPayments() + "]");
                        }

                        try {
                            accountReceivable.setPeriodNetDue(new BigDecimal(formatAmount(account.getPeriodNetDue())));
                        } catch (NumberFormatException nfe) {
                            logger.warn("Could not parse period net due [" + account.getPeriodNetDue() + "]");
                        }

                        try {
                            accountReceivable.setPreviousBalance(new BigDecimal(formatAmount(account.getPreviousBalance())));
                        } catch (NumberFormatException nfe) {
                            logger.warn("Could not parse previous balance [" + account.getPreviousBalance() + "]");
                        }

                        try {
                            accountReceivable.setCurrentBalanace(new BigDecimal(formatAmount(account.getCurrentBalance())));
                        } catch (NumberFormatException nfe) {
                            logger.warn("Could not parse current balance [" + account.getCurrentBalance() + "]");
                        }

                        accountReceivableList.add(accountReceivable);
                    }
                }
            }
            results.setAccountsReceivable(accountReceivableList);
            if (accountReceivableList.size() > 0) {
                results.setHasCoveragePeriods(Boolean.TRUE);
            }

            return results;
        }

        /**
         * formats the provided amount - trims leading/trailing spaces and removes commas
         * @param amount
         * @return
         */
        private String formatAmount(String amount) {
            return StringUtils.trimToEmpty(StringUtils.remove(amount, COMMA));
        }

    }
}