/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2013 BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ALL RIGHTS RESERVED.
 * 
 */
package com.bcbssc.desktop.dao.services.billing;

import com.bcbssc.desktop.dao.billing.AccountsReceivableSummaryDAO;
import com.bcbssc.desktop.util.data.DataParsingUtils;
import com.bcbssc.domain.entity.billing.AccountsReceivableSummary;
import com.bcbssc.services.policyadminarsummary.PolicyAdminARSummaryInput;
import com.bcbssc.services.policyadminarsummary.PolicyAdminARSummaryOutput;
import com.bcbssc.services.policyadminarsummary.PolicyAdminARSummaryService;
import com.bcbssc.wsutils.WebServiceConsumerCallback;
import com.bcbssc.wsutils.WebServiceConsumerTemplate;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.ejb.Stateless;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * DAO for AccountsReceivableSummary data  
 */
@Stateless(name = "ServicesPolicyAdminAccountsReceivableSummaryDAO")
public class ServicesPolicyAdminAccountsReceivableSummaryDAOImpl implements AccountsReceivableSummaryDAO {

    /**
     * Logger for this class.
     */
    private static final Log log = LogFactory.getLog(ServicesPolicyAdminAccountsReceivableSummaryDAOImpl.class);

    /**
     * fetch accounts receivable data
     * @see com.bcbssc.desktop.dao.billing.AccountsReceivableSummaryDAO#getAccountsReceivableSummary(java.lang.String)
     */
    public AccountsReceivableSummary getAccountsReceivableSummary(String masterArNumber) throws Exception {

        if (StringUtils.isBlank(masterArNumber)) {
            throw new IllegalArgumentException("masterARNumber must be provided");
        }

        WebServiceConsumerTemplate consumerTemplate = new WebServiceConsumerTemplate();
        WebServiceConsumerCallback consumerCallback = getWebServiceConsumerCallback();
        return (AccountsReceivableSummary) consumerTemplate.consumeService(masterArNumber, consumerCallback);
    }

    /**
     * utility method for unit testing, override and provide a unit
     * implementation of the service proxy
     * 
     * @return
     */
    protected PolicyAdminARSummaryService getPolicyAdminArSummaryService() {
//        return (PolicyAdminARSummaryService) new ServiceClientGenerator("PolicyAdminARSummary").getServiceClient();
        throw new UnsupportedOperationException("This class needs to be updated to extend the BaseServiceIntegrator");
    }

    /**
     * Returns the <code>WebServiceConsumerCallback</code> for this DAO.
     */
    protected PolicyAdminAccountsReceivableSummaryWebServiceConsumer getWebServiceConsumerCallback() {
        return new PolicyAdminAccountsReceivableSummaryWebServiceConsumer();
    }

    /**
     * Web Service Consumer for the PolicyAdminARSummary service
     */
    protected class PolicyAdminAccountsReceivableSummaryWebServiceConsumer implements WebServiceConsumerCallback {

        /**
         * Gets the <code>PolicyAdminARSummary</code> service handle.
         */
        public Object getService() {
            return getPolicyAdminArSummaryService();
        }

        /**
         * invoke the web service
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#invokeService(java.lang.Object, java.lang.Object)
         */
        public Object invokeService(Object serviceInput, Object serviceClient) throws Exception {
            PolicyAdminARSummaryService service = (PolicyAdminARSummaryService) serviceClient;
            return service.getAccountsReceivableSummary((PolicyAdminARSummaryInput) serviceInput);
        }

        /**
         * map input to the web service
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#mapInput(java.lang.Object)
         */
        public Object mapInput(Object masterARNumber) {

            PolicyAdminARSummaryInput input = new PolicyAdminARSummaryInput();
            input.setMasterArNumber((String) masterARNumber);
            return input;
        }

        /**
         * map output from the web service
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#mapOutput(java.lang.Object)
         */
        public Object mapOutput(Object serviceOutput) {

            PolicyAdminARSummaryOutput output = (PolicyAdminARSummaryOutput) serviceOutput;
            AccountsReceivableSummary result = new AccountsReceivableSummary();
            Date formattedDate = null;
            DateFormat dateFormat = new SimpleDateFormat(DataParsingUtils.FORMAT_DASHES_MONTH_DAY_HALFYEAR);
            
            String dueDate = StringUtils.trimToEmpty(output.getDueDate());
            try {
                if (StringUtils.isNotEmpty(dueDate)){
                    formattedDate = dateFormat.parse(dueDate);
                }
                result.setDueDate(formattedDate);
            } catch (Exception e) {
                log.warn("Exception caught while attempting to translate due date [" + dueDate + "] to a Date.", e);
            }

            String lastPaymentReceivedDate = StringUtils.trimToEmpty(output.getLastPaymentReceivedDate());
            try {
                if (StringUtils.isNotEmpty(lastPaymentReceivedDate)){
                    formattedDate = dateFormat.parse(lastPaymentReceivedDate);
                } else {
                    formattedDate = null;
                }
                result.setLastPaymentReceivedDate(formattedDate);
            } catch (Exception e) {
                log.warn("Exception caught while attempting to translate last payment received date [" + lastPaymentReceivedDate + "] to a Date.", e);
            }

            try {
                result.setCurrentBalanceDue(new BigDecimal(output.getCurrentBalanceDue()));
            } catch (NumberFormatException nfe) {
                log.warn("Could not parse current balance [" + output.getCurrentBalanceDue() + "]");
            }

            try {
                result.setLastPaymentAmount(new BigDecimal(output.getLastPaymentAmount()));
            } catch (NumberFormatException nfe) {
                log.warn("Could not parse last payment amount [" + output.getLastPaymentAmount() + "]");
            }

            result.setGroupNumber(StringUtils.trimToEmpty(output.getCesGroupNumber()));

            return result;
        }

    }
}
