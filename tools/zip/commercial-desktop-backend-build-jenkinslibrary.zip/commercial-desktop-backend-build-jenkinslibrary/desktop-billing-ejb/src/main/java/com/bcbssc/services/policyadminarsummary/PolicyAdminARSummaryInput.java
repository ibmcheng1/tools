
package com.bcbssc.services.policyadminarsummary;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PolicyAdminARSummaryInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PolicyAdminARSummaryInput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="masterArNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="rpn" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="hostID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="hostPassword" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="toEscapeChar" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="MWIConfig" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="applTrace" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PolicyAdminARSummaryInput", propOrder = {
    "masterArNumber",
    "rpn",
    "hostID",
    "hostPassword",
    "toEscapeChar",
    "mwiConfig",
    "applTrace"
})
public class PolicyAdminARSummaryInput {

    @XmlElement(required = true, nillable = true)
    protected String masterArNumber;
    @XmlElement(required = true, nillable = true)
    protected String rpn;
    @XmlElement(required = true, nillable = true)
    protected String hostID;
    @XmlElement(required = true, nillable = true)
    protected String hostPassword;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean toEscapeChar;
    @XmlElement(name = "MWIConfig", required = true, nillable = true)
    protected String mwiConfig;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean applTrace;

    /**
     * Gets the value of the masterArNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMasterArNumber() {
        return masterArNumber;
    }

    /**
     * Sets the value of the masterArNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMasterArNumber(String value) {
        this.masterArNumber = value;
    }

    /**
     * Gets the value of the rpn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRpn() {
        return rpn;
    }

    /**
     * Sets the value of the rpn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRpn(String value) {
        this.rpn = value;
    }

    /**
     * Gets the value of the hostID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHostID() {
        return hostID;
    }

    /**
     * Sets the value of the hostID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHostID(String value) {
        this.hostID = value;
    }

    /**
     * Gets the value of the hostPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHostPassword() {
        return hostPassword;
    }

    /**
     * Sets the value of the hostPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHostPassword(String value) {
        this.hostPassword = value;
    }

    /**
     * Gets the value of the toEscapeChar property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isToEscapeChar() {
        return toEscapeChar;
    }

    /**
     * Sets the value of the toEscapeChar property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setToEscapeChar(Boolean value) {
        this.toEscapeChar = value;
    }

    /**
     * Gets the value of the mwiConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMWIConfig() {
        return mwiConfig;
    }

    /**
     * Sets the value of the mwiConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMWIConfig(String value) {
        this.mwiConfig = value;
    }

    /**
     * Gets the value of the applTrace property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isApplTrace() {
        return applTrace;
    }

    /**
     * Sets the value of the applTrace property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setApplTrace(Boolean value) {
        this.applTrace = value;
    }

}
