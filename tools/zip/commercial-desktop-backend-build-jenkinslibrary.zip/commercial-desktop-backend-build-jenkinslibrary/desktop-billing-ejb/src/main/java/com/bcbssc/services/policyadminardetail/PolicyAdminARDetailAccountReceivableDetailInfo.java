
package com.bcbssc.services.policyadminardetail;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PolicyAdminARDetailAccountReceivableDetailInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PolicyAdminARDetailAccountReceivableDetailInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="arCreationDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="arDueDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="arDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="imageNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="arNumberOfMonths" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="arBilledAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="arPaymentAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="arSplitPaymentIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentCreationDate1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDueDate1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDescription1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentImageNumber1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentAmount1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentCreationDate2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDueDate2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDescription2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentImageNumber2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentAmount2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentCreationDate3" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDueDate3" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDescription3" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentImageNumber3" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentAmount3" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentCreationDate4" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDueDate4" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDescription4" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentImageNumber4" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentAmount4" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentCreationDate5" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDueDate5" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDescription5" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentImageNumber5" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentAmount5" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentCreationDate6" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDueDate6" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDescription6" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentImageNumber6" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentAmount6" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentCreationDate7" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDueDate7" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDescription7" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentImageNumber7" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentAmount7" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentCreationDate8" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDueDate8" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDescription8" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentImageNumber8" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentAmount8" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentCreationDate9" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDueDate9" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDescription9" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentImageNumber9" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentAmount9" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentCreationDate10" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDueDate10" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDescription10" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentImageNumber10" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentAmount10" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentCreationDate11" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDueDate11" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentDescription11" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentImageNumber11" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="splitPaymentAmount11" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PolicyAdminARDetailAccountReceivableDetailInfo", propOrder = {
    "arCreationDate",
    "arDueDate",
    "arDescription",
    "imageNumber",
    "arNumberOfMonths",
    "arBilledAmount",
    "arPaymentAmount",
    "arSplitPaymentIndicator",
    "splitPaymentCreationDate1",
    "splitPaymentDueDate1",
    "splitPaymentDescription1",
    "splitPaymentImageNumber1",
    "splitPaymentAmount1",
    "splitPaymentCreationDate2",
    "splitPaymentDueDate2",
    "splitPaymentDescription2",
    "splitPaymentImageNumber2",
    "splitPaymentAmount2",
    "splitPaymentCreationDate3",
    "splitPaymentDueDate3",
    "splitPaymentDescription3",
    "splitPaymentImageNumber3",
    "splitPaymentAmount3",
    "splitPaymentCreationDate4",
    "splitPaymentDueDate4",
    "splitPaymentDescription4",
    "splitPaymentImageNumber4",
    "splitPaymentAmount4",
    "splitPaymentCreationDate5",
    "splitPaymentDueDate5",
    "splitPaymentDescription5",
    "splitPaymentImageNumber5",
    "splitPaymentAmount5",
    "splitPaymentCreationDate6",
    "splitPaymentDueDate6",
    "splitPaymentDescription6",
    "splitPaymentImageNumber6",
    "splitPaymentAmount6",
    "splitPaymentCreationDate7",
    "splitPaymentDueDate7",
    "splitPaymentDescription7",
    "splitPaymentImageNumber7",
    "splitPaymentAmount7",
    "splitPaymentCreationDate8",
    "splitPaymentDueDate8",
    "splitPaymentDescription8",
    "splitPaymentImageNumber8",
    "splitPaymentAmount8",
    "splitPaymentCreationDate9",
    "splitPaymentDueDate9",
    "splitPaymentDescription9",
    "splitPaymentImageNumber9",
    "splitPaymentAmount9",
    "splitPaymentCreationDate10",
    "splitPaymentDueDate10",
    "splitPaymentDescription10",
    "splitPaymentImageNumber10",
    "splitPaymentAmount10",
    "splitPaymentCreationDate11",
    "splitPaymentDueDate11",
    "splitPaymentDescription11",
    "splitPaymentImageNumber11",
    "splitPaymentAmount11"
})
public class PolicyAdminARDetailAccountReceivableDetailInfo {

    @XmlElement(required = true, nillable = true)
    protected String arCreationDate;
    @XmlElement(required = true, nillable = true)
    protected String arDueDate;
    @XmlElement(required = true, nillable = true)
    protected String arDescription;
    @XmlElement(required = true, nillable = true)
    protected String imageNumber;
    @XmlElement(required = true, nillable = true)
    protected String arNumberOfMonths;
    @XmlElement(required = true, nillable = true)
    protected String arBilledAmount;
    @XmlElement(required = true, nillable = true)
    protected String arPaymentAmount;
    @XmlElement(required = true, nillable = true)
    protected String arSplitPaymentIndicator;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentCreationDate1;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDueDate1;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDescription1;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentImageNumber1;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentAmount1;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentCreationDate2;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDueDate2;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDescription2;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentImageNumber2;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentAmount2;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentCreationDate3;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDueDate3;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDescription3;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentImageNumber3;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentAmount3;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentCreationDate4;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDueDate4;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDescription4;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentImageNumber4;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentAmount4;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentCreationDate5;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDueDate5;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDescription5;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentImageNumber5;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentAmount5;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentCreationDate6;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDueDate6;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDescription6;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentImageNumber6;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentAmount6;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentCreationDate7;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDueDate7;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDescription7;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentImageNumber7;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentAmount7;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentCreationDate8;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDueDate8;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDescription8;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentImageNumber8;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentAmount8;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentCreationDate9;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDueDate9;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDescription9;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentImageNumber9;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentAmount9;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentCreationDate10;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDueDate10;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDescription10;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentImageNumber10;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentAmount10;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentCreationDate11;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDueDate11;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentDescription11;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentImageNumber11;
    @XmlElement(required = true, nillable = true)
    protected String splitPaymentAmount11;

    /**
     * Gets the value of the arCreationDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArCreationDate() {
        return arCreationDate;
    }

    /**
     * Sets the value of the arCreationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArCreationDate(String value) {
        this.arCreationDate = value;
    }

    /**
     * Gets the value of the arDueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArDueDate() {
        return arDueDate;
    }

    /**
     * Sets the value of the arDueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArDueDate(String value) {
        this.arDueDate = value;
    }

    /**
     * Gets the value of the arDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArDescription() {
        return arDescription;
    }

    /**
     * Sets the value of the arDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArDescription(String value) {
        this.arDescription = value;
    }

    /**
     * Gets the value of the imageNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getImageNumber() {
        return imageNumber;
    }

    /**
     * Sets the value of the imageNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setImageNumber(String value) {
        this.imageNumber = value;
    }

    /**
     * Gets the value of the arNumberOfMonths property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArNumberOfMonths() {
        return arNumberOfMonths;
    }

    /**
     * Sets the value of the arNumberOfMonths property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArNumberOfMonths(String value) {
        this.arNumberOfMonths = value;
    }

    /**
     * Gets the value of the arBilledAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArBilledAmount() {
        return arBilledAmount;
    }

    /**
     * Sets the value of the arBilledAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArBilledAmount(String value) {
        this.arBilledAmount = value;
    }

    /**
     * Gets the value of the arPaymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArPaymentAmount() {
        return arPaymentAmount;
    }

    /**
     * Sets the value of the arPaymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArPaymentAmount(String value) {
        this.arPaymentAmount = value;
    }

    /**
     * Gets the value of the arSplitPaymentIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArSplitPaymentIndicator() {
        return arSplitPaymentIndicator;
    }

    /**
     * Sets the value of the arSplitPaymentIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArSplitPaymentIndicator(String value) {
        this.arSplitPaymentIndicator = value;
    }

    /**
     * Gets the value of the splitPaymentCreationDate1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentCreationDate1() {
        return splitPaymentCreationDate1;
    }

    /**
     * Sets the value of the splitPaymentCreationDate1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentCreationDate1(String value) {
        this.splitPaymentCreationDate1 = value;
    }

    /**
     * Gets the value of the splitPaymentDueDate1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDueDate1() {
        return splitPaymentDueDate1;
    }

    /**
     * Sets the value of the splitPaymentDueDate1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDueDate1(String value) {
        this.splitPaymentDueDate1 = value;
    }

    /**
     * Gets the value of the splitPaymentDescription1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDescription1() {
        return splitPaymentDescription1;
    }

    /**
     * Sets the value of the splitPaymentDescription1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDescription1(String value) {
        this.splitPaymentDescription1 = value;
    }

    /**
     * Gets the value of the splitPaymentImageNumber1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentImageNumber1() {
        return splitPaymentImageNumber1;
    }

    /**
     * Sets the value of the splitPaymentImageNumber1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentImageNumber1(String value) {
        this.splitPaymentImageNumber1 = value;
    }

    /**
     * Gets the value of the splitPaymentAmount1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentAmount1() {
        return splitPaymentAmount1;
    }

    /**
     * Sets the value of the splitPaymentAmount1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentAmount1(String value) {
        this.splitPaymentAmount1 = value;
    }

    /**
     * Gets the value of the splitPaymentCreationDate2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentCreationDate2() {
        return splitPaymentCreationDate2;
    }

    /**
     * Sets the value of the splitPaymentCreationDate2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentCreationDate2(String value) {
        this.splitPaymentCreationDate2 = value;
    }

    /**
     * Gets the value of the splitPaymentDueDate2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDueDate2() {
        return splitPaymentDueDate2;
    }

    /**
     * Sets the value of the splitPaymentDueDate2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDueDate2(String value) {
        this.splitPaymentDueDate2 = value;
    }

    /**
     * Gets the value of the splitPaymentDescription2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDescription2() {
        return splitPaymentDescription2;
    }

    /**
     * Sets the value of the splitPaymentDescription2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDescription2(String value) {
        this.splitPaymentDescription2 = value;
    }

    /**
     * Gets the value of the splitPaymentImageNumber2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentImageNumber2() {
        return splitPaymentImageNumber2;
    }

    /**
     * Sets the value of the splitPaymentImageNumber2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentImageNumber2(String value) {
        this.splitPaymentImageNumber2 = value;
    }

    /**
     * Gets the value of the splitPaymentAmount2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentAmount2() {
        return splitPaymentAmount2;
    }

    /**
     * Sets the value of the splitPaymentAmount2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentAmount2(String value) {
        this.splitPaymentAmount2 = value;
    }

    /**
     * Gets the value of the splitPaymentCreationDate3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentCreationDate3() {
        return splitPaymentCreationDate3;
    }

    /**
     * Sets the value of the splitPaymentCreationDate3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentCreationDate3(String value) {
        this.splitPaymentCreationDate3 = value;
    }

    /**
     * Gets the value of the splitPaymentDueDate3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDueDate3() {
        return splitPaymentDueDate3;
    }

    /**
     * Sets the value of the splitPaymentDueDate3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDueDate3(String value) {
        this.splitPaymentDueDate3 = value;
    }

    /**
     * Gets the value of the splitPaymentDescription3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDescription3() {
        return splitPaymentDescription3;
    }

    /**
     * Sets the value of the splitPaymentDescription3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDescription3(String value) {
        this.splitPaymentDescription3 = value;
    }

    /**
     * Gets the value of the splitPaymentImageNumber3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentImageNumber3() {
        return splitPaymentImageNumber3;
    }

    /**
     * Sets the value of the splitPaymentImageNumber3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentImageNumber3(String value) {
        this.splitPaymentImageNumber3 = value;
    }

    /**
     * Gets the value of the splitPaymentAmount3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentAmount3() {
        return splitPaymentAmount3;
    }

    /**
     * Sets the value of the splitPaymentAmount3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentAmount3(String value) {
        this.splitPaymentAmount3 = value;
    }

    /**
     * Gets the value of the splitPaymentCreationDate4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentCreationDate4() {
        return splitPaymentCreationDate4;
    }

    /**
     * Sets the value of the splitPaymentCreationDate4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentCreationDate4(String value) {
        this.splitPaymentCreationDate4 = value;
    }

    /**
     * Gets the value of the splitPaymentDueDate4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDueDate4() {
        return splitPaymentDueDate4;
    }

    /**
     * Sets the value of the splitPaymentDueDate4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDueDate4(String value) {
        this.splitPaymentDueDate4 = value;
    }

    /**
     * Gets the value of the splitPaymentDescription4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDescription4() {
        return splitPaymentDescription4;
    }

    /**
     * Sets the value of the splitPaymentDescription4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDescription4(String value) {
        this.splitPaymentDescription4 = value;
    }

    /**
     * Gets the value of the splitPaymentImageNumber4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentImageNumber4() {
        return splitPaymentImageNumber4;
    }

    /**
     * Sets the value of the splitPaymentImageNumber4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentImageNumber4(String value) {
        this.splitPaymentImageNumber4 = value;
    }

    /**
     * Gets the value of the splitPaymentAmount4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentAmount4() {
        return splitPaymentAmount4;
    }

    /**
     * Sets the value of the splitPaymentAmount4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentAmount4(String value) {
        this.splitPaymentAmount4 = value;
    }

    /**
     * Gets the value of the splitPaymentCreationDate5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentCreationDate5() {
        return splitPaymentCreationDate5;
    }

    /**
     * Sets the value of the splitPaymentCreationDate5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentCreationDate5(String value) {
        this.splitPaymentCreationDate5 = value;
    }

    /**
     * Gets the value of the splitPaymentDueDate5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDueDate5() {
        return splitPaymentDueDate5;
    }

    /**
     * Sets the value of the splitPaymentDueDate5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDueDate5(String value) {
        this.splitPaymentDueDate5 = value;
    }

    /**
     * Gets the value of the splitPaymentDescription5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDescription5() {
        return splitPaymentDescription5;
    }

    /**
     * Sets the value of the splitPaymentDescription5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDescription5(String value) {
        this.splitPaymentDescription5 = value;
    }

    /**
     * Gets the value of the splitPaymentImageNumber5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentImageNumber5() {
        return splitPaymentImageNumber5;
    }

    /**
     * Sets the value of the splitPaymentImageNumber5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentImageNumber5(String value) {
        this.splitPaymentImageNumber5 = value;
    }

    /**
     * Gets the value of the splitPaymentAmount5 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentAmount5() {
        return splitPaymentAmount5;
    }

    /**
     * Sets the value of the splitPaymentAmount5 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentAmount5(String value) {
        this.splitPaymentAmount5 = value;
    }

    /**
     * Gets the value of the splitPaymentCreationDate6 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentCreationDate6() {
        return splitPaymentCreationDate6;
    }

    /**
     * Sets the value of the splitPaymentCreationDate6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentCreationDate6(String value) {
        this.splitPaymentCreationDate6 = value;
    }

    /**
     * Gets the value of the splitPaymentDueDate6 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDueDate6() {
        return splitPaymentDueDate6;
    }

    /**
     * Sets the value of the splitPaymentDueDate6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDueDate6(String value) {
        this.splitPaymentDueDate6 = value;
    }

    /**
     * Gets the value of the splitPaymentDescription6 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDescription6() {
        return splitPaymentDescription6;
    }

    /**
     * Sets the value of the splitPaymentDescription6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDescription6(String value) {
        this.splitPaymentDescription6 = value;
    }

    /**
     * Gets the value of the splitPaymentImageNumber6 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentImageNumber6() {
        return splitPaymentImageNumber6;
    }

    /**
     * Sets the value of the splitPaymentImageNumber6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentImageNumber6(String value) {
        this.splitPaymentImageNumber6 = value;
    }

    /**
     * Gets the value of the splitPaymentAmount6 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentAmount6() {
        return splitPaymentAmount6;
    }

    /**
     * Sets the value of the splitPaymentAmount6 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentAmount6(String value) {
        this.splitPaymentAmount6 = value;
    }

    /**
     * Gets the value of the splitPaymentCreationDate7 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentCreationDate7() {
        return splitPaymentCreationDate7;
    }

    /**
     * Sets the value of the splitPaymentCreationDate7 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentCreationDate7(String value) {
        this.splitPaymentCreationDate7 = value;
    }

    /**
     * Gets the value of the splitPaymentDueDate7 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDueDate7() {
        return splitPaymentDueDate7;
    }

    /**
     * Sets the value of the splitPaymentDueDate7 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDueDate7(String value) {
        this.splitPaymentDueDate7 = value;
    }

    /**
     * Gets the value of the splitPaymentDescription7 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDescription7() {
        return splitPaymentDescription7;
    }

    /**
     * Sets the value of the splitPaymentDescription7 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDescription7(String value) {
        this.splitPaymentDescription7 = value;
    }

    /**
     * Gets the value of the splitPaymentImageNumber7 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentImageNumber7() {
        return splitPaymentImageNumber7;
    }

    /**
     * Sets the value of the splitPaymentImageNumber7 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentImageNumber7(String value) {
        this.splitPaymentImageNumber7 = value;
    }

    /**
     * Gets the value of the splitPaymentAmount7 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentAmount7() {
        return splitPaymentAmount7;
    }

    /**
     * Sets the value of the splitPaymentAmount7 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentAmount7(String value) {
        this.splitPaymentAmount7 = value;
    }

    /**
     * Gets the value of the splitPaymentCreationDate8 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentCreationDate8() {
        return splitPaymentCreationDate8;
    }

    /**
     * Sets the value of the splitPaymentCreationDate8 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentCreationDate8(String value) {
        this.splitPaymentCreationDate8 = value;
    }

    /**
     * Gets the value of the splitPaymentDueDate8 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDueDate8() {
        return splitPaymentDueDate8;
    }

    /**
     * Sets the value of the splitPaymentDueDate8 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDueDate8(String value) {
        this.splitPaymentDueDate8 = value;
    }

    /**
     * Gets the value of the splitPaymentDescription8 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDescription8() {
        return splitPaymentDescription8;
    }

    /**
     * Sets the value of the splitPaymentDescription8 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDescription8(String value) {
        this.splitPaymentDescription8 = value;
    }

    /**
     * Gets the value of the splitPaymentImageNumber8 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentImageNumber8() {
        return splitPaymentImageNumber8;
    }

    /**
     * Sets the value of the splitPaymentImageNumber8 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentImageNumber8(String value) {
        this.splitPaymentImageNumber8 = value;
    }

    /**
     * Gets the value of the splitPaymentAmount8 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentAmount8() {
        return splitPaymentAmount8;
    }

    /**
     * Sets the value of the splitPaymentAmount8 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentAmount8(String value) {
        this.splitPaymentAmount8 = value;
    }

    /**
     * Gets the value of the splitPaymentCreationDate9 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentCreationDate9() {
        return splitPaymentCreationDate9;
    }

    /**
     * Sets the value of the splitPaymentCreationDate9 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentCreationDate9(String value) {
        this.splitPaymentCreationDate9 = value;
    }

    /**
     * Gets the value of the splitPaymentDueDate9 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDueDate9() {
        return splitPaymentDueDate9;
    }

    /**
     * Sets the value of the splitPaymentDueDate9 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDueDate9(String value) {
        this.splitPaymentDueDate9 = value;
    }

    /**
     * Gets the value of the splitPaymentDescription9 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDescription9() {
        return splitPaymentDescription9;
    }

    /**
     * Sets the value of the splitPaymentDescription9 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDescription9(String value) {
        this.splitPaymentDescription9 = value;
    }

    /**
     * Gets the value of the splitPaymentImageNumber9 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentImageNumber9() {
        return splitPaymentImageNumber9;
    }

    /**
     * Sets the value of the splitPaymentImageNumber9 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentImageNumber9(String value) {
        this.splitPaymentImageNumber9 = value;
    }

    /**
     * Gets the value of the splitPaymentAmount9 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentAmount9() {
        return splitPaymentAmount9;
    }

    /**
     * Sets the value of the splitPaymentAmount9 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentAmount9(String value) {
        this.splitPaymentAmount9 = value;
    }

    /**
     * Gets the value of the splitPaymentCreationDate10 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentCreationDate10() {
        return splitPaymentCreationDate10;
    }

    /**
     * Sets the value of the splitPaymentCreationDate10 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentCreationDate10(String value) {
        this.splitPaymentCreationDate10 = value;
    }

    /**
     * Gets the value of the splitPaymentDueDate10 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDueDate10() {
        return splitPaymentDueDate10;
    }

    /**
     * Sets the value of the splitPaymentDueDate10 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDueDate10(String value) {
        this.splitPaymentDueDate10 = value;
    }

    /**
     * Gets the value of the splitPaymentDescription10 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDescription10() {
        return splitPaymentDescription10;
    }

    /**
     * Sets the value of the splitPaymentDescription10 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDescription10(String value) {
        this.splitPaymentDescription10 = value;
    }

    /**
     * Gets the value of the splitPaymentImageNumber10 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentImageNumber10() {
        return splitPaymentImageNumber10;
    }

    /**
     * Sets the value of the splitPaymentImageNumber10 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentImageNumber10(String value) {
        this.splitPaymentImageNumber10 = value;
    }

    /**
     * Gets the value of the splitPaymentAmount10 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentAmount10() {
        return splitPaymentAmount10;
    }

    /**
     * Sets the value of the splitPaymentAmount10 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentAmount10(String value) {
        this.splitPaymentAmount10 = value;
    }

    /**
     * Gets the value of the splitPaymentCreationDate11 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentCreationDate11() {
        return splitPaymentCreationDate11;
    }

    /**
     * Sets the value of the splitPaymentCreationDate11 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentCreationDate11(String value) {
        this.splitPaymentCreationDate11 = value;
    }

    /**
     * Gets the value of the splitPaymentDueDate11 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDueDate11() {
        return splitPaymentDueDate11;
    }

    /**
     * Sets the value of the splitPaymentDueDate11 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDueDate11(String value) {
        this.splitPaymentDueDate11 = value;
    }

    /**
     * Gets the value of the splitPaymentDescription11 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentDescription11() {
        return splitPaymentDescription11;
    }

    /**
     * Sets the value of the splitPaymentDescription11 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentDescription11(String value) {
        this.splitPaymentDescription11 = value;
    }

    /**
     * Gets the value of the splitPaymentImageNumber11 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentImageNumber11() {
        return splitPaymentImageNumber11;
    }

    /**
     * Sets the value of the splitPaymentImageNumber11 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentImageNumber11(String value) {
        this.splitPaymentImageNumber11 = value;
    }

    /**
     * Gets the value of the splitPaymentAmount11 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitPaymentAmount11() {
        return splitPaymentAmount11;
    }

    /**
     * Sets the value of the splitPaymentAmount11 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitPaymentAmount11(String value) {
        this.splitPaymentAmount11 = value;
    }

}
