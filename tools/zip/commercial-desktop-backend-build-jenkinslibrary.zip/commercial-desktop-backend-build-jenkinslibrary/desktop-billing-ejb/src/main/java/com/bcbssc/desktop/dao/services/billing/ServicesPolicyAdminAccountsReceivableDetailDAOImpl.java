/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2013 BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.dao.services.billing;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.dao.billing.AccountsReceivableDetailDAO;
import com.bcbssc.desktop.util.data.DataParsingUtils;
import com.bcbssc.domain.entity.billing.AccountReceivable;
import com.bcbssc.domain.entity.billing.AccountReceivableDetail;
import com.bcbssc.domain.entity.billing.SplitPayment;
import com.bcbssc.domain.valueobject.Period;
import com.bcbssc.services.policyadminardetail.PolicyAdminARDetailAccountReceivableDetailInfo;
import com.bcbssc.services.policyadminardetail.PolicyAdminARDetailInput;
import com.bcbssc.services.policyadminardetail.PolicyAdminARDetailOutput;
import com.bcbssc.services.policyadminardetail.PolicyAdminARDetailService;
import com.bcbssc.wsutils.WebServiceConsumerCallback;
import com.bcbssc.wsutils.WebServiceConsumerTemplate;

/**
 * DAO for Accounts Receivable Detail data fetching methods 
 */
@Stateless(name = "ServicesPolicyAdminAccountsReceivableDetailDAO")
public class ServicesPolicyAdminAccountsReceivableDetailDAOImpl implements AccountsReceivableDetailDAO {

    /** logger  */
    private static final Log logger = LogFactory.getLog(ServicesPolicyAdminAccountsReceivableDetailDAOImpl.class);
    private static final char COMMA = ',';
    private static final int SPLIT_PAYMENT_RECORDS = 11;

    /** 
     * fetch Accounts receivable details 
     */
    @Override
    public AccountReceivable fetchAccountsReceivableDetail(String masterARNumber, Period coveragePeriod) throws Exception {

        if (StringUtils.isBlank(masterARNumber)) {
            throw new IllegalArgumentException("masterARNumber must be provided");
        }
        if (coveragePeriod == null) {
            throw new IllegalArgumentException("coveragePeriod must be provided");
        }

        PolicyAdminAccountsReceivableDetailWebServiceConsumer consumer = getWebServiceConsumerCallback();
        DateFormat dateFormat = new SimpleDateFormat(DataParsingUtils.FORMAT_HALF_USA);
        if (coveragePeriod.getStartDate() != null) {
            consumer.coveragePeriodBeginDate = dateFormat.format(coveragePeriod.getStartDate());
        }
        if (coveragePeriod.getEndDate() != null) {
            consumer.coveragePeriodEndDate = dateFormat.format(coveragePeriod.getEndDate());
        }
        consumer.masterARNumber = masterARNumber;

        return (AccountReceivable) new WebServiceConsumerTemplate().consumeService(null, consumer);
    }

    /**
     * utility method for unit testing, override and provide a unit
     * implementation of the service proxy
     * 
     * @return
     */
    protected PolicyAdminARDetailService getPolicyAdminArDetailService() {
//        return (PolicyAdminARDetailService) new ServiceClientGenerator("PolicyAdminARDetail").getServiceClient();
        throw new UnsupportedOperationException("This class needs to be updated to extend BaseServiceIntegrator");
    }

    /**
     * Returns the <code>WebServiceConsumerCallback</code> for this DAO.
     */
    protected PolicyAdminAccountsReceivableDetailWebServiceConsumer getWebServiceConsumerCallback() {
        return new PolicyAdminAccountsReceivableDetailWebServiceConsumer();
    }

    /**
     * Web Service Consumer for the PolicyAdminARDetail web service
     */
    protected class PolicyAdminAccountsReceivableDetailWebServiceConsumer implements WebServiceConsumerCallback {

        private String coveragePeriodBeginDate;
        private String coveragePeriodEndDate;
        private String masterARNumber;

        /**
         * Gets the <code>PolicyAdminARDetail</code> service handle.
         */
        @Override
        public Object getService() {
            return getPolicyAdminArDetailService();
        }

        /**
         * invokes the web service
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#invokeService(java.lang.Object, java.lang.Object)
         */
        public Object invokeService(Object serviceInput, Object serviceClient) throws Exception {

            PolicyAdminARDetailService service = (PolicyAdminARDetailService) serviceClient;
            return service.getAccountsReceivableDetail((PolicyAdminARDetailInput) serviceInput);
        }

        /**
         * map the input for the web service 
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#mapInput(java.lang.Object)
         */
        public Object mapInput(Object obj) {
            PolicyAdminARDetailInput input = new PolicyAdminARDetailInput();
            input.setCoverageBeginDate(this.coveragePeriodBeginDate);
            input.setCoverageEndDate(this.coveragePeriodEndDate);
            input.setMasterArNumber(this.masterARNumber);
            return input;
        }

        /**
         * map the output from the web service
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#mapOutput(java.lang.Object)
         */
        public Object mapOutput(Object serviceResponse) {
            PolicyAdminARDetailOutput output = (PolicyAdminARDetailOutput) serviceResponse;
            AccountReceivable results = new AccountReceivable();
            List<AccountReceivableDetail> detailList = new ArrayList<AccountReceivableDetail>();
            List<SplitPayment> splitPayments = new ArrayList<SplitPayment>();

            //amount totals
            BigDecimal billedAmountTotal = new BigDecimal(0.0f);
            BigDecimal paymentAmountTotal = new BigDecimal(0.0f);
            BigDecimal splitPaymentAmountTotal = new BigDecimal(0.0f);

            List<PolicyAdminARDetailAccountReceivableDetailInfo> detailResults = output.getAccountReceivableDetailInfo().getPolicyAdminARDetailAccountReceivableDetailInfo();
            //each detail record contains detail results and a 'set' of split payment records
            for (PolicyAdminARDetailAccountReceivableDetailInfo detail : detailResults) {

                //if creation date is present, we have a valid record
                if (StringUtils.isNotBlank(detail.getArCreationDate())) {

                    //fetch detail information
                    AccountReceivableDetail accountReceivableDetail = new AccountReceivableDetail();
                    try {
                        accountReceivableDetail.setAccountCreationDate(DataParsingUtils.dateFromHalfUsa(StringUtils.trimToEmpty(detail.getArCreationDate())));
                    } catch (IllegalArgumentException iae) {
                        logger.warn("Unable to parse account creation date = [" + detail.getArCreationDate() + "]");
                    }
                    if (StringUtils.isNotBlank(detail.getArDueDate())) {
                        try {
                            accountReceivableDetail.setAccountDueDate(DataParsingUtils.dateFromHalfUsa(StringUtils.trimToEmpty(detail.getArDueDate())));
                        } catch (IllegalArgumentException iae) {
                            logger.warn("Unable to parse account due date = [" + detail.getArDueDate() + "]");
                        }
                    }
                    accountReceivableDetail.setAccountDescription(StringUtils.trimToEmpty(detail.getArDescription()));

                    try {
                        accountReceivableDetail.setBilledAmount(new BigDecimal(formatAmount(detail.getArBilledAmount())));
                        billedAmountTotal = billedAmountTotal.add(accountReceivableDetail.getBilledAmount());
                    } catch (NumberFormatException nfe) {
                        logger.warn("Could not parse billed amount [" + detail.getArBilledAmount() + "]");
                    }

                    try {
                        accountReceivableDetail.setPaymentAmount(new BigDecimal(formatAmount(detail.getArPaymentAmount())));
                        paymentAmountTotal = paymentAmountTotal.add(accountReceivableDetail.getPaymentAmount());
                    } catch (NumberFormatException nfe) {
                        logger.warn("Could not parse payment amount [" + detail.getArPaymentAmount() + "]");
                    }

                    accountReceivableDetail.setImageNumber(StringUtils.trimToEmpty(detail.getImageNumber()));
                    accountReceivableDetail.setNumberOfMonths(StringUtils.trimToEmpty(detail.getArNumberOfMonths()));
                    detailList.add(accountReceivableDetail);

                    if (StringUtils.isNotBlank(detail.getArSplitPaymentIndicator())) {
                        List<SplitPayment> detailSplitPayments = new ArrayList<SplitPayment>();
                        // split payment information - 11 sets per detail record
                        for (int j = 1; j <= SPLIT_PAYMENT_RECORDS; j++) {

                            //create a new split payment object and populate
                            SplitPayment splitPayment = new SplitPayment();
                            //fetch each field from the service output and populate in the split payment object
                            try {
                                String splitPaymentAmount = StringUtils.trimToEmpty(BeanUtils.getSimpleProperty(detail, "splitPaymentAmount" + j));
                                if (StringUtils.isNotBlank(splitPaymentAmount)) {
                                    splitPayment.setAmountApplied(new BigDecimal(splitPaymentAmount));
                                }
                                String splitPaymentImageNumber = StringUtils.trimToEmpty(BeanUtils.getSimpleProperty(detail, "splitPaymentImageNumber" + j));
                                splitPayment.setImageNumber(splitPaymentImageNumber);
                                String splitPaymentDescription = StringUtils.trimToEmpty(BeanUtils.getSimpleProperty(detail, "splitPaymentDescription" + j));
                                splitPayment.setDescription(splitPaymentDescription);

                                String splitPaymentDueDate = StringUtils.trimToEmpty(BeanUtils.getSimpleProperty(detail, "splitPaymentDueDate" + j));
                                if (StringUtils.isNotBlank(splitPaymentDueDate)) {
                                    Date dueDate = DataParsingUtils.dateFromHalfUsa(StringUtils.trimToEmpty(splitPaymentDueDate));
                                    splitPayment.setDueDate(dueDate);
                                }

                                String splitPaymentCreationDate = StringUtils.trimToEmpty(BeanUtils.getSimpleProperty(detail, "splitPaymentCreationDate" + j));
                                if (StringUtils.isNotBlank(splitPaymentCreationDate)) {
                                    Date creationDate = DataParsingUtils.dateFromHalfUsa(StringUtils.trimToEmpty(splitPaymentCreationDate));
                                    splitPayment.setCreationDate(creationDate);
                                }

                            } catch (Exception e) {
                                logger.error("There was an exception attempting to fetch properties from the web service client output", e);
                            }

                            //if a creation date was fetched/populated, we have a valid record
                            if (splitPayment.getCreationDate() != null) {
                                detailSplitPayments.add(splitPayment);
                                accountReceivableDetail.setSplitPaymentIndicator(Boolean.TRUE);
                            }
                        }

                        //if the detail split payments don't already exist (from a previous detail record), store them
                        for (SplitPayment detailSplitPayment : detailSplitPayments) {
                            if (!splitPayments.contains(detailSplitPayment)) {
                                splitPayments.add(detailSplitPayment);
                                
                            }
                        }

                    }
                }
            }
            //total up the payment amounts
            for (SplitPayment splitPayment : splitPayments) {
                if (splitPayment.getAmountApplied() != null) {
                    splitPaymentAmountTotal = splitPaymentAmountTotal.add(splitPayment.getAmountApplied());
                }
            }
            results.setDetailList(detailList);
            results.setSplitPayments(splitPayments);
            results.setPaymentAmountTotal(paymentAmountTotal);
            results.setBilledAmountTotal(billedAmountTotal);
            results.setSplitPaymentAmountTotal(splitPaymentAmountTotal);
            return results;
        }
    }

    /**
     * formats the provided amount - trims leading/trailing spaces and removes commas
     * @param amount
     * @return
     */
    private String formatAmount(String amount) {
        return StringUtils.trimToEmpty(StringUtils.remove(amount, COMMA));
    }

}
