
package com.bcbssc.services.policyadminarsummary;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="getAccountsReceivableSummaryReturn" type="{http://PolicyAdminARSummary.FSSMT103EJB.commercial.bcbssc.com}PolicyAdminARSummaryOutput"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getAccountsReceivableSummaryReturn"
})
@XmlRootElement(name = "getAccountsReceivableSummaryResponse")
public class GetAccountsReceivableSummaryResponse {

    @XmlElement(required = true, nillable = true)
    protected PolicyAdminARSummaryOutput getAccountsReceivableSummaryReturn;

    /**
     * Gets the value of the getAccountsReceivableSummaryReturn property.
     * 
     * @return
     *     possible object is
     *     {@link PolicyAdminARSummaryOutput }
     *     
     */
    public PolicyAdminARSummaryOutput getGetAccountsReceivableSummaryReturn() {
        return getAccountsReceivableSummaryReturn;
    }

    /**
     * Sets the value of the getAccountsReceivableSummaryReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link PolicyAdminARSummaryOutput }
     *     
     */
    public void setGetAccountsReceivableSummaryReturn(PolicyAdminARSummaryOutput value) {
        this.getAccountsReceivableSummaryReturn = value;
    }

}
