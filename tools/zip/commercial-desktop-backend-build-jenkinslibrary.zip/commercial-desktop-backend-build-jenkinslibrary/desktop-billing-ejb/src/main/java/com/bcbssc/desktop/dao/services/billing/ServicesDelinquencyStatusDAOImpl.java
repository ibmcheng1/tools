/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2013 BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.dao.services.billing;

import com.bcbssc.desktop.dao.billing.DelinquencyStatusDAO;
import com.bcbssc.desktop.model.DelinquencyStatusCriteria;
import com.bcbssc.desktop.util.services.BaseServiceIntegrator;
import com.bcbssc.domain.entity.billing.DelinquencyStatusDetails;
import com.bcbssc.domain.entity.codes.Code;
import com.bcbssc.services.premiumdelinqstatusdetail.PremiumDelinqStatusDetailInput;
import com.bcbssc.services.premiumdelinqstatusdetail.PremiumDelinqStatusDetailOutput;
import com.bcbssc.services.premiumdelinqstatusdetail.PremiumDelinqStatusDetailService;
import com.bcbssc.services.premiumdelinqstatusdetail.PremiumDelinqStatusDetailServiceService;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.ejb.Stateless;
import javax.jws.HandlerChain;
import javax.xml.ws.WebServiceRef;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * Delinquency Status DAO - fetches data pertaining to delinquent billing accounts
 */
@Stateless(name = "DelinquencyStatusDAO")
public class ServicesDelinquencyStatusDAOImpl extends BaseServiceIntegrator<PremiumDelinqStatusDetailService, DelinquencyStatusCriteria, PremiumDelinqStatusDetailInput, PremiumDelinqStatusDetailOutput, DelinquencyStatusDetails> implements DelinquencyStatusDAO {

    private static final Log logger = LogFactory.getLog(ServicesDelinquencyStatusDAOImpl.class);

    @HandlerChain(file = "../handlerchain/soax-service-handler-chain.xml")
    @WebServiceRef(wsdlLocation = "META-INF/wsdl/PremiumDelinqStatusDetail.wsdl", value = PremiumDelinqStatusDetailServiceService.class)
    private PremiumDelinqStatusDetailService service;

    /**
     * fetch delinquency status details
     * @see com.bcbssc.desktop.dao.billing.DelinquencyStatusDAO#getDelinquencyStatusDetail(java.lang.String, com.bcbssc.domain.entity.codes.Code, java.lang.String) 
     */
    public DelinquencyStatusDetails getDelinquencyStatusDetail(String clientNumber, Code businessTypeCode, String masterAccountsReceivableNumber) {
        DelinquencyStatusCriteria criteria = new DelinquencyStatusCriteria();
        criteria.setClientNumber(clientNumber);
        criteria.setBusinessTypeCode(businessTypeCode.getCode());
        criteria.setMasterAccountsReceivableNumber(masterAccountsReceivableNumber);

        return this.consumeService(criteria);
    }

    @Override
    public void setService(PremiumDelinqStatusDetailService service) {
        this.service = service;
    }

    @Override
    protected String getServiceName() {
        return PremiumDelinqStatusDetailService.class.getSimpleName();
    }

    @Override
    public PremiumDelinqStatusDetailService getService() {
        return service;
    }

    @Override
    public PremiumDelinqStatusDetailInput mapInput(DelinquencyStatusCriteria criteria) {
        PremiumDelinqStatusDetailInput input = new PremiumDelinqStatusDetailInput();
        input.setClientNumber(criteria.getClientNumber());
        input.setBusinessType(criteria.getBusinessTypeCode());
        input.setMasterArNumber(criteria.getMasterAccountsReceivableNumber());
        return input;
    }

    @Override
    public PremiumDelinqStatusDetailOutput invokeService(PremiumDelinqStatusDetailInput input, PremiumDelinqStatusDetailService service) throws Exception {
        return service.getDelinquencyStatusDetail(input);
    }

    @Override
    public DelinquencyStatusDetails mapOutput(PremiumDelinqStatusDetailOutput output) {
        DelinquencyStatusDetails details = new DelinquencyStatusDetails();

        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        try {
            if (StringUtils.isNotBlank(output.getCancelHoldStageDelinqArDate())) {
                details.setCancelHoldStageDelinquencyAccountsReceivableDate(df.parse(StringUtils.trimToEmpty(output.getCancelHoldStageDelinqArDate())));
            }
        } catch (ParseException e) {
            logger.error("There was an exception attempting to set cancelHoldStageDelinquencyAccountsReceivableDate", e);
        }
        try {
            if (StringUtils.isNotBlank(output.getCancelHoldStageDueDate())) {
                details.setCancelHoldStageDueDate(df.parse(StringUtils.trimToEmpty(output.getCancelHoldStageDueDate())));
            }
        } catch (ParseException e) {
            logger.error("There was an exception attempting to set cancelHoldStageDueDate", e);
        }
        try {
            if (StringUtils.isNotBlank(output.getCurrentAccountReceivableDate())) {
                details.setCurrentAccountsReceivableDate(df.parse(StringUtils.trimToEmpty(output.getCurrentAccountReceivableDate())));
            }
        } catch (ParseException e) {
            logger.error("There was an exception attempting to set currentAccountsReceivableDate", e);
        }
        try {
            if (StringUtils.isNotBlank(output.getCurrentDelinquencyArDate())) {
                details.setCurrentDelinquentAccountsReceivableDate(df.parse(StringUtils.trimToEmpty(output.getCurrentDelinquencyArDate())));
            }
        } catch (ParseException e) {
            logger.error("There was an exception attempting to set currentDelinquentAccountsReceivableDate", e);
        }
        try {
            if (StringUtils.isNotBlank(output.getDueDate())) {
                details.setDueDate(df.parse(StringUtils.trimToEmpty(output.getDueDate())));
            }
        } catch (ParseException e) {
            logger.error("There was an exception attempting to set dueDate", e);
        }
        try {
            if (StringUtils.isNotBlank(output.getInitialEvaluationDate())) {
                details.setInitialEvaluationDate(df.parse(StringUtils.trimToEmpty(output.getInitialEvaluationDate())));
            }
        } catch (ParseException e) {
            logger.error("There was an exception attempting to set initialEvaluationDate", e);
        }
        try {
            if (StringUtils.isNotBlank(output.getLastPaymentDate())) {
                details.setLastPaymentDate(df.parse(StringUtils.trimToEmpty(output.getLastPaymentDate())));
            }
        } catch (ParseException e1) {
            logger.error("There was an exception attempting to set lastPaymentDate", e1);
        }
        try {
            if (StringUtils.isNotBlank(output.getProjectedCancelEffectiveDate())) {
                details.setProjectedCancelEffectiveDate(df.parse(StringUtils.trimToEmpty(output.getProjectedCancelEffectiveDate())));
            }
        } catch (ParseException e1) {
            logger.error("There was an exception attempting to set projectedCancelEffectiveDate", e1);
        }
        try {
            if (StringUtils.isNotBlank(output.getProjectedCancelProcessDate())) {
                details.setProjectedCancelProcessDate(df.parse(StringUtils.trimToEmpty(output.getProjectedCancelProcessDate())));
            }
        } catch (ParseException e) {
            logger.error("There was an exception attempting to set projectedCancelProcessDate", e);
        }
        try {
            if (StringUtils.isNotBlank(output.getStageBeginDate())) {
                details.setStageBeginDate(df.parse(StringUtils.trimToEmpty(output.getStageBeginDate())));
            }
        } catch (ParseException e) {
            logger.error("There was an exception attempting to set projectedCancelProcessDate", e);
        }
        if (StringUtils.isNotBlank(output.getCancelHoldStageArAmount())) {
            try {
                details.setCancelHoldStageAccountsReceivableAmount(new BigDecimal(StringUtils.trimToEmpty(output.getCancelHoldStageArAmount())));
            } catch (NumberFormatException e) {
                logger.error("There was an exception attempting to set cancelHoldStageAccountsReceivableAmount", e);
            }
        }
        if (StringUtils.isNotBlank(output.getCancelHoldStageDelinqArAmount())) {
            try {
                details.setCancelHoldStageDelinquencyAccountsReceivableAmount(new BigDecimal(StringUtils.trimToEmpty(output
                        .getCancelHoldStageDelinqArAmount())));
            } catch (NumberFormatException e) {
                logger.error("There was an exception attempting to set cancelHoldStageDelinquencyAccountsReceivableAmount", e);
            }
        }
        if (StringUtils.isNotBlank(output.getCurrentAccountReceivableAmt())) {
            try {
                details.setCurrentAccountsReceivableAmount(new BigDecimal(StringUtils.trimToEmpty(output.getCurrentAccountReceivableAmt())));
            } catch (NumberFormatException e) {
                logger.error("There was an exception attempting to set currentAccountsReceivableAmount", e);
            }
        }
        if (StringUtils.isNotBlank(output.getCurrentDelinquentArAmount())) {
            try {
                details.setCurrentDelinquentAccountsReceivableAmount(new BigDecimal(StringUtils.trimToEmpty(output.getCurrentDelinquentArAmount())));
            } catch (NumberFormatException e) {
                logger.error("There was an exception attempting to set currentDelinquentAccountsReceivableAmount", e);
            }
        }
        if (StringUtils.isNotBlank(output.getLastPaymentAmount())) {
            try {
                details.setLastPaymentAmount(new BigDecimal(StringUtils.trimToEmpty(output.getLastPaymentAmount())));
            } catch (NumberFormatException e) {
                logger.error("There was an exception attempting to set lastPaymentAmount", e);
            }
        }
        details.setCancelOnHoldIndicator(StringUtils.trimToEmpty(output.getCancelOnHoldIndicator()));
        details.getCancelReasonCode().setCode(StringUtils.trimToEmpty(output.getCancelReasonCode()));
        details.getCancelReasonCode().setDescription(StringUtils.trimToEmpty(output.getCancelReasonDescription()));
        details.setClientDelinquencySetId(StringUtils.trimToEmpty(output.getClientDelinquencySetId()));
        details.setClientName(StringUtils.trimToEmpty(output.getClientName()));
        details.setCustomerName(StringUtils.trimToEmpty(output.getCustomerName()));
        details.setDelinquencyStage(StringUtils.trimToEmpty(output.getDelinquencyStage()));
        details.getLetterDistributionCode().setCode(StringUtils.trimToEmpty(output.getLetterDistributionCode()));
        details.getLetterDistributionCode().setDescription(StringUtils.trimToEmpty(output.getLetterDistributionCodeDesc()));
        details.setMasterAccountsReceivableName(StringUtils.trimToEmpty(output.getMasterArName()));
        details.setParameterMasterId(StringUtils.trimToEmpty(output.getParameterMasterId()));

        return details;
    }
}
