
package com.bcbssc.services.policyadminarsummary;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PolicyAdminARSummaryOutput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PolicyAdminARSummaryOutput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="applicationMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="systemMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="serviceMessageCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="serviceMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="rpnDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="masterArName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="subscriberId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="hicNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="clientNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cesGroupNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="clientSubNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cesGroupSubNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lastBilledAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="coveragePeriodBeginDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="coveragePeriodEndDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="currentBalanceDue" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="dueDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lastPaymentAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lastPaymentType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lastPaymentReceivedDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lastPaymentCoverageBeginDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lastPaymentCoverageEndDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="pendingPayment" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="proposalId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="electronicPaymentRequestAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="electronicPaymentRequestDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="electronicPaymentType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="electronicPaymentAccountNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="refundPendingAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="refundReleaseDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="refundProcessedAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="refundCheckNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="refundCheckDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ebizReplyAbendcode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ebizReplyStatus" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ebizReplyStatusMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PolicyAdminARSummaryOutput", propOrder = {
    "applicationMessage",
    "systemMessage",
    "serviceMessageCode",
    "serviceMessage",
    "rpnDescription",
    "masterArName",
    "subscriberId",
    "hicNumber",
    "clientNumber",
    "cesGroupNumber",
    "clientSubNumber",
    "cesGroupSubNumber",
    "lastBilledAmount",
    "coveragePeriodBeginDate",
    "coveragePeriodEndDate",
    "currentBalanceDue",
    "dueDate",
    "lastPaymentAmount",
    "lastPaymentType",
    "lastPaymentReceivedDate",
    "lastPaymentCoverageBeginDate",
    "lastPaymentCoverageEndDate",
    "pendingPayment",
    "proposalId",
    "electronicPaymentRequestAmount",
    "electronicPaymentRequestDate",
    "electronicPaymentType",
    "electronicPaymentAccountNumber",
    "refundPendingAmount",
    "refundReleaseDate",
    "refundProcessedAmount",
    "refundCheckNumber",
    "refundCheckDate",
    "ebizReplyAbendcode",
    "ebizReplyStatus",
    "ebizReplyStatusMessage"
})
public class PolicyAdminARSummaryOutput {

    @XmlElement(required = true, nillable = true)
    protected String applicationMessage;
    @XmlElement(required = true, nillable = true)
    protected String systemMessage;
    @XmlElement(required = true, nillable = true)
    protected String serviceMessageCode;
    @XmlElement(required = true, nillable = true)
    protected String serviceMessage;
    @XmlElement(required = true, nillable = true)
    protected String rpnDescription;
    @XmlElement(required = true, nillable = true)
    protected String masterArName;
    @XmlElement(required = true, nillable = true)
    protected String subscriberId;
    @XmlElement(required = true, nillable = true)
    protected String hicNumber;
    @XmlElement(required = true, nillable = true)
    protected String clientNumber;
    @XmlElement(required = true, nillable = true)
    protected String cesGroupNumber;
    @XmlElement(required = true, nillable = true)
    protected String clientSubNumber;
    @XmlElement(required = true, nillable = true)
    protected String cesGroupSubNumber;
    @XmlElement(required = true, nillable = true)
    protected String lastBilledAmount;
    @XmlElement(required = true, nillable = true)
    protected String coveragePeriodBeginDate;
    @XmlElement(required = true, nillable = true)
    protected String coveragePeriodEndDate;
    @XmlElement(required = true, nillable = true)
    protected String currentBalanceDue;
    @XmlElement(required = true, nillable = true)
    protected String dueDate;
    @XmlElement(required = true, nillable = true)
    protected String lastPaymentAmount;
    @XmlElement(required = true, nillable = true)
    protected String lastPaymentType;
    @XmlElement(required = true, nillable = true)
    protected String lastPaymentReceivedDate;
    @XmlElement(required = true, nillable = true)
    protected String lastPaymentCoverageBeginDate;
    @XmlElement(required = true, nillable = true)
    protected String lastPaymentCoverageEndDate;
    @XmlElement(required = true, nillable = true)
    protected String pendingPayment;
    @XmlElement(required = true, nillable = true)
    protected String proposalId;
    @XmlElement(required = true, nillable = true)
    protected String electronicPaymentRequestAmount;
    @XmlElement(required = true, nillable = true)
    protected String electronicPaymentRequestDate;
    @XmlElement(required = true, nillable = true)
    protected String electronicPaymentType;
    @XmlElement(required = true, nillable = true)
    protected String electronicPaymentAccountNumber;
    @XmlElement(required = true, nillable = true)
    protected String refundPendingAmount;
    @XmlElement(required = true, nillable = true)
    protected String refundReleaseDate;
    @XmlElement(required = true, nillable = true)
    protected String refundProcessedAmount;
    @XmlElement(required = true, nillable = true)
    protected String refundCheckNumber;
    @XmlElement(required = true, nillable = true)
    protected String refundCheckDate;
    @XmlElement(required = true, nillable = true)
    protected String ebizReplyAbendcode;
    protected int ebizReplyStatus;
    @XmlElement(required = true, nillable = true)
    protected String ebizReplyStatusMessage;

    /**
     * Gets the value of the applicationMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationMessage() {
        return applicationMessage;
    }

    /**
     * Sets the value of the applicationMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationMessage(String value) {
        this.applicationMessage = value;
    }

    /**
     * Gets the value of the systemMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystemMessage() {
        return systemMessage;
    }

    /**
     * Sets the value of the systemMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystemMessage(String value) {
        this.systemMessage = value;
    }

    /**
     * Gets the value of the serviceMessageCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceMessageCode() {
        return serviceMessageCode;
    }

    /**
     * Sets the value of the serviceMessageCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceMessageCode(String value) {
        this.serviceMessageCode = value;
    }

    /**
     * Gets the value of the serviceMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceMessage() {
        return serviceMessage;
    }

    /**
     * Sets the value of the serviceMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceMessage(String value) {
        this.serviceMessage = value;
    }

    /**
     * Gets the value of the rpnDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRpnDescription() {
        return rpnDescription;
    }

    /**
     * Sets the value of the rpnDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRpnDescription(String value) {
        this.rpnDescription = value;
    }

    /**
     * Gets the value of the masterArName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMasterArName() {
        return masterArName;
    }

    /**
     * Sets the value of the masterArName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMasterArName(String value) {
        this.masterArName = value;
    }

    /**
     * Gets the value of the subscriberId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriberId() {
        return subscriberId;
    }

    /**
     * Sets the value of the subscriberId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriberId(String value) {
        this.subscriberId = value;
    }

    /**
     * Gets the value of the hicNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHicNumber() {
        return hicNumber;
    }

    /**
     * Sets the value of the hicNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHicNumber(String value) {
        this.hicNumber = value;
    }

    /**
     * Gets the value of the clientNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientNumber() {
        return clientNumber;
    }

    /**
     * Sets the value of the clientNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientNumber(String value) {
        this.clientNumber = value;
    }

    /**
     * Gets the value of the cesGroupNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCesGroupNumber() {
        return cesGroupNumber;
    }

    /**
     * Sets the value of the cesGroupNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCesGroupNumber(String value) {
        this.cesGroupNumber = value;
    }

    /**
     * Gets the value of the clientSubNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientSubNumber() {
        return clientSubNumber;
    }

    /**
     * Sets the value of the clientSubNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientSubNumber(String value) {
        this.clientSubNumber = value;
    }

    /**
     * Gets the value of the cesGroupSubNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCesGroupSubNumber() {
        return cesGroupSubNumber;
    }

    /**
     * Sets the value of the cesGroupSubNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCesGroupSubNumber(String value) {
        this.cesGroupSubNumber = value;
    }

    /**
     * Gets the value of the lastBilledAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastBilledAmount() {
        return lastBilledAmount;
    }

    /**
     * Sets the value of the lastBilledAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastBilledAmount(String value) {
        this.lastBilledAmount = value;
    }

    /**
     * Gets the value of the coveragePeriodBeginDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoveragePeriodBeginDate() {
        return coveragePeriodBeginDate;
    }

    /**
     * Sets the value of the coveragePeriodBeginDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoveragePeriodBeginDate(String value) {
        this.coveragePeriodBeginDate = value;
    }

    /**
     * Gets the value of the coveragePeriodEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoveragePeriodEndDate() {
        return coveragePeriodEndDate;
    }

    /**
     * Sets the value of the coveragePeriodEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoveragePeriodEndDate(String value) {
        this.coveragePeriodEndDate = value;
    }

    /**
     * Gets the value of the currentBalanceDue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrentBalanceDue() {
        return currentBalanceDue;
    }

    /**
     * Sets the value of the currentBalanceDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrentBalanceDue(String value) {
        this.currentBalanceDue = value;
    }

    /**
     * Gets the value of the dueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDueDate() {
        return dueDate;
    }

    /**
     * Sets the value of the dueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDueDate(String value) {
        this.dueDate = value;
    }

    /**
     * Gets the value of the lastPaymentAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastPaymentAmount() {
        return lastPaymentAmount;
    }

    /**
     * Sets the value of the lastPaymentAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastPaymentAmount(String value) {
        this.lastPaymentAmount = value;
    }

    /**
     * Gets the value of the lastPaymentType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastPaymentType() {
        return lastPaymentType;
    }

    /**
     * Sets the value of the lastPaymentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastPaymentType(String value) {
        this.lastPaymentType = value;
    }

    /**
     * Gets the value of the lastPaymentReceivedDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastPaymentReceivedDate() {
        return lastPaymentReceivedDate;
    }

    /**
     * Sets the value of the lastPaymentReceivedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastPaymentReceivedDate(String value) {
        this.lastPaymentReceivedDate = value;
    }

    /**
     * Gets the value of the lastPaymentCoverageBeginDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastPaymentCoverageBeginDate() {
        return lastPaymentCoverageBeginDate;
    }

    /**
     * Sets the value of the lastPaymentCoverageBeginDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastPaymentCoverageBeginDate(String value) {
        this.lastPaymentCoverageBeginDate = value;
    }

    /**
     * Gets the value of the lastPaymentCoverageEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastPaymentCoverageEndDate() {
        return lastPaymentCoverageEndDate;
    }

    /**
     * Sets the value of the lastPaymentCoverageEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastPaymentCoverageEndDate(String value) {
        this.lastPaymentCoverageEndDate = value;
    }

    /**
     * Gets the value of the pendingPayment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPendingPayment() {
        return pendingPayment;
    }

    /**
     * Sets the value of the pendingPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPendingPayment(String value) {
        this.pendingPayment = value;
    }

    /**
     * Gets the value of the proposalId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProposalId() {
        return proposalId;
    }

    /**
     * Sets the value of the proposalId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProposalId(String value) {
        this.proposalId = value;
    }

    /**
     * Gets the value of the electronicPaymentRequestAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getElectronicPaymentRequestAmount() {
        return electronicPaymentRequestAmount;
    }

    /**
     * Sets the value of the electronicPaymentRequestAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setElectronicPaymentRequestAmount(String value) {
        this.electronicPaymentRequestAmount = value;
    }

    /**
     * Gets the value of the electronicPaymentRequestDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getElectronicPaymentRequestDate() {
        return electronicPaymentRequestDate;
    }

    /**
     * Sets the value of the electronicPaymentRequestDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setElectronicPaymentRequestDate(String value) {
        this.electronicPaymentRequestDate = value;
    }

    /**
     * Gets the value of the electronicPaymentType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getElectronicPaymentType() {
        return electronicPaymentType;
    }

    /**
     * Sets the value of the electronicPaymentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setElectronicPaymentType(String value) {
        this.electronicPaymentType = value;
    }

    /**
     * Gets the value of the electronicPaymentAccountNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getElectronicPaymentAccountNumber() {
        return electronicPaymentAccountNumber;
    }

    /**
     * Sets the value of the electronicPaymentAccountNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setElectronicPaymentAccountNumber(String value) {
        this.electronicPaymentAccountNumber = value;
    }

    /**
     * Gets the value of the refundPendingAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefundPendingAmount() {
        return refundPendingAmount;
    }

    /**
     * Sets the value of the refundPendingAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefundPendingAmount(String value) {
        this.refundPendingAmount = value;
    }

    /**
     * Gets the value of the refundReleaseDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefundReleaseDate() {
        return refundReleaseDate;
    }

    /**
     * Sets the value of the refundReleaseDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefundReleaseDate(String value) {
        this.refundReleaseDate = value;
    }

    /**
     * Gets the value of the refundProcessedAmount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefundProcessedAmount() {
        return refundProcessedAmount;
    }

    /**
     * Sets the value of the refundProcessedAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefundProcessedAmount(String value) {
        this.refundProcessedAmount = value;
    }

    /**
     * Gets the value of the refundCheckNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefundCheckNumber() {
        return refundCheckNumber;
    }

    /**
     * Sets the value of the refundCheckNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefundCheckNumber(String value) {
        this.refundCheckNumber = value;
    }

    /**
     * Gets the value of the refundCheckDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefundCheckDate() {
        return refundCheckDate;
    }

    /**
     * Sets the value of the refundCheckDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefundCheckDate(String value) {
        this.refundCheckDate = value;
    }

    /**
     * Gets the value of the ebizReplyAbendcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEbizReplyAbendcode() {
        return ebizReplyAbendcode;
    }

    /**
     * Sets the value of the ebizReplyAbendcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEbizReplyAbendcode(String value) {
        this.ebizReplyAbendcode = value;
    }

    /**
     * Gets the value of the ebizReplyStatus property.
     * 
     */
    public int getEbizReplyStatus() {
        return ebizReplyStatus;
    }

    /**
     * Sets the value of the ebizReplyStatus property.
     * 
     */
    public void setEbizReplyStatus(int value) {
        this.ebizReplyStatus = value;
    }

    /**
     * Gets the value of the ebizReplyStatusMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEbizReplyStatusMessage() {
        return ebizReplyStatusMessage;
    }

    /**
     * Sets the value of the ebizReplyStatusMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEbizReplyStatusMessage(String value) {
        this.ebizReplyStatusMessage = value;
    }

}
