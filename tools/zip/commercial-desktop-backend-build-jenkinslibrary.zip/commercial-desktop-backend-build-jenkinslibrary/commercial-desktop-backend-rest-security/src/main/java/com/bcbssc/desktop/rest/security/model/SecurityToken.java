/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.rest.security.model;

/**
 * Commercial desktop rest API security token.  This model provides the full serialized security token
 * that is expected to be passed in with each request as well as the token id which represents the user's
 * session.
 *
 */
public class SecurityToken {

    private String tokenId;
    private String token;

    public SecurityToken(String tokenId, String token) {
        super();
        this.tokenId = tokenId;
        this.token = token;
    }

    public String getTokenId() {
        return tokenId;
    }
    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }
    public String getToken() {
        return token;
    }
    public void setToken(String token) {
        this.token = token;
    }

}
