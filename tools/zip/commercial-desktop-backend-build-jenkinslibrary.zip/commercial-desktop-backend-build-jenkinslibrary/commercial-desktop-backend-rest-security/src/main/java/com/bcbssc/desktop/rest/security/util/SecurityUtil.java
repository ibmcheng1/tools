/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.rest.security.util;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.dao.auth.NotAuthenticatedException;
import com.bcbssc.desktop.rest.security.model.SecurityToken;
import com.ibm.websphere.security.jwt.InvalidBuilderException;
import com.ibm.websphere.security.jwt.InvalidClaimException;
import com.ibm.websphere.security.jwt.InvalidConsumerException;
import com.ibm.websphere.security.jwt.InvalidTokenException;
import com.ibm.websphere.security.jwt.JwtBuilder;
import com.ibm.websphere.security.jwt.JwtConsumer;
import com.ibm.websphere.security.jwt.JwtException;
import com.ibm.websphere.security.jwt.JwtToken;

/**
 * Utility class for working with the rest API security tokens.  This class works
 * as a singleton.  Use the static <code>getInstance()</code> method to get an instance of
 * the utility.
 *
 */
public class SecurityUtil {

    private static final Log log = LogFactory.getLog(SecurityUtil.class);

    private static final String JWT_CLAIM_SECURITY_TOKEN_ID = "security-token-id";
    private static final String REQUEST_ATTRIBUTE_SECURITY_TOKEN_ID = "security-token-id";
    private static final String REQUEST_HEADER_TOKEN = "token";
    private static final String JWT_BUILDER_NAME = "desktopJwtBuilder";
    private static final String JWT_CONSUMER_NAME = "desktopJwtConsumer";

    private static SecurityUtil INSTANCE = new SecurityUtil();

    protected SecurityUtil() {
        // Protected constructor for singleton reference
    }

    /**
     * Retrieve an instance of the <code>SecurityUtil</code>.
     * @return
     */
    public static SecurityUtil getInstance() {
        return INSTANCE;
    }

    /**
     * Create a security token for the current request and user subject.
     *
     * @param request
     * @param subject
     * @return
     */
    public SecurityToken createSecurityToken(HttpServletRequest request, String subject) {
        final String tokenId = request.getSession().getId();
        return new SecurityToken(tokenId, createCompactedJwtToken(subject, tokenId));
    }

    protected String createCompactedJwtToken(String subject, String tokenId) {
        try {
            return JwtBuilder.create(JWT_BUILDER_NAME).subject(subject).claim(JWT_CLAIM_SECURITY_TOKEN_ID, tokenId).buildJwt().compact();
        } catch (JwtException | InvalidBuilderException | InvalidClaimException exception) {
            throw new SecurityTokenException("An error was encountered attempting to create a JWT token.", exception);
        }
    }

    /**
     * Validate the security token on the current request.
     *
     * @param request
     */
    public void validateSecurityToken(HttpServletRequest request) {
        if(log.isTraceEnabled()) {
            log.trace("Validating Security Token");
        }
        final String securityTokenId = getSecurityTokenIdFromHeader(request);
        if(StringUtils.isNotBlank(securityTokenId)) {
            request.setAttribute(REQUEST_ATTRIBUTE_SECURITY_TOKEN_ID, securityTokenId);
        }
    }

    /**
     * Get the security token id for the current request.  This represents the user's unique
     * session and is to be used as a cache id.
     *
     * @param request
     * @return
     */
    public String getSecurityTokenId(HttpServletRequest request) {
        String securityTokenId = (String) request.getAttribute(REQUEST_ATTRIBUTE_SECURITY_TOKEN_ID);
        if(StringUtils.isNotBlank(securityTokenId)) {
            securityTokenId = getSecurityTokenIdFromHeader(request);
            request.setAttribute(REQUEST_ATTRIBUTE_SECURITY_TOKEN_ID, securityTokenId);
        }
        if(log.isTraceEnabled()) {
            log.trace("Found security token id: " + securityTokenId);
        }
        return securityTokenId;
    }

    /**
     * Get the security token id for the current request.  This represents the user's unique
     * session and is to be used as a cache id.  If a token is not found, a <code>NotAuthorized</code>
     * exception is thrown.
     *
     * @param request
     * @return
     */
    public String getSecurityTokenIdStrict(HttpServletRequest request) {
        final String securityTokenId = getSecurityTokenId(request);
        if(StringUtils.isBlank(securityTokenId)) {
            throw new NotAuthenticatedException("A security token id could not be found");
        }
        return securityTokenId;
    }

    private String getSecurityTokenIdFromHeader(HttpServletRequest request) {
        String securityTokenId = null;
        final String tokenHeader = request.getHeader(REQUEST_HEADER_TOKEN);
        if(StringUtils.isNotBlank(tokenHeader)) {
            securityTokenId = getSecurityTokenIdFromSecurityToken(tokenHeader);
            if(log.isTraceEnabled()) {
                log.trace("Found security token id: " + securityTokenId);
            }
        }
        return securityTokenId;
    }

    protected String getSecurityTokenIdFromSecurityToken(String securityToken) {
        String securityTokenId = null;
        try {
            final JwtToken jwtToken = JwtConsumer.create(JWT_CONSUMER_NAME).createJwt(securityToken);
            if(jwtToken.getClaims().containsKey(JWT_CLAIM_SECURITY_TOKEN_ID)) {
                securityTokenId = jwtToken.getClaims().getClaim(JWT_CLAIM_SECURITY_TOKEN_ID, String.class);
            }
        } catch (InvalidTokenException | InvalidConsumerException exception) {
            throw new SecurityTokenException("An error was encountered validating a JWT token.", exception);
        }
        return securityTokenId;
    }

    /**
     * Exception to be thrown when having issues creating or reading security tokens.
     *
     */
    public static class SecurityTokenException extends RuntimeException {
        private static final long serialVersionUID = 1L;
        public SecurityTokenException(String message) {
            super(message);
        }
        public SecurityTokenException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
