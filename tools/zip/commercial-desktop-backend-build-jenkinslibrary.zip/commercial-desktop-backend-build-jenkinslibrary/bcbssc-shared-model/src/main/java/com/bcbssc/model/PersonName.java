/**
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2007 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 *  [PVCS]
 *  $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/SharedProjects/bcbssc-common/bcbssc-model/src/main/java/com/bcbssc/model/PersonName.java_v  $
 *  $Workfile:   PersonName.java  $
 *  $Revision:   1.0  $
 *  $Date:   Aug 20 2008 10:56:56  $
 *  $Modtime:   Aug 06 2008 10:46:26  $
 *  
 */

package com.bcbssc.model;

import java.io.Serializable;

/**
 * @author X77D
 *
 */
public class PersonName implements Serializable {
    private static final long serialVersionUID = 1L;
    private String firstName;
    private String lastName;
    private String middleName;
    private String prefixName;
    private String suffixName;

    /**
     * @return the first name
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the first name to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the last name
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the last name to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the middle name
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * @param middleName the middle name to set
     */
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    /**
     * @return the prefix name
     */
    public String getPrefixName() {
        return prefixName;
    }

    /**
     * @param prefixName the prefix name to set
     */
    public void setPrefixName(String prefixName) {
        this.prefixName = prefixName;
    }

    /**
     * @return the suffix name
     */
    public String getSuffixName() {
        return suffixName;
    }

    /**
     * @param suffixName the suffix name to set
     */
    public void setSuffixName(String suffixName) {
        this.suffixName = suffixName;
    }
}
