/**
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2007 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 *  [PVCS]
 *  $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/SharedProjects/bcbssc-common/bcbssc-model/src/main/java/com/bcbssc/model/ClientBusinessSectorCode.java_v  $
 *  $Workfile:   ClientBusinessSectorCode.java  $
 *  $Revision:   1.0  $
 *  $Date:   Aug 20 2008 10:56:50  $
 *  $Modtime:   Aug 06 2008 10:46:26  $
 *  
 */

package com.bcbssc.model;

import java.io.Serializable;

/**
 * @author X77D
 *
 */
public class ClientBusinessSectorCode extends Code implements Serializable {
    private static final long serialVersionUID = 1L;
    private String rpn;
    private String ammsRpn;
    private String cisiRpn;
    private String pimsRpn;
    private String ruleRpn;
    private String infoRpn;
    private String tmcsRpn;

    /**
     * @return the ammsRpn
     */
    public String getAmmsRpn() {
        return ammsRpn;
    }

    /**
     * @param ammsRpn the ammsRpn to set
     */
    public void setAmmsRpn(String ammsRpn) {
        this.ammsRpn = ammsRpn;
    }

    /**
     * @return the cisiRpn
     */
    public String getCisiRpn() {
        return cisiRpn;
    }

    /**
     * @param cisiRpn the cisiRpn to set
     */
    public void setCisiRpn(String cisiRpn) {
        this.cisiRpn = cisiRpn;
    }

    /**
     * @return the infoRpn
     */
    public String getInfoRpn() {
        return infoRpn;
    }

    /**
     * @param infoRpn the infoRpn to set
     */
    public void setInfoRpn(String infoRpn) {
        this.infoRpn = infoRpn;
    }

    /**
     * @return the pimsRpn
     */
    public String getPimsRpn() {
        return pimsRpn;
    }

    /**
     * @param pimsRpn the pimsRpn to set
     */
    public void setPimsRpn(String pimsRpn) {
        this.pimsRpn = pimsRpn;
    }

    /**
     * @return the rpn
     */
    public String getRpn() {
        return rpn;
    }

    /**
     * @param rpn the rpn to set
     */
    public void setRpn(String rpn) {
        this.rpn = rpn;
    }

    /**
     * @return the ruleRpn
     */
    public String getRuleRpn() {
        return ruleRpn;
    }

    /**
     * @param ruleRpn the ruleRpn to set
     */
    public void setRuleRpn(String ruleRpn) {
        this.ruleRpn = ruleRpn;
    }

    /**
     * @return the tmcsRpn
     */
    public String getTmcsRpn() {
        return tmcsRpn;
    }

    /**
     * @param tmcsRpn the tmcsRpn to set
     */
    public void setTmcsRpn(String tmcsRpn) {
        this.tmcsRpn = tmcsRpn;
    }
}
