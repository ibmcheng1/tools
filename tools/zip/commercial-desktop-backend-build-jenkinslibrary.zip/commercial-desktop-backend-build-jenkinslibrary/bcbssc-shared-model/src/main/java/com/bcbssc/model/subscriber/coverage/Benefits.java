/**
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2007 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 *  [PVCS]
 *  $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/SharedProjects/bcbssc-common/bcbssc-model/src/main/java/com/bcbssc/model/subscriber/coverage/Benefits.java_v  $
 *  $Workfile:   Benefits.java  $
 *  $Revision:   1.0  $
 *  $Date:   Aug 20 2008 10:57:06  $
 *  $Modtime:   Aug 18 2008 09:06:20  $
 *  
 */

package com.bcbssc.model.subscriber.coverage;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author X77D
 *
 */
public class Benefits implements Serializable {

    private static final long serialVersionUID = 1L;
    private String networkDescription;
    private BigDecimal individualDeductible;
    private BigDecimal individualOutOfPocket;
    private BigDecimal familyDeductible;
    private BigDecimal familyOutOfPocket;
    private String coverageLevel;
    private boolean isFamilyOutofPocketFound;
    private boolean isFamilyDeductibleFound;

    /**
     * @return the familyDeductible
     */
    public BigDecimal getFamilyDeductible() {
        return familyDeductible;
    }

    /**
     * @param familyDeductible the familyDeductible to set
     */
    public void setFamilyDeductible(BigDecimal familyDeductible) {
        this.familyDeductible = familyDeductible;
    }

    /**
     * @return the familyOutOfPocket
     */
    public BigDecimal getFamilyOutOfPocket() {
        return familyOutOfPocket;
    }

    /**
     * @param familyOutOfPocket the familyOutOfPocket to set
     */
    public void setFamilyOutOfPocket(BigDecimal familyOutOfPocket) {
        this.familyOutOfPocket = familyOutOfPocket;
    }

    /**
     * @return the individualDeductible
     */
    public BigDecimal getIndividualDeductible() {
        return individualDeductible;
    }

    /**
     * @param individualDeductible the individualDeductible to set
     */
    public void setIndividualDeductible(BigDecimal individualDeductible) {
        this.individualDeductible = individualDeductible;
    }

    /**
     * @return the individualOutOfPocket
     */
    public BigDecimal getIndividualOutOfPocket() {
        return individualOutOfPocket;
    }

    /**
     * @param individualOutOfPocket the individualOutOfPocket to set
     */
    public void setIndividualOutOfPocket(BigDecimal individualOutOfPocket) {
        this.individualOutOfPocket = individualOutOfPocket;
    }

    /**
     * @return the networkDescription
     */
    public String getNetworkDescription() {
        return networkDescription;
    }

    /**
     * @param networkDescription the networkDescription to set
     */
    public void setNetworkDescription(String networkDescription) {
        this.networkDescription = networkDescription;
    }

    /**
     * @return the coverageLevel
     */
    public String getCoverageLevel() {
        return coverageLevel;
    }

    /**
     * @param coverageLevel the coverageLevel to set
     */
    public void setCoverageLevel(String coverageLevel) {
        this.coverageLevel = coverageLevel;
    }

    /**
     * @return the isFamilyDeductibleFound
     */
    public boolean isFamilyDeductibleFound() {
        return isFamilyDeductibleFound;
    }

    /**
     * @param isFamilyDeductibleFound the isFamilyDeductibleFound to set
     */
    public void setFamilyDeductibleFound(boolean isFamilyDeductibleFound) {
        this.isFamilyDeductibleFound = isFamilyDeductibleFound;
    }

    /**
     * @return the isFamilyOutofPocketFound
     */
    public boolean isFamilyOutofPocketFound() {
        return isFamilyOutofPocketFound;
    }

    /**
     * @param isFamilyOutofPocketFound the isFamilyOutofPocketFound to set
     */
    public void setFamilyOutofPocketFound(boolean isFamilyOutofPocketFound) {
        this.isFamilyOutofPocketFound = isFamilyOutofPocketFound;
    }
}
