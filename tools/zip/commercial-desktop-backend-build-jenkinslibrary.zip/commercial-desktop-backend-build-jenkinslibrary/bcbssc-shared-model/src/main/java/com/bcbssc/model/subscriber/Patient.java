/**
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2007 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 *  [PVCS]
 *  $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/SharedProjects/bcbssc-common/bcbssc-model/src/main/java/com/bcbssc/model/subscriber/Patient.java_v  $
 *  $Workfile:   Patient.java  $
 *  $Revision:   1.0  $
 *  $Date:   Aug 20 2008 10:57:00  $
 *  $Modtime:   Aug 06 2008 12:48:00  $
 *  
 */

package com.bcbssc.model.subscriber;

import java.io.Serializable;
import java.util.Date;

import com.bcbssc.model.Person;

/**
 * @author X77D
 *
 */
public class Patient extends Person implements Serializable {
    private static final long serialVersionUID = 1L;
    private String patientId;
    private Date dateOfBirth;
    private RelationshipCode relationshipCode;
    private Boolean confidentialCommunications;

    /**
     * @return the dateOfBirth
     */
    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * @param dateOfBirth the dateOfBirth to set
     */
    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * @return the patientId
     */
    public String getPatientId() {
        return patientId;
    }

    /**
     * @param patientId the patientId to set
     */
    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    /**
     * @return the relationshipCode
     */
    public RelationshipCode getRelationshipCode() {
        return relationshipCode;
    }

    /**
     * @param relationshipCode the relationshipCode to set
     */
    public void setRelationshipCode(RelationshipCode relationshipCode) {
        this.relationshipCode = relationshipCode;
    }

    /**
     * @return the confidentialCommunications
     */
    public Boolean getConfidentialCommunications() {
        return confidentialCommunications;
    }

    /**
     * @param confidentialCommunications the confidentialCommunications to set
     */
    public void setConfidentialCommunications(Boolean confidentialCommunications) {
        this.confidentialCommunications = confidentialCommunications;
    }
}
