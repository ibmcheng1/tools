/**
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2008 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 *  [PVCS]
 *  $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/SharedProjects/bcbssc-common/bcbssc-model/src/main/java/com/bcbssc/model/SexCode.java_v  $
 *  $Workfile:   SexCode.java  $
 *  $Revision:   1.0  $
 *  $Date:   Aug 20 2008 10:56:58  $
 *  $Modtime:   Aug 11 2008 13:20:10  $
 *  
 */

package com.bcbssc.model;

/**
 * @author X77D
 *
 */
public class SexCode extends Code {

    private static final long serialVersionUID = 1L;

}
