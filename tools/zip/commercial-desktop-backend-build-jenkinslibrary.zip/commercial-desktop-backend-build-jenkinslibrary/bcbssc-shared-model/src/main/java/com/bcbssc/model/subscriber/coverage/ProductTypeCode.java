/**
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2007 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 *  [PVCS]
 *  $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/SharedProjects/bcbssc-common/bcbssc-model/src/main/java/com/bcbssc/model/subscriber/coverage/ProductTypeCode.java_v  $
 *  $Workfile:   ProductTypeCode.java  $
 *  $Revision:   1.0  $
 *  $Date:   Aug 20 2008 10:57:12  $
 *  $Modtime:   Aug 06 2008 10:46:26  $
 *  
 */

package com.bcbssc.model.subscriber.coverage;

import java.io.Serializable;

import com.bcbssc.model.Code;

/**
 * @author X77D
 *
 */
public class ProductTypeCode extends Code implements Serializable {

    private static final long serialVersionUID = 1L;

}
