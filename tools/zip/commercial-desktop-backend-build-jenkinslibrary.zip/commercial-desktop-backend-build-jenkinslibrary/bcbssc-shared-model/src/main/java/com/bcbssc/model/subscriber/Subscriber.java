/**
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2008 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 *  [PVCS]
 *  $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/SharedProjects/bcbssc-common/bcbssc-model/src/main/java/com/bcbssc/model/subscriber/Subscriber.java_v  $
 *  $Workfile:   Subscriber.java  $
 *  $Revision:   1.2  $
 *  $Date:   Nov 13 2008 15:07:58  $
 *  $Modtime:   Nov 13 2008 15:05:20  $
 *
 */

package com.bcbssc.model.subscriber;

import java.io.Serializable;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import com.bcbssc.model.Person;
import com.bcbssc.model.subscriber.coverage.Coverage;

/**
 * @author X77D
 * 
 */
public class Subscriber extends Person implements Serializable {
    private static final long serialVersionUID = 1L;
    private String databaseNumber;
    private String idCardNumber;
    private String socialSecurityNumber;
    private String groupNumber;
    private Set patients;
    private Coverage medicalCoverage;
    private Date dateOfBirth;
    /**
     * @return the database number
     */
    public String getDatabaseNumber() {
        return databaseNumber;
    }

    /**
     * @param databaseNumber the database number to set
     */
    public void setDatabaseNumber(String databaseNumber) {
        this.databaseNumber = databaseNumber;
    }

    /**
     * @return the ID card number
     */
    public String getIdCardNumber() {
        return idCardNumber;
    }

    /**
     * @param idCardNumber the ID card number to set
     */
    public void setIdCardNumber(String idCardNumber) {
        this.idCardNumber = idCardNumber;
    }

    /**
     * @return the set of patients
     */
    public Set getPatients() {
        return patients;
    }

    /**
     * @return a specific patient
     */
    public Patient getPatient(String patientId) {

        Patient selectedPatient = null;
        if (this.getPatients() != null) {
            Iterator it = this.getPatients().iterator();
            while (it.hasNext()) {
                selectedPatient = (Patient) it.next();
                if (selectedPatient.getPatientId().equalsIgnoreCase(patientId)) {
                    return selectedPatient;
                }
            }
        }
        return null;
    }

    /**
     * @param patients the set of patients to set
     */
    public void setPatients(Set patients) {
        this.patients = patients;
    }

    /**
     * @return the groupNumber
     */
    public String getGroupNumber() {
        return groupNumber;
    }

    /**
     * @param groupNumber the groupNumber to set
     */
    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }

    /**
     * @return the medicalCoverage
     */
    public Coverage getMedicalCoverage() {
        return medicalCoverage;
    }

    /**
     * @param medicalCoverage the medicalCoverage to set
     */
    public void setMedicalCoverage(Coverage medicalCoverage) {
        this.medicalCoverage = medicalCoverage;
    }

    public String getSocialSecurityNumber() {
        return socialSecurityNumber;
    }

    public void setSocialSecurityNumber(String socialSecurityNumber) {
        this.socialSecurityNumber = socialSecurityNumber;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }
}
