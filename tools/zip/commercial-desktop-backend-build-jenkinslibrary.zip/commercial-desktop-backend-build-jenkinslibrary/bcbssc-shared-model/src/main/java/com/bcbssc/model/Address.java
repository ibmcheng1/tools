/**
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2007 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 *  [PVCS]
 *  $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/SharedProjects/bcbssc-common/bcbssc-model/src/main/java/com/bcbssc/model/Address.java_v  $
 *  $Workfile:   Address.java  $
 *  $Revision:   1.0  $
 *  $Date:   Aug 20 2008 10:56:48  $
 *  $Modtime:   Aug 06 2008 10:46:26  $
 *
 */

package com.bcbssc.model;

import java.io.Serializable;

/**
 * @author X77D
 *
 */
public class Address implements Serializable {
    private static final long serialVersionUID = 1L;
    private String address1;
    private String address2;
    private String address3;
    private String address4;
    private String address5;
    private String city;
    private String state;
    private String zipcode;
    private String province;
    private CountyCode county;
    private String country;
    private String region;

    /**
     * @return line 1 of the address
     */
    public String getAddress1() {
        return address1;
    }

    /**
     * @param address1 line 1 of the address to set
     */
    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    /**
     * @return line 2 of the address
     */
    public String getAddress2() {
        return address2;
    }

    /**
     * @param address2 line 2 of the address to set
     */
    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    /**
     * @return line 3 of the address
     */
    public String getAddress3() {
        return address3;
    }

    /**
     * @param address3 line 3 of the address to set
     */
    public void setAddress3(String address3) {
        this.address3 = address3;
    }

    /**
     * @return line 4 of the address
     */
    public String getAddress4() {
        return address4;
    }

    /**
     * @param address4 line 4 of the address to set
     */
    public void setAddress4(String address4) {
        this.address4 = address4;
    }

    /**
     * @return line 5 of the address
     */
    public String getAddress5() {
        return address5;
    }

    /**
     * @param address5 line 5 of the address to set
     */
    public void setAddress5(String address5) {
        this.address5 = address5;
    }

    /**
     * @return the city
     */
    public String getCity() {
        return city;
    }

    /**
     * @param city the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * @param country the country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * @return the county
     */
    public CountyCode getCounty() {
        return county;
    }

    /**
     * @param county the county to set
     */
    public void setCounty(CountyCode county) {
        this.county = county;
    }

    /**
     * @return the province
     */
    public String getProvince() {
        return province;
    }

    /**
     * @param province the province to set
     */
    public void setProvince(String province) {
        this.province = province;
    }

    /**
     * @return the region
     */
    public String getRegion() {
        return region;
    }

    /**
     * @param region the region to set
     */
    public void setRegion(String region) {
        this.region = region;
    }

    /**
     * @return the state
     */
    public String getState() {
        return state;
    }

    /**
     * @param state the state to set
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * @return the zipcode
     */
    public String getZipcode() {
        return zipcode;
    }

    /**
     * @param zipcode the zipcode to set
     */
    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }
}
