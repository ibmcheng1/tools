/**
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2007 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 *
 *  [PVCS]
 *  $Archive:   //a70tpvcs/dev/projectdbs/Websites/archives/SharedProjects/bcbssc-common/bcbssc-model/src/main/java/com/bcbssc/model/Person.java_v  $
 *  $Workfile:   Person.java  $
 *  $Revision:   1.0  $
 *  $Date:   Aug 20 2008 10:56:54  $
 *  $Modtime:   Aug 14 2008 11:24:42  $
 *  
 */

package com.bcbssc.model;

import java.io.Serializable;

/**
 * @author X77D
 *
 */
public class Person implements Serializable {
    private static final long serialVersionUID = 1L;
    private PersonName personName;
    private Address address;
    private String phoneNumber;
    private SexCode sex;

    public Person() {
        super();
        this.personName = new PersonName();
        this.address = new Address();
        this.sex = new SexCode();
    }

    /**
     * @return the sex
     */
    public SexCode getSex() {
        return sex;
    }

    /**
     * @param sex the sex to set
     */
    public void setSex(SexCode sex) {
        this.sex = sex;
    }

    /**
     * @return the address
     */
    public Address getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(Address address) {
        this.address = address;
    }

    /**
     * @return the person name
     */
    public PersonName getPersonName() {
        return personName;
    }

    /**
     * @param personName the person name to set
     */
    public void setPersonName(PersonName personName) {
        this.personName = personName;
    }

    /**
     * @return the phone number
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * @param phoneNumber the phone number to set
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
