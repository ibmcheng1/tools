
package com.bcbssc.services.programsummaryinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="getProgramSummaryReturn" type="{http://ProgramSummaryInfo.TM05T101EJB.commercial.bcbssc.com}ProgramSummaryInfoOutput"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getProgramSummaryReturn"
})
@XmlRootElement(name = "getProgramSummaryResponse")
public class GetProgramSummaryResponse {

    @XmlElement(required = true, nillable = true)
    protected ProgramSummaryInfoOutput getProgramSummaryReturn;

    /**
     * Gets the value of the getProgramSummaryReturn property.
     * 
     * @return
     *     possible object is
     *     {@link ProgramSummaryInfoOutput }
     *     
     */
    public ProgramSummaryInfoOutput getGetProgramSummaryReturn() {
        return getProgramSummaryReturn;
    }

    /**
     * Sets the value of the getProgramSummaryReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProgramSummaryInfoOutput }
     *     
     */
    public void setGetProgramSummaryReturn(ProgramSummaryInfoOutput value) {
        this.getProgramSummaryReturn = value;
    }

}
