
package com.bcbssc.services.rpnresetprocess;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="processRPNResetReturn" type="{http://RPNResetProcess.RPNST101EJB.commercial.bcbssc.com}RPNResetProcessOutput"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "processRPNResetReturn"
})
@XmlRootElement(name = "processRPNResetResponse")
public class ProcessRPNResetResponse {

    @XmlElement(required = true, nillable = true)
    protected RPNResetProcessOutput processRPNResetReturn;

    /**
     * Gets the value of the processRPNResetReturn property.
     * 
     * @return
     *     possible object is
     *     {@link RPNResetProcessOutput }
     *     
     */
    public RPNResetProcessOutput getProcessRPNResetReturn() {
        return processRPNResetReturn;
    }

    /**
     * Sets the value of the processRPNResetReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link RPNResetProcessOutput }
     *     
     */
    public void setProcessRPNResetReturn(RPNResetProcessOutput value) {
        this.processRPNResetReturn = value;
    }

}
