/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.inform;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.StringTokenizer;

import org.apache.commons.lang.WordUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.domain.entity.inform.lines.AbstractInformVerbiageLine;
import com.bcbssc.domain.entity.inform.lines.InformMessage;
import com.bcbssc.domain.entity.inform.lines.InformRequestLine;

/**
 * Utility class for dealing with Inform messages
 *
 * @author CJ97 (R. Porter)
 */
public class InformUtil {

    private static final Log log = LogFactory.getLog(InformUtil.class);

    public static final String VERBIAGE_DELIMITER = "\n";
    public static final int MAX_LENGTH = 78;

    public static final String META_DATA_DELIM_ENVIRONMENT = "\n--Environment: ";
    public static final String META_DATA_DELIM_REGION = "\n--Region: ";
    public static final String META_DATA_DELIM_LAST_RETRY = "\n--Last Retry: ";
    public static final String META_DATA_DELIM_RETRY_COUNT = "\n--Retry Count: ";
    public static final String META_DATA_DELIM = "\n------------------------------------------------------\n";
    
    /**
     * add a single request line to an InformMessage
     * @param informMessage
     * @param verbiage - line to be added
     */
    public static void addRequestLines(InformMessage informMessage, String verbiage) {
        InformUtil.addRequestLines(informMessage, verbiage, false);
    }

    
    /**
     * add a single request line to an InformMessage
     * @param informMessage
     * @param verbiage - line to be added
     * @param wrapVerbiage - indicates whether to wrap the line
     */
    public static void addRequestLines(InformMessage informMessage, String verbiage, boolean wrapVerbiage) {
        InformUtil.addVerbiageLines(informMessage, verbiage, wrapVerbiage, InformRequestLine.class);
    }

    
    /**
     * add request lines to an InformMessage
     * @param informMessage
     * @param verbiage - line to be added
     * @param wrapVerbiage - indicates whether to wrap the line
     * @param informVerbiageLineClass - the class type of the lines to add to an InformMessage
     */
    public static void addVerbiageLines(InformMessage informMessage, String verbiage, boolean wrapVerbiage,
            Class<?> informVerbiageLineClass) {
        addVerbiageLines(informMessage, verbiage, wrapVerbiage, MAX_LENGTH, informVerbiageLineClass);
    }

    
    /**
     * add request lines to an informMessage
     * @param informMessage
     * @param verbiage - line to be added
     * @param wrapVerbiage - indicates whether to wrap the line
     * @param verbiageLength - length of the line to be added
     * @param informVerbiageLineClass - the class type of the lines to add to an InformMessage
     */
    public static void addVerbiageLines(InformMessage informMessage, String verbiage, boolean wrapVerbiage,
            int verbiageLength, Class<?> informVerbiageLineClass) {
        String tempVerbiage = verbiage;
        if (wrapVerbiage) {
            tempVerbiage = InformUtil.wrapVerbiage(tempVerbiage, verbiageLength);
        }
        StringTokenizer tokenizer = new StringTokenizer(tempVerbiage, InformUtil.VERBIAGE_DELIMITER);
        int verbiageIndex = 1;
        AbstractInformVerbiageLine informVerbiageLine;
        while (tokenizer.hasMoreTokens()) {
            informVerbiageLine = createInformVerbiageLine(informVerbiageLineClass);
            informVerbiageLine.setVerbiage(tokenizer.nextToken());
            informVerbiageLine.setSequenceNumber(String.valueOf(verbiageIndex++));
            informMessage.addLine(informVerbiageLine);
        }
    }

    
    /**
     *  create an InformMessage line 
     * @param informVerbiageLineClass - class type of the line
     * @return
     */
    private static AbstractInformVerbiageLine createInformVerbiageLine(Class<?> informVerbiageLineClass) {
        AbstractInformVerbiageLine informVerbiageLine = null;

        try {
            Class<?> clazz = Class.forName(informVerbiageLineClass.getName());
            Constructor<?> defConstructor = clazz.getConstructor((Class[]) null);
            informVerbiageLine = (AbstractInformVerbiageLine) defConstructor.newInstance((Object[]) null);
        } catch (ClassNotFoundException ex) {
            log.error("failed to create verbiage line from class = " + informVerbiageLineClass, ex);
            throw new IllegalArgumentException("Cannot create InformVerbiageLine; cannot find class "
                    + informVerbiageLineClass.getName());
        } catch (NoSuchMethodException ex) {
            log.error("failed to create verbiage line from class = " + informVerbiageLineClass, ex);
            throw new IllegalArgumentException("Canot create InformVerbiageLine; does not have default constructor");
        } catch (InstantiationException ex) {
            log.error("failed to create verbiage line from class = " + informVerbiageLineClass, ex);
            throw new IllegalArgumentException("Cannot instantiate InformVerbiageLine. " + String.valueOf(ex));
        } catch (IllegalAccessException ex) {
            log.error("failed to create verbiage line from class = " + informVerbiageLineClass, ex);
            throw new IllegalArgumentException("Cannot create InformVerbiageLine; default constructor not accessible");
        } catch (InvocationTargetException ex) {
            log.error("failed to create verbiage line from class = " + informVerbiageLineClass, ex);
            throw new IllegalArgumentException("Cannot create InformVerbiageLine; caught " + String.valueOf(ex));
        }

        return informVerbiageLine;
    }

    /**
     * wrap an InformMessage line by the maximum length
     * @param verbiage - line to be wrapped
     * @return
     */
    public static String wrapVerbiage(String verbiage) {
        return wrapVerbiage(verbiage, MAX_LENGTH);
    }

    /**
     * wrap an InformMessage line by a certain length
     * @param verbiage - line to be wrapped
     * @param verbiageLength - length of each line
     * @return
     */
    public static String wrapVerbiage(String verbiage, int verbiageLength) {
        if (verbiage == null) {
            return "";
        }
        StringBuffer wrappedVerbiage = new StringBuffer();
        StringTokenizer tokenizer = new StringTokenizer(verbiage, InformUtil.VERBIAGE_DELIMITER);
        while (tokenizer.hasMoreTokens()) {
            wrappedVerbiage.append(WordUtils.wrap(tokenizer.nextToken(), verbiageLength, InformUtil.VERBIAGE_DELIMITER,
                    true));
            wrappedVerbiage.append(InformUtil.VERBIAGE_DELIMITER);
        }

        return String.valueOf(wrappedVerbiage);
    }
}
