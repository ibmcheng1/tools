
package com.bcbssc.services.rpnresetprocess;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RPNResetProcessOutput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RPNResetProcessOutput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="serviceMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="serviceMessageCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="systemMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="applicationMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="racfId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="racfName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="rpn" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="clientName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ebizReplyAbendcode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ebizReplyStatus" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ebizReplyStatusMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RPNResetProcessOutput", propOrder = {
    "serviceMessage",
    "serviceMessageCode",
    "systemMessage",
    "applicationMessage",
    "racfId",
    "racfName",
    "rpn",
    "clientName",
    "ebizReplyAbendcode",
    "ebizReplyStatus",
    "ebizReplyStatusMessage"
})
public class RPNResetProcessOutput {

    @XmlElement(required = true, nillable = true)
    protected String serviceMessage;
    @XmlElement(required = true, nillable = true)
    protected String serviceMessageCode;
    @XmlElement(required = true, nillable = true)
    protected String systemMessage;
    @XmlElement(required = true, nillable = true)
    protected String applicationMessage;
    @XmlElement(required = true, nillable = true)
    protected String racfId;
    @XmlElement(required = true, nillable = true)
    protected String racfName;
    @XmlElement(required = true, nillable = true)
    protected String rpn;
    @XmlElement(required = true, nillable = true)
    protected String clientName;
    @XmlElement(required = true, nillable = true)
    protected String ebizReplyAbendcode;
    protected int ebizReplyStatus;
    @XmlElement(required = true, nillable = true)
    protected String ebizReplyStatusMessage;

    /**
     * Gets the value of the serviceMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceMessage() {
        return serviceMessage;
    }

    /**
     * Sets the value of the serviceMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceMessage(String value) {
        this.serviceMessage = value;
    }

    /**
     * Gets the value of the serviceMessageCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceMessageCode() {
        return serviceMessageCode;
    }

    /**
     * Sets the value of the serviceMessageCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceMessageCode(String value) {
        this.serviceMessageCode = value;
    }

    /**
     * Gets the value of the systemMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystemMessage() {
        return systemMessage;
    }

    /**
     * Sets the value of the systemMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystemMessage(String value) {
        this.systemMessage = value;
    }

    /**
     * Gets the value of the applicationMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationMessage() {
        return applicationMessage;
    }

    /**
     * Sets the value of the applicationMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationMessage(String value) {
        this.applicationMessage = value;
    }

    /**
     * Gets the value of the racfId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRacfId() {
        return racfId;
    }

    /**
     * Sets the value of the racfId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRacfId(String value) {
        this.racfId = value;
    }

    /**
     * Gets the value of the racfName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRacfName() {
        return racfName;
    }

    /**
     * Sets the value of the racfName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRacfName(String value) {
        this.racfName = value;
    }

    /**
     * Gets the value of the rpn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRpn() {
        return rpn;
    }

    /**
     * Sets the value of the rpn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRpn(String value) {
        this.rpn = value;
    }

    /**
     * Gets the value of the clientName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientName() {
        return clientName;
    }

    /**
     * Sets the value of the clientName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientName(String value) {
        this.clientName = value;
    }

    /**
     * Gets the value of the ebizReplyAbendcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEbizReplyAbendcode() {
        return ebizReplyAbendcode;
    }

    /**
     * Sets the value of the ebizReplyAbendcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEbizReplyAbendcode(String value) {
        this.ebizReplyAbendcode = value;
    }

    /**
     * Gets the value of the ebizReplyStatus property.
     * 
     */
    public int getEbizReplyStatus() {
        return ebizReplyStatus;
    }

    /**
     * Sets the value of the ebizReplyStatus property.
     * 
     */
    public void setEbizReplyStatus(int value) {
        this.ebizReplyStatus = value;
    }

    /**
     * Gets the value of the ebizReplyStatusMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEbizReplyStatusMessage() {
        return ebizReplyStatusMessage;
    }

    /**
     * Sets the value of the ebizReplyStatusMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEbizReplyStatusMessage(String value) {
        this.ebizReplyStatusMessage = value;
    }

}
