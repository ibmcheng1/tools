/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2016 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.contactHistory;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Remote;

import com.bcbssc.domain.entity.InformSearchCriteria;
import com.bcbssc.domain.entity.inform.InformRecord;

/**
 * Data Access Object related to submitting inform records
 * to populate contact history portlet, as well as the repeat caller alert on a call pop
 */
@Local
public interface InformDAO {
    /**
     * Retrieves a list of InformRecords based on the given InformSearchCriteria
     * @param searchCriteria
     * @return
     */
    public List<InformRecord> getInformRecords(InformSearchCriteria searchCriteria) throws Exception;
    
}

