/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.startup;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.security.auth.Subject;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.DesktopStartupBiz;
import com.bcbssc.desktop.biz.EnvironmentBiz;
import com.bcbssc.desktop.biz.cache.CacheRefreshBiz;
import com.bcbssc.domain.entity.ApplicationClient;
import com.bcbssc.domain.entity.InformSearchCriteria;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;

/**
 * This class performs all of the necessary transactions to refresh the
 * cached data in dynacache. This includes
 *   - Inform Picklists
 *
 * <pre>
 * [Harvest]
 * </pre>
 *
 * @author $Author$  (original: JC33)
 * @version $Revision$
 */
@Remote
@Stateless (name = "InformCacheRefresh")
public class InformPicklistCacheRefreshBizBDImpl implements CacheRefreshBiz {

    private static final String TIMER_INFO = "informPicklistRefreshTimer";

    private static final Log log = LogFactory.getLog(InformPicklistCacheRefreshBizBDImpl.class);

    @Resource
    private TimerService timerService;

    @Resource(name = "inform.picklist.cache.refresh.interval")
    private Long refreshInterval;

    @EJB
    private DesktopStartupBiz informBiz;

    /**
     * Protected instead of private for JUnit.
     */
    @EJB
    protected EnvironmentBiz environmentBiz;

    /**
     * Initializes this EJB with all of the data that it needs
     *
     * @return <code>true</code> if the initialization is successful
     */
    protected boolean initialize() {
        /*
         * At this point, there is no configuration that will fail the
         * initialization, default values will be used for all parameters
         */
        if (null == refreshInterval) {
            refreshInterval = environmentBiz.getCommon(EnvironmentObjects.INFORM_PICKLIST_CACHE_REFRESH_INTERVAL, Long.class);
        }
        return true;
    }

    @Override
    public void refreshCachedData() throws Exception {
        refreshCachedData(null);
    }

    @Override
    public void startCacheRefreshTimer() throws Exception {
        initialize();
        if (log.isInfoEnabled()) {
            log.info("Starting the INFOrm Picklist refresh timer - running every " + (refreshInterval / 1000 / 60) + " minute(s)");
        }
        timerService.createTimer(refreshInterval, refreshInterval, TIMER_INFO);
    }

    @Override
    public void cancelCacheRefreshTimer() throws Exception {
        final Collection<Timer> timers = timerService.getTimers();
        for (final Timer timer : timers) {
            if (TIMER_INFO.equals(timer.getInfo())) {
                timer.cancel();
            }
        }
    }

    /**
     * @param timer
     */
    @Timeout
    public void refreshCachedData(Timer timer) {
        if (log.isInfoEnabled()) {
            log.info("Running INFOrm Picklist refresh sequence");
        }
        final boolean initialized = initialize();

        if (initialized) {

            // Figure out which INFOrm Picklists are available in DynaCache as we don't want to refresh things that aren't there
            Set<String> keys = null;
            try {
                keys = DesktopAPI.getCacheWrapper().getKeys();
            } catch (final Exception e) {
                log.error("There was an exception getting the keys for the INFOrm picklist entries for a refresh", e);
            }
            final List<String> refreshPicklistRequests = getRefreshRequests(keys);

            // For each environment and criteria object, retrieve the INFOrm Picklist data
            for (final String environment : environmentBiz.getEnvironments()) {
                for (final String key : refreshPicklistRequests) {
                    final InformSearchCriteria request = extractCriteria(key);
                    try {
                        // get the application id
                        final String applicationId = extractApplicationId(key);
                        // get the client id
                        final String clientId = extractClientId(key);
                        // Build a subject to use to get the data
                        final Subject subject = buildSubject(applicationId, environment);
                        final HashMap<String, ?> picklistData = getPicklistData(request, clientId, applicationId, subject);
                        // Store the INFOrm Picklist data back into DynaCache
                        storePicklistData(picklistData, request, applicationId, clientId);
                    } catch (final Exception e) {
                        log.error("There was an exception attempting to retrieve the INFOrm picklist entries for a refresh", e);
                    }
                }
            }
        }
    }

    /**
     * For the list of given keys, figure out which ones are picklists that should be refreshed. The code will
     * assume that the key will match the pattern in {@link DesktopAPI#PICKLIST_PATTERN}.
     *
     * @param keys A {@link Set} of {@link String} objects that represent all of the keys available in cache.
     * @return A {@link List} of {@link String} objects that are a subset of the keys provided that are picklist entries.
     */
    protected List<String> getRefreshRequests(Set<String> keys) {
        final List<String> refreshPicklistRequests = new ArrayList<>(30);
        for (final String key : keys) {
            // check the defaults pattern first as the regular picklists regex will pick up both
            if (Pattern.matches(DesktopAPI.PICKLIST_DEFAULTS_PATTERN, key)) {
                /*
                 * Skip the defaults pattern because that data is user specific
                 *
                 * Because default picklist data is retrieved with a RACF it can
                 * not be refreshed
                 */
            } else if (Pattern.matches(DesktopAPI.PICKLIST_PATTERN, key)) {
                // get the company division department from the string
                // and add the data to the refreshPicklistRequests list
                refreshPicklistRequests.add(key);

                if (log.isDebugEnabled()) {
                    log.debug("Found the following key for refresh: " + key);
                }
            }
        }
        return refreshPicklistRequests;
    }

    /**
     * Builds a subject to be used to retrieve the inform data. This method is primarily here
     * in order to make the JUnit tests workable outside of a container with JNDI.
     *
     * @param applicationId The application ID that should be set into the {@link Subject} object.
     * @param environment The environment for the {@link Subject} object.
     * @return A {@link Subject} object
     * @throws Exception If there is a problem getting the data needed for the {@link Subject}.
     */
    protected Subject buildSubject(String applicationId, String environment) throws Exception {
        return DesktopAPI.createStaticSubject(applicationId);
    }

    /**
     * Retrieves the picklists for the given criteria.
     *
     * @param criteria The {@link InformSearchCriteria} object that should be used to retrieve picklist information.
     * @param clientId The id of the client that should be used to lookup the picklist data.
     * @param subject The {@link Subject} that should be used to run the execution as
     * @return A map of {@link String} keys and ambiguous objects.
     * @throws Exception If there is a problem looking up the picklist information.
     */
    protected HashMap<String, ?> getPicklistData(InformSearchCriteria criteria, String clientId, String applicationId, Subject subject) throws Exception {
        // default picklists
        HashMap<String, ?> picklists = null;
        // get the client that should be used to default values
        final ApplicationClient client = DesktopAPI.getClientFromClientList(applicationId, clientId);
        if (null != client) {
            picklists = informBiz.getPicklists(criteria, client, applicationId, subject);
        }
        return picklists;
    }

    /**
     * Stores the picklists back into cache.
     *
     * @param picklistData A {@link Map} of picklist data that should be saved.
     * @param criteria A {@link InformSearchCriteria} object that was used to lookup the information.
     * @param applicationId The ID of the application that was used to lookup the picklist.
     * @param clientId The client ID that was used to lookup the picklist.
     */
    protected void storePicklistData(HashMap<String, ?> picklistData, InformSearchCriteria criteria, String applicationId, String clientId) throws Exception {
        DesktopAPI.setPicklistCodes(applicationId, clientId, criteria.getCompanyCode(), criteria.getDivisionCode(), criteria.getDepartmentCode(), picklistData);
    }

    /**
     * Creates an {@link InformSearchCriteria} object based on the key that is passed in. The code
     * assumes that the key matches the pattern defined by {@link DesktopAPI#PICKLIST_PATTERN}.
     *
     * @param key A {@link String} representation of search criteria.
     * @return An {@link InformSearchCriteria} object populated by the key values.
     */
    protected InformSearchCriteria extractCriteria(String key) {
        final InformSearchCriteria criteria = new InformSearchCriteria();

        /*
         * requires the following fields...
         * - company code (index: 2)
         * - department code (index: 4)
         * - division code (index: 3)
         */

        final String[] values = StringUtils.split(StringUtils.remove(key, DesktopAPI.PICKLIST_KEY_SUFFIX), DesktopAPI.KEY_DELIM);
        if (null != values) {
            switch (values.length) {
                case 5:
                    criteria.setDepartmentCode(values[4]);
                case 4:
                    criteria.setDivisionCode(values[3]);
                case 3:
                    criteria.setCompanyCode(values[2]);
                case 2:
                    // client id
                case 1:
                    // application id
            }
        }
        return criteria;
    }

    /**
     * Returns the application ID that was stored in the key.
     *
     * @param key The key that the picklist data is stored under.
     * @return The application ID that was stored in the key.
     */
    protected String extractApplicationId(String key) {
        String applicationId = null;

        /*
         * application id (index: 0)
         */

        final String[] values = StringUtils.split(StringUtils.remove(key, DesktopAPI.PICKLIST_KEY_SUFFIX), DesktopAPI.KEY_DELIM);
        if (null != values) {
            if (values.length > 0) {
                applicationId = values[0];
            }
        }
        return applicationId;
    }

    /**
     * Returns the client ID that was stored in the key.
     *
     * @param key The key that the picklist data is stored under.
     * @return The client ID that was stored in the key.
     */
    protected String extractClientId(String key) {
        String clientId = null;

        /*
         * client id (index: 1)
         */

        final String[] values = StringUtils.split(StringUtils.remove(key, DesktopAPI.PICKLIST_KEY_SUFFIX), DesktopAPI.KEY_DELIM);
        if (null != values) {
            if (values.length > 1) {
                clientId = values[1];
            }
        }
        return clientId;
    }

    /**
     * @param timerService the timerService to set
     */
    public void setTimerService(TimerService timerService) {
        this.timerService = timerService;
    }

    /**
     * @return the timerService
     */
    public TimerService getTimerService() {
        return timerService;
    }

    /**
     * @param refreshInterval the refreshInterval to set
     */
    public void setRefreshInterval(Long refreshInterval) {
        this.refreshInterval = refreshInterval;
    }

    /**
     * @return the refreshInterval
     */
    public Long getRefreshInterval() {
        return refreshInterval;
    }

}
