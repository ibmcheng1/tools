@javax.xml.bind.annotation.XmlSchema(namespace = "http://RPNResetProcess.RPNST101EJB.commercial.bcbssc.com")
package com.bcbssc.services.rpnresetprocess;
