/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.startup;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.security.auth.Subject;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.DesktopStartupBiz;
import com.bcbssc.desktop.biz.EnvironmentBiz;
import com.bcbssc.desktop.biz.cache.CacheRefreshBiz;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.ApplicationClient;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;
import com.bcbssc.domain.valueobject.MenuConfiguration;

/**
 * This class performs all of the necessary transactions to refresh the
 * cached data in dynacache. This includes
 *   - RULES
 */
@Remote
@Stateless(name = "RulesCacheRefresh")
public class RulesCacheRefreshBizBDImpl implements CacheRefreshBiz {

    private static final String TIMER_INFO = "ruleRefreshTimer";

    private static final Log log = LogFactory.getLog(RulesCacheRefreshBizBDImpl.class);

    @Resource
    private TimerService timerService;

    @Resource(name = "rules.cache.refresh.interval")
    private Long refreshInterval;

    @EJB
    private DesktopStartupBiz ruleBiz;

    /**
     * Protected instead of private for JUnit.
     */
    @EJB
    protected EnvironmentBiz environmentBiz;

    @Resource(name = "rules.datatype")
    private String rulesDatatype;

    /**
     * Initializes this EJB with all of the data that it needs
     *
     * @return <code>true</code> if the initialization is successful
     */
    protected boolean initialize() {
        /*
         * At this point, there is no configuration that will fail the
         * initialization, default values will be used for all parameters
         */

        // WAS 6.1 will not be able to do the resource lookup, so we need to do it manually
        if (null == refreshInterval) {
            refreshInterval = environmentBiz.getCommon(EnvironmentObjects.RULES_CACHE_REFRESH_INTERVAL, Long.class);
        }

        if (null == rulesDatatype) {
            rulesDatatype = environmentBiz.getCommon(EnvironmentObjects.RULES_DATATYPE, String.class);
        }

        return true;
    }

    @Override
    public void startCacheRefreshTimer() throws Exception {
        initialize();
        if (log.isInfoEnabled()) {
            log.info("Starting the RULE refresh timer - running every " + (refreshInterval / 1000 / 60) + " minute(s)");
        }
        timerService.createTimer(refreshInterval, refreshInterval, TIMER_INFO);
    }

    @Override
    public void cancelCacheRefreshTimer() throws Exception {
        final Collection<Timer> timers = timerService.getTimers();
        for (final Timer timer : timers) {
            if (TIMER_INFO.equals(timer.getInfo())) {
                timer.cancel();
            }
        }
    }

    @Override
    public void refreshCachedData() throws Exception {
        refreshCachedData(null);
    }

    /**
     * @param timer
     */
    @Timeout
    public void refreshCachedData(Timer timer) {
        if (log.isInfoEnabled()) {
            log.info("Running RULE refresh sequence");
        }

        final boolean initialized = initialize();
        if (initialized) {
            // Figure out which RULE Entries are available in DynaCache as we don't want to refresh things that aren't there
            Set<String> keys = null;
            try {
                keys = DesktopAPI.getCacheWrapper().getKeys();
            } catch (final Exception e) {
                log.error("There was an exception attempting get the keys for the RULEs refresh", e);
            }
            final List<String> refreshRuleRequests = getRefreshRequests(keys);

            // Get a static subject for each environment
            for (final String environment : environmentBiz.getEnvironments()) {
                try {
                    final Subject staticSubject = getSubject(environment);
                    // For each of the criteria object, retrieve the RULE data
                    for (final String key : refreshRuleRequests) {
                        final MenuConfiguration config = extractConfig(key);
                        try {
                            final HashMap<String, ?> menuLinks = getRuleMenuLinks(config, staticSubject);
                            // Store the RULE data back into DynaCache
                            storeRuleData(menuLinks, config);
                        } catch (final Exception e) {
                            log.error("There was an exception attempting to retrieve the RULE entries for a refresh", e);
                        }
                    }
                } catch (final Exception e) {
                    log.error("There was an exception attempting to create a static subject in order to retrieve the RULE entries for a refresh", e);
                }
            }
        }
    }

    /**
     * Returns the subject that should be used for the retrieval of the RULE entries.
     * This is setup as it's own method so that Unit tests can be successfully run
     * without having to run against a container with JNDI.
     *
     * @param environment The environment for the {@link Subject} object.
     * @return A {@link Subject} object.
     * @throws Exception If there is a problem with getting the required data for the subject.
     */
    protected Subject getSubject(String environment) throws Exception {
        return DesktopAPI.createStaticSubject(null);
    }

    /**
     * For the list of given keys, figure out which ones are rules that should be refreshed. The code will
     * assume that the key will match the pattern in {@link DesktopAPI#RULES_PATTERN}.
     *
     * @param keys A {@link Set} of {@link String} objects that represeent all of the keys available in cache.
     * @return A {@link List} of {@link String} objects that are a subset of the keys provided that are rule entries.
     */
    protected List<String> getRefreshRequests(Set<String> keys) {
        final List<String> refreshRuleRequests = new ArrayList<>(10);
        for (final String key : keys) {
            // check to see if it matches the pattern specified in DesktopAPI
            if (Pattern.matches(DesktopAPI.RULES_PATTERN, key)) {
                // get the company division department from the string
                // and add the data to the refreshRuleRequests list
                refreshRuleRequests.add(key);

                if (log.isDebugEnabled()) {
                    log.debug("Found the following key for refresh: " + key);
                }
            }
        }
        return refreshRuleRequests;
    }

    /**
     * Retrieves the rule entries for the given criteria.
     *
     * @param config The {@link MenuConfiguration} object that represents the criteria for searching for links
     * @param staticSubject The {@link Subject} that should be used to run the execution as.
     * @return A {@link Map} of {@link String} keys and ambiguous objects.
     * @throws Exception If there is a problem looking up the rule entries.
     */
    protected HashMap<String, ?> getRuleMenuLinks(MenuConfiguration config, Subject staticSubject) throws Exception {
        // default menu links
        HashMap<String, ?> menuLinks = null;
        // get the static subject to run the rules request...
        final ApplicationClient subjectClient = SubjectUtils.getClient(staticSubject);
        final String applicationId = config.getApplicationId();
        subjectClient.setAppId(applicationId);
        SubjectUtils.setClient(staticSubject, subjectClient);
        // get the client that should be used to default values
        final ApplicationClient client = DesktopAPI.getClientFromClientList(applicationId, config.getClientId());
        if (null != client) {
            menuLinks = ruleBiz.getRulesEntries(config, client, staticSubject);
        }
        return menuLinks;
    }

    /**
     * Stores the rules back into cache.
     *
     * @param menuLinks A map of rule entries that should be saved.
     * @param config A {@link MenuConfiguration} object that was used to lookup the rule entries.
     */
    protected void storeRuleData(HashMap<String, ?> menuLinks, MenuConfiguration config) throws Exception {
        DesktopAPI.setRulesEntries(config.getApplicationId(), config.getAltRpn(), config.getClientId(), config.getCompanyCode(), config.getDivisionCode(), config.getDepartmentCode(), config.getDefaultRegion(), menuLinks);
    }

    /**
     * Extract as much of the menu configuration as possible out the data in the key
     *
     * @param key The key to parse for data
     * @return A MenuConfiguration object with as much of the data filled out as possible.
     */
    protected MenuConfiguration extractConfig(String key) {
        final MenuConfiguration config = new MenuConfiguration();

        /*
         * The following fields can come out of the key...
         * - rpn (index: 1)
         * - application Id (index: 0)
         * - client Id (index: 2)
         * - company (index: 3)
         * - division (index: 4)
         * - department (index: 5)
         * - default region (index: 6)
         */
        final String[] values = StringUtils.split(StringUtils.remove(key, DesktopAPI.RULES_KEY_SUFFIX), DesktopAPI.KEY_DELIM);
        if (null != values) {
            /*
             * Switches will continue through the cases until it finds a break.
             *
             * If the length is 6 then without a break, it will set all of the
             * values in the config that it can get out of the key except region.
             */
            switch (values.length) {
                case 7:
                    config.setDefaultRegion(values[6]);
                case 6:
                    config.setDepartmentCode(values[5]);
                case 5:
                    config.setDivisionCode(values[4]);
                case 4:
                    config.setCompanyCode(values[3]);
                case 3:
                    config.setClientId(values[2]);
                case 2:
                    config.setAltRpn(values[1]);
                case 1:
                    config.setApplicationId(values[0]);
            }

        }

        /*
         * The following fields can not come out of the key...
         * - plan code (885)
         * - role code (??)
         * - data type (rulesDatatype)
         */
        config.setPlanCode("885");
        config.setRoleCode(StringUtils.EMPTY);
        config.setDataType(rulesDatatype);

        return config;
    }

    /**
     * @param refreshInterval the refreshInterval to set
     */
    public void setRefreshInterval(Long refreshInterval) {
        this.refreshInterval = refreshInterval;
    }

    /**
     * @return the refreshInterval
     */
    public Long getRefreshInterval() {
        return refreshInterval;
    }

    /**
     * @return the timerService
     */
    public TimerService getTimerService() {
        return timerService;
    }

    /**
     * @param timerService the timerService to set
     */
    public void setTimerService(TimerService timerService) {
        this.timerService = timerService;
    }

}
