/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2006 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.desktop.startup;

import java.util.HashMap;

import com.bcbssc.domain.entity.Subsystem;
/**
 *
 * The interface that describes the behavior of DAO's that can get RPN's
 * for a given subsystem (CES/membership, PIMS, TMCS, etc.) based on an primary RPN
 * RPN value.
 */
public interface SubsystemRpnDAO{
    /**
     * <p>
     * Get a Map object containing all the subsystem rpn's,
     * keyed by CAPITALIZED string (like "CISI", "PIMS", etc.), for the given
     * "key" rpn (called the AMMS rpn at the data store level?)
     * </p>
     * @param keyRpn The key/primary rpn
     * @return A <code>java.util.Map</code> of rpns per subsystem name
     * @throws Exception If any required parameters are null or empty.
     */
    public HashMap<String, Subsystem> getSubsystemRpns(String keyRpn) throws Exception;    
}
