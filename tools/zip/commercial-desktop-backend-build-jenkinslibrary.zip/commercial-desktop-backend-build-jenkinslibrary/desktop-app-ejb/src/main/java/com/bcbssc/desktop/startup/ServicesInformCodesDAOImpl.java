/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.startup;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.jws.HandlerChain;
import javax.xml.ws.WebServiceRef;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.util.services.BaseServiceIntegrator;
import com.bcbssc.desktop.util.services.interceptor.ServicesDataAccessExceptionInterceptor;
import com.bcbssc.domain.entity.InformSearchCriteria;
import com.bcbssc.domain.entity.codes.Code;
import com.bcbssc.domain.entity.codes.inform.CategoryCode;
import com.bcbssc.domain.entity.codes.inform.ContactTypeCode;
import com.bcbssc.domain.entity.codes.inform.RequestReasonCode;
import com.bcbssc.domain.entity.codes.inform.ResolutionCode;
import com.bcbssc.domain.entity.codes.inform.ResponseCode;
import com.bcbssc.domain.entity.codes.inform.SeverityCode;
import com.bcbssc.domain.entity.codes.inform.StatusCode;
import com.bcbssc.domain.entity.codes.inform.TransferCode;
import com.bcbssc.domain.entity.codes.inform.TypedCode;
import com.bcbssc.services.informentryvalues.InformEntryValuesInformEntry;
import com.bcbssc.services.informentryvalues.InformEntryValuesInput;
import com.bcbssc.services.informentryvalues.InformEntryValuesOutput;
import com.bcbssc.services.informentryvalues.InformEntryValuesService;
import com.bcbssc.services.informentryvalues.InformEntryValuesServiceService;

/**
 * The DAO implementation that retrieve INFOrm code beans.
 */
@Stateless
@Local
@Interceptors({ServicesDataAccessExceptionInterceptor.class})
public class ServicesInformCodesDAOImpl
implements InformCodesDAO {

    private static final Log log = LogFactory.getLog(ServicesInformCodesDAOImpl.class);

    private static final String DEFAULT_CATEGORY_CODES_TABLE_ID = "CAT";
    private static final String DEFAULT_CATEGORY_CODES_TABLE_INDICATOR = "M";

    private static final String DEFAULT_CONTACT_TYPE_TABLE_ID = "SCD";
    private static final String DEFAULT_CONTACT_TYPE_TABLE_INDICATOR = "M";

    private static final String MORE_DATA_INDICATOR_YES ="Y";

    /*
     * FROM POC - Left for reference.
     *
	private static final String DEFAULT_LOCATION_TABLE_ID = "ELC";
	private static final String DEFAULT_LOCATION_TABLE_INDICATOR = "P";
	private static final Class<? extends Code> LOCATION_RETURN_CLASS = LocationCode.class;
     */

    private static final String DEFAULT_REQUEST_REASON_CODE_TABLE_ID = "RRC";
    private static final String DEFAULT_REQUEST_REASON_CODE_TABLE_INDICATOR = "P";

    private static final String DEFAULT_RESOLUTION_CODE_TABLE_ID = "RSC";
    private static final String DEFAULT_RESOLUTION_CODE_TABLE_INDICATOR = "P";

    /*
     * FROM POC - Left for reference.
     *
     * Get all of the available Respond By for the given search criteria
     * table = "VINFRBY$"
     * qualified name for service "RBYP"
	protected static final String DEFAULT_RESPOND_BY_CODE_TABLE_ID = "RBY";
	protected static final String DEFAULT_RESPOND_BY_CODE_TABLE_INDICATOR = "P";
	protected static final Class<? extends Code> RESPOND_BY_CODE_CLASS = RespondByCode.class;
     */

    protected static final String DEFAULT_RESPONSE_CODE_TABLE_ID = "RDC";
    protected static final String DEFAULT_RESPONSE_CODE_TABLE_INDICATOR = "M";

    protected static final String DEFAULT_SEVERITY_CODE_TABLE_ID = "SEV";
    protected static final String DEFAULT_SEVERITY_CODE_TABLE_INDICATOR = "M";

    protected static final String DEFAULT_STATUS_CODE_TABLE_ID = "STA";
    protected static final String DEFAULT_STATUS_CODE_TABLE_INDICATOR = "M";

    protected static final String DEFAULT_TRANSFER_CODE_TABLE_ID = "SEC";
    protected static final String DEFAULT_TRANSFER_CODE_TABLE_INDICATOR = "W";

    @HandlerChain(file = "../dao/services/handlerchain/soax-service-handler-chain.xml")
    @WebServiceRef(wsdlLocation = "META-INF/wsdl/InformEntryValues.wsdl", value=InformEntryValuesServiceService.class)
    private InformEntryValuesService service;

    /**
     * Get all of the available Category Codes for the given search criteria
     * table = "VINFCAT$"
     * qualified name for service = "CATM"
     * list contains type com.bcbssc.domain.entity.codes.inform.CategoryCode
     * @param criteria
     * @return
     */
    @Override
    public List<CategoryCode> getCategoryCodes(InformSearchCriteria criteria) throws Exception {
        if (StringUtils.isEmpty(criteria.getTableId())) {
            criteria.setTableId(DEFAULT_CATEGORY_CODES_TABLE_ID);
        }
        if (StringUtils.isEmpty(criteria.getTableIndicatorRequested())) {
            criteria.setTableIndicatorRequested(DEFAULT_CATEGORY_CODES_TABLE_INDICATOR);
        }
        return findAllBySearchCriteria(new InformCodesServiceIntegrator<CategoryCode>(service) {
            @Override
            protected CategoryCode getCodeObject() {
                return new CategoryCode();
            }
        }, criteria);
    }

    /**
     * Get all of the available Contact Type Codes for the given search criteria
     * table = "VINFSCD$"
     * qualified name for service = "SCDM"
     * list contains type com.bcbssc.domain.entity.codes.inform.ContactTypeCode
     * @param criteria
     * @return
     */
    @Override
    public List<ContactTypeCode> getContactTypeCodes(InformSearchCriteria criteria) throws Exception {
        if (StringUtils.isEmpty(criteria.getTableId())) {
            criteria.setTableId(DEFAULT_CONTACT_TYPE_TABLE_ID);
        }
        if (StringUtils.isEmpty(criteria.getTableIndicatorRequested())) {
            criteria.setTableIndicatorRequested(DEFAULT_CONTACT_TYPE_TABLE_INDICATOR);
        }
        return findAllBySearchCriteria(new InformCodesServiceIntegrator<ContactTypeCode>(service) {
            @Override
            protected ContactTypeCode getCodeObject() {
                return new ContactTypeCode();
            }
        }, criteria);
    }

    /**
     * Get all of the available Request Reason Codes for the given search criteria
     * table = "VINFRRCZ"
     * qualified name for service = "RRCP"
     * list contains type com.bcbssc.domain.entity.codes.inform.RequestReasonCode
     * @param criteria
     * @return
     */
    @Override
    public List<RequestReasonCode> getRequestReasonCodes(InformSearchCriteria criteria) throws Exception {
        if (StringUtils.isEmpty(criteria.getTableId())) {
            criteria.setTableId(DEFAULT_REQUEST_REASON_CODE_TABLE_ID);
        }
        if (StringUtils.isEmpty(criteria.getTableIndicatorRequested())) {
            criteria.setTableIndicatorRequested(DEFAULT_REQUEST_REASON_CODE_TABLE_INDICATOR);
        }
        return findAllBySearchCriteria(new InformCodesServiceIntegrator<RequestReasonCode>(service) {
            @Override
            protected RequestReasonCode getCodeObject() {
                return new RequestReasonCode();
            }
        }, criteria);
    }

    /**
     * Get all of the available Resolution Codes for the given search criteria
     * table = "VINFRSCZ"
     * qualified name for service "RSCP"
     * list contains type com.bcbssc.domain.entity.codes.inform.ResolutionCode
     * @param criteria
     * @return
     */
    @Override
    public List<ResolutionCode> getResolutionCodes(InformSearchCriteria criteria) throws Exception {
        if (StringUtils.isEmpty(criteria.getTableId())) {
            criteria.setTableId(DEFAULT_RESOLUTION_CODE_TABLE_ID);
        }
        if (StringUtils.isEmpty(criteria.getTableIndicatorRequested())) {
            criteria.setTableIndicatorRequested(DEFAULT_RESOLUTION_CODE_TABLE_INDICATOR);
        }
        return findAllBySearchCriteria(new InformCodesServiceIntegrator<ResolutionCode>(service) {
            @Override
            protected ResolutionCode getCodeObject() {
                return new ResolutionCode();
            }
        }, criteria);
    }

    /**
     * Get all of the available Response Codes for the given search criteria
     * table = "VINFRCD$"
     * qualified name for service "RCDM"
     * list contains type com.bcbssc.domain.entity.codes.inform.ResponseCode
     * @param criteria
     * @return
     */
    @Override
    public List<ResponseCode> getResponseCodes(InformSearchCriteria criteria) throws Exception {
        if (StringUtils.isEmpty(criteria.getTableId())) {
            criteria.setTableId(DEFAULT_RESPONSE_CODE_TABLE_ID);
        }
        if (StringUtils.isEmpty(criteria.getTableIndicatorRequested())) {
            criteria.setTableIndicatorRequested(DEFAULT_RESPONSE_CODE_TABLE_INDICATOR);
        }
        return findAllBySearchCriteria(new InformCodesServiceIntegrator<ResponseCode>(service) {
            @Override
            protected ResponseCode getCodeObject() {
                return new ResponseCode();
            }
        }, criteria);
    }

    /**
     * Get all of the available Severity Codes for the given search criteria
     * table = "VINFSEV$"
     * qualified name for service = "SEVM"
     * list contains type com.bcbssc.domain.entity.codes.inform.SeverityCode
     * @param criteria
     * @return
     */
    @Override
    public List<SeverityCode> getSeverityCodes(InformSearchCriteria criteria) throws Exception {
        if (StringUtils.isEmpty(criteria.getTableId())) {
            criteria.setTableId(DEFAULT_SEVERITY_CODE_TABLE_ID);
        }
        if (StringUtils.isEmpty(criteria.getTableIndicatorRequested())) {
            criteria.setTableIndicatorRequested(DEFAULT_SEVERITY_CODE_TABLE_INDICATOR);
        }
        return findAllBySearchCriteria(new InformCodesServiceIntegrator<SeverityCode>(service) {
            @Override
            protected boolean isEntryMappable(InformEntryValuesInformEntry serviceInformEntry) {
                return (StringUtils.isNotEmpty(serviceInformEntry.getEntryCode()) || StringUtils.isNotEmpty(serviceInformEntry.getEntryCodeDescription()));
            }
            @Override
            protected SeverityCode getCodeObject() {
                return new SeverityCode();
            }
        }, criteria);
    }

    /**
     * Get all of the available Status Codes for the given search Criteria
     * table = "VINFSTA$"
     * qualified name for service = "STAM"
     * list contains type com.bcbssc.domain.entity.codes.inform.StatusCode
     * @param criteria
     * @return
     */
    @Override
    public List<StatusCode> getStatusCodes(InformSearchCriteria criteria) throws Exception {
        if (StringUtils.isEmpty(criteria.getTableId())) {
            criteria.setTableId(DEFAULT_STATUS_CODE_TABLE_ID);
        }
        if (StringUtils.isEmpty(criteria.getTableIndicatorRequested())) {
            criteria.setTableIndicatorRequested(DEFAULT_STATUS_CODE_TABLE_INDICATOR);
        }
        return findAllBySearchCriteria(new InformCodesServiceIntegrator<StatusCode>(service) {
            @Override
            protected StatusCode getCodeObject() {
                return new StatusCode();
            }
        }, criteria);
    }

    /**
     * Get all of the available Transfer Codes for the given search criteria
     * table = "VINFSECW"
     * qualified name for service "SECW"
     * list contains type com.bcbssc.domain.entity.codes.inform.TransferCode
     * @param criteria
     * @return
     */
    @Override
    public List<TransferCode> getTransferCodes(InformSearchCriteria criteria) throws Exception {
        if (StringUtils.isEmpty(criteria.getTableId())) {
            criteria.setTableId(DEFAULT_TRANSFER_CODE_TABLE_ID);
        }
        if (StringUtils.isEmpty(criteria.getTableIndicatorRequested())) {
            criteria.setTableIndicatorRequested(DEFAULT_TRANSFER_CODE_TABLE_INDICATOR);
        }
        return findAllBySearchCriteria(new InformCodesServiceIntegrator<TransferCode>(service) {
            @Override
            protected TransferCode getCodeObject() {
                return new TransferCode();
            }
        }, criteria);
    }

    public <C extends Code> List<C> findAllBySearchCriteria(InformCodesServiceIntegrator<C> serviceIntegrator, InformSearchCriteria criteria) throws Exception {
        final ArrayList<C> results = new ArrayList<C>();
        boolean isMore = false;
        do {
            final InformCodesResponse<C> response = serviceIntegrator.consumeService(criteria);
            isMore = response.isMore();
            final List<C> resultsList = response.getCodesList();
            if ((resultsList.size() > 0) && isMore) {
                criteria.setLastEntry(resultsList.get(resultsList.size() - 1));
            }
            results.addAll(resultsList);
        } while(isMore);
        return results;
    }

    protected static abstract class InformCodesServiceIntegrator<S extends Code> extends BaseServiceIntegrator<InformEntryValuesService, InformSearchCriteria, InformEntryValuesInput, InformEntryValuesOutput, InformCodesResponse<S>>{

        private InformEntryValuesService service;

        public InformCodesServiceIntegrator(InformEntryValuesService service) {
            this.service = service;
        }

        @Override
        public InformEntryValuesService getService() {
            return this.service;
        }

        @Override
        public InformEntryValuesOutput invokeService(InformEntryValuesInput input, InformEntryValuesService service) throws Exception {
            return service.getInformEntryValues(input);
        }

        @Override
        public InformEntryValuesInput mapInput(InformSearchCriteria searchCriteria) {
            final InformEntryValuesInput input = new InformEntryValuesInput();
            input.setCompanyCode(StringUtils.trimToEmpty(searchCriteria.getCompanyCode()));
            input.setDefaultCompanyCode(StringUtils.trimToEmpty(searchCriteria.getDefaultCompanyCode()));
            input.setDefaultDepartmentCode(StringUtils.trimToEmpty(searchCriteria.getDefaultDepartmentCode()));
            input.setDefaultDivisionCode(StringUtils.trimToEmpty(searchCriteria.getDefaultDivisionCode()));
            input.setDepartmentCode(StringUtils.trimToEmpty(searchCriteria.getDepartmentCode()));
            input.setDivisionCode(StringUtils.trimToEmpty(searchCriteria.getDivisionCode()));
            input.setPageIndicator(StringUtils.trimToEmpty(searchCriteria.getPageIndicator()));
            if(searchCriteria.getLastEntry() != null) {
                input.setPreviousLastEntryCode(StringUtils.trimToEmpty(searchCriteria.getLastEntry().getCode()));
                input.setPreviousLastEntryCodeDesc(StringUtils.trimToEmpty(searchCriteria.getLastEntry().getDescription()));
            }
            input.setRole(StringUtils.trimToEmpty(searchCriteria.getRole()));
            input.setSortedByIndicator(StringUtils.trimToEmpty(searchCriteria.getSortedByIndicator()));
            input.setSystemPrefix(StringUtils.trimToEmpty(searchCriteria.getSystemPrefix()));
            input.setTableId(StringUtils.trimToEmpty(searchCriteria.getTableId()));
            input.setTableIndicatorRequested(StringUtils.trimToEmpty(searchCriteria.getTableIndicatorRequested()));
            return input;
        }

        @Override
        public InformCodesResponse<S> mapOutput(InformEntryValuesOutput output) {
            final InformCodesResponse<S> informCodesResponse = new InformCodesResponse<>();
            final List<S> codeList = new ArrayList<>();
            if (null != output) {
                informCodesResponse.setMore(StringUtils.trimToEmpty(output.getMoreDataIndicator()).equals(MORE_DATA_INDICATOR_YES));
                final List<InformEntryValuesInformEntry> entries = output.getInformEntry().getInformEntryValuesInformEntry();
                for (final InformEntryValuesInformEntry serviceInformEntry: entries) {
                    if (this.isEntryMappable(serviceInformEntry)) {
                        final S code = getCodeObject();
                        code.setCode(serviceInformEntry.getEntryCode());
                        code.setDescription(serviceInformEntry.getEntryCodeDescription());
                        if(code instanceof TypedCode) {
                            ((TypedCode)code).setType(serviceInformEntry.getEntryTypeDcnIndicator());
                        }
                        codeList.add(code);
                    }
                }
                informCodesResponse.setCodesList(codeList);
            }
            return informCodesResponse;
        }

        protected boolean isEntryMappable(InformEntryValuesInformEntry serviceInformEntry) {
            return StringUtils.isNotEmpty(serviceInformEntry.getEntryCode());
        }

        protected abstract S getCodeObject();

        @Override
        public void setService(InformEntryValuesService service) {
            this.service = service;
        }

        @Override
        protected String getServiceName() {
            return InformEntryValuesService.class.getSimpleName();
        }

    }

}
