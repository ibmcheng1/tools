
package com.bcbssc.services.managedcarepatientlist;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ManagedCarePatientListOutput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ManagedCarePatientListOutput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="applicationMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="serviceMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="serviceMessageCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="systemMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="groupNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="locationCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="patientRecord" type="{http://ManagedCarePatientList.THLST101EJB.health.bcbssc.com}ArrayOfManagedCarePatientListPatientRecord"/>
 *         &lt;element name="ebizReplyAbendcode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ebizReplyStatus" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ebizReplyStatusMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ManagedCarePatientListOutput", propOrder = {
    "applicationMessage",
    "serviceMessage",
    "serviceMessageCode",
    "systemMessage",
    "groupNumber",
    "locationCode",
    "patientRecord",
    "ebizReplyAbendcode",
    "ebizReplyStatus",
    "ebizReplyStatusMessage"
})
public class ManagedCarePatientListOutput {

    @XmlElement(required = true, nillable = true)
    protected String applicationMessage;
    @XmlElement(required = true, nillable = true)
    protected String serviceMessage;
    @XmlElement(required = true, nillable = true)
    protected String serviceMessageCode;
    @XmlElement(required = true, nillable = true)
    protected String systemMessage;
    @XmlElement(required = true, nillable = true)
    protected String groupNumber;
    @XmlElement(required = true, nillable = true)
    protected String locationCode;
    @XmlElement(required = true, nillable = true)
    protected ArrayOfManagedCarePatientListPatientRecord patientRecord;
    @XmlElement(required = true, nillable = true)
    protected String ebizReplyAbendcode;
    protected int ebizReplyStatus;
    @XmlElement(required = true, nillable = true)
    protected String ebizReplyStatusMessage;

    /**
     * Gets the value of the applicationMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationMessage() {
        return applicationMessage;
    }

    /**
     * Sets the value of the applicationMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationMessage(String value) {
        this.applicationMessage = value;
    }

    /**
     * Gets the value of the serviceMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceMessage() {
        return serviceMessage;
    }

    /**
     * Sets the value of the serviceMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceMessage(String value) {
        this.serviceMessage = value;
    }

    /**
     * Gets the value of the serviceMessageCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceMessageCode() {
        return serviceMessageCode;
    }

    /**
     * Sets the value of the serviceMessageCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceMessageCode(String value) {
        this.serviceMessageCode = value;
    }

    /**
     * Gets the value of the systemMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystemMessage() {
        return systemMessage;
    }

    /**
     * Sets the value of the systemMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystemMessage(String value) {
        this.systemMessage = value;
    }

    /**
     * Gets the value of the groupNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupNumber() {
        return groupNumber;
    }

    /**
     * Sets the value of the groupNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupNumber(String value) {
        this.groupNumber = value;
    }

    /**
     * Gets the value of the locationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationCode() {
        return locationCode;
    }

    /**
     * Sets the value of the locationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationCode(String value) {
        this.locationCode = value;
    }

    /**
     * Gets the value of the patientRecord property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfManagedCarePatientListPatientRecord }
     *     
     */
    public ArrayOfManagedCarePatientListPatientRecord getPatientRecord() {
        return patientRecord;
    }

    /**
     * Sets the value of the patientRecord property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfManagedCarePatientListPatientRecord }
     *     
     */
    public void setPatientRecord(ArrayOfManagedCarePatientListPatientRecord value) {
        this.patientRecord = value;
    }

    /**
     * Gets the value of the ebizReplyAbendcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEbizReplyAbendcode() {
        return ebizReplyAbendcode;
    }

    /**
     * Sets the value of the ebizReplyAbendcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEbizReplyAbendcode(String value) {
        this.ebizReplyAbendcode = value;
    }

    /**
     * Gets the value of the ebizReplyStatus property.
     * 
     */
    public int getEbizReplyStatus() {
        return ebizReplyStatus;
    }

    /**
     * Sets the value of the ebizReplyStatus property.
     * 
     */
    public void setEbizReplyStatus(int value) {
        this.ebizReplyStatus = value;
    }

    /**
     * Gets the value of the ebizReplyStatusMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEbizReplyStatusMessage() {
        return ebizReplyStatusMessage;
    }

    /**
     * Sets the value of the ebizReplyStatusMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEbizReplyStatusMessage(String value) {
        this.ebizReplyStatusMessage = value;
    }

}
