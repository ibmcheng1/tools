/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2016 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.inform;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.security.auth.Subject;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.biz.EnvironmentBiz;
import com.bcbssc.desktop.biz.inform.InformBD;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.jndi.JndiUtils;
import com.bcbssc.domain.entity.ApplicationClient;
import com.bcbssc.domain.entity.InformIdentification;
import com.bcbssc.domain.entity.auth.RacfIdPrincipal;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;
import com.bcbssc.domain.entity.inform.InformRecord;
import com.bcbssc.domain.entity.inform.lines.AbstractInformRecordLine;
import com.bcbssc.domain.entity.inform.lines.InformException;
import com.bcbssc.domain.entity.inform.lines.InformInquiryLine;
import com.bcbssc.domain.entity.inform.lines.InformKeyCrossReferenceLine;
import com.bcbssc.domain.entity.inform.lines.InformMessage;
import com.bcbssc.domain.entity.inform.lines.InformMessageImpl;
import com.bcbssc.domain.entity.inform.lines.InformRequestLine;
import com.bcbssc.domain.entity.inform.lines.InformResponseLine;
import com.bcbssc.domain.entity.inform.lines.InformTransferLine;
import com.bcbssc.domain.entity.inform.lines.InformTransferTrackingLine;
import com.bcbssc.util.logger.audit.RollingFileHandler;

/**
 * Used to send INFOrm messages to the host and if needed, maintaining an audit file.
 */
@Stateless
@Remote
public class InformBDBizImpl implements InformBD {

    private static final String ENROLLMENT_AUDIT_SUCCESS_LOGGER = "enrollment.audit.inform.success";
    private static final String ENROLLMENT_AUDIT_FAILURE_LOGGER = "enrollment.audit.inform.failure";
    private static final String BASE_AUDIT_SUCCESS_LOGGER = "base.audit.inform.success";
    private static final String BASE_AUDIT_FAILURE_LOGGER = "base.audit.inform.failure";

    private static Logger enrollmentAuditSuccessLogger = Logger.getLogger(ENROLLMENT_AUDIT_SUCCESS_LOGGER);
    private static Logger enrollmentAuditFailureLogger = Logger.getLogger(ENROLLMENT_AUDIT_FAILURE_LOGGER);
    private static Logger baseAuditSuccessLogger = Logger.getLogger(BASE_AUDIT_SUCCESS_LOGGER);
    private static Logger baseAuditFailureLogger = Logger.getLogger(BASE_AUDIT_FAILURE_LOGGER);

    private static final String LOG_TIMESTAMP_FORMAT = "yyyy-MM-dd-HH.mm.ss.SSSSSS";
    private static final String HH_MM_SS_WITH_DOTS = "HH.mm.ss";
    private static final String YYYY_MM_DD_WITH_DASHES = "yyyy-MM-dd";
    private static final String ACTION_ADD = "A";
    private static final String ACTION_MODIFY = "M";
    private static final String DEFAULT_CONVERT_AMOUNT = "00000000000";

    private static final String NPI_UNKNOWN = "NPI UNKNOWN";

    private static final String STATUS_TYPE_OPEN = "OP";

    /**
     * max lines of InformationMessages per group
     */
    private static final int MAX_LINE_COUNT = 197;

    private static final Log log = LogFactory.getLog(InformBDBizImpl.class);
    
    @EJB
    private SubmitInformDAO informMessenger;

    static {
        // Initialize the success and fail log files for enrollment messages
        String enrollmentAuditSuccessFilePath = null;
        String enrollmentAuditFailureFilePath = null;
        String baseAuditSuccessFilePath = null;
        String baseAuditFailureFilePath = null;
        

        // This outer try is simply to avoid an exception from the 
        // initializer
        try {
            try {
                final EnvironmentBiz environmentBiz = JndiUtils.getEnvironmentBiz();
                enrollmentAuditSuccessFilePath = environmentBiz.getCommon(EnvironmentObjects.ENROLLMENT_AUDIT_INFORM_SUCCESS_PATH, String.class);
                enrollmentAuditFailureFilePath = environmentBiz.getCommon(EnvironmentObjects.ENROLLMENT_AUDIT_INFORM_FAILURE_PATH, String.class);
                
                baseAuditSuccessFilePath = environmentBiz.getCommon(EnvironmentObjects.BASE_AUDIT_INFORM_SUCCESS_PATH, String.class);
                baseAuditFailureFilePath = environmentBiz.getCommon(EnvironmentObjects.BASE_AUDIT_INFORM_FAILURE_PATH, String.class);

                File enrollmentAuditSuccessFile = new File(enrollmentAuditSuccessFilePath);
                File enrollmentAuditFailureFile = new File(enrollmentAuditFailureFilePath);
                File baseAuditSuccessFile = new File(baseAuditSuccessFilePath);
                File baseAuditFailureFile = new File(baseAuditFailureFilePath);

                // if path components of the audit files are missing then create them
                File enrollmentAuditSuccessDir = enrollmentAuditSuccessFile.getParentFile();
                File enrollmentAuditFailureDir = enrollmentAuditFailureFile.getParentFile();
                File baseAuditSuccessDir = baseAuditSuccessFile.getParentFile();
                File baseAuditFailureDir = baseAuditFailureFile.getParentFile();

                if (enrollmentAuditSuccessDir != null) {
                    enrollmentAuditSuccessDir.mkdirs();
                }

                if (enrollmentAuditFailureDir != null) {
                    enrollmentAuditFailureDir.mkdirs();
                }

                if (baseAuditSuccessDir != null) {
                    baseAuditSuccessDir.mkdirs();
                }

                if (baseAuditFailureDir != null) {
                    baseAuditFailureDir.mkdirs();
                }
            } catch (IllegalStateException ise) {
                log.error("Unable to read jndi values for inform audit log", ise);

                throw ise;

            } catch (NumberFormatException nfe) {
                log.error("Inform audit file size or count have numeric conversion problems", nfe);

                throw nfe;
            } catch (SecurityException se) {
                log.error("Inform audit file unable to read or write components of audit path");
            }

            RollingFileHandler enrollmentAuditSuccessFileHandler = null;
            RollingFileHandler enrollmentAuditFailureFileHandler = null;
            RollingFileHandler baseAuditSuccessFileHandler = null;
            RollingFileHandler baseAuditFailureFileHandler = null;

            enrollmentAuditSuccessFileHandler = new RollingFileHandler(enrollmentAuditSuccessFilePath, "day");
            enrollmentAuditFailureFileHandler = new RollingFileHandler(enrollmentAuditFailureFilePath, "day");
            baseAuditSuccessFileHandler = new RollingFileHandler(baseAuditSuccessFilePath, "day", 10);
            baseAuditFailureFileHandler = new RollingFileHandler(baseAuditFailureFilePath, "day", 10);

            enrollmentAuditSuccessFileHandler.setFormatter(new SimpleFormatter());
            enrollmentAuditFailureFileHandler.setFormatter(new SimpleFormatter());
            baseAuditSuccessFileHandler.setFormatter(new SimpleFormatter());
            baseAuditFailureFileHandler.setFormatter(new SimpleFormatter());

            enrollmentAuditSuccessLogger.addHandler(enrollmentAuditSuccessFileHandler);
            enrollmentAuditFailureLogger.addHandler(enrollmentAuditFailureFileHandler);
            baseAuditSuccessLogger.addHandler(baseAuditSuccessFileHandler);
            baseAuditFailureLogger.addHandler(baseAuditFailureFileHandler);

            enrollmentAuditSuccessLogger.setLevel(Level.ALL);
            enrollmentAuditFailureLogger.setLevel(Level.ALL);
            baseAuditSuccessLogger.setLevel(Level.ALL);
            baseAuditFailureLogger.setLevel(Level.ALL);

            enrollmentAuditSuccessLogger.setUseParentHandlers(false);
            enrollmentAuditFailureLogger.setUseParentHandlers(false);
            baseAuditSuccessLogger.setUseParentHandlers(false);
            baseAuditFailureLogger.setUseParentHandlers(false);
            
        } catch (Exception someException) {
            // logging will go to parent handlers(server log)
            log.error("Error setting up enrollment audit success/failure files, logging will go to parent handlers (server log)");
        }
    }

    @Override
    public String sendApplicationInformMessage(InformRecord record, boolean doTransfer, boolean doTracking, Subject subject) throws InformException {
        return createAndSendApplicationInformMessage(record, doTransfer, doTracking, Boolean.FALSE, subject);
    }

    @Override
    public String sendUpdatedApplicationInformMessage(InformRecord record, boolean doTransfer, boolean doTracking, Subject subject) throws InformException {
        return createAndSendApplicationInformMessage(record, doTransfer, doTracking, Boolean.TRUE, subject);
    }

    @Override
    public String sendInformMessage(InformRecord record, boolean doTransfer, boolean doTracking, Subject subject) throws InformException {
        String correlationId = null;
        InformMessage informMessage = null;
        try {
            informMessage = createInformMessage(record, doTransfer, doTracking, Boolean.FALSE, subject);
            correlationId = sendInformMessage(informMessage, subject);
            //success log, if exception is not thrown at this point then assume it was successful
            this.createBaseAudit(informMessage, Boolean.TRUE);
        } catch (InformException ie) {
            //failure log
            this.createBaseAudit(informMessage, Boolean.FALSE);
            throw ie;
        }
        return correlationId;
    }

    /**
     * Creates, Sends and Audits the application inform message
     * @param record The Inform record to send
     * @param doTransfer boolean, indicates transfer
     * @param doTracking boolean, indicates tracking
     * @param forUpdate boolean, indicates if we are adding a new inform record or modifying an existing record
     * @param subject
     * @return correlation ID string
     * @throws InformException
     */
    private String createAndSendApplicationInformMessage(InformRecord record, boolean doTransfer, boolean doTracking, boolean forUpdate, Subject subject) throws InformException {
        String correlationId = null;
        InformMessage informMessage = null;
        try {
            informMessage = createInformMessage(record, doTransfer, doTracking, forUpdate, subject);
            correlationId = sendInformMessage(informMessage, subject);
            //success log, if exception is not thrown at this point then assume it was successful
            this.createEnrolmentAudit(informMessage, Boolean.TRUE);
        } catch (InformException ie) {
            //failure log
            this.createEnrolmentAudit(informMessage, Boolean.FALSE);
            throw ie;
        }
        return correlationId;
    }

    /**
     * Creates the Inform Message object from the Inform Record to send to MQ
     * @param record The Inform Record to send
     * @param doTransfer boolean, indicates transfer
     * @param doTracking boolean, indicates tracking
     * @param forUpdate boolean, indicates if we are adding a new inform record or modifying an existing record
     * @param subject
     * @return Inform Message object
     * @throws InformException if an error occurs attempting to send the message
     */
    private InformMessage createInformMessage(InformRecord record, Boolean doTransfer, Boolean doTracking, Boolean forUpdate, Subject subject) throws InformException {

        InformMessage informMessage = new InformMessageImpl();

        String actionRequested = StringUtils.EMPTY;

        ApplicationClient client = SubjectUtils.getClient(subject);
        String informTransaction = client.getInformTrans();
        InformIdentification informIdentification = SubjectUtils.getInformId(subject);

        DateFormat datestamp = new SimpleDateFormat(YYYY_MM_DD_WITH_DASHES);
        DateFormat timestamp = new SimpleDateFormat(LOG_TIMESTAMP_FORMAT);
        Date currentDate = new Date();
        String logTimestamp = null;

        if (forUpdate) {
            actionRequested = ACTION_MODIFY;
        } else {
            actionRequested = ACTION_ADD;
            logTimestamp = timestamp.format(currentDate);
        }

        String systemPrefix = informTransaction;

        String racfId = StringUtils.upperCase(SubjectUtils.getFirstPrincipalName(subject, RacfIdPrincipal.class));

        String assignedOwnerCompanyCode;
        String assignedOwnerDivisionCode;
        String assignedOwnerDepartmentCode;
        String assignedOwnerEmployeeId;

        if (doTransfer) {
            assignedOwnerCompanyCode = record.getOwnerCompanyCode();
            assignedOwnerDivisionCode = record.getOwnerDivisionCode();
            assignedOwnerDepartmentCode = record.getOwnerDepartmentCode();
            assignedOwnerEmployeeId = record.getOwnerEmployeeId();
        } else {
            assignedOwnerCompanyCode = record.getCompanyCode();
            assignedOwnerDivisionCode = record.getDivisionCode();
            assignedOwnerDepartmentCode = record.getDepartmentCode();
            assignedOwnerEmployeeId = record.getEmployeeId();
        }

        InformInquiryLine inquiryLine = getDefaultInformInquiryLine(record, actionRequested, informTransaction, systemPrefix, logTimestamp);
        if (StringUtils.isNotBlank(record.getStatusCode().getType())) {
            inquiryLine.setWsInqStatusType(record.getStatusCode().getType());
        }
        if (StringUtils.isNotBlank(record.getStatusCode().getCode())) {
            inquiryLine.setWsInqStatusCd(record.getStatusCode().getCode());
        }

        if (forUpdate) {
            inquiryLine.setFromApplication(record.getMqFromApplication());
        }

        inquiryLine.setWsInqSevCd(record.getSeverity().getCode());
        inquiryLine.setWsInqRequestCd(record.getRequestCode());
        inquiryLine.setWsInqReslCd(record.getResolutionCode().getCode());
        inquiryLine.setWsInqRespDate(StringUtils.EMPTY);
        inquiryLine.setWsInqCatCd(record.getCategoryCode().getCode());
        inquiryLine.setWsInqSrcCd(record.getSourceCode());
        inquiryLine.setWsInqIntExtIndicator(record.getInternalExternalInd().getCode());
        inquiryLine.setWsInqAdjReasCd(record.getAdjustmentReasonCode().getCode());
        inquiryLine.setWsInqClaimNumber(record.getClaimNumber());

        if (null != record.getProviderNumber() && StringUtils.equalsIgnoreCase(record.getProviderNumber(), NPI_UNKNOWN)) {
            inquiryLine.setWsInqPvdrNo(StringUtils.EMPTY);
        } else {
            // Per request to display provider name
            inquiryLine.setWsInqPvdrNo(record.getProviderName());
        }

        inquiryLine.setWsInqDocumNo(record.getDocumentNumber());
        inquiryLine.setWsInqDocumAppl(StringUtils.EMPTY);
        inquiryLine.setWsInqDocumMedia(record.getDocumentMedia());
        if (null != record.getCorrReceivedDate()) {
            inquiryLine.setWsInqCorrRecvDate(datestamp.format(record.getCorrReceivedDate()));
        } else {
            inquiryLine.setWsInqCorrRecvDate(datestamp.format(currentDate));
        }
        inquiryLine.setWsInqCorrspName(record.getCorrespondenceName());
        inquiryLine.setWsInqFollowUpDate(StringUtils.EMPTY);
        inquiryLine.setGroupNumber(record.getGroupNumber());
        if (!forUpdate) {
            inquiryLine.setWsInqUserDefLoadAppl("C");
        }
        inquiryLine.setWsInqAccessKey(record.getAccessKey());
        inquiryLine.setWsInqCusCompNo(record.getTimeKey());
        if (null != record.getStatusDate()) {
            inquiryLine.setStatusDate(datestamp.format(record.getStatusDate()));
        }
        if (null != record.getLocationSentDate()) {
            inquiryLine.setLocationSentDate(datestamp.format(record.getLocationSentDate()));
        }
        inquiryLine.setWsInqPatName(record.getPatientName());

        if (StringUtils.equalsIgnoreCase(record.getStatusCode().getType(), STATUS_TYPE_OPEN)) {
            inquiryLine.setWsInqAdjReasCd("Y");
            inquiryLine.setWsInqReslCd(StringUtils.EMPTY);
        }

        // setup the company, division, department, employee id fields
        if (doTransfer) {
            inquiryLine.setCompanyCode(assignedOwnerCompanyCode);
            inquiryLine.setDivisionCode(assignedOwnerDivisionCode);
            inquiryLine.setDepartmentCode(assignedOwnerDepartmentCode);
            inquiryLine.setEmployeeId(assignedOwnerEmployeeId);
        } else if (null != informIdentification) {
            if (null != informIdentification.getInformSecurity()) {
                if(!forUpdate){
                        inquiryLine.setCompanyCode(informIdentification.getInformSecurity().getCompanyCode());
                        inquiryLine.setDivisionCode(informIdentification.getInformSecurity().getDivisionCode());
                        inquiryLine.setDepartmentCode(informIdentification.getInformSecurity().getDepartmentCode());
                        inquiryLine.setEmployeeId(informIdentification.getInformSecurity().getEmployeeId());
                }
            }
        }
        

        if (!forUpdate) {
            inquiryLine.setRequestEmployeeId(record.getEmployeeId());
            inquiryLine.setRequestCompanyCode(record.getCompanyCode());
            inquiryLine.setRequestDivisionCode(record.getDivisionCode());
            inquiryLine.setRequestDepartmentCode(record.getDepartmentCode());
                        
            // adding this to populate fields for everything except update
            inquiryLine.setChangeCompanyCode(assignedOwnerCompanyCode);
            inquiryLine.setChangeDepartmentCode(assignedOwnerDepartmentCode);
            inquiryLine.setChangeDivisionCode(assignedOwnerDivisionCode);
            inquiryLine.setChangeEmployeeId(assignedOwnerEmployeeId);
        }

        // If we have a status code, then we should set that here
        if (StringUtils.isNotBlank(record.getStatusCode().getCode())) {
            inquiryLine.setWsInqStatusCd(record.getStatusCode().getCode());
        }

        inquiryLine.setCustomerClass(record.getCustomerClassCode());

        informMessage.addLine(inquiryLine);

        if (!forUpdate) {
            if (doTransfer) {
                InformTransferLine transfer = getDefaultInformTransferLine(record, actionRequested, informTransaction, systemPrefix, racfId,
                        assignedOwnerCompanyCode, assignedOwnerDivisionCode, assignedOwnerDepartmentCode, assignedOwnerEmployeeId, logTimestamp);
                informMessage.addLine(transfer);
                if (doTracking) {
                    InformTransferTrackingLine tracking = getDefaultInformTrackingLine(record, actionRequested, informTransaction, systemPrefix, racfId, logTimestamp);
                    tracking.setWsTftSevr(record.getSeverity().getCode());
                    tracking.setWsTftName(record.getCorrespondenceName());
                    informMessage.addLine(tracking);
                }
            }

            InformRequestLine requestLine = getDefaultInformRequestLine(record, actionRequested, informTransaction, systemPrefix, racfId, logTimestamp);
            // setup the company, division, department, employee id fields
            if (null != informIdentification) {
                if (null != informIdentification.getInformSecurity()) {
                    requestLine.setCompanyCode(informIdentification.getInformSecurity().getCompanyCode());
                    requestLine.setDivisionCode(informIdentification.getInformSecurity().getDivisionCode());
                    requestLine.setDepartmentCode(informIdentification.getInformSecurity().getDepartmentCode());
                    requestLine.setEmployeeId(informIdentification.getInformSecurity().getEmployeeId());
                }
            }
            informMessage.addLine(requestLine);
        }

        if (StringUtils.isNotBlank(record.getResponseVerbiage())) {
            InformResponseLine line = getDefaultInformResponseLine(record, actionRequested, informTransaction, systemPrefix, racfId, logTimestamp);
            line.setVerbiage(record.getResponseVerbiage());
            informMessage.addLine(line);
        }

        if (StringUtils.isNotBlank(record.getCallRecordingId())) {
            InformKeyCrossReferenceLine crossReference = getDefaultInformKeyCrossReferenceLine(record, actionRequested, informTransaction, systemPrefix, logTimestamp);
            crossReference.setWsKcfKey(record.getCallRecordingId());
            informMessage.addLine(crossReference);
        }

        return informMessage;
    }

    /**
     * BASE INFORM Request will be logged for auditing
     * @param informSuccessful
     * @param informMessage
     * 
     * @throws Exception
     */
    private void createBaseAudit(InformMessage informMessage, boolean informSuccessful) {
        try {
            List<String> resultArray = informMessage.getMessage(InformBDBizImpl.MAX_LINE_COUNT);
            if (resultArray != null) {
                for (String informMessageBody : resultArray) {
                    if (informSuccessful) {
                        baseAuditSuccessLogger.logp(Level.INFO, StringUtils.EMPTY, StringUtils.EMPTY, informMessageBody);
                    } else {
                        baseAuditFailureLogger.logp(Level.INFO, StringUtils.EMPTY, StringUtils.EMPTY, informMessageBody);
                    }
                }
            }
        } catch (Exception ex) {
            log.error("Error logging " + informMessage, ex);
        }
    }
    
    /**
     * ENROLMENT INFORM Request will be logged for auditing
     * @param informSuccessful
     * @param informMessage
     * 
     * @throws Exception
     */
    private void createEnrolmentAudit(InformMessage informMessage, boolean informSuccessful) {
        try {
            List<String> resultArray = informMessage.getMessage(InformBDBizImpl.MAX_LINE_COUNT);
            if (resultArray != null) {
                for (String informMessageBody : resultArray) {
                    if (informSuccessful) {
                        enrollmentAuditSuccessLogger.logp(Level.INFO, StringUtils.EMPTY, StringUtils.EMPTY, informMessageBody);
                    } else {
                        enrollmentAuditFailureLogger.logp(Level.INFO, StringUtils.EMPTY, StringUtils.EMPTY, informMessageBody);
                    }
                }
            }
        } catch (Exception ex) {
            log.error("Error logging " + informMessage, ex);
        }
    }

    /**
     * @param record
     * @param actionRequested
     * @param informTransaction
     * @param systemPrefix
     * @return
     */
    private InformKeyCrossReferenceLine getDefaultInformKeyCrossReferenceLine(InformRecord record, String actionRequested, String informTransaction,
            String systemPrefix, String logTimestamp) {

        DateFormat datestamp = new SimpleDateFormat(YYYY_MM_DD_WITH_DASHES);
        DateFormat timestamp = new SimpleDateFormat(HH_MM_SS_WITH_DOTS);

        Date currentDate = new Date();

        InformKeyCrossReferenceLine crossReference = new InformKeyCrossReferenceLine();
        defaultHeaderInformation(crossReference, actionRequested, informTransaction, systemPrefix, record, logTimestamp);
        crossReference.setWsKcfKeyType("01");
        crossReference.setDate(datestamp.format(currentDate));
        crossReference.setTime(timestamp.format(currentDate));
        crossReference.setCompanyCode(record.getCompanyCode());
        crossReference.setDivisionCode(record.getDivisionCode());
        crossReference.setDepartmentCode(record.getDepartmentCode());
        crossReference.setEmployeeId(record.getEmployeeId());
        crossReference.setConvertIndicator("N");
        if (StringUtils.isNotBlank(record.getConvertAmount())) {
            crossReference.setConvertAmount(record.getConvertAmount());
        } else {
            crossReference.setConvertAmount(StringUtils.EMPTY);
        }
        return crossReference;
    }

    private InformRequestLine getDefaultInformRequestLine(InformRecord record, String actionRequested, String informTransaction, String systemPrefix,
            String racfId, String logTimestamp) {
        InformRequestLine line = new InformRequestLine();
        defaultHeaderInformation(line, actionRequested, informTransaction, systemPrefix, record, logTimestamp);
        line.setVerbiage(record.getRequestVerbiage());
        line.setType(record.getInquiryType());
        return line;
    }

    /**
     * @param record
     * @param actionRequested
     * @param informTransaction
     * @param systemPrefix
     * @param racfId
     * @param logTimestamp
     * @return
     */
    private InformResponseLine getDefaultInformResponseLine(InformRecord record, String actionRequested, String informTransaction, String systemPrefix,
            String racfId, String logTimestamp) {

        DateFormat datestamp = new SimpleDateFormat(YYYY_MM_DD_WITH_DASHES);
        DateFormat timestamp = new SimpleDateFormat(HH_MM_SS_WITH_DOTS);

        Date currentDate = new Date();

        InformResponseLine line = new InformResponseLine();
        defaultHeaderInformation(line, actionRequested, informTransaction, systemPrefix, record, logTimestamp);
        line.setDate(datestamp.format(currentDate));
        line.setTime(timestamp.format(currentDate));
        line.setRacf(racfId);
        line.setType("CU");
        line.setConvertIndicator(StringUtils.EMPTY);
        if (StringUtils.isNotBlank(record.getConvertAmount())) {
            line.setConvertAmount(record.getConvertAmount());
        } else {
            line.setConvertAmount(DEFAULT_CONVERT_AMOUNT);
        }
        return line;
    }

    /**
     * @param record
     * @param actionRequested
     * @param informTransaction
     * @param systemPrefix
     * @param racfId
     * @return
     */
    private InformTransferTrackingLine getDefaultInformTrackingLine(InformRecord record, String actionRequested, String informTransaction, String systemPrefix,
            String racfId, String logTimestamp) {
        InformTransferTrackingLine tracking = new InformTransferTrackingLine();
        defaultHeaderInformation(tracking, actionRequested, informTransaction, systemPrefix, record, logTimestamp);
        // Per Inform team and Beth Tracking should default to OP as we will 
        // only track OP status
        tracking.setStatusType(STATUS_TYPE_OPEN);
        tracking.setInterApplicationIndicator(StringUtils.EMPTY);
        tracking.setRequestCode(record.getRequestCode());
        tracking.setRacf(racfId);
        tracking.setConvertIndicator("N");
        if (StringUtils.isNotBlank(record.getConvertAmount())) {
            tracking.setConvertAmount(record.getConvertAmount());
        } else {
            tracking.setConvertAmount(StringUtils.EMPTY);
        }
        return tracking;
    }

    /**
     * @param record
     * @param actionRequested
     * @param informTransaction
     * @param systemPrefix
     * @param racfId
     * @param assignedOwnerCompanyCode
     * @param assignedOwnerDivisionCode
     * @param assignedOwnerDepartmentCode
     * @param assignedOwnerEmployeeId
     * @return
     */
    private InformTransferLine getDefaultInformTransferLine(InformRecord record, String actionRequested, String informTransaction, String systemPrefix,
            String racfId, String assignedOwnerCompanyCode, String assignedOwnerDivisionCode, String assignedOwnerDepartmentCode,
            String assignedOwnerEmployeeId, String logTimestamp) {

        DateFormat datestamp = new SimpleDateFormat(YYYY_MM_DD_WITH_DASHES);
        DateFormat timestamp = new SimpleDateFormat(HH_MM_SS_WITH_DOTS);

        Date currentDate = new Date();

        InformTransferLine transfer = new InformTransferLine(assignedOwnerCompanyCode, assignedOwnerDivisionCode, assignedOwnerDepartmentCode,
                assignedOwnerEmployeeId);
        defaultHeaderInformation(transfer, actionRequested, informTransaction, systemPrefix, record, logTimestamp);
        transfer.setTransferDate(datestamp.format(currentDate));
        transfer.setTransferTime(timestamp.format(currentDate));
        transfer.setRacf(racfId);
        transfer.setWsTrhTftInd("3");
        transfer.setConvertIndicator("N");
        if (StringUtils.isNotBlank(record.getConvertAmount())) {
            transfer.setConvertAmount(record.getConvertAmount());
        } else {
            transfer.setConvertAmount(StringUtils.EMPTY);
        }
        return transfer;
    }

    /**
     * @param record
     * @param actionRequested
     * @param informTransaction
     * @param systemPrefix
     * @return
     */
    private InformInquiryLine getDefaultInformInquiryLine(InformRecord record, String actionRequested, String informTransaction, String systemPrefix,
            String logTimestamp) {

        DateFormat receivedDateFormat = new SimpleDateFormat(YYYY_MM_DD_WITH_DASHES);
        Date receivedDate = new Date();

        InformInquiryLine inquiryLine = new InformInquiryLine();
        defaultHeaderInformation(inquiryLine, actionRequested, informTransaction, systemPrefix, record, logTimestamp);
        inquiryLine.setEmployeeReceivedDate(receivedDateFormat.format(receivedDate));
        inquiryLine.setWsInqStatusType(STATUS_TYPE_OPEN);
        inquiryLine.setWsInqPatId(record.getPatientId());
        inquiryLine.setRelationshipCode(record.getPatientSexRelationshipCode().getCode());
        inquiryLine.setWsInqZipCode(StringUtils.EMPTY); // TODO ??
        if (StringUtils.isNotBlank(record.getConvertAmount())) {
            inquiryLine.setConvertAmount(record.getConvertAmount());
        } else {
            inquiryLine.setConvertAmount(DEFAULT_CONVERT_AMOUNT);
        }
        inquiryLine.setWsInqStatusCd("2");
        return inquiryLine;
    }

    /**
     * @param line
     * @param actionRequested
     * @param informTransaction
     * @param systemPrefix
     * @param record
     */
    private void defaultHeaderInformation(AbstractInformRecordLine line, String actionRequested, String informTransaction, String systemPrefix,
            InformRecord record, String logTimestamp) {
        line.setActionRequested(actionRequested);
        line.setSystemPrefix(systemPrefix);
        line.setToApplication(informTransaction);
        line.setKeyId(record.getKeyId());
        line.setAlternateKeyId(record.getAltKeyId());
        line.setQueueId(StringUtils.EMPTY);
        line.setFromApplication(record.getMqFromApplication());
        line.setUpdateKeyFields("N");
        line.setConvertIndicator("Y");
        line.setLogTimestamp(logTimestamp);

    }

    @Override
    public String sendInformMessage(InformMessage informMessage, Subject subject) throws InformException {
        return this.sendInformMessage(informMessage, null, subject);
    }

    @Override
    public String sendInformMessage(InformMessage informMessage, String correlationId, Subject subject) throws InformException {
        String informMessageBody = StringUtils.EMPTY;
        String returnString = null;
        String retCorrelationId = null;
        String retMultiPartCorrelationId = null;
        boolean isMultiPartParentTkt = false;
        try {
            List<String> resultArray = informMessage.getMessage(InformBDBizImpl.MAX_LINE_COUNT);
            int len = 0;
            if ((null != resultArray)) {
                len = resultArray.size();
            }
            //If len > 1, then it means that the ticket contains more than 200 lines...
            if ((len > 1) && (null == correlationId)) {
                //It is a Parent ticket with more than 1 message..
                //For a Parent ticket, if there is more than 1 message then the correlation ID returned by the first
                //message should be used further.
                isMultiPartParentTkt = true;
            }

            if (resultArray != null) {
                int index = 0;
                for (Iterator<String> iter = resultArray.iterator(); iter.hasNext(); index++) {
                    informMessageBody = iter.next();
                    retCorrelationId = informMessenger.sendInformMessage(informMessageBody, correlationId, subject);
                    if ((index == 0) && isMultiPartParentTkt) {
                        retMultiPartCorrelationId = retCorrelationId;
                    }
                }
            }
            if (log.isDebugEnabled()) {
                log.debug("Successfully sent INFORM message.");
            }
        } catch (Exception le) {
            throw new InformException("Error attempting to send INFOrm message - ", le);
        }
        if (isMultiPartParentTkt) {
            returnString = retMultiPartCorrelationId;
        } else {
            returnString = retCorrelationId;
        }
        return returnString;
    }

    /**
     * @return the informMessenger
     */
    public SubmitInformDAO getInformMessenger() {
        return this.informMessenger;
    }

    /**
     * @param informMessenger the informMessenger to set
     */
    public void setInformMessenger(SubmitInformDAO informMessenger) {
        this.informMessenger = informMessenger;
    }

}
