/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */

package com.bcbssc.desktop.member;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.dao.AbstractDaoService;
import com.bcbssc.desktop.dao.PatientDAO;
import com.bcbssc.domain.patientList.PatientListInputDesktop;
import com.bcbssc.domain.patientList.PatientListOutputDesktop;
import com.bcbssc.domain.patientList.PatientListRecord;
import com.bcbssc.services.patientlist.PatientListEligiblePatientList;
import com.bcbssc.services.patientlist.PatientListInput;
import com.bcbssc.services.patientlist.PatientListOutput;
import com.bcbssc.services.patientlist.PatientListService;

/**
 * Intended for JUnit profiling comparison against the real com.bcbssc.desktop.member.ServicePatientListDaoImpl.
 */
public class PatientListDaoNoCache
extends AbstractDaoService <PatientListService, PatientListInputDesktop, PatientListInput, PatientListOutput, PatientListOutputDesktop>
implements PatientDAO {
    private static final Log log = LogFactory.getLog(PatientListDaoNoCache.class);

    private static final String SERVICE_NAME = "PatientList";

    /** JUnit or future non EJB impls */
    private PatientListService service;

    @Override
    public PatientListOutputDesktop retrievePatientList(PatientListInputDesktop desktopInput) throws Exception {
        return call(desktopInput);
    }

    @Override
    public String getBackEndSourceName() {
        return SERVICE_NAME;
    }

    @Override
    public String getBackEndOperationName() {
        return "getPatientList";
    }

    @Override
    protected PatientListService getBackEndDataSource() throws Exception {
        if (null != service) {
            return service;
        }
        // NOTE: Don't set this.service since EJB is unstable.
        //return (PatientListService) new ServiceClientGenerator(SERVICE_NAME).getServiceClient();
        throw new UnsupportedOperationException("This class needs to be converted to extend the BaseServiceIntegrator");
    }

    /** For JUnit */
    protected void setService(PatientListService service) {
        this.service = service;
    }

    @Override
    protected PatientListOutput invoke(PatientListInputDesktop desktopInput, PatientListInput backEndInput, PatientListService dataSource) throws Exception {
        return dataSource.getPatientList(backEndInput);
    }

    @Override
    protected PatientListInput mapInput(PatientListInputDesktop desktopInput) throws Exception {
        final PatientListInput input = new PatientListInput();
        input.setRpn(desktopInput.getRpn());
        input.setSubscriberId(desktopInput.getSubscriberId());
        return input;
    }

    @Override
    protected PatientListOutputDesktop mapOutput(PatientListInputDesktop desktopInput, PatientListOutput backEndOutput) throws Exception {
        final List<PatientListEligiblePatientList> patients = backEndOutput.getEligiblePatientList().getPatientListEligiblePatientList();
        final List<PatientListRecord> patientList = new ArrayList<PatientListRecord>();
        final SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");

        for (final PatientListEligiblePatientList patient: patients) {
            // Since this service is backed by SELG, we better have an AMMS patient id.
            if (StringUtils.isEmpty(patient.getAmmsPatientIdNumber())) {
                break;
            }

            final PatientListRecord rec = new PatientListRecord();
            patientList.add(rec);
            rec.verifiedPatientIndicator = patient.getVerifiedPatientIndicator();
            rec.planCode = patient.getPlanCode();
            rec.ammsPatientIdNumber = patient.getAmmsPatientIdNumber();
            rec.cesMemberNumber = patient.getCesMemberNumber();
            rec.patientFirstName = patient.getPatientFirstName();
            rec.patientLastName = patient.getPatientLastName();
            rec.patientRelationshipDescription = patient.getPatientRelationshipDescription();
            rec.patientGender = patient.getPatientGender();
            rec.confidentialCommunicationsInd = patient.getConfidentialCommunicationsInd();

            //DOB
            final String dob = patient.getPatientDateOfBirth();
            try {
                if (StringUtils.isNotBlank(dob)) {
                    rec.patientDateOfBirth = dateFormatter.parse(dob);
                }
            } catch (final ParseException ex) {
                log.warn("Failed to parse the patient's date of birth:" + dob, ex);
            }
        }

        return new PatientListOutputDesktop(patientList);
    }
}
