/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.startup;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.util.jdbc.executor.JdbcServiceInputMapper;
import com.bcbssc.desktop.util.jdbc.executor.JdbcServiceOutputMapper;
import com.bcbssc.desktop.util.menu.MenuUtils;
import com.bcbssc.domain.valueobject.MenuConfiguration;
import com.bcbssc.domain.valueobject.MenuLink;

/**
 * This class is a jdbc query to get navigation links.
 *
 * @author jc33
 */
public class NavigationMenuLinksQuery extends MenuLinksQuery {

    private static final Log logger = LogFactory.getLog(NavigationMenuLinksQuery.class);

    private final String SQL = 
		" SELECT " +
		"     FNCT.FUNCTION_ID AS FUNCTION_ID, " +
		"     FNCT.SUBFUNCTION_ID AS SUBFUNCTION_ID, " +
		"     LT.FUNCTION_TYP AS FUNCTION_TYPE, " +
		"     FNCT.FNCT_SUBFNCT_DESC AS LINK_DESCRIPTION, " +
		"     LT.ALTERNATE_FUNCTION AS ALT_FUNCTION, " +
		"     LT.REGION_ID AS REGION, " +
		"     LT.TASK_KEY AS TASK_KEY, " +
		"     LT.KEY_TYPE AS KEY_TYPE, " +
		"     LT.KEY_VALUE AS KEY_VALUE, " +
		"     LT.FUNCTION_COMMENTS AS FUNCTION_COMMENTS, " +
		"     NTLN.DT_TYP_NTE_LN_TEXT AS LINK_ACTION, " +
		"     FNCT.FNCT_SUBFNCT_SEQ AS SEQUENCE, " +
		"     NTLN.DT_TYP_NOTE_LN AS NOTE_LINE, " +
		"     FNCT.CLIENT_ID AS CLIENT_ID, " +
		"     FNCT.COMPANY_CD AS COMPANY_CD, " +
		"     FNCT.DIVISION_CD AS DIVISION_CD, " +
		"     FNCT.DEPARTMENT_CD AS DEPARTMENT_CD " +
		"FROM " +
		" {0}.DT_TYP_FUNCTION FNCT INNER JOIN {0}.DT_TYP_LINKS_TASKS LT ON " + 
		"     (LT.FUNCTION_ID = FNCT.SUBFUNCTION_ID) AND " +
		"     (LT.PLAN_CD = FNCT.PLAN_CD) AND " +
		"     (LT.RP_NO = FNCT.RP_NO) AND " +
		"     (LT.DATA_TYP = ?) AND " +
		"     (LT.FUNCTION_TYP LIKE ?) AND " +
		"     (LT.SYS_VOID_STS_IND = ''N'') " +
		" LEFT OUTER JOIN {0}.DT_TYP_NOTE_SPCL NOTE ON " +
		"     (LT.DATA_TYP = NOTE.DATA_TYP) AND " +
		"     (NOTE.SYS_VOID_STS_IND = ''N'') AND " +
		"     (NOTE.DT_TYP_TM_STMP = LT.DT_TYP_NTE_TM_STMP) AND " +
		"     (FNCT.RP_NO = NOTE.RP_NO) AND " +
		"     (FNCT.PLAN_CD = NOTE.PLAN_CD) " +
		" LEFT OUTER JOIN {0}.DT_TYP_NT_LN_SPCL NTLN ON " +
		"     (NTLN.DATA_TYP = NOTE.DATA_TYP) AND " +
		"     (NTLN.DT_TYP_NTE_TM_STMP = NOTE.DT_TYP_NTE_TM_STMP) AND " +
		"     (FNCT.RP_NO = NTLN.RP_NO) AND " +
		"     (FNCT.PLAN_CD = NTLN.PLAN_CD) " +
		"WHERE " +
		"     FNCT.DATA_TYP=''FUNCTION'' AND " +
		"     FNCT.SYS_VOID_STS_IND=''N'' AND " +
		"     FNCT.APPLICATION_ID = ? AND " +
		"     FNCT.RP_NO = ? AND " +
		"     FNCT.PLAN_CD = ? AND " +
		"     FNCT.ROLE_CD IN (?, ''X'') AND " +
		"     FNCT.COMPANY_CD IN (?, ''X'') AND " +
		"     FNCT.DIVISION_CD IN (?, ''X'') AND " +
		"     FNCT.DEPARTMENT_CD IN (?, ''X'') AND " +
		"     FNCT.CLIENT_ID IN (?, ''X'') " +
		"ORDER BY " +
		"     FUNCTION_ID, " +
		"     FNCT_SUBFNCT_SEQ, " +
		"     SUBFUNCTION_ID, " +
		"     DT_TYP_NOTE_LN " +
		"FOR FETCH ONLY WITH UR";

    @Override
    public List<MenuLink> findLinks(String schema, MenuConfiguration menuConfig) {
        String actualSql = MessageFormat.format(SQL, new Object[] { schema });

        JdbcServiceInputMapper inputMapper = new FindLinksInputMapper(actualSql, false, menuConfig);
        JdbcServiceInputMapper defaultInputMapper = new FindLinksInputMapper(actualSql, true, menuConfig);

        List<MenuLink> results = this.runQuery(inputMapper, defaultInputMapper, menuConfig.getDefaultRegion());

        return results;
    }


    /**
     * Get the row mapper to be used for this operation
     * 
     * @param defaultRegion
     * @return An instance of {@link JdbcServiceOutputMapper}
     */
    @Override
    public JdbcServiceOutputMapper getOutputMapper(String defaultRegion) {
        MenuLinkOutputMapper rowMapper = new MenuLinkOutputMapper();
        rowMapper.setDefaultRegion(defaultRegion);
        return rowMapper;
    }

    private class FindLinksInputMapper extends JdbcServiceInputMapper {
        private boolean isDefault;
        private MenuConfiguration menuConfig;

        /**
         * Constructor for the input mapper that passes everything this needs to execute.
         * 
         * @param query
         * @param isDefault
         * @param menuConfig
         */
        private FindLinksInputMapper(String query, boolean isDefault, MenuConfiguration menuConfig) {
            super(query);
            this.isDefault = isDefault;
            this.menuConfig = menuConfig;
        }

        /**
         * @see com.bcbssc.desktop.util.jdbc.executor.JdbcServiceInputMapper#mapInput()
         * 
         * codereview - This method complains about returning type Object - that can not
         * be changed unless the JdbcServiceInputMapper is change to allow for typing of 
         * classes.
         */
        @Override
        public Object mapInput() {
            Object[] params = new Object[10];
            params[0] = StringUtils.trimToEmpty(menuConfig.getDataType());
            params[1] = StringUtils.trimToEmpty(menuConfig.getFunctionType()) + "%";
            params[2] = StringUtils.trimToEmpty(menuConfig.getApplicationId());
            params[3] = StringUtils.trimToEmpty(menuConfig.getAltRpn());
            params[4] = StringUtils.trimToEmpty(menuConfig.getPlanCode());
            params[5] = StringUtils.trimToEmpty(menuConfig.getRoleCode());
            params[9] = StringUtils.trimToEmpty(menuConfig.getClientId());

            if (isDefault) {
                params[6] = StringUtils.trimToEmpty(menuConfig.getDefaultCompanyCode());
                params[7] = StringUtils.trimToEmpty(menuConfig.getDefaultDivisionCode());
                params[8] = StringUtils.trimToEmpty(menuConfig.getDefaultDepartmentCode());
            } else {
                params[6] = StringUtils.trimToEmpty(menuConfig.getCompanyCode());
                params[7] = StringUtils.trimToEmpty(menuConfig.getDivisionCode());
                params[8] = StringUtils.trimToEmpty(menuConfig.getDepartmentCode());
            }
            if (logger.isDebugEnabled()) {
                logger.debug("Executing JDBC query: " + getQuery() + "\nwith parameters: " + ReflectionToStringBuilder.toString(params));
            }
            return params;
        }
    }

    /**
     * Default row mapper to be used by the menu queries
     * 
     * Needs to access only columns present in the ResultSet,
     * or breakage results. 
     */
    private class MenuLinkOutputMapper extends JdbcServiceOutputMapper {

        private static final String DEFAULT_REGION_INDICATOR = "DEFAULT";
        private String defaultRegion;


        /**
         * @see com.bcbssc.desktop.util.jdbc.executor.JdbcServiceOutputMapper#mapRow(java.sql.ResultSet)
         * 
         * codereview - This method complains about returning type Object - that can not
         * be changed unless the JdbcServiceInputMapper is change to allow for typing of 
         * classes.
         */
        @Override
        public Object mapRow(ResultSet resultSet) throws SQLException {

            MenuLink link = new MenuLink();

            link.setFunctionId(StringUtils.trim(resultSet.getString("FUNCTION_ID")));
            link.setSubfunctionId(StringUtils.trim(resultSet.getString("SUBFUNCTION_ID")));
            link.setFunctionType(StringUtils.trim(resultSet.getString("FUNCTION_TYPE")));
            link.setLinkDesc(MenuUtils.dropCase(StringUtils.trim(resultSet.getString("LINK_DESCRIPTION"))));
            link.setAltFunction(MenuUtils.dropCase(StringUtils.trim(resultSet.getString("ALT_FUNCTION"))));
            link.setComments(MenuUtils.dropCase(StringUtils.trim(resultSet.getString("FUNCTION_COMMENTS"))));

            String region = StringUtils.trim(resultSet.getString("REGION"));

            /*
             * If the menu link was setup to use the default region, then set the region for the link
             * to the region that the desktop is using.
             */
            if (StringUtils.equalsIgnoreCase(DEFAULT_REGION_INDICATOR, region) && StringUtils.isNotBlank(defaultRegion)) {
                region = defaultRegion;
            }

            link.setRegionId(region);
            link.setTaskKey(MenuUtils.dropCase(StringUtils.trim(resultSet.getString("TASK_KEY"))));
            link.setKeyType(MenuUtils.dropCase(StringUtils.trim(resultSet.getString("KEY_TYPE"))));
            link.setKeyValue(MenuUtils.dropCase(StringUtils.trim(resultSet.getString("KEY_VALUE"))));

            String linkAction = resultSet.getString("LINK_ACTION");
            if (StringUtils.isNotEmpty(linkAction)) {
                link.setLinkAction(MenuUtils.dropCase(StringUtils.trim(linkAction)));
            }

            link.setSeq(resultSet.getInt("SEQUENCE"));

            link.setClientCode(StringUtils.trim(resultSet.getString("CLIENT_ID")));
            link.setCompanyCode(StringUtils.trim(resultSet.getString("COMPANY_CD")));
            link.setDepartmentCode(StringUtils.trim(resultSet.getString("DEPARTMENT_CD")));
            link.setDivisionCode(StringUtils.trim(resultSet.getString("DIVISION_CD")));

            return link;
        }

        /**
         * @param defaultRegion The defaultRegion to set
         */
        public void setDefaultRegion(String defaultRegion) {
            this.defaultRegion = defaultRegion;
        }
    }
}
