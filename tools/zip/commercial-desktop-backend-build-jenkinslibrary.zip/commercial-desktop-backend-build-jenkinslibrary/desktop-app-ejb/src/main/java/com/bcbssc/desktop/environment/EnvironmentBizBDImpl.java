/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.environment;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.security.auth.Subject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.biz.EnvironmentBiz;
import com.bcbssc.desktop.dao.EnvironmentDAO;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;

/**
 * Implements the Environment business interface to access environment-level
 * configuration settings.
 */
@Stateless
@Local
public class EnvironmentBizBDImpl implements EnvironmentBiz {
    /**
     * The logger for this class.
     */
    private static final Log logger = LogFactory.getLog(EnvironmentBizBDImpl.class);

    /**
     * The object that perform the actual retrieval.
     */
    @EJB(beanName = "ResourceProviderEnvironmentDAOImpl")
    private EnvironmentDAO environmentDao;

    // Implements for EnvironmentBiz
    @Override
    public String get(EnvironmentObjects environmentObject, Subject subject) {
        return get(environmentObject, String.class, subject);
    }

    // Implements for EnvironmentBiz
    @Override
    public <T> T get(EnvironmentObjects environmentObject, Class<T> expectedClass, Subject subject) {
        if (null == subject) {
            throw new IllegalArgumentException("Must provide the subject.");
        }

        return internalGet(environmentObject, expectedClass, subject);
    }

    // Implements for EnvironmentBiz
    @Override
    public <T> T getCommon(EnvironmentObjects environmentObject, Class<T> expectedClass) {
        return internalGet(environmentObject, expectedClass, null);
    }

    // Implements for EnvironmentBiz
    @Override
    public boolean isDefined(EnvironmentObjects environmentObject, Subject subject) {
        // Check all of our inputs.
        if (null == environmentObject) {
            throw new IllegalArgumentException("Must provide the EnvironmentObjects enum.");
        }
        if (null == subject) {
            throw new IllegalArgumentException("Must provide the subject.");
        }

        // Get and check the value.
        Object rawValue = getObjectFromDao(environmentObject, subject);
        boolean result = false;
        if (rawValue != null) {
            result = true;
        }
        return result;
    }

    // Implements for EnvironmentBiz
    @Override
    public boolean isEnvironmentDefined(String environment) {
        if (logger.isDebugEnabled()) {
            logger.debug("Validating environment: " + environment);
        }
        return environmentDao.isEnvironmentDefined(environment);
    }

    // Implements for EnvironmentBiz
    @Override
    public List<String> getEnvironments() {
        if (logger.isDebugEnabled()) {
            logger.debug("Getting list of environments");
        }
        return environmentDao.getEnvironments();
    }

    /**
     * Internal implementation for {@link #get(EnvironmentObjects, Class, Subject)}
     * and {@link #getCommon(EnvironmentObjects, Class)}.
     */
    private <T> T internalGet(EnvironmentObjects environmentObject, Class<T> expectedClass, Subject subject) {
        // Check all of our inputs.
        if (null == environmentObject) {
            throw new IllegalArgumentException("Must provide the EnvironmentObjects enum.");
        }
        if (null == expectedClass) {
            throw new IllegalArgumentException("Must provide the expected class.");
        }

        // Sanity check - Make sure the caller and the enum match.
        // Explicitly checking the types is friendlier than waiting for the cast.
        if (!expectedClass.isAssignableFrom(environmentObject.getType())) {
            throw new ClassCastException("Type mismatch, enum returns type: " + environmentObject.getType().getName() + ", caller expects: " + expectedClass.getName());
        }

        // Get, convert, cast and return the value.
        Object rawValue = getObjectFromDao(environmentObject, subject);
        Object value = null;
        if (null != rawValue) {
            try {
                value = environmentObject.convert(rawValue);
            } catch (Exception e) {
                rawValue = null;
                logger.error("Environment Object [" + environmentObject + "] conversion failed; using default");
            }
        }
        if (null == rawValue) {
            value = environmentObject.getDefaultValue();
            logger.warn("Environment Object [" + environmentObject + "] not found or conversion failed; defaulting to: " + value);
        }

        return expectedClass.cast(value);
    }

    /**
     * Gets the object from the {@link EnvironmentDAO}.
     * 
     * @param environmentObject The unique identifier for an object stored on Base Desktop's server.
     * @param subject The desktop user's context for the current region or line of business.
     * @return If object is not found then <code>null</code>.
     */
    private Object getObjectFromDao(EnvironmentObjects environmentObject, Subject subject) {
        if (logger.isDebugEnabled()) {
            logger.debug("Looking up object by enum: " + environmentObject);
        }

        // The object that was retrieved.
        Object rawValue = null;

        // Get from the backing DAO.
        try {
            // The subject is never null unless this method was reached from getCommon()
            // get() enforces and must continue to enforce this
            if (subject == null) {
                rawValue = environmentDao.getCommonObject(environmentObject);
            } else {
                rawValue = environmentDao.getObject(environmentObject, subject);
            }
        } catch (Exception ex) {
            logger.warn("Cannot find object by enum: " + environmentObject, ex);
            rawValue = null;
        }

        return rawValue;
    }

    protected EnvironmentDAO getEnvironmentDao() {
        return environmentDao;
    }

    protected void setEnvironmentDao(EnvironmentDAO environmentDao) {
        this.environmentDao = environmentDao;
    }
}
