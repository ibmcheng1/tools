/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2007 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.endtask;

import com.bcbssc.desktop.util.jdbc.executor.JdbcServiceInputMapper;
import com.bcbssc.desktop.util.jdbc.executor.JdbcServiceInvoker;
import com.bcbssc.desktop.util.jdbc.executor.JdbcServiceOutputMapper;
import com.bcbssc.desktop.util.jdbc.query.BaseQuery;
import com.bcbssc.domain.entity.Employee;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Employee Lookup Query for JDBC Executor framework
 */
public class EmployeeLookupQuery extends BaseQuery {

    private static final Log logger = LogFactory.getLog(EmployeeLookupQuery.class);
    private static final String LIKE_NAME_SELECT_QUERY = "SELECT SEC_EMP_NAME AS EMPLOYEE_NAME, SEC_EMP_ID_NO AS EMPLOYEE_ID FROM {0}.VINFSECZ WHERE SEC_EMP_NAME LIKE ?";
    private static final String LIKE_ID_SELECT_QUERY = "SELECT SEC_EMP_NAME AS EMPLOYEE_NAME, SEC_EMP_ID_NO AS EMPLOYEE_ID FROM {0}.VINFSECZ WHERE SEC_EMP_ID_NO LIKE ?";

    /**
      * Looks up employee(s) by name.
      * @param schema database schema containing tables
      * @param name is the name of the employee to lookup.
      * @return List of Employees
      */
    public List<Employee> retrieveEmployeesByName(String schema, String name) {
        List<Employee> results = new ArrayList<Employee>();
        String sql = MessageFormat.format(LIKE_NAME_SELECT_QUERY, new Object[] { schema });

        JdbcServiceInputMapper inputMapper = new InformEmployeeQueryInputMapper(sql, "%" + StringUtils.trimToEmpty(name) + "%");
        JdbcServiceOutputMapper outputMapper = new InformEmployeeQueryRowMapper();

        try {
            results = (List<Employee>) jdbcTemplate.execute(inputMapper, outputMapper, new JdbcServiceInvoker());
        } catch (Exception e) {
            logger.error("Unable to load employees: ", e);
        }

        return results;
    }

    /**
     * Looks up employees by id
     * 
     * @param schema is database schema containing tables
     * @param id is id employee to lookup
     * @return List of Employees
     */
    public List<Employee> retrieveEmployeesById(String schema, String id) {
        List<Employee> results = new ArrayList<Employee>();
        String sql = MessageFormat.format(LIKE_ID_SELECT_QUERY, new Object[] { schema });

        JdbcServiceInputMapper inputMapper = new InformEmployeeQueryInputMapper(sql, "%" + StringUtils.trimToEmpty(id) + "%");
        JdbcServiceOutputMapper outputMapper = new InformEmployeeQueryRowMapper();

        try {
            results = (List<Employee>) jdbcTemplate.execute(inputMapper, outputMapper, new JdbcServiceInvoker());
        } catch (Exception e) {
            logger.error("Unable to load employees: ", e);
        }

        return results;
    }

    /**
     * input mapper for the employee lookup queries -  see <code>EmployeeLookupQuery.retrieveEmployeesByName(java.lang.String, java.lang.String)</code> 
     * and <code>EmployeeLookupQuery.retrieveEmployeesById(java.lang.String, java.lang.String)</code><br>
     * contains mapInput method to map the single input parameter (employeeId)
     * 
     */
    private static final class InformEmployeeQueryInputMapper extends JdbcServiceInputMapper {
        String employeeId;

        public InformEmployeeQueryInputMapper(String query, String employeeId) {
            super(query);
            this.employeeId = employeeId;
        }

        /* (non-Javadoc)
         * @see com.bcbssc.desktop.util.jdbc.executor.JdbcServiceInputMapper#mapInput()
         */
        @Override
        public Object mapInput() {
            Object[] parameters = new Object[1];
            parameters[0] = employeeId;

            return parameters;
        }

    }

    /**
     * row mapper for the employee name lookup query -  see <code>EmployeeLookupQuery.retrieveEmployeesByName(java.lang.String, java.lang.String)</code>
     * and <code>EmployeeLookupQuery.retrieveEmployeesById(java.lang.String, java.lang.String)</code><br> 
     * contains mapRow method to map query results to an Employee object 
     * 
     */
    private static final class InformEmployeeQueryRowMapper extends JdbcServiceOutputMapper {

        @Override
        protected Object mapRow(ResultSet resultSet) throws SQLException {
            Employee employee = new Employee();
            employee.getName().setLastName(StringUtils.trim(resultSet.getString("EMPLOYEE_NAME")));
            employee.setId(StringUtils.trim(resultSet.getString("EMPLOYEE_ID")));
            return employee;
        }

    }
}
