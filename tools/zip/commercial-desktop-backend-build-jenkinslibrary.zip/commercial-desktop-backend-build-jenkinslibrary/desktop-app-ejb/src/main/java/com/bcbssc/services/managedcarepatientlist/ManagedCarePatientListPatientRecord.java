
package com.bcbssc.services.managedcarepatientlist;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ManagedCarePatientListPatientRecord complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ManagedCarePatientListPatientRecord">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="patientId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="patientName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="patientGenderAndRltnshpCd" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="patientDateOfBirth" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ammsIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ManagedCarePatientListPatientRecord", propOrder = {
    "patientId",
    "patientName",
    "patientGenderAndRltnshpCd",
    "patientDateOfBirth",
    "ammsIndicator"
})
public class ManagedCarePatientListPatientRecord {

    @XmlElement(required = true, nillable = true)
    protected String patientId;
    @XmlElement(required = true, nillable = true)
    protected String patientName;
    @XmlElement(required = true, nillable = true)
    protected String patientGenderAndRltnshpCd;
    @XmlElement(required = true, nillable = true)
    protected String patientDateOfBirth;
    @XmlElement(required = true, nillable = true)
    protected String ammsIndicator;

    /**
     * Gets the value of the patientId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientId() {
        return patientId;
    }

    /**
     * Sets the value of the patientId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientId(String value) {
        this.patientId = value;
    }

    /**
     * Gets the value of the patientName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientName() {
        return patientName;
    }

    /**
     * Sets the value of the patientName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientName(String value) {
        this.patientName = value;
    }

    /**
     * Gets the value of the patientGenderAndRltnshpCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientGenderAndRltnshpCd() {
        return patientGenderAndRltnshpCd;
    }

    /**
     * Sets the value of the patientGenderAndRltnshpCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientGenderAndRltnshpCd(String value) {
        this.patientGenderAndRltnshpCd = value;
    }

    /**
     * Gets the value of the patientDateOfBirth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientDateOfBirth() {
        return patientDateOfBirth;
    }

    /**
     * Sets the value of the patientDateOfBirth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientDateOfBirth(String value) {
        this.patientDateOfBirth = value;
    }

    /**
     * Gets the value of the ammsIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmmsIndicator() {
        return ammsIndicator;
    }

    /**
     * Sets the value of the ammsIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmmsIndicator(String value) {
        this.ammsIndicator = value;
    }

}
