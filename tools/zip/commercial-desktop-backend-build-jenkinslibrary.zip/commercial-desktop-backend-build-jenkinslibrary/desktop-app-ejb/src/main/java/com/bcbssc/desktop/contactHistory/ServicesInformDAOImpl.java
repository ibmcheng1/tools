/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2017 BLUECROSS BLUESHIELD OF SOUTH CAROLINA.
 * ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.contactHistory;

import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.services.BaseServiceIntegrator;
import com.bcbssc.desktop.util.services.interceptor.ServicesDataAccessExceptionInterceptor;
import com.bcbssc.domain.entity.InformSearchCriteria;
import com.bcbssc.domain.entity.inform.InformRecord;
import com.bcbssc.services.customercontactlist.v1.CustomerContactList;
import com.bcbssc.services.customercontactlist.v1.CustomerContactListRequest;
import com.bcbssc.services.customercontactlist.v1.CustomerContactList_Service;
import com.bcbssc.services.customercontactlist.v1.CustomerContactListlnformation;
import com.bcbssc.services.customercontactlist.v1.RequestorVerbiageInformation;
import com.bcbssc.services.customercontactlist.v1.SearchByDateRange;
import com.bcbssc.services.customercontactlist.v1.SearchByGroup;
import com.bcbssc.services.customercontactlist.v1.SearchByKeyId;
import com.bcbssc.services.customercontactlist.v1.SearchByRequestorWorkloadInfo;
import com.bcbssc.services.customercontactlist.v1.SearchProcessingComponents;
import com.bcbssc.services.customercontactlist.v1.ServiceResponse;
import com.bcbssc.services.customercontactlist.v1.SubsequentServiceCallInformation;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.jws.HandlerChain;
import javax.xml.ws.WebServiceRef;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Stateless
@Local
@Interceptors({ServicesDataAccessExceptionInterceptor.class})
public class ServicesInformDAOImpl extends BaseServiceIntegrator<CustomerContactList, InformSearchCriteria, CustomerContactListRequest, ServiceResponse, Map<String, Object>> implements InformDAO {

    private static final Log log = LogFactory.getLog(ServicesInformDAOImpl.class);

    private static final String MORE_DATA = "more";
    private static final String RESULTS_LIST = "results";
    private static final String MORE_DATA_FLAG_YES = "Y";
    private static final String UNDEFINED_CODE = "Undefined Code ";
    private static final String NAME_NOT_FOUND = "NAME NOT FOUND";

    private static final String BACKWARD_PAGING_INDICATOR = "2";

    @HandlerChain(file = "../dao/services/handlerchain/datapower-service-with-credentials-handler-chain.xml")
    @WebServiceRef(wsdlLocation = "META-INF/wsdl/CustomerContactList.wsdl", value=CustomerContactList_Service.class)
    private CustomerContactList service;

    @Override
    @Interceptors({ServicesDataAccessExceptionInterceptor.class})
    public List<InformRecord> getInformRecords(InformSearchCriteria searchCriteria) throws Exception {
        final List<InformRecord> records = new ArrayList<>();
        boolean allRecordsFound = false;

        if (searchCriteria != null) {
            while (!allRecordsFound) {
                // Consume the service
                final Map<String, Object> results = this.consumeService(searchCriteria);

                records.addAll((List<InformRecord>) results.get(RESULTS_LIST));

                final Object lastTimeStamp = results.get(MORE_DATA);

                if ((null == lastTimeStamp) || !searchCriteria.isEnabledPaging()) {
                    if(log.isDebugEnabled() && (null != lastTimeStamp) && !searchCriteria.isEnabledPaging()) {
                        log.debug("More records found, but paging has been disabled by requesting code.  Not calling CustomerContactList again.");
                    }
                    allRecordsFound = true;
                } else {
                    if (log.isDebugEnabled()) {
                        log.debug("More records found.  Must run CustomerContactList again.");
                    }
                    final Date lastTimeStampDate = (Date)lastTimeStamp;
                    searchCriteria.setLastTimeStamp(lastTimeStampDate);
                }
            }
        } else {
            throw new IllegalArgumentException("A searchCriteria is required.");
        }
        return records;
    }

    @Override
    protected String getServiceName() {
        return CustomerContactList.class.getSimpleName();
    }

    @Override
    public void setService(CustomerContactList service) {
        this.service = service;
    }

    /**
     * Gets the service.
     *
     * @return Returns the service.
     */
    @Override
    public CustomerContactList getService() {
        return service;
    }

    @Override
    public CustomerContactListRequest mapInput(InformSearchCriteria searchCriteria) {
        final CustomerContactListRequest input = new CustomerContactListRequest();

        //Key ID is the subscriber ID
        final SearchByGroup searchByGroup = new SearchByGroup();
        final SearchByKeyId searchByKeyId = new SearchByKeyId();
        searchByGroup.setSearchByKeyId(searchByKeyId);
        searchByKeyId.setKeyId(searchCriteria.getKeyId());
        input.setSearchByGroup(searchByGroup);

        input.setRacfId(SubjectUtils.getRacfId(SubjectUtils.getCurrentSubject()));
        input.setTransactionId(SubjectUtils.getClient(SubjectUtils.getCurrentSubject()).getInformQualifier());

        //Date range should always be passed by the Desktop
        final SearchByDateRange searchByDateRange = new SearchByDateRange();
        searchByDateRange.setBeginDate(searchCriteria.getBeginDate());
        searchByDateRange.setEndDate(searchCriteria.getEndDate());
        input.setSearchByDateRange(searchByDateRange);

        input.setStatusTypeFilter(searchCriteria.getStatus());

        final Date lastTimeStampDate = searchCriteria.getLastTimeStamp();
        if(null != lastTimeStampDate) {
            final SubsequentServiceCallInformation subsequentServiceCallInformation = new SubsequentServiceCallInformation();
            subsequentServiceCallInformation.setPreviousKeyIdTimeStamp(lastTimeStampDate);
            input.setSubsequentServiceCallInformation(subsequentServiceCallInformation);
        }

        final String companyCode = searchCriteria.getCompanyCode();
        if(StringUtils.isNotBlank(companyCode)) {
            final SearchByRequestorWorkloadInfo searchByRequestorWorkloadInfo = new SearchByRequestorWorkloadInfo();
            searchByRequestorWorkloadInfo.setRequestorWorkloadCompanyCode(companyCode);
            input.setSearchByRequestorWorkloadInfo(searchByRequestorWorkloadInfo);
        }

        //Make sure backwards paging is enabled, so the service always returns the newest records first if there are
        //multiple pages
        final SearchProcessingComponents searchProcessingComponents = new SearchProcessingComponents();
        searchProcessingComponents.setPagingIndicator(BACKWARD_PAGING_INDICATOR);
        input.setSearchProcessingComponents(searchProcessingComponents);

        return input;
    }

    @Override
    public ServiceResponse invokeService(CustomerContactListRequest input, CustomerContactList service) {
        return service.getCustomerContactList(input);
    }

    @Override
    public Map<String, Object> mapOutput(ServiceResponse output) {
        final Map<String, Object> results = new HashMap<>();

        final List<CustomerContactListlnformation> customerContactList = output.getCustomerContactListlnformation();
        final List<InformRecord> informRecords = new ArrayList<>(customerContactList.size());

        //If there is more data, return the last timestamp in the map
        if(StringUtils.trimToEmpty(output.getMoreDataIndicator()).equalsIgnoreCase(MORE_DATA_FLAG_YES)) {
            results.put(MORE_DATA, output.getLastTimeStamp());
        }

        for (final CustomerContactListlnformation customerContactlnformation : customerContactList) {
            final InformRecord record = new InformRecord();
            record.setKeyId(StringUtils.trimToEmpty(customerContactlnformation.getKeyIdReturned()));
            record.setAltKeyId(StringUtils.trimToEmpty(customerContactlnformation.getAlternateKeyIdReturned()));
            record.setClaimNumber(StringUtils.trimToEmpty(customerContactlnformation.getClaimNumber()));
            record.setCompanyCode(StringUtils.trimToEmpty(customerContactlnformation.getCompanyCode()));
            record.setCorporationCode(StringUtils.trimToEmpty(customerContactlnformation.getCorporationCode()));
            record.setCorrReceivedDate(customerContactlnformation.getCorrespondenceReceivedDate());
            record.setCorrespondenceName(customerContactlnformation.getCorrespondenceName());
            record.setCustomerClassCode(customerContactlnformation.getCustomerClassCode());
            record.setDepartmentCode(StringUtils.trimToEmpty(customerContactlnformation.getDepartmentCode()));
            record.setDivisionCode(StringUtils.trimToEmpty(customerContactlnformation.getDivisionCode()));
            record.setDocumentNumber(StringUtils.trimToEmpty(customerContactlnformation.getDocumentNumber()));
            record.setEmployeeId(StringUtils.trimToEmpty(customerContactlnformation.getEmployeeId()));
            record.setEmployeeReceivedDate(customerContactlnformation.getEmployeeReceivedDate());
            record.setLocationCode(StringUtils.trimToEmpty(customerContactlnformation.getLocationCode()));
            record.setRequestCode(StringUtils.trimToEmpty(customerContactlnformation.getRequestCode()));
            record.setSourceCode(StringUtils.trimToEmpty(customerContactlnformation.getSourceCode()));
            record.getStatusCode().setType(StringUtils.trimToEmpty(customerContactlnformation.getStatusType()));
            record.setTimestamp(StringUtils.trimToEmpty(customerContactlnformation.getLogTimestamp()));
            record.setType(StringUtils.trimToEmpty(customerContactlnformation.getTypeCode()));
            record.setRequestEmployeeId(StringUtils.trimToEmpty(customerContactlnformation.getRequestorEmployeeId()));
            record.setRequestorDepartmentCode(customerContactlnformation.getRequestorDepartmentCode());
            record.setRequestorDivisionCode(customerContactlnformation.getRequestorDivisionCode());

            final RequestorVerbiageInformation  requestVerbiageInformation = customerContactlnformation.getRequestorVerbiageInformation();

            String requestVerbiage = StringUtils.EMPTY;

            if(null != requestVerbiageInformation) {
                requestVerbiage = StringUtils.trimToEmpty(requestVerbiageInformation.getVerbiage1());
                requestVerbiage += StringUtils.trimToEmpty(requestVerbiageInformation.getVerbiage2());
                requestVerbiage += StringUtils.trimToEmpty(requestVerbiageInformation.getVerbiage3());
                requestVerbiage += StringUtils.trimToEmpty(requestVerbiageInformation.getVerbiage4());
            }

            if(customerContactlnformation.getDescriptionInformation() != null) {
                record.setSourceCodeDesc(customerContactlnformation.getDescriptionInformation().getSourceCodeDesc());

                if (StringUtils.isBlank(requestVerbiage)) {
                    requestVerbiage = StringUtils.trimToEmpty(customerContactlnformation.getDescriptionInformation().getRequestCodeDesc());
                }

                String ownerName = StringUtils.trimToEmpty(customerContactlnformation.getDescriptionInformation().getEmployeeName());
                if (StringUtils.isBlank(ownerName)) {
                    ownerName = NAME_NOT_FOUND;
                }
                record.setEmployeeName(ownerName);
            }

            if (StringUtils.isBlank(requestVerbiage)) {
                requestVerbiage = UNDEFINED_CODE + customerContactlnformation.getRequestCode();
            }

            record.setRequestVerbiage(requestVerbiage);

            informRecords.add(record);
        }

        results.put(RESULTS_LIST, informRecords);

        return results;
    }
}
