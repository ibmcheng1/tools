/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.desktop.familySummary;

import com.bcbssc.desktop.dao.MemberDAO;
import com.bcbssc.desktop.util.auth.ContextSubjectUtils;
import com.bcbssc.desktop.util.services.interceptor.ServicesDataAccessExceptionInterceptor;
import com.bcbssc.domain.entity.Member;
import com.bcbssc.domain.entity.MemberSearchCriteria;
import com.bcbssc.domain.entity.PaiMember;
import com.bcbssc.services.managedcarepatientlist.ManagedCarePatientListInput;
import com.bcbssc.services.managedcarepatientlist.ManagedCarePatientListOutput;
import com.bcbssc.services.managedcarepatientlist.ManagedCarePatientListPatientRecord;
import com.bcbssc.services.managedcarepatientlist.ManagedCarePatientListService;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Service Implementation to retrieve @PaiMember List
 *
 */
@Stateless(name = "paiMemberDAO")
@Local
@Interceptors({ServicesDataAccessExceptionInterceptor.class})
public class ServicesManagedCarePatientListImpl implements MemberDAO {
    /**
     * Logger for this class.
     */
    private static final Log log = LogFactory.getLog(ServicesManagedCarePatientListImpl.class);

    /**
     * PAI patients live in the TMCS subsystem, so make sure we look up the user's RPN when calling the service.
     */
    private static final String SUBSYSTEM_RPN_TMCS = "TMCS";

    /*
     * Method not currently implemented
     * @see com.bcbssc.desktop.dao.MemberDAO#getMember(java.lang.String, java.lang.String)
     * */
    @Override
    public Member getMember(String subscriberId, String memberId)
                    throws Exception {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /*
     * Consume the PatientList web service
     *
     * @see com.bcbssc.desktop.dao.MemberDAO#getSubscriberMembers(java.lang.String)
     *
     * */
    @Override
    @SuppressWarnings("unchecked")
    public Set getSubscriberMembers(String subscriberId) {
        //        WebServiceConsumerTemplate template = new WebServiceConsumerTemplate();
        //        WebServiceConsumerCallback consumerCallback = new ManagedCarePatientListWebService(subscriberId);
        //        return (Set) template.consumeService(null, consumerCallback);
        throw new UnsupportedOperationException("This class needs to be redone to use the BaseServicesIntegrator");
    }


    /*
     * Method not implemented
     * @param searchCriteria the search criteria to use for searching
     * @see com.bcbssc.desktop.dao.MemberDAO#searchForMember(com.bcbssc.domain.entity.MemberSearchCriteria)
     * */
    @Override
    @SuppressWarnings("unchecked")
    public List searchForMember(MemberSearchCriteria searchCriteria) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    protected ManagedCarePatientListService getManagedCarePatientListService(){
        //return (ManagedCarePatientListService) new ServiceClientGenerator("ManagedCarePatientList").getServiceClient();
        throw new UnsupportedOperationException("This class needs to be converted to extend the BaseServicesIntegrator");
    }

    /**
     * Manager care call back service for mapping the response to the appropriate return type
     *
     * @author $Author$  (original: XAA7)
     * @version $Revision$
     */
    private class ManagedCarePatientListWebService {
        private final String subscriberId;
        public ManagedCarePatientListWebService(String subscriberId){
            this.subscriberId = subscriberId;
        }

        /*
         * Returns the ManagedCarePatientListService
         *
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#getService()
         * */
        public Object getService() {
            return getManagedCarePatientListService();
        }

        /*
         * Invokes the ManagedCarePatientList service and returns
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#invokeService(java.lang.Object, java.lang.Object) */
        public Object invokeService(Object serviceInput, Object serviceClient) throws Exception {
            final ManagedCarePatientListService service = (ManagedCarePatientListService) serviceClient;
            final ManagedCarePatientListOutput output = service.getManagedCarePatientList((ManagedCarePatientListInput) serviceInput);
            return output;
        }

        /*
         * Maps the input to the appropriate type
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#mapInput(java.lang.Object)
         * */
        public Object mapInput(Object unsused) {
            final ManagedCarePatientListInput input = new ManagedCarePatientListInput();
            input.setRpn(ContextSubjectUtils.getCurrentRpn(SUBSYSTEM_RPN_TMCS));
            input.setPlanCode(ContextSubjectUtils.getCurrentPlanCode());
            input.setSubscriberId(subscriberId);

            if (log.isDebugEnabled()) {
                final StringBuilder buff = new StringBuilder(128);
                buff.append("TMCS RPN: ").append(input.getRpn());
                buff.append("Current Plan Code: ").append(input.getPlanCode());
                log.debug(buff.toString());
            }

            return input;
        }

        /*
         * Maps the response to the appropriate type
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#mapOutput(java.lang.Object)
         * */
        public Object mapOutput(Object serviceOutput) {
            final ManagedCarePatientListOutput output = (ManagedCarePatientListOutput) serviceOutput;
            final List<ManagedCarePatientListPatientRecord> result = output.getPatientRecord().getManagedCarePatientListPatientRecord();
            final Set<PaiMember> paiMembers = new HashSet<>();
            for(final ManagedCarePatientListPatientRecord patientInfo: result) {
                if (StringUtils.isBlank(patientInfo.getPatientId())) {
                    break;
                }

                final PaiMember member = new PaiMember();
                member.setMemberId(patientInfo.getPatientId());
                member.getName().setFirstName(patientInfo.getPatientName());
                member.setBirthdate(patientInfo.getPatientDateOfBirth());
                member.setSexCode(patientInfo.getPatientGenderAndRltnshpCd());
                member.setRelationshipCode(patientInfo.getPatientGenderAndRltnshpCd());
                paiMembers.add(member);
            }
            return paiMembers;
        }
    }
}
