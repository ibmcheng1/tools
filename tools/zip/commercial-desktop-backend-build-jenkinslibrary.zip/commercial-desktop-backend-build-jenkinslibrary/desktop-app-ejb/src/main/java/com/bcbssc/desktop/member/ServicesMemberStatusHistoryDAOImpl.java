/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.desktop.member;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import com.bcbssc.desktop.dao.MemberStatusHistoryDAO;
import com.bcbssc.desktop.util.auth.ContextSubjectUtils;
import com.bcbssc.desktop.util.services.interceptor.ServicesDataAccessExceptionInterceptor;
import com.bcbssc.domain.entity.Member;
import com.bcbssc.domain.entity.MemberStatusHistoryCriteria;
import com.bcbssc.domain.entity.codes.MaritalStatusCode;
import com.bcbssc.domain.entity.codes.OverAgeDependentCode;
import com.bcbssc.domain.entity.codes.SexCode;
import com.bcbssc.domain.entity.enums.Subsystems;
import com.bcbssc.domain.valueobject.PrincipalName;
import com.bcbssc.services.memberstatushistory.MemberStatusHistoryInput;
import com.bcbssc.services.memberstatushistory.MemberStatusHistoryMemberStatusInformation;
import com.bcbssc.services.memberstatushistory.MemberStatusHistoryOutput;
import com.bcbssc.services.memberstatushistory.MemberStatusHistoryService;

/**
 * Service Implementation to retrieve member status information.
 *
 */
@Stateless
@Remote
@Interceptors({ServicesDataAccessExceptionInterceptor.class})
public class ServicesMemberStatusHistoryDAOImpl implements MemberStatusHistoryDAO {

    private static final Logger log = Logger.getLogger(ServicesMemberStatusHistoryDAOImpl.class.getName());

    @Override
    public List<Member> getMemberStatusHistory(MemberStatusHistoryCriteria criteria) {
        //        WebServiceConsumerCallback consumerCallback = new MemberStatusHistoryWebService(criteria);
        //        return (List<Member>) new WebServiceConsumerTemplate().consumeService(null, consumerCallback);
        throw new UnsupportedOperationException("This class needs to be redone to use the BaseServicesIntegrator");
    }

    /**
     * Returns the binding stub for the MemberStatusHistory web service.
     * @return The binding stub for the MemberStatusHistory web service.
     */
    protected Object getMemberStatusHistoryService() {
        //return new ServiceClientGenerator("MemberStatusHistory").getServiceClient();
        throw new UnsupportedOperationException("This class needs to be updated to extend BaseServiceIntegrator");
    }

    /**
     * Protected class that is used to map the input to the web service, invoke the web service and
     * map the output from the web service. This class is to be used with the
     * (or in BCBSSC terms, SCI).
     */
    protected class MemberStatusHistoryWebService {
        private static final String BACKWARDS_DATE_FORMAT = "dd/MM/yyyy";
        private static final String UNKNOWN_DESCRIPTION = "UNKNOWN";
        private static final String FEMALE_DESCRIPTION = "FEMALE";
        private static final String MALE_DESCRIPTION = "MALE";
        private static final String UNKNOWN_CODE = "U";
        private static final String FEMALE_CODE = "F";
        private static final String MALE_CODE = "M";
        private static final String FOUR_DIGIT_YEAR = "MM/dd/yyyy";
        private static final String TWO_DIGIT_YEAR = "MM/dd/yy";
        private static final String SERVICE_TRUE_INDICATOR = "Y";
        private final MemberStatusHistoryCriteria criteria;

        /**
         * Constructor used to populate the search criteria
         * @param criteria {@link MemberStatusHistoryCriteria} object to use.
         */
        protected MemberStatusHistoryWebService(MemberStatusHistoryCriteria criteria) {
            this.criteria = criteria;
        }

        /** (non-Javadoc)
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#getService()
         */
        public Object getService() {
            return getMemberStatusHistoryService();
        }

        /** (non-Javadoc)
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#invokeService(java.lang.Object, java.lang.Object)
         */
        public Object invokeService(Object serviceInput, Object serviceClient) throws Exception {
            final MemberStatusHistoryService service = (MemberStatusHistoryService) serviceClient;
            final MemberStatusHistoryOutput output = service.getMemberStatusHistory((MemberStatusHistoryInput) serviceInput);
            return output;
        }

        /** (non-Javadoc)
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#mapInput(java.lang.Object)
         */
        public Object mapInput(Object unused) {
            final MemberStatusHistoryInput input = new MemberStatusHistoryInput();
            input.setSubscriberId(criteria.getSubscriberId());
            input.setMemberNumberRequested(criteria.getCesMemberId());
            input.setRpn(ContextSubjectUtils.getCurrentRpn(Subsystems.CISI.getName()));
            input.setToEscapeChar(true);
            return input;
        }

        /** (non-Javadoc)
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#mapOutput(java.lang.Object)
         */
        public Object mapOutput(Object serviceOutput) {
            final List<Member> memberStatusHistory = new ArrayList<>(10);
            final MemberStatusHistoryOutput output = (MemberStatusHistoryOutput) serviceOutput;
            final List<MemberStatusHistoryMemberStatusInformation> memberStatusInformation = output.getMemberStatusInformation().getMemberStatusHistoryMemberStatusInformation();
            for (final MemberStatusHistoryMemberStatusInformation record : memberStatusInformation) {
                // If this record has no data then stop.
                if (StringUtils.isBlank(record.getMemberNumber())) {
                    break;
                }
                Member entry = null;
                try {
                    entry = mapRecord(record);
                } catch (final Exception e) {
                    log.log(Level.SEVERE, "An error occured while mapping the member record returned by MemberStatusHistory", e);
                }

                if (null != entry) {
                    memberStatusHistory.add(entry);
                }
            }
            return memberStatusHistory;
        }

        /**
         * Map a service history record into a model history entry.
         *
         * @param record A populated record from the service.
         * @return The mapped history entry.
         * @throws Exception With a ParseException cause, if there was a issue parsing dates.
         */
        protected Member mapRecord(MemberStatusHistoryMemberStatusInformation record) throws Exception {
            final SimpleDateFormat twoDigitYearFormat = new SimpleDateFormat(TWO_DIGIT_YEAR);
            final SimpleDateFormat fourDigitYearFormat = new SimpleDateFormat(FOUR_DIGIT_YEAR);

            final Member entry = new Member();

            entry.setConfidentialClaimIndicator(SERVICE_TRUE_INDICATOR.equals(record.getConfidentialClaimIndicator()));

            final String recordBeginDate = record.getRecordBeginDate();
            try {
                entry.setRecordBeginDate(twoDigitYearFormat.parse(recordBeginDate));
            } catch (final ParseException ex) {
                throw new RuntimeException("Failed to parse recordBeginDate: \"" + recordBeginDate + "\" (a required field)", ex);
            }

            final String recordTermDate = record.getRecordTermDate();
            try {
                // If blank then record is current.
                if (StringUtils.isBlank(recordTermDate)) {
                    entry.setRecordTermDate(null);
                } else {
                    entry.setRecordTermDate(twoDigitYearFormat.parse(recordTermDate));
                }
            } catch (final ParseException ex) {
                throw new RuntimeException("Failed to parse recordTermDate: \"" + recordTermDate + "\"", ex);
            }

            final String originalEnrollDate = record.getOriginalEnrollDate();
            if (StringUtils.isNotBlank(originalEnrollDate)) {
                try {
                    entry.setOriginalEnrollmentDate(twoDigitYearFormat.parse(originalEnrollDate));
                } catch (final ParseException ex) {
                    throw new RuntimeException("Failed to parse originalEnrollDate: \"" + originalEnrollDate + "\"", ex);
                }
            }

            entry.setUnderstandsEnglish(SERVICE_TRUE_INDICATOR.equals(record.getUnderstandsEnglishIndicator()));
            entry.setCesMemberNumber(record.getMemberNumber());
            final PrincipalName memberName = new PrincipalName();
            memberName.setFirstName(record.getMemberFirstName());
            memberName.setMiddleName(StringUtils.defaultIfEmpty(record.getMemberMiddleName(), StringUtils.EMPTY));
            memberName.setLastName(record.getMemberLastName());
            memberName.setSuffixName(record.getMemberSuffix());
            memberName.setPrefixName(record.getMemberNameTitle());
            entry.setName(memberName);

            if (log.isLoggable(Level.FINEST)) {
                log.finest("The member name information is:\n" + ReflectionToStringBuilder.toString(memberName));
            }

            final SexCode memberSex = entry.getSex();
            final String memberGender = record.getMemberGender();
            memberSex.setCode(memberGender);
            if (MALE_CODE.equalsIgnoreCase(memberGender)) {
                memberSex.setDescription(MALE_DESCRIPTION);
            } else if (FEMALE_CODE.equalsIgnoreCase(memberGender)) {
                memberSex.setDescription(FEMALE_DESCRIPTION);
            } else if (UNKNOWN_CODE.equalsIgnoreCase(memberGender)) {
                memberSex.setDescription(UNKNOWN_DESCRIPTION);
            } else {
                memberSex.setDescription(memberGender);
            }

            final String memberDateOfBirth = record.getMemberDateOfBirth();
            if (StringUtils.isNotBlank(memberDateOfBirth)) {
                try {
                    entry.setDateOfBirth(fourDigitYearFormat.parse(memberDateOfBirth));
                } catch (final ParseException ex) {
                    throw new RuntimeException("Failed to parse memberDateOfBirth: \"" + memberDateOfBirth + "\"", ex);
                }
            }

            entry.setSocialSecurityNumber(record.getMemberSocialSecurityNumber());
            final MaritalStatusCode maritalStatus = entry.getMaritalStatus();
            maritalStatus.setCode(record.getMemberMaritalStatusCode());
            final String memberMaritalStatusDate = record.getMemberMaritalStatusDate();
            if (!StringUtils.isEmpty(memberMaritalStatusDate)) {
                try {
                    maritalStatus.setMaritalStatusDate(fourDigitYearFormat.parse(memberMaritalStatusDate));
                } catch (final ParseException ex) {
                    throw new RuntimeException("Failed to parse marital status date: \"" + memberMaritalStatusDate + "\"", ex);
                }
            }

            entry.setMedicareNumber(record.getMedicareNumber());
            final PrincipalName nickName1 = new PrincipalName();
            nickName1.setFirstName(record.getMemberNickName1());
            final PrincipalName nickName2 = new PrincipalName();
            nickName2.setFirstName(record.getMemberNickName2());
            final List<PrincipalName> alternateNames = entry.getAlternateNames();
            alternateNames.add(nickName1);
            alternateNames.add(nickName2);
            entry.setVisionPlanPatientId(record.getVisionPlanPatientId());
            entry.setPreviousMemberId(record.getPreviousMedPlanPatientId());
            entry.setMemberId(record.getCurrentMedPlanPatientId());
            entry.setUpdateByEmployee(StringUtils.defaultIfEmpty(record.getUpdatedByOperatorId(), StringUtils.EMPTY));

            //Tobacco Usage Code
            entry.getTobaccoUsage().setCode(record.getMemberTobaccoUsageIndicator());

            //Cancel Code
            entry.getCancelCode().setCode(record.getCancelCode());

            //Employment Status Code
            entry.getEmploymentStatus().setCode(record.getMemberEmployeeStatusInd());

            //Language Code
            entry.getPreferredLanguage().setCode(record.getPreferredLanguageCode());

            //Member Status Code
            entry.getMemberStatus().setCode(record.getMemberStatusCode());

            //Over Age Dependent Code
            final SimpleDateFormat overAgeDateFormatter = new SimpleDateFormat(BACKWARDS_DATE_FORMAT);
            Date overAgeDate = null;
            final String memberOverAgeCertifiedDate = record.getMemberOverAgeCertifiedDate();
            if (StringUtils.isNotEmpty(memberOverAgeCertifiedDate)) {
                try {
                    overAgeDate = overAgeDateFormatter.parse(memberOverAgeCertifiedDate);
                } catch (final ParseException ex) {
                    throw new RuntimeException("Error parsing Over Age Date", ex);
                }
            }
            final OverAgeDependentCode overAgeDependent = entry.getOverAgeDependent();
            overAgeDependent.setCode(record.getMemberOverAgeDependentInd());
            overAgeDependent.setCertifiedDate(overAgeDate);

            //Relationship Code
            entry.getRelationship().setCode(record.getMemberRelationship());

            //Suppress Id Cards Code
            entry.getSuppressIdCards().setCode(record.getSuppressIdCardsIndicator());

            final String memberUpdatedDate = record.getMemberUpdatedDate();
            if (StringUtils.isNotBlank(memberUpdatedDate)) {
                try {
                    entry.setUpdateDate(twoDigitYearFormat.parse(memberUpdatedDate));
                } catch (final ParseException ex) {
                    throw new RuntimeException("Failed to parse memberUpdatedDate: \"" + memberUpdatedDate + "\"", ex);
                }
            }

            final String memberSetupDate = record.getMemberSetupDate();
            if (StringUtils.isNotBlank(memberSetupDate)) {
                try {
                    entry.setSetupDate(twoDigitYearFormat.parse(memberSetupDate));
                } catch (final ParseException ex) {
                    throw new RuntimeException("Failed to parse memberSetupDate: \"" + memberSetupDate + "\"", ex);
                }
            }

            return entry;
        }
    }
}
