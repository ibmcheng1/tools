package com.bcbssc.desktop.dao;

import com.bcbssc.domain.cache.CacheableInput;
import com.bcbssc.domain.common.DomainObjectCloneable;
import com.bcbssc.wsutils.exception.WebServicesException;
import com.bcbssc.wsutils.util.FaultHelper;

import java.rmi.RemoteException;

public abstract class AbstractDaoCachingService <BackEndDataSourceType, DESKTOP_INPUT extends CacheableInput, BackEndInputType, BackEndOutputType, DESKTOP_OUTPUT extends DomainObjectCloneable<?>>
extends AbstractDaoCaching <BackEndDataSourceType, DESKTOP_INPUT, BackEndInputType, BackEndOutputType, DESKTOP_OUTPUT> {
	/** Services have a specific operation name. */
	@Override
	public abstract String getBackEndOperationName();

	@Override
	public void handleInvokeError(Exception ex) throws Exception {
		WebServicesException exceptionToThrow = null;
		if (ex instanceof WebServicesException) {
			exceptionToThrow = (WebServicesException) ex;
		} else {
			exceptionToThrow = new WebServicesException(ex);
		}
		throwTranslatedException(exceptionToThrow);
	}

    private void throwTranslatedException(WebServicesException exceptionToThrow) {
        Throwable cause = exceptionToThrow.getCause();
        if (cause != null) {
            this.translateFromCause(cause);
        }

        throw exceptionToThrow;
    }

    private void translateFromCause(Throwable cause) {
        if (cause instanceof RemoteException) {
            this.translateFromCause(((RemoteException)cause).detail);
        } else if (cause instanceof javax.xml.ws.soap.SOAPFaultException) {
            this.handleJaxWsFault((javax.xml.ws.soap.SOAPFaultException)cause);
        }

    }

    private void handleJaxWsFault(javax.xml.ws.soap.SOAPFaultException cause) {
        (new FaultHelper()).translateJaxWsFaultException(cause);
    }
}