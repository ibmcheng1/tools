/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.desktop.startup;

import java.io.Serializable;

/**
 * Request data to retrieve an application client list.
 *
 */
public class ClientListRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private String applicationId;
    private String rpn;

    public ClientListRequest(String applicationId, String rpn) {
        super();
        this.applicationId = applicationId;
        this.rpn = rpn;
    }

    public String getApplicationId() {
        return applicationId;
    }
    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }
    public String getRpn() {
        return rpn;
    }
    public void setRpn(String rpn) {
        this.rpn = rpn;
    }
}