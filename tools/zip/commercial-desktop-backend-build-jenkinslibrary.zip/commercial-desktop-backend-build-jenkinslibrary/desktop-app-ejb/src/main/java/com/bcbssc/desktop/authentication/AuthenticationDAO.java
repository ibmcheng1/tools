package com.bcbssc.desktop.authentication;

import com.bcbssc.desktop.dao.auth.NotAuthenticatedException;
import com.bcbssc.desktop.dao.auth.NotAuthorizedException;
import com.bcbssc.domain.entity.UserAuthenticationCriteria;

public interface AuthenticationDAO {

    public void authenticateUser(UserAuthenticationCriteria criteria) throws NotAuthenticatedException, NotAuthorizedException, Exception;
}
