@javax.xml.bind.annotation.XmlSchema(namespace = "http://ManagedCarePatientList.THLST101EJB.health.bcbssc.com")
package com.bcbssc.services.managedcarepatientlist;
