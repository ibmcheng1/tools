/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */

package com.bcbssc.desktop.member;

import com.bcbssc.desktop.dao.PatientDAO;
import com.bcbssc.desktop.util.services.CachingServiceIntegrator;
import com.bcbssc.desktop.util.services.interceptor.ServicesDataAccessExceptionInterceptor;
import com.bcbssc.domain.patientList.PatientListInputDesktop;
import com.bcbssc.domain.patientList.PatientListOutputDesktop;
import com.bcbssc.domain.patientList.PatientListRecord;
import com.bcbssc.services.patientlist.PatientListEligiblePatientList;
import com.bcbssc.services.patientlist.PatientListInput;
import com.bcbssc.services.patientlist.PatientListOutput;
import com.bcbssc.services.patientlist.PatientListService;
import com.bcbssc.services.patientlist.PatientListServiceService;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.jws.HandlerChain;
import javax.xml.ws.WebServiceRef;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * This class is an implementation of the PatientDAO interface.
 * This class contains the logic to consume the PatientList service.
 * It returns a List of Member objects that correspond to the Patients
 * that show on the SELG screen.
 *
 * https://dcmis.bcbssc.com/sites/sysdoc/ws/WebServiceDocumentation/PatientList/SDD/PatientList.doc
 */
@Stateless
@Interceptors({ServicesDataAccessExceptionInterceptor.class})
public class ServicesPatientListDAOImpl
extends CachingServiceIntegrator<PatientListService, PatientListInputDesktop, PatientListInput, PatientListOutput, PatientListOutputDesktop>
implements PatientDAO {
    private static final Log log = LogFactory.getLog(ServicesPatientListDAOImpl.class);

    private static final String SERVICE_NAME = "PatientList";

    @HandlerChain(file = "../dao/services/handlerchain/soax-service-handler-chain.xml")
    @WebServiceRef(wsdlLocation = "META-INF/wsdl/PatientList.wsdl", value = PatientListServiceService.class)
    private PatientListService service;

    protected int maxHit = 10;

    public ServicesPatientListDAOImpl() {
    }

    public ServicesPatientListDAOImpl(PatientListService service) {
        this.service = service;
    }

    /** By default we keep the cache entry around for 10 hits but can be programmatically change for JUnit. */
    @Override
    public int getMaxHitCount() {
        return maxHit;
    }

    @Override
    public PatientListOutputDesktop retrievePatientList(PatientListInputDesktop desktopInput) {
        return this.consumeService(desktopInput);
    }

    @Override
    public void setService(PatientListService service) {
        this.service = service;
    }

    @Override
    public String getBackEndSourceName() {
        return SERVICE_NAME;
    }

    @Override
    public String getBackEndOperationName() {
        return "getPatientList";
    }

    @Override
    protected String getServiceName() {
        return PatientListService.class.getSimpleName();
    }

    @Override
    public PatientListService getService() {
        return service;
    }

    @Override
    public PatientListInput mapInput(PatientListInputDesktop desktopInput) {
        final PatientListInput input = new PatientListInput();
        input.setRpn(desktopInput.getRpn());
        input.setSubscriberId(desktopInput.getSubscriberId());
        return input;
    }

    @Override
    public PatientListOutput invokeService(PatientListInput input, PatientListService service) throws Exception {
        return service.getPatientList(input);
    }

    @Override
    public PatientListOutputDesktop mapOutput(PatientListOutput backEndOutput) {
        final List<PatientListEligiblePatientList> patients = backEndOutput.getEligiblePatientList().getPatientListEligiblePatientList();
        final List<PatientListRecord> patientList = new ArrayList<>();
        final SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");

        for (final PatientListEligiblePatientList patient: patients) {
            // Since this service is backed by SELG, we better have an AMMS patient id.
            if (StringUtils.isEmpty(patient.getAmmsPatientIdNumber())) {
                break;
            }

            final PatientListRecord rec = new PatientListRecord();
            patientList.add(rec);
            rec.verifiedPatientIndicator = patient.getVerifiedPatientIndicator();
            rec.planCode = patient.getPlanCode();
            rec.ammsPatientIdNumber = patient.getAmmsPatientIdNumber();
            rec.cesMemberNumber = patient.getCesMemberNumber();
            rec.patientFirstName = patient.getPatientFirstName();
            rec.patientLastName = patient.getPatientLastName();
            rec.patientRelationshipDescription = patient.getPatientRelationshipDescription();
            rec.patientGender = patient.getPatientGender();
            rec.confidentialCommunicationsInd = patient.getConfidentialCommunicationsInd();

            //DOB
            final String dob = patient.getPatientDateOfBirth();
            try {
                if (StringUtils.isNotBlank(dob)) {
                    rec.patientDateOfBirth = dateFormatter.parse(dob);
                }
            } catch (final ParseException ex) {
                log.warn("Failed to parse the patient's date of birth:" + dob, ex);
            }
        }

        return new PatientListOutputDesktop(patientList);
    }
}
