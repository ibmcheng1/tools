/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2016 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.events;

import com.bcbssc.desktop.biz.EnvironmentBiz;
import com.bcbssc.desktop.biz.events.EventBiz;
import com.bcbssc.desktop.dao.events.EventDAO;
import com.bcbssc.desktop.dao.events.EventServiceDAO;
import com.bcbssc.desktop.util.dao.executor.WorkExecutor;
import com.bcbssc.desktop.util.dao.executor.WorkTask;
import com.bcbssc.desktop.util.jndi.JndiUtils;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;
import com.bcbssc.domain.entity.events.Event;
import com.bcbssc.domain.entity.events.EventsQueue;
import com.bcbssc.domain.entity.events.ResponseDataDTO;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.security.auth.Subject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Sends Event Management events.
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class EventBizBDImpl implements EventBiz {
    private static final String DATE_PATTERN = "yyyy-MM-dd";
    private static final String TIME_PATTERN = "HH.mm.ss";
    private static final String SUBMIT_EVENTS_FLAG = "SUBMIT_EVENTS";
    
    @EJB
    public EventDAO daoJms;

    @EJB
    public EventServiceDAO daoService;

    private static final Log log = LogFactory.getLog(EventBizBDImpl.class);

    private WorkTask<?> submitEvent(final Event eventData, final Subject subject) {
        return new WorkTask<Object>(SUBMIT_EVENTS_FLAG, subject, () -> daoService.sendEvent(eventData));
    }
    
    private WorkTask<?> submitEvents(final List<Event> events, final Subject subject) {
        return new WorkTask<Object>(SUBMIT_EVENTS_FLAG, subject, () -> daoService.sendEvents(events));
    }
    
    @Override
    public ResponseDataDTO sendEvent(final Event eventData, Subject subject) throws Exception {
        this.enforceDateTime(eventData);
        if (StringUtils.isBlank(eventData.getMapName())) {
            log.debug("mapName is Empty, Sending event by service...");
            List<WorkTask<?>> workTasks = new ArrayList<>();
            workTasks.add(submitEvent(eventData, subject));
//            WorkExecutor workExecutor = new WorkExecutor(workManager, workTasks, WorkManager.JOIN_AND, (int) WorkManager.IMMEDIATE);
//            workExecutor.executeWorkTasks();
//            return new ResponseDataDTO();
        } else {
            log.debug("mapName is not Empty, Sending event by JMS...");
//            return daoJms.sendEvent(eventData);
        }
        throw new UnsupportedOperationException("This methods needs to be fixed to not use IBM WorkManager");
    }

    @Override
    public ResponseDataDTO sendEventAllowQueue(Event event, Subject subject) throws Exception {
        ResponseDataDTO results = null;
        if(log.isTraceEnabled()) {
            log.trace("Event to be processed is: "+event);
        }
        this.enforceDateTime(event);
        if (StringUtils.isBlank(event.getMapName())) {
            // We can queue service events.
            synchronized (EventsQueue.savedOff) {
                if(!EventsQueue.initialized) {
                    initializeMaxServicePayload();
                }
                EventsQueue.savedOff.add(event);
                if(log.isDebugEnabled()) {
                    log.debug("Adding event to pool of events.  Size of pool is "+EventsQueue.savedOff.size()+"/"+EventsQueue.maxServicePayload);
                }
                if (EventsQueue.savedOff.size() >= EventsQueue.maxServicePayload) {
                    log.debug("Pool of events is full.  Sending to EVNT.");
                    results = this.flushQueue(subject);
                } else {
                    results = new ResponseDataDTO();
                    results.ResponseData = "event is queued";
                }
            }
        } else {
            // We don't want to queue JMS events.
            results = this.sendEvent(event, subject);
        }
        return results;
    }

    @Override
    public ResponseDataDTO flushQueue(Subject subject) throws Exception {
        ResponseDataDTO results = null;
        synchronized (EventsQueue.savedOff) {
            if(EventsQueue.savedOff.isEmpty()) {
                log.debug("Flush requested, but there are no events in the queue.  Not sending anything to EVNT.");
                //Set a response string
                results = new ResponseDataDTO();
                results.ResponseData = "";
            } else {
                log.debug("Flush requested.  Sending events to EVNT.");
                results = this.innerBulkSend(subject);
            }
        }
        return results;
    }

    /** This function assumes we already have a lock. */
    private ResponseDataDTO innerBulkSend(final Subject subject) throws Exception {
        List<WorkTask<?>> workTasks = new ArrayList<WorkTask<?>>();
        // Sending just a copy of the List<Event> object to the new thread to avoid race condition on clearing the object in the main thread.
        workTasks.add(submitEvents(new ArrayList<Event>(EventsQueue.savedOff), subject));
//        WorkExecutor workExecutor = new WorkExecutor(workManager, workTasks, WorkManager.JOIN_AND, (int) WorkManager.IMMEDIATE);
//        workExecutor.executeWorkTasks();
//        // Empty the queue in the main thread.
//        EventsQueue.savedOff.clear();
//        // Return empty DTO since the workTasks is configured as async
//        return new ResponseDataDTO();
        throw new UnsupportedOperationException("This methods needs to be fixed to not use IBM WorkManager");
    }

    /**
     * If the event doesn't have a date then create one.
     */
    protected void enforceDateTime(Event event) {
        if (StringUtils.isBlank(event.getDate())) {
            final Date now = new Date();
            SimpleDateFormat format = new SimpleDateFormat(DATE_PATTERN);
            event.setDate(format.format(now));
            format = new SimpleDateFormat(TIME_PATTERN);
            event.setTime(format.format(now));
        }
    }

    /**
     * Reads a REP and sets the max service payload value
     */
    private void initializeMaxServicePayload() {
        final EnvironmentBiz environmentBiz = JndiUtils.getEnvironmentBiz();
        String eventReportingPoolSizeString = environmentBiz.getCommon(EnvironmentObjects.EVENT_REPORTING_POOL_SIZE, String.class);

        int eventReportingPoolSize = Integer.parseInt(eventReportingPoolSizeString);
        EventsQueue.maxServicePayload = eventReportingPoolSize;
        EventsQueue.initialized = true;
    }
}
