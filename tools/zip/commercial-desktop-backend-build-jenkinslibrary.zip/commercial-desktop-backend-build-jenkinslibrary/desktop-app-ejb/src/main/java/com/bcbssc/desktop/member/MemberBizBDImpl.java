/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.member;

import java.security.PrivilegedExceptionAction;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.security.auth.Subject;

import org.apache.commons.lang.StringUtils;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.MemberBiz;
import com.bcbssc.desktop.dao.MemberDAO;
import com.bcbssc.desktop.dao.MemberStatusHistoryDAO;
import com.bcbssc.desktop.dao.PatientDAO;
import com.bcbssc.desktop.dao.TranslationLookupDAO;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.dao.DataRetrievalHandler;
import com.bcbssc.domain.entity.Member;
import com.bcbssc.domain.entity.MemberStatusHistoryCriteria;
import com.bcbssc.domain.entity.codes.RelationshipCode;
import com.bcbssc.domain.patientList.PatientListInputDesktop;
import com.bcbssc.domain.patientList.PatientListOutputDesktop;
import com.bcbssc.domain.valueobject.MenuLink;

/**
 * This is an implementation of {@link MemberBiz} for member information retrieval
 * 
 * @author jc33
 */
@Stateless
@Remote
public class MemberBizBDImpl implements MemberBiz {

	@EJB(beanName = "ammsMemberDAO")
	private MemberDAO memberDAO;
	@EJB
	private MemberStatusHistoryDAO memberStatusHistoryDAO;
	@EJB
	private TranslationLookupDAO translationLookupDAO;

	/** protected for JUnit. */
	@EJB
	protected PatientDAO patientDAO;

	private static final String RETRIEVE_MEMBER_INFO = "RETRIEVE_MEMBER_INFO";
	private static final String RETRIEVE_MEMBER_STATUS_HISTORY = "RETRIEVE_MEMBER_STATUS_HISTORY_INFO";
	private static final String LOOKUP_TRANSLATION_FLAG = "LOOKUP_TRANSLATION";
	private static final String RETRIEVE_PATIENT_LIST_TASK = "RETRIEVE_PATIENT_LIST_SERVICE";
	
	private static final Logger log = Logger.getLogger(MemberBizBDImpl.class.getName());

	@Override
	public Member getMember(final String subscriberId, final String memberId, final Subject subject) throws Exception {
		Member result = null;
		Map<String, ?> rulesEntries = DesktopAPI.getRulesEntries(subject);
		Map<String, MenuLink> userConfigs = (Map<String, MenuLink>) rulesEntries.get(MenuLink.FUNCTION_TYPE_USERCONFIG);
		final MenuLink retrieveMemberInfo = userConfigs.get(RETRIEVE_MEMBER_INFO);
		if (DataRetrievalHandler.runDataRetrieval(retrieveMemberInfo)) {
			try {
				result = SubjectUtils.runAsSubject(new PrivilegedExceptionAction<Member>() {
					@Override
					public Member run() throws Exception {
						return memberDAO.getMember(subscriberId, memberId);
					}
				}, subject);
			} catch (Exception exception) {
				DataRetrievalHandler.handleDataRetrievalException(retrieveMemberInfo, exception);
			}
		}
		return result;
	}

	@Override
	public List<Member> retrieveStatusHistory(String subscriberId, String memberId, Subject subject) throws Exception {
		if (StringUtils.isBlank(subscriberId)) {
			throw new Exception("A subscriber ID is required to call MemberBizBDImpl.retrieveStatusHistory()");
		}
		if (StringUtils.isBlank(memberId)) {
			throw new Exception("A member ID is required to call MemberBizBDImpl.retrieveStatusHistory()");
		}
		if (null == subject) {
			throw new Exception("A subject is required to call MemberBizBDImpl.retrieveStatusHistory()");
		}

		//Declarations
		List<Member> statusHistory = null;
		final MemberStatusHistoryCriteria criteria = new MemberStatusHistoryCriteria();
		Map<String, ?> rulesEntries = DesktopAPI.getRulesEntries(subject);
		Map<String, MenuLink> userConfigs = (Map<String, MenuLink>) rulesEntries.get(MenuLink.FUNCTION_TYPE_USERCONFIG);
		final MenuLink retrieveStatusHistoryInfo = userConfigs.get(RETRIEVE_MEMBER_STATUS_HISTORY);

		//Set appropriate attribute values on the MemberStatusHistoryCriteria Object
		criteria.setSubscriberId(subscriberId);
		criteria.setCesMemberId(memberId);

		//Let's call the service - YEEEHAAA!!	   
		if (DataRetrievalHandler.runDataRetrieval(retrieveStatusHistoryInfo)) {
			try {
				statusHistory = SubjectUtils.runAsSubject(new PrivilegedExceptionAction<List<Member>>() {
					@Override
					public List<Member> run() throws Exception {
						return memberStatusHistoryDAO.getMemberStatusHistory(criteria);
					}
				}, subject);
			} catch (Exception exception) {
				DataRetrievalHandler.handleDataRetrievalException(retrieveStatusHistoryInfo, exception);
			}
		}

		//Iterate over the members and translate the relationship codes if the statusHistory is not null
		if (null != statusHistory) {
			if (log.isLoggable(Level.FINEST)) {
				log.finest("About to perform Relationship translations on the members");
			}

			MenuLink lookupTranslationLink = userConfigs.get(LOOKUP_TRANSLATION_FLAG);
			String relationshipName = null;

			if (DataRetrievalHandler.runDataRetrieval(lookupTranslationLink)) {
				try {
					for (Member member : statusHistory) {
						//perform relationship name lookup
						RelationshipCode memberRelationship = member.getRelationship();
						final String relationshipCode = memberRelationship.getCode();
						relationshipName = SubjectUtils.runAsSubject(new PrivilegedExceptionAction<String>() {
							@Override
							public String run() throws Exception {
								return translationLookupDAO.lookupTranslation(TranslationLookupDAO.FIELD_ID_CES_RELATIONSHIP, relationshipCode);
							}
						}, subject);
						if (StringUtils.isNotBlank(relationshipName)) {
							//Store the relationship name on the member
							memberRelationship.setDescription(relationshipName);
						}
					}
				} catch (Exception ex) {
					DataRetrievalHandler.handleDataRetrievalException(lookupTranslationLink, ex);
				}
			}
		}

		return statusHistory;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Member> retrievePatientList(String subId, Subject subject) throws Exception {
		if (StringUtils.isBlank(subId)) {
			throw new Exception("A subscriber ID is required to call MemberBizBDImpl.retrievePatientList()");
		}
		if (null == subject) {
			throw new Exception("A subject is required to call MemberBizBDImpl.retrievePatientList()");
		}
		
		List<Member> patientList = null;
		final String subscriberId = subId;

		Map<String, ?> rulesEntries = DesktopAPI.getRulesEntries(subject);
		Map<String, MenuLink> userConfigs = (Map<String, MenuLink>) rulesEntries.get(MenuLink.FUNCTION_TYPE_USERCONFIG);
		final MenuLink retrievePatientListMenuLink = userConfigs.get(RETRIEVE_PATIENT_LIST_TASK);
		
		if (DataRetrievalHandler.runDataRetrieval(retrievePatientListMenuLink)) {
			try {
				patientList = SubjectUtils.runAsSubject(new PrivilegedExceptionAction<List<Member>>() {
					@Override
					public List<Member> run() throws Exception {
						PatientListInputDesktop desktopInput = new PatientListInputDesktop(subscriberId);
						PatientListOutputDesktop desktopOutput = patientDAO.retrievePatientList(desktopInput);
						return desktopOutput.toListMember();
					}
				}, subject);
			} catch (Exception exception) {
				DataRetrievalHandler.handleDataRetrievalException(retrievePatientListMenuLink, exception);
			}
		}
		
		return patientList;
	}

	@Override
	public List<Member> retrievePatientListFilter(final String subscriberId, final String planCode, Subject subject) throws Exception {
		List<Member> results = SubjectUtils.runAsSubject(new PrivilegedExceptionAction<List<Member>>() {
			@Override
			public List<Member> run() throws Exception {
				PatientListInputDesktop desktopInput = new PatientListInputDesktop(subscriberId);
				PatientListOutputDesktop desktopOutput = patientDAO.retrievePatientList(desktopInput);
				return desktopOutput.toListMember(planCode);
			}
		}, subject);

		return results;
	}
}
