/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.startup;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.security.auth.Subject;

import org.apache.commons.lang.StringUtils;

import com.bcbssc.desktop.biz.ClientListBiz;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.ApplicationClient;
import com.bcbssc.domain.entity.Subsystem;

/**
 * This class will hold business logic for retrieving client list and rpn
 * subsystems data.
 */
@Stateless
@Remote
public class ClientListBizBDImpl implements ClientListBiz {

    @EJB
    private ApplicationClientDAO applicationClientDao;
    @EJB
    private SubsystemRpnDAO subsystemRpnDAO;

    /**
     * Constructor (Empty)
     */
    public ClientListBizBDImpl() {
    }

    @Override
    public ArrayList<ApplicationClient> getClientList(Subject subject) throws Exception {
        return SubjectUtils.runAsSubject((() -> applicationClientDao.getClientList()), subject);
    }

    @Override
    public HashMap<String, Subsystem> getSubsystemRpns(final String keyRpn, Subject subject) throws Exception {
        return SubjectUtils.runAsSubject((() -> subsystemRpnDAO.getSubsystemRpns(keyRpn)), subject);
    }

    @Override
    public String getDefaultClientId(String applicationId) throws IOException {
        String defaultClientId;
        // get the properties file that contains the defaults
        final InputStream in = DesktopStartupBizBDImpl.class
                        .getResourceAsStream("/com/bcbssc/desktop/startup/client.properties");
        final Properties props = new Properties();
        props.load(in);

        defaultClientId = props.getProperty(StringUtils.lowerCase(applicationId) + ".default.client.id",
                        StringUtils.EMPTY);

        return defaultClientId;
    }

    /**
     * @return the subsystemRpnDAO
     */
    public SubsystemRpnDAO getSubsystemRpnDAO() {
        return subsystemRpnDAO;
    }

    /**
     * @param subsystemRpnDAO the subsystemRpnDAO to set
     */
    public void setSubsystemRpnDAO(SubsystemRpnDAO subsystemRpnDAO) {
        this.subsystemRpnDAO = subsystemRpnDAO;
    }
}
