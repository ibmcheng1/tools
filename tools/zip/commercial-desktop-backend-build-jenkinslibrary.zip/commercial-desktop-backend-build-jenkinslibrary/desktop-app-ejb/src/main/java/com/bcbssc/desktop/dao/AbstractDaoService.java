package com.bcbssc.desktop.dao;

/** A non caching service backed DAO. */
public abstract class AbstractDaoService <BackEndDataSourceType, DESKTOP_INPUT, BackEndInputType, BackEndOutputType, DESKTOP_OUTPUT>
extends AbstractDao <BackEndDataSourceType, DESKTOP_INPUT, BackEndInputType, BackEndOutputType, DESKTOP_OUTPUT> {
	/** Services have a specific operation name. */
	@Override
	public abstract String getBackEndOperationName();
}