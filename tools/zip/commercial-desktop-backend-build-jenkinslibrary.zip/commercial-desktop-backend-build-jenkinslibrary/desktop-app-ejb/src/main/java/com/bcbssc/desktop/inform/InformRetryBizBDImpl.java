/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.inform;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Collection;
import java.util.Date;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.security.auth.Subject;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.biz.EnvironmentBiz;
import com.bcbssc.desktop.biz.inform.InformRetryBiz;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.jndi.JndiUtils;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;

/**
 * Used to resend failed INFOrm messages back to the host.
 * 
 * Default Retry Interval: 30 minutes Default Retry Hospital Threshold: 5 attempts Default Retry Throttle Time: 15 minutes
 * 
 * @author HX61
 * 
 */
@Remote
@Stateless
public class InformRetryBizBDImpl implements InformRetryBiz {

    private static final Log log = LogFactory.getLog(InformRetryBizBDImpl.class);

    @Resource
    private TimerService timerService;

    @EJB
    private SubmitInformDAO submitInformDao;

    @Resource(name = "inform.retry.interval")
    private Long retryInterval; // Value configured in milliseconds

    @Resource(name = "inform.retry.threshold")
    private Long retryThreshold;

    @Resource(name = "inform.retry.throttle.count")
    private Long retryThrottleCount;

    @Resource(name = "inform.retry.throttle.time")
    private Long retryThrottleTime;

    @Resource(name = "failure.log.location")
    private String failureLogLocation;

    @Resource(name = "hospital.log.location")
    private String hospitalLogLocation;

    public InformRetryBizBDImpl() {
        if (log.isInfoEnabled()) {
            log.info("Creating INFOrm retry EJB");
        }
    }

    /**
     * Initialize the EJB, lookup values from JNDI if not already set
     * 
     * @return boolean indicating if all required parameters were set
     */
    private boolean initEJB() {
        final EnvironmentBiz environmentBiz = JndiUtils.getEnvironmentBiz();
        boolean successfulInit = true;
        if (failureLogLocation == null) {
            try {
                failureLogLocation = environmentBiz.getCommon(EnvironmentObjects.FAILURE_LOG_LOCATION, String.class);
            } catch (IllegalStateException e) {
                log.error("Could not find the failure log location, will not be able to determine a location for the failure log files, not processing INFOrm retry routines", e);
                successfulInit = false;
            }
        }
        if (hospitalLogLocation == null) {
            try {
                hospitalLogLocation = environmentBiz.getCommon(EnvironmentObjects.HOSPITAL_LOG_LOCATION, String.class);
            } catch (IllegalStateException e) {
                log.error("Could not find the failure hospital log location, will not be able to determine a location for the hospital log files, not processing INFOrm retry routines", e);
                successfulInit = false;
            }
        }
        if (retryInterval == null) {
            retryInterval = environmentBiz.getCommon(EnvironmentObjects.INFORM_RETRY_INTERVAL, Long.class);
        }
        if (retryThreshold == null) {
            retryThreshold = environmentBiz.getCommon(EnvironmentObjects.INFORM_RETRY_THRESHOLD, Long.class);
        }
        if (retryThrottleCount == null) {
            retryThrottleCount = environmentBiz.getCommon(EnvironmentObjects.INFORM_RETRY_THROTTLE_COUNT, Long.class);
            if (retryThrottleCount == null) {
                log.warn("Could not find the retry throttle count (inform.retry.throttle.count), defaulting to a time based throttle");
            }
        }
        if (retryThrottleTime == null) {
            retryThrottleTime = environmentBiz.getCommon(EnvironmentObjects.INFORM_RETRY_THROTTLE_TIME, Long.class);
        }

        return successfulInit;
    }

    /**
     * Start the retry timer
     */
    public void startInformRetryTimer() {
        initEJB();
        if (log.isInfoEnabled()) {
            log.info("Starting INFOrm retry timer - running every " + retryInterval / 1000 / 60 + " minute(s)");
        }
        timerService.createTimer(retryInterval, retryInterval, "informRetryTimer");
    }

    /**
     * Cancels the timer
     */
    public void cancelInformRetryTimer() {
        Collection<Timer> timers = timerService.getTimers();
        for (Timer timer : timers) {
            timer.cancel();
        }
    }

    /**
     * Run the INFOrm retry procedure
     */
    public void runInformRetry() {
        runInformRetry(null);
    }

    /**
     * Run the INFOrm retry procedure
     * 
     * @param timer
     */
    @Timeout
    public void runInformRetry(Timer timer) {
        if (log.isInfoEnabled()) {
            log.info("Running INFOrm retry sequence");
        }
        boolean successfulInit = initEJB();
        if (log.isInfoEnabled()) {
            log.info("Looking up failure logs from: " + failureLogLocation);
        }
        if (successfulInit) {
            File file = new File(failureLogLocation);
            if (!file.exists()) {
                try {
                    file.mkdirs();
                } catch (Exception e) {
                    log.warn("Unable to create missing failure log directory: " + failureLogLocation, e);
                }
            }
            if (!file.isDirectory()) {
                log.warn("Skipping InformRetry; directory does not exist: " + failureLogLocation);
                return;
            }
            File[] fileList = file.listFiles();
            Integer availableFileCount = fileList.length;
            if (log.isInfoEnabled()) {
                log.info("Found " + availableFileCount + " INFOrm record(s) that need to be resent");
            }
            int processedFileCount = 0;
            Long endTimestamp = ((new Date()).getTime()) + retryThrottleTime;

            // Process each error file
            while (continueProcessing(endTimestamp, processedFileCount, availableFileCount)) {
                // Attempt to re-send the failed INFOrm message based on the metadata and contents
                // in the error file
                ErrorFileContent errorFileContent = parseRetryFile(fileList[processedFileCount]);
                if (errorFileContent != null) {
                    boolean successfulSend = false;
                    try {
                        final Subject subject = SubjectUtils.createEmptySubject();
                        SubjectUtils.setEnvironment(subject, errorFileContent.getEnvironment());
                        // Set the region in the subject from the error file only if it is not blank.
                        // Region will be blank only for older error files if any exist. Not setting
                        // the region in the subject just results in taking the non-region-specific
                        // INFOrm queue.
                        if (StringUtils.isNotBlank(errorFileContent.getRegion())) {
                            SubjectUtils.setRegion(subject, errorFileContent.getRegion());
                        }
                        submitInformDao.sendInformMessage(errorFileContent.getPayload(), false, subject);
                        successfulSend = true;
                    } catch (Exception exception) {
                        if (log.isErrorEnabled()) {
                            log.error("Error resubmitting INFOrm record.", exception);
                        }
                    }
                    if (successfulSend) {
                        // send was a success! remove the file
                        fileList[processedFileCount].delete();
                    } else {
                        // send was a failure! update the file
                        handleFailedRetry(errorFileContent);
                    }
                }
                processedFileCount++;
            }
        }
    }

    private boolean continueProcessing(Long endTimestamp, int processedFileCount, int availableFileCount) {

        boolean continueProcessing = false;
        if ((retryThrottleCount != null) && (retryThrottleCount > 0)) {
            // Use the count based throttle
            continueProcessing = ((processedFileCount < availableFileCount) && (processedFileCount < retryThrottleCount));
        } else {
            // Default to a time based throttle
            Long currentTimestamp = (new Date()).getTime();
            continueProcessing = ((processedFileCount < availableFileCount) && (currentTimestamp < endTimestamp));
        }
        return continueProcessing;
    }

    /**
     * Parse the error file to look for any meta data
     * 
     * @param retryFile
     * @return
     */
    private ErrorFileContent parseRetryFile(File retryFile) {
        ErrorFileContent errorFileContent = null;
        String contents = readFile(retryFile);

        if (StringUtils.isNotBlank(contents)) {
            errorFileContent = new ErrorFileContent();
            errorFileContent.setActualFile(retryFile);
            String[] fileContents = contents.split(InformUtil.META_DATA_DELIM);
            int retryCount = 0;
            String payload = null;
            String lastRetry = null;

            /* The error file may be in the old or new format, and may or may not have been retried before
             * 4 cases are handled:
             * 1) New format/not retried before
             * 2) New format/retried before
             * 3) Old format/not retried before
             * 4) Old format/retried before
             */

            if (fileContents.length > 1) {
                // The error file has metata
                payload = fileContents[1];
                if (fileContents[0].indexOf(InformUtil.META_DATA_DELIM_ENVIRONMENT) > -1) {
                    // New format
                    errorFileContent.setEnvironment(getDelimitedText(fileContents[0], InformUtil.META_DATA_DELIM_ENVIRONMENT, InformUtil.META_DATA_DELIM_REGION));
                    if (fileContents[0].indexOf(InformUtil.META_DATA_DELIM_LAST_RETRY) > 0) {
                        // Retried before
                        errorFileContent.setRegion(getDelimitedText(fileContents[0], InformUtil.META_DATA_DELIM_REGION, InformUtil.META_DATA_DELIM_LAST_RETRY));
                    } else {
                        // Not retried before
                        errorFileContent.setRegion(getDelimitedText(fileContents[0], InformUtil.META_DATA_DELIM_REGION, null));
                    }
                }
                if (fileContents[0].indexOf(InformUtil.META_DATA_DELIM_LAST_RETRY) > -1) {
                    // New or old format/retried before
                    lastRetry = getDelimitedText(fileContents[0], InformUtil.META_DATA_DELIM_LAST_RETRY, InformUtil.META_DATA_DELIM_RETRY_COUNT);
                    retryCount = Integer.parseInt(getDelimitedText(fileContents[0], InformUtil.META_DATA_DELIM_RETRY_COUNT, null));
                }
            } else {
                // Old format/not retried before
                payload = fileContents[0];
            }

            if (log.isDebugEnabled()) {
                log.debug("environment=" + errorFileContent.getEnvironment());
                log.debug("region=" + errorFileContent.getRegion());
            }

            errorFileContent.setLastRetry(lastRetry);
            errorFileContent.setRetryCount(retryCount);
            errorFileContent.setPayload(payload);
        }

        return errorFileContent;
    }

    /**
     * Returns the text in between two specified delimiters.
     *
     * @param in the input text.
     * @param leftDelim the left delimiter. If null, zero is used as the left index. 
     * @param rightDelim the right delimeter. If null, the end of the input string is
     *     used (the string length is used as the right index).
     *
     * @throws java.lang.NullPointerException if both leftDelim and rightDelim are null.
     *
     * @return a substring of the input text between the two delimiters.
     */
    private static String getDelimitedText(String in, String leftDelim, String rightDelim) {
        if (leftDelim == null) {
            return in.substring(0, in.indexOf(rightDelim));
        } else if (rightDelim == null) {
            return in.substring(in.indexOf(leftDelim) + leftDelim.length());
        } else {
            return in.substring(in.indexOf(leftDelim) + leftDelim.length(), in.indexOf(rightDelim));
        }
    }

    /**
     * Handle another failed retry
     * 
     * @param errorFileContent
     */
    private void handleFailedRetry(ErrorFileContent errorFileContent) {
        /*
         * Sample error file format:
         *
         * --Environment: default
         * --Region: DV7ST1
         * --Last Retry: Mon Jan 01 00:00:00 EDT 2012 
         * --Retry Count: 1
         * ------------------------------------------------------
         * <?xml version="1.0" encoding="ibm-1148"?>
         * <INFORM><INQ xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
         *     <INQREQCD><![CDATA[A4]]></INQREQCD>
         *     ...
         * </INFORM>
         */

        // update the retry count
        errorFileContent.incrementRetryCount();
        File retryFile = errorFileContent.getActualFile();
        // Update the meta data to reflect the updated retry count and last
        // count date
        final StringBuffer newFileContents = new StringBuffer(2024);
        newFileContents.append(InformUtil.META_DATA_DELIM_ENVIRONMENT).append(errorFileContent.getEnvironment())
                       .append(InformUtil.META_DATA_DELIM_REGION).append(errorFileContent.getRegion())
                       .append(InformUtil.META_DATA_DELIM_LAST_RETRY).append(new Date())
                       .append(InformUtil.META_DATA_DELIM_RETRY_COUNT).append(errorFileContent.getRetryCount())
                       .append(InformUtil.META_DATA_DELIM).append(errorFileContent.getPayload());
        log.info("Cannot resend INFOrm record: " + newFileContents.toString());
        writeFile(retryFile, newFileContents.toString());

        // Too many tries, move the file to the hospital
        if (errorFileContent.getRetryCount() > retryThreshold) {
            log.info("This record has exceeded the allowable number of retries - moving to the hospital for manual intervention");
            File hospitalFile = new File(hospitalLogLocation + File.separator + retryFile.getName());
            retryFile.renameTo(hospitalFile);
        }
    }

    /**
     * Read the error file.
     * 
     * @param file
     * @return
     */
    private String readFile(File file) {
        FileInputStream inputStream = null;
        String fileContents = null;
        try {
            int ch;
            StringBuffer strContent = new StringBuffer();
            inputStream = new FileInputStream(file);
            while ((ch = inputStream.read()) != -1) {
                strContent.append((char) ch);
            }
            fileContents = strContent.toString();
        } catch (Exception exception) {
            log.error("Could not retry record", exception);
        } finally {
            if (null != inputStream) {
                try {
                    inputStream.close();
                } catch (Exception exception) {
                    log.info("There was an exception attempting to close the stream", exception);
                }
            }
        }
        return fileContents;
    }

    /**
     * Write the updated error file.
     * 
     * @param file
     * @param contents
     */
    private void writeFile(File file, String contents) {
        OutputStream stream = null;
        try {
            stream = new FileOutputStream(file);
            stream.write(contents.getBytes());
            stream.flush();
        } catch (Exception exception) {
            log.error("There was an exception attempting to save the INFOrm record to disk, the record is\n" + contents, exception);
        } finally {
            if (null != stream) {
                try {
                    stream.close();
                } catch (Exception exception) {
                    log.info("There was an exception attempting to close the stream", exception);
                }
            }
        }
    }

    /**
     * @return the timerService
     */
    public TimerService getTimerService() {
        return timerService;
    }

    /**
     * @param timerService the timerService to set
     */
    public void setTimerService(TimerService timerService) {
        this.timerService = timerService;
    }

    /**
     * @return the submitInformDao
     */
    public SubmitInformDAO getSubmitInformDao() {
        return submitInformDao;
    }

    /**
     * @param submitInformDao the submitInformDao to set
     */
    public void setSubmitInformDao(SubmitInformDAO submitInformDao) {
        this.submitInformDao = submitInformDao;
    }

    /**
     * @return the retryInterval
     */
    public Long getRetryInterval() {
        return retryInterval;
    }

    /**
     * @param retryInterval the retryInterval to set
     */
    public void setRetryInterval(Long retryInterval) {
        this.retryInterval = retryInterval;
    }

    /**
     * @return the retryThreshold
     */
    public Long getRetryThreshold() {
        return retryThreshold;
    }

    /**
     * @param retryThreshold the retryThreshold to set
     */
    public void setRetryThreshold(Long retryThreshold) {
        this.retryThreshold = retryThreshold;
    }

    public Long getRetryThrottleCount() {
        return retryThrottleCount;
    }

    public void setRetryThrottleCount(Long retryThrottleCount) {
        this.retryThrottleCount = retryThrottleCount;
    }

    public Long getRetryThrottleTime() {
        return retryThrottleTime;
    }

    public void setRetryThrottleTime(Long retryThrottleTime) {
        this.retryThrottleTime = retryThrottleTime;
    }

    /**
     * @return the failureLogLocation
     */
    public String getFailureLogLocation() {
        return failureLogLocation;
    }

    /**
     * @param failureLogLocation the failureLogLocation to set
     */
    public void setFailureLogLocation(String failureLogLocation) {
        this.failureLogLocation = failureLogLocation;
    }

    /**
     * @return the hospitalLogLocation
     */
    public String getHospitalLogLocation() {
        return hospitalLogLocation;
    }

    /**
     * @param hospitalLogLocation the hospitalLogLocation to set
     */
    public void setHospitalLogLocation(String hospitalLogLocation) {
        this.hospitalLogLocation = hospitalLogLocation;
    }

    /**
     * Private inner class representing the error file content
     * 
     * @author HX61
     * 
     */
    private class ErrorFileContent {

        private String payload = StringUtils.EMPTY;
        private int retryCount = 0;
        private String lastRetry = StringUtils.EMPTY;
        private File actualFile = null;
        private String environment = "default";
        private String region = StringUtils.EMPTY;

        public String getPayload() {
            return payload;
        }

        public void setPayload(String payload) {
            this.payload = payload;
        }

        public int getRetryCount() {
            return retryCount;
        }

        public void setRetryCount(int retryCount) {
            this.retryCount = retryCount;
        }

        public String getLastRetry() {
            return lastRetry;
        }

        public void setLastRetry(String lastRetry) {
            this.lastRetry = lastRetry;
        }

        public File getActualFile() {
            return actualFile;
        }

        public void setActualFile(File actualFile) {
            this.actualFile = actualFile;
        }

        public void incrementRetryCount() {
            this.retryCount++;
        }

        public String getEnvironment() {
            return environment;
        }

        public void setEnvironment(String environment) {
            this.environment = environment;
        }

        public String getRegion() {
            return region;
        }

        public void setRegion(String region) {
            this.region = region;
        }
    }
}
