/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2015 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.saml;

import java.util.Map;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.interceptor.Interceptors;

import com.bcbssc.desktop.dao.auth.SAMLAssertionDAO;
import com.bcbssc.desktop.util.services.interceptor.ServicesDataAccessExceptionInterceptor;
import com.bcbssc.domain.entity.auth.sso.SAMLAssertionCriteria;
import com.bcbssc.services.SAMLAssertionPortType;
import com.bcbssc.services.samlassertion.AssertionInput;
import com.bcbssc.services.samlassertion.AttributeList;
import com.bcbssc.services.samlassertion.AttributeList.Attribute;
import com.bcbssc.wsutils.GenericJaxWsServiceProxy;
import com.bcbssc.wsutils.GenericWebServiceConsumerCallback;
import com.bcbssc.wsutils.GenericWebServiceConsumerTemplate;

/**
 * Retrieves SAML Assertions
 *
 * @author $Author$  (original: mf19)
 * @version $Revision$
 */
@Stateless
@Remote
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
@Interceptors({ServicesDataAccessExceptionInterceptor.class})
public class ServicesSAMLAssertionDAOImpl implements SAMLAssertionDAO {

    /* @see com.bcbssc.desktop.auth.dao.SAMLAssertionDAO#retrieveSAMLAssertion(com.bcbssc.domain.entity.auth.sso.SAMLAssertionCriteria) */
    @Override
    public String retrieveSAMLAssertion(SAMLAssertionCriteria criteria) throws Exception {
        final GenericWebServiceConsumerTemplate<SAMLAssertionPortType, SAMLAssertionCriteria, AssertionInput, String, String>
        template = new GenericWebServiceConsumerTemplate<SAMLAssertionPortType, SAMLAssertionCriteria, AssertionInput, String, String>();

        return template.consumeService(criteria, getWebServiceConsumerCallback());
    }

    /**
     * Returns the web service consumer callback implementation for this DAO.
     */
    protected SAMLAssertionServiceConsumerCallback getWebServiceConsumerCallback() {
        return new SAMLAssertionServiceConsumerCallback();
    }

    /**
     * SAMLAssertion callback
     *
     * @author $Author$  (original: mf19)
     * @version $Revision$
     */
    public class SAMLAssertionServiceConsumerCallback implements GenericWebServiceConsumerCallback
    <SAMLAssertionPortType, SAMLAssertionCriteria, AssertionInput, String, String> {

        @Override
        public SAMLAssertionPortType getService() {
            return (SAMLAssertionPortType) new GenericJaxWsServiceProxy("java:comp/env/service/SAMLAssertion").getService();
        }

        @Override
        public AssertionInput mapInput(SAMLAssertionCriteria domainInput) {
            final AssertionInput input = new AssertionInput();
            final String nameQualifier = domainInput.getNameQualifier();
            final String profile = domainInput.getProfile();
            final Map<String, String> domainAttributes = domainInput.getAttributes();

            final AttributeList attributes = new AttributeList();
            for (final String attributeName : domainAttributes.keySet()) {
                final String attributeValue = domainAttributes.get(attributeName);

                final Attribute attribute = new Attribute();
                attribute.setName(attributeName);
                attribute.setValue(attributeValue);

                attributes.getAttribute().add(attribute);
            }

            input.setAttributes(attributes);
            input.setNameQualifier(nameQualifier);
            input.setSAMLProfile(profile);

            return input;
        }

        @Override
        public String mapOutput(String serviceOutput) {
            return serviceOutput;
        }

        @Override
        public String invokeService(AssertionInput serviceInput, SAMLAssertionPortType client) throws Exception {
            return client.createAssertion(serviceInput);
        }
    }
}
