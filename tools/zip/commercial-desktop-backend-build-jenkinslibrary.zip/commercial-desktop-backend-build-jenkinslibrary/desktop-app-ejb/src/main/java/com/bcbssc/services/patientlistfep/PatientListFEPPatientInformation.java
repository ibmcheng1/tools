
package com.bcbssc.services.patientlistfep;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PatientListFEPPatientInformation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PatientListFEPPatientInformation">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="memberNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="firstName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="dateOfBirth" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="genderRelationshipCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="policyEffectiveDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="policyTerminationDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="familyDeductibleMet" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="memberDeductibleMet" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PatientListFEPPatientInformation", propOrder = {
    "memberNumber",
    "firstName",
    "dateOfBirth",
    "genderRelationshipCode",
    "policyEffectiveDate",
    "policyTerminationDate",
    "familyDeductibleMet",
    "memberDeductibleMet"
})
public class PatientListFEPPatientInformation {

    @XmlElement(required = true, nillable = true)
    protected String memberNumber;
    @XmlElement(required = true, nillable = true)
    protected String firstName;
    @XmlElement(required = true, nillable = true)
    protected String dateOfBirth;
    @XmlElement(required = true, nillable = true)
    protected String genderRelationshipCode;
    @XmlElement(required = true, nillable = true)
    protected String policyEffectiveDate;
    @XmlElement(required = true, nillable = true)
    protected String policyTerminationDate;
    @XmlElement(required = true, nillable = true)
    protected String familyDeductibleMet;
    @XmlElement(required = true, nillable = true)
    protected String memberDeductibleMet;

    /**
     * Gets the value of the memberNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberNumber() {
        return memberNumber;
    }

    /**
     * Sets the value of the memberNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberNumber(String value) {
        this.memberNumber = value;
    }

    /**
     * Gets the value of the firstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Gets the value of the dateOfBirth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Sets the value of the dateOfBirth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateOfBirth(String value) {
        this.dateOfBirth = value;
    }

    /**
     * Gets the value of the genderRelationshipCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGenderRelationshipCode() {
        return genderRelationshipCode;
    }

    /**
     * Sets the value of the genderRelationshipCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGenderRelationshipCode(String value) {
        this.genderRelationshipCode = value;
    }

    /**
     * Gets the value of the policyEffectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyEffectiveDate() {
        return policyEffectiveDate;
    }

    /**
     * Sets the value of the policyEffectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyEffectiveDate(String value) {
        this.policyEffectiveDate = value;
    }

    /**
     * Gets the value of the policyTerminationDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolicyTerminationDate() {
        return policyTerminationDate;
    }

    /**
     * Sets the value of the policyTerminationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolicyTerminationDate(String value) {
        this.policyTerminationDate = value;
    }

    /**
     * Gets the value of the familyDeductibleMet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFamilyDeductibleMet() {
        return familyDeductibleMet;
    }

    /**
     * Sets the value of the familyDeductibleMet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFamilyDeductibleMet(String value) {
        this.familyDeductibleMet = value;
    }

    /**
     * Gets the value of the memberDeductibleMet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberDeductibleMet() {
        return memberDeductibleMet;
    }

    /**
     * Sets the value of the memberDeductibleMet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberDeductibleMet(String value) {
        this.memberDeductibleMet = value;
    }

}
