/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2016 BLUECROSS BLUESHIELD OF SOUTH CAROLINA.
 * ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.rules;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.security.auth.Subject;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.biz.rules.RulesScriptBiz;
import com.bcbssc.desktop.dao.rules.RulesScriptDAO;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.cti.CallCenterAttribute;
import com.bcbssc.domain.entity.enums.Subsystems;
import com.bcbssc.domain.entity.rules.RulesScriptRequest;
import com.bcbssc.domain.entity.rules.RulesScriptResponse;
import java.security.PrivilegedExceptionAction;

/**
 * Runs Rules scripts.
 */
@Stateless
@Remote
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class RulesScriptBizBDImpl implements RulesScriptBiz {
    protected static final String ICD9_OVERRIDE_SCRIPT = "ICD10CMP";
    protected static final String GROUP_NUMBER_FIELD_NAME = "GROUPNO";
    protected static final String MEDICARE_ADVANTAGE_INDICATOR_FIELD_NAME = "MEDADIND";
    protected static final String OVERRIDE_RESPONSE_Y = "Y";

    //Call center attributes
    protected static final String CALL_CENTER_ATTRIBUTE_SCRIPT = "CALCTRAT";
    protected static final String CALL_CENTER_ID = "CALL_CNTR_ID";
    protected static final String PRODUCT_CODE = "PRODUCT_CODE";
    protected static final String REPEAT_CALLER_COUNT = "RPT_CALLER_CNT";
    protected static final String REPEAT_CALLER_NUMBER_OF_DAYS = "NO_OF_DAYS";
    protected static final int REPEAT_CALLER_NUMBER_OF_DAYS_MAX = 100;
    protected static final String REPEAT_CALLER_INFORM_SOURCE = "INFORM_SOURCE";
    protected static final String REPEAT_CALLER_DIVISION_CODE = "DIV_CD";
    protected static final String REPEAT_CALLER_DEPARTMENT_CODE = "DEPT_CD";
    protected static final String COB_INFORM_COMPANY_CODE = "OHI_COMP_CD";
    protected static final String COB_INFORM_DIVISION_CODE = "OHI_DIV_CD";
    protected static final String COB_INFORM_DEPARTMENT_CODE = "OHI_DEPT_CD";
    protected static final String COB_INFORM_EMPLOYEE_ID = "OHI_EMP_ID_NO";
    protected static final String TIMER_MAX_HOLD_TIME = "MAX_HOLD_TIME";
    protected static final String TIMER_WRAP_UP_TIME = "WRAP_UP_TIME";

    private static final Log log = LogFactory.getLog(RulesScriptBiz.class);

    @EJB
    private RulesScriptDAO rulesScriptDAO;

    @Override
    public boolean checkIcd9Override(String groupNumber, String medicareAdvantageIndicator, String rpn) {
        final RulesScriptRequest request = new RulesScriptRequest();
        final Map<String, String> inputFields = new TreeMap<String, String>();
        request.setRpn(rpn);
        request.setScript(ICD9_OVERRIDE_SCRIPT);
        request.setInputFields(inputFields);
        inputFields.put(GROUP_NUMBER_FIELD_NAME, groupNumber);
        inputFields.put(MEDICARE_ADVANTAGE_INDICATOR_FIELD_NAME, medicareAdvantageIndicator);

        final RulesScriptResponse response = rulesScriptDAO.executeRulesScript(request);
        final Map<String, List<String>> outputFields = response.getOutputFields();

        List<String> overrideValueList = outputFields.entrySet().iterator().next().getValue();
        String overrideValue = StringUtils.EMPTY;
        if(isListPopulated(overrideValueList)) {
            overrideValue = overrideValueList.get(0);
        }

        return outputFields.size() > 0
            && OVERRIDE_RESPONSE_Y.equals(overrideValue);
    }

    @Override
    public CallCenterAttribute retrieveCallCenterAttribute(String callCenter, String productCode, Subject subject) {
        //default it.  some call centers may not want it, and the project isn't sure which call centers are doing what.  Additionally, if the call center "RULEs Ops"
        //person deletes it or forgets they made a change/it will break us.
        CallCenterAttribute callCenterAttribute = new CallCenterAttribute();
        Map<String, List<String>> outputFields = null;
        
        final RulesScriptRequest request = new RulesScriptRequest();
        final Map<String, String> inputFields = new TreeMap<String, String>();
        final String rpn = SubjectUtils.getRpnForSubsystem(subject, Subsystems.CISI);
        request.setRpn(rpn);
        request.setScript(CALL_CENTER_ATTRIBUTE_SCRIPT);
        request.setInputFields(inputFields);
        inputFields.put(CALL_CENTER_ID, callCenter);
        inputFields.put(PRODUCT_CODE, productCode);

        try {
            //Avalon call center doesn't want this, based on what we can tell.  When the script is non-existent it crashes, and breaks CTI log-in.  This prevents that.
            //Use runAsSubject in order to run with a generic Subject for the DynaCache refresh
            RulesScriptResponse response = SubjectUtils.runAsSubject(new PrivilegedExceptionAction<RulesScriptResponse>() {
                public RulesScriptResponse run() throws Exception {
                    return rulesScriptDAO.executeRulesScript(request);
                }
            }, subject);
            
            outputFields = response.getOutputFields();
        } catch (Exception e) {
            log.warn("RulesScriptDAO.executeRulesScript failed, ignoring", e);
        }       

        if(outputFields != null && !outputFields.isEmpty()) {
            //Number of calls for repeat caller
            List<String> repeatCallerCountList = outputFields.get(REPEAT_CALLER_COUNT);
            if(isListPopulated(repeatCallerCountList)) {
                int repeatCallerCount = NumberUtils.toInt(repeatCallerCountList.get(0));
                callCenterAttribute.setNumberOfCallsForRepeatCaller(repeatCallerCount);
            }

            //Number of days for repeat caller
            List<String> repeatCallerNumberOfDaysList = outputFields.get(REPEAT_CALLER_NUMBER_OF_DAYS);
            if(isListPopulated(repeatCallerNumberOfDaysList)) {
                int repeatCallerDays = NumberUtils.toInt(repeatCallerNumberOfDaysList.get(0));
                //A hardcoded max number of days, so the service doesn't run too long
                if(repeatCallerDays > REPEAT_CALLER_NUMBER_OF_DAYS_MAX) {
                    repeatCallerDays = REPEAT_CALLER_NUMBER_OF_DAYS_MAX;
                }
                callCenterAttribute.setNumberOfDaysForRepeatCaller(repeatCallerDays);
            }

            //Department and division for repeat caller
            List<String> repeatCallerDepartmentCodeList = outputFields.get(REPEAT_CALLER_DEPARTMENT_CODE);
            if(isListPopulated(repeatCallerDepartmentCodeList)) {
                callCenterAttribute.setDepartmentTypeForRepeatCaller(repeatCallerDepartmentCodeList);
            }
            List<String> repeatCallerDivisionCodeList = outputFields.get(REPEAT_CALLER_DIVISION_CODE);
            if(isListPopulated(repeatCallerDivisionCodeList)) {
                callCenterAttribute.setDivisionTypeForRepeatCaller(repeatCallerDivisionCodeList);
            }

            //Inform sources for repeat caller
            List<String> informSources = outputFields.get(REPEAT_CALLER_INFORM_SOURCE);
            if(isListPopulated(informSources)) {
                callCenterAttribute.setSourceTypesForRepeatCaller(informSources);
            }

            //Max hold time for timer
            List<String> maxHoldTimeList = outputFields.get(TIMER_MAX_HOLD_TIME);
            if(isListPopulated(maxHoldTimeList)) {
                callCenterAttribute.setMaxHoldTime(NumberUtils.toInt(maxHoldTimeList.get(0)));
            }

            //Wrap up time for timer
            List<String> wrapUpTimeList = outputFields.get(TIMER_WRAP_UP_TIME);
            if(isListPopulated(wrapUpTimeList)) {
                callCenterAttribute.setWrapUpTime(NumberUtils.toInt(wrapUpTimeList.get(0)));
            }

            //Company, Department, division and employee ID for COB Inform submittals
            List<String> cobCompanyCodeList = outputFields.get(COB_INFORM_COMPANY_CODE);
            if(isListPopulated(cobCompanyCodeList)) {
                callCenterAttribute.setCompanyTypeForCOBInforms(cobCompanyCodeList.get(0));
            }
            
            List<String> cobDepartmentCodeList = outputFields.get(COB_INFORM_DEPARTMENT_CODE);
            if(isListPopulated(cobDepartmentCodeList)) {
                callCenterAttribute.setDepartmentTypeForCOBInforms(cobDepartmentCodeList.get(0));
            }
            List<String> cobDivisionCodeList = outputFields.get(COB_INFORM_DIVISION_CODE);
            if(isListPopulated(cobDivisionCodeList)) {
                callCenterAttribute.setDivisionTypeForCOBInforms(cobDivisionCodeList.get(0));
            }
            List<String> cobEmployeeIdList = outputFields.get(COB_INFORM_EMPLOYEE_ID);
            if(isListPopulated(cobEmployeeIdList)) {
                callCenterAttribute.setEmployeeIdForCOBInforms(cobEmployeeIdList.get(0));
            }
        } else {
            if(log.isWarnEnabled()) {
                log.warn(CALL_CENTER_ATTRIBUTE_SCRIPT+" rules script is not setup for the "+callCenter+" call center with "+productCode+" product code");
            }
        }

        return callCenterAttribute;
    }

    /*
     * Checks if a list is not null and populated
     */
    private boolean isListPopulated(List<?> list) {
        if(list != null && !list.isEmpty()) {
            return true;
        } else {
            return false;
        }
    }
}
