/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.startup;

import java.util.List;

import com.bcbssc.domain.entity.codes.Code;

public class InformCodesResponse<T extends Code> {

    private boolean more;
    private List<T> codesList;

    public boolean isMore() {
        return more;
    }
    public void setMore(boolean more) {
        this.more = more;
    }
    public List<T> getCodesList() {
        return codesList;
    }
    public void setCodesList(List<T> codesList) {
        this.codesList = codesList;
    }


}