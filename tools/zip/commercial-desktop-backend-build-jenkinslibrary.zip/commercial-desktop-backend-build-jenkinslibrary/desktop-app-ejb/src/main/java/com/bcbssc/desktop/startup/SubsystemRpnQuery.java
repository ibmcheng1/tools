/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.startup;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.util.jdbc.executor.JdbcServiceInputMapper;
import com.bcbssc.desktop.util.jdbc.executor.JdbcServiceInvoker;
import com.bcbssc.desktop.util.jdbc.executor.JdbcServiceOutputMapper;
import com.bcbssc.desktop.util.jdbc.query.BaseQuery;
import com.bcbssc.domain.entity.Subsystem;

/**
 *
 */
public class SubsystemRpnQuery extends BaseQuery {
    
    private static final String RPNSQL = "SELECT DISTINCT CISI_RP_NO, PIMS_RP_NO, RULE_RP_NO, INFO_RP_NO, TMCS_RP_NO, AMMS_RP_NO FROM {0}.CLI_BUSN_SECT_REF WHERE AMMS_RP_NO = ?  AND (CLI_SECT_TRM_DT IS NULL OR CLI_SECT_TRM_DT > ?)";
    private static final String ALTRPNSQL = "SELECT RES_MAPPED_VALUE FROM {0}.AMMS_RESC_TYP_MAP WHERE RES_TYPE = ''ALIASRPN'' AND RES_TYPE_KEY = ? AND END_DATE > ?";
    private static final Log logger = LogFactory.getLog(SubsystemRpnQuery.class);

    public List<Subsystem> getSubsystemRpns(String schema, String altSchema, String rpn) {
        String rpnSql = MessageFormat.format(RPNSQL, new Object[] { schema });
        String altRpnSql = MessageFormat.format(ALTRPNSQL, new Object[] { altSchema });
        
        JdbcServiceInputMapper inputMapper = new SubsystemRpnInputMapper(rpnSql, rpn);
        JdbcServiceInputMapper altInputMapper = new SubsystemAltRpnInputMapper(altRpnSql, rpn);
        
        JdbcServiceOutputMapper outputMapper = new SubsystemRpnOutputMapper();
        JdbcServiceOutputMapper altOutputMapper = new SubsystemAltRpnOutputMapper();
        
        List<String> stringList = new ArrayList<String>();
        try {
            stringList = (List<String>)jdbcTemplate.execute(inputMapper, outputMapper, new JdbcServiceInvoker());
        } catch (Exception e) {
            logger.error("An error occured while attempting to get client list", e);
        }
        
        /*
         * Take the first one from the list and convert it
         */
        List<Subsystem> results = new ArrayList<Subsystem>();
        if (stringList.size() > 0) {
            String subsystemsList = stringList.get(0);
            String[] subsystems = StringUtils.splitPreserveAllTokens(subsystemsList, ",");
            results.add(getSubsystem("CISI", subsystems[0]));
            results.add(getSubsystem("PIMS", subsystems[1]));
            results.add(getSubsystem("RULE", subsystems[2]));
            results.add(getSubsystem("INFO", subsystems[3]));
            results.add(getSubsystem("TMCS", subsystems[4]));
            results.add(getSubsystem("AMMS", subsystems[5]));
        }
        
        List<String> altStringList = new ArrayList<String>();
        try {
            altStringList = (List<String>)jdbcTemplate.execute(altInputMapper, altOutputMapper, new JdbcServiceInvoker());
        } catch (Exception e) {
            logger.error("An error occured while attempting to get client list", e);
        }
        
        /*
         * Take the first one from the list and convert it
         */
        if (altStringList.size() > 0) {
            String subsystemsList = altStringList.get(0);
            results.add(getSubsystem("AMMSALTERNATE", subsystemsList));
        }
        
        return results;
    }
    
    private Subsystem getSubsystem(String name, String rpn) {
        Subsystem subsystem = new Subsystem();
        subsystem.setName(name);
        subsystem.setRpn(rpn);
        
        return subsystem;
    }
    
    private class SubsystemRpnInputMapper extends JdbcServiceInputMapper{
        private String rpn;
        
        public SubsystemRpnInputMapper(String query, String rpn){
            super(query);
            this.rpn = rpn;
        }

        /* (non-Javadoc)
         * @see com.bcbssc.desktop.util.jdbc.executor.JdbcServiceInputMapper#mapInput()
         */
        @Override
        public Object mapInput() {
            Object[] parameters = new Object[2];
            parameters[0] = rpn;
            parameters[1] = DateUtils.truncate(new java.util.Date(), java.util.Calendar.DAY_OF_MONTH);
            
            return parameters;
        }
    }
    
    private class SubsystemRpnOutputMapper extends JdbcServiceOutputMapper {

        @Override
        public Object mapRow(ResultSet resultSet) throws SQLException {
            return StringUtils.trimToEmpty(resultSet.getString("CISI_RP_NO")) + "," + StringUtils.trimToEmpty(resultSet.getString("PIMS_RP_NO")) + "," + StringUtils.trimToEmpty(resultSet.getString("RULE_RP_NO")) + "," + StringUtils.trimToEmpty(resultSet.getString("INFO_RP_NO")) + "," + StringUtils.trimToEmpty(resultSet.getString("TMCS_RP_NO")) + "," + StringUtils.trimToEmpty(resultSet.getString("AMMS_RP_NO"));
        }
        
    }
    
    private class SubsystemAltRpnInputMapper extends JdbcServiceInputMapper{
        private String ammsAlternate;
        
        public SubsystemAltRpnInputMapper(String query, String ammsAlternate){
            super(query);
            this.ammsAlternate = ammsAlternate;
        }

        /* (non-Javadoc)
         * @see com.bcbssc.desktop.util.jdbc.executor.JdbcServiceInputMapper#mapInput()
         */
        @Override
        public Object mapInput() {
            SimpleDateFormat currentDate = new SimpleDateFormat("yyyy-MM-dd");
            Object[] parameters = new Object[2];
            parameters[0] = ammsAlternate;
            parameters[1] = currentDate.format(new Date());
            
            return parameters;
        }
    }
    
    private class SubsystemAltRpnOutputMapper extends JdbcServiceOutputMapper {

        @Override
        public Object mapRow(ResultSet resultSet) throws SQLException {
            return StringUtils.trimToEmpty(resultSet.getString("RES_MAPPED_VALUE"));
        }
        
    }
    
}
