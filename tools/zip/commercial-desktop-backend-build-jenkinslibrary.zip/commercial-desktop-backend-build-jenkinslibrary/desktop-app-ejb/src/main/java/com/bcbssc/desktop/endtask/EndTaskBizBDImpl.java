/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2016 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.endtask;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.security.auth.Subject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.EndTaskBiz;
import com.bcbssc.desktop.biz.events.EventBiz;
import com.bcbssc.desktop.biz.inform.InformBD;
import com.bcbssc.desktop.dao.inform.EmployeeLookupDAO;
import com.bcbssc.desktop.history.SessionHistoryDataHandler;
import com.bcbssc.domain.entity.Employee;
import com.bcbssc.domain.entity.Member;
import com.bcbssc.domain.entity.Subscriber;
import com.bcbssc.domain.entity.codes.Code;
import com.bcbssc.domain.entity.inform.InformRecord;
import com.bcbssc.domain.entity.inform.InformSecurity;

/**
 * Session Bean implementation class EndTaskBizBDImpl
 */

@Stateless
@Remote
public class EndTaskBizBDImpl implements EndTaskBiz {
    private static Log log = LogFactory.getLog(EndTaskBiz.class);

    @EJB
    private EmployeeLookupDAO employeeLookupDAO;

    @EJB
    private InformBD informBD;

    @EJB
    private EventBiz eventBiz;

    @Override
    public List<Employee> retrieveEmployeesById(String id, Subject subject) throws Exception {
        return employeeLookupDAO.retrieveEmployeesById(id, subject);
    }

    @Override
    public List<Employee> retrieveEmployeesByName(String name, Subject subject) throws Exception {
        return employeeLookupDAO.retrieveEmployeesByName(name, subject);
    }

    @Override
    public Map<String, String> retrieveInformPicklist(String sessionId, String listname) throws Exception {
        Map<String, String> results = new TreeMap<String, String>();
        List<Code> picklist = DesktopAPI.getPicklistCodes(sessionId, listname);
        for (Code code : picklist) {
            results.put(code.getDescription(), code.getCode());
        }
        return results;
    }

    @Override
    public <T extends Code> Map<String, T> retrieveInformCodeMap(String sessionId, String listname) throws Exception {
        Map<String, T> results = new TreeMap<String, T>();
        List<T> picklist = DesktopAPI.getPicklistCodes(sessionId, listname);
        for (T code : picklist) {
            results.put(code.getCode(), code);
        }
        return results;
    }

    @Override
    public Map<String, String> retrieveInformPicklistDefaults(String sessionId) throws Exception {
        return DesktopAPI.getPicklistDefaults(sessionId);
    }

    @Override
    public Set<Member> retrievePatientPicklist(Subscriber subscriber) throws Exception {
        Set<Member> members = subscriber.getMembers();
        // if family summary doesn't load then the members list will be empty
        if (null == members) {
            members = new TreeSet<Member>();
        }
        return members;
    }

    @Override
    public List<Map<String, String>> retrieveViewData(String sessionId, String type) throws Exception {
        SessionHistoryDataHandler sessionHistoryDataHandler = new SessionHistoryDataHandler();
        return sessionHistoryDataHandler.getHistoryData(type, sessionId);
    }

    @Override
    public void submitEndtaskRecord(InformRecord record, boolean doTransfer, boolean doTracking, Subject subject) throws Exception {
        try {
            informBD.sendInformMessage(record, doTransfer, doTracking, subject);

            //Flush all events in the queue during end task
            eventBiz.flushQueue(subject);
        } catch (Exception e) {
            log.error("Unable to log InformRecord from EndTask", e);
        }
    }

    @Override
    public InformSecurity retrieveInformSecurityById(String id, Subject subject) throws Exception {
        return employeeLookupDAO.retrieveInformSecurityById(id, subject);
    }

    @Override
    public InformSecurity retrieveInformSecurityByRacfId(String racf, Subject subject) throws Exception {
        return employeeLookupDAO.retrieveInformSecurityByRacf(racf, subject);
    }
}
