
package com.bcbssc.services.programsummaryinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProgramSummaryInfoInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProgramSummaryInfoInput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="rpn" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="planCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="sponsorId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="patientId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="historyIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="managementArea" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="eligibilityIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="enrollmentIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="startPageNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="hostID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="hostPassword" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="toEscapeChar" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="MWIConfig" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="applTrace" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProgramSummaryInfoInput", propOrder = {
    "rpn",
    "planCode",
    "sponsorId",
    "patientId",
    "historyIndicator",
    "managementArea",
    "eligibilityIndicator",
    "enrollmentIndicator",
    "startPageNumber",
    "hostID",
    "hostPassword",
    "toEscapeChar",
    "mwiConfig",
    "applTrace"
})
public class ProgramSummaryInfoInput {

    @XmlElement(required = true, nillable = true)
    protected String rpn;
    @XmlElement(required = true, nillable = true)
    protected String planCode;
    @XmlElement(required = true, nillable = true)
    protected String sponsorId;
    @XmlElement(required = true, nillable = true)
    protected String patientId;
    @XmlElement(required = true, nillable = true)
    protected String historyIndicator;
    @XmlElement(required = true, nillable = true)
    protected String managementArea;
    @XmlElement(required = true, nillable = true)
    protected String eligibilityIndicator;
    @XmlElement(required = true, nillable = true)
    protected String enrollmentIndicator;
    @XmlElement(required = true, nillable = true)
    protected String startPageNumber;
    @XmlElement(required = true, nillable = true)
    protected String hostID;
    @XmlElement(required = true, nillable = true)
    protected String hostPassword;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean toEscapeChar;
    @XmlElement(name = "MWIConfig", required = true, nillable = true)
    protected String mwiConfig;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean applTrace;

    /**
     * Gets the value of the rpn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRpn() {
        return rpn;
    }

    /**
     * Sets the value of the rpn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRpn(String value) {
        this.rpn = value;
    }

    /**
     * Gets the value of the planCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlanCode() {
        return planCode;
    }

    /**
     * Sets the value of the planCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlanCode(String value) {
        this.planCode = value;
    }

    /**
     * Gets the value of the sponsorId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSponsorId() {
        return sponsorId;
    }

    /**
     * Sets the value of the sponsorId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSponsorId(String value) {
        this.sponsorId = value;
    }

    /**
     * Gets the value of the patientId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientId() {
        return patientId;
    }

    /**
     * Sets the value of the patientId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientId(String value) {
        this.patientId = value;
    }

    /**
     * Gets the value of the historyIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHistoryIndicator() {
        return historyIndicator;
    }

    /**
     * Sets the value of the historyIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHistoryIndicator(String value) {
        this.historyIndicator = value;
    }

    /**
     * Gets the value of the managementArea property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getManagementArea() {
        return managementArea;
    }

    /**
     * Sets the value of the managementArea property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setManagementArea(String value) {
        this.managementArea = value;
    }

    /**
     * Gets the value of the eligibilityIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEligibilityIndicator() {
        return eligibilityIndicator;
    }

    /**
     * Sets the value of the eligibilityIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEligibilityIndicator(String value) {
        this.eligibilityIndicator = value;
    }

    /**
     * Gets the value of the enrollmentIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnrollmentIndicator() {
        return enrollmentIndicator;
    }

    /**
     * Sets the value of the enrollmentIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnrollmentIndicator(String value) {
        this.enrollmentIndicator = value;
    }

    /**
     * Gets the value of the startPageNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartPageNumber() {
        return startPageNumber;
    }

    /**
     * Sets the value of the startPageNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartPageNumber(String value) {
        this.startPageNumber = value;
    }

    /**
     * Gets the value of the hostID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHostID() {
        return hostID;
    }

    /**
     * Sets the value of the hostID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHostID(String value) {
        this.hostID = value;
    }

    /**
     * Gets the value of the hostPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHostPassword() {
        return hostPassword;
    }

    /**
     * Sets the value of the hostPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHostPassword(String value) {
        this.hostPassword = value;
    }

    /**
     * Gets the value of the toEscapeChar property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isToEscapeChar() {
        return toEscapeChar;
    }

    /**
     * Sets the value of the toEscapeChar property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setToEscapeChar(Boolean value) {
        this.toEscapeChar = value;
    }

    /**
     * Gets the value of the mwiConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMWIConfig() {
        return mwiConfig;
    }

    /**
     * Sets the value of the mwiConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMWIConfig(String value) {
        this.mwiConfig = value;
    }

    /**
     * Gets the value of the applTrace property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isApplTrace() {
        return applTrace;
    }

    /**
     * Sets the value of the applTrace property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setApplTrace(Boolean value) {
        this.applTrace = value;
    }

}
