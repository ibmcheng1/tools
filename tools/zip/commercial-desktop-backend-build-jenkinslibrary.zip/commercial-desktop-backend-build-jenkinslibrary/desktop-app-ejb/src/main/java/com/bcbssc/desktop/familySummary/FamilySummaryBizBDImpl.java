/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2013 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.familySummary;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.FamilySummaryBiz;
import com.bcbssc.desktop.dao.MemberDAO;
import com.bcbssc.desktop.dao.PatientDAO;
import com.bcbssc.desktop.dao.PatientListDAO;
import com.bcbssc.desktop.dao.TranslationLookupDAO;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.dao.DataRetrievalHandler;
import com.bcbssc.desktop.util.dao.executor.WorkExecutor;
import com.bcbssc.desktop.util.dao.executor.WorkTask;
import com.bcbssc.domain.entity.FepMember;
import com.bcbssc.domain.entity.Member;
import com.bcbssc.domain.entity.Subscriber;
import com.bcbssc.domain.familySummary.FamilySummaryInputDesktop;
import com.bcbssc.domain.patientList.PatientListInputDesktop;
import com.bcbssc.domain.valueobject.MenuLink;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.security.auth.Subject;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;

/**
 * Session Bean implementation class FamilySummaryBizDBImpl
 * 
 * @author HX09
 */
@Stateless
@Remote
public class FamilySummaryBizBDImpl implements FamilySummaryBiz {

	private static final String ZERO = "0";
	private static final String SUBSCRIBER_MUST_BE_FEP_OR_PAI = "Cannot match members. Subscriber must be FEP or PAI.";
	private static final int TWO = 2;
	private static final String RETRIEVE_FAMILY_SUMMARY_FLAG = "RETRIEVE_FAMILY_SUMMARY";
	private static final String LOOKUP_TRANSLATION_FLAG = "LOOKUP_TRANSLATION";
	private static final String RETRIEVE_PATIENT_LIST_TASK = "RETRIEVE_PATIENT_LIST_SERVICE";
	private static final String SPACE = " ";

    @Resource(lookup="concurrent/executor")
    private ExecutorService executor;

	/** Protected instead of private for JUnit. */
	@EJB
	protected PatientListDAO patientListDao;

	/** Protected instead of private for JUnit. */
	@EJB
	protected TranslationLookupDAO translationDao;

	@EJB(beanName = "fepMemberDAO")
	private MemberDAO fepMemberDAO;

	@EJB(beanName = "paiMemberDAO")
	private MemberDAO paiMemberDAO;

	/** Protected instead of private for JUnit. */
	@EJB
	protected PatientDAO patientDAO;

	/**
	 * Logger for this class.
	 */
	private static final Log log = LogFactory.getLog(FamilySummaryBizBDImpl.class);

	@Override
	public List<Member> getFamilySummary(String subscriberId, Subject subject, boolean isRefresh) throws Exception {
		List<Member> members = retrieveFamilySummary(subscriberId, subject, isRefresh);
		translateCode(members, subject);
		return members;
	}

	@Override
    @SuppressWarnings("unchecked")
	public Map getMatchedAndUnmatchedMembers(final Subscriber subscriber, final Subject subject, boolean isRefresh) throws Exception {
		final Callable<List<Member>> familySummary = this.familySummaryCallable(subscriber.getId(), subject, isRefresh);
		return SubjectUtils.runAsSubject(() -> {
            Map rulesEntries = DesktopAPI.getRulesEntries(subject);
            Map<String, MenuLink> userConfigs = (Map<String, MenuLink>) rulesEntries.get(MenuLink.FUNCTION_TYPE_USERCONFIG);

            MenuLink retrieveFamilySummaryLink = userConfigs.get(RETRIEVE_FAMILY_SUMMARY_FLAG);
            Map<String, Object> memberMap = new HashMap<>();

            if (DataRetrievalHandler.runDataRetrieval(retrieveFamilySummaryLink)) {
                try {
                    List<Member> externalMemberList;
                    List<Member> commercialList;
                    MemberDAO memberDAO = (subscriber.isPAI() ? paiMemberDAO : fepMemberDAO);

                    Set<Member> externalMemberSet = memberDAO.getSubscriberMembers(subscriber.getId());

                    externalMemberList = new ArrayList<>(externalMemberSet);
                    commercialList = familySummary.call();

                    Map<String, List<Member>> matchMap = new HashMap<>();
                    List<List<Member>> matchedList = new ArrayList<>();
                    List<Member> unmatchedList = new ArrayList<>();

                    translateCode(commercialList, subject);
                    translateCode(externalMemberList, subject);

                    // Match the external members and the commercial members.
                    if (subscriber.isFep()) {
                        populateMatchMapFEP(commercialList, matchMap);
                        populateMatchMapFEP(externalMemberList, matchMap);
                    } else if (subscriber.isPAI()) {
                        populateMatchMapPAI(commercialList, matchMap);
                        populateMatchMapPAI(externalMemberList, matchMap);
                    } else {
                        throw new IllegalArgumentException(SUBSCRIBER_MUST_BE_FEP_OR_PAI);
                    }
                    collectMatches(matchMap, matchedList, unmatchedList);

                    memberMap.put(MATCHED_MEMBER_LIST, matchedList);
                    memberMap.put(UNMATCHED_MEMBER_LIST, unmatchedList);
                    memberMap.put(MEMBER_LIST, commercialList);
                } catch (Exception exception) {
                    DataRetrievalHandler.handleDataRetrievalException(retrieveFamilySummaryLink, exception);
                }
            }
            return memberMap;
		}, subject);
	}

	@Override
	public Member getMemberFromSummary(String subscriberId, String patientId, Subject subject, boolean isRefresh) throws Exception {
		List<Member> members = getFamilySummary(subscriberId, subject, isRefresh);

		// The patient id may be less than three characters if it came from FEP, attempt to pad it to 3
		//
		// TODO: This is a bug there is no guarantee that the person under FEP 01 == the person under AMMS ID 001.
		// It is very common but not always.
		String patientNumber = StringUtils.leftPad(patientId, 3, ZERO);

		Member requestedMember = null;
		for (Member currentMember : members) {
			if (StringUtils.equals(patientNumber, currentMember.getMemberId())) {
				requestedMember = currentMember;
				break;
			}
		}
		return requestedMember;
	}

	/**
	 * Translate codes using translationDAO
	 * 
	 * @param members The list of members to translate codes for.
	 * @param subject The subject to use to do the translations.
	 * @throws Exception If there is an error getting the translation.
	 */
	protected void translateCode(Collection<Member> members, Subject subject) throws Exception {
		for (Member member : members) {
			String relationshipCode = member.getRelationshipCode();
			String relationshipName = lookupTranslation(TranslationLookupDAO.FIELD_ID_RELATIONSHIP, relationshipCode, subject);

			if (StringUtils.contains(relationshipName, SPACE)) {
				String[] fragments = relationshipName.split(SPACE);
				int fragmentsLength = fragments.length;
				if (fragmentsLength > 0) {
					member.setSexName(fragments[0]);
					if (fragmentsLength > 1) {
						member.setRelationshipName(fragments[1]);
					}
				}
			}

			if (!member.getClass().equals(FepMember.class)) {
				String dependentIndicator = member.getDependentIndicator();
				member.setDependentVerified(lookupTranslation(TranslationLookupDAO.FIELD_ID_DEPENDENT_INDICATOR, dependentIndicator, subject));
			}
		}
	}

	/**
	 * Separate members into matched and unmatched lists.
	 * 
	 * @param matchMap
	 *			The map of matched member groupings
	 * @param matchedList
	 *			The matched member list to manipulate
	 * @param unmatchedList
	 *			The unmatched member list to manipulate
	 */
	protected void collectMatches(Map<String, List<Member>> matchMap, List<List<Member>> matchedList, List<Member> unmatchedList) {
		SortedSet<String> sortedKeys = new TreeSet<String>(matchMap.keySet());
		for (String key : sortedKeys) {
			List<Member> matches = matchMap.get(key);
			if (1 == matches.size()) {
				unmatchedList.add(matches.get(0));
			} else {
				matchedList.add(matches);
			}
		}
	}

	/**
	 * For FEP subscriber, groups members based on birth date and sex.
	 * 
	 * @param memberList
	 *			The list of members to group
	 * @param matchList
	 *			The groupings map to manipulate
	 */
	protected void populateMatchMapFEP(List<Member> memberList, Map<String, List<Member>> matchList) {
		if (log.isDebugEnabled()) {
			log.debug("Entering: populateMatchMapFEP()");
		}

		for (Member member : memberList) {
			String birthdate = member.getBirthdate();
			String sex = member.getSexName();
			String key = birthdate + sex;

			if (log.isDebugEnabled()) {
				log.debug("populateMatchMapFEP() member key: " + key);
			}

			List<Member> list = matchList.get(key);
			if (null == list) {
				list = new ArrayList<Member>();
				matchList.put(key, list);
			}
			list.add(member);
		}
	}

	/**
	 * For PAI subscribers, groups members based on patientId.
	 * 
	 * @param memberList
	 *			The list of members to group
	 * @param matchList
	 *			The groupings map to manipulate
	 */
	protected void populateMatchMapPAI(List<Member> memberList, Map<String, List<Member>> matchList) {
		if (log.isDebugEnabled()) {
			log.debug("Entering: populateMatchMapPAI()");
		}

		for (Member member : memberList) {
			String memberId = StringUtils.leftPad(member.getMemberId(), 3, '0');
			String key = memberId;

			if (log.isDebugEnabled()) {
				log.debug("populateMatchMapPAI() member key: " + key);
			}

			List<Member> list = matchList.get(key);
			if (null == list) {
				list = new ArrayList<Member>();
				matchList.put(key, list);
			}
			list.add(member);
		}
	}

	/**
	 * Retrieves the family summary from the PatientListDAO
	 * 
	 * @param subscriberId
	 *			The ID of the subscriber for whom to retrieve the family
	 *			summary
	 * @param subject
	 *			The Subject under which to execute the DAO
	 * @return A List of Member objects representing the family summary
	 * @throws Exception
	 */
	private List<Member> retrieveFamilySummary(final String subscriberId, Subject subject, boolean isRefresh) throws Exception {

		//results
		List<Member> members = new ArrayList<>();
		List<Member> patientListMembers = new ArrayList<>();

		ArrayList<WorkTask<?>> workTasks = new ArrayList<>(TWO);
		workTasks.add(retrieveFamilySummaryInfo(subscriberId, subject, members, isRefresh));
		workTasks.add(retrievePatientListInfo(subscriberId, subject, patientListMembers, isRefresh));

		//create a work executor, execute work tasks
		WorkExecutor workExecutor = new WorkExecutor(executor, workTasks);
		workExecutor.executeWorkTasks();


		//Iterate over the member list that came back from the family summary service and find the corresponding
		//member that came from the patient list service and store the verifiedPatientIndicator value and the
		//CES member id on the Member object from the Family Summary Member List
		if ((null != members) && (null != patientListMembers)) {
			//For each Member in the Members list from the Family Summary Service
			for (Member familySummaryMember : members) {
				//For each Member in the Members list from the Patient List Service
				for (Member patientListMember : patientListMembers) {
					//Find the corresponding Member object
					if (StringUtils.equals(familySummaryMember.getMemberId(), patientListMember.getMemberId())) {
						//If the Member was found, store the verifiedPatientIndicator, CES Member Number, and the DateOfBirth
						familySummaryMember.setCesMemberNumber(patientListMember.getCesMemberNumber());
						familySummaryMember.setVerifiedPatientIndicator(patientListMember.getVerifiedPatientIndicator());
						familySummaryMember.setDateOfBirth(patientListMember.getDateOfBirth());
						break;
					}
				}
			}
		}

		return members;
	}

	/**
	 * Retrieves translations of keys
	 * 
	 * @param fieldID
	 *			The ID of the field of the key in the data source
	 * @param key
	 *			The key to translate
	 * @param subject
	 *			The Subject under which to execute the DAO
	 * @return The translated String
	 * @throws Exception If there is an error looking up the translation.
	 */
	private String lookupTranslation(final String fieldID, final String key, Subject subject) throws Exception {

		String lookupTranslation = null;

		Map rulesEntries = DesktopAPI.getRulesEntries(subject);

		@SuppressWarnings("unchecked")
		Map<String, MenuLink> userConfigs = (Map<String, MenuLink>) rulesEntries.get(MenuLink.FUNCTION_TYPE_USERCONFIG);

		MenuLink lookupTranslationLink = userConfigs.get(LOOKUP_TRANSLATION_FLAG);

		if (DataRetrievalHandler.runDataRetrieval(lookupTranslationLink)) {

			try {
				lookupTranslation = SubjectUtils.runAsSubject(() -> translationDao.lookupTranslation(fieldID, key), subject);
			} catch (Exception exception) {
				DataRetrievalHandler.handleDataRetrievalException(lookupTranslationLink, exception);
			}
		}
		return lookupTranslation;
	}

	/**
	 * fetch a Work instance to run the Family Summary DAO to fetch family data
	 * @param subscriberId The subscriber ID to use to get the family summary for.
	 * @param subject The subject to use to get family summary info.
     * @param members The list of members to update when the call is complete.
     * @param isRefresh Indicator of whether or not to use cached data.
	 * @return Returns a WorkTask to retrieve family summary info.
	 */
	private WorkTask retrieveFamilySummaryInfo(final String subscriberId, final Subject subject, final List<Member> members, final boolean isRefresh) {
		return new WorkTask<List<Member>>(RETRIEVE_FAMILY_SUMMARY_FLAG, subject, this.familySummaryCallable(subscriberId, subject, isRefresh)) {
			@Override
			public void onComplete() {
				//fetch members
				members.addAll(this.getResults());
			}
		};
	}

	private Callable<List<Member>> familySummaryCallable(final String subscriberId, final Subject subject, final boolean isRefresh) {
		return () -> {
            FamilySummaryInputDesktop desktopInput = new FamilySummaryInputDesktop(subscriberId, SubjectUtils.getClient(subject).getPlanCode());
            desktopInput.setIsCacheBuster(isRefresh);
            return patientListDao.retrieveFamilySummary(desktopInput).toListMember();
		};
	}

	/**
	 * fetch a Work instance to run the Family Summary DAO to fetch patient data
	 * @param subscriberId The subscriber ID to use to get the patient list for.
	 * @param subject The subject to use to make the call.
     * @param patientList The list of {@link Member} objects to populate when the call is complete.
     * @param isRefresh An indicator of whether or not the cache should be cleared.
	 * @return Returns a WorkTask to retrieve the patient list info.
	 */
	private WorkTask retrievePatientListInfo(final String subscriberId, final Subject subject, final List<Member> patientList, final boolean isRefresh) {
		return new WorkTask<List<Member>>(RETRIEVE_PATIENT_LIST_TASK, subject, () -> {
            PatientListInputDesktop desktopInput = new PatientListInputDesktop(subscriberId);
            desktopInput.setIsCacheBuster(isRefresh);
            return patientDAO.retrievePatientList(desktopInput).toListMember();
		}) {
			@Override
			public void onComplete() {
				//fetch patients
				patientList.addAll(this.getResults());
			}
		};
	}
}
