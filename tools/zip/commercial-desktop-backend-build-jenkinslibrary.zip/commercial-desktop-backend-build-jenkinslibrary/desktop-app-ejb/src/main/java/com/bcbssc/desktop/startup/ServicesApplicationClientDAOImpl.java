/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.desktop.startup;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.jws.HandlerChain;
import javax.xml.ws.WebServiceRef;

import org.apache.commons.lang.StringUtils;

import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.services.BaseServiceIntegrator;
import com.bcbssc.desktop.util.services.interceptor.ServicesDataAccessExceptionInterceptor;
import com.bcbssc.domain.entity.ApplicationClient;
import com.bcbssc.services.desktopclientlist.DesktopClientListClientRecords;
import com.bcbssc.services.desktopclientlist.DesktopClientListInput;
import com.bcbssc.services.desktopclientlist.DesktopClientListOutput;
import com.bcbssc.services.desktopclientlist.DesktopClientListService;
import com.bcbssc.services.desktopclientlist.DesktopClientListServiceService;

/**
 * This service implementation is used to retrieve client related data.
 */
@Stateless
@Local
@Interceptors({ServicesDataAccessExceptionInterceptor.class})
public class ServicesApplicationClientDAOImpl extends BaseServiceIntegrator<DesktopClientListService, ClientListRequest, DesktopClientListInput, DesktopClientListOutput, ArrayList<ApplicationClient>> implements ApplicationClientDAO {

    private static final String CLIENT_LIST_DATA_TYPE = "CLIENT";
    private static final String FIRST_CLIENT = "0001";

    @HandlerChain(file = "../dao/services/handlerchain/soax-service-handler-chain.xml")
    @WebServiceRef(wsdlLocation = "META-INF/wsdl/DesktopClientList.wsdl", value=DesktopClientListServiceService.class)
    private DesktopClientListService service;

    public ServicesApplicationClientDAOImpl() {
    }

    @Override
    public ArrayList<ApplicationClient> getClientList() throws Exception {

        final ApplicationClient applicationClient = SubjectUtils.getClientStrict(SubjectUtils.getCurrentSubject());
        final String applicationId = applicationClient.getAppId();
        final String rpn = applicationClient.getRpn();

        if (StringUtils.isBlank(applicationId) || StringUtils.isBlank(rpn)){
            throw new IllegalArgumentException("Missing applicationId or rpn");
        }
        final ArrayList<ApplicationClient> clientList = this.consumeService(new ClientListRequest(applicationId, rpn));

        // Since the service does not return the application id (since it's input), spin through all the results
        // and add the application id here
        for(final ApplicationClient client : clientList) {
            client.setAppId(applicationId);
        }

        return clientList;
    }

    @Override
    public DesktopClientListService getService() {
        return service;
    }

    @Override
    public DesktopClientListOutput invokeService(DesktopClientListInput input, DesktopClientListService service) throws Exception {
        return service.getDesktopClientList(input);
    }

    @Override
    public DesktopClientListInput mapInput(ClientListRequest input) {
        final DesktopClientListInput serviceInput = new DesktopClientListInput();

        serviceInput.setApplicationId(input.getApplicationId());
        serviceInput.setRpn(input.getRpn());

        serviceInput.setDatatype(CLIENT_LIST_DATA_TYPE);
        serviceInput.setStartingRecordRequested(FIRST_CLIENT);

        serviceInput.setHostID(SubjectUtils.getRacfId(SubjectUtils.getCurrentSubject()));
        serviceInput.setHostPassword(SubjectUtils.getRACFPassword(SubjectUtils.getCurrentSubject()));
        serviceInput.setMWIConfig(SubjectUtils.getRegion(SubjectUtils.getCurrentSubject()));
        serviceInput.setPlanCode(SubjectUtils.getClientStrict(SubjectUtils.getCurrentSubject()).getPlanCode());
        serviceInput.setRacfid(SubjectUtils.getRacfId(SubjectUtils.getCurrentSubject()));
        serviceInput.setToEscapeChar(Boolean.FALSE);

        return serviceInput;
    }

    @Override
    public ArrayList<ApplicationClient> mapOutput(DesktopClientListOutput output) {
        final ArrayList<ApplicationClient> clients = new ArrayList<ApplicationClient>();
        final List<DesktopClientListClientRecords> clientListRecords = output.getClientRecords().getDesktopClientListClientRecords();
        for(final DesktopClientListClientRecords record: clientListRecords){
            if(StringUtils.isNotBlank(record.getClientName())){
                final ApplicationClient client = translateResult(record);
                clients.add(client);
            } else{
                break;
            }
        }
        return clients;
    }

    private ApplicationClient translateResult(DesktopClientListClientRecords clientListRecord){
        final ApplicationClient client = new ApplicationClient();
        client.setClientId(StringUtils.trimToEmpty(clientListRecord.getClientId()));
        client.setClientName(StringUtils.trimToEmpty(clientListRecord.getClientName()));
        client.setInformTrans(StringUtils.trimToEmpty(clientListRecord.getInformTransaction()));
        client.setInformQualifier(StringUtils.trimToEmpty(clientListRecord.getInformQualifier()));
        client.setAliasRpn(StringUtils.trimToEmpty(clientListRecord.getAliasRpn()));
        client.setPlanCode(StringUtils.trimToEmpty(clientListRecord.getAliasPlanCode()));
        client.setAliasPlanCode(StringUtils.trimToEmpty(clientListRecord.getAliasPlanCode()));
        client.setItsPlanCode(StringUtils.trimToEmpty(clientListRecord.getItsPlanCode()));
        return client;
    }

    @Override
    public void setService(DesktopClientListService service) {
        this.service = service;
    }

    @Override
    protected String getServiceName() {
        return DesktopClientListService.class.getSimpleName();
    }

}
