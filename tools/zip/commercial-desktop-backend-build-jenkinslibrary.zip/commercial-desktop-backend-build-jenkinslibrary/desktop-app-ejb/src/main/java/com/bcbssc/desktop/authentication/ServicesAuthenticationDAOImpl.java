/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.desktop.authentication;

import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.jws.HandlerChain;
import javax.security.auth.Subject;
import javax.xml.ws.WebServiceRef;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.dao.auth.AuthenticationException;
import com.bcbssc.desktop.dao.auth.NotAuthenticatedException;
import com.bcbssc.desktop.dao.auth.NotAuthorizedException;
import com.bcbssc.desktop.dao.auth.UserPasswordExpiredException;
import com.bcbssc.desktop.dao.auth.UserRevokedException;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.services.BaseServiceIntegrator;
import com.bcbssc.desktop.util.services.util.ServicesAuthorizationException;
import com.bcbssc.desktop.util.services.util.ServicesDataAccessException;
import com.bcbssc.domain.entity.UserAuthenticationCriteria;
import com.bcbssc.services.signonpasswordreset.SignOnPasswordResetInput;
import com.bcbssc.services.signonpasswordreset.SignOnPasswordResetOutput;
import com.bcbssc.services.signonpasswordreset.SignOnPasswordResetService;
import com.bcbssc.services.signonpasswordreset.SignOnPasswordResetServiceService;
import com.bcbssc.wsutils.exception.BcbsscDetailedSoapFaultException;
import com.bcbssc.wsutils.util.BcbsscFaultDetails;

/**
 * The DAO implementation for the SignOnPasswordReset service.
 */
@Stateless
@Local
public class ServicesAuthenticationDAOImpl
extends BaseServiceIntegrator<SignOnPasswordResetService, UserAuthenticationCriteria, SignOnPasswordResetInput, SignOnPasswordResetOutput, Boolean>
implements AuthenticationDAO {

    private static Log log = LogFactory.getLog(ServicesAuthenticationDAOImpl.class);

    private static final String REQUEST_TYPE_AUTHENTICATE = "1";
    private static final String REQUEST_TYPE_CHANGE_PASSWORD = "2";

    private static final Map<String, Class<? extends AuthenticationException>> FAULT_EXCEPTION_MAPPINGS = new HashMap<String, Class<? extends AuthenticationException>>();
    static {
        FAULT_EXCEPTION_MAPPINGS.put("20003", UserPasswordExpiredException.class); // NEW PASSWORD IS REQUIRED
        FAULT_EXCEPTION_MAPPINGS.put("20004", NotAuthenticatedException.class);    // PASSWORD INVALID - ENTER A VALID PASSWORD
        FAULT_EXCEPTION_MAPPINGS.put("20006", UserRevokedException.class);         // USERID IS REVOKED - CONTACT HELP DESK
        FAULT_EXCEPTION_MAPPINGS.put("20018", UserPasswordExpiredException.class); // PLEASE ENTER A NEW PASSWORD
        FAULT_EXCEPTION_MAPPINGS.put("20019", NotAuthenticatedException.class);    // USERID IS UNKNOWN TO THE ESM
    }

    @HandlerChain(file = "../dao/services/handlerchain/soax-service-handler-chain.xml")
    @WebServiceRef(wsdlLocation = "META-INF/wsdl/SignOnPasswordReset.wsdl", value=SignOnPasswordResetServiceService.class)
    private SignOnPasswordResetService service;

    @Override
    public void authenticateUser(UserAuthenticationCriteria criteria) throws NotAuthenticatedException, NotAuthorizedException, Exception {
        if (null == criteria) {
            throw new UnsupportedOperationException("Must supply the criteria for authenticating users");
        }
        this.consumeService(criteria);
    }

    @Override
    public SignOnPasswordResetService getService() {
        return service;
    }

    @Override
    public SignOnPasswordResetOutput invokeService(SignOnPasswordResetInput input, SignOnPasswordResetService service) throws Exception {
        return service.processSignOnPasswordReset(input);
    }

    @Override
    public SignOnPasswordResetInput mapInput(UserAuthenticationCriteria criteria) {
        /*
         * Assumes that the criteria object has been checked for null already
         */
        final String username = StringUtils.trim(criteria.getUserName());
        final String password = StringUtils.trim(criteria.getPassword());
        final String newPassword = StringUtils.trim(criteria.getNewPassword());
        final String newPasswordConfirmation = StringUtils.trim(criteria.getVerifyNewPassword());
        String hostId = StringUtils.trim(criteria.getHostUserName());
        String hostPassword = StringUtils.trim(criteria.getHostPassword());
        String region = StringUtils.trim(criteria.getRegion());

        /*
         * Considering this can be run a number of different ways, check to see if
         * the hostId, hostPassword and region are blank and if they are then
         * attempt to load them from the Context
         */
        final Subject subject = SubjectUtils.getCurrentSubject();
        if (StringUtils.isBlank(hostId)) {
            try {
                hostId = SubjectUtils.getRacfId(subject);
            } catch (final RuntimeException e) {
                /*
                 * This exception will be thrown if the context doesn't exist or if
                 * the subject is not on the context
                 */
                log.warn("Could not find the hostId in the criteria passed in nor in the context");
            }
        }
        if (StringUtils.isBlank(hostPassword)) {
            try {
                hostPassword = SubjectUtils.getRACFPassword(subject);
            } catch (final RuntimeException e) {
                /*
                 * This exception will be thrown if the context doesn't exist or if
                 * the subject is not on the context
                 */
                log.warn("Could not find the hostPassword in the criteria passed in nor in the context");
            }
        }
        if (StringUtils.isBlank(region)) {
            region = SubjectUtils.getRegion(subject);
        }

        final SignOnPasswordResetInput input = new SignOnPasswordResetInput();
        input.setHostID(hostId);
        input.setHostPassword(hostPassword);
        input.setMWIConfig(region);
        input.setReqPassword(password);
        if (StringUtils.isNotBlank(criteria.getNewPassword())) {
            input.setNewPassword(newPassword);
            input.setConfirmedNewPassword(newPasswordConfirmation);
            input.setTypeOfRequest(REQUEST_TYPE_CHANGE_PASSWORD);
        } else {
            input.setTypeOfRequest(REQUEST_TYPE_AUTHENTICATE);
        }

        input.setUserId(username);

        return input;
    }

    @Override
    public Boolean mapOutput(SignOnPasswordResetOutput arg0) {
        /*
         * This really doesn't have to do anything
         */
        return null;
    }

    @Override
    public void setService(SignOnPasswordResetService service) {
        this.service = service;
    }

    @Override
    protected String getServiceName() {
        return SignOnPasswordResetService.class.getSimpleName();
    }

    @Override
    protected FaultHandler<Boolean> getFaultHandler() {
        return new FaultHandler<Boolean>() {
            @Override
            public Boolean handleFault(BcbsscDetailedSoapFaultException wse) {
                if (wse.getFaultDetails() != null) {
                    final String faultCode = wse.getFaultCode();
                    final String faultString = wse.getFaultString();
                    translateFaultDetails(wse);
                } else {
                    //Response does not contain the original details from the SOA Express service
                    log.error("Expecting fault details in soap fault but found none:\n" + wse, wse);
                    throw new ServicesDataAccessException("Unexpected soap fault encountered - no fault details found", wse);
                }
                return Boolean.FALSE;
            }
        };
    }

    private void translateFaultDetails(BcbsscDetailedSoapFaultException wse) {

        final String faultCode = wse.getFaultCode();
        final String faultString = wse.getFaultString();
        final BcbsscFaultDetails details = wse.getFaultDetails();

        String serviceCode;
        String serviceMessage;
        String applicationMessage;
        String systemMessage;
        /*
         * First check to see if the fault code has 3 elements separated by a .
         */
        final String[] faultCodeSegments = StringUtils.split(faultCode, ".");
        if ((null != faultCodeSegments) && (faultCodeSegments.length >= 3)) {
            /*
             * The length was appropriate, use the last segment as the service code and the fault string as the service message
             */
            serviceCode = faultCodeSegments[faultCodeSegments.length - 1];
            serviceMessage = faultString;
            /*
             * Set the applicationMessage to the service code so that it will be passed through to the application
             */
            applicationMessage = serviceCode;
            systemMessage = serviceMessage;
        } else {
            serviceCode = details.getServiceMessageCode();
            serviceMessage = details.getServiceMessage();
            applicationMessage = details.getApplicationMessage();
            systemMessage = details.getSystemMessage();
        }

        if (log.isDebugEnabled()) {
            log.debug("Checking response status:" + " serviceCode=" + serviceCode + ", serviceMessage=" + serviceMessage + ", systemMessage="
                            + systemMessage + ", applicationMessage=" + applicationMessage);
        }

        if(StringUtils.isNotBlank(serviceCode)){
            final String responseType = StringUtils.trimToEmpty(serviceCode);
            if(FAULT_EXCEPTION_MAPPINGS.containsKey(responseType)) {
                AuthenticationException authenticationException = null;
                Constructor<? extends AuthenticationException> constructor;
                try {
                    constructor = FAULT_EXCEPTION_MAPPINGS.get(responseType)
                                    .getConstructor(String.class, Throwable.class);
                    authenticationException = constructor.newInstance(applicationMessage, wse);
                } catch (final Exception exception) {
                    log.error("Was not able to construct a proper exception type to throw for service code [" + responseType + "].  Throwing a generic exception that will not be properly handled.", exception);
                    throw new ServicesAuthorizationException(applicationMessage, wse);
                }
                throw authenticationException;
            }
            if(StringUtils.isNumeric(responseType)){
                final int responseTypeInt = Integer.parseInt(responseType);
                if (responseTypeInt < 10000){
                    throw new ServicesDataAccessException("Received soap fault, but serviceMessageCode in details indicated success (DP error?): " + serviceCode);
                }else if(responseTypeInt < 20000){
                    //Input error
                    throw new NotAuthenticatedException(applicationMessage);
                } else if(responseTypeInt < 30000){
                    //Access error
                    throw new ServicesAuthorizationException(applicationMessage);
                } else if(responseTypeInt < 99998){
                    //Internal error
                    throw new ServicesDataAccessException(applicationMessage);
                } else if (responseTypeInt <= 99999){
                    log.warn("'Unknown service status' message code encountered: "+serviceCode+" - "+applicationMessage);
                    throw new ServicesDataAccessException("'Unknown service status' message code encountered: "+serviceCode+" - "+applicationMessage);
                } else{
                    throw new ServicesDataAccessException("Invalid response status code: " + serviceCode);
                }
            } else{
                //Response code is invalid (ie. does not start with a number)
                throw new ServicesDataAccessException("Invalid response status code: " + serviceCode);
            }
        } else {
            //Response code is missing
            throw new ServicesDataAccessException("Missing response status code in fault details.");
        }
    }
}
