/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.desktop.startup;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.jws.HandlerChain;
import javax.xml.ws.WebServiceRef;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.dao.auth.NotAuthorizedException;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.services.BaseServiceIntegrator;
import com.bcbssc.desktop.util.services.interceptor.ServicesDataAccessExceptionInterceptor;
import com.bcbssc.domain.entity.ApplicationClient;
import com.bcbssc.domain.entity.RpnAuthorization;
import com.bcbssc.services.rpnresetprocess.RPNResetProcessInput;
import com.bcbssc.services.rpnresetprocess.RPNResetProcessOutput;
import com.bcbssc.services.rpnresetprocess.RPNResetProcessService;
import com.bcbssc.services.rpnresetprocess.RPNResetProcessServiceService;
import com.bcbssc.wsutils.exception.BcbsscDetailedSoapFaultException;

/**
 * DAO implementation of RPNResetProcess service.
 */
@Stateless
@Local
@Interceptors({ServicesDataAccessExceptionInterceptor.class})
public class ServicesRpnSecurityDAOImpl extends BaseServiceIntegrator<RPNResetProcessService, String, RPNResetProcessInput, RPNResetProcessOutput, RpnAuthorization> implements RpnSecurityDAO {

    private static final Log log = LogFactory.getLog(ServicesRpnSecurityDAOImpl.class);

    @HandlerChain(file = "../dao/services/handlerchain/soax-service-handler-chain.xml")
    @WebServiceRef(wsdlLocation = "META-INF/wsdl/RPNResetProcess.wsdl", value=RPNResetProcessServiceService.class)
    private RPNResetProcessService service;

    /**
     * Empty Constructor
     * @throws Exception
     */
    public ServicesRpnSecurityDAOImpl() throws Exception {
    }

    @Override
    public Boolean isSecureForRpn() throws Exception {

        final String aliasRpn = SubjectUtils.getClient(SubjectUtils.getCurrentSubject()).getAliasRpn();

        if(log.isDebugEnabled()){
            log.debug("Checking security for RPN "+ aliasRpn);
        }

        final RpnAuthorization rpnAuthorization = this.consumeService(aliasRpn);

        // If a security error occurs, a fault exception will be thrown, so just
        // assume that if the rpnAuthorization object isn't null, then the authorization
        // was successful.
        return (rpnAuthorization != null);
    }

    @Override
    public RPNResetProcessService getService() {
        return service;
    }

    @Override
    public RPNResetProcessOutput invokeService(RPNResetProcessInput input, RPNResetProcessService service) throws Exception {
        return service.processRPNReset(input);
    }

    @Override
    public RPNResetProcessInput mapInput(String aliasRpn) {
        final RPNResetProcessInput input = new RPNResetProcessInput();
        input.setRequestRpn(aliasRpn);
        return input;
    }

    @Override
    public RpnAuthorization mapOutput(RPNResetProcessOutput output) {

        final ApplicationClient client = new ApplicationClient();
        client.setRpn(output.getRpn());
        client.setClientName(output.getClientName());

        final RpnAuthorization authorization = new RpnAuthorization();
        authorization.setClient(client);
        authorization.setRacfId(output.getRacfId());
        authorization.setRacfName(output.getRacfName());
        authorization.setAuthMessage(output.getServiceMessage());

        return authorization;
    }

    @Override
    public void setService(RPNResetProcessService service) {
        this.service = service;
    }

    @Override
    protected String getServiceName() {
        return RPNResetProcessService.class.getSimpleName();
    }

    @Override
    protected FaultHandler<RpnAuthorization> getFaultHandler() {
        return new FaultHandler<RpnAuthorization>() {
            @Override
            public RpnAuthorization handleFault(BcbsscDetailedSoapFaultException excType) {
                // If anything goes wrong, throw an unauthorized exception
                // It is probably a security error and the user doesn't have access
                throw new NotAuthorizedException(excType.getFaultDetails().getApplicationMessage(), excType);
            }
        };
    }

}
