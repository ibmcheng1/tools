
package com.bcbssc.services.programsummaryinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProgramSummaryInfoOutput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProgramSummaryInfoOutput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="applicationMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="serviceMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="serviceMessageCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="systemMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="pageNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="patientName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="pharmacyBenefitManagerVendor" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="pharmacyBenefitManagerDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="mentalHealthVendor" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="mentalHealthEffDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="caseManagementInd" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="diseaseManagementInd" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="maternityManagementInd" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="wellnessManagementInd" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="moreDataIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="programSummaryInfo" type="{http://ProgramSummaryInfo.TM05T101EJB.commercial.bcbssc.com}ArrayOfProgramSummaryInfoProgramSummaryInfo"/>
 *         &lt;element name="ebizReplyAbendcode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ebizReplyStatus" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ebizReplyStatusMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProgramSummaryInfoOutput", propOrder = {
    "applicationMessage",
    "serviceMessage",
    "serviceMessageCode",
    "systemMessage",
    "pageNumber",
    "patientName",
    "pharmacyBenefitManagerVendor",
    "pharmacyBenefitManagerDate",
    "mentalHealthVendor",
    "mentalHealthEffDate",
    "caseManagementInd",
    "diseaseManagementInd",
    "maternityManagementInd",
    "wellnessManagementInd",
    "moreDataIndicator",
    "programSummaryInfo",
    "ebizReplyAbendcode",
    "ebizReplyStatus",
    "ebizReplyStatusMessage"
})
public class ProgramSummaryInfoOutput {

    @XmlElement(required = true, nillable = true)
    protected String applicationMessage;
    @XmlElement(required = true, nillable = true)
    protected String serviceMessage;
    @XmlElement(required = true, nillable = true)
    protected String serviceMessageCode;
    @XmlElement(required = true, nillable = true)
    protected String systemMessage;
    @XmlElement(required = true, nillable = true)
    protected String pageNumber;
    @XmlElement(required = true, nillable = true)
    protected String patientName;
    @XmlElement(required = true, nillable = true)
    protected String pharmacyBenefitManagerVendor;
    @XmlElement(required = true, nillable = true)
    protected String pharmacyBenefitManagerDate;
    @XmlElement(required = true, nillable = true)
    protected String mentalHealthVendor;
    @XmlElement(required = true, nillable = true)
    protected String mentalHealthEffDate;
    @XmlElement(required = true, nillable = true)
    protected String caseManagementInd;
    @XmlElement(required = true, nillable = true)
    protected String diseaseManagementInd;
    @XmlElement(required = true, nillable = true)
    protected String maternityManagementInd;
    @XmlElement(required = true, nillable = true)
    protected String wellnessManagementInd;
    @XmlElement(required = true, nillable = true)
    protected String moreDataIndicator;
    @XmlElement(required = true, nillable = true)
    protected ArrayOfProgramSummaryInfoProgramSummaryInfo programSummaryInfo;
    @XmlElement(required = true, nillable = true)
    protected String ebizReplyAbendcode;
    protected int ebizReplyStatus;
    @XmlElement(required = true, nillable = true)
    protected String ebizReplyStatusMessage;

    /**
     * Gets the value of the applicationMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationMessage() {
        return applicationMessage;
    }

    /**
     * Sets the value of the applicationMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationMessage(String value) {
        this.applicationMessage = value;
    }

    /**
     * Gets the value of the serviceMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceMessage() {
        return serviceMessage;
    }

    /**
     * Sets the value of the serviceMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceMessage(String value) {
        this.serviceMessage = value;
    }

    /**
     * Gets the value of the serviceMessageCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceMessageCode() {
        return serviceMessageCode;
    }

    /**
     * Sets the value of the serviceMessageCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceMessageCode(String value) {
        this.serviceMessageCode = value;
    }

    /**
     * Gets the value of the systemMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystemMessage() {
        return systemMessage;
    }

    /**
     * Sets the value of the systemMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystemMessage(String value) {
        this.systemMessage = value;
    }

    /**
     * Gets the value of the pageNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPageNumber() {
        return pageNumber;
    }

    /**
     * Sets the value of the pageNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPageNumber(String value) {
        this.pageNumber = value;
    }

    /**
     * Gets the value of the patientName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatientName() {
        return patientName;
    }

    /**
     * Sets the value of the patientName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatientName(String value) {
        this.patientName = value;
    }

    /**
     * Gets the value of the pharmacyBenefitManagerVendor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPharmacyBenefitManagerVendor() {
        return pharmacyBenefitManagerVendor;
    }

    /**
     * Sets the value of the pharmacyBenefitManagerVendor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPharmacyBenefitManagerVendor(String value) {
        this.pharmacyBenefitManagerVendor = value;
    }

    /**
     * Gets the value of the pharmacyBenefitManagerDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPharmacyBenefitManagerDate() {
        return pharmacyBenefitManagerDate;
    }

    /**
     * Sets the value of the pharmacyBenefitManagerDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPharmacyBenefitManagerDate(String value) {
        this.pharmacyBenefitManagerDate = value;
    }

    /**
     * Gets the value of the mentalHealthVendor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMentalHealthVendor() {
        return mentalHealthVendor;
    }

    /**
     * Sets the value of the mentalHealthVendor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMentalHealthVendor(String value) {
        this.mentalHealthVendor = value;
    }

    /**
     * Gets the value of the mentalHealthEffDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMentalHealthEffDate() {
        return mentalHealthEffDate;
    }

    /**
     * Sets the value of the mentalHealthEffDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMentalHealthEffDate(String value) {
        this.mentalHealthEffDate = value;
    }

    /**
     * Gets the value of the caseManagementInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCaseManagementInd() {
        return caseManagementInd;
    }

    /**
     * Sets the value of the caseManagementInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCaseManagementInd(String value) {
        this.caseManagementInd = value;
    }

    /**
     * Gets the value of the diseaseManagementInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDiseaseManagementInd() {
        return diseaseManagementInd;
    }

    /**
     * Sets the value of the diseaseManagementInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDiseaseManagementInd(String value) {
        this.diseaseManagementInd = value;
    }

    /**
     * Gets the value of the maternityManagementInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaternityManagementInd() {
        return maternityManagementInd;
    }

    /**
     * Sets the value of the maternityManagementInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaternityManagementInd(String value) {
        this.maternityManagementInd = value;
    }

    /**
     * Gets the value of the wellnessManagementInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWellnessManagementInd() {
        return wellnessManagementInd;
    }

    /**
     * Sets the value of the wellnessManagementInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWellnessManagementInd(String value) {
        this.wellnessManagementInd = value;
    }

    /**
     * Gets the value of the moreDataIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMoreDataIndicator() {
        return moreDataIndicator;
    }

    /**
     * Sets the value of the moreDataIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMoreDataIndicator(String value) {
        this.moreDataIndicator = value;
    }

    /**
     * Gets the value of the programSummaryInfo property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfProgramSummaryInfoProgramSummaryInfo }
     *     
     */
    public ArrayOfProgramSummaryInfoProgramSummaryInfo getProgramSummaryInfo() {
        return programSummaryInfo;
    }

    /**
     * Sets the value of the programSummaryInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfProgramSummaryInfoProgramSummaryInfo }
     *     
     */
    public void setProgramSummaryInfo(ArrayOfProgramSummaryInfoProgramSummaryInfo value) {
        this.programSummaryInfo = value;
    }

    /**
     * Gets the value of the ebizReplyAbendcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEbizReplyAbendcode() {
        return ebizReplyAbendcode;
    }

    /**
     * Sets the value of the ebizReplyAbendcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEbizReplyAbendcode(String value) {
        this.ebizReplyAbendcode = value;
    }

    /**
     * Gets the value of the ebizReplyStatus property.
     * 
     */
    public int getEbizReplyStatus() {
        return ebizReplyStatus;
    }

    /**
     * Sets the value of the ebizReplyStatus property.
     * 
     */
    public void setEbizReplyStatus(int value) {
        this.ebizReplyStatus = value;
    }

    /**
     * Gets the value of the ebizReplyStatusMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEbizReplyStatusMessage() {
        return ebizReplyStatusMessage;
    }

    /**
     * Sets the value of the ebizReplyStatusMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEbizReplyStatusMessage(String value) {
        this.ebizReplyStatusMessage = value;
    }

}
