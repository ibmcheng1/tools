/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.endtask;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.util.jdbc.executor.JdbcServiceInputMapper;
import com.bcbssc.desktop.util.jdbc.executor.JdbcServiceInvoker;
import com.bcbssc.desktop.util.jdbc.executor.JdbcServiceOutputMapper;
import com.bcbssc.desktop.util.jdbc.query.BaseQuery;
import com.bcbssc.domain.entity.inform.InformSecurity;

/**
 * An class that perform various query operations for 'InformSecurity' instances
 * 
 * Class Operations
 * ====================
 *	A. getInformSecurityByEmployeeId(schema, employeeId), returns InformSecurity 
 *		 
 *
 * <pre>
 * $Archive$
 * $Workfile$
 * $Revision$
 * $Date$
 * $Modtime$
 * </pre>
 * 
 * @author $Author$  (original: XAA7)
 * @version $Revision$
 */
public class InformSecurityQuery extends BaseQuery {

    private static final Log logger = LogFactory.getLog(InformSecurityQuery.class);

    private static final String SQL_GET_BY_ID = "SELECT SEC_P_COMP_CD, SEC_P_DIV_CD, SEC_P_DEPT_CD, SEC_EMP_ID_NO, SEC_CORP_CD, SEC_P_INQ_TYPE, SEC_SUB_ROLE, SEC_UPD_AD_HOC_IND, SEC_EMP_NAME FROM {0}.VINFSECZ WHERE SEC_EMP_ID_NO = ?";
    private static final String SQL_GET_BY_RACF_ID = "SELECT SEC_P_COMP_CD, SEC_P_DIV_CD, SEC_P_DEPT_CD, SEC_EMP_ID_NO, SEC_CORP_CD, SEC_P_INQ_TYPE, SEC_SUB_ROLE, SEC_UPD_AD_HOC_IND, SEC_EMP_NAME FROM {0}.VINFSECZ WHERE SEC_RACF_ID = ?";
    private static final String UNKNOWN_EMPLOYEE_NAME = "UNKNOWN";

    
    /**
     * fetch InformSecurity using RACF ID
     * @param schema is the name of data source to query
     * @param employeeRacf is the employeeRacf to query by
     * @return InformSecurity instance by employeeRacf
     */
    public InformSecurity getInformSecurityByEmployeeRacf(String schema, String employeeRacf) {
        InformSecurity informSecurity = null;
        List results = null;

        String actualSQL = MessageFormat.format(SQL_GET_BY_RACF_ID, new Object[] { schema });

        Object[] params = new Object[] { employeeRacf };

        if (logger.isDebugEnabled()) {
            logger.debug("SQL Query: " + actualSQL);
            logger.debug("Query parameters: " + StringUtils.join(params, ", "));
        }

        JdbcServiceInputMapper inputMapper = new InformSecurityInputMapper(actualSQL, employeeRacf);
        JdbcServiceOutputMapper outputMapper = new InformSecurityRowMapper();

        try {
            results = (List) this.jdbcTemplate.execute(inputMapper, outputMapper, new JdbcServiceInvoker());
        } catch (Exception e) {
            logger.error("Unable to load InformSecurity: ", e);
        }

        if (null != results && results.size() != 0) {
            informSecurity = (InformSecurity) results.get(0);
        }

        return informSecurity;
    }


    /**
     * @param schema is the name of data source to query
     * @param employeeId is the employeeId to query by
     * @return InformSecurity instance by employeeId
     */
    public InformSecurity getInformSecurityByEmployeeId(String schema, String employeeId) {
        InformSecurity informSecurity = null;
        List results = null;

        String actualSQL = MessageFormat.format(SQL_GET_BY_ID, new Object[] { schema });

        Object[] params = new Object[] { employeeId };

        if (logger.isDebugEnabled()) {
            logger.debug("SQL Query: " + actualSQL);
            logger.debug("Query parameters: " + StringUtils.join(params, ", "));
        }

        JdbcServiceInputMapper inputMapper = new InformSecurityInputMapper(actualSQL, employeeId);
        JdbcServiceOutputMapper outputMapper = new InformSecurityRowMapper();

        try {
            results = (List) this.jdbcTemplate.execute(inputMapper, outputMapper, new JdbcServiceInvoker());
        } catch (Exception e) {
            logger.error("Unable to load InformSecurity: ", e);
        }

        if (null != results && results.size() != 0) {
            informSecurity = (InformSecurity) results.get(0);
        }

        return informSecurity;
    }

    
    /**
     * input mapper for the RacfId select query - see <code>EmployeeLookupQuery.getInformSecurityByEmployeeRacf(java.lang.String, java.lang.String)</code><br>
     * contains a mapInput() method that maps a single parameter (employeeRACF)
     */
    private static final class InformSecurityInputMapper extends JdbcServiceInputMapper {
        String employeeRacf;

        public InformSecurityInputMapper(String query, String employeeRacf) {
            super(query);
            this.employeeRacf = employeeRacf;
        }

        /* (non-Javadoc)
         * @see com.bcbssc.desktop.util.jdbc.executor.JdbcServiceInputMapper#mapInput()
         */
        @Override
        public Object mapInput() {
            Object[] parameters = new Object[1];
            parameters[0] = employeeRacf;
            return parameters;
        }

    }

    /**
     * row mapper for the RacfId select query - see <code>EmployeeLookupQuery.getInformSecurityByEmployeeRacf(java.lang.String, java.lang.String)</code><br>
     * contains a mapRow() method that maps query results to an InformSecurity object
     */
    private static final class InformSecurityRowMapper extends JdbcServiceOutputMapper {

        /* (non-Javadoc)
         * @see com.bcbssc.desktop.util.jdbc.executor.JdbcServiceOutputMapper#mapRow(java.sql.ResultSet)
         */
        @Override
        protected Object mapRow(ResultSet resultSet) throws SQLException {
            String companyCode = StringUtils.trim(resultSet.getString("SEC_P_COMP_CD"));
            String divisionCode = StringUtils.trim(resultSet.getString("SEC_P_DIV_CD"));
            String departmentCode = StringUtils.trim(resultSet.getString("SEC_P_DEPT_CD"));
            String employeeId = StringUtils.trim(resultSet.getString("SEC_EMP_ID_NO"));
            String corporationCode = StringUtils.trim(resultSet.getString("SEC_CORP_CD"));
            String inquiryType = StringUtils.trim(resultSet.getString("SEC_P_INQ_TYPE"));
            String subRole = StringUtils.trim(resultSet.getString("SEC_SUB_ROLE"));
            String adHocAccess = StringUtils.trim(resultSet.getString("SEC_UPD_AD_HOC_IND"));
            String employeeName = StringUtils.trim(resultSet.getString("SEC_EMP_NAME"));

            InformSecurity informSecurity = new InformSecurity();

            informSecurity.setCompanyCode(companyCode);
            informSecurity.setDivisionCode(divisionCode);
            informSecurity.setDepartmentCode(departmentCode);
            informSecurity.setEmployeeId(employeeId);
            informSecurity.setCorporationCode(corporationCode);
            informSecurity.setInquiryType(inquiryType);
            informSecurity.setSubRole(subRole);
            informSecurity.setAdHocMessageAccess(adHocAccess);

            //Let's split up the employee name into first and last
            if (StringUtils.isNotBlank(employeeName)) {
                String[] firstLastName = employeeName.split(",");
                if (firstLastName != null && firstLastName.length > 1) {
                    informSecurity.setLastName(firstLastName[0]);
                    informSecurity.setFirstName(firstLastName[1]);
                } else {
                    informSecurity.setLastName(employeeName);
                    informSecurity.setFirstName(StringUtils.EMPTY);
                }
            } else {
                informSecurity.setFirstName(StringUtils.EMPTY);
                informSecurity.setLastName(UNKNOWN_EMPLOYEE_NAME);
            }

            return informSecurity;
        }
    }
}
