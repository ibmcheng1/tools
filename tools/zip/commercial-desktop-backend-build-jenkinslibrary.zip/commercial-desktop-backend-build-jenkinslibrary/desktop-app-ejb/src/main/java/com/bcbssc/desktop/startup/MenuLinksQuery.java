/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.startup;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.util.jdbc.executor.JdbcServiceInputMapper;
import com.bcbssc.desktop.util.jdbc.executor.JdbcServiceInvoker;
import com.bcbssc.desktop.util.jdbc.executor.JdbcServiceOutputMapper;
import com.bcbssc.desktop.util.jdbc.query.BaseQuery;
import com.bcbssc.desktop.util.menu.MenuUtils;
import com.bcbssc.domain.valueobject.MenuConfiguration;
import com.bcbssc.domain.valueobject.MenuLink;

/**
 * This is an abstract class that represents a menu link query. There can be a couple
 * various of the query, but the methods provided here will be needed for all 
 * implementations.
 *
 * @author jc33
 */
public abstract class MenuLinksQuery extends BaseQuery {

    private static final Log logger = LogFactory.getLog(MenuLinksQuery.class);

    /**
     * @param schema
     * @param menuConfig
     * @return A list of {@link MenuLink} Objects
     */
    public abstract List<MenuLink> findLinks(String schema, MenuConfiguration menuConfig);

    /**
     * @param inputMapper
     * @param defaultInputMapper
     * @param defaultRegion
     * @return A list of {@link MenuLink} Objects
     */
    protected List<MenuLink> runQuery(JdbcServiceInputMapper inputMapper, JdbcServiceInputMapper defaultInputMapper, String defaultRegion) {

        List<MenuLink> results = null;
       
        JdbcServiceOutputMapper outputMapper = getOutputMapper(defaultRegion);
        try {
            results = (List<MenuLink>)jdbcTemplate.execute(inputMapper, outputMapper, new JdbcServiceInvoker());
        } catch (Exception e) {
            logger.error("An error occured while attempting to get menu links", e);
        }

        //If we did not get any results, and we were given default parameters, re-run the query
        //with the default parameters
        if (((results == null) || (results.isEmpty())) && (defaultInputMapper != null)) {
            try {
                results = (List<MenuLink>)jdbcTemplate.execute(defaultInputMapper, outputMapper, new JdbcServiceInvoker());
            } catch (Exception e) {
                logger.error("An error occured while attempting to get menu links", e);
            }
        }

        if (results != null) {
            //Since we retrieve a record for every notes line, this will combine the related notes fields into
            //one record
            if(logger.isDebugEnabled()){
                logger.debug("Retrieved " + results.size() + " results");
            }
            results = MenuUtils.combineRelatedActions(results);
        }

        return results;
    }

    /**
     * Get the row mapper to be used for this operation
     * 
     * @param defaultRegion
     * @return An instance of {@link JdbcServiceOutputMapper}
     */
    public abstract JdbcServiceOutputMapper getOutputMapper(String defaultRegion);
}
