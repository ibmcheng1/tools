/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.startup;

import java.util.HashMap;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.support.LoggingDiagnosticActionExecutor;
import com.bcbssc.desktop.util.exception.DataAccessException;
import com.bcbssc.desktop.util.jdbc.BaseJDBCDAO;
import com.bcbssc.desktop.util.jdbc.executor.JdbcServiceExecutorTemplate;
import com.bcbssc.desktop.util.jdbc.interceptor.JdbcDataAccessExceptionInterceptor;
import com.bcbssc.desktop.util.jndi.JndiUtils;
import com.bcbssc.domain.entity.Subsystem;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;

/**
 * An implementation of a Subsystem Rpn DAO that uses JDBC to retrieve the information from a RDBMS.
 */
@Stateless
@Local
@Interceptors({JdbcDataAccessExceptionInterceptor.class})
public class JDBCSubsystemRpnDAOImpl extends BaseJDBCDAO implements SubsystemRpnDAO {
    private static final Log log = LogFactory.getLog(JDBCSubsystemRpnDAOImpl.class);

    public JDBCSubsystemRpnDAOImpl() throws Exception { // empty constructor
    }

    /**
     * looks up jndi and set up templates
     */
    private SubsystemRpnQuery createSubSystemRPNQuery() {
        DataSource dataSource = null;
        dataSource = JndiUtils.lookupObject(DataSource.class, EnvironmentObjects.JDBC_DEFAULT_DATASOURCE.getName());

        final JdbcServiceExecutorTemplate executorTemplate = new JdbcServiceExecutorTemplate(dataSource);
        final SubsystemRpnQuery subsystemRpnQuery = new SubsystemRpnQuery();
        final LoggingDiagnosticActionExecutor executor = new LoggingDiagnosticActionExecutor();
        executor.setActionName("JDBCSubsystemRpn");
        executor.setThreshold(3000l);
        executorTemplate.setActionExecutor(executor);

        subsystemRpnQuery.setJdbcTemplate(executorTemplate);
        return subsystemRpnQuery;

    }

    /**
     * Handle my row =%gt; object mapping.
     */
    public HashMap<String, Subsystem> convertToMap(List<Subsystem> subsystems) {
        final HashMap<String, Subsystem> result = new HashMap<>();
        for (final Subsystem subsystem: subsystems) {
            result.put(subsystem.getName(), subsystem);
        }

        if (log.isDebugEnabled()) {
            log.debug("Converted the subsystems list into a Map object: " + result);
        }
        return result;
    }

    /**
     * <p> Get a properties (map o' strings) object containing all the subsystem rpn's, keyed by CAPITALIZED string (like "CISI", "PIMS", etc.), for the given "key" rpn (called the AMMS rpn at the data store level?) </p>
     * @param keyRpn The key/amms rpn
     * @return A <code>java.util.Properties</code> of rpns per subsystem name
     * @throws DataAccessException If a data access failure (such as a database being down) occurs.
     * @throws IllegalArgumentException If any required parameters are null or empty.
     */
    @Override
    public HashMap<String, Subsystem> getSubsystemRpns(String keyRpn) throws Exception {
        if (keyRpn == null) {
            throw new IllegalArgumentException("key rpn cannot be null");
        }
        // Call createSubSystemRPNQuery every method call to initialize template with right values
        final SubsystemRpnQuery subsystemRpnQuery = createSubSystemRPNQuery();

        final List<Subsystem> subsystems = subsystemRpnQuery.getSubsystemRpns(getPrimarySchema(), getSecondarySchema(), keyRpn);

        if (log.isDebugEnabled()) {
            log.debug("Got all results: " + subsystems);
        }

        return convertToMap(subsystems);
    }

    /**
     * This method overloads the getPrimarySchema() method to pass right schema based on the environment on the current subject
     * @return String
     */
    @Override
    public String getPrimarySchema() {
        return JndiUtils.lookupObject(String.class, EnvironmentObjects.DBCONN_QUALIFIER_TMCS.getName());
    }

    /**
     * This method overloads the getSecondarySchema() method to pass right schema based on the environment on the current subject
     * @return String
     */
    private String getSecondarySchema(){
        return JndiUtils.lookupObject(String.class, EnvironmentObjects.DBCONN_QUALIFIER_ALTRPN.getName());
    }
}
