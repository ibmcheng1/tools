/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2006 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.startup;

import java.util.ArrayList;

import com.bcbssc.domain.entity.ApplicationClient;

/**
 * An ApplicationClientDAO is used to retrieve the group of clients for a given
 * desktop application deployment.
 */
public interface ApplicationClientDAO {
    /**
     * Retrieves a List of ApplicationClient objects representing the clients available for the application and rpn that is retrieved from the runtime subject.
     *
     * @return              A List of ApplicationClient objects.
     * @throws Exception
     */
    public ArrayList<ApplicationClient> getClientList() throws Exception;
}
