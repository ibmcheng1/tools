/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.events;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.interceptor.Interceptors;
import javax.jms.ConnectionFactory;
import javax.jms.Queue;
import javax.security.auth.Subject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.biz.EnvironmentBiz;
import com.bcbssc.desktop.dao.events.EventDAO;
import com.bcbssc.desktop.util.auth.ContextSubjectUtils;
import com.bcbssc.desktop.util.formats.mapper.AbstractFileBasedMapper;
import com.bcbssc.desktop.util.formats.mapper.CopybookMapper;
import com.bcbssc.desktop.util.formats.mapper.ObjectMapper;
import com.bcbssc.desktop.util.jms.interceptor.JmsDataAccessExceptionInterceptor;
import com.bcbssc.desktop.util.jms.messenger.OneWayMessenger;
import com.bcbssc.desktop.util.jndi.JndiUtils;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;
import com.bcbssc.domain.entity.events.Event;
import com.bcbssc.domain.entity.events.ResponseDataDTO;

/**
 * Sends Event Management events via JMS.
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
@Interceptors({JmsDataAccessExceptionInterceptor.class})
public class EventDAOJmsImpl implements EventDAO {
    private static final Log logger = LogFactory.getLog(EventDAOJmsImpl.class);

    private static final String COPYBOOK_MAPPER_FILE = "com/bcbssc/desktop/dao/jms/events/EVENT.xml";
    private static final String OBJECT_MAPPER_FILE = "com/bcbssc/desktop/dao/jms/events/EventMappings.xml";

    @Override
    public ResponseDataDTO sendEvent(Event event) throws Exception {
        final Subject subject = ContextSubjectUtils.getCurrentSubject();
        final EnvironmentBiz environmentBiz = JndiUtils.getEnvironmentBiz();
        final ConnectionFactory connectionFactory = environmentBiz.get(EnvironmentObjects.JMS_ENROLLMENTCONNECTIONFACTORY, ConnectionFactory.class, subject);
        final Queue eventDestination = environmentBiz.get(EnvironmentObjects.JMS_EVENTQ, Queue.class, subject);
        final String eventMessage = generateCopybookMessage(event);
        OneWayMessenger messenger = null;

        try {
            messenger = new OneWayMessenger(connectionFactory, eventDestination);
            messenger.sendRequestMessage(eventMessage);

            if (logger.isInfoEnabled()) {
                logger.info("Sent event message " + messenger.getCorrelationId());
            }
        } finally {
            if (messenger != null) {
                messenger.complete();
            }
        }
        final ResponseDataDTO result = new ResponseDataDTO();
        result.ResponseData = "sent via jms mq";
        return result;
    }

    @Override
    public ResponseDataDTO sendEvents(List<Event> events) throws Exception {
        // Try to faithfully send and report on every record.
        final List<String> responses = new ArrayList<String>(events.size());
        for (final Event e : events) {
            String r = null;
            try {
                r = (String) sendEvent(e).ResponseData;
            } catch (final Throwable t) {
                r = "failed to send via jms mq - " + t.getMessage();
            }
            responses.add(r);
        }

        final ResponseDataDTO totalResults = new ResponseDataDTO();
        totalResults.ResponseData = responses;
        return totalResults;
    }


    /**
     * Generates an Event copybook message.
     * @param event Event information.
     */
    protected static String generateCopybookMessage(Event event) throws Exception {
        final Hashtable<String, String> dataMap = new Hashtable<String, String>(75);
        final ObjectMapper objectMapper = new ObjectMapper();
        setMapperDocument(objectMapper, OBJECT_MAPPER_FILE);
        objectMapper.performCopy(event, dataMap, event.getMapName());

        final CopybookMapper copybookMapper = new CopybookMapper();
        setMapperDocument(copybookMapper, COPYBOOK_MAPPER_FILE);

        final String copybookMessage = copybookMapper.generateCopybook(dataMap);

        if (logger.isDebugEnabled()) {
            logger.debug("Copybook message generated from eventData: " + copybookMessage);
        }

        return copybookMessage;
    }

    /**
     * Sets the XML document to use on the given target mapper.
     * @param mapper the target mapper.
     * @param resourcePath the resource path of the XML document to use.
     * @throws Exception if an error occurs.
     */
    private static void setMapperDocument(AbstractFileBasedMapper mapper, String resourcePath) throws Exception {
        final InputStream streamToMappingFile = Thread.currentThread().getContextClassLoader().getResourceAsStream(resourcePath);

        if (streamToMappingFile == null) {
            throw new IllegalArgumentException("Unable to locate required XML file: " + resourcePath);
        }

        mapper.setDocument(streamToMappingFile);
    }
}
