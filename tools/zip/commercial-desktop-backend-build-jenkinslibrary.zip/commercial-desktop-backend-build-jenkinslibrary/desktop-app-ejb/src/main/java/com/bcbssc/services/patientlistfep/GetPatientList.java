
package com.bcbssc.services.patientlistfep;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="arg_0_0" type="{http://PatientListFEP.FEPET102EJB.commercial.bcbssc.com}PatientListFEPInput"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "arg00"
})
@XmlRootElement(name = "getPatientList")
public class GetPatientList {

    @XmlElement(name = "arg_0_0", required = true, nillable = true)
    protected PatientListFEPInput arg00;

    /**
     * Gets the value of the arg00 property.
     * 
     * @return
     *     possible object is
     *     {@link PatientListFEPInput }
     *     
     */
    public PatientListFEPInput getArg00() {
        return arg00;
    }

    /**
     * Sets the value of the arg00 property.
     * 
     * @param value
     *     allowed object is
     *     {@link PatientListFEPInput }
     *     
     */
    public void setArg00(PatientListFEPInput value) {
        this.arg00 = value;
    }

}
