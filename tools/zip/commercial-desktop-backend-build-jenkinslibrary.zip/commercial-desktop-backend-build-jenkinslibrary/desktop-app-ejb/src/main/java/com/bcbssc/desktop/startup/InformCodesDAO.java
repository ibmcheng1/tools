/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUE CROSS AND BLUE SHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION, OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 *
 * Copyright (c) 2007 Blue Cross and Blue Shield of South Carolina.
 * All rights reserved.
 * An independent licensee of the Blue Cross and Blue Shield Association.
 */
package com.bcbssc.desktop.startup;

import java.util.List;

import com.bcbssc.domain.entity.InformSearchCriteria;
import com.bcbssc.domain.entity.codes.inform.CategoryCode;
import com.bcbssc.domain.entity.codes.inform.ContactTypeCode;
import com.bcbssc.domain.entity.codes.inform.RequestReasonCode;
import com.bcbssc.domain.entity.codes.inform.ResolutionCode;
import com.bcbssc.domain.entity.codes.inform.ResponseCode;
import com.bcbssc.domain.entity.codes.inform.SeverityCode;
import com.bcbssc.domain.entity.codes.inform.StatusCode;
import com.bcbssc.domain.entity.codes.inform.TransferCode;

/**
 * The interface for DAOs that retrieve INFOrm code beans.
 */
public interface InformCodesDAO {
    
    /**
     * Get all of the available Status Codes for the given search Criteria
     * 
     * @param searchCriteria
     * @return
     */
    public List<StatusCode> getStatusCodes(InformSearchCriteria searchCriteria) throws Exception;
    
    /**
     * Get all of the available Severity Codes for the given search criteria
     * 
     * @param searchCriteria
     * @return
     */
    public List<SeverityCode> getSeverityCodes(InformSearchCriteria searchCriteria) throws Exception;
    
    /**
     * Get all of the available Category Codes for the given search criteria
     * 
     * @param searchCriteria
     * @return
     */
    public List<CategoryCode> getCategoryCodes(InformSearchCriteria searchCriteria) throws Exception;
    
    /**
     * Get all of the available Request Reason Codes for the given search criteria
     * 
     * @param searchCriteria
     * @return
     */
    public List<RequestReasonCode> getRequestReasonCodes(InformSearchCriteria searchCriteria) throws Exception;
    
    /**
     * Get all of the available Contact Type Codes for the given search criteria
     * 
     * @param searchCriteria
     * @return
     */
    public List<ContactTypeCode> getContactTypeCodes(InformSearchCriteria searchCriteria) throws Exception;
    
    /**
     * Get all of the available Response Codes for the given search criteria
     * 
     * @param searchCriteria
     * @return
     */
    public List<ResponseCode> getResponseCodes(InformSearchCriteria searchCriteria) throws Exception;
    
    /**
     * Get all of the available Resolution Codes for the given search criteria
     * 
     * @param searchCriteria
     * @return
     */
    public List<ResolutionCode> getResolutionCodes(InformSearchCriteria searchCriteria) throws Exception;
    
    /**
     * Get all of the available Transfer Codes for the given search criteria
     * 
     * @param searchCriteria
     * @return
     */
    public List<TransferCode> getTransferCodes(InformSearchCriteria searchCriteria) throws Exception;
}
