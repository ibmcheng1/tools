/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.desktop.familySummary;

import com.bcbssc.desktop.dao.MemberDAO;
import com.bcbssc.desktop.util.services.interceptor.ServicesDataAccessExceptionInterceptor;
import com.bcbssc.domain.entity.FepMember;
import com.bcbssc.domain.entity.Member;
import com.bcbssc.domain.entity.MemberSearchCriteria;
import com.bcbssc.services.patientlistfep.PatientListFEPInput;
import com.bcbssc.services.patientlistfep.PatientListFEPOutput;
import com.bcbssc.services.patientlistfep.PatientListFEPPatientInformation;
import com.bcbssc.services.patientlistfep.PatientListFEPService;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * This is an implementation of @MemberDAO to retrieve a FEPMembers
 *
 */
@Stateless(name = "fepMemberDAO")
@Local
@Interceptors({ServicesDataAccessExceptionInterceptor.class})
public class ServicesFepMemberDAOImpl implements MemberDAO {
    /**
     * Logger for this class.
     */
    private static final Log log = LogFactory.getLog(ServicesFepMemberDAOImpl.class);



    /*
     * Load Member by subscriber and member id.
     *
     * @see com.bcbssc.desktop.dao.MemberDAO#getMember(java.lang.String, java.lang.String) */
    @Override
    public Member getMember(String subscriberId, String memberId)
                    throws Exception {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /*
     * returns a set of members by the supplied subscriber id.
     *
     * @see com.bcbssc.desktop.dao.MemberDAO#getSubscriberMembers(java.lang.String)
     *
     * @param subscriberId - the id for the selected members
     * */
    @Override
    @SuppressWarnings("unchecked")
    public Set<Member> getSubscriberMembers(String subscriberId) {
        //        WebServiceConsumerTemplate consumerTemplate = new WebServiceConsumerTemplate();
        //        WebServiceConsumerCallback consumerCallback = new FepMemberServiceCallback(subscriberId);
        //
        //
        //        return (Set <Member>) consumerTemplate.consumeService(subscriberId, consumerCallback);
        throw new UnsupportedOperationException("This class needs to be redone to use the BaseServicesIntegrator");
    }

    /* @see com.bcbssc.desktop.dao.MemberDAO#searchForMember(com.bcbssc.domain.entity.MemberSearchCriteria) */
    @Override
    public List searchForMember(MemberSearchCriteria searchCriteria) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    protected Object getServiceObject() {
        //        return new ServiceClientGenerator("PatientListFEP").getServiceClient();
        throw new UnsupportedOperationException("This class needs to be redone to use the BaseServicesIntegrator");
    }

    /**
     * Consumes the FepMember service
     *
     * @author $Author$  (original: XAA7)
     * @version $Revision$
     */
    private class FepMemberServiceCallback {
        private final String subscriberId;


        public FepMemberServiceCallback(String subscriberId){
            this.subscriberId = subscriberId;
        }

        /*
         * returns PatientListFEPServiceProxy service
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#getService()
         * */
        public Object getService() {
            return getServiceObject();
        }

        /*
         * @param serviceInput PatientListFEPInput
         * @param serviceClient PatientListFepService
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#invokeService(java.lang.Object, java.lang.Object)
         *
         *  @return PatientListFEPOutput
         * */
        public Object invokeService(Object serviceInput, Object serviceClient) throws Exception {
            final PatientListFEPService service = (PatientListFEPService) serviceClient;
            final PatientListFEPOutput result = service.getPatientList((PatientListFEPInput) serviceInput);
            return result;
        }

        /*
         * @param modelInput - value ignore
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#mapInput(java.lang.Object)
         * @see com.bcbssc.services.patientlistfep.PatientListFEPInput
         *  @return PatientListFEPInput
         * */
        public Object mapInput(Object modelInput) {
            final PatientListFEPInput input = new PatientListFEPInput();
            input.setContractId(subscriberId);
            input.setToEscapeChar(Boolean.FALSE);
            return input;
        }

        /*
         * @param serviceOutput
         *
         * @see com.bcbssc.wsutils.WebServiceConsumerCallback#mapOutput(java.lang.Object)
         * @return
         * */
        public Object mapOutput(Object serviceOutput) {
            final PatientListFEPOutput output = (PatientListFEPOutput) serviceOutput;
            final List<PatientListFEPPatientInformation> result = output
                            .getPatientInformation().getPatientListFEPPatientInformation();

            final Set<FepMember> fepMembers = new HashSet<FepMember>();

            for (final PatientListFEPPatientInformation patientInfo: result) {

                if (StringUtils.isBlank(patientInfo.getMemberNumber())) {
                    break;
                }

                final FepMember member = new FepMember();
                member.setMemberId(patientInfo.getMemberNumber());
                member.getName().setFirstName(patientInfo.getFirstName());
                member.setBirthdate(patientInfo.getDateOfBirth());
                member.setSexCode(patientInfo.getGenderRelationshipCode());
                member.setRelationshipCode(patientInfo
                                .getGenderRelationshipCode());
                member.setPlanCode(output.getPlanCode());
                fepMembers.add(member);
            }
            return fepMembers;
        }

    }
}
