/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2013 BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.startup;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.jws.HandlerChain;
import javax.xml.ws.WebServiceRef;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.util.services.BaseServiceIntegrator;
import com.bcbssc.desktop.util.services.interceptor.ServicesDataAccessExceptionInterceptor;
import com.bcbssc.domain.valueobject.claims.CodeRange;
import com.bcbssc.services.rulesdatatypeinquiry.RULESDataTypeInquiryDetailedDataTypeRecords;
import com.bcbssc.services.rulesdatatypeinquiry.RULESDataTypeInquiryInput;
import com.bcbssc.services.rulesdatatypeinquiry.RULESDataTypeInquiryOutput;
import com.bcbssc.services.rulesdatatypeinquiry.RULESDataTypeInquiryService;
import com.bcbssc.services.rulesdatatypeinquiry.RULESDataTypeInquiryServiceService;

/**
 * The DAO Implementation that retrieves the ICD 10 Compliance Date
 */
@Stateless
@Local
@Interceptors({ServicesDataAccessExceptionInterceptor.class})
public class ServicesRulesDataTypeDAOImpl implements RulesDataTypeDAO {

    @SuppressWarnings("unused")
    private static final Log log = LogFactory.getLog(ServicesRulesDataTypeDAOImpl.class);

    protected final static String RPN = "900";
    protected final static String PLAN_CODE = "885";
    protected final static String ICD_DATE_DATA_TYPE = "RM40ICDX";
    protected final static String ICD_CATEGORIES_DATA_TYPE = "DXCATGRY";
    protected final static String ICD_DATE_KEY_FIELD = "ICDDATE";

    @HandlerChain(file = "../dao/services/handlerchain/soax-service-handler-chain.xml")
    @WebServiceRef(wsdlLocation = "META-INF/wsdl/RULESDataTypeInquiry.wsdl", value=RULESDataTypeInquiryServiceService.class)
    private RULESDataTypeInquiryService service;

    @Override
    public Date getIcdComplianceDate() {
        return new RulesDataTypeServiceIntegrator<Date>(service) {
            @Override
            public Date mapOutput(RULESDataTypeInquiryOutput output) {
                Date icdDate = null;
                final List<RULESDataTypeInquiryDetailedDataTypeRecords> records = output.getDetailedDataTypeRecords().getRULESDataTypeInquiryDetailedDataTypeRecords();
                for (final RULESDataTypeInquiryDetailedDataTypeRecords record: records) {
                    if (record.getKeyField1().equalsIgnoreCase(ICD_DATE_KEY_FIELD)) {
                        icdDate = Date.valueOf(record.getDataField1());
                        break;
                    }
                }
                return icdDate;
            }
        }.consumeService(ICD_DATE_DATA_TYPE);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<CodeRange> getIcdCategories() {
        return new RulesDataTypeServiceIntegrator<List<CodeRange>>(service) {
            @Override
            public List<CodeRange> mapOutput(RULESDataTypeInquiryOutput output) {
                final List<CodeRange> icdCategoryList = new ArrayList<>();
                final StringBuilder buffer = new StringBuilder(128);
                final List<RULESDataTypeInquiryDetailedDataTypeRecords> records = output.getDetailedDataTypeRecords().getRULESDataTypeInquiryDetailedDataTypeRecords();
                for(final RULESDataTypeInquiryDetailedDataTypeRecords record: records) {
                    buffer.setLength(0);
                    final CodeRange codeRange = new CodeRange();
                    codeRange.setCodeRangeBegin(record.getKeyField1());
                    codeRange.setCodeRangeEnd(record.getKeyField2());
                    //Check to see if the description for the range of records
                    //spans dataField1, dataField2 and dataField3.
                    if(record.getDataField3() != null) {
                        buffer.append(record.getDataField1()).append(" ").
                        append(record.getDataField2()).append(" ").
                        append(record.getDataField3());
                        //Check to see if the description for the range of records
                        //only spans dataField1 and dataField2.
                    } else if (record.getDataField2() != null) {
                        buffer.append(record.getDataField1()).append(" ").
                        append(record.getDataField2());
                    } else if(record.getDataField1() != null) {
                        buffer.append(record.getDataField1());
                    }
                    //Check to see if the description for the range of records
                    //only spans dataField1

                    codeRange.setDescription(buffer.toString());
                    icdCategoryList.add(codeRange);
                }
                return icdCategoryList;
            }
        }.consumeService(ICD_CATEGORIES_DATA_TYPE);
    }

    public void setService(RULESDataTypeInquiryService service) {
        this.service = service;
    }

    protected static abstract class RulesDataTypeServiceIntegrator<T> extends BaseServiceIntegrator<RULESDataTypeInquiryService, String, RULESDataTypeInquiryInput, RULESDataTypeInquiryOutput, T>{

        private RULESDataTypeInquiryService service;

        public RulesDataTypeServiceIntegrator(RULESDataTypeInquiryService service) {
            super();
            this.service = service;
        }

        @Override
        public RULESDataTypeInquiryService getService() {
            return service;
        }

        @Override
        public RULESDataTypeInquiryOutput invokeService(RULESDataTypeInquiryInput input, RULESDataTypeInquiryService service) throws Exception {
            return service.getRULESDataType(input);
        }

        @Override
        public RULESDataTypeInquiryInput mapInput(String dataType) {
            final RULESDataTypeInquiryInput input = new RULESDataTypeInquiryInput();
            input.setRpn(RPN);
            input.setPlanCode(PLAN_CODE);
            input.setDataType(dataType);
            input.setPreviousLastPage(StringUtils.EMPTY);
            input.setEffectiveDate(StringUtils.EMPTY);
            return input;
        }

        @Override
        public void setService(RULESDataTypeInquiryService service) {
            this.service = service;
        }

        @Override
        protected String getServiceName() {
            return RULESDataTypeInquiryService.class.getSimpleName();
        }

    }

}
