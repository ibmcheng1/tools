/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2013 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.member;

import com.bcbssc.desktop.dao.MemberDAO;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.services.BaseServiceIntegrator;
import com.bcbssc.desktop.util.services.interceptor.ServicesDataAccessExceptionInterceptor;
import com.bcbssc.domain.entity.Member;
import com.bcbssc.domain.entity.MemberSearchCriteria;
import com.bcbssc.services.patientcontactinfo.PatientContactInfoInput;
import com.bcbssc.services.patientcontactinfo.PatientContactInfoOutput;
import com.bcbssc.services.patientcontactinfo.PatientContactInfoService;
import com.bcbssc.services.patientcontactinfo.PatientContactInfoServiceService;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.jws.HandlerChain;
import javax.xml.ws.WebServiceRef;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Set;

/**
 * Retrieves detailed contact information about a single member (via <code>PatientContactInfo</code> service).
 *
 */
@Stateless(name = "ammsMemberDAO")
@Local
@Interceptors({ServicesDataAccessExceptionInterceptor.class})
public class ServicesContactInfoMemberDAOImpl extends BaseServiceIntegrator<PatientContactInfoService, ContactInfoCriteria, PatientContactInfoInput, PatientContactInfoOutput, Member> implements MemberDAO {

    /**
     * Logger for this class.
     */
    private static final Log logger = LogFactory.getLog(ServicesContactInfoMemberDAOImpl.class);
    private static final String PCP_NOT_FOUND = "PCP NOT FOUND";

    @HandlerChain(file = "../dao/services/handlerchain/soax-service-handler-chain.xml")
    @WebServiceRef(wsdlLocation = "META-INF/wsdl/PatientContactInfo.wsdl", value = PatientContactInfoServiceService.class)
    private PatientContactInfoService service;

    /**
     * Retrieves detailed contact information about a single member.
     *
     * @param subscriberId The subscriber to use to get the info.
     * @param memberId The member to use to get the info.
     * @return Returns a {@link Member} object.
     */
    @Override
    public Member getMember(String subscriberId, String memberId) {

        if(StringUtils.isBlank(subscriberId)) {
            throw new IllegalArgumentException("A subscriber ID is required.");
        } else if(StringUtils.isBlank(memberId)) {
            throw new IllegalArgumentException("A member ID is required.");
        }

        ContactInfoCriteria criteria = new ContactInfoCriteria();
        criteria.setSubscriberId(subscriberId);
        criteria.setMemberId(memberId);

        return this.consumeService(criteria);
    }

    /**
     * Not implemented.
     */
    @Override
    public Set<Member> getSubscriberMembers(String subscriberId) {
        throw new UnsupportedOperationException("Not implemented.");
    }

    /**
     * Not implemented.
     */
    @Override
    public List<Member> searchForMember(MemberSearchCriteria searchCriteria) {
        throw new UnsupportedOperationException("Not implemented.");
    }

    @Override
    public void setService(PatientContactInfoService service) {
        this.service = service;
    }

    @Override
    public PatientContactInfoService getService() {
        return service;
    }

    @Override
    protected String getServiceName() {
        return PatientContactInfoService.class.getSimpleName();
    }

    @Override
    public PatientContactInfoInput mapInput(ContactInfoCriteria criteria) {
        final PatientContactInfoInput input = new PatientContactInfoInput();
        input.setRpn(SubjectUtils.getClientStrict(SubjectUtils.getCurrentSubject()).getAliasRpn());
        input.setPlanCode(SubjectUtils.getClientStrict(SubjectUtils.getCurrentSubject()).getPlanCode());
        input.setRequestSubscriberId(criteria.getSubscriberId());
        input.setRequestPatientId(criteria.getMemberId());

        if (logger.isDebugEnabled()) {
            // Build the inputs but don't use the hostPassword
            // Any variable containing the word pass is removed.
            final String passwordVariableName = "pass";
            final String loggerString = (new ReflectionToStringBuilder(input) {
                @Override
                protected boolean accept(Field f) {
                    return super.accept(f) && !StringUtils.contains(StringUtils.lowerCase(f.getName()), passwordVariableName);
                }
            }).toString();

            logger.debug("The input for the RetrievePatientContactInfo service is: " + loggerString);
        }

        return input;
    }

    @Override
    public PatientContactInfoOutput invokeService(PatientContactInfoInput input, PatientContactInfoService service) throws Exception {
        return service.getPatientContactInfo(input);
    }

    @Override
    public Member mapOutput(PatientContactInfoOutput output) {
        final Member member = new Member();
        // There are a large number of returned fields that I'm ignoring
        // because MCS doesn't need them.
        member.getName().setFirstName(output.getPatientName());
        member.setBirthdate( output.getPatientDateOfBirth() );
        member.setSexCode( output.getPatientGender() );
        member.setRelationshipCode( output.getPatientRelationshipCode() );
        member.setCarrierName(output.getCarrierName());

        if(PCP_NOT_FOUND.equalsIgnoreCase(output.getPrimaryCarePhysicianName())) {
            // No PCP found.
            member.setPrimaryCarePhysicianFound(false);
            member.setPrimaryCarePhysicianId(StringUtils.EMPTY);
            member.setPrimaryCarePhysicianName(StringUtils.EMPTY);
        } else {
            member.setPrimaryCarePhysicianFound(true);
            member.setPrimaryCarePhysicianId(output.getPrimaryCarePhysicianName());
            member.setPrimaryCarePhysicianName(output.getPrimaryCarePhysicianDesc());
        }

        // Check if carrier is restricted for agent.
        if("Y".equalsIgnoreCase(output.getCarrierRestrictedIndicator())) {
            member.setCarrierRestricted(true);
        } else {
            member.setCarrierRestricted(false);
        }

        return member;
    }
}
