/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.inform;

import javax.security.auth.Subject;

/**
 * DAO methods dealing with Inform messages
 *
 * @author $Author$  (original: JC33)
 * @version $Revision$
 */
public interface SubmitInformDAO {

    /**
     * Sends an INFOrm message via JMS.
     * @param messageBody The message of the INFOrm to send.
     * @return Correlation ID
     */
    public String sendInformMessage(String messageBody, Subject subject);
    /**
     * Sends an INFOrm message. If the logFailedMessages indicator is set to <code>true</code>
     * then it will log the message to the file system if it fails. Otherwise it will throw
     * a RuntimeException with failure information.
     * 
     * @param messageBody
     * @param logFailedMessages
     * @return
     */
    public String sendInformMessage(String messageBody, boolean logFailedMessages, Subject subject);
    /**
     * Sends an INFOrm message via JMS.
     * @param messageBody The message of the INFOrm to send.
     * @param correlationId The correlation Id of parent ticket.
     * @return Correlation ID
     */
    public String sendInformMessage(String messageBody, String correlationId, Subject subject);
    /**
     * Sends an INFOrm message. If the logFailedMessages indicator is set to <code>true</code>
     * then it will log the message to the file system if it fails. Otherwise it will throw
     * a RuntimeException with failure information.
     * 
     * @param messageBody
     * @param correlationId
     * @param logFailedMessages
     * @return
     */
    public String sendInformMessage(String messageBody, String correlationId, boolean logFailedMessages, Subject subject);
    /**
     * Retreive INFOrm response message via JMS.
     * @param correlationId The correlationId of parent ticket.
     * @param timeoutInMillis Amount of time in milliseconds to wait for response
     * @return RECEIVED: INFOrm Move process read ticket from queue,
     *           PROCESSED: Ticket successfully processed in INFOrm,
     *           TIMEOUT: Timedout waiting for response,
     *           UNKNOWN: An unexpected response from INFOrm
     * @throws Exception If read or configuration errors occur.
     */
    public String readInformConfirmationResponse(String correlationId, long timeoutInMillis, Subject subject) throws Exception;
    
}
