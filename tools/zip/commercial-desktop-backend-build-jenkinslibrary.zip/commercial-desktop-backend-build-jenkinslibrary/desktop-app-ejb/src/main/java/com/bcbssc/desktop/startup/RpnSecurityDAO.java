/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2006 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.startup;

/**
 * An RpnSecurityDAO checks to see if the user has access to the chosen RPN and sets the user's RPN to that
 * value if access is allowed.
 */
public interface RpnSecurityDAO {

    /**
     * Checks whether or not the RACF is secure for the RPN
     * @return Boolean
     * @throws Exception
     */
    public Boolean isSecureForRpn() throws Exception;
}
