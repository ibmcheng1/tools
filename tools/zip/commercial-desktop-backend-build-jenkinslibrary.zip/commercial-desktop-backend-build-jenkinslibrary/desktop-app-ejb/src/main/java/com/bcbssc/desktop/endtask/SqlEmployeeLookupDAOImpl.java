/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2007 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.endtask;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.security.auth.Subject;
import javax.sql.DataSource;

import com.bcbssc.desktop.biz.EnvironmentBiz;
import com.bcbssc.desktop.dao.inform.EmployeeLookupDAO;
import com.bcbssc.desktop.support.LoggingDiagnosticActionExecutor;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.jdbc.BaseJDBCDAO;
import com.bcbssc.desktop.util.jdbc.executor.JdbcServiceExecutorTemplate;
import com.bcbssc.desktop.util.jdbc.interceptor.JdbcDataAccessExceptionInterceptor;
import com.bcbssc.domain.entity.Employee;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;
import com.bcbssc.domain.entity.inform.InformSecurity;

/**
 * Employee Lookup Access Object. This class is use to perform queries for the 'Employee' entity
 */
@Stateless
@Remote
@Interceptors({JdbcDataAccessExceptionInterceptor.class})
public class SqlEmployeeLookupDAOImpl extends BaseJDBCDAO implements EmployeeLookupDAO {

    @EJB
    private EnvironmentBiz environmentBiz;

    /**
     * Blank constructor
     *
     */
    public SqlEmployeeLookupDAOImpl() {
    }

    /**
     * Creates a JDBC executor template for the correct environment.
     */
    private JdbcServiceExecutorTemplate getExecutorTemplate(Subject subject) {
        final DataSource dataSource = environmentBiz.get(EnvironmentObjects.JDBC_DEFAULT_DATASOURCE, DataSource.class, subject);
        final JdbcServiceExecutorTemplate executorTemplate = new JdbcServiceExecutorTemplate(dataSource);
        final LoggingDiagnosticActionExecutor executor = new LoggingDiagnosticActionExecutor();
        executor.setActionName("JDBCEmployeeLookup");
        executor.setThreshold(3000L);
        executorTemplate.setActionExecutor(executor);
        return executorTemplate;
    }

    @Override
    public List<Employee> retrieveEmployeesByName(String name, Subject subject) {
        final String schema = SubjectUtils.getClient(subject).getInformQualifier();
        final EmployeeLookupQuery employeeLookupQuery = new EmployeeLookupQuery();
        employeeLookupQuery.setJdbcTemplate(getExecutorTemplate(subject));
        return employeeLookupQuery.retrieveEmployeesByName(schema, name);
    }

    @Override
    public List<Employee> retrieveEmployeesById(String id, Subject subject) {
        final String schema = SubjectUtils.getClient(subject).getInformQualifier();
        final EmployeeLookupQuery employeeLookupQuery = new EmployeeLookupQuery();
        employeeLookupQuery.setJdbcTemplate(getExecutorTemplate(subject));
        return employeeLookupQuery.retrieveEmployeesById(schema, id);
    }

    @Override
    public InformSecurity retrieveInformSecurityByRacf(String racf, Subject subject) {
        final String schema = SubjectUtils.getClient(subject).getInformQualifier();
        final InformSecurityQuery informSecurityQuery = new InformSecurityQuery();
        informSecurityQuery.setJdbcTemplate(getExecutorTemplate(subject));
        return informSecurityQuery.getInformSecurityByEmployeeRacf(schema, racf);
    }

    @Override
    public InformSecurity retrieveInformSecurityById(String id, Subject subject) {
        final String schema = SubjectUtils.getClient(subject).getInformQualifier();
        final InformSecurityQuery informSecurityQuery = new InformSecurityQuery();
        informSecurityQuery.setJdbcTemplate(getExecutorTemplate(subject));
        return informSecurityQuery.getInformSecurityByEmployeeId(schema, id);
    }
}
