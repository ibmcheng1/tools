/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2009, 2013 BLUECROSS BLUESHIELD OF SOUTH CAROLINA.
 * ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.startup;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutorService;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.security.auth.Subject;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.biz.DesktopStartupBiz;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.dao.DataRetrievalHandler;
import com.bcbssc.desktop.util.dao.executor.WorkExecutor;
import com.bcbssc.desktop.util.dao.executor.WorkTask;
import com.bcbssc.desktop.util.menu.MenuUtils;
import com.bcbssc.domain.entity.ApplicationClient;
import com.bcbssc.domain.entity.InformIdentification;
import com.bcbssc.domain.entity.InformSearchCriteria;
import com.bcbssc.domain.entity.codes.Code;
import com.bcbssc.domain.entity.inform.InformSecurity;
import com.bcbssc.domain.valueobject.MenuConfiguration;
import com.bcbssc.domain.valueobject.MenuLink;
import com.bcbssc.domain.valueobject.claims.CodeRange;

/**
 * This retrieves all of the stuff needed at startup for the application
 */
@Stateless
@Remote
public class DesktopStartupBizBDImpl implements DesktopStartupBiz {

    private static final String DEFAULT_RULES_DATATYPE = "BASELINK";

    private static final Log logger = LogFactory.getLog(DesktopStartupBizBDImpl.class);

    // DAOS
    @EJB
    private InformCodesDAO informCodesDAO;
    @EJB
    private InformSecurityDAO informSecurityDAO;
    @EJB
    private RpnSecurityDAO rpnSecurityDAO;
    @EJB
    private RulesDAO rulesDAO;
    @EJB
    private RulesDataTypeDAO rulesDataTypeDAO;

    @Resource(name = "rules.datatype")
    private String rulesDatatype;

    @Resource(lookup="concurrent/executor")
    ExecutorService executor;

    // Defaults
    private static final String DEFAULT_COMPANY = "3";
    private static final String DEFAULT_DEPARTMENT = "916";
    private static final String DEFAULT_DIVISION = "44";
    private static final String RULES_NAV_PREFIX = "NAV";

    /**
     * post construction - fetches WorkManager via JNDI lookup
     */
    @PostConstruct
    private void postConstruct() {
        //init block to set rulesDatatype if not injected
        if (rulesDatatype == null) {
            logger.error("There was an error attempting to inject the rules datatype, defaulting to " + DEFAULT_RULES_DATATYPE);
            rulesDatatype = DEFAULT_RULES_DATATYPE;
        }
    }

    /**
     * Retrieve User Security Profile and Picklist Codes
     * @see com.bcbssc.desktop.biz.DesktopStartupBiz#getUserData(javax.security.auth.Subject, javax.security.auth.Subject)
     */
    @Override
    public InformIdentification getUserData(Subject applicationUser, Subject staticSubject) throws Exception {
        // Setup Search Criteria Bean
        final InformSearchCriteria searchCriteria = new InformSearchCriteria();
        searchCriteria.setSubject(applicationUser);
        final ApplicationClient client = SubjectUtils.getClient(applicationUser);
        searchCriteria.setSystemPrefix(client.getInformTrans());

        if (logger.isDebugEnabled()) {
            logger.debug("Attempting to get the inform defaults using inform program " + client.getInformTrans() + " and application ID " + client.getAppId());
        }

        final InformSecurity defaults = getDefaultInformSecurity(client.getInformTrans(), client.getAppId());
        searchCriteria.setDefaultCompanyCode(defaults.getCompanyCode());
        searchCriteria.setDefaultDivisionCode(defaults.getDivisionCode());
        searchCriteria.setDefaultDepartmentCode(defaults.getDepartmentCode());

        if (logger.isDebugEnabled()) {
            logger.debug("SearchCriteria=" + searchCriteria);
        }

        //Our RULEs information is not yet available as the inform security information is a required input
        //for the RULEs lookup itself.  Let's just use the default unit-of-work configuration (always run primary)
        final MenuLink defaultConfiguration = DataRetrievalHandler.getDefaultConfiguration();

        InformIdentification userData = null;
        if (DataRetrievalHandler.runDataRetrieval(defaultConfiguration)) {
            // Get the user data
            try {
                //use the static subject for these calls
                userData = retrieveUserData(searchCriteria, staticSubject);
            } catch (final Exception exception) {
                DataRetrievalHandler.handleDataRetrievalException(defaultConfiguration, exception);
            }
        }

        return userData;
    }

    /**
     * Fetch picklists for the subject(s) and inform identification data.
     */
    @Override
    public HashMap<String,List<? extends Code>> fetchPicklists(Subject applicationUser, Subject staticSubject, InformIdentification userData) throws Exception {
        HashMap<String, List<? extends Code>> picklists = null;

        // Setup Search Criteria Bean
        final InformSearchCriteria searchCriteria = new InformSearchCriteria();
        searchCriteria.setSubject(applicationUser);
        final ApplicationClient client = SubjectUtils.getClient(applicationUser);
        searchCriteria.setSystemPrefix(client.getInformTrans());

        final InformSecurity defaults = getDefaultInformSecurity(client.getInformTrans(), client.getAppId());
        searchCriteria.setDefaultCompanyCode(defaults.getCompanyCode());
        searchCriteria.setDefaultDivisionCode(defaults.getDivisionCode());
        searchCriteria.setDefaultDepartmentCode(defaults.getDepartmentCode());

        final InformSecurity security = userData.getInformSecurity();
        // Set user data returned in search criteria bean
        if (security != null) {
            searchCriteria.setCompanyCode(StringUtils.trimToEmpty(security.getCompanyCode()));
            searchCriteria.setDepartmentCode(StringUtils.trimToEmpty(security.getDepartmentCode()));
            searchCriteria.setDivisionCode(StringUtils.trimToEmpty(security.getDivisionCode()));
        } else {
            if (logger.isDebugEnabled()) {
                logger.debug("No security values received for RACF.");
            }
            throw new Exception("Your RACF was not found in the INFOrm security table.");
        }

        // Set indicator for picklists
        searchCriteria.setTableIndicatorRequested(InformSearchCriteria.PICKLIST_TABLE_INDICATOR);

        //Our RULEs information is not yet available as the inform security information is a required input
        //for the RULEs lookup itself.  Let's just use the default unit-of-work configuration (always run primary)
        final MenuLink defaultConfiguration = DataRetrievalHandler.getDefaultConfiguration();

        if (DataRetrievalHandler.runDataRetrieval(defaultConfiguration)) {
            // If we've got the proper data, attempt to get the picklists.
            if (StringUtils.isNotEmpty(security.getCompanyCode()) && StringUtils.isNotEmpty(security.getDivisionCode())
                            && StringUtils.isNotEmpty(security.getDepartmentCode()) && StringUtils.isNotEmpty(security.getEmployeeId())) {
                try {
                    //use the static subject for these calls
                    picklists = getPicklists(searchCriteria, staticSubject);
                } catch (final Exception exception) {
                    DataRetrievalHandler.handleDataRetrievalException(defaultConfiguration, exception);
                }
            } else {
                if (logger.isDebugEnabled()) {
                    logger.debug("Could not run picklist lookup.  Data was missing from inform user lookup.");
                }
                throw new Exception("Retreiving data from Client Table failed.");
            }
        }
        return picklists;
    }

    @Override
    public HashMap<String, ?> getPicklists(InformSearchCriteria criteria, ApplicationClient client, String applicationId, Subject subject) throws Exception {
        // check the client
        if ((null != client) && (null != applicationId)) {
            final InformSecurity defaults = getDefaultInformSecurity(client.getInformTrans(), applicationId);
            criteria.setDefaultCompanyCode(defaults.getCompanyCode());
            criteria.setDefaultDivisionCode(defaults.getDivisionCode());
            criteria.setDefaultDepartmentCode(defaults.getDepartmentCode());
            criteria.setSystemPrefix(client.getInformTrans());
        }

        // Set indicator for picklists
        criteria.setTableIndicatorRequested(InformSearchCriteria.PICKLIST_TABLE_INDICATOR);
        return getPicklists(criteria, subject);
    }

    private InformSecurity getDefaultInformSecurity(String informProgram, String applicationId) throws IOException {
        final InformSecurity defaults = new InformSecurity();
        // get the properties file that contains the defaults
        final InputStream in = DesktopStartupBizBDImpl.class.getResourceAsStream("/com/bcbssc/desktop/startup/inform.properties");
        final Properties props = new Properties();
        props.load(in);

        String defaultCompanyCode = props.getProperty("default.company." + StringUtils.lowerCase(informProgram), DEFAULT_COMPANY);
        String defaultDivisionCode = props.getProperty("default.division." + StringUtils.lowerCase(informProgram), DEFAULT_DIVISION);
        String defaultDepartmentCode = props.getProperty("default.department." + StringUtils.lowerCase(informProgram), DEFAULT_DEPARTMENT);

        defaultCompanyCode = props.getProperty("default.company." + StringUtils.lowerCase(applicationId) + "." + StringUtils.lowerCase(informProgram),
                        defaultCompanyCode);
        defaultDivisionCode = props.getProperty("default.division." + StringUtils.lowerCase(applicationId) + "." + StringUtils.lowerCase(informProgram),
                        defaultDivisionCode);
        defaultDepartmentCode = props.getProperty("default.department." + StringUtils.lowerCase(applicationId) + "." + StringUtils.lowerCase(informProgram),
                        defaultDepartmentCode);

        defaults.setCompanyCode(defaultCompanyCode);
        defaults.setDivisionCode(defaultDivisionCode);
        defaults.setDepartmentCode(defaultDepartmentCode);

        return defaults;
    }

    /**
     * Fetching picklists from back end.
     * Protected instead of private for JUnit.
     */
    protected HashMap<String, List<? extends Code>> getPicklists(final InformSearchCriteria searchCriteria, final Subject subject) throws Exception {

        final HashMap<String, List<? extends Code>> userDataResults = SubjectUtils.runAsSubject(() -> {

            final HashMap<String, List<? extends Code>> employeeInformationResults = new HashMap<>();
            final List<WorkTask<Void>> workTasks = new ArrayList<>(7);

            workTasks.add(new WorkTask<Void>(null, subject, () -> {
                employeeInformationResults.put(
                                DesktopStartupBiz.USER_DATA_KEY_PICKLIST_STATUS,
                                informCodesDAO.getStatusCodes(searchCriteria.copy()));
                return null;
            }));

            workTasks.add(new WorkTask<Void>(null, subject, () -> {
                employeeInformationResults.put(
                                DesktopStartupBiz.USER_DATA_KEY_PICKLIST_CATEGORY,
                                informCodesDAO.getCategoryCodes(searchCriteria.copy()));
                return null;
            }));

            workTasks.add(new WorkTask<Void>(null, subject, () -> {
                employeeInformationResults.put(
                                DesktopStartupBiz.USER_DATA_KEY_PICKLIST_REQUEST_REASON,
                                informCodesDAO.getRequestReasonCodes(searchCriteria.copy()));
                return null;
            }));

            workTasks.add(new WorkTask<Void>(null, subject, () -> {
                employeeInformationResults.put(
                                DesktopStartupBiz.USER_DATA_KEY_PICKLIST_CONTACT_TYPE,
                                informCodesDAO.getContactTypeCodes(searchCriteria.copy()));
                return null;
            }));

            workTasks.add(new WorkTask<Void>(null, subject, () -> {
                employeeInformationResults.put(
                                DesktopStartupBiz.USER_DATA_KEY_PICKLIST_RESOLUTION,
                                informCodesDAO.getResolutionCodes(searchCriteria.copy()));
                return null;
            }));

            workTasks.add(new WorkTask<Void>(null, subject, () -> {
                employeeInformationResults.put(
                                DesktopStartupBiz.USER_DATA_KEY_PICKLIST_SEVERITY,
                                informCodesDAO.getSeverityCodes(searchCriteria.copy()));
                return null;
            }));

            workTasks.add(new WorkTask<Void>(null, subject, () -> {
                employeeInformationResults.put(
                                DesktopStartupBiz.USER_DATA_KEY_PICKLIST_TRANSFER,
                                informCodesDAO.getTransferCodes(searchCriteria.copy()));
                return null;
            }));

            //create a work executor, execute work tasks
            final WorkExecutor<Void> workExecutor = new WorkExecutor<>(executor, workTasks);
            workExecutor.executeWorkTasks();

            return employeeInformationResults;

        }, subject);

        return userDataResults;
    }

    /**
     * Retrieves the ICD-10 Compliance Date by RULESDataTypeInquiry web service
     * @param subject Current user Context
     * @return ICD-10 Compliance Date
     * @throws Exception
     */
    @Override
    public Date getIcdComplianceDate(Subject subject) throws Exception {
        return SubjectUtils.runAsSubject((() -> rulesDataTypeDAO.getIcdComplianceDate()), subject);
    }
    /**
     * Retrieves list of code categories for ICD-10
     * @param subject Current user context
     * @return icdCategories a List of CodeRange beans
     * @throws Exception
     *
     */
    @Override
    public List<CodeRange> getIcdCategories(Subject subject) throws Exception {
        return SubjectUtils.runAsSubject((() -> rulesDataTypeDAO.getIcdCategories()), subject);
    }

    @Override
    public HashMap<String, ?> getRulesEntries(Subject subject) throws Exception {
        // Get Subject and Client
        final ApplicationClient client = SubjectUtils.getClient(subject);

        final String applicationId = client.getAppId();
        final InformSecurity defaults = getDefaultInformSecurity(client.getInformTrans(), applicationId);

        // Setup menu configuration criteria
        final MenuConfiguration config = new MenuConfiguration();
        config.setAltRpn(client.getAliasRpn());
        config.setPlanCode(client.getPlanCode());
        config.setApplicationId(applicationId);
        config.setClientId(client.getClientId());
        config.setCompanyCode(SubjectUtils.getInformId(subject).getCompany());
        config.setDivisionCode(SubjectUtils.getInformId(subject).getDivision());
        config.setDepartmentCode(SubjectUtils.getInformId(subject).getDepartment());
        config.setDefaultCompanyCode(defaults.getCompanyCode());
        config.setDefaultDivisionCode(defaults.getDivisionCode());
        config.setDefaultDepartmentCode(defaults.getDepartmentCode());
        config.setRoleCode(client.getRoleCode()); // This will need to be default if empty in the jdbc queries
        config.setDataType(rulesDatatype);
        config.setDefaultRegion(SubjectUtils.getRegion(subject));

        return getRulesEntries(config, null, subject);
    }

    @Override
    public HashMap<String, ?> getRulesEntries(MenuConfiguration config, ApplicationClient client, Subject subject) throws Exception {
        // check the client
        if (null != client) {
            final InformSecurity defaults = getDefaultInformSecurity(client.getInformTrans(), config.getApplicationId());
            config.setDefaultCompanyCode(defaults.getCompanyCode());
            config.setDefaultDivisionCode(defaults.getDivisionCode());
            config.setDefaultDepartmentCode(defaults.getDepartmentCode());
        }
        // Get all of the menu links in one go
        final List<MenuLink> menuLinks = getMenuLinks(config, subject);
        return getRuleEntries(menuLinks);
    }

    /**
     * Converts the list of menu links into a map of menu links
     * @param menuLinks
     * @return
     */
    private HashMap<String, ?> getRuleEntries(List<MenuLink> menuLinks) {

        // Create containers for menu links
        final List<MenuLink> funcNavLinks = new ArrayList<>();
        final List<MenuLink> navMenu = new ArrayList<>();
        final List<MenuLink> summaryLinks = new ArrayList<>();
        final List<MenuLink> userConfigs = new ArrayList<>();
        final List<MenuLink> termSessions = new ArrayList<>();
        final List<MenuLink> quickLinks = new ArrayList<>();
        final List<MenuLink> mobLinks = new ArrayList<>();
        final List<MenuLink> manLinks = new ArrayList<>();
        final List<MenuLink> manCategories = new ArrayList<>();
        final List<MenuLink> itsReports = new ArrayList<>();
        final List<MenuLink> grpVerbiages = new ArrayList<>();
        final List<MenuLink> controlLinks = new ArrayList<>();

        //Iterate through list of menuLinks and store in proper arrays
        for (final MenuLink menuLink : menuLinks) {

            if (StringUtils.equals(menuLink.getFunctionType(), DesktopStartupBiz.RULES_DATA_KEY_FUNC_NAV_LINKS)) {
                funcNavLinks.add(menuLink);
            } else if ((menuLink.getFunctionType() != null) && (menuLink.getFunctionType().startsWith(RULES_NAV_PREFIX))) {
                navMenu.add(menuLink);
            } else if (StringUtils.equals(menuLink.getFunctionType(), DesktopStartupBiz.RULES_DATA_KEY_SUMMARY_LINKS)) {
                summaryLinks.add(menuLink);
            } else if (StringUtils.equals(menuLink.getFunctionType(), DesktopStartupBiz.RULES_DATA_KEY_USER_CONFIGS)) {
                userConfigs.add(menuLink);
            } else if (StringUtils.equals(menuLink.getFunctionType(), DesktopStartupBiz.RULES_DATA_KEY_TERM_SESSIONS)) {
                termSessions.add(menuLink);
            } else if (StringUtils.equals(menuLink.getFunctionType(), DesktopStartupBiz.RULES_DATA_KEY_QUICK_LINKS)) {
                quickLinks.add(menuLink);
            } else if (StringUtils.equals(menuLink.getFunctionType(), DesktopStartupBiz.RULES_DATA_KEY_MOBIUS_LINKS)) {
                mobLinks.add(menuLink);
            } else if (StringUtils.equals(menuLink.getFunctionType(), DesktopStartupBiz.RULES_DATA_KEY_MANUAL_LINKS)) {
                manLinks.add(menuLink);
            } else if (StringUtils.equals(menuLink.getFunctionType(), DesktopStartupBiz.RULES_DATA_KEY_MANUAL_CATEGORIES)) {
                manCategories.add(menuLink);
            } else if (StringUtils.equals(menuLink.getFunctionType(), DesktopStartupBiz.RULES_DATA_KEY_ITS_REPORTS)) {
                itsReports.add(menuLink);
            } else if (StringUtils.equals(menuLink.getFunctionType(), DesktopStartupBiz.RULES_DATA_KEY_GRPVERB_RECORDS)) {
                grpVerbiages.add(menuLink);
            } else if (StringUtils.equals(menuLink.getFunctionType(), DesktopStartupBiz.RULES_DATA_KEY_CONTROL_LINK)) {
                controlLinks.add(menuLink);
            }
        }

        //Let's do any special collection creation for our different RULEs types
        Collection<MenuLink> navigationTree = MenuUtils.createTree(navMenu);

        //Currently we have the entire navigation menu stored in the navigation tree (categories and links)
        //We need to split this into 2 collections now, one for categories, and one for links.  The categories
        //need to remain in the same tree format, but the links need to be stored in a map keyed by the full
        //id (functionId-subfunctionId) of the category they belong to.  For the sake of not over-complicating this section
        //of code, let's hand off these tasks to other methods.
        final Map navLinks = createNavLinksMap((List) navigationTree, "root", new HashMap());
        navigationTree = removeLinks((List) navigationTree);

        //We need to store the summary links, user config and group verbiage entries by task key so they can be looked up by the key identifier
        final Map<String, MenuLink> summaryLinksMap = MenuUtils.createMap(summaryLinks);
        final Map<String, MenuLink> userConfigMap = MenuUtils.createMap(userConfigs);
        final Map<String, MenuLink> grpVerbiagesMap = MenuUtils.createMap(grpVerbiages);

        //For our control panel and function navigation links, let's make sure they are sorted in the right order.
        //There is a compareTo(...) method defined on MenuLink to handle the sorting logic
        Collections.sort(controlLinks);
        Collections.sort(funcNavLinks);

        // Generate hash map and store menu link lists in map
        final HashMap<String, Object> rulesEntries = new HashMap<>();
        rulesEntries.put(DesktopStartupBiz.RULES_DATA_KEY_FUNC_NAV_LINKS, funcNavLinks);
        rulesEntries.put(DesktopStartupBiz.RULES_DATA_KEY_NAV_CATEGORY, navigationTree);
        rulesEntries.put(DesktopStartupBiz.RULES_DATA_KEY_NAV_LINKS, navLinks);
        rulesEntries.put(DesktopStartupBiz.RULES_DATA_KEY_SUMMARY_LINKS, summaryLinksMap);
        rulesEntries.put(DesktopStartupBiz.RULES_DATA_KEY_USER_CONFIGS, userConfigMap);
        rulesEntries.put(DesktopStartupBiz.RULES_DATA_KEY_TERM_SESSIONS, termSessions);
        rulesEntries.put(DesktopStartupBiz.RULES_DATA_KEY_QUICK_LINKS, quickLinks);
        rulesEntries.put(DesktopStartupBiz.RULES_DATA_KEY_MOBIUS_LINKS, mobLinks);
        rulesEntries.put(DesktopStartupBiz.RULES_DATA_KEY_MANUAL_LINKS, manLinks);
        rulesEntries.put(DesktopStartupBiz.RULES_DATA_KEY_MANUAL_CATEGORIES, manCategories);
        rulesEntries.put(DesktopStartupBiz.RULES_DATA_KEY_ITS_REPORTS, itsReports);
        rulesEntries.put(DesktopStartupBiz.RULES_DATA_KEY_GRPVERB_RECORDS, grpVerbiagesMap);
        rulesEntries.put(DesktopStartupBiz.RULES_DATA_KEY_CONTROL_LINK, controlLinks);
        return rulesEntries;
    }

    private Map createNavLinksMap(List<MenuLink> links, String categoryId, Map linksMap) {
        for (final MenuLink link : links) {
            if (StringUtils.equals(RULES_DATA_KEY_NAV_CATEGORY, link.getFunctionType())) {
                final String linkCategoryId = link.getFunctionId() + "-" + link.getSubfunctionId();
                createNavLinksMap(link.getChildLinks(), linkCategoryId, linksMap);
            } else {
                List linkList = (List) linksMap.get(categoryId);
                if (linkList == null) {
                    linkList = new ArrayList();
                    linksMap.put(categoryId, linkList);
                }
                linkList.add(link);
            }
        }

        return linksMap;
    }

    private List<MenuLink> removeLinks(List<MenuLink> links) {

        for (int i = 0; i < links.size(); i++) {
            final MenuLink link = links.get(i);
            if (StringUtils.equals(RULES_DATA_KEY_NAV_CATEGORY, link.getFunctionType())) {
                final List<MenuLink> childLinks = removeLinks(link.getChildLinks());
                link.setChildLinks(childLinks);
            } else {
                links.remove(i);
                i--;
            }
        }
        return links;
    }

    private List<MenuLink> getMenuLinks(final MenuConfiguration config, Subject subject) throws Exception {
        List<MenuLink> menuLinks = null;
        /*
         * Since we don't have a configuration for the RULEs lookup (chicken-or-egg situation), use the
         * default data retrieval configuration (always run primary).
         */
        final MenuLink defaultConfig = DataRetrievalHandler.getDefaultConfiguration();
        if (DataRetrievalHandler.runDataRetrieval(defaultConfig)) {
            try {
                menuLinks = SubjectUtils.runAsSubject((() -> rulesDAO.getMenuLinks(config)), subject);
            } catch (final Exception exception) {
                DataRetrievalHandler.handleDataRetrievalException(defaultConfig, exception);
            }
        }
        return menuLinks;
    }

    /**
     * Find out if the user is allowed to use the client they selected.
     * @see com.bcbssc.desktop.biz.DesktopStartupBiz#validateClientSelection(javax.security.auth.Subject)
     */
    @Override
    public Boolean validateClientSelection(Subject subject) throws Exception {
        boolean isValid = false;

        if (SubjectUtils.getIsDebugMode(subject)) {
            return true;
        }

        /*
         * Since we don't have a MenuLink for the RPNS service (we haven't retrieved the MenuLinks yet, that will be done next), use the
         * default data retrieval configuration (always run primary).
         */
        final MenuLink defaultConfig = DataRetrievalHandler.getDefaultConfiguration();
        if (DataRetrievalHandler.runDataRetrieval(defaultConfig)) {
            try {
                isValid = SubjectUtils.runAsSubject((() -> {
                    if (rpnSecurityDAO == null) {
                        if (logger.isDebugEnabled()) {
                            logger.debug("The DAO was not initialized, using the services implementation");
                        }
                        rpnSecurityDAO = new ServicesRpnSecurityDAOImpl();
                    }
                    return rpnSecurityDAO.isSecureForRpn();
                }), subject);
            } catch (final Exception exception) {
                DataRetrievalHandler.handleDataRetrievalException(defaultConfig, exception);
            }
        }
        return isValid;
    }

    private InformIdentification retrieveUserData(final InformSearchCriteria criteria, Subject subject) throws Exception {
        return SubjectUtils.runAsSubject((() -> informSecurityDAO.getInformIdentification(criteria)), subject);
    }

    /**
     * JUnit injection, chainable.
     */
    protected DesktopStartupBizBDImpl setInformCodesDAO(InformCodesDAO informCodesDAO) {
        this.informCodesDAO = informCodesDAO;
        return this;
    }
}
