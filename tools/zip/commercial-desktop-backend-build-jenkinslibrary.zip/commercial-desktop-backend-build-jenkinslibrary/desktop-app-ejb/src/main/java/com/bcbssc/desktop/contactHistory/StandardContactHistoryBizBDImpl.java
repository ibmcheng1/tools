/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2017 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.contactHistory;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.ContactHistoryBiz;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.dao.DataRetrievalHandler;
import com.bcbssc.desktop.util.dao.executor.WorkExecutor;
import com.bcbssc.desktop.util.dao.executor.WorkTask;
import com.bcbssc.domain.entity.Group;
import com.bcbssc.domain.entity.InformSearchCriteria;
import com.bcbssc.domain.entity.Subscriber;
import com.bcbssc.domain.entity.alerts.RepeatCallerAlert;
import com.bcbssc.domain.entity.codes.inform.InternalExternalIndicatorCode;
import com.bcbssc.domain.entity.codes.inform.StatusCode;
import com.bcbssc.domain.entity.cti.CallCenterAttribute;
import com.bcbssc.domain.entity.inform.InformRecord;
import com.bcbssc.domain.valueobject.MenuLink;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.security.auth.Subject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * CSR, MBR, MCS, AVL webservice implementation of ContactHistoryBiz
 * 
 * @author X87M (original: HX20)
 *
 */
@Stateless( name = "contactHistoryBizBD" )
@Remote
public class StandardContactHistoryBizBDImpl implements ContactHistoryBiz {

    private static final Log log = LogFactory.getLog(StandardContactHistoryBizBDImpl.class);

    /**
     * The RULEs category that contains all the user configuration records.
     */
    private static final String USERCONFIG = "USERCONFIG";

    /**
     * The key for the "special sauce" service configuration.
     */
    private static final String RETRIEVE_CONTACT_HISTORY_INFO = "RETRIEVE_CONTACT_HISTORY_INFO";

    private static final String OPEN_STATUS = "OP";

    //How many days to search for each INFOrm query type
    private static final int OPEN_INFORM_DAYS = 365;
    private static final int OTHER_INFORM_DAYS = 90;

    //MIM/Web's Ask customer service "cust name" in Inform
    private static final String ASK_CUSTOMER_SERVICE_CUSTOMER_NAME = "WEBMIM:ASKCUSTOMERSERVICE";

    //Custom identifier for desktop informs that should be included in the repeat caller count
    private static final String MEMBER_CALL_IDENTIFIER = "MEM";

    private static final String INTERNAL_IDENTIFIER = "I";

    @Resource(lookup="concurrent/executor")
    ExecutorService executor;

    /**
     * Subscriber and Group contact history records are stored on the INFOrm tables.
     */
    @EJB
    private InformDAO informDAO;

    // Implements the method from the ContactHistoryBiz interface.
    @Override
    public List<InformRecord> getContactHistoryRecords(final Subscriber subscriber, final Subject subject) throws Exception {
        return getContactHistoryRecords(subscriber, SubjectUtils.getInformIdStrict(subject).getCompany(), null, subject);
    }

    // Implements the method from the ContactHistoryBiz interface.
    @Override
    public List<InformRecord> getContactHistoryRecords(final Subscriber subscriber, final String companyCode, final String employeeId, Subject subject)
            throws Exception {
        return getContactHistoryRecords(subscriber.getDatabaseNumber(), companyCode, employeeId, subject);
    }

    // Implements the method from the ContactHistoryBiz interface.
    @Override
    public List<InformRecord> getContactHistoryRecords(Group group, Subject subject) throws Exception {
        return getContactHistoryRecords(group.getGroupNumberAmms(), SubjectUtils.getInformIdStrict(subject).getCompany(), null, subject);
    }

    /**
     * Retrieves contact history in a type agnostic way.
     *
     * @param keyId
     *      This can be a subscriber's database number or group number or any other ID.
     * @param companyCode
     *      Required field to filter to a company set of data.
     *      Use <code>ContextSubjectUtils.getCurrentInformId().getCompany()</code>
     * @param employeeId
     *      Optional field to filter to data for/from a specific employee, if not needed pass in <code>null</code>.
     * @param subject
     *      The subject to run the transaction as.
     * @return
     *      If the user is not configured to run the service then <code>null</code>.
     * @throws Exception If there are any issues with processing the request.
     */
    @Override
    public List<InformRecord> getContactHistoryRecords(final String keyId, final String companyCode, final String employeeId, Subject subject) throws Exception {

        if (StringUtils.isBlank(keyId)) {
            throw new IllegalArgumentException("Key ID is required.");
        }

        if (StringUtils.isBlank(companyCode)) {
            throw new IllegalArgumentException("Company code is required.");
        }

        List<InformRecord> results = null;
        MenuLink ruleService = getContactHistoryConfig(subject);

        // Check if we should run the service.
        if (DataRetrievalHandler.runDataRetrieval(ruleService)) {
            try {
                results = new ArrayList<>();

                InformSearchCriteria openInformSearchCriteria = createInformSearchCriteria(false, keyId, companyCode, null, null, employeeId, OPEN_INFORM_DAYS, OPEN_STATUS);
                InformSearchCriteria otherInformSearchCriteria = createInformSearchCriteria(false, keyId, companyCode, null, null, employeeId, OTHER_INFORM_DAYS, null);
                List<String> otherInformExcludeList = new ArrayList<>();
                otherInformExcludeList.add(OPEN_STATUS);

                if (log.isDebugEnabled()) {
                    log.debug("Executing work tasks for contact history...");
                }

                List<WorkTask> workTasks = new ArrayList<>();
                workTasks.add(retrieveInformRecordsWorkTask(openInformSearchCriteria, results, null, subject));
                workTasks.add(retrieveInformRecordsWorkTask(otherInformSearchCriteria, results, otherInformExcludeList, subject));

                if (log.isDebugEnabled()) {
                    log.debug("Executing work tasks for contact history...");
                }

                //Create a work executor, execute work tasks
                WorkExecutor workExecutor = new WorkExecutor(executor, workTasks);
                workExecutor.executeWorkTasks();

            } catch (Exception exception) {
                // Determine if we fail (primary service) or just log and ignore (secondary service).
                DataRetrievalHandler.handleDataRetrievalException(ruleService, exception);
            }
        }

        return results;
    }

    /* @see com.bcbssc.desktop.biz.ContactHistoryBiz#getRepeatCallerAlert(java.lang.String, com.bcbssc.domain.entity.cti.CallCenterAttribute, javax.security.auth.Subject) */
    @Override
    public RepeatCallerAlert getRepeatCallerAlert(String keyId, String companyCode, String employeeId, CallCenterAttribute callCenterAttribute, Subject subject) throws Exception {
        RepeatCallerAlert repeatCallerAlert = new RepeatCallerAlert();

        //Only perform a repeat caller lookup if the key id is supplied
        if(StringUtils.isNotBlank(keyId)) {
            List<String> divisionCodes = callCenterAttribute.getDivisionTypeForRepeatCaller();
            List<String> departmentCodes = callCenterAttribute.getDepartmentTypeForRepeatCaller();
            int numberOfCallsForRepeatCaller = callCenterAttribute.getNumberOfCallsForRepeatCaller();
            int numberOfDaysForRepeatCaller = callCenterAttribute.getNumberOfDaysForRepeatCaller();
            List<String> sources = callCenterAttribute.getSourceTypesForRepeatCaller();

            final InformSearchCriteria repeatCallerInformSearchCriteria = createInformSearchCriteria(false, keyId, companyCode, null, null, employeeId, numberOfDaysForRepeatCaller, null);

            //Call the service
            List<InformRecord> informRecords = SubjectUtils.runAsSubject(() -> informDAO.getInformRecords(repeatCallerInformSearchCriteria), subject);

            int callCount = 0;
            for(InformRecord informRecord : informRecords) {
                if(StringUtils.equals(informRecord.getCorrespondenceName(), ASK_CUSTOMER_SERVICE_CUSTOMER_NAME)) {
                    //Always include ACS (Ask Customer Service) INFOrm records
                    callCount++;
                } else if(sources == null || sources.isEmpty() || sources.contains(informRecord.getSourceCode())) {
                    //Exclude internal source records
                    boolean internalSource = false;
                    InternalExternalIndicatorCode internalExternalIndicatorCode = informRecord.getInternalExternalInd();
                    if(null != internalExternalIndicatorCode) {
                        String code = internalExternalIndicatorCode.getCode();
                        if(INTERNAL_IDENTIFIER.equals(code)) {
                            internalSource = true;
                        }
                    }

                    if(!internalSource) {
                        //Only include records that are identified as member calls, all if not set
                        if(StringUtils.equals(informRecord.getCustomerClassCode(), MEMBER_CALL_IDENTIFIER) ||
                                StringUtils.isBlank(informRecord.getCustomerClassCode())) {
                            //Only include records that match the configured department and division codes, all if not set
                            if(divisionCodes == null || divisionCodes.isEmpty() || divisionCodes.contains(informRecord.getRequestorDivisionCode())) {
                                if(departmentCodes == null || departmentCodes.isEmpty() || departmentCodes.contains(informRecord.getRequestorDepartmentCode())) {
                                    callCount++;
                                }
                            }
                        }
                    }
                }
            }

            if(log.isDebugEnabled()) {
                log.debug("Caller "+keyId+" has called "+callCount+" times over "+numberOfDaysForRepeatCaller+" days");
            }

            //Is this a repeat caller?
            if(callCount >= numberOfCallsForRepeatCaller) {
                if(log.isDebugEnabled()) {
                    log.debug("Caller "+keyId+" is a repeat caller");
                }
                repeatCallerAlert.setRepeatCaller(true);
                repeatCallerAlert.setNumberOfTimesCalled(callCount);
                repeatCallerAlert.setNumberOfDays(numberOfDaysForRepeatCaller);
            }
        } else {
            if (log.isDebugEnabled()) {
                log.debug("There was no subscriber id in the call data.  Not retrieving the repeat caller alert.");
            }
        }

        return repeatCallerAlert;
    }

    /**
     * Gets the special sauce RULEs entry for the contact history service configuration.
     *
     * @param subject
     *      Used to fetch the RULEs entries.
     * @return
     *      The RULEs entry object or <code>null</code> if there are no user configuration entries.
     */
    private static MenuLink getContactHistoryConfig(Subject subject) throws Exception {
        MenuLink rule = null;
        Map rulesEntries = DesktopAPI.getRulesEntries(subject);
        Map<String, MenuLink> userConfigs = (Map<String, MenuLink>) rulesEntries.get(USERCONFIG);
        if (null != userConfigs) {
            rule = userConfigs.get(RETRIEVE_CONTACT_HISTORY_INFO);
        }
        return rule;
    }

    /**
     * Fetch a Work instance to run the informDAO web service to retrieve inform records
     *
     * @param searchCriteria
     * @param totalInformRecords
     * @param excludeList
     * @param subject
     * @return
     */
    private WorkTask<?> retrieveInformRecordsWorkTask(final InformSearchCriteria searchCriteria, final List<InformRecord> totalInformRecords,
                                                      final List<String> excludeList, final Subject subject) {
        return new WorkTask<List<InformRecord>>(null, subject, () -> SubjectUtils.runAsSubject(() -> informDAO.getInformRecords(searchCriteria), subject))
        {
            @Override
            public void onComplete() {
                List<InformRecord> informRecords = this.getResults();
                if (informRecords != null && informRecords.size() > 0) {
                    if(excludeList == null || excludeList.isEmpty()) {
                        totalInformRecords.addAll(informRecords);
                    } else {
                        //Only include the records we care about
                        if(log.isDebugEnabled()) {
                            log.debug("Only returning records that do NOT have "+excludeList.toString()+" status types.");
                        }
                        for(InformRecord informRecord : informRecords) {
                            StatusCode statusCode = informRecord.getStatusCode();
                            if(statusCode != null && !excludeList.contains(statusCode.getType())) {
                                totalInformRecords.add(informRecord);
                            }
                        }
                    }
                }
            }
        };
    }

    /**
     * Creates an inform criteria object based on the status filter type
     *
     * @param enablePaging
     * @param keyId
     * @param companyCode
     * @param divisionCode
     * @param departmentCode
     * @param employeeId
     * @param numberOfDaysToSearch
     * @param status
     * @return
     */
    private InformSearchCriteria createInformSearchCriteria(boolean enablePaging, String keyId, String companyCode, String divisionCode, String departmentCode, String employeeId,
            int numberOfDaysToSearch, String status) {
        InformSearchCriteria searchCriteria = new InformSearchCriteria();
        searchCriteria.setEnabledPaging(enablePaging);
        searchCriteria.setKeyId(keyId);
        searchCriteria.setCompanyCode(companyCode);
        searchCriteria.setDepartmentCode(departmentCode);
        searchCriteria.setDivisionCode(divisionCode);
        searchCriteria.setEmployeeId(employeeId);
        searchCriteria.setStatus(status);

        Date beginDate;
        Date endDate = new Date(); //Current date
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(endDate);
        calendar.add(Calendar.DATE, -1 * numberOfDaysToSearch);
        beginDate = calendar.getTime();

        searchCriteria.setBeginDate(beginDate);
        searchCriteria.setEndDate(endDate);

        return searchCriteria;
    }
}