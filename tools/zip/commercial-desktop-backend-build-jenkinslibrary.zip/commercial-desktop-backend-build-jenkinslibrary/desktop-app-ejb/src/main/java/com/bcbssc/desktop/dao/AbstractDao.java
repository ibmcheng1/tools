package com.bcbssc.desktop.dao;

public abstract class AbstractDao <BackEndDataSourceType, DESKTOP_INPUT, BackEndInputType, BackEndOutputType, DESKTOP_OUTPUT> {
	/** The DB2 table name, MQ queue name or service name. */
	public abstract String getBackEndSourceName();

	/** Defaults to empty string.  The service operation name.  For other sources it makes less sense. */
	public String getBackEndOperationName() {
		return "";
	}

	protected abstract BackEndDataSourceType getBackEndDataSource() throws Exception;

	/**
	 * Makes a call to retrieve the data from the back end (typically a web service) but no mapping.
	 *
	 * @param desktopInput
	 * 		Useful for cases where the DAO has to perform some paging.
	 */
	protected abstract BackEndOutputType invoke(DESKTOP_INPUT desktopInput, BackEndInputType backEndInput, BackEndDataSourceType dataSource) throws Exception;

	protected abstract BackEndInputType mapInput(DESKTOP_INPUT desktopInput) throws Exception;

	/**
	 * @param desktopInput
	 * 		Useful for cases where the DAO has to filtering or sorting.
	 */
	protected abstract DESKTOP_OUTPUT mapOutput(DESKTOP_INPUT desktopInput, BackEndOutputType backEndOutput) throws Exception;

	/**
	 * Makes a call to retrieve the data from the back end (typically a web service).
	 */
	public DESKTOP_OUTPUT call(DESKTOP_INPUT desktopInput) throws Exception {
		BackEndDataSourceType dataSource = this.getBackEndDataSource();
		BackEndInputType input = this.mapInput(desktopInput);
		BackEndOutputType output = null;
		try {
			output = this.invoke(desktopInput, input, dataSource);
		} catch (Exception ex) {
			this.handleInvokeError(ex);
		}
		if (null == output) {
			return null;
		}
		return this.mapOutput(desktopInput, output);
	}

	protected void handleInvokeError(Exception t) throws Exception {
		throw t;
	}
}