
package com.bcbssc.services.programsummaryinfo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProgramSummaryInfoProgramSummaryInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProgramSummaryInfoProgramSummaryInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="medicalManagementtArea" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="programName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="effectiveDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="historyInd" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="programStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="statusDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="eligibilityInd" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="moreEligibilityInd" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="enrolledIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="moreEnrollmentIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="timeStamp" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="groupNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="vendorName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="reviewerName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="vendorUrl" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProgramSummaryInfoProgramSummaryInfo", propOrder = {
    "medicalManagementtArea",
    "programName",
    "effectiveDate",
    "historyInd",
    "programStatus",
    "statusDate",
    "eligibilityInd",
    "moreEligibilityInd",
    "enrolledIndicator",
    "moreEnrollmentIndicator",
    "timeStamp",
    "groupNumber",
    "vendorName",
    "reviewerName",
    "vendorUrl"
})
public class ProgramSummaryInfoProgramSummaryInfo {

    @XmlElement(required = true, nillable = true)
    protected String medicalManagementtArea;
    @XmlElement(required = true, nillable = true)
    protected String programName;
    @XmlElement(required = true, nillable = true)
    protected String effectiveDate;
    @XmlElement(required = true, nillable = true)
    protected String historyInd;
    @XmlElement(required = true, nillable = true)
    protected String programStatus;
    @XmlElement(required = true, nillable = true)
    protected String statusDate;
    @XmlElement(required = true, nillable = true)
    protected String eligibilityInd;
    @XmlElement(required = true, nillable = true)
    protected String moreEligibilityInd;
    @XmlElement(required = true, nillable = true)
    protected String enrolledIndicator;
    @XmlElement(required = true, nillable = true)
    protected String moreEnrollmentIndicator;
    @XmlElement(required = true, nillable = true)
    protected String timeStamp;
    @XmlElement(required = true, nillable = true)
    protected String groupNumber;
    @XmlElement(required = true, nillable = true)
    protected String vendorName;
    @XmlElement(required = true, nillable = true)
    protected String reviewerName;
    @XmlElement(required = true, nillable = true)
    protected String vendorUrl;

    /**
     * Gets the value of the medicalManagementtArea property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicalManagementtArea() {
        return medicalManagementtArea;
    }

    /**
     * Sets the value of the medicalManagementtArea property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicalManagementtArea(String value) {
        this.medicalManagementtArea = value;
    }

    /**
     * Gets the value of the programName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProgramName() {
        return programName;
    }

    /**
     * Sets the value of the programName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProgramName(String value) {
        this.programName = value;
    }

    /**
     * Gets the value of the effectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Sets the value of the effectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEffectiveDate(String value) {
        this.effectiveDate = value;
    }

    /**
     * Gets the value of the historyInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHistoryInd() {
        return historyInd;
    }

    /**
     * Sets the value of the historyInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHistoryInd(String value) {
        this.historyInd = value;
    }

    /**
     * Gets the value of the programStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProgramStatus() {
        return programStatus;
    }

    /**
     * Sets the value of the programStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProgramStatus(String value) {
        this.programStatus = value;
    }

    /**
     * Gets the value of the statusDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusDate() {
        return statusDate;
    }

    /**
     * Sets the value of the statusDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusDate(String value) {
        this.statusDate = value;
    }

    /**
     * Gets the value of the eligibilityInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEligibilityInd() {
        return eligibilityInd;
    }

    /**
     * Sets the value of the eligibilityInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEligibilityInd(String value) {
        this.eligibilityInd = value;
    }

    /**
     * Gets the value of the moreEligibilityInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMoreEligibilityInd() {
        return moreEligibilityInd;
    }

    /**
     * Sets the value of the moreEligibilityInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMoreEligibilityInd(String value) {
        this.moreEligibilityInd = value;
    }

    /**
     * Gets the value of the enrolledIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnrolledIndicator() {
        return enrolledIndicator;
    }

    /**
     * Sets the value of the enrolledIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnrolledIndicator(String value) {
        this.enrolledIndicator = value;
    }

    /**
     * Gets the value of the moreEnrollmentIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMoreEnrollmentIndicator() {
        return moreEnrollmentIndicator;
    }

    /**
     * Sets the value of the moreEnrollmentIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMoreEnrollmentIndicator(String value) {
        this.moreEnrollmentIndicator = value;
    }

    /**
     * Gets the value of the timeStamp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTimeStamp() {
        return timeStamp;
    }

    /**
     * Sets the value of the timeStamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTimeStamp(String value) {
        this.timeStamp = value;
    }

    /**
     * Gets the value of the groupNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupNumber() {
        return groupNumber;
    }

    /**
     * Sets the value of the groupNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupNumber(String value) {
        this.groupNumber = value;
    }

    /**
     * Gets the value of the vendorName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVendorName() {
        return vendorName;
    }

    /**
     * Sets the value of the vendorName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVendorName(String value) {
        this.vendorName = value;
    }

    /**
     * Gets the value of the reviewerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReviewerName() {
        return reviewerName;
    }

    /**
     * Sets the value of the reviewerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReviewerName(String value) {
        this.reviewerName = value;
    }

    /**
     * Gets the value of the vendorUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVendorUrl() {
        return vendorUrl;
    }

    /**
     * Sets the value of the vendorUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVendorUrl(String value) {
        this.vendorUrl = value;
    }

}
