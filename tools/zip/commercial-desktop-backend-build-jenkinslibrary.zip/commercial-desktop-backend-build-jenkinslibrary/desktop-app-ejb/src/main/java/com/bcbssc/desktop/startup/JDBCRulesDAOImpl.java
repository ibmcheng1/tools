/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2008 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.startup;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.security.auth.Subject;
import javax.sql.DataSource;

import com.bcbssc.desktop.support.LoggingDiagnosticActionExecutor;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.jdbc.BaseJDBCDAO;
import com.bcbssc.desktop.util.jdbc.executor.JdbcServiceExecutorTemplate;
import com.bcbssc.desktop.util.jdbc.interceptor.JdbcDataAccessExceptionInterceptor;
import com.bcbssc.desktop.util.jndi.JndiUtils;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;
import com.bcbssc.domain.valueobject.MenuConfiguration;
import com.bcbssc.domain.valueobject.MenuLink;

/**
 * This DAO is responsible for controlling the queries that access the RULES database for links that are set up via the function and linktask tables.
 */
@Stateless
@Local
@Interceptors({JdbcDataAccessExceptionInterceptor.class})
public class JDBCRulesDAOImpl extends BaseJDBCDAO implements RulesDAO {

    public JDBCRulesDAOImpl() {
    }

    /**
     * Looksup jndi and set up templates
     * @param subject
     */

    private MenuLinksQuery createMenuLinksQuery(Subject subject) {
        final DataSource dataSource = JndiUtils.lookupObject(DataSource.class, EnvironmentObjects.JDBC_RULES_DATASOURCE.getName());

        final JdbcServiceExecutorTemplate executorTemplate = new JdbcServiceExecutorTemplate(dataSource);
        final MenuLinksQuery menuLinksQuery = new NavigationMenuLinksQuery();
        final LoggingDiagnosticActionExecutor executor = new LoggingDiagnosticActionExecutor();
        executor.setActionName("JDBCRules");
        executor.setThreshold(3000L);
        executorTemplate.setActionExecutor(executor);

        menuLinksQuery.setJdbcTemplate(executorTemplate);
        return menuLinksQuery;

    }

    @Override
    public List<MenuLink> getMenuLinks(MenuConfiguration config) throws Exception {
        // Call createLinksQuery every method call to initialize template with right values for the current subject
        final Subject subject = SubjectUtils.getCurrentSubject();
        final MenuLinksQuery menuLinksQuery = createMenuLinksQuery(subject);
        return menuLinksQuery.findLinks(this.getPrimarySchema(subject), config);
    }

    /**
     * This method overloads the getPrimarySchema() method to pass right schema based on the environment on the current subject
     * @param subject
     * @return String
     */
    private String getPrimarySchema(Subject subject) {
        return JndiUtils.lookupObject(String.class, EnvironmentObjects.DBCONN_QUALIFIER_RULE.getName());
    }
}
