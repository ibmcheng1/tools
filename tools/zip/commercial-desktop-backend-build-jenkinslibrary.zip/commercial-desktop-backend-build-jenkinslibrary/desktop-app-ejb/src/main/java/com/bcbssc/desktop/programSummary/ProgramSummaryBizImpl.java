/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.programSummary;

import java.security.PrivilegedExceptionAction;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.security.auth.Subject;

import com.bcbssc.desktop.biz.ProgramSummaryBiz;
import com.bcbssc.desktop.dao.ProgramSummaryDAO;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.managed.ProgramSummary;
import com.bcbssc.domain.entity.managed.ProgramSummarySearchCriteria;

/**
 * This is the business implementation of the ProgramSummary interface 
 *
 * 
 * @author $Author$  (original: X99H)
 * @version $Revision$
 */
@Stateless
@Remote
public class ProgramSummaryBizImpl implements ProgramSummaryBiz {

    @EJB
    private ProgramSummaryDAO programSummaryDAO;

    public ProgramSummary findBySubscriber(ProgramSummary programSummary, final ProgramSummarySearchCriteria criteria, Subject subject) throws Exception {
        return SubjectUtils.runAsSubject(new PrivilegedExceptionAction<ProgramSummary>() {
        	public ProgramSummary run() throws Exception {
        		return programSummaryDAO.findBySubscriber(criteria);
        	}
        }, subject);
    }
}
