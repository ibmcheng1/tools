/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2006 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.startup;

import com.bcbssc.domain.entity.InformIdentification;
import com.bcbssc.domain.entity.InformSearchCriteria;

/**
 * An RpnSecurityDAO checks to see if the user has access to the chosen RPN and sets the user's RPN to that
 * value if access is allowed.
 */
public interface InformSecurityDAO {
    
    /**
     * This method is not yet implemented in services.
     * 
     * @return InformIdentification bean
     */
    public InformIdentification getInformIdentification();
    
    /**
     * This method will return user security profile data
     *
     * @param informSearchCriteria
     * @return InformIdenification bean
     * @throws Exception
     */
    public InformIdentification getInformIdentification(InformSearchCriteria informSearchCriteria) throws Exception;    
}
