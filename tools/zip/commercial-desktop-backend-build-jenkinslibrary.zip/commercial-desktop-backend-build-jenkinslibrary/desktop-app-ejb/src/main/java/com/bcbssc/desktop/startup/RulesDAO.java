/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2008 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.startup;

import java.util.List;

import com.bcbssc.domain.valueobject.MenuConfiguration;
import com.bcbssc.domain.valueobject.MenuLink;

/**
 * This interface declares methods for controlling the queries that access the RULES database for links that are
 * set up via the function and linktask tables.
 */
public interface RulesDAO {
    
    public static final String APPLICATION_CSR = "CSR";
    public static final String APPLICATION_MBR = "MBR";
    public static final String FUNCTIONS_KEY = "functions";
    public static final String NOTES_KEY = "notes";

    /**
     * @param config
     * @return List of menu links
     * @throws Exception
     */
    public List<MenuLink> getMenuLinks(MenuConfiguration config) throws Exception;
}
