
package com.bcbssc.services.managedcarepatientlist;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.bcbssc.services.managedcarepatientlist package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _EbizException_QNAME = new QName("http://cmpgen.microfocus.com", "EbizException");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.bcbssc.services.managedcarepatientlist
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetManagedCarePatientList }
     * 
     */
    public GetManagedCarePatientList createGetManagedCarePatientList() {
        return new GetManagedCarePatientList();
    }

    /**
     * Create an instance of {@link ManagedCarePatientListInput }
     * 
     */
    public ManagedCarePatientListInput createManagedCarePatientListInput() {
        return new ManagedCarePatientListInput();
    }

    /**
     * Create an instance of {@link GetManagedCarePatientListResponse }
     * 
     */
    public GetManagedCarePatientListResponse createGetManagedCarePatientListResponse() {
        return new GetManagedCarePatientListResponse();
    }

    /**
     * Create an instance of {@link ManagedCarePatientListOutput }
     * 
     */
    public ManagedCarePatientListOutput createManagedCarePatientListOutput() {
        return new ManagedCarePatientListOutput();
    }

    /**
     * Create an instance of {@link ManagedCarePatientListPatientRecord }
     * 
     */
    public ManagedCarePatientListPatientRecord createManagedCarePatientListPatientRecord() {
        return new ManagedCarePatientListPatientRecord();
    }

    /**
     * Create an instance of {@link ArrayOfManagedCarePatientListPatientRecord }
     * 
     */
    public ArrayOfManagedCarePatientListPatientRecord createArrayOfManagedCarePatientListPatientRecord() {
        return new ArrayOfManagedCarePatientListPatientRecord();
    }

    /**
     * Create an instance of {@link EbizException }
     * 
     */
    public EbizException createEbizException() {
        return new EbizException();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EbizException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://cmpgen.microfocus.com", name = "EbizException")
    public JAXBElement<EbizException> createEbizException(EbizException value) {
        return new JAXBElement<EbizException>(_EbizException_QNAME, EbizException.class, null, value);
    }

}
