/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.desktop.startup;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.jws.HandlerChain;
import javax.security.auth.Subject;
import javax.xml.ws.WebServiceRef;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.services.BaseServiceIntegrator;
import com.bcbssc.desktop.util.services.interceptor.ServicesDataAccessExceptionInterceptor;
import com.bcbssc.domain.entity.InformIdentification;
import com.bcbssc.domain.entity.InformSearchCriteria;
import com.bcbssc.domain.entity.auth.RacfIdPrincipal;
import com.bcbssc.domain.entity.inform.InformSecurity;
import com.bcbssc.domain.entity.inform.PicklistSecurity;
import com.bcbssc.domain.entity.inform.TransferProfileEntry;
import com.bcbssc.services.informemployeeprofile.InformEmployeeProfileInput;
import com.bcbssc.services.informemployeeprofile.InformEmployeeProfileOutput;
import com.bcbssc.services.informemployeeprofile.InformEmployeeProfileProfileInformation;
import com.bcbssc.services.informemployeeprofile.InformEmployeeProfileService;
import com.bcbssc.services.informemployeeprofile.InformEmployeeProfileServiceService;

/**
 * DAO implementation of InformEmployeeProfile service.
 *
 */
@Stateless
@Local
@Interceptors({ServicesDataAccessExceptionInterceptor.class})
public class ServicesInformSecurityDAOImpl
extends BaseServiceIntegrator<InformEmployeeProfileService, InformSearchCriteria, InformEmployeeProfileInput, InformEmployeeProfileOutput, InformIdentification>
implements InformSecurityDAO {

    private static final Log log = LogFactory.getLog(ServicesInformSecurityDAOImpl.class);

    @HandlerChain(file = "../dao/services/handlerchain/soax-service-handler-chain.xml")
    @WebServiceRef(wsdlLocation = "META-INF/wsdl/InformEmployeeProfile.wsdl", value=InformEmployeeProfileServiceService.class)
    private InformEmployeeProfileService service;

    /* @see com.bcbssc.desktop.biz.InformSecurityDAO#getInformIdentification(com.bcbssc.domain.entity.InformSearchCriteria) */
    @Override
    public InformIdentification getInformIdentification(InformSearchCriteria informSearchCriteria) throws Exception{

        if (informSearchCriteria==null){
            throw new IllegalArgumentException("An InformSearchCriteria is required.");
        }

        if(log.isDebugEnabled()){
            log.debug("Retrieving Inform Employee Profile Data with Employee ID: "+ StringUtils.trimToEmpty( informSearchCriteria.getEmployeeId()));
        }

        return this.consumeService(informSearchCriteria);
    }

    /* @see com.bcbssc.desktop.dao.InformSecurityDAO#getInformIdentification() */
    @Override
    public InformIdentification getInformIdentification() {
        throw new UnsupportedOperationException("This has not been implemented yet.");
    }

    @Override
    public InformEmployeeProfileService getService() {
        return service;
    }

    @Override
    public InformEmployeeProfileOutput invokeService(InformEmployeeProfileInput input, InformEmployeeProfileService service) throws Exception {
        return service.getInformEmployeeProfile(input);
    }

    @Override
    public InformEmployeeProfileInput mapInput(InformSearchCriteria informSearchCriteria) {
        final InformEmployeeProfileInput input = new InformEmployeeProfileInput();

        final Subject subject = SubjectUtils.getCurrentSubject();

        if (informSearchCriteria.getSubject() == null) {
            input.setRacfId(StringUtils.trimToEmpty(informSearchCriteria.getEmployeeId()));
            input.setSystemPrefix(StringUtils.trimToEmpty(informSearchCriteria.getSystemPrefix()));
            input.setMWIConfig(StringUtils.trimToEmpty(informSearchCriteria.getMwiConfig()));
        } else {
            input.setRacfId(StringUtils.trimToEmpty(SubjectUtils.getFirstPrincipalName(informSearchCriteria.getSubject(), RacfIdPrincipal.class)));
            input.setSystemPrefix(StringUtils.trimToEmpty(SubjectUtils.getClient(informSearchCriteria.getSubject()).getInformTrans()));
            input.setMWIConfig(StringUtils.trimToEmpty(SubjectUtils.getRegion(subject)));
        }

        input.setDefaultCompanyCode(StringUtils.trimToEmpty(informSearchCriteria.getDefaultCompanyCode()));
        input.setDefaultDepartmentCode(StringUtils.trimToEmpty(informSearchCriteria.getDefaultDepartmentCode()));
        input.setDefaultDivisionCode(StringUtils.trimToEmpty(informSearchCriteria.getDefaultDivisionCode()));
        input.setHostID(StringUtils.trimToEmpty(SubjectUtils.getRacfId(subject)));
        input.setHostPassword(StringUtils.trimToEmpty(SubjectUtils.getRACFPassword(subject)));
        input.setRoleIndicator(StringUtils.trimToEmpty(informSearchCriteria.getRoleIndicator()));

        final List<String> roles = informSearchCriteria.getRoles();

        input.setRole1("");
        input.setRole2("");
        input.setRole3("");
        input.setRole4("");
        input.setRole5("");

        if (roles != null) {
            if (roles.size() >= 1)
                input.setRole1(roles.get(0));
            if (roles.size() >= 2)
                input.setRole2(roles.get(1));
            if (roles.size() >= 3)
                input.setRole3(roles.get(2));
            if (roles.size() >= 4)
                input.setRole4(roles.get(3));
            if (roles.size() >= 5)
                input.setRole5(roles.get(4));
        }


        input.setToEscapeChar(Boolean.FALSE);


        if (log.isDebugEnabled()) {
            // Build the inputs but don't use the hostPassword
            // Any variable containing the word pass is removed.
            final String passwordVariableName = "pass";
            final String loggerString = (new ReflectionToStringBuilder(input) {
                @Override
                protected boolean accept(Field f) {
                    return super.accept(f) && !StringUtils.contains(StringUtils.upperCase(f.getName()), StringUtils.upperCase(passwordVariableName));
                }
            }).toString();

            log.debug("The input for the InformSecurity  service is: " + loggerString);
        }

        return input;
    }

    @Override
    public InformIdentification mapOutput(InformEmployeeProfileOutput output) {
        final InformIdentification informIdentification = new InformIdentification();

        informIdentification.setCompany(StringUtils.trimToEmpty(output.getRacfCompanyCode()));
        informIdentification.setDepartment(StringUtils.trimToEmpty(output.getRacfDepartmentCode()));
        informIdentification.setDivision(StringUtils.trimToEmpty(output.getRacfDivisionCode()));
        informIdentification.setEmployeeId(StringUtils.trimToEmpty(output.getRacfEmployeeIdNumber()));
        informIdentification.setLastName(StringUtils.trimToEmpty(output.getRacfEmployeeName()));

        final InformSecurity informSecurity = new InformSecurity();
        informSecurity.setAdHocMessageAccess(output.getRacfUpdateAdHocInd());
        informSecurity.setCompanyCode(informIdentification.getCompany());
        informSecurity.setCorporationCode(output.getRacfCorporationCode());
        informSecurity.setDepartmentCode(informIdentification.getDepartment());
        informSecurity.setDivisionCode(informIdentification.getDivision());
        informSecurity.setEmployeeId(informIdentification.getEmployeeId());
        //Check this one
        informSecurity.setInquiryType(output.getRacfSecurityType());
        informSecurity.setLastName(informIdentification.getLastName());
        informIdentification.setInformSecurity(informSecurity);

        final PicklistSecurity picklistSecurity = new PicklistSecurity();
        picklistSecurity.setCategoryDefault(output.getCategoryScreenDefault());
        picklistSecurity.setCategorySecurity(associateValueWithBoolean(output.getRacfCategoryPicklistInd()));
        picklistSecurity.setRequestReasonDefault(output.getRequestReasonScreenDefault());
        picklistSecurity.setRequestReasonSecurity(associateValueWithBoolean(output.getRacfRequestTypePicklistInd()));
        picklistSecurity.setResolutionDefault(output.getResolutionScreenDefault());
        picklistSecurity.setResolutionSecurity(associateValueWithBoolean(output.getRacfResolutionCodesPicklistInd()));
        picklistSecurity.setSeverityDefault(output.getSeverityScreenDefault());
        picklistSecurity.setSeveritySecurity(associateValueWithBoolean(output.getRacfSeverityPicklistInd()));
        picklistSecurity.setSourceOfInquiryDefault(output.getSourceScreenDefault());
        picklistSecurity.setSourceOfInquirySecurity(associateValueWithBoolean(output.getRacfSourceTypePicklistInd()));
        picklistSecurity.setStatusDefault(output.getStatusScreenDefault());
        picklistSecurity.setStatusSecurity(associateValueWithBoolean(output.getRacfStatusPicklistInd()));
        picklistSecurity.setLocationSecurity(associateValueWithBoolean(output.getRacfLocationPicklistInd()));
        picklistSecurity.setExternalLocationSecurity(associateValueWithBoolean(output.getRacfExternalLocPicklistInd()));
        picklistSecurity.setRespondBySecurity(associateValueWithBoolean(output.getRacfRespondByPicklistInd()));
        picklistSecurity.setResponseCodesSecurity(associateValueWithBoolean(output.getRacfResponseCodesPicklistInd()));
        picklistSecurity.setSourceContactTypeSecurity(associateValueWithBoolean(output.getRacfSourceCodePicklistInd()));
        picklistSecurity.setSecuritySecurity(associateValueWithBoolean(output.getRacfSecurityPicklistInd()));
        informIdentification.setPicklistSecurity(picklistSecurity);

        //Transfer profile information is used for the transfer department picklist in CRM:
        final List<InformEmployeeProfileProfileInformation> profiles = output.getProfileInformation().getInformEmployeeProfileProfileInformation();
        final List<TransferProfileEntry> transferProfileList = new ArrayList<>();

        for (final InformEmployeeProfileProfileInformation profile: profiles) {
            if (StringUtils.isNotEmpty(profile.getWorkloadTitle())) {
                final TransferProfileEntry transferProfile = new TransferProfileEntry();
                transferProfile.setCompanyCode(StringUtils.trimToEmpty(profile.getWorkloadCompanyCode()));
                transferProfile.setDepartmentCode(StringUtils.trimToEmpty(profile.getWorkloadDepartmentCode()));
                transferProfile.setDivisionCode(StringUtils.trimToEmpty(profile.getWorkloadDivisionCode()));
                transferProfile.setRole(StringUtils.trimToEmpty(profile.getWorkloadRole()));
                transferProfile.setEmployeeID(StringUtils.trimToEmpty(profile.getWorkloadEmployeeIdNumber()));
                transferProfile.setTitle(StringUtils.trimToEmpty(profile.getWorkloadTitle()));
                transferProfileList.add(transferProfile);
            }
        }

        informIdentification.setTransferProfileList(transferProfileList);

        if (log.isDebugEnabled()) {
            log.debug("The output for the InformSecurityDAO service is: " + StringUtils.trimToNull(informIdentification.toString()));
        }

        return informIdentification;
    }

    @Override
    public void setService(InformEmployeeProfileService service) {
        this.service = service;
    }

    @Override
    protected String getServiceName() {
        return InformEmployeeProfileService.class.getSimpleName();
    }

    /**
     * Returns True if the value of the input is 'Y', otherwise returns False
     * @param s     A String
     * @return
     */
    private Boolean associateValueWithBoolean(String s){
        Boolean returnReference = Boolean.FALSE;
        if (s.equalsIgnoreCase("Y")){
            returnReference = Boolean.TRUE;
        }
        return returnReference;
    }
}
