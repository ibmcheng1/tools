/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2013 BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.startup;

import java.sql.Date;
import java.util.List;
import com.bcbssc.domain.valueobject.claims.CodeRange;

/**
 * Retrieves detailed records for specific Rules data types.
 */
public interface RulesDataTypeDAO {
    /**
     * Returns the ICD-10 compliance date.
     * @return ICD-10 compliance date.
     */
    public Date getIcdComplianceDate();
    /**
     * Returns a list of ICD-10 Categories
     * @return icdCategories a list of code categories
     */
    public List<CodeRange> getIcdCategories();
}
