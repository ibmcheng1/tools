/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.environment;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.naming.InitialContext;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.security.auth.Subject;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.dao.EnvironmentDAO;
import com.bcbssc.desktop.resourceprovider.Config;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;

/**
 * Looks up environment-level configuration settings in Resource Environment
 * Providers (REP).
 */
@Stateless(name = "ResourceProviderEnvironmentDAOImpl")
@Local
public class ResourceProviderEnvironmentDAOImpl implements EnvironmentDAO {
    private static final Log logger = LogFactory.getLog(ResourceProviderEnvironmentDAOImpl.class);

    protected static final String REP_JNDI_NAME_PREFIX = "rep/";
    protected static final String REP_JNDI_NAME_REGION_PREFIX = "rep/region/";
    protected static final String DEFAULT_ENVIRONMENT = "default";

    /** @see com.bcbssc.desktop.dao.EnvironmentDAO#getObject(EnvironmentObjects, Subject) */
    @Override
    public Object getObject(EnvironmentObjects environmentObject, Subject subject) {
        Object value = null;
        InitialContext initialContext = null;

        // Obtain environment from subject
        String environment = SubjectUtils.getEnvironment(subject);
        if (StringUtils.isBlank(environment)) {
            throw new IllegalStateException("Unable to obtain environment from subject");
        }

        try {
            // Lookup resource environment configuration
            initialContext = getInitialContext();
            final Config config = (Config) initialContext.lookup(REP_JNDI_NAME_PREFIX + environment);
            final String key = environmentObject.getBaseId();

            // Check for region-specific value
            if (environmentObject.isRegionSpecific()) {
                value = checkRegionSpecificValue(initialContext, config, environment, key, subject);
            }

            // Not region-specific
            if (value == null) {
                value = config.getAttribute(key);
            }
        } catch (NamingException ne) {
            throw new IllegalStateException("Unable to obtain resource provider for environment " + environment, ne);
        } finally {
            if (initialContext != null) {
                try {
                    initialContext.close();
                } catch (NamingException ex) {
                    logger.warn("Unable to close jndi context", ex);
                }
            }
        }

        return value;
    }

    /** @see com.bcbssc.desktop.dao.EnvironmentDAO#getCommonObject(EnvironmentObjects) */
    @Override
    public Object getCommonObject(EnvironmentObjects environmentObject) {
        final Subject subject = SubjectUtils.createEmptySubject();
        SubjectUtils.setEnvironment(subject, DEFAULT_ENVIRONMENT);
        return getObject(environmentObject, subject);
    }

    /**
     * Checks for a region-specific value. First, tries rep/{environment}/{region}.
     * If that is not found, tries rep/{region}. If that is not found, returns null.
     *
     * @return the region-specific value or null if none exists.
     */
    private Object checkRegionSpecificValue(InitialContext initialContext, Config environmentConfig, String environment, String key, Subject subject) {
        Object value = null;

        try {
            // Make sure multi-region is enabled
            final EnvironmentObjects multiRegion = EnvironmentObjects.MULTIREGION_ENABLED;
            final Boolean isMultiRegionEnabled = (Boolean) multiRegion.convert(environmentConfig.getAttribute(multiRegion.getBaseId()));

            if (isMultiRegionEnabled.booleanValue()) {
                // First, check rep/<environment>/<region>
                final String region = SubjectUtils.getRegion(subject).toLowerCase();
                String repKey = REP_JNDI_NAME_PREFIX + environment + "/" + region;
                value = checkResourceValue(initialContext, repKey, key);

                // Second, check rep/<region>
                if (value == null) {
                    repKey = REP_JNDI_NAME_REGION_PREFIX + region;
                    value = checkResourceValue(initialContext, repKey, key);
                }

                if (logger.isDebugEnabled()) {
                    logger.debug("region value=" + value);
                }
            }
        } catch (Exception ex) {
            logger.warn("Error checking region-specific value [" + key + "]; using non-region-specific value", ex);
        }

        return value;
    }

    /**
     * Checks for a resource value using the given JNDI name and property key.
     * @return the resource value or null if none exists.
     */
    private Object checkResourceValue(InitialContext initialContext, String repKey, String key) {
        Object value = null;

        if (logger.isDebugEnabled()) {
            logger.debug("Checking REP " + repKey + " for key " + key);
        }

        try {
            value = ((Config) initialContext.lookup(repKey)).getAttribute(key);
        } catch (NamingException ne) {
            // This is not an error
        }

        return value;
    }

    /** @see com.bcbssc.desktop.dao.EnvironmentDAO#isEnvironmentDefined(String) */
    @Override
    public boolean isEnvironmentDefined(String environment) {
        InitialContext initialContext = null;
        Config config = null;
        boolean result = false;
        try {
            initialContext = getInitialContext();
            //Lookup environment for validation
            config = (Config) initialContext.lookup(REP_JNDI_NAME_PREFIX + environment);
        } catch (NamingException ne) {
            logger.warn("Environment lookup failed. Environment not found : " + environment);
            result = false;
        } finally {
            if (initialContext != null) {
                try {
                    initialContext.close();
                } catch (NamingException ex) {
                    logger.warn("Unable to close jndi context", ex);
                }
            }
        }
        if (null != config) {
            result = true;
        } else {
            logger.warn("Environment lookup returned null. Environment not found : " + environment);
        }

        return result;
    }

    /** @see com.bcbssc.desktop.dao.EnvironmentDAO#getEnvironments() */
    @Override
    public List<String> getEnvironments() {
        List<String> environments = new ArrayList<String>();
        try {
            // Find all resource environment provider entries
            InitialContext context = getInitialContext();
            NamingEnumeration<NameClassPair> reps = context.list("rep");
            while (reps != null && reps.hasMore()) {
                NameClassPair rep = reps.next();
                // Exclude region entries; only environments remain
                if (rep.getName() != null && !rep.getName().equals("region")) {
                    environments.add(rep.getName());
                }
            }
        } catch (NamingException e) {
            logger.error("ERROR : Naming Exception trying to get environments list " + e);
            environments = null;
        }
        return environments;
    }

    /**
     * This is used for JUnit testing only
     * @return
     * @throws NamingException
     */
    protected InitialContext getInitialContext() throws NamingException {
        return new InitialContext();
    }
}