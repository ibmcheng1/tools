/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2014 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 *
 */
package com.bcbssc.desktop.familySummary;

import com.bcbssc.desktop.dao.PatientListDAO;
import com.bcbssc.desktop.util.services.CachingServiceIntegrator;
import com.bcbssc.desktop.util.services.interceptor.ServicesDataAccessExceptionInterceptor;
import com.bcbssc.domain.familySummary.FamilySummaryInputDesktop;
import com.bcbssc.domain.familySummary.FamilySummaryOutputDesktop;
import com.bcbssc.domain.familySummary.FamilySummaryRecord;
import com.bcbssc.services.familysummary.FamilySummaryFamilySummaryGrp;
import com.bcbssc.services.familysummary.FamilySummaryInput;
import com.bcbssc.services.familysummary.FamilySummaryOutput;
import com.bcbssc.services.familysummary.FamilySummaryService;
import com.bcbssc.services.familysummary.FamilySummaryServiceService;
import org.apache.commons.lang.StringUtils;

import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.jws.HandlerChain;
import javax.xml.ws.WebServiceRef;
import java.util.ArrayList;
import java.util.List;

/**
 * Web service based implementation of the PatientListDAO for retrieving family summaries.
 */
@Stateless
@Interceptors({ServicesDataAccessExceptionInterceptor.class})
public class ServicesFamilySummaryDAOImpl
extends CachingServiceIntegrator<FamilySummaryService, FamilySummaryInputDesktop, FamilySummaryInput, FamilySummaryOutput, FamilySummaryOutputDesktop>
implements PatientListDAO {

    @HandlerChain(file = "../dao/services/handlerchain/soax-service-handler-chain.xml")
    @WebServiceRef(wsdlLocation = "META-INF/wsdl/FamilySummary.wsdl", value = FamilySummaryServiceService.class)
    private FamilySummaryService service;

    public ServicesFamilySummaryDAOImpl() {
    }

    public ServicesFamilySummaryDAOImpl(FamilySummaryService service) {
        this.service = service;
    }

    @Override
    public FamilySummaryOutputDesktop retrieveFamilySummary(FamilySummaryInputDesktop desktopInput) {
        return this.consumeService(desktopInput);
    }

    @Override
    public String getBackEndOperationName() {
        return "getFamilySummary";
    }

    @Override
    public String getBackEndSourceName() {
        return "FamilySummary";
    }

    @Override
    public FamilySummaryService getService() {
        return service;
    }

    @Override
    public FamilySummaryInput mapInput(FamilySummaryInputDesktop desktopInput) {
        final FamilySummaryInput input = new FamilySummaryInput();
        input.setSubscriberId(desktopInput.getSubscriberId());
        input.setPlanCode(desktopInput.getPlanCode());
        return input;
    }

    @Override
    public FamilySummaryOutput invokeService(FamilySummaryInput input, FamilySummaryService service) throws Exception {
        return service.getFamilySummary(input);
    }

    @Override
    public FamilySummaryOutputDesktop mapOutput(FamilySummaryOutput backEndOutput) {
        final List<FamilySummaryRecord> data = new ArrayList<>();
        for (final FamilySummaryFamilySummaryGrp elem : backEndOutput.getFamilySummaryGrp().getFamilySummaryFamilySummaryGrp()) {
            if (StringUtils.isEmpty(elem.getPatientId())) {
                break;
            }

            final FamilySummaryRecord rec = new FamilySummaryRecord();
            rec.patientId = elem.getPatientId();
            rec.patientFirstName = elem.getPatientFirstName();
            rec.patientMiddleInitial = elem.getPatientMiddleInitial();
            rec.patientLastName = elem.getPatientLastName();
            rec.patientNameSuffix = elem.getPatientNameSuffix();
            rec.patientDateOfBirth = elem.getPatientDateOfBirth();
            rec.patientGenderAndRltnshpCode = elem.getPatientGenderAndRltnshpCode();
            rec.patientAlternateName1 = elem.getPatientAlternateName1();
            rec.patientAlternateName2 = elem.getPatientAlternateName2();
            rec.patientPrivacyIndicator = elem.getPatientPrivacyIndicator();
            rec.patientDefer1 = elem.getPatientDefer1();
            rec.patientDeferDesc1 = elem.getPatientDeferDesc1();
            rec.patientDefer2 = elem.getPatientDefer2();
            rec.patientDeferDesc2 = elem.getPatientDeferDesc2();
            rec.patientDefer3 = elem.getPatientDefer3();
            rec.patientDeferDesc3 = elem.getPatientDeferDesc3();
            rec.patientOverride1 = elem.getPatientOverride1();
            rec.patientOverride2 = elem.getPatientOverride2();
            rec.updateDate = elem.getUpdateDate();
            rec.updateTime = elem.getUpdateTime();
            rec.typeOfUpdate = elem.getTypeOfUpdate();
            rec.dependentIndicator = elem.getDependentIndicator();
            rec.updatebyEmployee = elem.getUpdatebyEmployee();
            rec.processedPurgeDate = elem.getProcessedPurgeDate();
            rec.purgePrivacyIndicator = elem.getPurgePrivacyIndicator();
            data.add(rec);
        }
        return new FamilySummaryOutputDesktop(data);
    }

    @Override
    public void setService(FamilySummaryService service) {
        this.service = service;
    }

    @Override
    protected String getServiceName() {
        return FamilySummaryService.class.getSimpleName();
    }
}

