/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.desktop.programSummary;

import java.util.List;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.dao.ProgramSummaryDAO;
import com.bcbssc.desktop.util.auth.ContextSubjectUtils;
import com.bcbssc.desktop.util.menu.MenuUtils;
import com.bcbssc.desktop.util.services.interceptor.ServicesDataAccessExceptionInterceptor;
import com.bcbssc.domain.entity.managed.ProgramDetail;
import com.bcbssc.domain.entity.managed.ProgramSummary;
import com.bcbssc.domain.entity.managed.ProgramSummarySearchCriteria;
import com.bcbssc.services.programsummaryinfo.ProgramSummaryInfoInput;
import com.bcbssc.services.programsummaryinfo.ProgramSummaryInfoOutput;
import com.bcbssc.services.programsummaryinfo.ProgramSummaryInfoProgramSummaryInfo;
import com.bcbssc.services.programsummaryinfo.ProgramSummaryInfoService;

/**
 * This implements {@link ProgramSummaryDAO} to retrieve the subscriber @ProgramSummary
 *
 */
@Stateless
@Remote
@Interceptors({ServicesDataAccessExceptionInterceptor.class})
public class ServicesProgramSummaryDAOImpl implements ProgramSummaryDAO {

    @SuppressWarnings("unused")
    private static final Log logger = LogFactory.getLog(ServicesProgramSummaryDAOImpl.class);

    @Override
    public ProgramSummary findBySubscriber(ProgramSummarySearchCriteria searchCriteria) {

        if (StringUtils.isBlank(searchCriteria.getSubscriberId())) {
            throw new IllegalArgumentException("Subscriber ID is required");
        }
        if (StringUtils.isBlank(searchCriteria.getPatientId())) {
            throw new IllegalArgumentException("Patient ID is required");
        }
        if (StringUtils.isBlank(searchCriteria.getManagementArea())) {
            searchCriteria.setManagementArea("SUM");
        }

        //        WebServiceConsumerTemplate consumerTemplate = new WebServiceConsumerTemplate();
        //        WebServiceConsumerCallback consumerCallback = getWebServiceConsumerCallback(searchCriteria);
        //        return (ProgramSummary) consumerTemplate.consumeService(searchCriteria, consumerCallback);
        throw new UnsupportedOperationException("This class needs to be redone to use the BaseServicesIntegrator");
    }

    protected ProgramSummaryInfoService getServiceProgramInfo() {
        //return (ProgramSummaryInfoService) new ServiceClientGenerator("ProgramSummaryInfo").getServiceClient();
        throw new UnsupportedOperationException("This class needs to be updated to extend the BaseServiceIntegrator");
    }

    /**
     * Returns the <code>WebServiceConsumerCallback</code> for this DAO.
     */
    protected ProgramSummaryServiceConsumer getWebServiceConsumerCallback(ProgramSummarySearchCriteria searchCriteria) {
        return new ProgramSummaryServiceConsumer(searchCriteria);
    }

    protected class ProgramSummaryServiceConsumer {

        private final ProgramSummarySearchCriteria searchCriteria;
        private final String startingPageNumber = "";
        private static final String TRUE = "Y";

        public ProgramSummaryServiceConsumer(ProgramSummarySearchCriteria searchCriteria) {
            this.searchCriteria = searchCriteria;
        }

        public Object getService() {
            return getServiceProgramInfo();
        }

        public Object invokeService(Object serviceInput, Object serviceClient) throws Exception {
            final ProgramSummaryInfoService service = (ProgramSummaryInfoService) serviceClient;
            final ProgramSummaryInfoOutput result = service.getProgramSummary((ProgramSummaryInfoInput) serviceInput);
            return result;
        }

        public Object mapInput(Object unused) {

            final ProgramSummaryInfoInput input = new ProgramSummaryInfoInput();
            if (null != searchCriteria.getEligibilityIndicator()) {
                if (Boolean.TRUE.equals(searchCriteria.getEligibilityIndicator())) {
                    input.setEligibilityIndicator("Y");
                } else {
                    input.setEligibilityIndicator("N");
                }
            }

            if (null != searchCriteria.getEnrollmentIndicator()) {
                if (Boolean.TRUE.equals(searchCriteria.getEnrollmentIndicator())) {
                    input.setEnrollmentIndicator("Y");
                } else {
                    input.setEnrollmentIndicator("N");
                }
            }

            if (null != searchCriteria.getHistoryIndicator()) {
                if (Boolean.TRUE.equals(searchCriteria.getHistoryIndicator())) {
                    input.setHistoryIndicator("Y");
                } else {
                    input.setHistoryIndicator("N");
                }
            }
            input.setRpn(ContextSubjectUtils.getCurrentClient().getAliasRpn());
            input.setPlanCode(ContextSubjectUtils.getCurrentPlanCode());
            input.setManagementArea(StringUtils.trimToEmpty(searchCriteria.getManagementArea()));
            input.setPatientId(StringUtils.trimToEmpty(searchCriteria.getPatientId()));
            input.setSponsorId(StringUtils.trimToEmpty(searchCriteria.getSubscriberId()));
            input.setStartPageNumber(StringUtils.trimToEmpty(startingPageNumber));

            return input;
        }

        public Object mapOutput(Object serviceOutput) {
            final ProgramSummaryInfoOutput output = (ProgramSummaryInfoOutput)serviceOutput;
            final ProgramSummary programSummary = new ProgramSummary();

            programSummary.setMentalHealth(output.getMentalHealthVendor());
            programSummary.setPatientName(StringUtils.trimToEmpty(output.getPatientName()));
            programSummary.setPharmacy(StringUtils.trimToEmpty(output.getPharmacyBenefitManagerVendor()));
            programSummary.setPharmacyEffDate(StringUtils.trimToEmpty(output.getPharmacyBenefitManagerDate()));
            programSummary.setMentalHealth(StringUtils.trimToEmpty(output.getMentalHealthVendor()));
            programSummary.setMentalHealthEffDate(StringUtils.trimToEmpty(output.getMentalHealthEffDate()));
            programSummary.addManagementStatus("CM", StringUtils.trimToEmpty(output.getCaseManagementInd()));
            programSummary.addManagementStatus("DM", StringUtils.trimToEmpty(output.getDiseaseManagementInd()));
            programSummary.addManagementStatus("MM", StringUtils.trimToEmpty(output.getMaternityManagementInd()));
            programSummary.addManagementStatus("WM", StringUtils.trimToEmpty(output.getWellnessManagementInd()));

            final List<ProgramSummaryInfoProgramSummaryInfo> arrayOfProgramSummaryInfo = output.getProgramSummaryInfo().getProgramSummaryInfoProgramSummaryInfo();
            for(final ProgramSummaryInfoProgramSummaryInfo programSumaryInfoProgramSummaryInfo: arrayOfProgramSummaryInfo){

                final ProgramDetail programDetail = new ProgramDetail();
                programDetail.setProgramName(programSumaryInfoProgramSummaryInfo.getProgramName());
                programDetail.setGroupNumber(programSumaryInfoProgramSummaryInfo.getGroupNumber());
                programDetail.setManagementName(StringUtils.trimToEmpty(programSumaryInfoProgramSummaryInfo.getMedicalManagementtArea()));
                programDetail.setProgramName(programSumaryInfoProgramSummaryInfo.getProgramName());
                programDetail.setEffectiveDate(StringUtils.trimToEmpty(programSumaryInfoProgramSummaryInfo.getEffectiveDate()));
                programDetail.setEligible(StringUtils.equalsIgnoreCase(TRUE, StringUtils.trimToEmpty(programSumaryInfoProgramSummaryInfo.getEligibilityInd())));
                programDetail.setEnrolled(StringUtils.equalsIgnoreCase(TRUE, StringUtils.trimToEmpty(programSumaryInfoProgramSummaryInfo.getEnrolledIndicator())));
                programDetail.setMoreEligible(StringUtils.equalsIgnoreCase(TRUE, StringUtils.trimToEmpty(programSumaryInfoProgramSummaryInfo.getMoreEligibilityInd())));
                programDetail.setMoreEnrolled(StringUtils.equalsIgnoreCase(TRUE, StringUtils.trimToEmpty(programSumaryInfoProgramSummaryInfo.getMoreEnrollmentIndicator())));
                programDetail.setProgramStatus(StringUtils.trimToEmpty(programSumaryInfoProgramSummaryInfo.getProgramStatus()));
                programDetail.setStatusDate(StringUtils.trimToEmpty(programSumaryInfoProgramSummaryInfo.getStatusDate()));
                programDetail.setGroupNumber(StringUtils.trimToEmpty(programSumaryInfoProgramSummaryInfo.getGroupNumber()));
                programDetail.setVendorName(StringUtils.trimToEmpty(programSumaryInfoProgramSummaryInfo.getVendorName()));
                programDetail.setUrl(MenuUtils.dropCase(StringUtils.trimToEmpty(programSumaryInfoProgramSummaryInfo.getVendorUrl())));
                programDetail.setReviewer(StringUtils.trimToEmpty(programSumaryInfoProgramSummaryInfo.getReviewerName()));
                programDetail.setHistoryID(StringUtils.trimToEmpty(programSumaryInfoProgramSummaryInfo.getHistoryInd()));
                programDetail.setTimestamp(StringUtils.trimToEmpty(programSumaryInfoProgramSummaryInfo.getTimeStamp()));

                programSummary.addProgram(programDetail);
            }

            return programSummary;
        }
    }
}
