/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 * DesktopAuthenticationBizBDImpl.java
 */
package com.bcbssc.desktop.authentication;

import java.security.InvalidParameterException;
import java.security.PrivilegedExceptionAction;

import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.security.auth.Subject;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.biz.authentication.DesktopAuthenticationBiz;
import com.bcbssc.desktop.dao.auth.NotAuthenticatedException;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.jndi.JndiUtils;
import com.bcbssc.domain.entity.UserAuthenticationCriteria;
import com.bcbssc.domain.entity.auth.UserCredentials;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;

@Stateless
@Remote
public class DesktopAuthenticationBizBDImpl implements DesktopAuthenticationBiz {

    private static Log log = LogFactory.getLog(DesktopAuthenticationBizBDImpl.class);

    @EJB
    private AuthenticationDAO dao;

    @Override
    public void login(UserCredentials userCredentials, Subject subject) throws NotAuthenticatedException, Exception {
        // In case this request has a new password set, clear it out.  Changing a password is
        // not supported by this method.
        userCredentials.setNewPassword(null);
        runAuthenticationAttempt(userCredentials, subject);
    }

    @Override
    public void changePassword(UserCredentials userCredentials, Subject subject) throws NotAuthenticatedException, Exception {
        // If a new password isn't present, throw an exception
        if(StringUtils.isBlank(userCredentials.getNewPassword())) {
            throw new InvalidParameterException("Missing a new password in the userCredentials object.");
        }
        runAuthenticationAttempt(userCredentials, subject);
    }

    protected void runAuthenticationAttempt(UserCredentials userCredentials, Subject subject) throws NotAuthenticatedException, Exception {
        final String racfExpression = getRacfExpression(subject);

        if (StringUtils.isBlank(racfExpression)) {
            log.error("The RACF expression cannot be found.  Unable to validate the RACF.  Attempting to login.");
        }

        final String userName = userCredentials.getUserName();
        if (StringUtils.isBlank(racfExpression) || (StringUtils.isNotBlank(userName) && userName.matches(racfExpression))) {
            final UserAuthenticationCriteria criteria = new UserAuthenticationCriteria();
            criteria.setUserName(userName);
            criteria.setPassword(userCredentials.getPassword());
            if(StringUtils.isNotBlank(userCredentials.getNewPassword())) {
                criteria.setNewPassword(userCredentials.getNewPassword());
                criteria.setVerifyNewPassword(userCredentials.getNewPassword());
            }
            SubjectUtils.runAsSubject(new PrivilegedExceptionAction<Object>() {
                @Override
                public Object run() throws NotAuthenticatedException, Exception {
                    dao.authenticateUser(criteria);
                    return null;
                }
            }, subject);
        } else {
            //Throwing a NotAuthenticatedException as this was probably a bad user id.
            throw new NotAuthenticatedException("Unable to login.  The following invalid RACF is non-alphanumeric and/or is not between one and eight characters long: \""+userName+"\"." +
                            "  The expression used to validate the RACF is: \""+racfExpression+"\".");
        }
    }

    /**
     * Get the expression used to validate RACFs before they go to the service
     *
     * @param subject
     * @return
     */
    private String getRacfExpression(Subject subject) {
        return JndiUtils.lookupObject(String.class, EnvironmentObjects.VALID_RACF_EXPRESSION.getName());
    }

}
