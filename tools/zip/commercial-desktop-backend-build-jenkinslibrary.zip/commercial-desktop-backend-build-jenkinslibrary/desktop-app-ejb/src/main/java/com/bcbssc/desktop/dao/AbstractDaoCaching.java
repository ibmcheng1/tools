package com.bcbssc.desktop.dao;

import javax.security.auth.Subject;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.cache.CacheDataStore;
import com.bcbssc.domain.cache.CacheKey;
import com.bcbssc.domain.cache.CacheableInput;
import com.bcbssc.domain.common.DomainObjectCloneable;

/** Should only be used for reading DAOs not creating, updating or deleting ones. */
public abstract class AbstractDaoCaching <BackEndDataSourceType, DESKTOP_INPUT extends CacheableInput, BackEndInputType, BackEndOutputType, DESKTOP_OUTPUT extends DomainObjectCloneable<?>>
extends AbstractDao <BackEndDataSourceType, DESKTOP_INPUT, BackEndInputType, BackEndOutputType, DESKTOP_OUTPUT> {

	/** By default we don't expire based on time. */
	public long getMaxTimeToLiveMilliseconds() {
		return 0;
	}

	/** By default we keep the cache entry around for 10 hits. */
	public int getMaxHitCount() throws Exception {
		return 10;
	}

	/**
	 * Gets cached data (if no data in cache then it will fetched and cached for future calls).
	 */
	@Override
	public DESKTOP_OUTPUT call(DESKTOP_INPUT desktopInput) throws Exception {
		DESKTOP_OUTPUT desktopOutput = null;
		Subject subject = SubjectUtils.getCurrentSubject();
		CacheDataStore cds = DesktopAPI.getCacheDataStore(subject);
		CacheKey key = new CacheKey(this.getBackEndSourceName(), this.getBackEndOperationName(), desktopInput);
		Object lock = cds.getLock(key);

		synchronized (lock) {
			// Check cache first.
			desktopOutput = (DESKTOP_OUTPUT) cds.get(key, desktopInput, this.getMaxTimeToLiveMilliseconds(), this.getMaxHitCount());
	
			// No data in cache?
			if (null == desktopOutput) {
				// Fetch it.
				desktopOutput = super.call(desktopInput);
				// Save it.
				cds.put(key, desktopOutput);
			}
		}

		return desktopOutput;
	}
}