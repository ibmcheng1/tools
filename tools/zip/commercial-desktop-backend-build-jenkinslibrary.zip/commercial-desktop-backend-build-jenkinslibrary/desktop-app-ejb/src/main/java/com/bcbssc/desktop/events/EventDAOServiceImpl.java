/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2016 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.events;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.jws.HandlerChain;
import javax.xml.ws.WebServiceRef;

import com.bcbssc.desktop.dao.events.EventServiceDAO;
import com.bcbssc.desktop.util.services.BaseServiceIntegrator;
import com.bcbssc.desktop.util.services.interceptor.ServicesDataAccessExceptionInterceptor;
import com.bcbssc.domain.entity.events.Event;
import com.bcbssc.domain.entity.events.ResponseDataDTO;
import com.bcbssc.services.evententry.EnterEventsResponseData;
import com.bcbssc.services.evententry.EventEntry;
import com.bcbssc.services.evententry.EventEntry_Service;
import com.bcbssc.services.evententry.RequestData;
import com.bcbssc.services.evententry.SearchableFields;

@Stateless
@Remote
@Interceptors({ServicesDataAccessExceptionInterceptor.class})
public class EventDAOServiceImpl extends BaseServiceIntegrator<EventEntry, List<Event>, List<RequestData>, List<EnterEventsResponseData>, ResponseDataDTO> implements EventServiceDAO {
    private static final String LAST_RECORD_INDICATOR = "E";

    @WebServiceRef(wsdlLocation = "META-INF/wsdl/EventEntry.wsdl", value=EventEntry_Service.class)
    @HandlerChain(file = "../util/services/handlersupport/chain/soax-service-handler-chain.xml")
    private EventEntry service;

    @Override
    public ResponseDataDTO sendEvent(Event event) throws Exception {
        final List<Event> events = new ArrayList<>();
        events.add(event);
        return this.consumeService(events);
    }

    @Override
    public ResponseDataDTO sendEvents(List<Event> events) throws Exception {
        return this.consumeService(events);
    }

    @Override
    public void setService(EventEntry service) {
        this.service = service;
    }

    @Override
    public EventEntry getService() {
        return service;
    }

    @Override
    protected String getServiceName() {
        return EventEntry.class.getSimpleName();
    }

    @Override
    public List<RequestData> mapInput(List<Event> modelInput) {
        final List<RequestData> serviceInput = new ArrayList<RequestData>(modelInput.size());

        for (final Event event : modelInput) {
            final RequestData item = new RequestData();

            item.setEventKey(event.getKey01());
            item.setActionRequest(event.getActionRequested());
            item.setSystemPrefix(event.getSystemPrefix());
            item.setRpn(event.getRpn());
            item.setPlanCode(event.getPlan());
            item.setEventCode(event.getCode());
            item.setCustomerArea(event.getCustomerArea());
            item.setOrigination(event.getOrigination());
            item.setOriginator(event.getOriginator());
            item.setEventDate(event.getDate());
            item.setEventTime(event.getTime());
            item.setEventIndicator(event.getIndicator());
            item.setSequenceNumber(new BigInteger(event.getUnpackSequenceNumber()));
            item.setElapsedTime(event.getElapsedTime());
            item.setLastRecordIndicator(LAST_RECORD_INDICATOR);

            final SearchableFields fields = new SearchableFields();
            fields.setDataType1(event.getTypeOf01());
            fields.setDataValue1(event.getData01());
            fields.setDataType2(event.getTypeOf02());
            fields.setDataValue2(event.getData02());
            fields.setDataType3(event.getTypeOf03());
            fields.setDataValue3(event.getData03());
            fields.setDataType4(event.getTypeOf04());
            fields.setDataValue4(event.getData04());
            fields.setDataType5(event.getTypeOf05());
            fields.setDataValue5(event.getData05());
            fields.setDataType6(event.getTypeOf06());
            fields.setDataValue6(event.getData06());
            fields.setDataType7(event.getTypeOf07());
            fields.setDataValue7(event.getData07());
            fields.setDataType8(event.getTypeOf08());
            fields.setDataValue8(event.getData08a());
            fields.setDataType9(event.getTypeOf09());
            fields.setDataValue9(event.getData09());
            fields.setDataType10(event.getTypeOf10());
            fields.setDataValue10(event.getData10());
            fields.setDataType11(event.getTypeOf11());
            fields.setDataValue11(event.getData11());
            fields.setDataType12(event.getTypeOf12());
            fields.setDataValue12(event.getData12());
            item.setSearchableFields(fields);

            serviceInput.add(item);
        }
        return serviceInput;
    }

    @Override
    public List<EnterEventsResponseData> invokeService(List<RequestData> input, EventEntry service) throws Exception {
        return service.enterEvents(input);
    }

    @Override
    public ResponseDataDTO mapOutput(List<EnterEventsResponseData> serviceOutput) {
        final ResponseDataDTO output = new ResponseDataDTO();
        output.ResponseData = serviceOutput;
        return output;
    }
}
