/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2016 BLUECROSS BLUESHIELD OF SOUTH CAROLINA.
 * ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.rules;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;

import org.apache.commons.lang.StringUtils;

import com.bcbssc.desktop.dao.rules.RulesScriptDAO;
import com.bcbssc.desktop.util.services.interceptor.ServicesDataAccessExceptionInterceptor;
import com.bcbssc.domain.entity.rules.RulesScriptRequest;
import com.bcbssc.domain.entity.rules.RulesScriptResponse;
import com.bcbssc.services.rulesinquiryexecutingscript.v1.ArgumentRow;
import com.bcbssc.services.rulesinquiryexecutingscript.v1.ArgumentRowChar;
import com.bcbssc.services.rulesinquiryexecutingscript.v1.ExecuteScriptResponse;
import com.bcbssc.services.rulesinquiryexecutingscript.v1.ResponseArgChar;
import com.bcbssc.services.rulesinquiryexecutingscript.v1.ResponseArgNum;
import com.bcbssc.services.rulesinquiryexecutingscript.v1.ResponseArgumentTableInfo;
import com.bcbssc.services.rulesinquiryexecutingscript.v1.RulesInquiryExecutingScript;

/**
 * Runs Rules scripts.
 */
@Stateless
@Remote
@Interceptors({ServicesDataAccessExceptionInterceptor.class})
public class ServicesRulesScriptDAOImpl implements RulesScriptDAO {
    protected static final String PACKAGE_SET_PREFIX = "P";
    protected static final String STRING_FIELD_TYPE = "X";
    protected static final String MAX_OUTPUT_FIELDS = "128";

    @Override
    public RulesScriptResponse executeRulesScript(RulesScriptRequest request) {
        if (request == null) {
            throw new IllegalArgumentException("Request must be supplied");
        }
        if ((request.getInputFields() == null) || (request.getInputFields().size() == 0)) {
            throw new IllegalArgumentException("Request must contain at least one input field");
        }

        //        final GenericWebServiceConsumerTemplate<RulesInquiryExecutingScript, RulesScriptRequest, Object, ExecuteScriptResponse, RulesScriptResponse>
        //            template = new GenericWebServiceConsumerTemplate<>();
        //        return template.consumeService(request, this.getWebServiceConsumerCallback());
        throw new UnsupportedOperationException("This class needs to be redone to use the BaseServicesIntegrator");
    }

    /**
     * Returns the web service consumer callback implementation for this DAO.
     */
    protected RulesScriptConsumerCallback getWebServiceConsumerCallback() {
        return new RulesScriptConsumerCallback();
    }

    /**
     * Implements the web service consumer callback interface.
     */
    protected class RulesScriptConsumerCallback {

        protected String rpn;
        protected String script;
        protected List<ArgumentRow> argumentRow;

        public RulesInquiryExecutingScript getService() {
            //            return (RulesInquiryExecutingScript_PortType) new ServiceClientGenerator(
            //                "RulesInquiryExecutingScript",
            //                RulesInquiryExecutingScript_Service.class,
            //                RulesInquiryExecutingScript_ServiceLocator.class,
            //                "getInquireRulesExecutingScript"
            //            ).getServiceClient();
            throw new UnsupportedOperationException("This class needs to be updated to extend BaseServiceIntegrator");
        }

        public ExecuteScriptResponse invokeService(Object input, RulesInquiryExecutingScript client) throws Exception {
            return client.inquireRulesExecutingScript(PACKAGE_SET_PREFIX + rpn, rpn, script, MAX_OUTPUT_FIELDS, argumentRow);
        }

        public Object mapInput(RulesScriptRequest domainInput) {
            rpn = domainInput.getRpn();
            script = domainInput.getScript();
            final Map<String, String> fields = domainInput.getInputFields();
            argumentRow = new ArrayList<>();

            for (final String fieldName : fields.keySet()) {
                final ArgumentRow row = new ArgumentRow();
                final ArgumentRowChar entry = new ArgumentRowChar();
                entry.setArgumentName(fieldName);
                entry.setArgumentCharacter(fields.get(fieldName));
                entry.setArgumentType(STRING_FIELD_TYPE);
                row.setArgumentRowChar(entry);
                argumentRow.add(row);
            }

            return null;
        }

        public RulesScriptResponse mapOutput(ExecuteScriptResponse serviceOutput) {
            final Map<String, List<String>> domainOutputFields = new TreeMap<>();

            if (serviceOutput.getResponseArgumentTableInfo() != null) {
                for (final ResponseArgumentTableInfo serviceField : serviceOutput.getResponseArgumentTableInfo()) {
                    final ResponseArgChar entryChar = serviceField.getResponseArgChar();
                    final ResponseArgNum entryNum = serviceField.getResponseArgNum();

                    String entryString = StringUtils.EMPTY;
                    String valueString = StringUtils.EMPTY;

                    //Output might occur in either a char or num of the script
                    if (entryChar != null) {
                        entryString = StringUtils.trimToEmpty(entryChar.getReturnName());
                        valueString = StringUtils.trimToEmpty(entryChar.getReturnCharacter());
                    } else if(entryNum != null) {
                        entryString = StringUtils.trimToEmpty(entryNum.getReturnName());
                        valueString = StringUtils.trimToEmpty(entryNum.getReturnNumber().toString());
                    }

                    if(StringUtils.isNotBlank(entryString) && StringUtils.isNotBlank(valueString)) {
                        domainOutputFields.computeIfAbsent(entryString, k -> new ArrayList<>());
                        final List<String> value = domainOutputFields.get(entryString);
                        value.add(valueString);
                    }
                }
            }

            final RulesScriptResponse domainOutput = new RulesScriptResponse();
            domainOutput.setOutputFields(domainOutputFields);

            return domainOutput;
        }
    }
}
