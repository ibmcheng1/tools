/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT
 * OF BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ANY UNAUTHORIZED USE,
 * REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2009 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.inform;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.MessageFormat;

import javax.annotation.Resource;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.interceptor.Interceptors;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.security.auth.Subject;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.biz.EnvironmentBiz;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.jms.interceptor.JmsDataAccessExceptionInterceptor;
import com.bcbssc.desktop.util.jndi.JndiUtils;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;

/**
 * Used to send INFOrm messages for commercial websites. Used by {@link InformBDBizImpl}.
 */
@Stateless
@Remote
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
@Interceptors({JmsDataAccessExceptionInterceptor.class})
public class JMSSubmitInformDAOImpl implements SubmitInformDAO {

    private static final Log log = LogFactory.getLog(JMSSubmitInformDAOImpl.class);

    @Resource(name = "failure.log.location")
    private String failureLogLocation;

    private static final String SELECTOR_PATTERN_CORRID = "JMSCorrelationID = ''{0}''";

    public JMSSubmitInformDAOImpl() {
        try {
            final EnvironmentBiz environmentBiz = JndiUtils.getEnvironmentBiz();
            failureLogLocation = environmentBiz.getCommon(EnvironmentObjects.FAILURE_LOG_LOCATION, String.class);
        } catch (final IllegalStateException e) {
            log.error("Could not find the failure log location, will not be able to determine a location for the log file", e);
        }
    }

    @Override
    public String sendInformMessage(String messageBody, Subject subject) {
        return this.sendInformMessage(messageBody, null, true, subject);
    }

    @Override
    public String sendInformMessage(String messageBody, boolean logFailedMessages, Subject subject) {
        return this.sendInformMessage(messageBody, null, logFailedMessages, subject);
    }

    @Override
    public String sendInformMessage(String messageBody, String correlationId, Subject subject) {
        return this.sendInformMessage(messageBody, correlationId, true, subject);
    }

    @Override
    public String sendInformMessage(String messageBody, String correlationId, boolean logFailedMessages, Subject subject) {
        String retCorrelationId = null;
        Connection connection = null;
        Session session = null;
        MessageProducer producer = null;
        Queue informQueue = null;

        try {
            final EnvironmentBiz environmentBiz = JndiUtils.getEnvironmentBiz();
            final ConnectionFactory connectionFactory = environmentBiz.get(EnvironmentObjects.JMS_INFORMCONNECTIONFACTORY, ConnectionFactory.class, subject);
            connection = connectionFactory.createConnection();
            session = connection.createSession(true, Session.AUTO_ACKNOWLEDGE);

            try {
                informQueue = environmentBiz.get(EnvironmentObjects.JMS_INFORMSUBMITQ, Queue.class, subject);
            } catch (final IllegalStateException e) {
                log.error("Could not find the inform submit queue definition, will not be able to submit Inform records");
                throw e;
            }

            producer = session.createProducer(informQueue);

            final TextMessage message = session.createTextMessage();
            message.setText(messageBody);
            message.setJMSCorrelationID(correlationId);

            Queue expireQueue = null;
            try {
                expireQueue = environmentBiz.get(EnvironmentObjects.JMS_INFORMEXPIREQ, Queue.class, subject);
            } catch (final Exception e) {
                log.warn("Could not find the inform expire queue definition, will not be able to determine expired messages");
            }
            if (null != expireQueue) {
                message.setJMSReplyTo(expireQueue);
                message.setJMSExpiration(300000);
            }

            producer.send(message);
            producer.setTimeToLive(300000);

            //the message id is assigned after the message is sent.
            retCorrelationId = message.getJMSMessageID();

            // Commit the session, and we're done
            session.commit();

            if (log.isInfoEnabled()) {
                log.info("Successfully submitted an Inform Message with the following information:\nCorrelation ID: "
                                + retCorrelationId + "\nQueue Name:" + informQueue.getQueueName() + "\nMessage:\n" + messageBody);
            }
        } catch (final Exception e) {
            // START - Fail safe attempt to get queue name.
            String queueName = "UNKNOWN";
            try {
                if (null == informQueue) {
                    queueName = "informQueue is null";
                } else {
                    informQueue.getQueueName();
                }
            } catch (final Throwable t) {
                // Ignore, there's nothing we can do at this point.
                queueName = "failed to retrieve queue name";
            }
            // END - Fail safe attempt to get queue name.

            final String errorMessage = "There was an exception attempting to submit the INFOrm record the following information:\nCorrelation ID: "
                            + retCorrelationId + "\nQueue Name:" + queueName + "\nMessage:\n" + messageBody;

            if (logFailedMessages) {
                log.error("Creating a failure record.\n" + errorMessage, e);
                logFailure(messageBody, subject);
            } else {
                throw new RuntimeException("NO FAILURE RECORD CREATED.\n" + errorMessage, e);
            }
        } finally {
            if (null != producer) {
                try{
                    producer.close();
                } catch(final Exception exception){
                    log.warn("Not able to close the jms message producer, continuing on");
                }
            }
            if (null != session) {
                try{
                    session.close();
                } catch(final Exception exception){
                    log.warn("Not able to close the jms session, continuing on");
                }
            }
            if (null != connection) {
                try{
                    connection.close();
                } catch(final Exception exception){
                    log.warn("Not able to close the jms connection, continuing on");
                }
            }
        }

        return retCorrelationId;
    }

    /**
     * This method is protected only so that it can be used in a junit test
     *
     * @param messageBody
     * @param subject
     */
    protected void logFailure(String messageBody, Subject subject) {
        final String fileLocation = failureLogLocation + File.separator + messageBody.hashCode() + ".dat";
        final File file = new File(fileLocation);
        try {
            if (file.createNewFile() && file.canWrite() && file.isFile()) {
                OutputStream stream = null;
                try {
                    stream = new FileOutputStream(file);
                    stream.write(InformUtil.META_DATA_DELIM_ENVIRONMENT.getBytes());
                    stream.write(SubjectUtils.getEnvironment(subject).getBytes());
                    stream.write(InformUtil.META_DATA_DELIM_REGION.getBytes());
                    stream.write(SubjectUtils.getRegion(subject).getBytes());
                    stream.write(InformUtil.META_DATA_DELIM.getBytes());
                    stream.write(messageBody.getBytes());
                    stream.flush();
                } catch (final Exception e1) {
                    log.error("There was an exception attempting to save the INFOrm record to disk, the record is\n"
                                    + messageBody, e1);
                } finally {
                    if (null != stream) {
                        try {
                            stream.close();
                        } catch (final Exception e2) {
                            log.info("There was an exception attempting to close the stream", e2);
                        }
                    }
                }
            } else {
                log.error("There was a problem attempting to save the INFOrm record to disk.\nSome possibilities for this are...\n\tThe file "
                                + failureLogLocation
                                + File.separator
                                + messageBody.hashCode()
                                + ".dat already existed\n\tThe file "
                                + failureLogLocation
                                + File.separator
                                + messageBody.hashCode()
                                + ".dat was not writable\n\tThe file "
                                + failureLogLocation
                                + File.separator
                                + messageBody.hashCode()
                                + ".dat is actually a directory\n\nThe record is\n" + messageBody);
            }
        } catch (final IOException e) {
            log.error("There was an exception attempting to create the file to store the INFOrm record to disk ("
                            + fileLocation + "), the record is\n" + messageBody, e);
        }
    }

    @Override
    public String readInformConfirmationResponse(String correlationId, long timeoutInMillis, Subject subject) throws Exception {
        String response = null;
        Connection connection = null;
        Session session = null;
        MessageConsumer consumer = null;

        try {
            final String selector = buildCorrelationIdSelector(correlationId);
            final EnvironmentBiz environmentBiz = JndiUtils.getEnvironmentBiz();
            final ConnectionFactory connectionFactory = environmentBiz.get(EnvironmentObjects.JMS_INFORMCONNECTIONFACTORY, ConnectionFactory.class, subject);
            connection = connectionFactory.createConnection();
            session = connection.createSession(true, Session.AUTO_ACKNOWLEDGE);

            Queue responseQueue = null;
            try {
                responseQueue = environmentBiz.get(EnvironmentObjects.JMS_INFORMRESPONSEQ, Queue.class, subject);
            } catch (final IllegalStateException e) {
                log.error("Could not find the inform response queue definition, will not be able to determine a response for a message");
                throw e;
            }

            consumer = session.createConsumer(responseQueue, selector);

            Message message = null;

            if (timeoutInMillis > 0) {
                message = consumer.receive(timeoutInMillis);
            } else if (timeoutInMillis == 0) {
                message = consumer.receiveNoWait();
            } else {
                // This will block!
                message = consumer.receive();
            }

            if (null == message) {
                response = "TIMEOUT";
            } else if (message instanceof TextMessage) {
                response = ((TextMessage) message).getText().trim();
                if (StringUtils.equals(response, "0001")) {
                    response = "RECEIVED";
                } else if (StringUtils.equals(response, "0002")) {
                    response = "PROCESSED";
                } else {
                    response = "UNKNOWN";
                }
            } else {
                response = "UNKNOWN";
            }

        } catch (final Exception e) {
            log.error("caught JMSException receiving message from ", e);
            throw new Exception(e);
        } finally {
            try {
                if (null != consumer) {
                    consumer.close();
                }
                if (null != session) {
                    session.close();
                }
                if (null != connection) {
                    connection.close();
                }
            } catch (final JMSException e) {
                log.warn("There was an exception attempting to close the JMS connections", e);
            }
        }

        return response;
    }

    /**
     * Convenience method to build selector strings based on
     * a correlation ID string
     * @param correlationId the correlationId value to use in a selector statement
     * @return a JMS-compliant selector string suitable for MessageConsumers
     * to retrieve only messages with the given correlation id header
     */
    protected String buildCorrelationIdSelector(String correlationId) {
        return MessageFormat.format(SELECTOR_PATTERN_CORRID, ((Object[]) new String[] { correlationId }));
    }


    /**
     * @return the failureLogLocation
     */
    public String getFailureLogLocation() {
        return failureLogLocation;
    }

    /**
     * @param failureLogLocation the failureLogLocation to set
     */
    public void setFailureLogLocation(String failureLogLocation) {
        this.failureLogLocation = failureLogLocation;
    }
}
