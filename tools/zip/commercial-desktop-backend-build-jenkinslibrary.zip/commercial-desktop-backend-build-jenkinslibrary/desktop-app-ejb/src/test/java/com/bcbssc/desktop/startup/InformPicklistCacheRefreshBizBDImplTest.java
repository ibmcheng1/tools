/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.startup;

import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.security.auth.Subject;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.EnvironmentBizMock;
import com.bcbssc.desktop.testutils.mock.MockCacheWrapper;
import com.bcbssc.domain.entity.InformSearchCriteria;

import junit.framework.TestCase;

/**
 * Unit tests for the InformPicklistRefreshBizBDImpl class
 */
public class InformPicklistCacheRefreshBizBDImplTest extends TestCase {
    @Override
    protected void setUp() throws Exception {
        final MockCacheWrapper mockCache = new MockCacheWrapper();
        DesktopAPI.setCacheWrapper(mockCache);
    }

    @Override
    protected void tearDown() throws Exception {
        DesktopAPI.setCacheWrapper(null);
    }

    /**
     * Test method for
     */
    public void testRefreshCachedData() throws Throwable {
        // this test needs to be redone when we get there
        //        TestInformPicklistCacheRefreshBiz biz = new TestInformPicklistCacheRefreshBiz();
        //        biz.refreshCachedData();
        //
        //        assertEquals("the number of entries stored was not what was expected", 9, biz.getStoreCount());
    }

    /**
     * Test method for
     */
    public void testRefreshCachedDataWithNoData() throws Throwable {
        final TestInformPicklistCacheRefreshBiz biz = new TestInformPicklistCacheRefreshBiz();
        biz.refreshCachedData();

        assertEquals("the number of entries stored was not what was expected", 0, biz.getStoreCount());
    }

    /**
     * Test method for
     */
    public void testExtractCriteria() throws Throwable {
        final InformPicklistCacheRefreshBizBDImpl impl = new InformPicklistCacheRefreshBizBDImpl();
        final InformSearchCriteria criteria = impl.extractCriteria("CSR_BCBSSC_3_44_916PICKLIST");
        assertNotNull(criteria);
        assertEquals("The company code did not match", "3", criteria.getCompanyCode());
        assertEquals("The division code did not match", "44", criteria.getDivisionCode());
        assertEquals("The department code did not match", "916", criteria.getDepartmentCode());
    }

    /**
     * Test method for
     */
    public void testGetRefreshRequests() throws Throwable {
        final InformPicklistCacheRefreshBizBDImpl impl = new InformPicklistCacheRefreshBizBDImpl();
        final List<String> requests = impl.getRefreshRequests(getKeys());
        assertNotNull(requests);
        assertEquals("The size of the requests list was not what was expected", 9, requests.size());
    }

    private Set<String> getKeys() {
        final Set<String> keys = new TreeSet<String>();
        // should be processed
        keys.add("CSR_BCBSSC_1_44_916PICKLIST");
        keys.add("CSR_BCBSSC_2_43_916PICKLIST");
        keys.add("CSR_BCBSSC_3_42_916PICKLIST");
        keys.add("CSR_BCBSSC_4_41_916PICKLIST");
        keys.add("CSR_BCBSSC_5_40_916PICKLIST");
        keys.add("CSR_BCBSSC_6_39_916PICKLIST");
        keys.add("CSR_BCBSSC_7_38_916PICKLIST");
        keys.add("CSR_BCBSSC_8_37_916PICKLIST");
        keys.add("CSR_BCBSSC_9_36_916PICKLIST");
        // should not be processed
        keys.add("CSR_001_BCBSSC_3_44_916_DVOST1RUILES");
        keys.add("Z!KJDJUBV938947NV8NSJH%$");
        keys.add("RULESCSR_001_BCBSSC_3_44_916_DVOST1");
        keys.add("3_44_916PICKLIST_DEFAULTS");
        return keys;
    }

    private class TestInformPicklistCacheRefreshBiz extends InformPicklistCacheRefreshBizBDImpl {
        private int storeCount = 0;

        public TestInformPicklistCacheRefreshBiz() {
            final EnvironmentBizMock biz = new EnvironmentBizMock();
            biz.environments.put("JUNIT", Boolean.TRUE);
            environmentBiz = biz;
        }

        @Override
        protected boolean initialize() {
            /*
             * Don't need to do anything, just preventing the attempt at initializing the timer
             */
            return true;
        }

        @Override
        protected Subject buildSubject(String applicationId, String environment) throws Exception {
            return null;
        }


        @Override
        protected void storePicklistData(HashMap picklistData, InformSearchCriteria criteria, String applicationId, String clientId) {
            storeCount++;
        }

        @Override
        protected HashMap<String, ?> getPicklistData(InformSearchCriteria criteria, String clientId, String applicationId, Subject subject) {
            final HashMap<String, Object> picklistData = new HashMap<String, Object>();
            picklistData.put("TEST", "Value1");
            return picklistData;
        }

        /**
         * @return the storeCount
         */
        public int getStoreCount() {
            return storeCount;
        }
    }

}
