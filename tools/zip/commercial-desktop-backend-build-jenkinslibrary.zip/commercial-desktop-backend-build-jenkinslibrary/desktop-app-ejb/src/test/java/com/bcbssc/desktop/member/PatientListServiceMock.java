/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.member;

import com.bcbssc.services.patientlist.PatientListEligiblePatientList;
import com.bcbssc.services.patientlist.PatientListInput;
import com.bcbssc.services.patientlist.PatientListOutput;
import com.bcbssc.services.patientlist.PatientListService;

import java.util.Arrays;

public class PatientListServiceMock implements PatientListService {
	public int callCount = 0;

	@Override
	public PatientListOutput getPatientList(PatientListInput arg0) {
		// Simulates the service / host fetch time.
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		}

		this.callCount++;

		PatientListOutput output = new PatientListOutput();
		PatientListEligiblePatientList[] patients = new PatientListEligiblePatientList[4];

		patients[0] = new PatientListEligiblePatientList();
		patients[0].setPlanCode("885");
		patients[0].setAmmsPatientIdNumber("001");
		patients[0].setPatientFirstName("MICHAEL");
		patients[0].setPatientLastName("TESTING");
		patients[0].setCesMemberNumber("01");
		patients[0].setVerifiedPatientIndicator("Y");
		patients[0].setPatientRelationshipDescription("SUBSCRIBER");
		patients[0].setPatientGender("MALE");
		patients[0].setPatientDateOfBirth("12/12/2012");

		patients[1] = new PatientListEligiblePatientList();
		patients[1].setPlanCode("001");
		patients[1].setAmmsPatientIdNumber("001");
		patients[1].setPatientFirstName("MICHAEL");
		patients[1].setPatientLastName("TESTING");
		patients[1].setCesMemberNumber("01");
		patients[1].setVerifiedPatientIndicator("Y");
		patients[1].setPatientRelationshipDescription("SUBSCRIBER");
		patients[1].setPatientGender("MALE");
		patients[1].setPatientDateOfBirth("12/12/2012");

		patients[2] = new PatientListEligiblePatientList();
		patients[2].setPlanCode("885");
		patients[2].setAmmsPatientIdNumber("002");
		patients[2].setPatientFirstName("BOB");
		patients[2].setPatientLastName("TESTING");
		patients[2].setCesMemberNumber("02");
		patients[2].setVerifiedPatientIndicator("");
		patients[2].setPatientRelationshipDescription("DEPENDENT");
		patients[2].setPatientGender("MALE");
		patients[2].setPatientDateOfBirth("05/11/2010");

		patients[3] = new PatientListEligiblePatientList();
		patients[3].setPlanCode("001");
		patients[3].setAmmsPatientIdNumber("002");
		patients[3].setPatientFirstName("BOB");
		patients[3].setPatientLastName("TESTING");
		patients[3].setCesMemberNumber("02");
		patients[3].setVerifiedPatientIndicator("");
		patients[3].setPatientRelationshipDescription("DEPENDENT");
		patients[3].setPatientGender("MALE");
		patients[3].setPatientDateOfBirth("05/11/2010");

        output.getEligiblePatientList().getPatientListEligiblePatientList().addAll(Arrays.asList(patients));

		return output;
	}
}
