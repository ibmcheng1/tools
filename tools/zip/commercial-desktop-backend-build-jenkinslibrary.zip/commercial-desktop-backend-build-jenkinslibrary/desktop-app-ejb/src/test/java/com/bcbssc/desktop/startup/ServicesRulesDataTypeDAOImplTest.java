/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.startup;

import java.security.PrivilegedExceptionAction;
import java.sql.Date;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.security.auth.Subject;
import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.EndpointReference;

import com.bcbssc.desktop.testutils.naming.SimpleInitialContextStubber;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.valueobject.claims.CodeRange;
import com.bcbssc.services.rulesdatatypeinquiry.ArrayOfRULESDataTypeInquiryDetailedDataTypeRecords;
import com.bcbssc.services.rulesdatatypeinquiry.RULESDataTypeInquiryDetailedDataTypeRecords;
import com.bcbssc.services.rulesdatatypeinquiry.RULESDataTypeInquiryInput;
import com.bcbssc.services.rulesdatatypeinquiry.RULESDataTypeInquiryOutput;
import com.bcbssc.services.rulesdatatypeinquiry.RULESDataTypeInquiryService;

import junit.framework.TestCase;

public class ServicesRulesDataTypeDAOImplTest extends TestCase {

    private SimpleInitialContextStubber initialContextStubber;
    private TestServicesRulesDataTypeDAOImpl objectUnderTest;
    private Subject user;

    @Override
    protected void setUp() throws Exception {
        initialContextStubber = new SimpleInitialContextStubber();
        initialContextStubber.bind("service/baseEndpoint", "http://services.bcbssc.com");
        objectUnderTest = new TestServicesRulesDataTypeDAOImpl();
        objectUnderTest.setService(new MockRulesDataTypeInquiryService());
        user = SubjectUtils.createEmptySubject();
        SubjectUtils.setRegion(user, "region");
    }

    @Override
    protected void tearDown() throws Exception {
        initialContextStubber.unbindAll();
        initialContextStubber.shutDown();
    }

    /**
     * Test that the date is correct
     */
    public void testGetIcdComplianceDate() throws Throwable {
        Date result = null;

        result = Subject.doAs(user, new PrivilegedExceptionAction<Date>() {
            @Override
            public Date run() throws Exception {
                return objectUnderTest.getIcdComplianceDate();
            }
        });

        assertNotNull("Missing result", result);
        assertEquals("2012-10-01", result.toString());
    }

    public void testGetIcdCategories() throws Throwable {
        List<CodeRange> result = null;

        result = Subject.doAs(user, new PrivilegedExceptionAction<List<CodeRange>>() {
            @Override
            public List<CodeRange> run() throws Exception {
                return objectUnderTest.getIcdCategories();
            }
        });

        assertNotNull("Missing result", result);
        assertEquals(6, result.size());
        assertEquals("A00", result.get(3).getCodeRangeBegin());
        assertEquals("B99", result.get(3).getCodeRangeEnd());
        assertEquals("Diseases of the blood and blood-forming organs and certain disorders involving " +
                        "the immune mechanism of the bowels.", result.get(3).getDescription());
        assertEquals("C00", result.get(4).getCodeRangeBegin());
        assertEquals("D48", result.get(4).getCodeRangeEnd());
        assertEquals("Diseases of the blood and blood-forming", result.get(4).getDescription());
        assertEquals("E00", result.get(5).getCodeRangeBegin());
        assertEquals("E90", result.get(5).getCodeRangeEnd());
        assertEquals("Endocrine, nutritional and metabolic diseases", result.get(5).getDescription());
    }

    /**
     * Extends the class under test to add testing hooks.
     */
    private class TestServicesRulesDataTypeDAOImpl extends ServicesRulesDataTypeDAOImpl {

    }

    /**
     * Mock Rules Data Type Inquiry Service
     */
    private class MockRulesDataTypeInquiryService implements RULESDataTypeInquiryService, BindingProvider {

        @Override
        public RULESDataTypeInquiryOutput getRULESDataType(RULESDataTypeInquiryInput arg0) {
            final RULESDataTypeInquiryOutput output = new RULESDataTypeInquiryOutput();
            output.setDetailedDataTypeRecords(new ArrayOfRULESDataTypeInquiryDetailedDataTypeRecords());

            final RULESDataTypeInquiryDetailedDataTypeRecords[] dataTypeRecords = new RULESDataTypeInquiryDetailedDataTypeRecords[6];
            dataTypeRecords[0] = new RULESDataTypeInquiryDetailedDataTypeRecords();
            dataTypeRecords[0].setKeyField1("NoMatch");
            dataTypeRecords[0].setDataField1("NoMatch");
            dataTypeRecords[1] = new RULESDataTypeInquiryDetailedDataTypeRecords();
            dataTypeRecords[1].setKeyField1("NoMatch");
            dataTypeRecords[1].setDataField1("NoMatch");
            dataTypeRecords[2] = new RULESDataTypeInquiryDetailedDataTypeRecords();
            dataTypeRecords[2].setKeyField1("ICDDATE");
            dataTypeRecords[2].setDataField1("2012-10-01");
            dataTypeRecords[3] = new RULESDataTypeInquiryDetailedDataTypeRecords();
            dataTypeRecords[3].setKeyField1("A00");
            dataTypeRecords[3].setKeyField2("B99");
            dataTypeRecords[3].setDataField1("Diseases of the blood and blood-forming");
            dataTypeRecords[3].setDataField2("organs and certain disorders involving");
            dataTypeRecords[3].setDataField3("the immune mechanism of the bowels.");
            dataTypeRecords[4] = new RULESDataTypeInquiryDetailedDataTypeRecords();
            dataTypeRecords[4].setKeyField1("C00");
            dataTypeRecords[4].setKeyField2("D48");
            dataTypeRecords[4].setDataField1("Diseases of the blood and blood-forming");
            dataTypeRecords[4].setDataField2(null);
            dataTypeRecords[4].setDataField3(null);
            dataTypeRecords[5] = new RULESDataTypeInquiryDetailedDataTypeRecords();
            dataTypeRecords[5].setKeyField1("E00");
            dataTypeRecords[5].setKeyField2("E90");
            dataTypeRecords[5].setDataField1("Endocrine, nutritional and");
            dataTypeRecords[5].setDataField2("metabolic diseases");
            dataTypeRecords[5].setDataField3(null);
            output.getDetailedDataTypeRecords().getRULESDataTypeInquiryDetailedDataTypeRecords().addAll(Arrays.asList(dataTypeRecords));

            return output;
        }

        @Override
        public Map<String, Object> getRequestContext() {
            return new HashMap<>();
        }

        @Override
        public Map<String, Object> getResponseContext() {
            throw new UnsupportedOperationException("not implemented");
        }

        @Override
        public Binding getBinding() {
            throw new UnsupportedOperationException("not implemented");
        }

        @Override
        public EndpointReference getEndpointReference() {
            throw new UnsupportedOperationException("not implemented");
        }

        @Override
        public <T extends EndpointReference> T getEndpointReference(Class<T> clazz) {
            throw new UnsupportedOperationException("not implemented");
        }
    }
}
