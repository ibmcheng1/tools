/*
 * Copyright (C) 2012 BlueCross BlueShield of South Carolina, all rights reserved.
 *
 * This software is the confidential and proprietary property of
 * BlueCross BlueShield of South Carolina ("Confidential Information").
 * Any unauthorized use or reproduction is strictly prohibited.
 */
package com.bcbssc.desktop.environment;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.security.auth.Subject;

import junit.framework.TestCase;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.resourceprovider.Config;
import com.bcbssc.desktop.testutils.mock.MockCacheWrapper;
import com.bcbssc.desktop.testutils.naming.SimpleInitialContextStubber;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;

public class ResourceProviderEnvironmentDAOImplTest extends TestCase {
	protected static final String REP_JNDI_NAME_PREFIX = "rep/";
	protected static final String REP_JNDI_NAME_REGION_PREFIX = "rep/region/";
	protected static final String DEFAULT_ENVIRONMENT = "default";

	private MockCacheWrapper mockCache;

	@Override
	protected void setUp() throws Exception {
		mockCache = new MockCacheWrapper();
		DesktopAPI.setCacheWrapper(mockCache);
	}

	@Override
	protected void tearDown() throws Exception {
		mockCache.clear();
		DesktopAPI.setCacheWrapper(null);
	}

	public void testGetObject() {
		Subject subject = SubjectUtils.createEmptySubject();
		SubjectUtils.setEnvironment(subject, DEFAULT_ENVIRONMENT);

		SimpleInitialContextStubber jndi = new SimpleInitialContextStubber();

		//Creating config object for REP rep/default with lookup attribute values. This config object goes into mock initial context.
		Config config = new Config();
		config.setAttribute(EnvironmentObjects.REGION_DEFAULT.getBaseId(), "DV7ST1");
		jndi.bind(REP_JNDI_NAME_PREFIX + DEFAULT_ENVIRONMENT, config);

		ResourceProviderEnvironmentDAOImpl dao = new ResourceProviderEnvironmentDAOImpl();

		Object result = dao.getObject(EnvironmentObjects.REGION_DEFAULT, subject);
		assertEquals("DV7ST1", result);
		jndi.shutDown();
	}

	public void testGetObjectIllegalStateException() {
		Subject subject = SubjectUtils.createEmptySubject();
		SubjectUtils.setEnvironment(subject, DEFAULT_ENVIRONMENT);

		ResourceProviderEnvironmentDAOImpl dao = new ResourceProviderEnvironmentDAOImpl();

		boolean exceptionThrown = false;
		try {
			Object result = dao.getObject(EnvironmentObjects.REGION_DEFAULT, subject);
		} catch (IllegalStateException e) {
			exceptionThrown = true;
		}
		assertEquals(exceptionThrown, true);
	}

	public void testGetObjectBlankEnvironmentException() {
		Subject subject = SubjectUtils.createEmptySubject();

		ResourceProviderEnvironmentDAOImpl dao = new ResourceProviderEnvironmentDAOImpl();

		boolean exceptionThrown = false;
		try {
			Object result = dao.getObject(EnvironmentObjects.REGION_DEFAULT, subject);
		} catch (IllegalStateException e) {
			exceptionThrown = true;
		}
		assertEquals(exceptionThrown, true);
	}

	public void testGetCommonObject() {
		Subject subject = SubjectUtils.createEmptySubject();
		SubjectUtils.setEnvironment(subject, DEFAULT_ENVIRONMENT);

		SimpleInitialContextStubber jndi = new SimpleInitialContextStubber();

		//Creating config object for REP rep/<environment-name> with lookup attribute values. This config object goes into mock initial context.
		Config config = new Config();
		config.setAttribute(EnvironmentObjects.REGION_DEFAULT.getBaseId(), "DV7ST1");
		jndi.bind(REP_JNDI_NAME_PREFIX + DEFAULT_ENVIRONMENT, config);

		ResourceProviderEnvironmentDAOImpl dao = new ResourceProviderEnvironmentDAOImpl();

		Object result = dao.getCommonObject(EnvironmentObjects.REGION_DEFAULT);
		assertEquals("DV7ST1", result);
		jndi.shutDown();
	}

	public void testGetObjectMultiRegion_RegionEnvSpecific() throws Throwable {
		Object result = null;
		final String region = "DV7ST1".toLowerCase();

		//setting subject values to empty subject
		Subject subject = SubjectUtils.createEmptySubject();
		SubjectUtils.setEnvironment(subject, DEFAULT_ENVIRONMENT);
		SubjectUtils.setRegion(subject, region);

		final Queue dest = new Queue() {
			@Override
			public String getQueueName() throws JMSException {
				// TODO Auto-generated method stub
				return "JUNIT_MOCK_QUEUE";
			}
		};

		SimpleInitialContextStubber jndi = new SimpleInitialContextStubber();

		//Creating config object for REP rep/region/<region-name> with no attribute values. This config object goes into mock initial context.
		Config environmentConfigRegionSpecific = new Config();
		jndi.bind(REP_JNDI_NAME_REGION_PREFIX + region, environmentConfigRegionSpecific);

		//Creating config object for REP rep/<environment-name> with multi region attribute value. This config object goes into mock initial context
		//Multi region value lookup occur at this REP level and hence set into this config object
		Config environmentConfig = new Config();
		environmentConfig.setAttribute(EnvironmentObjects.MULTIREGION_ENABLED.getBaseId(), "true");
		jndi.bind(REP_JNDI_NAME_PREFIX + DEFAULT_ENVIRONMENT, environmentConfig);

		//Creating config object for REP rep/<environment-name>/<region-name> with required lookup attribute value for test. This config object goes into mock initial context.
		Config environmentConfigRegionEnvSpecific = new Config();
		environmentConfigRegionEnvSpecific.setAttribute(EnvironmentObjects.JMS_GATEWAYREQUESTQ.getBaseId(), dest);
		jndi.bind(REP_JNDI_NAME_PREFIX + DEFAULT_ENVIRONMENT + "/" + region, environmentConfigRegionEnvSpecific);

		ResourceProviderEnvironmentDAOImpl dao = new ResourceProviderEnvironmentDAOImpl();

		result = dao.getObject(EnvironmentObjects.JMS_GATEWAYREQUESTQ, subject);

		assertTrue(result == dest);
		jndi.shutDown();
	}

	public void testGetObjectMultiRegion_RegionSpecific() throws Throwable {
		Object result = null;
		final String region = "DV7ST1".toLowerCase();

		//setting subject values to empty subject
		Subject subject = SubjectUtils.createEmptySubject();
		SubjectUtils.setEnvironment(subject, DEFAULT_ENVIRONMENT);
		SubjectUtils.setRegion(subject, region);

		final Queue dest = new Queue() {
			@Override
			public String getQueueName() throws JMSException {
				return "JUNIT_MOCK_QUEUE";
			}
		};

		SimpleInitialContextStubber jndi = new SimpleInitialContextStubber();

		//Creating config object for REP rep/<environment-name>/<region-name> with no attribute values. This config object goes into mock initial context.
		Config environmentConfigRegionEnvSpecific = new Config();
		jndi.bind(REP_JNDI_NAME_PREFIX + DEFAULT_ENVIRONMENT + "/" + region, environmentConfigRegionEnvSpecific);

		//Creating config object for REP rep/<environment-name> with multi region attribute value. This config object goes into mock initial context
		//Multi region value lookup occur at this REP level and hence set into this config object
		Config environmentConfig = new Config();
		environmentConfig.setAttribute(EnvironmentObjects.MULTIREGION_ENABLED.getBaseId(), "true");
		jndi.bind(REP_JNDI_NAME_PREFIX + DEFAULT_ENVIRONMENT, environmentConfig);

		//Creating config object for REP rep/region/<region-name> with required lookup attribute value for test. This config object goes into mock initial context.
		Config environmentConfigRegionSpecific = new Config();
		environmentConfigRegionSpecific.setAttribute(EnvironmentObjects.JMS_GATEWAYREQUESTQ.getBaseId(), dest);
		jndi.bind(REP_JNDI_NAME_REGION_PREFIX + region, environmentConfigRegionSpecific);

		ResourceProviderEnvironmentDAOImpl dao = new ResourceProviderEnvironmentDAOImpl();

		result = dao.getObject(EnvironmentObjects.JMS_GATEWAYREQUESTQ, subject);

		assertTrue(result == dest);
		jndi.shutDown();
	}

	public void testGetObjectMultiRegion_default() {
		Object result = null;
		final String region = "DV7ST1".toLowerCase();

		//setting subject values to empty subject
		Subject subject = SubjectUtils.createEmptySubject();
		SubjectUtils.setEnvironment(subject, DEFAULT_ENVIRONMENT);
		SubjectUtils.setRegion(subject, region);

		final Queue dest = new Queue() {
			@Override
			public String getQueueName() throws JMSException {
				// TODO Auto-generated method stub
				return "JUNIT_MOCK_QUEUE";
			}
		};

		SimpleInitialContextStubber jndi = new SimpleInitialContextStubber();

		//Creating config object for REP rep/<environment-name>/<region-name> with no attribute values. This config object goes into mock initial context.
		Config environmentConfigRegionEnvSpecific = new Config();
		jndi.bind(REP_JNDI_NAME_PREFIX + DEFAULT_ENVIRONMENT + "/" + region, environmentConfigRegionEnvSpecific);

		//Creating config object for REP rep/<environment-name> with multi region attribute value and the required attribute lookup value for test. This config object goes into mock initial context
		//Multi region value lookup occur at this REP level and hence set into this config object
		Config environmentConfig = new Config();
		environmentConfig.setAttribute(EnvironmentObjects.MULTIREGION_ENABLED.getBaseId(), "true");
		environmentConfig.setAttribute(EnvironmentObjects.JMS_GATEWAYREQUESTQ.getBaseId(), dest);
		jndi.bind(REP_JNDI_NAME_PREFIX + DEFAULT_ENVIRONMENT, environmentConfig);

		//Creating config object for REP rep/region/<region-name> with no attribute values. This config object goes into mock initial context.
		Config environmentConfigRegionSpecific = new Config();
		jndi.bind(REP_JNDI_NAME_REGION_PREFIX + region, environmentConfigRegionSpecific);

		ResourceProviderEnvironmentDAOImpl dao = new ResourceProviderEnvironmentDAOImpl();

		result = dao.getObject(EnvironmentObjects.JMS_GATEWAYREQUESTQ, subject);

		assertTrue(result == dest);
		jndi.shutDown();
	}

	public void testCheckRegionSpecificValueRepNull() {
		Object result = "failed";
		final String region = "DV7ST1".toLowerCase();

		Subject subject = SubjectUtils.createEmptySubject();
		SubjectUtils.setEnvironment(subject, DEFAULT_ENVIRONMENT);
		SubjectUtils.setRegion(subject, region);

		SimpleInitialContextStubber jndi = new SimpleInitialContextStubber();

		//Creating config object for REP rep/<environment-name>/<region-name> with no attribute values. This config object goes into mock initial context.
		Config environmentConfigRegionEnvSpecific = new Config();
		jndi.bind(REP_JNDI_NAME_PREFIX + DEFAULT_ENVIRONMENT + "/" + region, environmentConfigRegionEnvSpecific);

		//Creating config object for REP rep/<environment-name> with  multi region attribute value. This config object goes into mock initial context
		//Multi region value lookup occur at this REP level and hence set into this config object
		Config environmentConfig = new Config();
		environmentConfig.setAttribute(EnvironmentObjects.MULTIREGION_ENABLED.getBaseId(), "true");
		jndi.bind(REP_JNDI_NAME_PREFIX + DEFAULT_ENVIRONMENT, environmentConfig);

		//Creating config object for REP rep/region/<region-name> with no attribute values. This config object goes into mock initial context.
		Config environmentConfigRegionSpecific = new Config();
		jndi.bind(REP_JNDI_NAME_REGION_PREFIX + region, environmentConfigRegionSpecific);

		ResourceProviderEnvironmentDAOImpl dao = new ResourceProviderEnvironmentDAOImpl();

		result = dao.getObject(EnvironmentObjects.JMS_GATEWAYREQUESTQ, subject);

		assertTrue(result == null);
		jndi.shutDown();
	}
}
