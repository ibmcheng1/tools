/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.member;

import java.rmi.RemoteException;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.security.auth.Subject;

import junit.framework.TestCase;

import com.bcbssc.desktop.member.ServicesMemberStatusHistoryDAOImpl.MemberStatusHistoryWebService;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.Member;
import com.bcbssc.domain.entity.MemberStatusHistoryCriteria;
import com.bcbssc.domain.entity.Subsystem;
import com.bcbssc.services.memberstatushistory.MemberStatusHistoryInput;
import com.bcbssc.services.memberstatushistory.MemberStatusHistoryMemberStatusInformation;
import com.bcbssc.services.memberstatushistory.MemberStatusHistoryOutput;
import com.bcbssc.services.memberstatushistory.MemberStatusHistoryService;

/**
 * JUnit test cases for {@link ServicesMemberStatusHistoryDAOImpl}. These test cases will test the
 * functionality of the class itself. This will not attempt to retrieve live data.
 */
public class ServicesMemberStatusHistoryDAOImplTest extends TestCase {

    /**
     * Tests
     */
    public void testGetMemberStatusHistory() {
        // this test needs to be redone when we get there
//        final ServicesMemberStatusHistoryDAOImpl impl = new ServicesMemberStatusHistoryDAOImpl() {
//            @Override
//            protected Object getMemberStatusHistoryService() {
//                return new TestMemberStatusHistoryService();
//            }
//        };
//
//        final Subject user = SubjectUtils.createEmptySubject();
//        final Map<String, Subsystem> rpns = new HashMap<String, Subsystem>();
//        final Subsystem rules = new Subsystem();
//        rules.setRpn("001");
//        rpns.put("CISI", rules);
//        SubjectUtils.setRPNSubsystems(user, rpns);
//
//        final MemberStatusHistoryCriteria criteria = new MemberStatusHistoryCriteria();
//        List<Member> results = null;
//
//        try {
//            results = (List<Member>) Subject.doAs(user, new PrivilegedExceptionAction<List<Member>>() {
//                public List<Member> run() {
//                    return impl.getMemberStatusHistory(criteria);
//                }
//            });
//        } catch (PrivilegedActionException e) {
//            e.printStackTrace(System.err);
//            fail("Exception thrown");
//        }
//
//        assertNotNull(results);
//        assertEquals(2, results.size());
//        assertEquals("MemberNumber1", results.get(0).getCesMemberNumber());
//        assertEquals("MemberNumber2", results.get(1).getCesMemberNumber());
//
//        final SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
//        try {
//            assertEquals(dateFormat.parse("01/01/2001"), results.get(0).getRecordBeginDate());
//            assertEquals(dateFormat.parse("02/02/2002"), results.get(1).getRecordBeginDate());
//        } catch (ParseException e) {
//            e.printStackTrace(System.err);
//            fail("Exception thrown");
//        }
    }

    /**
     * Tests
     * @throws ParseException
     */
    public void testMapRecord() throws ParseException {
        ServicesMemberStatusHistoryDAOImpl impl = new ServicesMemberStatusHistoryDAOImpl();
        MemberStatusHistoryWebService service = impl.new MemberStatusHistoryWebService(null);
        MemberStatusHistoryMemberStatusInformation record = getRecord();
        Member member = null;
        SimpleDateFormat twoDigitYearFormat = new SimpleDateFormat("MM/dd/yy");
        SimpleDateFormat fourDigitYearFormat = new SimpleDateFormat("MM/dd/yyyy");
        SimpleDateFormat overAgeFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date beginDate = twoDigitYearFormat.parse("02/11/10");
        Date termDate = twoDigitYearFormat.parse("12/10/10");
        Date originalEnrollDate = twoDigitYearFormat.parse("01/01/09");
        Date dateOfBirth = fourDigitYearFormat.parse("11/01/1983");
        Date marrageDate = fourDigitYearFormat.parse("08/12/2005");
        Date overAgeCertifiedDate = overAgeFormat.parse("11/02/2008");
        Date updateDate = twoDigitYearFormat.parse("10/01/10");
        Date setupDate = twoDigitYearFormat.parse("10/01/10");
        try {
            member = service.mapRecord(record);
            assertNotNull("The resulting member should not have been null", member);
            assertTrue("The confidential claim indicator should have been true", member.isConfidentialClaimIndicator());
            assertEquals("The record begin date was not correct", beginDate, member.getRecordBeginDate());
            assertEquals("The record end date was not correct", termDate, member.getRecordTermDate());
            assertEquals("The original enrollment date was not correct", originalEnrollDate, member.getOriginalEnrollmentDate());
            assertTrue("The understands english indicator should have been true", member.isUnderstandsEnglish());
            assertEquals("The member number did not match", record.getMemberNumber(), member.getCesMemberNumber());
            assertEquals("The first name did not match", record.getMemberFirstName(), member.getName().getFirstName());
            assertEquals("The middle name did not match", record.getMemberMiddleName(), member.getName().getMiddleName());
            assertEquals("The last name did not match", record.getMemberLastName(), member.getName().getLastName());
            assertEquals("The name suffix did not match", record.getMemberSuffix(), member.getName().getSuffixName());
            assertEquals("The name prefix did not match", record.getMemberNameTitle(), member.getName().getPrefixName());
            assertEquals("The gender code did not match", record.getMemberGender(), member.getSex().getCode());
            assertEquals("The gender description did not match", "MALE", member.getSex().getDescription());
            assertEquals("The date of birth was not correct", dateOfBirth, member.getDateOfBirth());
            assertEquals("The social security number was not correct", record.getMemberSocialSecurityNumber(), member.getSocialSecurityNumber());
            assertEquals("The marital status code was not correct", record.getMemberMaritalStatusCode(), member.getMaritalStatus().getCode());
            assertEquals("The marital status date was not correct", marrageDate, member.getMaritalStatus().getMaritalStatusDate());
            assertEquals("The medicare number was not correct", record.getMedicareNumber(), member.getMedicareNumber());
            assertNotNull("The alternate names array was null", member.getAlternateNames());
            assertEquals("The alternate names array did not have the expected length", 2, member.getAlternateNames().size());
            assertEquals("The first nickname was not correct", record.getMemberNickName1(), member.getAlternateNames().get(0).getFirstName());
            assertEquals("The second nickname was not correct", record.getMemberNickName2(), member.getAlternateNames().get(1).getFirstName());
            assertEquals("The vision plan patient id was not correct", record.getVisionPlanPatientId(), member.getVisionPlanPatientId());
            assertEquals("The previous patient id was not correct", record.getPreviousMedPlanPatientId(), member.getPreviousMemberId());
            assertEquals("The member id was not correct", record.getCurrentMedPlanPatientId(), member.getMemberId());
            assertEquals("The update employee was not correct", record.getUpdatedByOperatorId(), member.getUpdateByEmployee());
            assertEquals("The tobacco usage code was not correct", record.getMemberTobaccoUsageIndicator(), member.getTobaccoUsage().getCode());
            assertEquals("The cancel code was not correct", record.getCancelCode(), member.getCancelCode().getCode());
            assertEquals("The employment status code was not correct", record.getMemberEmployeeStatusInd(), member.getEmploymentStatus().getCode());
            assertEquals("The language code was not correct", record.getPreferredLanguageCode(), member.getPreferredLanguage().getCode());
            assertEquals("The member status code was not correct", record.getMemberStatusCode(), member.getMemberStatus().getCode());
            assertEquals("The over age date was not correct", overAgeCertifiedDate, member.getOverAgeDependent().getCertifiedDate());
            assertEquals("The over age indicator was not correct", record.getMemberOverAgeDependentInd(), member.getOverAgeDependent().getCode());
            assertEquals("The relationship code was not correct", record.getMemberRelationship(), member.getRelationship().getCode());
            assertEquals("The supress id cards indicator was not correct", record.getSuppressIdCardsIndicator(), member.getSuppressIdCards().getCode());
            assertEquals("The member update date was not correct", updateDate, member.getUpdateDate());
            assertEquals("The member setup date was not correct", setupDate, member.getSetupDate());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception");
        }

        // blank record start date - required field - throws exception
        record = getRecord();
        record.setRecordBeginDate("");
        try {
            member = service.mapRecord(record);
            fail("The record begin date is a required field, an exception should be thrown");
        } catch (Exception e) {
            // expect an exception to be thrown
        }

        // blank record term date - should not throw an exception
        record = getRecord();
        record.setRecordTermDate("");
        try {
            member = service.mapRecord(record);
            assertNotNull("The resulting member should not have been null", member);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception with a blank term date");
        }

        // blank original enroll date - should not throw an exception
        record = getRecord();
        record.setOriginalEnrollDate("");
        try {
            member = service.mapRecord(record);
            assertNotNull("The resulting member should not have been null", member);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception with a blank original enrollment date");
        }

        // blank understands english indicator - should not throw an exception - default to false
        record = getRecord();
        record.setUnderstandsEnglishIndicator("");
        try {
            member = service.mapRecord(record);
            assertNotNull("The resulting member should not have been null", member);
            assertFalse("The understands english indicator should have been set to false", member.isUnderstandsEnglish());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception with a blank understands english indicator");
        }

        // blank confidential claim indicator - should not throw an exception - default to false
        record = getRecord();
        record.setConfidentialClaimIndicator("");
        try {
            member = service.mapRecord(record);
            assertNotNull("The resulting member should not have been null", member);
            assertFalse("The confidential claim indicator should have been false", member.isConfidentialClaimIndicator());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception with a blank confidential claim indicator");
        }

        // no middle name - should not throw an exception - default to empty string
        record = getRecord();
        record.setMemberMiddleName("");
        try {
            member = service.mapRecord(record);
            assertNotNull("The resulting member should not have been null", member);
            assertEquals("The middle name should have been set to empty string", "", member.getName().getMiddleName());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception with a blank middle name");
        }

        // M member gender - should not throw an exception - description of MALE
        record = getRecord();
        record.setMemberGender("M");
        try {
            member = service.mapRecord(record);
            assertNotNull("The resulting member should not have been null", member);
            assertEquals("The translation of the member gender was not correct", "MALE", member.getSex().getDescription());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception with a M gender code");
        }

        // F member gender - should not throw an exception - description of FEMALE
        record = getRecord();
        record.setMemberGender("F");
        try {
            member = service.mapRecord(record);
            assertNotNull("The resulting member should not have been null", member);
            assertEquals("The translation of the member gender was not correct", "FEMALE", member.getSex().getDescription());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception with a F gender code");
        }

        // U member gender - should not throw an exception - description of UNKNOWN
        record = getRecord();
        record.setMemberGender("U");
        try {
            member = service.mapRecord(record);
            assertNotNull("The resulting member should not have been null", member);
            assertEquals("The translation of the member gender was not correct", "UNKNOWN", member.getSex().getDescription());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception with a U gender code");
        }

        // other member gender - should not throw an exception - description of the value passed in
        record = getRecord();
        record.setMemberGender("K");
        try {
            member = service.mapRecord(record);
            assertNotNull("The resulting member should not have been null", member);
            assertEquals("The translation of the member gender was not correct", "K", member.getSex().getDescription());
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception with a K gender code");
        }

        // blank member date of birth - should not throw an exception
        record = getRecord();
        record.setMemberDateOfBirth("");
        try {
            member = service.mapRecord(record);
            assertNotNull("The resulting member should not have been null", member);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception with a blank birthdate");
        }

        // blank member marital status date - should not throw an exception
        record = getRecord();
        record.setMemberMaritalStatusDate("");
        try {
            member = service.mapRecord(record);
            assertNotNull("The resulting member should not have been null", member);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception with a blank marital status date");
        }

        // blank updated by operator id - should not throw an exception
        record = getRecord();
        record.setUpdatedByOperatorId("");
        try {
            member = service.mapRecord(record);
            assertNotNull("The resulting member should not have been null", member);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception with a blank updated by operator id");
        }

        // blank member over age certified date - should not throw an exception
        record = getRecord();
        record.setMemberOverAgeCertifiedDate("");
        try {
            member = service.mapRecord(record);
            assertNotNull("The resulting member should not have been null", member);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception with a blank over age certification date");
        }

        // invalid member over age certified date - should throw an exception
        record = getRecord();
        record.setMemberOverAgeCertifiedDate("toast");
        try {
            member = service.mapRecord(record);
            fail("Should have thrown an exception with a bad over age certification date");
        } catch (Exception e) {
            // exception should be thrown
        }

        // blank member updated date - should not throw an exception
        record = getRecord();
        record.setMemberUpdatedDate("");
        try {
            member = service.mapRecord(record);
            assertNotNull("The resulting member should not have been null", member);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception with a blank update date");
        }

        // blank member setup date - should not throw an exception
        record = getRecord();
        record.setMemberSetupDate("");
        try {
            member = service.mapRecord(record);
            assertNotNull("The resulting member should not have been null", member);
        } catch (Exception e) {
            e.printStackTrace();
            fail("Should not have thrown an exception with a blank setup date");
        }
    }

    private MemberStatusHistoryMemberStatusInformation getRecord() {
        MemberStatusHistoryMemberStatusInformation record = new MemberStatusHistoryMemberStatusInformation();
        record.setRecordBeginDate("02/11/10");
        record.setRecordTermDate("12/10/10");
        record.setConfidentialClaimIndicator("Y");
        record.setOriginalEnrollDate("01/01/09");
        record.setUnderstandsEnglishIndicator("Y");
        record.setMemberNumber("01");
        record.setMemberFirstName("JOHN");
        record.setMemberMiddleName("PAUL");
        record.setMemberLastName("SMITH");
        record.setMemberSuffix("JR");
        record.setMemberNameTitle("MR");
        record.setMemberGender("M");
        record.setMemberDateOfBirth("11/01/1983");
        record.setMemberSocialSecurityNumber("111111111");
        record.setMemberMaritalStatusCode("yup");
        record.setMemberMaritalStatusDate("08/12/2005");
        record.setMedicareNumber("123");
        record.setMemberNickName1("JAY");
        record.setMemberNickName2("JP");
        record.setVisionPlanPatientId("01");
        record.setPreviousMedPlanPatientId("01");
        record.setCurrentMedPlanPatientId("01");
        record.setUpdatedByOperatorId("D845240");
        record.setMemberTobaccoUsageIndicator("Y");
        record.setCancelCode("N");
        record.setMemberEmployeeStatusInd("A");
        record.setMemberOverAgeCertifiedDate("11/02/2008");
        record.setMemberOverAgeDependentInd("N");
        record.setMemberRelationship("1");
        record.setMemberUpdatedDate("10/01/10");
        record.setMemberSetupDate("10/01/10");
        return record;
    }

    private class TestMemberStatusHistoryService implements MemberStatusHistoryService {
        @Override
        public MemberStatusHistoryOutput getMemberStatusHistory(MemberStatusHistoryInput arg0) {
            final MemberStatusHistoryOutput output = new MemberStatusHistoryOutput();
            final MemberStatusHistoryMemberStatusInformation[] memberStatusInformation = new MemberStatusHistoryMemberStatusInformation[2];

            memberStatusInformation[0] = new MemberStatusHistoryMemberStatusInformation();
            memberStatusInformation[0].setMemberNumber("MemberNumber1");
            memberStatusInformation[0].setRecordBeginDate("01/01/01");

            memberStatusInformation[1] = new MemberStatusHistoryMemberStatusInformation();
            memberStatusInformation[1].setMemberNumber("MemberNumber2");
            memberStatusInformation[1].setRecordBeginDate("02/02/02");

            output.getMemberStatusInformation().getMemberStatusHistoryMemberStatusInformation().addAll(Arrays.asList(memberStatusInformation));
            return output;
        }
    }
}
