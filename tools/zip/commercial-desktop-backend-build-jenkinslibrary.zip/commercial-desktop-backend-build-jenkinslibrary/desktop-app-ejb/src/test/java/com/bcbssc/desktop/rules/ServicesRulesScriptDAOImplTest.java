/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.rules;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.bcbssc.services.rulesinquiryexecutingscript.v1.RulesInquiryExecutingScript;
import junit.framework.TestCase;

import com.bcbssc.domain.entity.rules.RulesScriptRequest;
import com.bcbssc.domain.entity.rules.RulesScriptResponse;
import com.bcbssc.services.rulesinquiryexecutingscript.v1.ArgumentRow;
import com.bcbssc.services.rulesinquiryexecutingscript.v1.ArgumentRowChar;
import com.bcbssc.services.rulesinquiryexecutingscript.v1.ExecuteScriptResponse;
import com.bcbssc.services.rulesinquiryexecutingscript.v1.ResponseArgChar;
import com.bcbssc.services.rulesinquiryexecutingscript.v1.ResponseArgumentTableInfo;
import com.bcbssc.services.rulesinquiryexecutingscript.v1.RulesInquiryExecutingScript_Service;
import com.bcbssc.wsutils.exception.BcbsscDetailedSoapFaultException;
import com.bcbssc.wsutils.util.BcbsscFaultDetails;

/**
 * Tests
 */
public class ServicesRulesScriptDAOImplTest extends TestCase {
    private boolean throwException = false;

    /**
     * Tests
     */
    public void testExecuteRulesScript() {
        // this test needs to be redone when we get here
//        final TestServicesRulesScriptDAOImpl objectUnderTest = new TestServicesRulesScriptDAOImpl();
//        final RulesScriptRequest request = new RulesScriptRequest();
//        final Map<String, String> inputFields = new TreeMap<String, String>();
//        request.setRpn("rpn");
//        request.setScript("script");
//        request.setInputFields(inputFields);
//        inputFields.put("key1", "value1");
//        inputFields.put("key2", "value2");
//
//        final RulesScriptResponse response = objectUnderTest.executeRulesScript(request);
//        assertNotNull("Missing response", response);
//
//        final Map<String, List<String>> results = response.getOutputFields();
//        assertTrue("Missing result 1", results.containsKey("ReturnName1"));
//        assertEquals("ReturnCharacter1", results.get("ReturnName1").get(0));
//        assertTrue("Missing result 2", results.containsKey("ReturnName2"));
//        assertEquals("ReturnCharacter2", results.get("ReturnName2").get(0));
    }

    /**
     * Test with input and service exceptions.
     */
    public void testExecuteRulesScriptWithException() {
        // this test needs to be redone when we get here
//        final TestServicesRulesScriptDAOImpl objectUnderTest = new TestServicesRulesScriptDAOImpl();
//        final RulesScriptRequest request = new RulesScriptRequest();
//
//        boolean pass = false;
//        try {
//            objectUnderTest.executeRulesScript(null);
//        } catch (IllegalArgumentException e) {
//            assertEquals("Request must be supplied", e.getMessage());
//            pass = true;
//        }
//        assertTrue("Failed to throw IllegalArgumentException", pass);
//
//        pass = false;
//        try {
//            objectUnderTest.executeRulesScript(request);
//        } catch (IllegalArgumentException e) {
//            assertEquals("Request must contain at least one input field", e.getMessage());
//            pass = true;
//        }
//        assertTrue("Failed to throw IllegalArgumentException", pass);
//
//        final Map<String, String> inputFields = new TreeMap<String, String>();
//        request.setInputFields(inputFields);
//        inputFields.put("key1", "value1");
//        pass = false;
//        throwException = true;
//        try {
//            objectUnderTest.executeRulesScript(request);
//        } catch (BcbsscDetailedSoapFaultException bdsfe) {
//            assertEquals("Fault Message", bdsfe.getMessage());
//            assertEquals("ApplicationMessage", bdsfe.getFaultDetails().getApplicationMessage());
//            pass = true;
//        }
//        assertTrue("Failed to throw BcbsscDetailedSoapFaultException", pass);
    }

    /**
     * Extends the object under test to add testing hooks.
     */
    private class TestServicesRulesScriptDAOImpl extends ServicesRulesScriptDAOImpl {
        @Override
        protected RulesScriptConsumerCallback getWebServiceConsumerCallback() {
            return new RulesScriptConsumerCallback() {
                @Override
                public RulesInquiryExecutingScript getService() {
                    return new TestRulesInquiryExecutingScript();
                }

                @Override
                public Object mapInput(RulesScriptRequest domainInput) {
                    final Object returnObject = super.mapInput(domainInput);

                    if (!throwException) {
                        assertEquals("rpn", rpn);
                        assertEquals("script", script);
                        assertNotNull("Missing required input rows", argumentRow);
                        assertEquals("Incorrect number of input rows", 2, argumentRow.size());
                        assertNotNull("Missing input row 1", argumentRow.get(0));
                        ArgumentRowChar entry = argumentRow.get(0).getArgumentRowChar();
                        assertNotNull("Missing row entry 1", entry);
                        assertEquals("key1", entry.getArgumentName());
                        assertEquals("value1", entry.getArgumentCharacter());
                        assertNotNull("Missing input row 2", argumentRow.get(1));
                        entry = argumentRow.get(1).getArgumentRowChar();
                        assertNotNull("Missing row entry 2", entry);
                        assertEquals("key2", entry.getArgumentName());
                        assertEquals("value2", entry.getArgumentCharacter());
                    }

                    return returnObject;
                }
            };
        }
    }

    /**
     * Mock web service.
     */
    private class TestRulesInquiryExecutingScript implements RulesInquiryExecutingScript {
        @Override
        public ExecuteScriptResponse inquireRulesExecutingScript(String s, String s1, String s2, String s3, List<ArgumentRow> list) {
            if (throwException) {
                final BcbsscDetailedSoapFaultException faultException = new BcbsscDetailedSoapFaultException("Fault Message");
                final BcbsscFaultDetails faultDetails = new BcbsscFaultDetails();
                faultDetails.setApplicationMessage("ApplicationMessage");
                faultException.setFaultDetails(faultDetails);
                throw faultException;
            }

            final ExecuteScriptResponse output = new ExecuteScriptResponse();

            final ResponseArgumentTableInfo[] results = new ResponseArgumentTableInfo[2];
            ResponseArgChar entry = new ResponseArgChar();
            results[0] = new ResponseArgumentTableInfo();
            results[0].setResponseArgChar(entry);
            entry.setReturnName("ReturnName1");
            entry.setReturnCharacter("ReturnCharacter1");

            results[1] = new ResponseArgumentTableInfo();
            entry = new ResponseArgChar();
            results[1].setResponseArgChar(entry);
            entry.setReturnName("ReturnName2");
            entry.setReturnCharacter("ReturnCharacter2");

            output.getResponseArgumentTableInfo().addAll(Arrays.asList(results));
            return output;
        }
    }
}
