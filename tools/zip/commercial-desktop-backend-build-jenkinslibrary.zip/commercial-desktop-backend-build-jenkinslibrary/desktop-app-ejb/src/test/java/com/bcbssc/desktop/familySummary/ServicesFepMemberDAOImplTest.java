/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.familySummary;

import java.security.PrivilegedExceptionAction;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.security.auth.Subject;

import junit.framework.TestCase;

import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.Member;
import com.bcbssc.domain.entity.Subsystem;
import com.bcbssc.domain.entity.auth.RacfIdPrincipal;
import com.bcbssc.domain.entity.auth.RacfPasswordCredential;
import com.bcbssc.services.patientlistfep.PatientListFEPInput;
import com.bcbssc.services.patientlistfep.PatientListFEPOutput;
import com.bcbssc.services.patientlistfep.PatientListFEPPatientInformation;
import com.bcbssc.services.patientlistfep.PatientListFEPService;

/**
 * Test class for ServicesFepMemberDAOImpl
 *
 */
public class ServicesFepMemberDAOImplTest extends TestCase {

    private ServicesFepMemberDAOImpl objUnderTest;
    private Subject user;

    @Override
    protected void setUp() throws Exception {
        user = SubjectUtils.createEmptySubject();
        SubjectUtils.setUserId(user, RacfIdPrincipal.class, "TESTRACF");
        SubjectUtils.setPassword(user, RacfPasswordCredential.class, "PASSWORD");

        Map<String, Subsystem> rpns = new HashMap<String, Subsystem>();
        Subsystem rules = new Subsystem();
        rules.setRpn("001");
        rpns.put("CISI", rules);
        SubjectUtils.setRPNSubsystems(user, rpns);
    }

    /**
     *
     * Test method for getPatientList. See {@link ServicesFepMemberDAOImpl#getSubscriberMembers(String)}. 
     * @throws Exception
     */
    public void testPatientListFEP() throws Exception {

        objUnderTest = new ServicesFepMemberDAOImpl() {
            @Override
            protected Object getServiceObject() {
                return new TestPatientListFEPService();
            }

        };
        final String subscriberId = "R50733887";

        // this test needs to be updated when we get this far.
//        Set<Member> memberList = (Set<Member>) Subject.doAs(user, new PrivilegedExceptionAction() {
//            public Object run() throws Exception {
//                return objUnderTest.getSubscriberMembers(subscriberId);
//            }
//        });
//        assertNotNull(memberList);
//        Member member = memberList.iterator().next();
//        assertNotNull(member);
//        assertEquals("Birth date did not return the expected value", "1958-01-01", member.getBirthdate());
//        assertEquals("Member number did not return the expected value.", "1234", member.getMemberId());
//        assertEquals("Member first name did not return the expected value.", "firstName", member.getName().getFirstName());
//        assertEquals("Plan Code did not return the expected value.", "planCode", member.getPlanCode());

    }

    /**
     * Test PatientListFEPService class to return simulated service output.
     *

     */
    private class TestPatientListFEPService implements PatientListFEPService {

        public PatientListFEPOutput getPatientList(PatientListFEPInput input) {
            PatientListFEPOutput output = new PatientListFEPOutput();
            PatientListFEPPatientInformation patientInfo = new PatientListFEPPatientInformation();
            patientInfo.setFirstName("firstName");
            patientInfo.setGenderRelationshipCode("genderCode");
            patientInfo.setDateOfBirth("1958-01-01");
            output.setPlanCode("planCode");
            output.getPatientInformation().getPatientListFEPPatientInformation().add(patientInfo);
            return output;
        }
    }

}
