/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.events;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.EnvironmentBiz;
import com.bcbssc.desktop.biz.EnvironmentBizMock;
import com.bcbssc.desktop.testutils.mock.MockCacheWrapper;
import com.bcbssc.desktop.testutils.naming.SimpleInitialContextStubber;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;
import com.bcbssc.domain.entity.events.Event;
import com.bcbssc.domain.entity.events.EventsQueue;
import com.bcbssc.domain.entity.events.ResponseDataDTO;
import junit.framework.TestCase;

public class EventBizBDImplTest extends TestCase {
	private MockCacheWrapper mockCache;
	private SimpleInitialContextStubber jndi = new SimpleInitialContextStubber();

	@Override
	protected void setUp() throws Exception {
		mockCache = new MockCacheWrapper();
		DesktopAPI.setCacheWrapper(mockCache);

		EnvironmentBizMock environmentBiz = new EnvironmentBizMock();
		environmentBiz.environmentObjects.put(EnvironmentObjects.EVENT_REPORTING_POOL_SIZE, "2");
		jndi.bind("java:global/commercial-desktop-backend-ear/desktop-app-ejb/EnvironmentBizBDImpl!com.bcbssc.desktop.biz.EnvironmentBiz", environmentBiz);
	}

	@Override
	protected void tearDown() throws Exception {
		mockCache.clear();
		DesktopAPI.setCacheWrapper(null);

		jndi.shutDown();
	}

	/**
	 * Tests the path where we just save off the event in a temp queue.
	 */
	public void test_queued() throws Throwable {
		EventBizBDImpl biz = new EventBizBDImpl();
		ResponseDataDTO results = biz.sendEventAllowQueue(new Event(), null);

		assertEquals("event is queued", results.ResponseData);

		assertEquals(1, EventsQueue.savedOff.size());

		// Clean up the test.
		EventsQueue.savedOff.clear();
	}
}