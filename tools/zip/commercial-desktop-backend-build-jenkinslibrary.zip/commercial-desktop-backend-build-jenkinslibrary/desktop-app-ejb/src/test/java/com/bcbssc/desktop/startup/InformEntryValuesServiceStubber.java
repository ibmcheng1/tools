/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.startup;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import com.bcbssc.desktop.testutils.leds.ServiceOperationStubber;
import com.bcbssc.services.informentryvalues.InformEntryValuesInformEntry;
import com.bcbssc.services.informentryvalues.InformEntryValuesInput;
import com.bcbssc.services.informentryvalues.InformEntryValuesOutput;
import com.bcbssc.services.informentryvalues.InformEntryValuesService;

/**
 * Mock service handle.
 */
public class InformEntryValuesServiceStubber implements InformEntryValuesService {
	public ServiceOperationStubber<InformEntryValuesInput, InformEntryValuesOutput> operation;

	public InformEntryValuesServiceStubber() {
		operation = new ServiceOperationStubber<InformEntryValuesInput, InformEntryValuesOutput>(InformEntryValuesInput.class, InformEntryValuesOutput.class);
	}

	
	@Override
	public InformEntryValuesOutput getInformEntryValues(InformEntryValuesInput input) {
		return this.operation.invoke(input);
	}

	/**
	 * Helper function
	 */
	public static List<InformEntryValuesInformEntry> createEntries(String type, int amount) {
		List<InformEntryValuesInformEntry> entries = new ArrayList<>();
		for (int i = 0; i < amount; i++) { 
			entries.add(new InformEntryValuesInformEntry());
			entries.get(i).setEntryCode(type + "-code-" + i);
			entries.get(i).setEntryCodeDescription(type + "-description-" + i);
			entries.get(i).setEntryTypeDcnIndicator(type + "-dcn-indicator-" + i);
		}
		// Only in Java.
		return entries;
	}
}