/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2012 BLUECROSS BLUESHIELD OF SOUTH CAROLINA. ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.events;

import com.bcbssc.domain.entity.events.Event;

import junit.framework.TestCase;

public class EventDAOJmsImplTest extends TestCase {
    private static String EXPECTED_START = "EVMNA                                                                                                       00000                     Y0010000000000000                                                 RPN885BSIND20400DO002MBR                                        DATE      TIME                                             KEY01                                                                           0      HC005DATA01                                                                          CC805DATA02                                                                                                                                                                                                                                                                                                                                                                                                                                   CC260DATA10              CC261DATA11              CC262UA                  ";
    private static String EXPECTED_FAIL  = "EVMNA                                                                                                       00000                     Y0020000000000000 E                                               RPN885BSIND20450DO002MBR                                        DATE      TIME                                             KEY01                                                                                  *L001DATA01                                                                          *L002DATA02                                                                          *L003DATA03                                                      TYP04DATA04                        TYP05DATA05                                                                                                   TYP07DATA07                                                      TYP08DATA8ADATA8BDATA8CDATA8D                                                                  TYP11DATA11              TYP12DATA12              ";
    private static String EXPECTED_FINAL = "EVMNA                                                                                                       00000                     Y0010000000000000                                                 RPN885BSIND20410DO002MBR                                        DATE      TIME                                             KEY01                                                                           0      HC005DATA01                                                                          CC805DATA02                                                                                                                                                                                                                                                                                                                                                                                                                                   CC260DATA10              CC261DATA11              CC262UA                  ";

    /**
     * Tests <code>generateCopybookMessage</code> for a Start event.
     */
    public void testGenerateCopybookMessageForStartEvent() throws Throwable {
        final Event event = new Event();
        event.setMapName(Event.SUMMARY_BENEFITS_COVERAGE_START_MAPPINGS);
        event.setRpn("RPN");
        event.setData01("DATA01");
        event.setData02("DATA02");
        event.setData10("DATA10");
        event.setData11("DATA11");
        event.setKey01("KEY01");
        event.setDate("DATE");
        event.setTime("TIME");

        String message = EventDAOJmsImpl.generateCopybookMessage(event);
        assertEquals(message,EXPECTED_START);
    }
    
    /**
     * Tests <code>generateCopybookMessage</code> for a Start event.
     */
    public void testGenerateCopybookMessageForFinalEvent() throws Throwable {
        final Event event = new Event();
        event.setMapName(Event.SUMMARY_BENEFITS_COVERAGE_FINAL_MAPPINGS);
        event.setRpn("RPN");
        event.setData01("DATA01");
        event.setData02("DATA02");
        event.setData10("DATA10");
        event.setData11("DATA11");
        event.setKey01("KEY01");
        event.setDate("DATE");
        event.setTime("TIME");

        String message = EventDAOJmsImpl.generateCopybookMessage(event);
        assertEquals(message,EXPECTED_FINAL);
    }

    /**
     * Tests <code>generateCopybookMessage</code> for a Fail event.
     */
    public void testGenerateCopybookMessageForFailEvent() throws Throwable {
        final Event event = new Event();
        event.setMapName(Event.SUMMARY_BENEFITS_COVERAGE_FAIL_MAPPINGS);
        event.setRpn("RPN");
        event.setKey01("KEY01");
        event.setDate("DATE");
        event.setTime("TIME");
        event.setSequenceNumber("002");
        event.setData01("DATA01");
        event.setData02("DATA02");
        event.setData03("DATA03");
        event.setData04("DATA04");
        event.setData05("DATA05");
        event.setData07("DATA07");
        event.setData08a("DATA8A");
        event.setData08b("DATA8B");
        event.setData08c("DATA8C");
        event.setData08d("DATA8D");
        event.setData11("DATA11");
        event.setData12("DATA12");
        event.setTypeOf04("TYP04");
        event.setTypeOf05("TYP05");
        event.setTypeOf07("TYP07");
        event.setTypeOf08("TYP08");
        event.setTypeOf11("TYP11");
        event.setTypeOf12("TYP12");
        event.setLastRecordIndicator("E");

        String message = EventDAOJmsImpl.generateCopybookMessage(event);
        assertEquals(message, EXPECTED_FAIL);
    }
}
