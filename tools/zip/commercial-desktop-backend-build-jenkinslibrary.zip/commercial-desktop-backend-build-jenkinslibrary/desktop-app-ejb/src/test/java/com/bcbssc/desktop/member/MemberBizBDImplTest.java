/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.member;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.security.auth.Subject;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.testutils.mock.MockCacheWrapper;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.Member;
import com.bcbssc.domain.valueobject.MenuLink;

import junit.framework.TestCase;

public class MemberBizBDImplTest extends TestCase {
	private Subject user;

	@Override
	protected void setUp() throws Exception {
		MockCacheWrapper mockCache = new MockCacheWrapper();
		DesktopAPI.setCacheWrapper(mockCache);

		user = SubjectUtils.createEmptySubject();

		HashMap<String, Object> rules = new HashMap<String, Object>();
		rules.put(MenuLink.FUNCTION_TYPE_USERCONFIG, new HashMap<String, MenuLink>());
		DesktopAPI.setRulesEntries(user, rules);
	}

	@Override
	protected void tearDown() throws Exception {
		DesktopAPI.setCacheWrapper(null);
	}

	public void test_retrievePatientList() throws Throwable {
	    // this test appears to have a lot of dependencies, needs some thought/rework.
//		DesktopAPI.getCacheDataStore(user).clear();
//
//		MemberBizBDImpl biz = new MemberBizBDImpl();
//		ServicesPatientListDAOImpl dao = new ServicesPatientListDAOImpl();
//		dao.setService(new PatientListServiceMock());
//		biz.patientDAO = dao;
//
//
//		List<Member> results = biz.retrievePatientList("999574317", user);
//		assertEquals(4, results.size());
//
//		final Member firstMember = results.get(0);
//		assertEquals("885", firstMember.getPlanCode());
//		assertEquals("MICHAEL", firstMember.getName().getFirstName());
//		assertEquals("TESTING", firstMember.getName().getLastName());
//		assertEquals("001", firstMember.getMemberId());
//		assertEquals("01", firstMember.getCesMemberNumber());
//		assertEquals("Y", firstMember.getVerifiedPatientIndicator());
//		assertEquals("SUBSCRIBER", firstMember.getRelationship().getDescription());
//		assertEquals("MALE", firstMember.getSex().getDescription());
//		try {
//			assertEquals(new SimpleDateFormat("MM/dd/yyyy").parse("12/12/2012"), firstMember.getDateOfBirth());
//		} catch (ParseException e) {
//			fail("Exception thrown");
//		}
	}

	public void test_retrievePatientListFilter() throws Throwable {
        // this test appears to have a lot of dependencies, needs some thought/rework.
//		DesktopAPI.getCacheDataStore(user).clear();
//
//		MemberBizBDImpl biz = new MemberBizBDImpl();
//		ServicesPatientListDAOImpl dao = new ServicesPatientListDAOImpl();
//		dao.setService(new PatientListServiceMock());
//		biz.patientDAO = dao;
//
//		List<Member> results = biz.retrievePatientListFilter("999574317", "885", user);
//		assertEquals(2, results.size());
//		for (Member m : results) {
//			assertEquals("885", m.getPlanCode());
//		}
	}

	public void test_basic_caching() throws Throwable {
        // this test appears to have a lot of dependencies, needs some thought/rework.
//		DesktopAPI.getCacheDataStore(user).clear();
//
//		MemberBizBDImpl biz = new MemberBizBDImpl();
//		PatientListServiceMock service = new PatientListServiceMock();
//		ServicesPatientListDAOImpl dao = new ServicesPatientListDAOImpl();
//		dao.setService(service);
//		biz.patientDAO = dao;
//
//
//		int maxHit = dao.getMaxHitCount();
//
//		for (int i = 0; i < maxHit+3; i++) {
//			List<Member> results = biz.retrievePatientListFilter("999574317", "885", user);
//			assertEquals(2, results.size());
//			for (Member m : results) {
//				assertEquals("885", m.getPlanCode());
//			}
//			if (i < maxHit) {
//				assertEquals(1, service.callCount);
//			} else {
//				assertEquals(2, service.callCount);
//			}
//		}
	}

	public void test_compare_cache() throws Throwable {
        // this test appears to have a lot of dependencies, needs some thought/rework.
//		final int MAX = 5;
//		DesktopAPI.getCacheDataStore(user).clear();
//
//		MemberBizBDImpl biz = new MemberBizBDImpl();
//		PatientListServiceMock service = new PatientListServiceMock();
//		ServicesPatientListDAOImpl dao = new ServicesPatientListDAOImpl();
//		dao.maxHit = 1000;
//		dao.setService(service);
//		biz.patientDAO = dao;
//
//		Thread[] threads = new Thread[MAX];
//		long startTime = new Date().getTime();
//		for(int i = 0; i < MAX; i++) {
//			threads[i] = new Thread(new MyRunner(biz));
//			threads[i].start();
//		}
//		for (int i = 0; i < MAX; i++) {
//			threads[i].join();
//		}
//		for(int i = 0; i < MAX; i++) {
//			threads[i] = new Thread(new MyRunner(biz));
//			threads[i].start();
//		}
//		for (int i = 0; i < MAX; i++) {
//			threads[i].join();
//		}
//		for (int i = 0; i < MAX; i++) {
//			biz.retrievePatientListFilter("999574317", "885", user);
//		}
//		long endTime = new Date().getTime();
//		long cacheTime = endTime - startTime;
//		int cacheCount = service.callCount;
//		System.out.println("cache time - " + cacheTime);
//		System.out.println("cache count - " + cacheCount);
	}

	public void test_compare_noncache() throws Throwable {
        // this test appears to have a lot of dependencies, needs some thought/rework.
//		final int MAX = 5;
//		DesktopAPI.getCacheDataStore(user).clear();
//
//		MemberBizBDImpl biz = new MemberBizBDImpl();
//		PatientListServiceMock service = new PatientListServiceMock();
//		PatientListDaoNoCache otherDao = new PatientListDaoNoCache();
//		otherDao.setService(service);
//		biz.patientDAO = otherDao;
//
//		Thread[] threads = new Thread[MAX];
//		long startTime = new Date().getTime();
//		for(int i = 0; i < MAX; i++) {
//			threads[i] = new Thread(new MyRunner(biz));
//			threads[i].start();
//		}
//		for (int i = 0; i < MAX; i++) {
//			threads[i].join();
//		}
//		for(int i = 0; i < MAX; i++) {
//			threads[i] = new Thread(new MyRunner(biz));
//			threads[i].start();
//		}
//		for (int i = 0; i < MAX; i++) {
//			threads[i].join();
//		}
//		for (int i = 0; i < MAX; i++) {
//			biz.retrievePatientListFilter("999574317", "885", user);
//		}
//		long endTime = new Date().getTime();
//		long noCacheTime = endTime - startTime;
//		int noCacheCount = service.callCount;
//		System.out.println("non cache time - " + noCacheTime);
//		System.out.println("non cache count - " + noCacheCount);
	}

	private class MyRunner implements Runnable {
		public MemberBizBDImpl biz;

		public MyRunner(MemberBizBDImpl biz) {
			this.biz = biz;
		}

		@Override
		public void run() {
			try {
				this.biz.retrievePatientListFilter("999574317", "885", user);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
	}
}