/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.startup;

import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.security.auth.Subject;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.EnvironmentBizMock;
import com.bcbssc.desktop.testutils.mock.MockCacheWrapper;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.valueobject.MenuConfiguration;

import junit.framework.TestCase;

/**
 * Unit tests for the RulesCacheRefreshBizBDImpl class
 *
 * @author jc33
 */
public class RulesCacheRefreshBizBDImplTest extends TestCase {
    @Override
    protected void setUp() throws Exception {
        final MockCacheWrapper mockCache = new MockCacheWrapper();
        DesktopAPI.setCacheWrapper(mockCache);
    }

    @Override
    protected void tearDown() throws Exception {
        DesktopAPI.setCacheWrapper(null);
    }

    /**
     * Test method for
     */
    public void testRefreshCachedData() throws Throwable {
        // this test needs to be redone when we get there
        //        TestRulesCacheRefreshBiz biz = new TestRulesCacheRefreshBiz();
        //        biz.refreshCachedData();
        //
        //        assertEquals("the number of entries stored was not what was expected", 9, biz.getStoreCount());
    }

    /**
     * Test method for
     */
    public void testRefreshCachedDataWithNoData() throws Throwable {
        final TestRulesCacheRefreshBiz biz = new TestRulesCacheRefreshBiz();
        biz.refreshCachedData();

        assertEquals("the number of entries stored was not what was expected", 0, biz.getStoreCount());
    }

    /**
     * Test method for
     * @throws Exception Should not throw an exception
     */
    public void testExtractConfig() throws Throwable {
        final RulesCacheRefreshBizBDImpl impl = new RulesCacheRefreshBizBDImpl();
        final MenuConfiguration config = impl.extractConfig("CSR_001_BCBSSC_3_44_916_DVOST1RULES");
        assertNotNull(config);
        assertEquals("The application id did not match", "CSR", config.getApplicationId());
        assertEquals("The RPN did not match", "001", config.getAltRpn());
        assertEquals("The client id did not match", "BCBSSC", config.getClientId());
        assertEquals("The company code did not match", "3", config.getCompanyCode());
        assertEquals("The division code did not match", "44", config.getDivisionCode());
        assertEquals("The department code did not match", "916", config.getDepartmentCode());
        assertEquals("The region did not match", "DVOST1", config.getDefaultRegion());
    }

    /**
     * Test method for
     */
    public void testGetRefreshRequests() throws Throwable {
        final RulesCacheRefreshBizBDImpl impl = new RulesCacheRefreshBizBDImpl();
        final List<String> requests = impl.getRefreshRequests(getKeys());
        assertNotNull("The requests list was null", requests);
        assertEquals("The size of the requests list was not what was expected", 9, requests.size());
    }

    private Set<String> getKeys() {
        final Set<String> keys = new TreeSet<String>();
        // should be processed
        keys.add("CSR_001_BCBSSC_3_44_916_DVOST1RULES");
        keys.add("CSR_001_CDL_3_44_916_DVOST1RULES");
        keys.add("CSR_001_FEP_3_44_916_DVOST1RULES");
        keys.add("CSR_006_BMED_3_44_916_DVOST1RULES");
        keys.add("CSR_035_CHC_3_44_916_DVOST1RULES");
        keys.add("CSR_037_FCL_3_44_916_DVOST1RULES");
        keys.add("CSR_100_DSRT_3_44_916_DVOST1RULES");
        keys.add("CSR_101_MICH_3_44_916_DVOST1RULES");
        keys.add("CSR_103_HLNT_3_44_916_DVOST1RULES");
        // should not be processed
        keys.add("CSR_001_BCBSSC_3_44_916_DVOST1RUILES");
        keys.add("Z!KJDJUBV938947NV8NSJH%$");
        keys.add("RULESCSR_001_BCBSSC_3_44_916_DVOST1");
        return keys;
    }

    private class TestRulesCacheRefreshBiz extends RulesCacheRefreshBizBDImpl {

        private int storeCount = 0;

        public TestRulesCacheRefreshBiz() {
            final EnvironmentBizMock biz = new EnvironmentBizMock();
            biz.environments.put("JUNIT", Boolean.TRUE);
            environmentBiz = biz;
        }

        @Override
        protected boolean initialize() {
            /*
             * Don't need to do anything, just preventing the attempt at initializing the timer
             */
            return true;
        }

        @Override
        protected void storeRuleData(HashMap<String, ?> menuLinks, MenuConfiguration config) {
            storeCount++;
        }

        @Override
        protected Subject getSubject(String environment) throws Exception {
            return SubjectUtils.createEmptySubject();
        }

        @Override
        protected HashMap<String, ?> getRuleMenuLinks(MenuConfiguration config, Subject subject) throws Exception {
            final HashMap<String, Object> menuLinks = new HashMap<String, Object>();
            menuLinks.put("TEST", "Value1");
            return menuLinks;
        }

        /**
         * @return the storeCount
         */
        public int getStoreCount() {
            return storeCount;
        }

    }

}
