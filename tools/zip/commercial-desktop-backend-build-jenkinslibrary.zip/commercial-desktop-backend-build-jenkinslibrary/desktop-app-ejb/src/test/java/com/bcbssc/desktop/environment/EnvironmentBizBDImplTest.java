/*
 * Copyright (C) 2012 BlueCross BlueShield of South Carolina, all rights reserved.
 *
 * This software is the confidential and proprietary property of
 * BlueCross BlueShield of South Carolina ("Confidential Information").
 * Any unauthorized use or reproduction is strictly prohibited.
 */
package com.bcbssc.desktop.environment;

import javax.security.auth.Subject;

import junit.framework.TestCase;

import com.bcbssc.desktop.testutils.mock.MockEnvironmentDAOImpl;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;

/**
 * Tests {@link EnvironmentBizBDImpl}.
 *
 * @author X87M
 */
public class EnvironmentBizBDImplTest extends TestCase {
    /**
     * Tests the default value logic.
     */
    public void testDefault() {
        Subject subject = SubjectUtils.createEmptySubject();
        SubjectUtils.setRegion(subject, "DVOST1");

        MockEnvironmentDAOImpl dao = new MockEnvironmentDAOImpl();

        EnvironmentBizBDImpl biz = new EnvironmentBizBDImpl();
        biz.setEnvironmentDao(dao);

        Boolean result = biz.get(EnvironmentObjects.MULTIREGION_ENABLED, Boolean.class, subject);

        assertEquals(EnvironmentObjects.MULTIREGION_ENABLED.getDefaultValue(), result);
    }

    /**
     * Tests the general use of the Biz.
     */
    public void testGet() {
        Subject subject = SubjectUtils.createEmptySubject();
        SubjectUtils.setRegion(subject, "DVOST1");

        MockEnvironmentDAOImpl dao = new MockEnvironmentDAOImpl();
        dao.setObject(EnvironmentObjects.REGION_DEFAULT, "foo");

        EnvironmentBizBDImpl biz = new EnvironmentBizBDImpl();
        biz.setEnvironmentDao(dao);

        String result = biz.get(EnvironmentObjects.REGION_DEFAULT, String.class, subject);
        assertEquals("foo", result);
    }

    /**
     * Tests the general use of the Biz.
     */
    public void testIsDefined() {
        Subject subject = SubjectUtils.createEmptySubject();
        SubjectUtils.setRegion(subject, "DVOST1");

        MockEnvironmentDAOImpl dao = new MockEnvironmentDAOImpl();

        EnvironmentBizBDImpl biz = new EnvironmentBizBDImpl();
        biz.setEnvironmentDao(dao);

        boolean result = biz.isDefined(EnvironmentObjects.REGION_DEFAULT, subject);
        assertEquals(false, result);
    }

    /**
     * Tests the general use of the Biz.
     */
    public void testGetCommon() {
        MockEnvironmentDAOImpl dao = new MockEnvironmentDAOImpl();
        dao.setObject(EnvironmentObjects.ENROLLMENT_AUDIT_SUCCESS_PATH, "success");

        EnvironmentBizBDImpl biz = new EnvironmentBizBDImpl();
        biz.setEnvironmentDao(dao);

        String result = biz.getCommon(EnvironmentObjects.ENROLLMENT_AUDIT_SUCCESS_PATH, String.class);
        assertEquals("success", result);
    }

    /**
     * Tests exception is thrown when class is cast to wrong type is provided.
     */
    public void testGetCommonClassCastException() {
        MockEnvironmentDAOImpl dao = new MockEnvironmentDAOImpl();
        dao.setObject(EnvironmentObjects.ENROLLMENT_AUDIT_SUCCESS_PATH, "success");

        EnvironmentBizBDImpl biz = new EnvironmentBizBDImpl();
        biz.setEnvironmentDao(dao);

        boolean exceptionThrown = false;
        try {
            Integer result = biz.getCommon(EnvironmentObjects.ENROLLMENT_AUDIT_SUCCESS_PATH, Integer.class);
        } catch (ClassCastException e) {
            exceptionThrown = true;
        }
        assertEquals(exceptionThrown, true);
    }

    /**
     * Tests exception is thrown when null enum is provided.
     */
    public void testGetCommonNullEnumException() {
        MockEnvironmentDAOImpl dao = new MockEnvironmentDAOImpl();

        EnvironmentBizBDImpl biz = new EnvironmentBizBDImpl();
        biz.setEnvironmentDao(dao);

        boolean exceptionThrown = false;
        try {
            String result = biz.getCommon(null, String.class);
        } catch (IllegalArgumentException e) {
            exceptionThrown = true;
        }
        assertEquals(exceptionThrown, true);
    }

    /**
     * Tests exception is thrown when null class is provided.
     */
    public void testGetCommonNullClassException() {
        MockEnvironmentDAOImpl dao = new MockEnvironmentDAOImpl();

        EnvironmentBizBDImpl biz = new EnvironmentBizBDImpl();
        biz.setEnvironmentDao(dao);

        boolean exceptionThrown = false;
        try {
            String result = biz.getCommon(EnvironmentObjects.ENROLLMENT_AUDIT_SUCCESS_PATH, null);
        } catch (IllegalArgumentException e) {
            exceptionThrown = true;
        }
        assertEquals(exceptionThrown, true);
    }
    
    /**
     * Tests exception is thrown when null enum is provided.
     */
    public void testGetNullEnumException() {
        Subject subject = SubjectUtils.createEmptySubject();
        SubjectUtils.setRegion(subject, "DVOST1");

        MockEnvironmentDAOImpl dao = new MockEnvironmentDAOImpl();

        EnvironmentBizBDImpl biz = new EnvironmentBizBDImpl();
        biz.setEnvironmentDao(dao);

        boolean exceptionThrown = false;
        try {
            String result = biz.get(null, String.class, subject);
        } catch (IllegalArgumentException e) {
            exceptionThrown = true;
        }
        assertEquals(exceptionThrown, true);
    }
    
    /**
     * Tests exception is thrown when null class is provided.
     */
    public void testGetNullClassException() {
        Subject subject = SubjectUtils.createEmptySubject();
        SubjectUtils.setRegion(subject, "DVOST1");

        MockEnvironmentDAOImpl dao = new MockEnvironmentDAOImpl();

        EnvironmentBizBDImpl biz = new EnvironmentBizBDImpl();
        biz.setEnvironmentDao(dao);

        boolean exceptionThrown = false;
        try {
            String result = biz.get(EnvironmentObjects.REGION_DEFAULT, null, subject);
        } catch (IllegalArgumentException e) {
            exceptionThrown = true;
        }
        assertEquals(exceptionThrown, true);
    }
    
    /**
     * Tests exception is thrown when null subject is provided.
     */
    public void testGetNullSubjectException() {
        Subject subject = SubjectUtils.createEmptySubject();
        SubjectUtils.setRegion(subject, "DVOST1");

        MockEnvironmentDAOImpl dao = new MockEnvironmentDAOImpl();

        EnvironmentBizBDImpl biz = new EnvironmentBizBDImpl();
        biz.setEnvironmentDao(dao);

        boolean exceptionThrown = false;
        try {
            String result = biz.get(EnvironmentObjects.REGION_DEFAULT, String.class, null);
        } catch (IllegalArgumentException e) {
            exceptionThrown = true;
        }
        assertEquals(exceptionThrown, true);
    }
    
    /**
     * Tests exception is thrown when null enum is provided.
     */
    public void testIsDefinedNullEnum() {
        Subject subject = SubjectUtils.createEmptySubject();
        SubjectUtils.setRegion(subject, "DVOST1");

        MockEnvironmentDAOImpl dao = new MockEnvironmentDAOImpl();

        EnvironmentBizBDImpl biz = new EnvironmentBizBDImpl();
        biz.setEnvironmentDao(dao);
        
        boolean exceptionThrown = false;
        try {
            boolean result = biz.isDefined(null, subject);
        } catch (IllegalArgumentException e) {
            exceptionThrown = true;
        }
        assertEquals(exceptionThrown, true);
    }
    
    /**
     * Tests exception is thrown when null subject is provided.
     */
    public void testIsDefinedNullSubject() {
        Subject subject = SubjectUtils.createEmptySubject();
        SubjectUtils.setRegion(subject, "DVOST1");

        MockEnvironmentDAOImpl dao = new MockEnvironmentDAOImpl();

        EnvironmentBizBDImpl biz = new EnvironmentBizBDImpl();
        biz.setEnvironmentDao(dao);
        
        boolean exceptionThrown = false;
        try {
            boolean result = biz.isDefined(EnvironmentObjects.REGION_DEFAULT, null);
        } catch (IllegalArgumentException e) {
            exceptionThrown = true;
        }
        assertEquals(exceptionThrown, true);
    }
}
