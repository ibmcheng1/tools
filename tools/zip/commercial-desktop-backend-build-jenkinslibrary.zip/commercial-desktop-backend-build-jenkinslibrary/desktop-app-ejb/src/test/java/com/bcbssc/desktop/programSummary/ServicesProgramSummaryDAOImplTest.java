/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.programSummary;

import java.security.PrivilegedExceptionAction;
import java.util.Arrays;
import java.util.Vector;

import javax.security.auth.Subject;

import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.ApplicationClient;
import com.bcbssc.domain.entity.managed.ProgramDetail;
import com.bcbssc.domain.entity.managed.ProgramSummary;
import com.bcbssc.domain.entity.managed.ProgramSummarySearchCriteria;
import com.bcbssc.services.programsummaryinfo.ProgramSummaryInfoInput;
import com.bcbssc.services.programsummaryinfo.ProgramSummaryInfoOutput;
import com.bcbssc.services.programsummaryinfo.ProgramSummaryInfoProgramSummaryInfo;
import com.bcbssc.services.programsummaryinfo.ProgramSummaryInfoService;
import com.bcbssc.wsutils.exception.BcbsscDetailedSoapFaultException;
import com.bcbssc.wsutils.util.BcbsscFaultDetails;

import junit.framework.TestCase;

/**
 * Test for {@link ServicesProgramSummaryDAOImpl}.
 */
public class ServicesProgramSummaryDAOImplTest extends TestCase {
    Subject user;

    @Override
    protected void setUp() throws Exception {
        user = SubjectUtils.createEmptySubject();

        final ApplicationClient client = new ApplicationClient();
        client.setAliasRpn("aliasRpn");
        client.setPlanCode("planCode");
        SubjectUtils.setClient(user, client);

        super.setUp();
    }

    /**
     * Tests
     */
    public void testFindBySubscriber() throws Throwable {
        // This test needs to be redone when
//        final ServicesProgramSummaryDAOImpl objectUnderTest = new ServicesProgramSummaryDAOImpl() {
//            @Override
//            protected ProgramSummaryInfoService getServiceProgramInfo() {
//                return new TestProgramSummaryInfoService();
//            }
//
//            @Override
//            protected ProgramSummaryServiceConsumer getWebServiceConsumerCallback(ProgramSummarySearchCriteria searchCriteria) {
//                return new ProgramSummaryServiceConsumer(searchCriteria) {
//                    @Override
//                    public Object mapInput(Object unused) {
//                        final ProgramSummaryInfoInput input = (ProgramSummaryInfoInput) super.mapInput(unused);
//                        assertEquals("N", input.getEligibilityIndicator());
//                        assertEquals("Y", input.getEnrollmentIndicator());
//                        assertNull(input.getHistoryIndicator());
//                        assertEquals("aliasRpn", input.getRpn());
//                        assertEquals("planCode", input.getPlanCode());
//                        assertEquals("patientId", input.getPatientId());
//                        assertEquals("subscriberId", input.getSponsorId());
//                        return input;
//                    }
//                };
//            }
//        };
//
//        final ProgramSummarySearchCriteria criteria = new ProgramSummarySearchCriteria();
//        criteria.setSubscriberId("subscriberId");
//        criteria.setPatientId("patientId");
//        criteria.setEligibilityIndicator(false);
//        criteria.setEnrollmentIndicator(true);
//
//        ProgramSummary results = null;
//
//        results = Subject.doAs(user, new PrivilegedExceptionAction<ProgramSummary>() {
//            public ProgramSummary run() throws Exception {
//                return objectUnderTest.findBySubscriber(criteria);
//            }
//        });
//
//
//        assertNotNull("Missing results", results);
//        assertEquals("PatientName", results.getPatientName());
//        assertEquals("CaseManagementInd", results.getManagementStatus("CM"));
//        assertEquals("DiseaseManagementInd", results.getManagementStatus("DM"));
//        assertEquals("MaternityManagementInd", results.getManagementStatus("MM"));
//        assertEquals("WellnessManagementInd", results.getManagementStatus("WM"));
//        assertNotNull("Missing programs", results.getPrograms());
//        assertEquals("Incorrect number of programs", 2, results.getPrograms().size());
//
//        Vector vector = (Vector) results.getPrograms().get(0);
//        assertEquals("Incorrect number of program details", 2, vector.size());
//        ProgramDetail programDetail = (ProgramDetail) vector.get(0);
//        assertEquals("MedicalManagementtArea1", programDetail.getManagementName());
//        assertEquals("ProgramName1a", programDetail.getProgramName());
//        programDetail = (ProgramDetail) vector.get(1);
//        assertEquals("MedicalManagementtArea1", programDetail.getManagementName());
//        assertEquals("ProgramName1b", programDetail.getProgramName());
//
//        vector = (Vector) results.getPrograms().get(1);
//        assertEquals("Incorrect number of program details", 1, vector.size());
//        programDetail = (ProgramDetail) vector.get(0);
//        assertEquals("MedicalManagementtArea2", programDetail.getManagementName());
//        assertEquals("ProgramName2", programDetail.getProgramName());
    }

    /**
     * Test with input and service exceptions.
     */
    public void testFindBySubscriberWithExceptions() throws Throwable {
        // this test needs to be redone when we get there
//        final ServicesProgramSummaryDAOImpl objectUnderTest = new ServicesProgramSummaryDAOImpl() {
//            @Override
//            protected ProgramSummaryInfoService getServiceProgramInfo() {
//                return new TestProgramSummaryInfoServiceWithException();
//            }
//        };
//
//        final ProgramSummarySearchCriteria criteria = new ProgramSummarySearchCriteria();
//        boolean pass = false;
//        try {
//            Subject.doAs(user, new PrivilegedExceptionAction<ProgramSummary>() {
//                public ProgramSummary run() throws Exception {
//                    return objectUnderTest.findBySubscriber(criteria);
//                }
//            });
//        } catch (IllegalArgumentException e) {
//            pass = true;
//            assertEquals("Subscriber ID is required", e.getMessage());
//        }
//        assertTrue("Excpected IllegalArgumentException not thrown", pass);
//
//        criteria.setSubscriberId("subscriberId");
//        criteria.setPatientId("patientId");
//        pass = false;
//        try {
//            Subject.doAs(user, new PrivilegedExceptionAction<ProgramSummary>() {
//                public ProgramSummary run() throws Exception {
//                    return objectUnderTest.findBySubscriber(criteria);
//                }
//            });
//        } catch (BcbsscDetailedSoapFaultException bdsfe) {
//            pass = true;
//            assertEquals("Fault Message", bdsfe.getMessage());
//            assertEquals("ApplicationMessage", bdsfe.getFaultDetails().getApplicationMessage());
//        }
//        assertTrue("Excpected BcbsscDetailedSoapFaultException not thrown", pass);
    }

    /**
     * Mock service.
     */
    private class TestProgramSummaryInfoService implements ProgramSummaryInfoService {
        public ProgramSummaryInfoOutput getProgramSummary(ProgramSummaryInfoInput arg0) {
            final ProgramSummaryInfoOutput output = new ProgramSummaryInfoOutput();
            output.setPatientName("PatientName");
            output.setCaseManagementInd("CaseManagementInd");
            output.setDiseaseManagementInd("DiseaseManagementInd");
            output.setMaternityManagementInd("MaternityManagementInd");
            output.setWellnessManagementInd("WellnessManagementInd");

            final ProgramSummaryInfoProgramSummaryInfo[] records = new ProgramSummaryInfoProgramSummaryInfo[3];
            records[0] = new ProgramSummaryInfoProgramSummaryInfo();
            records[0].setMedicalManagementtArea("MedicalManagementtArea1");
            records[0].setProgramName("ProgramName1a");

            records[1] = new ProgramSummaryInfoProgramSummaryInfo();
            records[1].setMedicalManagementtArea("MedicalManagementtArea2");
            records[1].setProgramName("ProgramName2");

            records[2] = new ProgramSummaryInfoProgramSummaryInfo();
            records[2].setMedicalManagementtArea("MedicalManagementtArea1");
            records[2].setProgramName("ProgramName1b");

            output.getProgramSummaryInfo().getProgramSummaryInfoProgramSummaryInfo().addAll(Arrays.asList(records));
            return output;
        }
    }

    /**
     * Mock service that throws an exception.
     */
    private class TestProgramSummaryInfoServiceWithException implements ProgramSummaryInfoService {
        public ProgramSummaryInfoOutput getProgramSummary(ProgramSummaryInfoInput arg0) {
            BcbsscDetailedSoapFaultException faultException = new BcbsscDetailedSoapFaultException("Fault Message");
            BcbsscFaultDetails faultDetails = new BcbsscFaultDetails();
            faultDetails.setApplicationMessage("ApplicationMessage");
            faultException.setFaultDetails(faultDetails);
            throw faultException;
        }
    }
}
