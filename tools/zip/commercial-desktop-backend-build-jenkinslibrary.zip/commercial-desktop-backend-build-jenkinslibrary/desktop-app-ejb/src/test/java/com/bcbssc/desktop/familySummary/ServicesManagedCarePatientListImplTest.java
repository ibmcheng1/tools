/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.familySummary;

import java.rmi.RemoteException;
import java.security.PrivilegedExceptionAction;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.security.auth.Subject;

import junit.framework.TestCase;

import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.Member;
import com.bcbssc.domain.entity.Subsystem;
import com.bcbssc.domain.entity.auth.RacfIdPrincipal;
import com.bcbssc.domain.entity.auth.RacfPasswordCredential;
import com.bcbssc.services.managedcarepatientlist.ManagedCarePatientListInput;
import com.bcbssc.services.managedcarepatientlist.ManagedCarePatientListOutput;
import com.bcbssc.services.managedcarepatientlist.ManagedCarePatientListPatientRecord;
import com.bcbssc.services.managedcarepatientlist.ManagedCarePatientListService;

/**
 * Test class for ServicesManagedCarePatientListImpl
 *
 */
public class ServicesManagedCarePatientListImplTest extends TestCase {

    private ServicesManagedCarePatientListImpl objUnderTest;
    private Subject user;

    @Override
    protected void setUp() throws Exception {
        user = SubjectUtils.createEmptySubject();
        SubjectUtils.setUserId(user, RacfIdPrincipal.class, "TESTRACF");
        SubjectUtils.setPassword(user, RacfPasswordCredential.class, "PASSWORD");

        Map<String, Subsystem> rpns = new HashMap<String, Subsystem>();
        Subsystem rules = new Subsystem();
        rules.setRpn("001");
        rpns.put("TMCS", rules);
        SubjectUtils.setRPNSubsystems(user, rpns);

        objUnderTest = new ServicesManagedCarePatientListImpl() {
            @Override
            protected ManagedCarePatientListService getManagedCarePatientListService() {
                return new TestManagedCarePatientListService();
            }

        };
    }

    /**
     * Test method for getManagedCarePatientList. See {@link ServicesManagedCarePatientListImpl#getSubscriberMembers(String)}.
     * @throws Exception
     */
    public void testManagedCarePatientList() throws Exception {

        // this test needs to be reimplemented when we get there.

//        final String subscriberId = "999574317";
//
//        Set<Member> paiMemberList = (Set<Member>) Subject.doAs(user, new PrivilegedExceptionAction() {
//            public Object run() throws Exception {
//                return objUnderTest.getSubscriberMembers(subscriberId);
//            }
//        });
//        assertNotNull(paiMemberList);
//        Member member = paiMemberList.iterator().next();
//        assertNotNull(member);
//        assertEquals("Birth date did not return the expected value","1958-01-01",member.getBirthdate());
//        assertEquals("Patient Id did not return the expected value.", "1234", member.getMemberId());
//        assertEquals("Patient first name did not return the expected value.", "firstName", member.getName().getFirstName());

    }

    /**
     * Test ManagedCarePatientListService class to return simulated service output.
     *
     */
    private class TestManagedCarePatientListService implements ManagedCarePatientListService {

        @Override
        public ManagedCarePatientListOutput getManagedCarePatientList(ManagedCarePatientListInput arg0) {
            ManagedCarePatientListOutput output = new ManagedCarePatientListOutput();
            ManagedCarePatientListPatientRecord patientRecord = new ManagedCarePatientListPatientRecord();
            ManagedCarePatientListPatientRecord[] patientRecordArray = new ManagedCarePatientListPatientRecord[1];
            patientRecord.setPatientId("1234");
            patientRecord.setPatientName("firstName");
            patientRecord.setPatientGenderAndRltnshpCd("genderCode");
            patientRecord.setPatientDateOfBirth("1958-01-01");
            patientRecordArray[0] = patientRecord;
            output.getPatientRecord().getManagedCarePatientListPatientRecord().addAll(Arrays.asList(patientRecordArray));
            return output;
        }

    }

}
