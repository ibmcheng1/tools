package com.bcbssc.desktop.translations;

import java.util.HashMap;
import java.util.Map;

import com.bcbssc.desktop.dao.TranslationLookupDAO;

public class TranslationLookupDAOMock implements TranslationLookupDAO {
	private Map<String, Map<String, String>> data;

	public TranslationLookupDAOMock() {
		this.data = new HashMap<String, Map<String, String>>();
		this.data.put(FIELD_ID_RELATIONSHIP, new HashMap<String, String>());
		this.data.get(FIELD_ID_RELATIONSHIP).put("1", "SUBSCRIBER");
		this.data.get(FIELD_ID_RELATIONSHIP).put("2", "SPOUSE");
		this.data.get(FIELD_ID_RELATIONSHIP).put("3", "DEPENDENT");
		this.data.get(FIELD_ID_RELATIONSHIP).put("4", "WARD");
		this.data.get(FIELD_ID_RELATIONSHIP).put("5", "OTHR DEP");

		this.data.put(FIELD_ID_DEPENDENT_INDICATOR, new HashMap<String, String>());
		this.data.get(FIELD_ID_DEPENDENT_INDICATOR).put("?", "???");
	}

	@Override
	public String lookupTranslation(String fieldID, String key) throws Exception {
		return this.data.get(fieldID).get(key);
	}
}