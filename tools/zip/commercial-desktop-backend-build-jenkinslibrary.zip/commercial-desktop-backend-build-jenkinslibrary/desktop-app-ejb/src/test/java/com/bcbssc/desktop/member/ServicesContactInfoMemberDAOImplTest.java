/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.member;

import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.Member;
import com.bcbssc.domain.entity.Subsystem;
import com.bcbssc.domain.entity.auth.RacfIdPrincipal;
import com.bcbssc.domain.entity.auth.RacfPasswordCredential;
import com.bcbssc.services.patientcontactinfo.PatientContactInfoInput;
import com.bcbssc.services.patientcontactinfo.PatientContactInfoOutput;
import com.bcbssc.services.patientcontactinfo.PatientContactInfoService;
import junit.framework.TestCase;
import org.apache.commons.lang.StringUtils;

import javax.security.auth.Subject;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.HashMap;
import java.util.Map;

/**
 * JUnit tests
 */
public class ServicesContactInfoMemberDAOImplTest extends TestCase {
    private Subject user;
    private ServicesContactInfoMemberDAOImpl successObject;
    private ServicesContactInfoMemberDAOImpl alternateObject;

    @Override
    protected void setUp() throws Exception {
        user = SubjectUtils.createEmptySubject();
        SubjectUtils.setUserId(user, RacfIdPrincipal.class, "TESTRACF");
        SubjectUtils.setPassword(user, RacfPasswordCredential.class, "PASSWORD");

        Map<String, Subsystem> rpns = new HashMap<>();
        Subsystem rules = new Subsystem();
        rules.setRpn("001");
        rpns.put("CISI", rules);
        SubjectUtils.setRPNSubsystems(user, rpns);

        successObject = new ServicesContactInfoMemberDAOImpl() {
            @Override
            public PatientContactInfoOutput invokeService(PatientContactInfoInput input, PatientContactInfoService service) {
                final PatientContactInfoOutput output = new PatientContactInfoOutput();
                output.setPatientName("MICHAEL TESTING");
                output.setPatientGender("M");
                output.setCarrierName("LARGE GROUP ASO");
                output.setPatientDateOfBirth("10-01-1958");
                output.setPrimaryCarePhysicianName("PrimaryCarePhysicianName");
                output.setCarrierRestrictedIndicator("Y");
                return output;
            }
        };

        alternateObject = new ServicesContactInfoMemberDAOImpl() {
            @Override
            public PatientContactInfoOutput invokeService(PatientContactInfoInput input, PatientContactInfoService service) {
                final PatientContactInfoOutput output = new PatientContactInfoOutput();
                output.setPatientName("MICHAEL TESTING");
                output.setPatientGender("M");
                output.setCarrierName("LARGE GROUP ASO");
                output.setPatientDateOfBirth("10-01-1958");
                output.setPrimaryCarePhysicianName("PCP NOT FOUND");
                return output;
            }
        };
    }

    /**
     * Tests
     */
    public void testGetMember() {
        final String subscriberId = "999574317";
        final String patientId = "001";
        PatientContactInfoInput input = new PatientContactInfoInput();
        input.setRequestSubscriberId(subscriberId);

        // Test case 1
        Member member = null;
        try {
            member = Subject.doAs(user, (PrivilegedExceptionAction<Member>) () -> successObject.getMember(subscriberId, patientId));
        } catch (PrivilegedActionException e) {
            e.printStackTrace(System.err);
            fail("Exception thrown");
        }
        assertNotNull(member);
        assertEquals("MICHAEL TESTING", member.getName().getFirstName());
        assertEquals("M", member.getSexCode());
        assertEquals("LARGE GROUP ASO", member.getCarrierName());
        assertEquals("10-01-1958", member.getBirthdate());
        assertTrue(member.isPrimaryCarePhysicianFound());
        assertEquals("PrimaryCarePhysicianName", member.getPrimaryCarePhysicianId());
        assertTrue(member.isCarrierRestricted());

        // Test alternate data
        member = null;
        try {
            member = Subject.doAs(user, (PrivilegedExceptionAction<Member>) () -> alternateObject.getMember(subscriberId, patientId));
        } catch (PrivilegedActionException e) {
            e.printStackTrace(System.err);
            fail("Exception thrown");
        }
        assertNotNull(member);
        assertFalse(member.isPrimaryCarePhysicianFound());
        assertEquals(StringUtils.EMPTY, member.getPrimaryCarePhysicianId());
        assertFalse(member.isCarrierRestricted());
    }
}
