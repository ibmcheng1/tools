# Contributing to Commercial Desktop Backend

The following is a set of guidelines for contributing to the Commercial Desktop Backend. These are mostly guidelines,
not rules. Use your best judgement, and feel free to propose changes to this document in a pull request.

## Code of Conduct

This project and everyone participating in it is governed by the [Code of Conduct](CODE_OF_CONDUCT.md). By participating,
you are expected to uphold this code.

## Setup

In order to work on this code base, you need to have a handful of settings configured for your computer.

### Maven Settings.xml

This project uses maven to do the builds and testing. Maven needs to be configured to talk to jFrog Artifactory as the
main repository. There are dependencies in the `pom.xml` files that don't exist in the traditional public repositories.

The easiest way to setup your `settings.xml` file is to go to 
[jFrog Artifactory](http://a70lpcomjfrg001.a70adom.bcbssc.com/artifactory/webapp/#/artifacts/browse/tree/General/libs-release)
(login using your adom account) and click on the `Set Me Up` link in the upper right. When the modal appears, click on the link for `Generate Maven 
Settings`

This will provide a `settings.xml` file that you can place in your `<maven home>/conf` directory and replace the one
already in there. 

**REMEMBER:** jFrog Artifactory does not support anonymous access, you will need to provide your adom username and 
password in the `settings.xml` file

## Environment Setup

There are a number of things the code needs the server to provide. Here is a list of some of those things

### WebSphere Liberty

To run the application locally, we are using WebSphere Liberty. The easiest way to get started with Liberty is to
download the [javaee version](https://developer.ibm.com/wasdev/downloads/#asset/runtimes-wlp-javaee7), which already has
all of the plugins installed. In the setup steps below, you should start at step 3. If you already have Liberty on your
workstation and want to setup the features, then start at step 1.

1. First, if you haven't done it already, you will need to help Liberty access the internet. With the awesome proxy we
use, it acts as a middle in the man. You need to tell Java to trust the certificates from the BCBSSC proxy. For your
benefit, the certificates have been included in this project. The paths for `keytool` and `cacerts` should be under your
JDK `/bin/` and `/lib/security/` directories respectively.
    
    ```bash
    keytool -import -trustcacerts -file server/certs/root.cer -alias rootcert -keystore cacerts -storepass changeit
    ``` 
    
    It will ask you to confirm it, then import one more certificate...   

    ```bash
    keytool -import -trustcacerts -file server/certs/issuing.cer -alias issuingcert -keystore cacerts -storepass changeit
    ```
    
1. Now that the awesome proxy is trusted, you can now install the features that you need to install. It's probably a
good idea to check the latest `server/server.xml` file for the full feature list. The `installUtility` will be in your
Liberty `/bin/` directory. 

    ```bash
    installUtility --acceptLicense webProfile-7.0 ejbRemote-3.2 jms-2.0 jaxws-2.2 concurrent-1.0 jndi-1.0 jwt-1.0 appSecurity-2.0
    ```

1. Next thing is to create a liberty server for this application to live in. You can use any name you want, just replace
`desktop-backend` with whatever you need in the commands below.

    ```bash
    server create desktop-backend
    ```
    
1. Generate a desktop key store.  Assuming you are in the root of your liberty installation and using the desktop-backend server name, run the command below.  Note: if you use a different storepass, you must update the store password in the server.xml file (see below).

    ```bash
    keytool -genkeypair -alias "desktopKey" -keystore "usr/servers/desktop-backend/desktopKeys.jks" -dname "CN=bcbssc.com" -keyalg RSA -storepass "store-pass"
    ```

1. Start the server. Any changes you make to the server configuration or application after it is started will be
automatically picked up.

    ```bash
    server start desktop-backend
    ```
    
1. Copy the `server/server.xml` file from this project into your Liberty `usr/servers/desktop-backend/` directory.

1. For local development, to makes things a little easier you can tell Liberty where your application is and we can
point it to your maven build. Put a line similar to the following at the bottom of your `server.xml`, just above the
`</server>` tag.

    ```xml
    <application id='commercial-desktop-backend' location='D:/Projects/workspaces/api/commercial-desktop-backend/commercial-desktop-backend-ear/target/commercial-desktop-backend-ear-1.0-SNAPSHOT.ear' name='desktop-backend' type='ear'/>
    ```

1. To make sure everything is working, you should be able to hit 
[http://localhost:9080/resources/util/bindings](http://localhost:9080/resources/util/bindings) and you will see a list
of bindings available on the server.

### Managed Executors

This is already setup in `server.xml`, but if you want to learn more about how they work, see 
[Configuring Managed Executors](https://www.ibm.com/support/knowledgecenter/SSEQTP_liberty/com.ibm.websphere.wlp.doc/ae/twlp_config_managedexecutor.html)
for more information.

`concurrent/executor` - Used to execute multiple service calls simultaneously.

### Managed Scheduled Executors

This is already setup in `server.xml`, but if you want to learn more about how they work, see 
[Configuring Managed Scheduled Executors](https://www.ibm.com/support/knowledgecenter/en/SSEQTP_liberty/com.ibm.websphere.wlp.doc/ae/twlp_config_scheduledexecutor.html)
for more information.

`concurrent/scheduledExecutor` - used to cancel executing threads if it hits a timeout

### Database Data Source

The `server.xml` file defines a datasource for connecting to DB2. You will need to do some setup for your server to
create the datasource. There are two jars in the `server/lib` directory, you need to copy those to your server
definition. If you don't want to change the `server.xml` file, then create the following directory 
`<wlp dir>/usr/shared/resources/db2` and drop those jars in there. If you put the jars somewhere else, you will need to 
modify the `server.xml` file to point to the correct location.

## Branching

You should create a branch for your work. A good rule of thumb is to start on the `master` branch, do a `git pull` and
then create your branch.

### Naming Standards

You should prefix your branch with one of the following based on what you are working on:

* `feature/` - if you are working on adding a new feature
* `build/` - if you are working on enhancing the build
* `issue/` - if you are fixing an issue

### Versions

For the time being, we don't have anything built in to bump the version number of the components. As soon as you create
your branch, you should bump the version number for the component you are working on. These components use the
[semver](https://semver.org) standards. As a rule of thumb, you would bump the major number if you are making breaking
changes to the component. Bump the minor version if you are adding a new feature (aka `feature/` branch). Bump the patch
version if you are fixing issues (aka `issue/` branch).

## Code Coverage

When you run your tests, the JaCoCo plugin is setup to automatically run to generate code coverage reports. The reports
will exist in each module with unit tests and the HTML report will live in the directory `target/jacoco-ut`.

## Pull Requests

When you are done with your coding and testing, you should submit your changes via a pull request (PR). When submitting
the PR, you need to include in the description, the definition of done criteria:

* [ ] Code Coverage >= 80% of new code
* [ ] Documentation has been updated
* [ ] Unit testing completed
* [ ] Acceptance criteria has been verified and met

You should also include the JIRA task you are working on. If it is an issue in GHE, please indicate which one.