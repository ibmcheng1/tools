/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.desktop.rest.resources;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.DesktopStartupBiz;
import com.bcbssc.desktop.rest.logging.LogLevelHelper;
import com.bcbssc.desktop.rest.mock.MockCacheWrapper;
import com.bcbssc.desktop.rest.mock.MockHttpServletRequest;
import com.bcbssc.desktop.rest.mock.MockHttpServletResponse;
import com.bcbssc.desktop.rest.security.util.SecurityUtil;
import com.bcbssc.desktop.rest.util.ResourceExecutor;
import com.bcbssc.desktop.rest.util.ResourceExecutor.ExceptionData;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.ApplicationClient;
import com.bcbssc.domain.entity.InformIdentification;
import com.bcbssc.domain.valueobject.MenuLink;

import junit.framework.Assert;
import junit.framework.TestCase;

public class UserProfileResourceTest extends TestCase {

    private MockCacheWrapper mockCache;
    private MockHttpServletRequest request;
    private MockHttpServletResponse response;

    private InformIdentification cachedInformId = null;
    private ApplicationClient cachedClient = null;

    @Override
    protected void setUp() throws Exception {
        LogLevelHelper.enableTraceLogging(UserProfileResource.class);
        request = new MockHttpServletRequest();
        response = new MockHttpServletResponse();
        mockCache = new MockCacheWrapper();
        DesktopAPI.setCacheWrapper(new MockCacheWrapper());

        cachedInformId = new InformIdentification();
        cachedInformId.setCompany("001");
        cachedInformId.setDepartment("44");
        cachedInformId.setDivision("916");
        cachedClient = new ApplicationClient("CSR", "BCBSSC", "BLUE CROSS BLUE SHIELD");
        final Subject subject = SubjectUtils.createEmptySubject();
        SubjectUtils.setClient(subject, cachedClient);
        SubjectUtils.setInformId(subject, cachedInformId);

        DesktopAPI.setUserStartupData(request.getSession().getId(), cachedClient.getAppId(), subject);
    }

    @Override
    protected void tearDown() throws Exception {
        mockCache.clear();
        DesktopAPI.setCacheWrapper(null);
    }

    public void testGetInformIdentificationSuccess() throws Exception {
        final InformIdentification informId = getTestableUserProfileResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                exceptionData.exception.printStackTrace();
                Assert.fail("An exception should not have been thrown");
            }
        }).getUserInformIdentification(request, response);

        // Assert a good inform id was returned
        Assert.assertNotNull(informId);
        Assert.assertEquals(cachedInformId.getCompany(), informId.getCompany());
        Assert.assertEquals(cachedInformId.getDepartment(), informId.getDepartment());
        Assert.assertEquals(cachedInformId.getDivision(), informId.getDivision());
    }

    public void testGetInformIdentificationNoSubjectFailure() throws Exception {

        final Map<String, Object> errorResults = new HashMap<String, Object>();

        // User session is removed from cache
        DesktopAPI.removeUserSession(request.getSession().getId());

        getTestableUserProfileResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                errorResults.put("incidentId", incidentId);
                errorResults.put("exceptionData", exceptionData);
            }
        }).getUserInformIdentification(request, response);

        validateUnauthenticatedError(errorResults);
    }

    public void testGetRulesControlLinksSuccess() throws Exception {

        final HashMap<String, Object> rules = new HashMap<>();
        rules.put(DesktopStartupBiz.RULES_DATA_KEY_CONTROL_LINK, Arrays.asList(new MenuLink(), new MenuLink(), new MenuLink(), new MenuLink()));
        DesktopAPI.setRulesEntries(request.getSession().getId(), rules);

        final List<MenuLink> controlLinks = getTestableUserProfileResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                exceptionData.exception.printStackTrace();
                Assert.fail("An exception should not have been thrown");
            }
        }).getUserControlLinks(request, response);

        // Assert a good RULES collection was returned
        Assert.assertNotNull(controlLinks);
        Assert.assertEquals(4, controlLinks.size());
    }

    public void testGetRulesControlLinksNoSubjectFailure() throws Exception {

        final Map<String, Object> errorResults = new HashMap<String, Object>();

        // User session is removed from cache
        DesktopAPI.removeUserSession(request.getSession().getId());

        getTestableUserProfileResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                errorResults.put("incidentId", incidentId);
                errorResults.put("exceptionData", exceptionData);
            }
        }).getUserControlLinks(request, response);

        validateUnauthenticatedError(errorResults);
    }

    public void testGetRulesFunctionLinksSuccess() throws Exception {

        final HashMap<String, Object> rules = new HashMap<>();
        rules.put(DesktopStartupBiz.RULES_DATA_KEY_FUNC_NAV_LINKS, Arrays.asList(new MenuLink(), new MenuLink()));
        DesktopAPI.setRulesEntries(request.getSession().getId(), rules);

        final List<MenuLink> functionLinks = getTestableUserProfileResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                exceptionData.exception.printStackTrace();
                Assert.fail("An exception should not have been thrown");
            }
        }).getUserFunctionLinks(request, response);

        // Assert a good RULES collection was returned
        Assert.assertNotNull(functionLinks);
        Assert.assertEquals(2, functionLinks.size());
    }

    public void testGetRulesFunctionLinksNoSubjectFailure() throws Exception {

        final Map<String, Object> errorResults = new HashMap<String, Object>();

        // User session is removed from cache
        DesktopAPI.removeUserSession(request.getSession().getId());

        getTestableUserProfileResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                errorResults.put("incidentId", incidentId);
                errorResults.put("exceptionData", exceptionData);
            }
        }).getUserFunctionLinks(request, response);

        validateUnauthenticatedError(errorResults);
    }

    public void testGetRulesSummaryLinksSuccess() throws Exception {

        final HashMap<String, Object> rules = new HashMap<>();
        final HashMap<String, MenuLink> cachedSummaryLinks = new HashMap<>();
        cachedSummaryLinks.put("SUMMARY_LINK_1", new MenuLink());
        cachedSummaryLinks.put("SUMMARY_LINK_2", new MenuLink());
        cachedSummaryLinks.put("SUMMARY_LINK_3", new MenuLink());
        rules.put(DesktopStartupBiz.RULES_DATA_KEY_SUMMARY_LINKS, cachedSummaryLinks);
        DesktopAPI.setRulesEntries(request.getSession().getId(), rules);

        final Map<String, MenuLink> summaryLinks = getTestableUserProfileResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                exceptionData.exception.printStackTrace();
                Assert.fail("An exception should not have been thrown");
            }
        }).getUserSummaryLinks(request, response);

        // Assert a good RULES collection was returned
        Assert.assertNotNull(summaryLinks);
        Assert.assertEquals(3, summaryLinks.size());
        Assert.assertNotNull(summaryLinks.get("SUMMARY_LINK_1"));
    }

    public void testGetRulesSummaryLinksNoSubjectFailure() throws Exception {

        final Map<String, Object> errorResults = new HashMap<String, Object>();

        // User session is removed from cache
        DesktopAPI.removeUserSession(request.getSession().getId());

        getTestableUserProfileResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                errorResults.put("incidentId", incidentId);
                errorResults.put("exceptionData", exceptionData);
            }
        }).getUserSummaryLinks(request, response);

        validateUnauthenticatedError(errorResults);
    }

    public void testGetRulesNavigationLinksRootSuccess() throws Exception {

        final HashMap<String, Object> rules = new HashMap<>();
        rules.put(DesktopStartupBiz.RULES_DATA_KEY_NAV_CATEGORY, Arrays.asList(new MenuLink(), new MenuLink()));
        DesktopAPI.setRulesEntries(request.getSession().getId(), rules);

        final Collection<MenuLink> navCategoryLinks = getTestableUserProfileResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                exceptionData.exception.printStackTrace();
                Assert.fail("An exception should not have been thrown");
            }
        }).getUserNavigationMenuRoot(request, response);

        // Assert a good RULES collection was returned
        Assert.assertNotNull(navCategoryLinks);
        Assert.assertEquals(2, navCategoryLinks.size());
    }

    public void testGetRulesNavigationLinksRootNoSubjectFailure() throws Exception {

        final Map<String, Object> errorResults = new HashMap<String, Object>();

        // User session is removed from cache
        DesktopAPI.removeUserSession(request.getSession().getId());

        getTestableUserProfileResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                errorResults.put("incidentId", incidentId);
                errorResults.put("exceptionData", exceptionData);
            }
        }).getUserNavigationMenuRoot(request, response);

        validateUnauthenticatedError(errorResults);
    }

    public void testGetRulesNavigationLinksChildrenSuccess() throws Exception {

        final HashMap<String, Object> rules = new HashMap<>();
        final HashMap<String, List<MenuLink>> cachedChildNavLinks = new HashMap<>();
        cachedChildNavLinks.put("C0001-C0002", Arrays.asList(new MenuLink(), new MenuLink()));
        cachedChildNavLinks.put("C0001-C0003", Arrays.asList(new MenuLink(), new MenuLink(), new MenuLink()));
        cachedChildNavLinks.put("C0001-C0004", Arrays.asList(new MenuLink()));
        rules.put(DesktopStartupBiz.RULES_DATA_KEY_NAV_LINKS, cachedChildNavLinks);
        DesktopAPI.setRulesEntries(request.getSession().getId(), rules);

        final Map<String, List<MenuLink>> childNavLinks = getTestableUserProfileResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                exceptionData.exception.printStackTrace();
                Assert.fail("An exception should not have been thrown");
            }
        }).getUserNavigationMenuLinks(request, response);

        // Assert a good RULES collection was returned
        Assert.assertNotNull(childNavLinks);
        Assert.assertEquals(3, childNavLinks.size());
        Assert.assertEquals(2, childNavLinks.get("C0001-C0002").size());
        Assert.assertEquals(3, childNavLinks.get("C0001-C0003").size());
        Assert.assertEquals(1, childNavLinks.get("C0001-C0004").size());
    }

    public void testGetRulesNavigationLinksChildrenNoSubjectFailure() throws Exception {

        final Map<String, Object> errorResults = new HashMap<String, Object>();

        // User session is removed from cache
        DesktopAPI.removeUserSession(request.getSession().getId());

        getTestableUserProfileResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                errorResults.put("incidentId", incidentId);
                errorResults.put("exceptionData", exceptionData);
            }
        }).getUserNavigationMenuLinks(request, response);

        validateUnauthenticatedError(errorResults);
    }

    private void validateUnauthenticatedError(Map<String, Object> errorResults) {
        final ExceptionData exceptionData = (ExceptionData) errorResults.get("exceptionData");
        final String incidentId = (String) errorResults.get("incidentId");
        Assert.assertTrue(StringUtils.isNotBlank(incidentId));
        Assert.assertEquals("NotAuthenticatedError", exceptionData.exceptionMapping.errorType);
        Assert.assertEquals(Response.Status.FORBIDDEN, exceptionData.exceptionMapping.responseStatus);
    }

    protected UserProfileResource getTestableUserProfileResource(final ResourceExecutor.ResourceExecutorExceptionValidator validator) {
        return new UserProfileResource() {

            @Override
            protected ResourceExecutor getResourceExecutor() {
                return new ResourceExecutor() {
                    @Override
                    protected void throwResourceExecutorException(String incidentId, ExceptionData exceptionDataToLog) {
                        validator.validate(incidentId, exceptionDataToLog);
                    }
                };
            }

            @Override
            protected SecurityUtil getSecurityUtil() {
                return new SecurityUtil() {
                    @Override
                    protected String createCompactedJwtToken(String subject, String tokenId) {
                        return subject + "-" + tokenId;
                    }
                    @Override
                    public String getSecurityTokenId(HttpServletRequest request) {
                        return request.getSession().getId();
                    }
                };
            }

        };
    }
}
