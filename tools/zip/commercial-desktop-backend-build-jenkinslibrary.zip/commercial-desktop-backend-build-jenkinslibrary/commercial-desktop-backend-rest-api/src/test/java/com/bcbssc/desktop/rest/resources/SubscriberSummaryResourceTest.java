/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.resources;

import com.bcbssc.domain.entity.Subscriber;
import com.bcbssc.domain.valueobject.PhoneNumber;
import junit.framework.TestCase;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;

public class SubscriberSummaryResourceTest extends TestCase {

    public void testFormatPhoneNumber() {
        PhoneNumber shortPhone = new PhoneNumber();
        shortPhone.setType("short");
        shortPhone.setPrefix("555");
        shortPhone.setSuffix("1111");

        PhoneNumber longPhone = new PhoneNumber();
        longPhone.setType("long");
        longPhone.setAreaCode("513");
        longPhone.setPrefix("251");
        longPhone.setSuffix("1234");

        SubscriberSummaryResource resource = new SubscriberSummaryResource();
        assertEquals("The short phone number format didn't match the expected.", "short: 555-1111", resource.formatPhoneNumber(shortPhone));
        assertEquals("The long phone number format didn't match the expected.", "long: (513)251-1234", resource.formatPhoneNumber(longPhone));

        try {
            resource.formatPhoneNumber(null);
            fail("An IllegalArgumentException should have been thrown when the phone number is null");
        } catch (IllegalArgumentException e) {
            // expected
        }
    }

    public void testGetPhoneToolTip() {
        PhoneNumber shortPhone = new PhoneNumber();
        shortPhone.setType("short");
        shortPhone.setPrefix("555");
        shortPhone.setSuffix("1111");

        PhoneNumber longPhone = new PhoneNumber();
        longPhone.setType("long");
        longPhone.setAreaCode("513");
        longPhone.setPrefix("251");
        longPhone.setSuffix("1234");

        Subscriber subscriber = new Subscriber();
        subscriber.setExtraPhoneNumbers(new ArrayList<>());
        subscriber.getExtraPhoneNumbers().add(shortPhone);
        subscriber.getExtraPhoneNumbers().add(longPhone);
        subscriber.getExtraPhoneNumbers().add(null);

        SubscriberSummaryResource resource = new SubscriberSummaryResource();
        String tooltip = resource.getPhoneToolTip(subscriber);

        // there should be two populated lines (can't guarantee order though)
        assertTrue("The tooltip should have contained a 'short:' phone number.", StringUtils.contains(tooltip, "short:"));
        assertTrue("The tooltip should have contained a 'long:' phone number.", StringUtils.contains(tooltip, "long:"));
        assertEquals("There should have been two new lines in the tooltip.", 2, StringUtils.countMatches(tooltip, "\n"));
    }
}
