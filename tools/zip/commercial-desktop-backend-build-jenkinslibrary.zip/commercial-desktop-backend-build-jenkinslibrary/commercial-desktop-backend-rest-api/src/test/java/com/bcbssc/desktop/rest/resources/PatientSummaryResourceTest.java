/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.resources;

import com.bcbssc.desktop.biz.FamilySummaryBiz;
import com.bcbssc.desktop.biz.MemberBiz;
import com.bcbssc.desktop.biz.SubscriberBiz;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.Member;
import com.bcbssc.domain.entity.Subscriber;
import com.bcbssc.domain.entity.managed.PatientHistory;
import com.bcbssc.domain.entity.membership.AddressWithHistory;
import com.bcbssc.domain.valueobject.Address;
import com.bcbssc.domain.valueobject.ContactInformation;
import com.bcbssc.domain.valueobject.PrincipalName;
import junit.framework.TestCase;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

public class PatientSummaryResourceTest extends TestCase {

    public void testGetSelectedMemberNullResultFromFamilySummary() throws Exception {
        PatientSummaryResource resource = new PatientSummaryResource() {
            @Override
            protected Subject getUserSubject(HttpServletRequest request) {
                return SubjectUtils.createEmptySubject();
            }

            @Override
            protected SubscriberBiz getSubscriberBiz() {
                return new TestSubscriberBiz() {
                    @Override
                    public Address retrieveMemberAddress(String subscriberId, String memberId, Subject subject) {
                        fail("When the family summary biz returns a null object, SubscriberBiz::retrieveMemberAddress should not be called");
                        return null;
                    }
                };
            }

            @Override
            protected FamilySummaryBiz getFamilySummaryBiz() {
                return new TestFamilySummaryBiz() {
                    @Override
                    public Member getMemberFromSummary(String subscriberId, String patientId, Subject subject, boolean isRefresh) {
                        assertEquals("The subscriber id was not what was passed in", "subId", subscriberId);
                        assertEquals("The patient id was not what was passed in", "memberId", patientId);
                        assertFalse("The refresh flag was not set correctly", isRefresh);
                        return null;
                    }
                };
            }

            @Override
            protected MemberBiz getMemberBiz() {
                return new TestMemberBiz() {
                    @Override
                    public Member getMember(String subscriberId, String memberId, Subject subject) {
                        fail("When the family summary biz returns a null object, MemberBiz::getMember should not be called");
                        return null;
                    }
                };
            }
        };

        resource.getSelectedMember(null, "subId", "memberId", "yes");
    }

    public void testGetSelectedMemberWithMemberInfo() throws Exception {
        PatientSummaryResource resource = new PatientSummaryResource() {
            @Override
            protected Subject getUserSubject(HttpServletRequest request) {
                return SubjectUtils.createEmptySubject();
            }

            @Override
            protected SubscriberBiz getSubscriberBiz() {
                return new TestSubscriberBiz() {
                    @Override
                    public Address retrieveMemberAddress(String subscriberId, String memberId, Subject subject) {
                        assertEquals("The subscriber id was not what was passed in", "subId", subscriberId);
                        assertEquals("The patient id was not what was passed in", "memberId", memberId);
                        Address address = new Address();
                        address.setAddress1("address1");
                        address.setAddress2("address2");
                        address.setCity("city");
                        address.setState("state");
                        return address;
                    }
                };
            }

            @Override
            protected FamilySummaryBiz getFamilySummaryBiz() {
                return new TestFamilySummaryBiz() {
                    @Override
                    public Member getMemberFromSummary(String subscriberId, String patientId, Subject subject, boolean isRefresh) {
                        assertEquals("The subscriber id was not what was passed in", "subId", subscriberId);
                        assertEquals("The patient id was not what was passed in", "memberId", patientId);
                        assertFalse("The refresh flag was not set correctly", isRefresh);
                        Member member = new Member();
                        member.setMemberId("003");
                        member.setName(new PrincipalName("Pepper", "P", "Potts"));
                        return member;
                    }
                };
            }

            @Override
            protected MemberBiz getMemberBiz() {
                return new TestMemberBiz() {
                    @Override
                    public Member getMember(String subscriberId, String memberId, Subject subject) {
                        assertEquals("The subscriber id was not what was passed in", "subId", subscriberId);
                        assertEquals("The patient id was not what was passed in", "memberId", memberId);
                        Member member = new Member();
                        member.setPrimaryCarePhysicianFound(true);
                        member.setPrimaryCarePhysicianId("pcp-id");
                        member.setPrimaryCarePhysicianName("pcp-name");
                        return member;
                    }
                };
            }
        };

        Member member = resource.getSelectedMember(null, "subId", "memberId", "yes");
        assertNotNull("The resulting member should not have been null", member);
        assertEquals("The member first name was not what was expected", "Pepper", member.getName().getFirstName());
        assertEquals("The member middle name was not what was expected", "P", member.getName().getMiddleName());
        assertEquals("The member last name was not what was expected", "Potts", member.getName().getLastName());
        assertEquals("The member id was not what was expected", "003", member.getMemberId());
        assertEquals("The address line 1 was not what was expected", "address1", member.getAddress().getAddress1());
        assertEquals("The address line 2 was not what was expected", "address2", member.getAddress().getAddress2());
        assertEquals("The city was not what was expected", "city", member.getAddress().getCity());
        assertEquals("The state was not what was expected", "state", member.getAddress().getState());
        assertEquals("The primary care physician id was not set correctly", "pcp-id", member.getPrimaryCarePhysicianId());
        assertEquals("The primary care physician name was not set correctly", "pcp-name", member.getPrimaryCarePhysicianName());
    }

    // This class exists so each test doesn't have to implement all methods - it's annoying.
    private class TestSubscriberBiz implements SubscriberBiz {
        @Override
        public Map<String, Object> getSubscriberInformation(Subscriber subscriber, Subject subject) {
            fail("SubscriberBiz::getSubscriberInformation should not have been called");
            return null;
        }

        @Override
        public Map<String, Object> getSubscriberInformation(Subscriber subscriber, Subject subject, Boolean useServiceCenterLookup, Boolean isRefresh) {
            fail("SubscriberBiz::getSubscriberInformation should not have been called");
            return null;
        }

        @Override
        public Subscriber changeSubscriberAddress(Subscriber subscriber, ContactInformation updatedContactInformation, String employeeCode, String departmentCode, Subject subject) {
            fail("SubscriberBiz::changeSubscriberAddress should not have been called");
            return null;
        }

        @Override
        public PatientHistory getAuthorizationReferrals(Subscriber subscriber, int startingPage, boolean includeVoided, Subject subject) {
            fail("SubscriberBiz::getAuthorizationReferrals should not have been called");
            return null;
        }

        @Override
        public Address retrieveMemberAddress(String subscriberId, String memberId, Subject subject) {
            return null;
        }

        @Override
        public String lookupCountyName(String countyCode, String state, Subject subject) {
            fail("SubscriberBiz::lookupCountyName should not have been called");
            return null;
        }

        @Override
        public List<AddressWithHistory> retrieveMailingAddressHistory(String subscriberId, Subject subject) {
            fail("SubscriberBiz::retrieveMailingAddressHistory should not have been called");
            return null;
        }
    }

    // This class exists so each test doesn't have to implement all methods - it's annoying.
    private class TestFamilySummaryBiz implements FamilySummaryBiz {
        @Override
        public List<Member> getFamilySummary(String subscriberId, Subject subject, boolean isRefresh) {
            fail("FamilySummaryBiz::getFamilySummary should not have been called");
            return null;
        }

        @Override
        public Map<String, Object> getMatchedAndUnmatchedMembers(Subscriber subscriber, Subject subject, boolean isRefresh) {
            fail("FamilySummaryBiz::getMatchedAndUnmatchedMembers should not have been called");
            return null;
        }

        @Override
        public Member getMemberFromSummary(String subscriberId, String patientId, Subject subject, boolean isRefresh) {
            return null;
        }
    }

    private class TestMemberBiz implements MemberBiz {
        @Override
        public Member getMember(String subscriberId, String memberId, Subject subject) {
            return null;
        }

        @Override
        public List<Member> retrieveStatusHistory(String subscriberId, String memberId, Subject subject) {
            fail("MemberBiz::retrieveStatusHistory should not have been called");
            return null;
        }

        @Override
        public List<Member> retrievePatientList(String subscriberId, Subject subject) {
            fail("MemberBiz::retrievePatientList should not have been called");
            return null;
        }

        @Override
        public List<Member> retrievePatientListFilter(String subscriberId, String planCode, Subject subject) {
            fail("MemberBiz::retrievePatientListFilter should not have been called");
            return null;
        }
    }
}
