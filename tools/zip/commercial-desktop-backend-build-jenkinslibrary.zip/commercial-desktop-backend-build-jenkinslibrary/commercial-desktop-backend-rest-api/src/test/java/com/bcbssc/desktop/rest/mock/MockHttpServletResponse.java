/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 * MockHttpServletResponse.java
 *
 * Created on Sep 24, 2010, 1:08:07 PM by JC33
 */

package com.bcbssc.desktop.rest.mock;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

/**
 * A mock class that can be used in junit tests to represent an HttpServletResponse. Implement
 * methods as necessary.
 */
public class MockHttpServletResponse implements HttpServletResponse {

    private String contentType = null;
    private MockServletOutputStream outputStream = null;
    private PrintWriter writer = null;
    private StringWriter out = null;
    private String redirectPage = null;
    private Cookie[] cookies = new Cookie[0];
    private int contentLength;
    private final Map<String, String> header = new HashMap<String, String>();
    private int errorCode;
    private String errorMessage;
    private int statusCode;

    /* @see javax.servlet.http.HttpServletResponse#addCookie(javax.servlet.http.Cookie) */
    @Override
    public void addCookie(Cookie cookie) {
        if (cookie == null){
            return;
        }
        //Arrays.asList returns an AbstractList implementation that is apparently immutable,
        //so we'll add it to a new ArrayList first
        final List<Cookie> cookieList = new ArrayList<Cookie>(Arrays.asList(cookies));
        int index = -1;
        for (int i = 0; i < cookieList.size(); i++){
            final Cookie existingCookie = cookieList.get(i);
            if (existingCookie.getName().equals(cookie.getName())){
                index = i;
            }
        }
        if(index > -1){
            cookieList.set(index, cookie);
        } else{
            cookieList.add(cookie);
        }
        cookies = cookieList.toArray(cookies);
    }

    /**
     * Returns any cookies that have been set on the response
     * @return
     */
    public Cookie[] getCookies(){
        return cookies;
    }

    /* @see javax.servlet.http.HttpServletResponse#addDateHeader(java.lang.String, long) */
    @Override
    public void addDateHeader(String name, long date) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpServletResponse#addHeader(java.lang.String, java.lang.String) */
    @Override
    public void addHeader(String name, String value) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpServletResponse#addIntHeader(java.lang.String, int) */
    @Override
    public void addIntHeader(String name, int value) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpServletResponse#containsHeader(java.lang.String) */
    @Override
    public boolean containsHeader(String name) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpServletResponse#encodeRedirectURL(java.lang.String) */
    @Override
    public String encodeRedirectURL(String url) {
        return url;
    }

    /* @see javax.servlet.http.HttpServletResponse#encodeRedirectUrl(java.lang.String) */
    @Override
    public String encodeRedirectUrl(String url) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpServletResponse#encodeURL(java.lang.String) */
    @Override
    public String encodeURL(String url) {
        return url;
    }

    /* @see javax.servlet.http.HttpServletResponse#encodeUrl(java.lang.String) */
    @Override
    public String encodeUrl(String url) {
        throw new UnsupportedOperationException("This method is deprecated, please do not use it");
    }

    /* @see javax.servlet.http.HttpServletResponse#sendError(int) */
    @Override
    public void sendError(int sc) throws IOException {
        errorCode = sc;
        statusCode = sc;
    }

    /* @see javax.servlet.http.HttpServletResponse#sendError(int, java.lang.String) */
    @Override
    public void sendError(int sc, String msg) throws IOException {
        errorCode = sc;
        errorMessage = msg;
        statusCode = sc;
    }

    /* @see javax.servlet.http.HttpServletResponse#sendRedirect(java.lang.String) */
    @Override
    public void sendRedirect(String location) throws IOException {
        redirectPage = location;
    }

    /* @see javax.servlet.http.HttpServletResponse#setDateHeader(java.lang.String, long) */
    @Override
    public void setDateHeader(String name, long date) {
        header.put(name, new Date(date).toString());
    }

    /* @see javax.servlet.http.HttpServletResponse#setHeader(java.lang.String, java.lang.String) */
    @Override
    public void setHeader(String name, String value) {
        header.put(name, value);
    }

    /* @see javax.servlet.http.HttpServletResponse#setIntHeader(java.lang.String, int) */
    @Override
    public void setIntHeader(String name, int value) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpServletResponse#setStatus(int) */
    @Override
    public void setStatus(int sc) {
        statusCode = sc;
    }

    @Override
    public int getStatus(){
        return statusCode;
    }

    /* @see javax.servlet.http.HttpServletResponse#setStatus(int, java.lang.String) */
    @Override
    public void setStatus(int sc, String sm) {
        statusCode = sc;
    }

    /* @see javax.servlet.ServletResponse#flushBuffer() */
    @Override
    public void flushBuffer() throws IOException {
        // Nothing to do
    }

    /* @see javax.servlet.ServletResponse#getBufferSize() */
    @Override
    public int getBufferSize() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletResponse#getCharacterEncoding() */
    @Override
    public String getCharacterEncoding() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletResponse#getContentType() */
    @Override
    public String getContentType() {
        return contentType;
    }

    /* @see javax.servlet.ServletResponse#getLocale() */
    @Override
    public Locale getLocale() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletResponse#getOutputStream() */
    @Override
    public ServletOutputStream getOutputStream() throws IOException {
        if(outputStream == null){
            outputStream = new MockServletOutputStream();
        }
        return outputStream;
    }

    /* @see javax.servlet.ServletResponse#getWriter() */
    @Override
    public PrintWriter getWriter() throws IOException {
        if (null == writer) {
            if (null == out) {
                out = new StringWriter();
            }
            writer = new PrintWriter(out);
        }
        return writer;
    }

    /* @see javax.servlet.ServletResponse#isCommitted() */
    @Override
    public boolean isCommitted() {
        return ((header.size() > 0) && (statusCode != 0));
    }

    public Map<String, String> getHeader() {
        return header;
    }

    public int getContentLength() {
        return contentLength;
    }

    /* @see javax.servlet.ServletResponse#reset() */
    @Override
    public void reset() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletResponse#resetBuffer() */
    @Override
    public void resetBuffer() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletResponse#setBufferSize(int) */
    @Override
    public void setBufferSize(int size) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletResponse#setCharacterEncoding(java.lang.String) */
    @Override
    public void setCharacterEncoding(String charset) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletResponse#setContentLength(int) */
    @Override
    public void setContentLength(int len) {
        contentLength = len;
    }

    /* @see javax.servlet.ServletResponse#setContentType(java.lang.String) */
    @Override
    public void setContentType(String type) {
        contentType = type;
    }

    /* @see javax.servlet.ServletResponse#setLocale(java.util.Locale) */
    @Override
    public void setLocale(Locale loc) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /**
     * @return the out
     */
    public StringWriter getOut() {
        return out;
    }

    /**
     * @param out the out to set
     */
    public void setOut(StringWriter out) {
        this.out = out;
    }

    /**
     * @return the redirectPage
     */
    public String getRedirectPage() {
        return redirectPage;
    }

    public String getResponseContent(){
        String responseContent = null;
        if(out != null){
            responseContent = out.toString();
        } else if(outputStream != null){
            responseContent = outputStream.getServletResponse();
        }
        return responseContent;
    }

    public int getErrorCodeSent(){
        return errorCode;
    }

    public String getErrorMessageSent(){
        return errorMessage;
    }

    @Override
    public void setContentLengthLong(long len) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public String getHeader(String name) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Collection<String> getHeaders(String name) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Collection<String> getHeaderNames() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

}
