/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2016 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 */

package com.bcbssc.desktop.rest.mock;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;

import org.apache.commons.lang.StringUtils;

public class MockServletInputStream extends ServletInputStream {

    private ByteArrayInputStream inputStream = null;

    @Override
    public int read() throws IOException {
        if(inputStream == null){
            inputStream = new ByteArrayInputStream(StringUtils.EMPTY.getBytes());
        }
        return inputStream.read();
    }

    public void setContent(String content) {
        inputStream = new ByteArrayInputStream(content.getBytes());
    }

    @Override
    public String toString() {
        final ByteArrayOutputStream bos = new ByteArrayOutputStream();
        int next = inputStream.read();
        while (next > -1) {
            bos.write(next);
            next = inputStream.read();
        }
        try {
            bos.flush();
        } catch (final IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        final byte[] result = bos.toByteArray();
        return new String(result);
    }

    @Override
    public boolean isFinished() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isReady() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void setReadListener(ReadListener readListener) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

}
