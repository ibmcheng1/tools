/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.resources;

import com.bcbssc.desktop.biz.SubscriberBiz;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.Subscriber;
import com.bcbssc.domain.entity.managed.PatientHistory;
import com.bcbssc.domain.entity.membership.AddressWithHistory;
import com.bcbssc.domain.valueobject.Address;
import com.bcbssc.domain.valueobject.ContactInformation;
import junit.framework.TestCase;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

public class ActivitySummaryResourceTest extends TestCase {

    public void testGetAuthorizationReferralsNullInput() throws Exception {
        ActivitySummaryResource resource = new ActivitySummaryResource() {
            @Override
            protected SubscriberBiz getSubscriberBiz() {
                return new TestSubscriberBiz() {
                    @Override
                    public PatientHistory getAuthorizationReferrals(Subscriber subscriber, int startingPage, boolean includeVoided, Subject subject) {
                        assertNotNull("The subscriber object should not have been null", subscriber);
                        assertEquals("The subscriber id should have been set", "subId", subscriber.getId());
                        assertEquals("The selected patient id should have been set", "memberId", subscriber.getSelectedPatientId());
                        assertEquals("The selected AMMS patient id should have been set", "memberId", subscriber.getSelectedAMMSPatientId());
                        assertEquals("The starting page number was not set correctly", 0, startingPage);
                        assertFalse("The includeVoided flag was not set correctly", includeVoided);

                        return null;
                    }
                };
            }

            @Override
            protected Subject getUserSubject(HttpServletRequest request) {
                return SubjectUtils.createEmptySubject();
            }
        };

        // pass in a null page number and include voided flag
        resource.getAuthorizationReferrals(null, "subId", "memberId", null, null);
    }

    public void testGetAuthorizationReferralsInvalidInput() throws Exception {
        ActivitySummaryResource resource = new ActivitySummaryResource() {
            @Override
            protected SubscriberBiz getSubscriberBiz() {
                return new TestSubscriberBiz() {
                    @Override
                    public PatientHistory getAuthorizationReferrals(Subscriber subscriber, int startingPage, boolean includeVoided, Subject subject) {
                        assertNotNull("The subscriber object should not have been null", subscriber);
                        assertEquals("The subscriber id should have been set", "subId", subscriber.getId());
                        assertEquals("The selected patient id should have been set", "memberId", subscriber.getSelectedPatientId());
                        assertEquals("The selected AMMS patient id should have been set", "memberId", subscriber.getSelectedAMMSPatientId());
                        assertEquals("The starting page number was not set correctly", 0, startingPage);
                        assertFalse("The includeVoided flag was not set correctly", includeVoided);

                        return null;
                    }
                };
            }

            @Override
            protected Subject getUserSubject(HttpServletRequest request) {
                return SubjectUtils.createEmptySubject();
            }
        };

        // pass in a null page number and include voided flag
        resource.getAuthorizationReferrals(null, "subId", "memberId", "yes", "forty");
    }

    public void testGetAuthorizationReferralsGoodValues() throws Exception {
        ActivitySummaryResource resource = new ActivitySummaryResource() {
            @Override
            protected SubscriberBiz getSubscriberBiz() {
                return new TestSubscriberBiz() {
                    @Override
                    public PatientHistory getAuthorizationReferrals(Subscriber subscriber, int startingPage, boolean includeVoided, Subject subject) {
                        assertNotNull("The subscriber object should not have been null", subscriber);
                        assertEquals("The subscriber id should have been set", "subId", subscriber.getId());
                        assertEquals("The selected patient id should have been set", "memberId", subscriber.getSelectedPatientId());
                        assertEquals("The selected AMMS patient id should have been set", "memberId", subscriber.getSelectedAMMSPatientId());
                        assertEquals("The starting page number was not set correctly", 8, startingPage);
                        assertTrue("The includeVoided flag was not set correctly", includeVoided);

                        return null;
                    }
                };
            }

            @Override
            protected Subject getUserSubject(HttpServletRequest request) {
                return SubjectUtils.createEmptySubject();
            }
        };

        // pass in a null page number and include voided flag
        resource.getAuthorizationReferrals(null, "subId", "memberId", "true", "8");
    }

    // This class exists so we don't have to override every method for each test - it's annoying.
    private class TestSubscriberBiz implements SubscriberBiz {

        @Override
        public Map<String, Object> getSubscriberInformation(Subscriber subscriber, Subject subject) {
            fail("getSubscriberInformation should not have been called");
            return null;
        }

        @Override
        public Map<String, Object> getSubscriberInformation(Subscriber subscriber, Subject subject, Boolean useServiceCenterLookup, Boolean isRefresh) {
            fail("getSubscriberInformation should not have been called");
            return null;
        }

        @Override
        public Subscriber changeSubscriberAddress(Subscriber subscriber, ContactInformation updatedContactInformation, String employeeCode, String departmentCode, Subject subject) {
            fail("changeSubscriberAddress should not have been called");
            return null;
        }

        @Override
        public PatientHistory getAuthorizationReferrals(Subscriber subscriber, int startingPage, boolean includeVoided, Subject subject) {
            return null;
        }

        @Override
        public Address retrieveMemberAddress(String subscriberId, String memberId, Subject subject) {
            fail("retrieveMemberAddress should not have been called");
            return null;
        }

        @Override
        public String lookupCountyName(String countyCode, String state, Subject subject) {
            fail("lookupCountyName should not have been called");
            return null;
        }

        @Override
        public List<AddressWithHistory> retrieveMailingAddressHistory(String subscriberId, Subject subject) {
            fail("retrieveMailingAddressHistory should not have been called");
            return null;
        }
    }
}
