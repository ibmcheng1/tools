/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.rest.filter;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

import com.bcbssc.desktop.rest.mock.MockFilterChain;
import com.bcbssc.desktop.rest.mock.MockHttpServletRequest;
import com.bcbssc.desktop.rest.mock.MockHttpServletResponse;
import com.bcbssc.desktop.rest.security.util.SecurityUtil;

import junit.framework.Assert;
import junit.framework.TestCase;

public class SecurityFilterTest extends TestCase {

    private SecurityFilter objUnderTest;
    private MockHttpServletRequest request;
    private MockHttpServletResponse response;

    @Override
    protected void setUp() throws Exception {
        request = new MockHttpServletRequest();
        response = new MockHttpServletResponse();
        objUnderTest = new SecurityFilter() {
            @Override
            protected SecurityUtil getSecurityUtil() {
                return new SecurityUtil() {
                    @Override
                    protected String getSecurityTokenIdFromSecurityToken(String securityToken) {
                        final String token = request.getHeader("token");
                        if(StringUtils.isNotBlank(token) && !StringUtils.equals(token, "valid-security-token")) {
                            throw new SecurityTokenException("Not a valid token");
                        }
                        return token;
                    }
                };
            }
        };
    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testSuccessfulExecutionNoHeader() throws IOException, ServletException {
        final MockFilterChain chain = new MockFilterChain();
        chain.addServlet(new HttpServlet() {
            private static final long serialVersionUID = 1L;
            @Override
            protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
                // Successful call with no errors
                resp.getWriter().print("Success");
            }
        });
        objUnderTest.doFilter(request, response, chain);
        Assert.assertEquals("Success", response.getResponseContent());
        Assert.assertEquals(null, request.getAttribute("security-token-id"));
    }

    public void testSuccessfulExecutionWithValidHeader() throws IOException, ServletException {
        final MockFilterChain chain = new MockFilterChain();
        chain.addServlet(new HttpServlet() {
            private static final long serialVersionUID = 1L;
            @Override
            protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
                // Successful call with no errors
                resp.getWriter().print("Success");
            }
        });
        request.addStringHeader("token", "valid-security-token");
        objUnderTest.doFilter(request, response, chain);
        Assert.assertEquals("Success", response.getResponseContent());
        Assert.assertEquals("valid-security-token", request.getAttribute("security-token-id"));
    }

    public void testSuccessfulExecutionWithInvalidHeader() throws IOException, ServletException {
        final MockFilterChain chain = new MockFilterChain();
        chain.addServlet(new HttpServlet() {
            private static final long serialVersionUID = 1L;
            @Override
            protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
                // Successful call with no errors
                resp.getWriter().print("Success");
            }
        });
        // Adding an invalid security header
        request.addStringHeader("token", "invalid-security-token");
        objUnderTest.doFilter(request, response, chain);
        Assert.assertEquals(401, response.getErrorCodeSent());
        final String responseContext = response.getResponseContent();
        Assert.assertTrue(StringUtils.contains(responseContext, "'incidentId': "));
        Assert.assertTrue(StringUtils.contains(responseContext, "'errorType': "));
        Assert.assertEquals(null, request.getAttribute("security-token-id"));
    }
}
