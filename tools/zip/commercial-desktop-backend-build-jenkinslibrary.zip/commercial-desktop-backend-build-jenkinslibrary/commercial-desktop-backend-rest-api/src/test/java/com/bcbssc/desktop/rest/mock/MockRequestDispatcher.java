/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2011 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 * MockRequestDispatcher.java
 *
 * Created on Apr 4, 2011, 11:07:52 AM by JC33
 */

package com.bcbssc.desktop.rest.mock;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * A mock class that represents a {@link RequestDispatcher}. This allows for executing
 * servlets in JUnit tests that use the {@link RequestDispatcher}.
 *
 * @author Jon Sturdevant
 */
public class MockRequestDispatcher implements RequestDispatcher {

    private String url = null;
    private Boolean forwardCalled = Boolean.FALSE;

    public MockRequestDispatcher(String url) {
        this.url = url;
    }

    /* @see javax.servlet.RequestDispatcher#forward(javax.servlet.ServletRequest, javax.servlet.ServletResponse) */
    @Override
    public void forward(ServletRequest paramServletRequest, ServletResponse paramServletResponse) throws ServletException, IOException {
        forwardCalled = Boolean.TRUE;
    }

    /* @see javax.servlet.RequestDispatcher#include(javax.servlet.ServletRequest, javax.servlet.ServletResponse) */
    @Override
    public void include(ServletRequest paramServletRequest, ServletResponse paramServletResponse) throws ServletException, IOException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /**
     * @return the url
     */
    public String getUrl() {
        return url;
    }

    /**
     * @return the forwardCalled
     */
    public Boolean getForwardCalled() {
        return forwardCalled;
    }

}
