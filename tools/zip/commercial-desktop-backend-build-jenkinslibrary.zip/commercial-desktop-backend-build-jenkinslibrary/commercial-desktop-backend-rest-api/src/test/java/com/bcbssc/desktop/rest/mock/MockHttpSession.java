/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 * MockHttpSession.java
 *
 * Created on Sep 24, 2010, 1:37:20 PM by JC33
 */

package com.bcbssc.desktop.rest.mock;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;

/**
 * A mock class that can be used in junit tests to represent an HttpSession. Implement
 * methods as necessary.
 */
public class MockHttpSession implements HttpSession {

    private Map<String, Object> attributeMap = null;
    private static Random generator = new Random();
    private String sessionId = null;

    /* @see javax.servlet.http.HttpSession#getAttribute(java.lang.String) */
    @Override
    public Object getAttribute(String name) {
        Object result = null;
        if ((attributeMap != null) && attributeMap.containsKey(name)) {
            result = attributeMap.get(name);
        }
        return result;
    }

    /* @see javax.servlet.http.HttpSession#getAttributeNames() */
    @Override
    public Enumeration getAttributeNames() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpSession#getCreationTime() */
    @Override
    public long getCreationTime() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpSession#getId() */
    @Override
    public String getId() {
        if (null == sessionId) {
            sessionId = "mock-session-" + Math.abs(generator.nextInt());
        }
        return sessionId;
    }

    /* @see javax.servlet.http.HttpSession#getLastAccessedTime() */
    @Override
    public long getLastAccessedTime() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpSession#getMaxInactiveInterval() */
    @Override
    public int getMaxInactiveInterval() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpSession#getServletContext() */
    @Override
    public ServletContext getServletContext() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpSession#getSessionContext() */
    /**
     * @deprecated
     */
    @Deprecated
    @Override
    public HttpSessionContext getSessionContext() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpSession#getValue(java.lang.String) */
    @Override
    public Object getValue(String name) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpSession#getValueNames() */
    @Override
    public String[] getValueNames() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpSession#invalidate() */
    @Override
    public void invalidate() {
        attributeMap = null;
        sessionId = null;
    }

    /* @see javax.servlet.http.HttpSession#isNew() */
    @Override
    public boolean isNew() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpSession#putValue(java.lang.String, java.lang.Object) */
    @Override
    public void putValue(String name, Object value) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpSession#removeAttribute(java.lang.String) */
    @Override
    public void removeAttribute(String name) {
        if ((null != attributeMap) && attributeMap.containsKey(name)) {
            attributeMap.remove(name);
        }
    }

    /* @see javax.servlet.http.HttpSession#removeValue(java.lang.String) */
    @Override
    public void removeValue(String name) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpSession#setAttribute(java.lang.String, java.lang.Object) */
    @Override
    public void setAttribute(String name, Object value) {
        if (null == attributeMap) {
            attributeMap = new HashMap<String, Object>();
        }

        attributeMap.put(name, value);
    }

    /* @see javax.servlet.http.HttpSession#setMaxInactiveInterval(int) */
    @Override
    public void setMaxInactiveInterval(int interval) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

}
