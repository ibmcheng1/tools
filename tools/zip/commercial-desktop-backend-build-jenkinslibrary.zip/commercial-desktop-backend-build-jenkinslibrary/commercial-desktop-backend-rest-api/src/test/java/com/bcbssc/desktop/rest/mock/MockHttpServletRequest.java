/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2010 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 * MockHttpServletRequest.java
 *
 * Created on Sep 24, 2010, 12:50:10 PM by JC33
 */

package com.bcbssc.desktop.rest.mock;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.AsyncContext;
import javax.servlet.DispatcherType;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpUpgradeHandler;
import javax.servlet.http.Part;

/**
 * A mock class that can be used in junit tests to represent an HttpServletRequest. Implement
 * methods as necessary.
 */
public class MockHttpServletRequest implements HttpServletRequest {

    /*
     *  getRequestURL() http://localhost:8080/india/jasmine
     *  getRequestURI() /india/jasmine
     *  getServletPath() /jasmine
     *  getContextPath() /india
     */

    private Map<String, String> stringHeadersMap = null;
    private Map<String, String[]> parameterMap = null;
    private Map<String, Object> attributeMap = null;
    private HttpSession session = null;
    private String contextPath = "";
    private String requestUri = "/test/mock/uri";
    private String requestUrl = "";
    private MockRequestDispatcher lastInvokedRequestDispatcher = null;
    private Principal userPrincipal;
    private Cookie[] cookies = new Cookie[0];
    private MockServletInputStream inputStream = null;
    private String method;
    private String servletPath;

    public MockHttpServletRequest(){}

    private MockHttpServletRequest(HttpSession session){
        this.session = session;
    }

    /* @see javax.servlet.http.HttpServletRequest#getAuthType() */
    @Override
    public String getAuthType() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpServletRequest#getContextPath() */
    @Override
    public String getContextPath() {
        return contextPath;
    }

    public void setContextPath(String contextPath) {
        this.contextPath = contextPath;
    }

    /* @see javax.servlet.http.HttpServletRequest#getCookies() */
    @Override
    public Cookie[] getCookies() {
        return cookies;
    }

    public void addCookie(Cookie cookie){
        //Arrays.asList returns an AbstractList implementation that is apparently immutable,
        //so we'll add it to a new ArrayList first
        final List<Cookie> cookieList = new ArrayList<Cookie>(Arrays.asList(cookies));
        cookieList.add(cookie);
        cookies = cookieList.toArray(cookies);
    }

    public void addCookies(Cookie[] cookies){
        //Arrays.asList returns an AbstractList implementation that is apparently immutable,
        //so we'll add it to a new ArrayList first
        final List<Cookie> cookieList = new ArrayList<Cookie>(Arrays.asList(cookies));
        cookieList.addAll(Arrays.asList(cookies));
        this.cookies = cookieList.toArray(cookies);
    }

    public void addCookies(MockHttpServletResponse response){
        addCookies(response.getCookies());
    }

    /* @see javax.servlet.http.HttpServletRequest#getDateHeader(java.lang.String) */
    @Override
    public long getDateHeader(String arg0) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpServletRequest#getHeader(java.lang.String) */
    @Override
    public String getHeader(String name) {
        String header = null;
        if(stringHeadersMap != null) {
            header = stringHeadersMap.get(name);
        }
        return header;
    }

    /* @see javax.servlet.http.HttpServletRequest#getHeaderNames() */
    @Override
    public Enumeration getHeaderNames() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpServletRequest#getHeaders(java.lang.String) */
    @Override
    public Enumeration getHeaders(String arg0) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpServletRequest#getIntHeader(java.lang.String) */
    @Override
    public int getIntHeader(String arg0) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpServletRequest#getMethod() */
    @Override
    public String getMethod() {
        return method;
    }

    public void setMethod(String method){
        this.method = method;
    }

    /* @see javax.servlet.http.HttpServletRequest#getPathInfo() */
    @Override
    public String getPathInfo() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpServletRequest#getPathTranslated() */
    @Override
    public String getPathTranslated() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpServletRequest#getQueryString() */
    @Override
    public String getQueryString() {
        String queryString = null;
        if(requestUrl != null){
            final String[] parts = requestUrl.split("\\?");
            if(parts.length > 1){
                queryString = "?"+parts[1];
            }
        }
        return queryString;
    }

    /* @see javax.servlet.http.HttpServletRequest#getRemoteUser() */
    @Override
    public String getRemoteUser() {
        String user = null;
        if(userPrincipal != null){
            user = userPrincipal.getName();
        }
        return user;
    }

    /* @see javax.servlet.http.HttpServletRequest#getRequestURI() */
    @Override
    public String getRequestURI() {
        return requestUri;
    }

    public void setRequestURI(String requestUri) {
        this.requestUri = requestUri;
    }

    /* @see javax.servlet.http.HttpServletRequest#getRequestURL() */
    @Override
    public StringBuffer getRequestURL() {
        return new StringBuffer(requestUrl);
    }

    public void setRequestURL(String requestURL){
        requestUrl = requestURL;
    }

    /* @see javax.servlet.http.HttpServletRequest#getRequestedSessionId() */
    @Override
    public String getRequestedSessionId() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpServletRequest#getServletPath() */
    @Override
    public String getServletPath() {
        return servletPath;
    }

    public void setServletPath(String servletPath){
        this.servletPath = servletPath;
    }

    /* @see javax.servlet.http.HttpServletRequest#getSession() */
    @Override
    public HttpSession getSession() {
        if (null == session) {
            session = new MockHttpSession();
        }
        return session;
    }

    /* @see javax.servlet.http.HttpServletRequest#getSession(boolean) */
    @Override
    public HttpSession getSession(boolean arg0) {
        return getSession();
    }

    public MockHttpServletRequest getNewRequestWithThisSession(){
        return new MockHttpServletRequest(this.getSession());
    }

    /* @see javax.servlet.http.HttpServletRequest#getUserPrincipal() */
    @Override
    public Principal getUserPrincipal() {
        return userPrincipal;
    }

    public void setUserPrincipal(Principal userPrincipal){
        this.userPrincipal = userPrincipal;
    }

    /* @see javax.servlet.http.HttpServletRequest#isRequestedSessionIdFromCookie() */
    @Override
    public boolean isRequestedSessionIdFromCookie() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpServletRequest#isRequestedSessionIdFromURL() */
    @Override
    public boolean isRequestedSessionIdFromURL() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpServletRequest#isRequestedSessionIdFromUrl() */
    @Override
    public boolean isRequestedSessionIdFromUrl() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpServletRequest#isRequestedSessionIdValid() */
    @Override
    public boolean isRequestedSessionIdValid() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.http.HttpServletRequest#isUserInRole(java.lang.String) */
    @Override
    public boolean isUserInRole(String arg0) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#getAttribute(java.lang.String) */
    @Override
    public Object getAttribute(String name) {
        Object result = null;
        if ((null != attributeMap) && attributeMap.containsKey(name)) {
            result = attributeMap.get(name);
        }
        return result;
    }

    /* @see javax.servlet.ServletRequest#getAttributeNames() */
    @Override
    public Enumeration getAttributeNames() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#getCharacterEncoding() */
    @Override
    public String getCharacterEncoding() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#getContentLength() */
    @Override
    public int getContentLength() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#getContentType() */
    @Override
    public String getContentType() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#getInputStream() */
    @Override
    public ServletInputStream getInputStream() throws IOException {
        if(inputStream == null){
            inputStream = new MockServletInputStream();
        }
        return inputStream;
    }

    public void setRequestContent(String content) throws IOException{
        ((MockServletInputStream)getInputStream()).setContent(content);
    }

    /* @see javax.servlet.ServletRequest#getLocalAddr() */
    @Override
    public String getLocalAddr() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#getLocalName() */
    @Override
    public String getLocalName() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#getLocalPort() */
    @Override
    public int getLocalPort() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#getLocale() */
    @Override
    public Locale getLocale() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#getLocales() */
    @Override
    public Enumeration getLocales() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#getParameter(java.lang.String) */
    @Override
    public String getParameter(String name) {
        String result = null;
        if ((null != parameterMap) && parameterMap.containsKey(name)) {
            result = parameterMap.get(name)[0];
        }
        return result;
    }

    public void setParameterMap(Map<String, String[]> map) {
        parameterMap = map;
    }

    /* @see javax.servlet.ServletRequest#getParameterMap() */
    @Override
    public Map<String, String[]> getParameterMap() {
        return parameterMap;
    }

    public void addParameter(String name, String value){
        this.addParameter(name, new String[]{value});
    }

    public void addParameter(String name, String[] values){
        if(parameterMap == null){
            parameterMap = new HashMap<String, String[]>();
        }
        parameterMap.put(name, values);
    }

    public void addStringHeader(String name, String value) {
        if(stringHeadersMap == null) {
            stringHeadersMap = new HashMap<String, String>();
        }
        stringHeadersMap.put(name, value);
    }

    /* @see javax.servlet.ServletRequest#getParameterNames() */
    @Override
    public Enumeration<String> getParameterNames() {
        return Collections.enumeration(parameterMap.keySet());
    }

    /* @see javax.servlet.ServletRequest#getParameterValues(java.lang.String) */
    @Override
    public String[] getParameterValues(String name) {
        String[] result = null;
        if ((null != parameterMap) && parameterMap.containsKey(name)) {
            result = parameterMap.get(name);
        }
        return result;
    }

    /* @see javax.servlet.ServletRequest#getProtocol() */
    @Override
    public String getProtocol() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#getReader() */
    @Override
    public BufferedReader getReader() throws IOException {
        return new BufferedReader(new InputStreamReader(getInputStream()));
    }

    /* @see javax.servlet.ServletRequest#getRealPath(java.lang.String) */
    @Override
    public String getRealPath(String path) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#getRemoteAddr() */
    @Override
    public String getRemoteAddr() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#getRemoteHost() */
    @Override
    public String getRemoteHost() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#getRemotePort() */
    @Override
    public int getRemotePort() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#getRequestDispatcher(java.lang.String) */
    @Override
    public RequestDispatcher getRequestDispatcher(String path) {
        lastInvokedRequestDispatcher = new MockRequestDispatcher(path);
        return lastInvokedRequestDispatcher;
    }

    public MockRequestDispatcher getLastInvokedRequestDispatcher(){
        return lastInvokedRequestDispatcher;
    }

    /* @see javax.servlet.ServletRequest#getScheme() */
    @Override
    public String getScheme() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#getServerName() */
    @Override
    public String getServerName() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#getServerPort() */
    @Override
    public int getServerPort() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#isSecure() */
    @Override
    public boolean isSecure() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    /* @see javax.servlet.ServletRequest#removeAttribute(java.lang.String) */
    @Override
    public void removeAttribute(String name) {
        if ((null != attributeMap) && attributeMap.containsKey(name)) {
            attributeMap.remove(name);
        }
    }

    public Map<String, Object> getAttributeMap() {
        return attributeMap;
    }

    /* @see javax.servlet.ServletRequest#setAttribute(java.lang.String, java.lang.Object) */
    @Override
    public void setAttribute(String name, Object o) {
        if (null == attributeMap) {
            attributeMap = new HashMap<String, Object>(10);
        }
        attributeMap.put(name, o);
    }

    /* @see javax.servlet.ServletRequest#setCharacterEncoding(java.lang.String) */
    @Override
    public void setCharacterEncoding(String env) throws UnsupportedEncodingException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public long getContentLengthLong() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public ServletContext getServletContext() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public AsyncContext startAsync() throws IllegalStateException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public AsyncContext startAsync(ServletRequest servletRequest, ServletResponse servletResponse) throws IllegalStateException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isAsyncStarted() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean isAsyncSupported() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public AsyncContext getAsyncContext() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public DispatcherType getDispatcherType() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public String changeSessionId() {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public boolean authenticate(HttpServletResponse response) throws IOException, ServletException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void login(String username, String password) throws ServletException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public void logout() throws ServletException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Collection<Part> getParts() throws IOException, ServletException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public Part getPart(String name) throws IOException, ServletException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @Override
    public <T extends HttpUpgradeHandler> T upgrade(Class<T> handlerClass) throws IOException, ServletException {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

}
