/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.desktop.rest.util;

import java.io.IOException;
import java.util.concurrent.Callable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;

import com.bcbssc.desktop.dao.auth.NotAuthorizedException;
import com.bcbssc.desktop.rest.mock.MockHttpServletRequest;
import com.bcbssc.desktop.rest.mock.MockHttpServletResponse;
import com.bcbssc.desktop.rest.util.ResourceExecutor.ExceptionData;
import com.bcbssc.desktop.rest.util.ResourceExecutor.ResourceExecutorExceptionValidator;
import com.bcbssc.desktop.util.exception.DataAccessException;

import junit.framework.Assert;
import junit.framework.TestCase;

public class ResourceExecutorTest extends TestCase {

    public void testSuccessfulExecution(){

        final HttpServletRequest request = new MockHttpServletRequest();
        final HttpServletResponse response = new MockHttpServletResponse();

        final String result = getTestableResourceExecutor(new ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                Assert.fail("There should not have been any exception thrown in this case.");
            }
        }).execute(new Callable<String>(){
            @Override
            public String call() throws Exception {
                return "success";
            }
        }, request, response);

        Assert.assertEquals("success", result);
    }

    public void testGeneralError(){
        final MockHttpServletRequest request = new MockHttpServletRequest();
        final MockHttpServletResponse response = new MockHttpServletResponse();

        getTestableResourceExecutor(new ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                Assert.assertTrue(StringUtils.contains(incidentId, request.getSession().getId()));
                Assert.assertEquals(Response.Status.INTERNAL_SERVER_ERROR, exceptionData.exceptionMapping.responseStatus);
                Assert.assertEquals("SystemError", exceptionData.exceptionMapping.errorType);
                Assert.assertEquals(RuntimeException.class.getName(), exceptionData.exception.getClass().getName());
                Assert.assertEquals("error!", exceptionData.exception.getMessage());
            }
        }).execute(new Callable<String>(){
            @Override
            public String call() throws Exception {
                throw new RuntimeException("error!");
            }
        }, request, response);
    }

    public void testAuthorizationError(){
        final MockHttpServletRequest request = new MockHttpServletRequest();
        final MockHttpServletResponse response = new MockHttpServletResponse();

        getTestableResourceExecutor(new ResourceExecutorExceptionValidator() {

            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                Assert.assertTrue(StringUtils.contains(incidentId, request.getSession().getId()));
                Assert.assertEquals(Response.Status.UNAUTHORIZED, exceptionData.exceptionMapping.responseStatus);
                Assert.assertEquals("NotAuthorizedError", exceptionData.exceptionMapping.errorType);
                Assert.assertEquals(NotAuthorizedException.class.getName(), exceptionData.exception.getClass().getName());
                Assert.assertEquals("authorization error!", exceptionData.exception.getMessage());
            }
        }).execute(new Callable<String>(){
            @Override
            public String call() throws Exception {
                throw new NotAuthorizedException("authorization error!");
            }
        }, request, response);
    }

    public void testDataAccessError() throws IOException{
        final MockHttpServletRequest request = new MockHttpServletRequest();
        final MockHttpServletResponse response = new MockHttpServletResponse();

        getTestableResourceExecutor(new ResourceExecutorExceptionValidator() {

            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                Assert.assertTrue(StringUtils.contains(incidentId, request.getSession().getId()));
                Assert.assertEquals(Response.Status.INTERNAL_SERVER_ERROR, exceptionData.exceptionMapping.responseStatus);
                Assert.assertEquals("DataAccessError", exceptionData.exceptionMapping.errorType);
                Assert.assertEquals(DataAccessException.class.getName(), exceptionData.exception.getClass().getName());
                Assert.assertEquals("data access exception!", exceptionData.exception.getMessage());
            }
        }).execute(new Callable<String>(){
            @Override
            public String call() throws Exception {
                throw new DataAccessException("data access exception!");
            }
        }, request, response);

    }

    private ResourceExecutor getTestableResourceExecutor(final ResourceExecutorExceptionValidator validator) {
        return new ResourceExecutor() {
            @Override
            protected void throwResourceExecutorException(String incidentId, ExceptionData exceptionDataToLog) {
                validator.validate(incidentId, exceptionDataToLog);
            }
        };
    }

}
