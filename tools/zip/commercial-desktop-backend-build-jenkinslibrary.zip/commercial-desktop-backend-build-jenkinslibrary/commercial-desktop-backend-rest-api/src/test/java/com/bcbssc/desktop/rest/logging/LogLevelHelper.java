/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES. ANY UNAUTHORIZED
 * USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY PROHIBITED.
 * COPYRIGHT 2014 BLUECROSS BLUESHIELD OF SOUTH CAROLINA ALL RIGHTS RESERVED.
 */
package com.bcbssc.desktop.rest.logging;

import java.util.logging.Level;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.impl.Jdk14Logger;

/**
 * Test helper for enabling certain log levels during unit testing.
 *
 */
public class LogLevelHelper {

    /**
     * Enables trace logging for the given class
     *
     * @param classForLogger
     */
    public static void enableTraceLogging(Class<?> classForLogger){
        final Log log = LogFactory.getLog(classForLogger);
        if(log instanceof Jdk14Logger){
            final Jdk14Logger logger = (Jdk14Logger)log;
            logger.getLogger().setLevel(Level.FINEST);
            logger.getLogger().getParent().getHandlers()[0].setLevel(Level.FINEST);
        } else{
            log.warn("Cannot override logging for unit tests - logger type: " + log.getClass());
        }
    }

}
