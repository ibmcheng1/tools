/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.desktop.rest.resources;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.security.auth.Subject;
import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.ClientListBiz;
import com.bcbssc.desktop.biz.DesktopStartupBiz;
import com.bcbssc.desktop.biz.authentication.DesktopAuthenticationBiz;
import com.bcbssc.desktop.dao.auth.NotAuthenticatedException;
import com.bcbssc.desktop.dao.auth.UserPasswordExpiredException;
import com.bcbssc.desktop.dao.auth.UserRevokedException;
import com.bcbssc.desktop.rest.logging.LogLevelHelper;
import com.bcbssc.desktop.rest.mock.MockCacheWrapper;
import com.bcbssc.desktop.rest.mock.MockHttpServletRequest;
import com.bcbssc.desktop.rest.mock.MockHttpServletResponse;
import com.bcbssc.desktop.rest.naming.SimpleInitialContextStubber;
import com.bcbssc.desktop.rest.security.util.SecurityUtil;
import com.bcbssc.desktop.rest.util.ResourceExecutor;
import com.bcbssc.desktop.rest.util.ResourceExecutor.ExceptionData;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.exception.DataAccessException;
import com.bcbssc.domain.entity.ApplicationClient;
import com.bcbssc.domain.entity.InformIdentification;
import com.bcbssc.domain.entity.InformSearchCriteria;
import com.bcbssc.domain.entity.Subsystem;
import com.bcbssc.domain.entity.auth.AuthenticationRequest;
import com.bcbssc.domain.entity.auth.UserCredentials;
import com.bcbssc.domain.entity.codes.Code;
import com.bcbssc.domain.entity.codes.inform.CategoryCode;
import com.bcbssc.domain.entity.codes.inform.StatusCode;
import com.bcbssc.domain.entity.enums.Subsystems;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;
import com.bcbssc.domain.entity.inform.InformSecurity;
import com.bcbssc.domain.valueobject.MenuConfiguration;
import com.bcbssc.domain.valueobject.MenuLink;
import com.bcbssc.domain.valueobject.claims.CodeRange;

import junit.framework.Assert;
import junit.framework.TestCase;

public class SecurityResourceTest extends TestCase {

    private static final String JNDI_BINDING_VALUE_DEFAULT_REGION = "LOEST1";
    private static final String JNDI_BINDING_VALUE_STATIC_RACF_ID = "static-racf-id";
    private static final String JNDI_BINDING_VALUE_STATIC_RACF_PASSWORD = "static-racf-password";
    private static final String JNDI_BINDING_VALUE_DEFAULT_RPN = "001";

    private MockCacheWrapper mockCache;
    private MockHttpServletRequest request;
    private MockHttpServletResponse response;
    private final SimpleInitialContextStubber initialContextStubber = new SimpleInitialContextStubber();

    @Override
    protected void setUp() throws Exception {
        LogLevelHelper.enableTraceLogging(SecurityResource.class);
        request = new MockHttpServletRequest();
        response = new MockHttpServletResponse();
        mockCache = new MockCacheWrapper();
        DesktopAPI.setCacheWrapper(new MockCacheWrapper());
        initialContextStubber.bind(EnvironmentObjects.REGION_DEFAULT.getName(), JNDI_BINDING_VALUE_DEFAULT_REGION);
        initialContextStubber.bind(EnvironmentObjects.STATIC_RACF_ID.getName(), JNDI_BINDING_VALUE_STATIC_RACF_ID);
        initialContextStubber.bind(EnvironmentObjects.STATIC_RACF_PASSWORD.getName(), JNDI_BINDING_VALUE_STATIC_RACF_PASSWORD);
        initialContextStubber.bind(EnvironmentObjects.DEFAULT_RPN.getName(), JNDI_BINDING_VALUE_DEFAULT_RPN);
    }

    @Override
    protected void tearDown() throws Exception {
        mockCache.clear();
        DesktopAPI.setCacheWrapper(null);
        initialContextStubber.unbindAll();
        initialContextStubber.shutDown();
    }

    public void testGetClientListSuccess() throws Exception {
        final List<ApplicationClient> clientList = getTestableSecurityResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                exceptionData.exception.printStackTrace();
                Assert.fail("An exception should not have been thrown");
            }
        }).getClientList(request, response, "CSR");

        // Assert a good client list was returned
        Assert.assertNotNull(clientList);
        Assert.assertEquals(3, clientList.size());

        // Assert that a good client list was stored in cache
        Assert.assertEquals(3, DesktopAPI.getClientList("CSR").size());
    }

    public void testGetClientListDataAccessFailure() throws Exception {
        final List<ApplicationClient> clientList = getTestableSecurityResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                exceptionData.exception.printStackTrace();
                Assert.assertEquals("DataAccessError", exceptionData.exceptionMapping.errorType);
                Assert.assertEquals(500, exceptionData.exceptionMapping.responseStatus.getStatusCode());
            }
        }).getClientList(request, response, "INVALID");

        // Asssert no client list was returned
        Assert.assertNull(clientList);

        // Assert no client list was stored in cache
        Assert.assertNull(DesktopAPI.getClientList("CSR"));
    }

    @SuppressWarnings("unchecked")
    public void testAuthenticateSuccessWithValidAuthorizedClient() throws Exception {

        final AuthenticationRequest authenticationRequest = new AuthenticationRequest();
        authenticationRequest.setUserCredentials(new UserCredentials());
        authenticationRequest.getUserCredentials().setUserName("GOOD_USER");
        authenticationRequest.getUserCredentials().setPassword("GOOD_PASS");
        authenticationRequest.setApplicationId("CSR");
        authenticationRequest.setClientId("BCBSSC");

        final String token = getTestableSecurityResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                exceptionData.exception.printStackTrace();
                Assert.fail("An exception should not have been thrown");
            }
        }).authenticate(request, response, authenticationRequest);

        // Assert that a good token response was received
        Assert.assertEquals("GOOD_USER-"+request.getSession().getId(), token);

        // Assert that the user information was stored in cache
        final Subject cachedUser = DesktopAPI.getUserSubject(request.getSession().getId());
        Assert.assertEquals("GOOD_USER", SubjectUtils.getRacfId(cachedUser));
        Assert.assertEquals("GOOD_PASS", SubjectUtils.getRACFPassword(cachedUser));
        Assert.assertEquals("CSR", SubjectUtils.getClient(cachedUser).getAppId());
        Assert.assertEquals("BCBSSC", SubjectUtils.getClient(cachedUser).getClientId());
        Assert.assertEquals("AMMS-001", SubjectUtils.getRpnForSubsystem(cachedUser, Subsystems.AMMS));
        Assert.assertEquals("CISI-001", SubjectUtils.getRpnForSubsystem(cachedUser, Subsystems.CISI));
        Assert.assertEquals("PIMS-001", SubjectUtils.getRpnForSubsystem(cachedUser, Subsystems.PIMS));
        Assert.assertEquals("3", SubjectUtils.getInformId(cachedUser).getCompany());
        Assert.assertEquals("44", SubjectUtils.getInformId(cachedUser).getDivision());
        Assert.assertEquals("916", SubjectUtils.getInformId(cachedUser).getDepartment());
        Assert.assertEquals("local-carrier-rules-value", SubjectUtils.getLocalCarrier(cachedUser));
        Assert.assertEquals(2, DesktopAPI.getPicklistCodes(request.getSession().getId(), DesktopStartupBiz.USER_DATA_KEY_PICKLIST_STATUS).size());
        Assert.assertEquals(3, DesktopAPI.getPicklistCodes(request.getSession().getId(), DesktopStartupBiz.USER_DATA_KEY_PICKLIST_CATEGORY).size());
        Assert.assertEquals(2, ((List<MenuLink>)DesktopAPI.getRulesEntries(request.getSession().getId()).get(DesktopStartupBiz.RULES_DATA_KEY_FUNC_NAV_LINKS)).size());
        Assert.assertEquals(2, ((List<CodeRange>)DesktopAPI.getRulesDataTypeEntries().get(DesktopAPI.ICD_COMPLIANCE_CATEGORIES)).size());
        Assert.assertNotNull(DesktopAPI.getRulesDataTypeEntries().get(DesktopAPI.ICD_COMPLIANCE_DATE));
    }

    public void testAuthenticateSuccessWithInvalidClient() throws Exception {

        final AuthenticationRequest authenticationRequest = new AuthenticationRequest();
        authenticationRequest.setUserCredentials(new UserCredentials());
        authenticationRequest.getUserCredentials().setUserName("GOOD_USER");
        authenticationRequest.getUserCredentials().setPassword("GOOD_PASS");
        authenticationRequest.setApplicationId("CSR");
        authenticationRequest.setClientId("BAD-CLIENT");

        final Map<String, Object> errorResults = new HashMap<String, Object>();

        final String token = getTestableSecurityResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                errorResults.put("incidentId", incidentId);
                errorResults.put("exceptionData", exceptionData);
            }
        }).authenticate(request, response, authenticationRequest);

        // Assert the proper error response was given
        final ExceptionData exceptionData = (ExceptionData) errorResults.get("exceptionData");
        Assert.assertEquals("NotAuthorizedError", exceptionData.exceptionMapping.errorType);
        Assert.assertEquals(Response.Status.UNAUTHORIZED, exceptionData.exceptionMapping.responseStatus);
        Assert.assertNull(token);

        // Assert no user was stored in cache
        final Subject cachedUser = DesktopAPI.getUserSubject(request.getSession().getId());
        Assert.assertNull(cachedUser);
    }

    public void testAuthenticateSuccessWithValidUnauthorizedClient() throws Exception {

        final AuthenticationRequest authenticationRequest = new AuthenticationRequest();
        authenticationRequest.setUserCredentials(new UserCredentials());
        authenticationRequest.getUserCredentials().setUserName("GOOD_USER");
        authenticationRequest.getUserCredentials().setPassword("GOOD_PASS");
        authenticationRequest.setApplicationId("CSR");
        authenticationRequest.setClientId("FEP");

        final Map<String, Object> errorResults = new HashMap<String, Object>();

        final String token = getTestableSecurityResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                errorResults.put("incidentId", incidentId);
                errorResults.put("exceptionData", exceptionData);
            }
        }).authenticate(request, response, authenticationRequest);

        // Assert the proper error response was given
        final ExceptionData exceptionData = (ExceptionData) errorResults.get("exceptionData");
        Assert.assertEquals("NotAuthorizedError", exceptionData.exceptionMapping.errorType);
        Assert.assertEquals(Response.Status.UNAUTHORIZED, exceptionData.exceptionMapping.responseStatus);
        Assert.assertEquals(null, token);

        // Assert no user was stored in cache
        final Subject cachedUser = DesktopAPI.getUserSubject(request.getSession().getId());
        Assert.assertNull(cachedUser);
    }

    public void testAuthenticateBadUserId() throws Exception {

        final AuthenticationRequest authenticationRequest = new AuthenticationRequest();
        authenticationRequest.setUserCredentials(new UserCredentials());
        authenticationRequest.getUserCredentials().setUserName("BAD_USER");
        authenticationRequest.getUserCredentials().setPassword("GOOD_PASS");

        final Map<String, Object> errorResults = new HashMap<String, Object>();

        final String token = getTestableSecurityResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                errorResults.put("incidentId", incidentId);
                errorResults.put("exceptionData", exceptionData);
            }
        }).authenticate(request, response, authenticationRequest);

        // Assert the proper error response was given
        final ExceptionData exceptionData = (ExceptionData) errorResults.get("exceptionData");
        Assert.assertEquals("NotAuthenticatedError", exceptionData.exceptionMapping.errorType);
        Assert.assertEquals(Response.Status.FORBIDDEN, exceptionData.exceptionMapping.responseStatus);
        Assert.assertEquals(null, token);

        // Assert no user was stored in cache
        final Subject cachedUser = DesktopAPI.getUserSubject(request.getSession().getId());
        Assert.assertNull(cachedUser);
    }

    public void testAuthenticateDataAccessError() throws Exception {

        final AuthenticationRequest authenticationRequest = new AuthenticationRequest();
        authenticationRequest.setUserCredentials(new UserCredentials());
        authenticationRequest.getUserCredentials().setUserName("DATA_ACCESS_ERROR");
        authenticationRequest.getUserCredentials().setPassword("GOOD_PASS");

        final Map<String, Object> errorResults = new HashMap<String, Object>();

        final String token = getTestableSecurityResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                errorResults.put("incidentId", incidentId);
                errorResults.put("exceptionData", exceptionData);
            }
        }).authenticate(request, response, authenticationRequest);

        // Assert the proper error response was given
        final ExceptionData exceptionData = (ExceptionData) errorResults.get("exceptionData");
        Assert.assertEquals("DataAccessError", exceptionData.exceptionMapping.errorType);
        Assert.assertEquals(Response.Status.INTERNAL_SERVER_ERROR, exceptionData.exceptionMapping.responseStatus);
        Assert.assertEquals(null, token);

        // Assert no user was stored in cache
        final Subject cachedUser = DesktopAPI.getUserSubject(request.getSession().getId());
        Assert.assertNull(cachedUser);
    }

    public void testAuthenticateSystemError() throws Exception {

        final AuthenticationRequest authenticationRequest = new AuthenticationRequest();
        authenticationRequest.setUserCredentials(new UserCredentials());
        authenticationRequest.getUserCredentials().setUserName("SYSTEM_ERROR");
        authenticationRequest.getUserCredentials().setPassword("GOOD_PASS");

        final Map<String, Object> errorResults = new HashMap<String, Object>();

        final String token = getTestableSecurityResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                errorResults.put("incidentId", incidentId);
                errorResults.put("exceptionData", exceptionData);
            }
        }).authenticate(request, response, authenticationRequest);

        // Assert the proper error response was given
        final ExceptionData exceptionData = (ExceptionData) errorResults.get("exceptionData");
        Assert.assertEquals("SystemError", exceptionData.exceptionMapping.errorType);
        Assert.assertEquals(Response.Status.INTERNAL_SERVER_ERROR, exceptionData.exceptionMapping.responseStatus);
        Assert.assertEquals(null, token);

        // Assert no user was stored in cache
        final Subject cachedUser = DesktopAPI.getUserSubject(request.getSession().getId());
        Assert.assertNull(cachedUser);
    }

    public void testAuthenticateUserRevoked() throws Exception {

        final AuthenticationRequest authenticationRequest = new AuthenticationRequest();
        authenticationRequest.setUserCredentials(new UserCredentials());
        authenticationRequest.getUserCredentials().setUserName("REVOKED_USER");
        authenticationRequest.getUserCredentials().setPassword("GOOD_PASS");

        final Map<String, Object> errorResults = new HashMap<String, Object>();

        final String token = getTestableSecurityResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                errorResults.put("incidentId", incidentId);
                errorResults.put("exceptionData", exceptionData);
            }
        }).authenticate(request, response, authenticationRequest);

        // Assert the proper error response was given
        final ExceptionData exceptionData = (ExceptionData) errorResults.get("exceptionData");
        Assert.assertEquals("UserRevokedError", exceptionData.exceptionMapping.errorType);
        Assert.assertEquals(Response.Status.UNAUTHORIZED, exceptionData.exceptionMapping.responseStatus);
        Assert.assertEquals(null, token);

        // Assert no user was stored in cache
        final Subject cachedUser = DesktopAPI.getUserSubject(request.getSession().getId());
        Assert.assertNull(cachedUser);
    }

    public void testAuthenticateUserPasswordExpired() throws Exception {

        final AuthenticationRequest authenticationRequest = new AuthenticationRequest();
        authenticationRequest.setUserCredentials(new UserCredentials());
        authenticationRequest.getUserCredentials().setUserName("EXPIRED_USER");
        authenticationRequest.getUserCredentials().setPassword("EXPIRED_PASS");

        final Map<String, Object> errorResults = new HashMap<String, Object>();

        final String token = getTestableSecurityResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                errorResults.put("incidentId", incidentId);
                errorResults.put("exceptionData", exceptionData);
            }
        }).authenticate(request, response, authenticationRequest);

        // Assert the proper error response was given
        final ExceptionData exceptionData = (ExceptionData) errorResults.get("exceptionData");
        Assert.assertEquals("UserPasswordExpiredError", exceptionData.exceptionMapping.errorType);
        Assert.assertEquals(Response.Status.UNAUTHORIZED, exceptionData.exceptionMapping.responseStatus);
        Assert.assertEquals(null, token);

        // Assert no user was stored in cache
        final Subject cachedUser = DesktopAPI.getUserSubject(request.getSession().getId());
        Assert.assertNull(cachedUser);
    }

    public void testAuthenticatePasswordChangeFailureWithMissingNewPassword() throws Exception {

        final AuthenticationRequest authenticationRequest = new AuthenticationRequest();
        authenticationRequest.setUserCredentials(new UserCredentials());
        authenticationRequest.getUserCredentials().setUserName("GOOD_USER");
        authenticationRequest.getUserCredentials().setPassword("GOOD_PASS");
        authenticationRequest.setApplicationId("CSR");
        authenticationRequest.setClientId("BCBSSC");

        final Map<String, Object> errorResults = new HashMap<String, Object>();

        final String token = getTestableSecurityResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                errorResults.put("incidentId", incidentId);
                errorResults.put("exceptionData", exceptionData);
            }
        }).changePassword(request, response, authenticationRequest);

        // Assert the proper error response was given
        final ExceptionData exceptionData = (ExceptionData) errorResults.get("exceptionData");
        Assert.assertEquals("InvalidInputError", exceptionData.exceptionMapping.errorType);
        Assert.assertEquals(Response.Status.BAD_REQUEST, exceptionData.exceptionMapping.responseStatus);
        Assert.assertEquals(null, token);

        // Assert no user was stored in cache
        final Subject cachedUser = DesktopAPI.getUserSubject(request.getSession().getId());
        Assert.assertNull(cachedUser);
    }

    @SuppressWarnings("unchecked")
    public void testAuthenticatePasswordChangeSuccessWithValidAuthorizedClient() throws Exception {

        final AuthenticationRequest authenticationRequest = new AuthenticationRequest();
        authenticationRequest.setUserCredentials(new UserCredentials());
        authenticationRequest.getUserCredentials().setUserName("GOOD_USER");
        authenticationRequest.getUserCredentials().setPassword("GOOD_PASS");
        authenticationRequest.getUserCredentials().setNewPassword("GOOD_NEW_PASS");
        authenticationRequest.setApplicationId("CSR");
        authenticationRequest.setClientId("BCBSSC");

        final String token = getTestableSecurityResource(new ResourceExecutor.ResourceExecutorExceptionValidator() {
            @Override
            public void validate(String incidentId, ExceptionData exceptionData) {
                exceptionData.exception.printStackTrace();
                Assert.fail("An exception should not have been thrown");
            }
        }).changePassword(request, response, authenticationRequest);

        // Assert that a good token response was received
        Assert.assertEquals("GOOD_USER-"+request.getSession().getId(), token);

        // Assert that the user information was stored in cache
        final Subject cachedUser = DesktopAPI.getUserSubject(request.getSession().getId());
        Assert.assertEquals("GOOD_USER", SubjectUtils.getRacfId(cachedUser));
        Assert.assertEquals("GOOD_NEW_PASS", SubjectUtils.getRACFPassword(cachedUser));
        Assert.assertEquals("CSR", SubjectUtils.getClient(cachedUser).getAppId());
        Assert.assertEquals("BCBSSC", SubjectUtils.getClient(cachedUser).getClientId());
        Assert.assertEquals("AMMS-001", SubjectUtils.getRpnForSubsystem(cachedUser, Subsystems.AMMS));
        Assert.assertEquals("CISI-001", SubjectUtils.getRpnForSubsystem(cachedUser, Subsystems.CISI));
        Assert.assertEquals("PIMS-001", SubjectUtils.getRpnForSubsystem(cachedUser, Subsystems.PIMS));
        Assert.assertEquals("3", SubjectUtils.getInformId(cachedUser).getCompany());
        Assert.assertEquals("44", SubjectUtils.getInformId(cachedUser).getDivision());
        Assert.assertEquals("916", SubjectUtils.getInformId(cachedUser).getDepartment());
        Assert.assertEquals("local-carrier-rules-value", SubjectUtils.getLocalCarrier(cachedUser));
        Assert.assertEquals(2, DesktopAPI.getPicklistCodes(request.getSession().getId(), DesktopStartupBiz.USER_DATA_KEY_PICKLIST_STATUS).size());
        Assert.assertEquals(3, DesktopAPI.getPicklistCodes(request.getSession().getId(), DesktopStartupBiz.USER_DATA_KEY_PICKLIST_CATEGORY).size());
        Assert.assertEquals(2, ((List<MenuLink>)DesktopAPI.getRulesEntries(request.getSession().getId()).get(DesktopStartupBiz.RULES_DATA_KEY_FUNC_NAV_LINKS)).size());
        Assert.assertEquals(2, ((List<CodeRange>)DesktopAPI.getRulesDataTypeEntries().get(DesktopAPI.ICD_COMPLIANCE_CATEGORIES)).size());
        Assert.assertNotNull(DesktopAPI.getRulesDataTypeEntries().get(DesktopAPI.ICD_COMPLIANCE_DATE));
    }

    protected SecurityResource getTestableSecurityResource(final ResourceExecutor.ResourceExecutorExceptionValidator validator) {
        return new SecurityResource() {

            @Override
            protected ResourceExecutor getResourceExecutor() {
                return new ResourceExecutor() {
                    @Override
                    protected void throwResourceExecutorException(String incidentId, ExceptionData exceptionDataToLog) {
                        validator.validate(incidentId, exceptionDataToLog);
                    }
                };
            }

            @Override
            protected SecurityUtil getSecurityUtil() {
                return new SecurityUtil() {
                    @Override
                    protected String createCompactedJwtToken(String subject, String tokenId) {
                        return subject + "-" + tokenId;
                    }
                };
            }

            @Override
            protected DesktopAuthenticationBiz getDesktopAuthenticationBiz() {
                return new DesktopAuthenticationBiz() {
                    @Override
                    public void login(UserCredentials userCredentials, Subject subject) throws NotAuthenticatedException, Exception {
                        if(StringUtils.equals(userCredentials.getUserName(), "REVOKED_USER")) {
                            throw new UserRevokedException("The user has been revoked.");
                        }
                        if(StringUtils.equals(userCredentials.getUserName(), "EXPIRED_USER")) {
                            throw new UserPasswordExpiredException("The user's password has expired.");
                        }
                        if(StringUtils.equals(userCredentials.getUserName(), "SYSTEM_ERROR")) {
                            throw new RuntimeException("Something unknown went bump in the night");
                        }
                        if(StringUtils.equals(userCredentials.getUserName(), "DATA_ACCESS_ERROR")) {
                            throw new DataAccessException("Something went bump with the DAO.");
                        }
                        if(!StringUtils.equals(userCredentials.getUserName(), "GOOD_USER") || !StringUtils.equals(userCredentials.getPassword(), "GOOD_PASS") ) {
                            throw new NotAuthenticatedException("Bad user name and/or password");
                        }
                    }
                    @Override
                    public void changePassword(UserCredentials userCredentials, Subject subject) throws NotAuthenticatedException, Exception {
                        if(StringUtils.equals(userCredentials.getUserName(), "BAD_NEW_PASS")) {
                            throw new NotAuthenticatedException("The new password was unacceptable.");
                        }
                    }
                };
            }

            @Override
            protected ClientListBiz getClientListBiz() {
                return new ClientListBiz() {

                    @Override
                    public ArrayList<ApplicationClient> getClientList(Subject subject) throws Exception {

                        // Make sure the subject passed in contains the values from JNDI for the static subject
                        Assert.assertEquals(JNDI_BINDING_VALUE_STATIC_RACF_ID, SubjectUtils.getRacfId(subject));
                        Assert.assertEquals(JNDI_BINDING_VALUE_STATIC_RACF_PASSWORD, SubjectUtils.getRACFPassword(subject));
                        Assert.assertEquals(JNDI_BINDING_VALUE_DEFAULT_REGION, SubjectUtils.getRegion(subject));
                        Assert.assertEquals(JNDI_BINDING_VALUE_DEFAULT_RPN, SubjectUtils.getRPN(subject));

                        final ArrayList<ApplicationClient> clientList = new ArrayList<ApplicationClient>();
                        final ApplicationClient client = SubjectUtils.getClientStrict(subject);
                        if(StringUtils.equalsIgnoreCase(client.getAppId(), "CSR")) {
                            clientList.add(new ApplicationClient("CSR", "BCBSSC", "Blue Cross Blue Shield of SC"));
                            clientList.add(new ApplicationClient("CSR", "CHC", "Blue Choice"));
                            clientList.add(new ApplicationClient("CSR", "FEP", "Federal Employee Program"));
                        } else {
                            throw new DataAccessException("Invalid application id.");
                        }
                        return clientList;
                    }

                    @Override
                    public HashMap<String, Subsystem> getSubsystemRpns(String keyRpn, Subject subject) throws Exception {
                        final HashMap<String, Subsystem> subsystems = new HashMap<>();
                        for(final Subsystems subsystem : Subsystems.values()){
                            subsystems.put(subsystem.getName(), new Subsystem(subsystem, subsystem.getName()+"-001"));
                        }
                        return subsystems;
                    }

                    @Override
                    public String getDefaultClientId(String applicationId) throws IOException {
                        throw new UnsupportedOperationException("This is not implemented yet");
                    }

                };
            }

            @Override
            protected DesktopStartupBiz getDesktopStartupBiz() {
                return new DesktopStartupBiz() {

                    @Override
                    public Boolean validateClientSelection(Subject subject) throws Exception {
                        final String clientId = SubjectUtils.getClient(subject).getClientId();
                        return StringUtils.equals(clientId, "BCBSSC");
                    }

                    @Override
                    public InformIdentification getUserData(Subject applicationUser, Subject subject) throws Exception {
                        final InformIdentification informId = new InformIdentification();
                        informId.setCompany("3");
                        informId.setDivision("44");
                        informId.setDepartment("916");
                        final InformSecurity informSecurity = new InformSecurity();
                        informSecurity.setCompanyCode("3");
                        informSecurity.setDivisionCode("44");
                        informSecurity.setDepartmentCode("916");
                        informId.setInformSecurity(informSecurity);
                        return informId;
                    }

                    @Override
                    public HashMap<String, ?> getRulesEntries(MenuConfiguration config, ApplicationClient client, Subject subject) throws Exception {
                        throw new UnsupportedOperationException("This is not implemented yet");
                    }

                    @Override
                    public HashMap<String, ?> getRulesEntries(Subject subject) throws Exception {
                        final HashMap<String, Object> rules = new HashMap<>();
                        rules.put(RULES_DATA_KEY_FUNC_NAV_LINKS, Arrays.asList(new MenuLink(), new MenuLink()));
                        final Map<String, MenuLink> userConfigs = new HashMap<>();
                        final MenuLink localCarrierConfig = new MenuLink();
                        localCarrierConfig.setKeyValue("local-carrier-rules-value");
                        userConfigs.put("LOCALCARRIER", localCarrierConfig);
                        rules.put(RULES_DATA_KEY_USER_CONFIGS, userConfigs);
                        return rules;
                    }

                    @Override
                    public HashMap<String, ?> getPicklists(InformSearchCriteria criteria, ApplicationClient client, String applicationId, Subject subject)
                                    throws Exception {
                        throw new UnsupportedOperationException("This is not implemented yet");
                    }

                    @Override
                    public Date getIcdComplianceDate(Subject subject) throws Exception {
                        return new Date(Calendar.getInstance().getTimeInMillis());
                    }

                    @Override
                    public List<CodeRange> getIcdCategories(Subject subject) throws Exception {
                        return Arrays.asList(new CodeRange(),  new CodeRange());
                    }

                    @Override
                    public HashMap<String, List<? extends Code>> fetchPicklists(Subject applicationUser, Subject staticSubject, InformIdentification userData)
                                    throws Exception {
                        final HashMap<String, List<? extends Code>> picklists = new HashMap<String, List<? extends Code>>();
                        picklists.put(DesktopStartupBiz.USER_DATA_KEY_PICKLIST_STATUS, Arrays.asList(
                                        new StatusCode("123", "IN PROGRESS", "OP"),
                                        new StatusCode("124", "COMPLETED", "CL")));
                        picklists.put(DesktopStartupBiz.USER_DATA_KEY_PICKLIST_CATEGORY, Arrays.asList(
                                        new CategoryCode("MED", "MEDICAL CALL"),
                                        new CategoryCode("DEN", "DENTAL CALL"),
                                        new CategoryCode("DUG", "DRUG CALL")));
                        return picklists;
                    }
                };
            }

        };
    }
}
