/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.mock;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;

public class MockFilterChain implements FilterChain {

    private final List<Filter> filterList;
    private boolean chainStarted = false;
    private Iterator<Filter> filterIterator = null;
    private HttpServlet servlet = null;

    public MockFilterChain(){
        filterList = new ArrayList<Filter>();
    }
    @Override
    public void doFilter(ServletRequest request, ServletResponse response) throws IOException, ServletException {
        chainStarted = true;
        if(filterIterator == null){
            filterIterator = filterList.iterator();
        }
        if(filterIterator.hasNext()){
            filterIterator.next().doFilter(request, response, this);
        } else if(servlet != null){
            servlet.service(request, response);
        }
    }

    public void addFilter(Filter filter){
        if(!chainStarted){
            filterList.add(filter);
        }
    }

    public void addFilters(Filter... filters){
        if(!chainStarted){
            filterList.addAll(Arrays.asList(filters));
        }
    }

    public void addServlet(HttpServlet servlet){
        this.servlet = servlet;
    }

}