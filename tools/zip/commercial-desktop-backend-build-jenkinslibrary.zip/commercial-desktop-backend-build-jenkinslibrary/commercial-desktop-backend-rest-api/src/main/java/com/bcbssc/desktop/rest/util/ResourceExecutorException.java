/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.desktop.rest.util;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

/**
 * The <code>ResourceExecutor</code> is to be used by JAX-RS resource classes/methods to ensure consistent exception handling and logging
 * across all resource calls.  The IBM JAX-RS servlet provides it's own exception handling (swallowing with a bit of default logging) so using
 * an exception servlet filter attached to the servlet is not an option.
 *
 * @author hx61
 *
 */
public class ResourceExecutorException extends WebApplicationException {

    private static final long serialVersionUID = 1L;

    public ResourceExecutorException(Throwable cause){
        super(cause);
    }

    public ResourceExecutorException(Status status, String errorType, String incidentId, Throwable cause) {
        super (
                        "An exception was encountered executing a jax-rs resource.  Incident id: " + incidentId,
                        cause,
                        createResponse(status, errorType, incidentId));
    }

    private static Response createResponse(Status status, String errorType, String incidentId) {
        final ErrorResponse errorResponse = new ErrorResponse(errorType, incidentId);
        return Response.status(status).type(MediaType.APPLICATION_JSON).entity(errorResponse).build();
    }

    public static class ErrorResponse {
        public String errorType;
        public String incidentId;
        public ErrorResponse(String errorType, String incidentId) {
            super();
            this.errorType = errorType;
            this.incidentId = incidentId;
        }
    }
}
