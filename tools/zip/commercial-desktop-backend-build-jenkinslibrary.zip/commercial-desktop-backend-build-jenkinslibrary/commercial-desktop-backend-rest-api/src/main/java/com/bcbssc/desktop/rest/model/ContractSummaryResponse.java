/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.model;

import com.bcbssc.domain.entity.Contract;
import com.bcbssc.domain.entity.Subscriber;

import java.util.List;
import java.util.Map;

public class ContractSummaryResponse {

    private Map<String, List<Contract>> contracts;
    private Subscriber subscriber;

    public Map<String, List<Contract>> getContracts() {
        return contracts;
    }

    public void setContracts(Map<String, List<Contract>> contracts) {
        this.contracts = contracts;
    }

    public Subscriber getSubscriber() {
        return subscriber;
    }

    public void setSubscriber(Subscriber subscriber) {
        this.subscriber = subscriber;
    }
}
