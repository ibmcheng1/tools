/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.resources;

import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import io.swagger.v3.jaxrs2.integration.resources.AcceptHeaderOpenApiResource;
import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.tags.Tag;

@OpenAPIDefinition(
                info = @Info(
                                title = "Commercial Desktop Backend",
                                version = "1.0-SNAPSHOT"
                                ),
                tags = {
                                @Tag(name = "Subscriber"),
                                @Tag(name = "Group"),
                                @Tag(name = "Member"),
                                @Tag(name = "Security"),
                                @Tag(name = "Utility"),
                                @Tag(name = "Inform"),
                                @Tag(name = "User")
                }
                )
@ApplicationPath("")
public class CommercialDesktopBackendRestApplication extends Application {

    /**
     * Whenever we add a class that exposes endpoints, we will need to add it to the list here. If it is not added, then
     * the endpoints will not be available. The reason we have the list is so we can expose the swagger (OpenAPI)
     * resources. WebSphere Liberty is not smart enough to recognize they exist.
     *
     * @return Returns a set of classes that contain endpoints.
     */
    @Override
    public Set<Class<?>> getClasses() {
        return Stream.of(
                        SubscriberExceptionsSummaryResource.class,
                        ActivitySummaryResource.class,
                        AlertsResource.class,
                        SubscriberSummaryResource.class,
                        ContractSummaryResource.class,
                        FamilySummaryResource.class,
                        ContactHistoryResource.class,
                        PatientSummaryResource.class,
                        UtilityResource.class,
                        SecurityResource.class,
                        UserProfileResource.class,
                        OpenApiResource.class,
                        AcceptHeaderOpenApiResource.class
                        ).collect(Collectors.toSet());
    }
}
