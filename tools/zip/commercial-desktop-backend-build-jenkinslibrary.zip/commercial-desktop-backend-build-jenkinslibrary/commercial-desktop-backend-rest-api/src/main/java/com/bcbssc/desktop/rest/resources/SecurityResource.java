/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.rest.resources;

import java.security.InvalidParameterException;
import java.sql.Date;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.ClientListBiz;
import com.bcbssc.desktop.biz.DesktopStartupBiz;
import com.bcbssc.desktop.biz.authentication.DesktopAuthenticationBiz;
import com.bcbssc.desktop.dao.auth.NotAuthenticatedException;
import com.bcbssc.desktop.dao.auth.NotAuthorizedException;
import com.bcbssc.desktop.rest.security.model.SecurityToken;
import com.bcbssc.desktop.rest.security.util.SecurityUtil;
import com.bcbssc.desktop.rest.util.ResourceExecutor;
import com.bcbssc.desktop.support.DiagnosticException;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.jndi.JndiUtils;
import com.bcbssc.domain.entity.ApplicationClient;
import com.bcbssc.domain.entity.InformIdentification;
import com.bcbssc.domain.entity.Subsystem;
import com.bcbssc.domain.entity.auth.AuthenticationRequest;
import com.bcbssc.domain.entity.auth.RacfPasswordCredential;
import com.bcbssc.domain.entity.auth.UserCredentials;
import com.bcbssc.domain.entity.enums.environment.EnvironmentObjects;
import com.bcbssc.domain.entity.inform.PicklistSecurity;
import com.bcbssc.domain.valueobject.MenuLink;
import com.bcbssc.domain.valueobject.claims.CodeRange;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

/**
 * JAX-RS enabled resource for security features
 */
@Path("/security")
public class SecurityResource {

    private static Log log = LogFactory.getLog(SecurityResource.class);

    private static final String desktopAuthenticationBizBindingName = "java:global/commercial-desktop-backend-ear/desktop-app-ejb/DesktopAuthenticationBizBDImpl!com.bcbssc.desktop.biz.authentication.DesktopAuthenticationBiz";
    private static final String desktopStartupBizBindingName = "java:global/commercial-desktop-backend-ear/desktop-app-ejb/DesktopStartupBizBDImpl!com.bcbssc.desktop.biz.DesktopStartupBiz";
    private static final String clientListBizBindingName = "java:global/commercial-desktop-backend-ear/desktop-app-ejb/ClientListBizBDImpl!com.bcbssc.desktop.biz.ClientListBiz";

    @GET
    @Path("/clients/{applicationId}")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
                    summary = "get the application client list",
                    method = "GET",
                    responses = {
                                    @ApiResponse(
                                                    description = "a list of application clients",
                                                    content = @Content(
                                                                    mediaType = "application/json",
                                                                    array = @ArraySchema(schema = @Schema(implementation = ApplicationClient.class, description = "An application client's metadata"))
                                                                    )
                                                    )
                    },
                    tags = { "Security" }
                    )
    public List<ApplicationClient> getClientList(
                    @Context HttpServletRequest request,
                    @Context HttpServletResponse response,
                    @PathParam("applicationId")
                    @Parameter(
                                    in = ParameterIn.PATH,
                                    name = "applicationId",
                                    required = true,
                                    description = "The application id of the client list to retrieve",
                                    schema = @Schema(type = "string")
                                    )
                    String applicationId){
        return getResourceExecutor().execute(() -> {
            final ClientListBiz clientListBiz = getClientListBiz();
            final Subject staticSubject = DesktopAPI.createStaticSubject(StringUtils.upperCase(applicationId));
            final List<ApplicationClient> clientList = AuthenticationStrategy.getClientList(clientListBiz, staticSubject, applicationId);
            AuthenticationStrategy.updateRpnSubsystemsCache(clientListBiz, clientList, staticSubject);
            return clientList;
        }, request, response);
    }
    /**
     * JAX-RS endpoint to authenticate a user and obtain a secured session.<br>
     * Endpoint: /resources/security/authenticate
     *
     * @return
     */
    @POST
    @Path("/authenticate")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
                    summary = "authenticate a user",
                    method = "POST",
                    requestBody = @RequestBody(
                                    required = true,
                                    content = {
                                                    @Content(
                                                                    mediaType = "application/json",
                                                                    schema = @Schema(implementation = AuthenticationRequest.class, description = "The authentication request data to use for authentication")
                                                                    )
                                    }
                                    ),
                    responses = {
                                    @ApiResponse(
                                                    description = "A security token",
                                                    content = @Content(
                                                                    mediaType = "application/json",
                                                                    schema = @Schema(implementation = String.class, description = "The security token to pass back in to all subsequent requests")
                                                                    )
                                                    )
                    },
                    tags = { "Security" }
                    )
    public String authenticate(final @Context HttpServletRequest request, final @Context HttpServletResponse response, final AuthenticationRequest authenticationRequest) {
        return getResourceExecutor().execute(() -> {
            return new AuthenticationStrategy(getDesktopAuthenticationBiz(), getClientListBiz(), getDesktopStartupBiz(), getSecurityUtil()) {
                @Override
                protected UserCredentials runAuthentication(DesktopAuthenticationBiz desktopAuthenticationBiz, UserCredentials userCredentials, Subject staticSubject) throws NotAuthenticatedException, Exception {
                    desktopAuthenticationBiz.login(userCredentials, staticSubject);
                    return userCredentials;
                }
            }.authenticate(request, response, authenticationRequest);
        }, request, response);
    }

    /**
     * JAX-RS endpoint to change the user's password<br>
     * Endpoint: /resources/security/password
     *
     * @return
     */
    @POST
    @Path("/password")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
                    summary = "authenticate a user and change the password",
                    method = "POST",
                    requestBody = @RequestBody(
                                    required = true,
                                    content = {
                                                    @Content(
                                                                    mediaType = "application/json",
                                                                    schema = @Schema(implementation = AuthenticationRequest.class, description = "The authentication request data to use for authentication")
                                                                    )
                                    }
                                    ),
                    responses = {
                                    @ApiResponse(
                                                    description = "A security token",
                                                    content = @Content(
                                                                    mediaType = "application/json",
                                                                    schema = @Schema(implementation = String.class, description = "The security token to pass back in to all subsequent requests")
                                                                    )
                                                    )
                    },
                    tags = { "Security" }
                    )
    public String changePassword(final @Context HttpServletRequest request, final @Context HttpServletResponse response, final AuthenticationRequest authenticationRequest) {
        return getResourceExecutor().execute(() -> {
            // If a new password isn't present, throw an exception
            if(StringUtils.isBlank(authenticationRequest.getUserCredentials().getNewPassword())) {
                throw new InvalidParameterException("Missing a new password in the userCredentials object.");
            }
            return new AuthenticationStrategy(getDesktopAuthenticationBiz(), getClientListBiz(), getDesktopStartupBiz(), getSecurityUtil()) {
                @Override
                protected UserCredentials runAuthentication(DesktopAuthenticationBiz desktopAuthenticationBiz, UserCredentials userCredentials, Subject staticSubject) throws NotAuthenticatedException, Exception {
                    desktopAuthenticationBiz.changePassword(userCredentials, staticSubject);
                    // Return a new credentials object with the new password set as the password
                    return new UserCredentials(userCredentials.getUserName(), userCredentials.getNewPassword());
                }
            }.authenticate(request, response, authenticationRequest);
        }, request, response);
    }

    private static abstract class AuthenticationStrategy {

        private final DesktopAuthenticationBiz desktopAuthenticationBiz;
        private final ClientListBiz clientListBiz;
        private final DesktopStartupBiz desktopStartupBiz;
        private final SecurityUtil securityUtil;

        public AuthenticationStrategy(DesktopAuthenticationBiz desktopAuthenticationBiz,
                        ClientListBiz clientListBiz, DesktopStartupBiz desktopStartupBiz, SecurityUtil securityUtil) {
            super();
            this.desktopAuthenticationBiz = desktopAuthenticationBiz;
            this.clientListBiz = clientListBiz;
            this.desktopStartupBiz = desktopStartupBiz;
            this.securityUtil = securityUtil;
        }

        public String authenticate(final HttpServletRequest request, final HttpServletResponse response, final AuthenticationRequest authenticationRequest) throws NotAuthenticatedException, Exception {
            final String applicationId = authenticationRequest.getApplicationId();
            final String clientId = authenticationRequest.getClientId();
            UserCredentials userCredentials = authenticationRequest.getUserCredentials();
            if(log.isTraceEnabled()) {
                log.trace("Attempting to authenticate [" + userCredentials.getUserName() + "]");
            }
            final DesktopAuthenticationBiz desktopAuthenticationBiz = getDesktopAuthenticationBiz();
            final ClientListBiz clientListBiz = getClientListBiz();
            final DesktopStartupBiz desktopStartupBiz = getDesktopStartupBiz();
            final Subject staticSubject = DesktopAPI.createStaticSubject(applicationId);
            // Run authentication and obtain new credentials in case they've changed (ie. password change)
            userCredentials = runAuthentication(desktopAuthenticationBiz, userCredentials, staticSubject);
            // Authentication successful, validate client
            SecurityToken securityToken = null;
            final ApplicationClient client = findClient(clientListBiz, applicationId, clientId, staticSubject);
            if(client != null) {
                String region = authenticationRequest.getRegion();
                if(StringUtils.isBlank(region)) {
                    region = JndiUtils.lookupObject(String.class, EnvironmentObjects.REGION_DEFAULT.getName());
                }
                final Subject subject = getInitialUserSubject(userCredentials, client, region);

                if(getDesktopStartupBiz().validateClientSelection(subject)) {
                    // Client validation successful, create security token and set user session data
                    securityToken = getSecurityUtil().createSecurityToken(request, userCredentials.getUserName());
                    final Map<String, Subsystem> subsystemRpns = getSubsystemRpns(clientListBiz, client, staticSubject);
                    final InformIdentification informId = desktopStartupBiz.getUserData(subject, staticSubject);
                    updateUserSubjectAndCache(securityToken.getTokenId(), subject, subsystemRpns, informId);
                    cacheInformPicklists(desktopStartupBiz, subject, staticSubject);
                    cacheRulesData(desktopStartupBiz, subject);
                    cacheIcdConfiguration(desktopStartupBiz, staticSubject);
                } else {
                    throw new NotAuthorizedException("User not authorized for application/client combination: ["+applicationId+"/"+clientId+"]");
                }
            } else {
                throw new NotAuthorizedException("Invalid application/client combination: ["+applicationId+"/"+clientId+"]");
            }
            if(log.isTraceEnabled()) {
                log.trace("User authenticated, returning token [" + securityToken.getToken() + "]");
            }
            return securityToken.getToken();
        }

        protected abstract UserCredentials runAuthentication(DesktopAuthenticationBiz desktopAuthenticationBiz, UserCredentials userCredentials, Subject staticSubject) throws NotAuthenticatedException, Exception;

        public static List<ApplicationClient> getClientList(ClientListBiz clientListBiz, Subject staticSubject, String applicationId) throws Exception{
            List<ApplicationClient> clientList = DesktopAPI.getClientList(applicationId);
            if(clientList == null) {
                clientList = clientListBiz.getClientList(staticSubject);
                DesktopAPI.setClientList(applicationId, clientList);
            }
            return clientList;
        }

        protected ApplicationClient findClient(ClientListBiz clientListBiz, String applicationId, String clientId, Subject staticSubject) throws Exception {
            ApplicationClient client = null;
            final List<ApplicationClient> clientList = getClientList(clientListBiz, staticSubject, applicationId);
            for(final ApplicationClient applicationClient : clientList) {
                if(StringUtils.equalsIgnoreCase(applicationClient.getClientId(), clientId)) {
                    client = applicationClient;
                }
            }
            return client;
        }

        public static HashMap<String, Map<String, Subsystem>> updateRpnSubsystemsCache(ClientListBiz clientListBiz, List<ApplicationClient> clientList, Subject staticSubject) throws Exception {
            HashMap<String, Map<String, Subsystem>> allSubsystemRpns = DesktopAPI.getSubsystemRpnMap();
            if(allSubsystemRpns == null) {
                allSubsystemRpns = new HashMap<String, Map<String, Subsystem>>();
            }
            boolean saveRpnSubsystems = false;
            for(final ApplicationClient client : clientList) {
                final String aliasRpn = client.getAliasRpn();
                if(allSubsystemRpns.get(aliasRpn) == null) {
                    final Map<String, Subsystem> subsystemRpns = clientListBiz.getSubsystemRpns(aliasRpn, staticSubject);
                    allSubsystemRpns.put(aliasRpn, subsystemRpns);
                    saveRpnSubsystems = true;
                }
            }
            if(saveRpnSubsystems) {
                DesktopAPI.setSubsystemRpnMap(allSubsystemRpns);
            }
            return allSubsystemRpns;
        }

        protected Map<String, Subsystem> getSubsystemRpns(ClientListBiz clientListBiz, ApplicationClient client, Subject staticSubject) throws Exception {
            final HashMap<String, Map<String, Subsystem>> allSubsystemRpns = updateRpnSubsystemsCache(clientListBiz, Arrays.asList(client), staticSubject);
            return allSubsystemRpns.get(client.getAliasRpn());

        }

        protected void cacheInformPicklists(DesktopStartupBiz desktopStartupBiz, Subject userSubject, Subject staticSubject) throws Exception {
            final InformIdentification informId = SubjectUtils.getInformId(userSubject);
            // store picklist defaults
            final String company = informId.getCompany();
            final String division = informId.getDivision();
            final String department = informId.getDepartment();
            // get the defaults for the picklists
            final PicklistSecurity picklistSecurity = informId.getPicklistSecurity();
            final HashMap<String, String> picklistDefaults = new HashMap<String, String>();
            picklistDefaults.put(DesktopStartupBiz.USER_DATA_KEY_DEFAULT_CATEGORY, picklistSecurity.getCategoryDefault());
            picklistDefaults.put(DesktopStartupBiz.USER_DATA_KEY_DEFAULT_CONTACT_TYPE, picklistSecurity.getSourceOfInquiryDefault());
            picklistDefaults.put(DesktopStartupBiz.USER_DATA_KEY_DEFAULT_REQUEST_REASON, picklistSecurity.getRequestReasonDefault());
            picklistDefaults.put(DesktopStartupBiz.USER_DATA_KEY_DEFAULT_RESOLUTION, picklistSecurity.getResolutionDefault());
            picklistDefaults.put(DesktopStartupBiz.USER_DATA_KEY_DEFAULT_SEVERITY, picklistSecurity.getSeverityDefault());
            picklistDefaults.put(DesktopStartupBiz.USER_DATA_KEY_DEFAULT_STATUS, picklistSecurity.getStatusDefault());
            /*
             * Picklist defaults are coming back from a service that uses a RACF to retrieve data, but the default information is
             * actually retrieved from a table that only uses the division and department codes to access the data.
             * Because the service is using a RACF to retrieve the data, INFOrm picklist defaults will not be able to be refreshed.
             */
            DesktopAPI.setPicklistDefaults(company, division, department, picklistDefaults);

            // store picklists if not already stored
            if (!DesktopAPI.verifyPicklistsStored(userSubject)) {
                final HashMap<String, ?> picklistCodes = desktopStartupBiz.fetchPicklists(userSubject, staticSubject, informId);
                DesktopAPI.setPicklistCodes(userSubject, picklistCodes);
            }
        }

        protected void cacheRulesData(DesktopStartupBiz desktopStartupBiz, Subject userSubject) throws Exception {
            final HashMap<String, ?> rulesEntries = desktopStartupBiz.getRulesEntries(userSubject);
            DesktopAPI.setRulesEntries(userSubject, rulesEntries);

            // if there is a carrier code in the rule entries, put it in the subject
            if (log.isDebugEnabled()) {
                log.debug("Attempting to figure out if this client has a local carrier code by searching for LOCALCARRIER in the USERCONFIG RULE entries");
            }
            final Map<String, MenuLink> userConfig = (Map<String, MenuLink>) rulesEntries.get(DesktopStartupBiz.RULES_DATA_KEY_USER_CONFIGS);
            if(userConfig != null) {
                final MenuLink localCarrierMenuLink = userConfig.get("LOCALCARRIER");
                if (log.isDebugEnabled()) {
                    log.debug("The LOCALCARRIER menu link is " + localCarrierMenuLink);
                }
                if (null != localCarrierMenuLink) {
                    SubjectUtils.setLocalCarrier(userSubject, localCarrierMenuLink.getKeyValue());
                    if (log.isDebugEnabled()) {
                        log.debug("The subject after putting in the local carrer is " + userSubject);
                    }
                }
            }
        }

        @SuppressWarnings("unchecked")
        protected void cacheIcdConfiguration(DesktopStartupBiz desktopStartupBiz, Subject staticSubject) throws Exception {
            HashMap<String, Object> rulesDataTypeEntriesMap = DesktopAPI.getRulesDataTypeEntries();
            if (rulesDataTypeEntriesMap == null) {
                rulesDataTypeEntriesMap = new HashMap<>();
            }
            Date icdDate = (Date) rulesDataTypeEntriesMap.get(DesktopAPI.ICD_COMPLIANCE_DATE);
            List<CodeRange> icdCategoryList = (List<CodeRange>) rulesDataTypeEntriesMap.get(DesktopAPI.ICD_COMPLIANCE_CATEGORIES);
            if (icdDate == null) {
                icdDate = desktopStartupBiz.getIcdComplianceDate(staticSubject);
                rulesDataTypeEntriesMap.put(DesktopAPI.ICD_COMPLIANCE_DATE, icdDate);
            }
            if (icdCategoryList == null) {
                icdCategoryList = desktopStartupBiz.getIcdCategories(staticSubject);
                rulesDataTypeEntriesMap.put(DesktopAPI.ICD_COMPLIANCE_CATEGORIES, icdCategoryList);
            }
            DesktopAPI.setRulesDataTypeEntries(rulesDataTypeEntriesMap);
        }

        protected Subject getInitialUserSubject(UserCredentials userCredentials, ApplicationClient client, String region) {

            final Subject user = SubjectUtils.createEmptySubject();
            SubjectUtils.setRacfId(user, userCredentials.getUserName());
            SubjectUtils.setPassword(user, RacfPasswordCredential.class, userCredentials.getPassword());
            SubjectUtils.setRPN(user, client.getRpn());
            SubjectUtils.setRegion(user, region);
            SubjectUtils.setClient(user, client);

            // Nothing should use this anymore going forward, but there's still code looking it
            // Just hardcoding for now.

            SubjectUtils.setEnvironment(user, "default");

            return user;
        }

        protected void updateUserSubjectAndCache(String securityTokenId, Subject user, Map<String, Subsystem> subsystems, InformIdentification informId) {

            SubjectUtils.setSessionId(user, securityTokenId);
            SubjectUtils.setInformId(user, informId);
            SubjectUtils.setRPNSubsystems(user, subsystems);

            try {
                DesktopAPI.setUserStartupData(securityTokenId, SubjectUtils.getClient(user).getAppId(), user);
            } catch (final Exception exception) {
                throw new DiagnosticException("An error occurred setting the user startup data.", exception);
            }
        }

        public DesktopAuthenticationBiz getDesktopAuthenticationBiz() {
            return desktopAuthenticationBiz;
        }

        public ClientListBiz getClientListBiz() {
            return clientListBiz;
        }

        public DesktopStartupBiz getDesktopStartupBiz() {
            return desktopStartupBiz;
        }

        public SecurityUtil getSecurityUtil() {
            return securityUtil;
        }

    }

    protected ResourceExecutor getResourceExecutor() {
        return ResourceExecutor.getInstance();
    }

    protected DesktopAuthenticationBiz getDesktopAuthenticationBiz() {
        return JndiUtils.lookupObject(DesktopAuthenticationBiz.class, desktopAuthenticationBizBindingName);
    }

    protected DesktopStartupBiz getDesktopStartupBiz() {
        return JndiUtils.lookupObject(DesktopStartupBiz.class, desktopStartupBizBindingName);
    }

    protected ClientListBiz getClientListBiz() {
        return JndiUtils.lookupObject(ClientListBiz.class, clientListBizBindingName);
    }

    protected SecurityUtil getSecurityUtil() {
        return SecurityUtil.getInstance();
    }
}
