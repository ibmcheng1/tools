/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.resources;

import java.util.List;

import javax.naming.InitialContext;
import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.ContactHistoryBiz;
import com.bcbssc.desktop.rest.security.util.SecurityUtil;
import com.bcbssc.desktop.rest.util.ResourceExecutor;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.exception.DataAccessException;
import com.bcbssc.domain.entity.inform.InformRecord;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

/**
 * JAX-RS enabled resource for contact history
 */
@Path("")
public class ContactHistoryResource {

    private static final Log log = LogFactory.getLog(ContactHistoryResource.class);
    private static final String BINDING_NAME = "java:global/commercial-desktop-backend-ear/desktop-app-ejb/contactHistoryBizBD!com.bcbssc.desktop.biz.ContactHistoryBiz";

    /**
     * Gets a list of contacts for the provided subscriber.
     *
     * @param request The HttpServletRequest associated with the call.
     * @param subscriberId The subscriber ID to use to get the contact list.
     * @return Returns a list of {@link InformRecord} objects.
     */
    @GET
    @Path("/subscriber/{subscriberId}/contacts")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
                    summary = "Gets a list of contacts for the provided subscriber",
                    parameters = {
                                    @Parameter(
                                                    in = ParameterIn.HEADER,
                                                    name = "token",
                                                    required = true,
                                                    description = "The security token received from the /security/authenticate resource",
                                                    schema = @Schema(
                                                                    type = "string"
                                                                    )
                                                    )
                    },
                    responses = {
                                    @ApiResponse(
                                                    description = "The contact list",
                                                    content = @Content(
                                                                    mediaType = "application/json",
                                                                    array = @ArraySchema(schema = @Schema(implementation = InformRecord.class, description = "A list of InformRecord objects"))
                                                                    )
                                                    )
                    },
                    tags = { "Subscriber" }
                    )
    public List<InformRecord> getContactHistory(
                    @Context HttpServletRequest request,
                    @Context HttpServletResponse response,
                    @PathParam("subscriberId")
                    @Parameter(
                                    in = ParameterIn.PATH,
                                    name = "subscriberId",
                                    required = true,
                                    description = "The subscriber ID to use to get the contact list",
                                    schema = @Schema(type = "string")
                                    )
                    String subscriberId) {
        return ResourceExecutor.getInstance().execute(() -> {
            List<InformRecord> records;
            if (log.isTraceEnabled()) {
                log.trace("Looking up contact history for key id [" + subscriberId + "]");
            }
            try {
                final Subject subject = DesktopAPI.getUserSubject(SecurityUtil.getInstance().getSecurityTokenId(request));
                records = getContactHistoryBiz().getContactHistoryRecords(subscriberId, SubjectUtils.getInformIdStrict(subject).getCompany(), null, subject);
            } catch (final Exception e) {
                throw new DataAccessException("Error retrieving contact history", e);
            }
            return records;
        }, request, response);
    }

    /**
     * Gets a list of contacts for the provided group.
     *
     * @param request The HttpServletRequest associated with the call.
     * @param groupId The group ID to use to get the contact list.
     * @return Returns a list of {@link InformRecord} objects.
     */
    @GET
    @Path("/group/{groupId}/contacts")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
                    summary = "Gets a list of contacts for the provided group",
                    responses = {
                                    @ApiResponse(
                                                    description = "The contact list",
                                                    content = @Content(
                                                                    mediaType = "application/json",
                                                                    schema = @Schema(implementation = List.class, description = "A list of InformRecord objects")
                                                                    )
                                                    )
                    },
                    tags = { "Group" }
                    )
    public List<InformRecord> getGroupContactHistory(
                    @Context HttpServletRequest request,
                    @Context HttpServletResponse response,
                    @PathParam("groupId")
                    @Parameter(
                                    in = ParameterIn.PATH,
                                    name = "groupId",
                                    required = true,
                                    description = "The group ID to use to get the contact list",
                                    schema = @Schema(type = "string")
                                    )
                    String groupId) {
        return getContactHistory(request, response, groupId);
    }

    private ContactHistoryBiz getContactHistoryBiz() {
        ContactHistoryBiz biz;
        try {
            final InitialContext context = new InitialContext();
            biz = (ContactHistoryBiz) context.lookup(BINDING_NAME);
        } catch (final Exception e) {
            throw new DataAccessException("Error looking up ContactHistoryBiz", e);
        }
        return biz;
    }
}
