/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.model.alerts;

import com.bcbssc.domain.entity.alerts.AlertType;
import com.bcbssc.domain.entity.codes.ControlCode;

public class MemberAlerts {

    private AlertType alertType;
    private String deferral;
    private String override;
    private String exceptionDescription;
    private ControlCode controlCode;
    private boolean claimStatusAlert;
    private boolean claimSubrogationAlert;
    private String claimStatusCategoryDescription;

    public AlertType getAlertType() {
        return alertType;
    }

    public void setAlertType(AlertType alertType) {
        this.alertType = alertType;
    }

    public String getDeferral() {
        return deferral;
    }

    public void setDeferral(String deferral) {
        this.deferral = deferral;
    }

    public String getOverride() {
        return override;
    }

    public void setOverride(String override) {
        this.override = override;
    }

    public String getExceptionDescription() {
        return exceptionDescription;
    }

    public void setExceptionDescription(String exceptionDescription) {
        this.exceptionDescription = exceptionDescription;
    }

    public ControlCode getControlCode() {
        return controlCode;
    }

    public void setControlCode(ControlCode controlCode) {
        this.controlCode = controlCode;
    }

    public boolean isClaimStatusAlert() {
        return claimStatusAlert;
    }

    public void setClaimStatusAlert(boolean claimStatusAlert) {
        this.claimStatusAlert = claimStatusAlert;
    }

    public boolean isClaimSubrogationAlert() {
        return claimSubrogationAlert;
    }

    public void setClaimSubrogationAlert(boolean claimSubrogationAlert) {
        this.claimSubrogationAlert = claimSubrogationAlert;
    }

    public String getClaimStatusCategoryDescription() {
        return claimStatusCategoryDescription;
    }

    public void setClaimStatusCategoryDescription(String claimStatusCategoryDescription) {
        this.claimStatusCategoryDescription = claimStatusCategoryDescription;
    }
}
