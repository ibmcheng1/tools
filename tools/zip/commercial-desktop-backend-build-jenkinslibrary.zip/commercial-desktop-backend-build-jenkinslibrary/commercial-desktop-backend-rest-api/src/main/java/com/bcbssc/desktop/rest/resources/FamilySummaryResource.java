/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.resources;

import javax.naming.InitialContext;
import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.FamilySummaryBiz;
import com.bcbssc.desktop.rest.model.FamilySummaryResponse;
import com.bcbssc.desktop.rest.security.util.SecurityUtil;
import com.bcbssc.desktop.rest.util.ResourceExecutor;
import com.bcbssc.desktop.util.exception.DataAccessException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@Path("")
public class FamilySummaryResource {

    private static final String BINDING_NAME = "java:global/commercial-desktop-backend-ear/desktop-app-ejb/FamilySummaryBizBDImpl!com.bcbssc.desktop.biz.FamilySummaryBiz";

    @GET
    @Path("/subscriber/{subscriberId}/family")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
                    summary = "Gets the list of family members for the provided subscriber",
                    parameters = {
                                    @Parameter(
                                                    in = ParameterIn.HEADER,
                                                    name = "token",
                                                    required = true,
                                                    description = "The security token received from the /security/authenticate resource",
                                                    schema = @Schema(
                                                                    type = "string"
                                                                    )
                                                    )
                    },
                    responses = {
                                    @ApiResponse(
                                                    description = "The list of family members for the subscriber",
                                                    content = @Content(
                                                                    mediaType = "application/json",
                                                                    schema = @Schema(implementation = FamilySummaryResponse.class, description = "The family summary for the subscriber")
                                                                    )
                                                    )
                    },
                    tags = { "Subscriber" }
                    )
    public FamilySummaryResponse getFamilySummary(
                    @Context HttpServletRequest request,
                    @Context HttpServletResponse response,
                    @PathParam("subscriberId")
                    @Parameter(
                                    in = ParameterIn.PATH,
                                    name = "subscriberId",
                                    required = true,
                                    description = "The subscriber ID to use to get the family summary",
                                    schema = @Schema(type = "string")
                                    )
                    String subscriberId) {
        return ResourceExecutor.getInstance().execute(() -> {
            final FamilySummaryResponse familySummaryResponse = new FamilySummaryResponse();
            final Subject subject = DesktopAPI.getUserSubject(SecurityUtil.getInstance().getSecurityTokenId(request));
            familySummaryResponse.setFamilySummary(getFamilySummaryBiz().getFamilySummary(subscriberId, subject, false));
            return familySummaryResponse;
        }, request, response);
    }

    private FamilySummaryBiz getFamilySummaryBiz() {
        FamilySummaryBiz biz;
        try {
            final InitialContext context = new InitialContext();
            biz = (FamilySummaryBiz) context.lookup(BINDING_NAME);
        } catch (final Exception e) {
            throw new DataAccessException("Error looking up FamilySummaryBiz", e);
        }
        return biz;
    }

}
