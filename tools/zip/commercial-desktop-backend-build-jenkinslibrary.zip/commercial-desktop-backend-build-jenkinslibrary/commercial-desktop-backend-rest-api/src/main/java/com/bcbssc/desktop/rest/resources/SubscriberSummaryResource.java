/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.resources;

import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

import javax.naming.InitialContext;
import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.SubscriberBiz;
import com.bcbssc.desktop.rest.model.SubscriberSummaryResponse;
import com.bcbssc.desktop.rest.security.util.SecurityUtil;
import com.bcbssc.desktop.rest.util.ResourceExecutor;
import com.bcbssc.desktop.util.exception.DataAccessException;
import com.bcbssc.domain.entity.Bill;
import com.bcbssc.domain.entity.Subscriber;
import com.bcbssc.domain.entity.enrollment.Application;
import com.bcbssc.domain.valueobject.Agent;
import com.bcbssc.domain.valueobject.PhoneNumber;
import com.bcbssc.financial.model.FinancialAccount;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

/**
 * JAX-RS enabled resource for subscriber summary
 */
@Path("")
public class SubscriberSummaryResource {

    private static final Log log = LogFactory.getLog(SubscriberSummaryResource.class);
    private static final String BINDING_NAME = "java:global/commercial-desktop-backend-ear/desktop-subscriber-ejb/SubscriberBizBDImpl!com.bcbssc.desktop.biz.SubscriberBiz";
    private static final String LONG_PHONE_PATTERN = "{0}: ({3}){1}-{2}";
    private static final String SHORT_PHONE_PATTERN = "{0}: {1}-{2}";

    /**
     * Gets the subscriber summary information for the provided ID.
     *
     * @param request The HttpServletRequest associated with the call.
     * @param subscriberId The subscriber ID to use to get the summary.
     * @return Returns a {@link SubscriberSummaryResponse} object.
     */
    @GET
    @Path("/subscriber/{subscriberId}/summary")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
                    summary = "Gets the subscriber summary information for the provided ID",
                    parameters = {
                                    @Parameter(
                                                    in = ParameterIn.HEADER,
                                                    name = "token",
                                                    required = true,
                                                    description = "The security token received from the /security/authenticate resource",
                                                    schema = @Schema(
                                                                    type = "string"
                                                                    )
                                                    )
                    },
                    responses = {
                                    @ApiResponse(
                                                    description = "The subscriber summary response",
                                                    content = @Content(
                                                                    mediaType = "application/json",
                                                                    schema = @Schema(implementation = SubscriberSummaryResponse.class, description = "The summary response object")
                                                                    )
                                                    )
                    },
                    tags = { "Subscriber" }
                    )
    public SubscriberSummaryResponse getSubscriberSummary(
                    @Context HttpServletRequest request,
                    @Context HttpServletResponse response,
                    @PathParam("subscriberId")
                    @Parameter(
                                    in = ParameterIn.PATH,
                                    name = "subscriberId",
                                    required = true,
                                    description = "The subscriber ID to use to get the summary",
                                    schema = @Schema(type = "string")
                                    )
                    String subscriberId) {
        return ResourceExecutor.getInstance().execute(() -> {

            final SubscriberSummaryResponse subscriberSummaryResponse = new SubscriberSummaryResponse();

            if (log.isTraceEnabled()) {
                log.trace("Looking up the subscriber summary for subscriber ID [" + subscriberId + "]");
            }
            final Subject subject = DesktopAPI.getUserSubject(SecurityUtil.getInstance().getSecurityTokenId(request));
            final Map<String, Object> results = getSubscriberBiz().getSubscriberInformation(getSubscriberObject(subscriberId), subject, true, false);
            final Subscriber subscriber = (Subscriber) results.get(SubscriberBiz.SUBSCRIBER_KEY);
            final List<Application> applicationList = (List<Application>) results.get(SubscriberBiz.APPLICATIONS_KEY);

            subscriberSummaryResponse.setAgent((Agent) results.get(SubscriberBiz.AGENT_KEY));
            subscriberSummaryResponse.setFinancialAccount((FinancialAccount) results.get(SubscriberBiz.FINANCIAL_KEY));
            subscriberSummaryResponse.setHicNumber((String) results.get(SubscriberBiz.MEDICARE_KEY));
            subscriberSummaryResponse.setSubscriber(subscriber);
            subscriberSummaryResponse.setLoadableSubscriber(subscriber);
            subscriberSummaryResponse.setPhoneToolTipString(getPhoneToolTip(subscriber));
            subscriberSummaryResponse.setSubscriberId(subscriber.getId());
            subscriberSummaryResponse.setBill((Bill) results.get(SubscriberBiz.BILLING_KEY));
            subscriberSummaryResponse.setApplicationDataPresent((null != applicationList) && !applicationList.isEmpty());
            subscriberSummaryResponse.setErrorOccured(false);

            return subscriberSummaryResponse;

        }, request, response);
    }

    /**
     * Gets the phone tooltip for the display. This will format all of the available extra phone numbers and put them in
     * a string where each is separated by a new line character.
     *
     * @param subscriber The subscriber with the extra phone numbers.
     * @return Returns the phone tooltip.
     */
    String getPhoneToolTip(Subscriber subscriber) {
        String tooltip = StringUtils.EMPTY;
        if (subscriber.getExtraPhoneNumbers() != null) {
            final StringBuilder builder = new StringBuilder();
            for (final PhoneNumber phone : subscriber.getExtraPhoneNumbers()) {
                try {
                    builder.append(formatPhoneNumber(phone)).append("\n");
                } catch (final IllegalArgumentException e) {
                    log.warn("Could not set the phone tooltip: " + e.getMessage());
                }
            }
            tooltip = builder.toString();
        }
        return tooltip;
    }

    /**
     * Formats the phone number into one of two patterns. If the area code is available, it will use the
     * {@link SubscriberSummaryResource#LONG_PHONE_PATTERN} format. If the area code is not available it will use the
     * {@link SubscriberSummaryResource#SHORT_PHONE_PATTERN} format.
     *
     * @param phone The {@link PhoneNumber} object to format into a string.
     * @return Returns a string formatted phone number.
     */
    String formatPhoneNumber(PhoneNumber phone) {
        String result;
        if (null == phone) {
            throw new IllegalArgumentException("Phone number to be formatted cannot be null");
        } else {
            String pattern = LONG_PHONE_PATTERN;
            if (StringUtils.isBlank(phone.getAreaCode())) {
                pattern = SHORT_PHONE_PATTERN;
            }
            result = MessageFormat.format(pattern, phone.getType(), phone.getPrefix(), phone.getSuffix(), phone.getAreaCode());
        }
        return result;
    }

    private Subscriber getSubscriberObject(String subscriberId) {
        final Subscriber subscriber = new Subscriber();
        subscriber.setId(subscriberId);
        return subscriber;
    }

    private SubscriberBiz getSubscriberBiz() {
        SubscriberBiz biz;
        try {
            final InitialContext context = new InitialContext();
            biz = (SubscriberBiz) context.lookup(BINDING_NAME);
        } catch (final Exception e) {
            throw new DataAccessException("Error looking up SubscriberBiz", e);
        }
        return biz;
    }
}
