/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.rest.resources;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.DesktopStartupBiz;
import com.bcbssc.desktop.rest.security.util.SecurityUtil;
import com.bcbssc.desktop.rest.util.ResourceExecutor;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.InformIdentification;
import com.bcbssc.domain.valueobject.MenuLink;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

/**
 * JAX-RS enabled resource for user data
 */
@Path("/user")
public class UserProfileResource {

    private static Log log = LogFactory.getLog(UserProfileResource.class);

    @GET
    @Path("/inform-identification")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
                    summary = "gets the inform identification for the current user",
                    method = "GET",
                    responses = {
                                    @ApiResponse(
                                                    description = "inform identification information",
                                                    content = @Content(
                                                                    mediaType = "application/json",
                                                                    schema = @Schema(implementation = InformIdentification.class, description = "A user's inform identification")
                                                                    )
                                                    )
                    },
                    tags = { "User", "Inform" }
                    )
    @Parameter(
                    in = ParameterIn.HEADER,
                    name = "token",
                    required = true,
                    description = "The authentication token for the call"
                    )
    public InformIdentification getUserInformIdentification(
                    @Context HttpServletRequest request,
                    @Context HttpServletResponse response){
        return getResourceExecutor().execute(() -> {
            final String securityTokenId = getSecurityUtil().getSecurityTokenIdStrict(request);
            final Subject subject = DesktopAPI.getUserSubjectStrict(securityTokenId);
            return SubjectUtils.getInformId(subject);
        }, request, response);
    }

    @GET
    @Path("/links/control")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
                    summary = "gets RULEs control links for the current user",
                    method = "GET",
                    responses = {
                                    @ApiResponse(
                                                    description = "list of RULEs menu links",
                                                    content = @Content(
                                                                    mediaType = "application/json",
                                                                    array = @ArraySchema(schema = @Schema(implementation = MenuLink.class, description = "A RULEs menu link"))
                                                                    )
                                                    )
                    },
                    tags = { "User", "Rules" }
                    )
    @Parameter(
                    in = ParameterIn.HEADER,
                    name = "token",
                    required = true,
                    description = "The authentication token for the call"
                    )
    public List<MenuLink> getUserControlLinks(
                    @Context HttpServletRequest request,
                    @Context HttpServletResponse response){
        return getResourceExecutor().execute(() -> {
            return getRulesEntries(request, DesktopStartupBiz.RULES_DATA_KEY_CONTROL_LINK);
        }, request, response);
    }

    @GET
    @Path("/links/function")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
                    summary = "gets RULEs function links for the current user",
                    method = "GET",
                    responses = {
                                    @ApiResponse(
                                                    description = "list of RULEs menu links",
                                                    content = @Content(
                                                                    mediaType = "application/json",
                                                                    array = @ArraySchema(schema = @Schema(implementation = MenuLink.class, description = "A RULEs menu link"))
                                                                    )
                                                    )
                    },
                    tags = { "User", "Rules" }
                    )
    @Parameter(
                    in = ParameterIn.HEADER,
                    name = "token",
                    required = true,
                    description = "The authentication token for the call"
                    )
    public List<MenuLink> getUserFunctionLinks(
                    @Context HttpServletRequest request,
                    @Context HttpServletResponse response){
        return getResourceExecutor().execute(() -> {
            return getRulesEntries(request, DesktopStartupBiz.RULES_DATA_KEY_FUNC_NAV_LINKS);
        }, request, response);
    }

    @GET
    @Path("/links/summary")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
                    summary = "gets RULEs summary links for the current user",
                    method = "GET",
                    responses = {
                                    @ApiResponse(
                                                    description = "map of RULEs menu links, keyed by the summary link name",
                                                    content = @Content(
                                                                    mediaType = "application/json",
                                                                    schema = @Schema(implementation = Map.class)
                                                                    )
                                                    )
                    },
                    tags = { "User", "Rules" }
                    )
    @Parameter(
                    in = ParameterIn.HEADER,
                    name = "token",
                    required = true,
                    description = "The authentication token for the call"
                    )
    public Map<String, MenuLink> getUserSummaryLinks(
                    @Context HttpServletRequest request,
                    @Context HttpServletResponse response){
        return getResourceExecutor().execute(() -> {
            return getRulesEntries(request, DesktopStartupBiz.RULES_DATA_KEY_SUMMARY_LINKS);
        }, request, response);
    }

    @GET
    @Path("/links/navigation/root")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
                    summary = "gets RULEs navigation root menu for the current user",
                    method = "GET",
                    responses = {
                                    @ApiResponse(
                                                    description = "collection of RULEs menu links",
                                                    content = @Content(
                                                                    mediaType = "application/json",
                                                                    array = @ArraySchema(schema = @Schema(implementation = MenuLink.class, description = "A RULEs menu link"))
                                                                    )
                                                    )
                    },
                    tags = { "User", "Rules" }
                    )
    @Parameter(
                    in = ParameterIn.HEADER,
                    name = "token",
                    required = true,
                    description = "The authentication token for the call"
                    )
    public Collection<MenuLink> getUserNavigationMenuRoot(
                    @Context HttpServletRequest request,
                    @Context HttpServletResponse response){
        return getResourceExecutor().execute(() -> {
            return getRulesEntries(request, DesktopStartupBiz.RULES_DATA_KEY_NAV_CATEGORY);
        }, request, response);
    }

    @GET
    @Path("/links/navigation/children")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
                    summary = "gets RULEs navigation child menu trees for the current user",
                    method = "GET",
                    responses = {
                                    @ApiResponse(
                                                    description = "Map of a List of RULEs menu links keyed by their parent folder id",
                                                    content = @Content(
                                                                    mediaType = "application/json",
                                                                    schema = @Schema(implementation = Map.class, description = "Map of a List of RULEs menu links keyed by their parent folder id")
                                                                    )
                                                    )
                    },
                    tags = { "User", "Rules" }
                    )
    @Parameter(
                    in = ParameterIn.HEADER,
                    name = "token",
                    required = true,
                    description = "The authentication token for the call"
                    )
    public Map<String, List<MenuLink>> getUserNavigationMenuLinks(
                    @Context HttpServletRequest request,
                    @Context HttpServletResponse response){
        return getResourceExecutor().execute(() -> {
            return getRulesEntries(request, DesktopStartupBiz.RULES_DATA_KEY_NAV_LINKS);
        }, request, response);
    }

    @SuppressWarnings("unchecked")
    protected <T> T getRulesEntries(HttpServletRequest request, String key) throws Exception {
        final String securityTokenId = getSecurityUtil().getSecurityTokenIdStrict(request);
        return (T)DesktopAPI.getRulesEntries(securityTokenId).get(key);
    }

    protected ResourceExecutor getResourceExecutor() {
        return ResourceExecutor.getInstance();
    }

    protected SecurityUtil getSecurityUtil() {
        return SecurityUtil.getInstance();
    }
}
