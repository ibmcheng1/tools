/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.model;

import com.bcbssc.domain.entity.Member;

import java.util.List;

public class FamilySummaryResponse {

    private List<Member> familySummary;

    public List<Member> getFamilySummary() {
        return familySummary;
    }

    public void setFamilySummary(List<Member> familySummary) {
        this.familySummary = familySummary;
    }
}
