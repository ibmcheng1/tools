/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.resources;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.SubscriberBiz;
import com.bcbssc.desktop.rest.model.SubscriberSummaryResponse;
import com.bcbssc.desktop.rest.security.util.SecurityUtil;
import com.bcbssc.desktop.rest.util.ResourceExecutor;
import com.bcbssc.desktop.util.exception.DataAccessException;
import com.bcbssc.desktop.util.jndi.JndiUtils;
import com.bcbssc.domain.entity.Subscriber;
import com.bcbssc.domain.entity.managed.PatientHistory;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

@Path("")
public class ActivitySummaryResource {
    private static final Log log = LogFactory.getLog(ActivitySummaryResource.class);
    private static final String BINDING_NAME = "java:global/commercial-desktop-backend-ear/desktop-subscriber-ejb/SubscriberBizBDImpl!com.bcbssc.desktop.biz.SubscriberBiz";

    /**
     * Gets the activity summary information for the provided IDs.
     *
     * @param request The HttpServletRequest associated with the call.
     * @param response The HttpServletResponse associated with the call.
     * @param subscriberId The subscriber ID to use to get the summary.
     * @return Returns a {@link SubscriberSummaryResponse} object.
     */
    @GET
    @Path("/subscriber/{subscriberId}/member/{memberId}/activity")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
            summary = "Gets the subscriber summary information for the provided ID",
            parameters = {
                    @Parameter(
                            in = ParameterIn.HEADER,
                            name = "token",
                            required = true,
                            description = "The security token received from the /security/authenticate resource",
                            schema = @Schema(
                                    type = "string"
                            )
                    )
            },
            responses = {
                    @ApiResponse(
                            description = "The activity summary response",
                            content = @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = PatientHistory.class, description = "The patient history with activity summary information")
                            )
                    )
            },
            tags = { "Member" }
    )
    public PatientHistory getActivitySummary(
            @Context HttpServletRequest request,
            @Context HttpServletResponse response,
            @PathParam("subscriberId")
            @Parameter(
                    in = ParameterIn.PATH,
                    name = "subscriberId",
                    required = true,
                    description = "The subscriber ID to use to get the summary",
                    schema = @Schema(type = "string"),
                    example = "999574317"
            ) String subscriberId,
            @PathParam("memberId")
            @Parameter(
                    in = ParameterIn.PATH,
                    name = "memberId",
                    required = true,
                    description = "The member ID to use to get the summary",
                    schema = @Schema(type = "string"),
                    example = "001"
            ) String memberId,
            @QueryParam("includeVoided")
            @Parameter(
                    in = ParameterIn.QUERY,
                    name = "includeVoided",
                    description = "A flag to indicate if voided records should be included. Defaults to 'false'",
                    schema = @Schema(type = "boolean"),
                    example = "true"
            ) String includeVoided,
            @QueryParam("page")
            @Parameter(
                    in = ParameterIn.QUERY,
                    name = "page",
                    description = "The page number to start with for results. Defaults to the first page",
                    schema = @Schema(type = "number"),
                    example = "2"
            ) String page) {
        return ResourceExecutor.getInstance().execute(() -> getAuthorizationReferrals(request, subscriberId, memberId, includeVoided, page), request, response);
    }

    PatientHistory getAuthorizationReferrals(HttpServletRequest request, String subscriberId, String memberId, String includeVoided, String page) throws Exception {
        if (log.isTraceEnabled()) {
            log.trace("Looking up activity summary for subscriber ID [" + subscriberId + "] and member ID [" + memberId + "]");
        }

        // get the subject
        final Subject subject = getUserSubject(request);
        // default start page = 0
        int startPage = 0;
        if (StringUtils.isNumeric(page)) {
            startPage = Integer.parseInt(page);
        }
        // If the value isn't passed in or doesn't exactly equal "true" (ignoring case) then the default will to not
        // include the voided activity summary records.
        boolean includeVoid = Boolean.parseBoolean(includeVoided);
        // get the subscriber with the passed in data
        Subscriber subscriber = getSubscriber(subscriberId, memberId);
        return getSubscriberBiz().getAuthorizationReferrals(subscriber, startPage, includeVoid, subject);
    }

    protected Subject getUserSubject(HttpServletRequest request) throws Exception {
        return DesktopAPI.getUserSubject(SecurityUtil.getInstance().getSecurityTokenId(request));
    }

    private Subscriber getSubscriber(String subscriberId, String memberId) {
        Subscriber subscriber = new Subscriber();
        subscriber.setId(subscriberId);
        subscriber.setDatabaseNumber(subscriberId);
        subscriber.setSelectedAMMSPatientId(memberId);
        subscriber.setSelectedPatientId(memberId);

        return subscriber;
    }

    protected SubscriberBiz getSubscriberBiz() {
        try {
            return JndiUtils.lookupObject(SubscriberBiz.class, BINDING_NAME);
        } catch (final Exception e) {
            throw new DataAccessException("Error looking up SubscriberBiz", e);
        }
    }
}
