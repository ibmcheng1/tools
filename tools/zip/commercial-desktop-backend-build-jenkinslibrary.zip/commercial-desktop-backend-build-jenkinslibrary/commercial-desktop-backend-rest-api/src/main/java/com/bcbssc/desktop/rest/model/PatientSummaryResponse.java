/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.model;

import com.bcbssc.domain.entity.Member;
import com.bcbssc.domain.valueobject.Address;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class PatientSummaryResponse {
    private static String SPACE = " ";
    private static final Log log = LogFactory.getLog(PatientSummaryResponse.class);

    private Member selectedMember;

    public Member getSelectedMember() {
        return selectedMember;
    }

    public void setSelectedMember(Member selectedMember) {
        this.selectedMember = selectedMember;
    }

    /**
     * Gets concatinated name from selectedMember.
     *
     * @return name or empty string
     */
    public String getName() {
        String name = StringUtils.EMPTY;
        try {
            name = selectedMember.getName().getFirstName() + SPACE + selectedMember.getName().getLastName();
        } catch (NullPointerException ne) {
            log.error("Unable to get name from selectedMember:", ne);
        }
        return name;
    }

    /**
     * Gets address 1 from selectedMember
     *
     * @return address1 or empty string
     */
    public String getAddress1() {
        String address1 = StringUtils.EMPTY;
        try {
            address1 = selectedMember.getAddress().getAddress1();
        } catch (NullPointerException ne) {
            log.error("Unable to get address1 from selectedMember:", ne);
        }
        return address1;
    }

    /**
     * Gets address 2 from selectedMember
     *
     * @return address2 or empty string
     */
    public String getAddress2() {
        String address2 = StringUtils.EMPTY;
        try {
            address2 = selectedMember.getAddress().getAddress2();
        } catch (NullPointerException ne) {
            log.error("Unable to get address2 from selectedMember:", ne);
        }
        return address2;
    }

    /**
     * Gets concatenated city, state, and zip from selectedMember
     *
     * @return cityStateZip, or empty string
     */
    public String getCityStateZip() {
        String cityStateZip = StringUtils.EMPTY;
        try {
            Address memberAddress = selectedMember.getAddress();
            if (null != memberAddress.getCity() && null != memberAddress.getState()) {
                cityStateZip = selectedMember.getAddress().getCity() + ", " + memberAddress.getState() + SPACE +
                        memberAddress.getZipcode() + SPACE + memberAddress.getZipcodePostFix();
            }
        } catch (NullPointerException ne) {
            log.error("Unable to get city, state, zip from selectedMember:", ne);
        }
        return cityStateZip;
    }

    /**
     * @return gender from selectedMember
     */
    public String getGender() {
        return selectedMember.getSexName();
    }

    /**
     * Gets the relationship description for the selected member.
     * @return The relationship description.
     */
    public String getRelationship() {
        return selectedMember.getRelationshipName();
    }

    /**
     * @return birthdate from selectedMember
     */
    public String getBirthdate() {
        return selectedMember.getBirthdate();
    }

    /**
     * @return memberId from selectedMember
     */
    public String getMemberId() {
        return selectedMember.getMemberId();
    }

    /**
     * @return cesMemberNumber from selectedMember
     */
    public String getCesMemberNumber() {
        return selectedMember.getCesMemberNumber();
    }

    /**
     * @return primaryCarePhysicianName from selectedMember
     */
    public String getPrimaryCarePhysicianName() {
        return selectedMember.getPrimaryCarePhysicianName();
    }

    /**
     * @return primaryCarePhysicianId from the selectedMember
     */
    public String getPrimaryCarePhysicianId() {
        return selectedMember.getPrimaryCarePhysicianId();
    }

    /**
     * @return true if selectedMember is null
     */
    public boolean isMemberNull() {
        return (null == selectedMember);
    }

    /**
     * If a member is not found during patient selection,
     * an empty Member is stored in Dynacache. This method checks
     * for a non-null selectedMember with a blank id.
     *
     * @return true if selectedMember is not null and has a blank memberId
     */
    public boolean isMemberEmpty() {
        return (null != selectedMember && StringUtils.isBlank(selectedMember.getMemberId()));
    }
}
