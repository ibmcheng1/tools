/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 * ResourceExecutor.java
 *
 */
package com.bcbssc.desktop.rest.util;

import java.security.InvalidParameterException;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.dao.auth.NotAuthenticatedException;
import com.bcbssc.desktop.dao.auth.NotAuthorizedException;
import com.bcbssc.desktop.dao.auth.UserPasswordExpiredException;
import com.bcbssc.desktop.dao.auth.UserRevokedException;
import com.bcbssc.desktop.rest.security.util.SecurityUtil.SecurityTokenException;
import com.bcbssc.desktop.support.DiagnosticException;
import com.bcbssc.desktop.util.exception.DataAccessException;

/**
 * The <code>ResourceExecutor</code> is to be used by JAX-RS resource classes/methods to ensure consistent exception handling and logging
 * across all resource calls.  The IBM JAX-RS servlet provides it's own exception handling (swallowing with a bit of default logging) so using
 * an exception servlet filter attached to the servlet is not an option.
 *
 * @author hx61
 *
 */
public class ResourceExecutor {

    private static final Log log = LogFactory.getLog(ResourceExecutor.class);

    private static ResourceExecutor INSTANCE = new ResourceExecutor();

    private final static List<ExceptionMapping> desktopExceptionMappings = Arrays.asList(
                    new ExceptionMapping(DiagnosticException.class, "SystemError", Status.INTERNAL_SERVER_ERROR),
                    new ExceptionMapping(DataAccessException.class, "DataAccessError", Status.INTERNAL_SERVER_ERROR),
                    new ExceptionMapping(NotAuthenticatedException.class, "NotAuthenticatedError", Status.FORBIDDEN),
                    new ExceptionMapping(NotAuthorizedException.class, "NotAuthorizedError", Status.UNAUTHORIZED),
                    new ExceptionMapping(UserRevokedException.class, "UserRevokedError", Status.UNAUTHORIZED),
                    new ExceptionMapping(UserPasswordExpiredException.class, "UserPasswordExpiredError", Status.UNAUTHORIZED),
                    new ExceptionMapping(SecurityTokenException.class, "SecurityTokenError", Status.UNAUTHORIZED),
                    new ExceptionMapping(InvalidParameterException.class, "InvalidInputError", Status.BAD_REQUEST));

    private final static ExceptionMapping DEFAULT_EXCEPTION_MAPPING =
                    new ExceptionMapping(Throwable.class, "SystemError", Status.INTERNAL_SERVER_ERROR);

    protected ResourceExecutor() {
        // Protected constructor for singleton instance
    }

    public static ResourceExecutor getInstance() {
        return INSTANCE;
    }

    /**
     * Execute the resource logic.  This should wrap *everything* inside the resource method to ensure that any exceptions are caught and
     * handled appropriately.
     *
     * @param <T>
     * @param callable
     * @param request
     * @param response
     * @return
     */
    public <T> T execute(Callable<T> callable, HttpServletRequest request, HttpServletResponse response) {
        T callableResponse = null;
        try {
            callableResponse = callable.call();
        } catch (final Throwable exception) {
            handleException(request, exception);
        }
        return callableResponse;
    }

    private void handleException(final HttpServletRequest request, final Throwable exception) {
        final ExceptionData exceptionDataToLog = getExceptionDataToLog(exception);
        final String incidentId = getIncidentId(request);
        throwResourceExecutorException(incidentId, exceptionDataToLog);
    }

    protected void throwResourceExecutorException(String incidentId, ExceptionData exceptionDataToLog) {
        throw new ResourceExecutorException(
                        exceptionDataToLog.exceptionMapping.responseStatus,
                        exceptionDataToLog.exceptionMapping.errorType,
                        incidentId,
                        exceptionDataToLog.exception);
    }

    public static String getIncidentId(HttpServletRequest request){
        final String sessionId = request.getSession().getId();
        final String incidentId = sessionId + "-" + (new Date()).getTime();
        return incidentId;
    }

    public static ExceptionData getExceptionDataToLog(final Throwable exception){
        //Look to see if one of our desktop exceptions is in the stack somewhere.  If so, pull it out as the exception
        //to log.  This should get a lot of the J2EE and InvocationTargetException wrappers that the server
        //lifecycle will add on top of the thrown exception out of the stack trace.
        Throwable exceptionToLog = null;
        ExceptionMapping exceptionMappingToLog = null;
        final Iterator<ExceptionMapping> desktopExceptionMappingsIterator = desktopExceptionMappings.iterator();
        while(desktopExceptionMappingsIterator.hasNext() && (exceptionToLog == null)) {
            final ExceptionMapping exceptionMapping = desktopExceptionMappingsIterator.next();
            final int desktopExceptionIndex = ExceptionUtils.indexOfType(exception, exceptionMapping.exceptionType);
            if(desktopExceptionIndex > -1){
                exceptionToLog = ExceptionUtils.getThrowables(exception)[desktopExceptionIndex];
                exceptionMappingToLog = exceptionMapping;
            }
        }
        if(exceptionToLog == null) {
            exceptionToLog = exception;
            exceptionMappingToLog = DEFAULT_EXCEPTION_MAPPING;
        }
        return new ExceptionData(exceptionMappingToLog, exceptionToLog);
    }

    public static class ExceptionMapping {

        public Class<? extends Throwable> exceptionType;
        public String errorType;
        public Status responseStatus;

        public ExceptionMapping(Class<? extends Throwable> exceptionType, String errorType, Status responseStatus) {
            super();
            this.exceptionType = exceptionType;
            this.errorType = errorType;
            this.responseStatus = responseStatus;
        }

    }

    public static class ExceptionData {

        public ExceptionMapping exceptionMapping;
        public Throwable exception;

        public ExceptionData(ExceptionMapping exceptionMapping, Throwable exception) {
            super();
            this.exceptionMapping = exceptionMapping;
            this.exception = exception;
        }

    }

    // Interface to assist in testing
    public static interface ResourceExecutorExceptionValidator{
        public void validate(String incidentId, ExceptionData exceptionData);
    }
}
