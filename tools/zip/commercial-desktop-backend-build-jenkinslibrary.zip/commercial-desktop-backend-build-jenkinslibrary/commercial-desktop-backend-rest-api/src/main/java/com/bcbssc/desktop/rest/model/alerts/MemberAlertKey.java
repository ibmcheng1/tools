/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.model.alerts;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class MemberAlertKey implements Comparable<MemberAlertKey> {

    private static final Log log = LogFactory.getLog(MemberAlertKey.class);

    private String patientId;
    private String patientName;

    public MemberAlertKey(String patientId, String patientName) {
        this.patientId = patientId;
        this.patientName = patientName;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    @Override
    public int compareTo(MemberAlertKey o) {
        if (StringUtils.isBlank(this.getPatientId())) {
            return -1;
        }
        if (StringUtils.isBlank(o.getPatientId())) {
            return 1;
        }
        try {
            int patientIdInt1 = Integer.parseInt(this.getPatientId());
            int patientIdInt2 = Integer.parseInt(o.getPatientId());
            if (patientIdInt1 > patientIdInt2) {
                return 1;
            } else if (patientIdInt1 < patientIdInt2) {
                return -1;
            }
        } catch (NumberFormatException numberFormatException) {
            log.error("Unable to compare patient IDs.  Patient \"" + this.getPatientName() + "\" with ID \"" + this.getPatientId() +
                    "\" is being compared to patient \"" + o.getPatientName() + "\" with ID \"" + o.getPatientId());
        }
        return 0;
    }
}
