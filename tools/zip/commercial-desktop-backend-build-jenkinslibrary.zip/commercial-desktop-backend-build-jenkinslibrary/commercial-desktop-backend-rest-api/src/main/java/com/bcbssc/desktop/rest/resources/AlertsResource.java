/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.resources;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.SubscriberBiz;
import com.bcbssc.desktop.biz.alerts.AlertsBiz;
import com.bcbssc.desktop.rest.model.AlertsResponse;
import com.bcbssc.desktop.rest.model.alerts.MemberAlertKey;
import com.bcbssc.desktop.rest.model.alerts.MemberAlerts;
import com.bcbssc.desktop.rest.security.util.SecurityUtil;
import com.bcbssc.desktop.rest.util.ResourceExecutor;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.exception.DataAccessException;
import com.bcbssc.desktop.util.jndi.JndiUtils;
import com.bcbssc.domain.entity.ClaimsAlertRecord;
import com.bcbssc.domain.entity.Coverage;
import com.bcbssc.domain.entity.CoverageId;
import com.bcbssc.domain.entity.ExceptionsSummaryRecord;
import com.bcbssc.domain.entity.MemberMobileNotificationsRecord;
import com.bcbssc.domain.entity.Subscriber;
import com.bcbssc.domain.entity.alerts.Alert;
import com.bcbssc.domain.entity.alerts.AlertResults;
import com.bcbssc.domain.entity.alerts.AlertSearchCriteria;
import com.bcbssc.domain.entity.alerts.AlertType;
import com.bcbssc.domain.entity.alerts.MemberAlert;
import com.bcbssc.domain.entity.alerts.MemberClaimsAlert;
import com.bcbssc.domain.entity.alerts.MemberExceptionAlert;
import com.bcbssc.domain.entity.alerts.MemberMobileNotificationsAlert;
import com.bcbssc.domain.entity.alerts.MemberSubrogationAlert;
import com.bcbssc.domain.entity.enums.Products;
import com.bcbssc.domain.valueobject.MenuLink;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.naming.InitialContext;
import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * JAX-RS enabled resource for alerts
 */
@Path("")
public class AlertsResource {

    private static final Log log = LogFactory.getLog(AlertsResource.class);
    private static final String ALERTS_BINDING_NAME = "java:global/commercial-desktop-backend-ear/desktop-alerts-ejb/alertsBD";
    private static final String SUBSCRIBER_BINDING_NAME = "java:global/commercial-desktop-backend-ear/desktop-subscriber-ejb/SubscriberBizBDImpl!com.bcbssc.desktop.biz.SubscriberBiz";

    @GET
    @Path("/subscriber/{subscriberId}/alerts/{productName}")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
            summary = "Gets the list of alerts specific to the subscriber",
            responses = {
                    @ApiResponse(
                            description = "The alert response",
                            content = @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = AlertsResponse.class, description = "The alerts response")
                            )
                    )
            },
            tags = { "Subscriber" }
    )
    @Parameter(
            in = ParameterIn.HEADER,
            name = "token",
            required = true,
            description = "The authentication token for the call"
    )
    public AlertsResponse getSubscriberAlerts(
            @Context HttpServletRequest request,
            @Context HttpServletResponse response,
            @PathParam("subscriberId")
                    @Parameter(
                            in = ParameterIn.PATH,
                            name = "subscriberId",
                            required = true,
                            description = "The subscriber ID to use to get the alerts",
                            schema = @Schema(
                                    type = "string"
                            )
                    )
            String subscriberId,
            @QueryParam("callCenter")
                    @Parameter(
                            in = ParameterIn.QUERY,
                            name = "callCenter",
                            description = "The call center to filter results for",
                            schema = @Schema(
                                    type = "string"
                            )
                    )
            String callCenter,
            @PathParam("productName")
                    @Parameter(
                            in = ParameterIn.PATH,
                            name = "productName",
                            required = true,
                            description = "The product code to get alerts for",
                            schema = @Schema(
                                    type = "string"
                            )
                    )
            String productName
    ) {
        return ResourceExecutor.getInstance().execute(() -> {
            AlertsResponse alerts = new AlertsResponse();
            if (log.isTraceEnabled()) {
                log.trace("Looking up alerts for the subscriber");
            }
            final Subject subject = DesktopAPI.getUserSubject(SecurityUtil.getInstance().getSecurityTokenId(request));
            AlertSearchCriteria criteria = getAlertSearchCriteria(subscriberId, callCenter, productName, false, alerts, subject);
            AlertResults results = null;
            List<Alert> alertList = null;
            if (null != criteria) {
                results = getAlertsBiz().retrieveDesktopAlerts(criteria, subject);
                alertList = results.alerts;
            }

            //Filter and set member specific alerts to session bean
            filterMemberAlerts(alertList, alerts);

            //Cache claims related alerts
            criteria = this.getAlertSearchCriteria(subscriberId, callCenter, productName, false, alerts, subject);
            cacheProductSpecificAlerts(request, alertList, criteria);

            //Cache notes alerts
            cacheAlert(request, AlertType.SPECIAL_CONSIDERATIONS_ALERT, alertList, null);

            //Cache business sector code.
            cacheBusinessSector(request, results);

            // Set our results, if any, into session UI bean for rendering
            alerts.setAlerts(alertList);

            return alerts;
        }, request, response);
    }

    @GET
    @Path("/group/{groupId}/alerts/{productName}")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
            summary = "Gets the list of alerts specific to the group (not implemented yet)",
            responses = {
                    @ApiResponse(
                            description = "The alert response",
                            content = @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = AlertsResponse.class, description = "The alerts response")
                            )
                    )
            },
            tags = { "Group" }
    )
    @Parameter(
            in = ParameterIn.HEADER,
            name = "token",
            required = true,
            description = "The authentication token for the call"
    )
    public AlertsResponse getGroupAlerts(
            @Context HttpServletRequest request,
            @Context HttpServletResponse response,
            @PathParam("groupId")
            @Parameter(
                    in = ParameterIn.PATH,
                    name = "groupId",
                    required = true,
                    description = "The group ID to use to get the alerts",
                    schema = @Schema(
                            type = "string"
                    )
            )
                    String groupId,
            @QueryParam("callCenter")
            @Parameter(
                    in = ParameterIn.QUERY,
                    name = "callCenter",
                    description = "The call center to filter results for",
                    schema = @Schema(
                            type = "string"
                    )
            )
                    String callCenter,
            @PathParam("productName")
            @Parameter(
                    in = ParameterIn.PATH,
                    name = "productName",
                    required = true,
                    description = "The product code to get alerts for",
                    schema = @Schema(
                            type = "string"
                    )
            )
                    String productName
    ) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    @GET
    @Path("/subscriber/{subscriberId}/member/{memberId}/alerts/{productName}")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
            summary = "Gets the list of alerts specific to the member (not implemented yet)",
            responses = {
                    @ApiResponse(
                            description = "The alert response",
                            content = @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = AlertsResponse.class, description = "The alerts response")
                            )
                    )
            },
            tags = { "Member" }
    )
    @Parameter(
            in = ParameterIn.HEADER,
            name = "token",
            required = true,
            description = "The authentication token for the call"
    )
    public AlertsResponse getMemberAlerts(
            @Context HttpServletRequest request,
            @Context HttpServletResponse response,
            @PathParam("subscriberId")
            @Parameter(
                    in = ParameterIn.PATH,
                    name = "subscriberId",
                    required = true,
                    description = "The subscriber ID to use to get the alerts",
                    schema = @Schema(
                            type = "string"
                    )
            )
                    String subscriberId,
            @PathParam("memberId")
            @Parameter(
                    in = ParameterIn.PATH,
                    name = "memberId",
                    required = true,
                    description = "The member ID to use to get the alerts",
                    schema = @Schema(
                            type = "string"
                    )
            )
                    String memberId,
            @QueryParam("callCenter")
            @Parameter(
                    in = ParameterIn.QUERY,
                    name = "callCenter",
                    description = "The call center to filter results for",
                    schema = @Schema(
                            type = "string"
                    )
            )
                    String callCenter,
            @PathParam("productName")
            @Parameter(
                    in = ParameterIn.PATH,
                    name = "productName",
                    required = true,
                    description = "The product code to get alerts for",
                    schema = @Schema(
                            type = "string"
                    )
            )
                    String productName
    ) {
        throw new UnsupportedOperationException("This method hasn't been implemented yet");
    }

    private void filterMemberAlerts(List<Alert> alerts, AlertsResponse response) {
        List<MemberAlerts> memberAlerts;
        MemberExceptionAlert exceptionAlerts = new MemberExceptionAlert();
        MemberClaimsAlert claimsAlerts = new MemberClaimsAlert();
        MemberSubrogationAlert subrogationAlerts = new MemberSubrogationAlert();
        MemberMobileNotificationsAlert mobileNotificationsAlerts = new MemberMobileNotificationsAlert();
        Set<String> patientIdSet = new HashSet<>();
        Map<MemberAlertKey, List<MemberAlerts>> memberAlertsMap = new TreeMap<>();
        MemberAlerts viewBean;

        // Iterate through alerts to identify member alerts and also to get
        // patient id set
        if (alerts != null && alerts.size() > 0) {
            for (Alert alert : alerts) {
                if (alert instanceof MemberAlert) {

                    if (log.isDebugEnabled()) {
                        log.debug("Member alert found " + alert);
                    }
                    if(log.isDebugEnabled()){
                        log.debug("Patient Id Set start " + patientIdSet);
                    }
                    // Find patient ids as set from both exception and claims
                    // alert
                    if (AlertType.EXCEPTION_ALERT.getAlertClass().equals(
                            alert.getClass())) {
                        exceptionAlerts = (MemberExceptionAlert) alert;
                        patientIdSet.addAll(exceptionAlerts.getMemberExceptions()
                                .keySet());
                        if(log.isDebugEnabled()){
                            log.debug("Patient Id Set after Exception alerts" + patientIdSet);
                        }
                    }
                    if (AlertType.CLAIMS_ALERT.getAlertClass().equals(
                            alert.getClass())) {
                        if (log.isDebugEnabled()) {
                            log.debug("Claims Alerts found - " + alert);
                        }
                        claimsAlerts = (MemberClaimsAlert) alert;
                        patientIdSet.addAll(claimsAlerts.getClaimAlerts()
                                .keySet());
                        if(log.isDebugEnabled()){
                            log.debug("Patient Id Set after claim status alerts" + patientIdSet);
                        }
                    }
                    if (AlertType.SUBROGATION_ALERT.getAlertClass().equals(
                            alert.getClass())) {
                        if (log.isDebugEnabled()) {
                            log.debug("Subrogation Alerts found - " + alert);
                        }
                        subrogationAlerts = (MemberSubrogationAlert) alert;
                        patientIdSet.addAll(subrogationAlerts.getSubrogationAlerts().keySet());
                        if(log.isDebugEnabled()){
                            log.debug("Patient Id Set after claim subrogation alerts" + patientIdSet);
                        }
                    }
                    if (AlertType.MOBILE_NOTIFICATIONS_ALERT.getAlertClass().equals(
                            alert.getClass())) {
                        if (log.isDebugEnabled()) {
                            log.debug("Mobile Notification Alerts found - " + alert);
                        }
                        mobileNotificationsAlerts = (MemberMobileNotificationsAlert) alert;
                        patientIdSet.addAll(mobileNotificationsAlerts.getMobileNotificationAlerts().keySet());
                        if(log.isDebugEnabled()){
                            log.debug("Patient Id Set after mobile notification alerts" + patientIdSet);
                        }
                    }
                }
            }
        }

        for (String patientId : patientIdSet) {
            if(log.isDebugEnabled()){
                log.debug("Patient id for view bean is -" + patientId);
            }
            memberAlerts = new ArrayList<>();
            // Create one for contract
            MemberAlertKey memberAlertKey = new MemberAlertKey(patientId, "");
            if (StringUtils.isEmpty(patientId)) {
                memberAlertKey.setPatientName("CONTRACT"); //works for now
            }
            //For each patient, check for exception alerts records
            if (exceptionAlerts != null && exceptionAlerts.getMemberExceptions() != null
                    && exceptionAlerts.getMemberExceptions().get(patientId) != null) {
                //Iterate through exceptions
                for (ExceptionsSummaryRecord record : exceptionAlerts.getMemberExceptions().get(patientId)) {
                    if(record != null){
                        if (patientId.equals(record.getPatientID())) {
                            memberAlertKey.setPatientName(record.getPatientName());
                            //Create view bean for each exception
                            viewBean = new MemberAlerts();
                            viewBean.setAlertType(AlertType.EXCEPTION_ALERT);
                            viewBean.setControlCode(record.getControlCode());
                            viewBean.setDeferral(record.getDeferral());
                            viewBean.setExceptionDescription(record.getExceptionDescription());
                            viewBean.setOverride(record.getOverride());
                            //add view bean to the list
                            memberAlerts.add(viewBean);
                        }
                    }
                }
            }

            //For each patient, check for claims alerts records
            if (claimsAlerts != null && claimsAlerts.getClaimAlerts() != null
                    && claimsAlerts.getClaimAlerts().get(patientId) != null) {
                boolean claimsStatusAlertExist = false;
                //Iterate through records
                for (ClaimsAlertRecord record : claimsAlerts.getClaimAlerts().get(patientId)) {
                    if(record != null){
                        if (patientId.equals(record.getPatientId())) {
                            memberAlertKey.setPatientName(record.getPatientName());
                            // Check for a non-empty claims record and set claims status
                            if(record.getClaimCategoryCode() != null && record.getClaimNumbers() != null
                                    && !record.getClaimNumbers().isEmpty() && !claimsStatusAlertExist){
                                viewBean = new MemberAlerts();
                                viewBean.setAlertType(AlertType.CLAIMS_ALERT);
                                viewBean.setClaimStatusAlert(true);
                                viewBean.setClaimStatusCategoryDescription(record.getClaimCategoryCode().getDescription());
                                //This boolean prevents creating multiple view beans for each record. For claims status alert
                                // we just need to know if a non-empty record exist.
                                claimsStatusAlertExist = true;
                                memberAlerts.add(viewBean);
                            }

                        }
                    }
                }
            }
            //For each patient, check for claims alerts records
            if (subrogationAlerts != null && subrogationAlerts.getSubrogationAlerts() != null
                    && subrogationAlerts.getSubrogationAlerts().get(patientId) != null) {
                boolean claimsSubrogationAlertExist = false;
                //Iterate through records
                for (ClaimsAlertRecord record : subrogationAlerts.getSubrogationAlerts().get(patientId)) {
                    if(record != null){
                        if (patientId.equals(record.getPatientId())) {
                            memberAlertKey.setPatientName(record.getPatientName());
                            // Check for a subrogation claim cateogry code in the records.
                            if(record.getClaimCategoryCode() != null && record.getClaimNumbers() != null
                                    && !record.getClaimNumbers().isEmpty() && !claimsSubrogationAlertExist){
                                viewBean = new MemberAlerts();
                                viewBean.setAlertType(AlertType.SUBROGATION_ALERT);
                                viewBean.setClaimSubrogationAlert(true);
                                //This boolean prevents creating multiple view beans for each subrogation record. For subrogation alert
                                // we just need to know if a subrogation record exist.
                                claimsSubrogationAlertExist = true;
                                memberAlerts.add(viewBean);
                            }
                        }
                    }
                }
            }
            //For each patient, check for mobile notification alerts records
            if (mobileNotificationsAlerts != null && mobileNotificationsAlerts.getMobileNotificationAlerts() != null
                    && mobileNotificationsAlerts.getMobileNotificationAlerts().get(patientId) != null) {
                //Check patient record to see if alert need to show
                MemberMobileNotificationsRecord record = mobileNotificationsAlerts.getMobileNotificationAlerts().get(patientId);
                if(record != null){
                    if (patientId.equals(record.getPatientId())) {
                        memberAlertKey.setPatientName(record.getFirstName());
                        // Check for a alert flag in the record.
                        if(record.isShowAlert()){
                            viewBean = new MemberAlerts();
                            viewBean.setAlertType(AlertType.MOBILE_NOTIFICATIONS_ALERT);
                            memberAlerts.add(viewBean);
                        }
                    }
                }
            }
            // Add member alert key and alerts to the map
            memberAlertsMap.put(memberAlertKey, memberAlerts);
        }
        if(log.isDebugEnabled()){
            log.debug("Alerts Map is - " + memberAlertsMap);
        }
        response.setMemberAlerts(memberAlertsMap);
    }

    private void cacheProductSpecificAlerts(HttpServletRequest request, List<Alert> alerts, AlertSearchCriteria criteria) throws Exception {
        Products product = null;
        if(criteria != null && criteria.getCoverageId() != null && criteria.getCoverageId().getProductCode() != null){
            String productCode = criteria.getCoverageId().getProductCode().getCode();
            product = Products.fromCode(productCode);
        }

        //cache claims and subrogation alerts
        cacheAlert(request, AlertType.CLAIMS_ALERT, alerts, product);
        cacheAlert(request, AlertType.SUBROGATION_ALERT, alerts, product);

        //cache mobile notification alerts
        cacheAlert(request, AlertType.MOBILE_NOTIFICATIONS_ALERT, alerts, product);
    }

    private void cacheBusinessSector(HttpServletRequest request, AlertResults alertResults) throws Exception {
        Subscriber subscriber = fetchCachedData(request, Subscriber.class);
        if (null != subscriber) {
            // Try to update businessSector with a valid, stomp if needed.
            String businessSectorCode = null;

            if (null != alertResults.businessClassificationCode) {
                // This is simple but we might not have it.
                businessSectorCode = alertResults.businessClassificationCode.getClientBusinessSector();
            } else {
                // If not in BCC then check if we have mobile alerts.
                Class<? extends Alert> key = MemberMobileNotificationsAlert.class;
                if (alertResults.crossReference.containsKey(key)) {
                    // Ok we have mobile alerts so inspect them.
                    // There should only be one mobile alert.
                    MemberMobileNotificationsAlert alert = MemberMobileNotificationsAlert.class.cast(alertResults.crossReference.get(key).get(0));
                    if (alert.getMobileNotificationAlerts().size() > 0) {
                        // HAHAHA this is how java wants you to get an arbitrary 'first' entry in a map.
                        Set<String> keys = alert.getMobileNotificationAlerts().keySet();
                        Iterator<String> itr = keys.iterator();
                        String alertKey = itr.next();
                        MemberMobileNotificationsRecord record = alert.getMobileNotificationAlerts().get(alertKey);
                        businessSectorCode = record.getBusinessSectorCode();
                    }
                }
            }
            String sessionId = request.getSession().getId();

            if (null != businessSectorCode) {
                DesktopAPI.setSearchResultProperty(sessionId, Subscriber.class, "businessSector", businessSectorCode);
            }

            if (null != alertResults.isMobileNotificationsEnabledForGroup) {
                DesktopAPI.setSearchResultProperty(sessionId, Subscriber.class, "isMobileNotificationsEnabledForGroup", alertResults.isMobileNotificationsEnabledForGroup);
            }

            if (null != alertResults.engagementMemberRecords) {
                DesktopAPI.setSearchResultProperty(sessionId, Subscriber.class, "engagementMemberRecords", alertResults.engagementMemberRecords);
            }
        }
    }

    /**
     * Cache alerts that are requested to be cached. These cached alerts will retrieved and used by attached applications.
     */
    private void cacheAlert(HttpServletRequest request, AlertType alertType, List<Alert> alerts, Products product) throws Exception {
        if(alerts != null) {
            for(Alert alert : alerts){
                if(alertType.isMatch(alert)){
                    if(log.isDebugEnabled()){
                        log.debug("Setting alert data into cache for " + alert.getClass().getName());
                    }
                    DesktopAPI.getAlertsCache(request).set(product, alertType, alert);
                }
            }
        }
    }

    private AlertSearchCriteria getAlertSearchCriteria(String subscriberId, String callCenter, String productName, boolean patientSpecific, AlertsResponse response, Subject subject) throws Exception {
        AlertSearchCriteria criteria = new AlertSearchCriteria();
        String rpn = SubjectUtils.getClientStrict(subject).getAliasRpn();
        String searchDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        // get the subscriber information
        Subscriber subscriberCriteria = new Subscriber();
        subscriberCriteria.setId(subscriberId);
        Subscriber subscriber;
        try {
            subscriber = (Subscriber) getSubscriberBiz().getSubscriberInformation(subscriberCriteria, subject).get(SubscriberBiz.SUBSCRIBER_KEY);
        } catch (Exception e) {
            throw new DataAccessException("There was an error attempting to retrieve subscriber information for alerts", e);
        }
        criteria.setIdCardNumber(subscriber.getIdCardNumber());
        criteria.setAlphaPrefix(subscriber.getAlphaPrefix());
        criteria.setSubscriberId(subscriber.getId());
        criteria.setCoverageId(getCoverageCriteria(productName, subscriber, response, subject));
        criteria.setPatientId(getPatientCriteria(subscriber, patientSpecific));
        criteria.setAmmsGroupNumber(subscriber.getAmmsGroupNumber());

        // try to parse the date of birth, but it may fail
        try {
            criteria.setSubscriberDateOfBirth(subscriber.getDateOfBirth());
        } catch (Throwable e) {
            criteria.setSubscriberDateOfBirth(new Date(0));
        }

        response.setSubscriber(subscriber);

        criteria.setCallCenter(callCenter);
        criteria.setRpn(rpn);
        criteria.setSearchDate(searchDate);

        return criteria;
    }

    private CoverageId getCoverageCriteria(String productName, Subscriber subscriber, AlertsResponse response, Subject subject) throws Exception {
        CoverageId coverageId = null;
        List<Products> productsForAlerts = fetchProductsForAlerts(subject);
        Map<Products, CoverageId> coveragesOnProduct = new HashMap<>();

        // create a list of products the subscriber has coverage for
        for (Coverage coverage: subscriber.getCoverageItems()) {
            // add all of the subscriber products to the list
            if (coverage.getActive()) {
                // add to the map only if the product is requested for the alerts
                if (productsForAlerts.contains(coverage.getCoverageId().getProductCode())) {
                    coveragesOnProduct.put(coverage.getCoverageId().getProductCode(), coverage.getCoverageId());
                }
            }
        }

        // as long as we actually put together some coverages on the product, save them into the results
        if (!coveragesOnProduct.isEmpty()) {
            response.setSubscriberProducts(new ArrayList<>(coveragesOnProduct.keySet()));
        }

        //
        if (StringUtils.isNotEmpty(productName)) {
            // convert the product name into a Products type
            Products requestedType = getProductCode(productName);
            // as long as it mapped correctly, get the coverage ID off of it
            if (null != requestedType) {
                coverageId = coveragesOnProduct.get(requestedType);
            }
        } else {
            // No specific product was requested, default to health
            coverageId = coveragesOnProduct.get(Products.MEDICAL);

            // if there are no medical coverages then just pick the first one (whatever HashMap considers 'first')
            if (null == coverageId && !coveragesOnProduct.isEmpty()) {
                coverageId = (CoverageId) coveragesOnProduct.values().toArray()[0];
                if (log.isDebugEnabled()) {
                    log.debug("The subscriber did not have medical coverage. Defaulting alerts to view coverage for " + coverageId.getProductCode().getDescription());
                }
            }
        }

        // as long as we have a coverageId, set the selected product code
        if (null != coverageId) {
            response.setSelectedProductCode(coverageId.getProductCode());
        }

        return coverageId;
    }

    private String getPatientCriteria(Subscriber subscriber, boolean patientSpecific) {
        String patientId = "001";
        if (patientSpecific) {
            patientId = subscriber.getSelectedPatientId();
        }
        return patientId;
    }

    private Products getProductCode(String product) {
        Products products = null;
        try {
            products = Products.valueOf(StringUtils.upperCase(product));
        } catch (IllegalArgumentException e) {
            if (log.isDebugEnabled()) {
                log.debug("Unexpected product type: " + product);
            }
        }
        return products;
    }

    private List<Products> fetchProductsForAlerts(Subject subject) throws Exception {
        List<Products> productsForAlerts = new ArrayList<>();
        final String PRODUCT_FOR_ALERTS_RULE_FLAG = "ALERT_PRODUCT_CODES";
        final String COMMA = ",";
        List<String> productsFromRules = null;

        // Read products that we care about in Alerts from RULES entry. Products
        // are listed in the notes for the RULE entry.
        Map<String, ?> ruleEntries = DesktopAPI.getRulesEntries(subject);
        Map<String, MenuLink> userConfig = (Map<String, MenuLink>) ruleEntries.get(MenuLink.FUNCTION_TYPE_USERCONFIG);
        if (userConfig.get(PRODUCT_FOR_ALERTS_RULE_FLAG) != null && userConfig.get(PRODUCT_FOR_ALERTS_RULE_FLAG).getLinkAction() != null) {
            productsFromRules = Arrays.asList(StringUtils.trimToEmpty(StringUtils.deleteWhitespace(userConfig.get(
                            PRODUCT_FOR_ALERTS_RULE_FLAG).getLinkAction())).split(COMMA));
        }

        // Map products from RULES into Product enum
        if (productsFromRules != null) {
            for (String productFromRule : productsFromRules) {
                if (log.isDebugEnabled()) {
                    log.debug(productFromRule + " found in RULES for " + PRODUCT_FOR_ALERTS_RULE_FLAG);
                }
                Products product = getProductCode(productFromRule);
                productsForAlerts.add(product);
            }
        }

        // As a fallback if the products list is not populated correctly from
        // RULES, add them manually.
        if (productsForAlerts.size() == 0) {
            if (log.isDebugEnabled()) {
                log.debug("No products found in RULES for " + PRODUCT_FOR_ALERTS_RULE_FLAG
                        + ", defaulting to hardcoded version of product list - Medical and Dental");
            }
            productsForAlerts.add(Products.MEDICAL);
            productsForAlerts.add(Products.DENTAL);
        }

        return productsForAlerts;
    }

    /**
     * Look for and return the cached data by class type.
     */
    private <T extends Serializable> T fetchCachedData(HttpServletRequest request, Class<T> type) throws Exception {
        T clazz = DesktopAPI.getSearchResult(request, type);
        if (null == clazz && log.isDebugEnabled()) {
            log.debug("No cached object present for type: " + type);
        }
        return clazz;
    }

    private AlertsBiz getAlertsBiz() {
        try {
            return JndiUtils.lookupObject(AlertsBiz.class, ALERTS_BINDING_NAME);
        } catch (Exception e) {
            throw new DataAccessException("Error looking up AlertsBiz");
        }
    }

    private SubscriberBiz getSubscriberBiz() {
        try {
            return JndiUtils.lookupObject(SubscriberBiz.class, SUBSCRIBER_BINDING_NAME);
        } catch (final Exception e) {
            throw new DataAccessException("Error looking up SubscriberBiz", e);
        }
    }

}
