/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.rest.init;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.api.DesktopAPI;

@WebListener
public class CommercialDesktopBackendRestApplicationInitializer implements ServletContextListener {

    private static final Log log = LogFactory.getLog(CommercialDesktopBackendRestApplicationInitializer.class);

    @Override
    public void contextDestroyed(ServletContextEvent arg0) {
        // Do nothing on destroy
    }

    @Override
    public void contextInitialized(ServletContextEvent arg0) {
        try {
            // Remove previously cached data to avoid ClassCastExceptions from class loader differences
            cleanCache();
        } catch (final Exception e) {
            throw new InitializationException("Error initializing commercial desktop rest application.", e);
        }
    }

    private void cleanCache() throws Exception {
        if(log.isTraceEnabled()) {
            log.trace("Removing statically cached data from DynaCache");
        }
        DesktopAPI.removeClientListsCache();
        DesktopAPI.removeSubsystemsRpnMap();
        DesktopAPI.removeAllRulesEntriesCaches();
        DesktopAPI.removeRulesDataTypeEntriesCache();
    }

    public class InitializationException extends RuntimeException {
        private static final long serialVersionUID = 1L;
        public InitializationException(String message, Throwable cause) {
            super(message, cause);
        }
    }


}
