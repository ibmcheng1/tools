/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 *
 */
package com.bcbssc.desktop.rest.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.rest.security.util.SecurityUtil;
import com.bcbssc.desktop.rest.util.ResourceExecutor;
import com.bcbssc.desktop.rest.util.ResourceExecutor.ExceptionData;

/**
 * HTTP servlet filter for validating the security token in the request header if it exists and adding
 * the token id as a request attribute for downstream use.
 */
@WebFilter(filterName="CommercialDesktopBackendRestApplicationSecurityFilter", urlPatterns= {"/*"})
public class SecurityFilter implements Filter {

    private static final Log log = LogFactory.getLog(SecurityFilter.class);

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        final HttpServletRequest httpServletRequest = (HttpServletRequest)request;
        final HttpServletResponse httpServletResponse = (HttpServletResponse)response;
        boolean securityValidationError = false;
        try {
            getSecurityUtil().validateSecurityToken(httpServletRequest);
        } catch (final Throwable exception) {
            securityValidationError = true;
            handleSecurityValidationError(httpServletRequest, httpServletResponse, exception);
        }
        if(!securityValidationError) {
            // No errors occurred while validating the security token, continue processing the request
            chain.doFilter(request, response);
        }
    }

    protected void handleSecurityValidationError(HttpServletRequest request, HttpServletResponse response, Throwable exception) throws IOException {
        final ExceptionData exceptionData = ResourceExecutor.getExceptionDataToLog(exception);
        final String incidentId = ResourceExecutor.getIncidentId(request);
        response.sendError(exceptionData.exceptionMapping.responseStatus.getStatusCode());
        response.setContentType(MediaType.APPLICATION_JSON);
        String responseContent = "";
        responseContent += "{\n";
        responseContent += "    'incidentId': '" + incidentId + "',\n";
        responseContent += "    'errorType': '" + exceptionData.exceptionMapping.errorType + "'\n";
        responseContent += "}";
        response.getWriter().println(responseContent);
        response.flushBuffer();
        log.error("An exception was encountered validating the security token in the SecurityFilter.  Incident id: " + incidentId, exceptionData.exception);
    }

    protected SecurityUtil getSecurityUtil() {
        return SecurityUtil.getInstance();
    }

    @Override
    public void destroy() {

    }

}
