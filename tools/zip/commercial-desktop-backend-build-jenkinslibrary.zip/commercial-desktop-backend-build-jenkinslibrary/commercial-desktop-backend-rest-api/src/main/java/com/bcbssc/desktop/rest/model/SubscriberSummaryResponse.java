/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.model;

import com.bcbssc.domain.entity.Bill;
import com.bcbssc.domain.entity.Subscriber;
import com.bcbssc.domain.valueobject.Agent;
import com.bcbssc.financial.model.FinancialAccount;

/**
 * A generic class to store the subscriber summary response for the rest endpoint.
 */
public class SubscriberSummaryResponse {

    private Subscriber subscriber;
    private Subscriber loadableSubscriber;
    private String hicNumber;
    private Agent agent;
    private FinancialAccount financialAccount;
    private String subscriberId;
    private Bill bill;
    private Boolean errorOccured;
    private Boolean noDataFound;
    private String phoneToolTipString;
    private Boolean applicationDataPresent;

    public Subscriber getSubscriber() {
        return subscriber;
    }

    public void setSubscriber(Subscriber subscriber) {
        this.subscriber = subscriber;
    }

    public Subscriber getLoadableSubscriber() {
        return loadableSubscriber;
    }

    public void setLoadableSubscriber(Subscriber loadableSubscriber) {
        this.loadableSubscriber = loadableSubscriber;
    }

    public String getHicNumber() {
        return hicNumber;
    }

    public void setHicNumber(String hicNumber) {
        this.hicNumber = hicNumber;
    }

    public Agent getAgent() {
        return agent;
    }

    public void setAgent(Agent agent) {
        this.agent = agent;
    }

    public FinancialAccount getFinancialAccount() {
        return financialAccount;
    }

    public void setFinancialAccount(FinancialAccount financialAccount) {
        this.financialAccount = financialAccount;
    }

    public String getSubscriberId() {
        return subscriberId;
    }

    public void setSubscriberId(String subscriberId) {
        this.subscriberId = subscriberId;
    }

    public Bill getBill() {
        return bill;
    }

    public void setBill(Bill bill) {
        this.bill = bill;
    }

    public Boolean getErrorOccured() {
        return errorOccured;
    }

    public void setErrorOccured(Boolean errorOccured) {
        this.errorOccured = errorOccured;
    }

    public Boolean getNoDataFound() {
        return noDataFound;
    }

    public void setNoDataFound(Boolean noDataFound) {
        this.noDataFound = noDataFound;
    }

    public String getPhoneToolTipString() {
        return phoneToolTipString;
    }

    public void setPhoneToolTipString(String phoneToolTipString) {
        this.phoneToolTipString = phoneToolTipString;
    }

    public Boolean getApplicationDataPresent() {
        return applicationDataPresent;
    }

    public void setApplicationDataPresent(Boolean applicationDataPresent) {
        this.applicationDataPresent = applicationDataPresent;
    }
}
