/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.rest.resources;

import java.util.ArrayList;
import java.util.List;

import javax.naming.Binding;
import javax.naming.InitialContext;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import io.swagger.v3.oas.annotations.Operation;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * JAX-RS enabled resource for development utility features
 */
@Path("/util")
public class UtilityResource {

    private static final Log log = LogFactory.getLog(UtilityResource.class);

    /**
     * JAX-RS endpoint to retrieve an HTML list of context bindings from the <code>java:global</code> parent context.
     * This is useful for finding EJB binding names.<br>
     * Endpoint: /resources/util/bindings
     *
     * @return Returns an HTML string with the bindings.
     */
    @GET
    @Path("/bindings")
    @Produces(MediaType.TEXT_HTML)
    @Operation(
            summary = "Gets the available bindings",
            tags = { "Utilities" }
    )
    public String getBindings(){
        final List<String> bindings = new ArrayList<>();
        listBinds("java:global", bindings);
        listBinds("java:comp", bindings);
        final StringBuilder sb = new StringBuilder();
        sb.append("<ul>");
        for(final String binding : bindings) {
            sb.append("<li>").append(binding).append("</li>");
        }
        sb.append("</ul>");
        return sb.toString();
    }

    private void listBinds(String bind, List<String> bindings){
        InitialContext ic;
        try {
            ic = new InitialContext();
            final NamingEnumeration<Binding> en = ic.listBindings(bind);
            while (en.hasMore()){
                final Binding bd = en.next();
                final String bindingName = bind + "/" + bd.getName();
                if (bd.getClassName().equals("javax.naming.Context")) {
                    listBinds(bindingName, bindings);
                } else {
                    bindings.add(bindingName);
                }
            }
        } catch (final NamingException namingException) {
            log.error("Error looking up binding", namingException);
            namingException.printStackTrace();
        }
    }
}
