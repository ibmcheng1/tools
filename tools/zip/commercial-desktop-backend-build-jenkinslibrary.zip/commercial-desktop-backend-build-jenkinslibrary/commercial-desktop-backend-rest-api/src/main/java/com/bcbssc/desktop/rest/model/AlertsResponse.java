/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.model;

import com.bcbssc.desktop.rest.model.alerts.MemberAlertKey;
import com.bcbssc.desktop.rest.model.alerts.MemberAlerts;
import com.bcbssc.domain.entity.Subscriber;
import com.bcbssc.domain.entity.alerts.Alert;
import com.bcbssc.domain.entity.enums.Products;

import java.util.List;
import java.util.Map;

public class AlertsResponse {

    private Subscriber subscriber;
    private List<Alert> alerts;
    private Map<MemberAlertKey, List<MemberAlerts>> memberAlerts;
    private Products selectedProductCode;
    private List<Products> subscriberProducts;

    public Subscriber getSubscriber() {
        return subscriber;
    }

    public void setSubscriber(Subscriber subscriber) {
        this.subscriber = subscriber;
    }

    public List<Alert> getAlerts() {
        return alerts;
    }

    public void setAlerts(List<Alert> alerts) {
        this.alerts = alerts;
    }

    public Map<MemberAlertKey, List<MemberAlerts>> getMemberAlerts() {
        return memberAlerts;
    }

    public void setMemberAlerts(Map<MemberAlertKey, List<MemberAlerts>> memberAlerts) {
        this.memberAlerts = memberAlerts;
    }

    public Products getSelectedProductCode() {
        return selectedProductCode;
    }

    public void setSelectedProductCode(Products selectedProductCode) {
        this.selectedProductCode = selectedProductCode;
    }

    public List<Products> getSubscriberProducts() {
        return subscriberProducts;
    }

    public void setSubscriberProducts(List<Products> subscriberProducts) {
        this.subscriberProducts = subscriberProducts;
    }
}
