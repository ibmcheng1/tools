/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.resources;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.FamilySummaryBiz;
import com.bcbssc.desktop.biz.MemberBiz;
import com.bcbssc.desktop.biz.SubscriberBiz;
import com.bcbssc.desktop.rest.model.PatientSummaryResponse;
import com.bcbssc.desktop.rest.security.util.SecurityUtil;
import com.bcbssc.desktop.rest.util.ResourceExecutor;
import com.bcbssc.desktop.util.jndi.JndiUtils;
import com.bcbssc.domain.entity.Member;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

@Path("")
public class PatientSummaryResource {
    private static final Log log = LogFactory.getLog(PatientSummaryResource.class);
    private static final String SUBSCRIBER_BIZ_BINDING_NAME = "java:global/commercial-desktop-backend-ear/desktop-subscriber-ejb/SubscriberBizBDImpl!com.bcbssc.desktop.biz.SubscriberBiz";
    private static final String FAMILY_SUMMARY_BIZ_BINDING_NAME = "java:global/commercial-desktop-backend-ear/desktop-app-ejb/FamilySummaryBizBDImpl!com.bcbssc.desktop.biz.FamilySummaryBiz";
    private static final String MEMBER_BIZ_BINDING_NAME = "java:global/commercial-desktop-backend-ear/desktop-app-ejb/MemberBizBDImpl!com.bcbssc.desktop.biz.MemberBiz";

    @GET
    @Path("/subscriber/{subscriberId}/member/{memberId}/summary")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
            summary = "Get the patient summary information for the provided ID",
            parameters = {
                    @Parameter(
                            in = ParameterIn.HEADER,
                            name = "token",
                            required = true,
                            description = "The security token received from the /sercurity/authenticate resource",
                            schema = @Schema(
                                    type = "string"
                            )
                    )
            },
            responses = {
                    @ApiResponse(
                            description = "The patient summary response",
                            content = @Content(
                                    mediaType = "application/json",
                                    schema = @Schema(implementation = PatientSummaryResponse.class, description = "The patient summary response object")
                            )
                    )
            },
            tags = { "Member" }
    )
    public PatientSummaryResponse getPatientSummary(
            @Context HttpServletRequest request,
            @Context HttpServletResponse response,
            @PathParam("subscriberId")
            @Parameter(
                    in = ParameterIn.PATH,
                    name = "subscriberId",
                    required = true,
                    description = "The subscriber ID to use to get the summary",
                    schema = @Schema(type = "string"),
                    example = "999574317"
            ) String subscriberId,
            @PathParam("memberId")
            @Parameter(
                    in = ParameterIn.PATH,
                    name = "memberId",
                    required = true,
                    description = "The member ID to use to get the summary",
                    schema = @Schema(type = "string"),
                    example = "001"
            ) String memberId,
            @QueryParam("refresh")
            @Parameter(
                    in = ParameterIn.QUERY,
                    name = "refresh",
                    description = "A flag to indicate if the data should be refreshed. Defaults to 'false'",
                    schema = @Schema(type = "boolean"),
                    example = "true"
            ) String refresh
    ) {
        return ResourceExecutor.getInstance().execute(() -> {
            Member member = getSelectedMember(request, subscriberId, memberId, refresh);
            PatientSummaryResponse patientSummaryResponse = new PatientSummaryResponse();
            patientSummaryResponse.setSelectedMember(member);
            return patientSummaryResponse;
        }, request, response);
    }

    protected Member getSelectedMember(HttpServletRequest request, String subscriberId, String memberId, String isRefresh) throws Exception {
        Boolean refresh = Boolean.getBoolean(isRefresh);
        Subject subject = getUserSubject(request);
        if (log.isTraceEnabled()) {
            log.trace("Getting the family summary information for subscriber id [" + subscriberId + "] and member id + [" + memberId + "]");
        }
        Member member = getFamilySummaryBiz().getMemberFromSummary(subscriberId, memberId, subject, refresh);

        // as long as we got a member back, let's get more information
        if (null != member && StringUtils.isNotBlank(member.getMemberId())) {
            if (log.isTraceEnabled()) {
                log.trace("Getting the member address information for subscriber id [" + subscriberId + "] and member id + [" + memberId + "]");
            }
            member.setAddress(getSubscriberBiz().retrieveMemberAddress(subscriberId, memberId, subject));

            if (log.isTraceEnabled()) {
                log.trace("Getting the primary care physician information for subscriber id [" + subscriberId + "] and member id + [" + memberId + "]");
            }
            Member memberWithPcpData = getMemberBiz().getMember(subscriberId, memberId, subject);

            // as long as it has pcp data, put it on the original member object
            if (memberWithPcpData.isPrimaryCarePhysicianFound()) {
                member.setPrimaryCarePhysicianId(memberWithPcpData.getPrimaryCarePhysicianId());
                member.setPrimaryCarePhysicianName(memberWithPcpData.getPrimaryCarePhysicianName());
            }
        }
        return member;
    }

    protected Subject getUserSubject(HttpServletRequest request) throws Exception {
        return DesktopAPI.getUserSubject(SecurityUtil.getInstance().getSecurityTokenId(request));
    }

    protected SubscriberBiz getSubscriberBiz() {
        return JndiUtils.lookupObject(SubscriberBiz.class, SUBSCRIBER_BIZ_BINDING_NAME);
    }

    protected FamilySummaryBiz getFamilySummaryBiz() {
        return JndiUtils.lookupObject(FamilySummaryBiz.class, FAMILY_SUMMARY_BIZ_BINDING_NAME);
    }

    protected MemberBiz getMemberBiz() {
        return JndiUtils.lookupObject(MemberBiz.class, MEMBER_BIZ_BINDING_NAME);
    }
}
