/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.rest.resources;

import java.util.List;
import java.util.Map;

import javax.naming.InitialContext;
import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.ContractSummaryBiz;
import com.bcbssc.desktop.rest.model.ContractSummaryResponse;
import com.bcbssc.desktop.rest.security.util.SecurityUtil;
import com.bcbssc.desktop.rest.util.ResourceExecutor;
import com.bcbssc.desktop.util.exception.DataAccessException;
import com.bcbssc.domain.entity.Contract;
import com.bcbssc.domain.entity.Subscriber;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@Path("")
public class ContractSummaryResource {

    private static final String BINDING_NAME = "java:global/commercial-desktop-backend-ear/desktop-coverages-ejb/ContractSummaryBizBDImpl!com.bcbssc.desktop.biz.ContractSummaryBiz";

    @GET
    @Path("/subscriber/{subscriberId}/contracts")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
                    summary = "Gets the contracts for the provided subscriber",
                    parameters = {
                                    @Parameter(
                                                    in = ParameterIn.HEADER,
                                                    name = "token",
                                                    required = true,
                                                    description = "The security token received from the /security/authenticate resource",
                                                    schema = @Schema(
                                                                    type = "string"
                                                                    )
                                                    )
                    },
                    responses = {
                                    @ApiResponse(
                                                    description = "The list of contracts for the subsciber and the subscriber",
                                                    content = @Content(
                                                                    mediaType = "application/json",
                                                                    schema = @Schema(implementation = ContractSummaryResponse.class, description = "The contracts for the subscriber")
                                                                    )
                                                    )
                    },
                    tags = { "Subscriber" }
                    )
    public ContractSummaryResponse getContractSummary(
                    @Context HttpServletRequest request,
                    @Context HttpServletResponse response,
                    @PathParam("subscriberId")
                    @Parameter(
                                    in = ParameterIn.PATH,
                                    name = "subscriberId",
                                    required = true,
                                    description = "The subscriber ID to use to get the contracts",
                                    schema = @Schema(type = "string")
                                    )
                    String subscriberId) {
        return ResourceExecutor.getInstance().execute(() -> {
            final ContractSummaryResponse contractSummaryResponse = new ContractSummaryResponse();
            final Subscriber subscriber = new Subscriber();
            subscriber.setId(subscriberId);
            final Subject subject = DesktopAPI.getUserSubject(SecurityUtil.getInstance().getSecurityTokenId(request));
            final Map<String, Object> contractSummaryResponseMap = getContractSummaryBiz().getContractSummary(subscriber, subject, false);
            contractSummaryResponse.setContracts((Map<String, List<Contract>>) contractSummaryResponseMap.get(ContractSummaryBiz.CONTRACTS_KEY));
            contractSummaryResponse.setSubscriber((Subscriber) contractSummaryResponseMap.get(ContractSummaryBiz.CONTRACT_SUBSCRIBER_KEY));
            return contractSummaryResponse;
        }, request, response);


    }

    private ContractSummaryBiz getContractSummaryBiz() {
        ContractSummaryBiz biz;
        try {
            final InitialContext context = new InitialContext();
            biz = (ContractSummaryBiz) context.lookup(BINDING_NAME);
        } catch (final Exception e) {
            throw new DataAccessException("Error looking up the ContractSummaryBiz", e);
        }
        return biz;
    }
}
