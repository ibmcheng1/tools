/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.rest.resources;

import java.util.List;

import javax.naming.InitialContext;
import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.ExceptionsSummaryBiz;
import com.bcbssc.desktop.rest.security.util.SecurityUtil;
import com.bcbssc.desktop.rest.util.ResourceExecutor;
import com.bcbssc.desktop.util.exception.DataAccessException;
import com.bcbssc.domain.entity.ExceptionsSummaryRecord;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

/**
 * JAX-RS enabled resource for subscriber exceptions
 *
 */
@Path("")
public class SubscriberExceptionsSummaryResource {

    private static final Log log = LogFactory.getLog(SubscriberExceptionsSummaryResource.class);

    // Use the bindings utility resource to get a listing of all bound EJBs and their binding name
    // http://localhost:9080/resources/util/bindings
    private static final String remoteEJBBindingName = "java:global/commercial-desktop-backend-ear/desktop-exceptions-summary-ejb/ExceptionsSummaryBizBDImpl!com.bcbssc.desktop.biz.ExceptionsSummaryBiz";

    /**
     * JAX-RS endpoint to retrieve an exceptions summary listing for a subscriber.<br>
     * Endpoint: /resources/subscriber/{subscriberId}/exceptions
     *
     * @return A List of {@link ExceptionsSummaryRecord} objects.
     */
    @GET
    @Path("/subscriber/{subscriberId}/exceptions")
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(
                    summary = "Get a list of exceptions for the provided subscriber",
                    parameters = {
                                    @Parameter(
                                                    in = ParameterIn.HEADER,
                                                    name = "token",
                                                    required = true,
                                                    description = "The security token received from the /security/authenticate resource",
                                                    schema = @Schema(
                                                                    type = "string"
                                                                    )
                                                    )
                    },
                    responses = {
                                    @ApiResponse(
                                                    description = "The exception list",
                                                    content = @Content(
                                                                    mediaType = "application/json",
                                                                    array = @ArraySchema(schema = @Schema(implementation = ExceptionsSummaryRecord.class, description = "A list of ExceptionsSummaryRecord objects"))
                                                                    )
                                                    )
                    },
                    tags = { "Subscriber" }
                    )
    public List<ExceptionsSummaryRecord> getExceptionsSummary(@Context HttpServletRequest request,
                    @Context HttpServletResponse response,
                    @PathParam("subscriberId")
    @Parameter(
                    in = ParameterIn.PATH,
                    name = "subscriberId",
                    required = true,
                    description = "The subscriber ID to use to get the exceptions list",
                    schema = @Schema(
                                    type = "string"
                                    )
                    )
    String subscriberId) {
        return ResourceExecutor.getInstance().execute(() -> {
            List<ExceptionsSummaryRecord> records;
            if(log.isTraceEnabled()) {
                log.trace("Looking up exceptions summary for subscriber id [" + subscriberId + "]");
            }
            final Subject subject = DesktopAPI.getUserSubject(SecurityUtil.getInstance().getSecurityTokenId(request));
            records = getExceptionsSummaryBiz().getExceptionsSummaryData(subscriberId, subject);
            return records;
        }, request, response);
    }

    private ExceptionsSummaryBiz getExceptionsSummaryBiz() {
        ExceptionsSummaryBiz biz;
        try {
            final InitialContext context = new InitialContext();
            biz = (ExceptionsSummaryBiz)context.lookup(remoteEJBBindingName);
        } catch (final Exception exception) {
            throw new DataAccessException("Error looking up ExceptionsSummaryBiz", exception);
        }
        return biz;
    }
}
