# Contributor Covenant Code of Conduct

This does not replace Corporate Policies. Please refer to the follow list of 
applicable policies:

* [65003 - Our Values](https://mye-work.bcbssc.com/wps/portal/mye-work/BlueCross%20BlueShield%20of%20South%20Carolina/61ea2b8045f7883284b5c598848fa126/!ut/p/b1/vZDJbqNQEEW_xR_g8MzMEswMj9fYgIENwjbzGAxm-Pp2ol61lGTT6qpFqaR766oOFmI-Frbxs8jisejauP7YQzqiNJM_CAbgFNIDQIMqOHonAUcU8xIELwH4onjw6efso6LyH35JoIGGDEH0bI1ABwK7YH4e4JzYabMshWnvjiogNXeg0TzpWaDYy6P3lk72hnPLKoRMzMIYwZpix1xNJre8PN3B8FmukMlEHKK-Xpj1neurMGChWVayfTUYnMTXaXE3ux4YoGVo82NSnG2LMpU-znUzPTSXqqaaWIXJ_igrEssvy2r4Rb4IRZ7Vcp083vFozSpVVOL1Sftwtt6j5-wl9comhdFpfzh88-gPHC9Y-Cn5juRPLMNvQzj87wsAcS8eyMGRcuaB_YvGLLVrEix4yZgv7xAE5mA-IKNzufbaVm2ncrM3RwLgPGgzFGULMslrxiuUqtVx4sNo8vPDzU1LtFfAcgdPtiUeVrVbVLsfwnTwP8PwfxqmY2Fxbd7mW_MG3jgOpxlAAIIkAcUCGvPKGx05DzhLMF28SC0eqXvQ4WW2TzelEvj70QJTWVhXXGTMFJQMNxQsrxMTopb9vstPqV6fyQKq4jTR14moRrJjc8YiNB9pxSVAcAkeNZ1RBt_L-aqjlJCmYHLmeyPTLGj7hrR0VabfF5bf3404rhXyyuzPj8d4p--1m0qTD4fWBd4wheBmIE8bcwFsI1yPauRSpQXaLt97yTqMiBtRlme3PmHabBgnE-eKoW01gEqP6GXHHr2pzbsmAMp9KeoSLl0sL2p2dYItAuP2i-bgM6D2xn3e7bC-cZ8mfZJS0d8-mud3u9-XWcMx/dl4/d5/L2dBISEvZ0FBIS9nQSEh/?1dmy&urile=wcm%3apath%3a/My+e-Work/hr/Human+Resources/Policies/BlueCross+BlueShield+of+South+Carolina/61ea2b8045f7883284b5c598848fa126)
* [65202 - Open Door Policy](https://mye-work.bcbssc.com/wps/portal/mye-work/BlueCross%20BlueShield%20of%20South%20Carolina/64f1b5004613d6e096b5d798848fa126/!ut/p/b1/vZDJjqNAEES_xR_gplxs5ohNsZkCsy8XBGYwi7Gx2fn66W7NaaTuvowm85RSRDxlEBERENE9Gctr0pePe3L7uCMmphWN3x1OgJMoDwAFy-DoWQdo0Oy7IHwXgC-GB59-zjxKMv_hRwcGKMbpIHimQho7kvCJoAjhLDyUSURe3Lq9DKjsqCXGNKjXUDLnrg1I8_Sy6zbUYy2-CulwaehtMlX34PS69E8fjQVXitSv82tqG_5Y-EPS2vhcCZRYRPKRdDkfRvB58lGWK3Pd7qPwLjgzD297_wrbKCuwutynHFcMXwp36N7WQtXIwmECc7DKWm-sjoHxckA7qxoYcqf6XZyO6ZyMy5xzyIXLnx6-efSHHn0i-pR81-RPXUbfQjj4dwIwOPY9wYGGZPPAPDOELj-aX0T4LmO_zCFJwiECQMV2tbTKWq9WtZqr7egYV-6EBbTqiJrt1Z901C2OI5G9xk-dW2i6YC5gz-080US8gfcvOdz8AFPB_4TBfwpTiahMm7fp0ryBN46DDAtIQFIUoPeAIbzqwsROhyeE89mL5bLLXdFtjcW0LlJ94LOjDi_bo5pCgdVyULHcq9zzKjkY9LzdPgorV282VWJZGAYmHci6X3VaaPLRHEITwdrwC8_TCkSvB_NUlKqRk2gIB2fKGonaJg5YL6gWyth77vktFnUds4mekSrs-4zJCvdcBmqzWx9JCajV70srqeTuIWqsoDwFVs0GeJVB9xoD1KCxpXdbyHPCeVmeA30u9TE5uRQluaQu27VPZ8PoYhHd6BRTlhfg-ZGIs3xNnXCNQb-eGQ6PfXEO0LTZEG3jjhpjoVwI1o_l-c3mN-VPdjc!/dl4/d5/L2dBISEvZ0FBIS9nQSEh/?1dmy&urile=wcm%3apath%3a/My+e-Work/hr/Human+Resources/Policies/BlueCross+BlueShield+of+South+Carolina/64f1b5004613d6e096b5d798848fa126)
* [65205 - Personal Conduct](https://mye-work.bcbssc.com/wps/portal/mye-work/BlueCross%20BlueShield%20of%20South%20Carolina/b8c8f1004616264f9723d798848fa126/!ut/p/b1/vVDHjqNAEP0Wf4CHNqExR2xoTI4GmosFOJBxwED769cz2tNKO3NZbdWhVNILVY9KqJhKunQsL-lQ9l3afO4JPHCqIa42OhAUNgRANXdgG3ob2ub4NwC_AeAvJYIvvuBulZ34yZc3EKi2vpFCV2XsFUNFVFxgepYe6gXJ4aHAsbdGfebX54FttZJXpFQ6IQ9scKqr1iFbPpynRmedNkqbCvcjgfckoBFkzxfW25Utq1toy3HNlc9NvM-Rj_XhJXJcjGEwd5mC1NJm4ohNPc3UXeOURXUTy68xDSYk37B4k8qNL3BJcoOOfYNyqvpegZtkNRxq37oFCg9GGOXJyJwZMp-uRGiFJfJ-5_DNoz_kGFHJF-S7JH_KMvnWRKD_VAC2wL8VAtpWfBG4DqSsXd-eKPyG8X_VYRgqoGLAHvyKXNVX_fIqQIhvJKr5cidTkl-WZBITtO-Zk6BSmMEQp8e-MCzJJWAtrELkyqKmnO56vfjBTAP_04z-p2YalZRZ-zHl7Qf4EAQa8oABDMsCbg0gFVY5FLKHeUFqVkQ0KgKpoA31CFLeAr4e3ZTTtZ3mi6x3ouswIRFIJFwiDHlGAjCSg-VLb-ZtriMrWTHHe5KREG6b8-jesCsTdo8aJD_374sitdcLj17i4Y49Gw3z4LVAMJnZM_txk45uVbt09PDTG73GvO13zxGtzqEZ7WwOcR3mwmyrXMnc9KaN73unty_mztGObj5VFoMr1lzyznh8VMLkdOLw7Li64lFsnY59qNyfpV6rKxoeFZLq2m5uG1Lq9LG81HvaAccKGGtG6DTuIOboWp2nBXVt96MBPfksxa_PFsXF4hdGf22I/dl4/d5/L2dBISEvZ0FBIS9nQSEh/?1dmy&urile=wcm%3apath%3a/My+e-Work/hr/Human+Resources/Policies/BlueCross+BlueShield+of+South+Carolina/b8c8f1004616264f9723d798848fa126)


## Our Pledge

In the interest of fostering an open and welcoming environment, we as
contributors and maintainers pledge to making participation in our project and
our community a harassment-free experience for everyone, regardless of age, body
size, disability, ethnicity, gender identity and expression, level of experience,
education, socio-economic status, nationality, personal appearance, race,
religion, or sexual identity and orientation.

## Our Standards

Examples of behavior that contributes to creating a positive environment
include:

* Using welcoming and inclusive language
* Being respectful of differing viewpoints and experiences
* Gracefully accepting constructive criticism
* Focusing on what is best for the community
* Showing empathy towards other community members

Examples of unacceptable behavior by participants include:

* The use of sexualized language or imagery and unwelcome sexual attention or
  advances
* Trolling, insulting/derogatory comments, and personal or political attacks
* Public or private harassment
* Publishing others' private information, such as a physical or electronic
  address, without explicit permission
* Other conduct which could reasonably be considered inappropriate in a
  professional setting

## Our Responsibilities

Project maintainers are responsible for clarifying the standards of acceptable
behavior and are expected to take appropriate and fair corrective action in
response to any instances of unacceptable behavior.

Project maintainers have the right and responsibility to remove, edit, or
reject comments, commits, code, wiki edits, issues, and other contributions
that are not aligned to this Code of Conduct, or to ban temporarily or
permanently any contributor for other behaviors that they deem inappropriate,
threatening, offensive, or harmful.

## Scope

This Code of Conduct applies both within project spaces and in public spaces
when an individual is representing the project or its community. Examples of
representing a project or community include using an official project e-mail
address, posting via an official social media account, or acting as an appointed
representative at an online or offline event. Representation of a project may be
further defined and clarified by project maintainers.

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be
reported by contacting your manager. If you are uncomfortable talking with your
manager, or another management person in your division, contact the Corporate
Compliance Officer, Bruce Honeycutt, at 800-288-2227, ext. 43435. All
complaints will be reviewed and investigated and will result in a response that
is deemed necessary and appropriate to the circumstances.

No supervisor, manager, officer or other employee is permitted to engage in
retaliation or any form of harassment directed against an employee who makes
a good faith report of a concern. Anyone who engages in such retribution or
harassment is subject to discipline up to and including dismissal for even the
first offense.

Project maintainers who do not follow or enforce the Code of Conduct in good
faith may face temporary or permanent repercussions as determined by other
members of the project's leadership.

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant][homepage], version 1.4,
available at https://www.contributor-covenant.org/version/1/4/code-of-conduct.html

[homepage]: https://www.contributor-covenant.org
