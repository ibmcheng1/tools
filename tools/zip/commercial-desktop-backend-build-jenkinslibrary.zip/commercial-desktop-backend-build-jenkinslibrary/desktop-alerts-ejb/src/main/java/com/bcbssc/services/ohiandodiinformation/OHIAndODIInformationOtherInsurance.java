
package com.bcbssc.services.ohiandodiinformation;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OHIAndODIInformationOtherInsurance complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OHIAndODIInformationOtherInsurance">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="othInsCoverageLevel" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsMemberNumberAttached" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsSubscriberNumberAttached" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsEmployerName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsSubscriberId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsMemberNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsProductCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsPolicyNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsBeginDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsTerminationDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsInfoLastUpdateDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsEmployeeFirstName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsEmployeeLastName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsMemberRelationship" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsMemberRelationshipDesc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsPlanCoverageType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsPlanCoverageTypeDesc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsPrimarySecondaryInd" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsPlanName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OHIAndODIInformationOtherInsurance", propOrder = {
    "othInsCoverageLevel",
    "othInsMemberNumberAttached",
    "othInsSubscriberNumberAttached",
    "othInsEmployerName",
    "othInsSubscriberId",
    "othInsMemberNumber",
    "othInsProductCode",
    "othInsPolicyNumber",
    "othInsBeginDate",
    "othInsTerminationDate",
    "othInsInfoLastUpdateDate",
    "othInsEmployeeFirstName",
    "othInsEmployeeLastName",
    "othInsMemberRelationship",
    "othInsMemberRelationshipDesc",
    "othInsPlanCoverageType",
    "othInsPlanCoverageTypeDesc",
    "othInsPrimarySecondaryInd",
    "othInsPlanName"
})
public class OHIAndODIInformationOtherInsurance {

    @XmlElement(required = true, nillable = true)
    protected String othInsCoverageLevel;
    @XmlElement(required = true, nillable = true)
    protected String othInsMemberNumberAttached;
    @XmlElement(required = true, nillable = true)
    protected String othInsSubscriberNumberAttached;
    @XmlElement(required = true, nillable = true)
    protected String othInsEmployerName;
    @XmlElement(required = true, nillable = true)
    protected String othInsSubscriberId;
    @XmlElement(required = true, nillable = true)
    protected String othInsMemberNumber;
    @XmlElement(required = true, nillable = true)
    protected String othInsProductCode;
    @XmlElement(required = true, nillable = true)
    protected String othInsPolicyNumber;
    @XmlElement(required = true, nillable = true)
    protected String othInsBeginDate;
    @XmlElement(required = true, nillable = true)
    protected String othInsTerminationDate;
    @XmlElement(required = true, nillable = true)
    protected String othInsInfoLastUpdateDate;
    @XmlElement(required = true, nillable = true)
    protected String othInsEmployeeFirstName;
    @XmlElement(required = true, nillable = true)
    protected String othInsEmployeeLastName;
    @XmlElement(required = true, nillable = true)
    protected String othInsMemberRelationship;
    @XmlElement(required = true, nillable = true)
    protected String othInsMemberRelationshipDesc;
    @XmlElement(required = true, nillable = true)
    protected String othInsPlanCoverageType;
    @XmlElement(required = true, nillable = true)
    protected String othInsPlanCoverageTypeDesc;
    @XmlElement(required = true, nillable = true)
    protected String othInsPrimarySecondaryInd;
    @XmlElement(required = true, nillable = true)
    protected String othInsPlanName;

    /**
     * Gets the value of the othInsCoverageLevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsCoverageLevel() {
        return othInsCoverageLevel;
    }

    /**
     * Sets the value of the othInsCoverageLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsCoverageLevel(String value) {
        this.othInsCoverageLevel = value;
    }

    /**
     * Gets the value of the othInsMemberNumberAttached property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsMemberNumberAttached() {
        return othInsMemberNumberAttached;
    }

    /**
     * Sets the value of the othInsMemberNumberAttached property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsMemberNumberAttached(String value) {
        this.othInsMemberNumberAttached = value;
    }

    /**
     * Gets the value of the othInsSubscriberNumberAttached property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsSubscriberNumberAttached() {
        return othInsSubscriberNumberAttached;
    }

    /**
     * Sets the value of the othInsSubscriberNumberAttached property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsSubscriberNumberAttached(String value) {
        this.othInsSubscriberNumberAttached = value;
    }

    /**
     * Gets the value of the othInsEmployerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsEmployerName() {
        return othInsEmployerName;
    }

    /**
     * Sets the value of the othInsEmployerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsEmployerName(String value) {
        this.othInsEmployerName = value;
    }

    /**
     * Gets the value of the othInsSubscriberId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsSubscriberId() {
        return othInsSubscriberId;
    }

    /**
     * Sets the value of the othInsSubscriberId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsSubscriberId(String value) {
        this.othInsSubscriberId = value;
    }

    /**
     * Gets the value of the othInsMemberNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsMemberNumber() {
        return othInsMemberNumber;
    }

    /**
     * Sets the value of the othInsMemberNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsMemberNumber(String value) {
        this.othInsMemberNumber = value;
    }

    /**
     * Gets the value of the othInsProductCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsProductCode() {
        return othInsProductCode;
    }

    /**
     * Sets the value of the othInsProductCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsProductCode(String value) {
        this.othInsProductCode = value;
    }

    /**
     * Gets the value of the othInsPolicyNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsPolicyNumber() {
        return othInsPolicyNumber;
    }

    /**
     * Sets the value of the othInsPolicyNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsPolicyNumber(String value) {
        this.othInsPolicyNumber = value;
    }

    /**
     * Gets the value of the othInsBeginDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsBeginDate() {
        return othInsBeginDate;
    }

    /**
     * Sets the value of the othInsBeginDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsBeginDate(String value) {
        this.othInsBeginDate = value;
    }

    /**
     * Gets the value of the othInsTerminationDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsTerminationDate() {
        return othInsTerminationDate;
    }

    /**
     * Sets the value of the othInsTerminationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsTerminationDate(String value) {
        this.othInsTerminationDate = value;
    }

    /**
     * Gets the value of the othInsInfoLastUpdateDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsInfoLastUpdateDate() {
        return othInsInfoLastUpdateDate;
    }

    /**
     * Sets the value of the othInsInfoLastUpdateDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsInfoLastUpdateDate(String value) {
        this.othInsInfoLastUpdateDate = value;
    }

    /**
     * Gets the value of the othInsEmployeeFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsEmployeeFirstName() {
        return othInsEmployeeFirstName;
    }

    /**
     * Sets the value of the othInsEmployeeFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsEmployeeFirstName(String value) {
        this.othInsEmployeeFirstName = value;
    }

    /**
     * Gets the value of the othInsEmployeeLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsEmployeeLastName() {
        return othInsEmployeeLastName;
    }

    /**
     * Sets the value of the othInsEmployeeLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsEmployeeLastName(String value) {
        this.othInsEmployeeLastName = value;
    }

    /**
     * Gets the value of the othInsMemberRelationship property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsMemberRelationship() {
        return othInsMemberRelationship;
    }

    /**
     * Sets the value of the othInsMemberRelationship property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsMemberRelationship(String value) {
        this.othInsMemberRelationship = value;
    }

    /**
     * Gets the value of the othInsMemberRelationshipDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsMemberRelationshipDesc() {
        return othInsMemberRelationshipDesc;
    }

    /**
     * Sets the value of the othInsMemberRelationshipDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsMemberRelationshipDesc(String value) {
        this.othInsMemberRelationshipDesc = value;
    }

    /**
     * Gets the value of the othInsPlanCoverageType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsPlanCoverageType() {
        return othInsPlanCoverageType;
    }

    /**
     * Sets the value of the othInsPlanCoverageType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsPlanCoverageType(String value) {
        this.othInsPlanCoverageType = value;
    }

    /**
     * Gets the value of the othInsPlanCoverageTypeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsPlanCoverageTypeDesc() {
        return othInsPlanCoverageTypeDesc;
    }

    /**
     * Sets the value of the othInsPlanCoverageTypeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsPlanCoverageTypeDesc(String value) {
        this.othInsPlanCoverageTypeDesc = value;
    }

    /**
     * Gets the value of the othInsPrimarySecondaryInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsPrimarySecondaryInd() {
        return othInsPrimarySecondaryInd;
    }

    /**
     * Sets the value of the othInsPrimarySecondaryInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsPrimarySecondaryInd(String value) {
        this.othInsPrimarySecondaryInd = value;
    }

    /**
     * Gets the value of the othInsPlanName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsPlanName() {
        return othInsPlanName;
    }

    /**
     * Sets the value of the othInsPlanName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsPlanName(String value) {
        this.othInsPlanName = value;
    }

}
