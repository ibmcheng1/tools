@javax.xml.bind.annotation.XmlSchema(namespace = "http://OtherInsNegativeRespMaint.CISIC108EJB.commercial.bcbssc.com")
package com.bcbssc.services.otherinsnegativerespmaint;
