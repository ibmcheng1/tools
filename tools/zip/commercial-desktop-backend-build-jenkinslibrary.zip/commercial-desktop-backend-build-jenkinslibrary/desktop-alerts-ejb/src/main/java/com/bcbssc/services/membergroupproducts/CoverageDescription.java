
package com.bcbssc.services.membergroupproducts;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CoverageDescription.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="CoverageDescription">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="PAST_COVERAGE"/>
 *     &lt;enumeration value="CURRENT_COVERAGE"/>
 *     &lt;enumeration value="FUTURE_COVERAGE"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "CoverageDescription")
@XmlEnum
public enum CoverageDescription {

    PAST_COVERAGE,
    CURRENT_COVERAGE,
    FUTURE_COVERAGE;

    public String value() {
        return name();
    }

    public static CoverageDescription fromValue(String v) {
        return valueOf(v);
    }

}
