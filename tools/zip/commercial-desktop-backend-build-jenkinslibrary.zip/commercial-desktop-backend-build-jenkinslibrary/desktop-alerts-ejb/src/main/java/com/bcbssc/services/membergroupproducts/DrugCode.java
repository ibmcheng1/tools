
package com.bcbssc.services.membergroupproducts;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DrugCode complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DrugCode">
 *   &lt;complexContent>
 *     &lt;extension base="{http://common.model.commservices.bcbssc.com}Code">
 *       &lt;sequence>
 *         &lt;element name="pharmacyBenefitVendor" type="{http://common.model.commservices.bcbssc.com}PharmacyBenefitVendor" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DrugCode", propOrder = {
    "pharmacyBenefitVendor"
})
public class DrugCode
    extends Code
{

    @XmlSchemaType(name = "string")
    protected PharmacyBenefitVendor pharmacyBenefitVendor;

    /**
     * Gets the value of the pharmacyBenefitVendor property.
     * 
     * @return
     *     possible object is
     *     {@link PharmacyBenefitVendor }
     *     
     */
    public PharmacyBenefitVendor getPharmacyBenefitVendor() {
        return pharmacyBenefitVendor;
    }

    /**
     * Sets the value of the pharmacyBenefitVendor property.
     * 
     * @param value
     *     allowed object is
     *     {@link PharmacyBenefitVendor }
     *     
     */
    public void setPharmacyBenefitVendor(PharmacyBenefitVendor value) {
        this.pharmacyBenefitVendor = value;
    }

}
