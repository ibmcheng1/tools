
package com.bcbssc.services.ohiandodiinformation;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="getOHIAndODIInformationReturn" type="{http://OHIAndODIInformation.CISIC102EJB.commercial.bcbssc.com}OHIAndODIInformationOutput"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getOHIAndODIInformationReturn"
})
@XmlRootElement(name = "getOHIAndODIInformationResponse")
public class GetOHIAndODIInformationResponse {

    @XmlElement(required = true, nillable = true)
    protected OHIAndODIInformationOutput getOHIAndODIInformationReturn;

    /**
     * Gets the value of the getOHIAndODIInformationReturn property.
     * 
     * @return
     *     possible object is
     *     {@link OHIAndODIInformationOutput }
     *     
     */
    public OHIAndODIInformationOutput getGetOHIAndODIInformationReturn() {
        return getOHIAndODIInformationReturn;
    }

    /**
     * Sets the value of the getOHIAndODIInformationReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link OHIAndODIInformationOutput }
     *     
     */
    public void setGetOHIAndODIInformationReturn(OHIAndODIInformationOutput value) {
        this.getOHIAndODIInformationReturn = value;
    }

}
