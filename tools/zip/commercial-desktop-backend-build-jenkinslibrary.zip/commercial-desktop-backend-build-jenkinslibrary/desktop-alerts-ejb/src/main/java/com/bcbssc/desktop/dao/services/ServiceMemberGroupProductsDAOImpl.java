package com.bcbssc.desktop.dao.services;

import com.bcbssc.desktop.dao.MemberGroupProductsDAO;
import com.bcbssc.desktop.util.services.BaseServiceIntegrator;
import com.bcbssc.desktop.util.services.interceptor.ServicesDataAccessExceptionInterceptor;
import com.bcbssc.domain.entity.codes.MemberGroupProductCode;
import com.bcbssc.services.membergroupproducts.GroupProduct;
import com.bcbssc.services.membergroupproducts.GroupProductList;
import com.bcbssc.services.membergroupproducts.GroupProductsSearchCriteria;
import com.bcbssc.services.membergroupproducts.GroupProductsServiceBean;
import com.bcbssc.services.membergroupproducts.MemberGroupProducts;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.jws.HandlerChain;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.ws.WebServiceRef;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * https://dcmis.bcbssc.com/sites/sysdoc/ws/WebServiceDocumentation/MemberGroupProducts/SDD/MemberGroupProducts.doc
 */
@Stateless
@Interceptors({ServicesDataAccessExceptionInterceptor.class})
public class ServiceMemberGroupProductsDAOImpl extends BaseServiceIntegrator<GroupProductsServiceBean, GroupProductsSearchCriteria, GroupProductsSearchCriteria, GroupProductList, List<MemberGroupProductCode>> implements MemberGroupProductsDAO {

    private static final Log logger = LogFactory.getLog(ServiceMemberGroupProductsDAOImpl.class);

    @HandlerChain(file = "./handlersupport/chain/java-service-handler-chain.xml")
    @WebServiceRef(wsdlLocation = "META-INF/wsdl/MemberGroupProducts.wsdl", value = MemberGroupProducts.class)
    private GroupProductsServiceBean service;

    @Override
    public List<MemberGroupProductCode> retrieveGroupProducts(String ammsGroupNumber, Date subscriberDateOfBirth, boolean isSubscriberCovered) {
        GroupProductsSearchCriteria serviceInput = new GroupProductsSearchCriteria();
        // Per SDD - must be populated with the first 3-character patient(s) group number but can take the whole group number
        serviceInput.setGroupNumber(ammsGroupNumber);
        // Some products will only appear if the member is of a certain age.
        // turn the Date into an XMLGregorianCalendar
        final GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTime(subscriberDateOfBirth);
        try {
            serviceInput.setDateOfBirth(DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar));
        } catch (DatatypeConfigurationException e) {
            logger.warn("There was an exception attempting to populate the date of birth on the MemberGroupProduct input", e);
        }
        // serviceInput.setGender(paramString);
        // serviceInput.setPrivacyProtectionEnabled(paramBoolean);
        // Some products will only appear if the member is currently active.
        serviceInput.setCovered(isSubscriberCovered);
        try {
            serviceInput.setEffectiveDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(new GregorianCalendar()));
        } catch (DatatypeConfigurationException e) {
            logger.warn("There was an exception attempting to populate the effective date on the MemberGroupProduct input", e);
        }

        return this.consumeService(serviceInput);
    }

    @Override
    public GroupProductList invokeService(GroupProductsSearchCriteria serviceInput, GroupProductsServiceBean service) {
        return service.getGroupProducts(serviceInput);
    }

    @Override
    public GroupProductsSearchCriteria mapInput(GroupProductsSearchCriteria serviceInput) {
    	// Mapping done in retrieveGroupProducts
        return serviceInput;
    }

    @Override
    public List<MemberGroupProductCode> mapOutput(GroupProductList serviceOutput) {
        List<MemberGroupProductCode> groupProducts = new ArrayList<>();
        for(GroupProduct serviceGroupProduct: serviceOutput.getGroupProductsList()){
            MemberGroupProductCode groupProduct = new MemberGroupProductCode(serviceGroupProduct.getCode(), serviceGroupProduct.getDescription());
            groupProducts.add(groupProduct);
        }
        return groupProducts;
    }

    @Override
    public GroupProductsServiceBean getService() {
        return service;
    }

    @Override
    public void setService(GroupProductsServiceBean service) {
        this.service = service;
    }

    @Override
    protected String getServiceName() {
        return GroupProductsServiceBean.class.getSimpleName();
    }
}