
package com.bcbssc.services.ohiandodiinformation;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.bcbssc.services.ohiandodiinformation package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _EbizException_QNAME = new QName("http://cmpgen.microfocus.com", "EbizException");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.bcbssc.services.ohiandodiinformation
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link EbizException }
     * 
     */
    public EbizException createEbizException() {
        return new EbizException();
    }

    /**
     * Create an instance of {@link GetOHIAndODIInformationResponse }
     * 
     */
    public GetOHIAndODIInformationResponse createGetOHIAndODIInformationResponse() {
        return new GetOHIAndODIInformationResponse();
    }

    /**
     * Create an instance of {@link OHIAndODIInformationOutput }
     * 
     */
    public OHIAndODIInformationOutput createOHIAndODIInformationOutput() {
        return new OHIAndODIInformationOutput();
    }

    /**
     * Create an instance of {@link GetOHIAndODIInformation }
     * 
     */
    public GetOHIAndODIInformation createGetOHIAndODIInformation() {
        return new GetOHIAndODIInformation();
    }

    /**
     * Create an instance of {@link OHIAndODIInformationInput }
     * 
     */
    public OHIAndODIInformationInput createOHIAndODIInformationInput() {
        return new OHIAndODIInformationInput();
    }

    /**
     * Create an instance of {@link OHIAndODIInformationOtherInsurance }
     * 
     */
    public OHIAndODIInformationOtherInsurance createOHIAndODIInformationOtherInsurance() {
        return new OHIAndODIInformationOtherInsurance();
    }

    /**
     * Create an instance of {@link OHIAndODIInformationMedicareInsurance }
     * 
     */
    public OHIAndODIInformationMedicareInsurance createOHIAndODIInformationMedicareInsurance() {
        return new OHIAndODIInformationMedicareInsurance();
    }

    /**
     * Create an instance of {@link ArrayOfOHIAndODIInformationMedicareInsurance }
     * 
     */
    public ArrayOfOHIAndODIInformationMedicareInsurance createArrayOfOHIAndODIInformationMedicareInsurance() {
        return new ArrayOfOHIAndODIInformationMedicareInsurance();
    }

    /**
     * Create an instance of {@link ArrayOfOHIAndODIInformationOtherInsurance }
     * 
     */
    public ArrayOfOHIAndODIInformationOtherInsurance createArrayOfOHIAndODIInformationOtherInsurance() {
        return new ArrayOfOHIAndODIInformationOtherInsurance();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EbizException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://cmpgen.microfocus.com", name = "EbizException")
    public JAXBElement<EbizException> createEbizException(EbizException value) {
        return new JAXBElement<EbizException>(_EbizException_QNAME, EbizException.class, null, value);
    }

}
