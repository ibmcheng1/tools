
package com.bcbssc.services.ohiandodiinformation;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OHIAndODIInformationMedicareInsurance complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OHIAndODIInformationMedicareInsurance">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="medicarePrimarySecondaryInd" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="medicareId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="medicareMemberNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="medicareSubscriberNumAttached" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="medicareMemberNumberAttached" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="medicareMemberFirstName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="medicareMemberLastName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="medicareMemberRelationship" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="medicareMemberRelationshipDesc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="medicarePartABeginDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="medicarePartATerminationDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="medicarePartALastUpdateDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="medicarePartBBeginDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="medicarePartBTerminationDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="medicarePartBLastUpdateDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OHIAndODIInformationMedicareInsurance", propOrder = {
    "medicarePrimarySecondaryInd",
    "medicareId",
    "medicareMemberNumber",
    "medicareSubscriberNumAttached",
    "medicareMemberNumberAttached",
    "medicareMemberFirstName",
    "medicareMemberLastName",
    "medicareMemberRelationship",
    "medicareMemberRelationshipDesc",
    "medicarePartABeginDate",
    "medicarePartATerminationDate",
    "medicarePartALastUpdateDate",
    "medicarePartBBeginDate",
    "medicarePartBTerminationDate",
    "medicarePartBLastUpdateDate"
})
public class OHIAndODIInformationMedicareInsurance {

    @XmlElement(required = true, nillable = true)
    protected String medicarePrimarySecondaryInd;
    @XmlElement(required = true, nillable = true)
    protected String medicareId;
    @XmlElement(required = true, nillable = true)
    protected String medicareMemberNumber;
    @XmlElement(required = true, nillable = true)
    protected String medicareSubscriberNumAttached;
    @XmlElement(required = true, nillable = true)
    protected String medicareMemberNumberAttached;
    @XmlElement(required = true, nillable = true)
    protected String medicareMemberFirstName;
    @XmlElement(required = true, nillable = true)
    protected String medicareMemberLastName;
    @XmlElement(required = true, nillable = true)
    protected String medicareMemberRelationship;
    @XmlElement(required = true, nillable = true)
    protected String medicareMemberRelationshipDesc;
    @XmlElement(required = true, nillable = true)
    protected String medicarePartABeginDate;
    @XmlElement(required = true, nillable = true)
    protected String medicarePartATerminationDate;
    @XmlElement(required = true, nillable = true)
    protected String medicarePartALastUpdateDate;
    @XmlElement(required = true, nillable = true)
    protected String medicarePartBBeginDate;
    @XmlElement(required = true, nillable = true)
    protected String medicarePartBTerminationDate;
    @XmlElement(required = true, nillable = true)
    protected String medicarePartBLastUpdateDate;

    /**
     * Gets the value of the medicarePrimarySecondaryInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicarePrimarySecondaryInd() {
        return medicarePrimarySecondaryInd;
    }

    /**
     * Sets the value of the medicarePrimarySecondaryInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicarePrimarySecondaryInd(String value) {
        this.medicarePrimarySecondaryInd = value;
    }

    /**
     * Gets the value of the medicareId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicareId() {
        return medicareId;
    }

    /**
     * Sets the value of the medicareId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicareId(String value) {
        this.medicareId = value;
    }

    /**
     * Gets the value of the medicareMemberNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicareMemberNumber() {
        return medicareMemberNumber;
    }

    /**
     * Sets the value of the medicareMemberNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicareMemberNumber(String value) {
        this.medicareMemberNumber = value;
    }

    /**
     * Gets the value of the medicareSubscriberNumAttached property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicareSubscriberNumAttached() {
        return medicareSubscriberNumAttached;
    }

    /**
     * Sets the value of the medicareSubscriberNumAttached property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicareSubscriberNumAttached(String value) {
        this.medicareSubscriberNumAttached = value;
    }

    /**
     * Gets the value of the medicareMemberNumberAttached property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicareMemberNumberAttached() {
        return medicareMemberNumberAttached;
    }

    /**
     * Sets the value of the medicareMemberNumberAttached property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicareMemberNumberAttached(String value) {
        this.medicareMemberNumberAttached = value;
    }

    /**
     * Gets the value of the medicareMemberFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicareMemberFirstName() {
        return medicareMemberFirstName;
    }

    /**
     * Sets the value of the medicareMemberFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicareMemberFirstName(String value) {
        this.medicareMemberFirstName = value;
    }

    /**
     * Gets the value of the medicareMemberLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicareMemberLastName() {
        return medicareMemberLastName;
    }

    /**
     * Sets the value of the medicareMemberLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicareMemberLastName(String value) {
        this.medicareMemberLastName = value;
    }

    /**
     * Gets the value of the medicareMemberRelationship property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicareMemberRelationship() {
        return medicareMemberRelationship;
    }

    /**
     * Sets the value of the medicareMemberRelationship property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicareMemberRelationship(String value) {
        this.medicareMemberRelationship = value;
    }

    /**
     * Gets the value of the medicareMemberRelationshipDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicareMemberRelationshipDesc() {
        return medicareMemberRelationshipDesc;
    }

    /**
     * Sets the value of the medicareMemberRelationshipDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicareMemberRelationshipDesc(String value) {
        this.medicareMemberRelationshipDesc = value;
    }

    /**
     * Gets the value of the medicarePartABeginDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicarePartABeginDate() {
        return medicarePartABeginDate;
    }

    /**
     * Sets the value of the medicarePartABeginDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicarePartABeginDate(String value) {
        this.medicarePartABeginDate = value;
    }

    /**
     * Gets the value of the medicarePartATerminationDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicarePartATerminationDate() {
        return medicarePartATerminationDate;
    }

    /**
     * Sets the value of the medicarePartATerminationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicarePartATerminationDate(String value) {
        this.medicarePartATerminationDate = value;
    }

    /**
     * Gets the value of the medicarePartALastUpdateDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicarePartALastUpdateDate() {
        return medicarePartALastUpdateDate;
    }

    /**
     * Sets the value of the medicarePartALastUpdateDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicarePartALastUpdateDate(String value) {
        this.medicarePartALastUpdateDate = value;
    }

    /**
     * Gets the value of the medicarePartBBeginDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicarePartBBeginDate() {
        return medicarePartBBeginDate;
    }

    /**
     * Sets the value of the medicarePartBBeginDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicarePartBBeginDate(String value) {
        this.medicarePartBBeginDate = value;
    }

    /**
     * Gets the value of the medicarePartBTerminationDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicarePartBTerminationDate() {
        return medicarePartBTerminationDate;
    }

    /**
     * Sets the value of the medicarePartBTerminationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicarePartBTerminationDate(String value) {
        this.medicarePartBTerminationDate = value;
    }

    /**
     * Gets the value of the medicarePartBLastUpdateDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicarePartBLastUpdateDate() {
        return medicarePartBLastUpdateDate;
    }

    /**
     * Sets the value of the medicarePartBLastUpdateDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicarePartBLastUpdateDate(String value) {
        this.medicarePartBLastUpdateDate = value;
    }

}
