/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2016 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * ServiceClaimsAlertInformationDAOImpl.java
 * 
 * Created on Sep 22, 2016, 11:14:21 AM by xce1
 */
package com.bcbssc.desktop.dao.services;

import com.bcbssc.desktop.dao.alerts.ClaimsAlertInformationDAO;
import com.bcbssc.desktop.util.services.BaseServiceIntegrator;
import com.bcbssc.domain.entity.ClaimsAlertRecord;
import com.bcbssc.domain.entity.alerts.MemberClaimsAlert;
import com.bcbssc.domain.entity.codes.Code;
import com.bcbssc.domain.entity.enums.Products;
import com.bcbssc.services.claimsalertinformation.v1.CategoryInformation;
import com.bcbssc.services.claimsalertinformation.v1.ClaimInformation;
import com.bcbssc.services.claimsalertinformation.v1.ClaimsAlertInformation;
import com.bcbssc.services.claimsalertinformation.v1.ClaimsAlertInformation_Service;
import com.bcbssc.services.claimsalertinformation.v1.PatientInformation;
import com.bcbssc.services.claimsalertinformation.v1.REQUESTAREA;
import com.bcbssc.services.claimsalertinformation.v1.RESPONSEAREA;
import org.apache.commons.lang.StringUtils;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.jws.HandlerChain;
import javax.xml.ws.WebServiceRef;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Implmentation class for ClaimsAlertInformation dao
 */
@Stateless
@Local
public class ServiceClaimsAlertInformationDAOImpl extends BaseServiceIntegrator<ClaimsAlertInformation, ServiceClaimsAlertInformationDAOImpl.ClaimAlertServiceCriteria, REQUESTAREA, RESPONSEAREA, MemberClaimsAlert> implements
        ClaimsAlertInformationDAO {

    private static final String PARAM_HEALTH = "H";
    private static final String PARAM_DENTAL = "D";

    private static final String OTHER_HEALTH_INSURANCE_CATEGORY = "Other Health Insurance";
    private static final String OTHER_DENTAL_INSURANCE_CATEGORY = "Other Dental Insurance";

    @HandlerChain(file = "../dao/services/handlerchain/datapower-service-with-credentials-handler-chain.xml")
    @WebServiceRef(wsdlLocation = "META-INF/wsdl/ClaimsAlertInformation.wsdl", value = ClaimsAlertInformation_Service.class)
    private ClaimsAlertInformation service;

    /*
     * @see
     * com.bcbssc.desktop.dao.alerts.ClaimsAlertInformationDAO#retrieveClaimsAlert
     * (java.lang.String, java.lang.String)
     */
    @Override
    public MemberClaimsAlert retrieveClaimsAlert(String subscriberId,
            String productCode) {
        ClaimAlertServiceCriteria criteria = new ClaimAlertServiceCriteria(
                subscriberId, productCode);
        return this.consumeService(criteria);
    }

    @Override
    public void setService(ClaimsAlertInformation service) {
        this.service = service;
    }

    @Override
    protected String getServiceName() {
        return ClaimsAlertInformation.class.getSimpleName();
    }

    @Override
    public ClaimsAlertInformation getService() {
        return service;
    }

    @Override
    public REQUESTAREA mapInput(ClaimAlertServiceCriteria criteria) {
        REQUESTAREA input = new REQUESTAREA();
        input.setSubscriberId(criteria.getSubscriberId());
        if(Products.MEDICAL.getCode().equals(criteria.getProductCode())){
            input.setRequestProductCode(PARAM_HEALTH);
        } else if(Products.DENTAL.getCode().equals(criteria.getProductCode())){
            input.setRequestProductCode(PARAM_DENTAL);
        }
        return input;
    }

    @Override
    public RESPONSEAREA invokeService(REQUESTAREA input, ClaimsAlertInformation service) {
        return service.getClaimAlert(input);
    }

    @Override
    public MemberClaimsAlert mapOutput(RESPONSEAREA response) {
        MemberClaimsAlert claimsAlert = new MemberClaimsAlert();

        Map<String, List<ClaimsAlertRecord>> patientToClaimAlertsMap = new HashMap<>();

        for (PatientInformation patientInformation : response.getPatientInformation()) {
            List<ClaimsAlertRecord> claimAlertRecords = new ArrayList<>();
            for (CategoryInformation categoryInformation : patientInformation
                    .getCategoryInformation()) {
                //Create a alert record that contains a category description and a list of associated claim numbers
                ClaimsAlertRecord claimsAlertRecord = new ClaimsAlertRecord();
                claimsAlertRecord.setPatientId(patientInformation.getPatientId());
                if(null != patientInformation.getPatientName()) {
                    claimsAlertRecord.setPatientName(StringUtils.upperCase(patientInformation.getPatientName().getFirstName()));
                }
                Code categoryCode = new Code(
                        categoryInformation.getCategoryNumber(),
                        categoryInformation.getCategoryDescription());
                claimsAlertRecord.setClaimCategoryCode(categoryCode);

                //Identify other insurance categories
                if(OTHER_HEALTH_INSURANCE_CATEGORY.equalsIgnoreCase(categoryInformation.getCategoryDescription())) {
                    claimsAlertRecord.setOtherHealthInsuranceCategory(true);
                } else if(OTHER_DENTAL_INSURANCE_CATEGORY.equalsIgnoreCase(categoryInformation.getCategoryDescription())) {
                    claimsAlertRecord.setOtherDentalInsuranceCategory(true);
                }

                //Set the claim numbers associated with the category number
                List<String> claimNumbers = new ArrayList<>();
                for (ClaimInformation claimInformation : categoryInformation.getClaimInformation()) {
                    claimNumbers.add(claimInformation.getClaimNumber());
                }
                claimsAlertRecord.setClaimNumbers(claimNumbers);

                claimAlertRecords.add(claimsAlertRecord);
            }

            patientToClaimAlertsMap.put(patientInformation.getPatientId(), claimAlertRecords);
        }

        //final map goes into the claims alert object
        claimsAlert.setClaimAlerts(patientToClaimAlertsMap);
        return claimsAlert;
    }

    /**
     * Service criteria class to hold service inputs
     */
    protected class ClaimAlertServiceCriteria {
        private String subscriberId;
        private String productCode;

        ClaimAlertServiceCriteria(String subscriberId, String productCode) {
            super();
            this.subscriberId = subscriberId;
            this.productCode = productCode;
        }

        /**
         * @return the subscriberId
         */
        public String getSubscriberId() {
            return subscriberId;
        }

        /**
         * @return the productCode
         */
        public String getProductCode() {
            return productCode;
        }
    }

}
