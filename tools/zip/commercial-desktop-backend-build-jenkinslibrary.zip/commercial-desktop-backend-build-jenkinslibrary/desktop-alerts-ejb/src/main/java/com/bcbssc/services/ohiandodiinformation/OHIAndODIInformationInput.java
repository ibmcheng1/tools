
package com.bcbssc.services.ohiandodiinformation;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OHIAndODIInformationInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OHIAndODIInformationInput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="rpn" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="subscriberId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="productCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="planCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="racfId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="requestMoreDataIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lastMemberProcessed" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="hostID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="hostPassword" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="toEscapeChar" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="MWIConfig" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="applTrace" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OHIAndODIInformationInput", propOrder = {
    "rpn",
    "requestDate",
    "subscriberId",
    "productCode",
    "planCode",
    "racfId",
    "requestMoreDataIndicator",
    "lastMemberProcessed",
    "hostID",
    "hostPassword",
    "toEscapeChar",
    "mwiConfig",
    "applTrace"
})
public class OHIAndODIInformationInput {

    @XmlElement(required = true, nillable = true)
    protected String rpn;
    @XmlElement(required = true, nillable = true)
    protected String requestDate;
    @XmlElement(required = true, nillable = true)
    protected String subscriberId;
    @XmlElement(required = true, nillable = true)
    protected String productCode;
    @XmlElement(required = true, nillable = true)
    protected String planCode;
    @XmlElement(required = true, nillable = true)
    protected String racfId;
    @XmlElement(required = true, nillable = true)
    protected String requestMoreDataIndicator;
    @XmlElement(required = true, nillable = true)
    protected String lastMemberProcessed;
    @XmlElement(required = true, nillable = true)
    protected String hostID;
    @XmlElement(required = true, nillable = true)
    protected String hostPassword;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean toEscapeChar;
    @XmlElement(name = "MWIConfig", required = true, nillable = true)
    protected String mwiConfig;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean applTrace;

    /**
     * Gets the value of the rpn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRpn() {
        return rpn;
    }

    /**
     * Sets the value of the rpn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRpn(String value) {
        this.rpn = value;
    }

    /**
     * Gets the value of the requestDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestDate() {
        return requestDate;
    }

    /**
     * Sets the value of the requestDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestDate(String value) {
        this.requestDate = value;
    }

    /**
     * Gets the value of the subscriberId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriberId() {
        return subscriberId;
    }

    /**
     * Sets the value of the subscriberId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriberId(String value) {
        this.subscriberId = value;
    }

    /**
     * Gets the value of the productCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductCode() {
        return productCode;
    }

    /**
     * Sets the value of the productCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductCode(String value) {
        this.productCode = value;
    }

    /**
     * Gets the value of the planCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlanCode() {
        return planCode;
    }

    /**
     * Sets the value of the planCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlanCode(String value) {
        this.planCode = value;
    }

    /**
     * Gets the value of the racfId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRacfId() {
        return racfId;
    }

    /**
     * Sets the value of the racfId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRacfId(String value) {
        this.racfId = value;
    }

    /**
     * Gets the value of the requestMoreDataIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestMoreDataIndicator() {
        return requestMoreDataIndicator;
    }

    /**
     * Sets the value of the requestMoreDataIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestMoreDataIndicator(String value) {
        this.requestMoreDataIndicator = value;
    }

    /**
     * Gets the value of the lastMemberProcessed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastMemberProcessed() {
        return lastMemberProcessed;
    }

    /**
     * Sets the value of the lastMemberProcessed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastMemberProcessed(String value) {
        this.lastMemberProcessed = value;
    }

    /**
     * Gets the value of the hostID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHostID() {
        return hostID;
    }

    /**
     * Sets the value of the hostID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHostID(String value) {
        this.hostID = value;
    }

    /**
     * Gets the value of the hostPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHostPassword() {
        return hostPassword;
    }

    /**
     * Sets the value of the hostPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHostPassword(String value) {
        this.hostPassword = value;
    }

    /**
     * Gets the value of the toEscapeChar property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isToEscapeChar() {
        return toEscapeChar;
    }

    /**
     * Sets the value of the toEscapeChar property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setToEscapeChar(Boolean value) {
        this.toEscapeChar = value;
    }

    /**
     * Gets the value of the mwiConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMWIConfig() {
        return mwiConfig;
    }

    /**
     * Sets the value of the mwiConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMWIConfig(String value) {
        this.mwiConfig = value;
    }

    /**
     * Gets the value of the applTrace property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isApplTrace() {
        return applTrace;
    }

    /**
     * Sets the value of the applTrace property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setApplTrace(Boolean value) {
        this.applTrace = value;
    }

}
