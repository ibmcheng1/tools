@javax.xml.bind.annotation.XmlSchema(namespace = "http://OHIAndODIInformation.CISIC102EJB.commercial.bcbssc.com")
package com.bcbssc.services.ohiandodiinformation;
