
package com.bcbssc.services.membergroupproducts;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Group complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Group">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="groupNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cesGroupNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="groupName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cesClientNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cesClientName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="customNetwork" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="businessSectorCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="drugCode" type="{http://common.model.commservices.bcbssc.com}DrugCode" minOccurs="0"/>
 *         &lt;element name="customNetworkDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="deferralStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="reportRoute" type="{http://common.model.commservices.bcbssc.com}KeyDescription" minOccurs="0"/>
 *         &lt;element name="serviceCenter" type="{http://common.model.commservices.bcbssc.com}KeyDescription" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Group", propOrder = {
    "groupNumber",
    "cesGroupNumber",
    "groupName",
    "cesClientNumber",
    "cesClientName",
    "customNetwork",
    "businessSectorCode",
    "drugCode",
    "customNetworkDescription",
    "deferralStatus",
    "reportRoute",
    "serviceCenter"
})
public class Group {

    protected String groupNumber;
    protected String cesGroupNumber;
    protected String groupName;
    protected String cesClientNumber;
    protected String cesClientName;
    protected boolean customNetwork;
    protected String businessSectorCode;
    protected DrugCode drugCode;
    protected String customNetworkDescription;
    protected String deferralStatus;
    protected KeyDescription reportRoute;
    protected KeyDescription serviceCenter;

    /**
     * Gets the value of the groupNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupNumber() {
        return groupNumber;
    }

    /**
     * Sets the value of the groupNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupNumber(String value) {
        this.groupNumber = value;
    }

    /**
     * Gets the value of the cesGroupNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCesGroupNumber() {
        return cesGroupNumber;
    }

    /**
     * Sets the value of the cesGroupNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCesGroupNumber(String value) {
        this.cesGroupNumber = value;
    }

    /**
     * Gets the value of the groupName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupName() {
        return groupName;
    }

    /**
     * Sets the value of the groupName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupName(String value) {
        this.groupName = value;
    }

    /**
     * Gets the value of the cesClientNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCesClientNumber() {
        return cesClientNumber;
    }

    /**
     * Sets the value of the cesClientNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCesClientNumber(String value) {
        this.cesClientNumber = value;
    }

    /**
     * Gets the value of the cesClientName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCesClientName() {
        return cesClientName;
    }

    /**
     * Sets the value of the cesClientName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCesClientName(String value) {
        this.cesClientName = value;
    }

    /**
     * Gets the value of the customNetwork property.
     * 
     */
    public boolean isCustomNetwork() {
        return customNetwork;
    }

    /**
     * Sets the value of the customNetwork property.
     * 
     */
    public void setCustomNetwork(boolean value) {
        this.customNetwork = value;
    }

    /**
     * Gets the value of the businessSectorCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBusinessSectorCode() {
        return businessSectorCode;
    }

    /**
     * Sets the value of the businessSectorCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBusinessSectorCode(String value) {
        this.businessSectorCode = value;
    }

    /**
     * Gets the value of the drugCode property.
     * 
     * @return
     *     possible object is
     *     {@link DrugCode }
     *     
     */
    public DrugCode getDrugCode() {
        return drugCode;
    }

    /**
     * Sets the value of the drugCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link DrugCode }
     *     
     */
    public void setDrugCode(DrugCode value) {
        this.drugCode = value;
    }

    /**
     * Gets the value of the customNetworkDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomNetworkDescription() {
        return customNetworkDescription;
    }

    /**
     * Sets the value of the customNetworkDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomNetworkDescription(String value) {
        this.customNetworkDescription = value;
    }

    /**
     * Gets the value of the deferralStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeferralStatus() {
        return deferralStatus;
    }

    /**
     * Sets the value of the deferralStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeferralStatus(String value) {
        this.deferralStatus = value;
    }

    /**
     * Gets the value of the reportRoute property.
     * 
     * @return
     *     possible object is
     *     {@link KeyDescription }
     *     
     */
    public KeyDescription getReportRoute() {
        return reportRoute;
    }

    /**
     * Sets the value of the reportRoute property.
     * 
     * @param value
     *     allowed object is
     *     {@link KeyDescription }
     *     
     */
    public void setReportRoute(KeyDescription value) {
        this.reportRoute = value;
    }

    /**
     * Gets the value of the serviceCenter property.
     * 
     * @return
     *     possible object is
     *     {@link KeyDescription }
     *     
     */
    public KeyDescription getServiceCenter() {
        return serviceCenter;
    }

    /**
     * Sets the value of the serviceCenter property.
     * 
     * @param value
     *     allowed object is
     *     {@link KeyDescription }
     *     
     */
    public void setServiceCenter(KeyDescription value) {
        this.serviceCenter = value;
    }

}
