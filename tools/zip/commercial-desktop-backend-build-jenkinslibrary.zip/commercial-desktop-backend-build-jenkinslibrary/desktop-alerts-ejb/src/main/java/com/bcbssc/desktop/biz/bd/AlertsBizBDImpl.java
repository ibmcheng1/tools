/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2017 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.biz.bd;

import com.bcbssc.desktop.api.DesktopAPI;
import com.bcbssc.desktop.biz.MobileTextNotificationAuditBiz;
import com.bcbssc.desktop.biz.OtherInsuranceAuditBiz;
import com.bcbssc.desktop.biz.alerts.AlertsBiz;
import com.bcbssc.desktop.dao.BusinessClassificationCodeDAO;
import com.bcbssc.desktop.dao.MemberGroupProductsDAO;
import com.bcbssc.desktop.dao.SubscriberDAO;
import com.bcbssc.desktop.dao.alerts.ClaimsAlertInformationDAO;
import com.bcbssc.desktop.dao.alerts.MemberAlertInformationDAO;
import com.bcbssc.desktop.dao.alerts.MobileTextNotificationsDAO;
import com.bcbssc.desktop.dao.alerts.OtherInsuranceNegativeDAO;
import com.bcbssc.desktop.dao.alerts.RetrieveOtherInsuranceDAO;
import com.bcbssc.desktop.dao.billing.BillingDAO;
import com.bcbssc.desktop.dao.billing.DelinquencyStatusDAO;
import com.bcbssc.desktop.dao.group.GroupSummaryDAO;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.dao.executor.WorkExecutor;
import com.bcbssc.desktop.util.dao.executor.WorkTask;
import com.bcbssc.domain.entity.BusinessClassificationCode;
import com.bcbssc.domain.entity.BusinessClassificationCodeSearchCriteria;
import com.bcbssc.domain.entity.ClaimsAlertRecord;
import com.bcbssc.domain.entity.Coverage;
import com.bcbssc.domain.entity.CoverageId;
import com.bcbssc.domain.entity.Group;
import com.bcbssc.domain.entity.Member;
import com.bcbssc.domain.entity.MemberMobileNotificationsRecord;
import com.bcbssc.domain.entity.MobileTextNotificationSearchCriteria;
import com.bcbssc.domain.entity.Subscriber;
import com.bcbssc.domain.entity.alerts.Alert;
import com.bcbssc.domain.entity.alerts.AlertResults;
import com.bcbssc.domain.entity.alerts.AlertSearchCriteria;
import com.bcbssc.domain.entity.alerts.AlertType;
import com.bcbssc.domain.entity.alerts.DelinquencyAlert;
import com.bcbssc.domain.entity.alerts.MemberClaimsAlert;
import com.bcbssc.domain.entity.alerts.MemberMobileNotificationsAlert;
import com.bcbssc.domain.entity.alerts.MemberSubrogationAlert;
import com.bcbssc.domain.entity.alerts.OtherInsuranceNegativeCriteria;
import com.bcbssc.domain.entity.billing.BillingInformation;
import com.bcbssc.domain.entity.billing.DelinquencyStatusDetails;
import com.bcbssc.domain.entity.codes.MemberGroupProductCode;
import com.bcbssc.domain.entity.cti.CallCenterAttribute;
import com.bcbssc.domain.entity.enums.COBType;
import com.bcbssc.domain.entity.enums.Products;
import com.bcbssc.domain.entity.enums.Subsystems;
import com.bcbssc.domain.entity.enums.billing.PolicyType;
import com.bcbssc.domain.entity.group.GroupSearchCriteria;
import com.bcbssc.domain.entity.otherInsurance.OHIAndODIInformationOutputDTO;
import com.bcbssc.domain.entity.otherInsurance.SubmitOtherInsuranceData;
import com.bcbssc.domain.valueobject.MenuLink;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.security.auth.Subject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ExecutorService;

/**
 * Alerts Business Delegate Implementation
 *
 */

@Stateless(name = "alertsBD", mappedName = "alertsBD")
@Remote
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class AlertsBizBDImpl implements AlertsBiz {

    @EJB
    private BusinessClassificationCodeDAO businessClassificationsDAO;

    @EJB
    private BillingDAO billingAccountDAO;

    @EJB
    private DelinquencyStatusDAO delinquencyStatusDAO;

    @EJB
    private GroupSummaryDAO groupSummaryDAO;

    @EJB
    private MemberAlertInformationDAO memberAlertInformationDAO;

    @EJB
    private RetrieveOtherInsuranceDAO retrieveOtherInsuranceDAO;

    @EJB
    private OtherInsuranceNegativeDAO otherInsuranceNegativeDAO;

    @EJB
    private ClaimsAlertInformationDAO claimsAlertInformationDAO;

    @EJB
    private MobileTextNotificationsDAO mobileTextNotificationsDAO;

    @EJB
    private MemberGroupProductsDAO memberGroupProductsDAO;

    @EJB
    private SubscriberDAO subscriberDAO;

    private static final String RETRIEVE_GRANDFATHER_ALERT_FLAG = "MEMBER_ELIGIBILITY_ALERT";
    private static final String RETRIEVE_MEMBER_EXCEPTION_ALERT_FLAG = "MEMBER_EXCEPTION_ALERT";
    private static final String RETRIEVE_DELINQUENCY_STATUS_ALERT_FLAG = "DELINQUENCY_STATUS_ALERT";
    private static final String RETRIEVE_SPCL_CONSIDERATIONS_ALERT_FLAG = "SPL_CNSDRTNS_NOTES_ALERT";
    private static final String RETRIEVE_MEMBER_COB_ALERT_FLAG = "MEMBER_COB_ALERT";
    private static final String RETRIEVE_MEMBER_CLAIMS_ALERT_FLAG = "MEMBER_CLAIMS_ALERT";
    private static final String RETRIEVE_CLAIMS_ALERT_FLAG = "RETRIEVE_CLAIMS_ALERT"; 
    private static final String RETRIEVE_MEMBER_MOBILE_NOTIFICATIONS_ALERT_FLAG = "MEMBER_MOBILE_NOTIFICATIONS_ALERT";
    private static final String MOBILE_NOTIFY_GRP_PRODUCT_CODE_KEY = "MOBILE_NTFY_GRP_PRDCT_CD";
    private static final String COMMA = ",";
    //Currently hardcoded. Will need to be moved to configuration. 
    //This is used to create a list of subrogation codes in fetchSubrogationCodes below.
    private static final String SUBROGATION_CATEGORY_CODE = "AQ"; 

    /**
     * Logger for this class.
     */
    private static final Log log = LogFactory.getLog(AlertsBizBDImpl.class);

    @Resource(lookup="concurrent/executor")
    private ExecutorService executor;

    @Override
    public AlertResults retrieveDesktopAlerts(final AlertSearchCriteria searchCriteria, final Subject subject) throws Exception {
        AlertResults alertResults = new AlertResults();
        List<WorkTask<?>> workTasks = new ArrayList<>();
        final String RETRIEVE_ALERTS_FLAG = "RETRIEVE_ALERTS";
        boolean retrieveAlerts = false;

        // Read RULEs to see if Alerts is enabled.     
        Map<String, ?> ruleEntries = DesktopAPI.getRulesEntries(subject);
        Map<String, MenuLink> userConfig = (Map<String, MenuLink>) ruleEntries.get(MenuLink.FUNCTION_TYPE_USERCONFIG);

        if(userConfig.get(RETRIEVE_ALERTS_FLAG) != null){
            retrieveAlerts = Boolean.valueOf(userConfig.get(RETRIEVE_ALERTS_FLAG).getKeyValue());
            if (log.isDebugEnabled()) {
                log.debug("Alerts Rule found, Alerts retrieval flag is " + retrieveAlerts);
            }
        }

        // If Alerts retrieval is enabled, go through with the back-end call.
        if (retrieveAlerts) {
            String callCenter = searchCriteria.getCallCenter();
            String subscriberId = searchCriteria.getSubscriberId();
            String patientId = searchCriteria.getPatientId();
            BillingInformation billingInformation = null;
            String masterARNumber = searchCriteria.getMasterARNumber();

            // May be null if subscriber has no active coverage.
            CoverageId coverageId = searchCriteria.getCoverageId();


            //Get billing information if subscriberId is blank, used for both alert info WS and delinquency group searching
            if (StringUtils.isBlank(subscriberId))
                billingInformation = getBillingInformation(masterARNumber, subject);

            //Set ClientNumberRequested to client number if group lookup or blank if subscriber lookup 
            String clientNumber = (billingInformation != null) ? billingInformation.getClientNumber() : StringUtils.EMPTY;
            searchCriteria.setClientNumberRequested(clientNumber);

            //Set alert types requested
            Map<String, Boolean> alertsByCallCenter = getAlertsByCallCenter(callCenter, subject);
            List<AlertType> alertTypes = new ArrayList<>();
            if (alertsByCallCenter.get(RETRIEVE_GRANDFATHER_ALERT_FLAG)) alertTypes.add(AlertType.GRANDFATHER_ALERT);
            if (subscriberId != null && alertsByCallCenter.get(RETRIEVE_MEMBER_EXCEPTION_ALERT_FLAG)) alertTypes.add(AlertType.EXCEPTION_ALERT);
            if (subscriberId != null && alertsByCallCenter.get(RETRIEVE_SPCL_CONSIDERATIONS_ALERT_FLAG)) alertTypes.add(AlertType.SPECIAL_CONSIDERATIONS_ALERT);
            if (subscriberId != null && alertsByCallCenter.get(RETRIEVE_MEMBER_COB_ALERT_FLAG)) alertTypes.add(AlertType.COB_ALERT);
            if (alertTypes.size() > 0) searchCriteria.setAlertTypeRequested(alertTypes);

            if (log.isDebugEnabled()) {
                log.debug("Attempting to retrieve alert info with the following AlertSearchCriteria values: " + searchCriteria);
            }

            //Add Grandfather and Exception alerts to the alerts object list from memberAlertInformation webservice given the searchCriteria  
            if (alertTypes.size() > 0) {
                workTasks.add(retrieveMemberAlerts(searchCriteria, alertResults, subject));
            }

            //Get delinquency status
            if (alertsByCallCenter.get(RETRIEVE_DELINQUENCY_STATUS_ALERT_FLAG)) {
                if (billingInformation != null) {
                    if (log.isDebugEnabled()) {
                        log.debug("Retrieving delinquency alert by group");
                    }
                    workTasks.add(retrieveDelinquencyStatusByGroup(billingInformation, alertResults, subject));
                } else if (StringUtils.isNotBlank(subscriberId) && StringUtils.isNotBlank(patientId) && null != coverageId) {
                    if (log.isDebugEnabled()) {
                        log.debug("Retrieving delinquency alert by subscriber");
                    }
                    workTasks.add(retrieveDelinquencyStatusBySubscriber(subscriberId, coverageId.toString(), coverageId.getProductCode(), alertResults, subject));
                }
            }

            // Get claims status alerts
            if (alertsByCallCenter.get(RETRIEVE_MEMBER_CLAIMS_ALERT_FLAG)) {
                String productId = coverageId != null ? coverageId.getProductCode().getCode() : null;
                workTasks.add(retrieveClaimStatusSubrogationAlerts(subscriberId, productId, alertResults, subject));
            }

            if (DesktopAPI.getRelayLookupFlag().booleanValue() && alertsByCallCenter.get(RETRIEVE_MEMBER_MOBILE_NOTIFICATIONS_ALERT_FLAG) && null != coverageId && StringUtils.isNotEmpty(searchCriteria.getAmmsGroupNumber())) {
                // First determine if Mobile Notifications is allowed.
                boolean isMobileNotificationsEnabledForGroup = this.isMobileNotificationsEnabledForGroup(searchCriteria, subject);
                alertResults.isMobileNotificationsEnabledForGroup = isMobileNotificationsEnabledForGroup;

                if (isMobileNotificationsEnabledForGroup) {
                    // If it is allowed then get mobile notification alerts
                    MobileTextNotificationSearchCriteria mobileTextNotificationSearchCriteria = new MobileTextNotificationSearchCriteria();
                    mobileTextNotificationSearchCriteria.setAlphaPrefix(searchCriteria.getAlphaPrefix());
                    mobileTextNotificationSearchCriteria.setAmmsGroupNumber(searchCriteria.getAmmsGroupNumber());
                    mobileTextNotificationSearchCriteria.setIdCardNumber(searchCriteria.getIdCardNumber());
                    mobileTextNotificationSearchCriteria.setProduct(coverageId.getProductCode());
                    mobileTextNotificationSearchCriteria.setSubscriberId(subscriberId);
                    workTasks.add(retrieveMobileNotificationAlert(mobileTextNotificationSearchCriteria, alertResults, subject));
                }
            }

            if (!workTasks.isEmpty()) {
                //Create a work executor, execute work tasks
                WorkExecutor workExecutor = new WorkExecutor(executor, workTasks);
                workExecutor.executeWorkTasks();
            } else {
                if (log.isDebugEnabled()) {
                    log.debug("Work task list is empty.  No alerts are being returned!");
                }
            }
        }

        if (log.isDebugEnabled()) {
            log.debug("retrieveDesktopAlerts():  Finished alert retrieval, returning alerts: alertResults.alerts.size() = " + alertResults.alerts.size());
        }

        return alertResults;
    }

    @Override
    public List<Alert> retrieveNotes(final AlertSearchCriteria searchCriteria, final Subject subject) throws Exception {
        List<AlertType> alertTypes = new ArrayList<AlertType>();
        alertTypes.add(AlertType.SPECIAL_CONSIDERATIONS_ALERT);
        if (alertTypes.size() > 0) searchCriteria.setAlertTypeRequested(alertTypes);
        
        return SubjectUtils.runAsSubject(() -> memberAlertInformationDAO.retrieveMemberAlerts(searchCriteria), subject);
    }

    @Override
    public OHIAndODIInformationOutputDTO retrieveOtherInsuranceInformation(final String subscriberId, final Subscriber subscriber, final String productCode, final Subject subject) throws Exception {
        OHIAndODIInformationOutputDTO otherInsuranceSummary =
                SubjectUtils.runAsSubject(()  -> retrieveOtherInsuranceDAO.retrieveOtherInsurance(subscriberId, productCode), subject);

        // Check if call center attributes existing for call center
        CallCenterAttribute callCenterAttribute = DesktopAPI.getCallCenterAttribute(SubjectUtils.getCallCenter(subject).getCallCenterName(), productCode,
                SubjectUtils.getRpnForSubsystem(subject, Subsystems.CISI));

        if (null != callCenterAttribute && StringUtils.isNotBlank(callCenterAttribute.getCompanyTypeForCOBInforms())
                && StringUtils.isNotBlank(callCenterAttribute.getDepartmentTypeForCOBInforms())
                && StringUtils.isNotBlank(callCenterAttribute.getDivisionTypeForCOBInforms())
                && StringUtils.isNotBlank(callCenterAttribute.getEmployeeIdForCOBInforms())) {
            otherInsuranceSummary.setOHIODIInformationUpdateEnabled(true);
        } else {
            otherInsuranceSummary.setOHIODIInformationUpdateEnabled(false);
        }

        // If the subscriber could not be found in cache, or if the subscriber ID provided does not match the subscriber ID in cache,
        // call the subscriber dao to retrieve subscriber information
        Subscriber subscriberObject = subscriber;
        if(subscriberObject == null ||
          (StringUtils.isNotEmpty(subscriberId) && !subscriberId.equals(subscriberObject.getDatabaseNumber()))) {
            if(log.isDebugEnabled()) {
                log.debug(subscriberId+" subscriber ID could not be found in cache.  Retrieving subscriber object from service");
            }
            List<Subscriber> resultSbrs = SubjectUtils.runAsSubject(() -> subscriberDAO.findById(subscriberId), subject);
            // There should only be one subscriber object returned
            if (resultSbrs.size() == 1) {
                subscriberObject = (Subscriber) resultSbrs.iterator().next();
            } 
        }

        // Get the coverage begin/effective date for the subscriber + product code
        if(subscriberObject != null) {
            Set<Coverage> coverages = subscriberObject.getCoverageItems();
            for(Coverage coverage : coverages) {
                if(coverage.getActive()) {
                    if(coverage.getCoverageId() != null) {
                        Products product = coverage.getCoverageId().getProductCode();
                        if(productCode.equals(product.getCode()) && coverage.getEffectiveDate() != null) {
                            // Format the date with the same format as the other dates in the model object
                            SimpleDateFormat formatter = new SimpleDateFormat("MMddyyyy");
                            otherInsuranceSummary.setCoverageEffectiveDate(formatter.format(coverage.getEffectiveDate()));
                            if(log.isDebugEnabled()) {
                                log.debug("Begin date of "+productCode+" product is "+coverage.getEffectiveDate());
                            }
                            break;
                        }
                    }
                }
            }
        }

        return otherInsuranceSummary;
    }

    @Override
    public void submitOtherInsuranceInformation(SubmitOtherInsuranceData submitOtherInsuranceData, Subject subject) throws Exception {
        //Make sure the call center attribute is in cache and the COB bucket is defined or else submitting will not work
        String productCode = StringUtils.EMPTY;
        if(null != submitOtherInsuranceData.getProduct()) {
            productCode = submitOtherInsuranceData.getProduct().getCode();
        }

        CallCenterAttribute callCenterAttribute = DesktopAPI.getCallCenterAttribute(SubjectUtils.getCallCenter(subject).getCallCenterName(), productCode,
                SubjectUtils.getRpnForSubsystem(subject, Subsystems.CISI));

        if (null != callCenterAttribute && StringUtils.isNotBlank(callCenterAttribute.getCompanyTypeForCOBInforms())
                && StringUtils.isNotBlank(callCenterAttribute.getDepartmentTypeForCOBInforms())
                && StringUtils.isNotBlank(callCenterAttribute.getDivisionTypeForCOBInforms())
                && StringUtils.isNotBlank(callCenterAttribute.getEmployeeIdForCOBInforms())) {

            OtherInsuranceAuditBiz biz = new OtherInsuranceAuditBiz();
            if(submitOtherInsuranceData.getCobResponseType().equals(COBType.NEGATIVE)){
                final OtherInsuranceNegativeCriteria criteria = new OtherInsuranceNegativeCriteria();
                criteria.setSubscriberId(submitOtherInsuranceData.getSubscriber().getId());
                criteria.setResponseDate(submitOtherInsuranceData.getResponseDate());
                criteria.setEffectiveDate(submitOtherInsuranceData.getTerminationDate());
                criteria.setProductCode(submitOtherInsuranceData.getProduct().getCode());
                criteria.setMemberNumber(submitOtherInsuranceData.getCesMemberId());
                criteria.setInformationSourceCode("6"); //6 means the source is a "phone call"
                criteria.setRacfId(SubjectUtils.getRacfId(subject));
                criteria.setCobChangeIndicator("Y"); //Y means the member no longer has a positive COB, or needs to update the response date for negative product code
                criteria.setUpdateSource("CSR");
                criteria.setEmployeeProcessorId("CSR01");
                criteria.setRpn(SubjectUtils.getClient(subject).getAliasRpn());

                //Execute the negative update service
                SubjectUtils.runAsSubject(() -> {
                    otherInsuranceNegativeDAO.updateNegativeOtherInsurance(criteria);
                    return null;
                }, subject);

                //Find the member that was updated.  If null, it is for Contract level updates
                Member updatedMember = submitOtherInsuranceData.getSubscriber().locateMember(submitOtherInsuranceData.getCesMemberId());

                biz.submitNegativeAudit(submitOtherInsuranceData.getProduct(), submitOtherInsuranceData.getSubscriber(), updatedMember, callCenterAttribute,
                        subject);
            } else if(submitOtherInsuranceData.getCobResponseType().equals(COBType.POSITIVE)){
                biz.submitPositiveAudit(submitOtherInsuranceData.getProduct(), submitOtherInsuranceData.getSubscriber(),
                        submitOtherInsuranceData.getPositiveCobQuestionnaire(), callCenterAttribute, subject);
            }
        } else {
            throw new Exception("Call center COB information is not configured properly.  Customer must update CALCTRAT RULZ script.\n Call center: "
                    + SubjectUtils.getCallCenter(subject).getCallCenterName() + ".  Call center attribute: " + callCenterAttribute);
        }
    }

    @Override
    public boolean submitMobileNotificationInformation(final MobileTextNotificationSearchCriteria criteria, final String templateCode,
            final String mobileNumber, final String consentType, final Subject subject) throws Exception {
        boolean success = SubjectUtils.runAsSubject(() ->
                mobileTextNotificationsDAO.updateEngagementPreferences(criteria, templateCode, mobileNumber, consentType), subject);

        //only send audit event if update was successful
        if (success) {
            try {
                MobileTextNotificationAuditBiz biz = new MobileTextNotificationAuditBiz();
                biz.submitMobileTextNotificationAudit(criteria, mobileNumber, consentType, subject);
            } catch(Exception exception) {
                log.error("There was a problem sending an audit message to Inform!", exception);
            }
        } else {
            log.debug("Updating susbcriber text notifications failed.  Not creating audit record.");
        }


        return success;
    }

    @Override
    public MemberClaimsAlert retrieveClaimStatusAlerts(final String subscriberId, final String productCode, final Subject subject) throws Exception {
        // call web service
        MemberClaimsAlert unfiltered = SubjectUtils.runAsSubject(() ->
                claimsAlertInformationDAO.retrieveClaimsAlert(subscriberId, productCode), subject);

        if (unfiltered != null && unfiltered.getClaimAlerts().size() > 0){
            //Fetch claims alerts
            Map<AlertType, Alert> claimRelatedAlerts = getClaimRelatedAlerts(unfiltered);
            if(claimRelatedAlerts != null && claimRelatedAlerts.size() > 0){
                if(claimRelatedAlerts.get(AlertType.CLAIMS_ALERT) != null){
                    MemberClaimsAlert claimStatusAlerts = (MemberClaimsAlert)claimRelatedAlerts.get(AlertType.CLAIMS_ALERT);
                    if(claimStatusAlerts.getClaimAlerts() != null && claimStatusAlerts.getClaimAlerts().size() > 0){
                        return claimStatusAlerts;
                    }
                }
            }
        }
        return null;
    }

    @Override
    public MemberSubrogationAlert retrieveClaimSubrogationAlerts(final String subscriberId, final String productCode, final Subject subject) throws Exception {
        // call web service
        MemberClaimsAlert unfiltered = SubjectUtils.runAsSubject(() -> claimsAlertInformationDAO.retrieveClaimsAlert(subscriberId, productCode), subject);

        if (unfiltered != null && unfiltered.getClaimAlerts().size() > 0){
            //Fetch subrogation alerts
            Map<AlertType, Alert> claimRelatedAlerts = getClaimRelatedAlerts(unfiltered);
            if(claimRelatedAlerts != null && claimRelatedAlerts.size() > 0){
                if(claimRelatedAlerts.get(AlertType.SUBROGATION_ALERT) != null){
                    MemberSubrogationAlert subrogationAlerts = (MemberSubrogationAlert)claimRelatedAlerts.get(AlertType.SUBROGATION_ALERT);
                    if(subrogationAlerts.getSubrogationAlerts() != null && subrogationAlerts.getSubrogationAlerts().size() > 0){
                        return subrogationAlerts;
                    }
                }
            }
        }
        
        return null;
    }

    /**
     * Fetch a work instance to run the mobile notification related web service
     *
     * @param criteria
     * @param alertResults
     * @param subject
     * @return
     */
    private WorkTask<?> retrieveMobileNotificationAlert(final MobileTextNotificationSearchCriteria criteria, final AlertResults alertResults, final Subject subject) {
        return new WorkTask<HashMap<String, MemberMobileNotificationsRecord>>(null, subject, 
                () -> SubjectUtils.runAsSubject(() -> mobileTextNotificationsDAO.getEngagementMemberRecords(criteria), subject)) {
            @Override
            public void onComplete() {
            	HashMap<String, MemberMobileNotificationsRecord> results = this.getResults();
                alertResults.engagementMemberRecords = results;

                Map<String, MemberMobileNotificationsRecord> alertsOnly = new HashMap<>();
                for (Entry<String, MemberMobileNotificationsRecord> entry : results.entrySet()) {
                    if (entry.getValue().isShowAlert()) {
                        alertsOnly.put(entry.getKey(), entry.getValue());
                    }
                }

                if (alertsOnly.size() > 0) {
                    MemberMobileNotificationsAlert alertContainer = new MemberMobileNotificationsAlert();
                    alertContainer.setMobileNotificationAlerts(alertsOnly);
                    alertResults.add(alertContainer);
                }
            }
        };
    }

    /**
     * Fetch a Work instance to run the ClaimsAlertInformation web service
     *  
     * @param productCode
     *         May be null.
     */
    private WorkTask<?> retrieveClaimStatusSubrogationAlerts(final String subscriberId, final String productCode, final AlertResults alertResults, final Subject subject) {
        return new WorkTask<MemberClaimsAlert>(RETRIEVE_CLAIMS_ALERT_FLAG, subject, () -> SubjectUtils.runAsSubject(() -> claimsAlertInformationDAO.retrieveClaimsAlert(subscriberId, productCode), subject)) {
            @Override
            public void onComplete() {
                MemberClaimsAlert unfilteredAlerts = this.getResults();
                if (unfilteredAlerts != null && unfilteredAlerts.getClaimAlerts().size() > 0){
                    //Fetch claims alerts
                    Map<AlertType, Alert> claimRelatedAlerts= getClaimRelatedAlerts(unfilteredAlerts);
                    if(claimRelatedAlerts != null && claimRelatedAlerts.size() > 0){
                        if(claimRelatedAlerts.get(AlertType.CLAIMS_ALERT) != null){
                            MemberClaimsAlert claimStatusAlerts = (MemberClaimsAlert)claimRelatedAlerts.get(AlertType.CLAIMS_ALERT);
                            if(claimStatusAlerts.getClaimAlerts() != null && claimStatusAlerts.getClaimAlerts().size() > 0){
                                alertResults.add(claimStatusAlerts);
                            }
                        }
                        if(claimRelatedAlerts.get(AlertType.SUBROGATION_ALERT) != null){
                            MemberSubrogationAlert subrogationAlerts = (MemberSubrogationAlert)claimRelatedAlerts.get(AlertType.SUBROGATION_ALERT);
                            if(subrogationAlerts.getSubrogationAlerts() != null && subrogationAlerts.getSubrogationAlerts().size() > 0){
                                alertResults.add(subrogationAlerts);
                            }
                        }
                    }
                }
            }
        };
    }

    /**
    * Fetch a Work instance to run the MeberAlertInformation web service to retrieve Grandfather and Exception codes
    *
     * @param searchCriteria
     * @param alertResults
     * @param subject
     * @return
     */
    private WorkTask<?> retrieveMemberAlerts(final AlertSearchCriteria searchCriteria, final AlertResults alertResults, final Subject subject) {
        return new WorkTask<List<Alert>>(null, subject, () -> SubjectUtils.runAsSubject(() -> memberAlertInformationDAO.retrieveMemberAlerts(searchCriteria), subject)) {
            @Override
            public void onComplete() {
                List<Alert> memberAlerts = this.getResults();
                if (memberAlerts != null && memberAlerts.size() > 0)
                    alertResults.addAll(memberAlerts);
            }
        };
    }

    /**
     * This method checks the list of claims alerts and add subrogation alert if subrogation records are found.
     *
     * @param unfiltered
     * @return
     */
    private Map<AlertType, Alert> getClaimRelatedAlerts(final MemberClaimsAlert unfiltered){
        MemberSubrogationAlert subrogationAlert;
        MemberClaimsAlert claimsStatusAlert;
        Map<AlertType, Alert> claimRelatedAlerts = new HashMap<>();
        Map<String, List<ClaimsAlertRecord>> subrogationAlerts = new HashMap<>();
        Map<String, List<ClaimsAlertRecord>> claimsAlerts = new HashMap<>();

        if (unfiltered != null && unfiltered.getClaimAlerts().size() > 0) {
                for(Entry<String, List<ClaimsAlertRecord>> entry : unfiltered.getClaimAlerts().entrySet()){
                    List<ClaimsAlertRecord> claimStatusRecords = new ArrayList<>();
                    List<ClaimsAlertRecord> subrogationRecords = new ArrayList<>();
                    if(entry.getValue() != null){
                        String patientId = entry.getKey();
                        // Fetch codes marked as subrogation codes
                        List<String> subrogationCodes = fetchSubrogationCodes();
                        for(ClaimsAlertRecord record : entry.getValue()){
                            // if claim category code is in the list, mark as a subrogation record
                            if(record.getClaimCategoryCode() != null){
                                if(subrogationCodes.contains(record.getClaimCategoryCode().getCode())){
                                    subrogationRecords.add(record);
                                } else {
                                    claimStatusRecords.add(record);
                                }
                            }
                        }
                        //if claimstatus record exist, add claimstatus alert for patient.
                        if(claimStatusRecords.size() > 0){
                            claimsAlerts.put(patientId, claimStatusRecords);
                        }
                        //if subrogation record exist, add subrogation alert for patient.
                        if(subrogationRecords.size() > 0){
                            subrogationAlerts.put(patientId, subrogationRecords);
                        }
                    }
                }
            }
        if(!claimsAlerts.isEmpty()){
            claimsStatusAlert = new MemberClaimsAlert();
            claimsStatusAlert.setClaimAlerts(claimsAlerts);
            claimRelatedAlerts.put(AlertType.CLAIMS_ALERT, claimsStatusAlert);
        }
        if(!subrogationAlerts.isEmpty()){
            subrogationAlert = new MemberSubrogationAlert();
            subrogationAlert.setSubrogationAlerts(subrogationAlerts);
            claimRelatedAlerts.put(AlertType.SUBROGATION_ALERT, subrogationAlert);
        }
        return claimRelatedAlerts;
    }

    /**
     * Fetch the list of claim category codes which are marked as subrogation codes.
     * @return
     */
    private List<String> fetchSubrogationCodes(){
        List<String> subrogationCodes = new ArrayList<String>();
        //Currently hardcoded. This list need to be populated from RULES or REPs.
        subrogationCodes.add(SUBROGATION_CATEGORY_CODE);
        return subrogationCodes;
    }

    /**
     * Fetch a Work instance to run the BusinessClassificationCode, BillingAccount and possibly GroupSummary to get delinquent indicator
     *
     * @param subscriberId
     * @param coverageId
     * @param productCode
     * @param alertResults
     * @param subject
     * @return
     */
    private WorkTask<?> retrieveDelinquencyStatusBySubscriber(final String subscriberId, final String coverageId, final Products productCode, final AlertResults alertResults, final Subject subject) {
        return new WorkTask<DelinquencyStatusDetails>(null, subject, () -> {
            //If searching by subscriber, need to call BusinessClassificationsDAO to see if it is group or individual policy
            BusinessClassificationCodeSearchCriteria businessClassificationCodeCriteria = new BusinessClassificationCodeSearchCriteria();
            businessClassificationCodeCriteria.setSubscriberId(subscriberId);
            businessClassificationCodeCriteria.setProductCode(productCode);
            BusinessClassificationCode businessClassificationCode = businessClassificationsDAO.findBusinessClassificationCode(businessClassificationCodeCriteria);
            alertResults.businessClassificationCode = businessClassificationCode;

            boolean groupPolicy;
            if ((null == businessClassificationCode) || (null == businessClassificationCode.getPolicyType())) {
                //if the policy type wasn't fetched, default to individual
                groupPolicy = Boolean.FALSE;
            } else {
                groupPolicy = (businessClassificationCode.getPolicyType() == PolicyType.GROUP);
            }

            BillingInformation billingInformation;
            if (groupPolicy) {
                //If it is group, call GroupSummary to get the masterARNumber, then call BillingAccountInfo by masterARNumber
                GroupSearchCriteria groupCriteria = new GroupSearchCriteria();
                groupCriteria.setCesGroupNumber(businessClassificationCode.getCesGroupNo());
                groupCriteria.setProductCode(productCode.getCode());
                groupCriteria.setCoverageId(coverageId);
                Group group = groupSummaryDAO.getGroupInformation(groupCriteria);
                billingInformation = billingAccountDAO.findByARNumber(group.getMasterARNumber());
            } else {
                //If it is individual
                billingInformation = billingAccountDAO.findBySubscriber(subscriberId);
            }

            return delinquencyStatusDAO.getDelinquencyStatusDetail(billingInformation.getClientNumber(), billingInformation.getBusinessTypeCode(),
                    billingInformation.getMasterARNumber());
        }) {
            @Override
            public void onComplete() {
                DelinquencyStatusDetails delinquencyStatus = this.getResults();
                if (delinquencyStatus != null && isDelinquencyStatusPopulated(delinquencyStatus)) {
                    DelinquencyAlert alert = new DelinquencyAlert();
                    alert.setDelinquent(isDelinquencyStatusPopulated(delinquencyStatus));
                    alertResults.add(alert);
                }
            }
        };
    }

    /**
     * Fetch a Work instance to run DelinquencyStatusDAO for cases where we already have the billing data (for example if we're in MBR group mode).
     */
    private WorkTask<?> retrieveDelinquencyStatusByGroup(final BillingInformation billingInformation, final AlertResults alertResults, final Subject subject) {
        return new WorkTask<DelinquencyStatusDetails>(null, subject, () ->
                delinquencyStatusDAO.getDelinquencyStatusDetail(billingInformation.getClientNumber(), billingInformation.getBusinessTypeCode(),
                        billingInformation.getMasterARNumber())) {
            @Override
            public void onComplete() {
                DelinquencyStatusDetails delinquencyStatus = this.getResults();
                if (delinquencyStatus != null && isDelinquencyStatusPopulated(delinquencyStatus)) {
                    DelinquencyAlert alert = new DelinquencyAlert();
                    alert.setDelinquent(isDelinquencyStatusPopulated(delinquencyStatus));
                    alertResults.add(alert);
                }
            }
        };
    }

    /**
     * Gets billing information given ARNumber and subject
     * @param masterARNumber
     * @param subject
     * @return billingInformation
     * @throws Exception
     */
    private BillingInformation getBillingInformation(final String masterARNumber, final Subject subject) throws Exception {
        BillingInformation billingInformation = null;
        if (StringUtils.isNotBlank(masterARNumber)) {
            billingInformation = SubjectUtils.runAsSubject(() -> billingAccountDAO.findByARNumber(masterARNumber), subject);
        }
        return billingInformation;
    }

    /**
     * Determine if Delinquency Status details are populated
     * @param details
     * @return
     */
    private boolean isDelinquencyStatusPopulated(DelinquencyStatusDetails details) {
        return StringUtils.isNotBlank(details.getCancelOnHoldIndicator()) || StringUtils.isNotBlank(details.getClientDelinquencySetId())
                || StringUtils.isNotBlank(details.getClientName()) || StringUtils.isNotBlank(details.getCustomerName())
                || StringUtils.isNotBlank(details.getDelinquencyStage()) || StringUtils.isNotBlank(details.getMasterAccountsReceivableName())
                || StringUtils.isNotBlank(details.getParameterMasterId()) || (details.getCancelHoldStageAccountsReceivableAmount() != null)
                || (details.getCancelHoldStageDelinquencyAccountsReceivableAmount() != null)
                || (details.getCancelHoldStageDelinquencyAccountsReceivableDate() != null) || (details.getCancelHoldStageDueDate() != null)
                || (StringUtils.isNotBlank(details.getCancelReasonCode().getCode())) || (details.getCurrentAccountsReceivableAmount() != null)
                || (details.getCurrentAccountsReceivableDate() != null) || (details.getCurrentDelinquentAccountsReceivableAmount() != null)
                || (details.getCurrentDelinquentAccountsReceivableDate() != null) || (details.getDueDate() != null)
                || (details.getInitialEvaluationDate() != null) || (details.getLastPaymentAmount() != null) || (details.getLastPaymentDate() != null)
                || (StringUtils.isNotBlank(details.getLetterDistributionCode().getCode())) || (details.getProjectedCancelEffectiveDate() != null)
                || (details.getProjectedCancelProcessDate() != null);
    }

    /**
     * Returns all the alerts that should be retrieved for a given call center.
     *
     * @param callCenter
     * @param subject
     * @return
     * @throws Exception
     */
    private Map<String, Boolean> getAlertsByCallCenter(String callCenter, Subject subject) throws Exception {
        Map<String, Boolean> alertsByCallCenter = new HashMap<>();

        final String[] alertRulesConfigKeys = { RETRIEVE_GRANDFATHER_ALERT_FLAG, RETRIEVE_MEMBER_EXCEPTION_ALERT_FLAG,
                RETRIEVE_DELINQUENCY_STATUS_ALERT_FLAG, RETRIEVE_SPCL_CONSIDERATIONS_ALERT_FLAG, RETRIEVE_MEMBER_COB_ALERT_FLAG,
                RETRIEVE_MEMBER_CLAIMS_ALERT_FLAG, RETRIEVE_MEMBER_MOBILE_NOTIFICATIONS_ALERT_FLAG };

        // check RULES table if specific alerts are enabled for this call center
        for(String configKey : alertRulesConfigKeys){
            if(IsCallCenterEnabledForAlert(configKey, callCenter, subject)){
                alertsByCallCenter.put(configKey, Boolean.TRUE);
            } else {
                alertsByCallCenter.put(configKey, Boolean.FALSE);
            }
        }

        return alertsByCallCenter;
    }

    @Override
    public boolean isMobileNotificationsEnabledForGroup(final AlertSearchCriteria criteria, Subject userSubject) throws Exception {
        boolean mobileNotificationsEnabled = false;
        String relayMobileNotificationsCode = null;

        Map<String, ?> ruleEntries = DesktopAPI.getRulesEntries(userSubject);
        Map<String, MenuLink> userConfig = (Map<String, MenuLink>) ruleEntries.get(MenuLink.FUNCTION_TYPE_USERCONFIG);
        if (null != userConfig.get(MOBILE_NOTIFY_GRP_PRODUCT_CODE_KEY)) {
            relayMobileNotificationsCode = userConfig.get(MOBILE_NOTIFY_GRP_PRODUCT_CODE_KEY).getLinkAction();
        }
        if (log.isDebugEnabled()) {
            log.debug("Mobile notification group code retrieved from RULES - " + relayMobileNotificationsCode);
        }
        if (null != relayMobileNotificationsCode) {
            // Just because a subscriber isn't covered doesn't mean we don't offer relay.
            // We typically don't but we have to go through the RULZ script to be sure.
            // NOTE: In real life we can't call the MemberEngagementMessaging without coverage,
            // so the main function retrieveDesktopAlerts won't even invoke this, but just in case things
            // change in the future this function is coded properly.
            final boolean isSubscriberCovered = null != criteria.getCoverageId();

            // Since MemberGroupProducts doesn't have PHI we can use the static RACF instead of the user's RACF.
            // This saves a bit of paper work since we only have one RACF to submit access for (its the RCG1, RCGR).
            Subject staticSubject = DesktopAPI.createStaticSubject(null, SubjectUtils.getRegion(userSubject), SubjectUtils.getClient(userSubject));
            final MemberGroupProductsDAO dao = this.memberGroupProductsDAO;
            List<MemberGroupProductCode> groupProducts = SubjectUtils.runAsSubject(() ->
                    dao.retrieveGroupProducts(criteria.getAmmsGroupNumber(),criteria.getSubscriberDateOfBirth(),isSubscriberCovered), staticSubject);

            for (MemberGroupProductCode groupProduct : groupProducts) {
                if (StringUtils.equals(relayMobileNotificationsCode, groupProduct.getCode())) {
                    mobileNotificationsEnabled = true;
                    break;
                }
            }
        }
        if (log.isDebugEnabled()) {
            log.debug("isMobileNotificationsEnabledForGroup - " + mobileNotificationsEnabled);
        }
        return mobileNotificationsEnabled;
    }

    /**
     * Check RULES to see if call center is enabled for the alert
     * 
     * @param configKey
     * @param callCenter
     * @param subject
     * @return
     */
    private boolean IsCallCenterEnabledForAlert(String configKey, String callCenter, Subject subject) throws Exception {
        //If the user is signed into CTI they have a call center
        // if the user is in research mode check for existence of the alert in RULEs for whether to check further.
        
        // For WB1750 the entire MCS desktop should not see Mobile Text Alerts.  However, at least one call center
        // could span both CSR and MCS.  So excluding the call center in the BASELINK RULE would work for the MCS
        // user of that call center, but it would break the user of the CSR user of that call center.  This new
        // way means that there must be a FUNCTION entry for the Application ID in RULEs if the alert is to show up
        // at all.  During research, it would show all he time, when logged into CTI it could be filtered. For MCS
        // users, there's no MCS Application id entry in FUNCTION for the Mobile Text alerts, so it won't show during
        // research or on a call/logged into CTI.
        
        Map<String, ?> ruleEntries = DesktopAPI.getRulesEntries(subject);
        Map<String, MenuLink> userConfig = (Map<String, MenuLink>) ruleEntries.get(MenuLink.FUNCTION_TYPE_USERCONFIG);
        boolean alertEnabled = true;

        if (null != userConfig.get(configKey) && StringUtils.isNotBlank(callCenter)) {

            if(null != userConfig.get(configKey)) {
                //Remove spaces
                List<String> callCentersForConfigKey = Arrays.asList(StringUtils.trimToEmpty(
                        StringUtils.deleteWhitespace(userConfig.get(configKey).getLinkAction())).split(COMMA));

                if (log.isDebugEnabled()) {
                    log.debug("Callcenter name provided is: "+ callCenter);
                    log.debug("Callcenter black list for Config Key - "+ configKey + " - is: "+ callCentersForConfigKey.toString());
                }

                //If call center exists in the black list, alert is disabled.
                if (callCentersForConfigKey.contains(callCenter)) {
                    alertEnabled = false;
                }
            } else {
                log.warn("Cannot find key \""+configKey+"\" in rules.  Alert is disabled for all call centers for this Desktop (MCS, MBR, CSR), including \""+callCenter+"\"");
                alertEnabled = false;
            }
        }

        return alertEnabled;
    }
}
