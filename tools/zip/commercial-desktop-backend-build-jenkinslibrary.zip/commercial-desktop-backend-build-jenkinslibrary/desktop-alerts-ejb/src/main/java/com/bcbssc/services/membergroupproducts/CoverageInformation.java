
package com.bcbssc.services.membergroupproducts;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CoverageInformation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoverageInformation">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dependentId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cesMemberNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sexRelationship" type="{http://common.model.commservices.bcbssc.com}Code" minOccurs="0"/>
 *         &lt;element name="privacyProtectionEnabled" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="coverage" type="{http://common.model.commservices.bcbssc.com}Code" minOccurs="0"/>
 *         &lt;element name="covered" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="coveragePeriod" type="{http://common.model.commservices.bcbssc.com}PeriodDate" minOccurs="0"/>
 *         &lt;element name="coverageDescription" type="{http://common.model.commservices.bcbssc.com}CoverageDescription" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoverageInformation", propOrder = {
    "dependentId",
    "cesMemberNumber",
    "sexRelationship",
    "privacyProtectionEnabled",
    "coverage",
    "covered",
    "coveragePeriod",
    "coverageDescription"
})
public class CoverageInformation {

    protected String dependentId;
    protected String cesMemberNumber;
    protected Code sexRelationship;
    protected boolean privacyProtectionEnabled;
    protected Code coverage;
    protected boolean covered;
    protected PeriodDate coveragePeriod;
    @XmlSchemaType(name = "string")
    protected CoverageDescription coverageDescription;

    /**
     * Gets the value of the dependentId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDependentId() {
        return dependentId;
    }

    /**
     * Sets the value of the dependentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDependentId(String value) {
        this.dependentId = value;
    }

    /**
     * Gets the value of the cesMemberNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCesMemberNumber() {
        return cesMemberNumber;
    }

    /**
     * Sets the value of the cesMemberNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCesMemberNumber(String value) {
        this.cesMemberNumber = value;
    }

    /**
     * Gets the value of the sexRelationship property.
     * 
     * @return
     *     possible object is
     *     {@link Code }
     *     
     */
    public Code getSexRelationship() {
        return sexRelationship;
    }

    /**
     * Sets the value of the sexRelationship property.
     * 
     * @param value
     *     allowed object is
     *     {@link Code }
     *     
     */
    public void setSexRelationship(Code value) {
        this.sexRelationship = value;
    }

    /**
     * Gets the value of the privacyProtectionEnabled property.
     * 
     */
    public boolean isPrivacyProtectionEnabled() {
        return privacyProtectionEnabled;
    }

    /**
     * Sets the value of the privacyProtectionEnabled property.
     * 
     */
    public void setPrivacyProtectionEnabled(boolean value) {
        this.privacyProtectionEnabled = value;
    }

    /**
     * Gets the value of the coverage property.
     * 
     * @return
     *     possible object is
     *     {@link Code }
     *     
     */
    public Code getCoverage() {
        return coverage;
    }

    /**
     * Sets the value of the coverage property.
     * 
     * @param value
     *     allowed object is
     *     {@link Code }
     *     
     */
    public void setCoverage(Code value) {
        this.coverage = value;
    }

    /**
     * Gets the value of the covered property.
     * 
     */
    public boolean isCovered() {
        return covered;
    }

    /**
     * Sets the value of the covered property.
     * 
     */
    public void setCovered(boolean value) {
        this.covered = value;
    }

    /**
     * Gets the value of the coveragePeriod property.
     * 
     * @return
     *     possible object is
     *     {@link PeriodDate }
     *     
     */
    public PeriodDate getCoveragePeriod() {
        return coveragePeriod;
    }

    /**
     * Sets the value of the coveragePeriod property.
     * 
     * @param value
     *     allowed object is
     *     {@link PeriodDate }
     *     
     */
    public void setCoveragePeriod(PeriodDate value) {
        this.coveragePeriod = value;
    }

    /**
     * Gets the value of the coverageDescription property.
     * 
     * @return
     *     possible object is
     *     {@link CoverageDescription }
     *     
     */
    public CoverageDescription getCoverageDescription() {
        return coverageDescription;
    }

    /**
     * Sets the value of the coverageDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoverageDescription }
     *     
     */
    public void setCoverageDescription(CoverageDescription value) {
        this.coverageDescription = value;
    }

}
