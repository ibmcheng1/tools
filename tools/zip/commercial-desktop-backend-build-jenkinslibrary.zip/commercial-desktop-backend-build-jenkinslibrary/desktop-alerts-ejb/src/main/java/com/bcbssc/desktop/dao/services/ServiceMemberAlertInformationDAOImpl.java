/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2017 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.dao.services;

import com.bcbssc.desktop.dao.alerts.MemberAlertInformationDAO;
import com.bcbssc.desktop.util.exception.security.DataAccessAuthorizationException;
import com.bcbssc.desktop.util.services.BaseServiceIntegrator;
import com.bcbssc.domain.entity.CoverageId;
import com.bcbssc.domain.entity.ExceptionsSummaryRecord;
import com.bcbssc.domain.entity.NotesSummaryRecord;
import com.bcbssc.domain.entity.alerts.Alert;
import com.bcbssc.domain.entity.alerts.AlertSearchCriteria;
import com.bcbssc.domain.entity.alerts.AlertType;
import com.bcbssc.domain.entity.alerts.COBAlert;
import com.bcbssc.domain.entity.alerts.GrandfatherAlert;
import com.bcbssc.domain.entity.alerts.MemberExceptionAlert;
import com.bcbssc.domain.entity.alerts.SpecialNotesAlert;
import com.bcbssc.domain.entity.codes.ControlCode;
import com.bcbssc.services.memberalertinformation.ArrayOfMemberAlertInformationAlertTypes;
import com.bcbssc.services.memberalertinformation.MemberAlertInformationAlertInformation;
import com.bcbssc.services.memberalertinformation.MemberAlertInformationAlertTypes;
import com.bcbssc.services.memberalertinformation.MemberAlertInformationInput;
import com.bcbssc.services.memberalertinformation.MemberAlertInformationOutput;
import com.bcbssc.services.memberalertinformation.MemberAlertInformationService;
import com.bcbssc.services.memberalertinformation.MemberAlertInformationServiceService;
import com.bcbssc.wsutils.exception.BcbsscDetailedSoapFaultException;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.jws.HandlerChain;
import javax.xml.ws.WebServiceRef;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

@Stateless
@Local
public class ServiceMemberAlertInformationDAOImpl extends BaseServiceIntegrator<MemberAlertInformationService, AlertSearchCriteria, MemberAlertInformationInput, List<MemberAlertInformationOutput>, List<Alert>> implements MemberAlertInformationDAO {

    /**
    * Logger for this class.
    */
    private static final Log log = LogFactory.getLog(ServiceMemberAlertInformationDAOImpl.class);

    private static final String GRANDFATHER_INDICATOR = "GF";
    private static final String EXCEPTION_INDICATOR = "EX";
    private static final String SPECIAL_CONSIDERATION_INDICATOR = "SC";
    private static final String COB_QUESTIONNAIRE_INDICATOR = "CQ";
    private static final String DEFAULT_PATIENT_NAME = "CONTRACT";
    private static final String DEFAULT_MEMBER_NUMBER = "0000";
    private static final String MORE_DATA_INDICATOR = "Y";
    private static final String ALERT_LEVEL_SUBSCRIBER = "S";
    private static final String ALERT_LEVEL_GROUP = "G";
    private static final String ALERT_LEVEL_CLIENT = "C";
    private static final String DEFAULT_GROUP_NAME = "GROUP";
    private static final String DEFAULT_CLIENT_NAME = "CLIENT";

    @HandlerChain(file = "./handlerchain/soax-service-handler-chain.xml")
    @WebServiceRef(wsdlLocation = "META-INF/wsdl/MemberAlertInformation.wsdl", value = MemberAlertInformationServiceService.class)
    private MemberAlertInformationService service;

    @Override
    public List<Alert> retrieveMemberAlerts(AlertSearchCriteria searchCriteria) {
        if(log.isDebugEnabled()) debug("Entered retrieveMemberAlerts(searchCriteria, Subject) function", "retrieveMemberAlerts");
        List<Alert> alerts = new ArrayList<>();

        //Execute WS call
        List<Alert> memberAlertList = this.consumeService(searchCriteria);

        if(log.isDebugEnabled()) debug("Finished MemberAlertInfo WS Call(s). Adding member alert list to master alerts list...", "retrieveMemberAlerts");
        if (memberAlertList != null && memberAlertList.size() > 0) {
            if(log.isDebugEnabled()) debug("memberAlertList = " + memberAlertList, "retrieveMemberAlerts");
            alerts.addAll(memberAlertList);
        } else {
            if(log.isDebugEnabled()) debug("Returning alerts from MemberAlertInformationDAO.retrieveMemberAlerts(): alert list is empty", "retrieveMemberAlerts");
        }
        return alerts;
    }

    private ExceptionsSummaryRecord splitDeferralOverrideCodes(ExceptionsSummaryRecord record) {
        //deferral or deferral/override - eg: D5B84/5B84D
        String deferralString = StringUtils.trimToEmpty(record.getDeferral());
        if(log.isDebugEnabled()) debug("deferralString = [" + deferralString + "]", "splitDeferralOverrideCodes");
        // If string has '/' in it, we will split deferral and override.
        if (StringUtils.isNotBlank(deferralString) && deferralString.indexOf('/') != -1) {
            String[] codes = deferralString.split("/");
            if (codes.length == 2) {
                if(log.isDebugEnabled()) debug("Found deferral and override codes [" + codes[0] + "],[" + codes[1] + "]", "splitDeferralOverrideCodes");
                record.setDeferral(codes[0]);
                record.setOverride(codes[1]);
            }
        }
        return record;
    }

    @Override
	public MemberAlertInformationService getService() {
        return service;
    }

    @Override
	public void setService(MemberAlertInformationService service) {
		this.service = service;
	}

    @Override
    protected String getServiceName() {
        return MemberAlertInformationService.class.getSimpleName();
    }

    @Override
    public MemberAlertInformationInput mapInput(AlertSearchCriteria searchCriteria) {

        //Converting List<AlertType> to List<MemberAlertInformationAlertTypes>
        List<MemberAlertInformationAlertTypes> alertTypes = new ArrayList<>();
        CoverageId coverage = searchCriteria.getCoverageId();
        MemberAlertInformationInput memberAlertInput = new MemberAlertInformationInput();

        if (coverage != null) {
            memberAlertInput.setCoverageLevelCodeRequested(coverage.getCoverageLevelCode());
            memberAlertInput.setCoverageNumberRequested(coverage.getCoverageNumber());
            memberAlertInput.setCoverageBenefitLvlNumRequested(coverage.getBenefitLevel());

            if (coverage.getProductCode() != null) {
                memberAlertInput.setCoverageProductCodeRequested(coverage.getProductCode().getCode());
                memberAlertInput.setProductCodeRequested(coverage.getProductCode().getCode());
            }
        }

        memberAlertInput.setRpnNumber(searchCriteria.getRpn());
        memberAlertInput.setSearchDate(searchCriteria.getSearchDate());
        memberAlertInput.setSubscriberNumber(searchCriteria.getSubscriberId());
        memberAlertInput.setClientNumberRequested(searchCriteria.getClientNumberRequested());
        memberAlertInput.setMemberNumberRequested(searchCriteria.getPatientId());
        memberAlertInput.setAllMemberAlertsIndicator(searchCriteria.getAllMemberAlertsIndicator());
        memberAlertInput.setGroupNumberRequested(searchCriteria.getGroupNumberRequested());
        memberAlertInput.setRequestRacfId(StringUtils.EMPTY);

        int overflowCount = 0;
        if (searchCriteria.getAlertTypeRequested().isEmpty()) {
            if(log.isWarnEnabled()) log.warn("No AlertTypes were requested. No alerts will be returned from MemberAlertInformation web service.");
        } else {
            for (AlertType alert : searchCriteria.getAlertTypeRequested()) {
                MemberAlertInformationAlertTypes memberAlert = new MemberAlertInformationAlertTypes();
                if(log.isDebugEnabled()) debug("Retrieving alert type " + alert.getType(), "MemberAlertInformationServiceCallback.mapInput");
                memberAlert.setAlertTypeRequested(alert.getType());
                alertTypes.add(memberAlert);
            }

            //MemberAlertInformationInput DTO requires a minimum of 25 entries, SOAExpress limitation
            while (alertTypes.size() < 25) {
                overflowCount++;
                MemberAlertInformationAlertTypes emptyAlrt = new MemberAlertInformationAlertTypes();
                emptyAlrt.setAlertTypeRequested(StringUtils.EMPTY);
                alertTypes.add(emptyAlrt);
                if (overflowCount > 50) {
                    if(log.isWarnEnabled()) log.warn("Filling out MemberAlertInformationAlertTypes[25] looped more than 50 times, forced break from while loop!");
                    break;
                }
            }
            memberAlertInput.setAlertTypes(new ArrayOfMemberAlertInformationAlertTypes());
            memberAlertInput.getAlertTypes().getMemberAlertInformationAlertTypes().addAll(alertTypes);
        }

        return memberAlertInput;
    }

    @Override
    public List<MemberAlertInformationOutput> invokeService(MemberAlertInformationInput memberAlertInformationInput, MemberAlertInformationService service) throws Exception {
    	final int MAX = 50;
    	int dataPageCount = 0;
    	boolean keepGoing = true;
        List<MemberAlertInformationOutput> memberAlertInformationOutputs = new ArrayList<>(MAX);

    	do {
            dataPageCount++;
            if(log.isDebugEnabled()) debug("Retrieving page " + dataPageCount + " of member alert data...", "invokeService");

            try {
            	MemberAlertInformationOutput memberAlertInformationOutput = service.getMemberAlerts(memberAlertInformationInput);
           		memberAlertInformationOutputs.add(memberAlertInformationOutput);

           		// Next page...
                memberAlertInformationInput.setMoreDataIndicatorRequested(MORE_DATA_INDICATOR);
                memberAlertInformationInput.setMoreDataPageNumberRequested(memberAlertInformationOutput.getMoreDataPageNumber());

           		if (!MORE_DATA_INDICATOR.equals(memberAlertInformationOutput.getMoreDataIndicator())) {
           			keepGoing = false;
           		}
           		if (dataPageCount > MAX) {
           			log.warn("MemberAlertService attempted retrieving more than " + MAX + " pages of alert information. Breaking while loop...");
           			keepGoing = false;
           		}
            } catch (BcbsscDetailedSoapFaultException ex) {
            	if (StringUtils.contains(ex.getFaultDetails().getApplicationMessage(), "NOT FOUND ON NOTES AREA SECURITY")) {
            		log.error(ex);
            		throw new DataAccessAuthorizationException(ex.getFaultDetails().getApplicationMessage(), ex);
            	} else {
            		throw ex;
            	}
            }
    	} while (keepGoing);


        if(log.isDebugEnabled()) debug("Member alert retrieval completed, total page count:  " + dataPageCount, "invokeService");

        return memberAlertInformationOutputs;
    }

    @Override
    public List<Alert> mapOutput(List<MemberAlertInformationOutput> memberAlertOutputs) {
        List<Alert> alerts = new ArrayList<>();

        if (memberAlertOutputs != null && memberAlertOutputs.size() > 0) {
            Map<String, List<ExceptionsSummaryRecord>> patientIdToRecordsMap = new HashMap<>();
            Map<String, NotesSummaryRecord> memberNumberToNotesMap = new HashMap<>();
            for (MemberAlertInformationOutput memberAlertOutput : memberAlertOutputs) {
                List<MemberAlertInformationAlertInformation> memberAlertInfos = memberAlertOutput.getAlertInformation().getMemberAlertInformationAlertInformation();

                //Process MemberAlertInformationAlertInformation records returned from WS call
                for (MemberAlertInformationAlertInformation memberAlertInfo : memberAlertInfos) {
                    //If memberAlertInfo is a Grandfather alert, add Grandfather alert directly to alerts object list
                    if (memberAlertInfo.getAlertType().equals(GRANDFATHER_INDICATOR)) {
                        GrandfatherAlert grandfatherAlert = new GrandfatherAlert();
                        grandfatherAlert.setGrandfatherIndicator(true);
                        alerts.add(grandfatherAlert);
                    }
                    //If memberAlertInfo is an Exception alert, add Exception alert to patienIdToRecordsMap object map
                    if (memberAlertInfo.getAlertType().equals(EXCEPTION_INDICATOR)) {
                        ExceptionsSummaryRecord exceptionRecord = new ExceptionsSummaryRecord();
                        exceptionRecord.setAlertExceptionIndicator(true);
                        String patientId = StringUtils.trimToEmpty(memberAlertInfo.getMemberPatientId());
                        ControlCode controlCode = new ControlCode(memberAlertInfo.getAlertTypeCode1(), memberAlertInfo.getAlertTypeDescription1());
                        exceptionRecord.setControlCode(controlCode);

                        if (StringUtils.isNotEmpty(memberAlertInfo.getAlertTypeCode2())) {
                            exceptionRecord.setDeferral(memberAlertInfo.getAlertTypeCode2());
                            exceptionRecord.setExceptionDescription(memberAlertInfo.getAlertTypeDescription2());
                        }

                        //If there is no name or patient ID, assume that this exception record is a contract
                        if (StringUtils.isBlank(memberAlertInfo.getMemberPatientId()) || StringUtils.isBlank(memberAlertInfo.getMemberFirstName())) {
                            exceptionRecord.setContractLevelExceptionIndicator(true);
                            exceptionRecord.setPatientName(DEFAULT_PATIENT_NAME);
                            exceptionRecord.setPatientID(StringUtils.EMPTY);
                        } else {
                            exceptionRecord.setContractLevelExceptionIndicator(false);
                            exceptionRecord.setPatientName(StringUtils.trimToEmpty(memberAlertInfo.getMemberFirstName()));
                            exceptionRecord.setPatientID(patientId);
                        }

                        if(StringUtils.isNotBlank(exceptionRecord.getDeferral())) {
                            exceptionRecord = splitDeferralOverrideCodes(exceptionRecord);
                        }

                        if (patientIdToRecordsMap.containsKey(patientId)) {
                            patientIdToRecordsMap.get(patientId).add(exceptionRecord);
                        } else {
                            List<ExceptionsSummaryRecord> exceptions = new ArrayList<>();
                            exceptions.add(exceptionRecord);
                            patientIdToRecordsMap.put(patientId, exceptions);
                        }
                    }

                  //If memberAlertInfo is a Special Consideration/Note alert, add Notes alert to patienIdToNotesMap object map
                    if (memberAlertInfo.getAlertType().equals(SPECIAL_CONSIDERATION_INDICATOR)) {
                        NotesSummaryRecord notesSummaryRecord;
                        //Need composite key coz of group level alerts
                        String notesKey = memberAlertInfo.getMemberNumber() + memberAlertInfo.getAlertLevel();
                        
                        //Check if an entry exist for the patient for notes
                        if(memberNumberToNotesMap.get(notesKey) != null){
                            notesSummaryRecord = memberNumberToNotesMap.get(notesKey);
                        } else {
                            notesSummaryRecord = new NotesSummaryRecord();
                            memberNumberToNotesMap.put(notesKey, notesSummaryRecord);
                        }
                        // Identify contract level vs member level vs client level notes entry
                        if (DEFAULT_MEMBER_NUMBER.equals(memberAlertInfo.getMemberNumber())) {
                            if(ALERT_LEVEL_SUBSCRIBER.equals(memberAlertInfo.getAlertLevel())){
                                notesSummaryRecord.setContractLevelRecordIndicator(true);
                                notesSummaryRecord.setPatientFirstName(DEFAULT_PATIENT_NAME);
                            } else if(ALERT_LEVEL_GROUP.equals(memberAlertInfo.getAlertLevel())){
                                notesSummaryRecord.setPatientFirstName(DEFAULT_GROUP_NAME);
                            } else if(ALERT_LEVEL_CLIENT.equals(memberAlertInfo.getAlertLevel())) {
                                notesSummaryRecord.setPatientFirstName(DEFAULT_CLIENT_NAME);
                            }
                        } else {
                            notesSummaryRecord.setPatientFirstName(StringUtils.trimToEmpty(memberAlertInfo.getMemberFirstName()));
                            notesSummaryRecord.setContractLevelRecordIndicator(false);
                        }
                        //Extract notes text from the code and description fields.
                        if(notesSummaryRecord.getNotesText() != null){
                            notesSummaryRecord.getNotesText().add(addNotesFromMemberAlerts(memberAlertInfo));
                        } else {
                            List<String> notesList = new ArrayList<>();
                            notesList.add(addNotesFromMemberAlerts(memberAlertInfo));
                            notesSummaryRecord.setNotesText(notesList);
                        }
                    }
                    
                  //If memberAlertInfo is a Special Consideration/Note alert, add Notes alert to patienIdToRecordsMap object map
                    if (memberAlertInfo.getAlertType().equals(COB_QUESTIONNAIRE_INDICATOR)) {
                         COBAlert cobQuestionnaireAlert = new COBAlert();
                         cobQuestionnaireAlert.setResponseRequired(true);
                         alerts.add(cobQuestionnaireAlert);
                    }
                }
            }
            //Add EX alerts patientIdToRecordsMap to alerts object list
            if (!patientIdToRecordsMap.isEmpty()) {
                MemberExceptionAlert exceptionAlert = new MemberExceptionAlert();
                exceptionAlert.setMemberExceptions(patientIdToRecordsMap);
                alerts.add(exceptionAlert);
            }
            
            //Add Notes alerts patientIdToNotesMap to alerts object list
            if (!memberNumberToNotesMap.isEmpty()) {
                SpecialNotesAlert notesAlert = new SpecialNotesAlert();
                notesAlert.setMemberSpecialNoteRecords(new ArrayList<>());
                // All notes summary records will go into the list
                for(Entry<String, NotesSummaryRecord> entry : memberNumberToNotesMap.entrySet()){
                    notesAlert.getMemberSpecialNoteRecords().add(entry.getValue());
                }
                alerts.add(notesAlert);
            }
        }

        return alerts;
    }

    private String addNotesFromMemberAlerts(MemberAlertInformationAlertInformation memberAlertInfo){
        StringBuilder notesBuilder = new StringBuilder();
        //Add notes string from alert code-description 1-5

        if(StringUtils.isNotBlank(memberAlertInfo.getAlertTypeCode1())){
                notesBuilder.append(memberAlertInfo.getAlertTypeCode1());
        }
        if(StringUtils.isNotBlank(memberAlertInfo.getAlertTypeDescription1())){
                notesBuilder.append(memberAlertInfo.getAlertTypeDescription1());
        }

        if(StringUtils.isNotBlank(memberAlertInfo.getAlertTypeCode2())){
                notesBuilder.append(memberAlertInfo.getAlertTypeCode2());
        }
        if(StringUtils.isNotBlank(memberAlertInfo.getAlertTypeDescription2())){
                notesBuilder.append(memberAlertInfo.getAlertTypeDescription2());
        }

        if(StringUtils.isNotBlank(memberAlertInfo.getAlertTypeCode3())){
                notesBuilder.append(memberAlertInfo.getAlertTypeCode3());
        }
        if(StringUtils.isNotBlank(memberAlertInfo.getAlertTypeDescription3())){
                notesBuilder.append(memberAlertInfo.getAlertTypeDescription3());
        }

        if(StringUtils.isNotBlank(memberAlertInfo.getAlertTypeCode4())){
                notesBuilder.append(memberAlertInfo.getAlertTypeCode4());
        }
        if(StringUtils.isNotBlank(memberAlertInfo.getAlertTypeDescription4())){
                notesBuilder.append(memberAlertInfo.getAlertTypeDescription4());
        }

        if(StringUtils.isNotBlank(memberAlertInfo.getAlertTypeCode5())){
                notesBuilder.append(memberAlertInfo.getAlertTypeCode5());
        }
        if(StringUtils.isNotBlank(memberAlertInfo.getAlertTypeDescription5())){
                notesBuilder.append(memberAlertInfo.getAlertTypeDescription5());
        } 

        return notesBuilder.toString();
    }

    /**
     * Write to log.debug
     */
    private void debug(String input, String function) {
        log.debug(function + " [" + input + "]");
    }
}
