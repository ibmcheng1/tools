/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2017 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.dao.services;

import com.bcbssc.desktop.dao.alerts.MobileTextNotificationsDAO;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.services.BaseServiceIntegrator;
import com.bcbssc.domain.entity.MemberMobileNotificationsRecord;
import com.bcbssc.domain.entity.MobileTextNotificationSearchCriteria;
import com.bcbssc.domain.entity.codes.RelationshipCode;
import com.bcbssc.domain.entity.enums.MobileNotificationConsentType;
import com.bcbssc.domain.entity.enums.Subsystems;
import com.bcbssc.services.memberengagementmessaging.EngagementPreferences;
import com.bcbssc.services.memberengagementmessaging.EngagementPreferencesInfo;
import com.bcbssc.services.memberengagementmessaging.InquiryConsentType;
import com.bcbssc.services.memberengagementmessaging.MemberEngagementMessaging;
import com.bcbssc.services.memberengagementmessaging.MemberEngagementMessaging_Service;
import com.bcbssc.services.memberengagementmessaging.MemberInformation;
import com.bcbssc.services.memberengagementmessaging.ProductCode;
import com.bcbssc.services.memberengagementmessaging.UpdateConsentType;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.jws.HandlerChain;
import javax.security.auth.Subject;
import javax.xml.ws.WebServiceRef;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/**
 * Web service implementation for Mobile Text Notifications DAO. Calls LEDS service MemberEngagementMessaging
 * 
 * https://dcmis.bcbssc.com/sites/sysdoc/ws/WebServiceDocumentation/MemberEngagementMessaging/MemberEngagementMessaging.docx
 */
@Stateless
@Local
public class ServiceMobileTextNotificationDAOImpl
		extends
        BaseServiceIntegrator<MemberEngagementMessaging, ServiceMobileTextNotificationDAOImpl.DesktopInput, ServiceMobileTextNotificationDAOImpl.MemberEngagementMessagingInput, ServiceMobileTextNotificationDAOImpl.MemberEngagementMessagingOutput, ServiceMobileTextNotificationDAOImpl.DesktopOutput>
		implements MobileTextNotificationsDAO {
	/**
	 * Logger for this class.
	 */
	private static final Log log = LogFactory.getLog(ServiceMobileTextNotificationDAOImpl.class);
	private static final String FETCH_MEMBER_RECORD_OPERATION = "getEngagementMemberRecord";
	private static final String UPDATE_MEMBER_RECORD_OPERATION = "updateEngagementMemberRecord";

	@HandlerChain(file = "./handlersupport/chain/java-service-handler-chain.xml")
    @WebServiceRef(wsdlLocation = "META-INF/wsdl/MemberEngagementMessaging.wsdl", value = MemberEngagementMessaging_Service.class)
	private MemberEngagementMessaging service;

	/** Wraps up all the inputs for the actual service into one object. */
	protected class MemberEngagementMessagingInput {
		/** The method on the service to call. */
		String operation;
		String rpn;
		public ProductCode productCode;
		List<InquiryConsentType> inquiryConsentTypes;
		MemberInformation memberInformation;
		String clientChannel = "CSRDSKTP";
		/** RACF */
		String userId;
		/** Pass back in the value from EngagementPreferencesInfo for update. */
		String templateCode;
		/** All digits, no spaces, no parens, no dashes, no dots, just 8003334444 */
		String mobileNumber;
		UpdateConsentType consentType;
	}

	class MemberEngagementMessagingOutput {
		/** The method on the service that was called. */
		String operation;
		EngagementPreferencesInfo getEngagementPreferencesInfoOutput;
		boolean updateEngagementPreferencesOutput;
	}

	class DesktopInput {
		/** The method on the service to call. */
		String operation;
		MobileTextNotificationSearchCriteria criteria;
		/** Pass back in the value from EngagementPreferencesInfo for update. */
		String templateCode;
		String mobileNumber;
		/** Enum value name of UpdateConsentType */
		String consentType;
	}

	class DesktopOutput {
		/** The method on the service that was called. */
		String operation;
		/** AMMS Patient ID to Alert Record. */
		HashMap<String, MemberMobileNotificationsRecord> getEngagementPreferencesInfoOutput;
		boolean updateEngagementPreferencesOutput;
	}

	@Override
	public HashMap<String, MemberMobileNotificationsRecord> getEngagementMemberRecords(MobileTextNotificationSearchCriteria criteria) {
		DesktopInput input = new DesktopInput();
		input.operation = FETCH_MEMBER_RECORD_OPERATION;
		input.criteria = criteria;
		return (this.consumeService(input)).getEngagementPreferencesInfoOutput;
	}

	@Override
	public boolean updateEngagementPreferences(MobileTextNotificationSearchCriteria criteria, String templateCode, String mobileNumber, String consentType) {
		DesktopInput input = new DesktopInput();
		input.operation = UPDATE_MEMBER_RECORD_OPERATION;
		input.criteria = criteria;
		input.templateCode = templateCode;
		input.mobileNumber = mobileNumber;
		input.consentType = consentType;
		return (this.consumeService(input)).updateEngagementPreferencesOutput;
	}

	@Override
	public MemberEngagementMessaging getService() {
		return this.service;
	}

    @Override
    public MemberEngagementMessagingInput mapInput(DesktopInput input) {
        MobileTextNotificationSearchCriteria criteria = input.criteria;
        Subject subject = SubjectUtils.getCurrentSubject();

        MemberEngagementMessagingInput request = new MemberEngagementMessagingInput();
        request.operation = input.operation;

        request.productCode = ProductCode.valueOf(criteria.getProduct().getCode());
        request.rpn = SubjectUtils.getRpnForSubsystem(subject, Subsystems.CISI);
        MemberInformation memberInformation = new MemberInformation();
        memberInformation.setAmmsGroupNumber(criteria.getAmmsGroupNumber());
        memberInformation.setBusinessSectorCode(criteria.getBusinessSectorCode());
        //For update, alphaPrefix will be a part of the id card number field.
        if (StringUtils.isNotBlank(criteria.getAlphaPrefix())) {
            memberInformation.setIdCardNumber(criteria.getAlphaPrefix() + criteria.getIdCardNumber());
        } else {
            memberInformation.setIdCardNumber(criteria.getIdCardNumber());
        }
        memberInformation.setMemberNumber(criteria.getSubscriberId());

        if (criteria.getMember() != null && criteria.getMember().getDateOfBirth() != null && StringUtils.isNotBlank(criteria.getMember().getCesMemberNumber())
                && StringUtils.isNotBlank(criteria.getMember().getMemberId())) {
            memberInformation.setAmmsPatientNumber(criteria.getMember().getMemberId());
            memberInformation.setCesMemberNumber(criteria.getMember().getCesMemberNumber());
            memberInformation.setDateOfBirth(criteria.getMember().getDateOfBirth());
            memberInformation.setGender(criteria.getMember().getSex().getCode());
        } else {
            // This list let the service know which consent types where Desktop need to call RULEs for alerts.
            // This is not required for a specific member retrieval. All member retrievals should inquire RULES no matter which consent type.
            request.inquiryConsentTypes = Collections.singletonList(InquiryConsentType.NORECORD);
        }
        request.memberInformation = memberInformation;

        if (UPDATE_MEMBER_RECORD_OPERATION.equals(input.operation)) {
            request.userId = SubjectUtils.getRacfId(subject);
            request.templateCode = input.templateCode;
            request.mobileNumber = input.mobileNumber;
            request.consentType = UpdateConsentType.valueOf(input.consentType);
        }
        return request;
    }

    @Override
    public MemberEngagementMessagingOutput invokeService(MemberEngagementMessagingInput input, MemberEngagementMessaging service) throws Exception {
        MemberEngagementMessagingOutput output = new MemberEngagementMessagingOutput();
        output.operation = input.operation;

        if (FETCH_MEMBER_RECORD_OPERATION.equals(input.operation)) {
            output.getEngagementPreferencesInfoOutput = service.getEngagementPreferencesInfo(input.rpn, input.productCode, input.inquiryConsentTypes, null, input.memberInformation);
        } else if (UPDATE_MEMBER_RECORD_OPERATION.equals(input.operation)) {
            output.updateEngagementPreferencesOutput = service.updateEngagementPreferences(input.clientChannel, input.rpn, input.userId, input.templateCode, input.mobileNumber, input.consentType, input.memberInformation);
        } else {
            throw new Exception("Unsupported operation " + input.operation);
        }
        return output;
    }

    @Override
    public DesktopOutput mapOutput(MemberEngagementMessagingOutput response) {
		DesktopOutput output = new DesktopOutput();
		output.operation = response.operation;

		if (FETCH_MEMBER_RECORD_OPERATION.equals(response.operation)) {
			output.getEngagementPreferencesInfoOutput = this.convertToMap(response.getEngagementPreferencesInfoOutput);
		} else if (UPDATE_MEMBER_RECORD_OPERATION.equals(response.operation)) {
			output.updateEngagementPreferencesOutput = response.updateEngagementPreferencesOutput;
		} else {
			throw new RuntimeException("Unsupported operation " + response.operation);
		}

		return output;
	}


    /**
     *
     * @param serviceOutput Engagement preference information
     * @return Map of member mobile notification records
     */
	private HashMap<String, MemberMobileNotificationsRecord> convertToMap(EngagementPreferencesInfo serviceOutput) {
		HashMap<String, MemberMobileNotificationsRecord> patientToRecordsMap = new HashMap<>();
		for (EngagementPreferences preferences : serviceOutput.getEngagementPreferences()) {
			MemberMobileNotificationsRecord record = mapEngagementPreferencesToMobileNotificationsRecord(preferences);
			patientToRecordsMap.put(record.getPatientId(), record);
		}

		if (log.isDebugEnabled()) {
			log.debug("Mobile Notifications records map from service - " + patientToRecordsMap);
		}

		return patientToRecordsMap;
	}

	/**
	 * Map Engagement Preferences to Mobile Notifications Record
	 * @param preferences Engagement preferences
	 * @return Member mobile notification record
	 */
	private MemberMobileNotificationsRecord mapEngagementPreferencesToMobileNotificationsRecord(EngagementPreferences preferences) {
		MemberMobileNotificationsRecord record = new MemberMobileNotificationsRecord();

		// Straight one to one mapping...
		if (preferences.isSetConsentType()) {
			InquiryConsentType consentType = preferences.getConsentType();
			record.setConsentType(MobileNotificationConsentType.findByConsentType(consentType.value()));
		}
		if (preferences.isSetMemberInformation()) {
			MemberInformation memberInformation = preferences.getMemberInformation();
			record.setBusinessSectorCode(memberInformation.getBusinessSectorCode());
			record.setCesMemberNumber(memberInformation.getCesMemberNumber());
			record.setDateOfBirth(memberInformation.getDateOfBirth());
			record.setGender(memberInformation.getGender());
			record.setIdCardNumber(memberInformation.getIdCardNumber());
			record.setPatientId(memberInformation.getAmmsPatientNumber());
			record.setMobileNumber(preferences.getMobileNumber());
			record.setTemplateCode(preferences.getTemplateCode());
			record.setFirstName(memberInformation.getFirstName());
			RelationshipCode relationship = new RelationshipCode();
			relationship.setCode(memberInformation.getRelationshipIndicator());
			record.setRelationShip(relationship);
			record.setLastName(memberInformation.getLastName());
			record.setAmmsGroupNumber(memberInformation.getAmmsGroupNumber());
		}
		if (preferences.isSetConsentDate()) {
			record.setConsentDate(preferences.getConsentDate());
		}
		record.setShowAlert(preferences.isAlertFlag());
		record.setAlertType(preferences.getAlertType());

		return record;
	}

	@Override
	public void setService(MemberEngagementMessaging service) {
		this.service = service;
	}

    @Override
    protected String getServiceName() {
        return MemberEngagementMessaging.class.getSimpleName();
    }
}
