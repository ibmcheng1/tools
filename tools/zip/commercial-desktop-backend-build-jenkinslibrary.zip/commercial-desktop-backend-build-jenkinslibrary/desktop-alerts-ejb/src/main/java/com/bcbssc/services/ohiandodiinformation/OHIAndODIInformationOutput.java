
package com.bcbssc.services.ohiandodiinformation;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OHIAndODIInformationOutput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OHIAndODIInformationOutput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="applicationMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="serviceMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="serviceMessageCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="systemMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lastMemberReturned" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="moreDataIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="otherInsuranceIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="medicareInsuranceIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="groupBlockStatusIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lastQuestionnaireDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="questionnaireExpirationDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="questionnaireRequiredIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="totalNumberOthInsuranceRecords" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="totalNumberMedicareRecords" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="othInsuranceInfoLocation" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="otherInsurance" type="{http://OHIAndODIInformation.CISIC102EJB.commercial.bcbssc.com}ArrayOfOHIAndODIInformationOtherInsurance"/>
 *         &lt;element name="medicareInsurance" type="{http://OHIAndODIInformation.CISIC102EJB.commercial.bcbssc.com}ArrayOfOHIAndODIInformationMedicareInsurance"/>
 *         &lt;element name="ebizReplyAbendcode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ebizReplyStatus" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ebizReplyStatusMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OHIAndODIInformationOutput", propOrder = {
    "applicationMessage",
    "serviceMessage",
    "serviceMessageCode",
    "systemMessage",
    "lastMemberReturned",
    "moreDataIndicator",
    "otherInsuranceIndicator",
    "medicareInsuranceIndicator",
    "groupBlockStatusIndicator",
    "lastQuestionnaireDate",
    "questionnaireExpirationDate",
    "questionnaireRequiredIndicator",
    "totalNumberOthInsuranceRecords",
    "totalNumberMedicareRecords",
    "othInsuranceInfoLocation",
    "otherInsurance",
    "medicareInsurance",
    "ebizReplyAbendcode",
    "ebizReplyStatus",
    "ebizReplyStatusMessage"
})
public class OHIAndODIInformationOutput {

    @XmlElement(required = true, nillable = true)
    protected String applicationMessage;
    @XmlElement(required = true, nillable = true)
    protected String serviceMessage;
    @XmlElement(required = true, nillable = true)
    protected String serviceMessageCode;
    @XmlElement(required = true, nillable = true)
    protected String systemMessage;
    @XmlElement(required = true, nillable = true)
    protected String lastMemberReturned;
    @XmlElement(required = true, nillable = true)
    protected String moreDataIndicator;
    @XmlElement(required = true, nillable = true)
    protected String otherInsuranceIndicator;
    @XmlElement(required = true, nillable = true)
    protected String medicareInsuranceIndicator;
    @XmlElement(required = true, nillable = true)
    protected String groupBlockStatusIndicator;
    @XmlElement(required = true, nillable = true)
    protected String lastQuestionnaireDate;
    @XmlElement(required = true, nillable = true)
    protected String questionnaireExpirationDate;
    @XmlElement(required = true, nillable = true)
    protected String questionnaireRequiredIndicator;
    @XmlElement(required = true, nillable = true)
    protected String totalNumberOthInsuranceRecords;
    @XmlElement(required = true, nillable = true)
    protected String totalNumberMedicareRecords;
    @XmlElement(required = true, nillable = true)
    protected String othInsuranceInfoLocation;
    @XmlElement(required = true, nillable = true)
    protected ArrayOfOHIAndODIInformationOtherInsurance otherInsurance;
    @XmlElement(required = true, nillable = true)
    protected ArrayOfOHIAndODIInformationMedicareInsurance medicareInsurance;
    @XmlElement(required = true, nillable = true)
    protected String ebizReplyAbendcode;
    protected int ebizReplyStatus;
    @XmlElement(required = true, nillable = true)
    protected String ebizReplyStatusMessage;

    /**
     * Gets the value of the applicationMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationMessage() {
        return applicationMessage;
    }

    /**
     * Sets the value of the applicationMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationMessage(String value) {
        this.applicationMessage = value;
    }

    /**
     * Gets the value of the serviceMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceMessage() {
        return serviceMessage;
    }

    /**
     * Sets the value of the serviceMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceMessage(String value) {
        this.serviceMessage = value;
    }

    /**
     * Gets the value of the serviceMessageCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceMessageCode() {
        return serviceMessageCode;
    }

    /**
     * Sets the value of the serviceMessageCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceMessageCode(String value) {
        this.serviceMessageCode = value;
    }

    /**
     * Gets the value of the systemMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystemMessage() {
        return systemMessage;
    }

    /**
     * Sets the value of the systemMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystemMessage(String value) {
        this.systemMessage = value;
    }

    /**
     * Gets the value of the lastMemberReturned property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastMemberReturned() {
        return lastMemberReturned;
    }

    /**
     * Sets the value of the lastMemberReturned property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastMemberReturned(String value) {
        this.lastMemberReturned = value;
    }

    /**
     * Gets the value of the moreDataIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMoreDataIndicator() {
        return moreDataIndicator;
    }

    /**
     * Sets the value of the moreDataIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMoreDataIndicator(String value) {
        this.moreDataIndicator = value;
    }

    /**
     * Gets the value of the otherInsuranceIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOtherInsuranceIndicator() {
        return otherInsuranceIndicator;
    }

    /**
     * Sets the value of the otherInsuranceIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOtherInsuranceIndicator(String value) {
        this.otherInsuranceIndicator = value;
    }

    /**
     * Gets the value of the medicareInsuranceIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedicareInsuranceIndicator() {
        return medicareInsuranceIndicator;
    }

    /**
     * Sets the value of the medicareInsuranceIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedicareInsuranceIndicator(String value) {
        this.medicareInsuranceIndicator = value;
    }

    /**
     * Gets the value of the groupBlockStatusIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupBlockStatusIndicator() {
        return groupBlockStatusIndicator;
    }

    /**
     * Sets the value of the groupBlockStatusIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupBlockStatusIndicator(String value) {
        this.groupBlockStatusIndicator = value;
    }

    /**
     * Gets the value of the lastQuestionnaireDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastQuestionnaireDate() {
        return lastQuestionnaireDate;
    }

    /**
     * Sets the value of the lastQuestionnaireDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastQuestionnaireDate(String value) {
        this.lastQuestionnaireDate = value;
    }

    /**
     * Gets the value of the questionnaireExpirationDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuestionnaireExpirationDate() {
        return questionnaireExpirationDate;
    }

    /**
     * Sets the value of the questionnaireExpirationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuestionnaireExpirationDate(String value) {
        this.questionnaireExpirationDate = value;
    }

    /**
     * Gets the value of the questionnaireRequiredIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuestionnaireRequiredIndicator() {
        return questionnaireRequiredIndicator;
    }

    /**
     * Sets the value of the questionnaireRequiredIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuestionnaireRequiredIndicator(String value) {
        this.questionnaireRequiredIndicator = value;
    }

    /**
     * Gets the value of the totalNumberOthInsuranceRecords property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTotalNumberOthInsuranceRecords() {
        return totalNumberOthInsuranceRecords;
    }

    /**
     * Sets the value of the totalNumberOthInsuranceRecords property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTotalNumberOthInsuranceRecords(String value) {
        this.totalNumberOthInsuranceRecords = value;
    }

    /**
     * Gets the value of the totalNumberMedicareRecords property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTotalNumberMedicareRecords() {
        return totalNumberMedicareRecords;
    }

    /**
     * Sets the value of the totalNumberMedicareRecords property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTotalNumberMedicareRecords(String value) {
        this.totalNumberMedicareRecords = value;
    }

    /**
     * Gets the value of the othInsuranceInfoLocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthInsuranceInfoLocation() {
        return othInsuranceInfoLocation;
    }

    /**
     * Sets the value of the othInsuranceInfoLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthInsuranceInfoLocation(String value) {
        this.othInsuranceInfoLocation = value;
    }

    /**
     * Gets the value of the otherInsurance property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfOHIAndODIInformationOtherInsurance }
     *     
     */
    public ArrayOfOHIAndODIInformationOtherInsurance getOtherInsurance() {
        return otherInsurance;
    }

    /**
     * Sets the value of the otherInsurance property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfOHIAndODIInformationOtherInsurance }
     *     
     */
    public void setOtherInsurance(ArrayOfOHIAndODIInformationOtherInsurance value) {
        this.otherInsurance = value;
    }

    /**
     * Gets the value of the medicareInsurance property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfOHIAndODIInformationMedicareInsurance }
     *     
     */
    public ArrayOfOHIAndODIInformationMedicareInsurance getMedicareInsurance() {
        return medicareInsurance;
    }

    /**
     * Sets the value of the medicareInsurance property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfOHIAndODIInformationMedicareInsurance }
     *     
     */
    public void setMedicareInsurance(ArrayOfOHIAndODIInformationMedicareInsurance value) {
        this.medicareInsurance = value;
    }

    /**
     * Gets the value of the ebizReplyAbendcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEbizReplyAbendcode() {
        return ebizReplyAbendcode;
    }

    /**
     * Sets the value of the ebizReplyAbendcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEbizReplyAbendcode(String value) {
        this.ebizReplyAbendcode = value;
    }

    /**
     * Gets the value of the ebizReplyStatus property.
     * 
     */
    public int getEbizReplyStatus() {
        return ebizReplyStatus;
    }

    /**
     * Sets the value of the ebizReplyStatus property.
     * 
     */
    public void setEbizReplyStatus(int value) {
        this.ebizReplyStatus = value;
    }

    /**
     * Gets the value of the ebizReplyStatusMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEbizReplyStatusMessage() {
        return ebizReplyStatusMessage;
    }

    /**
     * Sets the value of the ebizReplyStatusMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEbizReplyStatusMessage(String value) {
        this.ebizReplyStatusMessage = value;
    }

}
