
package com.bcbssc.services.membergroupproducts;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PharmacyBenefitVendor.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PharmacyBenefitVendor">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="CAREMARK"/>
 *     &lt;enumeration value="UNKNOWN"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "PharmacyBenefitVendor")
@XmlEnum
public enum PharmacyBenefitVendor {

    CAREMARK,
    UNKNOWN;

    public String value() {
        return name();
    }

    public static PharmacyBenefitVendor fromValue(String v) {
        return valueOf(v);
    }

}
