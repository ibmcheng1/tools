
package com.bcbssc.services.ohiandodiinformation;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ArrayOfOHIAndODIInformationOtherInsurance complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ArrayOfOHIAndODIInformationOtherInsurance">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="OHIAndODIInformationOtherInsurance" type="{http://OHIAndODIInformation.CISIC102EJB.commercial.bcbssc.com}OHIAndODIInformationOtherInsurance" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArrayOfOHIAndODIInformationOtherInsurance", propOrder = {
    "ohiAndODIInformationOtherInsurance"
})
public class ArrayOfOHIAndODIInformationOtherInsurance {

    @XmlElement(name = "OHIAndODIInformationOtherInsurance", nillable = true)
    protected List<OHIAndODIInformationOtherInsurance> ohiAndODIInformationOtherInsurance;

    /**
     * Gets the value of the ohiAndODIInformationOtherInsurance property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ohiAndODIInformationOtherInsurance property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOHIAndODIInformationOtherInsurance().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OHIAndODIInformationOtherInsurance }
     * 
     * 
     */
    public List<OHIAndODIInformationOtherInsurance> getOHIAndODIInformationOtherInsurance() {
        if (ohiAndODIInformationOtherInsurance == null) {
            ohiAndODIInformationOtherInsurance = new ArrayList<OHIAndODIInformationOtherInsurance>();
        }
        return this.ohiAndODIInformationOtherInsurance;
    }

}
