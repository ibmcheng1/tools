/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2016 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */
package com.bcbssc.desktop.biz;

import com.bcbssc.desktop.biz.inform.InformBD;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.Member;
import com.bcbssc.domain.entity.Subscriber;
import com.bcbssc.domain.entity.codes.PatientSexRelationshipCode;
import com.bcbssc.domain.entity.codes.inform.CategoryCode;
import com.bcbssc.domain.entity.codes.inform.InternalExternalIndicatorCode;
import com.bcbssc.domain.entity.codes.inform.ResolutionCode;
import com.bcbssc.domain.entity.codes.inform.StatusCode;
import com.bcbssc.domain.entity.cti.CallCenterAttribute;
import com.bcbssc.domain.entity.enums.Products;
import com.bcbssc.domain.entity.inform.InformRecord;
import com.bcbssc.domain.entity.inform.InformSecurity;
import com.bcbssc.domain.entity.otherInsurance.forms.Individual;
import com.bcbssc.domain.entity.otherInsurance.forms.MedicareMember;
import com.bcbssc.domain.entity.otherInsurance.forms.OtherInsuranceInformation;
import com.bcbssc.domain.entity.otherInsurance.forms.OtherInsuranceQuestionnaire;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.naming.InitialContext;
import javax.security.auth.Subject;
import javax.xml.datatype.XMLGregorianCalendar;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Submits an audit INFOrm record about another insurance policy being added for COB.
 *
 * This started out as being a copy and past the following and then modifying it to fit desktop's needs.
 * <pre>
 * com.bcbssc.commapi.biz.otherinsurance.impl.OhiAuditUtility
 * LEDSCommercialWebServices_1
 * /OtherInsurance-ejb/ejbModule/com/bcbssc/commapi/biz/otherinsurance/impl/OhiAuditUtility.java
 *
 * And the createWorkLoadInform
 * com.bcbssc.commapi.biz.otherinsurance.impl.OtherInsuranceServiceBean
 *
 * otherinsurance-client.jar
 * </pre>
  */
public class OtherInsuranceAuditBiz {

    private static final Log logger = LogFactory.getLog(OtherInsuranceAuditBiz.class);
    
    
    /**
     * Submits a positive COB Inform
     *
     * @param product Product
     * @param subscriber Subscriber
     * @param questionnaire Questionnaire
     * @param callCenterAttribute Call Center Attribute
     * @param user User
     * @throws Exception If there is an error
     */
    public void submitPositiveAudit(Products product, Subscriber subscriber, OtherInsuranceQuestionnaire questionnaire, CallCenterAttribute callCenterAttribute, Subject user) throws Exception {
        createAndSendInformRecord(true, product, subscriber, null, createPositiveRequestVerbiage(product, subscriber, questionnaire), callCenterAttribute, user);
    }

    /**
     * Submits a negative COB Inform
     * 
     * @param product Product
     * @param subscriber Subscriber
     * @param member Member
     * @param callCenterAttribute Call Center Attribute
     * @param user User
     * @throws Exception If there is an error
     */
    public void submitNegativeAudit(Products product, Subscriber subscriber, Member member, CallCenterAttribute callCenterAttribute, Subject user) throws Exception {
        createAndSendInformRecord(false, product, subscriber, member, createNegativeRequestVerbiage(product, subscriber), callCenterAttribute, user);
    }

    /**
     * Creates and send an inform record
     *
     * @param isPositive Is Positive
     * @param product Product
     * @param subscriber Subscriber
     * @param member Member
     * @param requestVerbiage Request Verbiage
     * @param callCenterAttribute Call Center Attribute
     * @param user User
     * @throws Exception If there is an error
     */
    private void createAndSendInformRecord(boolean isPositive, Products product, Subscriber subscriber, Member member, String requestVerbiage, CallCenterAttribute callCenterAttribute, Subject user) throws Exception {
        InformRecord informRecord = new InformRecord();

        informRecord.setKeyId(subscriber.getId());
        informRecord.setRequestVerbiage(requestVerbiage);
        informRecord.setSourceCode("T");

        if(isPositive) {
            //Open status
            StatusCode statusCode = new StatusCode();
            statusCode.setType("OP");
            statusCode.setCode("2");
            informRecord.setStatusCode(statusCode);
        } else {
            //Closed status
            StatusCode statusCode = new StatusCode();
            statusCode.setType("CL");
            statusCode.setCode("1");
            informRecord.setStatusCode(statusCode);
        }

        InformSecurity informSecurity = SubjectUtils.getInformId(user).getInformSecurity();
        informRecord.setCompanyCode(informSecurity.getCompanyCode());
        informRecord.setDepartmentCode(informSecurity.getDepartmentCode());
        informRecord.setDivisionCode(informSecurity.getDivisionCode());
        informRecord.setEmployeeId(informSecurity.getEmployeeId());
        informRecord.setInquiryType(informSecurity.getInquiryType());

        //Comprehensive code (7)
        CategoryCode categoryCode = new CategoryCode();
        categoryCode.setCode("7");
        informRecord.setCategoryCode(categoryCode);

        //External
        InternalExternalIndicatorCode internalExternalInd = new InternalExternalIndicatorCode();
        internalExternalInd.setCode("X");
        informRecord.setInternalExternalInd(internalExternalInd);

        //The COB area bucket
        informRecord.setOwnerCompanyCode(callCenterAttribute.getCompanyTypeForCOBInforms());
        informRecord.setOwnerDepartmentCode(callCenterAttribute.getDepartmentTypeForCOBInforms());
        informRecord.setOwnerDivisionCode(callCenterAttribute.getDivisionTypeForCOBInforms());
        informRecord.setOwnerEmployeeId(callCenterAttribute.getEmployeeIdForCOBInforms());

        //Reason code is either ODI or OHI
        String requestReasonCode;
        if(Products.DENTAL == product) {
            requestReasonCode = "ODI";
        } else {
            requestReasonCode = "OHI";
        }
        informRecord.setRequestCode(requestReasonCode);

        if(null != member) {
            informRecord.setPatientId(member.getMemberId());

            PatientSexRelationshipCode patientSexRelationshipCode = null;
            if(null != member.getRelationship()) {
                patientSexRelationshipCode = new PatientSexRelationshipCode();
                patientSexRelationshipCode.setCode(member.getRelationship().getCode());
            }

            informRecord.setPatientSexRelationshipCode(patientSexRelationshipCode);
        }

        String firstName;
        String lastName = StringUtils.EMPTY;
        if(null != member && null != member.getName()) {
            firstName = member.getName().getFirstName();
            lastName = member.getName().getLastName();
        } else if(null != subscriber.getSubscriberMember() && null != subscriber.getSubscriberMember().getName()) {
            firstName = subscriber.getSubscriberMember().getName().getFirstName();
            lastName = subscriber.getSubscriberMember().getName().getLastName();
        } else {
            firstName = "CONTRACT";
        }
        informRecord.setPatientName(firstName + " " + lastName);

        ResolutionCode resolutionCode = new ResolutionCode();
        resolutionCode.setCode("COMP");
        informRecord.setResolutionCode(resolutionCode);

        this.getInformBD().sendInformMessage(informRecord, true, false, user);
    }

    /**
     * Protected instead of private for JUnit.
     *
     * @param product Product
     * @param subscriber Subscriber
     * @param questionnaire Questionnaire
     * @return String
     */
    protected String createPositiveRequestVerbiage(Products product, Subscriber subscriber, OtherInsuranceQuestionnaire questionnaire){
        StringBuffer requestVerbiage = new StringBuffer();

        if(Products.MEDICAL == product){
            requestVerbiage.append(lineBreaker("Member requested Other Health Insurance: successful"));
        }else if(Products.DENTAL == product){
            requestVerbiage.append(lineBreaker("Member requested Other Dental Insurance: successful"));
        } else {
            throw new IllegalArgumentException("Unable to use product: " + product);
        }

        requestVerbiage.append(lineBreaker("Member ID Card Number: " + subscriber.getIdCardNumber()));

        requestVerbiage.append(createOtherInsuranceRequestLines(questionnaire));
        if (Products.MEDICAL == product) {
            requestVerbiage.append(createMedicareRequestLines(questionnaire));
        }
        return requestVerbiage.toString();
    }

    /**
     * Protected instead of private for JUnit.
     *
     * @param product Product
     * @param subscriber Subscriber
     * @return String
     */
    protected String createNegativeRequestVerbiage(Products product, Subscriber subscriber){
        StringBuffer requestVerbiage = new StringBuffer();
        String firstRequestLine = "Member requested Other ";

        if(Products.MEDICAL == product){
            firstRequestLine += "Health";
        }else if(Products.DENTAL == product){
            firstRequestLine += "Dental";
        } else {
            throw new IllegalArgumentException("Unable to use product: " + product);
        }
        requestVerbiage.append(lineBreaker(firstRequestLine + " Insurance: Negativeupdate"));

        requestVerbiage.append(lineBreaker("Member ID Card Number: " + subscriber.getIdCardNumber()));
        requestVerbiage.append(lineBreaker("Member's ID: " + subscriber.getId()));

        return requestVerbiage.toString();
    }

    /**
     * @param questionnaire Questionnaire
     * @return String
     */
    private String createOtherInsuranceRequestLines(OtherInsuranceQuestionnaire questionnaire){
        StringBuffer otherInsurance = new StringBuffer();
        String otherPolicyHolderName;
        
        if (questionnaire.getOtherInsuranceInformation() != null){
            otherInsurance.append(lineBreaker("OTHER INSURANCE INFORMATION: "));
            
            //76 characters per line.
            for (int i =0; i< questionnaire.getOtherInsuranceInformation().size(); i++){
                OtherInsuranceInformation otherInfo = questionnaire.getOtherInsuranceInformation().get(i);
                if (otherInfo != null){
                    otherPolicyHolderName = otherInfo.getPolicyHolder().getName().getFirstName() + " " + otherInfo.getPolicyHolder().getName().getMiddleName() + " " + otherInfo.getPolicyHolder().getName().getLastName();
                    otherInsurance.append(lineBreaker("Name of Other Policy Holder: " + otherPolicyHolderName));
                    
                    otherInsurance.append(lineBreaker("Other Policyholder's Date of Birth: " + convertDateToString(otherInfo.getPolicyHolder().getDateOfBirth())));
                    
                    otherInsurance.append(lineBreaker("Relationship to you: " + otherInfo.getPolicyHolder().getRelationToSubscriber()));
                    
                    otherInsurance.append(lineBreaker("Policy ID: " + otherInfo.getPolicyHolder().getPolicyNumber()));
                     
                    otherInsurance.append(lineBreaker("Employer's Name, If Coverage is Provided Through an Employer: " + otherInfo.getEmployerName()));
                    otherInsurance.append(lineBreaker("Name of Other Insurance Company: " + otherInfo.getCompanyName()));
    
                    otherInsurance.append(lineBreaker("Effective Date of Policy: " + convertDateToString(otherInfo.getPolicyEffectiveDate().getFromDate())));
                                        
                    otherInsurance.append(lineBreaker("If policy is now terminated, please give termination date: " + convertDateToString(otherInfo.getPolicyEffectiveDate().getToDate())));
    
                    otherInsurance.append(lineBreaker("If there is a divorce or separation, please list who is responsible for the health care expenses: " + otherInfo.getFinancialResponsibilityInformation().getWhoHasResponsibility()));
                    otherInsurance.append(lineBreaker("If there is not a court decree, who has custody of the children? " + otherInfo.getFinancialResponsibilityInformation().getWhoHasCustody()));
                    otherInsurance.append(lineBreaker("Reason For Update: " + otherInfo.getReasonForUpdate()));
                    
                    if (otherInfo.getIndividual() != null && otherInfo.getIndividual().size() > 0) {
                        otherInsurance.append(lineBreaker("List of family members covered by the other policy and the type of coverage they have: "));
                        for(int j=0; j< otherInfo.getIndividual().size(); j++){
                            Individual depCoverage = otherInfo.getIndividual().get(j);;
                            if (depCoverage != null){
                                
                                StringBuffer dependentName = new StringBuffer().append(depCoverage.getName().getFirstName()).append(" ").append(depCoverage.getName().getMiddleName()).append(" ").append(depCoverage.getName().getLastName());
                                otherInsurance.append(lineBreaker("Dependent Name: " + dependentName));
                                // It appears there is only one type of coverage per dependent (not a list) since coverageType is a String
                                // coverage type just comes across as a single string with spaces, like - "Medical Hospital"
                                otherInsurance.append(lineBreaker("Type of Coverage: " + StringUtils.replace(depCoverage.getCoverageType(), " ", ", ")));                                
                            }
                        }
                    }
                }
            }
        }

        return otherInsurance.toString();
    }

    /**
     * @param questionnaire Questionnaire
     * @return String
     */
    private String createMedicareRequestLines(OtherInsuranceQuestionnaire questionnaire){
        StringBuffer mediCareInfo = new StringBuffer();
        String medicareMemberName;
        
        //seems to appear on the MIM INFORM example we received, so let us follow suit
        mediCareInfo.append(lineBreaker("Are you actively working? " + questionnaire.getMedicareInformation().getWorkStatus()));

        // employmentEffectiveDate has both "Start date" and "retirement/last day of active employment date
        if (questionnaire.getMedicareInformation().getEmploymentEffectiveDate().getFromDate() != null && questionnaire.getMedicareInformation().getWorkStatus().equals("Yes")) {
            mediCareInfo.append(lineBreaker("Start Date: " + convertDateToString(questionnaire.getMedicareInformation().getEmploymentEffectiveDate().getFromDate())));
        } else {
            mediCareInfo.append(lineBreaker("Start Date: "));
        }

        mediCareInfo.append(lineBreaker("Last Day of Active Employment: " + convertDateToString(questionnaire.getMedicareInformation().getEmploymentEffectiveDate().getToDate())));

        mediCareInfo.append(lineBreaker("MEDICARE INFORMATION: "));

        if (questionnaire.getMedicareInformation().getCoveredByMedicare().equals("Yes")){
            for (int i =0; i< questionnaire.getMedicareInformation().getMedicareMember().size(); i++){                
                MedicareMember medicareMember = questionnaire.getMedicareInformation().getMedicareMember().get(i);
                medicareMemberName = medicareMember.getName().getFirstName() + " " + medicareMember.getName().getMiddleName() + " " + medicareMember.getName().getLastName();

                mediCareInfo.append(lineBreaker("Name: " + medicareMemberName));
                mediCareInfo.append(lineBreaker("Date of Birth : " + convertDateToString(medicareMember.getDateOfBirth())));
                mediCareInfo.append(lineBreaker("Medicare Number: " + medicareMember.getMedicareNumber()));
                    
                if (medicareMember.getMedicareReason() != null){
                    mediCareInfo.append(lineBreaker("Reason for Medicare: " + medicareMember.getMedicareReason()));
                } else {
                    mediCareInfo.append(lineBreaker("Reason for Medicare: "));
               }

               mediCareInfo.append(lineBreaker("Part A Effective Date: " + convertDateToString(medicareMember.getPartAEffectiveDate())));
               mediCareInfo.append(lineBreaker("Part B Effective Date: " + convertDateToString(medicareMember.getPartBEffectiveDate())));
               if(medicareMember.getFirstDialysisDate() != null){                   
                   mediCareInfo.append(lineBreaker("Date of First Dialysis: " + convertDateToString(medicareMember.getFirstDialysisDate())));
               }
            }
        }
        
        return mediCareInfo.toString();
    }

    /**
     * @param date Date
     * @return String
     */
    private String convertDateToString(XMLGregorianCalendar date) {
        String resultDate = date + "";  //if there is an error return original data (as string).
        if (null == date) {
            return StringUtils.EMPTY;
        }
        
        try {
            Calendar calendar = date.toGregorianCalendar();
        
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            resultDate = sdf.format(calendar.getTime());
        } catch (Exception e) {
            logger.error("Failed to convert the date. Input values { inputDate = " + date + "} ", e);            
        }
            
        return resultDate;
    }

    /**
     * @param inputDate String date
     * @return String
     */
    private static String convertDateToString(String inputDate) {
        String resultDate = inputDate; //if there is an error return the original data
        String sourceFormat = "yyyy-MM-dd";
        String destFormat = "MM/dd/yyyy";
        if (StringUtils.isBlank(inputDate)) {
            if (logger.isDebugEnabled()) {
                logger.debug("inputDate is null, returning null");
            }
            return StringUtils.EMPTY;
        }
        if (StringUtils.isNotBlank(sourceFormat) && StringUtils.isNotBlank(destFormat)) {
            try {
                SimpleDateFormat formatter = new SimpleDateFormat(sourceFormat);
                formatter.setLenient(false);
                Date date = formatter.parse(inputDate.trim());
                formatter.applyPattern(destFormat);
                resultDate = formatter.format(date);
            } catch (ParseException pException) {
                logger.error("Failed to parse the date. Input values { inputDate = " + inputDate + ", sourceFormat = " + sourceFormat
                        + ", destFormat = " + destFormat + " } ", pException);
            } catch (IllegalArgumentException iaException) {
                logger.error("Failed convert from one format[" + sourceFormat + "] other format[" + destFormat + "]", iaException);
            }
        } else {
            logger.error("ConvertDate function : Input values { inputDate = " + inputDate + ", sourceFormat = " + sourceFormat
                    + ", destFormat = " + destFormat + " } ");
        }

        return resultDate;
    }
    
    /**
     * Line Breaker to make "carriage returns" for HOST/INFORm
     * 
     * @param s String
     * @return String
     */
    private String lineBreaker(String s) {
        StringBuffer newStr = new StringBuffer();
        double totalIterations;
        double stringLength = s.length();

        if (stringLength > 76) {
            totalIterations = Math.ceil(stringLength/76);
        
            for(int i=1; i<totalIterations+1; i++){
                String tempString = StringUtils.left(s, 76);
                newStr.append(padRight(tempString, 76)); 
            
                if (s.length() > 76) {
                    s = s.substring(76);
                }
            }
        } else {
            newStr.append(padRight(s, 76));
        }
        
        return newStr.toString();
    }    

    /**
     * @param s String
     * @param n Number
     * @return String
     */
    private String padRight(String s, int n) {
        return StringUtils.rightPad(s, n, " ");
    }
    
    /**
     * @return Inform Business Delegate
     * @throws Exception If there is an error
     */
    private InformBD getInformBD() throws Exception {
        InitialContext context = new InitialContext();
        return (InformBD) context.lookup(InformBD.class.getName());
    }
}