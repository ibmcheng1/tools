/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2017 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * MobileTextNotificationAuditBiz.java
 * 
 * Created on May 11, 2017, 4:30:21 PM by kx04
 */
package com.bcbssc.desktop.biz;

import javax.naming.InitialContext;
import javax.security.auth.Subject;

import org.apache.commons.lang.StringUtils;

import com.bcbssc.desktop.biz.inform.InformBD;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.domain.entity.Member;
import com.bcbssc.domain.entity.MobileTextNotificationSearchCriteria;
import com.bcbssc.domain.entity.codes.PatientSexRelationshipCode;
import com.bcbssc.domain.entity.codes.inform.CategoryCode;
import com.bcbssc.domain.entity.codes.inform.InternalExternalIndicatorCode;
import com.bcbssc.domain.entity.codes.inform.ResolutionCode;
import com.bcbssc.domain.entity.codes.inform.StatusCode;
import com.bcbssc.domain.entity.inform.InformRecord;
import com.bcbssc.domain.entity.inform.InformSecurity;
import com.bcbssc.domain.entity.inform.lines.InformException;

/**
 * Submits an audit INFOrm record for the Mobile Text Notification (relay) opt in/out activity
 */
public class MobileTextNotificationAuditBiz {

    public void submitMobileTextNotificationAudit(MobileTextNotificationSearchCriteria criteria, String mobileNumber, String consentType, Subject user) throws Exception {
        createAndSendInformRecord(criteria, createMobileTextNotificationRequestVerbiage(criteria, mobileNumber, consentType, user), user);
    }

    protected String createMobileTextNotificationRequestVerbiage(MobileTextNotificationSearchCriteria criteria, String mobileNumber, String consentType, Subject user){
        StringBuffer requestVerbiage = new StringBuffer();

        Member member = criteria.getMember();

        String memberFirstName = StringUtils.EMPTY;
        String memberLastName = StringUtils.EMPTY;
        if(member.getName() != null) {
            memberFirstName = StringUtils.defaultString(member.getName().getFirstName());
            memberLastName = StringUtils.defaultString(member.getName().getLastName());
        }

        requestVerbiage.append(lineBreaker("CSA CHANGED THE CONSENT TYPE ON BEHALF OF THE MEMBER"));
        requestVerbiage.append(lineBreaker("RACF ID: " + SubjectUtils.getRacfId(user) + ""));
        requestVerbiage.append(lineBreaker("MEMBER NAME: " + memberFirstName + " " +  memberLastName + ""));
        requestVerbiage.append(lineBreaker("MOBILE PHONE: " + mobileNumber + ""));
        requestVerbiage.append(lineBreaker("CONSENT TYPE: " + consentType + ""));
        requestVerbiage.append(lineBreaker("UPDATED: RELAY"));
        requestVerbiage.append(lineBreaker("CCID: " + criteria.getIdCardNumber() + ""));
        //AMMS patient #
        requestVerbiage.append(lineBreaker("      " + member.getMemberId() + ""));
        //CES MEM #
        requestVerbiage.append(lineBreaker("      " + member.getCesMemberNumber() + ""));
        //RPN
        requestVerbiage.append(lineBreaker("      " + SubjectUtils.getClient(user).getAliasRpn() + ""));

        requestVerbiage.append(lineBreaker("BUSINESS SECTOR CODE: " + criteria.getBusinessSectorCode() + ""));
        requestVerbiage.append(lineBreaker("AMMS GROUP NUMBER: " + criteria.getAmmsGroupNumber() + ""));

        return requestVerbiage.toString();
    }

    /**
     * Creates and send an inform record
     *
     * @param criteria
     * @param requestVerbiage
     * @param user
     * @throws Exception
     */
    private void createAndSendInformRecord(MobileTextNotificationSearchCriteria criteria, String requestVerbiage, Subject user) throws Exception {
        Member member = criteria.getMember();
        InformRecord informRecord = new InformRecord();

        informRecord.setKeyId(criteria.getSubscriberId());
        informRecord.setAltKeyId(criteria.getAmmsGroupNumber());
        informRecord.setRequestVerbiage(requestVerbiage);
        informRecord.setSourceCode("T");

        //MobileText inform is only a closed inform for now
        StatusCode statusCode = new StatusCode();
        statusCode.setType("CL");
        statusCode.setCode("1");
        informRecord.setStatusCode(statusCode);

        //getting user's inform security info
        InformSecurity informSecurity = SubjectUtils.getInformId(user).getInformSecurity();
        informRecord.setCompanyCode(informSecurity.getCompanyCode());
        informRecord.setDepartmentCode(informSecurity.getDepartmentCode());
        informRecord.setDivisionCode(informSecurity.getDivisionCode());
        informRecord.setEmployeeId(informSecurity.getEmployeeId());
        informRecord.setInquiryType(informSecurity.getInquiryType());

        //Assign to user's bucket
        informRecord.setOwnerCompanyCode(informSecurity.getCompanyCode());
        informRecord.setOwnerDepartmentCode(informSecurity.getDepartmentCode());
        informRecord.setOwnerDivisionCode(informSecurity.getDivisionCode());
        informRecord.setOwnerEmployeeId(informSecurity.getEmployeeId());

        //Comprehensive code (7)
        CategoryCode categoryCode = new CategoryCode();
        categoryCode.setCode("7");
        informRecord.setCategoryCode(categoryCode);

        //External
        InternalExternalIndicatorCode internalExternalInd = new InternalExternalIndicatorCode();
        internalExternalInd.setCode("X");
        informRecord.setInternalExternalInd(internalExternalInd);

        //Reason code is CSAIN for Mobile Text Notification changes
        informRecord.setRequestCode("CSAIN");

        //MQFROMAPP has different values based off of RPN
        if(StringUtils.equalsIgnoreCase(SubjectUtils.getClient(user).getAliasRpn(),"001"))
            informRecord.setMqFromApplication("WEB01");
        else
            if(StringUtils.equalsIgnoreCase(SubjectUtils.getClient(user).getAliasRpn(),"035"))
                informRecord.setMqFromApplication("WEBCHC");

        if(null != member) {
            informRecord.setPatientId(member.getMemberId());

            PatientSexRelationshipCode patientSexRelationshipCode = null;
            if(null != member.getRelationship()) {
                patientSexRelationshipCode = new PatientSexRelationshipCode();
                patientSexRelationshipCode.setCode(member.getRelationship().getCode());
            }

            informRecord.setPatientSexRelationshipCode(patientSexRelationshipCode);
        }

        
        String firstName;
        String lastName = StringUtils.EMPTY;
        if(null != member && null != member.getName()) {
            firstName = member.getName().getFirstName();
            lastName = member.getName().getLastName();
        } else {
            firstName = "CONTRACT";
        }

        informRecord.setPatientName(firstName + " " + lastName);

        ResolutionCode resolutionCode = new ResolutionCode();
        resolutionCode.setCode("COMP");
        informRecord.setResolutionCode(resolutionCode);

        this.getInformBD().sendInformMessage(informRecord, true, false, user);
    }

    /**
     * Line Breaker to make "carriage returns" for HOST/INFORm
     * 
     * @param s
     * @return
     */
    private String lineBreaker(String s) {
        StringBuffer newStr = new StringBuffer();
        double totalIterations = 1;
        double stringLength = s.length();

        if (stringLength > 76) {
            totalIterations = Math.ceil(stringLength/76);

            for(int i=1; i<totalIterations+1; i++){
                String tempString = StringUtils.left(s, 76);
                newStr.append(padRight(tempString, 76)); 

                if (s.length() > 76) {
                    s = s.substring(76);
                }
            }
        } else {
            newStr.append(padRight(s, 76));
        }
        
        return newStr.toString();
    }    

    /**
     * @param s
     * @param n
     * @return
     */
    private String padRight(String s, int n) {
        return StringUtils.rightPad(s, n, " ");
    }

    /**
     * @return
     * @throws Exception
     */
    private InformBD getInformBD() throws Exception {
        InitialContext context = new InitialContext();
        InformBD biz = (InformBD) context.lookup(InformBD.class.getName());
        return biz;
    }

}
