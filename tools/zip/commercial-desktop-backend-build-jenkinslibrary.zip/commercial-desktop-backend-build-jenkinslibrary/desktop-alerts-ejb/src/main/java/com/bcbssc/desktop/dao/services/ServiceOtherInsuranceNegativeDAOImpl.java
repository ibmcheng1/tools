/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2016 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 * 
 * OtherInsuranceNegativeDAOImpl.java
 */
package com.bcbssc.desktop.dao.services;

import com.bcbssc.desktop.dao.alerts.OtherInsuranceNegativeDAO;
import com.bcbssc.desktop.util.services.BaseServiceIntegrator;
import com.bcbssc.domain.entity.alerts.OtherInsuranceNegativeCriteria;
import com.bcbssc.services.otherinsnegativerespmaint.OtherInsNegativeRespMaintInput;
import com.bcbssc.services.otherinsnegativerespmaint.OtherInsNegativeRespMaintOutput;
import com.bcbssc.services.otherinsnegativerespmaint.OtherInsNegativeRespMaintService;
import com.bcbssc.services.otherinsnegativerespmaint.OtherInsNegativeRespMaintServiceService;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.jws.HandlerChain;
import javax.xml.ws.WebServiceRef;

@Stateless
@Local
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class ServiceOtherInsuranceNegativeDAOImpl extends BaseServiceIntegrator<OtherInsNegativeRespMaintService, OtherInsuranceNegativeCriteria, OtherInsNegativeRespMaintInput, OtherInsNegativeRespMaintOutput, String> implements OtherInsuranceNegativeDAO {

    @HandlerChain(file = "./handlerchain/soax-service-handler-chain.xml")
    @WebServiceRef(wsdlLocation = "META-INF/wsdl/OtherInsNegativeRespMaint.wsdl", value = OtherInsNegativeRespMaintServiceService.class)
    private OtherInsNegativeRespMaintService service;

    @Override
    public void updateNegativeOtherInsurance(OtherInsuranceNegativeCriteria criteria) {
        this.consumeService(criteria);
    }

    @Override
    public void setService(OtherInsNegativeRespMaintService service) {
        this.service = service;
    }

    @Override
    protected String getServiceName() {
        return OtherInsNegativeRespMaintService.class.getSimpleName();
    }

    @Override
    public OtherInsNegativeRespMaintService getService() {
        return service;
    }

    @Override
    public OtherInsNegativeRespMaintInput mapInput(OtherInsuranceNegativeCriteria searchCriteria) {
        OtherInsNegativeRespMaintInput otherInsNegativeRespMaintInput = new OtherInsNegativeRespMaintInput();

        otherInsNegativeRespMaintInput.setSubscriberId(searchCriteria.getSubscriberId());
        otherInsNegativeRespMaintInput.setResponseDate(searchCriteria.getResponseDate());
        otherInsNegativeRespMaintInput.setEffectiveDate(searchCriteria.getEffectiveDate());
        otherInsNegativeRespMaintInput.setProductCode(searchCriteria.getProductCode());
        otherInsNegativeRespMaintInput.setMemberNumber(searchCriteria.getMemberNumber());
        otherInsNegativeRespMaintInput.setInformationSourceCode(searchCriteria.getInformationSourceCode());
        otherInsNegativeRespMaintInput.setRacfId(searchCriteria.getRacfId());
        otherInsNegativeRespMaintInput.setCobChangeIndicator(searchCriteria.getCobChangeIndicator());
        otherInsNegativeRespMaintInput.setUpdateSource(searchCriteria.getUpdateSource());
        otherInsNegativeRespMaintInput.setEmployeeProcessorId(searchCriteria.getEmployeeProcessorId());
        otherInsNegativeRespMaintInput.setEmployeeProcessorId(searchCriteria.getEmployeeProcessorId());
        otherInsNegativeRespMaintInput.setRpn(searchCriteria.getRpn());

        return otherInsNegativeRespMaintInput;
    }

    @Override
    public OtherInsNegativeRespMaintOutput invokeService(OtherInsNegativeRespMaintInput input, OtherInsNegativeRespMaintService service) throws Exception {
        return service.updateOtherInsNegativeRespMaint(input);
    }

    @Override
    public String mapOutput(OtherInsNegativeRespMaintOutput output) {
        return output.getApplicationMessage();
    }
}
