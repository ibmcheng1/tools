
package com.bcbssc.services.membergroupproducts;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getGroupProductListResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getGroupProductListResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PatientsGroupProducts" type="{http://rules.model.commservices.bcbssc.com}PatientsGroupProducts" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getGroupProductListResponse", namespace = "http://membergroupproducts.services.bcbssc.com/", propOrder = {
    "patientsGroupProducts"
})
public class GetGroupProductListResponse {

    @XmlElement(name = "PatientsGroupProducts")
    protected PatientsGroupProducts patientsGroupProducts;

    /**
     * Gets the value of the patientsGroupProducts property.
     * 
     * @return
     *     possible object is
     *     {@link PatientsGroupProducts }
     *     
     */
    public PatientsGroupProducts getPatientsGroupProducts() {
        return patientsGroupProducts;
    }

    /**
     * Sets the value of the patientsGroupProducts property.
     * 
     * @param value
     *     allowed object is
     *     {@link PatientsGroupProducts }
     *     
     */
    public void setPatientsGroupProducts(PatientsGroupProducts value) {
        this.patientsGroupProducts = value;
    }

}
