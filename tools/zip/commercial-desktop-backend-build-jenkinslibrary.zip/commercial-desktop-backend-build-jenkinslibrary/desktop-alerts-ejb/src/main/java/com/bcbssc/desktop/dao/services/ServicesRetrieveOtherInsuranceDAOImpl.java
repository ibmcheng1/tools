package com.bcbssc.desktop.dao.services;

import com.bcbssc.desktop.dao.alerts.RetrieveOtherInsuranceDAO;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.services.BaseServiceIntegrator;
import com.bcbssc.desktop.util.services.interceptor.ServicesDataAccessExceptionInterceptor;
import com.bcbssc.domain.entity.enums.Subsystems;
import com.bcbssc.domain.entity.otherInsurance.OHIAndODIInformationOutputDTO;
import com.bcbssc.services.ohiandodiinformation.ArrayOfOHIAndODIInformationMedicareInsurance;
import com.bcbssc.services.ohiandodiinformation.ArrayOfOHIAndODIInformationOtherInsurance;
import com.bcbssc.services.ohiandodiinformation.OHIAndODIInformationInput;
import com.bcbssc.services.ohiandodiinformation.OHIAndODIInformationMedicareInsurance;
import com.bcbssc.services.ohiandodiinformation.OHIAndODIInformationOtherInsurance;
import com.bcbssc.services.ohiandodiinformation.OHIAndODIInformationOutput;
import com.bcbssc.services.ohiandodiinformation.OHIAndODIInformationService;
import com.bcbssc.services.ohiandodiinformation.OHIAndODIInformationServiceService;

import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.jws.HandlerChain;
import javax.xml.ws.WebServiceRef;
import java.util.ArrayList;

@Stateless
@Interceptors({ServicesDataAccessExceptionInterceptor.class})
public class ServicesRetrieveOtherInsuranceDAOImpl extends BaseServiceIntegrator<OHIAndODIInformationService, OHIAndODIInformationInput, OHIAndODIInformationInput, OHIAndODIInformationOutput, OHIAndODIInformationOutput> implements RetrieveOtherInsuranceDAO {
	private static final String MORE_DATA_INDICATOR_YES = "Y";

	@HandlerChain(file = "./handlerchain/soax-service-handler-chain.xml")
    @WebServiceRef(wsdlLocation = "META-INF/wsdl/OHIAndODIInformation.wsdl", value = OHIAndODIInformationServiceService.class)
	private OHIAndODIInformationService service;

	@Override
	public OHIAndODIInformationOutputDTO retrieveOtherInsurance(String subscriberId, String productCode) throws Exception {
		OHIAndODIInformationOutputDTO dto = new OHIAndODIInformationOutputDTO();
		String moreDataIndicator;


		OHIAndODIInformationInput input = new OHIAndODIInformationInput();
		input.setSubscriberId(subscriberId);
		input.setProductCode(productCode);
		input.setRpn(SubjectUtils.getRpnForSubsystem(SubjectUtils.getCurrentSubject(), Subsystems.CISI));
		input.setPlanCode(SubjectUtils.getClientStrict(SubjectUtils.getCurrentSubject()).getPlanCode());

		do {
			OHIAndODIInformationOutput output = this.consumeService(input);

			if (null == dto.getOHIAndODIInformationOutput()) {
				// First call so just set.
				dto.setOHIAndODIInformationOutput(output);
			} else {
				// Slurp up this output into the primary payload.
				OHIAndODIInformationOutput primary = (OHIAndODIInformationOutput) dto.getOHIAndODIInformationOutput();

				ArrayList<OHIAndODIInformationOtherInsurance> otherInsurance = new ArrayList<>(
				        primary.getOtherInsurance().getOHIAndODIInformationOtherInsurance().size() +
                                output.getOtherInsurance().getOHIAndODIInformationOtherInsurance().size());
				otherInsurance.addAll(primary.getOtherInsurance().getOHIAndODIInformationOtherInsurance());
				otherInsurance.addAll(output.getOtherInsurance().getOHIAndODIInformationOtherInsurance());
				primary.setOtherInsurance(new ArrayOfOHIAndODIInformationOtherInsurance());
				primary.getOtherInsurance().getOHIAndODIInformationOtherInsurance().addAll(otherInsurance);

				ArrayList<OHIAndODIInformationMedicareInsurance> medicareInsurance = new ArrayList<>(
				        primary.getOtherInsurance().getOHIAndODIInformationOtherInsurance().size() +
                                output.getMedicareInsurance().getOHIAndODIInformationMedicareInsurance().size());
				medicareInsurance.addAll(primary.getMedicareInsurance().getOHIAndODIInformationMedicareInsurance());
				medicareInsurance.addAll(output.getMedicareInsurance().getOHIAndODIInformationMedicareInsurance());
				primary.setMedicareInsurance(new ArrayOfOHIAndODIInformationMedicareInsurance());
				primary.getMedicareInsurance().getOHIAndODIInformationMedicareInsurance().addAll(medicareInsurance);

				primary.setLastMemberReturned(output.getLastMemberReturned());
				primary.setMoreDataIndicator(output.getMoreDataIndicator());
			}

			moreDataIndicator = output.getMoreDataIndicator();
			input.setRequestMoreDataIndicator(moreDataIndicator);
			input.setLastMemberProcessed(output.getLastMemberReturned());
		} while (moreDataIndicator.equals(MORE_DATA_INDICATOR_YES));

		return dto;
	}

    @Override
    public void setService(OHIAndODIInformationService service) {
        this.service = service;
    }

    @Override
    protected String getServiceName() {
        return OHIAndODIInformationService.class.getSimpleName();
    }

    @Override
    public OHIAndODIInformationService getService() {
        return service;
    }

    @Override
    public OHIAndODIInformationInput mapInput(OHIAndODIInformationInput input) {
        return input;
    }

    @Override
    public OHIAndODIInformationOutput invokeService(OHIAndODIInformationInput input, OHIAndODIInformationService service) throws Exception {
        return service.getOHIAndODIInformation(input);
    }

    @Override
    public OHIAndODIInformationOutput mapOutput(OHIAndODIInformationOutput output) {
        return output;
    }
}
