
package com.bcbssc.services.otherinsnegativerespmaint;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OtherInsNegativeRespMaintInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OtherInsNegativeRespMaintInput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="rpn" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="subscriberId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="responseDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="effectiveDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="productCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="memberNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="informationSourceCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="racfId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cobChangeIndicator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="updateSource" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="employeeProcessorId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="hostID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="hostPassword" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="toEscapeChar" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="MWIConfig" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="applTrace" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OtherInsNegativeRespMaintInput", propOrder = {
    "rpn",
    "subscriberId",
    "responseDate",
    "effectiveDate",
    "productCode",
    "memberNumber",
    "informationSourceCode",
    "racfId",
    "cobChangeIndicator",
    "updateSource",
    "employeeProcessorId",
    "hostID",
    "hostPassword",
    "toEscapeChar",
    "mwiConfig",
    "applTrace"
})
public class OtherInsNegativeRespMaintInput {

    @XmlElement(required = true, nillable = true)
    protected String rpn;
    @XmlElement(required = true, nillable = true)
    protected String subscriberId;
    @XmlElement(required = true, nillable = true)
    protected String responseDate;
    @XmlElement(required = true, nillable = true)
    protected String effectiveDate;
    @XmlElement(required = true, nillable = true)
    protected String productCode;
    @XmlElement(required = true, nillable = true)
    protected String memberNumber;
    @XmlElement(required = true, nillable = true)
    protected String informationSourceCode;
    @XmlElement(required = true, nillable = true)
    protected String racfId;
    @XmlElement(required = true, nillable = true)
    protected String cobChangeIndicator;
    @XmlElement(required = true, nillable = true)
    protected String updateSource;
    @XmlElement(required = true, nillable = true)
    protected String employeeProcessorId;
    @XmlElement(required = true, nillable = true)
    protected String hostID;
    @XmlElement(required = true, nillable = true)
    protected String hostPassword;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean toEscapeChar;
    @XmlElement(name = "MWIConfig", required = true, nillable = true)
    protected String mwiConfig;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean applTrace;

    /**
     * Gets the value of the rpn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRpn() {
        return rpn;
    }

    /**
     * Sets the value of the rpn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRpn(String value) {
        this.rpn = value;
    }

    /**
     * Gets the value of the subscriberId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriberId() {
        return subscriberId;
    }

    /**
     * Sets the value of the subscriberId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriberId(String value) {
        this.subscriberId = value;
    }

    /**
     * Gets the value of the responseDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseDate() {
        return responseDate;
    }

    /**
     * Sets the value of the responseDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseDate(String value) {
        this.responseDate = value;
    }

    /**
     * Gets the value of the effectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Sets the value of the effectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEffectiveDate(String value) {
        this.effectiveDate = value;
    }

    /**
     * Gets the value of the productCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductCode() {
        return productCode;
    }

    /**
     * Sets the value of the productCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductCode(String value) {
        this.productCode = value;
    }

    /**
     * Gets the value of the memberNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberNumber() {
        return memberNumber;
    }

    /**
     * Sets the value of the memberNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberNumber(String value) {
        this.memberNumber = value;
    }

    /**
     * Gets the value of the informationSourceCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInformationSourceCode() {
        return informationSourceCode;
    }

    /**
     * Sets the value of the informationSourceCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInformationSourceCode(String value) {
        this.informationSourceCode = value;
    }

    /**
     * Gets the value of the racfId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRacfId() {
        return racfId;
    }

    /**
     * Sets the value of the racfId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRacfId(String value) {
        this.racfId = value;
    }

    /**
     * Gets the value of the cobChangeIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCobChangeIndicator() {
        return cobChangeIndicator;
    }

    /**
     * Sets the value of the cobChangeIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCobChangeIndicator(String value) {
        this.cobChangeIndicator = value;
    }

    /**
     * Gets the value of the updateSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdateSource() {
        return updateSource;
    }

    /**
     * Sets the value of the updateSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdateSource(String value) {
        this.updateSource = value;
    }

    /**
     * Gets the value of the employeeProcessorId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmployeeProcessorId() {
        return employeeProcessorId;
    }

    /**
     * Sets the value of the employeeProcessorId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmployeeProcessorId(String value) {
        this.employeeProcessorId = value;
    }

    /**
     * Gets the value of the hostID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHostID() {
        return hostID;
    }

    /**
     * Sets the value of the hostID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHostID(String value) {
        this.hostID = value;
    }

    /**
     * Gets the value of the hostPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHostPassword() {
        return hostPassword;
    }

    /**
     * Sets the value of the hostPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHostPassword(String value) {
        this.hostPassword = value;
    }

    /**
     * Gets the value of the toEscapeChar property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isToEscapeChar() {
        return toEscapeChar;
    }

    /**
     * Sets the value of the toEscapeChar property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setToEscapeChar(Boolean value) {
        this.toEscapeChar = value;
    }

    /**
     * Gets the value of the mwiConfig property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMWIConfig() {
        return mwiConfig;
    }

    /**
     * Sets the value of the mwiConfig property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMWIConfig(String value) {
        this.mwiConfig = value;
    }

    /**
     * Gets the value of the applTrace property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isApplTrace() {
        return applTrace;
    }

    /**
     * Sets the value of the applTrace property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setApplTrace(Boolean value) {
        this.applTrace = value;
    }

}
