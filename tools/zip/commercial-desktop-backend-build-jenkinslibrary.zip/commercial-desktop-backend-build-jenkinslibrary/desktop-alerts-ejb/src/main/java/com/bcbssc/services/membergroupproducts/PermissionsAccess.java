
package com.bcbssc.services.membergroupproducts;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PermissionsAccess.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PermissionsAccess">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="FULL_PHI_ACCESS"/>
 *     &lt;enumeration value="NO_PHI_ACCESS"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "PermissionsAccess")
@XmlEnum
public enum PermissionsAccess {

    FULL_PHI_ACCESS,
    NO_PHI_ACCESS;

    public String value() {
        return name();
    }

    public static PermissionsAccess fromValue(String v) {
        return valueOf(v);
    }

}
