
package com.bcbssc.services.membergroupproducts;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getGroupProductsResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getGroupProductsResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GroupProductList" type="{http://rules.model.commservices.bcbssc.com}GroupProductList" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getGroupProductsResponse", namespace = "http://membergroupproducts.services.bcbssc.com/", propOrder = {
    "groupProductList"
})
public class GetGroupProductsResponse {

    @XmlElement(name = "GroupProductList")
    protected GroupProductList groupProductList;

    /**
     * Gets the value of the groupProductList property.
     * 
     * @return
     *     possible object is
     *     {@link GroupProductList }
     *     
     */
    public GroupProductList getGroupProductList() {
        return groupProductList;
    }

    /**
     * Sets the value of the groupProductList property.
     * 
     * @param value
     *     allowed object is
     *     {@link GroupProductList }
     *     
     */
    public void setGroupProductList(GroupProductList value) {
        this.groupProductList = value;
    }

}
