
package com.bcbssc.services.membergroupproducts;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for Patient complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Patient">
 *   &lt;complexContent>
 *     &lt;extension base="{http://common.model.commservices.bcbssc.com}Person">
 *       &lt;sequence>
 *         &lt;element name="subscriberId" type="{http://common.model.commservices.bcbssc.com}SubscriberId" minOccurs="0"/>
 *         &lt;element name="cesMemberNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="relationshipToSubscriber" type="{http://common.model.commservices.bcbssc.com}Code" minOccurs="0"/>
 *         &lt;element name="coverageInformation" type="{http://common.model.commservices.bcbssc.com}CoverageInformation" minOccurs="0"/>
 *         &lt;element name="outOfAreaPatient" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="dateOfDeath" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="student" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="handicapped" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="pregnant" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="weight" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="birthSequenceNumber" type="{http://common.model.commservices.bcbssc.com}Code" minOccurs="0"/>
 *         &lt;element name="maintenanceType" type="{http://common.model.commservices.bcbssc.com}Code" minOccurs="0"/>
 *         &lt;element name="maintenanceReason" type="{http://common.model.commservices.bcbssc.com}Code" minOccurs="0"/>
 *         &lt;element name="internalSequenceNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="customNetwork" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="employmentStatus" type="{http://common.model.commservices.bcbssc.com}Code" minOccurs="0"/>
 *         &lt;element name="underAge" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="permissionType" type="{http://common.model.commservices.bcbssc.com}PermissionType" minOccurs="0"/>
 *         &lt;element name="permissionsChangedSinceLastLogin" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="permissionsAccess" type="{http://common.model.commservices.bcbssc.com}PermissionsAccess" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Patient", propOrder = {
    "subscriberId",
    "cesMemberNumber",
    "relationshipToSubscriber",
    "coverageInformation",
    "outOfAreaPatient",
    "dateOfDeath",
    "student",
    "handicapped",
    "pregnant",
    "weight",
    "birthSequenceNumber",
    "maintenanceType",
    "maintenanceReason",
    "internalSequenceNumber",
    "customNetwork",
    "employmentStatus",
    "underAge",
    "permissionType",
    "permissionsChangedSinceLastLogin",
    "permissionsAccess"
})
public class Patient
    extends Person
{

    protected SubscriberId subscriberId;
    protected String cesMemberNumber;
    protected Code relationshipToSubscriber;
    protected CoverageInformation coverageInformation;
    protected boolean outOfAreaPatient;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dateOfDeath;
    protected boolean student;
    protected boolean handicapped;
    protected boolean pregnant;
    protected int weight;
    protected Code birthSequenceNumber;
    protected Code maintenanceType;
    protected Code maintenanceReason;
    protected String internalSequenceNumber;
    protected boolean customNetwork;
    protected Code employmentStatus;
    protected boolean underAge;
    @XmlSchemaType(name = "string")
    protected PermissionType permissionType;
    protected boolean permissionsChangedSinceLastLogin;
    @XmlSchemaType(name = "string")
    protected PermissionsAccess permissionsAccess;

    /**
     * Gets the value of the subscriberId property.
     * 
     * @return
     *     possible object is
     *     {@link SubscriberId }
     *     
     */
    public SubscriberId getSubscriberId() {
        return subscriberId;
    }

    /**
     * Sets the value of the subscriberId property.
     * 
     * @param value
     *     allowed object is
     *     {@link SubscriberId }
     *     
     */
    public void setSubscriberId(SubscriberId value) {
        this.subscriberId = value;
    }

    /**
     * Gets the value of the cesMemberNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCesMemberNumber() {
        return cesMemberNumber;
    }

    /**
     * Sets the value of the cesMemberNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCesMemberNumber(String value) {
        this.cesMemberNumber = value;
    }

    /**
     * Gets the value of the relationshipToSubscriber property.
     * 
     * @return
     *     possible object is
     *     {@link Code }
     *     
     */
    public Code getRelationshipToSubscriber() {
        return relationshipToSubscriber;
    }

    /**
     * Sets the value of the relationshipToSubscriber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Code }
     *     
     */
    public void setRelationshipToSubscriber(Code value) {
        this.relationshipToSubscriber = value;
    }

    /**
     * Gets the value of the coverageInformation property.
     * 
     * @return
     *     possible object is
     *     {@link CoverageInformation }
     *     
     */
    public CoverageInformation getCoverageInformation() {
        return coverageInformation;
    }

    /**
     * Sets the value of the coverageInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoverageInformation }
     *     
     */
    public void setCoverageInformation(CoverageInformation value) {
        this.coverageInformation = value;
    }

    /**
     * Gets the value of the outOfAreaPatient property.
     * 
     */
    public boolean isOutOfAreaPatient() {
        return outOfAreaPatient;
    }

    /**
     * Sets the value of the outOfAreaPatient property.
     * 
     */
    public void setOutOfAreaPatient(boolean value) {
        this.outOfAreaPatient = value;
    }

    /**
     * Gets the value of the dateOfDeath property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateOfDeath() {
        return dateOfDeath;
    }

    /**
     * Sets the value of the dateOfDeath property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateOfDeath(XMLGregorianCalendar value) {
        this.dateOfDeath = value;
    }

    /**
     * Gets the value of the student property.
     * 
     */
    public boolean isStudent() {
        return student;
    }

    /**
     * Sets the value of the student property.
     * 
     */
    public void setStudent(boolean value) {
        this.student = value;
    }

    /**
     * Gets the value of the handicapped property.
     * 
     */
    public boolean isHandicapped() {
        return handicapped;
    }

    /**
     * Sets the value of the handicapped property.
     * 
     */
    public void setHandicapped(boolean value) {
        this.handicapped = value;
    }

    /**
     * Gets the value of the pregnant property.
     * 
     */
    public boolean isPregnant() {
        return pregnant;
    }

    /**
     * Sets the value of the pregnant property.
     * 
     */
    public void setPregnant(boolean value) {
        this.pregnant = value;
    }

    /**
     * Gets the value of the weight property.
     * 
     */
    public int getWeight() {
        return weight;
    }

    /**
     * Sets the value of the weight property.
     * 
     */
    public void setWeight(int value) {
        this.weight = value;
    }

    /**
     * Gets the value of the birthSequenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Code }
     *     
     */
    public Code getBirthSequenceNumber() {
        return birthSequenceNumber;
    }

    /**
     * Sets the value of the birthSequenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Code }
     *     
     */
    public void setBirthSequenceNumber(Code value) {
        this.birthSequenceNumber = value;
    }

    /**
     * Gets the value of the maintenanceType property.
     * 
     * @return
     *     possible object is
     *     {@link Code }
     *     
     */
    public Code getMaintenanceType() {
        return maintenanceType;
    }

    /**
     * Sets the value of the maintenanceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link Code }
     *     
     */
    public void setMaintenanceType(Code value) {
        this.maintenanceType = value;
    }

    /**
     * Gets the value of the maintenanceReason property.
     * 
     * @return
     *     possible object is
     *     {@link Code }
     *     
     */
    public Code getMaintenanceReason() {
        return maintenanceReason;
    }

    /**
     * Sets the value of the maintenanceReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link Code }
     *     
     */
    public void setMaintenanceReason(Code value) {
        this.maintenanceReason = value;
    }

    /**
     * Gets the value of the internalSequenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInternalSequenceNumber() {
        return internalSequenceNumber;
    }

    /**
     * Sets the value of the internalSequenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInternalSequenceNumber(String value) {
        this.internalSequenceNumber = value;
    }

    /**
     * Gets the value of the customNetwork property.
     * 
     */
    public boolean isCustomNetwork() {
        return customNetwork;
    }

    /**
     * Sets the value of the customNetwork property.
     * 
     */
    public void setCustomNetwork(boolean value) {
        this.customNetwork = value;
    }

    /**
     * Gets the value of the employmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link Code }
     *     
     */
    public Code getEmploymentStatus() {
        return employmentStatus;
    }

    /**
     * Sets the value of the employmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link Code }
     *     
     */
    public void setEmploymentStatus(Code value) {
        this.employmentStatus = value;
    }

    /**
     * Gets the value of the underAge property.
     * 
     */
    public boolean isUnderAge() {
        return underAge;
    }

    /**
     * Sets the value of the underAge property.
     * 
     */
    public void setUnderAge(boolean value) {
        this.underAge = value;
    }

    /**
     * Gets the value of the permissionType property.
     * 
     * @return
     *     possible object is
     *     {@link PermissionType }
     *     
     */
    public PermissionType getPermissionType() {
        return permissionType;
    }

    /**
     * Sets the value of the permissionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link PermissionType }
     *     
     */
    public void setPermissionType(PermissionType value) {
        this.permissionType = value;
    }

    /**
     * Gets the value of the permissionsChangedSinceLastLogin property.
     * 
     */
    public boolean isPermissionsChangedSinceLastLogin() {
        return permissionsChangedSinceLastLogin;
    }

    /**
     * Sets the value of the permissionsChangedSinceLastLogin property.
     * 
     */
    public void setPermissionsChangedSinceLastLogin(boolean value) {
        this.permissionsChangedSinceLastLogin = value;
    }

    /**
     * Gets the value of the permissionsAccess property.
     * 
     * @return
     *     possible object is
     *     {@link PermissionsAccess }
     *     
     */
    public PermissionsAccess getPermissionsAccess() {
        return permissionsAccess;
    }

    /**
     * Sets the value of the permissionsAccess property.
     * 
     * @param value
     *     allowed object is
     *     {@link PermissionsAccess }
     *     
     */
    public void setPermissionsAccess(PermissionsAccess value) {
        this.permissionsAccess = value;
    }

}
