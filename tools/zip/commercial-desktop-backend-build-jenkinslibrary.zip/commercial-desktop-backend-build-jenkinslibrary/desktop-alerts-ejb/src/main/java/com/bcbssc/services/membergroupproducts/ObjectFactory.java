
package com.bcbssc.services.membergroupproducts;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.bcbssc.services.membergroupproducts package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetGroupProductsResponse_QNAME = new QName("http://membergroupproducts.services.bcbssc.com/", "getGroupProductsResponse");
    private final static QName _GetGroupProducts_QNAME = new QName("http://membergroupproducts.services.bcbssc.com/", "getGroupProducts");
    private final static QName _GetGroupProductList_QNAME = new QName("http://membergroupproducts.services.bcbssc.com/", "getGroupProductList");
    private final static QName _GetGroupProductListResponse_QNAME = new QName("http://membergroupproducts.services.bcbssc.com/", "getGroupProductListResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.bcbssc.services.membergroupproducts
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PatientGroupProducts }
     * 
     */
    public PatientGroupProducts createPatientGroupProducts() {
        return new PatientGroupProducts();
    }

    /**
     * Create an instance of {@link GroupProductList }
     * 
     */
    public GroupProductList createGroupProductList() {
        return new GroupProductList();
    }

    /**
     * Create an instance of {@link GroupProductsSearchCriteria }
     * 
     */
    public GroupProductsSearchCriteria createGroupProductsSearchCriteria() {
        return new GroupProductsSearchCriteria();
    }

    /**
     * Create an instance of {@link GroupProduct }
     * 
     */
    public GroupProduct createGroupProduct() {
        return new GroupProduct();
    }

    /**
     * Create an instance of {@link PatientList }
     * 
     */
    public PatientList createPatientList() {
        return new PatientList();
    }

    /**
     * Create an instance of {@link PatientsGroupProducts }
     * 
     */
    public PatientsGroupProducts createPatientsGroupProducts() {
        return new PatientsGroupProducts();
    }

    /**
     * Create an instance of {@link Group }
     * 
     */
    public Group createGroup() {
        return new Group();
    }

    /**
     * Create an instance of {@link Address }
     * 
     */
    public Address createAddress() {
        return new Address();
    }

    /**
     * Create an instance of {@link DrugCode }
     * 
     */
    public DrugCode createDrugCode() {
        return new DrugCode();
    }

    /**
     * Create an instance of {@link Patient }
     * 
     */
    public Patient createPatient() {
        return new Patient();
    }

    /**
     * Create an instance of {@link Code }
     * 
     */
    public Code createCode() {
        return new Code();
    }

    /**
     * Create an instance of {@link Name }
     * 
     */
    public Name createName() {
        return new Name();
    }

    /**
     * Create an instance of {@link SubscriberId }
     * 
     */
    public SubscriberId createSubscriberId() {
        return new SubscriberId();
    }

    /**
     * Create an instance of {@link CoverageInformation }
     * 
     */
    public CoverageInformation createCoverageInformation() {
        return new CoverageInformation();
    }

    /**
     * Create an instance of {@link KeyDescription }
     * 
     */
    public KeyDescription createKeyDescription() {
        return new KeyDescription();
    }

    /**
     * Create an instance of {@link Person }
     * 
     */
    public Person createPerson() {
        return new Person();
    }

    /**
     * Create an instance of {@link PeriodDate }
     * 
     */
    public PeriodDate createPeriodDate() {
        return new PeriodDate();
    }

    /**
     * Create an instance of {@link GetGroupProductList }
     * 
     */
    public GetGroupProductList createGetGroupProductList() {
        return new GetGroupProductList();
    }

    /**
     * Create an instance of {@link GetGroupProductListResponse }
     * 
     */
    public GetGroupProductListResponse createGetGroupProductListResponse() {
        return new GetGroupProductListResponse();
    }

    /**
     * Create an instance of {@link GetGroupProducts }
     * 
     */
    public GetGroupProducts createGetGroupProducts() {
        return new GetGroupProducts();
    }

    /**
     * Create an instance of {@link GetGroupProductsResponse }
     * 
     */
    public GetGroupProductsResponse createGetGroupProductsResponse() {
        return new GetGroupProductsResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetGroupProductsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://membergroupproducts.services.bcbssc.com/", name = "getGroupProductsResponse")
    public JAXBElement<GetGroupProductsResponse> createGetGroupProductsResponse(GetGroupProductsResponse value) {
        return new JAXBElement<GetGroupProductsResponse>(_GetGroupProductsResponse_QNAME, GetGroupProductsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetGroupProducts }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://membergroupproducts.services.bcbssc.com/", name = "getGroupProducts")
    public JAXBElement<GetGroupProducts> createGetGroupProducts(GetGroupProducts value) {
        return new JAXBElement<GetGroupProducts>(_GetGroupProducts_QNAME, GetGroupProducts.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetGroupProductList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://membergroupproducts.services.bcbssc.com/", name = "getGroupProductList")
    public JAXBElement<GetGroupProductList> createGetGroupProductList(GetGroupProductList value) {
        return new JAXBElement<GetGroupProductList>(_GetGroupProductList_QNAME, GetGroupProductList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetGroupProductListResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://membergroupproducts.services.bcbssc.com/", name = "getGroupProductListResponse")
    public JAXBElement<GetGroupProductListResponse> createGetGroupProductListResponse(GetGroupProductListResponse value) {
        return new JAXBElement<GetGroupProductListResponse>(_GetGroupProductListResponse_QNAME, GetGroupProductListResponse.class, null, value);
    }

}
