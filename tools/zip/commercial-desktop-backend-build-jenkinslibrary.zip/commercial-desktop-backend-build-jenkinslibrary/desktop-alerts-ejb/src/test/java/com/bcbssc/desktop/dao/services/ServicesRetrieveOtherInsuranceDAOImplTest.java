/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.dao.services;

import com.bcbssc.desktop.dao.alerts.RetrieveOtherInsuranceDAO;
import com.bcbssc.desktop.util.auth.SubjectUtils;
import com.bcbssc.desktop.util.json.JSONUtil;
import com.bcbssc.domain.entity.Subsystem;
import com.bcbssc.domain.entity.enums.Subsystems;
import com.bcbssc.domain.entity.otherInsurance.OHIAndODIInformationOutputDTO;
import com.bcbssc.services.ohiandodiinformation.OHIAndODIInformationInput;
import com.bcbssc.services.ohiandodiinformation.OHIAndODIInformationOutput;
import com.bcbssc.services.ohiandodiinformation.OHIAndODIInformationService;
import junit.framework.TestCase;

import javax.security.auth.Subject;
import java.util.HashMap;
import java.util.Map;

public class ServicesRetrieveOtherInsuranceDAOImplTest extends TestCase {
    public void test_paging() throws Throwable {
		final OHIAndODIInformationServiceStubber service = new OHIAndODIInformationServiceStubber();
		service.setupPagingOutput();
		final RetrieveOtherInsuranceDAO dao = new ServicesRetrieveOtherInsuranceDAOImpl() {
		    @Override
            public OHIAndODIInformationOutput invokeService(OHIAndODIInformationInput input, OHIAndODIInformationService fakeService) {
		        return service.getOHIAndODIInformation(input);
            }
        };

		Subject subject = SubjectUtils.createEmptySubject();
		Map<String, Subsystem> rpnSubsystems = new HashMap<>();
		Subsystem cisi = new Subsystem();
		cisi.setRpn("666");
		rpnSubsystems.put(Subsystems.CISI.getName(), cisi);
		SubjectUtils.setRPNSubsystems(subject, rpnSubsystems);

		OHIAndODIInformationOutputDTO dto = SubjectUtils.runAsSubject(() -> dao.retrieveOtherInsurance("IN_SUBSCRIBER_ID", "IN_PRODUCT_CODE"), subject);

		OHIAndODIInformationOutput results = (OHIAndODIInformationOutput) dto.getOHIAndODIInformationOutput();
		assertEquals(4, results.getOtherInsurance().getOHIAndODIInformationOtherInsurance().size());
		assertEquals(4, results.getMedicareInsurance().getOHIAndODIInformationMedicareInsurance().size());

		assertEquals("IN_SUBSCRIBER_ID", service.input.get(0).getSubscriberId());
		assertEquals("666", service.input.get(0).getRpn());
		assertEquals("IN_PRODUCT_CODE", service.input.get(0).getProductCode());
        assertNull(service.input.get(0).getLastMemberProcessed());
        assertNull(service.input.get(0).getRequestMoreDataIndicator());

		assertEquals("IN_SUBSCRIBER_ID", service.input.get(1).getSubscriberId());
		assertEquals("666", service.input.get(1).getRpn());
		assertEquals("IN_PRODUCT_CODE", service.input.get(1).getProductCode());
		assertEquals("XXX", service.input.get(1).getLastMemberProcessed());
		assertEquals("Y", service.input.get(1).getRequestMoreDataIndicator());

		System.out.print(JSONUtil.toJSON(dto.getOHIAndODIInformationOutput()));
	}
}
