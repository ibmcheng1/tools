/*
 * THIS MATERIAL IS THE CONFIDENTIAL, PROPRIETARY AND TRADE SECRET PRODUCT OF
 * BLUECROSS BLUESHIELD OF SOUTH CAROLINA AND ITS SUBSIDIARIES.  ANY
 * UNAUTHORIZED USE, REPRODUCTION OR TRANSFER OF THESE MATERIALS IS STRICTLY
 * PROHIBITED.
 * COPYRIGHT 2018 BLUECROSS BLUESHIELD OF SOUTH CAROLINA   ALL RIGHTS
 * RESERVED.
 */

package com.bcbssc.desktop.dao.services;

import com.bcbssc.services.ohiandodiinformation.ArrayOfOHIAndODIInformationMedicareInsurance;
import com.bcbssc.services.ohiandodiinformation.ArrayOfOHIAndODIInformationOtherInsurance;
import com.bcbssc.services.ohiandodiinformation.OHIAndODIInformationInput;
import com.bcbssc.services.ohiandodiinformation.OHIAndODIInformationMedicareInsurance;
import com.bcbssc.services.ohiandodiinformation.OHIAndODIInformationOtherInsurance;
import com.bcbssc.services.ohiandodiinformation.OHIAndODIInformationOutput;
import com.bcbssc.services.ohiandodiinformation.OHIAndODIInformationService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class OHIAndODIInformationServiceStubber implements OHIAndODIInformationService {
	/** A mapping of the call count to the respective output. */
	private Map<Integer, OHIAndODIInformationOutput> output = new HashMap<>();
	/** A mapping of the call count to the saved respective input. */
	Map<Integer, OHIAndODIInformationInput> input = new HashMap<>();
	private int callCount = 0;

	@Override
	public OHIAndODIInformationOutput getOHIAndODIInformation(OHIAndODIInformationInput input) {
		this.input.put(this.callCount, this.deepCopyInput(input));
		OHIAndODIInformationOutput result = this.output.get(this.callCount);
		this.callCount++;
		return result;
	}

	private OHIAndODIInformationInput deepCopyInput(OHIAndODIInformationInput input) {
		OHIAndODIInformationInput copy = new OHIAndODIInformationInput();
		copy.setRpn(input.getRpn());
		copy.setRequestDate(input.getRequestDate());
		copy.setSubscriberId(input.getSubscriberId());
		copy.setProductCode(input.getProductCode());
		copy.setPlanCode(input.getPlanCode());
		copy.setRacfId(input.getRacfId());
		copy.setRequestMoreDataIndicator(input.getRequestMoreDataIndicator());
		copy.setLastMemberProcessed(input.getLastMemberProcessed());
		copy.setHostID(input.getHostID());
		copy.setHostPassword(input.getHostPassword());
		copy.setToEscapeChar(input.isToEscapeChar());
		copy.setMWIConfig(input.getMWIConfig());
		copy.setApplTrace(input.isApplTrace());
		return copy;
	}

	/**
	 * Create and populate the output field for a two call paging test.
	 */
	void setupPagingOutput() {
		this.output.put(0, new OHIAndODIInformationOutput());
		this.output.get(0).setApplicationMessage("IGNORED");
		this.output.get(0).setServiceMessage("IGNORED");
		this.output.get(0).setServiceMessageCode("IGNORED");
		this.output.get(0).setSystemMessage("IGNORED");
		this.output.get(0).setLastMemberReturned("XXX");
		this.output.get(0).setMoreDataIndicator("Y");
		this.output.get(0).setOtherInsuranceIndicator("");
		this.output.get(0).setMedicareInsuranceIndicator("");
		this.output.get(0).setGroupBlockStatusIndicator("");
		this.output.get(0).setLastQuestionnaireDate("0-LastQuestionnaireDate-MMddyyyy");
		this.output.get(0).setQuestionnaireExpirationDate("0-QuestionnaireExpirationDate-MMddyyyy");
		this.output.get(0).setQuestionnaireRequiredIndicator("");
		this.output.get(0).setTotalNumberOthInsuranceRecords("4");
		this.output.get(0).setTotalNumberMedicareRecords("4");
		this.output.get(0).setOthInsuranceInfoLocation("");
		ArrayList<OHIAndODIInformationOtherInsurance> otherInsurance = new ArrayList<>();
		otherInsurance.add(new OHIAndODIInformationOtherInsurance());
		otherInsurance.get(0).setOthInsCoverageLevel("0-OthInsCoverageLevel-C");
		otherInsurance.get(0).setOthInsMemberNumberAttached("0-OthInsMemberNumberAttached");
		otherInsurance.get(0).setOthInsSubscriberNumberAttached("0-OthInsSubscriberNumberAttached");
		otherInsurance.get(0).setOthInsEmployerName("0-OthInsEmployerName");
		otherInsurance.get(0).setOthInsSubscriberId("0-OthInsSubscriberId");
		otherInsurance.get(0).setOthInsMemberNumber("0-OthInsMemberNumber");
		otherInsurance.get(0).setOthInsProductCode("0-OthInsProductCode");
		otherInsurance.get(0).setOthInsPolicyNumber("0-OthInsPolicyNumber");
		otherInsurance.get(0).setOthInsBeginDate("0-OthInsBeginDate-MMddyyyy");
		otherInsurance.get(0).setOthInsTerminationDate("0-OthInsTerminationDate-MMddyyyy");
		otherInsurance.get(0).setOthInsInfoLastUpdateDate("0-OthInsInfoLastUpdateDate-MMddyyyy");
		otherInsurance.get(0).setOthInsEmployeeFirstName("0-OthInsEmployeeFirstName");
		otherInsurance.get(0).setOthInsEmployeeLastName("0-OthInsEmployeeLastName");
		otherInsurance.get(0).setOthInsMemberRelationship("0-OthInsMemberRelationship");
		otherInsurance.get(0).setOthInsMemberRelationshipDesc("0-OthInsMemberRelationshipDesc");
		otherInsurance.get(0).setOthInsPlanCoverageType("0-OthInsPlanCoverageType");
		otherInsurance.get(0).setOthInsPlanCoverageTypeDesc("0-OthInsPlanCoverageTypeDesc");
		otherInsurance.get(0).setOthInsPrimarySecondaryInd("0-OthInsPrimarySecondaryInd-P");
		otherInsurance.get(0).setOthInsPlanName("0-OthInsPlanName");
		otherInsurance.add(new OHIAndODIInformationOtherInsurance());
		otherInsurance.get(1).setOthInsCoverageLevel("1-OthInsCoverageLevel-M");
		otherInsurance.get(1).setOthInsMemberNumberAttached("1-OthInsMemberNumberAttached");
		otherInsurance.get(1).setOthInsSubscriberNumberAttached("1-OthInsSubscriberNumberAttached");
		otherInsurance.get(1).setOthInsEmployerName("1-OthInsEmployerName");
		otherInsurance.get(1).setOthInsSubscriberId("1-OthInsSubscriberId");
		otherInsurance.get(1).setOthInsMemberNumber("1-OthInsMemberNumber");
		otherInsurance.get(1).setOthInsProductCode("1-OthInsProductCode");
		otherInsurance.get(1).setOthInsPolicyNumber("1-OthInsPolicyNumber");
		otherInsurance.get(1).setOthInsBeginDate("1-OthInsBeginDate-MMddyyyy");
		otherInsurance.get(1).setOthInsTerminationDate("1-OthInsTerminationDate-MMddyyyy");
		otherInsurance.get(1).setOthInsInfoLastUpdateDate("1-OthInsInfoLastUpdateDate-MMddyyyy");
		otherInsurance.get(1).setOthInsEmployeeFirstName("1-OthInsEmployeeFirstName");
		otherInsurance.get(1).setOthInsEmployeeLastName("1-OthInsEmployeeLastName");
		otherInsurance.get(1).setOthInsMemberRelationship("1-OthInsMemberRelationship");
		otherInsurance.get(1).setOthInsMemberRelationshipDesc("1-OthInsMemberRelationshipDesc");
		otherInsurance.get(1).setOthInsPlanCoverageType("1-OthInsPlanCoverageType");
		otherInsurance.get(1).setOthInsPlanCoverageTypeDesc("1-OthInsPlanCoverageTypeDesc");
		otherInsurance.get(1).setOthInsPrimarySecondaryInd("1-OthInsPrimarySecondaryInd-S");
		otherInsurance.get(1).setOthInsPlanName("1-OthInsPlanName");
        this.output.get(0).setOtherInsurance(new ArrayOfOHIAndODIInformationOtherInsurance());
        this.output.get(0).getOtherInsurance().getOHIAndODIInformationOtherInsurance().addAll(otherInsurance);
		ArrayList<OHIAndODIInformationMedicareInsurance> medicareInsurance = new ArrayList<>();
		medicareInsurance.add(new OHIAndODIInformationMedicareInsurance());
		medicareInsurance.get(0).setMedicarePrimarySecondaryInd("0-MedicarePrimarySecondaryInd-P");
		medicareInsurance.get(0).setMedicareId("0-MedicareId");
		medicareInsurance.get(0).setMedicareMemberNumber("0-MedicareMemberNumber");
		medicareInsurance.get(0).setMedicareSubscriberNumAttached("0-MedicareSubscriberNumAttached");
		medicareInsurance.get(0).setMedicareMemberNumberAttached("0-MedicareMemberNumberAttached");
		medicareInsurance.get(0).setMedicareMemberFirstName("0-MedicareMemberFirstName");
		medicareInsurance.get(0).setMedicareMemberLastName("0-MedicareMemberLastName");
		medicareInsurance.get(0).setMedicareMemberRelationship("0-MedicareMemberRelationship");
		medicareInsurance.get(0).setMedicareMemberRelationshipDesc("0-MedicareMemberRelationshipDesc");
		medicareInsurance.get(0).setMedicarePartABeginDate("0-MedicarePartABeginDate-MMddyyyy");
		medicareInsurance.get(0).setMedicarePartATerminationDate("0-MedicarePartATerminationDate-MMddyyyy");
		medicareInsurance.get(0).setMedicarePartALastUpdateDate("0-MedicarePartALastUpdateDate-MMddyyyy");
		medicareInsurance.get(0).setMedicarePartBBeginDate("0-MedicarePartBBeginDate-MMddyyyy");
		medicareInsurance.get(0).setMedicarePartBTerminationDate("0-MedicarePartBTerminationDate-MMddyyyy");
		medicareInsurance.get(0).setMedicarePartBLastUpdateDate("0-MedicarePartBLastUpdateDate-MMddyyyy");
		medicareInsurance.add(new OHIAndODIInformationMedicareInsurance());
		medicareInsurance.get(1).setMedicarePrimarySecondaryInd("1-MedicarePrimarySecondaryInd-S");
		medicareInsurance.get(1).setMedicareId("1-MedicareId");
		medicareInsurance.get(1).setMedicareMemberNumber("1-MedicareMemberNumber");
		medicareInsurance.get(1).setMedicareSubscriberNumAttached("1-MedicareSubscriberNumAttached");
		medicareInsurance.get(1).setMedicareMemberNumberAttached("1-MedicareMemberNumberAttached");
		medicareInsurance.get(1).setMedicareMemberFirstName("1-MedicareMemberFirstName");
		medicareInsurance.get(1).setMedicareMemberLastName("1-MedicareMemberLastName");
		medicareInsurance.get(1).setMedicareMemberRelationship("1-MedicareMemberRelationship");
		medicareInsurance.get(1).setMedicareMemberRelationshipDesc("1-MedicareMemberRelationshipDesc");
		medicareInsurance.get(1).setMedicarePartABeginDate("1-MedicarePartABeginDate-MMddyyyy");
		medicareInsurance.get(1).setMedicarePartATerminationDate("1-MedicarePartATerminationDate-MMddyyyy");
		medicareInsurance.get(1).setMedicarePartALastUpdateDate("1-MedicarePartALastUpdateDate-MMddyyyy");
		medicareInsurance.get(1).setMedicarePartBBeginDate("1-MedicarePartBBeginDate-MMddyyyy");
		medicareInsurance.get(1).setMedicarePartBTerminationDate("1-MedicarePartBTerminationDate-MMddyyyy");
		medicareInsurance.get(1).setMedicarePartBLastUpdateDate("1-MedicarePartBLastUpdateDate-MMddyyyy");
        this.output.get(0).setMedicareInsurance(new ArrayOfOHIAndODIInformationMedicareInsurance());
        this.output.get(0).getMedicareInsurance().getOHIAndODIInformationMedicareInsurance().addAll(medicareInsurance);
		this.output.get(0).setEbizReplyAbendcode("IGNORED");
		this.output.get(0).setEbizReplyStatus(0);
		this.output.get(0).setEbizReplyStatusMessage("IGNORED");

		this.output.put(1, new OHIAndODIInformationOutput());
		this.output.get(1).setApplicationMessage("IGNORED");
		this.output.get(1).setServiceMessage("IGNORED");
		this.output.get(1).setServiceMessageCode("IGNORED");
		this.output.get(1).setSystemMessage("IGNORED");
		this.output.get(1).setLastMemberReturned("");
		this.output.get(1).setMoreDataIndicator("N");
		this.output.get(1).setOtherInsuranceIndicator("");
		this.output.get(1).setMedicareInsuranceIndicator("");
		this.output.get(1).setGroupBlockStatusIndicator("");
		this.output.get(1).setLastQuestionnaireDate("");
		this.output.get(1).setQuestionnaireExpirationDate("");
		this.output.get(1).setQuestionnaireRequiredIndicator("");
		this.output.get(1).setTotalNumberOthInsuranceRecords("4");
		this.output.get(1).setTotalNumberMedicareRecords("4");
		this.output.get(1).setOthInsuranceInfoLocation("");
		otherInsurance = new ArrayList<>();
		otherInsurance.add(new OHIAndODIInformationOtherInsurance());
		otherInsurance.get(0).setOthInsCoverageLevel("2-OthInsCoverageLevel-M");
		otherInsurance.get(0).setOthInsMemberNumberAttached("2-OthInsMemberNumberAttached");
		otherInsurance.get(0).setOthInsSubscriberNumberAttached("2-OthInsSubscriberNumberAttached");
		otherInsurance.get(0).setOthInsEmployerName("2-OthInsEmployerName");
		otherInsurance.get(0).setOthInsSubscriberId("2-OthInsSubscriberId");
		otherInsurance.get(0).setOthInsMemberNumber("2-OthInsMemberNumber");
		otherInsurance.get(0).setOthInsProductCode("2-OthInsProductCode");
		otherInsurance.get(0).setOthInsPolicyNumber("2-OthInsPolicyNumber");
		otherInsurance.get(0).setOthInsBeginDate("2-OthInsBeginDate-MMddyyyy");
		otherInsurance.get(0).setOthInsTerminationDate("2-OthInsTerminationDate-MMddyyyy");
		otherInsurance.get(0).setOthInsInfoLastUpdateDate("2-OthInsInfoLastUpdateDate-MMddyyyy");
		otherInsurance.get(0).setOthInsEmployeeFirstName("2-OthInsEmployeeFirstName");
		otherInsurance.get(0).setOthInsEmployeeLastName("2-OthInsEmployeeLastName");
		otherInsurance.get(0).setOthInsMemberRelationship("2-OthInsMemberRelationship");
		otherInsurance.get(0).setOthInsMemberRelationshipDesc("2-OthInsMemberRelationshipDesc");
		otherInsurance.get(0).setOthInsPlanCoverageType("2-OthInsPlanCoverageType");
		otherInsurance.get(0).setOthInsPlanCoverageTypeDesc("2-OthInsPlanCoverageTypeDesc");
		otherInsurance.get(0).setOthInsPrimarySecondaryInd("2-OthInsPrimarySecondaryInd-S");
		otherInsurance.get(0).setOthInsPlanName("2-OthInsPlanName");
		otherInsurance.add(new OHIAndODIInformationOtherInsurance());
		otherInsurance.get(1).setOthInsCoverageLevel("3-OthInsCoverageLevel-M");
		otherInsurance.get(1).setOthInsMemberNumberAttached("3-OthInsMemberNumberAttached");
		otherInsurance.get(1).setOthInsSubscriberNumberAttached("3-OthInsSubscriberNumberAttached");
		otherInsurance.get(1).setOthInsEmployerName("3-OthInsEmployerName");
		otherInsurance.get(1).setOthInsSubscriberId("3-OthInsSubscriberId");
		otherInsurance.get(1).setOthInsMemberNumber("3-OthInsMemberNumber");
		otherInsurance.get(1).setOthInsProductCode("3-OthInsProductCode");
		otherInsurance.get(1).setOthInsPolicyNumber("3-OthInsPolicyNumber");
		otherInsurance.get(1).setOthInsBeginDate("3-OthInsBeginDate-MMddyyyy");
		otherInsurance.get(1).setOthInsTerminationDate("3-OthInsTerminationDate-MMddyyyy");
		otherInsurance.get(1).setOthInsInfoLastUpdateDate("3-OthInsInfoLastUpdateDate-MMddyyyy");
		otherInsurance.get(1).setOthInsEmployeeFirstName("3-OthInsEmployeeFirstName");
		otherInsurance.get(1).setOthInsEmployeeLastName("3-OthInsEmployeeLastName");
		otherInsurance.get(1).setOthInsMemberRelationship("3-OthInsMemberRelationship");
		otherInsurance.get(1).setOthInsMemberRelationshipDesc("3-OthInsMemberRelationshipDesc");
		otherInsurance.get(1).setOthInsPlanCoverageType("3-OthInsPlanCoverageType");
		otherInsurance.get(1).setOthInsPlanCoverageTypeDesc("3-OthInsPlanCoverageTypeDesc");
		otherInsurance.get(1).setOthInsPrimarySecondaryInd("3-OthInsPrimarySecondaryInd-S");
		otherInsurance.get(1).setOthInsPlanName("3-OthInsPlanName");
        this.output.get(1).setOtherInsurance(new ArrayOfOHIAndODIInformationOtherInsurance());
        this.output.get(1).getOtherInsurance().getOHIAndODIInformationOtherInsurance().addAll(otherInsurance);
		medicareInsurance = new ArrayList<>();
		medicareInsurance.add(new OHIAndODIInformationMedicareInsurance());
		medicareInsurance.get(0).setMedicarePrimarySecondaryInd("2-MedicarePrimarySecondaryInd-S");
		medicareInsurance.get(0).setMedicareId("2-MedicareId");
		medicareInsurance.get(0).setMedicareMemberNumber("2-MedicareMemberNumber");
		medicareInsurance.get(0).setMedicareSubscriberNumAttached("2-MedicareSubscriberNumAttached");
		medicareInsurance.get(0).setMedicareMemberNumberAttached("2-MedicareMemberNumberAttached");
		medicareInsurance.get(0).setMedicareMemberFirstName("2-MedicareMemberFirstName");
		medicareInsurance.get(0).setMedicareMemberLastName("2-MedicareMemberLastName");
		medicareInsurance.get(0).setMedicareMemberRelationship("2-MedicareMemberRelationship");
		medicareInsurance.get(0).setMedicareMemberRelationshipDesc("2-MedicareMemberRelationshipDesc");
		medicareInsurance.get(0).setMedicarePartABeginDate("2-MedicarePartABeginDate-MMddyyyy");
		medicareInsurance.get(0).setMedicarePartATerminationDate("2-MedicarePartATerminationDate-MMddyyyy");
		medicareInsurance.get(0).setMedicarePartALastUpdateDate("2-MedicarePartALastUpdateDate-MMddyyyy");
		medicareInsurance.get(0).setMedicarePartBBeginDate("2-MedicarePartBBeginDate-MMddyyyy");
		medicareInsurance.get(0).setMedicarePartBTerminationDate("2-MedicarePartBTerminationDate-MMddyyyy");
		medicareInsurance.get(0).setMedicarePartBLastUpdateDate("2-MedicarePartBLastUpdateDate-MMddyyyy");
		medicareInsurance.add(new OHIAndODIInformationMedicareInsurance());
		medicareInsurance.get(1).setMedicarePrimarySecondaryInd("3-MedicarePrimarySecondaryInd-S");
		medicareInsurance.get(1).setMedicareId("3-MedicareId");
		medicareInsurance.get(1).setMedicareMemberNumber("3-MedicareMemberNumber");
		medicareInsurance.get(1).setMedicareSubscriberNumAttached("3-MedicareSubscriberNumAttached");
		medicareInsurance.get(1).setMedicareMemberNumberAttached("3-MedicareMemberNumberAttached");
		medicareInsurance.get(1).setMedicareMemberFirstName("3-MedicareMemberFirstName");
		medicareInsurance.get(1).setMedicareMemberLastName("3-MedicareMemberLastName");
		medicareInsurance.get(1).setMedicareMemberRelationship("3-MedicareMemberRelationship");
		medicareInsurance.get(1).setMedicareMemberRelationshipDesc("3-MedicareMemberRelationshipDesc");
		medicareInsurance.get(1).setMedicarePartABeginDate("3-MedicarePartABeginDate-MMddyyyy");
		medicareInsurance.get(1).setMedicarePartATerminationDate("3-MedicarePartATerminationDate-MMddyyyy");
		medicareInsurance.get(1).setMedicarePartALastUpdateDate("3-MedicarePartALastUpdateDate-MMddyyyy");
		medicareInsurance.get(1).setMedicarePartBBeginDate("3-MedicarePartBBeginDate-MMddyyyy");
		medicareInsurance.get(1).setMedicarePartBTerminationDate("3-MedicarePartBTerminationDate-MMddyyyy");
		medicareInsurance.get(1).setMedicarePartBLastUpdateDate("3-MedicarePartBLastUpdateDate-MMddyyyy");
        this.output.get(1).setMedicareInsurance(new ArrayOfOHIAndODIInformationMedicareInsurance());
        this.output.get(1).getMedicareInsurance().getOHIAndODIInformationMedicareInsurance().addAll(medicareInsurance);
		this.output.get(1).setEbizReplyAbendcode("IGNORED");
		this.output.get(1).setEbizReplyStatus(0);
		this.output.get(1).setEbizReplyStatusMessage("IGNORED");
	}
}