# HOW TO JENKINS-SHARED-LIBRARY

## Step 1:  File Structure
```  (root)
  +- src                     # Groovy source files
  |   +- org
  |       +- foo
  |           +- Bar.groovy  # for org.foo.Bar class
  +- vars
  |   +- foo.groovy          # for global 'foo' variable
  |   +- foo.txt             # help for 'foo' variable
  +- resources               # resource files (external libraries only)
  |   +- org
  |       +- foo
  |           +- bar.json    # static helper data for org.foo.Bar
```

(shamelessly stolen from https://jenkins.io/doc/book/pipeline/shared-libraries/)

## Step 2: Make your library project in Git
Self-explanatory - Jenkins wants to pull shared libraries from a SCM repo.  So put 'er in Git!

## Step 3: Telling Jenkins to use the library
This has to be done by a Jenkins admin.  On the 'Manage Jenkins' -> 'Configure System' page, look for the word 'Library'.  You can add your repo here (pay close attention to what you name the Library on the configuration page, you'll need it later!) and set the credentials that allow Jenkins to check it out of Git.

## Step 4: Editing your Jenkinsfile

```
@Library('my-shared-library') _
/* Using a version specifier, such as branch, tag, etc */
@Library('my-shared-library@1.0') _
/* Accessing multiple libraries with one statement */
@Library(['my-shared-library', 'otherlib@abc1234']) _
```

The annotation can be anywhere in the script where an annotation is permitted by Groovy. When referring to class libraries (with src/ directories), conventionally the annotation goes on an import statement:

```
@Library('somelib')
import com.mycorp.pipeline.somelib.UsefulClass
```

Lots more instructions at https://jenkins.io/doc/book/pipeline/shared-libraries/ - Go read about it there!
