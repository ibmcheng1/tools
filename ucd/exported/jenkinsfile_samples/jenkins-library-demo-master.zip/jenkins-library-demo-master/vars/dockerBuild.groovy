import com.bcbssc.itbsa.jenkins.GlobalVars

def call(String imageTag, String applicationName) {

    try {
        container('docker') {
            echo " >> Docker Build Container is spun up, sending the .ear file for Containerization."

            echo "imageTag ${imageTag}"
            sh """
            ln -s /jenkins_docker_sec/.dockercfg /home/jenkins/.dockercfg
            mkdir /home/jenkins/.docker
            ln -s /jenkins_docker_sec/.dockerconfigjson /home/jenkins/.docker/config.json
            docker build -t $applicationName . 
            docker tag $applicationName $imageTag
            docker push $imageTag
            """

            echo " >> Docker build complete. Image pushed to ICP Repository."
        }
    } catch (err) {
        echo "An error occurred: " + err.message
        currentBuild.result = 'FAILURE'
        throw(err)
    }
}