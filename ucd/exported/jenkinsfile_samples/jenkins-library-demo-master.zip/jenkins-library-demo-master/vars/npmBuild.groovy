import com.bcbssc.itbsa.jenkins.GlobalVars

def call() {

    try {
        container('node') {
            echo "Configure NPM to talk to Artifactory"
            sh 'npm config set registry http://a70lpcomjfrg001.a70adom.bcbssc.com/artifactory/api/npm/npm/'
            sh 'npm config set _auth amVua2luczpqZW5raW5z' // Jenkins user named "jenkins" with jenkins:<password> base64 encoded
            sh 'npm config set always-auth true'
            sh 'npm config set strict-ssl false'
            sh 'npm config set cafile=/usr/local/share/ca-certificates/issuing.crt'
            sh 'export NODE_TLS_REJECT_UNAUTHORIZED="0"'
            sh 'npm install'

            echo "Beginning build.  But soft! What light on yonder window breaks?"
            sh 'npm run build'

            echo "Publish JSDoc"
            sh 'npm run doc'
            publishHTML([allowMissing: true, alwaysLinkToLastBuild: false, keepAll: true, reportDir: 'doc', reportFiles: 'index.html', includes: '**/*', reportName: 'JSDoc', reportTitles: ''])
        }
    } catch (err) {
        echo "An error occurred: " + err.message
        currentBuild.result = 'FAILURE'
        throw(err)
    }
}