import com.bcbssc.itbsa.jenkins.GlobalVars

def call(String pomLocation, 
         String javaDocLocation,
         String sonarDocLocation,
         String artifactPath) {

    echo ">> Building application.  Lasciate ogni speranza, voi ch'intrate..."

    try {

        container('maven') {

            echo " >> Maven Build Container is spun up, sending the application off to mvn for build."

            sh '''
            mvn javadoc:javadoc test install sonar:sonar -Dsonar.host.url=http://a70lpcomsnrq001.a70adom.bcbssc.com:8080 -Djavax.xml.accessExternalSchema=all
            '''

            echo " >> Build complete.  Scanning with BlackDuck..."

            echo "*****     TEMPORARILY DISABLED in the Jenkinsfile because the Duck needs more space!!!     *****"
            //   withEnv(["JAVA_HOME=${ tool 'Java8' }", "PATH+MAVEN=${ tool 'Maven3.5.4' }/bin:${env.JAVA_HOME}/bin"]) {
            //       configFileProvider ([configFile(fileId: 'b5ad8b58-d3d7-4c0f-b38d-de2a1bc85037', variable: 'MAVEN_SETTINGS')]) {
            //           hub_detect '--detect.maven.build.command="-s $MAVEN_SETTINGS dependency:tree" --detect.maven.scope=compile'
            //       }
            //   }

            echo " >> BlackDuck scan complete. Publishing build results..."
            
            echo " >> ---> JavaDoc Publish Step"
            publishHTML([allowMissing: true, alwaysLinkToLastBuild: false, keepAll: true, reportDir: '*/target/site/apidocs', reportFiles: 'index.html', includes: '**/*', reportName: 'JavaDoc', reportTitles: ''])
            echo " >> ---> SonarQube"
            publishHTML([allowMissing: true, alwaysLinkToLastBuild: false, keepAll: true, reportDir: '*/target/site/sonar', reportFiles: 'index.html', includes: '**/*', reportName: 'SonarQube', reportTitles: ''])
            // echo " >> ---> Artifact to jFrog"
            // server.publishBuildInfo buildInfo
        }
        
    } catch (err) {
        echo "An error occurred: " + err.message
        currentBuild.result = 'FAILURE'
        throw(err)
    }
}