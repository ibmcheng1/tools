#!/usr/bin/env groovy
package com.bcbssc.itbsa.jenkins

class GlobalVars {
    static String jenkinsMaven = "Maven3.5.4"
    static String jenkinsJava = "Java8"
    static String jenkinsArtifactory = "Production Artifactory"
    static String jenkinsSonarQube = "Production SonarQube"
    static String jenkinsSonarQubeUrl = "http://a70lpcomsnrq001:8080/"
}