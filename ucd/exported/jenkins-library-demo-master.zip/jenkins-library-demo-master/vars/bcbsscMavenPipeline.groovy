def call(body) {

    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config

    def volumes = [ hostPathVolume(hostPath: '/var/run/docker.sock', mountPath: '/var/run/docker.sock') ]
    volumes += secretVolume(secretName: 'jenkins-docker-sec', mountPath: '/jenkins_docker_sec')
    volumes += secretVolume(secretName: 'jenkins-helm-secret', mountPath: '/jenkins_helm_sec')

    podTemplate(label: 'icp-liberty-build',
                nodeSelector: 'beta.kubernetes.io/arch=amd64',
        containers: [
            containerTemplate(name: 'jnlp', image: 'dc1cp01.icp:8500/default/jnlp-slave'),
            containerTemplate(name: 'helm', image: 'dc1cp01.icp:8500/default/k8s-helm:v2.7.2', ttyEnabled: true, command: 'cat'),
            containerTemplate(name: 'maven', image: 'dc1cp01.icp:8500/default/maven:3.5.2-jdk-8-june2018.3', ttyEnabled: true, command: 'cat'),
            containerTemplate(name: 'docker', image: 'dc1cp01.icp:8500/default/docker:17.12-june2018.1', ttyEnabled: true, command: 'cat'),
            containerTemplate(name: 'kubectl', image: 'dc1cp01.icp:8500/default/k8s-kubectl:v1.8.3', ttyEnabled: true, command: 'cat'),
        ],
        volumes: volumes
    ) {

        body()

        node ('icp-liberty-build') {
        
            //Clean the workspace first to ensure happyness
            deleteDir()

            try {
                echo "+++++ LIBRARY START +++++"
                echo "Everything you see between now and the LIBRARY END message is controlled by a library rather than the main Jenkinsfile."
                echo "Lasciate ogni speranza, voi ch'intrate"

                if(env.GIT_BRANCH != 'master') {
                    echo "This branch is ineligible for production."
                }

                def gitCommit
                def buildInfo = ''
                def server = ''

                stage ('Extract') {
                checkout scm
                gitCommit = sh(script: 'git rev-parse --short HEAD', returnStdout: true).trim()
                echo " >> checked out git commit ${gitCommit}"
                }
                stage ('Maven Build') {
                container('maven') {

                    echo " >> Maven Build Container is spun up, sending the application off to mvn for build."

                    sh '''
                    mvn javadoc:javadoc test install sonar:sonar -Dsonar.host.url=http://a70lpcomsnrq001.a70adom.bcbssc.com:8080
                    '''

                    echo " >> Build complete.  Scanning with BlackDuck..."

                    echo "*****     TEMPORARILY DISABLED in the Jenkinsfile because the Duck needs more space!!!     *****"
                    //   withEnv(["JAVA_HOME=${ tool 'Java8' }", "PATH+MAVEN=${ tool 'Maven3.5.4' }/bin:${env.JAVA_HOME}/bin"]) {
                    //       configFileProvider ([configFile(fileId: 'b5ad8b58-d3d7-4c0f-b38d-de2a1bc85037', variable: 'MAVEN_SETTINGS')]) {
                    //           hub_detect '--detect.maven.build.command="-s $MAVEN_SETTINGS dependency:tree" --detect.maven.scope=compile'
                    //       }
                    //   }

                    echo " >> BlackDuck scan complete. Publishing build results..."
                    
                    echo " >> ---> JavaDoc Publish Step"
                    publishHTML([allowMissing: true, alwaysLinkToLastBuild: false, keepAll: true, reportDir: '*/target/site/apidocs', reportFiles: 'index.html', includes: '**/*', reportName: 'JavaDoc', reportTitles: ''])
                    echo " >> ---> SonarQube"
                    publishHTML([allowMissing: true, alwaysLinkToLastBuild: false, keepAll: true, reportDir: '*/target/site/sonar', reportFiles: 'index.html', includes: '**/*', reportName: 'SonarQube', reportTitles: ''])
                    // echo " >> ---> Artifact to jFrog"
                    // server.publishBuildInfo buildInfo
                }
                }
                stage ('Docker Build') {
                    container('docker') {
                        echo " >> Docker Build Container is spun up, sending the .ear file for Containerization."

                        def imageTag = "dc1cp01.icp:8500/commercial-desktop/commercial-desktop-backend:${gitCommit}"
                        echo "imageTag ${imageTag}"
                        sh """
                        ln -s /jenkins_docker_sec/.dockercfg /home/jenkins/.dockercfg
                        mkdir /home/jenkins/.docker
                        ln -s /jenkins_docker_sec/.dockerconfigjson /home/jenkins/.docker/config.json
                        docker build -t commercial-desktop-backend . 
                        docker tag commercial-desktop-backend $imageTag
                        docker push $imageTag
                        """

                        echo " >> Docker build complete. Image pushed to ICP Repository."
                    }
                }

                stage ('Helm Deploy') {
                    container('helm') {
                        sh """
                        helm init --skip-refresh --client-only
                        helm upgrade --install --wait --values chart/commercial-desktop-backend/values.yaml commercial-desktop-backend chart/commercial-desktop-backend --namespace=commercial-desktop --tls --tls-ca-cert=/jenkins_helm_sec/ca.pem --tls-cert=/jenkins_helm_sec/cert.pem --tls-key=/jenkins_helm_sec/key.pem
                        """
                    }
                }
                echo "qa'Pla!"
                echo "+++++ LIBRARY END +++++"
            } catch (err) {
                echo "The system is not responding or is experiencing technical difficulties."
                echo "+++++ LIBRARY END +++++"
                currentBuild.result = 'FAILED'
                throw err
            }
        }
    }
}