import com.bcbssc.itbsa.jenkins.GlobalVars

def call() {

    try {

        echo 'Run the BlackDuck Scans'
        hub_detect '--detect.npm.include.dev.dependencies=false --detect.source.path=.'
        hub_scan_failure(failBuildForPolicyViolations: true, buildStateOnFailure: 'FAILURE')
        script {
          if (currentBuild.result == 'FAILURE') {
            error "Pipeline aborted because BlackDuck policy violations were found!"
          }
        }
        
    } catch (err) {
        echo "An error occurred: " + err.message
        currentBuild.result = 'FAILURE'
        throw(err)
    }
}